package com.rbs.pbbdhb.coordinator.adbo.model.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.pbbdhb.coordinator.adbo.enums.MortgageType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductFeeType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductTerm;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import com.rbs.pbbdhb.coordinator.adbo.enums.WaysToApply;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductResult {

  @JsonProperty(value = "class", index = 0)
  private ProductFeeType productFeeType;

  private String productCode;

  private String range;

  private String productSearchDate;

  private ProductType productType;

  private ProductTerm productTerm;

  private BigDecimal mortgageAmount;

  private BigDecimal existingBorrowing;

  private Double initialInterestRate;

  private Double ltv;

  private Boolean erc;

  @JsonIgnore
  private Boolean freeValuation;

  @JsonIgnore
  private BigDecimal valuationFeeThreshold;

  private BigDecimal productFee;

  private BigDecimal chapsFee;

  private BigDecimal cashBackValue;

  private BigDecimal initialMonthlyPayment;

  private BigDecimal productTermCost;

  private BigDecimal mortgageTermCost;

  private Integer mortgageTermYears;

  private Integer mortgageTermMonths;

  private MortgageType mortgageType;

  private BigDecimal feeWrappedInitialMonthlyPayment;

  private BigDecimal feeWrappedProductTermCost;

  private BigDecimal feeWrappedMortgageTermCost;

  private BigDecimal standardValuationFee;

  private String valuationFeeMessage;

  private Double svr;

  private Double baseRate;

  private Integer sequence;

  private String productStartDate;

  private String productEndDate;

  private String productExpiryDate;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<GMSProductFee> fees;

  private WaysToApply waysToApply;

  private Boolean freeLegal;

  private String productName;

  private String overPayment;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<String> eligibility;

  private Double trackerMarginPercent;

  private Boolean switchToFixed;

  private String switchToFixedText;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<EarlyRepaymentChargeDto> earlyRepaymentCharges;

}