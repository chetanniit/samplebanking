package com.rbs.pbbdhb.coordinator.adbo.response;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Builder
@Data
@ToString
@EqualsAndHashCode
public class DeleteAdboApplicationResponse {
    private Long noOfApplicationsDeleted;
}
