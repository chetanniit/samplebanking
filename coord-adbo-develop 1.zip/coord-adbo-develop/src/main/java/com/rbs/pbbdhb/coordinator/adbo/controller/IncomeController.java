package com.rbs.pbbdhb.coordinator.adbo.controller;


import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.IncomeControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.IncomeRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.IncomeResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.IncomeService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import com.rbs.pbbdhb.coordinator.adbo.validator.IncomeDetailsValidator;
import io.swagger.v3.oas.annotations.Parameter;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
@RequestMapping("/income")
public class IncomeController implements IncomeControllerSwagger {

  private final IncomeService incomeService;
  private final IncomeDetailsValidator incomeDetailsValidator;

  @InitBinder("incomeRequest")
  protected void initIncomeDetailsBinder(WebDataBinder binder) {
    binder.addValidators(incomeDetailsValidator);
  }

  @Override
  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<IncomeResponse>> getIncomeDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getIncomeDetails start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<List<IncomeResponse>> response = new ResponseEntity<>(incomeService.getIncomeDetails(accountNumber),
        HttpStatus.OK);
    log.info("getIncomeDetails end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  @Override
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveIncomeDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "IncomeRequest") @RequestBody @Valid IncomeRequest incomeRequest) {
    log.info("saveIncomeDetails start - Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute, incomeRequest);
    TenantProvider.applyBrand(brand);
    incomeService.saveIncomeDetails(accountNumber, incomeRequest);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveIncomeDetails end's with response {}, account_number: {}, brand: {}, channel: {}",response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }


}
