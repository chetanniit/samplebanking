package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.ValidateAccountControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.BankDetailsResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.ValidateAccountRequest;
import com.rbs.pbbdhb.coordinator.adbo.service.ValidateAccountService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class ValidateAccountController implements ValidateAccountControllerSwagger {

  private final ValidateAccountService validateAccountService;

  @Override
  @PostMapping(path = "/validateAccount", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<BankDetailsResponse> validateAccount(
      @Parameter(name = Headers.BRAND, description = Constants.BRAND_DESCRIPTION)
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(RBS|rbs|nwb|NWB)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final ValidateAccountRequest validateAccountRequest) {
    log.info("validateAccount - Headers - brand: {}, channel: {}, request: {}", brand, channelRoute, validateAccountRequest);
    TenantProvider.applyBrand(brand);
    ResponseEntity<BankDetailsResponse> response = ResponseEntity.ok(this.validateAccountService.validateAccount(brand, validateAccountRequest));
    log.info("validateAccount end's for, brand: {}, channel: {}", brand, channelRoute);
    return response;
  }
}