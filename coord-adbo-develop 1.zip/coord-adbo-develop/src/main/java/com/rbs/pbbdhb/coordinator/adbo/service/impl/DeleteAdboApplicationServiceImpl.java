package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.service.DeleteAdboApplicationService;
import com.rbs.pbbdhb.coordinator.brand.BrandedComponentsFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile({ "local", "dev", "uat", "nft" })
@RequiredArgsConstructor
@Service
@Slf4j
public class DeleteAdboApplicationServiceImpl implements DeleteAdboApplicationService {

    private final BrandedComponentsFactory factory;
    @Override
    public Long deleteAdboApplication(String accountNumber) {
      return factory.getAdboCaseDetailsRepository().deleteByAccountNumber(accountNumber);
    }
}
