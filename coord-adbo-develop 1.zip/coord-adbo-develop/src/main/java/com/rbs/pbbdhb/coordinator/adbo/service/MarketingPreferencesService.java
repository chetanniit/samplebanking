package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.MarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferencesResponse;

public interface MarketingPreferencesService {

  MarketingPreferencesResponse getMarketingPreferences(String customerId, String accountNumber);


  UpdateMarketingPreferencesResponse updateMarketingPreferences(String customerId, String accountNumber,
      MarketingPreferencesResponse marketingPreferencesRequest);


  AdboCaseDetails updateIsMarketingPreference(String customerId, String accountNumber);

}
