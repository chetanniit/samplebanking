package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.DashboardAndTrackingControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.response.DashboardAndTrackingDetails;
import com.rbs.pbbdhb.coordinator.adbo.service.DashboardStatusService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@Validated
@Slf4j
@RequestMapping("/dashboard-status")
@RequiredArgsConstructor
public class DashboardAndTrackingController implements DashboardAndTrackingControllerSwagger {

    private final DashboardStatusService dashboardStatusService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DashboardAndTrackingDetails> getDashboardStatus(
            @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
            @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
            @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
        log.info("getDashboardStatus start with headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
        TenantProvider.applyBrand(brand);
        ResponseEntity<DashboardAndTrackingDetails> response = new ResponseEntity<>(
                dashboardStatusService.getDashboardAndTracking(accountNumber), HttpStatus.OK);
        log.info("getDashboardStatus end's with response {} account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
        return response;
    }


}
