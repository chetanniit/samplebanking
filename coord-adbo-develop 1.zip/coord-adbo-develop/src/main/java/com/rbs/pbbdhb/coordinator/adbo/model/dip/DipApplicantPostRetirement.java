package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.math.BigDecimal;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipApplicantPostRetirement {

  private final LirMarkerEnum lirMarker;

  private final BigDecimal regularAnnualincome;

  private final BigDecimal otherAnnualincome;

  public enum LirMarkerEnum {
    NOT_LIR,
    LIR_MORE_THAN_TEN_YEARS,
    LIR_EQUAL_OR_LESS_THAN_TEN_YEARS
  }

}
