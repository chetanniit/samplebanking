package com.rbs.pbbdhb.coordinator.adbo.entity.income;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.BenefitType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.OtherIncomeSource;
import com.rbs.pbbdhb.coordinator.adbo.enums.FrequencyType;
import java.math.BigDecimal;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class OtherIncome  {

  private OtherIncomeSource sourceOfIncome;

  private BenefitType benefitType;

  private BigDecimal amount;

  private FrequencyType frequency;

}
