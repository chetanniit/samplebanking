package com.rbs.pbbdhb.coordinator.adbo.response;

import java.io.Serializable;
import java.math.BigDecimal;

import com.rbs.pbbdhb.coordinator.adbo.enums.BrandEnum;

import java.math.RoundingMode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SubAccountMinMaxRepaymentVo implements Serializable  {
  
  /**
   * 
   */
  private static final long serialVersionUID = 7378423667169405595L;
  
  private Integer subAccountNumber;
  private BigDecimal minRepayment;
  private BigDecimal maxRepayment;

  public SubAccountMinMaxRepaymentVo(BigDecimal minRepayment,BigDecimal maxRepayment){
    this.minRepayment=minRepayment;
    this.maxRepayment=maxRepayment;
  }

  public BigDecimal getMinRepayment(){
    return minRepayment.setScale(0, RoundingMode.DOWN);
  }

  public BigDecimal getMaxRepayment(){
    return maxRepayment.setScale(0, RoundingMode.UP);
  }

}
