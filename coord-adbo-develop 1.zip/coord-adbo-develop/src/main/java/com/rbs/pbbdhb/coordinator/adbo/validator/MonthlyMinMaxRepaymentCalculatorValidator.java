package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyMinMaxRepaymentCalculator;
import org.springframework.stereotype.Component;

@Component
public class MonthlyMinMaxRepaymentCalculatorValidator extends AbstractTermValidator<MonthlyMinMaxRepaymentCalculator> {

  @Override
  protected Class<MonthlyMinMaxRepaymentCalculator> supportedClass() {
    return MonthlyMinMaxRepaymentCalculator.class;
  }

  @Override
  protected Integer getRepaymentTermMonths(MonthlyMinMaxRepaymentCalculator minMaxRepaymentRequest) {
    return minMaxRepaymentRequest.getRepaymentTermMonths();
  }

  @Override
  protected Integer getRepaymentTermYears(MonthlyMinMaxRepaymentCalculator minMaxRepaymentRequest) {
    return minMaxRepaymentRequest.getRepaymentTermYears();
  }
}
