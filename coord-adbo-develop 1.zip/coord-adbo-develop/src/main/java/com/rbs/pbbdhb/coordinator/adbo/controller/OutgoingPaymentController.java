package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.OutgoingPaymentControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.service.OutgoingPaymentsService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import com.rbs.pbbdhb.coordinator.adbo.validator.OutgoingPaymentsDetailsValidator;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequestMapping("/outgoings")
public class OutgoingPaymentController implements OutgoingPaymentControllerSwagger {

  private final OutgoingPaymentsService outgoingPaymentsService;
  private final OutgoingPaymentsDetailsValidator outgoingPaymentsDetailsValidator;

  @Autowired
  public OutgoingPaymentController(OutgoingPaymentsService outgoingPaymentsService,
      OutgoingPaymentsDetailsValidator outgoingPaymentsDetailsValidator) {
    this.outgoingPaymentsService = outgoingPaymentsService;
    this.outgoingPaymentsDetailsValidator = outgoingPaymentsDetailsValidator;
  }

  /**
   * This method is used to call the validation framework to perform the validation on the input fields. If the validation got fails then
   * will return bad request with appropriate error message to client.
   */
  @InitBinder("outgoingPaymentsDetails")
  protected void initOutgoingPaymentsDetailsBinder(WebDataBinder binder) {
    binder.addValidators(outgoingPaymentsDetailsValidator);
  }

  /**
   * This method is responsible for persist the outgoing payments details into the mongodb.
   *
   * @param accountNumber           is a unique identification number
   * @param brand                   is nwb or rbs
   * @param outgoingPaymentsDetails object contains all outgoing payments details
   * @return void
   */
  @Override
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveOutgoingPaymentsDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "outgoingPaymentDetails") @RequestBody @Valid OutgoingPaymentsDetails outgoingPaymentsDetails) {
    log.info("saveOutgoingPaymentsDetails start - Headers - account_number: {}, brand: {}, channel: {}, request: {}",
        accountNumber, brand, channelRoute, outgoingPaymentsDetails);
    TenantProvider.applyBrand(brand);
    outgoingPaymentsService.saveOutgoingPayments(accountNumber, outgoingPaymentsDetails);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveOutgoingPaymentsDetails end's with response {},account_number: {}, brand: {}, channel: {}",
        response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * This method is responsible to return all outgoing payments of a customer.
   *
   * @param accountNumber is a unique identification number
   * @param brand         is a nwb or rbs
   * @return outgoingPaymentsDetails object contains all outgoing payments details
   */
  @Override
  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<OutgoingPaymentsDetails> getOutgoingPaymentsDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getOutgoingPaymentsDetails - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<OutgoingPaymentsDetails> response = new ResponseEntity<>(
        outgoingPaymentsService.getOutgoingPayments(accountNumber), HttpStatus.OK);
    log.info("getOutgoingPaymentsDetails end's with response {}, account_number: {}, brand: {}, channel: {}",
        response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }
}
