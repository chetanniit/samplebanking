package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmploymentType;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class PreviousEmployment  {

  private String name;

  private EmploymentType employmentStatus;

  private String employmentBasis;

  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate startDate;

  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate endDate;
}
