package com.rbs.pbbdhb.coordinator.adbo.request;

import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;



@Data
@ToString
@EqualsAndHashCode
public class MortgageQuoteRequest  {
  
  @Valid
  @NotNull(message = "For Additional Borrowing with switch, subAccount information cannot be null")
  private List<MortgageQuoteSubAccountRequest> subAccounts;

}
