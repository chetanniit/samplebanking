package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.AgreementsAndDisclaimers;
import com.rbs.pbbdhb.coordinator.adbo.entity.ReadyToStart;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode;
import com.rbs.pbbdhb.coordinator.adbo.request.ReadyToStartRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.ReadyToStartResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ReadyToStartService;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReadyToStartServiceImpl implements ReadyToStartService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public void saveFraudWarningAndLossOfProtectionAndImportantInfoAboutUsDisclaimers(final String accountNumber,
      final ReadyToStartRequest readyToStartRequest) {

    AdboCaseDetails caseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    if (!Objects.equals(JourneyValidationResultCode.PASS.getLabel(), caseDetails.getValidationResult())) {

      log.info("Ready To Start Page details can't be saved for this account number {}, journey validation status {}", accountNumber,
          caseDetails.getValidationResult());
      throw new BusinessException(Constants.READY_TO_START, HttpStatus.BAD_REQUEST.value());
    }
    adboCaseDetailsDao.save(mapReadyToStartRequest(caseDetails, readyToStartRequest));
    log.info("Ready To Start Page details have been saved/updated successfully, accountNumber {}", accountNumber);

  }

  @Override
  public ReadyToStartResponse getFraudWarningAndLossOfProtectionAndImportantInfoAboutUsDisclaimers(final String accountNumber) {

    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    AgreementsAndDisclaimers mainApplicantAgreementAndDisclaimers = adboCaseDetails.getAdboApplicants().get(ApplicantType.MAIN)
        .getAgreementsAndDisclaimers();
    return ReadyToStartResponse.builder()
        .hasAcknowledgedFraudWarning(
            Objects.isNull(adboCaseDetails.getReadyToStart()) ? null : adboCaseDetails.getReadyToStart().getHasAcknowledgedFraudWarning())
        .importantInformationAboutUs(Objects.isNull(mainApplicantAgreementAndDisclaimers) ? null
            : mainApplicantAgreementAndDisclaimers.getImportantInformationAboutUs())
        .selfServiceLossOfProtectionDocument(Objects.isNull(mainApplicantAgreementAndDisclaimers) ? null
            : mainApplicantAgreementAndDisclaimers.getSelfServiceLossOfProtectionDocument())
        .build();

  }

  private AdboCaseDetails mapReadyToStartRequest(AdboCaseDetails caseDetails, ReadyToStartRequest readyToStartRequest) {

    caseDetails.setReadyToStart(new ReadyToStart(readyToStartRequest.getHasAcknowledgedFraudWarning()));
    AgreementsAndDisclaimers mainApplicantAgreementAndDisclaimers = caseDetails.getAdboApplicants().get(ApplicantType.MAIN)
        .getAgreementsAndDisclaimers();
    if (Objects.isNull(mainApplicantAgreementAndDisclaimers)) {
      mainApplicantAgreementAndDisclaimers = new AgreementsAndDisclaimers();
    }
    mainApplicantAgreementAndDisclaimers.setImportantInformationAboutUs(readyToStartRequest.getImportantInformationAboutUs());
    mainApplicantAgreementAndDisclaimers
        .setSelfServiceLossOfProtectionDocument(readyToStartRequest.getSelfServiceLossOfProtectionDocument());
    caseDetails.getAdboApplicants().get(ApplicantType.MAIN).setAgreementsAndDisclaimers(mainApplicantAgreementAndDisclaimers);
    return caseDetails;

  }

}
