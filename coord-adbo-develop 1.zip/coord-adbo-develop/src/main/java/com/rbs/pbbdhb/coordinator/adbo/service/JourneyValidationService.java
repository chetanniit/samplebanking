package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidationApiResponse;

public interface JourneyValidationService {

  JourneyValidationApiResponse getJourneyValidation(String accountNumber, String cin, boolean isRequiredStatusReset);

}
