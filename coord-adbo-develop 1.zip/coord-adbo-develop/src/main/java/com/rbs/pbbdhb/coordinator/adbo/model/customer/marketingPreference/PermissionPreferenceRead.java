package com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PermissionPreferenceRead {

  private String perPrefSource;
  private String perPrefSourceLastUpdatedTimestamp;
  private String status;
  private String lastUpdatedTimestamp;
  private PreferenceType preferenceType;
  private PreferenceValue preferenceValue;
}

