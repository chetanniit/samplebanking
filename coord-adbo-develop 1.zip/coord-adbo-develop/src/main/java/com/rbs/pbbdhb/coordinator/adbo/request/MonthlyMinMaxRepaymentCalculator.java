package com.rbs.pbbdhb.coordinator.adbo.request;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MonthlyMinMaxRepaymentCalculator implements Serializable {

  private static final long serialVersionUID = 6200603029012003421L;

  @NotNull(message = "borrowingAmount cannot be null")
  @Min(value = 10000, message = "borrowingAmount not lesser than 10000")
  @Max(value = 500000, message = "borrowingAmount not greater than 500000")
  private Integer borrowingAmount;

  @NotNull(message = "totalTrueBalance cannot be null")
  private Integer totalTrueBalance;

  @NotNull(message = "repaymentTermYears cannot be null")
  @Min(value = 3, message = "repaymentTermYears must not lesser than 3 years")
  @Max(value = 40, message = "repaymentTermYears must not greater than 40 years")
  private Integer repaymentTermYears;

  @NotNull(message = "repaymentTermMonths cannot be null")
  @Min(value = 0, message = "repaymentTermMonths must not lesser than 0 months")
  @Max(value = 11, message = "repaymentTermMonths must not greater than 11 months")
  private Integer repaymentTermMonths;

  @NotNull(message = "loanToValue must not be null")
  @Max(value = 90, message = "loanToValue must not greater than 90%")
  private Double loanToValue;
  
  private Boolean additionalBorrowingWithSwitch;
    
}
