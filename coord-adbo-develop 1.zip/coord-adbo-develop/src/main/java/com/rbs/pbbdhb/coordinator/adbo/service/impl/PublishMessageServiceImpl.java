package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.kafka.AdboKafkaEventDto;
import com.rbs.pbbdhb.coordinator.adbo.kafka.JointDisclaimersAndMpUpdateKafkaEventDto;
import com.rbs.pbbdhb.coordinator.adbo.service.PublishMessageService;
import java.util.Objects;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

/**
 * PublishMessageService implementation class
 */
@Slf4j
@Service
public class PublishMessageServiceImpl implements PublishMessageService {

  private static final String CHANNEL = "channel";
  private static final String JOURNEY = "journey";
  private final KafkaTemplate<String, Object> genericKafkaTemplate;

  @Autowired
  public PublishMessageServiceImpl(KafkaTemplate<String, Object> genericKafkaTemplate) {
    this.genericKafkaTemplate = genericKafkaTemplate;
  }

  /**
   * Posting message to the given topic
   *
   * @param adboKafkaEventDto which has a- brandName,topic name,channel,journey and adboCaseDetails details
   */
  @Override
  @SneakyThrows
  public void publishMessageToTopic(AdboKafkaEventDto adboKafkaEventDto) {
    log.info("publishMessageToTopic is started for publish message to the kafka for accountNumber {}",
        adboKafkaEventDto.getAdboCaseDetails().getAccountNumber());
    String key = UUID.randomUUID().toString();
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    Message<String> message = MessageBuilder
        .withPayload(objectMapper.writeValueAsString(adboKafkaEventDto.getAdboCaseDetails()))
        .setHeader(KafkaHeaders.TOPIC, adboKafkaEventDto.getTopicName())
        .setHeader(KafkaHeaders.KEY, key)
        .setHeader(CHANNEL, adboKafkaEventDto.getChannel())
        .setHeader(JOURNEY, adboKafkaEventDto.getJourney())
        .setHeader(Headers.BRAND, adboKafkaEventDto.getBrandName())
        .build();
    publishMessage(message, adboKafkaEventDto.getAdboCaseDetails().getAccountNumber(), adboKafkaEventDto.getTopicName());
    log.info("publishMessageToTopic is ended for publish message to the kafka for accountNumber {}",
        adboKafkaEventDto.getAdboCaseDetails().getAccountNumber());
  }

  @Override
  @SneakyThrows
  public void publishJointApplicantMessageToTopic(JointDisclaimersAndMpUpdateKafkaEventDto jointDisclaimersAndMpUpdateKafkaEventDto,
      String accountNumber) {
    log.info("publishJointApplicantMessageToTopic is started for publish message to the kafka for accountNumber {}",
        accountNumber);
    String key = UUID.randomUUID().toString();
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    Message<String> message = MessageBuilder
        .withPayload(objectMapper.writeValueAsString(jointDisclaimersAndMpUpdateKafkaEventDto.getJointDisclaimersAndMp()))
        .setHeader(KafkaHeaders.TOPIC, jointDisclaimersAndMpUpdateKafkaEventDto.getTopicName())
        .setHeader(KafkaHeaders.KEY, key)
        .setHeader(CHANNEL, jointDisclaimersAndMpUpdateKafkaEventDto.getChannel())
        .setHeader(JOURNEY, jointDisclaimersAndMpUpdateKafkaEventDto.getJourney())
        .setHeader(Headers.BRAND, jointDisclaimersAndMpUpdateKafkaEventDto.getBrandName())
        .build();
    publishMessage(message, accountNumber, jointDisclaimersAndMpUpdateKafkaEventDto.getTopicName());
    log.info("publishJointApplicantMessageToTopic is ended for publish message to the kafka for accountNumber {}",
        accountNumber);
  }

  private void publishMessage(Message<String> message, String accountNumber, String topicName) {
    log.info("publishMessage is start for publish message to the kafka for accountNumber {}, topic {}",
        accountNumber, topicName);
    var resultCompletableFuture = genericKafkaTemplate.send(message);
    resultCompletableFuture.whenComplete(((sendResult, throwable) -> {
      if (Objects.isNull(throwable)) {
        onSuccess(sendResult);
      } else {
        onFailure(throwable);
      }
    }));
    log.info("Posted message to topic : {}, accountNumber {}", topicName,
        accountNumber);
    log.info("publishMessage is end accountNumber {}", accountNumber);
  }

  private void onSuccess(SendResult<String, Object> result) {
    log.info("Message successfully delivered to the kafka, partition id {}, offset {}, key {}", result.getRecordMetadata().partition(),
        result.getRecordMetadata().offset(), result.getProducerRecord().key());
  }

  private void onFailure(Throwable ex) {
    log.error("Unable to deliver message, exception occurred {}", ex.getMessage());
  }
}
