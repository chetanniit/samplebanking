package com.rbs.pbbdhb.coordinator.adbo.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
public class DependentExpenseDetails  {

  /**
   * monthly payment for childcare
   */
  private BigDecimal monthlyPayment;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyPayment;

  /**
   * Is customer going to pay childcare expenses more than 6 months
   */
  private Boolean continueMoreThanSixMonths;


  /**
   * Outgoings Owner
   */
  @NotNull(message = "Owner type cannot be null")
  private OutgoingsOwnerType owner;


}
