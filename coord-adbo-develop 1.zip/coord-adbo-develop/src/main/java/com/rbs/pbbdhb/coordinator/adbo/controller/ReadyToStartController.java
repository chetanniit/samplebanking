package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.ReadyToStartControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.ReadyToStartRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.ReadyToStartResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ReadyToStartService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class ReadyToStartController implements ReadyToStartControllerSwagger {

  private final ReadyToStartService readyToStartService;

  /**
   * Before Starting AIP and Product selection ,Customer need to Acknowledge the fraud warnings. This Post call will save the user selected
   * value on our DB.
   */
  @Override
  @PostMapping(value = "/readyToStart", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveReadyToStart(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final ReadyToStartRequest readyToStartRequest) {
    log.info("saveReadyToStart start - Headers - account_number: {}, brand: {}, channel: {}, request: ", accountNumber, brand, channelRoute,
        readyToStartRequest);
    TenantProvider.applyBrand(brand);
    readyToStartService.saveFraudWarningAndLossOfProtectionAndImportantInfoAboutUsDisclaimers(accountNumber, readyToStartRequest);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveReadyToStart end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * Determines weather customer has read the fraud warnings or not(fetching from DB).
   */
  @Override
  @GetMapping(value = "/readyToStart", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ReadyToStartResponse> getReadyToStart(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getReadyToStart start - Headers account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<ReadyToStartResponse> response = new ResponseEntity<>(
        readyToStartService.getFraudWarningAndLossOfProtectionAndImportantInfoAboutUsDisclaimers(accountNumber),
        HttpStatus.OK);
    log.info("getReadyToStart end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }


}
