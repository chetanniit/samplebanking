package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.kafka.AdboKafkaEventDto;
import com.rbs.pbbdhb.coordinator.adbo.kafka.JointDisclaimersAndMpUpdateKafkaEventDto;

/**
 * Service class to publish message to topic
 */
public interface PublishMessageService {

  /**
   * Posting message to the given topic
   *
   * @param adboKafkaEventDto which has a- brandName,topic name,channel,journey and adboCaseDetails details
   */
  void publishMessageToTopic(AdboKafkaEventDto adboKafkaEventDto);

  /**
   * Posting message to the given topic
   *
   * @param jointDisclaimersAndMpUpdateKafkaEventDto which has a- brandName,topic name,channel,journey and jointApplicantContact details
   */
  void publishJointApplicantMessageToTopic(JointDisclaimersAndMpUpdateKafkaEventDto jointDisclaimersAndMpUpdateKafkaEventDto,
      String accountNumber);
}
