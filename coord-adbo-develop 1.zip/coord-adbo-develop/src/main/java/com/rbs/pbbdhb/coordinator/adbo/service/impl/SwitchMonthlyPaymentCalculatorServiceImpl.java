package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentRequest.ADBO_SUB_ACCOUNT_NUMBER;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.mapper.AdboSwitchRepaymentRequestMapper;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AboSwitchRepaymentSubAccountResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboSwitchMonthlyPaymentsResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboSwitchMonthlyPaymentsSubAccount;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.SwitchMonthlyPaymentCalculatorService;
import java.math.BigDecimal;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class SwitchMonthlyPaymentCalculatorServiceImpl implements SwitchMonthlyPaymentCalculatorService {

  private final ApiService apiService;
  private final AdboSwitchRepaymentRequestMapper adboSwitchRepaymentRequestMapper;
  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public AdboSwitchMonthlyPaymentsResponse getAdboSwitchMonthlyPayments(String accountNumber, BigDecimal interestRate
  ) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    AdditionalBorrowingCalculator calculator = adboCaseDetails.getAdditionalBorrowingCalculator();

    AdboSwitchRepaymentResponse adboSwitchRepaymentResponse = apiService.getAdboSwitchMonthlyPayments(
        adboSwitchRepaymentRequestMapper.map(calculator, interestRate, null));

    Map<String, BigDecimal> newMonthlyPaymentsBySubAccountNumber = adboSwitchRepaymentResponse.getSubAccountRepaymentDetails().stream()
        .collect(
            Collectors.toMap(AboSwitchRepaymentSubAccountResponse::getSubAccountNumber,
                AboSwitchRepaymentSubAccountResponse::getRepaymentAmountWithoutProductFee));
    return AdboSwitchMonthlyPaymentsResponse.builder()
        .sequenceNumber(calculator.getSubAccountDetails().stream().mapToInt(SubAccount::getSequenceNumber).max().getAsInt() + 1)
        .newMonthlyPayment(newMonthlyPaymentsBySubAccountNumber.get(ADBO_SUB_ACCOUNT_NUMBER))
        .subAccounts(
            calculator.getSubAccountDetails().stream()
                .filter(subAccount -> isTrue(subAccount.getSelectedForSwitch()))
                .map(s ->
                    AdboSwitchMonthlyPaymentsSubAccount.builder()
                        .sequenceNumber(s.getSequenceNumber())
                        .subAccountNumber(s.getSubAccountNumber())
                        .monthlyPayment(s.getMonthlyPayment())
                        .newMonthlyPayment(newMonthlyPaymentsBySubAccountNumber.get(Integer.toString(s.getSubAccountNumber())))
                        .build())
                .collect(toList()))
        .build();
  }

}
