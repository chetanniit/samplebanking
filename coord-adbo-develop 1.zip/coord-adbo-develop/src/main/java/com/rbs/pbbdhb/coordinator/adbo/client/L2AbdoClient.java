package com.rbs.pbbdhb.coordinator.adbo.client;

import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.TrueBalanceResponse;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

//TODO: use feign for L2 calls
//@FeignClient("msvc-adbo")
public interface L2AbdoClient {

  @RequestMapping(method = RequestMethod.GET, value = "/accounts")
  AccountSummaryResponse getAccountSummary(@RequestHeader("BRAND_HEADER_PARAM") String brand, String accountNumber);

  @RequestMapping(method = RequestMethod.GET, value = "/truebalance")
  TrueBalanceResponse getTrueBalance(@RequestHeader("BRAND_HEADER_PARAM") String brand, String accountNumber);
}
