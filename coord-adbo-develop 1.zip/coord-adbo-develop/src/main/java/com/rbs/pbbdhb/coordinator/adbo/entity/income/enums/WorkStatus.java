package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;

public enum WorkStatus {

  WORKING("WORKING"), NOT_WORKING("NOT_WORKING"), RETIRED("RETIRED");

  private final String label;

  WorkStatus(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
