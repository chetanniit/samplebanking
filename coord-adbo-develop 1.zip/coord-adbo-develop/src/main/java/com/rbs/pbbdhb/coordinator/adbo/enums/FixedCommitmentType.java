package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum FixedCommitmentType {
  CAREER_RELATED_SUBSCRIPTION_OR_QUALIFICATIONS("CAREER_RELATED_SUBSCRIPTION_OR_QUALIFICATIONS"),
  CHILD_MAINTENANCE("CHILD_MAINTENANCE"),
  GROUND_RENT_OR_SERVICE_CHARGE("GROUND_RENT_OR_SERVICE_CHARGE"),
  SCHOOL_OR_EDUCATION_FEES("SCHOOL_OR_EDUCATION_FEES"),
  OTHER("OTHER");

  private final String label;

  FixedCommitmentType(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
