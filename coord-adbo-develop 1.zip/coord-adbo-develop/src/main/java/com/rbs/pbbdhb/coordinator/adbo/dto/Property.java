package com.rbs.pbbdhb.coordinator.adbo.dto;

import com.natwest.pbbdhb.commondictionaries.enums.property.ValuationType;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Property {

  private String valuationDate;
  private BigDecimal valuationAmount;
  private String valuationType;
  private Boolean buyToLet;
}
