package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.CustomerControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsPatch;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.CustomerService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class CustomerController implements CustomerControllerSwagger {

  private final CustomerService customerService;

  /**
   * Fetches borrower's personal details information.
   *
   * <p>
   * Fetched data contains basic data like names and dob from the gms database as well as all data send to coordinator in the PATCH
   * request.
   * </p>
   *
   * @return response entity with personal details object
   */
  @Override
  @GetMapping(path = "/personalDetails", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<PersonalDetailsResponse>> getPersonalDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.CIN) @CIN String cin,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getPersonalDetails start - Headers - account_number: {}, cin: {}, brand: {}, channel: {}", accountNumber, cin, brand,
        channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<List<PersonalDetailsResponse>> response = new ResponseEntity<>(
        customerService.getPersonalDetails(accountNumber), HttpStatus.OK);
    log.info("getPersonalDetails end with response {}, account_number {}, brand: {}, channel: {}",response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * Persists borrower's personal details information
   *
   * <p>
   * Stores additional data provided by user. From prefetched gms data only email and mobile number can be overwritten.
   * </p>
   */
  @PostMapping(path = "/personalDetails", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> savePersonalDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid PersonalDetailsPatch personalDetails) {
    log.info("savePersonalDetails start- Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute, personalDetails);
    TenantProvider.applyBrand(brand);
    customerService.patchPersonalDetails(accountNumber, personalDetails);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("savePersonalDetails end's with response {} account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

}
