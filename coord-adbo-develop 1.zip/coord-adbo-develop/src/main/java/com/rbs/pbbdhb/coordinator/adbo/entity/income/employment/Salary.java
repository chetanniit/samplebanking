package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import java.math.BigDecimal;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Getter
@Setter
public class Salary  {

  private BigDecimal salary;
  private BigDecimal dividend;
  private Integer year;
}
