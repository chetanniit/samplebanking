package com.rbs.pbbdhb.coordinator.adbo.dto;

import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
@Builder

public class AdboDashboardApplicants {
    /**
     * The applicantType either MAIN OR JOINT
     */
    private ApplicantType applicantType;
    /**
     *
     * The consent value to be set based on the marketing preference value
     */
    private boolean consent;

    /**
     * The docUpload field is populated how many days remaining to upload the documents
     */
    private DashboardDocUploadDetails docUpload;


}

