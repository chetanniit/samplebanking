package com.rbs.pbbdhb.coordinator.adbo.dao.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.OUTDATED_RECORD;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * Class to filter out records with outdated data.
 */
@Component
public class DetailsTtlFilter extends AbstractDetailsFilter {

  /**
   * Time to live in days
   */
  private final int daysToLive;

  public DetailsTtlFilter(@Value("${mongodb.adbo.details.daysToLive:14}") int daysToLive) {
    super(HttpStatus.NOT_FOUND, OUTDATED_RECORD);
    this.daysToLive = daysToLive;
  }

  public static boolean isDateInRange(LocalDateTime startDate, LocalDateTime endDate) {

    LocalDateTime currentDate = LocalDateTime.now();
    return !currentDate.isBefore(startDate) && !currentDate.isAfter(endDate);
  }

  /**
   * Check if record's creation time or record's case id creation time is not too far in the past.
   *
   * @param adboCaseDetails the input argument
   * @return true if record's data is up-to-date or false otherwise
   */
  @Override
  public boolean test(AdboCaseDetails adboCaseDetails) {
    if (adboCaseDetails.getModifiedDate() != null && !isDateInRange(adboCaseDetails.getModifiedDate(),
        adboCaseDetails.getModifiedDate().plusDays(180))) {
      return Boolean.FALSE;
    } else {
      return Boolean.TRUE;
    }
  }
}
