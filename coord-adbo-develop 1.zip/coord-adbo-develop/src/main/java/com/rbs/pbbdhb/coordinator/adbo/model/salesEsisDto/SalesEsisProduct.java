package com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Builder
@Getter
@Setter
public class SalesEsisProduct {

  private BigDecimal loanAmount;

  private Integer termYears;

  private Integer termMonths;

  private String calculationType;

  private BigDecimal initialInterestRate;

  private BigDecimal svr;

  private BigDecimal baseRate;

  private String productCode;

  private String productName;

  private LocalDate productSelectionDate;

  private LocalDate productEndDate;

  private String productType;

  private String productTerm;

  private BigDecimal ltv;

  private BigDecimal productFee;

  private Boolean feeAddedToLoan;

  private BigDecimal valuationFee;

  private BigDecimal chapsFee;

  private BigDecimal cashBackValue;

  private List<ErcItem> erc;

  private Boolean freeLegal;
}
