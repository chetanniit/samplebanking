package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipBankDetails {

  private final String dateOpened;

  private final String bankName;

  private final Boolean debitCard;

  private final String sortCode;

  private final String accountNumber;

}
