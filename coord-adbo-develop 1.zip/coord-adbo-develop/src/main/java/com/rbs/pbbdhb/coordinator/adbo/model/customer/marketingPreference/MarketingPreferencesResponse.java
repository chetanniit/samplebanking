package com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketingPreferencesResponse {

  @ToString.Exclude
  private String emailAddress;

  @ToString.Exclude
  private String postalAddress;

  @ToString.Exclude
  private String phoneNumber;
  @NotNull(message = "emailMarketing cannot be null, needs to be either true or false")
  private Boolean emailMarketing;

  @NotNull(message = "postalMarketing cannot be null, needs to be either true or false")
  private Boolean postalMarketing;

  @NotNull(message = "phoneMarketing cannot be null, needs to be either true or false")
  private Boolean phoneMarketing;

  private String lawfulBasisMarker;
  private Boolean isMobileNumberChanged;
  private Boolean isEmailChanged;

}
