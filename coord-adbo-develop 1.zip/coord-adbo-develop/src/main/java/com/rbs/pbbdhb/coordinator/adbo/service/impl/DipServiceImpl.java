package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.REPAYMENT_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.SELF_EMPLOYED_CURRENT_YEAR_PROFIT_NOT_FOUND;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.SELF_EMPLOYED_CURRENT_YEAR_SALARY_OR_DIVIDEND_NOT_FOUND;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.SELF_EMPLOYED_PREVIOUS_YEAR_PROFIT_NOT_FOUND;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.SELF_EMPLOYED_PREVIOUS_YEAR_SALARY_OR_DIVIDEND_NOT_FOUND;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.JOINT1;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.MAIN;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAdditionalBorrowing.DEFAULT_REPAYMENT_VEHICLE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum.OWNER_MORTGAGED;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication.DEFAULT_APPLICATION_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication.DEFAULT_BUYER_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication.DEFAULT_CHANNEL;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication.DEFAULT_GOVT_SHARED_EQUITY_SCHEME;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication.DEFAULT_LOAN_PURPOSE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipDetails.dipDetails;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipFinancialCommitment.DipFinancialCommitmentTypeEnum.ADULT_CARE_COSTS;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipFinancialCommitment.DipFinancialCommitmentTypeEnum.OTHER_COMMITTED_EXPENDITURE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipFinancialCommitment.DipFinancialCommitmentTypeEnum.RENT;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.BenefitTypeEnum.OTHER_TAXABLE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.ANNUALLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.BIANNUALLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.FORTNIGHTLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.FOUR_WEEKLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.MONTHLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.QUARTERLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum.WEEKLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipSubAccount.DEFAULT_SUB_ACCOUNT_REPAYMENT_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipSubAccount.subAccount;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.Telephone.PhoneTypeEnum.MOBILE;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.childCareExpenseToDipFinancialCommitmentTypeMap;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.financialCommitmentTypeToDipFinancialCommitmentTypeMap;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.getDipFrequencyEnum;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.getIncomeTypeEnum;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.loanTypeToDipLoanTypeMap;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.occupancyStatusToDipOccupancyStatusEnum;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.otherIncomeFrequencyTypeToDipOtherIncomeFrequencyTypeMap;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.otherIncomeSourceMap;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.pensionTypeToDipPensionTypeMap;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.propertyGmsBuildTypeToDipPropertyTypeEnum;
import static com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil.selfEmployedBusinessTypeMap;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.getAverageAmount;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.getKey;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.getRoundDownAmount;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.hasContinuesEmployment;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.math.BigDecimal.ZERO;
import static java.util.Arrays.asList;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.BooleanUtils.isNotTrue;
import static org.apache.commons.lang3.BooleanUtils.isTrue;
import static org.apache.commons.lang3.StringUtils.isAllBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.springframework.util.CollectionUtils.isEmpty;

import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.entity.CreditCardDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.LoanDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.NewAdditionalProperty;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.HomeImprovement;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.OtherIncome;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.AdditionalIncome;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Profit;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Retired;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Salary;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.SelfEmployed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.PensionType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.WorkStatus;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.FrequencyType;
import com.rbs.pbbdhb.coordinator.adbo.enums.GmsCodeToCountryIso;
import com.rbs.pbbdhb.coordinator.adbo.enums.PropertyType;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAdditionalBorrowing;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAdditionalBorrowing.DipAdditionalBorrowingBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.DipAddressBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplicant;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplicant.DipApplicantBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplicant.WorkStatusEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication.DipApplicationBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipCreditCard;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipCreditCard.CreditCardTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipCreditHistory;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipDetails.PurposeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment.DipEmploymentBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment.EmploymentStatusEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment.OccupationCodeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipFinancialCommitment;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipFinancialCommitment.DipFinancialCommitmentTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.FrequencyEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipLoan;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipMortgage;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.BenefitTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipPersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipPersonalDetails.DipPersonalDetailsBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipProperty;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipProperty.DipPropertyBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipResult;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipSelfEmployed;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipSelfEmployed.DipSelfEmployedBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.Policy;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.Telephone;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.Telephone.PhoneTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.response.DipResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.DipService;
import com.rbs.pbbdhb.coordinator.adbo.util.EnumsMappingUtil;
import com.rbs.pbbdhb.exception.BusinessException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class DipServiceImpl implements DipService {

  private final static String UK_ISO_CODE = GmsCodeToCountryIso.BRIT.getCountryIsoCode();
  private final static EnumMap<BorrowingPurposeType, DipDetails.PurposeEnum> BORROWING_PURPOSE_MAP
      = new EnumMap<BorrowingPurposeType, DipDetails.PurposeEnum>(BorrowingPurposeType.class) {{
    put(BorrowingPurposeType.BUYOUT, PurposeEnum.BUY_OUT);
    put(BorrowingPurposeType.GIFT, PurposeEnum.GIFT);
    put(BorrowingPurposeType.HOLIDAY, PurposeEnum.HOLIDAY);
    put(BorrowingPurposeType.MEDICAL, PurposeEnum.OTHER);
    put(BorrowingPurposeType.EDUCATION, PurposeEnum.OTHER);
    put(BorrowingPurposeType.HOME_IMPROVEMENT, PurposeEnum.HOME_IMPROVEMENT);
    put(BorrowingPurposeType.PURCHASE_ADDITIONAL_PROPERTY, PurposeEnum.HOUSE_PURCHASE);
    put(BorrowingPurposeType.REDEEM_SECOND_CHARGE, PurposeEnum.OTHER);
    put(BorrowingPurposeType.VEHICLE, PurposeEnum.BUY_NEW_OR_USED_CAR);
    put(BorrowingPurposeType.WEDDING, PurposeEnum.WEDDING);
  }};
  private final static String DECLINE = "DECLINE";
  private final static String LENDING_CODE = "D889";
  private final static String LENDING_RULE = "lendingRuleDecline";
  private final static String CREDIT_RULE = "creditFileDecline";
  private final static String policyCodes = "DS04,D003,D004,D890,D256,D257,D258,D259,D314,D315,D432,D439,D440,D001,D002,D037,D044,D385,D414,D498,D680";
  private final static String MAX_LENDING_DECLINE_POLICY_MESSAGE = "Salary below Minimum threshold";
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final ApiService apiService;
  private final Comparator<DipAddress> SORT_BY_START_YEAR = Comparator.comparing(DipAddress::getStartYear);
  private final Comparator<DipAddress> SORT_BY_START_MONTH = Comparator.comparing(DipAddress::getStartMonth);
  private final Comparator<DipAddress> SORT_ADDRESS_DESCENDING = SORT_BY_START_YEAR.thenComparing(SORT_BY_START_MONTH).reversed();

  private static Telephone mapPhoneNumber(String phoneNumber, PhoneTypeEnum phoneType) {
    return Telephone.builder().type(phoneType).number(phoneNumber).build();
  }

  @Override
  public DipResponse getDecisionInPrincipleFromDB(String accountNumber) {
    AdboCaseDetails validatedAdboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(requireNonNull(accountNumber));
    if (nonNull(validatedAdboCaseDetails.getDipResult())) {
      return constructDIPResponse(validatedAdboCaseDetails);
    } else {
      throw new BusinessException(Constants.DIP_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
  }

  @Override
  public DipResponse getDecisionInPrinciple(String accountNumber) {
    AdboCaseDetails validatedAdboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(requireNonNull(accountNumber));
    DipApplication dipRequest = convertToDip(validatedAdboCaseDetails);
    validatedAdboCaseDetails.setDipRequest(dipRequest);
    adboCaseDetailsDao.save(validatedAdboCaseDetails);
    Optional<DipResult> dipResultResponse = apiService.performDip(dipRequest);
    if (nonNull(dipResultResponse) && dipResultResponse.isPresent()) {
      DipResult dipResult = dipResultResponse.get();
      checkMaxLendingAmountAndUpdateResult(dipResult, validatedAdboCaseDetails.getAdditionalBorrowingCalculator().getBorrowingAmount());
      validatedAdboCaseDetails.setDipResult(dipResult);
      adboCaseDetailsDao.save(validatedAdboCaseDetails);
      return constructDIPResponse(validatedAdboCaseDetails);
    } else {
      throw new BusinessException(Constants.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
  }

  private void checkMaxLendingAmountAndUpdateResult(DipResult dipResult, Integer borrowingAmount) {
    if (dipResult.getAdditionalDetails().getMaximumAllowableLoan() <= borrowingAmount) {
      dipResult.setDecision(DECLINE);
      Policy maxLendingDeclinePolicy = new Policy();
      maxLendingDeclinePolicy.setCode(LENDING_CODE);
      maxLendingDeclinePolicy.setMessage(MAX_LENDING_DECLINE_POLICY_MESSAGE);
      List<Policy> maxLendingDeclinePolicies = Collections.singletonList(maxLendingDeclinePolicy);
      dipResult.setPolicyMessages(maxLendingDeclinePolicies);
    }

  }

  private DipResponse constructDIPResponse(AdboCaseDetails details) {
    return DipResponse.builder()
        .decision(details.getDipResult().getDecision())
        .additionalBorrowingAmount(details.getAdditionalBorrowingCalculator().getBorrowingAmount())
        .estimatedPropertyValue(nonNull(details.getAdditionalBorrowingCalculator().getEstimatedPropertyValue()) ? BigDecimal.valueOf(
            details.getAdditionalBorrowingCalculator().getEstimatedPropertyValue()) : null)
        .hpiValuation(details.getAdditionalBorrowingCalculator().getHpiValuation())
        .termMonths(details.getAdditionalBorrowingCalculator().getRepaymentTermMonths())
        .termYears(details.getAdditionalBorrowingCalculator().getRepaymentTermYears())
        .planningPermissionRequired(
            nonNull(details.getAdditionalBorrowingCalculator().getAdboAmountDistributions()) ? setPermissionRequired(
                details.getAdditionalBorrowingCalculator().getAdboAmountDistributions()) : null)
        .planningPermissionAcquired(
            nonNull(details.getAdditionalBorrowingCalculator().getAdboAmountDistributions()) ? setPermissionAcquired(
                details.getAdditionalBorrowingCalculator().getAdboAmountDistributions()) : null)
        .policyMessage(setDeclineMsg(details))
        .build();
  }

  private List<String> getCode(String policyCodes) {
    return asList(policyCodes.split(","));
  }

  private String setDeclineMsg(AdboCaseDetails details) {
    if (Objects.equals(DECLINE, details.getDipResult().getDecision())) {
      if (details.getDipResult().getPolicyMessages().stream().anyMatch(policy -> policy.getCode().equalsIgnoreCase(LENDING_CODE))) {
        return LENDING_RULE;
      } else if (details.getDipResult().getPolicyMessages().stream().anyMatch(policy -> getCode(policyCodes).contains(policy.getCode()))) {
        return CREDIT_RULE;
      }
    }
    return null;
  }

  private Boolean setPermissionRequired(List<AdboAmountDistribution> adboAmountDistributions) {
    for (AdboAmountDistribution adboAmountDistribution : adboAmountDistributions) {
      if (Objects.equals(BorrowingPurposeType.HOME_IMPROVEMENT, adboAmountDistribution.getType())) {
        HomeImprovement homeImprovement = (HomeImprovement) adboAmountDistribution;
        if (isTrue(homeImprovement.getPlanningPermissionRequired())) {
          return true;
        }
      }
    }
    return null;
  }

  private Boolean setPermissionAcquired(List<AdboAmountDistribution> adboAmountDistributions) {
    for (AdboAmountDistribution adboAmountDistribution : adboAmountDistributions) {
      if (Objects.equals(BorrowingPurposeType.HOME_IMPROVEMENT, adboAmountDistribution.getType())) {
        HomeImprovement homeImprovement = (HomeImprovement) adboAmountDistribution;
        if (isTrue(homeImprovement.getPlanningPermissionRequired())) {
          return homeImprovement.getPlanningPermissionAcquired();
        }
      }
    }
    return null;
  }

  private void mapDependentsDetails(AdboCaseDetails adboCaseDetails, DipApplicationBuilder dipApplicationBuilder) {
    PersonalDetails mainPersonalDetails = adboCaseDetails.getAdboApplicants().get(MAIN).getPersonalDetails();
    if (isTrue(mainPersonalDetails.getHasDependents())) {
      dipApplicationBuilder
          .numberOfDependantsUnder18(mainPersonalDetails.getDependentsUnder18())
          .numberOfDependantsOver18(mainPersonalDetails.getDependentsOver18());
    }
  }

  public DipApplication convertToDip(AdboCaseDetails adboCaseDetails) {
    log.info("construct DIP request start, accountNumber {}", adboCaseDetails.getAccountNumber());
    DipApplicationBuilder dipApplicationBuilder = DipApplication.builder();
    mapDependentsDetails(adboCaseDetails, dipApplicationBuilder);
    Collection<AdboApplicant> adboApplicants = adboCaseDetails.getAdboApplicants().values();
    if (adboCaseDetails.getAdboApplicants().containsKey(JOINT1)) {
      adboApplicants = adboApplicants.stream().filter(adboApplicant -> nonNull(adboApplicant.getAcctHolderPosition()))
          .sorted(Comparator.comparing(AdboApplicant::getAcctHolderPosition)).collect(Collectors.toList());
    }
    adboApplicants.stream()
        .map(applicantAdbo -> mapApplicant(applicantAdbo, getKey(adboCaseDetails.getAdboApplicants(), applicantAdbo),
            adboCaseDetails.getAdditionalBorrowingCalculator().getRetirementAge(),
            adboCaseDetails.getEligibilityApplicant().getEligibleNationality(),
            nonNull(adboCaseDetails.getEligibilityApplicant().getJointApplicantEligibleNationality())
                ? adboCaseDetails.getEligibilityApplicant().getJointApplicantEligibleNationality()
                : adboCaseDetails.getEligibilityApplicant().getEligibleNationality()))
        .forEach(dipApplicationBuilder::applicant);
    dipApplicationBuilder.mortgage(mapMortgage(adboCaseDetails.getAdditionalBorrowingCalculator()));
    dipApplicationBuilder.additionalBorrowing(mapAdbo(adboCaseDetails));
    dipApplicationBuilder.applicationType(DEFAULT_APPLICATION_TYPE);
    dipApplicationBuilder.loanPurpose(DEFAULT_LOAN_PURPOSE);
    dipApplicationBuilder.buyerType(DEFAULT_BUYER_TYPE);
    dipApplicationBuilder.channel(DEFAULT_CHANNEL);
    dipApplicationBuilder.govtSharedEquityScheme(DEFAULT_GOVT_SHARED_EQUITY_SCHEME);
    dipApplicationBuilder.property(mapProperty(adboCaseDetails.getAdditionalBorrowingCalculator().getPropertyGmsBuildType()));
    DipApplication dipApplication = dipApplicationBuilder.build();
    if (nonNull(adboCaseDetails.getDipResult())) {
      dipApplication.setDipId(isTrue(personalDetailsAreSame(Objects.requireNonNull(adboCaseDetails.getDipRequest().getApplicants()), dipApplication.getApplicants())) ?
              adboCaseDetails.getDipResult().getDipId() :
              null);
    }
    log.info("construct DIP request end, accountNumber {}", adboCaseDetails.getAccountNumber());
    return dipApplication;
  }

  private boolean personalDetailsAreSame(List<DipApplicant> dipApplicantsListOld, List<DipApplicant> dipApplicantListNew) {
    if (dipApplicantsListOld.size() != dipApplicantListNew.size()) {
      return false;
    }
    for (int i = 0; i < dipApplicantListNew.size(); i++) {
      if (isFalse(isPersonalDetailsAreSame(dipApplicantsListOld.get(i).getPersonalDetails(), dipApplicantListNew.get(i).getPersonalDetails())) ||
              isFalse(isAddressesAreSame(dipApplicantsListOld.get(i).getAddresses(), dipApplicantListNew.get(i).getAddresses())))
        return false;
    }
    return true;
  }

  private boolean isPersonalDetailsAreSame(DipPersonalDetails dipPersonalDetailsOld, DipPersonalDetails dipPersonalDetailsNew) {
    return Objects.equals(dipPersonalDetailsOld.getFirstNames(), dipPersonalDetailsNew.getFirstNames()) &&
            Objects.equals(dipPersonalDetailsOld.getMiddleNames(), dipPersonalDetailsNew.getMiddleNames()) &&
            Objects.equals(dipPersonalDetailsOld.getLastName(), dipPersonalDetailsNew.getLastName()) &&
            Objects.equals(dipPersonalDetailsOld.getDateOfBirth(), dipPersonalDetailsNew.getDateOfBirth());

  }

  private boolean isAddressesAreSame(Set<DipAddress> dipAddressSetOld, Set<DipAddress> dipAddressSetNew) {
    if (dipAddressSetOld.size() != dipAddressSetNew.size()) {
      return false;
    }
      List<DipAddress> addressesOld = new ArrayList<>(dipAddressSetOld);
      List<DipAddress> addressesNew = new ArrayList<>(dipAddressSetNew);
      Collections.sort(addressesOld, SORT_ADDRESS_DESCENDING);
      Collections.sort(addressesNew, SORT_ADDRESS_DESCENDING);
      for (int i = 0; i < dipAddressSetNew.size(); i++)
          if (isFalse(compareAddress(addressesOld.get(i), addressesNew.get(i))))
              return false;

    return true;
  }

  private boolean compareAddress(DipAddress dipAddressOld, DipAddress dipAddressNew) {
    return Objects.equals(dipAddressOld.getFlat(), dipAddressNew.getFlat()) &&
            Objects.equals(dipAddressOld.getHouseName(), dipAddressNew.getHouseName()) &&
            Objects.equals(dipAddressOld.getHouseNumber(), dipAddressNew.getHouseNumber()) &&
            Objects.equals(dipAddressOld.getStreet(), dipAddressNew.getStreet()) &&
            Objects.equals(dipAddressOld.getTown(), dipAddressNew.getTown()) &&
            Objects.equals(dipAddressOld.getCounty(), dipAddressNew.getCounty()) &&
            Objects.equals(dipAddressOld.getCountryIsoCode(), dipAddressNew.getCountryIsoCode()) &&
            Objects.equals(dipAddressOld.getOccupyStatus(), dipAddressNew.getOccupyStatus()) &&
            Objects.equals(dipAddressOld.getPostcode(), dipAddressNew.getPostcode());
  }

  private DipProperty mapProperty(String property) {
    DipPropertyBuilder propertyBuilder = DipProperty.builder();
    propertyBuilder.propertyType(propertyGmsBuildTypeToDipPropertyTypeEnum(property));
    return propertyBuilder.build();
  }

  private DipAdditionalBorrowing mapAdbo(AdboCaseDetails adboCaseDetails) {
    AdditionalBorrowingCalculator adboCalculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    DipAdditionalBorrowingBuilder adboBuilder = DipAdditionalBorrowing.builder()
        .termMonths(adboCalculator.getRepaymentTermMonths())
        .repaymentVehicle(DEFAULT_REPAYMENT_VEHICLE)
        .termYears(adboCalculator.getRepaymentTermYears());
    adboCalculator.getAdboAmountDistributions().stream()
        .map(dist -> dipDetails(BORROWING_PURPOSE_MAP.get(dist.getType()), dist.getAmount()))
        .forEach(adboBuilder::detail);
    adboCalculator.getSubAccountDetails().stream()
        .map(account -> subAccount(account.getRemainingTerm().getYears() * 12 + account.getRemainingTerm().getMonths(),
            account.getTrueBalance(), DEFAULT_SUB_ACCOUNT_REPAYMENT_TYPE))
        .forEach(adboBuilder::subAccount);
    return adboBuilder.build();
  }

  private DipApplicant mapApplicant(AdboApplicant adboApplicant, ApplicantType applicantType,
      List<Integer> retirementAge, boolean mainApplicantEligibleNationality, boolean jointApplicantEligibleNationality) {
    log.info("building DIP applicant start");
    PersonalDetails personalDetails = adboApplicant.getPersonalDetails();
    Address currentStructuredAddress = personalDetails.getCurrentAddressStructuredFormat();
    DipApplicantBuilder applicantBuilder = DipApplicant.builder()
        .address(mapStructuredAddress(currentStructuredAddress, personalDetails.getCurrentAddress().getAddress1(),
            personalDetails.getCurrentAddressMoveInDate()))
        .cin(adboApplicant.getCin())
        .consentToDIP(true)
        .workStatus(Objects.equals(WorkStatus.WORKING, adboApplicant.getIncome().getCurrentWorkStatus()) ? WorkStatusEnum.WORKING
            : WorkStatusEnum.NOT_WORKING)
        .intendedRetirementAge(
            Objects.equals(WorkStatus.WORKING, adboApplicant.getIncome().getCurrentWorkStatus()) ?
                retirementAge.get(applicantType.getIndex()) : null)
        .personalDetails(mapPersonalDetails(personalDetails.getTitle(), personalDetails,
            !applicantType.equals(MAIN) ? jointApplicantEligibleNationality : mainApplicantEligibleNationality));
    applicantBuilder.employment(
        Objects.equals(WorkStatus.WORKING, adboApplicant.getIncome().getCurrentWorkStatus()) ? mapEmployment(
            adboApplicant, applicantBuilder)
            : null);
    if (nonNull(adboApplicant.getIncome().getHasOtherIncome()) && isTrue(
        adboApplicant.getIncome().getHasOtherIncome())) {
      log.info("customer provided other income details");
      if (Objects.equals(WorkStatus.RETIRED, adboApplicant.getIncome().getCurrentWorkStatus())) {
        log.info("Retired and has a other source of income");
        Retired retired = adboApplicant.getIncome().getRetired();
        PensionType pensionType = retired.getPensionType();
        Supplier<Stream<OtherIncome>> otherIncomeStream = () -> adboApplicant.getIncome().getOtherIncomes().stream();
        aggregatePensionAmount(retired, pensionType, applicantBuilder, otherIncomeStream);
        boolean isMatched = otherIncomeStream.get()
            .anyMatch(otherIncome -> Objects.equals(otherIncome.getSourceOfIncome().name(), pensionType.name()));
        if (!isMatched && !Objects.equals(PensionType.NONE, pensionType)) {
          applicantBuilder.otherIncome(
              DipOtherIncome.builder().amount(adboApplicant.getIncome().getRetired().getAnnualAmount().toBigInteger())
                  .type(pensionTypeToDipPensionTypeMap(adboApplicant.getIncome().getRetired().getPensionType())).frequency(
                      ANNUALLY).build());
        }
      } else {
        adboApplicant.getIncome().getOtherIncomes().stream().map(this::mapOtherIncome).forEach(applicantBuilder::otherIncome);
      }
    }
    if (Objects.equals(WorkStatus.RETIRED, adboApplicant.getIncome().getCurrentWorkStatus()) && !(
        nonNull(adboApplicant.getIncome().getHasOtherIncome()) && isTrue(
            adboApplicant.getIncome().getHasOtherIncome()))) {
      log.info("Retired and don't have any other source of income");
      if (!Objects.equals(PensionType.NONE, adboApplicant.getIncome().getRetired().getPensionType())) {
        applicantBuilder.otherIncome(
            DipOtherIncome.builder().amount(adboApplicant.getIncome().getRetired().getAnnualAmount().toBigInteger())
                .type(pensionTypeToDipPensionTypeMap(adboApplicant.getIncome().getRetired().getPensionType())).frequency(
                    ANNUALLY).build());
      }
    }
    OutgoingPaymentsDetails outgoings = adboApplicant.getOutgoingPaymentsDetails();
    if (isTrue(outgoings.getHasCreditCards()) && !CollectionUtils.isEmpty(outgoings.getCreditCards())) {
      log.info("customer has a  total {} credit card expenses in outgoings", outgoings.getCreditCards().size());
      outgoings.getCreditCards().stream().map(this::mapCreditCard).forEach(applicantBuilder::creditCard);
    }
    if (isTrue(outgoings.getHasLoans()) && !CollectionUtils.isEmpty(outgoings.getLoans())) {
      log.info("customer has a  total {} loan expenses in outgoings", outgoings.getLoans().size());
      outgoings.getLoans().stream().map(this::mapLoan).forEach(applicantBuilder::loan);
    }
    if (isTrue(outgoings.getHasFixedCommitments()) && !CollectionUtils.isEmpty(outgoings.getFixedCommitments())) {
      log.info("customer has a  total {} fixed commitment expenses in outgoings", outgoings.getFixedCommitments().size());
      outgoings.getFixedCommitments().stream()
          .map(fixedCommitment ->
              mapFixedCommitment(financialCommitmentTypeToDipFinancialCommitmentTypeMap(fixedCommitment.getType()),
                  fixedCommitment.getApplicantShareOnMonthlyPayment(),
                  isTrue(fixedCommitment.getContinueMoreThanSixMonths()) ?
                      fixedCommitment.getApplicantShareOnMonthlyPayment() :
                      ZERO,null))
          .forEach(applicantBuilder::financialCommitment);
    }
    if (isTrue(outgoings.getHasAdditionalProperties()) && !CollectionUtils.isEmpty(outgoings.getAdditionalProperties())) {
      log.info("customer has a  total {} additional property expenses in outgoings", outgoings.getAdditionalProperties().size());
      outgoings.getAdditionalProperties().stream()
          .filter(additionalProperty ->
                  Objects.equals(additionalProperty.getPropertyType(), PropertyType.RESIDENTIAL) &&
                          nonNull(additionalProperty.getApplicantShareOnMonthlyMortgagePayment()))
              .map(additionalProperty ->
                      mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
                              additionalProperty.getApplicantShareOnMonthlyMortgagePayment(),
                              isTrue(additionalProperty.getWillThisMortgagePaidOff()) ?
                                      ZERO :
                                      additionalProperty.getApplicantShareOnMonthlyMortgagePayment(),null))
              .forEach(applicantBuilder::financialCommitment);


      outgoings.getAdditionalProperties().stream()
          .filter(additionalProperty ->
              Objects.equals(additionalProperty.getPropertyType(), PropertyType.RESIDENTIAL) &&
                      (nonNull(additionalProperty.getApplicantShareOnMonthlyRunningCostsPayment())|| isFalse(additionalProperty.getHasRunningCosts())))
          .map(additionalProperty ->
              mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
                      isTrue(additionalProperty.getHasRunningCosts()) ? additionalProperty.getApplicantShareOnMonthlyRunningCostsPayment() :
                              ZERO,
                  isTrue(additionalProperty.getRunningCostsContinueForMoreThanSixMonths()) ?
                      additionalProperty.getApplicantShareOnMonthlyRunningCostsPayment() :
                      ZERO,additionalProperty.getIsLetToFamilyMember()))
          .forEach(applicantBuilder::financialCommitment);

      outgoings.getAdditionalProperties().stream()
          .filter(additionalProperty ->
              Objects.equals(additionalProperty.getPropertyType(), PropertyType.BUY_TO_LET) &&
                  nonNull(additionalProperty.getApplicantShareOnShortFallAmount()))
          .map(additionalProperty ->
              mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
                  additionalProperty.getApplicantShareOnShortFallAmount(),
                  isTrue(additionalProperty.getContinueForMoreThanSixMonths()) ?
                      additionalProperty.getApplicantShareOnShortFallAmount() :
                      ZERO,null))
          .forEach(applicantBuilder::financialCommitment);
    }
    if (isTrue(outgoings.getHasChildcareExpenses()) && !CollectionUtils.isEmpty(outgoings.getChildcareExpenses())) {
      log.info("customer has a  total {} childcare expenses in outgoings", outgoings.getChildcareExpenses().size());
      outgoings.getChildcareExpenses().stream()
          .map(childCareExpense ->
              mapFixedCommitment(childCareExpenseToDipFinancialCommitmentTypeMap(childCareExpense.getType()),
                  childCareExpense.getApplicantShareOnMonthlyPayment(),
                  isTrue(childCareExpense.getContinueMoreThanSixMonths()) ?
                      childCareExpense.getApplicantShareOnMonthlyPayment() :
                      ZERO,null)).forEach(applicantBuilder::financialCommitment);
    }
    if (isTrue(outgoings.getHasDependentExpenses()) && !CollectionUtils.isEmpty(outgoings.getDependentExpenses())) {
      log.info("customer has a  total {} adult care expenses in outgoings", outgoings.getDependentExpenses().size());
      outgoings.getDependentExpenses().stream()
          .map(dependentExpenses ->
              mapFixedCommitment(ADULT_CARE_COSTS,
                  dependentExpenses.getApplicantShareOnMonthlyPayment(),
                  isTrue(dependentExpenses.getContinueMoreThanSixMonths()) ?
                      dependentExpenses.getApplicantShareOnMonthlyPayment() :
                      ZERO,null)).forEach(applicantBuilder::financialCommitment);
    }
    if (nonNull(outgoings.getJointApplicantMonthlyPensionContribution())) {
      log.info("customer has a monthly pension contribution in outgoings");
      applicantBuilder.financialCommitment(mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
          outgoings.getJointApplicantMonthlyPensionContribution(),
          outgoings.getJointApplicantMonthlyPensionContribution(),null));
    }
    if (nonNull(outgoings.getApplicantShareOnMonthlyLivingElseWhereAmount())) {
      log.info("customer provided joint living elsewhere amount in outgoings");
      applicantBuilder.financialCommitment(mapFixedCommitment(RENT,
          outgoings.getApplicantShareOnMonthlyLivingElseWhereAmount(),
          outgoings.getApplicantShareOnMonthlyLivingElseWhereAmount(),null));
    }
    if (nonNull(outgoings.getNewAdditionalProperty())) {
      log.info("customer provided future liability amount on residential in outgoings");
      NewAdditionalProperty newAdditionalProperty = outgoings.getNewAdditionalProperty();
      if (nonNull(newAdditionalProperty.getApplicantShareOnNewMortgageMonthlyPayment())) {
        applicantBuilder.financialCommitment(mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
            newAdditionalProperty.getApplicantShareOnNewMortgageMonthlyPayment(),
            newAdditionalProperty.getApplicantShareOnNewMortgageMonthlyPayment(),null));
      }
      if (nonNull(newAdditionalProperty.getApplicantShareOnMonthlyRunningCostPayment())) {
        log.info("customer provided future liability running cost amount on residential in outgoings");
        applicantBuilder.financialCommitment(mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
            newAdditionalProperty.getApplicantShareOnMonthlyRunningCostPayment(),
            newAdditionalProperty.getApplicantShareOnMonthlyRunningCostPayment(),newAdditionalProperty.getIsLetToFamilyMember()));

      }
      if (nonNull(newAdditionalProperty.getApplicantShareOnBuyTOLetShortFallAmount())) {
        log.info("customer provided future liability amount on buy to let in outgoings");
        applicantBuilder.financialCommitment(mapFixedCommitment(OTHER_COMMITTED_EXPENDITURE,
            newAdditionalProperty.getApplicantShareOnBuyTOLetShortFallAmount(),
            newAdditionalProperty.getApplicantShareOnBuyTOLetShortFallAmount(),null));
      }
    }
    if (!isEmpty(personalDetails.getPreviousAddresses())) {
      log.info("customer has previous address");
      personalDetails.getPreviousAddresses().stream()
          .map(this::mapAddress)
          .forEach(applicantBuilder::address);
    }
    applicantBuilder.creditHistory(
        DipCreditHistory.builder()
            .bankrupt(false)
            .courtProceedings(false)
            .build()
    );
    return applicantBuilder.build();
  }

  private void aggregatePensionAmount(Retired retired, PensionType pensionType, DipApplicantBuilder applicantBuilder,
      Supplier<Stream<OtherIncome>> otherIncomeStream) {
    log.info("Retired, Aggregate the pension amount if the customer annual income and other source income has same pension type");
    List<OtherIncome> validPensionTypeList = otherIncomeStream.get()
        .filter(otherIncome -> !Objects.equals(PensionType.NONE, pensionType.name())).collect(Collectors.toList());
    validPensionTypeList.stream().forEach(otherIncome -> {
      log.info("Retired, pension amount annually {}, pension type {}, other source of income amount {},frequency {}, pension type {}",
          retired.getAnnualAmount(), pensionType.name(), otherIncome.getAmount(), otherIncome.getFrequency().name(),
          otherIncome.getSourceOfIncome().name());
      if (Objects.equals(otherIncome.getSourceOfIncome().name(), pensionType.name())) {
        BigDecimal annuallyAmount = convertAnnuallyAmount(otherIncome.getFrequency(), otherIncome.getAmount());
        otherIncome.setAmount(retired.getAnnualAmount().add(annuallyAmount));
        otherIncome.setFrequency(FrequencyType.ANNUALLY);
        applicantBuilder.otherIncome(mapOtherIncome(otherIncome));
      } else {
        applicantBuilder.otherIncome(mapOtherIncome(otherIncome));
      }
    });
  }

  private void mapPrimaryEmploymentIsEmployed(AdboApplicant adboApplicant, DipApplicantBuilder applicantBuilder,
      DipEmploymentBuilder builder) {
    List<Employment> employedList = getValidEmployedList(adboApplicant);
    List<Employment> selfEmployedMoreThan2YearsList = getValidSelfEmploymentList(adboApplicant);

    if (CollectionUtils.isEmpty(employedList) && CollectionUtils.isEmpty(selfEmployedMoreThan2YearsList)) {
      builder.employmentStatus(EmploymentStatusEnum.NOT_EMPLOYED);
      builder.occupationCode(OccupationCodeEnum.UNEMPLOYED);
      applicantBuilder.workStatus(WorkStatusEnum.NOT_WORKING);
      return;
    }
    if (!CollectionUtils.isEmpty(employedList)) {
      Optional<Employment> firstEmployment = employedList.stream().findFirst();
      Employed employed = (Employed) firstEmployment.get();
      mapEmployed(employed, builder);
      employedList.stream().skip(1).forEach(employment -> employedIncomeMapToOtherIncome((Employed) employment, applicantBuilder));
      if (!CollectionUtils.isEmpty(selfEmployedMoreThan2YearsList)) {
        selfEmployedMoreThan2YearsList.forEach(
            employment -> selfEmployedIncomeMapToOtherIncome((SelfEmployed) employment, applicantBuilder));
      }
    } else {
      if (!CollectionUtils.isEmpty(selfEmployedMoreThan2YearsList)) {
        Optional<Employment> selfEmployedIncome = selfEmployedMoreThan2YearsList.stream().findFirst();
        mapSelfEmployment((SelfEmployed) selfEmployedIncome.get(), builder, applicantBuilder);
        selfEmployedMoreThan2YearsList.stream().skip(1)
            .forEach(employment -> selfEmployedIncomeMapToOtherIncome((SelfEmployed) employment, applicantBuilder));
      }
    }

  }

  private void mapPrimaryEmploymentIsSelfEmployed(AdboApplicant adboApplicant, DipApplicantBuilder applicantBuilder,
      DipEmploymentBuilder builder) {

    log.info("Self-employment less than 2 years, So at least one employment should built as employment income");
    List<Employment> selfEmployedMoreThan2YearsList = getValidSelfEmploymentList(adboApplicant);
    List<Employment> employedList = getValidEmployedList(adboApplicant);
    if (!CollectionUtils.isEmpty(selfEmployedMoreThan2YearsList)) {
      Optional<Employment> firstEmployment = selfEmployedMoreThan2YearsList.stream().findFirst();
      SelfEmployed selfEmployed = (SelfEmployed) firstEmployment.get();
      mapSelfEmployment(selfEmployed, builder, applicantBuilder);
      applicantBuilder.workStatus(WorkStatusEnum.WORKING);
      selfEmployedMoreThan2YearsList.stream().skip(1)
          .forEach(employment -> selfEmployedIncomeMapToOtherIncome((SelfEmployed) employment, applicantBuilder));
    }
    if (!CollectionUtils.isEmpty(employedList)) {
      if (CollectionUtils.isEmpty(selfEmployedMoreThan2YearsList)) {
        log.info("customer has less than 2 years self-employment so employed income map to main income");
        Optional<Employment> firstEmployment = employedList.stream().findFirst();
        mapEmployed((Employed) firstEmployment.get(), builder);
        applicantBuilder.workStatus(WorkStatusEnum.WORKING);
        employedList.stream().skip(1).forEach(employment -> employedIncomeMapToOtherIncome((Employed) employment, applicantBuilder));
      } else {
        log.info("customer has more than 2 years self-employment so employed income is map to other income");
        employedList.forEach(employment -> employedIncomeMapToOtherIncome((Employed) employment, applicantBuilder));
      }
    }
  }

  private List<Employment> getValidSelfEmploymentList(AdboApplicant adboApplicant) {
    return adboApplicant.getIncome().getEmployments().stream().skip(1)
        .filter(employment -> employment instanceof SelfEmployed)
        .filter(employment -> ((SelfEmployed) employment).getHasBeenTradingForTwoYears()).collect(
            Collectors.toList());
  }

  private List<Employment> getValidEmployedList(AdboApplicant adboApplicant) {

    return adboApplicant.getIncome().getEmployments().stream().skip(1)
        .filter(employment -> employment instanceof Employed).filter(
            employment -> hasContinuesEmployment((Employed) employment)).collect(Collectors.toList());
  }

  private void mapSelfEmployedAndEmployedIncomeToOtherIncome(AdboApplicant adboApplicant, DipApplicantBuilder applicantBuilder) {
    List<Employment> selfEmployedMoreThan2YearsList = getValidSelfEmploymentList(adboApplicant);
    if (!CollectionUtils.isEmpty(getValidSelfEmploymentList(adboApplicant))) {
      selfEmployedMoreThan2YearsList.forEach(employment -> selfEmployedIncomeMapToOtherIncome((SelfEmployed) employment, applicantBuilder));
    }
    List<Employment> employedList = getValidEmployedList(adboApplicant);
    if (!CollectionUtils.isEmpty(employedList)) {
      employedList.forEach(employment -> employedIncomeMapToOtherIncome((Employed) employment, applicantBuilder));
    }
  }

  private DipEmployment mapEmployment(AdboApplicant adboApplicant, DipApplicantBuilder applicantBuilder) {
    DipEmploymentBuilder builder = DipEmployment.builder();
    Optional<Employment> employmentOptional = adboApplicant.getIncome().getEmployments().stream().findFirst();
    if (!employmentOptional.isPresent()) {
      throw new BusinessException("Income details not found", HttpStatus.NOT_FOUND.value());
    }
    Employment employmentType = employmentOptional.get();
    if (employmentType instanceof Employed) {
      Employed primaryEmployed = (Employed) employmentType;
      log.info("Primarily employed will map to employed,employerName {}", primaryEmployed.getEmployerName());
      if (nonNull(primaryEmployed.getEmploymentBasis()) && isFalse(hasContinuesEmployment(primaryEmployed))) {
        mapPrimaryEmploymentIsEmployed(adboApplicant, applicantBuilder, builder);
      } else {
        mapEmployed(primaryEmployed, builder);
        mapSelfEmployedAndEmployedIncomeToOtherIncome(adboApplicant, applicantBuilder);
      }
    } else if (employmentType instanceof SelfEmployed) {
      SelfEmployed primarySelfEmployed = (SelfEmployed) employmentType;
      log.info("Primary employment is self-employment, self-employment businessName {}", primarySelfEmployed.getBusinessName());
      mapSelfEmployment(primarySelfEmployed, builder, applicantBuilder);
      if (isTrue(primarySelfEmployed.getHasBeenTradingForTwoYears())) {
        log.info("Self-employment is more than 2 years, So all other employments income should be mapped to other income");
        mapSelfEmployedAndEmployedIncomeToOtherIncome(adboApplicant, applicantBuilder);
      } else {
        mapPrimaryEmploymentIsSelfEmployed(adboApplicant, applicantBuilder, builder);
      }
    }
    return builder.build();
  }

  private void selfEmployedIncomeMapToOtherIncome(SelfEmployed selfEmployed, DipApplicantBuilder applicantBuilder) {
    log.info("customer is employed so self employed income is mapped to other income for employmentBasis {} ,business type {},",
        selfEmployed.getEmploymentBasis().name(), selfEmployed.getBusinessName());
    if (isNotTrue(selfEmployed.getHasBeenTradingForTwoYears())) {
      log.info("customer self-employed less than 2 years, business name {}", selfEmployed.getBusinessName());
      return;
    }
    switch (selfEmployed.getEmploymentBasis()) {
      case PARTNERSHIP:
      case SOLE_TRADER:
        Profit currentYearProfit = selfEmployed.getLatestProfit();
        Profit previousYearProfit = selfEmployed.getPreviousProfit();
        if (!isValidProfit(currentYearProfit, previousYearProfit)) {
          break;
        }
        applicantBuilder.otherIncome(
            mapOtherIncome(averageAmount(currentYearProfit.getAmount(), previousYearProfit.getAmount()),
                ANNUALLY, OTHER_TAXABLE));
        break;
      case LIMITED_COMPANY:
        if (!isValidSalaryAndDividend(selfEmployed.getLatestSalary(), selfEmployed.getPreviousSalary())) {
          break;
        }
        applicantBuilder.otherIncome(
            mapOtherIncome(averageSelfEmployedLimitedCompanyIncome(selfEmployed.getLatestSalary(), selfEmployed.getPreviousSalary()),
                ANNUALLY, OTHER_TAXABLE));
        break;
      default:
        log.error("Unsupported self-employed type passed,{}", selfEmployed.getEmploymentBasis().name());
    }
  }

  private void employedIncomeMapToOtherIncome(Employed employed, DipApplicantBuilder applicantBuilder) {
    log.info("customer primary job is self-employed, so employed income mapped to other income");
    applicantBuilder.otherIncome(
        mapOtherIncome(employed.getAmount(),
            ANNUALLY, OTHER_TAXABLE));
    mapEmployedAdditionalIncomeToOtherIncome(employed.getAdditionalIncomes(), applicantBuilder);
  }

  private void mapEmployedAdditionalIncomeToOtherIncome(List<AdditionalIncome> additionalIncomes, DipApplicantBuilder applicantBuilder) {
    log.info(
        "customer primary job is self-employed, so additional income mapped to other income based on frequency");
    additionalIncomes.stream().filter(Objects::nonNull)
        .filter(additionalIncome -> nonNull(additionalIncome.getFrequency()) && nonNull(additionalIncome.getAmount()))
        .forEach(additionalIncome -> {
          switch (additionalIncome.getFrequency()) {
            case ANNUALLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      ANNUALLY, OTHER_TAXABLE));
              break;
            case SIX_MONTHLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      BIANNUALLY, OTHER_TAXABLE));
              break;
            case WEEKLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      WEEKLY, OTHER_TAXABLE));
              break;
            case FOUR_WEEKLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      FOUR_WEEKLY, OTHER_TAXABLE));
              break;
            case FORTNIGHTLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      FORTNIGHTLY, OTHER_TAXABLE));
              break;
            case MONTHLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      MONTHLY, OTHER_TAXABLE));
              break;
            case QUARTERLY:
              applicantBuilder.otherIncome(
                  mapOtherIncome(additionalIncome.getAmount(),
                      QUARTERLY, OTHER_TAXABLE));
              break;
          }
        });
  }

  private boolean isValidProfit(Profit currentYearProfit, Profit previousYearProfit) {
    if (isNull(currentYearProfit) || isNull(currentYearProfit.getAmount())) {
      throw new BusinessException(SELF_EMPLOYED_CURRENT_YEAR_PROFIT_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    if (isNull(previousYearProfit) || isNull(previousYearProfit.getAmount())) {
      throw new BusinessException(SELF_EMPLOYED_PREVIOUS_YEAR_PROFIT_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    return true;
  }

  private BigDecimal averageSelfEmployedLimitedCompanyIncome(Salary currentYearSalary, Salary previousYearSalary) {
    return averageAmount(currentYearSalary.getSalary(), previousYearSalary.getSalary()).add(
        averageAmount(currentYearSalary.getDividend(), previousYearSalary.getDividend()));
  }

  private void mapEmployed(Employed employed, DipEmploymentBuilder builder) {
    log.info("customer employed mapping DIP employment,employment basis name {}", employed.getEmploymentBasis().name());
    builder.employmentType(EnumsMappingUtil.getEmploymentTypeMap(employed.getEmploymentBasis()));
    builder.startDate(employed.getStartDate());
    builder.occupationCode(EnumsMappingUtil.getDipOccupationCode(employed.getOccupation()));
    builder.industryType(EnumsMappingUtil.getDipIndustryCode(employed.getIndustry()));
    if (!isEmpty(employed.getAdditionalIncomes())) {
      employed.getAdditionalIncomes().stream().forEach(additionalIncome -> builder.income(
          DipIncome.builder().frequency(getDipFrequencyEnum(additionalIncome.getFrequency()))
              .amount(additionalIncome.getAmount()).type(
                  getIncomeTypeEnum(additionalIncome.getSourceOfIncome(), additionalIncome.getFrequency(),
                      additionalIncome.getBonusType())).build()));
    }
    builder.employmentStatus(EmploymentStatusEnum.EMPLOYED);
    builder.income(
        DipIncome.builder().amount(employed.getAmount()).type(DipIncome.TypeEnum.BASIC_EARNINGS).frequency(FrequencyEnum.ANNUALLY).build());
  }

  private boolean isValidSalaryAndDividend(Salary currentYearSalary, Salary previousYearSalary) {
    if (isNull(currentYearSalary) || (isNull(currentYearSalary.getSalary()) || isNull(currentYearSalary.getDividend()))) {
      throw new BusinessException(SELF_EMPLOYED_CURRENT_YEAR_SALARY_OR_DIVIDEND_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    if (isNull(previousYearSalary) || (isNull(previousYearSalary.getSalary()) || isNull(previousYearSalary.getDividend()))) {
      throw new BusinessException(SELF_EMPLOYED_PREVIOUS_YEAR_SALARY_OR_DIVIDEND_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    return true;
  }

  private void mapSelfEmployment(SelfEmployed selfEmployed, DipEmploymentBuilder builder, DipApplicantBuilder applicantBuilder) {
    log.info("customer has self-employed, mapping DIP self-employed details");
    if (isNotTrue(selfEmployed.getHasBeenTradingForTwoYears())) {
      log.info("customer primary self-employment is less than 2 years, business name {}", selfEmployed.getBusinessName());
      builder.employmentStatus(EmploymentStatusEnum.NOT_EMPLOYED);
      builder.occupationCode(OccupationCodeEnum.UNEMPLOYED);
      applicantBuilder.workStatus(WorkStatusEnum.NOT_WORKING);
      return;
    }
    DipSelfEmployedBuilder dipSelfEmployedBuilder = DipSelfEmployed.builder()
        .businessType(selfEmployedBusinessTypeMap(selfEmployed.getEmploymentBasis()))
        .selfEmployedDateEstablished(
            createStatDate(selfEmployed.getYearsEstablished(), selfEmployed.getMonthsEstablished()));
    switch (selfEmployed.getEmploymentBasis()) {
      case PARTNERSHIP:
      case SOLE_TRADER:
        if (!isValidProfit(selfEmployed.getLatestProfit(), selfEmployed.getPreviousProfit())) {
          log.error("self-employed type {} profit validation failed ", selfEmployed.getEmploymentBasis().name());
          break;
        }
        dipSelfEmployedBuilder.netProfitLatest(getRoundDownAmount(
            averageAmount(selfEmployed.getLatestProfit().getAmount(), selfEmployed.getPreviousProfit().getAmount())));
        dipSelfEmployedBuilder.netProfitPrevious(
            getRoundDownAmount(averageAmount(selfEmployed.getLatestProfit().getAmount(), selfEmployed.getPreviousProfit().getAmount())));
        break;
      case LIMITED_COMPANY:
        if (!isValidSalaryAndDividend(selfEmployed.getLatestSalary(), selfEmployed.getPreviousSalary())) {
          log.error("customer self-employed salary validation failed");
          break;
        }
        BigDecimal averageSalary = averageAmount(selfEmployed.getLatestSalary().getSalary(), selfEmployed.getPreviousSalary().getSalary());
        BigDecimal averageDividends = averageAmount(selfEmployed.getLatestSalary().getDividend(),
            selfEmployed.getPreviousSalary().getDividend());
        dipSelfEmployedBuilder.drawingsLatest(getRoundDownAmount(averageSalary.add(averageDividends)));
        dipSelfEmployedBuilder.drawingsPrevious(getRoundDownAmount(averageSalary.add(averageDividends)));
        break;
      default:
        log.error("Unsupported first self-employed type passed,{}", selfEmployed.getEmploymentBasis().name());
    }
    builder.employmentStatus(EmploymentStatusEnum.SELF_EMPLOYED);
    builder.occupationCode(OccupationCodeEnum.SELF_EMPLOYED);
    builder.selfEmployed(dipSelfEmployedBuilder.build());
  }

  private LocalDate createStatDate(Integer years, Integer months) {
    if (isNull(years) || years < 2 || isNull(months)) {
      log.info("Self employed start establishment date is less than 2 years, so input years {}, months {} ", years, months);
      return null;
    }
    return LocalDate.now().withDayOfMonth(1).minusYears(years).minusMonths(months);
  }

  private BigDecimal averageAmount(BigDecimal currentYearAmount, BigDecimal previousYearAmount) {
    return currentYearAmount.compareTo(previousYearAmount) == 1 ? getAverageAmount(currentYearAmount.add(previousYearAmount))
        : currentYearAmount;
  }

  private DipOtherIncome mapOtherIncome(OtherIncome otherIncome) {
    log.info("customer has other income so mapping DIP other-income details");
    return DipOtherIncome.builder()
        .amount(otherIncome.getAmount().toBigInteger())
        .frequency(otherIncomeFrequencyTypeToDipOtherIncomeFrequencyTypeMap(otherIncome.getFrequency()))
        .type(otherIncomeSourceMap(otherIncome.getSourceOfIncome(), otherIncome.getBenefitType()))
        .build();
  }

  private BigDecimal convertAnnuallyAmount(FrequencyType frequencyType, BigDecimal amount) {
    log.info("calculate annual amount for for all the frequency types, frequency type {}", frequencyType.name());
    switch (frequencyType) {
      case ANNUALLY:
        return amount;
      case QUARTERLY:
        return amount.multiply(BigDecimal.valueOf(4));
      case MONTHLY:
        return amount.multiply(BigDecimal.valueOf(12));
      case FORTNIGHTLY:
        return amount.multiply(BigDecimal.valueOf(26));
      case FOUR_WEEKLY:
        return amount.multiply(BigDecimal.valueOf(13));
      case SIX_MONTHLY:
        return amount.multiply(BigDecimal.valueOf(2));
      default:
        return amount.multiply(BigDecimal.valueOf(52));
    }
  }

  private DipOtherIncome mapOtherIncome(BigDecimal amount, OtherIncomeFrequencyEnum frequency, BenefitTypeEnum benefitType) {
    log.info("customer is self-employed has other income so mapping DIP other-income details");
    return DipOtherIncome.builder()
        .amount(amount.toBigInteger())
        .frequency(frequency)
        .type(benefitType)
        .build();
  }

  private DipCreditCard mapCreditCard(CreditCardDetails creditCardDetails) {
    log.info("customer has credit card so mapping DIP credit-card details");
    return DipCreditCard.builder()
        .totalBalance(creditCardDetails.getCurrentBalance().toBigInteger())
        .toBeRepaid(creditCardDetails.getIsPaidOffEveryMonth())
        .creditCardType(CreditCardTypeEnum.CREDIT_CARD)
        .build();
  }

  private DipLoan mapLoan(LoanDetails loanDetails) {
    log.info("customer has loan so mapping DIP loan details");
    return DipLoan.builder()
        .monthlyPayment(loanDetails.getApplicantShareOnMonthlyPayment().toBigInteger())
        .toBeRepaid(!isTrue(loanDetails.getContinueForMoreThanSixMonths()))
        .loanType(loanTypeToDipLoanTypeMap(loanDetails.getLoanType()))
        .build();
  }

  private DipFinancialCommitment mapFixedCommitment(DipFinancialCommitmentTypeEnum financialCommitmentTypeEnum,
      BigDecimal monthlyPayment, BigDecimal paymentsContinuing, Boolean isLetToFamilyMember) {
    log.info("customer has a fixed commitment so mapping DIP financial commitments details,financialCommitmentType {}",
        financialCommitmentTypeEnum.name());
    return DipFinancialCommitment.builder()
        .type(financialCommitmentTypeEnum)
        .monthlyPayments(monthlyPayment.toBigInteger())
        .paymentsContinuing(paymentsContinuing.toBigInteger())
        .familyLiveInProperty(isLetToFamilyMember)
        .build();
  }

  private DipMortgage mapMortgage(AdditionalBorrowingCalculator additionalBorrowingCalculator) {
    log.info("customer mortgage mapping DIP mortgage details");
    return DipMortgage.builder()
        .mortgageType(REPAYMENT_TYPE)
        .mortgageTermMonths(additionalBorrowingCalculator.getRepaymentTermMonths())
        .mortgageTermYears(additionalBorrowingCalculator.getRepaymentTermYears())
        .mortgageAmount(additionalBorrowingCalculator.getBorrowingAmount())
        .propertyValue(
            additionalBorrowingCalculator.getEstimatedPropertyValue() != null ? additionalBorrowingCalculator.getEstimatedPropertyValue()
                : additionalBorrowingCalculator.getHpiValuation().intValue())
        .build();
  }

  private DipAddress mapStructuredAddress(Address address, String gmsAddressLineOne, LocalDate currentAddressMoveInDate) {
    log.info("customer current structured address mapping DIP address");
    DipAddressBuilder dipAddressBuilder = DipAddress.builder();
    dipAddressBuilder.houseName(getLimitedLengthValue(address.getPropertyName(), 22));
    if (isAllBlank(address.getFlatNumber(), address.getPropertyNumber(), address.getPropertyName())) {
      dipAddressBuilder.houseName(getLimitedLengthValue(gmsAddressLineOne, 22));
    }
    return dipAddressBuilder
        .isCurrentAddress(true)
        .ukAddress(true)
        .postcode(address.getPostcode())
        .flat(getLimitedLengthValue(address.getFlatNumber(), 10))
        .houseNumber(getLimitedLengthValue(address.getPropertyNumber(), 5))
        .street(getLimitedLengthValue(address.getStreet(), 30))
        .town(getLimitedLengthValue(address.getTown(), 28))
        .county(address.getCounty())
        .occupyStatus(OWNER_MORTGAGED)
        .startMonth(currentAddressMoveInDate.getMonth().getValue())
        .startYear(currentAddressMoveInDate.getYear())
        .build();
  }

  private String getLimitedLengthValue(String input, int length) {
    if (isNotBlank(input)) {
      if (input.length() > length) {
        return input.substring(0, length);
      } else {
        return input;
      }
    }
    return "";
  }

  private DipAddress mapAddress(Address address) {
    log.info("customer previous unstructured address mapping DIP address");
    DipAddressBuilder addressBuilder = DipAddress.builder();
    addressBuilder.houseName(getLimitedLengthValue(address.getPropertyName(), 22));
    if (Objects.equals(UK_ISO_CODE, address.getCountryIsoCode())) {
      addressBuilder.ukAddress(TRUE);
    } else {
      addressBuilder.ukAddress(FALSE);
      addressBuilder.countryIsoCode(address.getCountryIsoCode());
    }
    return addressBuilder
        .isCurrentAddress(FALSE)
        .postcode(address.getPostcode())
        .flat(getLimitedLengthValue(address.getFlatNumber(), 10))
        .houseNumber(getLimitedLengthValue(address.getPropertyNumber(), 5))
        .street(getLimitedLengthValue(address.getStreet(), 30))
        .town(getLimitedLengthValue(address.getTown(), 28))
        .county(address.getCounty())
        .occupyStatus(occupancyStatusToDipOccupancyStatusEnum(address.getOccupancy()))
        .startMonth(address.getMoveInMonth())
        .startYear(address.getMoveInYear())
        .build();
  }

  private DipPersonalDetails mapPersonalDetails(Title title, PersonalDetails personalDetails, boolean eligibleNationality) {
    log.info("customer personal details mapping DIP personal details,name {}", personalDetails.getFirstName());
    DipPersonalDetailsBuilder personalDetailsBuilder = DipPersonalDetails.builder()
        .title(title)
        .otherTitle(personalDetails.getOtherTitle())
        .firstNames(personalDetails.getFirstName())
        .middleNames(personalDetails.getMiddleName() != null ? personalDetails.getMiddleName().substring(0, Math.min(personalDetails
            .getMiddleName().length(), 25)) : null)
        .lastName(personalDetails.getLastName())
        .nationality(personalDetails.getNationalityIsoCode())
        .rightToReside(eligibleNationality)
        .email(personalDetails.getEmail())
        .telephone(mapPhoneNumber(personalDetails.getMobileNumber(), MOBILE))
        .dateOfBirth(personalDetails.getDateOfBirth())
        .gender(personalDetails.getGender())
        .maritalStatus(personalDetails.getMaritalStatus())
        .countryOfResidenceIsoCode(UK_ISO_CODE);
    return personalDetailsBuilder.build();
  }

}
