package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.math.BigInteger;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipFinancialCommitment {

  private final DipFinancialCommitmentTypeEnum type;

  private final BigInteger monthlyPayments;

  private final BigInteger paymentsContinuing;

  private final Boolean familyLiveInProperty;

  public enum DipFinancialCommitmentTypeEnum {
    CHILD_SUPPORT,
    RENT,
    SCHOOL_FEES,
    CHILD_CARE_COSTS,
    ADULT_CARE_COSTS,
    GROUND_RENT,
    SERVICE_CHARGE,
    ESTATE_CHARGE,
    HELP_TO_BUY_LOAN,
    OTHER_COMMITTED_EXPENDITURE
  }

}
