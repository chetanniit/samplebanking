package com.rbs.pbbdhb.coordinator.adbo.enums;

import static java.util.Arrays.stream;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import lombok.Getter;

public enum ApplicantType {
  MAIN(0), JOINT1(1), JOINT2(2);

  /**
   * Index of objects in lists containing no more than one object for each ApplicantType value.
   *
   * <p>It's added to keep order in some lists stored in Mongo, even if ApplicationType values are reordered.</p>
   * <p><b>Do not change this values unless you know what you are doing.</b></p>
   */
  @Getter
  private final int index;

  ApplicantType(int index) {
    this.index = index;
  }

  /**
   * Convert {@link Map} to list of objects puting each value in place eqaul to {@link ApplicantType#index}
   *
   * @param objectsByType to convert to list
   * @return List of given map values
   */
  public static <T> List<T> getInOrder(Map<ApplicantType, T> objectsByType) {
    if (objectsByType.isEmpty()) {
      return emptyList();
    }
    int max = objectsByType.keySet().stream().mapToInt(ApplicantType::getIndex).max().getAsInt();
    return stream(values())
        .filter(type -> type.getIndex() <= max)
        .sorted(Comparator.comparingInt(type -> type.index))
        .map(objectsByType::get)
        .collect(toList());
  }
}
