package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.BooleanUtils.isNotTrue;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityBorrowing;
import com.rbs.pbbdhb.coordinator.adbo.service.EligibilityBorrowingService;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EligibilityBorrowingServiceImpl implements EligibilityBorrowingService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public void saveEligibilityBorrowing(final String accountNumber, final EligibilityBorrowing eligibilityBorrowing) {
    AdboCaseDetails caseDetails = getCaseDetails(accountNumber);
    if (isNotTrue(eligibilityBorrowing.getDebtConsolidation())) {
      if (isTrue(caseDetails.getHasSecondCharge())) {
        if (isNull(eligibilityBorrowing.getSecondChargePayOff()) ||
            (isTrue(eligibilityBorrowing.getSecondChargePayOff()) && !isTrue(eligibilityBorrowing.getSecondChargeDisclaimer())) ||
            (isFalse(eligibilityBorrowing.getSecondChargePayOff()) && nonNull(eligibilityBorrowing.getSecondChargeDisclaimer()))) {
          throw new BusinessException(Constants.ELIGIBILITY_BORROWING_HAS_SECOND_CHARGE_PAY, HttpStatus.BAD_REQUEST.value());
        }
      } else {
        if (nonNull(eligibilityBorrowing.getSecondChargePayOff()) || nonNull(eligibilityBorrowing.getSecondChargeDisclaimer())) {
          throw new BusinessException(Constants.ELIGIBILITY_BORROWING_SECOND_CHARGE_PAY_OFF, HttpStatus.BAD_REQUEST.value());
        }
      }
    }
    caseDetails.setEligibilityBorrowing(
        requireNonNull(eligibilityBorrowing, "Eligibility borrowing must not be null when journey validation status is PASS"));
    adboCaseDetailsDao.save(caseDetails);
    log.info("Eligibility borrowing details have been saved/updated successfully, accountNumber {}", accountNumber);
  }

  @Override
  public EligibilityBorrowing getEligibilityBorrowing(final String accountNumber) {
    AdboCaseDetails caseDetails = getCaseDetails(accountNumber);
    return caseDetails.getEligibilityBorrowing();
  }

  private AdboCaseDetails getCaseDetails(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    if (Objects.nonNull(adboCaseDetails)) {
      return adboCaseDetails;
    } else {
      log.info("eligibilityBorrowing not found for the given account number {}", accountNumber);
      throw new BusinessException(Constants.ELIGIBILITY_BORROWING_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
  }

}
