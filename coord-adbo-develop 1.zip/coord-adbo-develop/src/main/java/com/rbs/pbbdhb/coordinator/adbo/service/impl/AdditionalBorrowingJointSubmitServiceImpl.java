package com.rbs.pbbdhb.coordinator.adbo.service.impl;


import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.READ_SWITCH_ILLUSTRATION_REQUIRED;
import static java.lang.Boolean.TRUE;
import static java.util.Objects.isNull;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.AgreementsAndDisclaimers;
import com.rbs.pbbdhb.coordinator.adbo.entity.Applicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.PatchApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.kafka.JointApplicantDisclaimersAndMpDto;
import com.rbs.pbbdhb.coordinator.adbo.kafka.JointDisclaimersAndMpUpdateKafkaEventDto;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.PermissionPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateCustomerPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.enums.PreferenceType;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingJointSubmitRequest;
import com.rbs.pbbdhb.coordinator.adbo.service.AdditionalBorrowingJointSubmitService;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.PublishMessageService;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Objects;
import java.util.TimeZone;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@RequiredArgsConstructor
public class AdditionalBorrowingJointSubmitServiceImpl implements AdditionalBorrowingJointSubmitService {

  public static final String ADDITIONAL_BORROWING_AGREEMENTS_AND_DISCLAIMERS = "/additionalBorrowing/agreementsAndDisclaimers";
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final ApiService apiService;
  private final PublishMessageService publishMessageService;
  @Value("${kafka.adbo.joint.disclaimersandmp-event.topic-name}")
  private String topicName;

  @Value("${kafka.adbo.channel}")
  private String channel;

  @Value("${kafka.adbo.journey}")
  private String journey;

  private static AgreementsAndDisclaimers createAgreementsAndDisclaimers(
      AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest) {
    AgreementsAndDisclaimers agreementsAndDisclaimers = new AgreementsAndDisclaimers();

    agreementsAndDisclaimers.setCreditCheckDisclaimer(additionalBorrowingJointSubmitRequest.getCreditCheckDisclaimer());
    agreementsAndDisclaimers
        .setSelfServiceLossOfProtectionDocument(additionalBorrowingJointSubmitRequest.getSelfServiceLossOfProtectionDocument());
    agreementsAndDisclaimers.setImportantInformationAboutUs(additionalBorrowingJointSubmitRequest.getImportantInformationAboutUs());
    agreementsAndDisclaimers.setReadAboutOurMortgageRange(additionalBorrowingJointSubmitRequest.getReadAboutOurMortgageRange());
    agreementsAndDisclaimers.setReadMortgageIllustration(additionalBorrowingJointSubmitRequest.getReadMortgageIllustration());
    agreementsAndDisclaimers.setReadSwitchIllustration(additionalBorrowingJointSubmitRequest.getReadSwitchIllustration());
    agreementsAndDisclaimers
        .setReadMortgageIllustrationUnderstoodProduct(additionalBorrowingJointSubmitRequest.getReadMortgageIllustrationUnderstoodProduct());
    return agreementsAndDisclaimers;
  }

  @Override
  public void saveAdditionalBorrowingJointSubmit(String accountNumber, String customerId,
      AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest) {

    log.info("saveAdditionalBorrowingJointSubmit start for the give accountNumber {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    validateRequest(additionalBorrowingJointSubmitRequest, adboCaseDetails);
    AdboApplicant adboApplicant = adboCaseDetails.getAdboApplicants().get(ApplicantType.JOINT1);
    updateAgreementsAndDisclaimersApplicant(adboApplicant, additionalBorrowingJointSubmitRequest, accountNumber);
    updateMarketingPreference(accountNumber, customerId, additionalBorrowingJointSubmitRequest);
    adboApplicant.setIsMarketingPreferenceUpdated(true);
    adboCaseDetailsDao.save(adboCaseDetails);
    publishMessageToKafka(adboCaseDetails);
    log.info("saveAdditionalBorrowingJointSubmit end for the give accountNumber {}", accountNumber);

  }

  private void validateRequest(AdditionalBorrowingJointSubmitRequest request, AdboCaseDetails adboCaseDetails) {
    if (TRUE.equals(adboCaseDetails.getAdditionalBorrowingWithSwitch()) && isNull(request.getReadSwitchIllustration())) {
      throw new BusinessException(READ_SWITCH_ILLUSTRATION_REQUIRED, HttpStatus.BAD_REQUEST.value());
    }
  }

  @SneakyThrows
  private void updateAgreementsAndDisclaimersApplicant(AdboApplicant adboApplicant,
      AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest, String accountNumber) {
    log.info("updateAgreementsAndDisclaimersApplicant start for the joint applicant of the account number {}", accountNumber);

    AgreementsAndDisclaimers agreementsAndDisclaimers = createAgreementsAndDisclaimers(additionalBorrowingJointSubmitRequest);
    adboApplicant.setAgreementsAndDisclaimers(agreementsAndDisclaimers);
    PatchApplicant patchApplicant = PatchApplicant.builder()
        .path(ADDITIONAL_BORROWING_AGREEMENTS_AND_DISCLAIMERS)
        .op(Constants.REPLACE)
        .value(agreementsAndDisclaimers)
        .build();
    log.info("Patch Record {}", patchApplicant);
    Applicant applicant = apiService.patchAgreementsAndDisclaimers(
        adboApplicant.getApplicantId(), Collections.singletonList(patchApplicant));

    log.info("updateAgreementsAndDisclaimersApplicant end for the joint applicant of the account number {}", accountNumber);
  }

  private void updateMarketingPreference(String accountNumber, String customerId,
      AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest) {
    log.info("updateMarketingPreference start for the joint applicant of the account number {}", accountNumber);
    Constants.SIMPLE_DATE_FORMAT.setTimeZone(TimeZone.getTimeZone(Constants.GMT));
    UpdateMarketingPreferences updateMarketingPreferences = UpdateMarketingPreferences.builder()
        .channel(Constants.CHANNEL_TYPE)
        .recordUpdatedTimestamp(Constants.SIMPLE_DATE_FORMAT.format(new Date()))
        .lawfulBasisMarker("C")
        .referenceNumber(accountNumber)
        .customer(UpdateCustomerPreferences.builder()
            .permissionPreference(
                Arrays.asList(
                    PermissionPreferences.build(PreferenceType.MAIL_MARKETING, additionalBorrowingJointSubmitRequest.getPostalMarketing()),
                    PermissionPreferences.build(PreferenceType.PHONE_MARKETING, additionalBorrowingJointSubmitRequest.getPhoneMarketing()),
                    PermissionPreferences.build(PreferenceType.EMAIL_MARKETING, additionalBorrowingJointSubmitRequest.getEmailMarketing())
                )
            ).build()
        )
        .build();
    apiService.updateCustomerMarketingPreferences(customerId, updateMarketingPreferences);
    log.info("updateMarketingPreference start for the joint applicant of the account number {}", accountNumber);
  }

  private void publishMessageToKafka(final AdboCaseDetails adboCaseDetails) {
    Objects.requireNonNull(adboCaseDetails, "AdboCaseDetails must not be null before publishing an event to the kafka for joint applicant");
    log.info("setPublishMessage is start for accountNumber {}", adboCaseDetails.getAccountNumber());
    JointDisclaimersAndMpUpdateKafkaEventDto kafkaEventDto =
        JointDisclaimersAndMpUpdateKafkaEventDto.builder()
            .journey(journey)
            .topicName(topicName)
            .channel(channel)
            .brandName(adboCaseDetails.getBrand())
            .jointDisclaimersAndMp(createJointApplicantDisclaimersAndMpDto(adboCaseDetails))
            .build();
    publishMessageService.publishJointApplicantMessageToTopic(kafkaEventDto, adboCaseDetails.getAccountNumber());
  }

  private JointApplicantDisclaimersAndMpDto createJointApplicantDisclaimersAndMpDto(AdboCaseDetails adboCaseDetails) {
    AdboApplicant jointApplicant = adboCaseDetails.getAdboApplicants().get(ApplicantType.JOINT1);
    PersonalDetails jointPersonalDetails = jointApplicant.getPersonalDetails();
    return JointApplicantDisclaimersAndMpDto.builder()
        .id(adboCaseDetails.getId())
        .applicantId(jointApplicant.getApplicantId())
        .route(jointApplicant.getRoute())
        .email(jointPersonalDetails.getEmail())
        .mobileNumber(jointPersonalDetails.getMobileNumber())
        .build();
  }

}
