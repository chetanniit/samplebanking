package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.EligibilityBorrowingControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityBorrowing;
import com.rbs.pbbdhb.coordinator.adbo.service.EligibilityBorrowingService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class EligibilityBorrowingController implements EligibilityBorrowingControllerSwagger {

  private final EligibilityBorrowingService eligibilityBorrowingService;

  /**
   * SaveEligibilityBorrowing method is useful to persist eligibility borrowing details once Journey validation status passed
   */
  @Override
  @PostMapping(value = "/eligibilityBorrowing", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveEligibilityBorrowing(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final EligibilityBorrowing eligibilityBorrowing) {
    log.info("saveEligibilityBorrowing start - Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute, eligibilityBorrowing);
    TenantProvider.applyBrand(brand);
    eligibilityBorrowingService.saveEligibilityBorrowing(accountNumber, eligibilityBorrowing);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveEligibilityBorrowing end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * GetEligibilityBorrowing method is useful to retrieve eligibility borrowing details by passing account number and brand name
   */
  @Override
  @GetMapping(value = "/eligibilityBorrowing", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<EligibilityBorrowing> getEligibilityBorrowing(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getEligibilityBorrowing start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<EligibilityBorrowing> response = new ResponseEntity<>(
        eligibilityBorrowingService.getEligibilityBorrowing(accountNumber), HttpStatus.OK);
    log.info("getEligibilityBorrowing end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

}
