package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum CustomerType {
  EXISTING_CUSTOMER("Existing Customer"),
  NEW_CUSTOMER("New Customer");

  private final String value;

  @Override
  public String toString() {
    return name();
  }

}