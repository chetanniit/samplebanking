package com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.enums;

public enum PreferenceValue {

  YES("YES"),
  NO("NO");


  private final String label;

  PreferenceValue(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
