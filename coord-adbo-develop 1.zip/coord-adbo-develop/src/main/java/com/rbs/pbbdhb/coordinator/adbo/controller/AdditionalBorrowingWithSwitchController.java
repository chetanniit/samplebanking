package com.rbs.pbbdhb.coordinator.adbo.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.AdditionalBorrowingWithSwitchControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingWithSwitchRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AdditionalBorrowingWithSwitchResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AdditionalBorrowingWithSwitchService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/additionalBorrowingWithSwitch")
@Slf4j
public class AdditionalBorrowingWithSwitchController implements AdditionalBorrowingWithSwitchControllerSwagger {

  private final AdditionalBorrowingWithSwitchService additionalBorrowingWithSwitchService;

  @PostMapping(consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
  @Override
  public ResponseEntity<Void> saveAdditionalBorrowingWithSwitch(@RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid AdditionalBorrowingWithSwitchRequest switchRequest) {
    TenantProvider.applyBrand(brand);
    log.info("saveAdditionalBorrowingWithSwitch is started for request : {}, brand:{}, account_number: {},channel: {}", switchRequest,
        brand, accountNumber, channelRoute);
    additionalBorrowingWithSwitchService.saveAdditionalBorrowingWithSwitch(accountNumber, brand, switchRequest);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveAdditionalBorrowingWithSwitch is end for brand {}, account_number: {},channel: {}", brand, accountNumber, channelRoute);
    return response;
  }

  @GetMapping(produces = APPLICATION_JSON_VALUE)
  @Override
  public ResponseEntity<AdditionalBorrowingWithSwitchResponse> getAdditionalBorrowingWithSwitch(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    TenantProvider.applyBrand(brand);
    log.info("getAdditionalBorrowingWithSwitch is started for brand: {}, account_number: {},channel: {}", brand, accountNumber,
        channelRoute);
    AdditionalBorrowingWithSwitchResponse switchedSubAccounts = additionalBorrowingWithSwitchService.getAdditionalBorrowingWithSwitch(accountNumber,
        brand);
    ResponseEntity<AdditionalBorrowingWithSwitchResponse> response = ResponseEntity.ok(switchedSubAccounts);
    log.info("getAdditionalBorrowingWithSwitch is end for  response: {}, brand: {}, account_number: {},channel: {}", response.getBody(), brand,
        accountNumber, channelRoute);
    return response;
  }
}
