package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityApplicant;

public interface EligibilityApplicantService {

  void saveEligibilityApplicant(String accountNumber, EligibilityApplicant eligibilityApplicant);

  EligibilityApplicant getEligibilityApplicant(String accountNumber);
}
