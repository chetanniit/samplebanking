package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.dto.AdboDashboardApplicants;
import com.rbs.pbbdhb.coordinator.adbo.dto.DashboardDocUploadDetails;
import com.rbs.pbbdhb.coordinator.adbo.dto.DashboardFeePaymentDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.*;
import com.rbs.pbbdhb.coordinator.adbo.model.BasicPackagingUpdate.BasicPackagingUpdate;
import com.rbs.pbbdhb.coordinator.adbo.model.BasicPackagingUpdate.PackagingApplicantInfo;
import com.rbs.pbbdhb.coordinator.adbo.response.DashboardAndTrackingDetails;
import com.rbs.pbbdhb.coordinator.adbo.service.DashboardStatusService;
import com.rbs.pbbdhb.coordinator.adbo.util.AdboFeePaymentActionCheck;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.rbs.pbbdhb.coordinator.adbo.enums.AdboApplicationStatus.*;
import static com.rbs.pbbdhb.coordinator.adbo.enums.CaseStatus.SUBMIT_GMS_STAGE_20;
import static com.rbs.pbbdhb.coordinator.adbo.enums.DashboardDocUploadStatus.*;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

@Slf4j
@Service
@RequiredArgsConstructor
public class DashboardStatusServiceImpl implements DashboardStatusService {
    private final AdboCaseDetailsDao adboCaseDetailsDao;
    private final AdboFeePaymentActionCheck adboFeePaymentActionCheck;

    @Override
    public DashboardAndTrackingDetails getDashboardAndTracking(String accountNumber) {
        log.info("getDashboardAndTracking started for account_number {}", accountNumber);
        AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
        return buildDashboardAndTracking(adboCaseDetails);
    }

    private List<AdboDashboardApplicants> buildApplicants(AdboCaseDetails adboCaseDetails) {
        log.info("buildApplicants started for account_number {}, caseStatus {}", adboCaseDetails.getAccountNumber(), adboCaseDetails.getStatus());
        ArrayList<AdboDashboardApplicants> applicants = new ArrayList<>();
        adboCaseDetails.getAdboApplicants().forEach((applicantType, adboApplicant) -> applicants.add(buildApplicant(adboCaseDetails, applicantType)));
        return applicants;
    }

    private AdboDashboardApplicants buildApplicant(AdboCaseDetails adboCaseDetails, ApplicantType applicantType) {
        return AdboDashboardApplicants.builder()
                .applicantType(applicantType)
                .consent(isTrue(adboCaseDetails.getAdboApplicants().get(applicantType).getIsMarketingPreferenceUpdated()))
                .docUpload(buildDocUpload(adboCaseDetails, applicantType))
                .build();
    }

    private DashboardDocUploadStatus getDocUploadStatus(AdboCaseDetails adboCaseDetails, ApplicantType applicantType) {
        if (StringUtils.isBlank(adboCaseDetails.getCaseId()) || isNull(adboCaseDetails.getBasicPackagingUpdate())) {
            return UNKNOWN;
        }
        BasicPackagingUpdate basicPackagingUpdate = adboCaseDetails.getBasicPackagingUpdate();
        log.info("BasicPackagingUpdate account_number {} has a isBasicPackagingReceived {},isBasicPackagingRequired {},isSIReceived {}, isSIRequested {}",
                adboCaseDetails.getAccountNumber(), basicPackagingUpdate.isBasicPackagingReceived(), basicPackagingUpdate.isBasicPackagingRequired(), basicPackagingUpdate.isSIReceived(), basicPackagingUpdate.isSIRequested());
        for (PackagingApplicantInfo packagingApplicantInfo : basicPackagingUpdate.getApplicants()) {
            if (Objects.equals(packagingApplicantInfo.getApplicantId(), adboCaseDetails.getAdboApplicants().get(applicantType).getApplicantId())) {
                if (! isPackagingReceivedOrNotRequired(packagingApplicantInfo.isBasicPackagingReceived(), packagingApplicantInfo.isBasicPackagingRequired())) {
                    return TODO;
                } else if (! isPackagingReceivedOrNotRequired(packagingApplicantInfo.isSIReceived(), packagingApplicantInfo.isSIRequested())) {
                    return TODO_AFTER_COMPLETE;
                } else {
                    return COMPLETE;
                }
            }
        }
        return UNKNOWN;
    }

    private Boolean isPackagingReceivedOrNotRequired(Boolean isPackagingReceived, Boolean isPackagingRequired) {
        return isTrue(isPackagingReceived) || isFalse(isPackagingRequired);
    }

    private DashboardDocUploadDetails buildDocUpload(AdboCaseDetails adboCaseDetails, ApplicantType applicantType) {
        return DashboardDocUploadDetails.builder()
                .enabled(Objects.nonNull(adboCaseDetails.getCaseId()))
                .status(getDocUploadStatus(adboCaseDetails, applicantType))
                .build();
    }

    private Long getTotalRemainingDaysInSeconds(AdboCaseDetails adboCaseDetails) {
        return switch (adboCaseDetails.getStatus()) {
            case CAPIE_UPDATED ->
                    SECONDS.between(LocalDateTime.now(), adboCaseDetails.getCaseCreationDate().plusDays(14));
            case SUBMIT_ORCHESTRATION ->
                    SECONDS.between(LocalDateTime.now(), adboCaseDetails.getModifiedDate().plusDays(14));
            default -> null;
        };
    }

    private DashboardFeePaymentDetails buildFeePayment(AdboCaseDetails adboCaseDetails) {
        FeeAction feeAction = adboFeePaymentActionCheck.getFeeActionFrom(adboCaseDetails);
        boolean isPaymentMade = false;
        if (Objects.equals(FeeAction.NO_ACTION, feeAction) && Objects.equals(SUBMIT_GMS_STAGE_20, adboCaseDetails.getStatus())) {
            isPaymentMade = adboFeePaymentActionCheck.getIsPaymentMade(adboCaseDetails.getCaseId());
        }
        log.info("Fee payment feeAction {},isPaymentMade {}  account_number {} ,application current status {}", feeAction, isPaymentMade, adboCaseDetails.getAccountNumber(), adboCaseDetails.getStatus());
        return DashboardFeePaymentDetails.builder()
                .enabled(isFeePaymentEnabled(feeAction, isPaymentMade, adboCaseDetails.getStatus()))
                .status(getFeePaymentStatus(feeAction, isPaymentMade, adboCaseDetails.getStatus()))
                .build();
    }

    private FeePaymentStatus getFeePaymentStatus(FeeAction feeAction, Boolean isPaymentMade, CaseStatus caseStatus) {
        if (! Objects.equals(FeeAction.NO_ACTION, feeAction)) return FeePaymentStatus.NOT_APPLICABLE;
        return ! Objects.equals(SUBMIT_GMS_STAGE_20, caseStatus) ? FeePaymentStatus.TODO : (isTrue(isPaymentMade) ?
                FeePaymentStatus.COMPLETE : FeePaymentStatus.TODO);
    }

    private boolean isFeePaymentEnabled(FeeAction feeAction, boolean isPaymentMade, CaseStatus caseStatus) {
        return Objects.equals(FeeAction.NO_ACTION, feeAction) && Objects.equals(SUBMIT_GMS_STAGE_20, caseStatus) && isFalse(isPaymentMade);
    }

    private DashboardAndTrackingDetails buildDashboardAndTracking(AdboCaseDetails adboCaseDetails) {
        return DashboardAndTrackingDetails
                .builder()
                .remainingDaysInSeconds(Objects.nonNull(adboCaseDetails.getStatus()) ? getTotalRemainingDaysInSeconds(adboCaseDetails) : null)
                .enableApplicationTracking(Objects.equals(SUBMIT_GMS_STAGE_20, adboCaseDetails.getStatus()))
                .applicants(buildApplicants(adboCaseDetails))
                .feePayment(buildFeePayment(adboCaseDetails))
                .applicationStatus(Objects.nonNull(adboCaseDetails.getStatus()) ? getApplicationStatus(adboCaseDetails.getStatus()) : null)
                .build();

    }

    private AdboApplicationStatus getApplicationStatus(CaseStatus status) {
        return switch (status) {
            case SUBMIT_GMS_STAGE_20 -> SUBMITTED;
            case CAPIE_UPDATED, SUBMIT_ORCHESTRATION -> MINI_SUBMITTED;
            case HARDSCORE_DECLINED, SUBMIT_GMS_MOPS, CONTRACT_VALIDATION_ERROR -> SUBMISSION_FAILED;
        };
    }


}
