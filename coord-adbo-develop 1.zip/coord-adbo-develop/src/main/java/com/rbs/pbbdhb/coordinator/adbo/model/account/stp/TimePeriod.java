package com.rbs.pbbdhb.coordinator.adbo.model.account.stp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TimePeriod {

  private Integer years;
  private Integer months;
  @JsonIgnore
  private Long totalDurationDays;

}