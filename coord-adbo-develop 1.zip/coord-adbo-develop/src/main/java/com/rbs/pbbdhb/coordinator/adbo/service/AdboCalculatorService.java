package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails;
import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyMinMaxRepaymentCalculator;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboCalculator;
import com.rbs.pbbdhb.coordinator.adbo.response.MinMaxRepaymentVo;

public interface AdboCalculatorService {

	void saveBorrowingDetails(String accountNumber, BorrowingDetails borrowingDetails);

	MinMaxRepaymentVo getMonthlyMinMaxRepayment(
			MonthlyMinMaxRepaymentCalculator additionalRepaymentCalculatorForTenure, String accountNumber);

	AdboCalculator getAdboCalculatorDetails(String accountNumber);
}
