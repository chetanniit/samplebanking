package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.pbbdhb.coordinator.adbo.service.RestService;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class RestServiceImpl implements RestService {

  private final RestTemplate iamJwtChainRestTemplate;

  private final RestTemplate patchRestTemplate;

  private final ObjectMapper objectMapper;

  public RestServiceImpl(@Qualifier("iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainRestTemplate,
      @Qualifier("patchRestTemplate") RestTemplate patchRestTemplate, ObjectMapper objectMapper) {
    this.iamJwtChainRestTemplate = iamJwtChainRestTemplate;
    this.patchRestTemplate = patchRestTemplate;
    this.objectMapper = objectMapper;
  }

  @Override
  public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity,
      ParameterizedTypeReference<T> responseType) {
    return executeExchange(url, null, () -> iamJwtChainRestTemplate.exchange(url, method, requestEntity, responseType));
  }

  @Override
  public <T> ResponseEntity<T> patchExchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType) {
    return patchRestTemplate.exchange(url, method, requestEntity, responseType);
  }

  @Override
  public <T> ResponseEntity<T> exchange(String url, HttpMethod method, @Nullable HttpEntity<?> requestEntity, Class<T> responseType) {
    return executeExchange(url, responseType, () -> iamJwtChainRestTemplate.exchange(url, method, requestEntity, responseType));
  }

  private <T> ResponseEntity<T> executeExchange(String url, Class<T> responseType, Supplier<ResponseEntity<T>> exchangeResponse) {
    ResponseEntity<T> response;
    try {
      response = exchangeResponse.get();
      if (HttpStatus.OK.equals(response.getStatusCode()) || HttpStatus.CREATED.equals(response.getStatusCode())) {
        return response;
      }
      log.error("Rest call failed for Url:{}\nErrorDetails: StatusCode:{} Response:{}", url, response.getStatusCodeValue(),
          response.getBody());
      throw new BusinessException("internal.server.error", response.getStatusCodeValue());
    } catch (RestClientException ex) {
      if (ex instanceof HttpStatusCodeException) {
        HttpStatusCodeException statusCodeException = (HttpStatusCodeException) ex;
        String responseBody = statusCodeException.getResponseBodyAsString();
        HttpStatusCode statusCode = statusCodeException.getStatusCode();
        log.error("Rest call failed for Url:{}}\nErrorDetails:{}", url, responseBody, ex);
        try {
          if (responseType != null && StringUtils.isNotBlank(responseBody)) {
            T errorResponseBody = objectMapper.readValue(statusCodeException.getResponseBodyAsByteArray(), responseType);
            response = new ResponseEntity<>(errorResponseBody, statusCode);
          } else {
            response = new ResponseEntity<>(statusCode);
          }
        } catch (Exception e) {
          throw new BusinessException("internal.server.error", e);
        }
      } else if (ex instanceof ResourceAccessException) {
        log.error("{} Request timed out for Url:{}", HttpStatus.REQUEST_TIMEOUT.value(), url);
        throw new BusinessException("request.timed.out", ex, HttpStatus.REQUEST_TIMEOUT.value());
      } else {
        throw new BusinessException("internal.server.error", ex);
      }
    }
    return response;
  }
}
