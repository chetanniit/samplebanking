package com.rbs.pbbdhb.coordinator.adbo.dao.impl;

import static com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode.FAILED;
import static com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode.PASS;
import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toSet;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode;
import com.rbs.pbbdhb.coordinator.brand.BrandedComponentsFactory;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * Class for mongodb CRUD operations for {@link AdboCaseDetails}
 */
@Slf4j
@Component
public class AdboCaseDetailsDaoImpl implements AdboCaseDetailsDao {

  private static final DetailsFilter VALIDATION_PASSED = new JourneyValidationResultDetailsFilter(EnumSet.of(PASS));
  private static final DetailsFilter VALIDATION_NOT_FAILED = new JourneyValidationResultDetailsFilter(
      EnumSet.complementOf(EnumSet.of(FAILED)));
  private final BrandedComponentsFactory factory;
  /**
   * Collection of {@link DetailsFilter} implementations to test each time {@link AdboCaseDetails} record is loaded.
   */
  private final List<DetailsFilter> detailsFilters;

  public AdboCaseDetailsDaoImpl(BrandedComponentsFactory factory, List<DetailsFilter> detailsFilters) {
    this.factory = factory;
    this.detailsFilters = detailsFilters;
  }

  /**
   * This method is useful to save the case details document in the mongodb.
   */
  @Override
  public AdboCaseDetails save(AdboCaseDetails adboCaseDetails) {
    try {
      return factory.getAdboCaseDetailsRepository().save(adboCaseDetails);
    } catch (Exception exception) {
      log.error(
          "Unexpected error occurred while saving/updating the adboCaseDetails details in mongodb, accountNumber {}, brand {}",
          adboCaseDetails.getAccountNumber(), adboCaseDetails.getBrand(), exception);
      throw new BusinessException("adboCaseDetails failed to save in the mongodb", HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
  }

  @Override
  public AdboCaseDetails getCaseDetailsByAccountNumber(String accountNumber) {
    return getCaseDetailsByAccountNumber(accountNumber, new DetailsFilter[]{});
  }

  @Override
  public AdboCaseDetails getValidCaseDetailsByAccountNumber(String accountNumber) {
    return getCaseDetailsByAccountNumber(accountNumber, VALIDATION_PASSED);
  }

  @Override
  public AdboCaseDetails getCaseForJourneyValidationPassOrLimited(String accountNumber) {
    return getCaseDetailsByAccountNumber(accountNumber, VALIDATION_NOT_FAILED);
  }

  private AdboCaseDetails getCaseDetailsByAccountNumber(String accountNumber, DetailsFilter... acceptCondition) {
    AdboCaseDetails adboCaseDetails = factory.getAdboCaseDetailsRepository().findFirstByAccountNumberOrderByCreatedDateDesc(accountNumber)
        .orElseGet(() -> {
          log.error("adboCaseDetails not found for the given account number {}", accountNumber);
          throw new BusinessException(Constants.ACCOUNT_NOT_FOUND, HttpStatus.NOT_FOUND.value());
        });
    checkDetails(adboCaseDetails, detailsFilters);
    checkDetails(adboCaseDetails, asList(acceptCondition));
    return adboCaseDetails;
  }

  private void checkDetails(AdboCaseDetails adboCaseDetails, List<DetailsFilter> acceptCondition) {
    acceptCondition.stream().filter(condition -> !condition.test(adboCaseDetails)).findFirst().ifPresent(filter -> {
      log.error("adboCaseDetails does not match condition for the given account number {}", adboCaseDetails.getAccountNumber());
      throw new BusinessException(filter.errorMessageKey(), filter.errorCode());
    });
  }

  /**
   * Class is an extension to {@link Predicate} to also provide error data to return in case {@link #test(Object)} check fails.
   */
  public interface DetailsFilter extends Predicate<AdboCaseDetails> {

    /**
     * @return error code to return when {@link #test(Object)} fails.
     */
    int errorCode();

    /**
     * @return error message to return when {@link #test(Object)} fails.
     */
    String errorMessageKey();
  }

  /**
   * Class to create {@link DetailsFilter} implementations to filter {@link AdboCaseDetails} records with matching journey validation result
   * codes.
   *
   * <p>This class is private because its instances should be reused so there is no point of making it visible outside</p>
   */

  private static final class JourneyValidationResultDetailsFilter extends AbstractDetailsFilter {

    private final Set<String> allowedCodes;

    private JourneyValidationResultDetailsFilter(EnumSet<JourneyValidationResultCode> allowedCodes) {
      super(HttpStatus.BAD_REQUEST, Constants.ACCOUNT_NOT_ELIGIBLE);
      this.allowedCodes = allowedCodes.stream().map(JourneyValidationResultCode::name).collect(toSet());
    }

    @Override
    public boolean test(AdboCaseDetails adboCaseDetails) {
      return allowedCodes.contains(adboCaseDetails.getValidationResult());
    }

  }
}
