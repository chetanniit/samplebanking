package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Validator extends Predicate<JourneyValidation>, Function<JourneyValidation, ValidationRuleResultCode> {

  int getPriority();

  /**
   * If it's important who caused validation failure, provide list of cins of borrowers for whom {@link #test(Object)} returns true.
   *
   * @return List of cins failing check and triggering return of the assigned {@link ValidationRuleResultCode}
   */
  default List<String> getFailingCins(JourneyValidation journeyValidationData) {
    return new ArrayList<>(0);
  }
}
