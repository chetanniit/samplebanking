package com.rbs.pbbdhb.coordinator.adbo.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertFalse;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
public class OutgoingPaymentsDetails  {

  /**
   * Does the customer has any credit cards or not
   */
  @NotNull(message = "hasCreditCards must not be null, should be either true or false")
  private Boolean hasCreditCards;

  /**
   * List out the all the credit cards from the different banks or same bank
   */
  @Valid
  private List<CreditCardDetails> creditCards;

  /**
   * Does the customer has any loans or not
   */
  @NotNull(message = "hasLoans must not be null, should be either true or false")
  private Boolean hasLoans;

  /**
   * List out the all the loan details from the different banks or same bank
   */
  @Valid
  private List<LoanDetails> loans;
  /**
   * customer has any additional properties
   */
  @NotNull(message = "hasAdditionalProperties must not be null, should be either true or false")
  private Boolean hasAdditionalProperties;

  /**
   * List of additional properties
   */
  @Valid
  private List<AdditionalPropertyDetails> additionalProperties;

  /**
   * customer has any fixed commitments
   */
  @NotNull(message = "hasFixedCommitments must not be null, should be either true or false")
  private Boolean hasFixedCommitments;

  /**
   * List of fixed commitments
   */
  @Valid
  private List<FixedCommitmentDetails> fixedCommitments;

  /**
   * Is there any childcare expenses
   */
  private Boolean hasChildcareExpenses;

  /**
   * listed childcare expenses into a list
   */
  @Valid
  private List<ChildCareExpenseDetails> childcareExpenses;

  /**
   * Is there any childcare expenses
   */
  private Boolean hasDependentExpenses;

  /**
   * listed dependents expenses into a list
   */
  @Valid
  private List<DependentExpenseDetails> dependentExpenses;

  /**
   * Is there any changes in circumstances or not
   */
  @NotNull(message = "hasChangeInCircumstances must not be null, should be either true or false")
  @AssertFalse(message = "hasChangeInCircumstances must be False")
  private Boolean hasChangeInCircumstances;

  /**
   * monthly pension contribution
   */
  private BigDecimal monthlyPensionContribution;

  /**
   * monthly pension contribution
   */
  private BigDecimal jointApplicantMonthlyPensionContribution;

  /**
   * residentialProperty details added
   */
  private NewAdditionalProperty newAdditionalProperty;

  /**
   * monthly living elsewhere amount
   */
  private BigDecimal monthlyLivingElseWhereAmount;

  /**
   * monthly living elsewhere amount shared between the both parties 50-50
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyLivingElseWhereAmount;
}
