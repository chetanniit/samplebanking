package com.rbs.pbbdhb.coordinator.adbo.request;

import com.rbs.pbbdhb.coordinator.adbo.dto.SelectedSubAccountDto;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@EqualsAndHashCode
public class AdditionalBorrowingWithSwitchRequest {

  @NotNull(message = "additionalBorrowingWithSwitch must not be Null")
  private Boolean additionalBorrowingWithSwitch;
  private List<SelectedSubAccountDto> selectedSubAccountsForSwitch;
}
