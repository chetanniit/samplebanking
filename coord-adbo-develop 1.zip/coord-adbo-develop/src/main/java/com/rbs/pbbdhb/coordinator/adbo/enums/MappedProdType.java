package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum MappedProdType {
  F,
  T,
  R,
  S,
  X;
}
