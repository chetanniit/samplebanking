package com.rbs.pbbdhb.coordinator.adbo.response;

import java.math.BigDecimal;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipResponse {

  private String decision;

  private Integer additionalBorrowingAmount;

  private Integer termYears;

  private Integer termMonths;

  private BigDecimal estimatedPropertyValue;

  private BigDecimal hpiValuation;

  private Boolean planningPermissionRequired;

  private Boolean planningPermissionAcquired;

  private String policyMessage;

}
