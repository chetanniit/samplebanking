package com.rbs.pbbdhb.coordinator.adbo.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class SelectedSubAccountDto {

  @NotNull(message = "subAccountNumber must not be Null")
  private Integer subAccountNumber;
}
