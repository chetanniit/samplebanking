package com.rbs.pbbdhb.coordinator.adbo.model.BasicPackagingUpdate;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class DocumentRequestUpdateDetail {

    private List<String> requiredFor;
    @JsonProperty("docrefId")
    private String documentIdentifier;
    @JsonProperty("requestType")
    private String requestType;
    @JsonProperty("categoryCode")
    private String docCategory;
    private String count;
    private String frequency;
    private String requestId;
    private String towerCorrespondenceCode;
    @JsonProperty("isClosed")
    private boolean isClosed;
    private List<String> documentIds;
    private List<DocInfo> documentInfo;

}


