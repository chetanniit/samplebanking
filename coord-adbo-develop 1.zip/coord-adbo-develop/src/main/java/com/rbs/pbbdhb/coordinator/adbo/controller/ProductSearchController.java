package com.rbs.pbbdhb.coordinator.adbo.controller;

import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.ProductSearchControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ProductSearchService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;

import io.swagger.v3.oas.annotations.Parameter;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/products")
public class ProductSearchController implements ProductSearchControllerSwagger {

  private final ProductSearchService productSearchService;

  @Override
  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ProductSearchResponse> productSearch(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(RBS|rbs|nwb|NWB)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("productSearch start - Headers - accountNumber: {}, brand: {}, channel: {}",accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<ProductSearchResponse> response = ResponseEntity.ok(productSearchService.getProducts(accountNumber, brand));
    log.info("productSearch end's with accountNumber: {}, response {}, brand: {}, channel: {}", accountNumber,response.getBody(), brand, channelRoute);
    return response;
  }

  /**
   * This method is responsible to persist the product details into the mongodb.
   *
   * @param accountNumber  is a unique identification number
   * @param brand          is nwb or rbs
   * @param productDetails list of products to be saved
   * @return void
   */
  @Override
  @PostMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveProductDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "productDetails") @RequestBody @Valid List<Product> productDetails) {
    log.info("saveProductDetails start - Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand,
        channelRoute, productDetails);
    TenantProvider.applyBrand(brand);
    productSearchService.saveProductDetails(accountNumber, productDetails);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveProductDetails end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber,
        brand, channelRoute);
    return response;
  }
}