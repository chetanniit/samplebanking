package com.rbs.pbbdhb.coordinator.adbo.configuration;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rbs.dws.security.UserPrincipalProvider;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import com.rbs.dws.security.utils.HttpHeadersHelper;
import com.rbs.dws.transport.claimSource.ClaimsSourceFactory;
import com.rbs.dws.transport.config.HttpConfig;
import com.rbs.dws.transport.config.IamJwtChainConfig;
import com.rbs.dws.transport.jwtchain.JwkProvider;
import com.rbs.dws.transport.rest.SecureClientHttpRequestFactory;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;
import org.apache.hc.client5.http.classic.HttpClient;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;


@Configuration
@EnableAutoConfiguration
public class CoordinatorApplicationConfig {

  @Bean("modelMapper")
  public ModelMapper modelMapper() {
    return new ModelMapper();
  }


  @Bean
  public ObjectMapper objectMapper() {
    // ObjectMapper used in various tests but is configured here so that info actuator output has a human readable date

    // Default time format includes timezone offset and relative to UTC
    // so BST will be "...+0100" and GMT will be "...Z"
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXX");
    format.setTimeZone(TimeZone.getTimeZone("UTC"));  // output UTC times

    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    objectMapper.setSerializationInclusion(Include.NON_NULL);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.setDateFormat(format);

    return objectMapper;
  }

  @Bean
  public MessageSource messageSource() {
    ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
    messageSource.setBasename("classpath:messages");
    messageSource.setDefaultEncoding("UTF-8");
    return messageSource;
  }

  @Bean
  public jakarta.validation.Validator localValidatorFactoryBean() {
    return new com.rbs.pbbdhb.coordinator.adbo.configuration.CustomLocalValidatorFactoryBean();
  }

  @Bean("patchIamJwtChainSecureClientHttpRequestFactory")
  public SecureClientHttpRequestFactory<HttpHeadersHelper> patchIamJwtChainSecureClientHttpRequestFactory(
      @Qualifier("secureHttpClient") HttpClient httpClient,
      HttpConfig httpConfig,
      @Qualifier("cascadingUserPrincipalProvider") UserPrincipalProvider principalProvider,
      JwkProvider jwkProvider, IamJwtChainConfig iamJwtChainConfig,
      MicroserviceIssuer microserviceIssuer,
      ClaimsSourceFactory claimsSourceFactory) {
    return new PatchIamJwtChainSecureClientHttpRequestFactory(httpClient, httpConfig, principalProvider, jwkProvider,
        iamJwtChainConfig, microserviceIssuer, new HttpHeadersHelper(), claimsSourceFactory);
  }

  @Bean("patchRestTemplate")
  @Qualifier("patchRestTemplate")
  public RestTemplate patchRestTemplate(
      @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate secureRestTemplate,
      @Qualifier("patchIamJwtChainSecureClientHttpRequestFactory") SecureClientHttpRequestFactory<HttpHeadersHelper> clientHttpRequestFactory) {
    secureRestTemplate.setRequestFactory(clientHttpRequestFactory);

    List<HttpMessageConverter<?>> messageConverters =
        secureRestTemplate.getMessageConverters();
    for (HttpMessageConverter<?> messageConverter : messageConverters) {
      if (messageConverter instanceof MappingJackson2HttpMessageConverter) {
        ((MappingJackson2HttpMessageConverter) messageConverter)
            .setObjectMapper(objectMapper());
      }
    }
    return secureRestTemplate;
  }

}
