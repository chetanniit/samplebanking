package com.rbs.pbbdhb.coordinator.adbo.configuration;

import com.rbs.pbbdhb.coordinator.adbo.tenant.Brand;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;

/**
 * Duplicate of {@link TenantProvider}.
 *
 * @deprecated Use {@link TenantProvider}.
 */
@Deprecated
public class BrandContextHolder {

  private BrandContextHolder() {
  }

  public static String getCurrentBrand() {
    return TenantProvider.getCurrentBrand().getName();
  }

  public static void setCurrentBrand(String brand) {
    TenantProvider.applyBrand(Brand.valueOf(brand.toUpperCase()));
  }

  public static void clear() {
    TenantProvider.clearBrand();
  }
}