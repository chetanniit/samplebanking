package com.rbs.pbbdhb.coordinator.adbo.util;

import static org.apache.commons.lang3.BooleanUtils.isNotTrue;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import java.util.List;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;

@UtilityClass
public class SubAccountsSelectionForSwitching {

  public List<SubAccount> selectedSubAccountsForSwitching(AdboCaseDetails adboCaseDetails) {

    return adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream()
        .filter(subAccount -> isTrue(subAccount.getSelectedForSwitch())).collect(Collectors.toList());
  }

  public List<SubAccount> nonSelectedSubAccountsForSwitching(AdboCaseDetails adboCaseDetails) {

    return adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream()
        .filter(subAccount -> isNotTrue(subAccount.getSelectedForSwitch())).collect(Collectors.toList());
  }
}
