package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;


public enum SelfEmployedBasis {

  LIMITED_COMPANY("LIMITED_COMPANY"),
  SOLE_TRADER("SOLE_TRADER"),
  PARTNERSHIP("PARTNERSHIP");


  private final String label;

  SelfEmployedBasis(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
