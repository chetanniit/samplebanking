package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.MortgageQuoteRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.MortgageQuoteResponse;

public interface MortgageQuoteService {

  MortgageQuoteResponse getMortgageQuoteDetails(String accountNumber);

  void saveMortgageQuoteDetails(String accountNumber, MortgageQuoteRequest mortgageQuoteRequest);

}
