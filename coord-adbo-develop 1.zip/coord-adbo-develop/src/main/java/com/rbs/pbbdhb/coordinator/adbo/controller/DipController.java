package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.DipControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.response.DipResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.DipService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is used for fetch customer details from mongodb and construct dip contract and call DIP API and store the DIP API results in
 * mongodb.
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/dip")
public class DipController implements DipControllerSwagger {

  private final DipService dipService;

  @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  @Override
  public ResponseEntity<DipResponse> getDecisionInPrinciple(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getDecisionInPrinciple start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<DipResponse> response = new ResponseEntity<>(dipService.getDecisionInPrinciple(accountNumber),
        HttpStatus.OK);
    log.info("getDecisionInPrinciple end's with response {}, account_number: {}, brand {}, channel: {}", response.getBody(), accountNumber,brand, channelRoute);
    return response;
  }

  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  @Override
  public ResponseEntity<DipResponse> getDecisionInPrincipleFromDB(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getDecisionInPrincipleFromDB start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand,
        channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<DipResponse> response = new ResponseEntity<>(dipService.getDecisionInPrincipleFromDB(accountNumber), HttpStatus.OK);
    log.info("getDecisionInPrincipleFromDB end's with response {}, account_number: {}, brand {}, channel: {}", response.getBody(), accountNumber,brand, channelRoute);
    return response;
  }
}
