package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static java.util.Arrays.asList;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.account.gmsaccount.HoldCodes;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.util.List;
import java.util.Map;

public abstract class HoldCodesValidator extends AbstractValidator {

  private final List<String> matchCodes;

  public HoldCodesValidator(int priority, ValidationRuleResultCode validationRuleResultCode, String... matchCodes) {
    super(priority, validationRuleResultCode);
    this.matchCodes = asList(matchCodes);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    HoldCodes holdCodes = journeyValidation.getAccountSummaryApiResponse().getHoldCodes();
    if (holdCodes != null) {
      Map<String, String> holdCode = holdCodes.getHoldCode();
      for (String h2BHoldCode : matchCodes) {
        if (holdCode.containsKey(h2BHoldCode)) {
          return true;
        }
      }
    }
    return false;
  }
}
