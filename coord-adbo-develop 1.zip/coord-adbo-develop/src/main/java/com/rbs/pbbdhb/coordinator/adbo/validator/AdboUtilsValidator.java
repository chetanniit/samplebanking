package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.isBlank;

import com.rbs.pbbdhb.coordinator.adbo.enums.BankName;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.Errors;

public class AdboUtilsValidator {

  public static final int OTHER_FIELD_MAX_LENGTH = 30;
  private static final String OTHER_FIELD_ALLOWED_30_CHARACTERS = "other field maximum 30 characters allowed";
  private static final String OTHER_FIELD_NOT_NULL = "other field must not be null, If the bank name is other";
  private static final String PROVIDER_MUST_VALID_TYPE = ", Please provide valid bank name";
  private static final String OTHER = "other";

  public static void nullCheck(final String errorMessage, final Object input) {
    if (isNull(input)) {
      throw new BusinessException(errorMessage, HttpStatus.BAD_REQUEST.value());
    }
  }

  public static void nullOrEmptyList(final String errorMessage, final List<?> input) {
    if (CollectionUtils.isEmpty(input)) {
      throw new BusinessException(errorMessage, HttpStatus.BAD_REQUEST.value());
    }
  }

  public static void unsupportedType(final String errorMessage) {
    throw new BusinessException(errorMessage, HttpStatus.BAD_REQUEST.value());
  }

  public static void unsupportedType(final String propertyName, final String errorMessage, final Errors errors) {
    errors.rejectValue(propertyName, "unsupported-type", errorMessage);
  }

  public static void validateBankName(BankName bankName, Errors errors, String fieldName, String other) {
    switch (bankName) {
      case NATWEST_BANK:
      case ROYAL_BANK_OF_SCOTLAND:
      case BARCLAYS_BANK:
      case HALIFAX:
      case HSBC_BANK:
      case SANTANDER:
      case TESCO_BANK:
      case LLOYDS_BANK:
      case SAINSBURYS_BANK:
      case NATIONWIDE_BUILDING_SOCIETY:
        break;
      case OTHER:
        if (isBlank(other)) {
          errors.rejectValue(OTHER, "not_null", OTHER_FIELD_NOT_NULL);
          break;
        }
        if (other.length() > OTHER_FIELD_MAX_LENGTH) {
          errors.rejectValue(OTHER, "length_restricted", OTHER_FIELD_ALLOWED_30_CHARACTERS);
          break;
        }
        break;
      default:
        errors.rejectValue(fieldName, "unsupported_cardProvider", fieldName.concat(PROVIDER_MUST_VALID_TYPE));
    }
  }
}
