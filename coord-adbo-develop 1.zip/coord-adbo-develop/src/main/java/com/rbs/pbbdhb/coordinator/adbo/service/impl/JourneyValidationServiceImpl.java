package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static java.util.Arrays.asList;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicationStatus;
import com.rbs.pbbdhb.coordinator.adbo.enums.CaseStatus;
import com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode;
import com.rbs.pbbdhb.coordinator.adbo.enums.RouteTo;
import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.GmsStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.Customer;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidationApiResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AccountService;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.AsyncDataLoader;
import com.rbs.pbbdhb.coordinator.adbo.service.JourneyValidationDataMapper;
import com.rbs.pbbdhb.coordinator.adbo.service.JourneyValidationService;
import com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation.JourneyValidatorsWrapper;
import com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation.JourneyValidatorsWrapper.ValidationRuleResult;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.EnumMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Slf4j
@ConditionalOnProperty(value = "stub.journeyValidation.enabled", havingValue = "false", matchIfMissing = true)
@Service
@RequiredArgsConstructor
public class JourneyValidationServiceImpl implements JourneyValidationService {

  private final AsyncDataLoader asyncDataLoader;

  private final JourneyValidatorsWrapper journeyValidatorsWrapper;

  private final AccountService accountService;

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  private final JourneyValidationDataMapper dataMapper;

  private final ApiService apiService;

  @Value("${eligibleToSwitch.max.allowed-sub-accounts}")
  private int eligibleToSwitchMaxAllowedSubAccounts;

  private static boolean hasBeenModifiedToday(AdboCaseDetails adboCaseDetails) {
    return adboCaseDetails.getModifiedDate().toLocalDate().equals(LocalDate.now());
  }

  public static boolean isDateInRange(LocalDateTime startDate, LocalDateTime endDate) {
    LocalDateTime currentDate = LocalDateTime.now();
    return !currentDate.isBefore(startDate) && !currentDate.isAfter(endDate);
  }

  public static long daysRemaining(AdboCaseDetails adboCaseDetails) {
    LocalDate currentDate = LocalDateTime.now().toLocalDate();
    LocalDate modifiedDate = adboCaseDetails.getModifiedDate().toLocalDate();

    return 180 - (ChronoUnit.DAYS.between(modifiedDate, currentDate));
  }

  private static boolean checkIfApplicationInProgressBeforeMiniSubmit(AdboCaseDetails adboCaseDetails,
      JourneyValidationApiResponse response) {
    boolean jointApplicantLogin = false;
    for (Customer customer : response.getCustomers()) {
      if (!customer.getApplicantType().equals(ApplicantType.MAIN) && customer.isLoggedInUser()) {
        jointApplicantLogin = true;
        break;
      }
    }

    return jointApplicantLogin && (adboCaseDetails.getStatus() == null
        || (adboCaseDetails.getStatus() == CaseStatus.CAPIE_UPDATED && !isDateInRange(
        adboCaseDetails.getCaseCreationDate(), adboCaseDetails.getCaseCreationDate().plusDays(14))));
  }

  private static void changeResultToFailedDueToMainApplicantApplicationInProgress(JourneyValidationApiResponse response,
      AdboCaseDetails caseDetails) {
    response.setJourneyValidationResultCode(JourneyValidationResultCode.FAILED);
    response.setValidationRuleResultCode(ValidationRuleResultCode.FAILED_DUE_TO_MAIN_APPLICANT_APPLICATION_IS_INPROGRESS);
    response.setHasSecondCharge(null);
    response.setDaysToComplete((int) daysRemaining(caseDetails));
  }

  @Override
  public JourneyValidationApiResponse getJourneyValidation(String accountNumber, String cin, boolean isStatusResetRequired) {
    JourneyValidationApiResponse response = null;
    AdboCaseDetails adboCaseDetails = null;
    try {
      adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    } catch (Exception e) {
      log.error("No Record found on Mongo for the given Account Number {}", accountNumber);
    }

    boolean isStatusValidAndWithin14Days = nonNull(adboCaseDetails) && nonNull(adboCaseDetails.getStatus()) &&
            (isStatusSubmitOrchestrationWithInInterval(adboCaseDetails) || isStatusCapieUpdatedWithInInterval(adboCaseDetails));

    if(nonNull(adboCaseDetails)) {
      response = getJourneyValidationApiResponseForCinMisMatched(cin,accountNumber, response, adboCaseDetails);
      if (nonNull(response ))
        return response;
    }

    if (nonNull(adboCaseDetails) && (hasBeenModifiedToday(adboCaseDetails) || isStatusValidAndWithin14Days ||
            asList(CaseStatus.HARDSCORE_DECLINED, CaseStatus.CONTRACT_VALIDATION_ERROR, CaseStatus.SUBMIT_GMS_STAGE_20, CaseStatus.SUBMIT_GMS_MOPS).contains(adboCaseDetails.getStatus()))) {
      response = buildResponse(adboCaseDetails, null, cin);
      if (isStatusValidAndWithin14Days) {
        response = checkIfApplicationInFlightAfterMiniSubmit(accountNumber, response);
      }
    }
    if (response == null) {
      JourneyValidationResult result = getJourneyValidationFromGMS(accountNumber, cin, adboCaseDetails);
      response = result.response;
      adboCaseDetails = result.adboCaseDetails;
    }

    if (checkIfApplicationInProgressBeforeMiniSubmit(adboCaseDetails, response)) {
      changeResultToFailedDueToMainApplicantApplicationInProgress(response, adboCaseDetails);
    }
    if (response.getJourneyValidationResultCode().equals(JourneyValidationResultCode.PASS)) {
      return updateRouteTo(accountNumber, response, isStatusResetRequired);
    }
    return response;
  }

  private JourneyValidationApiResponse getJourneyValidationApiResponseForCinMisMatched(String cin,String accountNumber, JourneyValidationApiResponse response, AdboCaseDetails adboCaseDetails) {
    boolean cinMatched= adboCaseDetails.getAdboApplicants().values().stream().anyMatch(adboApplicant -> adboApplicant.getCin().equals(cin));
    if(!cinMatched ){
      return JourneyValidationApiResponse.builder()
                      .journeyValidationResultCode(JourneyValidationResultCode.FAILED)
                      .validationRuleResultCode(ValidationRuleResultCode.FAILED_DUE_TO_CIN_NOT_MATCHED)
                      .accountNumber(accountNumber).build();
    }
    return null;
  }

  private JourneyValidationResult getJourneyValidationFromGMS(String accountNumber, String cin, AdboCaseDetails adboCaseDetailsOld) {
    JourneyValidation journeyValidation = asyncDataLoader.getValidationData(accountNumber, cin);
    ValidationRuleResult result = journeyValidatorsWrapper.validate(journeyValidation);
    ValidationRuleResultCode resultCode = result.getCode();
    log.info("Validation rule result Code and journey validation code: {} and {}", resultCode,
        resultCode.getJourneyValidationResultCode());
    AdboCaseDetails adboCaseDetails = dataMapper.prepareCaseDetails(journeyValidation, accountNumber, cin);
    adboCaseDetails.setBrand(TenantProvider.getCurrentBrand().getName());
    adboCaseDetails.setHasSecondCharge(hasSecondCharge(journeyValidation, resultCode));
    if (nonNull(adboCaseDetails.getEligibilityBorrowing()) && isFalse(adboCaseDetails.getHasSecondCharge())) {
      adboCaseDetails.getEligibilityBorrowing().setSecondChargePayOff(null);
      adboCaseDetails.getEligibilityBorrowing().setSecondChargeDisclaimer(null);
    }
    adboCaseDetails.setValidationResult(resultCode.getJourneyValidationResultCode().toString());
    adboCaseDetails.setValidationRuleResultCode(resultCode.toString());
    adboCaseDetails.setEligibleToSwitch(isEligibleToSwitch(adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails()));
    resetSwitchDetailsIfEligibilityToSwitchIsFalse(adboCaseDetails);
    updateAdboCaseDetailsWithEarlierSelectedDetails(adboCaseDetails, adboCaseDetailsOld);
    if (resultCode.getJourneyValidationResultCode() != JourneyValidationResultCode.FAILED) {
      adboCaseDetailsDao.save(adboCaseDetails);
    }
    return new JourneyValidationResult(buildResponse(adboCaseDetails, result, cin), adboCaseDetails);
  }

  private void resetSwitchDetailsIfEligibilityToSwitchIsFalse(AdboCaseDetails adboCaseDetails) {

    if (isFalse(adboCaseDetails.getEligibleToSwitch())) {
      adboCaseDetails.setAdditionalBorrowingWithSwitch(null);
      adboCaseDetails.resetSwitchDetails();
    }
  }

  private Boolean isEligibleToSwitch(List<SubAccount> subAccounts) {

    return nonNull(subAccounts) && subAccounts.size() <= eligibleToSwitchMaxAllowedSubAccounts &&
        subAccounts.stream().anyMatch(s -> isTrue(s.getEligibleToSwitch()));
  }

  private void updateAdboCaseDetailsWithEarlierSelectedDetails(AdboCaseDetails latest, AdboCaseDetails existing) {
    if (isTrue(latest.getEligibleToSwitch()) && nonNull(existing)) {
      latest.getAdditionalBorrowingCalculator().getSubAccountDetails()
          .forEach(latestSubAccount -> existing.getAdditionalBorrowingCalculator().getSubAccountDetails()
              .stream()
              .filter(existingSubAccount -> latestSubAccount.getSubAccountNumber().equals(existingSubAccount.getSubAccountNumber())
                  && isTrue(latestSubAccount.getEligibleToSwitch()))
              .findAny().ifPresent(existingSubAccount -> latestSubAccount.setSelectedForSwitch(existingSubAccount.getSelectedForSwitch())));
    }
  }

  private JourneyValidationApiResponse buildResponse(AdboCaseDetails adboCaseDetails, ValidationRuleResult result, String cin) {
    List<Customer> customers = getCustomers(adboCaseDetails.getAdboApplicants(), result, cin);
    return JourneyValidationApiResponse.builder()
        .validationRuleResultCode(ValidationRuleResultCode.valueOf(adboCaseDetails.getValidationRuleResultCode()))
        .journeyValidationResultCode(JourneyValidationResultCode.valueOf(adboCaseDetails.getValidationResult()))
        .hasSecondCharge(adboCaseDetails.getHasSecondCharge())
        .customers(customers)
        .accountNumber(adboCaseDetails.getAccountNumber())
        .sysDate(nonNull(adboCaseDetails.getGmsSysDate()) ? adboCaseDetails.getGmsSysDate().toLocalDate() : LocalDate.now())
        .build();
  }

  private Boolean hasSecondCharge(JourneyValidation journeyValidation, ValidationRuleResultCode resultCode) {
    return resultCode.getJourneyValidationResultCode() == JourneyValidationResultCode.FAILED ? null
        : accountService.getSecondChargeDetails(journeyValidation.getAccountSummaryApiResponse());
  }

  private List<Customer> getCustomers(EnumMap<ApplicantType, AdboApplicant> applicants, ValidationRuleResult result,
      String cin) {
    return applicants.entrySet().stream().map(entry -> {
      AdboApplicant applicant = entry.getValue();
      return Customer.builder()
          .firstName(applicant.getPersonalDetails().getFirstName())
          .dateOfBirth(applicant.getPersonalDetails().getDateOfBirth())
          .applicantType(entry.getKey())
          .isLoggedInUser(cin.equals(applicant.getCin()))
          .hasKycPassed((result != null && result.getCode() == ValidationRuleResultCode.FAILED_DUE_TO_MARKER_KYC) ?
              result.getFailingCins().contains(applicant.getCin()) : null)
          .build();
    }).filter(Objects::nonNull).collect(toList());
  }

  private void updateStatus(AdboCaseDetails caseDetails) {
    caseDetails.setStatus(null);
    caseDetails.setModifiedDate(LocalDateTime.now());
    adboCaseDetailsDao.save(caseDetails);
  }

  private Boolean isStatusCapieUpdatedWithInInterval(AdboCaseDetails adboCaseDetails) {
    return Objects.equals(adboCaseDetails.getStatus(), CaseStatus.CAPIE_UPDATED) && isDateInRange(adboCaseDetails.getCaseCreationDate(),
        adboCaseDetails.getCaseCreationDate().plusDays(14));
  }

  private Boolean isStatusSubmitOrchestrationWithInInterval(AdboCaseDetails adboCaseDetails) {
    return Objects.equals(adboCaseDetails.getStatus(), CaseStatus.SUBMIT_ORCHESTRATION) && isDateInRange(adboCaseDetails.getModifiedDate(),
        adboCaseDetails.getModifiedDate().plusDays(14));
  }

  private JourneyValidationApiResponse updateRouteTo(String accountNumber, JourneyValidationApiResponse response,
      boolean isStatusResetRequired) {

    AdboCaseDetails caseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    for (Customer customer : response.getCustomers()) {
      if (customer.isLoggedInUser()) {
        ApplicantType applicantType = customer.getApplicantType();
        AdboApplicant applicant = caseDetails.getAdboApplicants().get(applicantType);

        if (caseDetails.getStatus() != null) {

          if (isStatusSubmitOrchestrationWithInInterval(caseDetails)) {
            response.setIsEligibleForStatusReset(true);
            if (applicant != null && applicant.getIsMarketingPreferenceUpdated() != null && applicant.getIsMarketingPreferenceUpdated()
                && caseDetails.getMortgageApplSeq() == null) {
              response.setNavigateTo(RouteTo.DASHBOARD_PAGE);
            } else {
              if (applicantType.equals(ApplicantType.MAIN)) {
                response.setNavigateTo(RouteTo.MARKETING_PREFERENCE_PAGE_MAIN);
              } else {
                //mini submit is not success and status is in SUBMIT_ORCHESTRATION, Main applicant still in progress
                changeResultToFailedDueToMainApplicantApplicationInProgress(response, caseDetails);
              }
            }
            if (isTrue(isStatusResetRequired)) {
              updateStatus(caseDetails);
            }
          }

          if (isStatusCapieUpdatedWithInInterval(caseDetails)) {
            response.setIsEligibleForStatusReset(true);
            if (applicant != null && applicant.getIsMarketingPreferenceUpdated() != null && applicant.getIsMarketingPreferenceUpdated()
                && caseDetails.getMortgageApplSeq() == null) {
              response.setNavigateTo(RouteTo.DASHBOARD_PAGE);
            } else {
              if (applicantType.equals(ApplicantType.MAIN)) {
                response.setNavigateTo(RouteTo.MARKETING_PREFERENCE_PAGE_MAIN);
              } else {
                response.setNavigateTo(RouteTo.JOINT_APPLICANT_LANDING_PAGE);
              }
            }
            if (isTrue(isStatusResetRequired)) {
              updateStatus(caseDetails);
            }
          }

          if (caseDetails.getStatus() == CaseStatus.SUBMIT_GMS_STAGE_20) {
            List<String> allowedStages = asList("80", "85", "90");
            GmsStatusResponse gmsResponse = apiService.getGmsApplicationStatus(caseDetails.getAccountNumber(), caseDetails
                .getMortgageApplSeq());
            if (allowedStages.contains(gmsResponse.getStageNo())) {
              caseDetails.setCreateNewRecord(Boolean.TRUE);
              adboCaseDetailsDao.save(caseDetails);
              return getJourneyValidationFromGMS(caseDetails.getAccountNumber(), applicant.getCin(), caseDetails).response;
            } else {
              response.setNavigateTo(RouteTo.DASHBOARD_PAGE);
            }
          } else if (caseDetails.getStatus() == CaseStatus.SUBMIT_GMS_MOPS) {
            response.setNavigateTo(RouteTo.DASHBOARD_PAGE);
          } else if (caseDetails.getStatus() == CaseStatus.HARDSCORE_DECLINED) {
            caseDetails.setCreateNewRecord(Boolean.TRUE);
            adboCaseDetailsDao.save(caseDetails);
            return getJourneyValidationFromGMS(caseDetails.getAccountNumber(), applicant.getCin(), caseDetails).response;
          } else if (caseDetails.getStatus() == CaseStatus.CONTRACT_VALIDATION_ERROR) {
            response.setNavigateTo(RouteTo.DASHBOARD_PAGE);
          }
        }
      }
    }
    return response;
  }

  @RequiredArgsConstructor
  private static class JourneyValidationResult {

    private final JourneyValidationApiResponse response;
    private final AdboCaseDetails adboCaseDetails;
  }

  private JourneyValidationApiResponse checkIfApplicationInFlightAfterMiniSubmit(String accountNumber,
      JourneyValidationApiResponse response) {

    boolean applicationInProgress  = true;
    ApplicationStatusResponse statusResponse = apiService.getApplicationStatusApi(accountNumber);
    for (ApplicationStatus appstatus : ApplicationStatus.values()) {
      if (appstatus.name().equalsIgnoreCase(statusResponse.getAppStatus())) {
        applicationInProgress = false;
      }
    }
    if (applicationInProgress) {
      response.setValidationRuleResultCode(ValidationRuleResultCode.FAILED_DUE_TO_INPROGRESS_APPLICATION_AFTER_MINI_SUBMIT);
      response.setJourneyValidationResultCode(JourneyValidationResultCode.FAILED);
    }
      return response;
  }
}