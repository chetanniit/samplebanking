package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PatchApplicant {

  private String op;
  private String path;
  private Object value;

}
