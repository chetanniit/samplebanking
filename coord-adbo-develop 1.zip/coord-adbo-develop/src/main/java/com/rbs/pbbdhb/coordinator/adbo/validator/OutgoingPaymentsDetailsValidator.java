package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.rbs.pbbdhb.coordinator.adbo.entity.*;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.List;

import static org.apache.commons.lang3.BooleanUtils.isTrue;

/**
 * OutgoingPaymentsDetailsValidator is used to validate the outgoing payment data while persisting in Mongodb
 */
@Component
public class OutgoingPaymentsDetailsValidator implements Validator {

  private final static String HAS_CHANGE_IN_CIRCUMSTANCES = "hasChangeInCircumstances";
  private final static String HAS_CHANGE_IN_CIRCUMSTANCES_MUST_FALSE = "hasChangeInCircumstances must be false";
  private static final String CREDIT_CARDS_NESTED_PATH = "creditCards";
  private static final String CREDIT_CARDS_NESTED_PATH_NOT_EMPTY = "creditCards must not be empty, If customer has a credit card";
  private static final String CLOSED_SQUARE_BRACE = "].";
  private static final String OPEN_SQUARE_BRACE = "[";
  private static final String LOANS_NESTED_PATH = "loans";
  private static final String LOANS_NESTED_PATH_NOT_EMPTY = "loans must not be empty, If customer has a loans";
  private static final String ADDITIONAL_PROPERTIES_NESTED_PATH = "additionalProperties";
  private static final String ADDITIONAL_PROPERTIES_NESTED_PATH_NOT_EMPTY = "additionalProperties must not be empty, If customer has a additional properties";
  private static final String FIXED_COMMITMENTS_NESTED_PATH = "fixedCommitments";
  private static final String FIXED_COMMITMENTS_NESTED_PATH_NOT_EMPTY = "fixedCommitments must not be empty, If customer has a fixed commitments";

  private final ValidateCreditCardDetails validateCreditCardDetails;
  private final ValidateLoanDetails validateLoanDetails;
  private final ValidateAdditionalPropertyDetails validateAdditionalPropertyDetails;
  private final ValidateFixedCommitmentDetails validateFixedCommitmentDetails;

  @Autowired
  public OutgoingPaymentsDetailsValidator(ValidateCreditCardDetails validateCreditCardDetails,
      ValidateLoanDetails validateLoanDetails,
      ValidateAdditionalPropertyDetails validateAdditionalPropertyDetails,
      ValidateFixedCommitmentDetails validateFixedCommitmentDetails) {
    this.validateCreditCardDetails = validateCreditCardDetails;
    this.validateLoanDetails = validateLoanDetails;
    this.validateAdditionalPropertyDetails = validateAdditionalPropertyDetails;
    this.validateFixedCommitmentDetails = validateFixedCommitmentDetails;
  }

  @Override
  public boolean supports(Class<?> clazz) {
    return OutgoingPaymentsDetails.class.isAssignableFrom(clazz);
  }

  @Override
  @SneakyThrows
  public void validate(Object target, Errors errors) {
    OutgoingPaymentsDetails outgoingPaymentsDetails = (OutgoingPaymentsDetails) target;
    if (isTrue(outgoingPaymentsDetails.getHasCreditCards())) {
      if (CollectionUtils.isEmpty(outgoingPaymentsDetails.getCreditCards())) {
        errors.rejectValue(CREDIT_CARDS_NESTED_PATH, "required", CREDIT_CARDS_NESTED_PATH_NOT_EMPTY);
        return;
      }
      validateCreditCards(outgoingPaymentsDetails.getCreditCards(), errors);
    }
    if (isTrue(outgoingPaymentsDetails.getHasLoans())) {
      if (CollectionUtils.isEmpty(outgoingPaymentsDetails.getLoans())) {
        errors.rejectValue(LOANS_NESTED_PATH, "required", LOANS_NESTED_PATH_NOT_EMPTY);
        return;
      }
      validateLoans(outgoingPaymentsDetails.getLoans(), errors);
    }
    if (isTrue(outgoingPaymentsDetails.getHasAdditionalProperties())) {
      if (CollectionUtils.isEmpty(outgoingPaymentsDetails.getAdditionalProperties())) {
        errors.rejectValue(ADDITIONAL_PROPERTIES_NESTED_PATH, "required", ADDITIONAL_PROPERTIES_NESTED_PATH_NOT_EMPTY);
        return;
      }
      validateAdditionalProperties(outgoingPaymentsDetails.getAdditionalProperties(), errors);
    }
    if (isTrue(outgoingPaymentsDetails.getHasFixedCommitments())) {
      if (CollectionUtils.isEmpty(outgoingPaymentsDetails.getFixedCommitments())) {
        errors.rejectValue(FIXED_COMMITMENTS_NESTED_PATH, "required", FIXED_COMMITMENTS_NESTED_PATH_NOT_EMPTY);
        return;
      }
      validateFixedCommitments(outgoingPaymentsDetails.getFixedCommitments(), errors);

    }
    if (isTrue(outgoingPaymentsDetails.getHasChangeInCircumstances())) {
      errors.rejectValue(HAS_CHANGE_IN_CIRCUMSTANCES, "required-false", HAS_CHANGE_IN_CIRCUMSTANCES_MUST_FALSE);
    }
  }

  private void validateCreditCards(final List<CreditCardDetails> creditCardDetailsList, final Errors errors) {
    int index = 0;
    for (CreditCardDetails creditCardDetails : creditCardDetailsList) {
      errors.pushNestedPath(constructPath(CREDIT_CARDS_NESTED_PATH.concat(OPEN_SQUARE_BRACE), index));
      ValidationUtils.invokeValidator(this.validateCreditCardDetails, creditCardDetails, errors);
      errors.popNestedPath();
      index++;
    }
  }

  private void validateFixedCommitments(final List<FixedCommitmentDetails> fixedCommitmentDetailsList, final Errors errors) {
    int index = 0;
    for (FixedCommitmentDetails fixedCommitmentDetails : fixedCommitmentDetailsList) {
      errors.pushNestedPath(constructPath(FIXED_COMMITMENTS_NESTED_PATH.concat(OPEN_SQUARE_BRACE), index));
      ValidationUtils.invokeValidator(this.validateFixedCommitmentDetails, fixedCommitmentDetails, errors);
      errors.popNestedPath();
      index++;
    }
  }

  private void validateAdditionalProperties(final List<AdditionalPropertyDetails> additionalPropertyDetailsList, final Errors errors) {
    int index = 0;
    for (AdditionalPropertyDetails additionalPropertyDetails : additionalPropertyDetailsList) {
      errors.pushNestedPath(constructPath(ADDITIONAL_PROPERTIES_NESTED_PATH.concat(OPEN_SQUARE_BRACE), index));
      ValidationUtils.invokeValidator(this.validateAdditionalPropertyDetails, additionalPropertyDetails, errors);
      errors.popNestedPath();
      index++;
    }
  }

  private void validateLoans(final List<LoanDetails> loans, final Errors errors) {
    int index = 0;
    for (LoanDetails loan : loans) {
      errors.pushNestedPath(constructPath(LOANS_NESTED_PATH.concat(OPEN_SQUARE_BRACE), index));
      ValidationUtils.invokeValidator(this.validateLoanDetails, loan, errors);
      errors.popNestedPath();
      index++;
    }
  }

  private String constructPath(String nestedPath, int index) {
    return new StringBuffer().append(nestedPath).append(index).append(CLOSED_SQUARE_BRACE).toString();
  }
}
