package com.rbs.pbbdhb.coordinator.adbo.response;

import com.rbs.pbbdhb.coordinator.adbo.enums.PropertyTenure;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class AdboCalculator {

  private List<SubAccount> subAccounts;
  private String propertyType;
  private String propertyBuiltType;
  private PropertyTenure propertyTenure;
  private BigDecimal totalTrueBalance;
  private BigDecimal hpiValuation;
  private BigDecimal minBorrowing;
  private BigDecimal maxBorrowing;
  private BigDecimal estimatedPropertyValue;
  private Boolean isPropertyModified;
  private Integer retirementAge;
  private Integer jointApplicantRetirementAge;
  private Integer borrowingAmount;
  private Integer repaymentTermYears;
  private Integer repaymentTermMonths;
  private BigDecimal loanToValue;
}
