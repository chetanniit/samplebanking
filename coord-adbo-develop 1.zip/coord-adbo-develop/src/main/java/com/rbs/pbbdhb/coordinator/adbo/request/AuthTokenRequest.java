package com.rbs.pbbdhb.coordinator.adbo.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthTokenRequest {

  private String applicantId;
  private String caseId;
  private String cin;
  private String loanPurpose;
  private String applicationType;

}
