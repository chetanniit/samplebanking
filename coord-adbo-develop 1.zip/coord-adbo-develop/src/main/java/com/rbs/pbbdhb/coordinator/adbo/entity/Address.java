package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.rbs.pbbdhb.coordinator.adbo.enums.OccupancyStatus;
import java.util.Objects;
import java.util.stream.Stream;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class Address  {

  private String flatNumber;

  private String propertyName;

  private String propertyNumber;
  @NotNull(message = "street cannot be null")
  private String street;
  @NotNull(message = "town cannot be null")
  private String town;
  private String county;
  @NotNull(message = "country cannot be null")
  private String country;
  private String countryIsoCode;
  @Size(max = 12, message = "postcode length must not be greater than 12 characters")
  private String postcode;
  @NotNull(message = "occupancy cannot be null")
  private OccupancyStatus occupancy;
  @NotNull(message = "moveInMonth cannot be null")
  @Min(value = 1, message = "moveInMonth must be between 1 and 12")
  @Max(value = 12, message = "moveInMonth must be between 1 and 12")
  private Integer moveInMonth;
  @NotNull(message = "moveInYear cannot be null")
  private Integer moveInYear;

  @AssertTrue(message = "Either flatNumber, propertyName or propertyNumber is mandatory")
  public boolean isNameOrNumberSet() {
    return Stream.of(flatNumber, propertyName, propertyNumber).anyMatch(Objects::nonNull);
  }
}
