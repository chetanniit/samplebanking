package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CustomerAgeValidator extends AbstractValidator {

  @Value("${adbo.age.allowed}")
  private int ageAllowed;

  public CustomerAgeValidator(@Value("${journeyValidator.priority.customerAge}") int priority) {
    super(priority, ValidationRuleResultCode.FAILED_DUE_TO_CUSTOMER_AGE);
  }

  public static long calcAge(LocalDateTime sysDate, LocalDate dateOfBirth) {
    return ChronoUnit.YEARS.between(dateOfBirth, sysDate);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return journeyValidation.getCustomerSummaryApiResponses().stream()
        .anyMatch(customerSummaryApiResponse -> {
              LocalDate dateOfBirth = LocalDate.parse(customerSummaryApiResponse.getDateOfBirth());
              LocalDateTime sysDate = journeyValidation.getAccountSummaryApiResponse().getSysDate();
              if (dateOfBirth != null && sysDate != null) {
                long age = calcAge(sysDate, dateOfBirth);
                return age >= ageAllowed;
              }
              return false;
            }
        );
  }
}
