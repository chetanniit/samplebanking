package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingsOwnerType.JOINT1;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.getRoundUpAverageAmount;
import static java.util.Objects.nonNull;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdditionalPropertyDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.ChildCareExpenseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.CreditCardDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.DependentExpenseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.FixedCommitmentDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.LoanDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.NewAdditionalProperty;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingsOwnerType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.service.OutgoingPaymentsService;
import com.rbs.pbbdhb.coordinator.adbo.validator.DependentsValidator;
import com.rbs.pbbdhb.coordinator.adbo.validator.PensionContributionValidator;
import com.rbs.pbbdhb.coordinator.adbo.validator.PropertyPurchaseValidator;
import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class OutgoingPaymentsServiceImpl implements OutgoingPaymentsService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final PropertyPurchaseValidator propertyPurchaseValidator;
  private final DependentsValidator dependentsValidator;
  private final PensionContributionValidator pensionContributionValidator;

  /**
   * This method is useful to save the outgoing payments details in the mongodb.
   *
   * @param accountNumber           is number unique customer identity number
   * @param outgoingPaymentsDetails object has all the outgoing payments details
   */
  @Override
  public void saveOutgoingPayments(String accountNumber, OutgoingPaymentsDetails outgoingPaymentsDetails) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    separateOutgoingsBasedOnApplicantType(outgoingPaymentsDetails, adboCaseDetails);
    adboCaseDetails.getAdboApplicants().forEach((applicantType, adboApplicant) -> {
      dependentsValidator.validateChildcareOrDependentExpenses(adboCaseDetails.getAdboApplicants(),
          adboApplicant.getOutgoingPaymentsDetails());
      propertyPurchaseValidator.validatePropertyPurchase(adboCaseDetails.getAdditionalBorrowingCalculator().getAdboAmountDistributions(),
          adboApplicant.getOutgoingPaymentsDetails());
      pensionContributionValidator.validatePensionContribution(applicantType, adboCaseDetails,
          getPensionContribution(adboApplicant.getOutgoingPaymentsDetails()));
      propertyPurchaseValidator.validateNewAdditionalProperty(adboApplicant.getOutgoingPaymentsDetails());
    });
    adboCaseDetailsDao.save(adboCaseDetails);
    log.info("Outgoing payment details have been saved/updated successfully, accountNumber {}", accountNumber);
  }

  /**
   * getOutgoingDetails method will retrieve outgoing payments details from the mongodb. maximum
   *
   * @param accountNumber is number unique customer identity number
   * @return This method return OutgoingDetails which has outgoing payment details.
   */
  @Override
  public OutgoingPaymentsDetails getOutgoingPayments(String accountNumber) {
    log.info("Retrieve outgoing payment details retrieve is started");
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    return getApplicantsOutgoings(adboCaseDetails);
  }

  private void separateOutgoingsBasedOnApplicantType(OutgoingPaymentsDetails outgoingPaymentsDetails, AdboCaseDetails adboCaseDetails) {
    EnumMap<ApplicantType, AdboApplicant> adboApplicants = adboCaseDetails.getAdboApplicants();
    if (adboApplicants.containsKey(ApplicantType.MAIN)) {
      buildMainOutgoingsPayments(outgoingPaymentsDetails, adboApplicants);
    }
    if (adboApplicants.containsKey(ApplicantType.JOINT1)) {
      buildJoint1OutgoingsPayments(outgoingPaymentsDetails, adboApplicants);
    }
  }

  private void buildMainOutgoingsPayments(OutgoingPaymentsDetails outgoingPayments,
      EnumMap<ApplicantType, AdboApplicant> adboApplicants) {
    OutgoingPaymentsDetails mainOutgoingPayments = new OutgoingPaymentsDetails();
    if (!CollectionUtils.isEmpty(outgoingPayments.getAdditionalProperties())) {
      mainOutgoingPayments.setAdditionalProperties(outgoingPayments.getAdditionalProperties().stream()
          .filter(additionalPropertyDetails -> !Objects.equals(JOINT1, additionalPropertyDetails.getOwner())).collect(Collectors.toList()));
      mainOutgoingPayments.getAdditionalProperties().stream().forEach(additionalPropertyDetails -> {
        if (Boolean.FALSE.equals(additionalPropertyDetails.getHasRunningCosts())) {
          additionalPropertyDetails.setApplicantShareOnMonthlyRunningCostsPayment(null);
        }
        if(Boolean.FALSE.equals(additionalPropertyDetails.getHasMortgageOnThisProperty())){
          additionalPropertyDetails.setApplicantShareOnMonthlyMortgagePayment(null);
        }

      });
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getCreditCards())) {
      mainOutgoingPayments.setCreditCards(outgoingPayments.getCreditCards().stream()
          .filter(creditCard -> !Objects.equals(JOINT1, creditCard.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getLoans())) {
      mainOutgoingPayments.setLoans(outgoingPayments.getLoans().stream()
          .filter(loan -> !Objects.equals(JOINT1, loan.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getDependentExpenses())) {
      mainOutgoingPayments.setDependentExpenses(outgoingPayments.getDependentExpenses().stream()
          .filter(dependentExpense -> !Objects.equals(OutgoingsOwnerType.JOINT1, dependentExpense.getOwner()))
          .collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getChildcareExpenses())) {
      mainOutgoingPayments.setChildcareExpenses(outgoingPayments.getChildcareExpenses().stream()
          .filter(childCareExpense -> !Objects.equals(JOINT1, childCareExpense.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getFixedCommitments())) {
      mainOutgoingPayments.setFixedCommitments(outgoingPayments.getFixedCommitments().stream()
          .filter(fixedCommitment -> !Objects.equals(JOINT1, fixedCommitment.getOwner())).collect(Collectors.toList()));
    }
    mainOutgoingPayments.setMonthlyPensionContribution(outgoingPayments.getMonthlyPensionContribution());
    mainOutgoingPayments.setJointApplicantMonthlyPensionContribution(outgoingPayments.getMonthlyPensionContribution());
    mapOutgoingDecisions(outgoingPayments, mainOutgoingPayments);
    mapNewAdditionalPropertiesAmount(adboApplicants, outgoingPayments, mainOutgoingPayments);
    adboApplicants.get(ApplicantType.MAIN).setOutgoingPaymentsDetails(mainOutgoingPayments);
  }

  private void mapNewAdditionalPropertiesAmount(EnumMap<ApplicantType, AdboApplicant> adboApplicants,
      OutgoingPaymentsDetails outgoingPayments,
      OutgoingPaymentsDetails output) {
    NewAdditionalProperty newAdditionalProperty = null;
    if (nonNull(outgoingPayments.getNewAdditionalProperty())) {
      newAdditionalProperty = new NewAdditionalProperty();
      if (nonNull(outgoingPayments.getNewAdditionalProperty().getBuyTOLetShortFallAmount())) {
        newAdditionalProperty.setBuyTOLetShortFallAmount(outgoingPayments.getNewAdditionalProperty().getBuyTOLetShortFallAmount());
        newAdditionalProperty.setApplicantShareOnBuyTOLetShortFallAmount(
            outgoingPayments.getNewAdditionalProperty().getBuyTOLetShortFallAmount());
        if (adboApplicants.containsKey(ApplicantType.JOINT1)) {
          newAdditionalProperty.setApplicantShareOnBuyTOLetShortFallAmount(
              getRoundUpAverageAmount(outgoingPayments.getNewAdditionalProperty().getBuyTOLetShortFallAmount()));
        }
      }
      if (nonNull(outgoingPayments.getNewAdditionalProperty().getNewMortgageMonthlyPayment())) {
        newAdditionalProperty.setNewMortgageMonthlyPayment(outgoingPayments.getNewAdditionalProperty().getNewMortgageMonthlyPayment());
        newAdditionalProperty.setApplicantShareOnNewMortgageMonthlyPayment(
            outgoingPayments.getNewAdditionalProperty().getNewMortgageMonthlyPayment());
        if (adboApplicants.containsKey(ApplicantType.JOINT1)) {
          newAdditionalProperty.setApplicantShareOnNewMortgageMonthlyPayment(
              getRoundUpAverageAmount(outgoingPayments.getNewAdditionalProperty().getNewMortgageMonthlyPayment()));
        }
      }
      if (nonNull(outgoingPayments.getNewAdditionalProperty().getMonthlyRunningCostPayment())) {
        newAdditionalProperty.setIsLetToFamilyMember(outgoingPayments.getNewAdditionalProperty().getIsLetToFamilyMember());
        newAdditionalProperty.setMonthlyRunningCostPayment(outgoingPayments.getNewAdditionalProperty().getMonthlyRunningCostPayment());
        newAdditionalProperty.setApplicantShareOnMonthlyRunningCostPayment(
            outgoingPayments.getNewAdditionalProperty().getMonthlyRunningCostPayment());
        if (adboApplicants.containsKey(ApplicantType.JOINT1)) {
          newAdditionalProperty.setApplicantShareOnMonthlyRunningCostPayment(
              getRoundUpAverageAmount(outgoingPayments.getNewAdditionalProperty().getMonthlyRunningCostPayment()));
        }
      }
    }
    output.setNewAdditionalProperty(newAdditionalProperty);
    output.setMonthlyLivingElseWhereAmount(outgoingPayments.getMonthlyLivingElseWhereAmount());
    output.setApplicantShareOnMonthlyLivingElseWhereAmount(outgoingPayments.getMonthlyLivingElseWhereAmount());
    if (adboApplicants.containsKey(ApplicantType.JOINT1)) {
      if (nonNull(outgoingPayments.getMonthlyLivingElseWhereAmount())) {
        output.setApplicantShareOnMonthlyLivingElseWhereAmount(
            getRoundUpAverageAmount(outgoingPayments.getMonthlyLivingElseWhereAmount()));
      }

    }
  }

  private BigDecimal getPensionContribution(OutgoingPaymentsDetails outgoingPaymentsDetails) {
    return nonNull(outgoingPaymentsDetails.getMonthlyPensionContribution())
        ? outgoingPaymentsDetails.getMonthlyPensionContribution() : outgoingPaymentsDetails.getJointApplicantMonthlyPensionContribution();
  }

  private void buildJoint1OutgoingsPayments(OutgoingPaymentsDetails outgoingPayments,
      EnumMap<ApplicantType, AdboApplicant> adboApplicants) {
    OutgoingPaymentsDetails jointOutgoingPayments = new OutgoingPaymentsDetails();
    if (!CollectionUtils.isEmpty(outgoingPayments.getAdditionalProperties())) {
      jointOutgoingPayments.setAdditionalProperties(outgoingPayments.getAdditionalProperties().stream()
          .filter(additionalPropertyDetails -> !Objects.equals(OutgoingsOwnerType.MAIN, additionalPropertyDetails.getOwner()))
          .collect(Collectors.toList()));
      jointOutgoingPayments.getAdditionalProperties().stream().forEach(additionalPropertyDetails -> {
        if (Boolean.FALSE.equals(additionalPropertyDetails.getHasRunningCosts())) {
          additionalPropertyDetails.setApplicantShareOnMonthlyRunningCostsPayment(null);
        }
        if(Boolean.FALSE.equals(additionalPropertyDetails.getHasMortgageOnThisProperty())){
          additionalPropertyDetails.setApplicantShareOnMonthlyMortgagePayment(null);
        }
      });
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getCreditCards())) {
      jointOutgoingPayments.setCreditCards(outgoingPayments.getCreditCards().stream()
          .filter(creditCard -> !Objects.equals(OutgoingsOwnerType.MAIN, creditCard.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getLoans())) {
      jointOutgoingPayments.setLoans(outgoingPayments.getLoans().stream()
          .filter(loan -> !Objects.equals(OutgoingsOwnerType.MAIN, loan.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getDependentExpenses())) {
      jointOutgoingPayments.setDependentExpenses(outgoingPayments.getDependentExpenses().stream()
          .filter(dependentExpense -> !Objects.equals(OutgoingsOwnerType.MAIN, dependentExpense.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getChildcareExpenses())) {
      jointOutgoingPayments.setChildcareExpenses(outgoingPayments.getChildcareExpenses().stream()
          .filter(childCareExpense -> !Objects.equals(OutgoingsOwnerType.MAIN, childCareExpense.getOwner())).collect(Collectors.toList()));
    }
    if (!CollectionUtils.isEmpty(outgoingPayments.getFixedCommitments())) {
      jointOutgoingPayments.setFixedCommitments(outgoingPayments.getFixedCommitments().stream()
          .filter(fixedCommitment -> !Objects.equals(OutgoingsOwnerType.MAIN, fixedCommitment.getOwner())).collect(Collectors.toList()));
    }
    jointOutgoingPayments.setJointApplicantMonthlyPensionContribution(outgoingPayments.getJointApplicantMonthlyPensionContribution());
    jointOutgoingPayments.setMonthlyPensionContribution(outgoingPayments.getJointApplicantMonthlyPensionContribution());
    mapOutgoingDecisions(outgoingPayments, jointOutgoingPayments);
    mapNewAdditionalPropertiesAmount(adboApplicants, outgoingPayments, jointOutgoingPayments);
    adboApplicants.get(ApplicantType.JOINT1).setOutgoingPaymentsDetails(jointOutgoingPayments);
  }

  private void mapOutgoingDecisions(OutgoingPaymentsDetails input, OutgoingPaymentsDetails output) {
    output.setHasCreditCards(input.getHasCreditCards());
    output.setHasLoans(input.getHasLoans());
    output.setHasAdditionalProperties(input.getHasAdditionalProperties());
    output.setHasFixedCommitments(input.getHasFixedCommitments());
    output.setHasChildcareExpenses(input.getHasChildcareExpenses());
    output.setHasDependentExpenses(input.getHasDependentExpenses());
    output.setHasChangeInCircumstances(input.getHasChangeInCircumstances());
  }

  private OutgoingPaymentsDetails getApplicantsOutgoings(AdboCaseDetails adboCaseDetails) {
    AdboApplicant adboApplicant = adboCaseDetails.getAdboApplicants().get(ApplicantType.MAIN);
    OutgoingPaymentsDetails outgoingPaymentsDetails = adboApplicant.getOutgoingPaymentsDetails();
    if (nonNull(outgoingPaymentsDetails)) {
      if (adboCaseDetails.getAdboApplicants().containsKey(ApplicantType.JOINT1)) {
        aggregateOutgoings(adboCaseDetails.getAdboApplicants().get(ApplicantType.JOINT1).getOutgoingPaymentsDetails(),
            outgoingPaymentsDetails);
      } else {
        outgoingPaymentsDetails.setJointApplicantMonthlyPensionContribution(null);
      }
    }
    return outgoingPaymentsDetails;
  }

  private void aggregateOutgoings(OutgoingPaymentsDetails joint1Outgoings, OutgoingPaymentsDetails outgoingPaymentsDetails) {
    if (!CollectionUtils.isEmpty(joint1Outgoings.getCreditCards())) {
      List<CreditCardDetails> joint1CreditCards = joint1Outgoings.getCreditCards().stream()
          .filter(creditCard -> !Objects.equals(creditCard.getOwner(), OutgoingsOwnerType.BOTH)).collect(
              Collectors.toList());
      if (!CollectionUtils.isEmpty(joint1CreditCards)) {
        outgoingPaymentsDetails.getCreditCards().addAll(joint1CreditCards);
      }
    }
    if (!CollectionUtils.isEmpty(joint1Outgoings.getLoans())) {
      List<LoanDetails> loanDetails = joint1Outgoings.getLoans().stream()
          .filter(loan -> !Objects.equals(loan.getOwner(), OutgoingsOwnerType.BOTH)).collect(
              Collectors.toList());
      if (!CollectionUtils.isEmpty(loanDetails)) {
        outgoingPaymentsDetails.getLoans().addAll(loanDetails);
      }
    }
    if (!CollectionUtils.isEmpty(joint1Outgoings.getAdditionalProperties())) {
      List<AdditionalPropertyDetails> joint1AdditionalProperties = joint1Outgoings.getAdditionalProperties().stream()
          .filter(additionalProperty -> !Objects.equals(additionalProperty.getOwner(), OutgoingsOwnerType.BOTH)).collect(
              Collectors.toList());
      if (!CollectionUtils.isEmpty(joint1AdditionalProperties)) {
        outgoingPaymentsDetails.getAdditionalProperties().addAll(joint1AdditionalProperties);
      }
    }
    if (!CollectionUtils.isEmpty(joint1Outgoings.getFixedCommitments())) {
      List<FixedCommitmentDetails> joint1FixedCommitments = joint1Outgoings.getFixedCommitments().stream()
          .filter(fixedCommitment -> !Objects.equals(fixedCommitment.getOwner(), OutgoingsOwnerType.BOTH)).collect(
              Collectors.toList());
      if (!CollectionUtils.isEmpty(joint1FixedCommitments)) {
        outgoingPaymentsDetails.getFixedCommitments().addAll(joint1FixedCommitments);
      }
    }
    if (!CollectionUtils.isEmpty(joint1Outgoings.getChildcareExpenses())) {
      List<ChildCareExpenseDetails> joint1ChildCare = joint1Outgoings.getChildcareExpenses().stream()
          .filter(childCareExpense -> !Objects.equals(childCareExpense.getOwner(), OutgoingsOwnerType.BOTH)).collect(
              Collectors.toList());
      outgoingPaymentsDetails.getChildcareExpenses().addAll(joint1ChildCare);
    }
    if (!CollectionUtils.isEmpty(joint1Outgoings.getDependentExpenses())) {
      List<DependentExpenseDetails> joint1DependentExpense = joint1Outgoings.getDependentExpenses().stream()
          .filter(dependentExpense -> !Objects.equals(dependentExpense.getOwner(), OutgoingsOwnerType.BOTH)).collect(
              Collectors.toList());
      outgoingPaymentsDetails.getDependentExpenses().addAll(joint1DependentExpense);
    }
    outgoingPaymentsDetails.setJointApplicantMonthlyPensionContribution(joint1Outgoings.getJointApplicantMonthlyPensionContribution());
  }
}
