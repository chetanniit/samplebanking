package com.rbs.pbbdhb.coordinator.adbo.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Data
public class ReadyToStartRequest  {

  @NotNull(message = "Please read 5 Fraud warnings before proceeding")
  @AssertTrue(message = "Please Acknowledge that you have read 5 Fraud warnings before proceeding")
  private Boolean hasAcknowledgedFraudWarning;

  @Schema(example = "true", required = true)
  @NotNull(message = "selfServiceLossOfProtection must not be null, Should be true ")
  @AssertTrue(message = "Please Acknowledge that you have read Self Service loss of Protection document before proceeding")
  private Boolean selfServiceLossOfProtectionDocument;

  @Schema(example = "true", required = true)
  @NotNull(message = "importantInformationAboutUs must not be null, Should be true")
  @AssertTrue(message = "Please Acknowledge that you have read about our Important Information about us before proceeding")
  private Boolean importantInformationAboutUs;
}
