package com.rbs.pbbdhb.coordinator.adbo.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.MortgageQuoteControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.MortgageQuoteRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.MortgageQuoteResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.MortgageQuoteService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
@RequestMapping("/mortgage-quote")
public class MortgageQuoteController implements MortgageQuoteControllerSwagger {

  private final MortgageQuoteService mortgageQuoteService;

  @Override
  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MortgageQuoteResponse> getMortgageQuoteDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getMortgageQuoteDetails - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    MortgageQuoteResponse response = mortgageQuoteService.getMortgageQuoteDetails(accountNumber);
    log.info("getMortgageQuoteDetails end's with response {}, account_number: {}, brand: {}, channel: {}",
        response, accountNumber, brand, channelRoute);
    return ResponseEntity.ok(response);
  }

  @Override
  @PostMapping(value = "/save", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveMortgageQuoteDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid MortgageQuoteRequest mortgageQuoteRequest) {
    log.info("saveMortgageQuoteDetails - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    mortgageQuoteService.saveMortgageQuoteDetails(accountNumber, mortgageQuoteRequest);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
