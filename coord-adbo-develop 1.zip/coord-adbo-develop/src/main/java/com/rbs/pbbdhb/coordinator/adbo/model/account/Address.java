package com.rbs.pbbdhb.coordinator.adbo.model.account;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Address {

  private String propAddressNo;
  private String addressNo;
  private String address1;
  private String address2;
  private String address3;
  private String address4;
  private String address5;
  private String postcode;
  private String foreignAddrInd;

}
