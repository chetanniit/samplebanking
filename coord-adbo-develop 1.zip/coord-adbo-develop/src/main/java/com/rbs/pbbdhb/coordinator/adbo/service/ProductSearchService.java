package com.rbs.pbbdhb.coordinator.adbo.service;

import java.util.List;

import jakarta.validation.Valid;

import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchResponse;

public interface ProductSearchService {

  ProductSearchResponse getProducts(String accountNumber,String brand);

  void saveProductDetails(String accountNumber, @Valid List<Product> productDetails);
}
