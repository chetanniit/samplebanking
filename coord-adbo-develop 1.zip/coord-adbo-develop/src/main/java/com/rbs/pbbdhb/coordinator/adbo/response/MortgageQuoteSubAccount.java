package com.rbs.pbbdhb.coordinator.adbo.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.enums.InterestType;
import com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType;
import com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
public class MortgageQuoteSubAccount {

  private Integer sequenceNumber;
  private Integer subAccountNumber;
  private Boolean selectedForSwitch;
  private InterestType interestType;
  private BigDecimal interestRate;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN)
  private LocalDate currentDealEnds;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN)
  private LocalDate newDealEnds;
  private RepaymentType repaymentType;
  private BigDecimal monthlyPayment;
  private BigDecimal newMonthlyPayment;
  private TimePeriod remainingTerm;
  private BigDecimal currentBalance;
  private Integer productTerm;
  private NewDealStartDateType newDealStartDateType;
  private Boolean switchImmediately;
}
