package com.rbs.pbbdhb.coordinator.adbo.dto;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_PATTERN;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_TIME_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SalesIllustrationDto {

  private boolean isAccepted;

  @JsonFormat(pattern = DATE_PATTERN)
  private LocalDate selectionDate;

  private String documentUrl;

  @JsonFormat(pattern = DATE_TIME_PATTERN)
  private LocalDateTime lastUpdated;

  private List<ProductDto> products;

}