package com.rbs.pbbdhb.coordinator.adbo.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidateAccountRequest {

  @Pattern(regexp = "^[0-9]{6}$", message = "sort code must be 6 digits")
  @NotNull(message = "sortCode cannot be null or empty")
  @Schema(example = "603015", description = "sort code should be 6 digit numeric")
  private String sortCode;

  @Pattern(regexp = "^[0-9]{8}$", message = "account number must be 8 digits")
  @NotNull(message = "accountNumber cannot be null or empty")
  @Schema(example = "12603015", description = "account number should be 8 digit numeric")
  private String accountNumber;

}