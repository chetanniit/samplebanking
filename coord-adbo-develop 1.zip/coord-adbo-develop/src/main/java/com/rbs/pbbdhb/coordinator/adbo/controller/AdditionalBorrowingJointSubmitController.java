package com.rbs.pbbdhb.coordinator.adbo.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.AdditionalBorrowingJointSubmitControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingJointSubmitRequest;
import com.rbs.pbbdhb.coordinator.adbo.service.AdditionalBorrowingJointSubmitService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;


@Validated
@RestController
@Slf4j
@RequiredArgsConstructor
public class AdditionalBorrowingJointSubmitController implements AdditionalBorrowingJointSubmitControllerSwagger {


  private final AdditionalBorrowingJointSubmitService additionalBorrowingJointSubmitService;

  @PostMapping(value = "/additional-borrow-joint-submit", consumes = APPLICATION_JSON_VALUE)
  @Override
  public ResponseEntity<Void> saveAdditionalBorrowingJointSubmit(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.CIN) @CIN String customerId,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest) {
    log.info("saveAdditionalBorrowingJointSubmit start-Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand,
        channelRoute, additionalBorrowingJointSubmitRequest);
    TenantProvider.applyBrand(brand);
    additionalBorrowingJointSubmitService.saveAdditionalBorrowingJointSubmit(accountNumber, customerId,
        additionalBorrowingJointSubmitRequest);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info(
        "saveAdditionalBorrowingJointSubmit end's with response {}, account_number: {} brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }
}
