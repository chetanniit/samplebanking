package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.ADDITIONAL_BORROWING_ESIS_DOCUMENT_NOT_RECEIVED;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.APPLICATION_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CALCULATION_INTEREST_ONLY;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CALCULATION_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHANNEL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.ESIS_MORTGAGE_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.LEVEL_OF_SERVICE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.LOAN_PURPOSE_ADDITIONAL_BORROWING;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.LOAN_PURPOSE_PRODUCT_SWITCH;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.PRODUCT_FIELD_NOT_FOUND;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.PRODUCT_SWITCH_ESIS_DOCUMENT_CAN_NOT_GENERATE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.PRODUCT_SWITCH_ESIS_DOCUMENT_NOT_RECEIVED;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.REPAYMENT_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.enums.CaseStatus.SUBMIT_GMS_STAGE_20;
import static com.rbs.pbbdhb.coordinator.adbo.enums.InterestType.FIXED;
import static com.rbs.pbbdhb.coordinator.adbo.enums.InterestType.fromValue;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ProductTermEnum.getProductTerm;
import static com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType.CAPITAL_AND_INTEREST;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.BooleanUtils.isNotTrue;
import static org.springframework.util.ObjectUtils.isEmpty;

import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.rbs.pbbdhb.coordinator.adbo.util.AdboFeePaymentActionCheck;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.server.ResponseStatusException;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.enums.FeeAction;
import com.rbs.pbbdhb.coordinator.adbo.enums.InterestType;
import com.rbs.pbbdhb.coordinator.adbo.model.DocumentPaymentFlagsResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;
import com.rbs.pbbdhb.coordinator.adbo.model.product.EarlyRepaymentCharge;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.Applicants;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISApplication.ESISApplicationBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISDocument;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ErcItem;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ErcItem.ErcItemBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.Mortgage;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.Mortgage.MortgageBuilder;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.SalesEsisProduct;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.SalesEsisProduct.SalesEsisProductBuilder;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.ESISDocumentService;
import com.rbs.pbbdhb.coordinator.adbo.util.SubAccountsSelectionForSwitching;
import com.rbs.pbbdhb.exception.BusinessException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class EsisDocumentServiceImpl implements ESISDocumentService {


  private final ApiService apiService;
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final AdboFeePaymentActionCheck adboFeePaymentActionCheck;
  @Value("${fixedProduct.baseRatePercentage}")
  private BigDecimal fixedProductBaseRatePercentage;
  @Value("${trackerProduct.baseRatePercentage}")
  private BigDecimal trackerProductBaseRatePercentage;
  
  @Override
  public ESISDocument generateSalesEsisRequestForAdditionalBorrowing(String accountNumber) {
    log.info("Entering generateSalesEsisRequestForAdditionalBorrowing for {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    ESISApplication application = mapToEsisApplication(adboCaseDetails, LOAN_PURPOSE_ADDITIONAL_BORROWING);
    log.info("Additional_Borrowing ESISApplication request for accountNumber {}, request {}", accountNumber, application);
    ESISDocument response = apiService.getESISDocument(application);
    if (!response.hasBody()) {
      log.error("Additional borrowing ESIS document not received from the producer for given account_number: {}, hasBody: {}",
          accountNumber, response.hasBody());
      throw new BusinessException(ADDITIONAL_BORROWING_ESIS_DOCUMENT_NOT_RECEIVED, HttpStatus.NOT_FOUND.value());
    }
    adboCaseDetails.getSalesIllustration().setDocumentUrl(response.getUrl());
    saveAdboCaseDetailsWithSalesIllustration(adboCaseDetails);
    log.info("Exiting generateSalesEsisRequestForAdditionalBorrowing for {}", accountNumber);
    return response;

  }

  @Override
  public ESISDocument generateSalesEsisRequestForProductSwitch(String accountNumber) {
    log.info("Entering generateSalesEsisRequestForProductSwitch for {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    if (BooleanUtils.isNotTrue(adboCaseDetails.getAdditionalBorrowingWithSwitch())) {
      log.error("Product switch ESIS document can't be generated for given account_number: {}, additionalBorrowingWithSwitch: {}",
          accountNumber, adboCaseDetails.getAdditionalBorrowingWithSwitch());
      throw new BusinessException(PRODUCT_SWITCH_ESIS_DOCUMENT_CAN_NOT_GENERATE, HttpStatus.BAD_REQUEST.value());
    }
    ESISApplication application = mapToEsisApplicationForProductSwitch(adboCaseDetails, LOAN_PURPOSE_PRODUCT_SWITCH);
    log.info("PRODUCT_SWITCH ESISApplication request for accountNumber {}, request {}", accountNumber, application);
    ESISDocument response = apiService.getESISDocument(application);
    if (!response.hasBody()) {
      log.error(
          "Product switch ESIS document not received from the producer for given account_number: {}, hasBody: {} ,additionalBorrowingWithSwitch: {}",
          accountNumber, response.hasBody(), adboCaseDetails.getAdditionalBorrowingWithSwitch());
      throw new BusinessException(PRODUCT_SWITCH_ESIS_DOCUMENT_NOT_RECEIVED, HttpStatus.NOT_FOUND.value());
    }
    adboCaseDetails.getSalesIllustration().setProductSwitchDocumentUrl(response.getUrl());
    saveAdboCaseDetailsWithSalesIllustration(adboCaseDetails);
    log.info("Exiting generateSalesEsisRequestForProductSwitch for {}", accountNumber);
    return response;

  }

  void saveAdboCaseDetailsWithSalesIllustration(AdboCaseDetails adboCaseDetails) {
    log.info("Entered into save SalesIllustration Service {}", adboCaseDetails.getAccountNumber());
    adboCaseDetails.getSalesIllustration().setLastUpdated(LocalDateTime.now(ZoneId.of("GMT")));
    adboCaseDetailsDao.save(adboCaseDetails);
    log.info("Exiting Save SalesIllustration Service {}", adboCaseDetails.getAccountNumber());
  }

  ESISApplication mapToEsisApplication(AdboCaseDetails adboCaseDetails, String loanPurpose) {
    return buildESISApplicationBuilder(adboCaseDetails, loanPurpose)
        .mortgage(getMortgageData(adboCaseDetails))
        .applicants(getApplicantData(adboCaseDetails))
        .build();
  }

  ESISApplicationBuilder buildESISApplicationBuilder(AdboCaseDetails adboCaseDetails, String loanPurpose) {
    return ESISApplication.builder().channel(CHANNEL)
        .levelOfService(LEVEL_OF_SERVICE)
        .caseId(adboCaseDetails.getId())
        .applicationType(APPLICATION_TYPE)
        .loanPurpose(loanPurpose)
        .buyerType(adboCaseDetails.getSalesIllustration().getProductDetails().get(0).getCustomerType());
  }

  ESISApplication mapToEsisApplicationForProductSwitch(AdboCaseDetails adboCaseDetails, String loanPurpose) {
    return buildESISApplicationBuilder(adboCaseDetails, loanPurpose)
        .mortgage(getMortgageDataForProductSwitch(adboCaseDetails))
        .applicants(getApplicantData(adboCaseDetails))
        .build();
  }

  Mortgage getMortgageData(AdboCaseDetails adboCaseDetails) {
    List<SalesEsisProduct> products = new ArrayList<>();
    products.add(getProducts(adboCaseDetails));
    AdditionalBorrowingCalculator additionalBorrowingCalculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    return buildMortgageBuilder(adboCaseDetails.getAdditionalBorrowingCalculator())
        .mortgageAmount(BigDecimal.valueOf(additionalBorrowingCalculator.getBorrowingAmount()))
        .mortgageTermYears(additionalBorrowingCalculator.getRepaymentTermYears())
        .mortgageTermMonths(additionalBorrowingCalculator.getRepaymentTermMonths())
        .products(products)
        .build();
  }

  Mortgage getMortgageDataForProductSwitch(AdboCaseDetails adboCaseDetails) {
    Product product = adboCaseDetails.getSalesIllustration().getProductDetails().get(0);
    List<SubAccount> selectedSubAccounts = SubAccountsSelectionForSwitching.selectedSubAccountsForSwitching(adboCaseDetails);
    List<SalesEsisProduct> salesEsisProducts = buildSalesESISProductListFromSelectedSubAccounts(selectedSubAccounts, product,
        adboCaseDetails.getSalesIllustration().getSelectionDate());
    buildProductsForUnSelectedSubAccounts(adboCaseDetails, product, salesEsisProducts);
    TimePeriod highestTermYearsMonthsFromSubAccountList = findHighestTermYearsMonthsFromSubAccountList(selectedSubAccounts);
    return buildMortgageBuilder(adboCaseDetails.getAdditionalBorrowingCalculator())
        .mortgageAmount(getMortgageAmountFromSubAccounts(selectedSubAccounts))
        .mortgageTermYears(highestTermYearsMonthsFromSubAccountList.getYears())
        .mortgageTermMonths(highestTermYearsMonthsFromSubAccountList.getMonths())
        .products(salesEsisProducts)
        .build();
  }

  void buildProductsForUnSelectedSubAccounts(AdboCaseDetails adboCaseDetails, Product product, List<SalesEsisProduct> salesEsisProducts) {
    SubAccountsSelectionForSwitching.nonSelectedSubAccountsForSwitching(adboCaseDetails)
        .forEach(subAccount -> {
          salesEsisProducts.add(salesEsisProductForUnSelectedSubAccount(subAccount, product, adboCaseDetails.getGmsSysDate(),
              adboCaseDetails.getSalesIllustration().getSelectionDate()));
        });

  }

  MortgageBuilder buildMortgageBuilder(AdditionalBorrowingCalculator additionalBorrowingCalculator) {
    return Mortgage.builder().propertyValue(isEmpty(additionalBorrowingCalculator.getEstimatedPropertyValue()) ?
            BigDecimal.valueOf(additionalBorrowingCalculator.getHpiValuation().intValue()) :
            BigDecimal.valueOf(additionalBorrowingCalculator.getEstimatedPropertyValue()))
        .mortgageType(ESIS_MORTGAGE_TYPE);
  }

  List<SalesEsisProduct> buildSalesESISProductListFromSelectedSubAccounts(List<SubAccount> selectedSubAccounts, Product product,
      LocalDate selectionDate) {
    return selectedSubAccounts.stream()
        .map(subAccount -> getProductsForProductSwitch(subAccount, product, selectionDate))
        .collect(Collectors.toList());
  }

  BigDecimal getMortgageAmountFromSubAccounts(List<SubAccount> subAccounts) {
    return subAccounts.stream().map(subAccount -> subAccount.getTrueBalance()).reduce(BigDecimal.ZERO, BigDecimal::add);
  }

  TimePeriod findHighestTermYearsMonthsFromSubAccountList(List<SubAccount> subAccounts) {
    List<TimePeriod> sortedTimePeriod = subAccounts.stream()
        .map(subAccount -> subAccount.getRemainingTerm()).sorted(Comparator.comparing(
            TimePeriod::getYears).thenComparing(TimePeriod::getMonths)).collect(Collectors.toList());
    return CollectionUtils.lastElement(sortedTimePeriod);
  }

  SalesEsisProduct getProductsForProductSwitch(SubAccount subAccount, Product product, LocalDate selectionDate) {
    var salesEsisProduct = buildSalesEsisProductBuilder(product, selectionDate)
        .loanAmount(subAccount.getTrueBalance())
        .termYears(subAccount.getRemainingTerm().getYears())
        .termMonths(subAccount.getRemainingTerm().getMonths())
        .build();
    return salesEsisProduct;
  }

  SalesEsisProductBuilder buildSalesEsisProductBuilder(Product product, LocalDate selectionDate) {
    try {
      SalesEsisProductBuilder salesEsisProductBuilder = SalesEsisProduct.builder()
          .calculationType(CALCULATION_TYPE)
          .initialInterestRate(BigDecimal.valueOf(product.getInitialInterestRate()))
          .svr(BigDecimal.valueOf(product.getSvr()))
          .productCode(product.getProductCode())
          .productName(product.getProductName())
          .productSelectionDate(selectionDate)
          .productEndDate(LocalDate.parse(product.getProductEndDate()))
          .productType(product.getProductType().name())
          .productTerm(product.getProductTerm().name())
          .ltv(BigDecimal.valueOf(product.getLtv()))
          .erc(getErc(product.getEarlyRepaymentCharges()));
      if (Objects.equals(product.getProductType(), ProductType.TRACKER)) {
        salesEsisProductBuilder.baseRate(BigDecimal.valueOf(product.getBaseRate() * 100).setScale(2, RoundingMode.DOWN));
        salesEsisProductBuilder.initialInterestRate(BigDecimal.valueOf(product.getTrackerMarginPercent() * 100).setScale(2, RoundingMode.DOWN));
      }
      return salesEsisProductBuilder;
    } catch (Exception exception) {
      log.error("Exception occurred while mapping the sales esis product from the subaccount and product objects, exception: {}",
          exception);
      throw new BusinessException(PRODUCT_FIELD_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
  }

  SalesEsisProduct getProducts(AdboCaseDetails adboCaseDetails) {
    Product product = adboCaseDetails.getSalesIllustration().getProductDetails().get(0);
    return buildSalesEsisProductBuilder(product, adboCaseDetails.getSalesIllustration().getSelectionDate())
        .loanAmount(BigDecimal.valueOf(adboCaseDetails.getAdditionalBorrowingCalculator().getBorrowingAmount()))
        .termYears(product.getMortgageTermYears())
        .termMonths(product.getMortgageTermMonths())
        .productFee(BigDecimal.valueOf(product.getProductFee()))
        .feeAddedToLoan(product.isProductFeeAddedToBorrowing())
        .build();
  }

  List<ErcItem> getErc(List<EarlyRepaymentCharge> earlyRepaymentChargeList) {
    List<ErcItem> ercItems = new ArrayList<>();
    for (EarlyRepaymentCharge earlyRepaymentCharge : earlyRepaymentChargeList) {
      if (!isEmpty(earlyRepaymentCharge)) {
        ercItems.add(ErcItem.builder()
            .endDate(LocalDate.parse(earlyRepaymentCharge.getEarlyRepaymentInterestDate()))
            .percentage(BigDecimal.valueOf(earlyRepaymentCharge.getCharge()))
            .seqNo(earlyRepaymentCharge.getYear())
            .build());
      }
    }
    return ercItems;
  }

// Get Document Functionality

  Applicants getApplicantData(AdboCaseDetails adboCaseDetails) {
    List<PersonalDetails> personalDetailsList = new ArrayList<>();
    for (AdboApplicant applicant : adboCaseDetails.getAdboApplicants().values()) {
      if (!isEmpty(applicant)) {
        personalDetailsList.add(PersonalDetails.builder().title(applicant.getPersonalDetails().getTitle())
            .lastName(applicant.getPersonalDetails().getLastName())
            .firstNames(applicant.getPersonalDetails().getFirstName())
            .middleNames(applicant.getPersonalDetails().getMiddleName())
            .dob(applicant.getPersonalDetails().getDateOfBirth())
            .build());
      }
    }
    return Applicants.builder().personalDetails(personalDetailsList).build();
  }

  @Override
  public ESISDocument getSalesEsisRequest(String accountNumber) {
    String documentName = getDocumentName(accountNumber);
    return apiService.getESISDocument(documentName);
  }

  @Override
  public DocumentPaymentFlagsResponse getFlag(String accountNumber) {
    log.info("Entering getFlag for {}", accountNumber);
    log.info("Fetching Account Details {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    return checkValueAndReturnFlag(adboCaseDetails);
  }

  String getDocumentName(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    if (!isEmpty(adboCaseDetails.getSalesIllustration().getDocumentUrl())) {
      String url = adboCaseDetails.getSalesIllustration().getDocumentUrl();
      String[] paths = url.split("/");
      return paths[paths.length - 1];
    } else {
      throw new ResponseStatusException(HttpStatus.NOT_FOUND,
          "Document url not present in Account Number " + adboCaseDetails.getAccountNumber());
    }
  }

  private DocumentPaymentFlagsResponse checkValueAndReturnFlag(AdboCaseDetails adboCaseDetails) {
    DocumentPaymentFlagsResponse response = new DocumentPaymentFlagsResponse();
    if (!isEmpty(adboCaseDetails.getCaseId())) {
      response.setEnableDocUpload(true);
    }
    if (adboCaseDetails.getStatus() == SUBMIT_GMS_STAGE_20 && adboFeePaymentActionCheck.getFeeActionFrom(adboCaseDetails) == FeeAction.NO_ACTION) {
      if (isNotTrue(adboFeePaymentActionCheck.getIsPaymentMade(adboCaseDetails.getCaseId()))) {
        response.setEnablePayment(true);
      }
    }
    return response;
  }

  SalesEsisProduct salesEsisProductForUnSelectedSubAccount(SubAccount subAccount, Product product, LocalDateTime gmsSysDate,
      LocalDate selectionDate) {
    LocalDate productEndDate = subAccount.getCurrentDealEnds();
    if (isNull(productEndDate) &&
        (Objects.equals(subAccount.getInterestType(), FIXED.getInterestType()) || Objects.equals(subAccount.getInterestType(),
            InterestType.TRACKER.getInterestType()))) {
      productEndDate = constructProductEndDate(subAccount);
    }
    return SalesEsisProduct
        .builder()
        .loanAmount(subAccount.getTrueBalance())
        .baseRate(Objects.equals(subAccount.getInterestType(), InterestType.TRACKER.getInterestType()) ? subAccount.getBaseRate() : null)
        .termYears(subAccount.getRemainingTerm().getYears())
        .termMonths(subAccount.getRemainingTerm().getMonths())
        .calculationType(Objects.equals(subAccount.getRepaymentType(), CAPITAL_AND_INTEREST) ? REPAYMENT_TYPE : CALCULATION_INTEREST_ONLY)
        .initialInterestRate(Objects.equals(subAccount.getInterestType(), InterestType.TRACKER.getInterestType()) ? subAccount.getInterestRate().subtract(subAccount.getBaseRate()):
            subAccount.getInterestRate())
        .productType(fromValue(subAccount.getInterestType()).name())
        .productTerm(isNull(subAccount.getProductTerm()) ? null : getProductTerm(subAccount.getProductTerm()))
        .ltv(BigDecimal.valueOf(product.getLtv()))
        .svr(BigDecimal.valueOf(product.getSvr()))
        .productSelectionDate(selectionDate)
        .productEndDate(productEndDate)
        .erc(isNull(subAccount.getCurrentDealEnds()) ? null : mapErcItem(subAccount, gmsSysDate))
        .build();

  }

  /**
   * This method is used to formulate ERC list for the subaccount that is not-opted /In eligible ones
   *
   * @param subAccount
   */
  private List<ErcItem> mapErcItem(SubAccount subAccount, LocalDateTime gmsSysDate) {
    log.info("mapErcItem is started for unselected sub accounts for switch. subAccountNumber: {}, gmsSysDate: {}, currentDealEndDate: {}",
        subAccount.getSubAccountNumber(), gmsSysDate, subAccount.getCurrentDealEnds());
    BigDecimal basePercentage = setDefaultErcBasePercentageByInterestType(subAccount.getInterestType());
    if (subAccount.getCurrentDealEnds().isBefore(gmsSysDate.toLocalDate())) {
      return null;
    }
    List<ErcItem> ercItems = new ArrayList<>();
    if (!isEmpty(subAccount)) {
      ErcItem ercItem = ercItemBuilder(subAccount.getCurrentDealEnds()).percentage(basePercentage).build();
      ercItems.add(ercItem);
    }
    LocalDate currentDealEnd = subAccount.getCurrentDealEnds();
    int seq = 1;
    while (currentDealEnd.minusYears(1).compareTo(gmsSysDate.toLocalDate()) >= 0) {
      currentDealEnd = currentDealEnd.minusYears(1);
      ErcItemBuilder ercItemBuilder = ercItemBuilder(currentDealEnd);
      ercItemBuilder = ercItemBuilder.percentage(ercItems.get(seq - 1).getPercentage().add(basePercentage));
      ercItems.add(ercItemBuilder.build());
      seq++;
    }
    Collections.reverse(ercItems);
    List<ErcItem> ercItemsWithSeqNo = IntStream.range(0, ercItems.size())
        .mapToObj(i -> {
          ErcItem ercItem = ercItems.get(i);
          ercItem.setSeqNo(i + 1);
          return ercItem;
        }).collect(Collectors.toList());
    log.info("mapErcItem is end for unselected sub accounts for switch, subAccountNumber: {}, ercList {}", subAccount.getSubAccountNumber(),
        ercItemsWithSeqNo);
    return ercItemsWithSeqNo;
  }

  private BigDecimal setDefaultErcBasePercentageByInterestType(String interestType) {
    return Objects.equals(interestType, InterestType.VARIABLE.getInterestType()) ? null
        : Objects.equals(interestType, InterestType.TRACKER.getInterestType()) ? trackerProductBaseRatePercentage
            : fixedProductBaseRatePercentage;
  }

  private ErcItemBuilder ercItemBuilder(LocalDate currenDealEndDate) {
    return ErcItem
        .builder()
        .endDate(currenDealEndDate);
  }

  private LocalDate constructProductEndDate(SubAccount subAccount) {
    return LocalDate.of(subAccount.getRemainingTerm().getYears(), subAccount.getRemainingTerm().getMonths(), 01);
  }
}
