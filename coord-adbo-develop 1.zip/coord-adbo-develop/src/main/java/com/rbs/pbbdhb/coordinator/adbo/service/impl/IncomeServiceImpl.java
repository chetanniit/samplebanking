package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static java.lang.Integer.parseInt;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerEmployed;
import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerEmploymentDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerResponse;
import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerSelfEmployed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.BankDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.Income;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.SelfEmployed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmployedBasis;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmploymentType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Industry;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Occupation;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.SelfEmployedBasis;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.mapper.AddressMapper;
import com.rbs.pbbdhb.coordinator.adbo.request.IncomeRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.IncomeResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.IncomeService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class IncomeServiceImpl implements IncomeService {

  private static final int BANK_SORT_CODE_MAX_LENGTH = 6;
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final ApiService apiService;
  private final AddressMapper addressMapper;
  private final int bankSortCodeMaxLength = 6;
  private final int bankAccountNumberMaxLength = 8;
  private final ModelMapper modelMapper;

  private static LocalDate calculateContractDateEnd(EmployedBasis employedBasis) {
    return employedBasis == EmployedBasis.CONTRACTOR ? LocalDate.now().plusYears(1) : null;
  }

  /**
   * If not modified display only the bank name and time with the bank.
   */
  private static BankDetails prepareBankDetails(BankDetails bankDetails, boolean hasBeenModified) {
    return hasBeenModified || bankDetails == null ? bankDetails :
        BankDetails.builder()
            .bankName(bankDetails.getBankName())
            .yearsWithBank(bankDetails.getYearsWithBank())
            .monthsWithBank(bankDetails.getMonthsWithBank())
            .build();
  }

  @Override
  public void saveIncomeDetails(final String accountNumber, IncomeRequest incomeRequest) {
    AdboCaseDetails caseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    if (!incomeRequest.isHasBankDetailsModified()) {
      // restore full data see {@link #prepareBankDetailsToDisplay}
      BankDetails bankDetails = caseDetails.getAdboApplicants().get(incomeRequest.getApplicantType()).getIncome()
          .getBankDetails();
      incomeRequest.setBankDetails(bankDetails);
    }
    caseDetails.getAdboApplicants().get(incomeRequest.getApplicantType())
        .setIncome(Income.builder().currentWorkStatus(incomeRequest.getCurrentWorkStatus())
            .employments(addCountryIsoCodesAndContractEndDate(incomeRequest.getEmployments()))
            .retired(incomeRequest.getRetired()).hasOtherIncome(incomeRequest.getHasOtherIncome())
            .otherIncomes(incomeRequest.getOtherIncomes())
            .hasBankDetailsModified(incomeRequest.isHasBankDetailsModified())
            .bankDetails(incomeRequest.getBankDetails()).build());
    adboCaseDetailsDao.save(caseDetails);
    log.info("Income details have been saved/updated successfully, accountNumber {}", accountNumber);
  }

  @Override
  public List<IncomeResponse> getIncomeDetails(String accountNumber) {
    AdboCaseDetails caseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    return caseDetails.getAdboApplicants().keySet().stream()
        .map(applicantType -> prepareResponse(applicantType, caseDetails))
        .collect(toList());
  }

  private List<Employment> addCountryIsoCodesAndContractEndDate(List<Employment> employments) {
    if (employments != null) {
      employments.stream()
          .map(employment -> {
            if (employment instanceof Employed) {
              Employed employed = (Employed) employment;
              employed.setContractEndDate(calculateContractDateEnd(employed.getEmploymentBasis()));
              return employed.getEmployerStructuredAddress();
            }
            if (employment instanceof SelfEmployed) {
              return ((SelfEmployed) employment).getCompanyStructuredAddress();
            }
            return null;
          })
          .filter(Objects::nonNull)
          .forEach(address -> address.setCountryIsoCode(address.getCountry()));
    }
    return employments;
  }

  private IncomeResponse prepareResponse(ApplicantType applicantType, AdboCaseDetails caseDetails) {
    Income income = caseDetails.getAdboApplicants().get(applicantType).getIncome();
    if (income == null || income.getCurrentWorkStatus() == null) {
      income = fetchIncome(applicantType, caseDetails);
    }

    return IncomeResponse.builder()
        .fromGms(income.isFromGms())
        .currentWorkStatus(income.getCurrentWorkStatus())
        .employments(prepareResponseEmployments(income.getEmployments()))
        .hasOtherIncome(income.getHasOtherIncome())
        .otherIncomes(income.getOtherIncomes())
        .hasBankDetailsModified(income.isHasBankDetailsModified())
        .bankDetails(prepareBankDetails(income.getBankDetails(), income.isHasBankDetailsModified()))
        .applicantType(applicantType)
        .retired(income.getRetired())
        .build();
  }

  private List<Employment> prepareResponseEmployments(List<Employment> employments) {
    return employments.stream()
        .map(employment -> {
          if (employment instanceof Employed) {
            Employed newEmployed = modelMapper.map(employment, Employed.class);
            return newEmployed;
          } else {
            return employment;
          }
        })
        .collect(toList());
  }

  private Income fetchIncome(ApplicantType applicantType, AdboCaseDetails adboCaseDetails) {
    Income income = new Income();
    String cin = adboCaseDetails.getAdboApplicants().get(applicantType).getCin();
    income.setEmployments(applicantType == ApplicantType.MAIN ? fetchEmployments(cin) : emptyList());
    income.setBankDetails(fetchLatestBankDetails(adboCaseDetails, cin));
    income.setFromGms(applicantType == ApplicantType.MAIN);
    adboCaseDetails.getAdboApplicants().get(applicantType).setIncome(income);
    adboCaseDetailsDao.save(adboCaseDetails);
    return income;
  }

  private List<Employment> fetchEmployments(String cin) {
    List<Employment> employments = new ArrayList<>();
    GetCustomerResponse response = apiService.getEmploymentDetails(cin, Constants.EMPLOYMENT_DETAILS);
    GetCustomerEmploymentDetails employmentDetails = response.getData().getEmploymentDetails();
    List<GetCustomerEmployed> employedList = employmentDetails.getEmployed();
    if (employedList != null) {
      for (GetCustomerEmployed emp : employedList) {
        Employed employed = new Employed();
        if ("E".equals(emp.getEmploymentType()) && "C".equals(emp.getCurrentOrPrevious())) {
          employed.setType(EmploymentType.EMPLOYED);
          employed.setEmployerName(emp.getEmployerName() != null ? emp.getEmployerName() : null);
          employed.setIndustry(emp.getEmployerStatus() != null ? setIndustryType(emp.getEmployerStatus()) : null);
          employed.setOccupation(emp.getOccupation() != null ? setOccupationType(emp.getOccupation()) : null);
          employed.setStartDate(emp.getStartDate() != null ? emp.getStartDate() : null);
          employed.setEmploymentBasis(emp.getEmploymentStatus() != null ? setEmploymentBasis(emp.getEmploymentStatus()) : null);
          employed.setEmployerAddress(emp.getEmployerAddress() != null ?
              addressMapper.mapAddress(emp.getEmployerAddress()) : null);
          employments.add(employed);
        }
      }
    }
    List<GetCustomerSelfEmployed> selfEmployedList = employmentDetails.getSelfEmployed();
    if (selfEmployedList != null) {
      for (GetCustomerSelfEmployed selfEmp : selfEmployedList) {
        if ("C".equals(selfEmp.getCurrentOrPrevious())) {
          SelfEmployed selfEmployed = new SelfEmployed();
          selfEmployed.setType(EmploymentType.SELF_EMPLOYED);
          selfEmployed.setEmploymentBasis(selfEmp.getEmploymentStatus() != null ?
              mapEmploymentStatus(selfEmp.getEmploymentStatus()) : null);
          selfEmployed.setYearsEstablished(selfEmp.getYearsEstablished() != null ? selfEmp.getYearsEstablished() : null);
          selfEmployed.setMonthsEstablished(selfEmp.getMonthsEstablished() != null ? selfEmp.getMonthsEstablished() : null);
          selfEmployed.setBusinessName(selfEmp.getCompanyName() != null ? selfEmp.getCompanyName() : null);
          selfEmployed.setCompanyAddress(selfEmp.getCompanyAddress() != null ?
              addressMapper.mapAddress(selfEmp.getCompanyAddress()) : null);
          employments.add(selfEmployed);
        }
      }
    }
    return employments;
  }

  private BankDetails fetchLatestBankDetails(AdboCaseDetails adboCaseDetails, String cin) {
    List<com.rbs.pbbdhb.coordinator.adbo.model.customer.BankDetails> fetchBankDetails = apiService
        .getBankDetails(adboCaseDetails.getAccountNumber());
    BankDetails latestbankdetails = BankDetails.builder().build();
    for (com.rbs.pbbdhb.coordinator.adbo.model.customer.BankDetails bankDetail : fetchBankDetails) {
      if (bankDetail.getCin().equals(cin)) {
        latestbankdetails.setBankAccountName(bankDetail.getBankAccountName());
        latestbankdetails.setBankAccountNumber(
            String.format("%" + bankAccountNumberMaxLength + "s", bankDetail.getBankAccountNumber()).replace(' ', '0'));
        latestbankdetails.setBankName(bankDetail.getBankName());
        latestbankdetails.setBankSortCode(
            String.format("%" + BANK_SORT_CODE_MAX_LENGTH + "s", bankDetail.getBankSortCode()).replace(' ', '0'));
        latestbankdetails.setMonthsWithBank(parseInt(bankDetail.getMonthsWithBank()));
        latestbankdetails.setYearsWithBank(parseInt(bankDetail.getYearsWithBank()));
        break;
      }
    }
    return latestbankdetails;
  }

  private Industry setIndustryType(String gmsIndustryCode) {

    switch (gmsIndustryCode) {
      case "A":
        return Industry.AGRICULTURE_AND_FORESTRY;
      case "B":
        return Industry.FISHING;
      case "C":
        return Industry.MINING_AND_QUARRYING;
      case "D":
        return Industry.MANUFACTURING;
      case "E":
        return Industry.ELECTRICITY_GAS_AND_WATER_SUPPLY;
      case "F":
        return Industry.CONSTRUCTION;
      case "G":
        return Industry.WHOLESALE_RETAIL_AND_REPAIR;
      case "H":
        return Industry.HOTELS_AND_RESTAURANTS;
      case "I":
        return Industry.TRANSPORT_STORAGE_AND_COMMERCIAL;
      case "J":
        return Industry.FINANCE_AND_BANKING;
      case "K":
        return Industry.PROPERTY_AND_BUSINESS;
      case "L":
        return Industry.PUBLIC_ADMIN_AND_DEFENCE;
      case "M":
        return Industry.EDUCATION;
      case "N":
        return Industry.HEALTH_AND_SOCIAL_WORK;
      case "O":
        return Industry.OTHER;
      case "P":
        return Industry.OFFICE_WORK_AND_ADMINISTRATION;
      default:
        log.error("Unsupported gms industry type {}  provided", gmsIndustryCode);
        return null;
    }
  }

  private EmployedBasis setEmploymentBasis(String employmentBasis) {
    switch (employmentBasis) {
      case "P":
        return EmployedBasis.PERMANENT;
      case "T":
        return EmployedBasis.TEMPORARY;
      case "C":
        return EmployedBasis.CONTRACTOR;
      default:
        log.info("employment basis type {}  provided", employmentBasis);
        return null;
    }
  }

  private Occupation setOccupationType(String gmsOccupationCode) {

    switch (gmsOccupationCode) {
      case "AS":
        return Occupation.ACADEMIC_STAFF;
      case "AG":
        return Occupation.AGRICULTURAL_WORKER;
      case "CG":
        return Occupation.ARCHITECT_BUILDING_AND_PLANNING;
      case "CA":
        return Occupation.ARTS;
      case "CB":
        return Occupation.BUSINESS_AND_ADMINISTRATION;
      case "CE":
        return Occupation.ENGINEERING;
      case "FM":
        return Occupation.FARM_OWNER_AND_MANAGER;
      case "OF":
        return Occupation.HM_FORCES_OFFICER;
      case "OR":
        return Occupation.HM_FORCES_OTHER_RANK;
      case "CH":
        return Occupation.HUMANITIES;
      case "MJ":
        return Occupation.JUNIOR_MANAGER;
      case "CK":
        return Occupation.LANGUAGES;
      case "CL":
        return Occupation.LAW;
      case "CF":
        return Occupation.MATHS;
      case "CM":
        return Occupation.MEDICAL_AND_RELATED;
      case "PM":
        return Occupation.SEMI_PROFESSIONALS;
      case "CN":
        return Occupation.NURSING;
      case "OC":
        return Occupation.OFFICE_AND_CLERICAL;
      case "SA":
        return Occupation.SALES;
      case "CC":
        return Occupation.SCIENCES;
      case "SS":
        return Occupation.SEMI_SKILLED_MANUAL;
      case "MS":
        return Occupation.SENIOR_MANAGER;
      case "SR":
        return Occupation.SERVICE_INDUSTRY_EMPLOYEE;
      case "SK":
        return Occupation.SKILLED_MANUAL;
      case "CD":
        return Occupation.SOCIAL_STUDIES;
      case "SU":
        return Occupation.SUPERVISOR;
      case "TC":
        return Occupation.TEACHER;
      case "TH":
        return Occupation.TECHNICIAN;
      case "UM":
        return Occupation.UNSKILLED_MANUAL;
      case "CO":
      case "PR":
        return Occupation.PROFESSIONALS;
      default:
        log.error("Unsupported gms occupation type {}  provided", gmsOccupationCode);
        return null;
    }
  }

  private SelfEmployedBasis mapEmploymentStatus(String gmsSelfEmploymentStatus) {

    switch (gmsSelfEmploymentStatus) {
      case "D":
        return SelfEmployedBasis.LIMITED_COMPANY;
      case "P":
        return SelfEmployedBasis.PARTNERSHIP;
      case "S":
        return SelfEmployedBasis.SOLE_TRADER;
      default:
        log.error("Unsupported self employment type {}  provided", gmsSelfEmploymentStatus);
        throw new IllegalArgumentException("Unsupported self employment type provided");
    }
  }
}
