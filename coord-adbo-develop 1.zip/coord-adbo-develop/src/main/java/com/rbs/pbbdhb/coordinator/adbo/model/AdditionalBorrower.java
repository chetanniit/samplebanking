package com.rbs.pbbdhb.coordinator.adbo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Gender;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.ValidatableCustomer;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AdditionalBorrower implements Serializable, ValidatableCustomer {

  private static final long serialVersionUID = -1980328847631145620L;

  private Title title;
  private String forename;
  private String email;
  private String surname;
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate dateOfBirth;
  private Gender gender;
  private Integer acctHolderPosition;
  private String gmsId;
  private String cin;

}
