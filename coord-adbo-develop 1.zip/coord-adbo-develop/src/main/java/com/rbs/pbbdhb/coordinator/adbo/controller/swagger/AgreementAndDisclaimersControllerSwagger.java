package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.request.AgreementsAndDisclaimersRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AgreementsAndDisclaimersResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "16 - Agreements & Disclaimers", description = "Agreements And Disclaimers of the customer")
public interface AgreementAndDisclaimersControllerSwagger {

  @Operation(description = "Retrieve customer agreements and disclaimers", operationId = "getAgreementsAndDisclaimers", summary = "Retrieve customer agreements and disclaimers",
      responses = {
          @ApiResponse(responseCode = "200", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AgreementsAndDisclaimersResponse.class))),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
          @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
          @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<AgreementsAndDisclaimersResponse> getAgreementsAndDisclaimers(
      @RequestHeader(Headers.ACCOUNT_NUMBER) String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);

  @Operation(description = "Save customer agreements and disclaimers", operationId = "saveAgreementsAndDisclaimers", summary = "Save customer agreements and disclaimers",
      responses = {
          @ApiResponse(responseCode = "204", content = @Content),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
          @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
          @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Void> saveAgreementsAndDisclaimers(
      @RequestHeader(Headers.ACCOUNT_NUMBER) String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final AgreementsAndDisclaimersRequest agreementsAndDisclaimers);

}
