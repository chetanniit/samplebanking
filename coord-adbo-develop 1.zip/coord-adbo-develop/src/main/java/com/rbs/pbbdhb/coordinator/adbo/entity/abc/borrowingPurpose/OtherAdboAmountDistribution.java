package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OtherAdboAmountDistribution implements AdboAmountDistribution {

  @NotNull(message = "Borrowing purpose amount cannot be null")
  @Positive(message = "Borrowing Purpose amount should not be zero")
  private BigDecimal amount;
  @NotNull(message = "Borrowing Purpose type cannot be empty")
  private BorrowingPurposeType type;

  @Override
  public BigDecimal getAmount() {
    return amount;
  }

  @Override
  public BorrowingPurposeType getType() {
    return type;
  }

}
