package com.rbs.pbbdhb.coordinator.adbo.kafka;

import com.rbs.pbbdhb.coordinator.adbo.enums.Route;
import lombok.Builder;
import lombok.Data;
import lombok.With;
import lombok.extern.jackson.Jacksonized;

@Data
@With
@Builder
@Jacksonized
public class JointApplicantDisclaimersAndMpDto {

  private final String id;
  private final String applicantId;
  private final String email;
  private final String mobileNumber;
  private final Route route;

}
