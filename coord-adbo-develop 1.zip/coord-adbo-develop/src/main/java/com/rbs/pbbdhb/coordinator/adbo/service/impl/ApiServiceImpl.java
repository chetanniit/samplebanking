package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DOCUMENT_NOT_GENERATED;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.util.ObjectUtils.isEmpty;

import com.google.common.collect.ImmutableMap;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.dto.CaseDetailsDto;
import com.rbs.pbbdhb.coordinator.adbo.entity.Applicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerResponse;
import com.rbs.pbbdhb.coordinator.adbo.entity.PatchApplicant;
import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.GmsStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.TrueBalanceResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.BankDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CoreCustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerAddress;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerKycResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerVulnerableResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.VulnerabilityRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.MarketingPreference;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipResult;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchFinalResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISDocument;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISDocument.ESISDocumentBuilder;
import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyAdditionalRepaymentCalculatorForTenure;
import com.rbs.pbbdhb.coordinator.adbo.response.MonthlyAdditionalMinMaxRepaymentVo;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.RestService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.Brand;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Component
public class ApiServiceImpl implements ApiService {

  public static final String ESIS_STORAGE_URL_HEADER = "Esis-Storage-Url";
  private static final EnumSet<HttpStatus> NOT_ERRORS_SET = EnumSet.of(OK);
  private static final EnumSet<HttpStatus> OK_AND_NOT_FOUND_SET = EnumSet.of(OK, NOT_FOUND);
  private final RestService restService;
  @Value("${adbo.service.base.url}")
  private String adboServiceBaseUrl;
  @Value("${adbo.service.account.summary.path}")
  private String accountSummaryReqPath;
  @Value("${adbo.service.application.type.path}")
  private String applicationTypeReqPath;
  @Value("${adbo.service.account.true-balance.path}")
  private String accountTrueBalancePath;
  @Value("${adbo.service.account.stage.path}")
  private String accountStagePath;
  @Value("${adbo.service.customer.summary.path}")
  private String customerRequestPath;
  @Value("${adbo.service.customer.address.path}")
  private String customerAddressPath;
  @Value("${adbo.service.customer.bankdetails.path}")
  private String customerBankDetailsPath;
  @Value("${customer.service.base.url}")
  private String customerServiceBaseUrl;
  @Value("${customer.service.check.kyc.path}")
  private String customerServiceKycPath;
  @Value("${adbo.service.customer.vulnerable.path}")
  private String adboServiceCustomerVulnerablePath;
  @Value("${product.service.base.url}")
  private String productServiceBaseUrl;
  @Value("${product.service.minmax.request.path}")
  private String minMaxRepaymentReqPath;
  @Value("${productstate.service.base.url}")
  private String productStateServiceBaseUrl;
  @Value("${core.dip.service.base.url}")
  private String dipServiceBaseUrl;
  @Value("${core.dip.service.dip.path}")
  private String dipRequestPath;
  @Value("${core.dip.service.base.nwb-client-id}")
  private String dipNwbClientId;
  @Value("${core.dip.service.base.rbs-client-id}")
  private String dipRbsClientId;
  @Value("${product.service.product-search.request.path}")
  private String productSearchReqPath;
  @Value("${app.status.request.path}")
  private String appStatusReqPath;
  @Value("${salesesis.service.base.url}")
  private String salesEsisUrl;
  @Value("${salesesis.service.base.esis.path}")
  private String salesEsisPath;
  @Value("${msvc.applicant.service.base.url}")
  private String applicantBaseUrl;
  @Value("${msvc.applicant.service.request.path}")
  private String applicantPath;
  @Value("${msvc.marketing-preference.service.base.url}")
  private String marketingPreferenceBaseUrl;
  @Value("${msvc.marketing-preference.service.request.path}")
  private String marketingPreferencePath;
  @Value("${kyc-api.mock-response:false}")
  private boolean mockKycResponse;
  @Value("${vulnerable-api.mock-response:false}")
  private boolean mockVulnerableResponse;
  @Value("${msvc.case-adbo.service.base.url}")
  private String caseAdboBaseUrl;
  @Value("${msvc.case-adbo.service.request.path}")
  private String casePath;
  @Value("${msvc.product-switch-repayment-calculator.service.base.url}")
  private String productSwitchRepaymentCalculatorBaseUrl;
  @Value("${msvc.product-switch-repayment-calculator.service.request.path}")
  private String productSwitchRepaymentCalculatorReqPath;
  @Value("${coreCustomer-api.mock-response}")
  private boolean mockCoreCustomerResponse;

  @Autowired
  public ApiServiceImpl(RestService restService) {
    this.restService = restService;
  }

  @Override
  public AccountSummaryResponse getAccount(String accountNumber) {
    String url = StringUtils.join(adboServiceBaseUrl, accountSummaryReqPath, "/", accountNumber);
    ResponseEntity<AccountSummaryResponse> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
        AccountSummaryResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.ACCOUNT_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public TrueBalanceResponse getTrueBalance(String accountNumber) {
    String url = StringUtils.join(adboServiceBaseUrl, accountTrueBalancePath, "/", accountNumber);
    ResponseEntity<TrueBalanceResponse> response = restService.exchange(url, HttpMethod.GET, createHeaders(), TrueBalanceResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.TRUE_BALANCE_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public List<CoreCustomerSummaryResponse> getCustomers(String accountNumber) {
    String url = StringUtils.join(adboServiceBaseUrl, customerRequestPath, "/", accountNumber);
    ResponseEntity<List<CustomerSummaryResponse>> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
        new ParameterizedTypeReference<List<CustomerSummaryResponse>>() {
        });
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.BORROWER_NOT_FOUND));
    List<String> cins = response.getBody().stream()
        .map(CustomerSummaryResponse::getCin)
        .collect(Collectors.toList());
    List<CoreCustomerSummaryResponse> coreCustomerResponse = getCoreCustomers(cins, response.getBody());
    return coreCustomerResponse;
  }

  @Override
  public CustomerKycResponse getKycApi(String cin) {
    // TO-DO, mockKyResponse code to removed, In the prod it should be false
    if (mockKycResponse) {
      log.info("Mocked the response for kyc api");
      CustomerKycResponse mockResponse = new CustomerKycResponse();
      mockResponse.setKycVerified(true);
      return mockResponse;
    }
    // TO-DO end, mockKyResponse code to removed, In the prod it should be false
    String url = StringUtils.join(customerServiceBaseUrl, customerServiceKycPath, '/', cin);
    try {
      ResponseEntity<CustomerKycResponse> response = restService.exchange(url, HttpMethod.GET, createHeaders(), CustomerKycResponse.class);
      throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.KYC_DETAILS_NOT_FOUND));
      return response.getBody();
    } catch (Exception e) {
      if (mockKycResponse) {
        log.info("Mocked the response for kyc api");
        CustomerKycResponse mockResponse = new CustomerKycResponse();
        mockResponse.setKycVerified(true);
        return mockResponse;
      }
      throw e;
    }
  }

  @Override
  public CustomerVulnerableResponse getVulnerabilityApi(String cin) {

    //TO-DO Mock the response in the test env, Need to investigate the response time
    if (mockVulnerableResponse) {
      log.info("Mocked the response for vulnerability api");
      CustomerVulnerableResponse mockResponse = new CustomerVulnerableResponse();
      mockResponse.setVulnerable(false);
      return mockResponse;
    }
    //TO-DO Mock the response in the test env, Need to investigate the response time

    String url = StringUtils.join(adboServiceBaseUrl, adboServiceCustomerVulnerablePath);
    try {
      ResponseEntity<CustomerVulnerableResponse> response = restService.exchange(url, HttpMethod.POST, createVulnerableProfileRequest(cin),
          CustomerVulnerableResponse.class);
      throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.VULNERABLE_DETAILS_NOT_FOUND));
      return response.getBody();
    } catch (Exception e) {
      if (mockVulnerableResponse) {
        log.info("Mocked the response for vulnerability api");
        CustomerVulnerableResponse mockResponse = new CustomerVulnerableResponse();
        mockResponse.setVulnerable(false);
        return mockResponse;
      }
      throw e;
    }
  }

  @Override
  public MonthlyAdditionalMinMaxRepaymentVo getMonthlyAdditionalMinMaxRepayment(
      MonthlyAdditionalRepaymentCalculatorForTenure monthlyAdditionalRepaymentCalculatorForTenure) {
    log.info("Product API minMax request body {}", monthlyAdditionalRepaymentCalculatorForTenure);
    String url = StringUtils.join(productServiceBaseUrl, minMaxRepaymentReqPath);
    ResponseEntity<MonthlyAdditionalMinMaxRepaymentVo> response = restService.exchange(url, HttpMethod.POST,
        createHeaders(monthlyAdditionalRepaymentCalculatorForTenure), MonthlyAdditionalMinMaxRepaymentVo.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.MIN_MAX_DETAILS_NOT_FOUND));
    log.info("Product API minMax response body {}", response.getBody());
    return response.getBody();
  }

  @Override
  public ApplicationStatusResponse getApplicationStatusApi(String accountNumber) {
    String url = StringUtils.join(productStateServiceBaseUrl, appStatusReqPath, accountNumber);
    ResponseEntity<ApplicationStatusResponse> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
        ApplicationStatusResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.NO_APPLICATION_FOUND));
    return response.getBody();
  }

  @Override
  public GetCustomerResponse getEmploymentDetails(String cin, String employmentDetails) {
    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(customerServiceBaseUrl + "/gms-customers/cin/" + cin);
    uriBuilder.queryParam("details", employmentDetails);
    ResponseEntity<GetCustomerResponse> response = restService.exchange(uriBuilder.toUriString(), HttpMethod.GET, createHeaders(),
        GetCustomerResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.BORROWER_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public List<BankDetails> getBankDetails(String accountNumber) {
    String url = StringUtils.join(adboServiceBaseUrl, customerBankDetailsPath, "/", accountNumber);
    ResponseEntity<List<BankDetails>> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
        new ParameterizedTypeReference<List<BankDetails>>() {
        });
    throwExceptionIfNotSuccess(response, OK_AND_NOT_FOUND_SET, emptyMap());
    List<BankDetails> details = response.getBody();
    return (details == null) ? emptyList() : details;
  }

  @Override
  public ProductSearchFinalResponse getProductDetails(ProductSearchRequest productSearchRequest) {
    log.info("The product search query parameters : {}", productSearchRequest);
    String url = StringUtils.join(productServiceBaseUrl, productSearchReqPath);
    ResponseEntity<ProductSearchFinalResponse> response = restService.exchange(url, HttpMethod.POST,
        createHeaders(productSearchRequest), ProductSearchFinalResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.PRODUCT_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public ESISDocument getESISDocument(ESISApplication application) {
    String url = StringUtils.join(salesEsisUrl, salesEsisPath);
    ResponseEntity<byte[]> response = restService.exchange(url, HttpMethod.POST, createHeaders(application), byte[].class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.DOCUMENT_NOT_GENERATED));
    ESISDocumentBuilder responseBuilder = ESISDocument.builder();
    List<String> urlHeaders = response.getHeaders().get(ESIS_STORAGE_URL_HEADER);
    if (isEmpty(urlHeaders)) {
      throw new BusinessException(DOCUMENT_NOT_GENERATED, HttpStatus.NOT_FOUND.value());
    }
    responseBuilder.url(urlHeaders.get(0));
    return responseBuilder.body(response.getBody()).build();

  }

  @Override
  public ESISDocument getESISDocument(String documentName) {
    String url = StringUtils.join(salesEsisUrl, salesEsisPath, '/', documentName);
    ResponseEntity<byte[]> response = restService.exchange(url, HttpMethod.GET, createHeaders(), byte[].class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.DOCUMENT_NOT_FOUND));
    return ESISDocument.builder().body(response.getBody()).build();

  }

  @Override
  public Optional<DipResult> performDip(DipApplication dipRequest) {
    String url = StringUtils.join(dipServiceBaseUrl, dipRequestPath);
    Brand brand = TenantProvider.getCurrentBrand();
    HttpEntity<DipApplication> dipApplicationHttpEntity =
        (brand == Brand.NWB) ? createHeaders(dipRequest, "client_id", dipNwbClientId) :
            createHeaders(dipRequest, "client_id", dipRbsClientId);
    ResponseEntity<DipResult> response = restService.exchange(url, HttpMethod.POST, dipApplicationHttpEntity, DipResult.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.BORROWER_NOT_FOUND));
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public ApplicationType getApplicationType(String accountNumber) {
    String url = StringUtils.join(adboServiceBaseUrl, applicationTypeReqPath, "/", accountNumber);
    ResponseEntity<ApplicationType> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
        ApplicationType.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.ACCOUNT_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public Applicant patchAgreementsAndDisclaimers(String applicantId, List<PatchApplicant> agreementsAndDisclaimers) {

    String url = StringUtils.join(applicantBaseUrl, applicantPath.replaceFirst("\\{applicantId}", applicantId));
    ResponseEntity<Applicant> response = restService
        .patchExchange(url, HttpMethod.PATCH, createPatchHeaders(agreementsAndDisclaimers), Applicant.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.APPLICANT_DETAILS_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public List<MarketingPreference> getCustomerMarketingPreferences(String customerId, String referenceNumber) {
    String url = StringUtils
        .join(marketingPreferenceBaseUrl, marketingPreferencePath.replaceFirst("\\{customerId}", customerId), "?referenceNumber=",
            referenceNumber);
    ResponseEntity<List<MarketingPreference>> response = restService
        .exchange(url, HttpMethod.GET, createHeaders(), new ParameterizedTypeReference<List<MarketingPreference>>() {
        });
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.MARKETING_PREFERENCES_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public UpdateMarketingPreferencesResponse updateCustomerMarketingPreferences(String customerId,
      UpdateMarketingPreferences updateMarketingPreferences) {
    String url = StringUtils.join(marketingPreferenceBaseUrl, marketingPreferencePath.replaceFirst("\\{customerId}", customerId));
    ResponseEntity<UpdateMarketingPreferencesResponse> response = restService
        .exchange(url, HttpMethod.PUT, createHeaders(updateMarketingPreferences), UpdateMarketingPreferencesResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.MARKETING_PREFERENCES_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public GmsStatusResponse getGmsApplicationStatus(String accountNumber, String mortSeqNumber) {
    String url = StringUtils.join(adboServiceBaseUrl, accountStagePath, "/", mortSeqNumber, "/", accountNumber);
    ResponseEntity<GmsStatusResponse> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
        GmsStatusResponse.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.ACCOUNT_NOT_FOUND));
    return response.getBody();
  }

  @Override
  public CaseDetailsDto getIsPaymentMadeFlag(String caseId) {
    String url = StringUtils.join(caseAdboBaseUrl, casePath.replaceFirst("\\{caseId}", caseId));
    ResponseEntity<CaseDetailsDto> response = restService
        .exchange(url, HttpMethod.GET, createHeaders(), CaseDetailsDto.class);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.CASE_DETAILS_NOT_FOUND));
    return response.getBody();

  }

  @Override
  public AdboSwitchRepaymentResponse getAdboSwitchMonthlyPayments(AdboSwitchRepaymentRequest request) {
    log.info("Making call to productSwitchRepaymentCalculatorService with request: {}", request);
    String url = StringUtils.join(productSwitchRepaymentCalculatorBaseUrl, productSwitchRepaymentCalculatorReqPath);
    ResponseEntity<AdboSwitchRepaymentResponse> response = restService.exchange(url, HttpMethod.POST,
        createHeaders(request), AdboSwitchRepaymentResponse.class);
    log.info("Response from productSwitchRepaymentCalculatorService is: {}", response);
    throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.PRODUCT_SWITCH_REPAYMENT_CALCULATOR_NOT_FOUND));
    return response.getBody();
  }

  private List<CoreCustomerSummaryResponse> getCoreCustomers(List<String> cins, List<CustomerSummaryResponse> customerSummaryResponses) {

    try {
      List<CoreCustomerSummaryResponse> responses = new ArrayList<>();
      for (String cin : cins) {
        String url = StringUtils.join(customerServiceBaseUrl, "/core-customer/", cin);
        ResponseEntity<CoreCustomerSummaryResponse> response = restService.exchange(url, HttpMethod.GET, createHeaders(),
            CoreCustomerSummaryResponse.class);
        throwExceptionIfNotSuccess(response, ImmutableMap.of(NOT_FOUND, Constants.BORROWER_NOT_FOUND));
        //only if response is 200.
        response.getBody().setCin(cin);
        for (CustomerSummaryResponse customerResponse : customerSummaryResponses) {
          if (cin.equals(customerResponse.getCin())) {
            response.getBody().setGmsTitle(customerResponse.getTitle());
            response.getBody().setAcctHolderPosition(customerResponse.getAcctHolderPosition());
            response.getBody().setGmsId(customerResponse.getGmsId());
            response.getBody().setHasGuarantor(customerResponse.isHasGuarantor());
            response.getBody().setGmsMaritalStatus(customerResponse.getMaritalStatus());
            responses.add(response.getBody());
          }
        }
      }
      return responses;
    } catch (Exception e) {
      if (mockCoreCustomerResponse) {
        return getMockDataForCoreCustomerResponse(cins);
      }
      throw e;
    }
  }

  private List<CoreCustomerSummaryResponse> getMockDataForCoreCustomerResponse(List<String> cins) {
    List<CoreCustomerSummaryResponse> mockResponseList = new ArrayList<>();
    int acctHolderPosition = 0;
    for (String cin : cins) {
      acctHolderPosition++;
      CoreCustomerSummaryResponse mockResponse = CoreCustomerSummaryResponse.builder().firstName("test").lastName("test")
          .dateOfBirth("1965-12-21").email("test@natwest.com").gender("F").gmsId("123456").
          countryOfResidence("GB").middleNames(List.of("test")).mobileNumber("07789563214").nationality("GB").gmsTitle(Title.MRS)
          .hasGuarantor(false).gmsMaritalStatus(
              MaritalStatus.SINGLE)
          .customerAddress(CustomerAddress.builder().addressLine1("YKL UDKGB LKDQLCSAGM XJMZ").addressLine2("SBSCDN").addressLine3("FDTEZNHFMXX,UJXJLCMTG").postCode("GU1 4BB").build())
          .build();
      mockResponse.setCin(cin);
      mockResponse.setAcctHolderPosition(acctHolderPosition);
      mockResponseList.add(mockResponse);
    }
    return mockResponseList;
  }


  private HttpEntity<?> createHeaders() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    headers.add(Headers.BRAND, TenantProvider.getCurrentBrand().getName());
    return new HttpEntity<>(headers);
  }

  private <T> HttpEntity<T> createHeaders(T request, String... additionalHeaders) {
    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    headers.add(Headers.BRAND, TenantProvider.getCurrentBrand().getName());
    for (int i = 0; i < additionalHeaders.length; i++) {
      headers.add(additionalHeaders[i], additionalHeaders[++i]);
    }
    return new HttpEntity<>(request, headers);
  }

  private <T> HttpEntity<T> createPatchHeaders(T request, String... additionalHeaders) {
    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, Headers.MEDIA_TYPE_APPLICATION_JSON_PATCH_JSON_VALUE);
    headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    headers.add(Headers.BRAND, TenantProvider.getCurrentBrand().getName());
    for (int i = 0; i < additionalHeaders.length; i++) {
      headers.add(additionalHeaders[i], additionalHeaders[++i]);
    }
    return new HttpEntity<>(request, headers);
  }

  private HttpEntity<?> createVulnerableProfileRequest(String cin) {
    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    headers.add(Headers.BRAND, TenantProvider.getCurrentBrand().getName());
    headers.add(Constants.JOURNEY, "adbo");
    return new HttpEntity<>(new VulnerabilityRequest(cin), headers);
  }

  private void throwExceptionIfNotSuccess(ResponseEntity<?> response, Map<HttpStatus, String> errorMessageKeys) {
    throwExceptionIfNotSuccess(response, NOT_ERRORS_SET, errorMessageKeys);
  }

  private void throwExceptionIfNotSuccess(ResponseEntity<?> response, EnumSet<HttpStatus> successStatuses,
      Map<HttpStatus, String> errorMessageKeys) {
    if (response == null || !successStatuses.contains(response.getStatusCode())) {
      HttpStatusCode httpStatus = response == null ? INTERNAL_SERVER_ERROR : response.getStatusCode();
      throw new BusinessException(errorMessageKeys.getOrDefault(httpStatus, Constants.INTERNAL_SERVER_ERROR), httpStatus.value());
    }
  }


}
