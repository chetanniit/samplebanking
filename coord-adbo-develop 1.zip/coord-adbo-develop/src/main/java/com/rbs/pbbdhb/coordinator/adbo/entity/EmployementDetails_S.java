package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class EmployementDetails_S {

  private Integer yearsEstablished;
  private Integer monthsEstablished;
  private String companyName;
  private String employmentStatus;

}
