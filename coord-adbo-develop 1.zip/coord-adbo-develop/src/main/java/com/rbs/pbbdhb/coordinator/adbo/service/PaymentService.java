package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.response.PaymentUrlResponse;


public interface PaymentService {

  PaymentUrlResponse getAdboPaymentUrl(String accountNumber);

}