package com.rbs.pbbdhb.coordinator.adbo.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.AdditionalBorrowingSubmitControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingSubmitRequest;
import com.rbs.pbbdhb.coordinator.adbo.service.AdditionalBorrowingSubmitService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@Slf4j
@RequiredArgsConstructor
public class AdditionalBorrowingSubmitController implements AdditionalBorrowingSubmitControllerSwagger {

  private final AdditionalBorrowingSubmitService additionalBorrowingSubmitService;

  @GetMapping(value = "/products/selected-product", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<Product> getSelectedProduct(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Valid @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getSelectedProduct start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<Product> productResponseEntity = new ResponseEntity<>(additionalBorrowingSubmitService.getSelectedProduct(accountNumber), HttpStatus.OK);
    log.info("getSelectedProduct end with response {} account_number: {}, brand: {}, channel: {}",productResponseEntity.getBody(), accountNumber, brand, channelRoute);
    return productResponseEntity;
  }

  @PostMapping(value = "/additional-borrow-submit", consumes = APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveAdditionalBorrowingSubmit(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final AdditionalBorrowingSubmitRequest additionalBorrowingSubmitRequest) {
    log.info("saveAdditionalBorrowingSubmit start - Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand,
        channelRoute, additionalBorrowingSubmitRequest);
    TenantProvider.applyBrand(brand);
    additionalBorrowingSubmitService.saveAdditionalBorrowingSubmit(accountNumber, additionalBorrowingSubmitRequest);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveAdditionalBorrowingSubmit end's with response {}, account_number: {} brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }


}


