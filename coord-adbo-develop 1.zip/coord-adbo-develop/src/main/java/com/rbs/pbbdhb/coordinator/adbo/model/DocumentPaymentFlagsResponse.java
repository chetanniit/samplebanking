package com.rbs.pbbdhb.coordinator.adbo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentPaymentFlagsResponse {

  private Boolean enableDocUpload = false;
  private Boolean enablePayment = false;
}
