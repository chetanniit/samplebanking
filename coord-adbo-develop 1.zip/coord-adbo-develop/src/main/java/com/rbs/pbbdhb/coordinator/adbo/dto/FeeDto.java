package com.rbs.pbbdhb.coordinator.adbo.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.enums.FeeAction;
import com.rbs.pbbdhb.coordinator.adbo.enums.FeePaymentType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * Model representing GMS ProductResult Fee
 */
@Setter
@Getter
public class FeeDto {

  private FeeAction feeAction;
  private String feeCode;
  private String type;
  private BigDecimal feeAmount;
  private Boolean isPaymentMade;
  private String orderId;
  @JsonFormat(pattern = Constants.DATE_TIME_PATTERN)
  private LocalDateTime paidDate;
  private FeePaymentType feePaymentType;
}