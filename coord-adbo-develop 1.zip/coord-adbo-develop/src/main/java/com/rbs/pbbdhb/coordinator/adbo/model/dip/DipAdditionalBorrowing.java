package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigInteger;
import java.util.Set;
import jakarta.validation.constraints.Max;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Singular;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
@Builder
public class DipAdditionalBorrowing {

  public static final boolean DEFAULT_REPAYMENT_VEHICLE = false;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final boolean repaymentVehicle;

  @Max(9999)
  private final Integer termYears;

  @Max(99)
  private final Integer termMonths;

  private final BigInteger repaymentCurrentValue;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean existMortgBf20Sep2015;

  @Singular
  private final Set<DipDetails> details;

  @Singular
  private final Set<DipSubAccount> subAccounts;

}

