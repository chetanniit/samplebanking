package com.rbs.pbbdhb.coordinator.adbo.response;

import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Builder
@ToString
@EqualsAndHashCode
public class AdditionalBorrowingWithSwitchResponse {

  private Boolean eligibleToSwitch;
  private Boolean additionalBorrowingWithSwitch;
  private List<SubAccount> subAccounts;
}
