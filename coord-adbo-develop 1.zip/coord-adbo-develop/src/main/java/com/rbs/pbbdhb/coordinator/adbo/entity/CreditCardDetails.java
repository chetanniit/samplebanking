package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.rbs.pbbdhb.coordinator.adbo.enums.BankName;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
@EqualsAndHashCode
public class CreditCardDetails  {

  /**
   * which bank provided the credit card
   */
  private BankName cardProvider;

  /**
   * current balance on this card
   */
  private BigDecimal currentBalance;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnCurrentBalance;

  /**
   * If the bank is not available in the dropdown list, Then User has to provide the credit card provider name not more than 30 characters
   */
  private String other;


  /**
   * Is this fully paid off every month
   */
  private Boolean isPaidOffEveryMonth;


  /**
   * Outgoings Owner
   */
  @NotNull(message = "Owner type cannot be null")
  private OutgoingsOwnerType owner;

}
