package com.rbs.pbbdhb.coordinator.adbo.model.account;

import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TrueBalanceResponse extends BaseResponse {

  private static final long serialVersionUID = -7104406515953888708L;
  private String accountNo;
  private List<TrueBalance> trueBalances;
}
