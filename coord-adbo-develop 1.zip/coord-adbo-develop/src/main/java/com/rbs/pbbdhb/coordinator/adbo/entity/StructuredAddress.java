package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StructuredAddress  {

  private String flatNumber;

  private String propertyName;

  private String propertyNumber;

  private String town;

  private String street;

  private String county;

  private String country;

  private String countryIsoCode;

  private String postcode;

}