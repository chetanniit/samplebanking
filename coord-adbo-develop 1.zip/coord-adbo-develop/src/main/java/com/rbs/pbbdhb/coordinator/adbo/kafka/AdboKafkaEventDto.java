package com.rbs.pbbdhb.coordinator.adbo.kafka;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import lombok.Builder;
import lombok.Data;
import lombok.With;
import lombok.extern.jackson.Jacksonized;

@Data
@With
@Builder
@Jacksonized
public class AdboKafkaEventDto {

  private final String channel;
  private final String journey;
  private final String brandName;
  private final String topicName;
  private final AdboCaseDetails adboCaseDetails;
}
