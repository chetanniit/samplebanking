package com.rbs.pbbdhb.coordinator.adbo.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@ToString
@EqualsAndHashCode
public class JointApplicantEmailUpdateRequest  {

  @Email(regexp = "^[^\\s!£#$%^&*(){}+=\\[\\]:;|<>?/~`,@]+@[^\\s!£#$%^&*(){}+=\\[\\]:;|<>?/~`,@]+\\.[^\\s!£#$%^&*(){}+=\\[\\]:;|<>?/~`,@]+$", message = "Wrong email format")
  @Size(max = 45, message = "The email address should be no longer than 45 characters")
  @NotNull(message = "email must not be null")
  private String email;
}
