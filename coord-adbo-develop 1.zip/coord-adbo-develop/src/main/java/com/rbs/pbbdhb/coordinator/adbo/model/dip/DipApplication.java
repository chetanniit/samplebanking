package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.Singular;

/**
 * Decision in principle input
 */
@Data
@Builder
public class DipApplication {

  public static final String DEFAULT_APPLICATION_TYPE = "ADDITIONAL_BORROWING";
  public static final String DEFAULT_BUYER_TYPE = "EXISTING_CUSTOMER";
  public static final String DEFAULT_LOAN_PURPOSE = "ADDITIONAL_BORROWING";
  public static final String DEFAULT_CHANNEL = "INTERNET";
  public static final boolean DEFAULT_GOVT_SHARED_EQUITY_SCHEME = false;
  private final DipAdditionalBorrowing additionalBorrowing;
  private final DipMortgage mortgage;
  @Singular
  private final List<DipApplicant> applicants;
  private final DipProperty property;
  private String applicationType;
  private String loanPurpose;
  private String buyerType;
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private boolean govtSharedEquityScheme;
  private String dipId;
  private Integer numberOfDependantsOver18;
  private Integer numberOfDependantsUnder18;
  private String channel;
  private String gmsReferenceNumber;


}

