package com.rbs.pbbdhb.coordinator.adbo.client;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.INTERNAL_SERVER_ERROR;

import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.model.ValidateAccountRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.ValidateAccountResult;
import com.rbs.pbbdhb.coordinator.adbo.service.RestService;
import com.rbs.pbbdhb.exception.BusinessException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;

@Component
@Slf4j
public class ValidateAccountClient {

  private static final String VALIDATE_ACCOUNT_ERROR = "validate account error";

  private final String directDebitServiceBaseUrl;
  private final String directDebitServiceRequestPath;
  private final String clientId;
  private final RestService restService;

  public ValidateAccountClient(
      @Value("${msvc.direct-debit.service.base.url}") String directDebitServiceBaseUrl,
      @Value("${msvc.direct-debit.service.request.path}") String directDebitServiceRequestPath,
      @Value("${client.id}") String clientId,
      RestService restService) {
    this.directDebitServiceBaseUrl = directDebitServiceBaseUrl;
    this.directDebitServiceRequestPath = directDebitServiceRequestPath;
    this.clientId = clientId;
    this.restService = restService;
  }

  public static HttpHeaders constructHeaders(final String brand) {
    final HttpHeaders headers = new HttpHeaders();
    headers.add(Headers.BRAND, brand);
    return headers;
  }

  public static HttpHeaders constructHeadersForJsonRequest(final String brand) {
    final HttpHeaders headers = constructHeaders(brand);
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }

  public ValidateAccountResult validateAccount(String brand, ValidateAccountRequest bankDetails) {
    log.info("Calling {} to check bank details", directDebitServiceBaseUrl);

    HttpHeaders headers = constructHeadersForJsonRequest(brand);
    headers.add("client_id", clientId);
    String url = StringUtils.join(directDebitServiceBaseUrl, directDebitServiceRequestPath);
    ValidateAccountResult results = restService.exchange(
        url,
        HttpMethod.POST,
        new HttpEntity<>(bankDetails, headers),
        ValidateAccountResult.class).getBody();

    handleErrorAndException(results);

    return results;
  }

  public void handleErrorAndException(ValidateAccountResult results) {
    if (results == null) {
      throw new BusinessException(INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
    if (results.getErrors() != null) {
      List<String> errors = results.getErrors();
      if (!errors.isEmpty()) {
        throw HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
            new HttpHeaders(),
            (VALIDATE_ACCOUNT_ERROR + ": " + String.join("; ", errors)).getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
      }
    }
  }
}
