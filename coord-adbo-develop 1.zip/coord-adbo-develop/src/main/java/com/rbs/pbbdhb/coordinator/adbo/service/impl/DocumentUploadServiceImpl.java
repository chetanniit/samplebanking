package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.createRequestEntity;
import static java.util.Objects.isNull;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.OK;

import com.google.common.collect.Lists;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.mapper.AuthTokenMapper;
import com.rbs.pbbdhb.coordinator.adbo.request.AuthTokenRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AuthTokenResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.DocumentsUploadURLResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.DocumentUploadService;
import com.rbs.pbbdhb.coordinator.adbo.service.RestService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.Brand;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DocumentUploadServiceImpl implements DocumentUploadService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final AuthTokenMapper authTokenMapper;
  private final RestService restService;
  @Value("${auth.service.base.url}")
  private String authServiceBaseUrl;
  @Value("${auth.service.xotoken.request.path}")
  private String authServiceXoTokenPath;
  @Value("${document.upload.url}")
  private String documentUploadURL;
  @Value("${rbs.document.upload.url}")
  private String rbsDocumentUploadURL;

  public DocumentUploadServiceImpl(AdboCaseDetailsDao adboCaseDetailsDao, AuthTokenMapper authTokenMapper,
      RestService restService) {
    this.adboCaseDetailsDao = adboCaseDetailsDao;
    this.authTokenMapper = authTokenMapper;
    this.restService = restService;
  }

  @Override
  public DocumentsUploadURLResponse getDocUploadUrl(String accountNumber, String cin, String brand) {
    log.info("getDocUploadUrl started for accountNumber : {}", accountNumber);
    AdboCaseDetails caseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);

    Optional<AdboApplicant> applicant = caseDetails.getAdboApplicants()
        .values()
        .stream()
        .filter(adboApplicant -> cin.equalsIgnoreCase(adboApplicant.getCin()))
        .findFirst();

    checkValidApplicant(caseDetails.getCaseId(), applicant, accountNumber);
    AuthTokenRequest authRequest = authTokenMapper.xoAuthTokenRequest(caseDetails, applicant.get().getApplicantId(),
        applicant.get().getCin());
    String url = StringUtils.join(authServiceBaseUrl, authServiceXoTokenPath);
    ResponseEntity<AuthTokenResponse> authResponse =
        restService.exchange(url, HttpMethod.POST, createRequestEntity(authRequest),
            AuthTokenResponse.class);
    checkAndThrowExceptionOnError(authResponse, accountNumber);

    log.info("getDocUploadUrl token : {}", authResponse.getBody().getAccessToken());
    String brandSpecificDocumentUploadURL = documentUploadURL;
    if (Brand.RBS.getName().equalsIgnoreCase(brand)) {
      brandSpecificDocumentUploadURL = rbsDocumentUploadURL;
    }
    return DocumentsUploadURLResponse.builder().documentUploadURL(String.format(brandSpecificDocumentUploadURL,
        authResponse.getBody().getAccessToken())).build();
  }

  private void checkValidApplicant(String caseId, Optional<AdboApplicant> applicant, String accountNumber) {

    if (isNull(caseId) || !applicant.isPresent() || isNull(applicant.get().getApplicantId())) {
      log.info("Account is not available to proceed further on the journey {}", accountNumber);
      throw new BusinessException(Constants.ACCOUNT_NOT_ELIGIBLE, HttpStatus.BAD_REQUEST.value());
    }
  }

  private void checkAndThrowExceptionOnError(ResponseEntity<AuthTokenResponse> response, String accountNumber) {

    if (isNull(response) || !Lists.newArrayList(CREATED, OK).contains(response.getStatusCode())) {
      HttpStatusCode httpStatus = isNull(response) ? INTERNAL_SERVER_ERROR : response.getStatusCode();
      log.error("Error getting token for Account : {}, status : {}", accountNumber, httpStatus);
      throw new BusinessException(Constants.ACCOUNT_TOKEN_ERROR, httpStatus.value());
    }
  }

}