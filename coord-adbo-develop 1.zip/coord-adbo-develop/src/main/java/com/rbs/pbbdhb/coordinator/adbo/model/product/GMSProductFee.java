package com.rbs.pbbdhb.coordinator.adbo.model.product;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model representing GMS ProductResult Fee
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class GMSProductFee {

  private String code;
  private String type;
  private Double amount;
}