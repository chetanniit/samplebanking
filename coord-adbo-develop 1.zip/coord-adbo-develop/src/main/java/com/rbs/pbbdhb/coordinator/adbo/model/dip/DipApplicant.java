package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.List;
import java.util.Set;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Singular;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
@Builder
public class DipApplicant {

  @NotNull
  private final DipPersonalDetails personalDetails;

  @Singular
  private final Set<DipAddress> addresses;

  @NotNull
  private final WorkStatusEnum workStatus;

  private final Integer intendedRetirementAge;

  private final DipEmployment employment;

  @Singular
  private final List<DipOtherIncome> otherIncomes;

  @Singular
  private final Set<ExistingMortgage> existingMortgages;

  @Singular
  private final List<DipCreditCard> creditCards;

  @Singular
  private final List<DipLoan> loans;

  @Singular
  private final List<DipFinancialCommitment> financialCommitments;

  private final DipBankDetails mainBankDetails;

  @NotNull
  private final DipCreditHistory creditHistory;

  private final String cin;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean consentToDIP;

  public enum WorkStatusEnum {
    WORKING,
    NOT_WORKING
  }

}
