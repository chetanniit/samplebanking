package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.NewAdditionalProperty;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.HomeImprovement;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.PropertyPurchase;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.PropertyType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.Address;
import com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose.BorrowingPurposeResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.BorrowingPurposeService;
import com.rbs.pbbdhb.coordinator.adbo.validator.BorrowingAmountValidator;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BorrowingPurposeServiceImpl implements BorrowingPurposeService {

  private static final Map<Predicate<AdboAmountDistribution>, Consumer<AdboApplicant>> UNSET_IF_NOT_SELECTED
      = new HashMap<Predicate<AdboAmountDistribution>, Consumer<AdboApplicant>>() {{
    put(BorrowingPurposeServiceImpl::livingElsewhere, BorrowingPurposeServiceImpl::unsetLivingElsewhereCost);
    put(BorrowingPurposeServiceImpl::additionalPropertyWithMortgage, BorrowingPurposeServiceImpl::unsetAdditionalPropertyMortgagePayment);
    put(BorrowingPurposeServiceImpl::residentialAdditionalProperty, BorrowingPurposeServiceImpl::unsetAdditionalProperty);
    put(BorrowingPurposeServiceImpl::buyToLetAdditionalProperty, BorrowingPurposeServiceImpl::unsetAdditionalProperty);
    put(BorrowingPurposeServiceImpl::additionalProperty, BorrowingPurposeServiceImpl::unsetAdditionalProperty);
  }};

  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final BorrowingAmountValidator borrowingAmountValidator;
  private final ApiService apiService;

  private static boolean livingElsewhere(AdboAmountDistribution adboAmountDistribution) {
    if (adboAmountDistribution.getType() == BorrowingPurposeType.HOME_IMPROVEMENT) {
      HomeImprovement homeImprovement = (HomeImprovement) adboAmountDistribution;
      return isTrue(homeImprovement.getLivingElseWhereMoreThan6Months());
    }
    return false;
  }

  private static void unsetLivingElsewhereCost(AdboApplicant applicant) {
    OutgoingPaymentsDetails outgoingPaymentsDetails = applicant.getOutgoingPaymentsDetails();
    if (outgoingPaymentsDetails != null) {
      outgoingPaymentsDetails.setMonthlyLivingElseWhereAmount(null);
      outgoingPaymentsDetails.setApplicantShareOnMonthlyLivingElseWhereAmount(null);
    }
  }

  private static boolean additionalProperty(AdboAmountDistribution adboAmountDistribution) {
    return adboAmountDistribution.getType() == BorrowingPurposeType.PURCHASE_ADDITIONAL_PROPERTY;
  }

  private static boolean additionalPropertyWithMortgage(AdboAmountDistribution adboAmountDistribution) {
    if (additionalProperty(adboAmountDistribution)) {
      PropertyPurchase propertyPurchase = (PropertyPurchase) adboAmountDistribution;
      return isTrue(propertyPurchase.getAnotherMortgage());
    }
    return false;
  }

  private static void unsetAdditionalPropertyMortgagePayment(AdboApplicant applicant) {
    OutgoingPaymentsDetails outgoingPaymentsDetails = applicant.getOutgoingPaymentsDetails();
    if (outgoingPaymentsDetails != null) {
      NewAdditionalProperty newAdditionalProperty = outgoingPaymentsDetails.getNewAdditionalProperty();
      if (newAdditionalProperty != null) {
        newAdditionalProperty.setNewMortgageMonthlyPayment(null);
        newAdditionalProperty.setApplicantShareOnNewMortgageMonthlyPayment(null);
      }
    }
  }

  private static boolean residentialAdditionalProperty(AdboAmountDistribution adboAmountDistribution) {
    if (additionalProperty(adboAmountDistribution)) {
      PropertyPurchase propertyPurchase = (PropertyPurchase) adboAmountDistribution;
      return propertyPurchase.getPropertyType() == PropertyType.RESIDENTIAL;
    }
    return false;
  }

  private static boolean buyToLetAdditionalProperty(AdboAmountDistribution adboAmountDistribution) {
    if (additionalProperty(adboAmountDistribution)) {
      PropertyPurchase propertyPurchase = (PropertyPurchase) adboAmountDistribution;
      return propertyPurchase.getPropertyType() == PropertyType.BUY_TO_LET;
    }
    return false;
  }

  private static void unsetAdditionalProperty(AdboApplicant applicant) {
    OutgoingPaymentsDetails outgoingPaymentsDetails = applicant.getOutgoingPaymentsDetails();
    if (outgoingPaymentsDetails != null) {
      outgoingPaymentsDetails.setNewAdditionalProperty(null);
    }
  }

  @Override
  public void saveBorrowingPurpose(String accountNumber, List<AdboAmountDistribution> borrowingPurposeRequest) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    if (adboCaseDetails != null && adboCaseDetails.getAdditionalBorrowingCalculator() != null) {
      borrowingAmountValidator.validateAmount(adboCaseDetails, borrowingPurposeRequest);
    }
    if (adboCaseDetails.getAdditionalBorrowingCalculator() == null) {
      log.error("accountNumber : {}, additionalBorrowingCalculatorEntity is null", accountNumber);
      adboCaseDetails.setAdditionalBorrowingCalculator(new AdditionalBorrowingCalculator());
    }
    List<AdboAmountDistribution> oldBorrowingPurposeRequest = adboCaseDetails.getAdditionalBorrowingCalculator()
        .getAdboAmountDistributions();
    if (nonNull(oldBorrowingPurposeRequest)) {
      clearNotExistingBorrowingPurposeData(adboCaseDetails.getAdboApplicants().values(),
          borrowingPurposeRequest, oldBorrowingPurposeRequest);
    }
    adboCaseDetails.getAdditionalBorrowingCalculator().setAdboAmountDistributions(borrowingPurposeRequest);
    adboCaseDetailsDao.save(adboCaseDetails);
  }

  @Override
  public BorrowingPurposeResponse getBorrowingPurpose(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    if (adboCaseDetails.getAdditionalBorrowingCalculator() == null) {
      throw new BusinessException(Constants.VALID_APP_DETAILS_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    return BorrowingPurposeResponse.builder()
        .propertyAddress1(Optional.ofNullable(apiService.getAccount(accountNumber))
            .map(AccountSummaryResponse::getAddress)
            .map(Address::getAddress1)
            .orElse(null))
        .totalBorrowingAmount(adboCaseDetails.getAdditionalBorrowingCalculator().getBorrowingAmount())
        .borrowingPurposeDetails(adboCaseDetails.getAdditionalBorrowingCalculator().getAdboAmountDistributions())
        .build();
  }

  private void clearNotExistingBorrowingPurposeData(Collection<AdboApplicant> applicants,
      List<AdboAmountDistribution> adboAmountDistributions, List<AdboAmountDistribution> oldAdboAmountDistributions) {
    UNSET_IF_NOT_SELECTED.forEach((isSelected, unset) -> {
      if (oldAdboAmountDistributions.stream().anyMatch(isSelected)) {
        if (adboAmountDistributions.stream().noneMatch(isSelected)) {
          for (AdboApplicant applicant : applicants) {
            unset.accept(applicant);
          }
        }
      }
    });
  }

}
