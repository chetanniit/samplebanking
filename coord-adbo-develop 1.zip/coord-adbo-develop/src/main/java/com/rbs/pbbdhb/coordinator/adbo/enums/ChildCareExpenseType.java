package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum ChildCareExpenseType {
  NURSERY("NURSERY"), CHILD_MINDER("CHILD_MINDER"), DAILY_NANNY("DAILY_NANNY"), LIVE_IN_NANNY("LIVE_IN_NANNY"), AU_PAIR(
      "AU_PAIR"), PLAY_GROUP_OR_PRE_SCHOOL("PLAY_GROUP_OR_PRE_SCHOOL"), BREAKFAST_AFTER_SCHOOL_CLUBS(
      "BREAKFAST_AFTER_SCHOOL_CLUBS"), HOLIDAY_CLUBS("HOLIDAY_CLUBS"), OTHER("OTHER");
  private final String type;

  ChildCareExpenseType(String type) {
    this.type = type;
  }

  public String getExpenseType() {
    return type;
  }

}
