package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.math.BigDecimal;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipIncome {

  private final TypeEnum type;

  private final FrequencyEnum frequency;

  private final BigDecimal amount;

  public enum TypeEnum {
    BASIC_EARNINGS,
    BONUS_GUARANTEED_PAID_MONTHLY,
    BONUS_GUARANTEED_PAID_QUARTERLY,
    BONUS_GUARANTEED_PAID_BI_ANNUALLY,
    BONUS_GUARANTEED_PAID_ANNUALLY,
    OVERTIME_GUARANTEED,
    COMMISSION_GUARANTEED,
    SHIFT_ALLOWANCE_GUARANTEED,
    BONUS_DISCRETIONARY_PAID_MONTHLY,
    BONUS_DISCRETIONARY_PAID_QUARTERLY,
    BONUS_DISCRETIONARY_PAID_BI_ANNUALLY,
    BONUS_DISCRETIONARY_PAID_ANNUALLY,
    OVERTIME_REGULAR,
    COMMISSION_REGULAR,
    SHIFT_ALLOWANCE_REGULAR,
    PROFIT_SHARE,
    DIVIDEND,
    CAR_ALLOWANCE,
    MORTGAGE_SUBSIDY
  }

  public enum FrequencyEnum {
    ANNUALLY,
    BIANNUALLY,
    QUARTERLY,
    MONTHLY,
    WEEKLY,
    FORTNIGHTLY,
    FOUR_WEEKLY
  }
}
