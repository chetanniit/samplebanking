package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import java.util.Objects;
import java.util.regex.Pattern;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class CinValidator implements ConstraintValidator<CIN, String> {

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {

    if (Objects.nonNull(value)) {
      return Pattern.compile("\\d{10}").matcher(value).matches();
    }

    return false;
  }
}
