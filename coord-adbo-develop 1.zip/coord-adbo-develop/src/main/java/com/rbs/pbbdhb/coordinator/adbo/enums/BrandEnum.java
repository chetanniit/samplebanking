package com.rbs.pbbdhb.coordinator.adbo.enums;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Gets or Sets brand
 */
public enum BrandEnum {
  RBS("RBS"),

  NWB("NWB");

  private final String value;

  BrandEnum(String value) {
    this.value = value;
  }

  @JsonCreator
  public static BrandEnum fromValue(String value) {
    for (BrandEnum b : BrandEnum.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }
}