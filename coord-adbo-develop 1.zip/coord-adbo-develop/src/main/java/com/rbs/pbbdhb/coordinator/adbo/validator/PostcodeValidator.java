package com.rbs.pbbdhb.coordinator.adbo.validator;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.POSTCODE_WRONG_FORMAT;

import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.enums.GmsCodeToCountryIso;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Component
public class PostcodeValidator {

  private static final String REGEX = "^(([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?)))) [0-9][A-Za-z]{2}$";

  public void validatePostcode(List<Address> previousAddresses) {
    if (CollectionUtils.isEmpty(previousAddresses)) {
      return;
    }
    Boolean isInvalidPostcode = previousAddresses.stream()
        .filter(address -> GmsCodeToCountryIso.BRIT.getCountryIsoCode().equals(address.getCountry()))
        .anyMatch(address -> StringUtils.isBlank(address.getPostcode())
            || !(Pattern.compile(REGEX).matcher(address.getPostcode()).find()));
    if (isInvalidPostcode) {
      throw new BusinessException(POSTCODE_WRONG_FORMAT, HttpStatus.BAD_REQUEST.value());
    }
  }
}