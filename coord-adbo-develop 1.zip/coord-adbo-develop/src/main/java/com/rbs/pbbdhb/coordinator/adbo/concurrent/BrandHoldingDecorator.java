package com.rbs.pbbdhb.coordinator.adbo.concurrent;

import static java.lang.Thread.currentThread;
import static java.util.Arrays.stream;

import com.rbs.pbbdhb.coordinator.adbo.configuration.BrandContextHolder;
import java.util.function.Function;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class BrandHoldingDecorator {

  private BrandHoldingDecorator() {
  }

  public static <V> Supplier<V> addBrandContext(Supplier<V> callable) {
    Function<Void, V> function = addBrandContext(o -> callable.get());
    return () -> function.apply(null);
  }

  public static <S, V> Function<S, V> addBrandContext(Function<S, V> function) {
    String brand = BrandContextHolder.getCurrentBrand();
    if (brand == null && log.isDebugEnabled()) {
      log.info("Brand is null when called from {}", stream(currentThread().getStackTrace())
          .map(StackTraceElement::getMethodName)
          .filter(name -> !name.equals("getStackTrace") && !name.toLowerCase().contains("brand"))
          .findFirst()
          .orElse("{unknown}"));
    }
    return s -> {
      String previousBrand;
      try {
        previousBrand = BrandContextHolder.getCurrentBrand();
      } catch (IllegalStateException ignore) {
        previousBrand = null;
      }
      try {
        BrandContextHolder.setCurrentBrand(brand);
        return function.apply(s);
      } finally {
        BrandContextHolder.clear();
        if (previousBrand != null) {
          BrandContextHolder.setCurrentBrand(previousBrand);
        }
      }
    };
  }

}
