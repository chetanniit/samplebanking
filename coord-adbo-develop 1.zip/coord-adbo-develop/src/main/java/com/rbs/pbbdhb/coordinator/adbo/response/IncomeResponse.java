package com.rbs.pbbdhb.coordinator.adbo.response;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.BankDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.OtherIncome;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Retired;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.WorkStatus;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(onlyExplicitlyIncluded = true)
@Builder
public class IncomeResponse {

  @ToString.Include
  private final boolean fromGms;

  private final WorkStatus currentWorkStatus;

  private final List<Employment> employments;

  private final Retired retired;

  private final Boolean hasOtherIncome;

  private final List<OtherIncome> otherIncomes;

  private final boolean hasBankDetailsModified;

  private final BankDetails bankDetails;

  @ToString.Include
  private final ApplicantType applicantType;

}
