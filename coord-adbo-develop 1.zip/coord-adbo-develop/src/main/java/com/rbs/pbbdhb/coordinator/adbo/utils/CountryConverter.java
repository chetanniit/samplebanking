package com.rbs.pbbdhb.coordinator.adbo.utils;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toMap;

import java.util.Locale;
import java.util.Map;

public final class CountryConverter {

  private static final Map<String, String> COUNTRIES_ISO_BY_NAME = stream(Locale.getISOCountries())
      .map(iso -> new Locale("", iso))
      .collect(toMap(Locale::getDisplayCountry, Locale::getCountry));

  private CountryConverter() {
    // Do not instantiate
  }

  public static String isoFromCountryName(String name) {
    return COUNTRIES_ISO_BY_NAME.getOrDefault(name, "GB");
  }
}
