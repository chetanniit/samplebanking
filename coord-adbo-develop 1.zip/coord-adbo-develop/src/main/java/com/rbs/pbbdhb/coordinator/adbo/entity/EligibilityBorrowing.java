package com.rbs.pbbdhb.coordinator.adbo.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.AssertFalse;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Getter
@Setter
public class EligibilityBorrowing  {

  @Schema(name = "interestOnly", example = "false")
  @NotNull(message = "interestOnly must not be Null")
  @AssertFalse(message = "interestOnly must be False")
  private Boolean interestOnly;

  @NotNull(message = "debtConsolidation must not be Null, Should be either True or False")
  private Boolean debtConsolidation;

  private Boolean secondChargePayOff;

  private Boolean secondChargeDisclaimer;

}
