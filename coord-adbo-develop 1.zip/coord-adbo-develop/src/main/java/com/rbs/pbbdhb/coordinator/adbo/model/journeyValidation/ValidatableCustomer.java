package com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation;

public interface ValidatableCustomer {

  String getCin();

}
