package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.natwest.pbbdhb.commondictionaries.enums.applicant.Gender;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.GmsCodeToCountryIso;
import com.rbs.pbbdhb.coordinator.adbo.enums.PropertyTenure;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.TrueBalance;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CoreCustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.ValidatableCustomer;
import com.rbs.pbbdhb.coordinator.adbo.service.JourneyValidationDataMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.EnumMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.toList;

@Slf4j
@Service
public class JourneyValidationDataMapperImpl implements JourneyValidationDataMapper {

  private static final String PLUS = "+";
  private static final String ZERO = "0";
  private static final String DOUBLE_ZEROES = "00";
  private static final String DOUBLE_FOURS = "44";
  private static final String NON_DIGIT_REGEX = "\\D";

  private static void prepareNewApplicantsMap(AdboCaseDetails adboCaseDetails,
      List<CoreCustomerSummaryResponse> additionalBorrowers, String cin) {
    EnumMap<ApplicantType, AdboApplicant> adboApplicants = new EnumMap<>(ApplicantType.class);
    adboCaseDetails.setAdboApplicants(adboApplicants);
    List<ApplicantType> jointTypes = asList(ApplicantType.values());
    Stream<String> additionalCins = additionalBorrowers.stream()
        .map(ValidatableCustomer::getCin)
        .filter(additionalCin -> !additionalCin.equals(cin));
    List<String> cins = Stream.concat(Stream.of(cin), additionalCins).collect(toList());
    int size = Math.min(jointTypes.size(), cins.size());
    for (int i = 0; i < size; i++) {
      AdboApplicant applicant = new AdboApplicant();
      applicant.setCin(cins.get(i));
      for (CoreCustomerSummaryResponse customer : additionalBorrowers) {
        if (customer.getCin().equals(cins.get(i))) {
          applicant.setAcctHolderPosition(customer.getAcctHolderPosition());
        }
      }
      adboApplicants.put(jointTypes.get(i), applicant);
    }
  }

  private static AdboApplicant getAdboApplicant(AdboCaseDetails adboCaseDetails, String cin) {
    AdboApplicant adboApplicant = adboCaseDetails.getAdboApplicants().values().stream()
        .filter(applicant -> cin.equals(applicant.getCin()))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Unknown cin:" + cin + " - applicant not present before"));
    if (adboApplicant.getPersonalDetails() == null) {
      adboApplicant.setPersonalDetails(new PersonalDetails());
    }
    return adboApplicant;
  }


  @Override
  public AdboCaseDetails prepareCaseDetails(JourneyValidation journeyValidation, String accountNumber, String cin) {
    AdboCaseDetails adboCaseDetails = journeyValidation.getAdboCaseDetails();
    if (adboCaseDetails == null || (adboCaseDetails.isCreateNewRecord())) {
      adboCaseDetails = new AdboCaseDetails();
      adboCaseDetails.setAccountNumber(accountNumber);
    }
    mapApplicationDetails(adboCaseDetails, journeyValidation.getApplicationType());
    mapPersonalDetails(adboCaseDetails, journeyValidation.getCustomerSummaryApiResponses(), cin);
    storeAdditionalBorrowingCalculatorEntity(adboCaseDetails, journeyValidation);
    setDerivedSubAccountFields(adboCaseDetails, journeyValidation);
    return adboCaseDetails;
  }
  
  private void mapPersonalDetails(AdboCaseDetails adboCaseDetails, List<CoreCustomerSummaryResponse> customerSummaryApiResponse,
      String cin) {
    if (adboCaseDetails.getAdboApplicants() == null) {
      prepareNewApplicantsMap(adboCaseDetails, customerSummaryApiResponse, cin);
    }
    for (CoreCustomerSummaryResponse customer : customerSummaryApiResponse) {
      mapApplicant(adboCaseDetails, customer);
    }
  }

  private void mapApplicant(AdboCaseDetails adboCaseDetails, CoreCustomerSummaryResponse customerSummaryApiResponse) {
    AdboApplicant adboApplicant = getAdboApplicant(adboCaseDetails, customerSummaryApiResponse.getCin());
    mapPersonalDetails(customerSummaryApiResponse, adboApplicant, adboCaseDetails);
  }

  private void mapPersonalDetails(CoreCustomerSummaryResponse customerSummaryApiResponse, AdboApplicant adboApplicant,
      AdboCaseDetails adboCaseDetails) {
    PersonalDetails personalDetails = adboApplicant.getPersonalDetails();
    if (adboCaseDetails.getAdboApplicants().get(ApplicantType.MAIN).getCin().equals(adboApplicant.getCin())) {
      personalDetails.setGmsMobileNumber(formatPhoneNumber(customerSummaryApiResponse.getMobileNumber()));
      if (personalDetails.getMobileNumber() == null) {
        personalDetails.setMobileNumber(personalDetails.getGmsMobileNumber());
      }
      personalDetails.setGmsEmail(customerSummaryApiResponse.getEmail());
      if (personalDetails.getEmail() == null) {
        personalDetails.setEmail(personalDetails.getGmsEmail());
      }

    } else {
      personalDetails.setGmsMobileNumber(formatPhoneNumber(customerSummaryApiResponse.getMobileNumber()));
      personalDetails.setGmsEmail(customerSummaryApiResponse.getEmail());
    }
    personalDetails.setOtherTitle(
        Objects.equals(customerSummaryApiResponse.getGmsTitle(), Title.OTHER.toString()) ? customerSummaryApiResponse.getGmsTitle().name(): null);
    personalDetails.setTitle(customerSummaryApiResponse.getGmsTitle());
    personalDetails.setFirstName(customerSummaryApiResponse.getFirstName());
    personalDetails.setMiddleName(
        customerSummaryApiResponse.getMiddleNames() != null ? String.join(" ", customerSummaryApiResponse.getMiddleNames()) : null);
    personalDetails.setLastName(customerSummaryApiResponse.getLastName());
    personalDetails.setNationality(customerSummaryApiResponse.getNationality());
    personalDetails.setDateOfBirth(LocalDate.parse(customerSummaryApiResponse.getDateOfBirth()));
    personalDetails.setGender(customerSummaryApiResponse.getGender().equals("F") ? Gender.FEMALE : Gender.MALE);
    personalDetails.setGmsId(customerSummaryApiResponse.getGmsId());
    personalDetails.setMaritalStatus(customerSummaryApiResponse.getGmsMaritalStatus());
    personalDetails.setOriginalNationalityIsoCode(customerSummaryApiResponse.getNationality());
    if (personalDetails.getNationalityIsoCode() == null) {
      personalDetails.setNationalityIsoCode(personalDetails.getOriginalNationalityIsoCode());
    }
    personalDetails.setOriginalMaritalStatus(customerSummaryApiResponse.getGmsMaritalStatus());
    if (personalDetails.getMaritalStatus() == null) {
      personalDetails.setMaritalStatus(personalDetails.getOriginalMaritalStatus());
    }
    mapAddress(customerSummaryApiResponse, personalDetails);
  }

  private void mapAddress(CoreCustomerSummaryResponse customerSummaryApiResponse, PersonalDetails personalDetails) {

    if(isCurrentAddressNotUpdated(customerSummaryApiResponse,personalDetails)) {
      return ;
    }
      personalDetails.setCurrentAddress(new GmsAddress());
      personalDetails.getCurrentAddress().setAddress1(customerSummaryApiResponse.getCustomerAddress().getAddressLine1());
      personalDetails.getCurrentAddress().setAddress2(customerSummaryApiResponse.getCustomerAddress().getAddressLine2());
      personalDetails.getCurrentAddress().setAddress3(customerSummaryApiResponse.getCustomerAddress().getAddressLine3());
      personalDetails.getCurrentAddress().setAddress4(customerSummaryApiResponse.getCustomerAddress().getAddressLine4());
      personalDetails.getCurrentAddress().setAddress5(customerSummaryApiResponse.getCustomerAddress().getAddressLine5());
      personalDetails.getCurrentAddress().setPostcode(
              customerSummaryApiResponse.getCustomerAddress().getPostCode() != null ? StringUtils.normalizeSpace(
                      customerSummaryApiResponse.getCustomerAddress().getPostCode()) : null);
      personalDetails.getCurrentAddress()
              .setCountryCode(GmsCodeToCountryIso.fromIsoCode(customerSummaryApiResponse.getCountryOfResidence()).getCountryCode());
      personalDetails.setCurrentAddressStructuredFormat(null);
  }
  private boolean isCurrentAddressNotUpdated(CoreCustomerSummaryResponse customerSummaryApiResponse, PersonalDetails personalDetails){

    return  nonNull(personalDetails.getCurrentAddress()) &&
            StringUtils.equals(customerSummaryApiResponse.getCustomerAddress().getAddressLine1(),personalDetails.getCurrentAddress().getAddress1())
            && StringUtils.equals(customerSummaryApiResponse.getCustomerAddress().getAddressLine2(),personalDetails.getCurrentAddress().getAddress2())
            && StringUtils.equals(customerSummaryApiResponse.getCustomerAddress().getAddressLine3(),personalDetails.getCurrentAddress().getAddress3())
            && StringUtils.equals(customerSummaryApiResponse.getCustomerAddress().getAddressLine4(),personalDetails.getCurrentAddress().getAddress4())
            && StringUtils.equals(customerSummaryApiResponse.getCustomerAddress().getAddressLine5(),personalDetails.getCurrentAddress().getAddress5())
            && StringUtils.equals(customerSummaryApiResponse.getCustomerAddress().getPostCode() != null ? StringUtils.normalizeSpace(
            customerSummaryApiResponse.getCustomerAddress().getPostCode()) : null,personalDetails.getCurrentAddress().getPostcode())
            && GmsCodeToCountryIso.fromIsoCode(customerSummaryApiResponse.getCountryOfResidence()).getCountryCode().equals(personalDetails.getCurrentAddress()
            .getCountryCode());
  }
  private String formatPhoneNumber(String number) {
    if (StringUtils.isNotBlank(number)) {
      String mobileNumber = number
          .replace(PLUS, DOUBLE_ZEROES)
          .replaceAll(NON_DIGIT_REGEX, "")
          .trim();
      return mobileNumber.startsWith(ZERO) ? mobileNumber
          : mobileNumber.startsWith(DOUBLE_FOURS) ? DOUBLE_ZEROES.concat(mobileNumber) : ZERO.concat(mobileNumber);
    }
    return null;
  }

  public void storeAdditionalBorrowingCalculatorEntity(AdboCaseDetails adboCaseDetails, JourneyValidation journeyValidation) {
    if (adboCaseDetails.getAdditionalBorrowingCalculator() != null) {
      setAdditionalBorrowingDetails(adboCaseDetails, journeyValidation);
    } else {
      adboCaseDetails.setAdditionalBorrowingCalculator(new AdditionalBorrowingCalculator());
      setAdditionalBorrowingDetails(adboCaseDetails, journeyValidation);
    }
  }

  public void setAdditionalBorrowingDetails(AdboCaseDetails adboCaseDetails, JourneyValidation journeyValidation) {
    var gmsSysDate = journeyValidation.getAccountSummaryApiResponse().getSysDate();
    adboCaseDetails.setGmsSysDate(nonNull(gmsSysDate) ? gmsSysDate : LocalDateTime.now());
    adboCaseDetails.getAdditionalBorrowingCalculator().setSubAccountDetails(journeyValidation.getAccountSummaryApiResponse()
        .getSubAccounts());
    if (journeyValidation.getAccountSummaryApiResponse().getPropertyTypeCode() != null
        && journeyValidation.getAccountSummaryApiResponse().getPropertyTypeCode().equals("FL")) {
      adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyTypeCode("Flat");
    } else {
      adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyTypeCode("House");
    }
    adboCaseDetails.getAdditionalBorrowingCalculator()
        .setPropertyGmsTypeCode(nonNull(journeyValidation.getAccountSummaryApiResponse().getPropertyTypeCode()) ? journeyValidation
            .getAccountSummaryApiResponse().getPropertyTypeCode() : Constants.DEFAULT_PROPERTY_GMS_TYPE_CODE);
    if (journeyValidation.getAccountSummaryApiResponse().getPropertyYearBuilt() != null) {
      int yearBuilt = Integer.parseInt(journeyValidation.getAccountSummaryApiResponse().getPropertyYearBuilt());
      adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyYearBuilt(yearBuilt);
      int sysDateYear = journeyValidation.getAccountSummaryApiResponse().getSysDate().getYear();
      int noOfYears = sysDateYear - yearBuilt;
      if (noOfYears <= 2) {
        adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyBuiltType(Constants.NEW_BUILD);
      } else {
        adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyBuiltType(Constants.OLD_BUILD);
      }
    } else {
      adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyBuiltType(Constants.OLD_BUILD);
    }
    if (journeyValidation.getAccountSummaryApiResponse().getHpiValuationAmount() != null) {
      adboCaseDetails
          .getAdditionalBorrowingCalculator().setHpiValuation(journeyValidation.getAccountSummaryApiResponse()
              .getHpiValuationAmount());
      if(nonNull(journeyValidation.getAccountSummaryApiResponse().getHpiValuationDate())){
      adboCaseDetails.getAdditionalBorrowingCalculator().setHpiValuationDate(journeyValidation.getAccountSummaryApiResponse().getHpiValuationDate());
      }
    } else {
      adboCaseDetails.getAdditionalBorrowingCalculator().setHpiValuation(BigDecimal.ZERO);
    }
    if (journeyValidation.getAccountSummaryApiResponse().getPropertyTenureCode() != null) {
      PropertyTenure propertyTenure = PropertyTenure.getByCode(journeyValidation.getAccountSummaryApiResponse().getPropertyTenureCode());
      adboCaseDetails.getAdditionalBorrowingCalculator().setPropertyTenure(propertyTenure);
    }

  }

  public void setDerivedSubAccountFields(AdboCaseDetails adboCaseDetails, JourneyValidation journeyValidation) {

    List<TrueBalance> trueBalances = journeyValidation.getTrueBalance().getTrueBalances();
    BigDecimal totalTrueBalanceAmount = trueBalances.stream().map(TrueBalance::getTrueBalance)
        .reduce(BigDecimal.ZERO, BigDecimal::add).setScale(0, RoundingMode.UP);
    adboCaseDetails.getAdditionalBorrowingCalculator().setTotalTrueBalance(totalTrueBalanceAmount);
    for (SubAccount subAccount : adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails()) {
      for (TrueBalance trueBalance : trueBalances) {
        if (subAccount.getSubAccountNumber().toString().equals(trueBalance.getSubAccNo())) {
          subAccount.setTrueBalance(trueBalance.getTrueBalance().setScale(0, RoundingMode.UP));
        }
      }
      subAccount.setProductTerm(calculateDiffInYears(subAccount.getDealStartDate(), subAccount.getCurrentDealEnds()));
    }
  }

  private Integer calculateDiffInYears(LocalDate startDate, LocalDate endDate) {
    return isNull(startDate) || isNull(endDate) ? null : (int) ChronoUnit.YEARS.between(startDate, endDate);
  }

  private void mapApplicationDetails(AdboCaseDetails adboCaseDetails, ApplicationType applicationType) {
    adboCaseDetails.setNorthernIrelandApplication(applicationType.isNorthernIrelandApplication());
    adboCaseDetails.setScottishApplication(applicationType.isScottishApplication());
  }
}
