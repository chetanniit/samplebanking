package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Packaging {

  private String app1PaySlipsReq;
  private String app1BankStmntsReq;
  private String app2PaySlipsReq;
  private String app2BankStmntsReq;
  private String app1AccountsReq;
  private String app1TaxCalc;
  private String app1PerAndBusBankStmntsReq;
  private String app2AccountsReq;
  private String app2TaxCalc;
  private String app2PerAndBusBankStmntsReq;

}
