package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum RepaymentType {
  INTEREST_ONLY,
  CAPITAL_AND_INTEREST
}