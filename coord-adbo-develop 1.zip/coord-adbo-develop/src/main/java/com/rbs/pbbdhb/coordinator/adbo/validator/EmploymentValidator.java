package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.AdditionalIncome;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.SelfEmployed;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class EmploymentValidator implements Validator {

  private static final String OPEN_SQUARE_BRACE = "[";
  private static final String CLOSED_SQUARE_BRACE = "].";

  private final AdditionalIncomeValidator additionalIncomeValidator;
  private final ProfitValidator profitValidator;
  private final SalaryValidator salaryValidator;

  @Autowired
  public EmploymentValidator(AdditionalIncomeValidator additionalIncomeValidator, ProfitValidator profitValidator,
      SalaryValidator salaryValidator) {

    this.additionalIncomeValidator = additionalIncomeValidator;
    this.profitValidator = profitValidator;
    this.salaryValidator = salaryValidator;

  }

  public static boolean isNullOrEmpty(String str) {
    return str == null || str.trim().isEmpty();
  }

  @Override
  public boolean supports(Class<?> clazz) {
    return Employment.class.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {
    Employment employment = (Employment) target;

    switch (employment.getType()) {
      case EMPLOYED:
        Employed employedType = (Employed) employment;
        if (isNull(employedType.getOccupation())) {
          errors.rejectValue("occupation", "required-non-null", " occupation cannot be null or empty");
        } else {
          switch (employedType.getOccupation()) {
            case ACADEMIC_STAFF:
            case AGRICULTURAL_WORKER:
            case ARCHITECT_BUILDING_AND_PLANNING:
            case ARTS:
            case BUSINESS_AND_ADMINISTRATION:
            case ENGINEERING:
            case FARM_OWNER_AND_MANAGER:
            case HM_FORCES_OFFICER:
            case HM_FORCES_OTHER_RANK:
            case HUMANITIES:
            case JUNIOR_MANAGER:
            case LANGUAGES:
            case LAW:
            case PROFESSIONALS:
            case MATHS:
            case MEDICAL_AND_RELATED:
            case SEMI_PROFESSIONALS:
            case NURSING:
            case OFFICE_AND_CLERICAL:
            case SALES:
            case SCIENCES:
            case SEMI_SKILLED_MANUAL:
            case SENIOR_MANAGER:
            case SERVICE_INDUSTRY_EMPLOYEE:
            case SKILLED_MANUAL:
            case SOCIAL_STUDIES:
            case SUPERVISOR:
            case TEACHER:
            case TECHNICIAN:
            case UNSKILLED_MANUAL:
              break;
            default:
              errors.rejectValue("occupation", "unsupported-commitmentType",
                  "The given occupation is unsupported for our journey");
          }
        }
        if (isNullOrEmpty(employedType.getEmployerName())) {
          errors.rejectValue("employerName", "required-non-empty", "employerName cannot be null or empty");
        } else {
          if (employedType.getEmployerName().length() > 30) {
            errors.rejectValue("employerName", "required-non-empty",
                "employerName cannot be more than 30 characters");
          }
        }

        if (isNull(employedType.getEmploymentBasis())) {
          errors.rejectValue("employmentBasis", "required-non-empty", "employmentBasis cannot be null or empty");
        } else {
          switch (employedType.getEmploymentBasis()) {
            case PERMANENT:
              if (isNull(employedType.getOnParentalLeave())) {
                errors.rejectValue("onParentalLeave", "required-non-empty",
                    "onParentalLeave cannot be null or empty");
              }
              if (isNull(employedType.getHasAdditionalIncome())) {
                errors.rejectValue("hasAdditionalIncome", "required-non-empty",
                    "hasAdditionalIncome cannot be null or empty");
              } else {
                if (isTrue(employedType.getHasAdditionalIncome())
                    && nonNull(employedType.getAdditionalIncomes()) && employedType.getAdditionalIncomes().size() > 0) {
                  int index = 0;
                  for (AdditionalIncome additionalIncomes : employedType.getAdditionalIncomes()) {
                    errors.pushNestedPath(constructPath("additionalIncomes" + OPEN_SQUARE_BRACE, index));
                    ValidationUtils.invokeValidator(this.additionalIncomeValidator, additionalIncomes,
                        errors);
                    errors.popNestedPath();
                    index++;
                  }
                }
                if (isTrue(employedType.getHasAdditionalIncome())
                    && (isNull(employedType.getAdditionalIncomes()) || (nonNull(employedType.getAdditionalIncomes())
                    && employedType.getAdditionalIncomes().size() == 0))) {
                  errors.rejectValue("additionalIncomes", "required-non-empty",
                      "additionalIncomes cannot be null or empty");
                }

                if (isFalse(employedType.getHasAdditionalIncome())
                    && nonNull(employedType.getAdditionalIncomes()) && employedType.getAdditionalIncomes().size() > 0) {
                  errors.rejectValue("additionalIncomes", "required-non-empty",
                      "additionalIncomes must be empty, as additional Income is false");
                }
              }
              break;
            case CONTRACTOR:
            case TEMPORARY:
              if (nonNull(employedType.getOnParentalLeave())) {
                errors.rejectValue("onParentalLeave", "requiredempty",
                    "onParentalLeave must be null or empty as Employment Basis is - Contractor or Temporary");
              }
              if (nonNull(employedType.getHasAdditionalIncome())) {
                errors.rejectValue("hasAdditionalIncome", "required-empty",
                    "hasAdditionalIncome must be null or empty as Employment Basis is - Contractor or Temporary");
              }
              if (nonNull(employedType.getAdditionalIncomes()) && employedType.getAdditionalIncomes().size() > 0) {
                errors.rejectValue("additionalIncomes", "required-non-empty",
                    "additionalIncomes must be empty as Employment Basis is - Contractor or Temporary");
              }
              break;
            default:
              errors.rejectValue("employmentBasis", "unsupported-commitmentType",
                  "The given employment Basis is unsupported for our journey");
          }
        }
        if (isNull(employedType.getIndustry())) {
          errors.rejectValue("industry", "required-non-empty", "industry cannot be null or empty");
        } else {
          switch (employedType.getIndustry()) {
            case AGRICULTURE_AND_FORESTRY:
            case FISHING:
            case MINING_AND_QUARRYING:
            case MANUFACTURING:
            case ELECTRICITY_GAS_AND_WATER_SUPPLY:
            case CONSTRUCTION:
            case WHOLESALE_RETAIL_AND_REPAIR:
            case HOTELS_AND_RESTAURANTS:
            case TRANSPORT_STORAGE_AND_COMMERCIAL:
            case FINANCE_AND_BANKING:
            case PROPERTY_AND_BUSINESS:
            case PUBLIC_ADMIN_AND_DEFENCE:
            case EDUCATION:
            case HEALTH_AND_SOCIAL_WORK:
            case OFFICE_WORK_AND_ADMINISTRATION:
            case OTHER:
              break;
            default:
              errors.rejectValue("industry", "unsupported-commitmentType",
                  "The given industry is unsupported for our journey");
          }
        }
        if (isNull(employedType.getStartDate())) {
          errors.rejectValue("startDate", "required-non-empty", "startDate cannot be null or empty");
        }

        if (isNull(employedType.getAmount())) {
          errors.rejectValue("amount", "required-non-empty", "amount cannot be null or empty");
        } else {
          int max = employedType.getAmount().compareTo(BigDecimal.valueOf(99999999));
          if (max == 1) {
            errors.rejectValue("amount", "maximum", "amount maximum value is 99999999");
          }
          int min = BigDecimal.valueOf(0).compareTo(employedType.getAmount());
          if (min == 1) {
            errors.rejectValue("amount", "minimum", "amount minimum value is 0");
          }
        }
        break;
      case SELF_EMPLOYED:
        SelfEmployed selfEmployedType = (SelfEmployed) employment;
        if (isNull(selfEmployedType.getEmploymentBasis())) {
          errors.rejectValue("employmentBasis", "required-non-empty", "employmentBasis cannot be null or Empty");
        } else {
          if (selfEmployedType.getHasBeenTradingForTwoYears() != null && isTrue(selfEmployedType.getHasBeenTradingForTwoYears())) {
            switch (selfEmployedType.getEmploymentBasis()) {
              case LIMITED_COMPANY:
                if (isNull(selfEmployedType.getLatestSalary())) {
                  errors.rejectValue("latestSalary", "required-non-empty",
                      "latestSalary cannot be null or Empty");
                } else {
                  errors.pushNestedPath("latestSalary");
                  ValidationUtils.invokeValidator(this.salaryValidator, selfEmployedType.getLatestSalary(),
                      errors);
                  errors.popNestedPath();
                }

                if (isNull(selfEmployedType.getPreviousSalary())) {
                  errors.rejectValue("previousSalary", "required-non-empty",
                      "previousSalary cannot be null or Empty");
                } else {
                  errors.pushNestedPath("previousSalary");
                  ValidationUtils.invokeValidator(this.salaryValidator, selfEmployedType.getPreviousSalary(),
                      errors);
                  errors.popNestedPath();
                }

                getShareInBuisness(selfEmployedType, errors);
                break;
              case SOLE_TRADER:
                if (nonNull(selfEmployedType.getLatestProfit())) {
                  errors.pushNestedPath("latestProfit");
                  ValidationUtils.invokeValidator(this.profitValidator, selfEmployedType.getLatestProfit(),
                      errors);
                  errors.popNestedPath();
                } else {
                  errors.rejectValue("latestProfit", "required-non-empty",
                      "latestProfit cannot be null or Empty");
                }

                if (nonNull(selfEmployedType.getPreviousProfit())) {
                  errors.pushNestedPath("previousProfit");
                  ValidationUtils.invokeValidator(this.profitValidator, selfEmployedType.getPreviousProfit(),
                      errors);
                  errors.popNestedPath();
                } else {
                  errors.rejectValue("previousProfit", "required-non-empty",
                      "previousProfit cannot be null or Empty");
                }
                if (nonNull(selfEmployedType.getLatestSalary()) || nonNull(selfEmployedType.getPreviousSalary())) {
                  errors.rejectValue("previousSalary", "required-non-empty",
                      "previousSalary or latestSalary not applicable when basis is Sole Trader");
                }

                if (nonNull(selfEmployedType.getShareInBusiness())) {
                  errors.rejectValue("shareInBusiness", "required-empty", "shareInBusiness must be null or empty");
                }
                break;
              case PARTNERSHIP:

                if (isNull(selfEmployedType.getShareInBusiness())) {
                  errors.rejectValue("shareInBusiness", "required-non-empty",
                      "shareInBusiness cannot be null or Empty");
                }
                getShareInBuisness(selfEmployedType, errors);

                if (nonNull(selfEmployedType.getLatestProfit())) {
                  errors.pushNestedPath("latestProfit");
                  ValidationUtils.invokeValidator(this.profitValidator, selfEmployedType.getLatestProfit(),
                      errors);
                  errors.popNestedPath();
                } else {
                  errors.rejectValue("latestProfit", "required-non-empty",
                      "latestProfit cannot be null or Empty");
                }

                if (nonNull(selfEmployedType.getPreviousProfit())) {
                  errors.pushNestedPath("previousProfit");
                  ValidationUtils.invokeValidator(this.profitValidator, selfEmployedType.getPreviousProfit(),
                      errors);
                  errors.popNestedPath();
                } else {
                  errors.rejectValue("previousProfit", "required-non-empty",
                      "previousProfit cannot be null or Empty");
                }
                if (nonNull(selfEmployedType.getLatestSalary()) || nonNull(selfEmployedType.getPreviousSalary())) {
                  errors.rejectValue("previousSalary", "required-non-empty",
                      "previousSalary or latestSalary not applicable when basis is Paternship");
                }
                break;
              default:
                errors.rejectValue("employmentBasis", "unsupported-commitmentType",
                    "The given employmentBasis is unsupported for our journey");
            }
          }
        }
        if (isNull(selfEmployedType.getIndustry())) {
          errors.rejectValue("industry", "required-non-empty", "industry cannot be null or empty");
        } else {
          switch (selfEmployedType.getIndustry()) {
            case AGRICULTURE_AND_FORESTRY:
            case FISHING:
            case MINING_AND_QUARRYING:
            case MANUFACTURING:
            case ELECTRICITY_GAS_AND_WATER_SUPPLY:
            case CONSTRUCTION:
            case WHOLESALE_RETAIL_AND_REPAIR:
            case HOTELS_AND_RESTAURANTS:
            case TRANSPORT_STORAGE_AND_COMMERCIAL:
            case FINANCE_AND_BANKING:
            case PROPERTY_AND_BUSINESS:
            case PUBLIC_ADMIN_AND_DEFENCE:
            case EDUCATION:
            case HEALTH_AND_SOCIAL_WORK:
            case OFFICE_WORK_AND_ADMINISTRATION:
            case OTHER:
              break;
            default:
              errors.rejectValue("industry", "unsupported-commitmentType",
                  "The given industry is unsupported for our journey");
          }
        }

        if (isNullOrEmpty(selfEmployedType.getBusinessName())) {
          errors.rejectValue("businessName", "required-non-empty", "businessName cannot be null or empty");
        } else {
          if (selfEmployedType.getBusinessName().length() > 30) {
            errors.rejectValue("businessName", "required-non-empty",
                "businessName cannot be more than 30 characters");
          }
        }

        if (selfEmployedType.getHasBeenTradingForTwoYears() != null && isTrue(selfEmployedType.getHasBeenTradingForTwoYears())) {
          if (isNull(selfEmployedType.getMonthsEstablished())) {
            errors.rejectValue("monthsEstablished", "required-non-empty",
                "monthsEstablished cannot be null or empty");
          } else {
            if (selfEmployedType.getMonthsEstablished() > 11) {
              errors.rejectValue("monthsEstablished", "required-non-empty",
                  "monthsEstablished cannot be more than 11");
            }
            if (selfEmployedType.getMonthsEstablished() < 0) {
              errors.rejectValue("monthsEstablished", "required-non-empty", "monthsEstablished cannot be less than 0");
            }
          }
          if (isNull(selfEmployedType.getYearsEstablished())) {
            errors.rejectValue("yearsEstablished", "required-non-empty",
                "yearsEstablished cannot be null or empty");
          } else {
            if (selfEmployedType.getYearsEstablished() > 99) {
              errors.rejectValue("yearsEstablished", "required-non-empty",
                  "yearsEstablished cannot be more than 99");
            }
            if (selfEmployedType.getYearsEstablished() < 2) {
              errors.rejectValue("yearsEstablished", "required-non-empty",
                  "yearsEstablished cannot be less than 2");
            }
          }
        }
        if (isNull(selfEmployedType.getHasBeenTradingForTwoYears())) {
          errors.rejectValue("hasBeenTradingForTwoYears", "required-true",
              "hasBeenTradingForTwoyears is a mandatory question");
        }
        break;
      default:
        errors.rejectValue("type", "unsupported-commitmentType",
            "The given employment type is unsupported for our journey");
    }

  }

  private void getShareInBuisness(SelfEmployed selfEmployedType, Errors errors) {

    if (isNull(selfEmployedType.getShareInBusiness())) {
      errors.rejectValue("shareInBusiness", "required-non-empty", "shareInBusiness cannot be null or empty");
    } else {

      int max = selfEmployedType.getShareInBusiness().compareTo(BigDecimal.valueOf(100));
      if (max == 1) {
        errors.rejectValue("shareInBusiness", "maximum", "shareInBusiness maximum value is 100");
      }
      int min = BigDecimal.valueOf(0).compareTo(selfEmployedType.getShareInBusiness());
      if (min == 1) {
        errors.rejectValue("shareInBusiness", "minimum", "shareInBusiness minimum value is 0");
      }
    }
  }

  private String constructPath(String nestedPath, int index) {
    return new StringBuffer().append(nestedPath).append(index).append(CLOSED_SQUARE_BRACE).toString();
  }
}
