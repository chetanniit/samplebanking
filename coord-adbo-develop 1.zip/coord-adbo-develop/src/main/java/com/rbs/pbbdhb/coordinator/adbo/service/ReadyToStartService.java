package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.ReadyToStartRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.ReadyToStartResponse;

public interface ReadyToStartService {

  void saveFraudWarningAndLossOfProtectionAndImportantInfoAboutUsDisclaimers(String accountNumber, ReadyToStartRequest readyToStartRequest);

  ReadyToStartResponse getFraudWarningAndLossOfProtectionAndImportantInfoAboutUsDisclaimers(String accountNumber);

}
