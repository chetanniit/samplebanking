package com.rbs.pbbdhb.coordinator.adbo.model.BasicPackagingUpdate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
@Data
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class PackagingApplicantInfo {

    private String applicantId;

    private String firstName;

    private String middleName;

    private String lastName;

    @JsonProperty("isMainApplicant")
    private boolean isMainApplicant;

    @JsonProperty("isCatoVerified")
    private boolean isCatoVerified;

    @JsonProperty("isBasicPackagingRequired")
    private boolean isBasicPackagingRequired;

    @JsonProperty("isBasicPackagingReceived")
    private boolean isBasicPackagingReceived;

    @JsonProperty("isBasicPackagingClosed")
    private boolean isBasicPackagingClosed;

    @JsonProperty("isSIRequested")
    private boolean isSIRequested;

    @JsonProperty("isSIReceived")
    private boolean isSIReceived;

    @JsonProperty("isSIClosed")
    private boolean isSIClosed;
}
