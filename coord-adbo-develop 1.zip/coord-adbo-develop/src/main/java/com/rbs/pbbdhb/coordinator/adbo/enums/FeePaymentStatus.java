package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum FeePaymentStatus {
    NOT_APPLICABLE, TODO, COMPLETE
}
