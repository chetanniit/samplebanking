package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.util.EligibleToSwitchCheckAndSetForSubAccount;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class StandardEligibleToSwitchValidator extends AbstractValidator {

  private final EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount;

  public StandardEligibleToSwitchValidator(@Value("${journeyValidator.priority.standardEligibleToSwitch}") int priority,
      EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount) {
    super(priority, ValidationRuleResultCode.PASS_ELIGIBLE_TO_SWITCH);
    this.eligibleToSwitchCheckAndSetForSubAccount = eligibleToSwitchCheckAndSetForSubAccount;
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    List<SubAccount> subAccounts = journeyValidation.getAccountSummaryApiResponse().getSubAccounts();
    for (SubAccount subAccount : subAccounts) {
      boolean eligibleToSwitch = eligibleToSwitchCheckAndSetForSubAccount.standardEligibleToSwitch(subAccount);
      if (eligibleToSwitch) {
        return true;
      }
    }
    return false;
  }

}
