package com.rbs.pbbdhb.coordinator.adbo.brand.nwb;

import com.rbs.pbbdhb.coordinator.adbo.brand.nwb.repositories.NwbAdboCaseDetailsRepository;
import com.rbs.pbbdhb.coordinator.brand.BrandedComponentsProvider;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This class will have repository information related to NWB
 */
@Component
@RequiredArgsConstructor
@Getter
public class NwbComponentsProvider implements BrandedComponentsProvider {

  private final NwbAdboCaseDetailsRepository adboCaseDetailsRepository;
}
