package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.OtherIncome;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.request.IncomeRequest;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class IncomeDetailsValidator implements Validator {

  private static final String CLOSED_SQUARE_BRACE = "].";
  private static final String OPEN_SQUARE_BRACE = "[";

  private final OtherIncomeValidator otherIncomesValidator;
  private final BankDetailsValidator bankDetailsValidator;
  private final RetiredValidator retiredValidator;
  private final EmploymentValidator employmentValidator;

  @Autowired
  public IncomeDetailsValidator(OtherIncomeValidator otherIncomesValidator, BankDetailsValidator bankDetailsValidator,
      RetiredValidator retiredValidator, EmploymentValidator employmentValidator) {

    this.otherIncomesValidator = otherIncomesValidator;
    this.bankDetailsValidator = bankDetailsValidator;
    this.retiredValidator = retiredValidator;
    this.employmentValidator = employmentValidator;
  }

  @Override
  public boolean supports(Class<?> clazz) {
    return IncomeRequest.class.isAssignableFrom(clazz);
  }

  @Override
  @SneakyThrows
  public void validate(Object target, Errors errors) {
    IncomeRequest income = (IncomeRequest) target;

    if (nonNull(income.getHasOtherIncome())) {
      if (isTrue(income.getHasOtherIncome())) {
        if (isNull(income.getOtherIncomes()) || income.getOtherIncomes().size() == 0) {
          errors.rejectValue("otherIncomes", "required-non-empty",
              "otherIncomes cannot be null or empty,as hasOtherIncome is true");
        } else {
          int index = 0;
          for (OtherIncome otherIncomes : income.getOtherIncomes()) {
            errors.pushNestedPath(constructPath("otherIncomes" + OPEN_SQUARE_BRACE, index));
            ValidationUtils.invokeValidator(this.otherIncomesValidator, otherIncomes, errors);
            errors.popNestedPath();
            index++;
          }
        }
      } else {
        if (nonNull(income.getOtherIncomes()) && income.getOtherIncomes().size() > 0) {
          errors.rejectValue("otherIncomes", "required-empty",
              "otherIncomes must be empty, as hasOtherIncome is false");
        }
      }
    }

    if (nonNull(income.isHasBankDetailsModified())) {
      if (isTrue(income.isHasBankDetailsModified())) {
        if (isNull(income.getBankDetails())) {
          errors.rejectValue("bankDetails", "required-non-empty",
              "bankDetails cannnot be null, as bank details has been verified");
        } else {
          errors.pushNestedPath("bankDetails");
          ValidationUtils.invokeValidator(this.bankDetailsValidator, income.getBankDetails(), errors);
          errors.popNestedPath();
        }
      } else {
        if (nonNull(income.getBankDetails())) {
          errors.rejectValue("bankDetails", "required-empty",
              "bankDetails must  be null, as no bank deatils has been modifed");
        }
      }
    }

    switch (income.getCurrentWorkStatus()) {
      case RETIRED: {
        if (nonNull(income.getRetired())) {
          errors.pushNestedPath("retired");
          ValidationUtils.invokeValidator(this.retiredValidator, income.getRetired(), errors);
          errors.popNestedPath();
        } else {
          errors.rejectValue("retired", "required-non-empty",
              "retirement details cannot  be null as work status is retired");
        }

        if (nonNull(income.getEmployments()) && income.getEmployments().size() > 0) {
          errors.rejectValue("employments", "required-empty",
              "employments details must  be empty, as work status is retired");
        }
      }
      break;
      case WORKING: {
        if (isNull(income.getEmployments()) || (nonNull(income.getEmployments()) && income.getEmployments().size() == 0)) {
          errors.rejectValue("employments", "required-non-empty",
              "employments details cannot  be null or empty as work status is working");
        } else {
          int index = 0;
          for (Employment employments : income.getEmployments()) {
            errors.pushNestedPath(constructPath("employments" + OPEN_SQUARE_BRACE, index));
            ValidationUtils.invokeValidator(this.employmentValidator, employments, errors);
            errors.popNestedPath();
            index++;
          }
        }

        if (nonNull(income.getRetired())) {
          errors.rejectValue("retired", "required-empty",
              "retirement details must  be null, as work status is working");
        }

      }
      break;
      case NOT_WORKING: {
        if (nonNull(income.getEmployments()) && income.getEmployments().size() > 0) {
          errors.rejectValue("employments", "required-empty",
              "employments details must  be empty, as work status is not working");
        }

        if (nonNull(income.getRetired())) {
          errors.rejectValue("retired", "required-empty",
              "retirement details must  be null, as work status is not working");
        }
      }
      break;
      default:
        errors.rejectValue("currentWorkStatus", "unsupported-commitmentType",
            "This currentWorkStatus is currently unsupported for our journey");
        break;
    }

  }

  private String constructPath(String nestedPath, int index) {
    return new StringBuffer().append(nestedPath).append(index).append(CLOSED_SQUARE_BRACE).toString();
  }

}
