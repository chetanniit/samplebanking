package com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation;

import static java.util.Collections.unmodifiableList;
import static java.util.Objects.requireNonNull;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.TrueBalanceResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CoreCustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerKycResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerVulnerableResponse;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Singular;
import lombok.ToString;
import org.springframework.http.HttpStatus;

@Getter
@ToString
public class JourneyValidation {

  private final String loggedUserCin;
  private final AdboCaseDetails adboCaseDetails;
  private final AccountSummaryResponse accountSummaryApiResponse;
  private final CoreCustomerSummaryResponse customerSummaryApiResponse;
  private final List<CoreCustomerSummaryResponse> customerSummaryApiResponses;
  private final List<CustomerKycResponse> customerKycResponses;
  private final List<CustomerVulnerableResponse> customerVulnerableResponses;
  private final ApplicationStatusResponse applicationStatusResponse;
  private final ApplicationType applicationType;
  private final TrueBalanceResponse trueBalance;


  @Builder
  private JourneyValidation(String loggedUserCin, AdboCaseDetails adboCaseDetails, AccountSummaryResponse accountSummaryApiResponse,
      @Singular("customerSummaryApiResponse") List<CoreCustomerSummaryResponse> customerSummaryApiResponse,
      @Singular List<CustomerKycResponse> customerKycResponses,
      @Singular List<CustomerVulnerableResponse> customerVulnerableResponses, ApplicationStatusResponse applicationStatusResponse,
      ApplicationType applicationType, TrueBalanceResponse trueBalance) {
    this.loggedUserCin = requireNonNull(loggedUserCin);
    this.adboCaseDetails = adboCaseDetails;
    this.accountSummaryApiResponse = requireNonNull(accountSummaryApiResponse);
    this.customerSummaryApiResponse = customerSummaryApiResponse.stream()
        .filter(customer -> customer.getCin().equals(loggedUserCin))
        .findFirst()
        .orElseThrow(() -> new BusinessException("User not found", HttpStatus.BAD_REQUEST.value()));
    this.applicationType = requireNonNull(applicationType);
    this.customerSummaryApiResponses = unmodifiableList(customerSummaryApiResponse);
    this.customerKycResponses = unmodifiableList(requireNonEmpty(customerKycResponses));
    this.customerVulnerableResponses = unmodifiableList(requireNonEmpty(customerVulnerableResponses));
    this.applicationStatusResponse = requireNonNull(applicationStatusResponse);
    this.trueBalance = requireNonNull(trueBalance);

  }

  private static <T> List<T> requireNonEmpty(List<T> list) {
    if (requireNonNull(list).isEmpty()) {
      throw new IllegalArgumentException();
    }
    return list;
  }
}
