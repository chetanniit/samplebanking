package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AgreementsAndDisclaimers {

  private Boolean readMortgageIllustration;
  
  private Boolean readSwitchIllustration;

  private Boolean readAboutOurMortgageRange;

  private Boolean cantLendTillApproved;

  private Boolean creditCheckDisclaimer;

  private Boolean readMortgageIllustrationUnderstoodProduct;

  private Boolean rightMortgageConfident;

  private Boolean selfServiceLossOfProtectionDocument;

  private Boolean importantInformationAboutUs;
}
