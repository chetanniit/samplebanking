package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * AipResponse
 */
@Getter
@Setter
public class DipResult {

  private String decisionUniqueId;

  private String dipId;

  private String decision;

  private String podDecision;

  private List<Policy> policyMessages = null;

  private AdditionalDetails additionalDetails;

  private Packaging packaging;

  private List<ApplicantCinResponse> applicants = null;

}

