package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum LoanType {
  PERSONAL_LOAN("PERSONAL_LOAN"),
  SECURED_LOAN("SECURED_LOAN"),
  STUDENT_LOAN("STUDENT_LOAN"),
  CAR_FINANCE("CAR_FINANCE");

  private final String label;

  LoanType(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
