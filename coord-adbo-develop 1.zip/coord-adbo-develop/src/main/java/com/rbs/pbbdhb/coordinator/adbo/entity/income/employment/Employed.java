package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import com.rbs.pbbdhb.coordinator.adbo.entity.StructuredAddress;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmployedBasis;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmploymentType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Industry;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Occupation;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class Employed  implements Employment {

  private Occupation occupation;
  private String employerName;
  private EmployedBasis employmentBasis;
  private Industry industry;
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate startDate;
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate contractEndDate;
  private Boolean onParentalLeave;
  private BigDecimal amount;
  private Boolean hasContinuousEmployment;
  private Boolean hasAdditionalIncome;
  private List<PreviousEmployment> previousEmployments;
  private List<AdditionalIncome> additionalIncomes;
  private EmploymentType type;
  private GmsAddress employerAddress;
  private StructuredAddress employerStructuredAddress;

  @Override
  public EmploymentType getType() {
    return type;
  }

}
