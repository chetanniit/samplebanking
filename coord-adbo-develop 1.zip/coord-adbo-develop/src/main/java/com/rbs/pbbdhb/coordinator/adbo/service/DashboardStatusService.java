package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.response.DashboardAndTrackingDetails;

public interface DashboardStatusService {
    DashboardAndTrackingDetails getDashboardAndTracking(String accountNumber);
}
