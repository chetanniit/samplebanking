package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum ProductFeeType {
  FEE_UP_FRONT,
  NO_FEE
}