package com.rbs.pbbdhb.coordinator.adbo.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@ToString
@EqualsAndHashCode
public class AdditionalBorrowingJointSubmitRequest  {

  /**
   * Do you agree to check being made with credit reference and fraud prevention agencies for all mortgage applicants
   */
  @Schema(example = "true", required = true)
  @NotNull(message = "creditCheckDisclaimer must not be null, Should be true or false")
  @AssertTrue(message = "creditCheckDisclaimer must be true")
  private Boolean creditCheckDisclaimer;


  @Schema(example = "true", required = true)
  @NotNull(message = "readMortgageIllustration must not be null, Should be true or false")
  @AssertTrue(message = "Please Acknowledge that you have read mortgage illustration before proceeding")
  private Boolean readMortgageIllustration;

  @Schema(example = "true")
  @AssertTrue(message = "Please Acknowledge that you have read switch illustration before proceeding")
  private Boolean readSwitchIllustration;

  /**
   * Can you confirm you have read and understood mortgage illustration and want to apply for the product described
   */
  @Schema(example = "true", required = true)
  @NotNull(message = "readMortgageIllustrationUnderstoodProduct must not be null, Should be true or false")
  @AssertTrue(message = "readMortgageIllustrationUnderstoodProduct must be true")
  private Boolean readMortgageIllustrationUnderstoodProduct;


  @Schema(example = "true", required = true)
  @NotNull(message = "readAboutOurMortgageRange must not be null, Should be true or false")
  @AssertTrue(message = "Please Acknowledge that you have read about our mortgage range before proceeding")
  private Boolean readAboutOurMortgageRange;


  @Schema(example = "true", required = true)
  @NotNull(message = "selfServiceLossOfProtection must not be null, Should be true ")
  @AssertTrue(message = "Please Acknowledge that you have read Self Service loss of Protection document before proceeding")
  private Boolean selfServiceLossOfProtectionDocument;

  @Schema(example = "true", required = true)
  @NotNull(message = "importantInformationAboutUs must not be null, Should be true")
  @AssertTrue(message = "Please Acknowledge that you have read about our Important Information about us before proceeding")
  private Boolean importantInformationAboutUs;


  @NotNull(message = "emailMarketing cannot be null, needs to be either true or false")
  private Boolean emailMarketing;

  @NotNull(message = "postalMarketing cannot be null, needs to be either true or false")
  private Boolean postalMarketing;

  @NotNull(message = "phoneMarketing cannot be null, needs to be either true or false")
  private Boolean phoneMarketing;

  private String lawfulBasisMarker;
}
