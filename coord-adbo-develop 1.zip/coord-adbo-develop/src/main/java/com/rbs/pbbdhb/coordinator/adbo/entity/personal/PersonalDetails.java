package com.rbs.pbbdhb.coordinator.adbo.entity.personal;

import static org.apache.commons.lang3.StringUtils.equalsIgnoreCase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Gender;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PersonalDetails  {

  @NotNull
  private Title title;

  private String otherTitle;

  private String nationality;

  private String originalNationalityIsoCode;

  private String nationalityIsoCode;

  @NotNull
  private String firstName;

  private String middleName;

  @NotNull
  private String lastName;

  private Gender gender;

  private String gmsId;

  private MaritalStatus originalMaritalStatus;

  private MaritalStatus maritalStatus;

  @NotNull
  @Email(regexp = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$")
  private String email;

  @NotNull
  @Email(regexp = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$")
  private String gmsEmail;

  @NotNull
  @Pattern(regexp = "^(0[^7]\\d{9,13})|(07\\d{9})$")
  private String mobileNumber;

  @NotNull
  @Pattern(regexp = "^(0[^7]\\d{9,13})|(07\\d{9})$")
  private String gmsMobileNumber;

  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate currentAddressMoveInDate;

  @NotNull
  private GmsAddress currentAddress;

  private Address currentAddressStructuredFormat;

  private List<Address> previousAddresses;

  private Boolean hasDependents;

  private Integer dependentsOver18;

  private Integer dependentsUnder18;

  @AssertTrue
  private Boolean isAboveInformationCorrect;

  @NotNull
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate dateOfBirth;

  public boolean isEmailChanged() {
    return !equalsIgnoreCase(email, gmsEmail);
  }

  public boolean isMobileNumberChanged() {
    return !equalsIgnoreCase(mobileNumber, gmsMobileNumber);
  }

  public boolean isNationalityChanged() {
    return !equalsIgnoreCase(nationalityIsoCode, originalNationalityIsoCode);
  }

  public boolean isMaritalStatusChanged() {
    return !Objects.equals(maritalStatus, originalMaritalStatus);
  }
}
