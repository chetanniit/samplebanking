package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Channel {
  BRANCH("Branch"),
  INTERNET("Internet");

  private String value;

  @Override
  public String toString() {
    return name();
  }
}