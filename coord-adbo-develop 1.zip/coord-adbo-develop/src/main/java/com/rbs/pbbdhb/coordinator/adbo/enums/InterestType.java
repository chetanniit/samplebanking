package com.rbs.pbbdhb.coordinator.adbo.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum InterestType {
  FIXED("F"), TRACKER("T"), VARIABLE("V");
  private final String interestType;

  InterestType(String interestType) {
    this.interestType = interestType;
  }

  public String getInterestType() {
    return interestType;
  }

  @JsonCreator
  public static InterestType fromValue(String interestType) {
    for (InterestType b : InterestType.values()) {
      if (b.interestType.equals(interestType)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + interestType + "'");
  }

  @Override
  @JsonValue
  public String toString() {
    return interestType;
  }
}
