package com.rbs.pbbdhb.coordinator.adbo.entity;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerSelfEmployed {

  private String currentOrPrevious;
  private String companyName;
  private GetCustomerAddress companyAddress;
  private String natureOfBusiness;
  private Integer yearsEstablished;
  private Integer monthsEstablished;
  private String telephoneNumber;
  private String deliveryPreference;
  private String faxNumber;
  private String emailAddress;
  private String profitYear1;
  private String profitYear2;
  private String profitYear3;
  private BigDecimal profitAmount1;
  private BigDecimal profitAmount2;
  private BigDecimal profitAmount3;
  private GetCustomerIncomeDetails incomeDetails;
  private GetCustomerAccountantDetails accountantDetails;
  private Integer yearsOfAccounts;
  private String employmentStatus;

}
