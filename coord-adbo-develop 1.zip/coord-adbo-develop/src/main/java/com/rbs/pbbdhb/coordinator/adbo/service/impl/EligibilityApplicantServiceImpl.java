package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityApplicant;
import com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode;
import com.rbs.pbbdhb.coordinator.adbo.service.EligibilityApplicantService;
import com.rbs.pbbdhb.coordinator.adbo.validator.ValidateJointApplicant;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EligibilityApplicantServiceImpl implements EligibilityApplicantService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final ValidateJointApplicant validateJointApplicantEligibleNationality;

  @Override
  public void saveEligibilityApplicant(final String accountNumber, final EligibilityApplicant eligibilityApplicant) {
    AdboCaseDetails caseDetails = getCaseDetails(accountNumber);
    validateJointApplicantEligibleNationality.validateJointAccount(caseDetails.getAdboApplicants(), eligibilityApplicant);
    if (Objects.equals(JourneyValidationResultCode.PASS.name(), caseDetails.getValidationResult())) {
      caseDetails.setEligibilityApplicant(
          Objects.requireNonNull(eligibilityApplicant, "Eligibility applicant must not be null when journey validation status is PASS"));
      adboCaseDetailsDao.save(caseDetails);
      log.info("Eligibility applicant details have been saved/updated successfully, accountNumber {}", accountNumber);
    } else {
      log.info("eligibilityApplicant can't save for this account number {}, journey validation status {}", accountNumber,
          caseDetails.getValidationResult());
      throw new BusinessException(Constants.ELIGIBILITY_APPLICANT_CANNOT_SAVED, HttpStatus.BAD_REQUEST.value());
    }
  }

  @Override
  public EligibilityApplicant getEligibilityApplicant(final String accountNumber) {
    AdboCaseDetails caseDetails = getCaseDetails(accountNumber);
    return caseDetails.getEligibilityApplicant();
  }

  private AdboCaseDetails getCaseDetails(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    if (Objects.nonNull(adboCaseDetails)) {
      return adboCaseDetails;
    } else {
      log.info("eligibilityApplicant not found for the given account number {}", accountNumber);
      throw new BusinessException(Constants.ELIGIBILITY_APPLICANT_NOT_FOUND, HttpStatus.BAD_REQUEST.value());
    }
  }
}
