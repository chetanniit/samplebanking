package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum MortgageType {
  ADBO("Adbo"),
  SWITCHER("Switcher");
  
  private final String value;

  @Override
  public String toString() {
    return name();
  }

}