package com.rbs.pbbdhb.coordinator.adbo.brand.rbs;

import com.rbs.pbbdhb.coordinator.adbo.brand.rbs.repositories.RbsAdboCaseDetailsRepository;
import com.rbs.pbbdhb.coordinator.brand.BrandedComponentsProvider;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This class will have repository information related to RBS
 */
@Component
@RequiredArgsConstructor
@Getter
public class RbsComponentsProvider implements BrandedComponentsProvider {

  private final RbsAdboCaseDetailsRepository adboCaseDetailsRepository;
}
