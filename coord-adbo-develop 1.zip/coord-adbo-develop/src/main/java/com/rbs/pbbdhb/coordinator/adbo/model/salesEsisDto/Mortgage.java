package com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Schema(description = "Mortgage Information")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Mortgage {

  private BigDecimal propertyValue;

  private BigDecimal purchasePrice;

  private BigDecimal mortgageAmount;

  private Integer mortgageTermYears;

  private Integer mortgageTermMonths;

  private String mortgageType;

  private List<SalesEsisProduct> products;

  private String schemeType;

  private String schemeName;

  private String foreignCurrencyName;

  private BigDecimal foreignCurrencyExchangeRate;


}
