package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.EligibilityApplicantControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityApplicant;
import com.rbs.pbbdhb.coordinator.adbo.service.EligibilityApplicantService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class EligibilityApplicantController implements EligibilityApplicantControllerSwagger {

  private final EligibilityApplicantService eligibilityApplicantService;

  @Override
  @PostMapping(value = "/eligibilityApplicant", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveEligibilityApplicant(@RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final EligibilityApplicant eligibilityApplicant) {
    log.info("saveEligibilityApplicant start - Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute, eligibilityApplicant);
    TenantProvider.applyBrand(brand);
    eligibilityApplicantService.saveEligibilityApplicant(accountNumber, eligibilityApplicant);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveEligibilityApplicant end's with response {}, account_number: {}, brand: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  @Override
  @GetMapping(value = "/eligibilityApplicant", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<EligibilityApplicant> getEligibilityApplicant(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getEligibilityApplicant start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<EligibilityApplicant> response = new ResponseEntity<>(
        eligibilityApplicantService.getEligibilityApplicant(accountNumber), HttpStatus.OK);
    log.info("getEligibilityApplicant end's with response {} account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

}
