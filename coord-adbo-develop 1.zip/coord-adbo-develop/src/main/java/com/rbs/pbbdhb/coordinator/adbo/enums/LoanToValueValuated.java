package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum LoanToValueValuated {
  HPI("HPI"),
  LAST_VALUATION("Last Valuation");

  String label;

  LoanToValueValuated(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }
}
