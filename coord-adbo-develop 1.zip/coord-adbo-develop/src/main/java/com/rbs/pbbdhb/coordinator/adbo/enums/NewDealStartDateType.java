package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum NewDealStartDateType {

  START_IMMEDIATELY,
  START_IMMEDIATELY_TRACK_AND_SWITCH,
  START_AFTER_CURRENT_DEAL,
  START_OPTION_TO_SWITCH
}
