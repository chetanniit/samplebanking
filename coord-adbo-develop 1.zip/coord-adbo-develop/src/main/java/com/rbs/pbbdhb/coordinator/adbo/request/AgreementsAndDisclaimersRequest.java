package com.rbs.pbbdhb.coordinator.adbo.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@ToString
@EqualsAndHashCode
public class AgreementsAndDisclaimersRequest  {

  @Schema(example = "true", required = true)
  @NotNull(message = "readMortgageIllustration must not be null, Should be true or false")
  @AssertTrue(message = "Please Acknowledge that you have read mortgage illustration before proceeding")
  private Boolean readMortgageIllustration;

  @Schema(example = "true", required = true)
  @NotNull(message = "readAboutOurMortgageRange must not be null, Should be true or false")
  @AssertTrue(message = "Please Acknowledge that you have read about our mortgage range before proceeding")
  private Boolean readAboutOurMortgageRange;

  @Schema(example = "true")
  @AssertTrue(message = "Please Acknowledge that you have read switch illustration before proceeding")
  private Boolean readSwitchIllustration;
}
