package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.NEW_BUILD;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import com.rbs.pbbdhb.coordinator.adbo.enums.PropertyGmsBuildType;
import com.rbs.pbbdhb.coordinator.adbo.enums.SubAccountType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails;
import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyAdditionalRepaymentCalculatorForTenure;
import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyMinMaxRepaymentCalculator;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboCalculator;
import com.rbs.pbbdhb.coordinator.adbo.response.MinMaxRepaymentVo;
import com.rbs.pbbdhb.coordinator.adbo.response.SubAccountMinMaxRepaymentVo;
import com.rbs.pbbdhb.coordinator.adbo.service.AdboCalculatorService;
import com.rbs.pbbdhb.coordinator.adbo.service.AdboCalculatorValidator;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AdboCalculatorServiceImpl implements AdboCalculatorService {

  private final ApiService apiService;
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final AdboCalculatorValidator adboCalculatorValidator;

  /**
   * minimum borrowing amount
   */
  @Value("${adbo.borrowing.minimum}")
  private BigDecimal minimumBorrowing;

  /**
   * maximum borrowing amount
   */
  @Value("${adbo.borrowing.maximum}")
  private BigDecimal maximumBorrowing;

  /**
   * This method is useful to save the applicant borrowing details in the mongodb.
   *
   * @param accountNumber    accountNumber is number unique customer identity number
   * @param borrowingDetails object which has a properties like estimatedPropertyValue, isPropertyModified,retirementAge and
   *                         monthlyMinMaxRepaymentCalculator object
   */
  @Override
  public void saveBorrowingDetails(String accountNumber, BorrowingDetails borrowingDetails) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    adboCalculatorValidator.validateLoanToValue(accountNumber, borrowingDetails, adboCaseDetails);
    Map<ApplicantType, Integer> retirementAge = adboCalculatorValidator.prepareAndValidateRetirementAge(accountNumber,
        borrowingDetails, adboCaseDetails);
    AdditionalBorrowingCalculator additionalBorrowingCalculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    additionalBorrowingCalculator.setLoanToValue(BigDecimal.valueOf(borrowingDetails.getLoanToValue()));
    if (additionalBorrowingCalculator.getHpiValuation() != null) {
      additionalBorrowingCalculator.setHpiValuation(BigDecimal.valueOf(additionalBorrowingCalculator.getHpiValuation().intValue()));
    }
    additionalBorrowingCalculator.setPropertyModified(borrowingDetails.getIsPropertyModified());
    additionalBorrowingCalculator.setEstimatedPropertyValue(
        borrowingDetails.getEstimatedPropertyValue() != null ? borrowingDetails.getEstimatedPropertyValue().intValue() : null);
    additionalBorrowingCalculator.setRetirementAge(ApplicantType.getInOrder(retirementAge));
    additionalBorrowingCalculator.setBorrowingAmount(borrowingDetails.getBorrowingAmount());
    additionalBorrowingCalculator.setRepaymentTermYears(borrowingDetails.getRepaymentTermYears());
    additionalBorrowingCalculator.setRepaymentTermMonths(borrowingDetails.getRepaymentTermMonths());
    updatePropertyGmsBuildType(borrowingDetails.getIsPropertyModified(), additionalBorrowingCalculator);
    adboCaseDetails.setAdditionalBorrowingCalculator(additionalBorrowingCalculator);
    adboCaseDetailsDao.save(adboCaseDetails);
    log.info("Borrowing need and tenure details have been saved/updated successfully, accountNumber {}", accountNumber);
  }

  private void updatePropertyGmsBuildType(Boolean isModified, AdditionalBorrowingCalculator additionalBorrowingCalculator) {
    try {
      PropertyGmsBuildType propertyGmsBuildType = PropertyGmsBuildType.valueOf(additionalBorrowingCalculator.getPropertyGmsTypeCode());
      if (additionalBorrowingCalculator.getPropertyBuiltType().equals(NEW_BUILD) || isModified) {
        additionalBorrowingCalculator.setPropertyGmsBuildType(propertyGmsBuildType.getNewBuild());
      } else {
        additionalBorrowingCalculator.setPropertyGmsBuildType(propertyGmsBuildType.getOldBuild());
      }
    } catch (Exception e) {
      log.error("Skipped updatePropertyGmsBuildType as propertyGmsBuildType was not mapped successfully for input :: {} ",
          additionalBorrowingCalculator.getPropertyGmsTypeCode());
    }
  }

  /**
   * getMonthlyMinMaxRepayment method will call the msvc-product microservice for calculating monthly additional repayment minimum and
   * maximum
   *
   * @param monthlyMinMaxRepaymentCalculator In this object we are sending majorly borrowingAmount,existingBorrowing,repaymentTermYears
   *                                         repaymentTermMonths and loanToValue(ltv)
   * @return This method return MonthlyAdditionalMinMaxRepaymentVo which has minimum and maximum repayment for the complete tenure.
   */
  @Override
  public MinMaxRepaymentVo getMonthlyMinMaxRepayment(
      MonthlyMinMaxRepaymentCalculator monthlyMinMaxRepaymentCalculator, String accountNumber) {
    log.info("MonthlyMinMaxRepayment is started, request {}", monthlyMinMaxRepaymentCalculator);

    MonthlyAdditionalRepaymentCalculatorForTenure monthlyAdditionalRepaymentCalculatorForTenure = new MonthlyAdditionalRepaymentCalculatorForTenure(
        monthlyMinMaxRepaymentCalculator.getBorrowingAmount(),
        monthlyMinMaxRepaymentCalculator.getTotalTrueBalance(),
        monthlyMinMaxRepaymentCalculator.getRepaymentTermYears(),
        monthlyMinMaxRepaymentCalculator.getRepaymentTermMonths(),
        monthlyMinMaxRepaymentCalculator.getLoanToValue());

    if (Boolean.TRUE.equals(monthlyMinMaxRepaymentCalculator.getAdditionalBorrowingWithSwitch())) {
      AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseForJourneyValidationPassOrLimited(accountNumber);

      if (adboCaseDetails.getAdditionalBorrowingCalculator().getCohortDate() != null) {
        monthlyAdditionalRepaymentCalculatorForTenure.setCohortDate(adboCaseDetails.getAdditionalBorrowingCalculator().getCohortDate());
      }

      List<SubAccountMinMaxRepaymentVo> subAccountsSelectedForSwitching = new ArrayList<>();

      monthlyAdditionalRepaymentCalculatorForTenure.setMortgageType(Constants.MORTGAGE_TYPE_SWITCHER);
      boolean productTypeFixed = adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream()
          .anyMatch(subAccount -> isTrue(subAccount.getSelectedForSwitch()) && SubAccountType.TRACKER == subAccount.getSubAccountType());
      if (productTypeFixed) {
        monthlyAdditionalRepaymentCalculatorForTenure.setProductType(ProductType.FIXED);
      }
      MinMaxRepaymentVo response = apiService.getMonthlyAdditionalMinMaxRepayment(monthlyAdditionalRepaymentCalculatorForTenure)
          .getCapitalAndInterest();
      for (SubAccount subAccounts : adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails()) {
        SubAccountMinMaxRepaymentVo subAccountMinMaxRepayment = new SubAccountMinMaxRepaymentVo();
        if (Boolean.TRUE.equals(subAccounts.getSelectedForSwitch())) {
          monthlyAdditionalRepaymentCalculatorForTenure.setMortgageAmount(subAccounts.getTrueBalance().setScale(0, RoundingMode.UP)
              .intValue());
          monthlyAdditionalRepaymentCalculatorForTenure.setExistingBorrowing(calculateExistingBorrowingAmount(monthlyMinMaxRepaymentCalculator,
                  subAccounts.getTrueBalance().setScale(0, RoundingMode.UP).intValue()));
          monthlyAdditionalRepaymentCalculatorForTenure.setCustomerPreferredTermYears(subAccounts.getRemainingTerm().getYears());
          monthlyAdditionalRepaymentCalculatorForTenure.setCustomerPreferredTermMonths(subAccounts.getRemainingTerm().getMonths());
          if (adboCaseDetails.getAdditionalBorrowingCalculator().getCohortDate() != null) {
            monthlyAdditionalRepaymentCalculatorForTenure.setCohortDate(adboCaseDetails.getAdditionalBorrowingCalculator().getCohortDate());
          }
          MinMaxRepaymentVo result = apiService.getMonthlyAdditionalMinMaxRepayment(monthlyAdditionalRepaymentCalculatorForTenure)
              .getCapitalAndInterest();
          subAccountMinMaxRepayment.setSubAccountNumber(subAccounts.getSubAccountNumber());
          subAccountMinMaxRepayment.setMaxRepayment(result.getMaxRepayment());
          subAccountMinMaxRepayment.setMinRepayment(result.getMinRepayment());
          subAccountsSelectedForSwitching.add(subAccountMinMaxRepayment);
        }
      }
      response.setSubAccounts(subAccountsSelectedForSwitching);
      return response;
    } else {
      return apiService.getMonthlyAdditionalMinMaxRepayment(monthlyAdditionalRepaymentCalculatorForTenure)
              .getCapitalAndInterest();

    }
  }

  private Integer calculateExistingBorrowingAmount(MonthlyMinMaxRepaymentCalculator monthlyMinMaxRepaymentCalculator, Integer subAccountTrueBalance) {
    return nonNull(monthlyMinMaxRepaymentCalculator.getBorrowingAmount()) &&
            nonNull(monthlyMinMaxRepaymentCalculator.getTotalTrueBalance()) &&
            nonNull(subAccountTrueBalance) ?
            (monthlyMinMaxRepaymentCalculator.getTotalTrueBalance() + monthlyMinMaxRepaymentCalculator.getBorrowingAmount())
                    - subAccountTrueBalance : 0;
  }
  /**
   * This method has a logic to build the adboCalculator object for Journey validation result is either PASS or Limited after fetching it
   * from the mongodb based on the business criteria If the journey validation is failed then we will return bad request response for the
   * requested account number
   *
   * @param accountNumber is a unique identification number
   * @return adboCalculator object. Which as a sub-account, borrowing need and tenure details.
   */
  @Override
  public AdboCalculator getAdboCalculatorDetails(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseForJourneyValidationPassOrLimited(accountNumber);
    AdditionalBorrowingCalculator additionalBorrowingCalculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    return AdboCalculator.builder()
        .subAccounts(additionalBorrowingCalculator.getSubAccountDetails())
        .propertyType(additionalBorrowingCalculator.getPropertyTypeCode())
        .propertyBuiltType(additionalBorrowingCalculator.getPropertyBuiltType())
        .totalTrueBalance(additionalBorrowingCalculator.getTotalTrueBalance())
        .hpiValuation(BigDecimal.valueOf(additionalBorrowingCalculator.getHpiValuation().intValue()))
        .minBorrowing(minimumBorrowing)
        .maxBorrowing(maximumBorrowing)
        .borrowingAmount(additionalBorrowingCalculator.getBorrowingAmount())
        .estimatedPropertyValue(nonNull(additionalBorrowingCalculator.getEstimatedPropertyValue()) ? BigDecimal.valueOf(
            additionalBorrowingCalculator.getEstimatedPropertyValue()) : null)
        .isPropertyModified(additionalBorrowingCalculator.getPropertyModified())
        .retirementAge(nonNull(additionalBorrowingCalculator.getRetirementAge()) ? additionalBorrowingCalculator.getRetirementAge().get(
            ApplicantType.MAIN.getIndex()) : null)
        .jointApplicantRetirementAge(adboCaseDetails.getAdboApplicants().containsKey(ApplicantType.JOINT1)
            && nonNull(additionalBorrowingCalculator.getRetirementAge()) ? additionalBorrowingCalculator.getRetirementAge().get(
            ApplicantType.JOINT1.getIndex()) : null)
        .repaymentTermYears(additionalBorrowingCalculator.getRepaymentTermYears())
        .repaymentTermMonths(additionalBorrowingCalculator.getRepaymentTermMonths())
        .loanToValue(additionalBorrowingCalculator.getLoanToValue())
        .propertyTenure(additionalBorrowingCalculator.getPropertyTenure())
        .build();
  }

}
