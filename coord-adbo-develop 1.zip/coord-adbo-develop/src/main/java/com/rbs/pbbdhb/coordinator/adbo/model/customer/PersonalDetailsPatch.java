package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.MAIN;
import static org.apache.commons.lang.BooleanUtils.isFalse;
import static org.apache.commons.lang.BooleanUtils.isTrue;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Length;

@Getter
@Setter
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class PersonalDetailsPatch {

  @NotNull(message = "applicantType cannot be null")
  ApplicantType applicantType;

  @NotNull(message = "email cannot be null")
  @Email(regexp = "^[^\\s!£#$%^&*(){}+=\\[\\]:;|<>?/~`,@]+@[^\\s!£#$%^&*(){}+=\\[\\]:;|<>?/~`,@]+\\.[^\\s!£#$%^&*(){}+=\\[\\]:;|<>?/~`,@]+$", message = "Wrong email format")
  @Length(max = 45, message = "The email address should be no longer than 45 characters")
  private String email;

  @NotNull(message = "mobileNumber cannot be null")
  @Pattern(regexp = "^(0[^7]\\d{9,13})|(07\\d{9})$", message = "Wrong mobileNumber format")
  private String mobileNumber;

  @Valid
  private List<com.rbs.pbbdhb.coordinator.adbo.entity.Address> previousAddresses;

  private com.rbs.pbbdhb.coordinator.adbo.entity.Address currentAddressStructuredFormat;

  @ToString.Include
  private Boolean hasDependents;

  @NotNull(message = "maritalStatus cannot be null")
  private MaritalStatus maritalStatus;

  private String nationalityIsoCode;
  @ToString.Include
  private Integer dependentsOver18;
  @ToString.Include
  private Integer dependentsUnder18;
  @ToString.Include
  private Boolean isAboveInformationCorrect;
  @NotNull(message = "currentAddressMoveInDate cannot be null")
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate currentAddressMoveInDate;

  private static LocalDate getLocalDate(Integer moveInYear, Integer moveInMonth) {
    try {
      return LocalDate.of(moveInYear, moveInMonth, 1);
    } catch (DateTimeException e) {
      log.error("Incorrect date - moveInYear={} moveInMonth={}", moveInYear, moveInMonth);
      // this is validated with more details in Address class
    }
    return null;
  }

  // TODO: rewrite with dynamic groups usage {@link jakarta.validation.constraints.NotNull#groups()}
  @AssertTrue(message = "hasDependents cannot be null")
  @ToString.Include
  boolean isHasDependentsRequiredAndNotNull() {
    return applicantType != MAIN || hasDependents != null;
  }

  @AssertTrue(message = "isAboveInformationCorrect cannot be null")
  @ToString.Include
  boolean isIsAboveInformationCorrectRequiredAndNotNull() {
    return applicantType != MAIN || isAboveInformationCorrect != null;
  }

  @AssertTrue(message = "isAboveInformationCorrect has to be selected")
  @ToString.Include
  boolean isIsAboveInformationCorrectRequiredAndSelected() {
    return applicantType != MAIN || isAboveInformationCorrect;
  }

  @AssertTrue(message = "Dependents information is incorrect")
  @ToString.Include
  boolean isDependentsCorrect() {
    if (applicantType != MAIN) {
      return true;
    }
    if (isTrue(hasDependents) && dependentsOver18 != null && dependentsUnder18 != null) {
      return dependentsOver18 + dependentsUnder18 > 0;
    }
    return isFalse(hasDependents) && dependentsOver18 == null && dependentsUnder18 == null;

  }

  @AssertTrue(message = "Previous address move in date is in the future")
  private boolean isPreviousDateInPast() {
    if (previousAddresses == null) {
      return true;
    }
    LocalDate today = LocalDate.now();
    return previousAddresses.stream()
        .map(address -> getLocalDate(address.getMoveInYear(), address.getMoveInMonth()))
        .filter(Objects::nonNull).noneMatch(moveInDate -> moveInDate.isAfter(today));
  }

  @AssertTrue(message = "Please provide a valid email address")
  private boolean isEmailCorrect() {
    return !email.matches(".*\\.con$");
  }

}