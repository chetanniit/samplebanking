package com.rbs.pbbdhb.coordinator.adbo.dto;

import com.rbs.pbbdhb.coordinator.adbo.enums.DashboardDocUploadStatus;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
@Builder
public class DashboardDocUploadDetails {

    /**
     * The status value can be UNKNOWN,COMPLETE,TODO,TODO_AFTER_COMPLETE
     */
    private DashboardDocUploadStatus status;

    /**
     * The enabled field holds boolean value true/false
     * Will set only enabled field value as true when caseId exist otherwise will set false
     */
    private boolean enabled;
}
