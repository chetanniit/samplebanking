package com.rbs.pbbdhb.coordinator.adbo.entity;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerEmploymentDetails {

  private List<GetCustomerEmployed> employed;
  private List<GetCustomerSelfEmployed> selfEmployed;
  private Boolean notEmployed;
  private Boolean retired;
}
