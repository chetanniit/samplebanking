package com.rbs.pbbdhb.coordinator.adbo.request;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.BankDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.OtherIncome;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Retired;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.WorkStatus;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode
public class IncomeRequest  {

  @NotNull(message = "applicantType cannot be null")
  @ToString.Include
  private ApplicantType applicantType;

  @NotNull(message = "currentWorkStatus cannot be null")
  private WorkStatus currentWorkStatus;

  private List<Employment> employments;

  private Retired retired;

  @NotNull(message = "hasOtherIncome cannot be null")
  private Boolean hasOtherIncome;

  private List<OtherIncome> otherIncomes;

  @NotNull(message = "hasBankDetailsModified cannot be null")
  private boolean hasBankDetailsModified;

  private BankDetails bankDetails;

}
