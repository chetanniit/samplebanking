package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;
import static java.util.Optional.ofNullable;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.BankDetails;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class BankDetailsValidator implements Validator {

  private static final Pattern SORT_CODE_REGEX = Pattern.compile("^[0-9]{6}$");
  private static final Pattern ACCOUNT_NUMBER_REGEX = Pattern.compile("^[0-9]{8}$");

  public static boolean isNullOrEmpty(String str) {
    return str == null || str.trim().isEmpty();
  }

  @Override
  public boolean supports(Class<?> clazz) {
    return BankDetails.class.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {
    BankDetails bankDetails = (BankDetails) target;

    if (isNullOrEmpty(bankDetails.getBankAccountName())) {
      errors.rejectValue("bankAccountName", "required-non-empty", "bankAccountName cannot be null or empty");
    } else {
      if (bankDetails.getBankAccountName().length() > 18) {
        errors.rejectValue("bankAccountName", "required-non-empty",
            "bankAccountName cannot be more than 18 characters");
      }
    }

    if (isNullOrEmpty(bankDetails.getBankAccountNumber())) {
      errors.rejectValue("bankAccountNumber", "required-non-empty", "bankAccountNumber cannot be null or empty");
    }

    ofNullable(bankDetails.getBankAccountNumber()).filter(StringUtils::isNotEmpty)
        .ifPresent(a -> this.rejectIfNotMatchingPattern(errors, a, "bankAccountNumber", "required-non-empty",
            "Bank Account number is incorrectly formatted", ACCOUNT_NUMBER_REGEX));

    if (isNullOrEmpty(bankDetails.getBankName())) {
      errors.rejectValue("bankName", "required-non-empty", "bankName cannot be null or empty");
    } else {
      if (bankDetails.getBankName().length() > 30) {
        errors.rejectValue("bankName", "required-non-empty", "bankName cannot be more than 30 characters");
      }
    }
    if (isNullOrEmpty(bankDetails.getBankSortCode())) {
      errors.rejectValue("bankSortCode", "required-non-empty", "bankSortCode cannot be null or empty");
    }

    ofNullable(bankDetails.getBankSortCode()).filter(StringUtils::isNotEmpty)
        .ifPresent(s -> this.rejectIfNotMatchingPattern(errors, s, "bankSortCode", "invalid-format",
            "Sort code is incorrectly formatted", SORT_CODE_REGEX));

    if (isNull(bankDetails.getMonthsWithBank())) {
      errors.rejectValue("monthsWithBank", "required-non-empty", "monthsWithBank cannot be null or empty");
    } else {
      if (bankDetails.getMonthsWithBank() > 11) {
        errors.rejectValue("monthsWithBank", "required-non-empty",
            "monthsWithBank cannot be more than 11 months");
      }
      if (bankDetails.getMonthsWithBank() < 0) {
        errors.rejectValue("monthsWithBank", "required-non-empty",
            "Invalid months with Bank entered ,minimim months must be 0");
      }
    }
    if (isNull(bankDetails.getYearsWithBank())) {
      errors.rejectValue("yearsWithBank", "required-non-empty", "yearsWithBank cannot be null or empty");
    } else {
      if (bankDetails.getYearsWithBank() > 50) {
        errors.rejectValue("yearsWithBank", "required-non-empty",
            "maximum years with bank cannot be more than 50");
      }

      if (bankDetails.getYearsWithBank() < 0) {
        errors.rejectValue("yearsWithBank", "required-non-empty",
            "Invalid years with Bank entered ,minimim years must be 0");
      }
    }

  }

  private void rejectIfNotMatchingPattern(Errors errors, String field, String fieldName, String errorCode,
      String message, Pattern pattern) {
    if (!pattern.matcher(field).matches()) {
      errors.rejectValue(fieldName, errorCode, message);
    }
  }

}
