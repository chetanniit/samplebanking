package com.rbs.pbbdhb.coordinator.adbo.utils;

import static java.util.stream.Collectors.toList;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.rbs.pbbdhb.error.BaseResponse;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.List;
import java.util.Locale;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.NonNull;
import org.springframework.util.StringUtils;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * This class is a copy of {@link com.rbs.pbbdhb.error.ControllerExceptionHandler} adjusted to meet the newest logging standards
 */
@ControllerAdvice(
    basePackages = {"com.rbs.pbbdhb"}
)
@Slf4j
@RequiredArgsConstructor
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {

  private final MessageSource messageSource;

  @Value("${application.name}:Exception in processing request for mortgage process:")
  private String errorMessage;


  @NonNull
  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(@NonNull HttpMessageNotReadableException ex, @NonNull HttpHeaders headers,
      @NonNull HttpStatusCode status, @NonNull WebRequest request) {
    log.error(errorMessage, ex);
    String message;
    if (ex.getMostSpecificCause() instanceof InvalidFormatException) {
      message = ((InvalidFormatException) ex.getMostSpecificCause()).getOriginalMessage();
    } else {
      message = ex.getMessage();
    }

    return new ResponseEntity<>(new BaseResponse(message), HttpStatus.BAD_REQUEST);
  }

  @NonNull
  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(@NonNull MethodArgumentNotValidException ex, @NonNull HttpHeaders headers,
      @NonNull HttpStatusCode status, @NonNull WebRequest request) {
    log.error(errorMessage, ex);
    List<ObjectError> fieldErrors = ex.getBindingResult().getAllErrors();
    List<String> messages = fieldErrors.stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(toList());
    return new ResponseEntity<>(new BaseResponse(StringUtils.collectionToCommaDelimitedString(messages)), HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler({ConstraintViolationException.class})
  public ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException ex, WebRequest ignoredRequest) {
    log.error(errorMessage, ex);
    List<String> messages = ex.getConstraintViolations().stream().map(ConstraintViolation::getMessage).collect(toList());
    return new ResponseEntity<>(new BaseResponse(Strings.join(messages, ',')), HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler({BusinessException.class})
  public ResponseEntity<Object> handleBusinessException(BusinessException ex, WebRequest request) {
    log.error(errorMessage, ex);
    String message = messageSource.getMessage(ex.getMessage(), null, Locale.ENGLISH);
    HttpStatusCode httpStatus = null == ex.getStatusCode() ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.valueOf(ex.getStatusCode());
    return this.handleExceptionInternal(ex, new BaseResponse(message), new HttpHeaders(), httpStatus, request);
  }

  @ExceptionHandler({Exception.class})
  public ResponseEntity<Object> handleGenericException(Exception ex, WebRequest request) {
    log.error(errorMessage, ex);
    return this.handleExceptionInternal(ex, new BaseResponse("Something went wrong. Please try again or contact support."),
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

}
