package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.util.EligibleToSwitchCheckAndSetForSubAccount;
import com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class FixedEligibleToSwitchValidator extends AbstractValidator {

  private final EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount;
  public FixedEligibleToSwitchValidator(@Value("${journeyValidator.priority.fixedEligibleToSwitch}") int priority, EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount) {
    super(priority, ValidationRuleResultCode.PASS_ELIGIBLE_TO_SWITCH_FIXED_RATE);
    this.eligibleToSwitchCheckAndSetForSubAccount = eligibleToSwitchCheckAndSetForSubAccount;
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    List<SubAccount> subAccounts = journeyValidation.getAccountSummaryApiResponse().getSubAccounts();
    for (SubAccount subAccount : subAccounts) {
      boolean isEligibleToSwitch = eligibleToSwitchCheckAndSetForSubAccount.fixedEligibleToSwitch(subAccount, journeyValidation.getAccountSummaryApiResponse().getSysDate());
      if (isEligibleToSwitch) {
        return true;
      }
    }
    return false;
  }

}
