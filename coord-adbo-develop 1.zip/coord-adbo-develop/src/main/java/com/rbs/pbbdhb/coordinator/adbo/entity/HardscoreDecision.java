package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class HardscoreDecision {

  private String decisionUniqueId;
  private String decision;
  private String podDecision;
  private List<Policy> policyMessages;
  private List<KycMessage> kycMessages;
  private Packaging packaging;
  private AdditionalDetails additionalDetails;

}

