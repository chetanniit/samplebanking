package com.rbs.pbbdhb.coordinator.adbo.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

  /**
   * http://localhost:server.port/context.root/swagger-ui/index.html - for UI http://localhost:server.port/context.root/v3/api-docs - for
   * json
   */
  @Bean
  public OpenAPI apiInfo() {
    return new OpenAPI().info(new Info()
        .title("External Coordinator")
        .description("External Coordinator API's")
        .version("v1"));
  }
}