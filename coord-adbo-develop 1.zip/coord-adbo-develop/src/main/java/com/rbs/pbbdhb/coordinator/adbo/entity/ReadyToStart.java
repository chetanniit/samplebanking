package com.rbs.pbbdhb.coordinator.adbo.entity;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReadyToStart  {

  @NotNull(message = "Please read 5 Fraud warnings before proceeding")
  @AssertTrue(message = "Please Acknowledge that you have read 5 Fraud warnings before proceeding")
  private Boolean hasAcknowledgedFraudWarning;
}
