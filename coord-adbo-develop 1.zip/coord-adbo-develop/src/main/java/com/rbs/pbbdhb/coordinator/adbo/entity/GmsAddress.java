package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class GmsAddress  {

  private String address1;
  private String address2;
  private String address3;
  private String address4;
  private String address5;
  private String postcode;
  private String countryCode;

}