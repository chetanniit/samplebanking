package com.rbs.pbbdhb.coordinator.adbo.model.product;

import static com.rbs.pbbdhb.coordinator.adbo.enums.FeeAction.ADD_CAPITALISE_TO_LOAN;
import static org.springframework.util.ObjectUtils.isEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductFeeType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductTerm;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboSwitchMonthlyPaymentsResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboSwitchMonthlyPaymentsSubAccount;

import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Product {

  @JsonProperty(value = "class", index = 0)
  private ProductFeeType productFeeType;

  private String productCode;

  private ProductType productType;

  private ProductTerm productTerm;

  private Double initialInterestRate;

  private Double ltv;

  private Integer productFee;

  private Integer initialMonthlyPayment;

  private BigDecimal initialMonthlyPaymentForSwitcher;
  
  private BigDecimal newEstimatedMonthlyPayment;

  private Integer productTermCost;

  private Integer feeWrappedInitialMonthlyPayment;

  private BigDecimal feeWrappedInitialMonthlyPaymentForSwitcher;

  private Integer feeWrappedProductTermCost;

  private Integer standardValuationFee;

  private String valuationFeeMessage;

  private Double svr;

  private String productStartDate;

  private String productEndDate;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<ProductFee> fees;

  private String productName;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<EarlyRepaymentCharge> earlyRepaymentCharges;

  private Integer mortgageTermYears;

  private Integer mortgageTermMonths;

  private String customerType;

  private Double baseRate;

  private Double trackerMarginPercent;

  private AdboSwitchMonthlyPaymentsResponse adboSwitchMonthlyPaymentsResponse;

  @JsonIgnore
  public Boolean isProductFeeAddedToBorrowing() {
    return !isEmpty(fees) &&
        !isEmpty(fees.get(0)) &&
        !isEmpty(fees.get(0).getFeeAction()) &&
        fees.get(0).getFeeAction() == ADD_CAPITALISE_TO_LOAN;
  }
  
}