package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum FeePaymentType {
  CARD_PAYMENT, CHEQUE, DIRECT_DEBIT, FEE_MANAGEMENT_SYSTEM, INTER_BRANCH_PAYMENT
}
