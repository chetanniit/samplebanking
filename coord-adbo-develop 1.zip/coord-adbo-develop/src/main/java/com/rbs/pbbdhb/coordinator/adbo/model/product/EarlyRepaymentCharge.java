package com.rbs.pbbdhb.coordinator.adbo.model.product;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EarlyRepaymentCharge {

  private String term;
  private Integer year;
  private Double charge;
  private String earlyRepaymentInterestDate;
}