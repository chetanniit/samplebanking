package com.rbs.pbbdhb.coordinator.adbo.controller;

import static org.springframework.http.ResponseEntity.ok;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.AdboCalculatorControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails;
import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyMinMaxRepaymentCalculator;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboCalculator;
import com.rbs.pbbdhb.coordinator.adbo.response.MinMaxRepaymentVo;
import com.rbs.pbbdhb.coordinator.adbo.service.AdboCalculatorService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import com.rbs.pbbdhb.coordinator.adbo.validator.BorrowingDetailsValidator;
import com.rbs.pbbdhb.coordinator.adbo.validator.MonthlyMinMaxRepaymentCalculatorValidator;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequestMapping(value = "/calculator")
public class AdboCalculatorController implements AdboCalculatorControllerSwagger {

  private final AdboCalculatorService adboCalculatorService;
  private final MonthlyMinMaxRepaymentCalculatorValidator monthlyMinMaxRepaymentCalculatorValidator;
  private final BorrowingDetailsValidator borrowingDetailsValidator;

  @Autowired
  public AdboCalculatorController(AdboCalculatorService adboCalculatorService,
      MonthlyMinMaxRepaymentCalculatorValidator monthlyMinMaxRepaymentCalculatorValidator,
      BorrowingDetailsValidator borrowingDetailsValidator) {
    this.adboCalculatorService = adboCalculatorService;
    this.monthlyMinMaxRepaymentCalculatorValidator = monthlyMinMaxRepaymentCalculatorValidator;
    this.borrowingDetailsValidator = borrowingDetailsValidator;
  }

  @InitBinder("monthlyMinMaxRepaymentCalculator")
  protected void initMonthlyMinMaxRepaymentCalculatorBinder(WebDataBinder binder) {
    binder.addValidators(monthlyMinMaxRepaymentCalculatorValidator);
  }

  @InitBinder("borrowingDetails")
  protected void initBorrowingDetailsBinder(WebDataBinder binder) {
    binder.addValidators(borrowingDetailsValidator);
  }

  /**
   * This method is responsible for persist the borrowing needs and tenure details into the mongodb.
   *
   * @param accountNumber    is a unique identification number
   * @param brand            is nwb or rbs
   * @param borrowingDetails object contains borrowingAmount, estimatedPropertyValue,retirementAge,repaymentTermYears,
   *                         repaymentTermMonths,loanToValue,and isPropertyModified properties.
   * @return void
   */
  @Override
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveBorrowingDetails(@RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "borrowingDetails") @RequestBody @Valid BorrowingDetails borrowingDetails) {
    log.info("saveBorrowingDetails start Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute, borrowingDetails);
    TenantProvider.applyBrand(brand);
    adboCalculatorService.saveBorrowingDetails(accountNumber, borrowingDetails);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveBorrowingDetails ends with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * This method is responsible to call msvc-product microservice for to calculate the monthly additional min and max repayments.
   *
   * @param brand                            is a nwb or rbs
   * @param monthlyMinMaxRepaymentCalculator object has borrowingAmount, termYears, termMonths,existingBorrowing and loanToValue
   */
  @Override
  @PostMapping(path = "/minMaxRepayment", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MinMaxRepaymentVo> getMonthlyMinMaxRepayment(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "monthlyMinMaxRepaymentCalculator") @RequestBody @Valid MonthlyMinMaxRepaymentCalculator monthlyMinMaxRepaymentCalculator) {
    log.info("getMonthlyMinMaxRepayment start Headers - account_number: {}, brand: {}, channel: {}, request: {}",
        accountNumber, brand, channelRoute, monthlyMinMaxRepaymentCalculator);
    TenantProvider.applyBrand(brand);
    ResponseEntity<MinMaxRepaymentVo> response = ok(adboCalculatorService.getMonthlyMinMaxRepayment(monthlyMinMaxRepaymentCalculator,accountNumber));
    log.info("getMonthlyMinMaxRepayment end's with response: {} for account_number: {}, brand: {}, channel: {}", response.getBody(),
        accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * This operation is used to fetch calculator details for ABC Page details and return
   *
   * @param accountNumber is unique identification number
   * @param brand         is a nwb or rbs return adboCalculator object which has sub account,borrowing need and tenure details
   */

  @Override
  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<AdboCalculator> getAdboCalculatorDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getAdboCalculatorDetails start Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<AdboCalculator> response = ok(adboCalculatorService.getAdboCalculatorDetails(accountNumber));
    log.info("getAdboCalculatorDetails end with response: {} for account_number: {} , brand: {}, channel: {}", response.getBody(),
        accountNumber, brand, channelRoute);
    return response;
  }

}
