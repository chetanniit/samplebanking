package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.AgreementsAndDisclaimersRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AgreementsAndDisclaimersResponse;

public interface AgreementsAndDisclaimersService {

  AgreementsAndDisclaimersResponse getAgreementsAndDisclaimers(String accountNumber);

  void updateAgreementsAndDisclaimers(String accountNumber, AgreementsAndDisclaimersRequest agreementsAndDisclaimers);

}
