package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class ForfeitureOfLeaseValidator extends AbstractValidator {

  public ForfeitureOfLeaseValidator(@Value("${journeyValidator.priority.forfeitureOfLease}") int priority) {
    super(priority, ValidationRuleResultCode.FAILED_DUE_TO_FORFEITURE_OF_LEASE);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return journeyValidation.getAccountSummaryApiResponse().isForfeitureOfLease();
  }
}
