package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import java.math.BigDecimal;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Getter
@Setter
public class SecondChargeRedemption  implements AdboAmountDistribution {

  @AssertTrue(message = "Second Charge Redemption figure must be true for second charge borrowing purpose")
  @NotNull(message = "Redemption figure cannot be null")
  private Boolean redemptionFigure;

  @Positive(message = "Borrowing purpose amount should not be zero")
  @NotNull(message = "Borrowing purpose amount cannot be null")
  private BigDecimal amount;
  private BorrowingPurposeType type;

  @Override
  public BigDecimal getAmount() {
    return amount;
  }

  @Override
  public BorrowingPurposeType getType() {
    return type;
  }


}
