package com.rbs.pbbdhb.coordinator.adbo.mapper;

import com.rbs.pbbdhb.coordinator.adbo.request.PaymentUrlRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface AdboPaymentMapper {

  @Mapping(target = "mortgageReferenceNumber", source = "accountNumber")
  @Mapping(target = "applicationType", constant = "ADDITIONAL_BORROWING")
  PaymentUrlRequest paymentUrlRequest(String accountNumber);
}
