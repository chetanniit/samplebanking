package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode;
import com.rbs.pbbdhb.coordinator.adbo.enums.Route;
import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import java.util.Map.Entry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RouteServiceImpl implements RouteService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public void saveRoute(String accountNumber, String cin, Route route,
      ValidationRuleResultCode validationRuleResultCode) {
    if (validationRuleResultCode.getJourneyValidationResultCode() != JourneyValidationResultCode.FAILED) {
      AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
      boolean changed = false;
      for (Entry<ApplicantType, AdboApplicant> entry : adboCaseDetails.getAdboApplicants().entrySet()) {
        ApplicantType type = entry.getKey();
        AdboApplicant applicant = entry.getValue();
        if (cin.equals(applicant.getCin())) {
          applicant.setRoute(route);
          changed = true;
// TODO remove following statement with {@link AdboCaseDetails#route}
          if (type == ApplicantType.MAIN) {
// noinspection deprecation
            adboCaseDetails.setRoute(route);
          }
        }
      }
      if (changed) {
        adboCaseDetailsDao.save(adboCaseDetails);
      }
    }
  }
}
