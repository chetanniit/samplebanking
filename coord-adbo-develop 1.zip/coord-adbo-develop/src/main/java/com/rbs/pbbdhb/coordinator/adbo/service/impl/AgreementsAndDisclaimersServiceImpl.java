package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.READ_SWITCH_ILLUSTRATION_REQUIRED;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.MAIN;
import static java.lang.Boolean.TRUE;
import static java.util.Objects.isNull;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.AgreementsAndDisclaimers;
import com.rbs.pbbdhb.coordinator.adbo.request.AgreementsAndDisclaimersRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AgreementsAndDisclaimersResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AgreementsAndDisclaimersService;
import com.rbs.pbbdhb.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class AgreementsAndDisclaimersServiceImpl implements AgreementsAndDisclaimersService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public AgreementsAndDisclaimersResponse getAgreementsAndDisclaimers(String accountNumber) {
    log.info("Fetching Agreements & Disclaimers of customer account number :: {} ", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    AgreementsAndDisclaimers agreementsAndDisclaimers = getAgreementsAndDisclaimersForMainApplicant(adboCaseDetails);

    return AgreementsAndDisclaimersResponse.builder()
        .readAboutOurMortgageRange(agreementsAndDisclaimers.getReadAboutOurMortgageRange())
        .readMortgageIllustration(agreementsAndDisclaimers.getReadMortgageIllustration())
        .readSwitchIllustration(agreementsAndDisclaimers.getReadSwitchIllustration())
        .build();
  }

  @Override
  public void updateAgreementsAndDisclaimers(String accountNumber, AgreementsAndDisclaimersRequest agreementsAndDisclaimersRequest) {
    log.info("Saving Agreements & Disclaimers of customer is start for accountNumber {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    validateRequest(agreementsAndDisclaimersRequest, adboCaseDetails);
    AgreementsAndDisclaimers agreementsAndDisclaimers = getAgreementsAndDisclaimersForMainApplicant(adboCaseDetails);
    agreementsAndDisclaimers.setReadMortgageIllustration(agreementsAndDisclaimersRequest.getReadMortgageIllustration());
    agreementsAndDisclaimers.setReadAboutOurMortgageRange(agreementsAndDisclaimersRequest.getReadAboutOurMortgageRange());
    agreementsAndDisclaimers.setReadSwitchIllustration(agreementsAndDisclaimersRequest.getReadSwitchIllustration());
    adboCaseDetailsDao.save(adboCaseDetails);
    log.info("Saved Agreements & Disclaimers of customer end for accountNumber {}", accountNumber);
  }

  private void validateRequest(AgreementsAndDisclaimersRequest request, AdboCaseDetails adboCaseDetails) {
    if (TRUE.equals(adboCaseDetails.getAdditionalBorrowingWithSwitch()) && isNull(request.getReadSwitchIllustration())) {
      throw new BusinessException(READ_SWITCH_ILLUSTRATION_REQUIRED, HttpStatus.BAD_REQUEST.value());
    }
  }

  private AgreementsAndDisclaimers getAgreementsAndDisclaimersForMainApplicant(AdboCaseDetails adboCaseDetails) {
    AgreementsAndDisclaimers agreementsAndDisclaimers = adboCaseDetails.getAdboApplicants().get(MAIN).getAgreementsAndDisclaimers();
    if (ObjectUtils.isEmpty(agreementsAndDisclaimers)) {
      throw new BusinessException(Constants.AGREEMENT_AND_DISCLAIMERS_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    return agreementsAndDisclaimers;
  }
}
