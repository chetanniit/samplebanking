package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Gender;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import java.time.LocalDate;
import java.util.Set;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Singular;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
@Builder
public class DipPersonalDetails {

  @NotNull
  private final Title title;

  private final String otherTitle;

  @NotNull
  @Size(min = 1, max = 15)
  private final String firstNames;

  @Size(max = 25)
  private final String middleNames;

  @NotNull
  @Size(min = 1, max = 30)
  private final String lastName;

  private final Gender gender;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_PATTERN)
  private final LocalDate dateOfBirth;

  private final MaritalStatus maritalStatus;

  @NotNull
  @Size(max = 2)
  private final String nationality;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean rightToReside;

  @NotNull
  @Size(max = 2)
  private final String countryOfResidenceIsoCode;

  @Singular
  private final Set<Telephone> telephones;

  @Size(max = 72)
  @Pattern(regexp = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$")
  private final String email;

}
