package com.rbs.pbbdhb.coordinator.adbo.entity;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Applicant {

  private String applicantId;

  private String createdDate;

  private String caseId;

  private Boolean mainApplicant;

  private String cin;

  private List<String> multiCins;

  private Integer gmsCustomerId;

  private String applicationStatus;

  private String customerType;

  private String version;
}

