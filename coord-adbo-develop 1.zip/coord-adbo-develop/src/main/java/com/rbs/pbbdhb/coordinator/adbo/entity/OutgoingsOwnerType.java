package com.rbs.pbbdhb.coordinator.adbo.entity;

public enum OutgoingsOwnerType {

  MAIN,
  JOINT1,
  BOTH
}
