package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails;
import java.util.Map;

public interface AdboCalculatorValidator {

  void validateLoanToValue(String accountNumber, BorrowingDetails borrowingDetails, AdboCaseDetails adboCaseDetails);

  Map<ApplicantType, Integer> prepareAndValidateRetirementAge(String accountNumber, BorrowingDetails borrowingDetails,
      AdboCaseDetails adboCaseDetails);
}
