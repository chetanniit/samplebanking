package com.rbs.pbbdhb.coordinator.adbo.service;

import static java.util.Objects.nonNull;
import static org.mapstruct.NullValuePropertyMappingStrategy.IGNORE;

import com.google.common.collect.ImmutableMap;
import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.GmsCodeToCountryIso;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsPatch;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsResponse;
import java.util.Map;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", imports = {GmsCodeToCountryIso.class})
public interface PersonalDetailsMapper {

  Map<String, String> FLAT_NUMBER_KEYWORDS_TO_REPLACEMENT_STRING = ImmutableMap.of(
      "(?i)apartment", "Apt",
      "(?i)flat", "Flt",
      "(?i)floor", "Flr",
      "(?i)basement", "Bst",
      "(?i)ground", "Gnd");

  /**
   * Copy personal details from patch request to db model. <br>
   *
   * <p>
   * This class does not validate input data.
   * </p>
   *
   * @param patch           Request data
   * @param personalDetails Previous personal details from db
   */
  @Mapping(target = "email", source = "patch.email", nullValuePropertyMappingStrategy = IGNORE)
  @Mapping(target = "mobileNumber", source = "patch.mobileNumber", nullValuePropertyMappingStrategy = IGNORE)
  @Mapping(target = "nationalityIsoCode", source = "patch.nationalityIsoCode", nullValuePropertyMappingStrategy = IGNORE)
  @Mapping(target = "maritalStatus", source = "patch.maritalStatus", nullValuePropertyMappingStrategy = IGNORE)
  void map(PersonalDetailsPatch patch, @MappingTarget PersonalDetails personalDetails);

  @AfterMapping
  default void afterPersonalDetailsMapping(PersonalDetailsPatch personalDetailsPatch,
      @MappingTarget PersonalDetails personalDetails) {
    Address currentAddressStructuredFormat = personalDetails.getCurrentAddressStructuredFormat();
    adjustFlatNumberLengthIfRequired(currentAddressStructuredFormat);
    adjustCountyLengthIfRequired(currentAddressStructuredFormat);
    addCountryIsoCodeToCurrentAddressStructuredFormat(currentAddressStructuredFormat);
    if (personalDetails.getPreviousAddresses() != null) {
      personalDetails.getPreviousAddresses().forEach(address -> {
        address.setCountryIsoCode(address.getCountry());
        if (address.getPostcode() != null) {
          address.setPostcode(address.getPostcode().trim());
        }
      });
    }
  }

  default void adjustFlatNumberLengthIfRequired(Address currentAddressStructuredFormat) {
    if (nonNull(currentAddressStructuredFormat) && nonNull(currentAddressStructuredFormat.getFlatNumber())
        && currentAddressStructuredFormat.getFlatNumber().length() > 10) {
      currentAddressStructuredFormat.setFlatNumber(
          getFlatNumberWithSpecifiedLength(currentAddressStructuredFormat.getFlatNumber(), 10));
    }
  }

  default String getFlatNumberWithSpecifiedLength(String flatNumber, int length) {
    // try to handle keywords
    for (Map.Entry<String, String> entry : FLAT_NUMBER_KEYWORDS_TO_REPLACEMENT_STRING.entrySet()) {
      if (flatNumber.length() > length) {
        flatNumber = flatNumber.replaceAll(entry.getKey(), entry.getValue());
      }
    }
    return (flatNumber.length() > length) ? flatNumber.substring(0, 3) + flatNumber.substring(
        flatNumber.length() - (length - 3)) : flatNumber;
  }

  default void addCountryIsoCodeToCurrentAddressStructuredFormat(Address currentAddress) {
    GmsCodeToCountryIso countryCode = GmsCodeToCountryIso.fromIsoCode(currentAddress.getCountry());
    if (countryCode == null) {
      countryCode = GmsCodeToCountryIso.fromGmsCode(currentAddress.getCountry());
    }
    if (countryCode == null) {
      countryCode = GmsCodeToCountryIso.fromIsoCode("GB");
    }
    currentAddress.setCountryIsoCode(countryCode.getCountryIsoCode());
  }

  /**
   * Create response from PersonalDetails
   *
   * @param personalDetails Personal details to copy
   * @param applicantType   Applicant type to set
   * @return Response created from loaded personal details
   */
  @Mapping(target = "nationality", source = "personalDetails.nationalityIsoCode", qualifiedByName = "toNationalityDescription")
  @Mapping(target = "maritalStatus", source = "personalDetails.maritalStatus")
  @Mapping(target = "isMobileNumberChanged", expression = "java(personalDetails.isMobileNumberChanged())")
  @Mapping(target = "isEmailChanged", expression = "java(personalDetails.isEmailChanged())")
  @Mapping(target = "isMaritalStatusChanged", expression = "java(personalDetails.isMaritalStatusChanged())")
  @Mapping(target = "isNationalityChanged", expression = "java(personalDetails.isNationalityChanged())")
  PersonalDetailsResponse mapToResponse(PersonalDetails personalDetails, ApplicantType applicantType);

  @Named("toNationalityDescription")
  default String toNationalityDescription(String nationalityIsoCode) {
    if (nationalityIsoCode != null && !nationalityIsoCode.isEmpty()) {
      return GmsCodeToCountryIso.fromIsoCode(nationalityIsoCode).getDescription();
    }
    return null;
  }


  default void adjustCountyLengthIfRequired(Address currentAddressStructuredFormat) {
    if (nonNull(currentAddressStructuredFormat) && nonNull(currentAddressStructuredFormat.getCounty())
        && currentAddressStructuredFormat.getCounty().length() > 18) {
      currentAddressStructuredFormat.setCounty(
          currentAddressStructuredFormat.getCounty().substring(0, 18));
    }
  }
}
