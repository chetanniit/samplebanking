package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
@Builder
public class DipAddress {

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean isCurrentAddress;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean ukAddress;

  @Size(max = 10)
  private final String flat;

  @Size(max = 22)
  private final String houseName;

  @Size(max = 5)
  private final String houseNumber;

  @NotNull
  private final String postcode;

  @NotNull
  @Size(max = 30)
  private final String street;

  @Size(max = 30)
  private final String district;

  @NotNull
  @Size(max = 28)
  private final String town;

  @Size(max = 18)
  private final String county;

  @NotNull
  @Size(max = 2)
  private final String countryIsoCode;

  @NotNull
  private final OccupancyStatusEnum occupyStatus;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  @Min(1)
  @Max(12)
  private final Integer startMonth;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  @Min(1900)
  private final Integer startYear;

  public enum OccupancyStatusEnum {
    OWNER_MORTGAGED,
    OWNER_NO_MORTGAGE,
    TENANT,
    OTHER,
    LIVING_WITH_RELATIVES
  }

}
