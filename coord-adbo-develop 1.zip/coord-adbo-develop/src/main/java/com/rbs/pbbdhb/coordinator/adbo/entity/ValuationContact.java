package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValuationContact {

  /**
   * full name
   */
  private String fullName;
  /**
   * mobile number
   */
  private String mobileNumber;

}
