package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;

public interface AsyncDataLoader {

  JourneyValidation getValidationData(String accountNumber, String cin);

}
