package com.rbs.pbbdhb.coordinator.adbo.request;

import java.io.Serializable;
import java.math.BigDecimal;

import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SubAccountMonthlyMinMaxRepaymentCalculator implements Serializable{
  
  /**
   * 
   */
  private static final long serialVersionUID = 7674879543474730363L;
  private Integer subAccountNumber;
  private BigDecimal mortgageAmount;
  private TimePeriod remainingTerm;

}
