package com.rbs.pbbdhb.coordinator.adbo.entity.abc;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import com.rbs.pbbdhb.coordinator.adbo.enums.PropertyTenure;
import com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Getter
@Setter
public class AdditionalBorrowingCalculator  {

  private List<SubAccount> subAccountDetails;

  private String propertyTypeCode;//Flat or House

  private String propertyGmsTypeCode;//FL,D,SM,B,X
  private String propertyGmsBuildType;
  private String propertyBuiltType;//New Build or Old Build
  private int propertyYearBuilt;
  private PropertyTenure propertyTenure;
  private BigDecimal totalTrueBalance;
  private BigDecimal hpiValuation;
  @JsonFormat(pattern = DATE_PATTERN)
  private LocalDate hpiValuationDate;
  private Integer borrowingAmount;
  private Integer estimatedPropertyValue;
  private Boolean propertyModified;
  private List<Integer> retirementAge;
  private Integer repaymentTermYears;
  private Integer repaymentTermMonths;
  private BigDecimal loanToValue;
  private LocalDate cohortDate;
  private RepaymentType repaymentType = RepaymentType.CAPITAL_AND_INTEREST;
  private List<AdboAmountDistribution> adboAmountDistributions;
}
