package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum CaseStatus {

  HARDSCORE_DECLINED,
  SUBMIT_GMS_STAGE_20,
  SUBMIT_GMS_MOPS,
  CONTRACT_VALIDATION_ERROR,
  SUBMIT_ORCHESTRATION,
  CAPIE_UPDATED
}
