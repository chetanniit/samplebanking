package com.rbs.pbbdhb.coordinator.adbo.request;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.APPLICATION_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHANNEL_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CUSTOMER_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DD_MM_YYYY_DATE_PATTERN;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.MORTGAGE_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.REPAYMENT_TYPE;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import java.io.Serializable;
import java.time.LocalDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MonthlyAdditionalRepaymentCalculatorForTenure implements Serializable {

  private static final long serialVersionUID = 3106666591967814094L;

  private String mortgageType;

  private String repaymentType;

  private String applicationType;

  private String customerType;

  private String channel;

  private Integer mortgageAmount;

  private int existingBorrowing;

  private Integer customerPreferredTermYears;

  private Integer customerPreferredTermMonths;

  private Double ltv;

  private ProductType productType;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate cohortDate;

  public MonthlyAdditionalRepaymentCalculatorForTenure(Integer mortgageAmount, int existingBorrowing, Integer customerPreferredTermYears,
      Integer customerPreferredTermMonths, Double ltv) {
    mortgageType = MORTGAGE_TYPE;
    repaymentType = REPAYMENT_TYPE;
    applicationType = APPLICATION_TYPE;
    customerType = CUSTOMER_TYPE;
    channel = CHANNEL_TYPE;
    this.mortgageAmount = mortgageAmount;
    this.existingBorrowing = existingBorrowing;
    this.customerPreferredTermYears = customerPreferredTermYears;
    this.customerPreferredTermMonths = customerPreferredTermMonths;
    this.ltv = ltv;
  }

}
