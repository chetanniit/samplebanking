package com.rbs.pbbdhb.coordinator.adbo.mapper;

import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerAddress;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface AddressMapper {

  @Mapping(target = "countryCode", source = "addressCountry")
  @Mapping(target = "postcode", expression = "java((address != null && address.getAddressPC() !=null) ? address.getAddressPC().trim():address.getAddressPC())")
  GmsAddress mapAddress(GetCustomerAddress address);
}
