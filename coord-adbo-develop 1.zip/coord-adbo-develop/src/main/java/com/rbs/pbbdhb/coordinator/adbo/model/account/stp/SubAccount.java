package com.rbs.pbbdhb.coordinator.adbo.model.account.stp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.enums.MappedProdType;
import com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType;
import com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType;
import com.rbs.pbbdhb.coordinator.adbo.enums.SubAccountType;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SubAccount implements Serializable {

  private Integer sequenceNumber;
  private BigDecimal currentBalance;
  private String interestType;
  private BigDecimal interestRate;
  private BigDecimal baseRate;
  private BigDecimal monthlyPayment;
  private TimePeriod remainingTerm;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN)
  private LocalDate termEndDate;
  private BigDecimal arrear;
  private RepaymentType repaymentType;
  private Integer subAccountNumber;
  private BigDecimal trueBalance;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN)
  private LocalDate currentDealEnds;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN)
  private LocalDate dealStartDate;
  private Boolean selectedForSwitch;
  private Boolean eligibleToSwitch = false;
  private Integer productTerm;
  private NewDealStartDateType newDealStartDateType;
  private Boolean switchImmediately;
  private SubAccountType subAccountType;
  private MappedProdType mappedProdType;

  public static class SubAccountNumberComparator implements Comparator<SubAccount> {

    @Override
    public int compare(SubAccount sa1, SubAccount sa2) {
      return Integer.compare(sa1.getSubAccountNumber(), sa2.getSubAccountNumber());
    }

  }
}