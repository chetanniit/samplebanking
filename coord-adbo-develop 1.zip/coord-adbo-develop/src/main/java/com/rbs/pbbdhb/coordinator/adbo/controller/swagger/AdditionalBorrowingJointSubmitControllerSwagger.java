package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingJointSubmitRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "20 - Final step of a addition borrowing for Joint applicant", description = "Step for joint applicant to submit agreement-disclaimers and marketing permissions")
public interface AdditionalBorrowingJointSubmitControllerSwagger {


  @Operation(description = "Save joint applicant agreement-disclaimers and marketing preference", operationId = "saveAdditionalBorrowingJointSubmit", summary = "Save Joint applicant agreement-disclaimers and marketing preference",
      responses = {
          @ApiResponse(responseCode = "204", content = @Content),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
          @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
          @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Void> saveAdditionalBorrowingJointSubmit(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.CIN) @CIN String customerId,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest);

}
