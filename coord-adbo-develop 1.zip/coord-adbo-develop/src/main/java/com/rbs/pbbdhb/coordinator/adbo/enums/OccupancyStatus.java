package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum OccupancyStatus {
  LIVING_WITH_FAMILY,
  LIVING_WITH_FRIENDS,
  LIVING_WITH_PARTNER,
  TENANT,
  OWNER_NO_MORTGAGE,
  OWNER_MORTGAGED
}