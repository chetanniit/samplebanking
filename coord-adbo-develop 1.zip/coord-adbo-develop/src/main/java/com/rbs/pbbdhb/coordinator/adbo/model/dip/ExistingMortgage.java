package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigInteger;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExistingMortgage {

  private final TypeEnum type;

  private final OwnershipEnum ownership;

  private final BigInteger monthlyRepaymentAmount;

  private final BigInteger outstandingAmount;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean redeemingMortgage;

  public enum TypeEnum {
    RESIDENTIAL,
    REPAYMENT
  }

  public enum OwnershipEnum {
    JOINT,
    SINGLE
  }

}

