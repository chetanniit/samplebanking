package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;


public enum AdditionalIncomeSources {

  BONUS("BONUS"),
  OVERTIME("OVERTIME"),
  COMMISSION("COMMISSION"),
  SHIFT_ALLOWANCE("SHIFT_ALLOWANCE"),
  CAR_ALLOWANCE("CAR_ALLOWANCE");

  private final String label;

  AdditionalIncomeSources(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }
}
