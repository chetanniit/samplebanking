package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.HomeImprovementsType;
import java.math.BigDecimal;
import java.util.List;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Getter
@Setter
public class HomeImprovement  implements AdboAmountDistribution {

  @NotNull(message = "living elsewhere for more than 6 months field cannot be null")
  private Boolean livingElseWhereMoreThan6Months;
  @NotNull(message = "Customer must answer if they need planning permission for home improvement")
  private Boolean planningPermissionRequired;
  private Boolean planningPermissionAcquired;

  private List<HomeImprovementsType> homeImprovementPlans;

  @NotNull(message = "Borrowing purpose amount cannot be null")
  @Positive(message = "Borrowing Purpose amount should not be zero")
  private BigDecimal amount;
  private BorrowingPurposeType type;

  @Override
  public BigDecimal getAmount() {
    return amount;
  }

  @Override
  public BorrowingPurposeType getType() {
    return type;
  }

  @AssertTrue(message = "Given planning permission is needed for home improvement, planning permission acquired question cannot be null")
  public boolean isValid() {
    return !Boolean.TRUE.equals(planningPermissionRequired) || planningPermissionAcquired != null;
  }

}
