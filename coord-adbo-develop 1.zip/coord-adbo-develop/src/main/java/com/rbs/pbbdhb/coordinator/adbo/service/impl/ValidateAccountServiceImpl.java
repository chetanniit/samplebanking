package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.client.ValidateAccountClient;
import com.rbs.pbbdhb.coordinator.adbo.model.BankDetailsResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.ValidateAccountRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.ValidateAccountResult;
import com.rbs.pbbdhb.coordinator.adbo.service.ValidateAccountService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ValidateAccountServiceImpl implements ValidateAccountService {

  private final static String CODE = "code";
  private final static String MODULUS = "modulus";
  private final ValidateAccountClient validateAccountClient;

  @Override
  public BankDetailsResponse validateAccount(String brand, ValidateAccountRequest validateAccountRequest) {

    ValidateAccountResult result = validateAccountClient.validateAccount(brand, validateAccountRequest);
    BankDetailsResponse bankDetailsResponse = BankDetailsResponse.builder().sortCode(true).accountNumber(true).build();
    if (result.getValid()) {
      return bankDetailsResponse;
    }
    if (result.getMessages().stream().anyMatch(s -> s.toLowerCase().contains(MODULUS))) {
      bankDetailsResponse.setAccountNumber(false);
    }
    if (result.getMessages().stream().anyMatch(s -> s.toLowerCase().contains(CODE))) {
      bankDetailsResponse.setSortCode(false);
    }
    return bankDetailsResponse;
  }
}
