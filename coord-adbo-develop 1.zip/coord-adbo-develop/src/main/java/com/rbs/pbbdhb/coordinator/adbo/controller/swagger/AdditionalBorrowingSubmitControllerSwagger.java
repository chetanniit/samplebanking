package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingSubmitRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "17 - Final step of a addition borrowing app", description = "Final step of a additional borrowing submit which publishes messages into the kafka")
public interface AdditionalBorrowingSubmitControllerSwagger {

  @Operation(description = "Retrieve selected product details", operationId = "getApplicationSubmit", summary = "Retrieve customer product details",
      responses = {
          @ApiResponse(responseCode = "200", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Product.class))),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
          @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
          @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Product> getSelectedProduct(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Valid @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);

  @Operation(description = "Save customer application submit", operationId = "saveAdditionalBorrowingSubmit", summary = "Save customer application submit request",
      responses = {
          @ApiResponse(responseCode = "204", content = @Content),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
          @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
          @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Void> saveAdditionalBorrowingSubmit(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account final String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final AdditionalBorrowingSubmitRequest additionalBorrowingSubmitRequest);

}
