package com.rbs.pbbdhb.coordinator.adbo.util;

import com.rbs.pbbdhb.coordinator.adbo.dto.CaseDetailsDto;
import com.rbs.pbbdhb.coordinator.adbo.dto.FeeDto;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.FeeAction;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

import static org.springframework.util.ObjectUtils.isEmpty;

@Component
@RequiredArgsConstructor
@Slf4j
public class AdboFeePaymentActionCheck {
    private final ApiService apiService;

    public FeeAction getFeeActionFrom(AdboCaseDetails adboCaseDetails) {
        if (! isEmpty(adboCaseDetails.getSalesIllustration()) &&
                ! isEmpty(adboCaseDetails.getSalesIllustration().getProductDetails()) &&
                ! isEmpty(adboCaseDetails.getSalesIllustration().getProductDetails().get(0).getFees())) {
            return adboCaseDetails.getSalesIllustration().getProductDetails().get(0).getFees().get(0).getFeeAction();
        }
        return null;
    }

    public Boolean getIsPaymentMade(String caseId) {
        CaseDetailsDto caseDetailsDto = apiService.getIsPaymentMadeFlag(caseId);
        Optional<FeeDto> feeDto = caseDetailsDto.getSalesIllustrations().get(0).getProducts().get(0).getFees().stream()
                .filter(fee -> Objects.equals(FeeAction.NO_ACTION, fee.getFeeAction())).findFirst();
        return feeDto.map(fee -> BooleanUtils.isTrue(fee.getIsPaymentMade())).orElse(false);
    }
}
