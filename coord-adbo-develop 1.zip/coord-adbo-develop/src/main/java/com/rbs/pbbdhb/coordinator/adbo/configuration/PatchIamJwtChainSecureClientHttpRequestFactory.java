package com.rbs.pbbdhb.coordinator.adbo.configuration;

import com.rbs.dws.security.UserPrincipalProvider;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import com.rbs.dws.security.utils.HttpHeadersHelper;
import com.rbs.dws.transport.claimSource.ClaimsSourceFactory;
import com.rbs.dws.transport.config.HttpConfig;
import com.rbs.dws.transport.config.IamJwtChainConfig;
import com.rbs.dws.transport.jwtchain.JwkProvider;
import com.rbs.dws.transport.rest.IamJwtChainSecureClientHttpRequestFactory;
import java.io.IOException;
import java.net.URI;
import org.apache.hc.client5.http.classic.HttpClient;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;

public class PatchIamJwtChainSecureClientHttpRequestFactory extends IamJwtChainSecureClientHttpRequestFactory {

  public PatchIamJwtChainSecureClientHttpRequestFactory(HttpClient httpClient, HttpConfig httpConfig,
      UserPrincipalProvider principalProvider,
      JwkProvider keyProvider, IamJwtChainConfig config, MicroserviceIssuer microserviceIssuer,
      HttpHeadersHelper httpHeadersHelper, ClaimsSourceFactory claimsSourceFactory) {
    super(httpClient, httpConfig, principalProvider, keyProvider, config, microserviceIssuer, httpHeadersHelper, claimsSourceFactory);
  }

  @Override
  public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
    setDefaultMediaType(new MediaType("application", "json-patch+json"));
    return super.createRequest(uri, httpMethod);
  }
}
