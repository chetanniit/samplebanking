package com.rbs.pbbdhb.coordinator.adbo.service.impl;


import com.google.common.base.Joiner;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.MarketingPreference;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.MarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.PermissionPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateCustomerPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.enums.PreferenceType;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.MarketingPreferencesService;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MarketingPreferencesServiceImpl implements MarketingPreferencesService {


  private final ApiService apiService;
  private final AdboCaseDetailsDao adboCaseDetailsDao;


  @Override
  public MarketingPreferencesResponse getMarketingPreferences(String customerId, String accountNumber) {

    List<MarketingPreference> responseList = apiService.getCustomerMarketingPreferences(customerId, accountNumber);
    MarketingPreferencesResponse output = new MarketingPreferencesResponse();
    //Regardless of the preferences, we need to return the values of user for rendering
    AdboCaseDetails details = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    if (details != null) {
      details.getAdboApplicants().values().stream()
          .filter(adboApplicant -> customerId.equals(adboApplicant.getCin()))
          .map(AdboApplicant::getPersonalDetails)
          .findFirst()
          .ifPresent(personalDetails -> {
            output.setEmailAddress(personalDetails.getEmail());
            output.setPhoneNumber(personalDetails.getMobileNumber());
            output.setPostalAddress(getPostalAddressFromGmsAddress(personalDetails.getCurrentAddress()));
            output.setIsEmailChanged(personalDetails.isEmailChanged());
            output.setIsMobileNumberChanged(personalDetails.isMobileNumberChanged());
          });
    }
    if (responseList == null) {
      return output;
    }

    Optional<MarketingPreference> marketingPreference = responseList.stream().filter(elem -> elem.getCustomerId().equals(customerId))
        .findFirst();

    if (!marketingPreference.isPresent()) {
      return output;
    }

    marketingPreference.get().getPermissionPreference().forEach(permissionPreferenceRead ->
    {
      if (permissionPreferenceRead.getPreferenceValue() == null || permissionPreferenceRead.getPreferenceType() == null) {
        return;
      }

      if (permissionPreferenceRead.getPreferenceType().getConformedValue().equals(Constants.EMAIL_MARKETING)) {
        output.setEmailMarketing(getBooleanBasedOnYesOrNo(permissionPreferenceRead.getPreferenceValue().getConformedValue()));
      }
      if (permissionPreferenceRead.getPreferenceType().getConformedValue().equals(Constants.MAIL_MARKETING)) {
        output.setPostalMarketing(getBooleanBasedOnYesOrNo(permissionPreferenceRead.getPreferenceValue().getConformedValue()));
      }
      if (permissionPreferenceRead.getPreferenceType().getConformedValue().equals(Constants.PHONE_MARKETING)) {
        output.setPhoneMarketing(getBooleanBasedOnYesOrNo(permissionPreferenceRead.getPreferenceValue().getConformedValue()));
      }
    });

    if (marketingPreference.get().getLawfulBasisMarker() == null
        || marketingPreference.get().getLawfulBasisMarker().getSourceValue() == null) {
      return output;
    }

    output.setLawfulBasisMarker(marketingPreference.get().getLawfulBasisMarker().getSourceValue());

    return output;

  }

  @Override
  public UpdateMarketingPreferencesResponse updateMarketingPreferences(String customerId, String accountNumber,
      MarketingPreferencesResponse marketingPreferencesRequest) {

    Constants.SIMPLE_DATE_FORMAT.setTimeZone(TimeZone.getTimeZone(Constants.GMT));
    UpdateMarketingPreferences updateMarketingPreferences = UpdateMarketingPreferences.builder()
        .channel(Constants.CHANNEL_TYPE)
        .recordUpdatedTimestamp(Constants.SIMPLE_DATE_FORMAT.format(new Date()))
        .lawfulBasisMarker("C")
        .referenceNumber(accountNumber)
        .customer(UpdateCustomerPreferences.builder()
            .permissionPreference(
                Arrays.asList(
                    PermissionPreferences.build(PreferenceType.MAIL_MARKETING, marketingPreferencesRequest.getPostalMarketing()),
                    PermissionPreferences.build(PreferenceType.PHONE_MARKETING, marketingPreferencesRequest.getPhoneMarketing()),
                    PermissionPreferences.build(PreferenceType.EMAIL_MARKETING, marketingPreferencesRequest.getEmailMarketing())
                )
            ).build()
        )
        .build();
    updateIsMarketingPreference(customerId, accountNumber);
    return apiService.updateCustomerMarketingPreferences(customerId, updateMarketingPreferences);
  }

  @Override
  public AdboCaseDetails updateIsMarketingPreference(String customerId, String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    AdboApplicant adboApplicant = adboCaseDetails.getAdboApplicants().values().stream()
        .filter(applicant -> customerId.equals(applicant.getCin()))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Invalid cin:" + customerId));
    adboApplicant.setIsMarketingPreferenceUpdated(true);
    return adboCaseDetailsDao.save(adboCaseDetails);

  }

  private Boolean getBooleanBasedOnYesOrNo(String input) {
    return !input.equals("NO");
  }

  private String getPostalAddressFromGmsAddress(GmsAddress customerAddress) {
    if (customerAddress == null) {
      return null;
    }

    return Joiner.on(Constants.COMMASEPARATOR).skipNulls().join(customerAddress.getAddress1(), customerAddress.getAddress2(),
        customerAddress.getAddress3(), customerAddress.getAddress4(), customerAddress.getAddress5(), customerAddress.getPostcode());
  }


}
