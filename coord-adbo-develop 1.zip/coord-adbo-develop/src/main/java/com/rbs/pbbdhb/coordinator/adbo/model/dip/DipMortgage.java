package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipMortgage {

  private final Integer mortgageAmount;

  private final Integer mortgageTermYears;

  private final Integer mortgageTermMonths;

  private final String mortgageType;

  private final Integer propertyValue;

}

