package com.rbs.pbbdhb.coordinator.adbo.response;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;



@ToString
@EqualsAndHashCode
@Data
@Builder
public class ReadyToStartResponse  {

  private Boolean hasAcknowledgedFraudWarning;
  private Boolean selfServiceLossOfProtectionDocument;
  private Boolean importantInformationAboutUs;
}
