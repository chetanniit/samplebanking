package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.FAILED_DUE_TO_GUARANTOR_ON_MORTGAGE;

import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class GuarantorValidator extends AbstractValidator {

  public GuarantorValidator(@Value("${journeyValidator.priority.guarantor}") int priority) {
    super(priority, FAILED_DUE_TO_GUARANTOR_ON_MORTGAGE);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return journeyValidation.getCustomerSummaryApiResponse().isHasGuarantor();
  }
}
