package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import static lombok.AccessLevel.PRIVATE;

import java.math.BigDecimal;
import java.math.RoundingMode;

import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor(access = PRIVATE)
public class DipDetails {

  private final PurposeEnum purpose;

  private final BigDecimal amount;

  public static DipDetails dipDetails(PurposeEnum purpose, BigDecimal amount) {
    return new DipDetails(purpose, amount.setScale(0, RoundingMode.HALF_UP));
  }

  public enum PurposeEnum {
    HOME_IMPROVEMENT,
    HOUSE_PURCHASE,
    HOLIDAY,
    BUY_NEW_OR_USED_CAR,
    DEBT_CONSOLIDATION,
    OTHER,
    WEDDING,
    GIFT,
    BUY_OUT
  }
}

