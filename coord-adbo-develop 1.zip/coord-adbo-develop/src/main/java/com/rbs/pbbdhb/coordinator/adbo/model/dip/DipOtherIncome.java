package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.math.BigInteger;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipOtherIncome {

  private final BenefitTypeEnum type;

  private final OtherIncomeFrequencyEnum frequency;

  private final BigInteger amount;

  public enum BenefitTypeEnum {
    WORKING_FAMILIES_TAX_CREDIT,
    CHILD_BENEFIT,
    UNIVERSAL_CREDIT,
    CARERS_ALLOWANCE,
    DISABLEMENT_LIVING_ALLOWANCE,
    PERSONAL_INDEPENDENT_INCOME,
    DIVIDEND,
    INVESTMENT_INCOME,
    MAINTENANCE,
    PENSION_PRIVATE_OR_EMPLOYERS,
    PENSION_STATE,
    RENTAL_INCOME,
    TRUST,
    OTHER_TAXABLE,
    OTHER_NON_TAXABLE
  }

  public enum OtherIncomeFrequencyEnum {
    ANNUALLY,
    BIANNUALLY,
    QUARTERLY,
    MONTHLY,
    WEEKLY,
    FORTNIGHTLY,
    FOUR_WEEKLY
  }

}
