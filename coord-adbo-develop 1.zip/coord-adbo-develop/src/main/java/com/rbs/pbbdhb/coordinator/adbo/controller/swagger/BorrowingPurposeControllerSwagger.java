package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose.BorrowingPurposeRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose.BorrowingPurposeResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "07 - Borrowing Purpose")
public interface BorrowingPurposeControllerSwagger {

  @Operation(description = "fetching Borrowing Purpose information", operationId = "getBorrowingPurposeDetails", summary = "fetching Borrowing Purpose information", responses = {
      @ApiResponse(responseCode = "200", content = {}),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<BorrowingPurposeResponse> getBorrowingPurposeDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);

  @Operation(description = "saving borrowing purpose information", operationId = "saveBorrowingPurpose", summary = "saving borrowing purpose information", responses = {
      @ApiResponse(responseCode = "204"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Void> saveBorrowingPurpose(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "BorrowingPurposeRequest") @RequestBody @Valid BorrowingPurposeRequest borrowingPurposeRequest);

}
