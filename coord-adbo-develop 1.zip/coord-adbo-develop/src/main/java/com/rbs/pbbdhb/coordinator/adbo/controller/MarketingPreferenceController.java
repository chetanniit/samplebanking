package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.MarketingPreferenceControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.MarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.MarketingPreferencesService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequestMapping("/marketingPreferences")
@RequiredArgsConstructor
public class MarketingPreferenceController implements MarketingPreferenceControllerSwagger {


  private final MarketingPreferencesService marketingPreferencesService;

  /**
   * This endpoint is used to get Customer Marketing Preferences.
   *
   * @param accountNumber Used to fetch user details from MongoDB & as referenceNumber for marketingPreferences downstream endpoint as it's
   *                      unique.
   * @param brand         Used for brand separation is nwb or rbs
   * @param customerId    Primary input for marketingPreferences downstream endpoint
   * @return MarketingPreferencesResponse
   */

  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MarketingPreferencesResponse> getCustomerMarketingPreferences(
      @RequestHeader(Headers.CIN) String customerId,
      @RequestHeader(Headers.ACCOUNT_NUMBER) String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getCustomerMarketingPreferences start - Headers - account_number: {}, cin: {}, brand: {}, channel: {}",
        accountNumber, customerId, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<MarketingPreferencesResponse> response = new ResponseEntity<>(
        marketingPreferencesService.getMarketingPreferences(customerId, accountNumber), HttpStatus.OK);
    log.info("getCustomerMarketingPreferences end's with response {}, account_number: {}, cin: {}, brand: {}, channel: {}",
        response.getBody(), accountNumber, customerId, brand, channelRoute);
    return response;
  }

  @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<UpdateMarketingPreferencesResponse> updateCustomerMarketingPreferences(
      @RequestHeader(Headers.CIN) String customerId,
      @RequestHeader(Headers.ACCOUNT_NUMBER) String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final MarketingPreferencesResponse marketingPreferencesRequest) {
    log.info("updateCustomerMarketingPreferences start - Headers - account_number: {}, cin: {}, brand: {}, channel: {}, request: {}",
        accountNumber, customerId, brand, channelRoute, marketingPreferencesRequest);
    TenantProvider.applyBrand(brand);
    ResponseEntity<UpdateMarketingPreferencesResponse> response = new ResponseEntity<>(
        marketingPreferencesService.updateMarketingPreferences(customerId, accountNumber, marketingPreferencesRequest), HttpStatus.OK);
    log.info("updateCustomerMarketingPreferences end's with response {}, account_number: {}, cin: {}, brand: {}, channel: {}",
        response.getBody(), accountNumber, customerId, brand, channelRoute);
    return response;
  }

}
