package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import com.rbs.pbbdhb.coordinator.adbo.entity.StructuredAddress;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmploymentType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Industry;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.SelfEmployedBasis;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Getter
@Setter
public class SelfEmployed  implements Employment {

  private SelfEmployedBasis employmentBasis;
  private Industry industry;
  private String businessName;
  private Boolean hasBeenTradingForTwoYears;
  private Integer yearsEstablished;
  private Integer monthsEstablished;
  private BigDecimal shareInBusiness;
  private Salary latestSalary;
  private Salary previousSalary;
  private Profit latestProfit;
  private Profit previousProfit;
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate startDate;
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate endDate;
  private EmploymentType type;
  private GmsAddress companyAddress;
  private StructuredAddress companyStructuredAddress;

  @Override
  public EmploymentType getType() {
    return type;
  }


}
