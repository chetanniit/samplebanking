package com.rbs.pbbdhb.coordinator.adbo.response;


import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class MinMaxRepaymentVo implements Serializable {

  private static final long serialVersionUID = -7483356941996790870L;
  private BigDecimal minRepayment;
  private BigDecimal maxRepayment;
  private List<SubAccountMinMaxRepaymentVo> subAccounts;

  public MinMaxRepaymentVo(BigDecimal minRepayment,BigDecimal maxRepayment){
    this.minRepayment=minRepayment;
    this.maxRepayment=maxRepayment;
  }

  public BigDecimal getMinRepayment(){
    return minRepayment.setScale(0, RoundingMode.DOWN);
  }

  public BigDecimal getMaxRepayment(){
    return maxRepayment.setScale(0, RoundingMode.UP);
  }
}



