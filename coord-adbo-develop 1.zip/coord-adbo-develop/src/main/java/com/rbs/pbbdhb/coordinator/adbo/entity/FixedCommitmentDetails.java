package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.rbs.pbbdhb.coordinator.adbo.enums.FixedCommitmentType;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
public class FixedCommitmentDetails  {

  /**
   * fixed commitment type
   */
  private FixedCommitmentType type;

  /**
   * monthly fixed commitment payment
   */
  private BigDecimal monthlyPayment;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyPayment;

  /**
   * customer is going pay monthly more than six months or not
   */
  private Boolean continueMoreThanSixMonths;


  /**
   * Outgoings Owner
   */
  @NotNull(message = "Owner type cannot be null")
  private OutgoingsOwnerType owner;


}
