package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Profit;
import java.math.BigDecimal;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class ProfitValidator implements Validator {

  @Override
  public boolean supports(Class<?> clazz) {
    return Profit.class.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {

    Profit profit = (Profit) target;

    if (isNull(profit.getAmount())) {
      errors.rejectValue("amount", "required-non-null", " Profit amount(Latest or Previous) cannot be null or empty");
    } else {
      int max = profit.getAmount().compareTo(BigDecimal.valueOf(99999999));
      if (max == 1) {
        errors.rejectValue("amount", "required-non-null", " Profit amount(Latest or Previous) maximum can be 99999999");
      }
      int min = profit.getAmount().compareTo(BigDecimal.valueOf(0));
      if (min == -1) {
        errors.rejectValue("amount", "required-non-null", " Profit amount(Latest or Previous) minimum can be 0");
      }
    }

    if (isNull(profit.getYear())) {
      errors.rejectValue("year", "required-non-null", " Profit year(Latest or Previous) cannot be null or empty");
    }

  }

}
