package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.Singular;


@Data
@Builder
public class DipEmployment {

  private final EmploymentStatusEnum employmentStatus;

  private final EmploymentTypeEnum employmentType;

  private final OccupationCodeEnum occupationCode;

  private final IndustryTypeEnum industryType;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_PATTERN)
  private final LocalDate startDate;

  @Singular
  private final List<DipIncome> incomes;

  private final PaymentFrequencyEnum paymentFrequency;

  private final DipSelfEmployed selfEmployed;

  private final DipApplicantPostRetirement postRetirement;

  public enum EmploymentStatusEnum {
    EMPLOYED,
    NOT_EMPLOYED,
    SELF_EMPLOYED
  }

  public enum EmploymentTypeEnum {
    PERMANENT,
    CONTRACT,
    TEMPORARY,
    OTHER
  }

  public enum OccupationCodeEnum {
    ACADEMIC_STAFF,
    AGRICULTURAL_WORKERS_GENERAL,
    FARM_MANAGEMENT_GENERAL,
    HM_FORCES_OFFICERS,
    HM_FORCES_OTHER_RANKS,
    HOME_FAMILY_RESPONSIBILITIES,
    JUNIOR_MANAGEMENT,
    OFFICE_AND_CLERICAL,
    PROFESSIONALS,
    SALES,
    SEMI_PROFESSIONALS,
    SEMI_SKILLED,
    TECHNICIANS,
    SENIOR_MANAGEMENT,
    SERVICE_JOBS,
    SKILLED_MANUAL,
    SUPERVISORY_FOREMAN,
    TEACHERS,
    UNEMPLOYED,
    SELF_EMPLOYED,
    STUDENT,
    RETIRED,
    MANUAL
  }

  public enum IndustryTypeEnum {
    AGRICULTURE_HUNTING_FORESTRY,
    FISHING,
    MINING_AND_QUARRYING,
    MANUFACTURING,
    ELECTRICITY_GAS_WATER_SUPPLY,
    CONSTRUCTION,
    WHOLESALE_RETAIL_AND_REPAIR,
    HOTELS_AND_RESTAURANTS,
    TRANSPORT_STORAGE_COMM,
    FINANCIAL_INTERMEDIATION,
    PROPERTY_AND_BUSINESS,
    PUBLIC_ADMIN_AND_DEFENCE,
    EDUCATION,
    HEALTH_AND_SOCIAL_WORK,
    OFFICE_WORK_AND_ADMINISTRATION,
    OTHER
  }

  public enum PaymentFrequencyEnum {
    ANNUALLY,
    MONTHLY,
    WEEKLY
  }

}

