package com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AdditionalBorrowingCalculatorRequest implements Serializable {

  private static final long serialVersionUID = -624499385641774461L;

  @NotNull(message = "additionalBorrowingAmount cannot be null")
  private int additionalBorrowingAmount;

  @NotNull(message = "estimatedPropertyValue cannot be null")
  private BigDecimal estimatedPropertyValue;

  @NotNull(message = "propertyModified cannot be null")
  private Boolean propertyModified;

  @NotNull(message = "retirementAge cannot be null")
  private List<Integer> retirementAge;

  @NotNull(message = "termYears cannot be null")
  private int termYears;

  @NotNull(message = "termMonths cannot be null")
  private int termMonths;

  @NotNull(message = "takeFiveDisclaimer must be accepted")
  private Boolean takeFiveDisclaimer;

  @NotNull(message = "ltv cannot be null")
  private BigDecimal ltv;

  @NotNull
  private List<AdboAmountDistribution> adboAmountDistributions;

}
