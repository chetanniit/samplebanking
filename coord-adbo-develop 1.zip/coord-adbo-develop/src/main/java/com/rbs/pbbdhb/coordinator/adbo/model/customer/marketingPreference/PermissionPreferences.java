package com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference;

import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.enums.PreferenceType;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.enums.PreferenceValue;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PermissionPreferences {

  private PreferenceType permissionPreferenceType;
  private PreferenceValue permissionPreferenceValue;

  public static PermissionPreferences build(PreferenceType type, boolean value) {
    return new PermissionPreferences(type, value ? PreferenceValue.YES : PreferenceValue.NO);
  }

}
