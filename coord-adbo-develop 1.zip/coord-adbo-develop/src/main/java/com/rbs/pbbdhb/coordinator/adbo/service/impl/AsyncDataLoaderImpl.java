package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.concurrent.BrandHoldingDecorator.addBrandContext;
import static java.lang.Thread.currentThread;
import static java.util.concurrent.CompletableFuture.supplyAsync;
import static java.util.stream.Collectors.toList;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.TrueBalanceResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CoreCustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerKycResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerVulnerableResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.AsyncDataLoader;
import com.rbs.pbbdhb.exception.BusinessException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AsyncDataLoaderImpl implements AsyncDataLoader {

  private final ApiService apiService;

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  private final Executor executor;

  @Value("${validation.timeout.millis:60000}")
  private int timeout = 60000;

  private static <T> Supplier<T> addContextAndLogs(Supplier<T> supplier) {
    return addBrandContext(() -> {
      long startNano = System.nanoTime();
      T response = supplier.get();
      if (log.isDebugEnabled()) {
        long duration = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNano);
        log.debug("Api call done for class={} in time={} millis",
            response == null ? "unknown" : response.getClass().getSimpleName(), duration);
      }
      return response;
    });
  }

  @Override
  public JourneyValidation getValidationData(String accountNumber, String cin) {
    try {
      log.info(
          "Starting fetching dependent data from account and customer api for acc number: " + accountNumber);

      List<CustomerKycResponse> kycResponses = new ArrayList<>();
      List<CustomerVulnerableResponse> vulnerableResponses = new ArrayList<>();

      CompletableFuture<AdboCaseDetails> futureAdboCaseDetails = loadCaseDetails(accountNumber);
      CompletableFuture<List<CoreCustomerSummaryResponse>> futureCustomerSummaryResponse = supplyAsync(
          addContextAndLogs(() -> apiService.getCustomers(accountNumber)), executor);
      CompletableFuture<AccountSummaryResponse> futureAccountSummaryResponse = supplyAsync(
          addContextAndLogs(() -> apiService.getAccount(accountNumber)), executor);
      CompletableFuture<ApplicationStatusResponse> futureApplicationStatusResponse = supplyAsync(
          addContextAndLogs(() -> apiService.getApplicationStatusApi(accountNumber)), executor);
      CompletableFuture<ApplicationType> futureApplicationType = supplyAsync(
          addContextAndLogs(() -> apiService.getApplicationType(accountNumber)), executor);
      CompletableFuture<TrueBalanceResponse> futureTrueBalance = supplyAsync(
          addContextAndLogs(() -> apiService.getTrueBalance(accountNumber)), executor);
      CompletableFuture<Void> futureCustomerVulnerableResponse = checkVulnerability(cin, vulnerableResponses);
      CompletableFuture<Void> futureKycResponse = checkKYC(cin, kycResponses);

      CompletableFuture<Void> futureAdditionalBorrowersChecks = futureCustomerSummaryResponse.thenCompose(
          addBrandContext(customers -> {
            List<CoreCustomerSummaryResponse> additionalBorrowers = customers.stream()
                .filter(customer -> !customer.getCin().equals(cin))
                .collect(toList());
            return checkAdditionalBorrowers(additionalBorrowers, vulnerableResponses, kycResponses);
          }));

      CompletableFuture.allOf(futureAdboCaseDetails, futureAccountSummaryResponse, futureCustomerSummaryResponse, futureKycResponse,
              futureCustomerVulnerableResponse, futureApplicationStatusResponse, futureAdditionalBorrowersChecks, futureTrueBalance)
          .get(timeout, TimeUnit.MILLISECONDS);

      JourneyValidation journeyValidation = JourneyValidation.builder()
          .loggedUserCin(cin)
          .adboCaseDetails(futureAdboCaseDetails.join())
          .accountSummaryApiResponse(futureAccountSummaryResponse.join())
          .customerSummaryApiResponse(futureCustomerSummaryResponse.join())
          .customerKycResponses(kycResponses)
          .customerVulnerableResponses(vulnerableResponses)
          .applicationStatusResponse(futureApplicationStatusResponse.join())
          .applicationType(futureApplicationType.join())
          .trueBalance(futureTrueBalance.join())
          .build();
      log.info("Dependent data fetched from account and customer api for acc number: " + accountNumber);
      return journeyValidation;
    } catch (ExecutionException | CompletionException e) {
      Throwable cause = e.getCause();
      if (cause instanceof RuntimeException) {
        throw (RuntimeException) cause;
      } else {
        throw new AsyncExecutionException("Fetching data failed", e);
      }
    } catch (InterruptedException e) {
      currentThread().interrupt();
      throw new AsyncExecutionException("Fetching data interrupted", e);
    } catch (TimeoutException e) {
      throw new AsyncExecutionException("Fetching data timed out", e);
    }
  }

  private CompletableFuture<AdboCaseDetails> loadCaseDetails(String accountNumber) {
    return supplyAsync(addContextAndLogs(() -> {
      try {
        return adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
      } catch (BusinessException ex) {
        return null;
      }
    }), executor);
  }

  private CompletableFuture<Void> checkAdditionalBorrowers(List<CoreCustomerSummaryResponse> additionalBorrowers,
      List<CustomerVulnerableResponse> vulnerableResponses, List<CustomerKycResponse> kycResponses) {
    if (additionalBorrowers.isEmpty()) {
      return CompletableFuture.completedFuture(null);
    }
    return CompletableFuture.allOf(
        additionalBorrowers.stream()
            .map(CoreCustomerSummaryResponse::getCin)
            .map(borrowerCin -> CompletableFuture.allOf(
                checkVulnerability(borrowerCin, vulnerableResponses),
                checkKYC(borrowerCin, kycResponses)
            )).toArray(CompletableFuture[]::new));
  }

  private CompletableFuture<Void> checkVulnerability(String borrowerCin, List<CustomerVulnerableResponse> vulnerableResponses) {
    return supplyAsync(addContextAndLogs(() -> apiService.getVulnerabilityApi(borrowerCin))).thenAccept(
        vulnerableResponse -> {
          vulnerableResponse.setCin(borrowerCin);
          vulnerableResponses.add(vulnerableResponse);
        });
  }

  private CompletableFuture<Void> checkKYC(String borrowerCin, List<CustomerKycResponse> kycResponses) {
    return supplyAsync(addContextAndLogs(() -> apiService.getKycApi(borrowerCin))).thenAccept(
        customerKycResponse -> {
          customerKycResponse.setCin(borrowerCin);
          kycResponses.add(customerKycResponse);
        });
  }


  public static class AsyncExecutionException extends RuntimeException {

    private AsyncExecutionException(String message, Exception cause) {
      super(message, cause);
    }

  }
}
