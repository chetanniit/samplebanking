package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipProperty {

  private DipPropertyTypeEnum propertyType;

  public enum DipPropertyTypeEnum {
    BUNGALOW_NEW_BUILD,
    BUNGALOW_DETACHED,
    BUNGALOW_SEMI_DETACHED,
    BUNGALOW_MID_TERRACED,
    BUNGALOW_END_TERRACED,
    HOUSE_NEW_BUILD,
    HOUSE_DETACHED,
    HOUSE_SEMI_DETACHED,
    HOUSE_MID_TERRACED,
    HOUSE_END_TERRACED,
    HOUSE_NEW_BUY,
    FLAT_NEW_BUILD,
    FLAT_PURPOSE_BUILT,
    FLAT_CONVERTED,
    FLAT_NEW_BUY
  }
}
