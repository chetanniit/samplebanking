package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import java.util.regex.Pattern;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;


public class AccountValidator implements ConstraintValidator<Account, String> {

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    if (value != null) {
      return Pattern.compile("\\d{8}").matcher(value).matches();
    }
    return true;
  }
}

