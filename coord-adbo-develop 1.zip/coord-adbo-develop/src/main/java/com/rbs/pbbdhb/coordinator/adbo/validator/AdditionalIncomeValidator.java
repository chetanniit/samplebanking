package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.AdditionalIncome;
import com.rbs.pbbdhb.coordinator.adbo.enums.FrequencyType;
import java.math.BigDecimal;
import java.util.Objects;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class AdditionalIncomeValidator implements Validator {

  @Override
  public boolean supports(Class<?> clazz) {
    return AdditionalIncome.class.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {
    AdditionalIncome additionalIncome = (AdditionalIncome) target;

    switch (additionalIncome.getSourceOfIncome()) {
      case BONUS:
        if (Objects.nonNull(additionalIncome.getFrequency())) {
          if (additionalIncome.getFrequency().equals(FrequencyType.ANNUALLY)
              || additionalIncome.getFrequency().equals(FrequencyType.SIX_MONTHLY)) {
            if (Objects.isNull(additionalIncome.getBonusType())) {
              errors.rejectValue("bonusType", "required-non-empty",
                  "bonusType cannot be null or empty as selected frequency is annually and six monthly");
            } else {
              switch (additionalIncome.getBonusType()) {
                case GUARANTEED:
                case PERFORMANCE_RELATED:
                  break;
                default:
                  errors.rejectValue("bonusType", "unsupported-commitmentType",
                      "The given bonusType is unsupported for our journey");
              }
            }

          } else {
            if (Objects.nonNull(additionalIncome.getBonusType())) {
              errors.rejectValue("bonusType", "required-non-empty",
                  "bonusType must be null or empty as selected frequency is not annually and six monthly");
            }

          }
        } else {
          errors.rejectValue("frequency", "required-non-empty", "frequency cannot be null or empty");
        }
        break;
      case OVERTIME:
      case COMMISSION:
      case CAR_ALLOWANCE:
      case SHIFT_ALLOWANCE:
        break;
      default:
        errors.rejectValue("sourceOfIncome", "unsupported-commitmentType",
            "The given sourceOfIncome is unsupported for our journey");
    }

    if (Objects.isNull(additionalIncome.getAmount())) {
      errors.rejectValue("amount", "required-non-empty", "amount cannot be null or empty");
    } else {
      int max = additionalIncome.getAmount().compareTo(BigDecimal.valueOf(99999999));
      if (max == 1) {
        errors.rejectValue("amount", "required-non-empty", "amount maxmimum allowed is 99999999");
      }
      int min = BigDecimal.valueOf(0).compareTo(additionalIncome.getAmount());
      if (min == 1) {
        errors.rejectValue("amount", "required-non-empty", "amount minimum allowed is 0");
      }
    }

    if (Objects.isNull(additionalIncome.getFrequency())) {
      errors.rejectValue("frequency", "required-non-empty", "frequency cannot be null or empty");
    } else {
      switch (additionalIncome.getFrequency()) {
        case ANNUALLY:
        case QUARTERLY:
        case MONTHLY:
        case SIX_MONTHLY:
          break;
        default:
          errors.rejectValue("frequency", "unsupported-commitmentType",
              "The given frequency is unsupported for our journey");
      }
    }

  }

}
