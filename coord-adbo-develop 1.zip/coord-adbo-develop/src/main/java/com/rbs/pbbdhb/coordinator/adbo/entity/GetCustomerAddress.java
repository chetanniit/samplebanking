package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerAddress {

  private String addressCountry;
  private String address1;
  private String address2;
  private String address3;
  private String address4;
  private String address5;
  private String addressPC;

}
