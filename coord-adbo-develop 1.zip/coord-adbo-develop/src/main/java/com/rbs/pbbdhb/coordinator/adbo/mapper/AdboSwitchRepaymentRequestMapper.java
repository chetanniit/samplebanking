package com.rbs.pbbdhb.coordinator.adbo.mapper;

import static com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentRequest.ADBO_SUB_ACCOUNT_NUMBER;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AboSwitchRepaymentSubAccountRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentRequest;
import java.math.BigDecimal;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface AdboSwitchRepaymentRequestMapper {

  default AdboSwitchRepaymentRequest map(AdditionalBorrowingCalculator calculator, BigDecimal interestRate,
      Integer productFee) {
    List<AboSwitchRepaymentSubAccountRequest> subAccounts = calculator.getSubAccountDetails().stream()
        .filter(subAccount -> isTrue(subAccount.getSelectedForSwitch()))
        .map(subAccount -> mapSubAccount(subAccount, interestRate))
        .collect(toList());
    subAccounts.add(mapAdboAmountAsSubAccount(calculator, interestRate, productFee));

    return AdboSwitchRepaymentRequest.builder()
        .subAccountDetails(subAccounts)
        .build();
  }

  @Mapping(target = "subAccountNumber", source = "subAccount.subAccountNumber")
  @Mapping(target = "currentBalance", source = "subAccount.trueBalance")
  @Mapping(target = "remainingTerm.years", source = "subAccount.remainingTerm.years")
  @Mapping(target = "remainingTerm.months", source = "subAccount.remainingTerm.months")
  @Mapping(target = "initialRate", source = "interestRate")
  AboSwitchRepaymentSubAccountRequest mapSubAccount(SubAccount subAccount, BigDecimal interestRate);


  @Mapping(target = "subAccountNumber", constant = ADBO_SUB_ACCOUNT_NUMBER)
  @Mapping(target = "currentBalance", source = "calculator.borrowingAmount")
  @Mapping(target = "initialRate", source = "interestRate")
  @Mapping(target = "remainingTerm.years", source = "calculator.repaymentTermYears")
  @Mapping(target = "remainingTerm.months", source = "calculator.repaymentTermMonths")
  @Mapping(target = "productFee", source = "productFee")
  AboSwitchRepaymentSubAccountRequest mapAdboAmountAsSubAccount(AdditionalBorrowingCalculator calculator, BigDecimal interestRate,
      Integer productFee);

}
