package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityApplicant;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingWithSwitchRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AdditionalBorrowingWithSwitchResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.AgreementsAndDisclaimersResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "04 - Additional Borrowing with Switch", description = " User can save/retrieve eligible sub accounts for switch with additional borrowing")
public interface AdditionalBorrowingWithSwitchControllerSwagger {

  @Operation(description = "Persist Sub accounts selected for switch  with additional borrowing", operationId = "saveAdditionalBorrowingWithSwitch", summary = "Persist Sub accounts selected for switch  with additional borrowing, If exist same account number than override ", responses = {
      @ApiResponse(responseCode = "204", description = "Additional borrowing with switch details saved successfully", content = @Content),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Void> saveAdditionalBorrowingWithSwitch(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid AdditionalBorrowingWithSwitchRequest switchRequest);

  @Operation(description = "Retrieve additional borrowing with switch details based on request criteria.", operationId = "getAdditionalBorrowingWithSwitch", summary = "Retrieve eligible sub accounts for switch with additional borrowing based on request criteria ", responses = {
      @ApiResponse(responseCode = "200", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AdditionalBorrowingWithSwitchResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<AdditionalBorrowingWithSwitchResponse> getAdditionalBorrowingWithSwitch(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);
}
