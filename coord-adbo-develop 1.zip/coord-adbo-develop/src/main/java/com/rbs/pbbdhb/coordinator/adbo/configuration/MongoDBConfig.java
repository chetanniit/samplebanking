package com.rbs.pbbdhb.coordinator.adbo.configuration;

import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

/**
 * This class will have configurations related to NWB and RBS data source
 */
@Configuration
public class MongoDBConfig {

  @Primary
  @Bean(name = "natwestMongoProperties")
  @ConfigurationProperties(prefix = "nwb.spring.data.mongodb")
  public MongoProperties natwestMongoProperties() {
    return new MongoProperties();
  }

  @Bean(name = "rbsMongoProperties")
  @ConfigurationProperties(prefix = "rbs.spring.data.mongodb")
  public MongoProperties rbsMongoProperties() {
    return new MongoProperties();
  }

  @Primary
  @Bean(name = "natwestMongoTemplate")
  public MongoTemplate natwestMongoTemplate() {
    MongoDatabaseFactory factory = natwestMongoDatabaseFactory(natwestMongoProperties());
    return new MongoTemplate(factory, mappingMongoConverter(factory, mongoMappingContext()));
  }

  @Bean(name = "rbsMongoTemplate")
  public MongoTemplate rbsMongoTemplate() {
    MongoDatabaseFactory factory = rbsMongoDatabaseFactory(rbsMongoProperties());
    return new MongoTemplate(factory, mappingMongoConverter(factory, mongoMappingContext()));
  }

  @Bean
  public MongoMappingContext mongoMappingContext() {
    return new MongoMappingContext();
  }

  @Bean
  public MappingMongoConverter mappingMongoConverter(MongoDatabaseFactory mongoDatabaseFactory, MongoMappingContext mongoMappingContext) {
    MappingMongoConverter converter = new MappingMongoConverter(new DefaultDbRefResolver(mongoDatabaseFactory), mongoMappingContext);
    converter.setTypeMapper(new DefaultMongoTypeMapper());
    mongoMappingContext.setSimpleTypeHolder(converter.getCustomConversions().getSimpleTypeHolder());
    mongoMappingContext.afterPropertiesSet();
    converter.afterPropertiesSet();
    return converter;

  }

  @Primary
  @Bean
  public MongoDatabaseFactory natwestMongoDatabaseFactory(MongoProperties mongo) {
    return new SimpleMongoClientDatabaseFactory(mongo.getUri());
  }

  @Bean
  public MongoDatabaseFactory rbsMongoDatabaseFactory(MongoProperties mongo) {
    return new SimpleMongoClientDatabaseFactory(mongo.getUri());
  }

}
