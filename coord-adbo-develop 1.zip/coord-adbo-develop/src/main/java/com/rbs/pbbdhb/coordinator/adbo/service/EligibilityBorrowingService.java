package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityBorrowing;

public interface EligibilityBorrowingService {

  void saveEligibilityBorrowing(String accountNumber, EligibilityBorrowing eligibilityBorrowing);

  EligibilityBorrowing getEligibilityBorrowing(String accountNumber);
}
