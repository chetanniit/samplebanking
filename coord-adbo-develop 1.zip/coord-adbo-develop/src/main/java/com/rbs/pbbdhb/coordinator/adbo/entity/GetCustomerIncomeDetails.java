package com.rbs.pbbdhb.coordinator.adbo.entity;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerIncomeDetails {

  private List<GetCustomerIncome> income;

}
