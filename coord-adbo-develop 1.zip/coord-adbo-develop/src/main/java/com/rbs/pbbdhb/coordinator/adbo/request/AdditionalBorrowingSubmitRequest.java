package com.rbs.pbbdhb.coordinator.adbo.request;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.PHONE_NUMBER_WRONG_FORMAT;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.VALUATION_CONTACT_NAME_TOO_LONG;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.VALUATION_CONTACT_NAME_TOO_SMALL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.VALUATION_CONTACT_PHONE_NUMBER_TOO_LONG;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.VALUATION_CONTACT_PHONE_NUMBER_TOO_SMALL;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@ToString
@EqualsAndHashCode
public class AdditionalBorrowingSubmitRequest  {

  /**
   * do you understand that we can't agree to lend you money until we have provided your mortgage application
   */
  @Schema(example = "true", required = true)
  @NotNull(message = "cantLendTillApproved must not be null, Should be true or false")
  @AssertTrue(message = "cantLendTillApproved must be true")
  private Boolean cantLendTillApproved;
  /**
   * Do you agree to check being made with credit reference and fraud prevention agencies for all mortgage applicants
   */
  @Schema(example = "true", required = true)
  @NotNull(message = "creditCheckDisclaimer must not be null, Should be true or false")
  @AssertTrue(message = "creditCheckDisclaimer must be true")
  private Boolean creditCheckDisclaimer;
  /**
   * Can you confirm you have read and understood mortgage illustration and want to apply for the product described
   */
  @Schema(example = "true", required = true)
  @NotNull(message = "readMortgageIllustrationUnderstoodProduct must not be null, Should be true or false")
  @AssertTrue(message = "readMortgageIllustrationUnderstoodProduct must be true")
  private Boolean readMortgageIllustrationUnderstoodProduct;
  /**
   * You have chosen the right mortgage for your circumstances and take responsibility for your choice.
   */
  @Schema(example = "true", required = true)
  @NotNull(message = "rightMortgageConfident must not be null, Should be true or false")
  @AssertTrue(message = "rightMortgageConfident must be true")
  private Boolean rightMortgageConfident;
  /**
   * valuation contact full name
   */
  @Schema(example = "John Mark")
  @Size.List({
      @Size(min = 1, message = VALUATION_CONTACT_NAME_TOO_SMALL),
      @Size(max = 45, message = VALUATION_CONTACT_NAME_TOO_LONG)
  })
  @ToString.Exclude
  private String fullName;
  /**
   * valuation contact phone number
   */
  @Schema(example = "07586581612")
  @Size.List({
      @Size(min = 11, message = VALUATION_CONTACT_PHONE_NUMBER_TOO_SMALL),
      @Size(max = 15, message = VALUATION_CONTACT_PHONE_NUMBER_TOO_LONG)
  })
  @Pattern(regexp = "^(0[^7]\\d{9,13})|(07\\d{9})$", message = PHONE_NUMBER_WRONG_FORMAT)
  @ToString.Exclude
  private String phoneNumber;


}
