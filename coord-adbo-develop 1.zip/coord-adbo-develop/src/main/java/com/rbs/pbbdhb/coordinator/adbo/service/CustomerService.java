package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsPatch;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsResponse;
import java.util.List;

public interface CustomerService {

  List<PersonalDetailsResponse> getPersonalDetails(String accountNumber);

  void patchPersonalDetails(String accountNumber, PersonalDetailsPatch personalDetailsPatch);

}
