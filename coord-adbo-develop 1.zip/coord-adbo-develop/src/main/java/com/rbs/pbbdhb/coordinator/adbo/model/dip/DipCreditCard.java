package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.math.BigInteger;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipCreditCard {

  private final CreditCardTypeEnum creditCardType;

  private final BigInteger totalBalance;

  private final Boolean toBeRepaid;

  private final Boolean debtConsolidation;

  private final BigInteger partialRefinanced;

  public enum CreditCardTypeEnum {
    CREDIT_CARD,
    STORE_CARD
  }

}
