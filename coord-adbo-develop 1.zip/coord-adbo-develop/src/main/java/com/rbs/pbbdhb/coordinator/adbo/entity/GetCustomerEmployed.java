package com.rbs.pbbdhb.coordinator.adbo.entity;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerEmployed {

  private String currentOrPrevious;
  private String employerName;
  private GetCustomerAddress employerAddress;
  private String natureOfBusiness;
  private String presentPosition;
  private String employmentType;
  private String employerStatus;
  private Integer yearsOfService;
  private Integer monthsOfService;
  private String employeeReferenceNo;
  private String contactName;
  private String position;
  private String telephoneNumber;
  private String deliveryPreference;
  private String faxNumber;
  private String emailAddress;
  private String employmentStatus;
  private LocalDate contractEndDate;
  private String occupation;
  private LocalDate startDate;
  private GetCustomerIncomeDetails incomeDetails;

}
