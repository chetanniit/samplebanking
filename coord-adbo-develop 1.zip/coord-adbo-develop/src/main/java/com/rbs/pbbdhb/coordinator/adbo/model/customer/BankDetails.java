package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankDetails {

  private String cin;
  private String bankAccountName;
  private String bankAccountNumber;
  private String yearsWithBank;
  private String monthsWithBank;
  private String bankSortCode;
  private String bankName;

}
