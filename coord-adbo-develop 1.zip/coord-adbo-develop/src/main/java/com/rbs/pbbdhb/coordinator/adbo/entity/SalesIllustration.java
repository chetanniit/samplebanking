package com.rbs.pbbdhb.coordinator.adbo.entity;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_PATTERN;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_TIME_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SalesIllustration {

  private boolean isAccepted;

  @JsonFormat(pattern = DATE_PATTERN)
  private LocalDate selectionDate;

  private String documentUrl;

  private String productSwitchDocumentUrl;

  @JsonFormat(pattern = DATE_TIME_PATTERN)
  private LocalDateTime lastUpdated;

  private List<Product> productDetails;

}