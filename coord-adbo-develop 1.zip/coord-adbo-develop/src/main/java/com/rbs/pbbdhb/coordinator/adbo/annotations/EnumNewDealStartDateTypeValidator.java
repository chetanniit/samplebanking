package com.rbs.pbbdhb.coordinator.adbo.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import com.rbs.pbbdhb.coordinator.adbo.validator.EnumNewDealStartDateTypeValidation;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Constraint(validatedBy = EnumNewDealStartDateTypeValidation.class)
public @interface EnumNewDealStartDateTypeValidator {

  String message() default "Invalid switchImmediately && newDealStartDateType combination";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

}
