/**
 *
 */
package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.JourneyValidationControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.enums.Route;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidationApiResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.JourneyValidationService;
import com.rbs.pbbdhb.coordinator.adbo.service.RouteService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
public class JourneyValidationController implements JourneyValidationControllerSwagger {

  private final JourneyValidationService journeyValidationService;
  private final RouteService routeService;

  @Autowired
  public JourneyValidationController(JourneyValidationService journeyValidationService, RouteService routeService) {
    this.journeyValidationService = journeyValidationService;
    this.routeService = routeService;
  }

  /**
   * This operation is used to retrieve journey validation information for a given account/customer
   *
   * @param accountNumber account number
   * @param cin           customer identifier
   * @return journey validation results
   */
  @GetMapping(path = "/journeyValidation", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<JourneyValidationApiResponse> getJourneyValidation(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.CIN) @CIN String cin,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getJourneyValidation start- Headers - account_number: {}, cin: {}, brand: {}, channel: {}", accountNumber, cin, brand,
        channelRoute);
    TenantProvider.applyBrand(brand);
    JourneyValidationApiResponse journeyValidation = journeyValidationService.getJourneyValidation(accountNumber, cin, false);
    routeService.saveRoute(accountNumber, cin, Route.valueOfRoute(channelRoute), journeyValidation.getValidationRuleResultCode());
    ResponseEntity<JourneyValidationApiResponse> response = new ResponseEntity<>(journeyValidation, HttpStatus.OK);
    log.info("getJourneyValidation end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

}
