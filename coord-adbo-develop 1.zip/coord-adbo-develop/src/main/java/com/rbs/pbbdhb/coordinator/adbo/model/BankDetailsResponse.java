package com.rbs.pbbdhb.coordinator.adbo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BankDetailsResponse {

  private Boolean accountNumber;
  private Boolean sortCode;

}