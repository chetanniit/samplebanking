package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum FrequencyType {
  ANNUALLY("ANNUALLY"),
  QUARTERLY("QUARTERLY"),
  MONTHLY("MONTHLY"),
  FOUR_WEEKLY("FOUR_WEEKLY"),
  FORTNIGHTLY("FORTNIGHTLY"),
  SIX_MONTHLY("SIX_MONTHLY"),
  WEEKLY("WEEKLY");

  private final String label;

  FrequencyType(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }
}
