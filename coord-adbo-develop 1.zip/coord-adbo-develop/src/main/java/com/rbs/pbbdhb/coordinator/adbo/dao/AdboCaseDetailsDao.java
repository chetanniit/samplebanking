package com.rbs.pbbdhb.coordinator.adbo.dao;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;

public interface AdboCaseDetailsDao {

  AdboCaseDetails save(AdboCaseDetails adboCaseDetails);

  AdboCaseDetails getCaseDetailsByAccountNumber(String accountNumber);

  AdboCaseDetails getValidCaseDetailsByAccountNumber(String accountNumber);

  AdboCaseDetails getCaseForJourneyValidationPassOrLimited(String accountNumber);

}
