package com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto;

import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ErcItem {

  private LocalDate endDate;

  private BigDecimal percentage;

  private Integer seqNo;
}
