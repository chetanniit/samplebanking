package com.rbs.pbbdhb.coordinator.adbo.model.account;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DD_MM_YYYY_DATE_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.enums.LoanToValueValuated;
import com.rbs.pbbdhb.coordinator.adbo.model.account.gmsaccount.HoldCodes;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.error.BaseResponse;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountSummaryResponse extends BaseResponse {

  private static final long serialVersionUID = -5234191228513462925L;

  private String accountNumber;

  private BigDecimal totalOutstandingBalance;

  private BigDecimal monthlyPayment;
  private Boolean buyToLet;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate monthlyPaymentDueDate;

  private Address address;

  private String propertyTypeCode;
  private String propertyYearBuilt;
  private String propertyHomeEnergyRating;
  private String propertyTenureCode;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate lastValuationDate;

  private BigDecimal lastValuationAmount;

  private BigDecimal hpiValuationAmount;
  private LoanToValueValuated loanToValueValuated;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate hpiValuationDate;

  private BigDecimal loanToValue;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private LocalDateTime sysDate;

  private boolean isForfeitureOfLease;
  private List<SubAccount> subAccounts;

  private HoldCodes holdCodes;
  private boolean isDeceased;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate holdFromDate;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate secondChargeHoldToDate;

  private boolean firstPaymentMade;

  public void setSubAccounts(List<SubAccount> subAccounts) {
    subAccounts.sort(new SubAccount.SubAccountNumberComparator());
    this.subAccounts = subAccounts;
  }
}