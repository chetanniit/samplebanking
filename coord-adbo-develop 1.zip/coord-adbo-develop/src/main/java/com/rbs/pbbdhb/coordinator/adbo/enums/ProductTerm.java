package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ProductTerm {
  TWO_YEAR("2 Year", 2),
  FIVE_YEAR("5 Year", 5);

  private final String value;
  private final int years;

  @Override
  public String toString() {
    return name();
  }

}
