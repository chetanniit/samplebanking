package com.rbs.pbbdhb.coordinator.adbo.entity;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdditionalDetails {

  private Integer shortestTerminMonths;
  private Integer maximumAllowableLoan;
  private BigDecimal loanToValue;
  private Integer excessIncome;
  private String podScoreBand;
  private ScoringPostRetirement postRetirement;

}
