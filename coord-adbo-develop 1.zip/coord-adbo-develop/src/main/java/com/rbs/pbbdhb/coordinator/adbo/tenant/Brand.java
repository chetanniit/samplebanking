package com.rbs.pbbdhb.coordinator.adbo.tenant;

import static java.util.Arrays.stream;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;

import java.util.Map;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum Brand {
  NWB("nwb"),
  RBS("rbs");

  private static final Map<String, Brand> BY_NAME = stream(values()).collect(toMap(Brand::getName, identity()));
  private final String name;

  public static Brand fromName(String name) {
    return BY_NAME.get(name);
  }

  @Override
  public String toString() {
    return name;
  }
}
