package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.FAILED_DUE_TO_CUSTOMER_ARREAR;
import static java.math.BigDecimal.ZERO;

import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.math.BigDecimal;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ArrearsValidator extends AbstractValidator {

  public ArrearsValidator(@Value("${journeyValidator.priority.arrears}") int priority) {
    super(priority, FAILED_DUE_TO_CUSTOMER_ARREAR);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return journeyValidation.getAccountSummaryApiResponse().getSubAccounts().stream()
        .map(SubAccount::getArrear)
        .filter(Objects::nonNull)
        .reduce(ZERO, BigDecimal::add)
        .compareTo(ZERO) > 0;
  }
}
