package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.rbs.pbbdhb.coordinator.adbo.enums.BankName;
import com.rbs.pbbdhb.coordinator.adbo.enums.LoanType;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
@EqualsAndHashCode
public class LoanDetails  {

  /**
   * existing loan type
   */
  private LoanType loanType;

  /**
   * existing loan provider name
   */
  private BankName loanProvider;

  /**
   * If the bank name not exist in the dropdown list, Then user should pass the provider name not more than 30 characters
   */
  private String other;

  /**
   * monthly payment-EMI for the current loan
   */
  private BigDecimal monthlyPayment;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyPayment;
  /**
   * customer is going pay monthly more than six months or not
   */
  private Boolean continueForMoreThanSixMonths;

  /**
   * Outgoings Owner
   */
  @NotNull(message = "Owner type cannot be null")
  private OutgoingsOwnerType owner;


}
