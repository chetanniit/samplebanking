package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.model.BankDetailsResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.ValidateAccountRequest;

public interface ValidateAccountService {

  BankDetailsResponse validateAccount(String brand, ValidateAccountRequest validateAccountRequest);
}
