package com.rbs.pbbdhb.coordinator.adbo.configuration;

import java.util.HashMap;
import java.util.Map;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

/**
 * Kafka configuration properties
 */
@Getter
@Setter
@Configuration
public class KafkaProducerConfig {

  public static final String SSL_ALGORITHM = "ssl.endpoint.identification.algorithm";
  public static final String SERVER_ERROR = "Internal Server Error Occurred.";
  private static final String SSL_PROTOCOL = "security.protocol";
  @Value("${kafka.bootstrapServers}")
  private String bootstrapServers;
  @Value("${kafka.sslKeystoreLocation}")
  private String sslKeystoreLocation;
  @Value("${kafka.sslKeystorePassword}")
  private String sslKeystorePassword;
  @Value("${kafka.securityprotocol}")
  private String securityProtocol;
  @Value("${kafka.clientId}")
  private String clientId;


  @Bean
  @NotNull
  public ProducerFactory<String, Object> genericProducerFactory() {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
    configProps.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, sslKeystoreLocation);
    configProps.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, sslKeystorePassword);
    configProps.put(SSL_PROTOCOL, securityProtocol);
    configProps.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    return new DefaultKafkaProducerFactory<>(configProps);
  }

  @Bean
  public KafkaTemplate<String, Object> genericKafkaTemplate() {
    return new KafkaTemplate<>(genericProducerFactory());
  }
}
