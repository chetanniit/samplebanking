package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum BankName {
  NATWEST_BANK("NATWEST_BANK"),
  ROYAL_BANK_OF_SCOTLAND("ROYAL_BANK_OF_SCOTLAND"),
  BARCLAYS_BANK("BARCLAYS_BANK"),
  HALIFAX("HALIFAX"),
  LLOYDS_BANK("LLOYDS_BANK"),
  SANTANDER("SANTANDER"),
  HSBC_BANK("HSBC_BANK"),
  NATIONWIDE_BUILDING_SOCIETY("NATIONWIDE_BUILDING_SOCIETY"),
  TESCO_BANK("TESCO_BANK"),
  SAINSBURYS_BANK("SAINSBURYS_BANK"),
  OTHER("OTHER");
  private final String label;

  BankName(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }
}
