package com.rbs.pbbdhb.coordinator.adbo.utils;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;

import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employed;
import com.rbs.pbbdhb.coordinator.adbo.tenant.Brand;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;


public class AppUtil {

  private static final HttpHeaders nwbHttpHeaders;
  private static final HttpHeaders rbsHttpHeaders;

  static {
    nwbHttpHeaders = new HttpHeaders();
    nwbHttpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    nwbHttpHeaders.add(Headers.BRAND, Brand.NWB.getName());

    rbsHttpHeaders = new HttpHeaders();
    rbsHttpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    rbsHttpHeaders.add(Headers.BRAND, Brand.RBS.getName());
  }

  public static <T> HttpEntity<T> createRequestEntity() {
    return new HttpEntity<>(applicationHeaders(TenantProvider.getCurrentBrand()));
  }

  public static <T> HttpEntity<T> createRequestEntity(T request) {
    return new HttpEntity<>(request, applicationHeaders(TenantProvider.getCurrentBrand()));
  }

  public static HttpHeaders applicationHeaders(Brand brand) {
    return Brand.NWB == brand ? nwbHttpHeaders : rbsHttpHeaders;
  }

  public static BigDecimal getRoundUpAverageAmount(BigDecimal amount) {
    return amount.divide(BigDecimal.valueOf(2), 0, BigDecimal.ROUND_CEILING);
  }

  public static BigDecimal getAverageAmount(BigDecimal amount) {
    return amount.divide(BigDecimal.valueOf(2));
  }

  public static BigDecimal getRoundDownAmount(BigDecimal amount) {
    return amount.setScale(0, BigDecimal.ROUND_DOWN);
  }

  public static boolean hasContinuesEmployment(Employed employed) {
    if (isNull(employed.getHasContinuousEmployment())) {
      return true;
    }
    if (isFalse(employed.getHasContinuousEmployment())) {
      return false;
    }
    boolean hasGap = false;
    if (!CollectionUtils.isEmpty(employed.getPreviousEmployments())) {
      for (int i = 0; i < employed.getPreviousEmployments().size(); i++) {
        LocalDate startDate = (i == 0) ? employed.getStartDate() : employed.getPreviousEmployments().get(i - 1).getStartDate();
        LocalDate endDate = employed.getPreviousEmployments().get(i).getEndDate();
        if (ChronoUnit.WEEKS.between(endDate, startDate) >= 3) {
          hasGap = true;
          break;
        }
      }
    }
    return !hasGap;
  }

  public static <K, V> K getKey(Map<K, V> map, V value) {
    return map.entrySet().stream().filter(entry -> value.equals(entry.getValue()))
        .map(Map.Entry::getKey).findFirst().orElse(null);
  }
}