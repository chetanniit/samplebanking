package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum ProductType {
  FIXED,
  TRACKER
}