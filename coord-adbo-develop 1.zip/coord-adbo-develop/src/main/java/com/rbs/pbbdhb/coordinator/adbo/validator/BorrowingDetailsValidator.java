package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails;
import org.springframework.stereotype.Component;

@Component
public class BorrowingDetailsValidator extends AbstractTermValidator<BorrowingDetails> {

  @Override
  protected Class<BorrowingDetails> supportedClass() {
    return BorrowingDetails.class;
  }

  @Override
  protected Integer getRepaymentTermMonths(BorrowingDetails borrowingDetails) {
    return borrowingDetails.getRepaymentTermMonths();
  }

  @Override
  protected Integer getRepaymentTermYears(BorrowingDetails borrowingDetails) {
    return borrowingDetails.getRepaymentTermYears();
  }

}
