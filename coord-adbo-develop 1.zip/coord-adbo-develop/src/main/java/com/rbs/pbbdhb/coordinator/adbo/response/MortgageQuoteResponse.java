package com.rbs.pbbdhb.coordinator.adbo.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.enums.InterestType;
import com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
public class MortgageQuoteResponse {

  private Integer sequenceNumber;
  private InterestType interestType;
  private BigDecimal interestRate;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN)
  private LocalDate newDealEnds;
  private RepaymentType repaymentType;
  private BigDecimal newMonthlyPayment;
  private TimePeriod remainingTerm;
  private Integer currentBalance;
  private Integer productTerm;
  private Integer productFee;
  private Boolean isProductFeeAddedToMortgage;
  private List<MortgageQuoteSubAccount> subAccounts;

}
