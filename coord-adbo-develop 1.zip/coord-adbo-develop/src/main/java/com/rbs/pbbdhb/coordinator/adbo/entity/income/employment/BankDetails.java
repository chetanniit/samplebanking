package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankDetails {

  private String accountName;
  private String accountNumber;
  private String yearsWithBank;
  private String monthsWithBank;
  private String sortCode;
  private String bankName;
}
