package com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto;

import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class PersonalDetails {

    @ToString.Exclude
    private Title title;

    @ToString.Exclude
    private String lastName;

    @ToString.Exclude
    private String firstNames;

    @ToString.Exclude
    private String middleNames;

    @ToString.Exclude
    private LocalDate dob;
}
