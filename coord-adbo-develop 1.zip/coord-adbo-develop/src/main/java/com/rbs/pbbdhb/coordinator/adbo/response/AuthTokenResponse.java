package com.rbs.pbbdhb.coordinator.adbo.response;

import com.rbs.pbbdhb.error.BaseResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthTokenResponse extends BaseResponse {

  private String accessToken;


}
