package com.rbs.pbbdhb.coordinator.adbo.enums;

import static com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType.START_AFTER_CURRENT_DEAL;
import static com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType.START_IMMEDIATELY;
import static com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType.START_IMMEDIATELY_TRACK_AND_SWITCH;
import static com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType.START_OPTION_TO_SWITCH;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SubAccountType {

  FIXED_RATE(START_AFTER_CURRENT_DEAL),
  FIXED_RATE_ROLLOFF(START_AFTER_CURRENT_DEAL),
  TRACKER(START_IMMEDIATELY_TRACK_AND_SWITCH),
  TRACKER_ROLLOFF(START_OPTION_TO_SWITCH),
  VARIABLE(START_IMMEDIATELY);

  private final NewDealStartDateType newDealStartDateType;

}
