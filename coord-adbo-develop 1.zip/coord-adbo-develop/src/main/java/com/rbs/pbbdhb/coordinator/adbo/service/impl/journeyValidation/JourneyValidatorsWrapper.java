package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.PASS_ALL_CONDITIONS_SATISFIED;
import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.toList;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.service.Validator;
import com.rbs.pbbdhb.coordinator.adbo.util.EligibleToSwitchCheckAndSetForSubAccount;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lombok.Data;
import org.springframework.stereotype.Service;

@Service
public class JourneyValidatorsWrapper {

  private final List<Validator> validators;
  private final EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount;

  public JourneyValidatorsWrapper(List<Validator> validators,
      EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount) {
    this.validators = validators.stream()
        .filter(validator -> validator.getPriority() >= 0)
        .sorted(comparingInt(Validator::getPriority))
        .collect(toList());
    this.eligibleToSwitchCheckAndSetForSubAccount = eligibleToSwitchCheckAndSetForSubAccount;
  }

  public static ValidationRuleResult result(ValidationRuleResultCode code) {
    return new ValidationRuleResult(code, Collections.emptyList());
  }

  public ValidationRuleResult validate(JourneyValidation journeyValidation) {
    List<String> failingCins = new ArrayList<>();
    ValidationRuleResultCode resultCode = validators.stream()
        .filter(validator -> validator.test(journeyValidation))
        .findFirst()
        .map(validator -> {
          failingCins.addAll(validator.getFailingCins(journeyValidation));
          return validator.apply(journeyValidation);
        })
        .orElse(PASS_ALL_CONDITIONS_SATISFIED);
    eligibleToSwitchCheckAndSetForSubAccount.updateSubAccounts(journeyValidation);
    return new ValidationRuleResult(resultCode, failingCins);
  }

  @Data
  public static class ValidationRuleResult {

    private final ValidationRuleResultCode code;
    private final List<String> failingCins;
  }
}
