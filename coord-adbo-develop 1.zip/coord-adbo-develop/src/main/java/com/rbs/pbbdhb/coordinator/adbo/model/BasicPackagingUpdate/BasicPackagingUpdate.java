package com.rbs.pbbdhb.coordinator.adbo.model.BasicPackagingUpdate;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;
@Data
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class BasicPackagingUpdate {

    private String brand;

    private String caseId;

    private String mortgageReferenceNumber;

    private String sequenceNumber;

    private String channel;

    private String dateTime;

    private String loanPurpose;

    private String bankStatementRequested;

    private String podDecision;

    private String applicationType;

    @JsonProperty("isBasicPackagingRequired")
    private boolean isBasicPackagingRequired;

    @JsonProperty("isBasicPackagingReceived")
    private boolean isBasicPackagingReceived;

    @JsonProperty("isBasicPackagingClosed")
    private boolean isBasicPackagingClosed;

    @JsonProperty("isSIRequested")
    private boolean isSIRequested ;

    @JsonProperty("isSIReceived")
    private boolean isSIReceived;

    @JsonProperty("isSIClosed")
    private boolean isSIClosed;

    private List<PackagingApplicantInfo> applicants;

    private List<DocumentRequestUpdateDetail> documents;

    private String startDate;

    @JsonProperty("isRequiredDocsGenerated")
    private boolean isRequiredDocsGenerated;

}
