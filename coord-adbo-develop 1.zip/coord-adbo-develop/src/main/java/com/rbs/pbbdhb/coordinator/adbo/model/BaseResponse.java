package com.rbs.pbbdhb.coordinator.adbo.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;

public class BaseResponse implements Serializable {


  private static final long serialVersionUID = 5746389872216130770L;

  @JsonIgnore
  private String errorMessage;

  public BaseResponse() {
  }

  public BaseResponse(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

}

