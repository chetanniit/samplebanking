package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigInteger;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipLoan {

  private final DipLoanTypeEnum loanType;

  private final BigInteger monthlyPayment;

  private final BigInteger amountOutstanding;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean toBeRepaid;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean debtConsolidation;

  public enum DipLoanTypeEnum {
    HIRE_PURCHASE,
    SECURED_LOAN,
    UNSECURED_LOAN,
    STUDENT_LOAN,
    PERSONAL_CONTRACT_PURCHASE
  }

}
