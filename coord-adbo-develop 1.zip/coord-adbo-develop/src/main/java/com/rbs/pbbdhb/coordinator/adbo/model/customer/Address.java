package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Address {

  private Integer addressNo;
  private Integer addressNumber;
  private String address1;
  private String address2;
  private String address3;
  private String address4;
  private String address5;
  private String addrPostCode;

}