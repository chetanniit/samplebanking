package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;


import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.PensionType;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Retired {

  @NotNull(message = "Pension Type cannot be null")
  public PensionType pensionType;

  public BigDecimal annualAmount;

}
