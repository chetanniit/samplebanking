package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums;

public enum PropertyType {
  BUY_TO_LET,
  RESIDENTIAL;

  public String getLabel() {
    return this.name();
  }
}
