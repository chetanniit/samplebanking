package com.rbs.pbbdhb.coordinator.adbo;

import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

@SpringBootApplication
@EnableMongoAuditing
@ComponentScan(basePackages = "com.rbs.pbbdhb", excludeFilters = @Filter(type = FilterType.REGEX, pattern = "com.rbs.pbbdhb.error.ControllerExceptionHandler"))
public class CoordADBOApplication {

  public static void main(String[] args) {
    new SpringApplicationBuilder()
        .environment(new StandardEncryptableEnvironment())
        .sources(CoordADBOApplication.class)
        .run(args);
  }
}
