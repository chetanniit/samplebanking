package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerResponse {

  private GetCustomerData data;

}
