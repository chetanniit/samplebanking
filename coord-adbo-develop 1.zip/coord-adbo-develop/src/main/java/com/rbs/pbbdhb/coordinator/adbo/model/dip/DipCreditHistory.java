package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;

/**
 * ADBO is not allowed for user with declared bankruptcy or court proceedings.
 */
@Data
@Builder
public class DipCreditHistory {

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final boolean bankrupt;

  private final String bankruptDetails;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final boolean courtProceedings;

  private final String courtProceedingDetails;

}
