package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum JourneyValidationResultCode {
  FAILED("FAILED"),
  LIMITED("LIMITED"),
  PASS("PASS");

  private final String label;

  JourneyValidationResultCode(String label) {
    this.label = label;
  }

  /**
   * @deprecated This is unnecessary, it always equals {@link JourneyValidationResultCode#name()}
   */
  public String getLabel() {
    return label;
  }
}
