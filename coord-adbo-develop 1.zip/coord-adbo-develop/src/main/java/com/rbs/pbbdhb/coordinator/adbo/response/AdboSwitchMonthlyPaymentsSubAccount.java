package com.rbs.pbbdhb.coordinator.adbo.response;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class AdboSwitchMonthlyPaymentsSubAccount {

  private Integer subAccountNumber;
  private Integer sequenceNumber;
  private BigDecimal monthlyPayment;
  private BigDecimal newMonthlyPayment;
}
