package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;


public enum OtherIncomeSource {

  BENEFITS("BENEFITS"),
  INVESTMENT_INCOME("INVESTMENT_INCOME"),
  PRIVATE_PENSION("PRIVATE_PENSION"),
  STATE_PENSION("STATE_PENSION"),
  MAINTENANCE("MAINTENANCE"),
  TRUST("TRUST");


  private final String label;

  OtherIncomeSource(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
