package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.OtherIncome;
import java.math.BigDecimal;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class OtherIncomeValidator implements Validator {

  @Override
  public boolean supports(Class<?> clazz) {
    return OtherIncome.class.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {
    OtherIncome otherIncome = (OtherIncome) target;
    if (isNull(otherIncome.getSourceOfIncome())) {
      errors.rejectValue("sourceOfIncome", "required-non-empty", "sourceOfIncome cannot be null or empty");
    } else {
      switch (otherIncome.getSourceOfIncome()) {
        case BENEFITS:
          if (isNull(otherIncome.getBenefitType())) {
            errors.rejectValue("benefitType", "required-non-empty", "benefitType cannot be null or empty");
          } else {
            switch (otherIncome.getBenefitType()) {
              case ADOPTION_ALLOWANCE:
              case ATTENDANCE_ALLOWANCE:
              case CARERS_ALLOWANCE:
              case CHILD_BENEFIT:
              case CHILD_WORKING_TAX_CREDIT:
              case CONSTANT_ATTENDANCE_ALLOWANCE:
              case DISABILITY_LIVING_ALLOWANCE:
              case EMPLOYMENT_AND_SUPPORT_ALLOWANCE:
              case FOSTER_CARERS_ALLOWANCE:
              case GUARDIANS_ALLOWANCE:
              case INCOME_SUPPORT:
              case INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT:
              case PENSION_CREDIT:
              case PERSONAL_INDEPENDENCE_PAYMENT:
              case REDUCED_EARNINGS_ALLOWANCE:
              case UNIVERSAL_CREDIT:
              case WIDOWED_PARENT_ALLOWANCE:
              case WAR_WIDOW_PENSION:
                break;
              default:
                errors.rejectValue("benefitType", "unsupported-commitmentType",
                    "benefitType is currently  unsupported for our journey");
            }
          }
          break;
        case INVESTMENT_INCOME:
        case STATE_PENSION:
        case PRIVATE_PENSION:
        case MAINTENANCE:
        case TRUST:
          if (nonNull(otherIncome.getBenefitType())) {
            errors.rejectValue("benefitType", "required-non-empty", "benefitType is only applicable when Benefit type is Benefit");
          }
          break;
        default:
          errors.rejectValue("sourceOfIncome", "unsupported-commitmentType",
              "sourceOfIncome is unsupported for our journey");
      }
    }

    if (isNull(otherIncome.getAmount())) {
      errors.rejectValue("amount", "required-non-empty", "amount cannot be null or empty");
    } else {
      int max = otherIncome.getAmount().compareTo(BigDecimal.valueOf(99999999));
      if (max == 1) {
        errors.rejectValue("amount", "required-non-empty", "amount maxmimum allowed is 99999999");
      }
      int min = BigDecimal.valueOf(0).compareTo(otherIncome.getAmount());
      if (min == 1) {
        errors.rejectValue("amount", "required-non-empty", "amount minimum allowed is 0");
      }
    }

    if (isNull(otherIncome.getFrequency())) {
      errors.rejectValue("frequency", "required-non-empty", "frequency cannot be null or empty");
    } else {
      switch (otherIncome.getFrequency()) {
        case ANNUALLY:
        case FORTNIGHTLY:
        case FOUR_WEEKLY:
        case MONTHLY:
        case QUARTERLY:
        case SIX_MONTHLY:
        case WEEKLY:
          break;
        default:
          errors.rejectValue("frequency", "unsupported-commitmentType",
              "frequency is unsupported for our journey");

      }
    }

  }

}
