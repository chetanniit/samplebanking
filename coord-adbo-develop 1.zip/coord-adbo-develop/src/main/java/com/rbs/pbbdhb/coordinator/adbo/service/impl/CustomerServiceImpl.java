package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.MISSING_ADDRESS_HISTORY;
import static java.util.stream.Collectors.toList;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsPatch;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.PersonalDetailsResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AsyncDataLoader;
import com.rbs.pbbdhb.coordinator.adbo.service.CustomerService;
import com.rbs.pbbdhb.coordinator.adbo.service.PersonalDetailsMapper;
import com.rbs.pbbdhb.coordinator.adbo.validator.PostcodeValidator;
import com.rbs.pbbdhb.exception.BusinessException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

  private final AsyncDataLoader asyncDataLoader;
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final ModelMapper modelMapper;
  private final PersonalDetailsMapper personalDetailsMapper;
  private final PostcodeValidator postcodeValidator;

  private static void unsetDependants(Collection<AdboApplicant> applicants) {
    boolean hasDependents = applicants.stream()
        .map(AdboApplicant::getPersonalDetails)
        .map(PersonalDetails::getHasDependents)
        .anyMatch(BooleanUtils::isTrue);
    if (!hasDependents || !hasOver18Dependents(applicants)) {
      unsetOver18Dependants(applicants);
    }
    if (!hasDependents || !hasUnder18Dependents(applicants)) {
      unsetUnder18Dependants(applicants);
    }
  }

  private static boolean hasUnder18Dependents(Collection<AdboApplicant> adboApplicants) {
    int dependentsUnder18 = getDependentsCount(adboApplicants, PersonalDetails::getDependentsUnder18);
    return dependentsUnder18 > 0;
  }

  private static boolean hasOver18Dependents(Collection<AdboApplicant> adboApplicants) {
    int dependentsOver18 = getDependentsCount(adboApplicants, PersonalDetails::getDependentsOver18);
    return dependentsOver18 > 0;
  }

  private static int getDependentsCount(Collection<AdboApplicant> adboApplicants, Function<PersonalDetails, Integer> getter) {
    return adboApplicants.stream()
        .map(AdboApplicant::getPersonalDetails)
        .map(getter)
        .filter(Objects::nonNull)
        .mapToInt(Integer::intValue)
        .sum();
  }

  private static void unsetOver18Dependants(Collection<AdboApplicant> applicants) {
    unsetFromOutgoingPaymentDetails(applicants, OutgoingPaymentsDetails::setDependentExpenses,
        OutgoingPaymentsDetails::setHasDependentExpenses);
  }

  private static void unsetUnder18Dependants(Collection<AdboApplicant> applicants) {
    unsetFromOutgoingPaymentDetails(applicants, OutgoingPaymentsDetails::setChildcareExpenses,
        OutgoingPaymentsDetails::setHasChildcareExpenses);
  }

  private static <T> void unsetFromOutgoingPaymentDetails(Collection<AdboApplicant> applicants,
      BiConsumer<OutgoingPaymentsDetails, List<T>> listSetter, BiConsumer<OutgoingPaymentsDetails, Boolean> hasListSetter) {
    for (AdboApplicant applicant : applicants) {
      OutgoingPaymentsDetails outgoingPaymentsDetails = applicant.getOutgoingPaymentsDetails();
      if (outgoingPaymentsDetails != null) {
        listSetter.accept(outgoingPaymentsDetails, null);
        hasListSetter.accept(outgoingPaymentsDetails, null);
      }
    }
  }

  @Override
  public List<PersonalDetailsResponse> getPersonalDetails(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    return adboCaseDetails.getAdboApplicants().entrySet().stream()
        .map(entry -> {
              PersonalDetails personalDetails = entry.getValue().getPersonalDetails();
              return personalDetailsMapper.mapToResponse(personalDetails, entry.getKey());
            }
        ).collect(toList());
  }

  @Override
  public void patchPersonalDetails(String accountNumber, PersonalDetailsPatch personalDetailsPatch) {
    postcodeValidator.validatePostcode(personalDetailsPatch.getPreviousAddresses());
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    PersonalDetails personalDetails = adboCaseDetails.getAdboApplicants().get(personalDetailsPatch.getApplicantType())
        .getPersonalDetails();
    personalDetailsMapper.map(personalDetailsPatch, personalDetails);
    populateStreet(personalDetails);
    validate(personalDetails);
    unsetDependants(adboCaseDetails.getAdboApplicants().values());
    adboCaseDetailsDao.save(adboCaseDetails);
  }

  private void validate(PersonalDetails personalDetails) {
    LocalDate historyStart = personalDetails.getCurrentAddressMoveInDate();
    List<Address> previousAddresses = personalDetails.getPreviousAddresses();
    if (previousAddresses != null) {
      historyStart = Stream.concat(Stream.of(historyStart),
              previousAddresses.stream()
                  .map(address -> LocalDate.of(address.getMoveInYear(), address.getMoveInMonth(), 1)))
          .min(LocalDate::compareTo).get();
    }
    if (historyStart.isAfter(LocalDate.now().minusYears(3))) {
      throw new BusinessException(MISSING_ADDRESS_HISTORY, HttpStatus.BAD_REQUEST.value());
    }
  }

  private void populateStreet(PersonalDetails personalDetails) {
    String street = personalDetails.getCurrentAddressStructuredFormat().getStreet();
    String propertyName = personalDetails.getCurrentAddressStructuredFormat().getPropertyName();
    String propertyNumber = personalDetails.getCurrentAddressStructuredFormat().getPropertyNumber();
    String flatNumber = personalDetails.getCurrentAddressStructuredFormat().getFlatNumber();
    if (StringUtils.isBlank(street)) {
      if (StringUtils.isNotBlank(propertyName)) {
        personalDetails.getCurrentAddressStructuredFormat().setStreet(propertyName);
      } else if (StringUtils.isNotBlank(flatNumber)) {
        personalDetails.getCurrentAddressStructuredFormat().setStreet(flatNumber);
      } else {
        personalDetails.getCurrentAddressStructuredFormat().setStreet(propertyNumber);
      }
    }
  }

}
