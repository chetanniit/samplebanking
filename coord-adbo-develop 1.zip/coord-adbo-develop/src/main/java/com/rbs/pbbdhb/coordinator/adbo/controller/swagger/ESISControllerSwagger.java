package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.model.DocumentPaymentFlagsResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;


@Tag(name = "15 - Sales Illustration Document Generator")
public interface ESISControllerSwagger {

  @Operation(summary = "Generate document", description = "Generate document")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Success",
          content = {@Content(mediaType = MediaType.APPLICATION_PDF_VALUE)}),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available")})
  ResponseEntity<InputStreamResource> getESISDocumentForAdditionalBorrowing(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  );

  @Operation(summary = "Generate document to switch a product", description = "Generate document to switch a product")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Success",
          content = {@Content(mediaType = MediaType.APPLICATION_PDF_VALUE)}),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available")})
  ResponseEntity<InputStreamResource> getESISDocumentForProductSwitch(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  );

  @Operation(summary = "Retrieves stored document", description = "Retrieves stored document")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Success",
          content = {@Content(mediaType = MediaType.APPLICATION_PDF_VALUE)}),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available")})
  ResponseEntity<InputStreamResource> getStoredESISDocument(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  );

  @Operation(summary = "Retrieves flag for document upload and payment flag.", description = "Retrieves flag for document upload and payment flag.",
      responses = {
          @ApiResponse(responseCode = "200", content = @Content),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
          @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
          @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<DocumentPaymentFlagsResponse> getDocumentPaymentFlag(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);
}
