package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.entity.EligibilityBorrowing;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "03 - Adbo eligibility borrowing check", description = "Applies the user eligibility rules for additional borrowing")
public interface EligibilityBorrowingControllerSwagger {

  @Operation(description = "Persist eligibility borrowing details", operationId = "saveEligibilityBorrowing", summary = "Persist eligibility borrowing details, If exist same account number than override ", responses = {
      @ApiResponse(responseCode = "204", description = "Eligibility borrowing saved successfully", content = @Content(schema = @Schema(implementation = EligibilityBorrowing.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<Void> saveEligibilityBorrowing(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid EligibilityBorrowing eligibilityBorrowing);

  @Operation(description = "Retrieve eligibility borrowing details based on request criteria.", operationId = "getEligibilityBorrowing", summary = "Retrieve eligibility borrowing based on request criteria ", responses = {
      @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = EligibilityBorrowing.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<EligibilityBorrowing> getEligibilityBorrowing(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);
}
