package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import static lombok.AccessLevel.PRIVATE;

import java.math.BigDecimal;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
@Builder
@Getter
@RequiredArgsConstructor(access = PRIVATE)
public class DipSubAccount {

  public static final String DEFAULT_SUB_ACCOUNT_REPAYMENT_TYPE = "SUB_ACCOUNT_CAPITAL_REPAYMENT";

  private final BigDecimal currentBalance;

  private final Integer termRemaining;

  private final String subAccountRepaymentType;

  public static DipSubAccount subAccount(Integer termRemaining, BigDecimal currentBalance, String subAccountRepaymentType) {
    return new DipSubAccount(currentBalance, termRemaining, subAccountRepaymentType);
  }
}
