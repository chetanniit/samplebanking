package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Gender;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.model.AdditionalBorrower;
import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.ValidatableCustomer;
import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerSummaryResponse extends BaseResponse implements ValidatableCustomer {

  private static final long serialVersionUID = 39702844902619011L;

  private String cin;
  private Integer acctHolderPosition;
  private Title title;
  private String email;
  private String surname;
  private String middleName;
  private String forename;
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate dateOfBirth;
  private String mobileNumber;
  private String nationality;
  private Gender gender;
  private String gmsId;
  private MaritalStatus maritalStatus;


  private List<AdditionalBorrower> additionalBorrowers;

  private boolean hasGuarantor;
}

