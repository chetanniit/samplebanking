package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum DashboardDocUploadStatus {
    UNKNOWN, TODO, COMPLETE, TODO_AFTER_COMPLETE
}
