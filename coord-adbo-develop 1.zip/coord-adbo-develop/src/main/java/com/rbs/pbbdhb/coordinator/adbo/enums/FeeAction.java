package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.Getter;

@Getter
public enum FeeAction {
  ADD_CAPITALISE_TO_LOAN,
  NO_ACTION
}