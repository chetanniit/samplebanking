package com.rbs.pbbdhb.coordinator.adbo.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;


@Setter
@Getter
@ToString
@EqualsAndHashCode
@Valid
public class NewAdditionalProperty  {

  /**
   * new mortgage monthly payment for residential property
   */
  private BigDecimal newMortgageMonthlyPayment;

  /**
   * new mortgage monthly payment for residential property shared between both the parties 50-50
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnNewMortgageMonthlyPayment;
  /**
   * residential total monthly utility bills like council tax,bills
   */
  private BigDecimal monthlyRunningCostPayment;

  /**
   * Is your property let to your family member
   */
  private Boolean isLetToFamilyMember;
  /**
   * residential total monthly utility bills shared between both the parties 50-50 like council tax,bills
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyRunningCostPayment;
  /**
   * Buy To Let property monthly short fall
   */
  private BigDecimal buyTOLetShortFallAmount;
  /**
   * Buy To Let property monthly short fall amount shared between both the parties 50-50
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnBuyTOLetShortFallAmount;
}
