package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum BonusType {

  GUARANTEED("GUARANTEED"), PERFORMANCE_RELATED("PERFORMANCE_RELATED");
  private final String bonusType;

  BonusType(String bonusType) {
    this.bonusType = bonusType;
  }

  public String getBonusType() {
    return bonusType;
  }

}
