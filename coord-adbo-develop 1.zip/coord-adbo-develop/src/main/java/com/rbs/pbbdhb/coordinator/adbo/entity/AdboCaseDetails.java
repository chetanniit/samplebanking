package com.rbs.pbbdhb.coordinator.adbo.entity;

import static com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails.COLLECTION_TEMPLATE;
import static java.util.Optional.ofNullable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.dto.ProductSwitchPostSubmission;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.enums.CaseStatus;
import com.rbs.pbbdhb.coordinator.adbo.enums.Channel;
import com.rbs.pbbdhb.coordinator.adbo.enums.CustomerType;
import com.rbs.pbbdhb.coordinator.adbo.enums.LevelOfService;
import com.rbs.pbbdhb.coordinator.adbo.enums.LoanPurpose;
import com.rbs.pbbdhb.coordinator.adbo.enums.Route;
import com.rbs.pbbdhb.coordinator.adbo.model.BasicPackagingUpdate.BasicPackagingUpdate;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipResult;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDateTime;
import java.util.EnumMap;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

@ToString
@EqualsAndHashCode
@Getter
@Setter
@Document(collection = COLLECTION_TEMPLATE)
public class AdboCaseDetails {

  public static final String COLLECTION = "AdboCaseDetails";
  public static final String COLLECTION_TEMPLATE =
      "#{T(com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider).getCurrentBrand().toString()}_"
          + COLLECTION;

  @Id
  private String id;

  @Account
  private String accountNumber;

  @Valid
  private Channel channel = Channel.INTERNET;

  @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand")
  private String brand;

  private Boolean additionalBorrowingWithSwitch;

  private Boolean eligibleToSwitch;

  private LocalDateTime gmsSysDate;
  /**
   * TODO: Remove when downstream services stop using it.
   *
   * @deprecated Use {@link AdboApplicant#route} instead for each applicant separately
   */
  @Deprecated
  private Route route;

  private LoanPurpose loanPurpose = LoanPurpose.ADDITIONAL_BORROWING;

  private ApplicationType applicationType = ApplicationType.RESIDENTIAL;

  private ApplicationType existingMortgageType = ApplicationType.RESIDENTIAL;

  private LevelOfService levelOfService = LevelOfService.NON_ADVISED;

  private CustomerType customerType = CustomerType.EXISTING_CUSTOMER;

  private boolean scottishApplication;

  private boolean northernIrelandApplication;

  private String caseId;

  private CaseStatus status;

  private String mortgageApplSeq;

  private boolean createNewRecord;

  private LocalDateTime caseCreationDate;

  @CreatedBy
  private String createdBy;

  @LastModifiedBy
  private String modifiedBy;

  @CreatedDate
  private LocalDateTime createdDate;

  @LastModifiedDate
  private LocalDateTime modifiedDate;

  @Version
  private Long version;

  private String validationResult;

  private String validationRuleResultCode;

  private Boolean hasSecondCharge;

  private EligibilityApplicant eligibilityApplicant;

  private EligibilityBorrowing eligibilityBorrowing;

  private ReadyToStart readyToStart;

  private AdditionalBorrowingCalculator additionalBorrowingCalculator;

  private EnumMap<ApplicantType, AdboApplicant> adboApplicants;

  private SalesIllustration salesIllustration;

  private ValuationContact valuationContact;

  private DipResult dipResult;

  private DipApplication dipRequest;

  private String stageNumber;

  private ProductSwitchPostSubmission switchSubmissionResult;

  private HardscoreDecision hardscoreDecision;

  private BasicPackagingUpdate basicPackagingUpdate;
  
  @JsonIgnore
  public void resetSwitchDetails() {
    ofNullable(adboApplicants).ifPresent(adboApplicantEnumMap -> adboApplicantEnumMap.values()
        .forEach(adboApplicant -> ofNullable(adboApplicant.getAgreementsAndDisclaimers())
            .ifPresent(agreementsAndDisclaimers -> agreementsAndDisclaimers.setReadSwitchIllustration(null))));
    ofNullable(salesIllustration).ifPresent(illustration -> illustration.setProductSwitchDocumentUrl(null));
    ofNullable(additionalBorrowingCalculator).ifPresent(adboCalculator -> {
      adboCalculator.setCohortDate(null);
      ofNullable(adboCalculator.getSubAccountDetails()).ifPresent(subAccounts -> subAccounts
          .forEach(subAccount -> {
            subAccount.setSwitchImmediately(null);
            subAccount.setNewDealStartDateType(null);
            subAccount.setSelectedForSwitch(null);
          }));
    });
  }
}
