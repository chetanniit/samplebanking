package com.rbs.pbbdhb.coordinator.adbo.response;

import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
public class AdboSwitchMonthlyPaymentsResponse {

  private Integer sequenceNumber;
  private BigDecimal newMonthlyPayment;
  private List<AdboSwitchMonthlyPaymentsSubAccount> subAccounts;

}
