package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.rbs.pbbdhb.coordinator.adbo.enums.PropertyType;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Setter
@Getter
public class AdditionalPropertyDetails  {

  /**
   * The property customer using it for Buy to Let or Residential
   */
  private PropertyType propertyType;

  /**
   * This property is self-financing or not Buy to Let
   */
  private Boolean hasSelfFinance;

  /**
   * How much shortfall your rental income to cover your property cost- Buy to Let
   */
  private BigDecimal shortFallAmount;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnShortFallAmount;

  /**
   * Continue to pay more than 6 months - Buy to Let
   */
  private Boolean continueForMoreThanSixMonths;

  /**
   * Is there any existing mortgage on this property - only for Residential
   */
  private Boolean hasMortgageOnThisProperty;

  /**
   * monthly mortgage payment - only for Residential
   */
  private BigDecimal monthlyMortgagePayment;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyMortgagePayment;
  /**
   * Will this mortgage be paid off before your additional borrowing completes or with your borrowing funds - only for Residential
   */
  private Boolean willThisMortgagePaidOff;


  /**
   * Any running cost on this property , example council tax and bills-only for Residential
   */
  private Boolean hasRunningCosts;

  /**
   * Is your property let to your family member
   */
  private Boolean isLetToFamilyMember;
  /**
   * Running cost per month - only for Residential
   */
  private BigDecimal monthlyRunningCostsPayment;

  /**
   * applicantShare means 50% of currentBalance if the owner type is BOTH
   */
  @Schema(accessMode = Schema.AccessMode.READ_ONLY)
  private BigDecimal applicantShareOnMonthlyRunningCostsPayment;
  /**
   * Continue to pay running cost more than 6 months - Buy to Let or Residential
   */
  private Boolean runningCostsContinueForMoreThanSixMonths;

  /**
   * Outgoings Owner
   */
  @NotNull(message = "Owner type cannot be null")
  private OutgoingsOwnerType owner;

}
