package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums;

public enum BorrowingPurposeType {
  HOME_IMPROVEMENT,
  BUYOUT,
  EDUCATION,
  GIFT,
  HOLIDAY,
  MEDICAL,
  PURCHASE_ADDITIONAL_PROPERTY,
  REDEEM_SECOND_CHARGE,
  VEHICLE,
  WEDDING;

  public String getLabel() {
    return this.name();
  }

}
