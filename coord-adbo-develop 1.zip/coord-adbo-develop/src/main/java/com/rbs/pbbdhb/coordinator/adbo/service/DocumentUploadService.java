package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.response.DocumentsUploadURLResponse;

public interface DocumentUploadService {

  DocumentsUploadURLResponse getDocUploadUrl(String accountNumber, String cin, String brand);
}
