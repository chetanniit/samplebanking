package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.enums.Route;
import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;

public interface RouteService {

  void saveRoute(String accountNumber, String cin, Route route, ValidationRuleResultCode validationRuleResultCode);
}
