package com.rbs.pbbdhb.coordinator.adbo.mapper;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.request.AuthTokenRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface AuthTokenMapper {

  @Mapping(target = "applicantId", source = "applicantId")
  @Mapping(target = "caseId", source = "caseDetails.caseId")
  @Mapping(target = "cin", source = "cin")
  @Mapping(target = "loanPurpose", source = "caseDetails.loanPurpose")
  @Mapping(target = "applicationType", source = "caseDetails.applicationType")
  AuthTokenRequest xoAuthTokenRequest(AdboCaseDetails caseDetails, String applicantId, String cin);
}
