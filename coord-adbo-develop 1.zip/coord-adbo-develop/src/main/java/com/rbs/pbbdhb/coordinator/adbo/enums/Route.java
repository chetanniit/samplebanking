package com.rbs.pbbdhb.coordinator.adbo.enums;

import java.util.HashMap;
import java.util.Map;

public enum Route {

  MOBILE_BANKING("mobile"),
  E_BANKING("ebanking");

  private static final Map<String, Route> BY_CHANNEL_ROUTE = new HashMap<>();

  static {

    for (Route r : values()) {
      BY_CHANNEL_ROUTE.put(r.channelRoute, r);
    }
  }

  public final String channelRoute;

  Route(String channelRoute) {
    this.channelRoute = channelRoute;
  }

  public static Route valueOfRoute(String routeChannel) {

    return BY_CHANNEL_ROUTE.get(routeChannel);
  }

}
