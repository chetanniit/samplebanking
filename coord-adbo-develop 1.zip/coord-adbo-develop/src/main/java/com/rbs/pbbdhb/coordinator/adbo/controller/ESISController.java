package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.ESISControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.DocumentPaymentFlagsResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISDocument;
import com.rbs.pbbdhb.coordinator.adbo.service.ESISDocumentService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import java.io.ByteArrayInputStream;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@Validated
public class ESISController implements ESISControllerSwagger {

  private final ESISDocumentService service;

  /**
   * This Get call will generate Sales ESIS Document.
   *
   * @param accountNumber is a unique identification number
   * @param brand         is nwb or rbs
   * @return filename=sales-esis.pdf
   */

  @Override
  @GetMapping(path = "/sales-illustration", produces = MediaType.APPLICATION_PDF_VALUE)
  public ResponseEntity<InputStreamResource> getESISDocumentForAdditionalBorrowing(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  ) {
    log.info("getESISDocumentForAdditionalBorrowing start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<InputStreamResource> response = buildResponseEntity(service.generateSalesEsisRequestForAdditionalBorrowing(accountNumber), accountNumber,
        brand);
    log.info("getESISDocumentForAdditionalBorrowing end's with response {} account_number: {}, brand: {}", response.getBody(), accountNumber, brand,
        channelRoute);
    return response;
  }

  @Override
  @GetMapping(path = "/productSwitchSalesIllustration", produces = MediaType.APPLICATION_PDF_VALUE)
  public ResponseEntity<InputStreamResource> getESISDocumentForProductSwitch(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") final String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  ) {
    log.info("getESISDocumentForProductSwitch start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<InputStreamResource> response = buildResponseEntity(service.generateSalesEsisRequestForProductSwitch(accountNumber), accountNumber, brand);
    log.info("getESISDocumentForProductSwitch end's with response {} account_number: {}, brand: {}", response.getBody(), accountNumber,
        brand, channelRoute);
    return response;
  }

  private ResponseEntity<InputStreamResource> buildResponseEntity(ESISDocument response, String accountNumber, String brand) {
    log.info("Sales-Esis Document call Successful account_number{}, brand {}", accountNumber, brand);
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Disposition", "inline; filename=sales-esis.pdf");
    return ResponseEntity.ok()
        .headers(headers)
        .contentType(MediaType.APPLICATION_PDF)
        .body(new InputStreamResource(new ByteArrayInputStream(response.getBody())));
  }

  /**
   * This Get call will get Sales ESIS Document from S3 Bucket.
   *
   * @param accountNumber is a unique identification number
   * @param brand         is nwb or rbs
   * @return filename=sales-esis.pdf
   */
  @Override
  @GetMapping(path = "/stored-sales-illustration", produces = MediaType.APPLICATION_PDF_VALUE)
  public ResponseEntity<InputStreamResource> getStoredESISDocument(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  ) {
    log.info("getStoredESISDocument start- Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<InputStreamResource> response = buildResponseEntity(service.getSalesEsisRequest(accountNumber),
        accountNumber, brand);
    log.info("getStoredESISDocument end's with response {} account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand,channelRoute);
    return response;
  }

  /**
   * This Get call will produce flag for document upload and payment.
   *
   * @param accountNumber is a unique identification number
   * @param brand         is nwb or rbs
   * @return Map<String, Boolean>
   */
  @Override
  @GetMapping(path = "/docupload-payment-flags", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<DocumentPaymentFlagsResponse> getDocumentPaymentFlag(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute
  ) {
    log.info("getDocumentPaymentFlag start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<DocumentPaymentFlagsResponse> response = new ResponseEntity<>(service.getFlag(accountNumber), HttpStatus.OK);
    log.info("getDocumentPaymentFlag end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber,
        brand, channelRoute);
    return response;
  }

}
