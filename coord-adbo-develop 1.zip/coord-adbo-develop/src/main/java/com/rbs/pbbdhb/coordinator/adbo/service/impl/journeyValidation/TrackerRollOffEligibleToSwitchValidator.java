package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.PASS_ELIGIBLE_TO_SWITCH_TRACKER_ROLLOFF;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.util.EligibleToSwitchCheckAndSetForSubAccount;

@Service
public class TrackerRollOffEligibleToSwitchValidator extends AbstractValidator {

  private final EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount;

  public TrackerRollOffEligibleToSwitchValidator(@Value("${journeyValidator.priority.trackerEligibleToSwitchRollOff}") int priority,
      EligibleToSwitchCheckAndSetForSubAccount eligibleToSwitchCheckAndSetForSubAccount) {
    super(priority, PASS_ELIGIBLE_TO_SWITCH_TRACKER_ROLLOFF);
    this.eligibleToSwitchCheckAndSetForSubAccount = eligibleToSwitchCheckAndSetForSubAccount;
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    List<SubAccount> subAccounts = journeyValidation.getAccountSummaryApiResponse().getSubAccounts();
    for (SubAccount subAccount : subAccounts) {
      boolean isEligibleToSwitch = eligibleToSwitchCheckAndSetForSubAccount.trackerRollOffEligibleToSwitch(subAccount, journeyValidation
          .getAccountSummaryApiResponse().getSysDate());
      if (isEligibleToSwitch) {
        return true;
      }
    }
    return false;
  }
}