package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingJointSubmitRequest;

public interface AdditionalBorrowingJointSubmitService {

  void saveAdditionalBorrowingJointSubmit(String accountNumber, String customerId,
      AdditionalBorrowingJointSubmitRequest additionalBorrowingJointSubmitRequest);

}
