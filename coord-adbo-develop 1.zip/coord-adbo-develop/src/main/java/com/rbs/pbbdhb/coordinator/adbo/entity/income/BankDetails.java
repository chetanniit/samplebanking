package com.rbs.pbbdhb.coordinator.adbo.entity.income;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankDetails  {

  private String bankAccountName;
  private String bankAccountNumber;
  private int yearsWithBank;
  private int monthsWithBank;
  private String bankSortCode;
  private String bankName;
}
