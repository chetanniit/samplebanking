package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.APPLICATION_IN_PROGRESS_CAN_NOT_RESUBMIT;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.VALUATION_CONTACT_DETAILS_REQUIRED;
import static com.rbs.pbbdhb.coordinator.adbo.enums.CaseStatus.CAPIE_UPDATED;
import static com.rbs.pbbdhb.coordinator.adbo.enums.CaseStatus.SUBMIT_ORCHESTRATION;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.hasContinuesEmployment;
import static java.math.BigDecimal.valueOf;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.StringUtils.isAllBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.entity.AgreementsAndDisclaimers;
import com.rbs.pbbdhb.coordinator.adbo.entity.ValuationContact;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employed;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.SelfEmployed;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.kafka.AdboKafkaEventDto;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingSubmitRequest;
import com.rbs.pbbdhb.coordinator.adbo.service.AdditionalBorrowingSubmitService;
import com.rbs.pbbdhb.coordinator.adbo.service.PublishMessageService;
import com.rbs.pbbdhb.exception.BusinessException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AdditionalBorrowingSubmitServiceImpl implements AdditionalBorrowingSubmitService {

  private static final BigDecimal MAX_TOTAL_BORROWING_WITHOUT_VALUATION = valueOf(350000);
  private static final String HOUSE_PROPERTY_TYPE_CODE = "House";
  private static final Integer MAX_LTV_WITHOUT_VALUATION = 60;
  private final PublishMessageService publishMessageService;
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  @Value("${kafka.adbo.event.topic-name}")
  private String topicName;
  @Value("${kafka.adbo.channel}")
  private String channel;
  @Value("${kafka.adbo.journey}")
  private String journey;
  @Value("${adbo.delay.response.seconds}")
  private long delayResponseSeconds;
  @Value("${adbo.disableApplicationInProgressCheck:false}")
  private Boolean disableApplicationInProgressCheck;

  @Override
  public Product getSelectedProduct(final String accountNumber) {
    log.info("getSelectedProduct start for the given accountNumber {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    Optional<Product> productOptional = adboCaseDetails.getSalesIllustration().getProductDetails().stream().findFirst();
    if (productOptional.isEmpty()) {
      log.error("products not found for the given account number {}", accountNumber);
      throw new BusinessException(Constants.ACCOUNT_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    log.info("getSelectedProduct end for the given accountNumber {}", accountNumber);
    return productOptional.get();
  }

  @Override
  public void saveAdditionalBorrowingSubmit(final String accountNumber, final AdditionalBorrowingSubmitRequest adboSubmitRequest) {
    log.info("saveAdditionalBorrowingSubmit start for the give accountNumber {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    validateRequest(adboSubmitRequest, adboCaseDetails);
    if (isNotBlank(adboSubmitRequest.getFullName()) && isNotBlank(adboSubmitRequest.getPhoneNumber())) {
      adboCaseDetails.setValuationContact(
          ValuationContact.builder().fullName(adboSubmitRequest.getFullName().trim())
              .mobileNumber(adboSubmitRequest.getPhoneNumber().trim()).build());
    }
    updateAgreementsAndDisclaimersForMainApplicant(adboCaseDetails, adboSubmitRequest);
    setCustomerProvidedValuation(adboCaseDetails);
    adboCaseDetails.setStatus(SUBMIT_ORCHESTRATION);
    AdboCaseDetails caseDetails = adboCaseDetailsDao.save(adboCaseDetails);
    manageAddressFields(caseDetails);
    publishMessageToKafka(caseDetails);
    try {
      TimeUnit.SECONDS.sleep(delayResponseSeconds);
    } catch (InterruptedException e) {
      log.error("Exception occurred while pausing the current thread {} seconds", delayResponseSeconds);
    }
    log.info("saveAdditionalBorrowingSubmit end for the give accountNumber {}", accountNumber);
  }

  private void validateRequest(AdditionalBorrowingSubmitRequest adboSubmitRequest, AdboCaseDetails adboCaseDetails) {
    if (!disableApplicationInProgressCheck && nonNull(adboCaseDetails.getStatus()) && !Objects.equals(CAPIE_UPDATED,
        adboCaseDetails.getStatus())) {
      log.error("application is in progress, can't resubmit again");
      throw new BusinessException(APPLICATION_IN_PROGRESS_CAN_NOT_RESUBMIT, HttpStatus.BAD_REQUEST.value());
    }
    AdditionalBorrowingCalculator calculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    if (valuationRequired(calculator)
        && (isBlank(adboSubmitRequest.getFullName()) || isBlank(adboSubmitRequest.getPhoneNumber()))) {
      throw new BusinessException(VALUATION_CONTACT_DETAILS_REQUIRED, HttpStatus.BAD_REQUEST.value());
    }
  }

  private boolean valuationRequired(AdditionalBorrowingCalculator calculator) {
    return !HOUSE_PROPERTY_TYPE_CODE.equals(calculator.getPropertyTypeCode())
        || calculator.getLoanToValue().compareTo(valueOf(MAX_LTV_WITHOUT_VALUATION)) > 0
        || calculator.getTotalTrueBalance().add(valueOf(calculator.getBorrowingAmount())).compareTo(MAX_TOTAL_BORROWING_WITHOUT_VALUATION)
        > 0;
  }

  private void updateAgreementsAndDisclaimersForMainApplicant(AdboCaseDetails adboCaseDetails,
      AdditionalBorrowingSubmitRequest adboSubmitRequest) {

    AgreementsAndDisclaimers agreementsAndDisclaimers = adboCaseDetails.getAdboApplicants().get(ApplicantType.MAIN)
        .getAgreementsAndDisclaimers();
    agreementsAndDisclaimers.setCantLendTillApproved(adboSubmitRequest.getCantLendTillApproved());
    agreementsAndDisclaimers.setCreditCheckDisclaimer(adboSubmitRequest.getCreditCheckDisclaimer());
    agreementsAndDisclaimers.setReadMortgageIllustrationUnderstoodProduct(adboSubmitRequest.getReadMortgageIllustrationUnderstoodProduct());
    agreementsAndDisclaimers.setRightMortgageConfident(adboSubmitRequest.getRightMortgageConfident());

  }

  private void setCustomerProvidedValuation(AdboCaseDetails adboCaseDetails) {
    AdditionalBorrowingCalculator additionalBorrowingCalculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    if (isNull(additionalBorrowingCalculator.getEstimatedPropertyValue())) {
      BigDecimal totalTrueBalance = additionalBorrowingCalculator.getTotalTrueBalance();
      BigDecimal totalLoanAmount = totalTrueBalance.add(valueOf(additionalBorrowingCalculator.getBorrowingAmount()));
      BigDecimal loanToValue = totalLoanAmount.multiply(valueOf(100))
          .divide(additionalBorrowingCalculator.getHpiValuation(), 0, RoundingMode.CEILING);
      additionalBorrowingCalculator.setEstimatedPropertyValue(additionalBorrowingCalculator.getHpiValuation().intValue());
      if (totalLoanAmount.compareTo(MAX_TOTAL_BORROWING_WITHOUT_VALUATION) <= 0) {
        if (Objects.equals(HOUSE_PROPERTY_TYPE_CODE, additionalBorrowingCalculator.getPropertyTypeCode())
            && loanToValue.intValue() <= MAX_LTV_WITHOUT_VALUATION) {
          additionalBorrowingCalculator.setEstimatedPropertyValue(null);
        }
      }
    }
  }


  private void publishMessageToKafka(final AdboCaseDetails adboCaseDetails) {
    log.info("setPublishMessage is start for accountNumber {}", adboCaseDetails.getAccountNumber());
    AdboKafkaEventDto kafkaEventDto =
        AdboKafkaEventDto.builder()
            .journey(journey)
            .topicName(topicName)
            .channel(channel)
            .brandName(adboCaseDetails.getBrand())
            .adboCaseDetails(getValidEmploymentDetails(adboCaseDetails))
            .build();
    publishMessageService.publishMessageToTopic(kafkaEventDto);
    log.info("setPublishMessage is end for accountNumber {}", adboCaseDetails.getAccountNumber());
  }

  private AdboCaseDetails getValidEmploymentDetails(AdboCaseDetails adboCaseDetails) {
    adboCaseDetails.getAdboApplicants().values().stream().forEach(adboApplicant -> {
      adboApplicant.getIncome().getEmployments().removeIf(
          employment -> (employment instanceof Employed) && employedLessThanOneYear((Employed) employment));
      adboApplicant.getIncome().getEmployments().removeIf(
          employment -> (employment instanceof SelfEmployed) && selfEmployedLessThanTwoYear((SelfEmployed) employment));
    });
    return adboCaseDetails;
  }

  private boolean employedLessThanOneYear(Employed employed) {
    return isFalse(hasContinuesEmployment(employed));
  }

  private boolean selfEmployedLessThanTwoYear(SelfEmployed selfEmployed) {
    return nonNull(selfEmployed.getHasBeenTradingForTwoYears())
        && (isFalse(selfEmployed.getHasBeenTradingForTwoYears()));
  }

  private void manageAddressFields(AdboCaseDetails adboCaseDetails) {
    adboCaseDetails.getAdboApplicants().forEach((applicantType, adboApplicant) -> {
      Address currentAddressStructuredFormat = adboApplicant.getPersonalDetails().getCurrentAddressStructuredFormat();
      adboApplicant.getPersonalDetails().getCurrentAddressStructuredFormat()
          .setStreet(getLimitedLengthValue(currentAddressStructuredFormat.getStreet(), 30));
      adboApplicant.getPersonalDetails().getCurrentAddressStructuredFormat()
          .setTown(getLimitedLengthValue(currentAddressStructuredFormat.getTown(), 28));
      adboApplicant.getPersonalDetails().getCurrentAddressStructuredFormat()
          .setFlatNumber(getLimitedLengthValue(currentAddressStructuredFormat.getFlatNumber(), 10));
      adboApplicant.getPersonalDetails().getCurrentAddressStructuredFormat()
          .setPropertyNumber(getLimitedLengthValue(currentAddressStructuredFormat.getPropertyNumber(), 5));
      adboApplicant.getPersonalDetails().getCurrentAddressStructuredFormat().setPropertyName(
          isAllBlank(currentAddressStructuredFormat.getFlatNumber(), currentAddressStructuredFormat.getPropertyNumber(),
              currentAddressStructuredFormat.getPropertyName())
              ? getLimitedLengthValue(adboApplicant.getPersonalDetails().getCurrentAddress().getAddress1(), 22)
              : getLimitedLengthValue(currentAddressStructuredFormat.getPropertyName(), 22));

    });
  }

  private String getLimitedLengthValue(String input, int length) {
    if (isNotBlank(input)) {
      if (input.length() > length) {
        return input.substring(0, length);
      } else {
        return input;
      }
    }
    return "";
  }
}
