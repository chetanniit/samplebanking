package com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import java.time.LocalDate;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class Customer {

  @ToString.Exclude
  private final String firstName;

  @JsonFormat(pattern = Constants.DATE_PATTERN)
  @ToString.Exclude
  private final LocalDate dateOfBirth;

  private final ApplicantType applicantType;
  private final boolean isLoggedInUser;

  private final Boolean hasKycPassed;
}
