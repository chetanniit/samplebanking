package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmploymentType;
import jakarta.validation.constraints.NotNull;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = As.EXISTING_PROPERTY, property = "type",
    visible = true
)
@JsonSubTypes({
    @Type(value = Employed.class, name = "EMPLOYED"),
    @Type(value = SelfEmployed.class, name = "SELF_EMPLOYED")
})
public interface Employment {

  @NotNull(message = "EmploymentType cannot be null")
  EmploymentType getType();

}
