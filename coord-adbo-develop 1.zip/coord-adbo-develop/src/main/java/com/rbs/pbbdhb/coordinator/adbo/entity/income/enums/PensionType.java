package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;


public enum PensionType {

  STATE_PENSION("STATE_PENSION"),
  PRIVATE_PENSION("PRIVATE_PENSION"),
  NONE("NONE");

  private final String label;

  PensionType(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

}
