package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.entity.Address;
import com.rbs.pbbdhb.coordinator.adbo.entity.GmsAddress;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import java.time.LocalDate;
import java.util.List;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode
public class PersonalDetailsResponse {

  @NotNull
  @ToString.Include
  private ApplicantType applicantType;

  @NotNull
  private Title title;

  private String nationality;

  private String nationalityIsoCode;

  private MaritalStatus maritalStatus;

  @NotNull
  private String firstName;

  private String middleName;

  @NotNull
  private String lastName;

  @NotNull
  @Email(regexp = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$")
  private String email;

  @NotNull
  @Pattern(regexp = "^(0[^7]\\d{9,13})|(07\\d{9})$")
  private String mobileNumber;

  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate currentAddressMoveInDate;

  @NotNull
  private GmsAddress currentAddress;

  private Address currentAddressStructuredFormat;

  private List<Address> previousAddresses;

  @ToString.Include
  private Boolean hasDependents;

  @ToString.Include
  private Integer dependentsOver18;

  @ToString.Include
  private Integer dependentsUnder18;

  @AssertTrue
  @ToString.Include
  private Boolean isAboveInformationCorrect;

  @NotNull
  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate dateOfBirth;

  @ToString.Include
  private boolean isEmailChanged;

  @ToString.Include
  private boolean isMobileNumberChanged;

  @ToString.Include
  private boolean isNationalityChanged;

  @ToString.Include
  private boolean isMaritalStatusChanged;
}
