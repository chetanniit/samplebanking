package com.rbs.pbbdhb.coordinator.adbo.controller;


import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.DocumentUploadControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.response.DocumentsUploadURLResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.DocumentUploadService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
public class DocumentUploadController implements DocumentUploadControllerSwagger {

  private final DocumentUploadService documentUploadService;

  @Autowired
  public DocumentUploadController(DocumentUploadService documentUploadService) {
    this.documentUploadService = documentUploadService;
  }

  @Override
  @GetMapping(path = "/docUploadUrl", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<DocumentsUploadURLResponse> getDocUploadUrl(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.CIN) @CIN String cin,
      @Parameter(name = Headers.BRAND, description = Constants.BRAND_DESCRIPTION)
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(RBS|rbs|nwb|NWB)",
          message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)",
          message = "Invalid Channel Route") String channelRoute) {
    log.info("getDocUploadUrl start - Headers - account_number: {}, cin: {}, brand: {}, channel: {}", accountNumber, cin, brand,
        channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<DocumentsUploadURLResponse> response = new ResponseEntity<>(documentUploadService.getDocUploadUrl(accountNumber, cin, brand), HttpStatus.OK);
    log.info("getDocUploadUrl end's with response {}, account_number: {}, cin: {}, brand: {}, channel: {}", response.getBody(), accountNumber, cin, brand, channelRoute);
    return response;
  }
}
