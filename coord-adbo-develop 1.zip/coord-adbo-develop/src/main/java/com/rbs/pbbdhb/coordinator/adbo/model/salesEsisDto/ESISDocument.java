package com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ESISDocument {

  private final String url;

  @Getter
  private final byte[] body;

  public final boolean hasUrl() {
    return url != null;
  }

  public final boolean hasBody() {
    return body != null;
  }
}
