package com.rbs.pbbdhb.coordinator.adbo.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.AssertFalse;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
public class EligibilityApplicant  {

  @AssertTrue(message = "hasJointApplicantPermission if not null has to be true")
  private Boolean hasJointApplicantPermission;

  @NotNull(message = "eligibleBorrower must not be Null")
  @AssertTrue(message = "eligibleBorrower must be True")
  private Boolean eligibleBorrower;

  @NotNull(message = "eligibleNationality must not be Null, It should be either True or False")
  private Boolean eligibleNationality;

  private Boolean jointApplicantEligibleNationality;

  @NotNull(message = "financialDefaulter must not be Null")
  @AssertFalse(message = "financialDefaulter must be False")
  @Schema(name = "financialDefaulter", example = "false")
  private Boolean financialDefaulter;

}
