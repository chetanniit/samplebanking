package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CoreCustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class AdditionalBorrowerValidator extends AbstractValidator {

  private final int allowedBorrowers;

  public AdditionalBorrowerValidator(@Value("${journeyValidator.priority.additionalBorrower}") int priority,
      @Value("${journeyValidator.additionalBorrower.allowedAdditionalCount:1}") int allowedAdditional) {
    super(priority, ValidationRuleResultCode.FAILED_DUE_TO_MORE_THAN_ALLOWED_BORROWERS);
    this.allowedBorrowers = allowedAdditional + 1;
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    List<CoreCustomerSummaryResponse> applicants = journeyValidation.getCustomerSummaryApiResponses();
    return applicants.size() > allowedBorrowers;
  }

}
