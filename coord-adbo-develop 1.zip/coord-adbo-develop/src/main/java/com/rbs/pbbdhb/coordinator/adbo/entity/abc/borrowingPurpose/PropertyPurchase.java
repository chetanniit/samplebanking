package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose;

import static java.lang.Boolean.FALSE;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.PropertyType;
import java.math.BigDecimal;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class PropertyPurchase  implements AdboAmountDistribution {

  @NotNull(message = "Customer has to choose either buy to let or residential as additional property type")
  private PropertyType propertyType;

  private Boolean selfFinancing;

  private Boolean anotherMortgage;
  private Boolean planToRentCurrentProperty;
  private String propertyAddress;

  @NotNull(message = "Borrowing purpose amount cannot be null")
  @Positive(message = "Borrowing Purpose amount should not be zero")
  private BigDecimal amount;
  private BorrowingPurposeType type;

  @Override
  public BigDecimal getAmount() {
    return amount;
  }

  @Override
  public BorrowingPurposeType getType() {
    return type;
  }

  @AssertTrue(message = "Given additional property purchase is buy to let, self financing should not be null")
  public boolean isBuyToLetValid() {
    return propertyType != PropertyType.BUY_TO_LET || selfFinancing != null;
  }

  @AssertTrue(message = "Given additional property purchase is residential, Customer must not plan to rent and answer the another mortgage question")
  public boolean isResidentialValid() {
    return propertyType != PropertyType.RESIDENTIAL || FALSE.equals(planToRentCurrentProperty) && anotherMortgage != null;
  }

}
