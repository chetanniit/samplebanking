package com.rbs.pbbdhb.coordinator.adbo.entity.income.employment;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.AdditionalIncomeSources;
import com.rbs.pbbdhb.coordinator.adbo.enums.BonusType;
import com.rbs.pbbdhb.coordinator.adbo.enums.FrequencyType;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalIncome  {

  private AdditionalIncomeSources sourceOfIncome;
  private FrequencyType frequency;
  private BonusType bonusType;
  private BigDecimal amount;

}
