package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.request.JointApplicantEmailUpdateRequest;
import com.rbs.pbbdhb.coordinator.adbo.request.JointApplicantMobileUpdateRequest;
import com.rbs.pbbdhb.coordinator.adbo.service.JointApplicantUpdateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class JointApplicantUpdateServiceImpl implements JointApplicantUpdateService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public void updateEmail(String accountNumber, JointApplicantEmailUpdateRequest jointApplicantEmailUpdateRequest) {
    log.info("updateEmail started for the joint applicant for give accountNumber {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    AdboApplicant adboApplicant = adboCaseDetails.getAdboApplicants().get(ApplicantType.JOINT1);
    PersonalDetails personalDetails = adboApplicant.getPersonalDetails();
    personalDetails.setEmail(jointApplicantEmailUpdateRequest.getEmail());
    adboCaseDetailsDao.save(adboCaseDetails);
    log.info("updateEmail ended for the joint applicant for give accountNumber {}", accountNumber);
  }

  @Override
  public void updateMobileNumber(String accountNumber, JointApplicantMobileUpdateRequest jointApplicantMobileUpdateRequest) {
    log.info("updateMobileNumber started for the joint applicant for give accountNumber {}", accountNumber);
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getValidCaseDetailsByAccountNumber(accountNumber);
    AdboApplicant adboApplicant = adboCaseDetails.getAdboApplicants().get(ApplicantType.JOINT1);
    PersonalDetails personalDetails = adboApplicant.getPersonalDetails();
    personalDetails.setMobileNumber(jointApplicantMobileUpdateRequest.getMobileNumber());
    adboCaseDetailsDao.save(adboCaseDetails);
    log.info("updateMobileNumber ended for the joint applicant give accountNumber {}", accountNumber);
  }
}
