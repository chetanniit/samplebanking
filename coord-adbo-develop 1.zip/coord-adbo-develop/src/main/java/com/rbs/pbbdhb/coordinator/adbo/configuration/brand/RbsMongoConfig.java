package com.rbs.pbbdhb.coordinator.adbo.configuration.brand;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * This class will have configurations for the RBS repositories
 */
@Configuration
@EnableMongoRepositories(
    basePackages = {"com.rbs.pbbdhb.coordinator.adbo.brand.rbs.repositories"}, mongoTemplateRef = "rbsMongoTemplate"
)
public class RbsMongoConfig {

}
