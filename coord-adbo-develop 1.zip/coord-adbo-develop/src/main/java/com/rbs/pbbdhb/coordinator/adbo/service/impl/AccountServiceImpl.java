package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AccountService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;


@Service
public class AccountServiceImpl implements AccountService {

  @Override
  public Boolean getSecondChargeDetails(AccountSummaryResponse accountSummaryResponse) {
    //null or future dates are true
    if (accountSummaryResponse.getHoldCodes() != null && accountSummaryResponse.getHoldCodes().getHoldCode().containsKey("SCQC")) {
      LocalDate secondChargeHoldToDate = accountSummaryResponse.getSecondChargeHoldToDate();
      LocalDateTime sysDate = accountSummaryResponse.getSysDate();
      if (secondChargeHoldToDate != null && sysDate != null) {
        return secondChargeHoldToDate.isAfter(sysDate.toLocalDate());
      }
      return true;
    }
    return false;
  }

}
