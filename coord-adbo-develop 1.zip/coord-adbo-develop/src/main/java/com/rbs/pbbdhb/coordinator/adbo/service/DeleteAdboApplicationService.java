package com.rbs.pbbdhb.coordinator.adbo.service;

public interface DeleteAdboApplicationService {

    Long deleteAdboApplication(String accountNumber);
}
