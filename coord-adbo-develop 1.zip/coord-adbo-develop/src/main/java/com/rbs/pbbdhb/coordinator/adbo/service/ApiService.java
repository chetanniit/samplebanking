package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.dto.CaseDetailsDto;
import com.rbs.pbbdhb.coordinator.adbo.entity.Applicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.GetCustomerResponse;
import com.rbs.pbbdhb.coordinator.adbo.entity.PatchApplicant;
import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.GmsStatusResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.account.TrueBalanceResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.BankDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CoreCustomerSummaryResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerKycResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerVulnerableResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.MarketingPreference;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferences;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.UpdateMarketingPreferencesResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipResult;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchFinalResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISApplication;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISDocument;
import com.rbs.pbbdhb.coordinator.adbo.request.MonthlyAdditionalRepaymentCalculatorForTenure;
import com.rbs.pbbdhb.coordinator.adbo.response.MonthlyAdditionalMinMaxRepaymentVo;
import java.util.List;
import java.util.Optional;

/**
 * TODO Split to smaller parts to comply with Interface Segregation principle.
 */
public interface ApiService {

  AccountSummaryResponse getAccount(String accountNumber);

  TrueBalanceResponse getTrueBalance(String accountNumber);

  List<CoreCustomerSummaryResponse> getCustomers(String accountNumber);

  CustomerKycResponse getKycApi(String cin);

  CustomerVulnerableResponse getVulnerabilityApi(String cin);

  ApplicationStatusResponse getApplicationStatusApi(String accountNumber);

  MonthlyAdditionalMinMaxRepaymentVo getMonthlyAdditionalMinMaxRepayment(
      MonthlyAdditionalRepaymentCalculatorForTenure monthlyAdditionalRepaymentCalculatorForTenure);

  GetCustomerResponse getEmploymentDetails(String cin, String employmentDetails);

  List<BankDetails> getBankDetails(String accountNumber);

  ProductSearchFinalResponse getProductDetails(ProductSearchRequest productSearchRequest);

  ESISDocument getESISDocument(ESISApplication application);

  ESISDocument getESISDocument(String documentName);

  ApplicationType getApplicationType(String accountNumber);

  Optional<DipResult> performDip(DipApplication dipRequest);

  /**
   * Patch through Agreements And Disclaimers for joint applicant.
   *
   * @param applicantId              Primary input for marketingPreferences downstream endpoint
   * @param agreementsAndDisclaimers the patch object with operation to be performed, path and the values
   * @return Applicant
   **/
  Applicant patchAgreementsAndDisclaimers(String applicantId, List<PatchApplicant> agreementsAndDisclaimers);

  /**
   * Get Customer Marketing Preferences.
   *
   * @param referenceNumber Unique transaction identifier, currently passed accountNumber
   * @param customerId      Primary input for marketingPreferences downstream endpoint
   * @return MarketingPreferencesResponse
   **/
  List<MarketingPreference> getCustomerMarketingPreferences(String customerId, String referenceNumber);

  /**
   * Put Customer Marketing Preferences.
   *
   * @param updateMarketingPreferences Used to set marketing preferences
   * @param customerId                 Primary input for marketingPreferences downstream endpoint
   * @return MarketingPreferencesResponse
   **/
  UpdateMarketingPreferencesResponse updateCustomerMarketingPreferences(String customerId,
      UpdateMarketingPreferences updateMarketingPreferences);

  GmsStatusResponse getGmsApplicationStatus(String accountNumber, String mortSeqNumber);

  CaseDetailsDto getIsPaymentMadeFlag(String caseId);

  AdboSwitchRepaymentResponse getAdboSwitchMonthlyPayments(AdboSwitchRepaymentRequest request);

}
