package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;

public interface JourneyValidationDataMapper {

  AdboCaseDetails prepareCaseDetails(JourneyValidation journeyValidation, String accountNumber, String cin);
}
