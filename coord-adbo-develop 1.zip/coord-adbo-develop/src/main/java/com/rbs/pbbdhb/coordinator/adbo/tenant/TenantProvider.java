package com.rbs.pbbdhb.coordinator.adbo.tenant;

import org.springframework.stereotype.Component;

@Component
public class TenantProvider {

  private static final ThreadLocal<Brand> CONTEXT_HOLDER = new ThreadLocal<>();

  public static Brand getCurrentBrand() {
    Brand value = CONTEXT_HOLDER.get();
    if (value == null) {
      throw new IllegalStateException("You must set value before.");
    }
    return value;
  }

  public static Brand applyBrand(String brand) {
    return applyBrand(Brand.fromName(brand));
  }

  public static Brand applyBrand(Brand brand) {
    if (brand == null) {
      return null;
    }

    CONTEXT_HOLDER.set(brand);
    return brand;
  }

  public static void clearBrand() {
    CONTEXT_HOLDER.remove();
  }
}
