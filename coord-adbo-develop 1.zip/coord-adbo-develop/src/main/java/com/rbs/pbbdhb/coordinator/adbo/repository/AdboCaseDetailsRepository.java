package com.rbs.pbbdhb.coordinator.adbo.repository;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdboCaseDetailsRepository extends MongoRepository<AdboCaseDetails, String> {

  /**
   * Find the newest {@link AdboCaseDetails} for given accountNumber.
   *
   * @param accountNumber to link
   * @return loaded {@link AdboCaseDetails} if exists
   */
  Optional<AdboCaseDetails> findFirstByAccountNumberOrderByCreatedDateDesc(String accountNumber);

  Long deleteByAccountNumber(String accountNumber);
}
