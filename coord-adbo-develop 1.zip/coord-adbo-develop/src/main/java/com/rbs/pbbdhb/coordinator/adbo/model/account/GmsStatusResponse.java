package com.rbs.pbbdhb.coordinator.adbo.model.account;

import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GmsStatusResponse extends BaseResponse {

  private static final long serialVersionUID = -8693249033598776453L;

  private String stageNo;

}
