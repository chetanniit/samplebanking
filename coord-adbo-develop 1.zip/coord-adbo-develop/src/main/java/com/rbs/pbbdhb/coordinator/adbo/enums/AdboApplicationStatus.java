package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum AdboApplicationStatus {
    MINI_SUBMITTED, SUBMISSION_FAILED,  SUBMITTED
}
