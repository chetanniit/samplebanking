package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.response.DipResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;

@Tag(name = "12 - DIP-Decision In Principle", description = "Post a customer data to DIP API and Fetch DIP response from database")
public interface DipControllerSwagger {

  @Operation(description = "Construct DIP contract and post message to DIP API", operationId = "getDecisionInPrinciple", summary = "Post request to the DIP API, store and return the response", responses = {
      @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = DipResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<DipResponse> getDecisionInPrinciple(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);

  @Operation(description = "Fetch DIP API response from database", operationId = "getDecisionInPrincipleFromDB", summary = "Retrieve the DIP API Response from database ", responses = {
      @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = DipResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)})
  ResponseEntity<DipResponse> getDecisionInPrincipleFromDB(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);
}
