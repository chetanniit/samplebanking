package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.FAILED_DUE_TO_POWER_OF_ATTORNEY;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PowerOfAttorneyValidator extends HoldCodesValidator {

  protected PowerOfAttorneyValidator(@Value("${journeyValidator.priority.powerOfAttorney}") int priority) {
    super(priority, FAILED_DUE_TO_POWER_OF_ATTORNEY, "POA");
  }
}
