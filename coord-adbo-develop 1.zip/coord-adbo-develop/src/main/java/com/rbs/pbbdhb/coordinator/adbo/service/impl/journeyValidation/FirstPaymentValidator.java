package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.FAILED_DUE_TO_NO_PAYMENT_YET_MADE;

import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class FirstPaymentValidator extends AbstractValidator {

  public FirstPaymentValidator(@Value("${journeyValidator.priority.noFirstPayment}") int priority) {
    super(priority, FAILED_DUE_TO_NO_PAYMENT_YET_MADE);
  }

  @Override
  public boolean test(JourneyValidation validation) {
    return !validation.getAccountSummaryApiResponse().isFirstPaymentMade();
  }
}
