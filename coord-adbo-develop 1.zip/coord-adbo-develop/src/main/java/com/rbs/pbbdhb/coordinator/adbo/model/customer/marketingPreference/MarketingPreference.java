package com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketingPreference extends BaseResponse {

  private String customerType;
  private String customerId;
  private String sourceSystemName;
  private String sourceSystemInstance;
  private String brand;
  private String bankId;
  private String customerOwnedBy;
  private LawfulBasisMarker lawfulBasisMarker;
  private String lawfulBasisMarkerUpdatedTimestamp;
  private List<PermissionPreferenceRead> permissionPreference;
}

