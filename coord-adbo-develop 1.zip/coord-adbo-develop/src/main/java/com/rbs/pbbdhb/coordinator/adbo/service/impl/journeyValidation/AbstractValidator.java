package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import com.rbs.pbbdhb.coordinator.adbo.service.Validator;

public abstract class AbstractValidator implements Validator {

  private final int priority;
  private final ValidationRuleResultCode validationRuleResultCode;

  protected AbstractValidator(int priority, ValidationRuleResultCode validationRuleResultCode) {
    this.priority = priority;
    this.validationRuleResultCode = validationRuleResultCode;
  }

  @Override
  public final int getPriority() {
    return priority;
  }

  @Override
  public final ValidationRuleResultCode apply(JourneyValidation journeyValidation) {
    return validationRuleResultCode;
  }
}
