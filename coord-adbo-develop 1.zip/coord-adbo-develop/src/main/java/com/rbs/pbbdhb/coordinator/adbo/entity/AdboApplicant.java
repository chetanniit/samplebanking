package com.rbs.pbbdhb.coordinator.adbo.entity;

import com.rbs.pbbdhb.coordinator.adbo.annotations.CIN;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.Income;
import com.rbs.pbbdhb.coordinator.adbo.entity.personal.PersonalDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.Route;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import lombok.ToString;
import org.springframework.lang.Nullable;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class AdboApplicant  {

  @CIN
  private String cin;

  private Integer acctHolderPosition;

  private String applicantId;

  private PersonalDetails personalDetails;

  private Income income;

  private OutgoingPaymentsDetails outgoingPaymentsDetails;

  private Boolean isMarketingPreferenceUpdated;

  private Route route;

  @Nullable
  private AgreementsAndDisclaimers agreementsAndDisclaimers;

}

