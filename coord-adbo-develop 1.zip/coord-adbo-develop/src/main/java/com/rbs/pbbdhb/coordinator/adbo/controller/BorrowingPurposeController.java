/**
 *
 */
package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.BorrowingPurposeControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose.BorrowingPurposeRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose.BorrowingPurposeResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.BorrowingPurposeService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class BorrowingPurposeController implements BorrowingPurposeControllerSwagger {

  private final BorrowingPurposeService borrowingPurposeService;

  /**
   * This operation is used to save ABC Page  details and return
   * Borrowing purpose information
   */
  @Override
  @GetMapping(path = "/borrowingPurpose", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<BorrowingPurposeResponse> getBorrowingPurposeDetails(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getBorrowingPurposeDetails start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<BorrowingPurposeResponse> response = new ResponseEntity<>( borrowingPurposeService.getBorrowingPurpose(accountNumber), HttpStatus.OK);
    log.info("getBorrowingPurposeDetails end's with response {}, account_number: {}, brand:{}, channel: {} ", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  /**
   * This operation is used to save borrowing purpose details and return
   * personalDetails information criteria
   */
  @Override
  @PostMapping(path = "/borrowingPurpose", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveBorrowingPurpose(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @Parameter(description = "BorrowingPurposeRequest") @RequestBody @Valid BorrowingPurposeRequest borrowingPurposeRequest) {
    log.info("saveBorrowingPurpose start - Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    borrowingPurposeService.saveBorrowingPurpose(accountNumber, borrowingPurposeRequest.getBorrowingPurposeDetails());
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveBorrowingPurpose end's with response {}, account_number: {}, brand {}, channel: {}",response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

}
