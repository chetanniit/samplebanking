package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.FAILED_DUE_TO_HOLD_CODE_DECEASED_CASE;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class DeceasedFlagValidator extends HoldCodesValidator {

  protected DeceasedFlagValidator(@Value("${journeyValidator.priority.deceasedFlag}") int priority) {
    super(priority, FAILED_DUE_TO_HOLD_CODE_DECEASED_CASE, "DC");
  }
}
