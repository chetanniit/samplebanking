package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.LEND_INTO_YOUR_RETIREMENT;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.LTV_VALIDATION_FAILED;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.RETIREMENT_AGE_75_BACKEND;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.RETIREMENT_AGE_BACKEND_VALIDATION_FAILED;
import static java.util.Objects.nonNull;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails;
import com.rbs.pbbdhb.coordinator.adbo.service.AdboCalculatorValidator;
import com.rbs.pbbdhb.exception.BusinessException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Period;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class AdboCalculatorValidatorImpl implements AdboCalculatorValidator {

  public static final BigDecimal _100 = BigDecimal.valueOf(100);

  /**
   * Allowed lending years
   */
  @Value("${adbo.lending.years}")
  private int lendingYears;

  private static Integer getPreviousRetirementAge(AdditionalBorrowingCalculator additionalBorrowingCalculator,
      ApplicantType applicantType) {
    List<Integer> previousRetirementAgeList = additionalBorrowingCalculator.getRetirementAge();
    return CollectionUtils.isEmpty(previousRetirementAgeList) ? null : previousRetirementAgeList.get(applicantType.getIndex());
  }

  private static void clearPensionContribution(AdboApplicant adboApplicant) {
    OutgoingPaymentsDetails outgoingPaymentsDetails = adboApplicant.getOutgoingPaymentsDetails();
    if (outgoingPaymentsDetails != null) {
      outgoingPaymentsDetails.setMonthlyPensionContribution(null);
      outgoingPaymentsDetails.setJointApplicantMonthlyPensionContribution(null);
    }
  }

  private static Map<ApplicantType, Integer> getRetirementAgeMap(Set<ApplicantType> applicantTypes,
      BorrowingDetails borrowingDetails) {
    Map<ApplicantType, Integer> retirementAgeMap = new EnumMap<>(ApplicantType.class);
    retirementAgeMap.put(ApplicantType.MAIN, borrowingDetails.getRetirementAge());
    if (applicantTypes.contains(ApplicantType.JOINT1)) {
      Integer jointApplicantRetirementAge = borrowingDetails.getJointApplicantRetirementAge();
      if (jointApplicantRetirementAge == null) {
        throw new BusinessException("jointApplicantRetirementAge cannot be null", HttpStatus.BAD_REQUEST.value());
      }
      retirementAgeMap.put(ApplicantType.JOINT1, jointApplicantRetirementAge);
    }
    return retirementAgeMap;
  }

  @Override
  public void validateLoanToValue(String accountNumber, BorrowingDetails borrowingDetails, AdboCaseDetails adboCaseDetails) {
    BigDecimal estimatedPropertyValue = nonNull(borrowingDetails.getEstimatedPropertyValue())
        && borrowingDetails.getEstimatedPropertyValue().intValue() > 0 ? borrowingDetails.getEstimatedPropertyValue()
        : BigDecimal.valueOf(adboCaseDetails.getAdditionalBorrowingCalculator().getHpiValuation().intValue());
    BigDecimal calculatedLtv = adboCaseDetails.getAdditionalBorrowingCalculator().getTotalTrueBalance()
        .add(BigDecimal.valueOf(borrowingDetails.getBorrowingAmount()))
        .multiply(_100).divide(estimatedPropertyValue, 0, RoundingMode.CEILING);
    checkLoanToValueMatch(accountNumber, borrowingDetails.getLoanToValue(), calculatedLtv);
  }

  private void checkLoanToValueMatch(String accountNumber, Double frontEndLtv, BigDecimal backendCalculatedLtv) {
    if (!Objects.equals(frontEndLtv.intValue(), backendCalculatedLtv.intValue())) {
      log.error("LoanToValue didn't matched for the given accountNumber {}, frontend ltv {}, backend calculated ltv {}",
          accountNumber, frontEndLtv.intValue(), backendCalculatedLtv.intValue());
      throw new BusinessException(LTV_VALIDATION_FAILED, HttpStatus.BAD_REQUEST.value());
    }
  }

  @Override
  public Map<ApplicantType, Integer> prepareAndValidateRetirementAge(String accountNumber, BorrowingDetails borrowingDetails,
      AdboCaseDetails adboCaseDetails) {
    LocalDate currentDate = LocalDate.now();
    EnumMap<ApplicantType, AdboApplicant> adboApplicants = adboCaseDetails.getAdboApplicants();
    Map<ApplicantType, Integer> retirementAgeMap = getRetirementAgeMap(adboApplicants.keySet(), borrowingDetails);
    LocalDate repaymentTermDate = currentDate.plusYears(borrowingDetails.getRepaymentTermYears())
        .plusMonths(borrowingDetails.getRepaymentTermMonths());
    AdditionalBorrowingCalculator additionalBorrowingCalculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    adboApplicants.forEach((applicantType, adboApplicant) -> {
      LocalDate dateOfBirth = adboCaseDetails.getAdboApplicants().get(applicantType).getPersonalDetails().getDateOfBirth();
      Period currentAge = Period.between(dateOfBirth, currentDate);
      Integer retirementAge = retirementAgeMap.get(applicantType);
      LocalDate maxAllowedRepaymentDate = dateOfBirth.plusYears(lendingYears);
      if (maxAllowedRepaymentDate.isBefore(repaymentTermDate)) {
        throw new BusinessException(RETIREMENT_AGE_75_BACKEND, HttpStatus.BAD_REQUEST.value());
      }
      if (retirementAge <= currentAge.getYears()) {
        log.info("Retirement age validation matches with frontend validation for accountNumber {}", accountNumber);
      } else {
        log.info("Retirement age is greater than then current age for accountNumber {}", accountNumber);
        LocalDate retirementDate = dateOfBirth.plusYears(retirementAge);
        Period timeToRetirement = Period.between(currentDate, retirementDate);
        if (retirementDate.isBefore(repaymentTermDate)) {
          throw new BusinessException(LEND_INTO_YOUR_RETIREMENT, HttpStatus.BAD_REQUEST.value());
        }
        Integer previousRetirementAge = getPreviousRetirementAge(additionalBorrowingCalculator, applicantType);
        AtomicBoolean clearPensionContribution = new AtomicBoolean(
            previousRetirementAge != null && retirementAge > previousRetirementAge);
        additionalBorrowingCalculator.getSubAccountDetails().stream()
            .map(SubAccount::getTermEndDate)
            .min(LocalDate::compareTo).ifPresent(termEndDate -> {
              if (!retirementDate.isAfter(termEndDate)) {
                clearPensionContribution.set(false);
                log.info("Retirement age is lesser than the subAccount termEndDate for accountNumber {}", accountNumber);
                if (timeToRetirement.getYears() > 10) {
                  log.info("Customer retirement is {} years for accountNumber {}", retirementDate.getYear() - currentDate.getYear(),
                      accountNumber);
                } else {
                  log.error("Customer retirement is {} years for accountNumber {}", timeToRetirement.getYears(), accountNumber);
                  throw new BusinessException(RETIREMENT_AGE_BACKEND_VALIDATION_FAILED, HttpStatus.BAD_REQUEST.value());
                }
              } else {
                log.info("Retirement age is greater than the subAccount termEndDate for accountNumber {}", accountNumber);
              }
            });
        if (clearPensionContribution.get()) {
          clearPensionContribution(adboApplicant);
        }
      }
    });
    return retirementAgeMap;
  }

}
