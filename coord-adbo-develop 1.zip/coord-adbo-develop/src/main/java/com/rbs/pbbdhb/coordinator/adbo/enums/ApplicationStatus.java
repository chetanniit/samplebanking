package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum ApplicationStatus {
  L("L"), D("D"), R("R");

  String label;

  ApplicationStatus(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }
}
