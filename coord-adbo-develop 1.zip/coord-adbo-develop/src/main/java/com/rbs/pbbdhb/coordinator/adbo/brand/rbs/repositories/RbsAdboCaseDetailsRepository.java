package com.rbs.pbbdhb.coordinator.adbo.brand.rbs.repositories;

import com.rbs.pbbdhb.coordinator.adbo.repository.AdboCaseDetailsRepository;

/**
 * This class is used to create repository for NWB
 */
public interface RbsAdboCaseDetailsRepository extends AdboCaseDetailsRepository {

}
