package com.rbs.pbbdhb.coordinator.adbo.dao.impl;

import com.rbs.pbbdhb.coordinator.adbo.dao.impl.AdboCaseDetailsDaoImpl.DetailsFilter;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;

/**
 * Abstract class to help configure error data for {@link DetailsFilter} implementations.
 */
public abstract class AbstractDetailsFilter implements DetailsFilter {

  private final int errorCode;

  private final String errorMessageKey;

  public AbstractDetailsFilter(HttpStatusCode errorCode, String errorMessageKey) {
    this.errorCode = errorCode.value();
    this.errorMessageKey = errorMessageKey;
  }

  @Override
  public final int errorCode() {
    return errorCode;
  }

  @Override
  public final String errorMessageKey() {
    return errorMessageKey;
  }
}
