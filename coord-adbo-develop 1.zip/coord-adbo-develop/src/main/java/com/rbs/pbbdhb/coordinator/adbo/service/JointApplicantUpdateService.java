package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.JointApplicantEmailUpdateRequest;
import com.rbs.pbbdhb.coordinator.adbo.request.JointApplicantMobileUpdateRequest;

public interface JointApplicantUpdateService {

  void updateEmail(String accountNumber, JointApplicantEmailUpdateRequest jointApplicantEmailUpdateRequest);

  void updateMobileNumber(String accountNumber, JointApplicantMobileUpdateRequest jointApplicantMobileUpdateRequest);

}
