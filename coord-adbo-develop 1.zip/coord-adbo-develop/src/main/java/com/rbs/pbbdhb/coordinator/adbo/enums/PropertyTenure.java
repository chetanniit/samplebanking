package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum PropertyTenure {

  FREEHOLD, LEASEHOLD, FEUHOLD;

  public static PropertyTenure getByCode(String propertyTenureCode) {

    switch (propertyTenureCode) {
      case "1":
        return PropertyTenure.FREEHOLD;
      case "2":
        return PropertyTenure.LEASEHOLD;
      case "6":
        return PropertyTenure.FEUHOLD;
    }
    return null;
  }

}