package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingSubmitRequest;

public interface AdditionalBorrowingSubmitService {

  Product getSelectedProduct(String accountNumber);

  void saveAdditionalBorrowingSubmit(String accountNumber, AdditionalBorrowingSubmitRequest additionalBorrowingSubmitRequest);

}
