package com.rbs.pbbdhb.coordinator.adbo.configuration.brand;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * This class will have configurations for the NWB repositories
 */
@Configuration
@EnableMongoRepositories(
    basePackages = {"com.rbs.pbbdhb.coordinator.adbo.brand.nwb.repositories"}, mongoTemplateRef = "natwestMongoTemplate"
)
public class NwbMongoConfig {

}
