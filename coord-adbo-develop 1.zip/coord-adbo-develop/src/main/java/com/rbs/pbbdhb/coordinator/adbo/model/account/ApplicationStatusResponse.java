package com.rbs.pbbdhb.coordinator.adbo.model.account;

import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationStatusResponse extends BaseResponse {

  /**
   *
   */
  private static final long serialVersionUID = -979052161643973523L;

  private String appStatus;

  private String applicationSequenceNumber;

}

