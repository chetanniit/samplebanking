package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum LoanPurpose {

  ADDITIONAL_BORROWING

}
