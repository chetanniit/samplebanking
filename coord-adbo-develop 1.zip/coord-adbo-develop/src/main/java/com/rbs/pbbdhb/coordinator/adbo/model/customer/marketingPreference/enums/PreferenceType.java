package com.rbs.pbbdhb.coordinator.adbo.model.customer.marketingPreference.enums;

public enum PreferenceType {
  EMAIL_MARKETING,
  PHONE_MARKETING,
  MAIL_MARKETING
}
