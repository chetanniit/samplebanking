package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingWithSwitchRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AdditionalBorrowingWithSwitchResponse;

public interface AdditionalBorrowingWithSwitchService {

 void saveAdditionalBorrowingWithSwitch(String accountNumber, String brand , AdditionalBorrowingWithSwitchRequest additionalBorrowingWithSwitchRequest);

  AdditionalBorrowingWithSwitchResponse getAdditionalBorrowingWithSwitch(String accountNumber,String brand);
}
