package com.rbs.pbbdhb.coordinator.adbo.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@ToString
@EqualsAndHashCode
public class JointApplicantMobileUpdateRequest  {

  @Pattern(regexp = "^(0[^7]\\d{9,13})|(07\\d{9})$", message = "Wrong mobileNumber format")
  @NotNull(message = "mobileNumber must not be null")
  private String mobileNumber;
}
