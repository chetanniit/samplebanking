package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;

public enum EmploymentType {
  EMPLOYED,
  SELF_EMPLOYED;

  public String getLabel() {
    return this.name();
  }


}
