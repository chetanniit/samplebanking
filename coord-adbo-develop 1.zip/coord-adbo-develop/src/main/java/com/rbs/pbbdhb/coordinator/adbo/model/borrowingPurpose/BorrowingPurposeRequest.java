package com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotEmpty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class BorrowingPurposeRequest {

  @NotEmpty(message = "Customer has to choose at least one borrowing purpose")
  private @Valid List<AdboAmountDistribution> borrowingPurposeDetails;

  @AssertTrue(message = "Borrowing purposes need to be of unique types")
  private boolean isBorrowingPurposeTypesUnique() {
    return borrowingPurposeDetails == null
        || borrowingPurposeDetails.stream()
        .map(AdboAmountDistribution::getType)
        .distinct().count() == borrowingPurposeDetails.size();
  }

}