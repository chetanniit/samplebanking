package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static java.util.Arrays.asList;
import static org.apache.commons.lang3.BooleanUtils.isNotTrue;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.dto.SelectedSubAccountDto;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.SubAccountType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.request.AdditionalBorrowingWithSwitchRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AdditionalBorrowingWithSwitchResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AdditionalBorrowingWithSwitchService;
import com.rbs.pbbdhb.coordinator.adbo.util.SubAccountsSelectionForSwitching;
import com.rbs.pbbdhb.exception.BusinessException;
import java.time.LocalDate;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service
public class AdditionalBorrowingWithSwitchServiceImpl implements
    AdditionalBorrowingWithSwitchService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;

  @Override
  public void saveAdditionalBorrowingWithSwitch(String accountNumber, String brand,
      AdditionalBorrowingWithSwitchRequest additionalBorrowingWithSwitchRequest) {
    log.info("saveAdditionalBorrowingWithSwitch is started for brand {}, account_number: {}", brand, accountNumber);
    try {
      AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
      additionalBorrowingWithSwitchRequest.getSelectedSubAccountsForSwitch().forEach(selectedSubAccountDto -> {
        if (isValidRequest(adboCaseDetails, selectedSubAccountDto)) {
          throw new BusinessException("Bad Request- Sub account is not eligible for switch, But selected for switch",
              HttpStatus.BAD_REQUEST.value());
        }
      });
      adboCaseDetails.setAdditionalBorrowingWithSwitch(additionalBorrowingWithSwitchRequest.getAdditionalBorrowingWithSwitch());
      if (isNotTrue(additionalBorrowingWithSwitchRequest.getAdditionalBorrowingWithSwitch())) {
        log.info("Customer has not selected additionalBorrowingWithSwitch for account_number: {}", accountNumber);
        adboCaseDetails.resetSwitchDetails();
        adboCaseDetailsDao.save(adboCaseDetails);
        return;
      }
      adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails() .forEach(subAccount -> subAccount.setSelectedForSwitch(null));
      additionalBorrowingWithSwitchRequest.getSelectedSubAccountsForSwitch()
          .forEach(selectedSubAccountDto -> adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream()
              .filter(subAccount -> Objects.equals(selectedSubAccountDto.getSubAccountNumber(), subAccount.getSubAccountNumber()))
              .forEach(subAccount -> subAccount.setSelectedForSwitch(Boolean.TRUE)));
      setCohortDate(adboCaseDetails);
      adboCaseDetailsDao.save(adboCaseDetails);
    } catch (Exception exception) {
      log.error("Exception occurred while updating the eligible sub accounts for switch. brand {}, account_number: {}, exception {}", brand,
          accountNumber, exception);
      throw new BusinessException("Exception occurred while updating the eligible sub accounts for switch", exception);
    }
    log.info("saveAdditionalBorrowingWithSwitch is end for brand {}, account_number: {}", brand, accountNumber);
  }

  private boolean isValidRequest(AdboCaseDetails adboCaseDetails, SelectedSubAccountDto selectedSubAccountDto) {
    return adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream().anyMatch(
        subAccount -> Objects.equals(selectedSubAccountDto.getSubAccountNumber(), subAccount.getSubAccountNumber()) && isNotTrue(
            subAccount.getEligibleToSwitch()));
  }

  private void setCohortDate(AdboCaseDetails adboCaseDetails) {

    adboCaseDetails.getAdditionalBorrowingCalculator().setCohortDate(null);
    SubAccountsSelectionForSwitching
        .selectedSubAccountsForSwitching(adboCaseDetails)
        .stream()
        .filter(subAccount -> asList(SubAccountType.TRACKER_ROLLOFF, SubAccountType.FIXED_RATE_ROLLOFF)
            .contains(subAccount.getSubAccountType()))
        .map(SubAccount::getCurrentDealEnds)
        .filter(Objects::nonNull)
        .min(LocalDate::compareTo)
        .ifPresent(cohortDate -> adboCaseDetails.getAdditionalBorrowingCalculator().setCohortDate(cohortDate));
  }

  @Override
  public AdditionalBorrowingWithSwitchResponse getAdditionalBorrowingWithSwitch(String accountNumber, String brand) {
    log.info("getAdditionalBorrowingWithSwitch is started for brand {}, account_number: {}", brand, accountNumber);
    try {
      AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
      log.info("Customer is eligible to switch : {},account_number: {}", adboCaseDetails.getEligibleToSwitch(), accountNumber);
      AdditionalBorrowingWithSwitchResponse response = AdditionalBorrowingWithSwitchResponse.builder()
          .additionalBorrowingWithSwitch(adboCaseDetails.getAdditionalBorrowingWithSwitch())
          .subAccounts(adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails())
          .eligibleToSwitch(adboCaseDetails.getEligibleToSwitch())
          .build();
      log.info("getAdditionalBorrowingWithSwitch is end for brand {}, account_number: {}", brand, accountNumber);
      return response;
    } catch (Exception exception) {
      log.error("Exception occurred while existing switched sub accounts. brand {}, account_number: {}, exception {}", brand, accountNumber,
          exception);
      throw new BusinessException("Exception occurred while retrieving existing switched sub accounts", exception);
    }
  }
}
