package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.customer.CustomerKycResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class KycMarkerValidator extends AbstractValidator {

  public KycMarkerValidator(@Value("${journeyValidator.priority.kyc}") int priority) {
    super(priority, ValidationRuleResultCode.FAILED_DUE_TO_MARKER_KYC);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return !journeyValidation.getCustomerKycResponses().stream()
        .allMatch(CustomerKycResponse::isKycVerified);
  }

  @Override
  public List<String> getFailingCins(JourneyValidation journeyValidation) {
    return journeyValidation.getCustomerKycResponses().stream()
        .filter(CustomerKycResponse::isKycVerified)
        .map(CustomerKycResponse::getCin)
        .collect(Collectors.toList());
  }
}
