package com.rbs.pbbdhb.coordinator.adbo.util;

import static com.rbs.pbbdhb.coordinator.adbo.enums.InterestType.FIXED;
import static com.rbs.pbbdhb.coordinator.adbo.enums.InterestType.TRACKER;
import static com.rbs.pbbdhb.coordinator.adbo.enums.InterestType.VARIABLE;
import static java.time.temporal.ChronoUnit.DAYS;
import static java.util.Objects.nonNull;

import com.rbs.pbbdhb.coordinator.adbo.enums.InterestType;
import com.rbs.pbbdhb.coordinator.adbo.enums.SubAccountType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EligibleToSwitchCheckAndSetForSubAccount {

    @Value("${eligibleToSwitch.minRemainingTermsInMonths}")
    private int minRemainingTermsInMonths;

    @Value("${eligibleToSwitch.fixed.noOfDaysBetweenDealEndAndIncep}")
    private int noOfDaysBetweenDealEndAndIncep;

    @Value("${eligibleToSwitch.newRuleApplicableDate}")
    private LocalDate newRuleApplicableDate;
    @Value("${eligibleToSwitch.rollOffSwitchingWindowInMonths}")
    private int rollOffSwitchingWindow;

    public void updateSubAccounts(JourneyValidation journeyValidation) {
        log.info(
                "updateSubAccounts is started for to set the EligibleToSwitch flag as True/False for the all eligible sub accounts");
        List<SubAccount> subAccounts = journeyValidation.getAccountSummaryApiResponse().getSubAccounts();
        for (SubAccount subAccount : subAccounts) {
            if (fixedEligibleToSwitch(subAccount, journeyValidation.getAccountSummaryApiResponse().getSysDate())
                    || trackerEligibleToSwitch(subAccount, journeyValidation.getAccountSummaryApiResponse().getSysDate())
                    || trackerRollOffEligibleToSwitch(subAccount, journeyValidation.getAccountSummaryApiResponse().getSysDate())
                    || standardEligibleToSwitch(subAccount)) {
                subAccount.setEligibleToSwitch(Boolean.TRUE);
            }
            subAccount.setSubAccountType(getSubAccountType(subAccount, journeyValidation.getAccountSummaryApiResponse().getSysDate()));
        }
    }

    private SubAccountType getSubAccountType(SubAccount subAccount, LocalDateTime sysDate) {
        return switch (InterestType.fromValue(subAccount.getInterestType())) {
            case VARIABLE -> SubAccountType.VARIABLE;
            case FIXED ->
                    nonNull(subAccount.getCurrentDealEnds()) && isSubAccountWithinRollOffWindow(subAccount, sysDate)
                            ? SubAccountType.FIXED_RATE_ROLLOFF : SubAccountType.FIXED_RATE;
            case TRACKER ->
                    nonNull(subAccount.getCurrentDealEnds()) && isSubAccountWithinRollOffWindow(subAccount, sysDate)
                            ? SubAccountType.TRACKER_ROLLOFF : SubAccountType.TRACKER;
        };
    }

    private boolean isSubAccountRemainingTermGreaterThan27Months(final SubAccount subAccount) {
        return (subAccount.getRemainingTerm().getYears() * 12) + subAccount.getRemainingTerm().getMonths() >= minRemainingTermsInMonths;
    }

    private LocalDate getRollOffDate(@NonNull final LocalDate baseDate) {
        return baseDate.minusMonths(rollOffSwitchingWindow - 1L).withDayOfMonth(1);
    }

    public boolean isWithinRollOffDate(LocalDate sysDate, LocalDate currentDealEndDate) {
        LocalDate rollOffDate = getRollOffDate(currentDealEndDate);
        return ((sysDate.equals(rollOffDate) || sysDate.isAfter(rollOffDate)) &&
                (sysDate.equals(currentDealEndDate) || sysDate.isBefore(currentDealEndDate)));
    }

    private boolean isSubAccountWithinRollOffWindow(final SubAccount subAccount, LocalDateTime sysDate) {
        return subAccount.getCurrentDealEnds().isAfter(newRuleApplicableDate) ? isWithinRollOffDate(sysDate.toLocalDate(), subAccount.getCurrentDealEnds()) : DAYS.between(sysDate.toLocalDate(), subAccount.getCurrentDealEnds()) <= noOfDaysBetweenDealEndAndIncep;
    }

    public boolean fixedEligibleToSwitch(SubAccount subAccount, final LocalDateTime sysDate) {
        return FIXED.getInterestType().equals(subAccount.getInterestType()) && isSubAccountRemainingTermGreaterThan27Months(subAccount) && isSubAccountWithinRollOffWindow(subAccount, sysDate);
    }

    public boolean trackerEligibleToSwitch(SubAccount subAccount, final LocalDateTime sysDate) {
        return trackerInitialEligibilityCheck(subAccount) && ! isSubAccountWithinRollOffWindow(subAccount, sysDate);
    }

    public boolean trackerRollOffEligibleToSwitch(SubAccount subAccount, final LocalDateTime sysDate) {
        return trackerInitialEligibilityCheck(subAccount) && isSubAccountWithinRollOffWindow(subAccount, sysDate);
    }

    public boolean trackerInitialEligibilityCheck(SubAccount subAccount) {
        return TRACKER.getInterestType().equals(subAccount.getInterestType()) && subAccount.getCurrentDealEnds() != null
                && isSubAccountRemainingTermGreaterThan27Months(subAccount);
    }


    public boolean standardEligibleToSwitch(SubAccount subAccount) {
        return VARIABLE.getInterestType().equals(subAccount.getInterestType()) && subAccount.getMappedProdType() != null && isSubAccountRemainingTermGreaterThan27Months(subAccount);
    }
}
