package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose.BorrowingPurposeResponse;
import java.util.List;

public interface BorrowingPurposeService {

  void saveBorrowingPurpose(String accountNumber, List<AdboAmountDistribution> borrowingPurposeRequest);

  BorrowingPurposeResponse getBorrowingPurpose(final String accountNumber);

}
