package com.rbs.pbbdhb.coordinator.adbo.util;

import static com.rbs.pbbdhb.coordinator.adbo.enums.BonusType.GUARANTEED;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum.LIVING_WITH_RELATIVES;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum.OTHER;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum.OWNER_MORTGAGED;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum.OWNER_NO_MORTGAGE;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum.TENANT;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_DISCRETIONARY_PAID_ANNUALLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_DISCRETIONARY_PAID_BI_ANNUALLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_DISCRETIONARY_PAID_MONTHLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_DISCRETIONARY_PAID_QUARTERLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_GUARANTEED_PAID_ANNUALLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_GUARANTEED_PAID_BI_ANNUALLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_GUARANTEED_PAID_MONTHLY;
import static com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum.BONUS_GUARANTEED_PAID_QUARTERLY;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.AdditionalIncomeSources;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.BenefitType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.EmployedBasis;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Industry;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.Occupation;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.OtherIncomeSource;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.PensionType;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.SelfEmployedBasis;
import com.rbs.pbbdhb.coordinator.adbo.enums.BonusType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ChildCareExpenseType;
import com.rbs.pbbdhb.coordinator.adbo.enums.FixedCommitmentType;
import com.rbs.pbbdhb.coordinator.adbo.enums.FrequencyType;
import com.rbs.pbbdhb.coordinator.adbo.enums.LoanType;
import com.rbs.pbbdhb.coordinator.adbo.enums.OccupancyStatus;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipAddress.OccupancyStatusEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment.EmploymentTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment.IndustryTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipEmployment.OccupationCodeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipFinancialCommitment.DipFinancialCommitmentTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.FrequencyEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipIncome.TypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipLoan.DipLoanTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.BenefitTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipOtherIncome.OtherIncomeFrequencyEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipProperty.DipPropertyTypeEnum;
import com.rbs.pbbdhb.coordinator.adbo.model.dip.DipSelfEmployed.BusinessTypeEnum;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EnumsMappingUtil {

  public static OccupationCodeEnum getDipOccupationCode(Occupation occupation) {
    switch (occupation) {
      case ARTS:
      case LAW:
      case MATHS:
      case NURSING:
      case SCIENCES:
      case SOCIAL_STUDIES:
      case ARCHITECT_BUILDING_AND_PLANNING:
      case PROFESSIONALS:
      case SEMI_PROFESSIONALS:
      case BUSINESS_AND_ADMINISTRATION:
      case ENGINEERING:
      case LANGUAGES:
      case HUMANITIES:
      case MEDICAL_AND_RELATED:
        return OccupationCodeEnum.PROFESSIONALS;
      case TEACHER:
        return OccupationCodeEnum.TEACHERS;
      case AGRICULTURAL_WORKER:
        return OccupationCodeEnum.AGRICULTURAL_WORKERS_GENERAL;
      case FARM_OWNER_AND_MANAGER:
        return OccupationCodeEnum.FARM_MANAGEMENT_GENERAL;
      case HM_FORCES_OFFICER:
        return OccupationCodeEnum.HM_FORCES_OFFICERS;
      case HM_FORCES_OTHER_RANK:
        return OccupationCodeEnum.HM_FORCES_OTHER_RANKS;
      case JUNIOR_MANAGER:
        return OccupationCodeEnum.JUNIOR_MANAGEMENT;
      case SEMI_SKILLED_MANUAL:
        return OccupationCodeEnum.SEMI_SKILLED;
      case SENIOR_MANAGER:
        return OccupationCodeEnum.SENIOR_MANAGEMENT;
      case TECHNICIAN:
        return OccupationCodeEnum.TECHNICIANS;
      case SERVICE_INDUSTRY_EMPLOYEE:
        return OccupationCodeEnum.SERVICE_JOBS;
      case SUPERVISOR:
        return OccupationCodeEnum.SUPERVISORY_FOREMAN;
      case ACADEMIC_STAFF:
        return OccupationCodeEnum.ACADEMIC_STAFF;
      case OFFICE_AND_CLERICAL:
        return OccupationCodeEnum.OFFICE_AND_CLERICAL;
      case SALES:
        return OccupationCodeEnum.SALES;
      case SKILLED_MANUAL:
        return OccupationCodeEnum.SKILLED_MANUAL;
      case UNSKILLED_MANUAL:
        return OccupationCodeEnum.MANUAL;
      default:
        log.error("Unsupported occupation type provided, occupation {}", occupation);
        return null;
    }
  }

  public static IndustryTypeEnum getDipIndustryCode(Industry industry) {
    switch (industry) {
      case AGRICULTURE_AND_FORESTRY:
        return IndustryTypeEnum.AGRICULTURE_HUNTING_FORESTRY;
      case FISHING:
        return IndustryTypeEnum.FISHING;
      case MINING_AND_QUARRYING:
        return IndustryTypeEnum.MINING_AND_QUARRYING;
      case MANUFACTURING:
        return IndustryTypeEnum.MANUFACTURING;
      case ELECTRICITY_GAS_AND_WATER_SUPPLY:
        return IndustryTypeEnum.ELECTRICITY_GAS_WATER_SUPPLY;
      case CONSTRUCTION:
        return IndustryTypeEnum.CONSTRUCTION;
      case WHOLESALE_RETAIL_AND_REPAIR:
        return IndustryTypeEnum.WHOLESALE_RETAIL_AND_REPAIR;
      case HOTELS_AND_RESTAURANTS:
        return IndustryTypeEnum.HOTELS_AND_RESTAURANTS;
      case TRANSPORT_STORAGE_AND_COMMERCIAL:
        return IndustryTypeEnum.TRANSPORT_STORAGE_COMM;
      case FINANCE_AND_BANKING:
        return IndustryTypeEnum.FINANCIAL_INTERMEDIATION;
      case PROPERTY_AND_BUSINESS:
        return IndustryTypeEnum.PROPERTY_AND_BUSINESS;
      case PUBLIC_ADMIN_AND_DEFENCE:
        return IndustryTypeEnum.PUBLIC_ADMIN_AND_DEFENCE;
      case EDUCATION:
        return IndustryTypeEnum.EDUCATION;
      case HEALTH_AND_SOCIAL_WORK:
        return IndustryTypeEnum.HEALTH_AND_SOCIAL_WORK;
      case OFFICE_WORK_AND_ADMINISTRATION:
        return IndustryTypeEnum.OFFICE_WORK_AND_ADMINISTRATION;
      case OTHER:
        return IndustryTypeEnum.OTHER;
      default:
        log.error("Unsupported industry type provided, industry type {}", industry);
        return null;
    }
  }

  public static FrequencyEnum getDipFrequencyEnum(FrequencyType frequencyType) {
    switch (frequencyType) {
      case ANNUALLY:
        return FrequencyEnum.ANNUALLY;
      case QUARTERLY:
        return FrequencyEnum.QUARTERLY;
      case MONTHLY:
        return FrequencyEnum.MONTHLY;
      case WEEKLY:
        return FrequencyEnum.WEEKLY;
      case FORTNIGHTLY:
        return FrequencyEnum.FORTNIGHTLY;
      case FOUR_WEEKLY:
        return FrequencyEnum.FOUR_WEEKLY;
      case SIX_MONTHLY:
        return FrequencyEnum.BIANNUALLY;
      default:
        log.error("Unsupported frequency type provided, frequency type {}", frequencyType);
        return null;
    }
  }

  public static TypeEnum getIncomeTypeEnum(AdditionalIncomeSources additionalIncomeSources, FrequencyType frequencyType,
      BonusType bonusType) {
    switch (additionalIncomeSources) {
      case BONUS:
        switch (frequencyType) {
          case ANNUALLY:
            return bonusType == GUARANTEED ? BONUS_GUARANTEED_PAID_ANNUALLY : BONUS_DISCRETIONARY_PAID_ANNUALLY;
          case MONTHLY:
            return bonusType == GUARANTEED ? BONUS_GUARANTEED_PAID_MONTHLY : BONUS_DISCRETIONARY_PAID_MONTHLY;
          case QUARTERLY:
            return bonusType == GUARANTEED ? BONUS_GUARANTEED_PAID_QUARTERLY : BONUS_DISCRETIONARY_PAID_QUARTERLY;
          case SIX_MONTHLY:
            return bonusType == GUARANTEED ? BONUS_GUARANTEED_PAID_BI_ANNUALLY : BONUS_DISCRETIONARY_PAID_BI_ANNUALLY;
          default:
            return BONUS_GUARANTEED_PAID_ANNUALLY;
        }
      case OVERTIME:
        return TypeEnum.OVERTIME_GUARANTEED;
      case CAR_ALLOWANCE:
        return TypeEnum.CAR_ALLOWANCE;
      case COMMISSION:
        return TypeEnum.COMMISSION_GUARANTEED;
      case SHIFT_ALLOWANCE:
        return TypeEnum.SHIFT_ALLOWANCE_GUARANTEED;
      default:
        log.error("Unsupported income type provided, additionalIncomeSource {}", additionalIncomeSources);
        return null;
    }
  }

  public static BusinessTypeEnum selfEmployedBusinessTypeMap(SelfEmployedBasis selfEmployedBasis) {
    switch (selfEmployedBasis) {
      case SOLE_TRADER:
        return BusinessTypeEnum.SOLE_TRADER;
      case LIMITED_COMPANY:
        return BusinessTypeEnum.LIMITED_COMPANY;
      case PARTNERSHIP:
        return BusinessTypeEnum.PARTNERSHIP;
      default:
        log.error("Unsupported self employed type provided, selfEmployedBasis {}", selfEmployedBasis);
        return null;
    }

  }

  public static OtherIncomeFrequencyEnum otherIncomeFrequencyTypeToDipOtherIncomeFrequencyTypeMap(FrequencyType frequencyType) {
    switch (frequencyType) {
      case ANNUALLY:
        return OtherIncomeFrequencyEnum.ANNUALLY;
      case QUARTERLY:
        return OtherIncomeFrequencyEnum.QUARTERLY;
      case MONTHLY:
        return OtherIncomeFrequencyEnum.MONTHLY;
      case FORTNIGHTLY:
        return OtherIncomeFrequencyEnum.FORTNIGHTLY;
      case FOUR_WEEKLY:
        return OtherIncomeFrequencyEnum.FOUR_WEEKLY;
      case WEEKLY:
        return OtherIncomeFrequencyEnum.WEEKLY;
      case SIX_MONTHLY:
        return OtherIncomeFrequencyEnum.BIANNUALLY;
      default:
        log.error("Unsupported other income frequency type provided, income frequency type {}", frequencyType);
        return null;
    }

  }

  public static BenefitTypeEnum otherIncomeSourceMap(OtherIncomeSource otherIncomeSource, BenefitType benefitType) {
    switch (otherIncomeSource) {
      case BENEFITS:
        switch (benefitType) {
          case ADOPTION_ALLOWANCE:
          case ATTENDANCE_ALLOWANCE:
          case CONSTANT_ATTENDANCE_ALLOWANCE:
          case EMPLOYMENT_AND_SUPPORT_ALLOWANCE:
          case FOSTER_CARERS_ALLOWANCE:
          case GUARDIANS_ALLOWANCE:
          case INCOME_SUPPORT:
          case INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT:
          case PENSION_CREDIT:
          case REDUCED_EARNINGS_ALLOWANCE:
          case WIDOWED_PARENT_ALLOWANCE:
          case WAR_WIDOW_PENSION:
            return BenefitTypeEnum.OTHER_NON_TAXABLE;
          case CHILD_BENEFIT:
            return BenefitTypeEnum.CHILD_BENEFIT;
          case CARERS_ALLOWANCE:
            return BenefitTypeEnum.CARERS_ALLOWANCE;
          case DISABILITY_LIVING_ALLOWANCE:
            return BenefitTypeEnum.DISABLEMENT_LIVING_ALLOWANCE;
          case PERSONAL_INDEPENDENCE_PAYMENT:
            return BenefitTypeEnum.PERSONAL_INDEPENDENT_INCOME;
          case UNIVERSAL_CREDIT:
            return BenefitTypeEnum.UNIVERSAL_CREDIT;
          case CHILD_WORKING_TAX_CREDIT:
            return BenefitTypeEnum.WORKING_FAMILIES_TAX_CREDIT;
          default:
            log.error("Unsupported other income benefit type provided, benefitType {}", benefitType);
            return null;
        }
      case TRUST:
        return BenefitTypeEnum.TRUST;
      case MAINTENANCE:
        return BenefitTypeEnum.MAINTENANCE;
      case STATE_PENSION:
        return BenefitTypeEnum.PENSION_STATE;
      case PRIVATE_PENSION:
        return BenefitTypeEnum.PENSION_PRIVATE_OR_EMPLOYERS;
      case INVESTMENT_INCOME:
        return BenefitTypeEnum.INVESTMENT_INCOME;
      default:
        log.error("Unsupported other income source type provided, otherIncomeSource {}", otherIncomeSource);
        return null;
    }
  }

  public static DipLoanTypeEnum loanTypeToDipLoanTypeMap(LoanType loanType) {
    switch (loanType) {
      case CAR_FINANCE:
        return DipLoanTypeEnum.HIRE_PURCHASE;
      case PERSONAL_LOAN:
        return DipLoanTypeEnum.UNSECURED_LOAN;
      case SECURED_LOAN:
        return DipLoanTypeEnum.SECURED_LOAN;
      case STUDENT_LOAN:
        return DipLoanTypeEnum.STUDENT_LOAN;
      default:
        log.error("Unsupported loan type provided, loanType {}", loanType);
        return null;
    }
  }

  public static DipFinancialCommitmentTypeEnum financialCommitmentTypeToDipFinancialCommitmentTypeMap(
      FixedCommitmentType fixedCommitmentType) {
    switch (fixedCommitmentType) {
      case CAREER_RELATED_SUBSCRIPTION_OR_QUALIFICATIONS:
      case OTHER:
        return DipFinancialCommitmentTypeEnum.OTHER_COMMITTED_EXPENDITURE;
      case CHILD_MAINTENANCE:
        return DipFinancialCommitmentTypeEnum.CHILD_SUPPORT;
      case GROUND_RENT_OR_SERVICE_CHARGE:
        return DipFinancialCommitmentTypeEnum.GROUND_RENT;
      case SCHOOL_OR_EDUCATION_FEES:
        return DipFinancialCommitmentTypeEnum.SCHOOL_FEES;
      default:
        log.error("Unsupported financial commitment type provided, fixedCommitmentType {}", fixedCommitmentType);
        return null;
    }
  }

  public static DipFinancialCommitmentTypeEnum childCareExpenseToDipFinancialCommitmentTypeMap(
      ChildCareExpenseType childCareExpenseType) {
    switch (childCareExpenseType) {
      case CHILD_MINDER:
      case AU_PAIR:
      case HOLIDAY_CLUBS:
      case BREAKFAST_AFTER_SCHOOL_CLUBS:
      case DAILY_NANNY:
      case OTHER:
      case PLAY_GROUP_OR_PRE_SCHOOL:
      case LIVE_IN_NANNY:
      case NURSERY:
        return DipFinancialCommitmentTypeEnum.CHILD_CARE_COSTS;
      default:
        log.error("unsupported childcare type provided , childCareExpenseType {}", childCareExpenseType);
        return null;
    }
  }

  public static BenefitTypeEnum pensionTypeToDipPensionTypeMap(PensionType pensionType) {
    switch (pensionType) {
      case PRIVATE_PENSION:
        return BenefitTypeEnum.PENSION_PRIVATE_OR_EMPLOYERS;
      case STATE_PENSION:
        return BenefitTypeEnum.PENSION_STATE;
      case NONE:
        return BenefitTypeEnum.OTHER_NON_TAXABLE;
      default:
        log.error("Unsupported pension type provided, pensionType {}", pensionType);
        return null;
    }
  }

  public static EmploymentTypeEnum getEmploymentTypeMap(EmployedBasis employedBasis) {
    switch (employedBasis) {
      case PERMANENT:
        return EmploymentTypeEnum.PERMANENT;
      case CONTRACTOR:
        return EmploymentTypeEnum.CONTRACT;
      case TEMPORARY:
        return EmploymentTypeEnum.TEMPORARY;
      default:
        return EmploymentTypeEnum.OTHER;
    }
  }

  public static OccupancyStatusEnum occupancyStatusToDipOccupancyStatusEnum(OccupancyStatus occupancyStatus) {
    switch (occupancyStatus) {
      case LIVING_WITH_FAMILY:
      case LIVING_WITH_FRIENDS:
      case LIVING_WITH_PARTNER:
        return LIVING_WITH_RELATIVES;
      case OWNER_MORTGAGED:
        return OWNER_MORTGAGED;
      case OWNER_NO_MORTGAGE:
        return OWNER_NO_MORTGAGE;
      case TENANT:
        return TENANT;
      default:
        return OTHER;
    }
  }

  public static DipPropertyTypeEnum propertyGmsBuildTypeToDipPropertyTypeEnum(String propertyGmsBuildType) {
    switch (propertyGmsBuildType) {
      case "BUNGALOW_DETACHED":
        return DipPropertyTypeEnum.BUNGALOW_DETACHED;
      case "BUNGALOW_NEW_BUILD":
        return DipPropertyTypeEnum.BUNGALOW_NEW_BUILD;
      case "HOUSE_DETACHED":
        return DipPropertyTypeEnum.HOUSE_DETACHED;
      case "HOUSE_NEW_BUILD":
        return DipPropertyTypeEnum.HOUSE_NEW_BUILD;
      case "FLAT_PURPOSE_BUILT":
        return DipPropertyTypeEnum.FLAT_PURPOSE_BUILT;
      case "FLAT_NEW_BUILD":
        return DipPropertyTypeEnum.FLAT_NEW_BUILD;
      case "HOUSE_SEMI_DETACHED":
        return DipPropertyTypeEnum.HOUSE_SEMI_DETACHED;
      default:
        log.error("Unsupported propertyGmsBuildType {} is passed", propertyGmsBuildType);
        return null;
    }
  }
}
