package com.rbs.pbbdhb.coordinator.adbo.controller;


import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.PaymentControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.response.PaymentUrlResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.PaymentService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
public class PaymentController implements PaymentControllerSwagger {

  private final PaymentService paymentService;

  @Autowired
  public PaymentController(PaymentService paymentService) {
    this.paymentService = paymentService;
  }

  @Override
  @GetMapping(path = "/paymentUrl", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<PaymentUrlResponse> getAdboPaymentUrl(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @Parameter(name = Headers.BRAND, description = Constants.BRAND_DESCRIPTION)
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(RBS|rbs|nwb|NWB)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getAdboPaymentUrl start - Headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<PaymentUrlResponse> response = new ResponseEntity<>( paymentService.getAdboPaymentUrl(accountNumber), HttpStatus.OK);
    log.info("getAdboPaymentUrl end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }
}
