package com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.JourneyValidationResultCode;
import com.rbs.pbbdhb.coordinator.adbo.enums.RouteTo;
import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class JourneyValidationApiResponse {

  private JourneyValidationResultCode journeyValidationResultCode;
  private ValidationRuleResultCode validationRuleResultCode;
  private Boolean hasSecondCharge;
  private List<Customer> customers;
  private RouteTo navigateTo;
  private Integer daysToComplete;
  private String accountNumber;
  private LocalDate sysDate;
  private Boolean isEligibleForStatusReset=false;
}
