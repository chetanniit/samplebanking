package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.Getter;


@Getter
public enum RouteTo {

  MARKETING_PREFERENCE_PAGE_MAIN,
  DASHBOARD_PAGE,
  JOINT_APPLICANT_LANDING_PAGE,

}
