package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum SubmissionStatus {
  SUCCESSFUL, RETRY_SUCCESSFUL, RETRY_FAILED
}
