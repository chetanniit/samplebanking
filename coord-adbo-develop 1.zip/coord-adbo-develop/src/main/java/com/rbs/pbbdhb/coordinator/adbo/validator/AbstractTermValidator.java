package com.rbs.pbbdhb.coordinator.adbo.validator;

import static com.rbs.pbbdhb.coordinator.adbo.request.BorrowingDetails.MAXIMUM_NUMBER_YEARS;

import lombok.SneakyThrows;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public abstract class AbstractTermValidator<C> implements Validator {

  @Override
  public final boolean supports(Class<?> clazz) {
    return supportedClass().isAssignableFrom(clazz);
  }

  @Override
  @SneakyThrows
  public final void validate(Object target, Errors errors) {
    C castedTarget = supportedClass().cast(target);

    Integer repaymentTermYears = getRepaymentTermYears(castedTarget);
    Integer repaymentTermMonths = getRepaymentTermMonths(castedTarget);

    validateTerm(errors, repaymentTermYears, repaymentTermMonths);
  }

  private void validateTerm(Errors errors, Integer repaymentTermYears, Integer repaymentTermMonths) {
    if (repaymentTermYears != null && repaymentTermMonths != null && 0 == repaymentTermYears && 0 == repaymentTermMonths) {
      errors.rejectValue("repaymentTermYears", "required", "repaymentTermYears and repaymentTermMonths both cannot be 0");
    }
    if (MAXIMUM_NUMBER_YEARS == repaymentTermYears && 0 != repaymentTermMonths) {
      errors.rejectValue("repaymentTermYears", "required",
          "if repaymentTermYears equals " + MAXIMUM_NUMBER_YEARS + " then repaymentTermMonths must be 0");
    }
  }

  protected abstract Class<C> supportedClass();

  protected abstract Integer getRepaymentTermMonths(C target);

  protected abstract Integer getRepaymentTermYears(C target);
}
