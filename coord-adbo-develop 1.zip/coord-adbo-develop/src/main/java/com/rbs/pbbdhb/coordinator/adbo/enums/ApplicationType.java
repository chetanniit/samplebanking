package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * ApplicationType enumeration
 */
@AllArgsConstructor
@Getter
public enum ApplicationType {
  RESIDENTIAL("Residential"),
  BUY_TO_LET("B2L");

  private final String value;

  @Override
  public String toString() {
    return name();
  }
}