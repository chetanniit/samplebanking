package com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.enums.BorrowingPurposeType;
import java.math.BigDecimal;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = As.EXISTING_PROPERTY, property = "type",
    defaultImpl = OtherAdboAmountDistribution.class, visible = true)
@JsonSubTypes({
    @Type(value = HomeImprovement.class, name = "HOME_IMPROVEMENT"),
    @Type(value = PropertyPurchase.class, name = "PURCHASE_ADDITIONAL_PROPERTY"),
    @Type(value = SecondChargeRedemption.class, name = "REDEEM_SECOND_CHARGE"),
    @Type(value = OtherAdboAmountDistribution.class, name = "Everything else") //added for schema
})
public interface AdboAmountDistribution {

  BigDecimal getAmount();

  BorrowingPurposeType getType();
}
