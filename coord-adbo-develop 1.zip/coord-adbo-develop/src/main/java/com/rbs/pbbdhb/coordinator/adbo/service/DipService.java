package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.response.DipResponse;

public interface DipService {

  DipResponse getDecisionInPrinciple(String accountNumber);

  DipResponse getDecisionInPrincipleFromDB(String accountNumber);
}
