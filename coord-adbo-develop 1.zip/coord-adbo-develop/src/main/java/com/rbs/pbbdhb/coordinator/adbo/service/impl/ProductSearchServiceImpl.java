package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DD_MM_YYYY_DATE_PATTERN;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.MAIN;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ProductTerm.FIVE_YEAR;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ProductType.FIXED;
import static java.util.Collections.emptyList;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.toList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.AgreementsAndDisclaimers;
import com.rbs.pbbdhb.coordinator.adbo.entity.SalesIllustration;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.enums.Channel;
import com.rbs.pbbdhb.coordinator.adbo.enums.CustomerType;
import com.rbs.pbbdhb.coordinator.adbo.enums.FeeAction;
import com.rbs.pbbdhb.coordinator.adbo.enums.FeePaymentType;
import com.rbs.pbbdhb.coordinator.adbo.enums.MortgageType;
import com.rbs.pbbdhb.coordinator.adbo.enums.SubAccountType;
import com.rbs.pbbdhb.coordinator.adbo.mapper.ProductResponseMapper;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchFinalResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchRequest;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductSearchResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.AdboSwitchMonthlyPaymentsResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.ProductSearchService;
import com.rbs.pbbdhb.coordinator.adbo.service.SwitchMonthlyPaymentCalculatorService;
import com.rbs.pbbdhb.coordinator.adbo.util.SubAccountsSelectionForSwitching;
import com.rbs.pbbdhb.exception.BusinessException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class ProductSearchServiceImpl implements ProductSearchService {

  private final ProductResponseMapper productResponseMapper;
  private final ApiService apiService;
  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final SwitchMonthlyPaymentCalculatorService switchMonthlyPaymentCalculatorService;


  private ProductSearchResponse search(ProductSearchRequest productSearchRequest,
      AdboCaseDetails adboCaseDetails) {
    ProductSearchFinalResponse productSearchResp = apiService.getProductDetails(setProductRequest(productSearchRequest));
    ProductSearchResponse productSearchResponse = new ProductSearchResponse();
    List<Product> products = productSearchResp == null ? emptyList() : productSearchResp.getProduct().stream()
        .map(productResponseMapper::toEligibleProduct)
        .filter(product -> filterProductsBasedOnLtv(product, productSearchRequest))
        .collect(toList());
    if (!CollectionUtils.isEmpty(products)) {
      products.forEach(product -> product.setNewEstimatedMonthlyPayment(BigDecimal.valueOf(product.getInitialMonthlyPayment())));

      List<Product> filterProductList = products.stream().filter(product -> removeProductFromList(product, productSearchRequest))
          .collect(toList());
      if (!CollectionUtils.isEmpty(filterProductList)) {
        products.removeIf(product -> Objects.equals(product.getProductTerm(), FIVE_YEAR));
      }

      if (MortgageType.SWITCHER.equals(productSearchRequest.getMortgageType())) {
        List<TimePeriod> timePeriods = SubAccountsSelectionForSwitching.selectedSubAccountsForSwitching(adboCaseDetails).stream()
            .map(SubAccount::getRemainingTerm).collect(toList());
        timePeriods.add(TimePeriod.builder()
            .years(adboCaseDetails.getAdditionalBorrowingCalculator().getRepaymentTermYears())
            .months(adboCaseDetails.getAdditionalBorrowingCalculator().getRepaymentTermMonths())
            .build());
        Optional<TimePeriod> sortedTimePeriod = timePeriods.stream()
            .min(Comparator.comparing(TimePeriod::getYears)
                .thenComparing(TimePeriod::getMonths));
        List<Product> filterProductListForSwticher = products.stream().filter(product -> (product.getProductTerm()
                .getYears() < sortedTimePeriod.get().getYears()) || (product.getProductTerm().getYears() == sortedTimePeriod.get().getYears()
                && sortedTimePeriod.get().getMonths() > 0))
            .collect(toList());
        setnewEstimatedMonthlyPaymentForSwitcher(productSearchResponse, filterProductListForSwticher, adboCaseDetails);
        products = filterProductListForSwticher;
      }
    }
    productSearchResponse.setProduct(products);
    return productSearchResponse;
  }

  private boolean filterProductsBasedOnLtv(Product product, ProductSearchRequest productSearchRequest) {
    return nonNull(product.getLtv()) && nonNull(productSearchRequest.getLtv()) && (product.getLtv() <= 60 && productSearchRequest
        .getLtv() <= 60 || ((product.getLtv() > 60 && productSearchRequest.getLtv() > 60) && (product.getLtv() <= 75
        && productSearchRequest.getLtv() <= 75))
        || ((product.getLtv() > 75 && productSearchRequest.getLtv() > 75) && (product.getLtv() <= 80
        && productSearchRequest.getLtv() <= 80))
        || ((product.getLtv() > 80 && productSearchRequest.getLtv() > 80) && (product.getLtv() <= 85
        && productSearchRequest.getLtv() <= 85)) || ((product.getLtv() > 85 && productSearchRequest.getLtv() > 85) && (product
        .getLtv() <= 90 && productSearchRequest.getLtv() <= 90)));
  }

  private boolean removeProductFromList(Product product, ProductSearchRequest productSearchRequest) {

    if (nonNull(product.getMortgageTermYears()) && nonNull(product.getMortgageTermMonths()) && nonNull(
        productSearchRequest.getCustomerPreferredTermYears()) && nonNull(productSearchRequest.getCustomerPreferredTermMonths())) {
      return ((product.getMortgageTermYears() == 5 && productSearchRequest.getCustomerPreferredTermYears() == 5) &&
          (product.getMortgageTermMonths() == 0 && productSearchRequest.getCustomerPreferredTermMonths() == 0)) ||
          ((product.getMortgageTermYears() >= 3 && productSearchRequest.getCustomerPreferredTermYears() >= 3) &&
              (product.getMortgageTermYears() < 5 && productSearchRequest.getCustomerPreferredTermYears() < 5));
    }
    return false;
  }

  private void setnewEstimatedMonthlyPaymentForSwitcher(ProductSearchResponse productSearchResp, List<Product> products,
      AdboCaseDetails adboCaseDetails) {

    BigDecimal currentMonthlyPayment = adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream().map(
        SubAccount::getMonthlyPayment).reduce(BigDecimal.ZERO, BigDecimal::add);
    productSearchResp.setCurrentMonthlyPayment(currentMonthlyPayment);

    BigDecimal monthlyPaymentOfNonSelectedSubAccounts = SubAccountsSelectionForSwitching.nonSelectedSubAccountsForSwitching(adboCaseDetails)
        .stream().map(
            SubAccount::getMonthlyPayment).reduce(BigDecimal.ZERO, BigDecimal::add);

    products.forEach(product -> {
      AdboSwitchMonthlyPaymentsResponse adboSwitchMonthlyPaymentsResponse = switchMonthlyPaymentCalculatorService
          .getAdboSwitchMonthlyPayments(adboCaseDetails.getAccountNumber(),
              BigDecimal.valueOf(product.getInitialInterestRate()));
      BigDecimal sumOfNewMonthlyPayment = adboSwitchMonthlyPaymentsResponse.getSubAccounts().stream().map(subAccount -> subAccount
          .getNewMonthlyPayment()).reduce(BigDecimal.ZERO,
          BigDecimal::add);
      product.setNewEstimatedMonthlyPayment(sumOfNewMonthlyPayment.add(monthlyPaymentOfNonSelectedSubAccounts).add(
          adboSwitchMonthlyPaymentsResponse.getNewMonthlyPayment()));
      product.setAdboSwitchMonthlyPaymentsResponse(adboSwitchMonthlyPaymentsResponse);
    });
  }

  public ProductSearchRequest setProductRequest(ProductSearchRequest productSearchRequest) {
    String date = LocalDate.now().format(DateTimeFormatter.ofPattern(DD_MM_YYYY_DATE_PATTERN));
    productSearchRequest.setCustomerType(CustomerType.EXISTING_CUSTOMER.toString());
    productSearchRequest.setProductSearchDate(date);
    productSearchRequest.setRepaymentType(Constants.REPAYMENT_TYPE);
    productSearchRequest.setChannel(Channel.INTERNET.toString());
    productSearchRequest.setApplicationType(ApplicationType.RESIDENTIAL);
    if (isNull(productSearchRequest.getMortgageType())) {
      productSearchRequest.setMortgageType(MortgageType.ADBO);
    }
    productSearchRequest.setMortgageAmount(BigDecimal.valueOf(productSearchRequest.getMortgageAmount().intValue()));
    productSearchRequest.setExistingBorrowing(
        nonNull(productSearchRequest.getExistingBorrowing()) ? BigDecimal.valueOf(productSearchRequest.getExistingBorrowing().intValue())
            : null);
    productSearchRequest.setPropertyValue(BigDecimal.valueOf(productSearchRequest.getPropertyValue().intValue()));
    return productSearchRequest;
  }

  public ProductSearchRequest getProductRequest(ProductSearchRequest productSearchRequest, AdboCaseDetails adboCaseDetails) {
    productSearchRequest.setMortgageAmount(BigDecimal.valueOf(adboCaseDetails.getAdditionalBorrowingCalculator().getBorrowingAmount()));
    productSearchRequest.setExistingBorrowing(adboCaseDetails.getAdditionalBorrowingCalculator().getTotalTrueBalance());
    productSearchRequest.setPropertyValue(adboCaseDetails.getAdditionalBorrowingCalculator().getEstimatedPropertyValue() != null
        ? BigDecimal.valueOf(adboCaseDetails.getAdditionalBorrowingCalculator().getEstimatedPropertyValue())
        : (adboCaseDetails.getAdditionalBorrowingCalculator().getHpiValuation()));
    productSearchRequest.setCustomerPreferredTermMonths(adboCaseDetails.getAdditionalBorrowingCalculator().getRepaymentTermMonths());
    productSearchRequest.setCustomerPreferredTermYears(adboCaseDetails.getAdditionalBorrowingCalculator().getRepaymentTermYears());
    productSearchRequest.setLtv(adboCaseDetails.getAdditionalBorrowingCalculator().getLoanToValue().doubleValue());

    return productSearchRequest;
  }

  @Override
  public void saveProductDetails(String accountNumber, @Valid List<Product> productDetails) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    addProductFeePaymentType(productDetails);
    if (nonNull(adboCaseDetails)) {
      if (nonNull(adboCaseDetails.getSalesIllustration()) && !CollectionUtils.isEmpty(
          adboCaseDetails.getSalesIllustration().getProductDetails()) &&
          !CollectionUtils.isEmpty(productDetails) &&
          !adboCaseDetails.getSalesIllustration().getProductDetails().get(0).getProductCode()
              .equals(productDetails.get(0).getProductCode())) {
        SubAccountsSelectionForSwitching.selectedSubAccountsForSwitching(adboCaseDetails)
            .forEach(subAccount -> subAccount.setSwitchImmediately(null));
      }
      SalesIllustration salesIllustration = SalesIllustration.builder().isAccepted(Boolean.TRUE).selectionDate(LocalDate.now())
          .productDetails(productDetails).build();
      adboCaseDetails.setSalesIllustration(salesIllustration);
      updateReadMortgageIllustrationInAgreementsAndDisclaimersForMainApplicant(adboCaseDetails);
      adboCaseDetailsDao.save(adboCaseDetails);
      log.info("product details have been saved/updated successfully, accountNumber {}", accountNumber);
    } else {
      log.info("product details not found for the given account number {}", accountNumber);
      throw new BusinessException(Constants.PRODUCT_CANNOT_SAVED, HttpStatus.NOT_FOUND.value());
    }

  }

  private void updateReadMortgageIllustrationInAgreementsAndDisclaimersForMainApplicant(AdboCaseDetails adboCaseDetails) {
    AgreementsAndDisclaimers agreementsAndDisclaimers = adboCaseDetails.getAdboApplicants().get(MAIN).getAgreementsAndDisclaimers();
    if (ObjectUtils.isEmpty(agreementsAndDisclaimers)) {
      throw new BusinessException(Constants.AGREEMENT_AND_DISCLAIMERS_NOT_FOUND, HttpStatus.NOT_FOUND.value());
    }
    agreementsAndDisclaimers.setReadMortgageIllustration(null);
    agreementsAndDisclaimers.setReadSwitchIllustration(null);
  }

  private void addProductFeePaymentType(List<Product> productDetails) {
    productDetails.stream()
        .map(Product::getFees)
        .filter(Objects::nonNull)
        .flatMap(List::stream)
        .filter(Objects::nonNull)
        .filter(fee -> fee.getFeeAction() == FeeAction.NO_ACTION)
        .filter(fee -> fee.getFeePaymentType() == null)
        .forEach(fee -> fee.setFeePaymentType(FeePaymentType.CARD_PAYMENT));
  }

  @Override
  public ProductSearchResponse getProducts(String accountNumber, String brand) {

    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    ProductSearchRequest productSearchRequest = getProductRequest(new ProductSearchRequest(), adboCaseDetails);
    if (Boolean.TRUE.equals(adboCaseDetails.getAdditionalBorrowingWithSwitch())) {
      boolean productTypeFixed = false;
      productSearchRequest.setMortgageType(MortgageType.SWITCHER);
      productTypeFixed = SubAccountsSelectionForSwitching.selectedSubAccountsForSwitching(adboCaseDetails).stream().anyMatch(
          subAccount -> SubAccountType.TRACKER == subAccount.getSubAccountType());
      if (adboCaseDetails.getAdditionalBorrowingCalculator().getCohortDate() != null) {
        productSearchRequest.setCohortDate(adboCaseDetails.getAdditionalBorrowingCalculator().getCohortDate());
      }
      if (productTypeFixed) {
        productSearchRequest.setProductType(FIXED);
      }
    }
    return search(productSearchRequest, adboCaseDetails);
  }
}
