package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DipSelfEmployed {

  private final BusinessTypeEnum businessType;

  private final LocalDate selfEmployedDateEstablished;

  private final BigDecimal drawingsLatest;

  private final BigDecimal drawingsPrevious;

  private final BigDecimal dividendsLatest;

  private final BigDecimal dividendsPrevious;

  private final BigDecimal netProfitLatest;

  private final BigDecimal netProfitPrevious;

  public enum BusinessTypeEnum {
    SOLE_TRADER,
    PARTNERSHIP,
    LIMITED_COMPANY
  }

}
