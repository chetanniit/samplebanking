package com.rbs.pbbdhb.coordinator.adbo.validator;

import java.util.stream.Stream;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

@Slf4j
public class EnumValidator implements ConstraintValidator<ValidateEnum, String> {

  private String[] acceptedValues;

  @Override
  public void initialize(ValidateEnum constraintAnnotation) {
    acceptedValues = Stream.of(constraintAnnotation.enumClass().getEnumConstants()).map(Enum::name)
        .toArray(String[]::new);
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
    if (value == null) {
      return true;
    }
    if (!ArrayUtils.contains(acceptedValues, value.toUpperCase())) {
      if (constraintValidatorContext instanceof HibernateConstraintValidatorContext) {
        constraintValidatorContext.unwrap(HibernateConstraintValidatorContext.class)
            .addMessageParameter("values", String.join(", ", acceptedValues));
      }
      return false;
    }
    return true;
  }
}
