package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class InterestOnlyValidator extends AbstractValidator {

  public InterestOnlyValidator(@Value("${journeyValidator.priority.interestOnly}") int priority) {
    super(priority, ValidationRuleResultCode.LIMITED_DUE_TO_INTEREST_ONLY);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    List<SubAccount> subAccounts = journeyValidation.getAccountSummaryApiResponse().getSubAccounts();
    if (subAccounts != null) {
      for (SubAccount subAccount : subAccounts) {
        if (RepaymentType.INTEREST_ONLY.equals(subAccount.getRepaymentType())) {
          return true;
        }
      }
    }
    return false;
  }
}
