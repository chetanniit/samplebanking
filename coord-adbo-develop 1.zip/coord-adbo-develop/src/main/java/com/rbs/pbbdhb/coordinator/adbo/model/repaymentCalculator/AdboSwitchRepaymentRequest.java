package com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
public class AdboSwitchRepaymentRequest {

  public static final String ADBO_SUB_ACCOUNT_NUMBER = "0";

  private List<AboSwitchRepaymentSubAccountRequest> subAccountDetails;

}
