package com.rbs.pbbdhb.coordinator.adbo.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ProductTermEnum {
  ONE_YEAR(1),
  TWO_YEAR(2),
  THREE_YEAR(3),
  FOUR_YEAR(4),
  FIVE_YEAR(5),
  SIX_YEAR(6),
  SEVEN_YEAR(7),
  EIGHT_YEAR(8),
  NINE_YEAR(9),
  TEN_YEAR(10);
  private final Integer years;

  public static String getProductTerm(int years) {
    for (ProductTermEnum productTermEnum : ProductTermEnum.values()) {
      if (productTermEnum.years == years) {
        return productTermEnum.name();
      }
    }
    return null;
  }
}
