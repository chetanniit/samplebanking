package com.rbs.pbbdhb.coordinator.adbo.mapper;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_FORMATTER;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DD_MM_YYYY_DATE_PATTERN;
import static java.util.Objects.nonNull;

import com.rbs.pbbdhb.coordinator.adbo.model.product.EarlyRepaymentCharge;
import com.rbs.pbbdhb.coordinator.adbo.model.product.EarlyRepaymentChargeDto;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.model.product.ProductResult;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = MappingConfig.class)
public interface ProductResponseMapper {

  DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DD_MM_YYYY_DATE_PATTERN);

  @Named("getEarlyRepaymentChargeCode")
  static List<EarlyRepaymentCharge> getEarlyRepaymentChargeCode(ProductResult productResult) {
    if (productResult != null) {
      List<EarlyRepaymentChargeDto> earlyRepaymentCharges = productResult.getEarlyRepaymentCharges();
      if (earlyRepaymentCharges == null) {
        return null;
      }

      String date = productResult.getProductEndDate();
      LocalDate endDate = LocalDate.parse(date, formatter);
      List<EarlyRepaymentCharge> list = new ArrayList<>(earlyRepaymentCharges.size());
      for (EarlyRepaymentChargeDto chargeDto : earlyRepaymentCharges) {
        list.add(ToEarlyRepayment(chargeDto, endDate));
      }
      return list;
    }
    return null;
  }

  static EarlyRepaymentCharge ToEarlyRepayment(EarlyRepaymentChargeDto chargeDto, LocalDate endDate) {
    if (chargeDto == null) {
      return null;
    }
    EarlyRepaymentCharge repaymentCharge = new EarlyRepaymentCharge();
    repaymentCharge.setCharge(nonNull(chargeDto.getCharge()) ? chargeDto.getCharge() * 100 : null);
    repaymentCharge.setTerm(nonNull(chargeDto.getTerm()) ? chargeDto.getTerm() : null);
    repaymentCharge.setYear(nonNull(chargeDto.getYear()) ? chargeDto.getYear() : null);
    if (nonNull(chargeDto.getTerm()) && nonNull(chargeDto.getYear()) && nonNull(endDate)) {
      Integer term = Integer.parseInt(String.valueOf(chargeDto.getTerm().charAt(0)));
      long outstandingYears = term - chargeDto.getYear();
      LocalDate calculatedDate = endDate.minusYears(outstandingYears);
      String finalYear = DATE_FORMATTER.format(calculatedDate);
      repaymentCharge.setEarlyRepaymentInterestDate(finalYear);
      return repaymentCharge;
    }
    return repaymentCharge;
  }

  @Named("convertDate")
  static String convertDate(String date) {
    LocalDate formatDate = LocalDate.parse(date, formatter);
    return DATE_FORMATTER.format(formatDate);
  }

  @Named("mapToInt")
  static Integer mapToInt(BigDecimal amountValue) {
    return amountValue != null ? amountValue.intValue() : null;
  }

  @Mapping(target = "earlyRepaymentCharges", source = "product", qualifiedByName = "getEarlyRepaymentChargeCode")
  @Mapping(target = "productStartDate", source = "productStartDate", qualifiedByName = "convertDate")
  @Mapping(target = "productEndDate", source = "productEndDate", qualifiedByName = "convertDate")
  @Mapping(target = "productFee", expression = "java(product.getProductFee().intValue())")
  @Mapping(target = "initialMonthlyPaymentForSwitcher", source = "initialMonthlyPayment")
  @Mapping(target = "initialMonthlyPayment", source = "initialMonthlyPayment", qualifiedByName = "mapToInt")
  @Mapping(target = "productTermCost", source = "productTermCost", qualifiedByName = "mapToInt")
  @Mapping(target = "feeWrappedInitialMonthlyPaymentForSwitcher", source = "feeWrappedInitialMonthlyPayment")
  @Mapping(target = "feeWrappedInitialMonthlyPayment", source = "feeWrappedInitialMonthlyPayment", qualifiedByName = "mapToInt")
  @Mapping(target = "feeWrappedProductTermCost", source = "feeWrappedProductTermCost", qualifiedByName = "mapToInt")
  @Mapping(target = "standardValuationFee", source = "standardValuationFee", qualifiedByName = "mapToInt")
  @Mapping(target = "baseRate",source = "baseRate")
  @Mapping(target = "trackerMarginPercent",source = "trackerMarginPercent")
  Product toEligibleProduct(ProductResult product);

}