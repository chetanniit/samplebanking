package com.rbs.pbbdhb.coordinator.adbo.validator;

import static com.google.common.collect.Range.closed;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.MONTHLY_PENSION_CONTRIBUTION_NOT_NULL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.MONTHLY_PENSION_CONTRIBUTION_WITH_IN_RAGE;
import static com.rbs.pbbdhb.coordinator.adbo.validator.AdboUtilsValidator.nullCheck;
import static com.rbs.pbbdhb.coordinator.adbo.validator.AmountRangeValidator.validateAmountRange;

import com.google.common.collect.Range;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PensionContributionValidator {

  private static final Range<BigDecimal> PAYMENT_RANGE = closed(BigDecimal.ZERO, BigDecimal.valueOf(99999999));

  public void validatePensionContribution(ApplicantType applicantType, AdboCaseDetails adboCaseDetails,
      BigDecimal monthlyPensionContribution) {
    SubAccount account = adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().stream().sorted(
        (subAccount, subAccount1) -> subAccount1.getTermEndDate().compareTo(subAccount.getTermEndDate()))
        .findFirst().get();
    Integer retirementAge = adboCaseDetails.getAdditionalBorrowingCalculator().getRetirementAge()
        .get(applicantType.getIndex());
    LocalDate dateOfBirth = adboCaseDetails.getAdboApplicants().get(applicantType).getPersonalDetails()
        .getDateOfBirth();
    LocalDate retirementDate = dateOfBirth.plusYears(retirementAge);
    LocalDate termEndDate = account.getTermEndDate();
    LocalDate minRetirementIntervalDate = LocalDate.now().plusYears(10);

    if (retirementDate.isAfter(LocalDate.now())
        && (retirementDate.isEqual(termEndDate) || retirementDate.isBefore(termEndDate))
        && (retirementDate.isAfter(minRetirementIntervalDate))) {
      nullCheck(MONTHLY_PENSION_CONTRIBUTION_NOT_NULL, monthlyPensionContribution);
      validateAmountRange(MONTHLY_PENSION_CONTRIBUTION_WITH_IN_RAGE, monthlyPensionContribution, PAYMENT_RANGE);

    }
  }
}
