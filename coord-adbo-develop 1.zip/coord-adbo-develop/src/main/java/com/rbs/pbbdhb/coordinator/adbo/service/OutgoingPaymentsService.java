package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;

public interface OutgoingPaymentsService {

  void saveOutgoingPayments(String accountNumber, OutgoingPaymentsDetails outgoingPaymentsDetails);

  OutgoingPaymentsDetails getOutgoingPayments(String accountNumber);
}
