package com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator;

import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
public class AboSwitchRepaymentSubAccountRequest {

  private String subAccountNumber;
  private BigDecimal currentBalance;
  private BigDecimal initialRate;
  private TimePeriod remainingTerm;
  private boolean interestOnly;
  private Integer productFee;
}
