package com.rbs.pbbdhb.coordinator.adbo.brand.nwb.repositories;

import com.rbs.pbbdhb.coordinator.adbo.repository.AdboCaseDetailsRepository;

/**
 * This class is used to create repository for NWB
 */
public interface NwbAdboCaseDetailsRepository extends AdboCaseDetailsRepository {

}