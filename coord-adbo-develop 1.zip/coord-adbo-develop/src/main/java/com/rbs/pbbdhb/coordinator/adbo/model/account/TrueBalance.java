package com.rbs.pbbdhb.coordinator.adbo.model.account;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TrueBalance {

  private String subAccNo;
  private BigDecimal trueBalance;
}
