package com.rbs.pbbdhb.coordinator.adbo.validator;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.BORROW_AMOUNT;
import static java.math.BigDecimal.ZERO;
import static java.util.Objects.nonNull;

import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import com.rbs.pbbdhb.exception.BusinessException;
import java.math.BigDecimal;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class BorrowingAmountValidator {


  public void validateAmount(AdboCaseDetails adboCaseDetails, List<AdboAmountDistribution> borrowingPurposeRequest) {

    Integer borrowAmt = nonNull(adboCaseDetails.getAdditionalBorrowingCalculator().getBorrowingAmount()) ?
        adboCaseDetails.getAdditionalBorrowingCalculator().getBorrowingAmount() : 0;
    if (nonNull(borrowingPurposeRequest)) {
      boolean isMatches = borrowingPurposeRequest.stream().map(AdboAmountDistribution::getAmount)
          .reduce(BigDecimal::add).orElse(ZERO)
          .compareTo(BigDecimal.valueOf(borrowAmt)) == 0;
      if (!isMatches) {
        throw new BusinessException(BORROW_AMOUNT, HttpStatus.BAD_REQUEST.value());
      }
    }

  }

}