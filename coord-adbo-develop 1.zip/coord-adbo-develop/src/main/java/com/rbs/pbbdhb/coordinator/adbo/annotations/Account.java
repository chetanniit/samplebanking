package com.rbs.pbbdhb.coordinator.adbo.annotations;


import com.rbs.pbbdhb.coordinator.adbo.validator.AccountValidator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = AccountValidator.class)
public @interface Account {

  String message() default "Please enter your 8 digit Mortgage account number (e.g. 12345678).";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

}
