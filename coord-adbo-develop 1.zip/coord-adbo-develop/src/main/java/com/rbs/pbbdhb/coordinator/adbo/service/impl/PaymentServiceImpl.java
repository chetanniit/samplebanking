package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.createRequestEntity;
import static java.util.Objects.isNull;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.OK;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.mapper.AdboPaymentMapper;
import com.rbs.pbbdhb.coordinator.adbo.request.PaymentUrlRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.PaymentUrlResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.PaymentService;
import com.rbs.pbbdhb.coordinator.adbo.service.RestService;
import com.rbs.pbbdhb.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PaymentServiceImpl implements PaymentService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final AdboPaymentMapper adboPaymentMapper;
  private final RestService restService;
  @Value("${worldpay.service.base.url}")
  private String paymentServiceBaseUrl;
  @Value("${worldpay.service.paymenturl.request.path}")
  private String paymentUrlPath;

  public PaymentServiceImpl(AdboCaseDetailsDao adboCaseDetailsDao, AdboPaymentMapper adboPaymentMapper,
      RestService restService) {
    this.adboCaseDetailsDao = adboCaseDetailsDao;
    this.adboPaymentMapper = adboPaymentMapper;
    this.restService = restService;
  }

  @Override
  public PaymentUrlResponse getAdboPaymentUrl(String accountNumber) {
    log.info("getAdboPaymentUrl started for accountNumber : {}", accountNumber);
    AdboCaseDetails caseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);

    PaymentUrlRequest paymentRequest = adboPaymentMapper.paymentUrlRequest(caseDetails.getAccountNumber());
    String url = StringUtils.join(paymentServiceBaseUrl, paymentUrlPath);
    ResponseEntity<PaymentUrlResponse> paymentUrlResponse = restService.exchange(url, HttpMethod.POST, createRequestEntity(paymentRequest),
        PaymentUrlResponse.class);
    checkAndThrowExceptionOnError(paymentUrlResponse, accountNumber);

    log.info("Get Adbo Payment Url : {}", paymentUrlResponse.getBody().getPaymentUrl());
    return paymentUrlResponse.getBody();
  }

  private void checkAndThrowExceptionOnError(ResponseEntity<PaymentUrlResponse> paymentUrlResponse, String accountNumber) {
    if (isNull(paymentUrlResponse) || !OK.equals(paymentUrlResponse.getStatusCode())) {
      log.error("Error getting payment url for Account : {}, response: {}", accountNumber, paymentUrlResponse);
      HttpStatusCode httpStatus = isNull(paymentUrlResponse) ? INTERNAL_SERVER_ERROR : paymentUrlResponse.getStatusCode();
      throw new BusinessException(Constants.ACCOUNT_PAYMENT_URL_ERROR, httpStatus.value());
    }
  }

}