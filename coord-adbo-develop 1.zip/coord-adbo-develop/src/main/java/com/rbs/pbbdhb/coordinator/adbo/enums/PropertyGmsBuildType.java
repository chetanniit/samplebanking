package com.rbs.pbbdhb.coordinator.adbo.enums;

import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import lombok.Getter;

@Getter
public enum PropertyGmsBuildType {

  BG(Constants.BUNGALOW_DETACHED, Constants.BUNGALOW_NEW_BUILD),
  D(Constants.HOUSE_DETACHED, Constants.HOUSE_NEW_BUILD),
  FL(Constants.FLAT_PURPOSE_BUILT, Constants.FLAT_NEW_BUILD),
  SM(Constants.HOUSE_SEMI_DETACHED, Constants.HOUSE_NEW_BUILD),
  TR(Constants.HOUSE_SEMI_DETACHED, Constants.HOUSE_NEW_BUILD),
  X(Constants.HOUSE_DETACHED, Constants.HOUSE_NEW_BUILD);

  private final String oldBuild;
  private final String newBuild;

  PropertyGmsBuildType(String oldBuild, String newBuild) {
    this.oldBuild = oldBuild;
    this.newBuild = newBuild;
  }

}