package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicantCinResponse {

  private String cin;

  private String firstName;

  private String lastName;

  @JsonFormat(pattern = Constants.DATE_PATTERN)
  private LocalDate dateOfBirth;

}
