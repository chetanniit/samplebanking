package com.rbs.pbbdhb.coordinator.adbo.validator;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DateFormatValidator implements ConstraintValidator<DateFormat, String> {

  private DateTimeFormatter dateTimeFormatter;

  @Override
  public void initialize(DateFormat constraintAnnotation) {
    dateTimeFormatter = DateTimeFormatter.ofPattern(constraintAnnotation.format(), Locale.UK)
        .withResolverStyle(ResolverStyle.STRICT);
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    if (value == null) {
      return true;
    }
    try {
      dateTimeFormatter.parse(value);
    } catch (DateTimeParseException e) {
      log.error("DateTimeParseException occurred  {} ", e.getMessage(), e);
      return false;
    }
    return true;
  }
}
