package com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Builder
@Getter
@Setter
public class ESISApplication {

  private String channel;

  private String caseSalesIllustrationId;

  private String levelOfService;

  private String caseId;

  private String applicationType;

  private String loanPurpose;

  private String buyerType;

  private Mortgage mortgage;

  private Applicants applicants;


}
