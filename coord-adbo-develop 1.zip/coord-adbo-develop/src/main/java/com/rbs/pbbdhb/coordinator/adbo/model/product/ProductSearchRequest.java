package com.rbs.pbbdhb.coordinator.adbo.model.product;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DD_MM_YYYY_DATE_PATTERN;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicationType;
import com.rbs.pbbdhb.coordinator.adbo.enums.Channel;
import com.rbs.pbbdhb.coordinator.adbo.enums.CustomerType;
import com.rbs.pbbdhb.coordinator.adbo.enums.MortgageType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import com.rbs.pbbdhb.coordinator.adbo.enums.RepaymentType;
import com.rbs.pbbdhb.coordinator.adbo.validator.DateFormat;
import com.rbs.pbbdhb.coordinator.adbo.validator.ValidateEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.time.LocalDate;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/***
 * model for a product search request
 */

@ToString
@EqualsAndHashCode
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class ProductSearchRequest {

  @Schema(required = true, description = "mortgageAmount is required", example = "200000")
  @NotNull(message = "mortgageAmount cannot be null")
  @DecimalMin(value = "1", message = "mortgageAmount must be greater than or equal to 1")
  @Digits(integer = 12, fraction = 4, message = "mortgageAmount must be less than or equal to 12 digits")
  private BigDecimal mortgageAmount;

  @Schema(required = true, description = "propertyValue is required", example = "280000")
  @NotNull(message = "propertyValue cannot be null")
  @Min(value = 1, message = "propertyValue must be greater than or equal to 1")
  @Digits(integer = 12, fraction = 4, message = "property value must be less than or equal to 12 digits")
  private BigDecimal propertyValue;

  @Schema(description = "existingBorrowing is mandatory in order to search existing customer products", example = "200000")
  @DecimalMin(value = "0")
  @Digits(integer = 12, fraction = 4, message = "existing borrowing must be less than or equal to 12 digits")
  private BigDecimal existingBorrowing;

  @Schema(implementation = String.class, hidden = true)
  @DateFormat(format = DD_MM_YYYY_DATE_PATTERN, message = "must be a valid date in dd-MM-yyyy format")
  private String productSearchDate;

  @Schema(implementation = Channel.class, example = "ADVISORY", hidden = true)
  @ValidateEnum(enumClass = Channel.class)
  private String channel;

  @Schema(implementation = RepaymentType.class, hidden = true)
  private String repaymentType;

  @Schema(implementation = ApplicationType.class, hidden = true)
  private ApplicationType applicationType;

  @Schema(implementation = CustomerType.class, example = "NEW_CUSTOMER", hidden = true)
  @ValidateEnum(enumClass = CustomerType.class)
  private String customerType;

  @Schema(implementation = MortgageType.class, hidden = true)
  private MortgageType mortgageType;

  @Schema(implementation = ProductType.class, hidden = true)
  private ProductType productType;

  @Schema(required = true, minimum = "0", maximum = "100", example = "85.00")
  @NotNull(message = "ltv cannot be null")
  @DecimalMax(value = "100", message = "ltv cannot be more than 100")
  @DecimalMin(value = "0", message = "ltv must be greater than or equal to zero")
  private Double ltv;

  @Schema(example = "40")
  @Min(value = 3, message = "customerPreferredTermYears must be greater than or equal to 3")
  @Max(value = 40, message = "customerPreferredTermYears cannot be more than 40")
  private Integer customerPreferredTermYears;

  @Schema(example = "11")
  @Min(value = 0, message = "customerPreferredTermMonths should be greater than or equal to zero")
  @Max(value = 11, message = "customerPreferredTermMonths cannot be more than 11")
  private Integer customerPreferredTermMonths;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DD_MM_YYYY_DATE_PATTERN)
  private LocalDate cohortDate;

}