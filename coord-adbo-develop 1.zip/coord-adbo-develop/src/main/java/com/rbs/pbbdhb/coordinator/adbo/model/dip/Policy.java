package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Policy {

  private String message;

  private String code;

}
