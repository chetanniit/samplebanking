package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.AgreementAndDisclaimersControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.request.AgreementsAndDisclaimersRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.AgreementsAndDisclaimersResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.AgreementsAndDisclaimersService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.Brand;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@Slf4j
@RequestMapping("/agreement-disclaimers")
@RequiredArgsConstructor
public class AgreementAndDisclaimersController implements AgreementAndDisclaimersControllerSwagger {

  private final AgreementsAndDisclaimersService agreementsAndDisclaimersService;

  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<AgreementsAndDisclaimersResponse> getAgreementsAndDisclaimers(
      @RequestHeader(Headers.ACCOUNT_NUMBER) String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute) {
    log.info("getAgreementsAndDisclaimers start with headers - account_number: {}, brand: {}, channel: {}", accountNumber, brand, channelRoute);
    TenantProvider.applyBrand(brand);
    ResponseEntity<AgreementsAndDisclaimersResponse> response = new ResponseEntity<>(
        agreementsAndDisclaimersService.getAgreementsAndDisclaimers(accountNumber), HttpStatus.OK);
    log.info("getAgreementsAndDisclaimers end's with response {} account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }

  @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> saveAgreementsAndDisclaimers(
      @RequestHeader(Headers.ACCOUNT_NUMBER) String accountNumber,
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute,
      @RequestBody @Valid final AgreementsAndDisclaimersRequest agreementsAndDisclaimers) {
    log.info("saveAgreementsAndDisclaimers Headers - account_number: {}, brand: {}, channel: {}, request: {}", accountNumber, brand, channelRoute, agreementsAndDisclaimers);
    TenantProvider.applyBrand(Brand.fromName(brand));
    agreementsAndDisclaimersService.updateAgreementsAndDisclaimers(accountNumber, agreementsAndDisclaimers);
    ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
    log.info("saveAgreementsAndDisclaimers end's with response {}, account_number: {}, brand: {}, channel: {}", response.getBody(), accountNumber, brand, channelRoute);
    return response;
  }


}
