package com.rbs.pbbdhb.coordinator.adbo.model.dip;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Telephone {

  private final PhoneTypeEnum type;

  private final String number;

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private final Boolean preferred;

  public enum PhoneTypeEnum {
    HOME,
    WORK,
    MOBILE,
    FAX
  }

}
