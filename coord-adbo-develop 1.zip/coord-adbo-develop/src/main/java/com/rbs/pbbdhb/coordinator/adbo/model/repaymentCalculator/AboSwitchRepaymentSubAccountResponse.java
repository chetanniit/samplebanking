package com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@Builder
public class AboSwitchRepaymentSubAccountResponse {

  private String subAccountNumber;
  private BigDecimal repaymentAmountWithProductFee;
  private BigDecimal repaymentAmountWithoutProductFee;
}
