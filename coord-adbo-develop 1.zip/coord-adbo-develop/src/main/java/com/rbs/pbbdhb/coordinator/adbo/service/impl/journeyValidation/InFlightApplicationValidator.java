package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicationStatus;
import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class InFlightApplicationValidator extends AbstractValidator {

  public InFlightApplicationValidator(@Value("${journeyValidator.priority.inFlight}") int priority) {
    super(priority, ValidationRuleResultCode.FAILED_DUE_TO_INPROGRESS_APPLICATION);
  }

  public static Boolean checkEnumExits(String str) {
    for (ApplicationStatus appstatus : ApplicationStatus.values()) {
      if (appstatus.name().equalsIgnoreCase(str)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return !checkEnumExits(journeyValidation.getApplicationStatusResponse().getAppStatus());
  }

}

