package com.rbs.pbbdhb.coordinator.adbo.entity.income;

import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Employment;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.employment.Retired;
import com.rbs.pbbdhb.coordinator.adbo.entity.income.enums.WorkStatus;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Income  {

  private boolean fromGms;

  private WorkStatus currentWorkStatus;

  private List<Employment> employments;

  private Retired retired;

  private Boolean hasOtherIncome;

  private List<OtherIncome> otherIncomes;

  private boolean hasBankDetailsModified;

  private BankDetails bankDetails;

}
