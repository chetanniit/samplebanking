package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidationApiResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.JourneyValidationService;
import java.util.HashMap;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Slf4j
@ConditionalOnProperty(value = "stub.journeyValidation.enabled", havingValue = "true")
@Service
public class JourneyValidationServiceStubImpl implements JourneyValidationService {

  @Value("${stub.journeyValidation.cin}")
  private String stubbedCinValues;

  private HashMap<String, String> cinCodeMap;

  @PostConstruct
  private void init() {
    cinCodeMap = new HashMap<>();
    for (String keyValue : stubbedCinValues.trim().split(",")) {
      String[] keyValueArray = keyValue.trim().split("-");
      cinCodeMap.put(keyValueArray[0], keyValueArray[1]);
    }
  }

  @Override
  public JourneyValidationApiResponse getJourneyValidation(String accountNumber, String cin,boolean isRequiredStatusReset) {
    ValidationRuleResultCode validationResultCode = ValidationRuleResultCode.valueOf(cinCodeMap.get(cin));
    return JourneyValidationApiResponse.builder()
        .hasSecondCharge("1153418752".equals(cin))
        .journeyValidationResultCode(validationResultCode.getJourneyValidationResultCode())
        .validationRuleResultCode(validationResultCode)
        .build();
  }
}
