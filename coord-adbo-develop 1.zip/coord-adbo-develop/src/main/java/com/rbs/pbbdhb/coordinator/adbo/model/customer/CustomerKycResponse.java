package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerKycResponse extends BaseResponse {

  private boolean kycVerified;
  private String cin;
}
