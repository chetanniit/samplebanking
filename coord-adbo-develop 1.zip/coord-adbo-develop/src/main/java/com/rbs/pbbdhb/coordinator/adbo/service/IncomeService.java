package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.request.IncomeRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.IncomeResponse;
import java.util.List;

public interface IncomeService {

  List<IncomeResponse> getIncomeDetails(String accountNumber);

  void saveIncomeDetails(String accountNumber, IncomeRequest incomeRequest);

}
