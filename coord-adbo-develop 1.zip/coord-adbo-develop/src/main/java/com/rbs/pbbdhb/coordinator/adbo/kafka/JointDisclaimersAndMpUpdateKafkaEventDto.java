package com.rbs.pbbdhb.coordinator.adbo.kafka;

import lombok.Builder;
import lombok.Data;
import lombok.With;
import lombok.extern.jackson.Jacksonized;

@Data
@With
@Builder
@Jacksonized
public class JointDisclaimersAndMpUpdateKafkaEventDto {

  private final String channel;
  private final String journey;
  private final String brandName;
  private final String topicName;
  private final JointApplicantDisclaimersAndMpDto jointDisclaimersAndMp;
}
