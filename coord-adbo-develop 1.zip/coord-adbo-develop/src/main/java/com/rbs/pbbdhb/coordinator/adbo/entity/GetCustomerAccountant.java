package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCustomerAccountant {

  private String name;
  private GetCustomerBaseAddress accountantAddress;
  private String telephoneNumber;
  private String faxNumber;
  private String qualification;
  private String emailAddress;
}
