package com.rbs.pbbdhb.coordinator.adbo.request;

import jakarta.validation.constraints.NotNull;

import com.rbs.pbbdhb.coordinator.adbo.annotations.EnumNewDealStartDateTypeValidator;
import com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Data
@EnumNewDealStartDateTypeValidator
public class MortgageQuoteSubAccountRequest   {
  
  @Schema(example = "1", required = true)
  @NotNull(message="sequenceNumber cannot be null")
  private Integer sequenceNumber;
  
  @Schema(example = "1", required = true)
  @NotNull(message="subAccountNumber cannot be null")
  private Integer subAccountNumber;
  
  @Schema(required = true)
  @NotNull(message="newDealStartDateType cannot be null")
  private NewDealStartDateType newDealStartDateType;
  
  @Schema(example = "true")
  private Boolean switchImmediately;

}
