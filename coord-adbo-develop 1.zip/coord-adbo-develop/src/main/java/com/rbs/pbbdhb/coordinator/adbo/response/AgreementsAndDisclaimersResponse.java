package com.rbs.pbbdhb.coordinator.adbo.response;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@ToString
@EqualsAndHashCode
@Data
@Builder
public class AgreementsAndDisclaimersResponse  {

  private Boolean readMortgageIllustration;
  private Boolean readSwitchIllustration;

  private Boolean readAboutOurMortgageRange;
}
