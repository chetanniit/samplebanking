package com.rbs.pbbdhb.coordinator.adbo.validator;

import static com.google.common.collect.Range.closed;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHILDCARE_EXPENSES_CONTINUE_MORE_THAN_SIX_MONTHS_NOT_NULL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHILDCARE_EXPENSE_MONTHLY_PAYMENT_MUST_NOT_NULL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHILDCARE_EXPENSE_MONTHLY_PAYMENT_MUST_WITH_IN_RANGE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHILDCARE_EXPENSE_TYPE_MUST_NOT_NULL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.CHILDCARE_EXPENSE_TYPE_MUST_VALID_TYPE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DEPENDENT_EXPENSES_CONTINUE_MORE_THAN_SIX_MONTHS_NOT_NULL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DEPENDENT_EXPENSE_MONTHLY_PAYMENT_MUST_NOT_NULL;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DEPENDENT_EXPENSE_MONTHLY_PAYMENT_MUST_WITH_IN_RANGE;
import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.PERSONAL_DETAILS_HAS_DEPENDENT_NOT_MATCH_OUTGOINGS;
import static com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingsOwnerType.BOTH;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.JOINT1;
import static com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType.MAIN;
import static com.rbs.pbbdhb.coordinator.adbo.utils.AppUtil.getRoundUpAverageAmount;
import static com.rbs.pbbdhb.coordinator.adbo.validator.AdboUtilsValidator.nullCheck;
import static com.rbs.pbbdhb.coordinator.adbo.validator.AdboUtilsValidator.unsupportedType;
import static com.rbs.pbbdhb.coordinator.adbo.validator.AmountRangeValidator.validateAmountRange;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.BooleanUtils.isTrue;

import com.google.common.collect.Range;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboApplicant;
import com.rbs.pbbdhb.coordinator.adbo.entity.ChildCareExpenseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.DependentExpenseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.OutgoingPaymentsDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.ApplicantType;
import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DependentsValidator {

  private static final Range<BigDecimal> PAYMENT_RANGE = closed(BigDecimal.ZERO, BigDecimal.valueOf(99999999));

  public void validateChildcareOrDependentExpenses(EnumMap<ApplicantType, AdboApplicant> adboApplicants,
      OutgoingPaymentsDetails outgoingPaymentsDetails) {

    if (isFalse(hasAnyDependentsForThisApplication(adboApplicants)) && (isTrue(outgoingPaymentsDetails.getHasDependentExpenses()) ||
        isTrue(outgoingPaymentsDetails.getHasChildcareExpenses()))) {
      unsupportedType(PERSONAL_DETAILS_HAS_DEPENDENT_NOT_MATCH_OUTGOINGS);
    }
    if (isFalse(hasAnyDependentsForThisApplication(adboApplicants)) &&
        isFalse(outgoingPaymentsDetails.getHasDependentExpenses()) &&
        isFalse(outgoingPaymentsDetails.getHasChildcareExpenses())) {
      return;
    }
    if (hasAnyDependentsUnder18ForThisApplication(adboApplicants) && isTrue(outgoingPaymentsDetails
        .getHasChildcareExpenses())) {
      outgoingPaymentsDetails.getChildcareExpenses().forEach(this::validateChildcareExpenses);
    }
    if (hasAnyDependentsOver18ForThisApplication(adboApplicants) && isTrue(outgoingPaymentsDetails
        .getHasDependentExpenses())) {
      outgoingPaymentsDetails.getDependentExpenses().forEach(this::validateDependentExpenses);
    }
  }

  private void validateDependentExpenses(DependentExpenseDetails dependentExpense) {
    nullCheck(DEPENDENT_EXPENSE_MONTHLY_PAYMENT_MUST_NOT_NULL, dependentExpense.getMonthlyPayment());
    validateAmountRange(DEPENDENT_EXPENSE_MONTHLY_PAYMENT_MUST_WITH_IN_RANGE, dependentExpense.getMonthlyPayment(), PAYMENT_RANGE
    );
    dependentExpense.setApplicantShareOnMonthlyPayment(dependentExpense.getMonthlyPayment());
    if (Objects.equals(BOTH, dependentExpense.getOwner())) {
      dependentExpense.setApplicantShareOnMonthlyPayment(
          getRoundUpAverageAmount(dependentExpense.getMonthlyPayment()));
    }
    nullCheck(DEPENDENT_EXPENSES_CONTINUE_MORE_THAN_SIX_MONTHS_NOT_NULL, dependentExpense.getContinueMoreThanSixMonths());
  }

  private void validateChildcareExpenses(ChildCareExpenseDetails childCareExpense) {
    nullCheck(CHILDCARE_EXPENSE_TYPE_MUST_NOT_NULL, childCareExpense.getType());
    nullCheck(CHILDCARE_EXPENSE_MONTHLY_PAYMENT_MUST_NOT_NULL, childCareExpense.getMonthlyPayment());
    nullCheck(CHILDCARE_EXPENSES_CONTINUE_MORE_THAN_SIX_MONTHS_NOT_NULL, childCareExpense.getContinueMoreThanSixMonths());
    switch (childCareExpense.getType()) {
      case AU_PAIR:
      case BREAKFAST_AFTER_SCHOOL_CLUBS:
      case CHILD_MINDER:
      case NURSERY:
      case DAILY_NANNY:
      case HOLIDAY_CLUBS:
      case LIVE_IN_NANNY:
      case PLAY_GROUP_OR_PRE_SCHOOL:
      case OTHER:
        break;
      default:
        unsupportedType(CHILDCARE_EXPENSE_TYPE_MUST_VALID_TYPE);
    }
    validateAmountRange(CHILDCARE_EXPENSE_MONTHLY_PAYMENT_MUST_WITH_IN_RANGE, childCareExpense.getMonthlyPayment(), PAYMENT_RANGE
    );
    childCareExpense.setApplicantShareOnMonthlyPayment(childCareExpense.getMonthlyPayment());
    if (Objects.equals(BOTH, childCareExpense.getOwner())) {
      childCareExpense.setApplicantShareOnMonthlyPayment(
          getRoundUpAverageAmount(childCareExpense.getMonthlyPayment()));
    }
  }

  boolean hasAnyDependentsForThisApplication(EnumMap<ApplicantType, AdboApplicant> adboApplicants) {
    if (isTrue(adboApplicants.get(MAIN).getPersonalDetails().getHasDependents())) {

      return true;
    }

    return nonNull(adboApplicants.get(JOINT1))
        && isTrue(adboApplicants.get(JOINT1).getPersonalDetails().getHasDependents());
  }

  boolean hasAnyDependentsUnder18ForThisApplication(EnumMap<ApplicantType, AdboApplicant> adboApplicants) {
    if (nonNull(adboApplicants.get(MAIN).getPersonalDetails().getDependentsUnder18())
        && adboApplicants.get(MAIN).getPersonalDetails().getDependentsUnder18() > 0) {

      return true;
    }

    return nonNull(adboApplicants.get(JOINT1))
        && nonNull(adboApplicants.get(JOINT1).getPersonalDetails().getDependentsUnder18())
        && adboApplicants.get(JOINT1).getPersonalDetails().getDependentsUnder18() > 0;
  }


  boolean hasAnyDependentsOver18ForThisApplication(EnumMap<ApplicantType, AdboApplicant> adboApplicants) {
    if (nonNull(adboApplicants.get(MAIN).getPersonalDetails().getDependentsOver18())
        && adboApplicants.get(MAIN).getPersonalDetails().getDependentsOver18() > 0) {

      return true;
    }

    return nonNull(adboApplicants.get(JOINT1))
        && nonNull(adboApplicants.get(JOINT1).getPersonalDetails().getDependentsOver18())
        && adboApplicants.get(JOINT1).getPersonalDetails().getDependentsOver18() > 0;
  }
}
