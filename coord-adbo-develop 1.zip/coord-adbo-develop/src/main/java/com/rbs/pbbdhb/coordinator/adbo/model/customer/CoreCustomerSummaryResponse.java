package com.rbs.pbbdhb.coordinator.adbo.model.customer;

import com.natwest.pbbdhb.commondictionaries.enums.applicant.MaritalStatus;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.Title;
import com.rbs.pbbdhb.coordinator.adbo.model.BaseResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.ValidatableCustomer;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreCustomerSummaryResponse extends BaseResponse implements ValidatableCustomer {

  private static final long serialVersionUID = -5782612517512650165L;
  private String cin;
  private Integer acctHolderPosition;
  private String gender;
  private Title gmsTitle;
  private String firstName;
  private List<String> middleNames;
  private String lastName;
  private String dateOfBirth;
  private String mobileNumber;
  private String email;
  private String nationality;
  private String countryOfResidence;
  private CustomerAddress customerAddress;
  private String gmsId;
  private boolean hasGuarantor;
  private MaritalStatus gmsMaritalStatus;

}
