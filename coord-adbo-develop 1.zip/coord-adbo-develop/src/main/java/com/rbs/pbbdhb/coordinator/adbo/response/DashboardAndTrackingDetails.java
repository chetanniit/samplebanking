package com.rbs.pbbdhb.coordinator.adbo.response;

import com.rbs.pbbdhb.coordinator.adbo.dto.AdboDashboardApplicants;
import com.rbs.pbbdhb.coordinator.adbo.dto.DashboardFeePaymentDetails;
import com.rbs.pbbdhb.coordinator.adbo.enums.AdboApplicationStatus;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@EqualsAndHashCode
@Builder
public class DashboardAndTrackingDetails {

    /**
     * The status field is used for to determine the current application status in the adbo dashboard and tracking screen
     * MINI_SUBMITTED- If CaseStatus is CAPIE_UPDATED or SUBMIT_ORCHESTRATION then set AdboApplicationStatus as MINI_SUBMITTED
     * SUBMISSION_FAILED - If CaseStatus is HARDSCORE_DECLINED or CONTRACT_VALIDATION_ERROR or SUBMIT_GMS_MOPS then set AdboApplicationStatus as SUBMISSION_FAILED
     * SUBMITTED - If CaseStatus is SUBMIT_GMS_STAGE_20 then set AdboApplicationStatus as SUBMITTED
     */
    private AdboApplicationStatus applicationStatus;
    /**
     * applicants field list of the applicants
     */
    private List<AdboDashboardApplicants> applicants;
    /**
     * feePayment field holds fee payment status details
     */
    private DashboardFeePaymentDetails feePayment;
    /**
     * The enableApplicationTracking will be true when CaseStatus is SUBMIT_GMS_STAGE_20 otherwise false.
     */
    private boolean enableApplicationTracking;

    /**
     * The remainingDaysInSeconds field is populated based on the below cases
     * if CaseStatus is CAPIE_UPDATED then return remainingDaysInSeconds between (CaseCreationDate + 14 days) - todays date
     * if Casestatus is SUBMIT_ORCHESTRATION then return remainingDaysInSeconds between  (modified date + 14 days) - todays date
     *  else null
     *  remainingDaysInSeconds field will hold the days will be converted into milliseconds
     */
    private Long remainingDaysInSeconds;
}
