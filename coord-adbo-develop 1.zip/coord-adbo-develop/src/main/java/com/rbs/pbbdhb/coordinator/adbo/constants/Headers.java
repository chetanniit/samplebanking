package com.rbs.pbbdhb.coordinator.adbo.constants;

import org.springframework.http.MediaType;

public class Headers {

  public static final String ACCOUNT_NUMBER = "account_number";
  public static final String BRAND = "brand";
  public static final String CASE_ID = "caseId";
  public static final String CHANNEL = "channel";
  public static final String CIN = "cin";

  public static final MediaType MEDIA_TYPE_APPLICATION_JSON_PATCH_JSON = new MediaType("application", "json-patch+json");
  public static final String MEDIA_TYPE_APPLICATION_JSON_PATCH_JSON_VALUE = MEDIA_TYPE_APPLICATION_JSON_PATCH_JSON.toString();

}
