package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import static com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode.LIMITED_DUE_TO_H2B;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class HelpToBuyValidator extends HoldCodesValidator {

  public HelpToBuyValidator(@Value("${journeyValidator.priority.helpToBuy}") int priority) {
    super(priority, LIMITED_DUE_TO_H2B, "H2BMGS", "H2BSEE", "H2BSEW", "H2BSES", "RBC");
  }

}
