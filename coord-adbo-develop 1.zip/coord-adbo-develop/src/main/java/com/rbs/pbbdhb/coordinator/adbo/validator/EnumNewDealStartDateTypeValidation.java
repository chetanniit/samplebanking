package com.rbs.pbbdhb.coordinator.adbo.validator;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import com.rbs.pbbdhb.coordinator.adbo.annotations.EnumNewDealStartDateTypeValidator;
import com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType;
import com.rbs.pbbdhb.coordinator.adbo.request.MortgageQuoteSubAccountRequest;

public class EnumNewDealStartDateTypeValidation implements
    ConstraintValidator<EnumNewDealStartDateTypeValidator, MortgageQuoteSubAccountRequest> {

  @Override
  public boolean isValid(MortgageQuoteSubAccountRequest request, ConstraintValidatorContext context) {
    return isNull(request) || (NewDealStartDateType.START_OPTION_TO_SWITCH.equals(request.getNewDealStartDateType()) && nonNull(request
        .getSwitchImmediately())) || isNull(request.getSwitchImmediately());
  }
}
