package com.rbs.pbbdhb.coordinator.adbo.controller;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.controller.swagger.DeleteAdboApplicationControllerSwagger;
import com.rbs.pbbdhb.coordinator.adbo.response.DeleteAdboApplicationResponse;
import com.rbs.pbbdhb.coordinator.adbo.service.DeleteAdboApplicationService;
import com.rbs.pbbdhb.coordinator.adbo.tenant.TenantProvider;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Profile({"local", "dev", "uat", "nft" })
@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class DeleteAdboApplicationController implements DeleteAdboApplicationControllerSwagger {
    private final DeleteAdboApplicationService deleteAdboApplicationService;
    @Override
    @DeleteMapping("/deleteAdboApplication")
    public ResponseEntity<DeleteAdboApplicationResponse> deleteAdboApplication(@RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
                                                      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand) {
        log.info("deleteAdboApplication start- Headers - account_number: {}, brand: {}", accountNumber, brand);
        TenantProvider.applyBrand(brand);
        Long noOfRecordsDeleted = deleteAdboApplicationService.deleteAdboApplication(accountNumber);
        DeleteAdboApplicationResponse response = DeleteAdboApplicationResponse.builder().noOfApplicationsDeleted(noOfRecordsDeleted).build();
        log.info("deleteAdboApplication end's with {} account_number: {}, brand: {}", response, accountNumber, brand);
        return ResponseEntity.ok(response);
    }
}
