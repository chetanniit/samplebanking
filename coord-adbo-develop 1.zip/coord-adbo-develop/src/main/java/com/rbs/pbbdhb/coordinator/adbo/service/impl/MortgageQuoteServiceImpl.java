package com.rbs.pbbdhb.coordinator.adbo.service.impl;

import static com.rbs.pbbdhb.coordinator.adbo.constants.Constants.DATE_FORMATTER;
import static com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentRequest.ADBO_SUB_ACCOUNT_NUMBER;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang.BooleanUtils.isTrue;

import com.rbs.pbbdhb.coordinator.adbo.dao.AdboCaseDetailsDao;
import com.rbs.pbbdhb.coordinator.adbo.entity.AdboCaseDetails;
import com.rbs.pbbdhb.coordinator.adbo.entity.abc.AdditionalBorrowingCalculator;
import com.rbs.pbbdhb.coordinator.adbo.enums.InterestType;
import com.rbs.pbbdhb.coordinator.adbo.enums.NewDealStartDateType;
import com.rbs.pbbdhb.coordinator.adbo.enums.ProductType;
import com.rbs.pbbdhb.coordinator.adbo.mapper.AdboSwitchRepaymentRequestMapper;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.SubAccount;
import com.rbs.pbbdhb.coordinator.adbo.model.account.stp.TimePeriod;
import com.rbs.pbbdhb.coordinator.adbo.model.product.Product;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AboSwitchRepaymentSubAccountResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.repaymentCalculator.AdboSwitchRepaymentResponse;
import com.rbs.pbbdhb.coordinator.adbo.request.MortgageQuoteRequest;
import com.rbs.pbbdhb.coordinator.adbo.request.MortgageQuoteSubAccountRequest;
import com.rbs.pbbdhb.coordinator.adbo.response.MortgageQuoteResponse;
import com.rbs.pbbdhb.coordinator.adbo.response.MortgageQuoteSubAccount;
import com.rbs.pbbdhb.coordinator.adbo.response.MortgageQuoteSubAccount.MortgageQuoteSubAccountBuilder;
import com.rbs.pbbdhb.coordinator.adbo.service.ApiService;
import com.rbs.pbbdhb.coordinator.adbo.service.MortgageQuoteService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class MortgageQuoteServiceImpl implements MortgageQuoteService {

  private final AdboCaseDetailsDao adboCaseDetailsDao;
  private final ApiService apiService;
  private final AdboSwitchRepaymentRequestMapper adboSwitchRepaymentRequestMapper;

  @Override
  public MortgageQuoteResponse getMortgageQuoteDetails(String accountNumber) {
    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);

    Product selectedProduct = getSelectedProduct(adboCaseDetails);
    BigDecimal interestRate = BigDecimal.valueOf(selectedProduct.getInitialInterestRate());
    AdditionalBorrowingCalculator calculator = adboCaseDetails.getAdditionalBorrowingCalculator();
    AdboSwitchRepaymentResponse adboSwitchRepaymentResponse = apiService.getAdboSwitchMonthlyPayments(
        adboSwitchRepaymentRequestMapper.map(calculator, interestRate, getProductFeeIfApplicable(adboCaseDetails)));
    Map<String, BigDecimal> newMonthlyPaymentsBySubAccountNumber = adboSwitchRepaymentResponse.getSubAccountRepaymentDetails().stream()
        .collect(
            Collectors.toMap(AboSwitchRepaymentSubAccountResponse::getSubAccountNumber,
                s -> (s.getSubAccountNumber().equals(ADBO_SUB_ACCOUNT_NUMBER) && nonNull(getProductFeeIfApplicable(adboCaseDetails)))
                    ? s.getRepaymentAmountWithProductFee()
                    : s.getRepaymentAmountWithoutProductFee()));

    return MortgageQuoteResponse.builder()
        .sequenceNumber(calculator.getSubAccountDetails().stream().mapToInt(SubAccount::getSequenceNumber).max().getAsInt() + 1)
        .interestType(getInterestType(selectedProduct.getProductType()))
        .interestRate(interestRate)
        .newDealEnds(LocalDate.parse(selectedProduct.getProductEndDate(), DATE_FORMATTER))
        .repaymentType(calculator.getRepaymentType())
        .newMonthlyPayment(newMonthlyPaymentsBySubAccountNumber.get(ADBO_SUB_ACCOUNT_NUMBER))
        .remainingTerm(TimePeriod.builder()
            .years(calculator.getRepaymentTermYears())
            .months(calculator.getRepaymentTermMonths())
            .build())
        .currentBalance(selectedProduct.isProductFeeAddedToBorrowing() ? calculator.getBorrowingAmount() + selectedProduct.getProductFee()
            : calculator.getBorrowingAmount())
        .productTerm(selectedProduct.getProductTerm().getYears())
        .productFee(selectedProduct.getProductFee())
        .isProductFeeAddedToMortgage(selectedProduct.isProductFeeAddedToBorrowing())
        .subAccounts(
            calculator.getSubAccountDetails().stream().map(s -> {
              MortgageQuoteSubAccountBuilder subAccountBuilder = MortgageQuoteSubAccount.builder()
                  .sequenceNumber(s.getSequenceNumber())
                  .subAccountNumber(s.getSubAccountNumber())
                  .selectedForSwitch(s.getSelectedForSwitch())
                  .currentDealEnds(s.getCurrentDealEnds())
                  .repaymentType(s.getRepaymentType())
                  .monthlyPayment(s.getMonthlyPayment())
                  .remainingTerm(s.getRemainingTerm())
                  .currentBalance(s.getCurrentBalance());
              if (isTrue(s.getSelectedForSwitch())) {
                subAccountBuilder
                    .interestType(
                        getInterestType(selectedProduct.getProductType()))
                    .interestRate(interestRate)
                    .newDealEnds((LocalDate.parse(selectedProduct.getProductEndDate(), DATE_FORMATTER)))
                    .newMonthlyPayment(newMonthlyPaymentsBySubAccountNumber.get(
                        Integer.toString(s.getSubAccountNumber())))
                    .productTerm(selectedProduct.getProductTerm().getYears())
                    .switchImmediately(s.getSwitchImmediately())
                    .newDealStartDateType(nonNull(s.getSubAccountType()) ? s.getSubAccountType().getNewDealStartDateType() : null);
              } else {
                subAccountBuilder
                    .interestType(InterestType.fromValue(s.getInterestType()))
                    .interestRate(s.getInterestRate())
                    .newMonthlyPayment(s.getMonthlyPayment())
                    .productTerm(s.getProductTerm());
              }
              return subAccountBuilder.build();
            }).collect(toList()))
        .build();
  }

  private InterestType getInterestType(ProductType productType) {
    return ProductType.FIXED.equals(productType) ? InterestType.FIXED : InterestType.TRACKER;
  }

  private Product getSelectedProduct(AdboCaseDetails adboCaseDetails) {
    return adboCaseDetails.getSalesIllustration().getProductDetails().get(0);
  }

  private Integer getProductFeeIfApplicable(AdboCaseDetails adboCaseDetails) {
    Product selectedProduct = getSelectedProduct(adboCaseDetails);
    return selectedProduct.isProductFeeAddedToBorrowing() ? selectedProduct.getProductFee() : null;
  }

  @Override
  public void saveMortgageQuoteDetails(String accountNumber, MortgageQuoteRequest mortgageQuoteRequest) {

    AdboCaseDetails adboCaseDetails = adboCaseDetailsDao.getCaseDetailsByAccountNumber(accountNumber);
    adboCaseDetails.getAdditionalBorrowingCalculator().getSubAccountDetails().forEach(subAccount -> {
      Optional<MortgageQuoteSubAccountRequest> request = mortgageQuoteRequest.getSubAccounts().stream()
          .filter(mortgageQuoteSubAccountRequest ->
              Objects.equals(mortgageQuoteSubAccountRequest.getSequenceNumber(), subAccount.getSequenceNumber())
                  && Objects.equals(mortgageQuoteSubAccountRequest.getSubAccountNumber(), subAccount.getSubAccountNumber()))
          .findFirst();

      request.ifPresent(mortgageQuoteSubAccountRequest -> {
        if (setSwitchImmediatelyFlag(mortgageQuoteSubAccountRequest.getNewDealStartDateType()) != null) {
          subAccount.setSwitchImmediately(setSwitchImmediatelyFlag(mortgageQuoteSubAccountRequest.getNewDealStartDateType()));
        } else {
          subAccount.setSwitchImmediately(mortgageQuoteSubAccountRequest.getSwitchImmediately());
        }
        subAccount.setNewDealStartDateType(mortgageQuoteSubAccountRequest.getNewDealStartDateType());
      });
    });
    adboCaseDetailsDao.save(adboCaseDetails);
  }

  private Boolean setSwitchImmediatelyFlag(NewDealStartDateType newDealStartDateType) {

    switch (newDealStartDateType) {
      case START_IMMEDIATELY:
      case START_IMMEDIATELY_TRACK_AND_SWITCH:
        return Boolean.TRUE;
      case START_AFTER_CURRENT_DEAL:
        return Boolean.FALSE;
      default:
        return null;
    }
  }
}
