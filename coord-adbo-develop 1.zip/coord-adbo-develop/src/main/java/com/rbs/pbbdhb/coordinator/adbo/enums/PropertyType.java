package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum PropertyType {
  BUY_TO_LET("BUY_TO_LET"),
  RESIDENTIAL("RESIDENTIAL");

  String propertyType;

  PropertyType(String propertyType) {
    this.propertyType = propertyType;
  }

  public String getPropertyType() {
    return propertyType;
  }
}
