package com.rbs.pbbdhb.coordinator.adbo.model.borrowingPurpose;

import com.rbs.pbbdhb.coordinator.adbo.entity.abc.borrowingPurpose.AdboAmountDistribution;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class BorrowingPurposeResponse {

  String propertyAddress1;
  List<AdboAmountDistribution> borrowingPurposeDetails;
  Integer totalBorrowingAmount;
}
