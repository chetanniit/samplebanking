package com.rbs.pbbdhb.coordinator.adbo.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KycMessage {

  private String message;
  private String code;
  private Boolean applicant1IdRequired;
  private Boolean applicant2IdRequired;
}
