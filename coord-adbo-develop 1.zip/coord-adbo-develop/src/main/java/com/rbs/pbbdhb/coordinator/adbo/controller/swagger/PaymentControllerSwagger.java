package com.rbs.pbbdhb.coordinator.adbo.controller.swagger;

import com.rbs.pbbdhb.coordinator.adbo.annotations.Account;
import com.rbs.pbbdhb.coordinator.adbo.constants.Constants;
import com.rbs.pbbdhb.coordinator.adbo.constants.Headers;
import com.rbs.pbbdhb.coordinator.adbo.response.PaymentUrlResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;


@Tag(name = "23 - ADBO Payment Url", description = "Returns ADBO Payment url for account number")
public interface PaymentControllerSwagger {

  @Operation(description = "Retrieve ADBO Payment URL", operationId = "getAdboPaymentUrl", summary = "Returns ADBO Payment url for account number", responses = {
      @ApiResponse(responseCode = "200", description = "ADBO Payment url returned successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Boolean.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content)
  })
  ResponseEntity<PaymentUrlResponse> getAdboPaymentUrl(
      @RequestHeader(Headers.ACCOUNT_NUMBER) @Account String accountNumber,
      @Parameter(name = Headers.BRAND, description = Constants.BRAND_DESCRIPTION)
      @RequestHeader(Headers.BRAND) @Valid @Pattern(regexp = "(RBS|rbs|nwb|NWB)", message = "Invalid Brand") String brand,
      @RequestHeader(Headers.CHANNEL) @Valid @Pattern(regexp = "(mobile|ebanking)", message = "Invalid Channel Route") String channelRoute);

}