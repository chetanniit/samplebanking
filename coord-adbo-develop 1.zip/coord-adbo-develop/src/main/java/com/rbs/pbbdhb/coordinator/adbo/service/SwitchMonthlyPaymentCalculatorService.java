package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.response.AdboSwitchMonthlyPaymentsResponse;
import java.math.BigDecimal;

public interface SwitchMonthlyPaymentCalculatorService {
  
  AdboSwitchMonthlyPaymentsResponse getAdboSwitchMonthlyPayments(String accountNumber,
      BigDecimal initialInterestRate);

}
