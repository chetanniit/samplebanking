package com.rbs.pbbdhb.coordinator.adbo.service;

import com.rbs.pbbdhb.coordinator.adbo.model.account.AccountSummaryResponse;

public interface AccountService {

  Boolean getSecondChargeDetails(AccountSummaryResponse accountSummaryResponse);

}
