package com.rbs.pbbdhb.coordinator.adbo.dto;

import com.rbs.pbbdhb.coordinator.adbo.enums.FeePaymentStatus;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
@Builder
public class DashboardFeePaymentDetails {
    /**
     * The status value can be NOT_APPLICABLE,COMPLETE,TODO
     */
    private FeePaymentStatus status;
    /**
     *The enabled field holds boolean value true/false
     * Will set only enabled field value as false when status is NOT a SUBMIT_GMS_STAGE_20 and FeeAction.NO_ACTION otherwise will set true
     */
    private boolean enabled;
}
