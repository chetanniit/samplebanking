package com.rbs.pbbdhb.coordinator.adbo.validator;

import com.google.common.collect.Range;
import com.rbs.pbbdhb.exception.BusinessException;
import java.math.BigDecimal;
import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;

public class AmountRangeValidator {

  public static void validateAmountRange(final String errorMsg, final BigDecimal amount, Range<BigDecimal> paymentRange) {
    if (!paymentRange.contains(amount)) {
      throw new BusinessException(errorMsg, HttpStatus.BAD_REQUEST.value());
    }
  }

  public static void validateAmountRange(final String propertyName, final String errorMsg, final BigDecimal amount,
      Range<BigDecimal> paymentRange, Errors errors) {
    if (!paymentRange.contains(amount)) {
      errors.rejectValue(propertyName, "not_in_range", errorMsg);
    }
  }
}
