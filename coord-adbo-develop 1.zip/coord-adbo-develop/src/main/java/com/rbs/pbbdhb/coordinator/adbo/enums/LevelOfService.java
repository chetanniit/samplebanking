package com.rbs.pbbdhb.coordinator.adbo.enums;

public enum LevelOfService {

  EXECUTION_ONLY,
  ADVISED,
  ADVICE_REJECTED,
  NON_ADVISED

}
