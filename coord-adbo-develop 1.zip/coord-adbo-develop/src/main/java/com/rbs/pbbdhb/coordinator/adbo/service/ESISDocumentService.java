package com.rbs.pbbdhb.coordinator.adbo.service;


import com.rbs.pbbdhb.coordinator.adbo.model.DocumentPaymentFlagsResponse;
import com.rbs.pbbdhb.coordinator.adbo.model.salesEsisDto.ESISDocument;

public interface ESISDocumentService {

  ESISDocument generateSalesEsisRequestForAdditionalBorrowing(String accountNumber);

  ESISDocument generateSalesEsisRequestForProductSwitch(String accountNumber);

  ESISDocument getSalesEsisRequest(String documentName);

  DocumentPaymentFlagsResponse getFlag(String accountNumber);
}
