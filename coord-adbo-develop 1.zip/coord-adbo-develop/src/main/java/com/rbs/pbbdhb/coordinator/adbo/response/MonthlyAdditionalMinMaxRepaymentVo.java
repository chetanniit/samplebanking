package com.rbs.pbbdhb.coordinator.adbo.response;


import com.rbs.pbbdhb.coordinator.adbo.enums.BrandEnum;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MonthlyAdditionalMinMaxRepaymentVo implements Serializable {

  private static final long serialVersionUID = 1L;
  private BrandEnum brand;
  private MinMaxRepaymentVo capitalAndInterest;
}



