package com.rbs.pbbdhb.coordinator.adbo.dto;

import com.rbs.pbbdhb.coordinator.adbo.enums.SubmissionStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class ProductSwitchPostSubmission {

  private String brand;
  private String channel;
  private String route;
  private String accountNumber;
  private String applicationId;
  private String errorMessage;
  private String applicationSequenceNumber;
  private String applicationState;
  private String documentUrl;
  private SubmissionStatus status;
  private Property property;
}
