package com.rbs.pbbdhb.coordinator.adbo.service.impl.journeyValidation;

import com.rbs.pbbdhb.coordinator.adbo.enums.ValidationRuleResultCode;
import com.rbs.pbbdhb.coordinator.adbo.model.journeyValidation.JourneyValidation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class BuyToLetValidator extends AbstractValidator {

  public BuyToLetValidator(@Value("${journeyValidator.priority.buyToLet}") int priority) {
    super(priority, ValidationRuleResultCode.FAILED_DUE_TO_HAS_BUY_TO_LET_MORTGAGE);
  }

  @Override
  public boolean test(JourneyValidation journeyValidation) {
    return journeyValidation.getAccountSummaryApiResponse().getBuyToLet();
  }
}
