package com.rbs.pbbdhb.coordinator.adbo.entity.income.enums;


public enum EmployedBasis {

  PERMANENT("PERMANENT"),
  CONTRACTOR("CONTRACTOR"),
  TEMPORARY("TEMPORARY");


  private final String label;

  EmployedBasis(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }


}
