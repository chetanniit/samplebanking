# Spring Boot MicroService coord-adbo

## Brief Overview :
This Serves as a coordinator micro service for the Additional Borrowing functionality.

## API's
```
```

## Build the application
```shell script
mvn clean install
```

## Running unit tests
```shell script
mvn clean test
```

## Code Formatting

It is recommended that all developers use a consistent code formatter.

## Setting up code autoformatting in IntelliJ

1. File > Settings > Editor > Code Style, then Settings > Import Scheme > IntelliJ IDEA code style
   XML.
2. Select `intellij-style.xml` from the root of the project
3. Install the Save Actions plugin and restart IntelliJ
4. File > Settings > Tools > Actions on Save
5. Enable `Activate save actions on save`, `Optimize imports`, `Reformat code` (Changed lines for
   legacy code)

