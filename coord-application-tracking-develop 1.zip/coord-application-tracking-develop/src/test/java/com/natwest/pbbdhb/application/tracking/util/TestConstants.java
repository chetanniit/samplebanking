/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import java.util.Arrays;
import java.util.List;

public class TestConstants {

    public static final String AMBER = "AMBER";
    public static final String RED = "RED";
    public static final String GREEN = "GREEN";
    public static final String GREY = "GREY";
    public static final String ACTION_REQUIRED = "Action required";
    public static final String NO_ACTION_REQUIRED = "No Action required";
    public static final String COMPLETION = "Completion";
    public static final String AMBER_DESC = " is in progress";
    public static final String RED_DESC = "Decline needs more information";
    public static final String GREEN_DESC = " is completed";
    public static final String GREY_DESC = " is not started";
    public static final String ACTION_REQUIRED_DESC = "Action is required";
    public static final String NO_ACTION_REQUIRED_DESC = "No action is required";
    public static final String COMPLETION_DESC = "Application is completed";
    public static final String OFFER = "Offer";
    public static final String OFFER_DESC = "Your application is under Offer";
    public static final String STAGE_COMPLETION_DESC = "Your application is under Completion";
    public static final String DECLINE = "Decline";
    public static final String DECLINE_DESC = "Your application is Declined";

    public static final String APPLICATION_DETAILS_REQUEST_PROCESSING_FAIL_ERROR_MESSAGE =
            "Error occurred while processing the request,please try again later.";

    public static final String APPLICANT_PLACE_HOLDER_REPLACEMENT_TEXT =
            "We require UNLBMJ BPPK's last three months payslips. Please upload the document(s) or email them to intermediarydocs@natwest.com including the mortgage reference number";
    public static final String HOLDING_STAGE = "Holding Stage";
    public static final String JOINT_APPLICANT_PLACE_HOLDER_TEXT =
            "We require ${joint-applicant}'s last three months payslips. Please upload the document(s) or email them to intermediarydocs@natwest.com including the mortgage reference number";
    public static final String APPLICANT_PLACE_HOLDER_TEXT =
            "We require ${applicant}'s last three months payslips. Please upload the document(s) or email them to intermediarydocs@natwest.com including the mortgage reference number";
    public static final String NO = "NO";
    public static final String ASSESSMENT_VALUATION = "Assessment + Valuation";
    public static final String ASSESSMENT_AND_VALUATION = "AssessmentAndValuation";

    public static final String APPLICATION_DETAILS_NULL = "applicationDetails is null";
    public static final String STAGE_HISTORY_CODE_NULL = "stageHistoryCode is null";
    public static final String STATUS_NULL = "status is null";

    public static final String N = "N";
    public static final String Y = "Y";
    public static final String A = "A";
    public static final String STAR = "*";
    public static final String T = "T";
    public static final String B = "B";
    public static final String C = "C";
    public static final String S = "S";
    public static final String P = "P";
    public static final String H = "H";
    public static final String X = "X";
    public static final String AV = "AV";
    public static final String AUTOMATED_VALUATION = "Avm - Automated Valuation";
    public static final String STANDARD_MORTGAGE_VALUATION = "Standard Mortgage Valuation";
    public static final String TRIED_FOR_APPOINTMENT = "Tried for an appointment";
    public static final String ASSIGNED_TO_SURVEYOR = "Assigned to surveyor";
    public static final String BOOKED_APPOINTMENT = "Booked Appointment";
    public static final String CANCELLED = "Cancelled";
    public static final String SUSPENDED = "Suspended";
    public static final String BOOKING_MADE = "Booking made";
    public static final String IGNORED = "Ignored";
    public static final String PANELLED = "Panelled";
    public static final String APPOINTMENT_HELD = "Appointment Held";
    public static final String MANUAL_ALLOCATION = "Manual Allocation";
    public static final String MANUAL_ALLOCATION_NOTES =
            "Manual allocation to S C Ruggles,MRICS (Connells)";
    public static final String VALUATION_REPORT_RECEIVED = "Valuation Report Received";

    public static final String RED_MILESTONE = "${milestoneName} needs more information";
    public static final String AMBER_MILESTONE = "${milestoneName} is in progress";
    public static final String GREEN_MILESTONE = "${milestoneName} is completed";
    public static final String GREY_MILESTONE = "${milestoneName} is not started";
    public static final String OFFER_AMBER_DESC = "Offer is in progress";
    public static final String ASSESMENT_VALUATION_PROGRESS =
            "Assessment + Valuation is in progress";

    public static final String AWAIT = "Await";
    public static final String ASSESS = "Assess";

    public static final String APPLICATION_SUPPRESS_STAGE_CODE_VALUES = "80,84,85,90";
    public static final List<String> APPLICATION_SUPPRESS_STAGE_CODE_LIST =
            Arrays.asList(APPLICATION_SUPPRESS_STAGE_CODE_VALUES.split(",", -1));
    public static final int COMPLETED_APPLICATION_SUPPRESS_DAYS = 2;
    public static final int DECLINED_APPLICATION_SUPPRESS_DAYS = 14;
    public static final int REFUSED_APPLICATION_SUPPRESS_DAYS = 14;
    public static final String COMPLETED_APPLICATION_SUPPRESS_MESSAGE =
            "Error 451 : Your client's application has been completed";
    public static final String SOFT_DECLINED_APPLICATION_SUPPRESS_MESSAGE =
            "Error 451 : We are sorry but on this occasion we are unable to offer your client a mortgage. If you require further information or wish to appeal this decision please email intermediarydocs@natwest.com including the mortgage reference number";
    public static final String DECLINED_APPLICATION_SUPPRESS_MESSAGE =
            "Error 451 : We are sorry but on this occasion we are unable to offer your client a mortgage. Thank you for considering NatWest for your mortgage application";
    public static final String REFUSED_APPLICATION_SUPPRESS_MESSAGE =
            "Error 451 : Your client's mortgage application has now been closed. Thank you for considering NatWest for your mortgage application";
    public static final String APPLICATION_COMPLETED_STATUS_CODE = "C";
    public static final String APPLICATION_DECLINED_STATUS_CODE = "D";
    public static final String APPLICATION_REFUSED_STATUS_CODE = "R";
    public static final String STAGE_80 = "80";
    public static final String STAGE_84 = "84";
    public static final String STAGE_85 = "85";
    public static final String STAGE_90 = "90";
    public static final String STAGE_00 = "0";

    public static final String FORBIDDEN_ERROR_MESSAGE =
            "Error 403 : Authentication failed. Please try again later. If the problem persists, please contact with our LiveTALK team for any technical help.";
    public static final String NO_DESCRIPTION_AVAILABLE = "No Description Available";
    public static final String DEFAULT_TASK_CODE = "DEF";

    public static final String CSP_VALUE =
            "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self' data: http://www.w3.org/; font-src 'self'; style-src 'self' 'unsafe-inline';base-uri 'self';form-action 'self'";
    public static final String NO_CACHE = "no-cache";
    public static final String PRAGMA = "Pragma";
    public static final String CACHE_CONTROL = "Cache-control";
    public static final String CONTENT_SECURITY_POLICY = "Content-Security-Policy";

    public static final String OPEN = "Open";
    public static final String CLOSE = "Close";

    public static final String VALUATION_INFORMATION_NULL = "valuationInformation is null";

    public static final String INTEREST_ONLY = "Interest Only";
    public static final String CAPITAL_AND_INTEREST = "Capital and Interest";
    public static final String PART_AND_PART = "Part n Part";

    public static final String MILESTONE_DECLINED_OR_CANCELLED_DESCRIPTION = "Declined/Cancelled";

    public static final String GLOBAL_SUB_STATUS = "SubStatus";
    public static final String GLOBAL_SUB_STATUS_CANCELLED_DESCRIPTION = "Application is cancelled";
    public static final String GLOBAL_SUB_STATUS_DECLINED_DESCRIPTION = "Application is declined";
    public static final String SUB_STATUS_CANCELLED = "Cancelled";
    public static final String SUB_STATUS_DECLINED = "Declined";

    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mmxxx";
    public static final String ARO = "ARO";
    public static final String SRP = "SRP";

    public static final String PRODUCT_SWITCH_STATUS = "Product Switch";
    public static final String PRODUCT_SWITCH_STATUS_DESCRIPTION =
            "Your application is at Product Switch";

    public static final String PRODUCT_SWITCH_CANCELLED = "ProductSwitchCancelled";
    public static final String PRODUCT_SWITCH_CANCELLED_DESCRIPTION =
            "Your client's application has been cancelled";
}
