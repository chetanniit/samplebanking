/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.stepdefs;

import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.GET_APPLICATION_DETAILS_INPUT_JSON;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberTestProperties.getTestEnv;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberConfigReader;
import com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.application.tracking.jwt.AuthCredentialHolder;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import io.restassured.specification.RequestSpecification;

import java.io.*;
import java.util.*;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.junit.jupiter.api.Assertions;
import org.springframework.util.ResourceUtils;


@Slf4j
public class ApiTestUtil {

    private static final String PROXY_PASSWORD = "FB@fgYt6kqqUx4ln";
    private static final String PROXY_USERNAME = "SVC-HBOAPITeamCity";
    private static final String PROXY_PORT = "8080";
    private static final String PROXY_HOST = "userproxy.rbsgrp.net";
    private static int header_count = 0;

    // Commented the Code as its used for apigee implementation
//    public static JsonNode getInputsAsJsonNode(String inputFileName) throws IOException {
//        String testInputPath = getTestEnv().getTestInputPath();
//        Assertions.assertNotNull(testInputPath, ApiTestConstants.Errors.TEST_INPUT_PATH_IS_NULL);
//        String inputFilePath = testInputPath.concat(inputFileName);
//        JsonNode inputsAsJsonNode = new ObjectMapper().readTree(new File(inputFilePath));
//        String inputsMissingErrorMessage =
//                String.format(
//                        ApiTestConstants.Errors.INPUTS_MISSING_FOR,
//                        inputsAsJsonNode.get(PATH).asText());
//        Assertions.assertNotNull(inputsAsJsonNode, inputsMissingErrorMessage);
//        return inputsAsJsonNode;
//    }

    public static JsonNode getInputsAsJsonNode(String inputFileName) throws IOException {
        String testInputPath = CucumberTestProperties.getTestInputPath();
        Assertions.assertNotNull(testInputPath, ApiTestConstants.Errors.TEST_INPUT_PATH_IS_NULL);
        String inputFilePath = testInputPath.concat(inputFileName);
        JsonNode inputsAsJsonNode = new ObjectMapper().readTree(new File(inputFilePath));
        Assertions.assertNotNull(
                inputsAsJsonNode,
                String.format(ApiTestConstants.Errors.INPUTS_MISSING_FOR, inputsAsJsonNode.get(PATH).asText()));
        return inputsAsJsonNode;
    }

    public static void prepareRequestWithBearerToken(
            RequestSpecification request, AuthCredentialHolder authCredentialHolder) {
        try {
            ProxySpecification proxySpecification =
                    new ProxySpecification(PROXY_HOST, new Integer(PROXY_PORT), "http")
                            .withAuth(PROXY_USERNAME, PROXY_PASSWORD);
            request.header("client_id", authCredentialHolder.getOauthPayload().getSub())
                    .header("apiKey", authCredentialHolder.getApiKey())
                    .keyStore(
                            ResourceUtils.getFile(
                                    authCredentialHolder.getApiKeystore().getLocation()),
                            authCredentialHolder.getApiKeystore().getPassword())
                    .trustStore(
                            ResourceUtils.getFile(
                                    authCredentialHolder.getApiKeystore().getLocation()),
                            authCredentialHolder.getApiKeystore().getPassword())
                    .proxy(proxySpecification)
                    .auth()
                    .oauth2(authCredentialHolder.getBearerToken());
        } catch (FileNotFoundException e) {
            log.error("file not found", e);
        }
    }

    public static void createRequestForInputParams(
            JsonNode testInput, RequestSpecification request) {
        // Commented the Code as its used for apigee implementation
       // if (!CucumberTestProperties.getTestEnv().isAuthEnabled()) {
            JsonNode brand = testInput.get(BRAND);
            if (brand != null && !"null".equals(brand.asText())) {
                request.header(BRAND, brand.asText());
            } else {
                JsonNode isSkipBrandNode = testInput.get(IS_SKIP_BRAND);
                boolean isSkipBrand = false;
                if (isSkipBrandNode != null) {
                    isSkipBrand = isSkipBrandNode.asBoolean(false);
                }
                if (!isSkipBrand) {
                    request.header(BRAND, BRAND_NWB);
                }
            }
       // }

        JsonNode applicantDob = testInput.get(APPLICANT_DOB);
        if (applicantDob != null && !"null".equals(applicantDob.asText())) {
            request.queryParam(APPLICANT_DOB, applicantDob.asText());
        }

        JsonNode applicantFirstName = testInput.get(APPLICANT_FIRST_NAME);
        if (applicantFirstName != null && !"null".equals(applicantFirstName.asText())) {
            request.queryParam(APPLICANT_FIRST_NAME, applicantFirstName.asText());
        }

        JsonNode applicantLastName = testInput.get(APPLICANT_LAST_NAME);
        if (applicantLastName != null && !"null".equals(applicantLastName.asText())) {
            request.queryParam(APPLICANT_LAST_NAME, applicantLastName.asText());
        }

        JsonNode brokerEmailId = testInput.get(BROKER_EMAIL_ID);
        if (brokerEmailId != null && !"null".equals(brokerEmailId.asText())) {
            request.queryParam(BROKER_EMAIL_ID, brokerEmailId.asText());
        }

        JsonNode brokerUserName = testInput.get(BROKER_USER_NAME);
        if (brokerUserName != null && !"null".equals(brokerUserName.asText())) {
            request.queryParam(BROKER_USER_NAME, brokerUserName.asText());
        }

        JsonNode brokerFirstName = testInput.get(BROKER_FIRST_NAME);
        if (brokerFirstName != null && !"null".equals(brokerFirstName.asText())) {
            request.queryParam(BROKER_FIRST_NAME, brokerFirstName.asText());
        }

        JsonNode brokerLastName = testInput.get(BROKER_LAST_NAME);
        if (brokerLastName != null && !"null".equals(brokerLastName.asText())) {
            request.queryParam(BROKER_LAST_NAME, brokerLastName.asText());
        }

        JsonNode brokerPostcode = testInput.get(BROKER_POST_CODE);
        if (brokerPostcode != null && !"null".equals(brokerPostcode.asText())) {
            request.queryParam(BROKER_POST_CODE, brokerPostcode.asText());
        }

        JsonNode dateRange = testInput.get(DATE_RANGE);
        if (dateRange != null && !"null".equals(dateRange.asText())) {
            request.queryParam(DATE_RANGE, dateRange.asText());
        }

        JsonNode fcaNumber = testInput.get(FCA_NUMBER);
        if (fcaNumber != null && !"null".equals(fcaNumber.asText())) {
            request.queryParam(FCA_NUMBER, fcaNumber.asText());
        }

        JsonNode firmPostcode = testInput.get(FIRM_POSTCODE);
        if (firmPostcode != null && !"null".equals(firmPostcode.asText())) {
            request.queryParam(FIRM_POSTCODE, firmPostcode.asText());
        }

        JsonNode pageNumber = testInput.get(PAGE_NUMBER);
        if (pageNumber != null && !"null".equals(pageNumber.asText())) {
            request.queryParam(PAGE_NUMBER, pageNumber.asText());
        }

        JsonNode propertyPostcode = testInput.get(PROPERTY_POSTCODE);
        if (propertyPostcode != null && !"null".equals(propertyPostcode.asText())) {
            request.queryParam(PROPERTY_POSTCODE, propertyPostcode.asText());
        }

        JsonNode resultsPerPage = testInput.get(RESULT_PER_PAGE);
        if (resultsPerPage != null && !"null".equals(resultsPerPage.asText())) {
            request.queryParam(RESULT_PER_PAGE, resultsPerPage.asText());
        }

        JsonNode sortBy = testInput.get(SORT_BY);
        if (sortBy != null && !"null".equals(sortBy.asText())) {
            request.queryParam(SORT_BY, sortBy.asText());
        }

        JsonNode sortOrder = testInput.get(SORT_ORDER);
        if (sortOrder != null && !"null".equals(sortOrder.asText())) {
            request.queryParam(SORT_ORDER, sortOrder.asText());
        }

        JsonNode referenceNumber = testInput.get(REFERENCE_NUMBER);
        if (referenceNumber != null && !"null".equals(referenceNumber.asText())) {
            request.pathParam(REFERENCE_NUMBER, referenceNumber.asText());
        }

        JsonNode userEmailId = testInput.get(USER_EMAIL_ID);
        if (userEmailId != null && !"null".equals(userEmailId.asText())) {
            request.queryParam(USER_EMAIL_ID, userEmailId.asText());
        }

        JsonNode userFirmFCANumber = testInput.get(USER_FIRM_FCA_NUMBER);
        if (userFirmFCANumber != null && !"null".equals(userFirmFCANumber.asText())) {
            request.queryParam(USER_FIRM_FCA_NUMBER, userFirmFCANumber.asText());
        }

        JsonNode userFirstName = testInput.get(USER_FIRST_NAME);
        if (userFirstName != null && !"null".equals(userFirstName.asText())) {
            request.queryParam(USER_FIRST_NAME, userFirstName.asText());
        }

        JsonNode userLastName = testInput.get(USER_LAST_NAME);
        if (userLastName != null && !"null".equals(userLastName.asText())) {
            request.queryParam(USER_LAST_NAME, userLastName.asText());
        }

        JsonNode userPrincipleFCANumber = testInput.get(USER_PRINCIPLE_FCA_NUMBER);
        if (userPrincipleFCANumber != null && !"null".equals(userPrincipleFCANumber.asText())) {
            request.queryParam(USER_PRINCIPLE_FCA_NUMBER, userPrincipleFCANumber.asText());
        }

        JsonNode userRole = testInput.get(USER_ROLE);
        if (userRole != null && !"null".equals(userRole.asText())) {
            request.queryParam(USER_ROLE, userRole.asText());
        }
    }

    public static String getJWTToken(String environment, String serviceName) throws JsonProcessingException {
        String testInput = "{" +
                "  \"serviceBeingTested\": \"" + serviceName + "\"," +
                "  \"expiryInMinutes\": 60," +
                "  \"isMSGenerated\": false" +
                "}";

        RestAssured.baseURI = CucumberTestProperties.getJWTTokenURI().replace("<environment>", environment);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, "application/json")
                .accept("*/*")
                .body(testInput);
        System.out.println(testInput);
        Response response = request.post();
        return (new ObjectMapper().readTree(response.asString())).get("iam-claimsetjwt").asText();
    }

    public static void convertJsonNodeToCSVFormat(JsonNode inputName) throws IOException {
        FileReader reader = new FileReader("src/test/resources/config/convertToCSVFields.properties");
        Properties props = new Properties();
        props.load(reader);
        final Set<String> keys = props.stringPropertyNames();
        PrintStream out = new PrintStream(
                new FileOutputStream("src/test/resources/config/convertToCSVResults.csv", true), true);
        if(header_count == 0) {
            String header = "";
            for (final String key : keys) {
                header += key + ",";
            }
            out.print(header);
            header_count++;
        }
        String values = "";
        for (final String key : keys) {
            final String value = props.getProperty(key);
            String propertyValue = inputName.at(value).asText();
            values += propertyValue + ",";
        }
        out.println();
        out.print(values);
    }
}
