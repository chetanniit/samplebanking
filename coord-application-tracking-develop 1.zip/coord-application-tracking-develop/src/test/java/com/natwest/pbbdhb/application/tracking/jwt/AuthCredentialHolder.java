/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.jwt;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AuthCredentialHolder {
    private String bearerToken;
    private String apiKey;
    private OauthPayload oauthPayload;
    private OauthHeader oauthHeader;
    private ApiKeystore apiKeystore;

    @Data
    @ToString
    public static class OauthHeader {
        private String alg;
        private String typ;
        private String kid;
    }

    @Data
    @ToString
    public static class OauthPayload {
        private String sub;
        private String iss;
        private String scope;
        private String exp;
        private String aud;
    }

    @Data
    @ToString
    public static class ApiKeystore {
        private String location;
        private String password;
        private String signingAlias;
    }
}
