/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.controller;

import static com.natwest.pbbdhb.application.tracking.util.TestConstants.CACHE_CONTROL;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.CONTENT_SECURITY_POLICY;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.CSP_VALUE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.NO_CACHE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRAGMA;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.exception.ApplicationDetailsProcessFailException;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.model.exception.ErrorResponse;
import com.natwest.pbbdhb.application.tracking.model.exception.LegalReasonException;
import com.natwest.pbbdhb.application.tracking.service.ApplicationTrackingService;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import javax.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

@ExtendWith(SpringExtension.class)
@WebMvcTest(
        value = ApplicationTrackingController.class,
        properties = {"spring.profiles.active=test"})
@DisplayName("ApplicationTrackingController - MVC Test")
class ApplicationTrackingControllerTest {

    public static final String NWB_BRAND = "NWB";

    @Autowired private MockMvc mockMvc;

    @Autowired private ObjectMapper objectMapper;

    @MockBean private ErrorMessageConfigReader errorMessageConfigReader;

    @MockBean private ApplicationTrackingService applicationTrackingService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetApplications() throws Exception {
        ApplicationRequest applicationRequest = getApplicationRequest();
        when(applicationTrackingService.getApplications(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationsResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", NWB_BRAND)
                                        .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationsNegative() throws Exception {
        ApplicationRequest applicationRequest = getApplicationRequest();
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", "nob")
                                        .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        verifyNoInteractions(applicationTrackingService);
    }
    
    
    @Test
    void testGetApplicationList() throws Exception {
        ApplicationListRequest applicationRequest = getApplicationListRequest();
        when(applicationTrackingService.getApplicationList(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationListResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/applicationList")
                                        .header("brand", NWB_BRAND)
                                        .flashAttr("applicationListRequest", applicationRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationListNegative() throws Exception {
        ApplicationListRequest applicationRequest = getApplicationListRequest();
        
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applicationList")
                                        .header("brand", "nob")
                                        .flashAttr("applicationListRequest", applicationRequest))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        verifyNoInteractions(applicationTrackingService);
    }

    @Test
    void testGetApplicationDetails() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(getApplicationDetailsResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationDetailsFrmNameValidations() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(getApplicationDetailsResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationsValidations() throws Exception {
        ApplicationRequest applicationRequest = getValidApplicationRequestWithSpecialChar();
        when(applicationTrackingService.getApplications(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationsResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", NWB_BRAND)
                                        .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationsFrmNameValidations() throws Exception {
        ApplicationRequest applicationRequest = getValidApplicationRequestWithSpecialChar();
        when(applicationTrackingService.getApplications(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationsResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", NWB_BRAND)
                                        .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationsInvalidSpecialChar() throws Exception {
        ApplicationRequest applicationRequest = getInValidApplicationRequestWithSpecialChar();
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", NWB_BRAND)
                                        .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationTrackingService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationsFirstNameMinChar() throws Exception {
        ApplicationRequest applicationRequest = getInValidApplicationRequestWithSpecialChar();
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", NWB_BRAND)
                                        .param("applicantFirstName", "C")
                                        .param("applicantLastName", APPLICANT_LAST_NAME)
                                        .param("brokerEmailId", BROKER_EMAIL_ID)
                                        .param("brokerFirstName", "C")
                                        .param("brokerLastName", BROKER_LAST_NAME)
                                        .param("brokerPostcode", BROKER_POST_CODE)
                                        .param("fcaNumber", FCA_NUMBER)
                                        .param("firmName", FIRM_NAME)
                                        .param("firmPostcode", FIRM_POST_CODE))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationTrackingService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationsLastNameMinChar() throws Exception {
        ApplicationRequest applicationRequest = getInValidApplicationRequestWithSpecialChar();
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", NWB_BRAND)
                                        .param("applicantFirstName", APPLICANT_FIRST_NAME)
                                        .param("applicantLastName", "C")
                                        .param("brokerEmailId", BROKER_EMAIL_ID)
                                        .param("brokerFirstName", BROKER_FIRST_NAME)
                                        .param("brokerLastName", BROKER_LAST_NAME)
                                        .param("brokerPostcode", BROKER_POST_CODE)
                                        .param("fcaNumber", FCA_NUMBER)
                                        .param("firmName", FIRM_NAME)
                                        .param("firmPostcode", FIRM_POST_CODE))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationTrackingService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationDetailsWithInvalidAdminDetails() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getInvalidApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(getApplicationDetailsResponse());
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationTrackingService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testBrokerValidationException() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(BrokerValidationException.class);

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isUnauthorized())
                        .andReturn();

        assertEquals(401, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleConstraintViolationException() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getInvalidApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(ConstraintViolationException.class);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleApplicationDetailsException() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(ApplicationDetailsProcessFailException.class);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isInternalServerError())
                        .andReturn();

        assertEquals(500, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleLegalReasonException() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(LegalReasonException.class);

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isUnavailableForLegalReasons())
                        .andReturn();

        assertEquals(451, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleHttpServerErrorException() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(new HttpServerErrorException(HttpStatus.SERVICE_UNAVAILABLE));

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isServiceUnavailable())
                        .andReturn();

        assertEquals(503, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleHttpServerErrorExceptionWithInternalServerError() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isInternalServerError())
                        .andReturn();

        assertEquals(500, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleHttpClientErrorExceptionWithForbidden() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(new HttpClientErrorException(HttpStatus.FORBIDDEN));

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isForbidden())
                        .andReturn();

        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleHttpClientErrorExceptionWithConflict() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(new HttpClientErrorException(HttpStatus.CONFLICT));

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isConflict())
                        .andReturn();

        assertEquals(409, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleHttpClientErrorExceptionWithPayloadTooLarge() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(new HttpClientErrorException(HttpStatus.PAYLOAD_TOO_LARGE));

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isPayloadTooLarge())
                        .andReturn();

        assertEquals(413, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleHttpClientErrorExceptionWithUnauthorized() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();

        when(applicationTrackingService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));

        MvcResult result =
                mockMvc.perform(
                                get("/applicationDetails/" + REFERENCE_NUMBER)
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isUnauthorized())
                        .andReturn();

        assertEquals(401, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testHandleMissingRequestHeaderException() throws Exception {
        MvcResult result =
                mockMvc.perform(get("/applicationDetails/" + REFERENCE_NUMBER))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        ErrorResponse errorResponse =
                objectMapper.readValue(
                        result.getResponse().getContentAsByteArray(), ErrorResponse.class);
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(MISSING_BRAND, errorResponse.getErrorMessages().get(0));
        verifyNoInteractions(applicationTrackingService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationWithInvalidAdminDetails() throws Exception {

        ApplicationRequest applicationRequest = getInvalidAdminApplicationRequest();
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                                get("/applications")
                                        .header("brand", "nwb")
                                        .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        verifyNoInteractions(applicationTrackingService);
    }

    @Test
    void testGetApplicationsWithValidBrokerDetails() throws Exception {
        ApplicationRequest applicationRequest = getApplicationRequest();
        applicationRequest.setBrokerFirstName("Test B2B");
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        MvcResult result =
                mockMvc.perform(
                        get("/applications")
                                .header("brand", "nwb")
                                .flashAttr("applicationRequest", applicationRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetApplicationDetailsWithValidBrokerDetails() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        applicationDetailRequest.setBrokerFirstName("Test B2B");
        when(applicationTrackingService.getApplicationDetail(
                NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(getApplicationDetailsResponse());

        MvcResult result =
                mockMvc.perform(
                        get("/applicationDetails/" + REFERENCE_NUMBER)
                                .header("brand", NWB_BRAND)
                                .flashAttr(
                                        "applicationDetailRequest",
                                        applicationDetailRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testGetCustomerDetailsWithValidBrokerDetails() throws Exception {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        when(applicationTrackingService.getCustomerCaseDetails(
                NWB_BRAND, REFERENCE_NUMBER))
                .thenReturn(getApplicationDetailsResponse());

        MvcResult result =
                mockMvc.perform(
                                get("/application/" + REFERENCE_NUMBER +"/track")
                                        .header("brand", NWB_BRAND)
                                        .flashAttr(
                                                "applicationDetailRequest",
                                                applicationDetailRequest))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }
}
