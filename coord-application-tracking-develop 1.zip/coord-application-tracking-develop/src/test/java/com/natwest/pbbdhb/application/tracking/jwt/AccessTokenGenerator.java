/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.jwt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberTestProperties;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Date;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.springframework.util.ResourceUtils;

@Slf4j
public class AccessTokenGenerator {

    private static final AuthCredentialHolder credholder;
    private static final String jwt;

    static {
        credholder = getCertJsonBean();
        Assertions.assertNotNull(credholder, "Invalid json file found");
        jwt = getJwt();
        Assertions.assertNotNull(jwt, "jwt not created");
    }

    public static AuthCredentialHolder getTokenHolder() {
        String bearerToken = generateBearerToken();
        credholder.setBearerToken(bearerToken);
        return credholder;
    }

    private static String generateBearerToken() {
        String iamTokenUrl = credholder.getOauthPayload().getAud();
        String keystoreLocation = credholder.getApiKeystore().getLocation();
        String keyStorePassword = credholder.getApiKeystore().getPassword();
        try {
            RequestSpecification requestSpecification =
                    RestAssured.given()
                            .log()
                            .all()
                            .keyStore(ResourceUtils.getFile(keystoreLocation), keyStorePassword)
                            .trustStore(ResourceUtils.getFile(keystoreLocation), keyStorePassword)
                            .baseUri(iamTokenUrl);

            Response response =
                    requestSpecification
                            .contentType(ContentType.URLENC)
                            .formParam("client_id", credholder.getOauthPayload().getSub())
                            .formParam("scope", "mortgages-v1:application-tracking")
                            .formParam(
                                    "client_assertion_type",
                                    "urn:ietf:params:oauth:client-assertion-type:jwt-bearer")
                            .formParam("client_assertion", jwt)
                            .formParam("grant_type", "client_credentials")
                            .post();
            return new JSONObject(response.getBody().prettyPrint()).get("access_token").toString();
        } catch (FileNotFoundException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String getJwt() {
        String keystoreLocation = credholder.getApiKeystore().getLocation();
        String keyStorePassword = credholder.getApiKeystore().getPassword();
        try {
            KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
            ks.load(
                    new FileInputStream(ResourceUtils.getFile(keystoreLocation)),
                    keyStorePassword.toCharArray());
            Key privateKey =
                    ks.getKey(
                            credholder.getApiKeystore().getSigningAlias(),
                            keyStorePassword.toCharArray());
            String signedJwt = getJwtString(privateKey);
            log.info("signed JWT = {}", signedJwt);
            return signedJwt;
        } catch (KeyStoreException
                | CertificateException
                | UnrecoverableKeyException
                | IOException
                | NoSuchAlgorithmException e) {
            log.error("jwt generation failed", e);
        }
        return null;
    }

    private static String getJwtString(Key privateKey) {
        JwtBuilder jwtBuilder = Jwts.builder();
        jwtBuilder.setHeaderParam("alg", credholder.getOauthHeader().getAlg());
        jwtBuilder.setHeaderParam("typ", credholder.getOauthHeader().getTyp());
        jwtBuilder.setHeaderParam("kid", credholder.getOauthHeader().getKid());

        jwtBuilder.setSubject(credholder.getOauthPayload().getSub());
        jwtBuilder.setAudience(credholder.getOauthPayload().getAud());
        jwtBuilder.claim("scope", credholder.getOauthPayload().getScope());
        jwtBuilder.setIssuer(credholder.getOauthPayload().getIss());
        Date currentDate = new Date();
        jwtBuilder.setIssuedAt(currentDate);
        jwtBuilder.setExpiration(new Date(currentDate.getTime() + 3600000));
        jwtBuilder.setNotBefore(currentDate);
        jwtBuilder.setId(UUID.randomUUID().toString());
        jwtBuilder.signWith(SignatureAlgorithm.PS256, privateKey);

        return jwtBuilder.compact();
    }

    private static AuthCredentialHolder getCertJsonBean() {
        AuthCredentialHolder authCredentialHolder = null;
        try {
            String jsonFileName =
                    "classpath:jwt/"
                            + CucumberTestProperties.getTestEnv().name().toLowerCase()
                            + ".json";
            ObjectMapper objectMapper = new ObjectMapper();
            authCredentialHolder =
                    objectMapper.readValue(
                            ResourceUtils.getFile(jsonFileName), AuthCredentialHolder.class);
        } catch (Exception e) {
            log.error("unable to read config", e);
        }
        return authCredentialHolder;
    }

    /*public static void main(String[] args) {
        String accessToken = generateBearerToken();
        log.info("access_token: {}", accessToken);
    }*/
}
