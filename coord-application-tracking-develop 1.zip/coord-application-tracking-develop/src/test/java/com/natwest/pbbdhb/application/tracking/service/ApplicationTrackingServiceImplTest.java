/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.GREY;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.ACTION_REQUIRED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.AMBER;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.APPLICATION_DETAILS_REQUEST_PROCESSING_FAIL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.ARO;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.ASSESS;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.AWAIT;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.CAPITAL_AND_INTEREST;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.COMPLETED_APPLICATION_SUPPRESS_MESSAGE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.COMPLETION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DECLINE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DECLINED_APPLICATION_SUPPRESS_MESSAGE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DEFAULT_TASK_CODE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GREEN;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.INTEREST_ONLY;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.N;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.NO;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.NO_ACTION_REQUIRED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PART_AND_PART;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_CANCELLED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_CANCELLED_DESCRIPTION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_STATUS;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.RED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.REFUSED_APPLICATION_SUPPRESS_MESSAGE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.SRP;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.*;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.REFERENCE_NUMBER;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.mapper.ApplicationDetailsResponseMapper;
import com.natwest.pbbdhb.application.tracking.model.GMSTaskDescription;
import com.natwest.pbbdhb.application.tracking.model.MilestoneMappingInformation;
import com.natwest.pbbdhb.application.tracking.model.ValuationStatus;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerDetailValidationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerValidationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.FirmBroker;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.ApplicationDetailsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.CaseHistoryDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.HistoryDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.Products;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.StageHistoryDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.StatusDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.ApplicationDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StageHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StatusInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.GranularTracking;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.valuation.Details;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.valuation.ValuationInformation;
import com.natwest.pbbdhb.application.tracking.model.exception.ApplicationDetailsProcessFailException;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.model.exception.LegalReasonException;
import com.natwest.pbbdhb.application.tracking.service.impl.ApplicationTrackingServiceImpl;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import com.natwest.pbbdhb.application.tracking.util.PropertiesReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;
import org.apache.commons.collections.CollectionUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ApplicationTrackingServiceImplTest {

    private static final String NWB_BRAND = "NWB";

    @InjectMocks private ApplicationTrackingServiceImpl service;

    @Mock private BrokerValidationService brokerValidationService;

    @Mock private BrokerService brokerService;

    @Mock private ApplicationDetailsService applicationDetailsService;

    @Mock private ObjectMapper objectMapper;

    @Mock private ApplicationDetailsResponseMapper applicationDetailsResponseMapper;

    @Mock private GmsStageAndTaskLoader gmsStageAndTaskLoader;

    @Mock private PropertiesReader propertiesReader;

    @Mock private ErrorMessageConfigReader errorMessageConfigReader;

    @Mock private BrokerDetailValidationService brokerDetailValidationService;

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(brokerValidationService, brokerService);
    }

    @Test
    void testGetApplications() {
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        ApplicationRequest applicationRequest = getApplicationRequest();
        when(brokerService.getApplications(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationsResponse());
        service.getApplications(NWB_BRAND, applicationRequest);
        verify(brokerValidationService).validateBroker(any());
        verify(brokerService).getApplications(NWB_BRAND, applicationRequest);
    }
    
    @Test
    void testGetApplicationList() {
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        ApplicationListRequest applicationRequest = getApplicationListRequest();
        when(brokerService.getApplicationList(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationListResponse());
        service.getApplicationList(NWB_BRAND, applicationRequest);
        verify(brokerValidationService).validateBroker(any());
        verify(brokerService).getApplicationList(NWB_BRAND, applicationRequest);
    }

    @Test
    void testGetApplicationsWithInvalidBroker() {
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.FALSE);
        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ApplicationRequest applicationRequest = getApplicationRequest();
        BrokerValidationException brokerValidationException =
                assertThrows(
                        BrokerValidationException.class,
                        () -> service.getApplications(NWB_BRAND, applicationRequest));

        assertEquals(
                "Error Code 401 : Authentication failed. Please contact our technical team on 0345 600 0205.",
                brokerValidationException.getMessage());
        verify(brokerValidationService).validateBroker(any());
        verifyNoInteractions(brokerService);
    }

    @Test
    void testGetApplicationDetailsException() {
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>("{\"productInformation\": [{}]}", HttpStatus.OK));
        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(HttpStatus.NOT_FOUND)));
        when(applicationDetailsService.getValuationInformation(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(
                                        "{\"valuationInformation\": }", HttpStatus.OK)));
        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenReturn(getApplicationDetailsResponse());
        service.getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(brokerValidationService).validateBroker(any());
    }

    @Test
    void testGetApplicationDetailsExceptionWithApplicationInfoFails() {
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR));

        assertNull(
                service.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest));

        verify(brokerValidationService).validateBroker(any());
    }

    @Test
    void testGetApplicationDetailsSuccess() throws IOException {
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>("{\"productInformation\": [{}]}", HttpStatus.OK));
        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK)));
        when(applicationDetailsService.getValuationInformation(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(
                                        "{\"valuationInformation\": }", HttpStatus.OK)));
        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(objectMapper.readValue(anyString(), eq(ApplicationDetailsInfo.class)))
                .thenReturn(getApplicationDetailsInfo());

        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenReturn(getApplicationDetailsResponse());
        service.getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(brokerValidationService).validateBroker(any());
        verify(applicationDetailsService)
                .getApplicationInfo(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getValuationInformation(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
    }

    @Test
    void testGetApplicationDetailsSuccessForProductSwitch() throws JsonProcessingException {
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String applicationInfoResponse = "{\"productInformation\": {\"mortgageTypeCode\": \"I\"}}";
        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>(applicationInfoResponse, HttpStatus.OK));
        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK)));
        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(objectMapper.readValue(applicationInfoResponse, ApplicationDetailsInfo.class))
                .thenReturn(
                        ApplicationDetailsInfo.builder()
                                .productInformation(
                                        ProductInfo.builder().mortgageTypeCode("I").build())
                                .build());

        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenReturn(getApplicationDetailsResponse());
        service.getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(brokerValidationService).validateBroker(any());
        verify(applicationDetailsService)
                .getApplicationInfo(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
    }

    @Test
    void testGetApplicationDetailsSuccessForProductSwitchException()
            throws JsonProcessingException {
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String applicationInfoResponse = "{\"productInformation\": {\"mortgageTypeCode\": \"I\"}}";
        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>(applicationInfoResponse, HttpStatus.OK));
        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK)));
        when(applicationDetailsService.getValuationInformation(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(
                                        "{\"valuationInformation\": }", HttpStatus.OK)));
        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(objectMapper.readValue(applicationInfoResponse, ApplicationDetailsInfo.class))
                .thenThrow(JsonProcessingException.class);

        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenReturn(getApplicationDetailsResponse());
        service.getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(brokerValidationService).validateBroker(any());
        verify(applicationDetailsService)
                .getApplicationInfo(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getValuationInformation(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
    }

    @Test
    void TestMainApplicantPopulateTaskDescription() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        GMSTaskDescription gmsTaskDescription = getTaskDescription();
        when(gmsStageAndTaskLoader.getTaskDescription(
                        applicationDetailsInfo
                                .getApplicationDetails()
                                .getCaseHistory()
                                .get(0)
                                .getCode()))
                .thenReturn(gmsTaskDescription);
        service.populateTaskDescription(applicationDetailsInfo);
        assertEquals(
                APPLICANT_PLACE_HOLDER_REPLACEMENT_TEXT,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getCaseHistory()
                        .get(0)
                        .getDescription());
        assertEquals(APPLICANT_PLACE_HOLDER_TEXT, gmsTaskDescription.getDescription());
        verify(gmsStageAndTaskLoader).getTaskDescription(anyString());
    }

    @Test
    void TestPopulateTaskDescription() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicantInformation().get(0).setIsMainApplicant(NO);
        GMSTaskDescription gmsTaskDescription = getTaskDescription();
        gmsTaskDescription.setDescription(JOINT_APPLICANT_PLACE_HOLDER_TEXT);
        when(gmsStageAndTaskLoader.getTaskDescription(
                        applicationDetailsInfo
                                .getApplicationDetails()
                                .getCaseHistory()
                                .get(0)
                                .getCode()))
                .thenReturn(gmsTaskDescription);
        service.populateTaskDescription(applicationDetailsInfo);
        assertEquals(
                APPLICANT_PLACE_HOLDER_REPLACEMENT_TEXT,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getCaseHistory()
                        .get(0)
                        .getDescription());
        assertEquals(JOINT_APPLICANT_PLACE_HOLDER_TEXT, gmsTaskDescription.getDescription());
        verify(gmsStageAndTaskLoader).getTaskDescription(anyString());
    }

    @Test
    void testPopulateDefaultTaskDescription() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicantInformation().get(0).setIsMainApplicant(NO);
        GMSTaskDescription gmsTaskDescription = getTaskDescription();
        gmsTaskDescription.setDescription(NO_DESCRIPTION_AVAILABLE);
        when(gmsStageAndTaskLoader.getTaskDescription(
                        applicationDetailsInfo
                                .getApplicationDetails()
                                .getCaseHistory()
                                .get(0)
                                .getCode()))
                .thenReturn(null);
        when(gmsStageAndTaskLoader.getTaskDescription(DEFAULT_TASK_CODE))
                .thenReturn(gmsTaskDescription);
        service.populateTaskDescription(applicationDetailsInfo);
        assertEquals(
                NO_DESCRIPTION_AVAILABLE,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getCaseHistory()
                        .get(0)
                        .getDescription());
        verify(gmsStageAndTaskLoader, times(2)).getTaskDescription(anyString());
    }

    @Test
    void testClubStageAndTaskBasedOnMilestone() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithRequiredActions() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();

        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(getOpenCaseHistory()));
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        when(applicationDetailsResponseMapper.toCaseHistory(anyList()))
                .thenReturn(Collections.singletonList(getCaseHistoryDetail(null, AWAIT)));
        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(Boolean.TRUE);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertTrue(CollectionUtils.isNotEmpty(stageHistoryDetailList.get(0).getRequiredActions()));
        assertTrue(CollectionUtils.isEmpty(stageHistoryDetailList.get(0).getCaseHistory()));
        assertEquals(
                "We have received your client's payslips.",
                stageHistoryDetailList.get(0).getRequiredActions().get(0).getDescription());
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithRequiredActions1() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();

        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(getOpenCaseHistory()));
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        when(applicationDetailsResponseMapper.toCaseHistory(anyList()))
                .thenReturn(
                        Collections.singletonList(
                                getCaseHistoryDetail(ZonedDateTime.now(), AWAIT)));
        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(Boolean.TRUE);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertTrue(CollectionUtils.isEmpty(stageHistoryDetailList.get(0).getRequiredActions()));
        assertTrue(CollectionUtils.isNotEmpty(stageHistoryDetailList.get(0).getCaseHistory()));
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithRequiredActions2() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();

        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(getOpenCaseHistory()));
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        when(applicationDetailsResponseMapper.toCaseHistory(anyList()))
                .thenReturn(
                        Collections.singletonList(
                                getCaseHistoryDetail(ZonedDateTime.now(), ASSESS)));
        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(Boolean.FALSE);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertTrue(CollectionUtils.isEmpty(stageHistoryDetailList.get(0).getRequiredActions()));
        assertTrue(CollectionUtils.isNotEmpty(stageHistoryDetailList.get(0).getCaseHistory()));
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithRequiredActions3() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();

        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(getOpenCaseHistory()));
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        when(applicationDetailsResponseMapper.toCaseHistory(anyList()))
                .thenReturn(Collections.singletonList(getCaseHistoryDetail(null, ASSESS)));
        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(Boolean.FALSE);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertTrue(CollectionUtils.isEmpty(stageHistoryDetailList.get(0).getRequiredActions()));
        assertTrue(CollectionUtils.isNotEmpty(stageHistoryDetailList.get(0).getCaseHistory()));
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneSkipWhenAppDetailsNull() {
        ApplicationDetailsInfo applicationDetailsInfo = ApplicationDetailsInfo.builder().build();
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        verifyNoInteractions(gmsStageAndTaskLoader);
        assertEquals(0, stageHistoryDetailList.size());
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneSkipWhenAppInfoDetailsNull() {
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(null, false);
        verifyNoInteractions(gmsStageAndTaskLoader);
        assertEquals(0, stageHistoryDetailList.size());
    }

    @Test
    void testRemoveExcludedStages() {
        ApplicationDetailsInfo applicationDetailsInfo =
                getApplicationDetailsInfoWithExcludedHistories();
        when(gmsStageAndTaskLoader.isAllowedStage("22")).thenReturn(Boolean.TRUE);
        when(gmsStageAndTaskLoader.isAllowedStage("95")).thenReturn(Boolean.FALSE);
        assertEquals(
                "2",
                String.valueOf(
                        applicationDetailsInfo.getApplicationDetails().getStageHistory().size()));
        service.removeExcludedStages("82345671", applicationDetailsInfo, false);
        assertEquals(
                "1",
                String.valueOf(
                        applicationDetailsInfo.getApplicationDetails().getStageHistory().size()));
        verify(gmsStageAndTaskLoader).isAllowedStage("22");
        verify(gmsStageAndTaskLoader).isAllowedStage("95");
    }

    @Test
    void testRemoveExcludedTasks() {
        ApplicationDetailsInfo applicationDetailsInfo =
                getApplicationDetailsInfoWithExcludedHistories();
        when(gmsStageAndTaskLoader.isAllowedTask("A29")).thenReturn(Boolean.TRUE);
        when(gmsStageAndTaskLoader.isAllowedTask("AU1")).thenReturn(Boolean.FALSE);
        assertEquals(
                "2",
                String.valueOf(
                        applicationDetailsInfo.getApplicationDetails().getCaseHistory().size()));
        service.removeExcludedTasks("82345671", applicationDetailsInfo, false);
        assertEquals(
                "1",
                String.valueOf(
                        applicationDetailsInfo.getApplicationDetails().getCaseHistory().size()));
        verify(gmsStageAndTaskLoader).isAllowedTask("A29");
        verify(gmsStageAndTaskLoader).isAllowedTask("AU1");
    }

    @Test
    void testPopulateMilestoneOpenTime() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now().minusDays(7))
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneOpenTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                Collections.singletonList(caseHistory));
        assertEquals(stageHistory.getOpenDateTime(), stageHistoryDetail.getTimeOpen());
    }

    @Test
    void testPopulateMilestoneOpenTimeScenario2() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now().minusDays(7))
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(stageHistory.getOpenDateTime())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneOpenTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                Collections.singletonList(caseHistory));
        assertEquals(caseHistory.getOpenDateTime(), stageHistoryDetail.getTimeOpen());
    }

    @Test
    void testPopulateMilestoneOpenTimeScenario3() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now().minusDays(7))
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneOpenTime(
                stageHistoryDetail, Collections.singletonList(stageHistory), new ArrayList<>());
        assertEquals(stageHistory.getOpenDateTime(), stageHistoryDetail.getTimeOpen());
    }

    @Test
    void testPopulateMilestoneOpenTimeScenario4() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneOpenTime(
                stageHistoryDetail, new ArrayList<>(), Collections.singletonList(caseHistory));
        assertEquals(caseHistory.getOpenDateTime(), stageHistoryDetail.getTimeOpen());
    }

    @Test
    void testPopulateMilestoneCloseTime() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now().minusDays(7))
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                Collections.singletonList(caseHistory),
                false);
        assertEquals(caseHistory.getClosedDateTime(), stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateMilestoneCloseTimeScenario2() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now().minusDays(7))
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(stageHistory.getClosedDateTime())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                Collections.singletonList(caseHistory),
                false);
        assertEquals(stageHistory.getClosedDateTime(), stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateMilestoneCloseTimeScenario3() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now().minusDays(7))
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                new ArrayList<>(),
                false);
        assertEquals(stageHistory.getClosedDateTime(), stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateMilestoneCloseTimeScenario4() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                new ArrayList<>(),
                Collections.singletonList(caseHistory),
                false);
        assertEquals(caseHistory.getClosedDateTime(), stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateMilestoneCloseTimeScenario5() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        CaseHistory caseHistory1 =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now().plusDays(7))
                        .closedDateTime(ZonedDateTime.now().plusDays(7))
                        .build();
        CaseHistory caseHistory2 =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now().plusDays(7))
                        .closedDateTime(null)
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                new ArrayList<>(),
                Arrays.asList(caseHistory1, caseHistory2),
                false);
        assertNull(stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testSetRagStatusMilestoneRED() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_COMPLETION).build();

        when(gmsStageAndTaskLoader.getStatusDescription(RED)).thenReturn(RED_MILESTONE);
        when(gmsStageAndTaskLoader.getStatusDescription(MILESTONE_DECLINE)).thenReturn(DECLINE);

        service.setRagStatus(stageHistoryDetail, "85", false);

        assertEquals(RED, stageHistoryDetail.getRagStatus());
        assertEquals(RED_DESC, stageHistoryDetail.getRagDescription());

        verify(gmsStageAndTaskLoader).getStatusDescription(RED);
        verify(gmsStageAndTaskLoader).getStatusDescription(MILESTONE_DECLINE);
    }

    @Test
    void testSetRagStatusMilestoneGREEN() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(MILESTONE_OFFER)
                        .timeOpen(ZonedDateTime.now())
                        .timeClosed(ZonedDateTime.now())
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(GREEN_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(GREEN, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_OFFER + GREEN_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusMilestoneGREENPreAssessment() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_PRE_ASSESSMENT).build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(GREEN_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(GREEN, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_PRE_ASSESSMENT + GREEN_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusMilestoneAMBER() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(MILESTONE_OFFER)
                        .timeOpen(ZonedDateTime.now())
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(AMBER_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(AMBER, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_OFFER + AMBER_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusMilestoneGREY() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_OFFER).build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(GREY_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(GREY, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_OFFER + GREY_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetSubStatusAttention() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .caseHistory(
                                Collections.singletonList(
                                        CaseHistoryDetail.builder()
                                                .code("A29")
                                                .timeOpen(ZonedDateTime.now())
                                                .build()))
                        .build();
        when(gmsStageAndTaskLoader.isAwaitTask(anyString())).thenReturn(true);
        when(gmsStageAndTaskLoader.getStatusDescription(anyString()))
                .thenReturn(ACTION_REQUIRED_DESC);
        service.setSubStatus(stageHistoryDetail);
        assertEquals(ACTION_REQUIRED, stageHistoryDetail.getSubStatus());
        assertEquals(ACTION_REQUIRED_DESC, stageHistoryDetail.getSubStatusDescription());
        verify(gmsStageAndTaskLoader).isAwaitTask(anyString());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetSubStatusNoAction() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .caseHistory(
                                Collections.singletonList(
                                        CaseHistoryDetail.builder()
                                                .code("R21")
                                                .timeOpen(ZonedDateTime.now())
                                                .build()))
                        .build();

        when(gmsStageAndTaskLoader.getStatusDescription(anyString()))
                .thenReturn(NO_ACTION_REQUIRED_DESC);

        service.setSubStatus(stageHistoryDetail);

        assertEquals(NO_ACTION_REQUIRED, stageHistoryDetail.getSubStatus());
        assertEquals(NO_ACTION_REQUIRED_DESC, stageHistoryDetail.getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(anyString());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusPreAssessmentAmber() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(MILESTONE_PRE_ASSESSMENT)
                        .timeOpen(ZonedDateTime.now())
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(AMBER_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(AMBER, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_PRE_ASSESSMENT + AMBER_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusAssessmentGrey() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_ASSESSMENT).build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(GREY_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(GREY, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_ASSESSMENT + GREY_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusValuationGrey() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(MILESTONE_Valuation).build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(GREY_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(GREY, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_Valuation + GREY_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetRagStatusCompletionGreen() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(MILESTONE_COMPLETION)
                        .timeOpen(ZonedDateTime.now())
                        .timeClosed(ZonedDateTime.now())
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(GREEN_MILESTONE);
        service.setRagStatus(stageHistoryDetail, null, false);
        assertEquals(GREEN, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_COMPLETION + GREEN_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testGetApplicationDetailsExceptionWithValuationInfo() {

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>("{\"productInformation\": [{}]}", HttpStatus.OK));

        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK)));

        when(applicationDetailsService.getValuationInformation(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(HttpStatus.NOT_FOUND)));
        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenReturn(getApplicationDetailsResponse());
        service.getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(brokerValidationService).validateBroker(any());
    }

    @Test
    void testGetApplicationDetailsProcessResponseError() {
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        BrokerValidationResponse brokerValidationResponse = new BrokerValidationResponse();
        brokerValidationResponse.setAllowMortgageBusiness(Boolean.TRUE);
        ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        when(brokerValidationService.validateBroker(any())).thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>("{\"productInformation\": [{}]}", HttpStatus.OK));
        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK)));
        when(applicationDetailsService.getValuationInformation(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(
                                        "{\"valuationInformation\": }", HttpStatus.OK)));

        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenAnswer(
                        invocation -> {
                            throw new IOException();
                        });

        ApplicationDetailsProcessFailException applicationDetailsProcessFailException =
                assertThrows(
                        ApplicationDetailsProcessFailException.class,
                        () ->
                                service.getApplicationDetail(
                                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest));
        assertEquals(
                APPLICATION_DETAILS_REQUEST_PROCESSING_FAIL_ERROR_MESSAGE,
                applicationDetailsProcessFailException.getMessage());
        verify(brokerValidationService).validateBroker(any());
        verify(applicationDetailsService)
                .getApplicationInfo(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getValuationInformation(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
    }

    @Test
    void testRemoveValuationDetailsEntry() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-01-27T13:20+01:00[Europe/London]",
                        A,
                        ASSIGNED_TO_SURVEYOR,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-01-30T11:20+01:00[Europe/London]",
                        STAR,
                        MANUAL_ALLOCATION,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-01-31T01:04+01:00[Europe/London]",
                        T,
                        TRIED_FOR_APPOINTMENT,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-02-01T12:56+01:00[Europe/London]",
                        X,
                        IGNORED,
                        null,
                        null));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .details(valuationDetailsList)
                                        .build())
                        .build();
        when(gmsStageAndTaskLoader.getValuationStatus(A))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(N)
                                .description(ASSIGNED_TO_SURVEYOR)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(STAR))
                .thenReturn(
                        ValuationStatus.builder().status(N).description(MANUAL_ALLOCATION).build());
        when(gmsStageAndTaskLoader.getValuationStatus(T))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(TRIED_FOR_APPOINTMENT)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(X))
                .thenReturn(ValuationStatus.builder().status(N).description(IGNORED).build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        assertEquals(1, applicationDetailsInfo.getValuationInformation().getDetails().size());
        verify(gmsStageAndTaskLoader, times(8)).getValuationStatus(anyString());
    }

    @Test
    void testRemoveValuationDetailsEntryWithMultipleIgnoreStatusDetails() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-01-27T13:20+01:00[Europe/London]",
                        A,
                        ASSIGNED_TO_SURVEYOR,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-01-30T11:20+01:00[Europe/London]",
                        STAR,
                        MANUAL_ALLOCATION,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-01-31T01:04+01:00[Europe/London]",
                        T,
                        TRIED_FOR_APPOINTMENT,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-02-01T12:56+01:00[Europe/London]",
                        X,
                        IGNORED,
                        null,
                        null));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("84042807")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();
        when(gmsStageAndTaskLoader.getValuationStatus(A))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(N)
                                .description(ASSIGNED_TO_SURVEYOR)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(STAR))
                .thenReturn(
                        ValuationStatus.builder().status(N).description(MANUAL_ALLOCATION).build());
        when(gmsStageAndTaskLoader.getValuationStatus(T))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(TRIED_FOR_APPOINTMENT)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(X))
                .thenReturn(ValuationStatus.builder().status(N).description(IGNORED).build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        valuationDetailsList = applicationDetailsInfo.getValuationInformation().getDetails();
        assertEquals(T, valuationDetailsList.get(0).getStatusCode());
        assertEquals(TRIED_FOR_APPOINTMENT, valuationDetailsList.get(0).getStatusDescription());
        assertEquals(1, valuationDetailsList.size());
        verify(gmsStageAndTaskLoader, times(8)).getValuationStatus(anyString());
    }

    @Test
    void testRemoveValuationDetailsEntryWithAutomaticValuationDetail() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        AV,
                        AUTOMATED_VALUATION,
                        "2021-10-06T08:20+01:00[Europe/London]",
                        null,
                        null,
                        null,
                        VALUATION_REPORT_RECEIVED));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("83987190")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        assertTrue(applicationDetailsInfo.getValuationInformation().getDetails().isEmpty());

        verifyNoInteractions(gmsStageAndTaskLoader);
    }

    @Test
    void testRemoveValuationDetailsEntryWithPhysicalValuationBooked() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-12-14T17:20+01:00[Europe/London]",
                        null,
                        null,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-12-15T01:40+01:00[Europe/London]",
                        T,
                        TRIED_FOR_APPOINTMENT,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-12-16T01:40+01:00[Europe/London]",
                        A,
                        ASSIGNED_TO_SURVEYOR,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-12-20T11:40+01:00[Europe/London]",
                        B,
                        BOOKED_APPOINTMENT,
                        "2020-12-24T11:40+01:00[Europe/London]",
                        BOOKING_MADE));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("84026219")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();

        when(gmsStageAndTaskLoader.getValuationStatus(T))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(TRIED_FOR_APPOINTMENT)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(A))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(N)
                                .description(ASSIGNED_TO_SURVEYOR)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(B))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(BOOKED_APPOINTMENT)
                                .build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        valuationDetailsList = applicationDetailsInfo.getValuationInformation().getDetails();

        assertEquals(2, valuationDetailsList.size());

        assertEquals(T, valuationDetailsList.get(0).getStatusCode());
        assertEquals(TRIED_FOR_APPOINTMENT, valuationDetailsList.get(0).getStatusDescription());

        assertEquals(B, valuationDetailsList.get(1).getStatusCode());
        assertEquals(BOOKED_APPOINTMENT, valuationDetailsList.get(1).getStatusDescription());

        verify(gmsStageAndTaskLoader, times(6)).getValuationStatus(anyString());
    }

    @Test
    void testRemoveValuationDetailsEntryWithPhysicalValuationCancelled() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-25T16:35+01:00[Europe/London]",
                        STAR,
                        MANUAL_ALLOCATION,
                        null,
                        MANUAL_ALLOCATION_NOTES));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-27T16:35+01:00[Europe/London]",
                        B,
                        BOOKED_APPOINTMENT,
                        "30/06/2021 16:35",
                        BOOKING_MADE));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-28T16:35+01:00[Europe/London]",
                        C,
                        CANCELLED,
                        null,
                        CANCELLED));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-29T16:35+01:00[Europe/London]",
                        S,
                        SUSPENDED,
                        null,
                        SUSPENDED));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("84152994")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();

        when(gmsStageAndTaskLoader.getValuationStatus(STAR))
                .thenReturn(
                        ValuationStatus.builder().status(N).description(MANUAL_ALLOCATION).build());
        when(gmsStageAndTaskLoader.getValuationStatus(B))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(BOOKED_APPOINTMENT)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(C))
                .thenReturn(ValuationStatus.builder().status(Y).description(CANCELLED).build());
        when(gmsStageAndTaskLoader.getValuationStatus(S))
                .thenReturn(ValuationStatus.builder().status(Y).description(SUSPENDED).build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        valuationDetailsList = applicationDetailsInfo.getValuationInformation().getDetails();

        assertEquals(3, valuationDetailsList.size());

        assertEquals(B, valuationDetailsList.get(0).getStatusCode());
        assertEquals(BOOKED_APPOINTMENT, valuationDetailsList.get(0).getStatusDescription());

        assertEquals(C, valuationDetailsList.get(1).getStatusCode());
        assertEquals(CANCELLED, valuationDetailsList.get(1).getStatusDescription());

        assertEquals(S, valuationDetailsList.get(2).getStatusCode());
        assertEquals(SUSPENDED, valuationDetailsList.get(2).getStatusDescription());

        verify(gmsStageAndTaskLoader, times(8)).getValuationStatus(anyString());
    }

    @Test
    void testRemoveValuationDetailsEntryWithPhysicalValuationReBooked() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-25T17:20+01:00[Europe/London]",
                        STAR,
                        MANUAL_ALLOCATION,
                        null,
                        MANUAL_ALLOCATION_NOTES));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-27T17:20+01:00[Europe/London]",
                        B,
                        BOOKED_APPOINTMENT,
                        "2021-06-30T16:35+01:00[Europe/London]",
                        BOOKING_MADE));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-28T17:20+01:00[Europe/London]",
                        C,
                        CANCELLED,
                        null,
                        CANCELLED));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-30T17:20+01:00[Europe/London]",
                        T,
                        TRIED_FOR_APPOINTMENT,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-07-01T17:20+01:00[Europe/London]",
                        B,
                        BOOKED_APPOINTMENT,
                        "2020-07-07T10:35+01:00[Europe/London]",
                        BOOKING_MADE));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("84105275")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();

        when(gmsStageAndTaskLoader.getValuationStatus(STAR))
                .thenReturn(
                        ValuationStatus.builder().status(N).description(MANUAL_ALLOCATION).build());
        when(gmsStageAndTaskLoader.getValuationStatus(B))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(BOOKED_APPOINTMENT)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(C))
                .thenReturn(ValuationStatus.builder().status(Y).description(CANCELLED).build());
        when(gmsStageAndTaskLoader.getValuationStatus(T))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(TRIED_FOR_APPOINTMENT)
                                .build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        valuationDetailsList = applicationDetailsInfo.getValuationInformation().getDetails();

        assertEquals(4, valuationDetailsList.size());

        assertEquals(B, valuationDetailsList.get(0).getStatusCode());
        assertEquals(BOOKED_APPOINTMENT, valuationDetailsList.get(0).getStatusDescription());

        assertEquals(C, valuationDetailsList.get(1).getStatusCode());
        assertEquals(CANCELLED, valuationDetailsList.get(1).getStatusDescription());

        assertEquals(T, valuationDetailsList.get(2).getStatusCode());
        assertEquals(TRIED_FOR_APPOINTMENT, valuationDetailsList.get(2).getStatusDescription());

        assertEquals(B, valuationDetailsList.get(3).getStatusCode());
        assertEquals(BOOKED_APPOINTMENT, valuationDetailsList.get(3).getStatusDescription());
        verify(gmsStageAndTaskLoader, times(10)).getValuationStatus(anyString());
    }

    @Test
    void testRemoveValuationDetailsEntryWithPhysicalValuationReportReceived() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-25T16:35+01:00[Europe/London]",
                        P,
                        PANELLED,
                        null,
                        null));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-27T16:35+01:00[Europe/London]",
                        B,
                        BOOKED_APPOINTMENT,
                        "30/06/2021 16:35",
                        BOOKING_MADE));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2020-06-28T16:35+01:00[Europe/London]",
                        H,
                        APPOINTMENT_HELD,
                        null,
                        VALUATION_REPORT_RECEIVED));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("83148251")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();

        when(gmsStageAndTaskLoader.getValuationStatus(P))
                .thenReturn(ValuationStatus.builder().status(N).description(PANELLED).build());
        when(gmsStageAndTaskLoader.getValuationStatus(B))
                .thenReturn(
                        ValuationStatus.builder()
                                .status(Y)
                                .description(BOOKED_APPOINTMENT)
                                .build());
        when(gmsStageAndTaskLoader.getValuationStatus(H))
                .thenReturn(
                        ValuationStatus.builder().status(Y).description(APPOINTMENT_HELD).build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        valuationDetailsList = applicationDetailsInfo.getValuationInformation().getDetails();

        assertEquals(2, valuationDetailsList.size());

        assertEquals(B, valuationDetailsList.get(0).getStatusCode());
        assertEquals(BOOKED_APPOINTMENT, valuationDetailsList.get(0).getStatusDescription());

        assertEquals(H, valuationDetailsList.get(1).getStatusCode());
        assertEquals(APPOINTMENT_HELD, valuationDetailsList.get(1).getStatusDescription());

        verify(gmsStageAndTaskLoader, times(6)).getValuationStatus(anyString());
    }

    @Test
    void testRemoveValuationDetailsEntryWithNullStatusEntries() {

        List<Details> valuationDetailsList = new ArrayList<>();
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-06-27T16:35+01:00[Europe/London]",
                        null,
                        null,
                        "30/06/2021 16:35",
                        BOOKING_MADE));
        valuationDetailsList.add(
                getValuationDetailsEntry(
                        N,
                        STANDARD_MORTGAGE_VALUATION,
                        "2021-06-28T16:35+01:00[Europe/London]",
                        H,
                        APPOINTMENT_HELD,
                        null,
                        VALUATION_REPORT_RECEIVED));

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .valuationInformation(
                                ValuationInformation.builder()
                                        .referenceNumber("83148251")
                                        .details(valuationDetailsList)
                                        .build())
                        .build();

        when(gmsStageAndTaskLoader.getValuationStatus(H))
                .thenReturn(
                        ValuationStatus.builder().status(Y).description(APPOINTMENT_HELD).build());

        service.removeValuationDetailsEntry(applicationDetailsInfo);

        valuationDetailsList = applicationDetailsInfo.getValuationInformation().getDetails();

        assertEquals(1, valuationDetailsList.size());

        assertEquals(H, valuationDetailsList.get(0).getStatusCode());
        assertEquals(APPOINTMENT_HELD, valuationDetailsList.get(0).getStatusDescription());

        verify(gmsStageAndTaskLoader, times(2)).getValuationStatus(anyString());
    }

    @Test
    void testSetMilestoneDescriptionDecline() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(COMPLETION).ragStatus(RED).build();

        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(MILESTONE_DECLINE);

        service.setMilestoneDescription(stageHistoryDetail);

        assertEquals(MILESTONE_DECLINE, stageHistoryDetail.getDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testSetMilestoneDescriptionCompletion() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description(COMPLETION).ragStatus(AMBER).build();

        service.setMilestoneDescription(stageHistoryDetail);

        assertEquals(MILESTONE_COMPLETION, stageHistoryDetail.getDescription());
    }

    @Test
    void testSetCaseHistoryCategoryAwait() {
        List<CaseHistoryDetail> caseHistoryDetails =
                Collections.singletonList(CaseHistoryDetail.builder().code("A29").build());

        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(true);

        service.setCaseHistoryCategory(caseHistoryDetails);

        assertEquals(AWAIT, caseHistoryDetails.get(0).getCategory());

        verify(gmsStageAndTaskLoader).isAwaitTask("A29");
    }

    @Test
    void testSetCaseHistoryCategoryAssess() {
        List<CaseHistoryDetail> caseHistoryDetails =
                Collections.singletonList(CaseHistoryDetail.builder().code("R21").build());

        when(gmsStageAndTaskLoader.isAssessTask("R21")).thenReturn(true);

        service.setCaseHistoryCategory(caseHistoryDetails);

        assertEquals(ASSESS, caseHistoryDetails.get(0).getCategory());

        verify(gmsStageAndTaskLoader).isAssessTask("R21");
    }

    @Test
    void testSetCaseHistoryCategoryNull() {
        List<CaseHistoryDetail> caseHistoryDetails =
                Collections.singletonList(CaseHistoryDetail.builder().code(null).build());
        service.setCaseHistoryCategory(caseHistoryDetails);
        assertNull(caseHistoryDetails.get(0).getCategory());
    }

    private Details getValuationDetailsEntry(
            String type,
            String description,
            String date,
            String status,
            String statusDescription,
            String bookingDate,
            String note) {
        return Details.builder()
                .typeCode(type)
                .typeDescription(description)
                .date(Objects.nonNull(date) ? ZonedDateTime.parse(date) : null)
                .statusCode(status)
                .statusDescription(statusDescription)
                .bookingDate(
                        Objects.nonNull(date)
                                ? ZonedDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME)
                                : null)
                .note(note)
                .build();
    }

    @Test
    void testPopulateMortgageTypeAndFeeStatus() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        when(gmsStageAndTaskLoader.getMortgageTypeDescription("P")).thenReturn("Purchase");
        when(gmsStageAndTaskLoader.getFeeStatusDescription("PP")).thenReturn("Paid");
        service.populateMortgageTypeAndFeeStatus(applicationDetailsInfo);
        assertEquals("Purchase", applicationDetailsInfo.getProductInformation().getMortgageType());
        assertEquals("Paid", applicationDetailsInfo.getProductInformation().getFeeStatus());
        verify(gmsStageAndTaskLoader).getMortgageTypeDescription("P");
        verify(gmsStageAndTaskLoader).getFeeStatusDescription("PP");
    }

    @Test
    void testPopulateMortgageTypeAndFeeStatusWithNoProductInfo() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.setProductInformation(null);
        service.populateMortgageTypeAndFeeStatus(applicationDetailsInfo);
        assertNull(applicationDetailsInfo.getProductInformation());
    }

    @Test
    void testPopulateMortgageTypeAndFeeStatusWithMortgageTypeAndFeeStatusNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getProductInformation().setFeeStatusCode(null);
        applicationDetailsInfo.getProductInformation().setMortgageTypeCode(null);
        service.populateMortgageTypeAndFeeStatus(applicationDetailsInfo);
        assertNull(applicationDetailsInfo.getProductInformation().getFeeStatus());
        assertNull(applicationDetailsInfo.getProductInformation().getMortgageType());
    }

    @Test
    void testValidateCompletionApplicationNegative() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("80").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(
                                                                getFormattedDate("2021-05-22"))
                                                        .declinedDate(null)
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getCompletedApplicationSuppressDays())
                .thenReturn(COMPLETED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        LegalReasonException legalReasonException =
                assertThrows(
                        LegalReasonException.class,
                        () -> service.validateApplicationToBeSuppressed(applicationDetailsInfo));
        assertEquals(COMPLETED_APPLICATION_SUPPRESS_MESSAGE, legalReasonException.getMessage());
    }

    @Test
    void testValidateCompletionApplicationPositive() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("80").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .declinedDate(null)
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getCompletedApplicationSuppressDays())
                .thenReturn(COMPLETED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testValidateSoftDeclineApplicationNegative() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("84").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(
                                                                getFormattedDate("2021-05-22"))
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getDeclinedApplicationSuppressDays())
                .thenReturn(DECLINED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        LegalReasonException legalReasonException =
                assertThrows(
                        LegalReasonException.class,
                        () -> service.validateApplicationToBeSuppressed(applicationDetailsInfo));
        assertEquals(SOFT_DECLINED_APPLICATION_SUPPRESS_MESSAGE, legalReasonException.getMessage());
    }

    @Test
    void testValidateSoftDeclineApplicationPositive() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("84").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getDeclinedApplicationSuppressDays())
                .thenReturn(DECLINED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testValidateDeclineApplicationNegative() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("85").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(
                                                                getFormattedDate("2021-05-22"))
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getDeclinedApplicationSuppressDays())
                .thenReturn(DECLINED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        LegalReasonException legalReasonException =
                assertThrows(
                        LegalReasonException.class,
                        () -> service.validateApplicationToBeSuppressed(applicationDetailsInfo));
        assertEquals(DECLINED_APPLICATION_SUPPRESS_MESSAGE, legalReasonException.getMessage());
    }

    @Test
    void testValidateDeclineApplicationPositive() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("85").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getDeclinedApplicationSuppressDays())
                .thenReturn(DECLINED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testValidateRefusedApplicationsNegative() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("90").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(null)
                                                        .refusedDate(getFormattedDate("2021-05-22"))
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getRefusedApplicationSuppressDays())
                .thenReturn(REFUSED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        LegalReasonException legalReasonException =
                assertThrows(
                        LegalReasonException.class,
                        () -> service.validateApplicationToBeSuppressed(applicationDetailsInfo));
        assertEquals(REFUSED_APPLICATION_SUPPRESS_MESSAGE, legalReasonException.getMessage());
    }

    @Test
    void testValidateRefusedApplicationsPositive() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("90").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(null)
                                                        .refusedDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getRefusedApplicationSuppressDays())
                .thenReturn(REFUSED_APPLICATION_SUPPRESS_DAYS);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testValidateRefusedApplicationsSuppressionDateFromProperty() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("90").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(null)
                                                        .refusedDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(propertiesReader.getRefusedApplicationSuppressDays())
                .thenReturn(REFUSED_APPLICATION_SUPPRESS_DAYS);
        when(propertiesReader.getSuppress451Error()).thenReturn("Y");
        when(propertiesReader.getSystemDate()).thenReturn("2021-11-09");
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testValidateApplicationToBeSuppressedForStageNotMatch() {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("50").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(null)
                                                        .declinedDate(null)
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);

        service.validateApplicationToBeSuppressed(applicationDetailsInfo);

        verify(propertiesReader, times(0)).getCompletedApplicationSuppressDays();
        verify(propertiesReader, times(0)).getDeclinedApplicationSuppressDays();
        verify(propertiesReader, times(0)).getRefusedApplicationSuppressDays();
    }

    @Test
    void testPopulateMilestoneCloseTimeWithSameOpenTimeForStages() {
        ZonedDateTime openTime = ZonedDateTime.now().minusDays(2);
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description("Offer").build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(openTime)
                        .closedDateTime(null)
                        .build();
        StageHistory stageHistory1 =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(openTime)
                        .closedDateTime(ZonedDateTime.now().minusDays(1))
                        .build();
        List<StageHistory> stages = new ArrayList<>();
        stages.add(stageHistory);
        stages.add(stageHistory1);
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail, stages, Collections.singletonList(caseHistory), false);
        assertNull(stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateProductInformationRepaymentAmountTest() {
        List<Products> list = new ArrayList<>();
        ProductInformation productInformation = ProductInformation.builder().build();
        ProductInfo prodInfo = getCapitalAndInterestProduct();
        list.add(getProduct("FO25949"));
        Products p2 = getProduct("FO25949");
        p2.setRepaymentAmount(new BigDecimal("278.91"));
        p2.setLoanAmount(new BigDecimal("209184"));
        p2.setTermYears("20");
        p2.setTermMonths("0");
        list.add(p2);
        productInformation.setProducts(list);
        service.populateProductInformation(productInformation, prodInfo);

        assertEquals(1, productInformation.getProducts().size());
        assertEquals(
                new BigDecimal("210000"), productInformation.getProducts().get(0).getLoanAmount());
        assertEquals(
                new BigDecimal("281.32"),
                productInformation.getProducts().get(0).getRepaymentAmount());
        assertEquals("20", productInformation.getProducts().get(0).getTermYears());
        assertEquals("0", productInformation.getProducts().get(0).getTermMonths());
        assertEquals(
                CAPITAL_AND_INTEREST, productInformation.getProducts().get(0).getRepaymentType());
    }

    @Test
    void testPopulateProductInformationMaxYearTest() {
        List<Products> list = new ArrayList<>();
        ProductInformation productInformation = ProductInformation.builder().build();
        ProductInfo prodInfo = getInterestOnlyProduct();
        Products p1 = getProduct("FO25949");
        p1.setTermYears("23");
        p1.setTermMonths("1");
        p1.setRepaymentType(CAPITAL_AND_INTEREST);
        list.add(p1);
        Products p2 = getProduct("FO25949");
        p2.setRepaymentAmount(new BigDecimal("278.91"));
        p2.setLoanAmount(new BigDecimal("209184"));
        p2.setTermYears("20");
        p2.setTermMonths("0");
        list.add(p2);
        productInformation.setProducts(list);
        service.populateProductInformation(productInformation, prodInfo);

        assertEquals(1, productInformation.getProducts().size());
        assertEquals(
                new BigDecimal("210000"), productInformation.getProducts().get(0).getLoanAmount());
        assertEquals(
                new BigDecimal("281.32"),
                productInformation.getProducts().get(0).getRepaymentAmount());
        assertEquals("23", productInformation.getProducts().get(0).getTermYears());
        assertEquals("1", productInformation.getProducts().get(0).getTermMonths());
        assertEquals(INTEREST_ONLY, productInformation.getProducts().get(0).getRepaymentType());
    }

    @Test
    void testPopulateProductInformationMaxTermMonthTest() {
        List<Products> list = new ArrayList<>();
        ProductInformation productInformation = ProductInformation.builder().build();
        ProductInfo prodInfo = getPartAndPartProduct();
        Products p1 = getProduct("FO25949");
        p1.setTermYears("23");
        p1.setTermMonths("1");
        p1.setRepaymentType(PART_AND_PART);
        list.add(p1);
        Products p2 = getProduct("FO25949");
        p2.setRepaymentAmount(new BigDecimal("278.91"));
        p2.setLoanAmount(new BigDecimal("209184"));
        p2.setTermYears("23");
        p2.setTermMonths("8");
        p2.setRepaymentType("Capital And Interest");
        list.add(p2);
        productInformation.setProducts(list);
        service.populateProductInformation(productInformation, prodInfo);

        assertEquals(1, productInformation.getProducts().size());
        assertEquals(
                new BigDecimal("210000"), productInformation.getProducts().get(0).getLoanAmount());
        assertEquals(
                new BigDecimal("281.32"),
                productInformation.getProducts().get(0).getRepaymentAmount());
        assertEquals("23", productInformation.getProducts().get(0).getTermYears());
        assertEquals("8", productInformation.getProducts().get(0).getTermMonths());
        assertEquals(PART_AND_PART, productInformation.getProducts().get(0).getRepaymentType());
    }

    @Test
    void testPopulateProductInformationNull() {
        List<Products> list = new ArrayList<>();
        ProductInformation productInformation = null;
        ProductInfo prodInfo = null;
        service.populateProductInformation(productInformation, prodInfo);
        assertNull(productInformation);
    }

    @Test
    void testPopulateProductInformationProductsNull() {
        List<Products> list = new ArrayList<>();
        ProductInformation productInformation = ProductInformation.builder().build();
        ProductInfo prodInfo = ProductInfo.builder().build();
        service.populateProductInformation(productInformation, prodInfo);
        assertNull(productInformation.getProducts());
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithCancelledStage() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<StageHistory> stageHistories = new ArrayList<>();
        StageHistory stageHistory = getStageHistory();
        stageHistory.setCode("90");
        stageHistories.add(stageHistory);
        stageHistories.addAll(applicationDetailsInfo.getApplicationDetails().getStageHistory());
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistories);

        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformationWithCancelledStage());
        when(gmsStageAndTaskLoader.getStatusDescription(DECLINE))
                .thenReturn(MILESTONE_DECLINED_OR_CANCELLED_DESCRIPTION);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("4", String.valueOf(stageHistoryDetailList.size()));
        IntStream.range(0, stageHistoryDetailList.size() - 1)
                .forEach(
                        i -> {
                            assertNull(stageHistoryDetailList.get(i).getRagStatus());
                            assertNull(stageHistoryDetailList.get(i).getRagDescription());
                            assertNull(stageHistoryDetailList.get(i).getSubStatus());
                            assertNull(stageHistoryDetailList.get(i).getSubStatusDescription());
                        });
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithDeclinedStage() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<StageHistory> stageHistories = new ArrayList<>();
        StageHistory stageHistory = getStageHistory();
        stageHistory.setCode("84");
        stageHistories.add(stageHistory);
        stageHistories.addAll(applicationDetailsInfo.getApplicationDetails().getStageHistory());
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistories);
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformationWithDeclinedStage());
        when(gmsStageAndTaskLoader.getStatusDescription(DECLINE))
                .thenReturn(MILESTONE_DECLINED_OR_CANCELLED_DESCRIPTION);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("4", String.valueOf(stageHistoryDetailList.size()));
        IntStream.range(0, stageHistoryDetailList.size() - 1)
                .forEach(
                        i -> {
                            assertNull(stageHistoryDetailList.get(i).getRagStatus());
                            assertNull(stageHistoryDetailList.get(i).getRagDescription());
                            assertNull(stageHistoryDetailList.get(i).getSubStatus());
                            assertNull(stageHistoryDetailList.get(i).getSubStatusDescription());
                        });
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void TestPopulateCOTDateARO() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ZonedDateTime zonedDateTime2 = ZonedDateTime.parse("2021-06-24T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime).build());
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime2).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotReceivedDate());
    }

    @Test
    void TestPopulateCOTDateARONull() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();

        applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).setCode(SRP);
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setClosedDateTime(zonedDateTime);
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void TestPopulateCOTDateSRPNull() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).setCode(ARO);
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setClosedDateTime(zonedDateTime);
        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void TestPopulateCOTDateSRPARO() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T17:00+00:00", formatter);
        ZonedDateTime zonedDateTime2 = ZonedDateTime.parse("2021-06-24T17:00+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime).build());
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime2).build());
        caseHistoryList.add(CaseHistory.builder().code(SRP).closedDateTime(zonedDateTime).build());
        caseHistoryList.add(CaseHistory.builder().code(SRP).closedDateTime(zonedDateTime2).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotAssessDate());
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotReceivedDate());
    }

    @Test
    void TestPopulateCOTDateNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void TestPopulateCOTDateBlank() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).setCode("");
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void TestPopulateCOTDateAccepted() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-26T15:37+00:00", formatter);
        ZonedDateTime zonedDateTime2 = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        List<StageHistory> stageHistoryList = new ArrayList<>();
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime).build());
        stageHistoryList.add(StageHistory.builder().code("50").openDateTime(zonedDateTime).build());
        stageHistoryList.add(
                StageHistory.builder().code("50").openDateTime(zonedDateTime2).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotReceivedDate());
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotAcceptedDate());
    }

    @Test
    void TestPopulateCOTDateAcceptedNull() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-26T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        List<StageHistory> stageHistoryList = new ArrayList<>();
        stageHistoryList.add(StageHistory.builder().code("50").openDateTime(zonedDateTime).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAcceptedDate());
    }

    @Test
    void TestPopulateCOTDateAcceptedNull2() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-26T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        List<StageHistory> stageHistoryList = new ArrayList<>();
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAcceptedDate());
    }

    @Test
    void TestPopulateCOTDateAcceptedNullStage() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-26T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        caseHistoryList.add(CaseHistory.builder().code(ARO).closedDateTime(zonedDateTime).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(null);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals(zonedDateTime, detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAcceptedDate());
    }

    @Test
    void TestPopulateCOTDateNullForOfferGray() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.getApplicationDetails().getStageHistory().get(0).setDescription("Offer");
        detailsResponse.getApplicationDetails().getStageHistory().get(0).setRagStatus("GREY");
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getCotReceivedDate());
        assertNull(detailsResponse.getStatus().getCotAcceptedDate());
        assertNull(detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void TestUpdateMileStoneRagStatus() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getStageHistory().get(0).setCode("25");

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.getApplicationDetails().getStageHistory().get(0).setDescription("Offer");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStoneRagStatus(applicationDetailsInfo, detailsResponse);
        assertEquals(
                "GREY",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void TestUpdateMileStoneRagStatusStage30() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getStageHistory().get(0).setCode("30");

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.getApplicationDetails().getStageHistory().get(0).setDescription("Offer");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStoneRagStatus(applicationDetailsInfo, detailsResponse);
        assertEquals(
                "GREY",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneTaskR29Open() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> list = new ArrayList<>();
        list.add(CaseHistory.builder().code("R29").status("Open").build());
        list.add(CaseHistory.builder().code("DR2").status("Open").build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(list);

        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);

        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertTrue(CollectionUtils.isEmpty(stageHistoryDetailList.get(1).getCaseHistory()));
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneTaskR29Close() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> list = new ArrayList<>();
        list.add(
                CaseHistory.builder()
                        .code("R29")
                        .status("Close")
                        .openDateTime(ZonedDateTime.now())
                        .build());
        list.add(
                CaseHistory.builder()
                        .code("DR2")
                        .status("Close")
                        .openDateTime(ZonedDateTime.now())
                        .build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(list);

        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        when(applicationDetailsResponseMapper.toCaseHistory(anyList()))
                .thenReturn(
                        Collections.singletonList(
                                getCaseHistoryDetail(ZonedDateTime.now(), ASSESS)));
        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(Boolean.FALSE);
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertEquals(1, stageHistoryDetailList.get(1).getCaseHistory().size());
        verify(gmsStageAndTaskLoader).getMilestoneMappingInformation();
    }

    @Test
    void TestUpdateMileStoneRagStatusCompletion() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getStageHistory().get(0).setCode("25");

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse
                .getApplicationDetails()
                .getStageHistory()
                .get(0)
                .setDescription("Completion");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStoneRagStatus(applicationDetailsInfo, detailsResponse);
        assertEquals(
                "GREY",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void TestUpdateMileStoneRagStatusStageNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().setStageHistory(null);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse
                .getApplicationDetails()
                .getStageHistory()
                .get(0)
                .setDescription("Completion");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStoneRagStatus(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void testPopulateExpectedCompletionDate() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.setExpectedCompletionDate(new Date());
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateExpectedCompletionDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getExpectedCompletionDate());
    }

    @Test
    void testPopulateExpectedCompletionDateNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateExpectedCompletionDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getExpectedCompletionDate());
    }

    @Test
    void testPopulateExpectedCompletionDateWhenStatusObjectNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.setExpectedCompletionDate(new Date());
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateExpectedCompletionDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getExpectedCompletionDate());
    }

    @Test
    void testPopulateOfferIssueDate() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).setCode("T21");
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setClosedDateTime(zonedDateTime);
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateOfferIssueDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getOfferIssueDate());
    }

    @Test
    void testPopulateOfferIssueDateMultipleT21() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ZonedDateTime zonedDateTime2 = ZonedDateTime.parse("2021-05-25T15:37+00:00", formatter);
        ZonedDateTime zonedDateTime3 = ZonedDateTime.parse("2021-04-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        caseHistoryList.add(
                CaseHistory.builder().code("T21").closedDateTime(zonedDateTime).build());
        caseHistoryList.add(
                CaseHistory.builder().code("T21").closedDateTime(zonedDateTime2).build());
        caseHistoryList.add(
                CaseHistory.builder().code("T21").closedDateTime(zonedDateTime3).build());
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setClosedDateTime(zonedDateTime);
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(1)
                .setClosedDateTime(zonedDateTime2);
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(2)
                .setClosedDateTime(zonedDateTime3);
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateOfferIssueDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getOfferIssueDate());
    }

    @Test
    void testPopulateOfferIssueDateWhenNoT21() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateOfferIssueDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getOfferIssueDate());
    }

    @Test
    void testPopulateOfferIssueDateNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).setCode("T21");
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setClosedDateTime(null);
        ApplicationDetailsResponse detailsResponse =
                ApplicationDetailsResponse.builder().status(StatusDetail.builder().build()).build();
        service.populateOfferIssueDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getOfferIssueDate());
    }

    @Test
    void testPopulateOfferIssueDateWhenStatusObjectNull() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).setCode("T21");
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setClosedDateTime(zonedDateTime);
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateOfferIssueDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getOfferIssueDate());
    }

    @Test
    void testPopulateExpectedEffectiveDate() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        applicationDetailsInfo
                .getApplicationDetails()
                .getStatus()
                .setExpectedEffectiveDate(new Date());
        service.populateExpectedEffectiveDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getExpectedEffectiveDate());
    }

    @Test
    void testPopulateExpectedEffectiveDateNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateExpectedEffectiveDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getExpectedEffectiveDate());
    }

    @Test
    void testPopulateExpectedEffectiveDateWhenStatusObjectNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo
                .getApplicationDetails()
                .getStatus()
                .setExpectedEffectiveDate(new Date());
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateExpectedEffectiveDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getExpectedEffectiveDate());
    }

    @Test
    void testPopulateActualEffectiveDate() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getStageHistory().get(0).setCode("80");
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setOpenDateTime(zonedDateTime);
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateActualEffectiveDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getActualEffectiveDate());
    }

    @Test
    void testPopulateActualEffectiveDateNull() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateActualEffectiveDate(applicationDetailsInfo, detailsResponse);
        assertNull(detailsResponse.getStatus().getActualEffectiveDate());
    }

    @Test
    void testPopulateActualEffectiveDateWhenStatusObjectNull() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2021-06-25T15:37+00:00", formatter);
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo.getApplicationDetails().getStageHistory().get(0).setCode("80");
        applicationDetailsInfo
                .getApplicationDetails()
                .getCaseHistory()
                .get(0)
                .setOpenDateTime(zonedDateTime);
        ApplicationDetailsResponse detailsResponse = ApplicationDetailsResponse.builder().build();
        service.populateActualEffectiveDate(applicationDetailsInfo, detailsResponse);
        assertNotNull(detailsResponse.getStatus().getActualEffectiveDate());
    }

    @Test
    void testValidateFundReturnedApplicationPositive() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code("92").build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .declinedDate(null)
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testValidateFundReturnedApplicationPositiveNull() throws ParseException {

        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(
                                ApplicationDetails.builder()
                                        .stageHistory(
                                                Collections.singletonList(
                                                        StageHistory.builder().code(null).build()))
                                        .status(
                                                StatusInfo.builder()
                                                        .completionDate(
                                                                getFormattedDate(
                                                                        LocalDate.now()
                                                                                .minusDays(1)
                                                                                .toString()))
                                                        .declinedDate(null)
                                                        .refusedDate(null)
                                                        .build())
                                        .build())
                        .build();

        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        service.validateApplicationToBeSuppressed(applicationDetailsInfo);
        assertTrue(Objects.nonNull(applicationDetailsInfo));
    }

    @Test
    void testSetRagStatusMilestoneAMBERForRET() {
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(MILESTONE_COMPLETION)
                        .timeOpen(ZonedDateTime.now())
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(anyString())).thenReturn(AMBER_MILESTONE);
        service.setRagStatus(stageHistoryDetail, "92", false);
        assertEquals(AMBER, stageHistoryDetail.getRagStatus());
        assertEquals(MILESTONE_COMPLETION + AMBER_DESC, stageHistoryDetail.getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(anyString());
    }

    @Test
    void testAddDummyTasksForProductSwitch() {
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        when(gmsStageAndTaskLoader.getDummyTaskCode(
                        applicationDetailsInfo
                                .getApplicationDetails()
                                .getStageHistory()
                                .get(0)
                                .getCode()))
                .thenReturn("D/40");
        service.addDummyTasksForProductSwitch(applicationDetailsInfo, true);
        assertTrue(
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                        .anyMatch(task -> task.getCode().equalsIgnoreCase("D/40")));
    }

    @Test
    void testAddDummyTasksForProductSwitchWithCaseHistoryNull() {
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(null);
        when(gmsStageAndTaskLoader.getDummyTaskCode(
                        applicationDetailsInfo
                                .getApplicationDetails()
                                .getStageHistory()
                                .get(0)
                                .getCode()))
                .thenReturn("D/40");
        service.addDummyTasksForProductSwitch(applicationDetailsInfo, true);
        assertTrue(
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                        .anyMatch(task -> task.getCode().equalsIgnoreCase("D/40")));
    }

    @Test
    void testAddDummyTasksForProductSwitchWithNoDummyTask() {
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(null);
        when(gmsStageAndTaskLoader.getDummyTaskCode(
                        applicationDetailsInfo
                                .getApplicationDetails()
                                .getStageHistory()
                                .get(0)
                                .getCode()))
                .thenReturn(null);
        service.addDummyTasksForProductSwitch(applicationDetailsInfo, true);
        assertTrue(Objects.isNull(applicationDetailsInfo.getApplicationDetails().getCaseHistory()));
    }

    @Test
    void testPopulateMilestoneCloseTimeForProductSwitchApp1() {
        // All stages are closed in milestone
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description("Offer").build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now().minusDays(7))
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                Collections.singletonList(caseHistory),
                true);
        assertEquals(stageHistory.getClosedDateTime(), stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateMilestoneCloseTimeForProductSwitchApp2() {
        // Milestone has open stage
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description("Offer").build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(null)
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                Collections.singletonList(stageHistory),
                Collections.singletonList(caseHistory),
                true);
        assertNull(stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testPopulateMilestoneCloseTimeForProductSwitchApp3() {
        // Milestone has no stages
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder().description("Offer").build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        service.populateMilestoneCloseTime(
                stageHistoryDetail,
                new ArrayList<>(),
                Collections.singletonList(caseHistory),
                true);
        assertNull(stageHistoryDetail.getTimeClosed());
    }

    @Test
    void testRemoveExcludedStagesForProductSwitchApplication1() {
        // has no stages
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        applicationDetailsInfo.getApplicationDetails().setStageHistory(null);
        service.removeExcludedStages(null, applicationDetailsInfo, true);
        verifyNoInteractions(gmsStageAndTaskLoader);
    }

    @Test
    void testRemoveExcludedStagesForProductSwitchApplication2() {
        // has invalid stage
        Map<String, MilestoneMappingInformation> milestoneMappingInformationMap = new HashMap<>();
        milestoneMappingInformationMap.put(
                "1",
                MilestoneMappingInformation.builder()
                        .stages(Collections.singletonList("40"))
                        .build());
        when(gmsStageAndTaskLoader.getProductSwitchMilestoneMappingInformation())
                .thenReturn(milestoneMappingInformationMap);
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("22")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(null)
                        .build();
        applicationDetailsInfo
                .getApplicationDetails()
                .setStageHistory(Collections.singletonList(stageHistory));
        service.removeExcludedStages(null, applicationDetailsInfo, true);
        assertTrue(
                CollectionUtils.isEmpty(
                        applicationDetailsInfo.getApplicationDetails().getStageHistory()));
    }

    @Test
    void testRemoveExcludedStagesForProductSwitchApplication3() {
        Map<String, MilestoneMappingInformation> milestoneMappingInformationMap = new HashMap<>();
        milestoneMappingInformationMap.put(
                "1",
                MilestoneMappingInformation.builder()
                        .stages(Collections.singletonList("40"))
                        .build());
        when(gmsStageAndTaskLoader.getProductSwitchMilestoneMappingInformation())
                .thenReturn(milestoneMappingInformationMap);
        // has valid stages
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("40")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(null)
                        .build();
        applicationDetailsInfo
                .getApplicationDetails()
                .setStageHistory(Collections.singletonList(stageHistory));
        service.removeExcludedStages(null, applicationDetailsInfo, true);
        assertTrue(
                CollectionUtils.isNotEmpty(
                        applicationDetailsInfo.getApplicationDetails().getStageHistory()));
    }

    @Test
    void testRemoveExcludedTasksForProductSwitchApplication1() {
        // has no tasks
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(null);
        service.removeExcludedTasks(null, applicationDetailsInfo, true);
        verifyNoInteractions(gmsStageAndTaskLoader);
    }

    @Test
    void testRemoveExcludedTasksForProductSwitchApplication2() {
        // has invalid task
        Map<String, MilestoneMappingInformation> milestoneMappingInformationMap = new HashMap<>();
        milestoneMappingInformationMap.put(
                "1",
                MilestoneMappingInformation.builder()
                        .tasks(Collections.singletonList("D/40"))
                        .build());
        when(gmsStageAndTaskLoader.getProductSwitchMilestoneMappingInformation())
                .thenReturn(milestoneMappingInformationMap);
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("SMS")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(caseHistory));
        service.removeExcludedTasks(null, applicationDetailsInfo, true);
        assertTrue(
                CollectionUtils.isEmpty(
                        applicationDetailsInfo.getApplicationDetails().getCaseHistory()));
    }

    @Test
    void testRemoveExcludedTasksForProductSwitchApplication3() {
        // has valid task
        Map<String, MilestoneMappingInformation> milestoneMappingInformationMap = new HashMap<>();
        milestoneMappingInformationMap.put(
                "1",
                MilestoneMappingInformation.builder()
                        .tasks(Collections.singletonList("D/40"))
                        .build());
        when(gmsStageAndTaskLoader.getProductSwitchMilestoneMappingInformation())
                .thenReturn(milestoneMappingInformationMap);
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("D/40")
                        .description("")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(caseHistory));
        service.removeExcludedTasks(null, applicationDetailsInfo, true);
        assertTrue(
                CollectionUtils.isNotEmpty(
                        applicationDetailsInfo.getApplicationDetails().getCaseHistory()));
    }

    @Test
    void testPopulateStageClosingTime() {
        // current stage is greater than 79
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        List<StageHistory> stageHistories = new ArrayList<>();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("80")
                        .description("Completion")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(null)
                        .build();
        stageHistories.add(stageHistory);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistories);
        service.populateStageClosingTime(applicationDetailsInfo, true);
        assertEquals(
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStageHistory()
                        .get(0)
                        .getClosedDateTime(),
                stageHistory.getOpenDateTime());
    }

    @Test
    void testPopulateStageClosingTime1() {
        // current stage is less than 79
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        List<StageHistory> stageHistories = new ArrayList<>();
        StageHistory stageHistory =
                StageHistory.builder()
                        .code("67")
                        .description("Completion")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(null)
                        .build();
        stageHistories.add(stageHistory);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistories);
        service.populateStageClosingTime(applicationDetailsInfo, true);
        assertNull(
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStageHistory()
                        .get(0)
                        .getClosedDateTime());
    }

    @Test
    void testPopulateStageClosingTime2() {
        // stage history is null
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .applicationDetails(getApplicationDetailsObject())
                        .build();
        applicationDetailsInfo.getApplicationDetails().setStageHistory(null);
        service.populateStageClosingTime(applicationDetailsInfo, true);
        assertNull(applicationDetailsInfo.getApplicationDetails().getStageHistory());
    }

    @Test
    void testSetRagStatusForProductSwitchApplication() {
        // Milestone level rag status for declined application
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(PRODUCT_SWITCH_STATUS)
                        .timeOpen(ZonedDateTime.now())
                        .timeClosed(ZonedDateTime.now())
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(PRODUCT_SWITCH_CANCELLED))
                .thenReturn(PRODUCT_SWITCH_CANCELLED_DESCRIPTION);
        service.setRagStatus(stageHistoryDetail, "85", true);
        assertEquals(RED, stageHistoryDetail.getRagStatus());
        assertEquals(PRODUCT_SWITCH_CANCELLED_DESCRIPTION, stageHistoryDetail.getRagDescription());
        assertEquals(PRODUCT_SWITCH_STATUS, stageHistoryDetail.getDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(PRODUCT_SWITCH_CANCELLED);
    }

    @Test
    void testSetRagStatusForProductSwitchApplication1() {
        // Milestone level rag status for product switch application at stage 40
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(PRODUCT_SWITCH_STATUS)
                        .timeOpen(ZonedDateTime.now())
                        .timeClosed(null)
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(AMBER)).thenReturn(AMBER_DESC);
        service.setRagStatus(stageHistoryDetail, "40", true);
        assertEquals(AMBER, stageHistoryDetail.getRagStatus());
        assertEquals(AMBER_DESC, stageHistoryDetail.getRagDescription());
        assertEquals(PRODUCT_SWITCH_STATUS, stageHistoryDetail.getDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(AMBER);
    }

    @Test
    void testSetRagStatusForProductSwitchApplication3() {
        // Milestone level rag status for product switch application where stage number is null
        StageHistoryDetail stageHistoryDetail =
                StageHistoryDetail.builder()
                        .description(PRODUCT_SWITCH_STATUS)
                        .timeOpen(ZonedDateTime.now())
                        .timeClosed(null)
                        .build();
        when(gmsStageAndTaskLoader.getStatusDescription(AMBER)).thenReturn(AMBER_DESC);
        service.setRagStatus(stageHistoryDetail, null, true);
        assertEquals(AMBER, stageHistoryDetail.getRagStatus());
        assertEquals(AMBER_DESC, stageHistoryDetail.getRagDescription());
        assertEquals(PRODUCT_SWITCH_STATUS, stageHistoryDetail.getDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(AMBER);
    }

    @Test
    void TestUpdateMileStone() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        StageHistory stageHistory = getStageHistory();
        stageHistory.setCode("84");
        StageHistory stageHistory2 = getStageHistory();
        stageHistory2.setCode("20");
        List<StageHistory> stageHistoryList = new ArrayList<>();
        stageHistoryList.add(stageHistory2);
        stageHistoryList.add(stageHistory);

        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.getApplicationDetails().getStageHistory().get(0).setDescription("Offer");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStone(applicationDetailsInfo, detailsResponse, false);
        assertEquals(
                "GREY",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void TestUpdateMileStoneCompletion() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        StageHistory stageHistory = getStageHistory();
        stageHistory.setCode("84");
        StageHistory stageHistory2 = getStageHistory();
        stageHistory2.setCode("20");
        List<StageHistory> stageHistoryList = new ArrayList<>();
        stageHistoryList.add(stageHistory2);
        stageHistoryList.add(stageHistory);

        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse
                .getApplicationDetails()
                .getStageHistory()
                .get(0)
                .setDescription("Completion");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStone(applicationDetailsInfo, detailsResponse, false);
        assertEquals(
                "RED",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void TestUpdateMileStoneStage34() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        StageHistory stageHistory = getStageHistory();
        stageHistory.setCode("84");
        StageHistory stageHistory2 = getStageHistory();
        stageHistory2.setCode("34");
        List<StageHistory> stageHistoryList = new ArrayList<>();
        stageHistoryList.add(stageHistory2);
        stageHistoryList.add(stageHistory);

        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.getApplicationDetails().getStageHistory().get(0).setDescription("Offer");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStone(applicationDetailsInfo, detailsResponse, false);
        assertEquals(
                "AMBER",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void TestUpdateMileStoneStage34Completion() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        StageHistory stageHistory = getStageHistory();
        stageHistory.setCode("84");
        StageHistory stageHistory2 = getStageHistory();
        stageHistory2.setCode("34");
        List<StageHistory> stageHistoryList = new ArrayList<>();
        stageHistoryList.add(stageHistory2);
        stageHistoryList.add(stageHistory);

        applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse
                .getApplicationDetails()
                .getStageHistory()
                .get(0)
                .setDescription("Completion");

        detailsResponse.setStatus(StatusDetail.builder().build());
        service.updateMileStone(applicationDetailsInfo, detailsResponse, false);
        assertEquals(
                "GREY",
                detailsResponse.getApplicationDetails().getStageHistory().get(0).getRagStatus());
    }

    @Test
    void TestResetCOTDate() {
        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        StageHistoryDetail stageHistoryDetail = getStageHistoryDetail();
        stageHistoryDetail.setDescription(COMPLETION);
        stageHistoryDetail.setRagStatus(GREY);
        detailsResponse.setApplicationDetails(
                HistoryDetails.builder()
                        .stageHistory(Collections.singletonList(stageHistoryDetail))
                        .build());
        detailsResponse.setStatus(
                StatusDetail.builder()
                        .expectedCompletionDate(new Date())
                        .cotAcceptedDate(
                                ZonedDateTime.parse("2018-09-16T08:00:00+00:00[Europe/London]"))
                        .cotAssessDate(
                                ZonedDateTime.parse("2018-09-16T08:00:00+00:00[Europe/London]"))
                        .build());

        service.resetCOTDate(detailsResponse);
        assertNull(detailsResponse.getStatus().getExpectedCompletionDate());
        assertNull(detailsResponse.getStatus().getCotAssessDate());
        assertNull(detailsResponse.getStatus().getCotAcceptedDate());
    }

    @Test
    void TestResetCOTDateNotNull() {
        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        StageHistoryDetail stageHistoryDetail = getStageHistoryDetail();
        stageHistoryDetail.setDescription(COMPLETION);
        stageHistoryDetail.setRagStatus(GREEN);
        detailsResponse.setApplicationDetails(
                HistoryDetails.builder()
                        .stageHistory(Collections.singletonList(stageHistoryDetail))
                        .build());
        detailsResponse.setStatus(
                StatusDetail.builder()
                        .expectedCompletionDate(new Date())
                        .cotAcceptedDate(
                                ZonedDateTime.parse("2018-09-16T08:00:00+00:00[Europe/London]"))
                        .cotAssessDate(
                                ZonedDateTime.parse("2018-09-16T08:00:00+00:00[Europe/London]"))
                        .build());

        service.resetCOTDate(detailsResponse);
        assertNotNull(detailsResponse.getStatus().getExpectedCompletionDate());
        assertNotNull(detailsResponse.getStatus().getCotAssessDate());
        assertNotNull(detailsResponse.getStatus().getCotAcceptedDate());
    }

    private CaseHistoryDetail getCaseHistoryDetail(ZonedDateTime timeClosed, String category) {
        return CaseHistoryDetail.builder()
                .code("A29")
                .description("We have received your client's payslips.")
                .event("event")
                .timeClosed(timeClosed)
                .timeOpen(ZonedDateTime.now())
                .category(category)
                .build();
    }

    private CaseHistory getOpenCaseHistory() {
        return CaseHistory.builder()
                .code("A29")
                .description("We have received your client's payslips.")
                .event("event")
                .openDateTime(ZonedDateTime.now())
                .closedDateTime(null)
                .build();
    }

    private Products getProduct(String code) {
        return Products.builder()
                .code(code)
                .loanAmount(new BigDecimal("816"))
                .termYears("20")
                .termMonths("0")
                .repaymentAmount(new BigDecimal("2.41"))
                .build();
    }

    @Test
    void testGetApplicationsWithBrokerDetailValidationSuccess() {
        Set<FirmBroker> firmBrokerSet = getValidFirmBrokers();

        BrokerDetailValidationResponse brokerValidationResponse =
                BrokerDetailValidationResponse.builder().brokers(firmBrokerSet).build();

        when(brokerDetailValidationService.validateBroker(any()))
                .thenReturn(brokerValidationResponse);
        ApplicationRequest applicationRequest = getApplicationRequest();
        when(brokerService.getApplications(NWB_BRAND, applicationRequest))
                .thenReturn(getApplicationsResponse());
        when(propertiesReader.getIsBrokerDetailValidateEndpointEnabled()).thenReturn(true);
        service.getApplications(NWB_BRAND, applicationRequest);
        verify(brokerDetailValidationService).validateBroker(any());
        verify(brokerService).getApplications(NWB_BRAND, applicationRequest);
    }

    private Set<FirmBroker> getValidFirmBrokers() {
        FirmBroker firmBroker1 =
                FirmBroker.builder()
                        .acceptMortgageBusiness("Yes")
                        .brokerEmail("mike.carter@brooksonfinancial.co.uk")
                        .brokerForeName("Carter")
                        .brokerSurname("Mike")
                        .fcaNumber("179752")
                        .build();

        FirmBroker firmBroker2 =
                FirmBroker.builder()
                        .acceptMortgageBusiness("YES")
                        .brokerEmail("mike.carter12@brooksonfinancial.co.uk")
                        .brokerForeName("Mike")
                        .brokerSurname("Carter")
                        .fcaNumber("179753")
                        .build();

        Set<FirmBroker> firmBrokerSet = new HashSet<>();
        firmBrokerSet.add(firmBroker1);
        firmBrokerSet.add(firmBroker2);
        return firmBrokerSet;
    }

    @Test
    void testGetApplicationsDetailBrokerValidationWithInvalidBroker() {
        Set<FirmBroker> firmBrokerSet = getInvalidFirmBrokers();

        BrokerDetailValidationResponse brokerValidationResponse =
                BrokerDetailValidationResponse.builder().brokers(firmBrokerSet).build();

        when(brokerDetailValidationService.validateBroker(any()))
                .thenReturn(brokerValidationResponse);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ApplicationRequest applicationRequest = getApplicationRequest();
        when(propertiesReader.getIsBrokerDetailValidateEndpointEnabled()).thenReturn(true);
        BrokerValidationException brokerValidationException =
                assertThrows(
                        BrokerValidationException.class,
                        () -> service.getApplications(NWB_BRAND, applicationRequest));

        assertEquals(
                "Error Code 401 : Authentication failed. Please contact our technical team on 0345 600 0205.",
                brokerValidationException.getMessage());
        verify(brokerDetailValidationService).validateBroker(any());
        verifyNoInteractions(brokerService);
    }

    @Test
    void testGetApplicationDetailsWithDetailBrokerValidationSuccess() throws IOException {
        Set<FirmBroker> firmBrokerSet = getValidFirmBrokers();

        BrokerDetailValidationResponse brokerValidationResponse =
                BrokerDetailValidationResponse.builder().brokers(firmBrokerSet).build();

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        when(brokerDetailValidationService.validateBroker(any()))
                .thenReturn(brokerValidationResponse);
        when(applicationDetailsService.getApplicationInfo(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(new ResponseEntity<>("{\"productInformation\": [{}]}", HttpStatus.OK));
        when(applicationDetailsService.getApplicationDetail(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK)));
        when(applicationDetailsService.getValuationInformation(
                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest))
                .thenReturn(
                        CompletableFuture.completedFuture(
                                new ResponseEntity<>(
                                        "{\"valuationInformation\": }", HttpStatus.OK)));
        when(propertiesReader.getApplicationSuppressStageList())
                .thenReturn(APPLICATION_SUPPRESS_STAGE_CODE_LIST);
        when(objectMapper.readValue(anyString(), eq(ApplicationDetailsInfo.class)))
                .thenReturn(getApplicationDetailsInfo());

        when(applicationDetailsResponseMapper.toApplicationDetailsResponse(null))
                .thenReturn(getApplicationDetailsResponse());
        when(propertiesReader.getIsBrokerDetailValidateEndpointEnabled()).thenReturn(true);
        service.getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(brokerDetailValidationService).validateBroker(any());
        verify(applicationDetailsService)
                .getApplicationInfo(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getApplicationDetail(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
        verify(applicationDetailsService)
                .getValuationInformation(NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);
    }

    @Test
    void testGetApplicationDetailsWithInvalidBrokerDetails() {
        Set<FirmBroker> firmBrokerSet = getInvalidFirmBrokers();

        BrokerDetailValidationResponse brokerValidationResponse =
                BrokerDetailValidationResponse.builder().brokers(firmBrokerSet).build();
        when(brokerDetailValidationService.validateBroker(any()))
                .thenReturn(brokerValidationResponse);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        when(propertiesReader.getIsBrokerDetailValidateEndpointEnabled()).thenReturn(true);
        BrokerValidationException brokerValidationException =
                assertThrows(
                        BrokerValidationException.class,
                        () ->
                                service.getApplicationDetail(
                                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest));

        assertEquals(
                "Error Code 401 : Authentication failed. Please contact our technical team on 0345 600 0205.",
                brokerValidationException.getMessage());
        verify(brokerDetailValidationService).validateBroker(any());
        verifyNoInteractions(brokerService);
    }

    @Test
    void testGetApplicationDetailsWithoutBrokerInfo() {

        when(brokerDetailValidationService.validateBroker(any())).thenReturn(null);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        when(propertiesReader.getIsBrokerDetailValidateEndpointEnabled()).thenReturn(true);
        BrokerValidationException brokerValidationException =
                assertThrows(
                        BrokerValidationException.class,
                        () ->
                                service.getApplicationDetail(
                                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest));

        assertEquals(
                "Error Code 401 : Authentication failed. Please contact our technical team on 0345 600 0205.",
                brokerValidationException.getMessage());
        verify(brokerDetailValidationService).validateBroker(any());
        verifyNoInteractions(brokerService);
    }

    @Test
    void testGetApplicationDetailsWithNullBrokerInfo() {
        Set<FirmBroker> firmBrokerSet = getInvalidFirmBrokers();

        BrokerDetailValidationResponse brokerValidationResponse =
                BrokerDetailValidationResponse.builder().brokers(null).build();
        when(brokerDetailValidationService.validateBroker(any()))
                .thenReturn(brokerValidationResponse);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        when(propertiesReader.getIsBrokerDetailValidateEndpointEnabled()).thenReturn(true);
        BrokerValidationException brokerValidationException =
                assertThrows(
                        BrokerValidationException.class,
                        () ->
                                service.getApplicationDetail(
                                        NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest));

        assertEquals(
                "Error Code 401 : Authentication failed. Please contact our technical team on 0345 600 0205.",
                brokerValidationException.getMessage());
        verify(brokerDetailValidationService).validateBroker(any());
        verifyNoInteractions(brokerService);
    }

    @Test
    void testCotDatesForECOTApplication() {

        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = getECotPositiveCaseHistory();
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals("AEC", caseHistoryList.get(12).getCode());
        assertEquals(
                caseHistoryList.get(12).getOpenDateTime(),
                detailsResponse.getStatus().getCotAcceptedDate());
        assertEquals("FNE", caseHistoryList.get(13).getCode());
        assertEquals(
                caseHistoryList.get(13).getClosedDateTime(),
                detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void testCotDatesForECOTNegativeApplication() {

        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        List<CaseHistory> caseHistoryList = getECotNegativeCaseHistory();
        applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistoryList);

        ApplicationDetailsResponse detailsResponse = getApplicationDetailsResponse();
        detailsResponse.setStatus(StatusDetail.builder().build());
        service.populateCOTDate(applicationDetailsInfo, detailsResponse);
        assertEquals("SRM", caseHistoryList.get(7).getCode());
        assertEquals(
                caseHistoryList.get(7).getOpenDateTime(),
                detailsResponse.getStatus().getCotAcceptedDate());
        assertEquals("SCM", caseHistoryList.get(8).getCode());
        assertEquals(
                caseHistoryList.get(8).getClosedDateTime(),
                detailsResponse.getStatus().getCotAssessDate());
    }

    @Test
    void testClubStageAndTaskBasedOnMilestoneWithRequiredActionsFromPM() {
        ApplicationDetailsInfo applicationDetailsInfo = getApplicationDetailsInfo();
        applicationDetailsInfo
                .getApplicationDetails()
                .setCaseHistory(Collections.singletonList(getOpenCaseHistory()));
        applicationDetailsInfo.getApplicationDetails().setGranularTracking(getGranularTrackingList());
        when(gmsStageAndTaskLoader.getMilestoneMappingInformation())
                .thenReturn(getMilestoneMappingInformation());
        List<CaseHistoryDetail> caseHistoryDetails = new ArrayList<>();
        caseHistoryDetails.add(getCaseHistoryDetail(null, AWAIT));
        when(applicationDetailsResponseMapper.toCaseHistory(anyList()))
                .thenReturn(caseHistoryDetails);
        when(applicationDetailsResponseMapper.toCaseHistoryDetail(any(), anyString()))
                .thenReturn(getCaseHistoryDetail(ZonedDateTime.now(), AWAIT));
        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(Boolean.TRUE);
        when(applicationDetailsResponseMapper.toGranularTrackingDetail(any()))
                .thenReturn(getGranularTrackingDetail());
        List<StageHistoryDetail> stageHistoryDetailList =
                service.clubStageAndTaskBasedOnMilestone(applicationDetailsInfo, false);
        assertEquals("2", String.valueOf(stageHistoryDetailList.size()));
        assertTrue(CollectionUtils.isNotEmpty(stageHistoryDetailList.get(0).getRequiredActions()));
        assertTrue(CollectionUtils.isEmpty(stageHistoryDetailList.get(0).getCaseHistory()));
        assertEquals(
                "We have received your client's payslips.",
                stageHistoryDetailList.get(0).getRequiredActions().get(0).getDescription());
    }

    @Test
    void testSetCaseHistoryCategoryTaskCodeIsNull() {
        List<CaseHistoryDetail> caseHistoryDetails =
                Collections.singletonList(CaseHistoryDetail.builder().build());
        service.setCaseHistoryCategory(caseHistoryDetails);
        verifyNoInteractions(gmsStageAndTaskLoader);
    }

    @Test
    void testRemoveOpenFSTTaskIfNoOpenFIs() {
        // Has open FI and open FST task
        List<CaseHistory> caseHistories = new ArrayList<>();
        caseHistories.add(CaseHistory.builder().code("FST").build());
        ApplicationDetailsInfo applicationDetailsInfo = ApplicationDetailsInfo.builder().applicationDetails(ApplicationDetails.builder()
                .caseHistory(caseHistories)
                .granularTracking(Collections.singletonList(GranularTracking.builder().state("Open").build()))
                .build()).build();
        service.removeOpenFSTTaskIfNoOpenFIs(applicationDetailsInfo);
        assertTrue(CollectionUtils.isNotEmpty(applicationDetailsInfo.getApplicationDetails().getCaseHistory()));
    }

    @Test
    void testRemoveOpenFSTTaskIfNoOpenFIs1() {
        // Has no open FI and open FST task
        List<CaseHistory> caseHistories = new ArrayList<>();
        caseHistories.add(CaseHistory.builder().code("FST").build());
        ApplicationDetailsInfo applicationDetailsInfo = ApplicationDetailsInfo.builder().applicationDetails(ApplicationDetails.builder()
                .caseHistory(caseHistories)
                .granularTracking(Collections.singletonList(GranularTracking.builder().state("Review").build()))
                .build()).build();
        service.removeOpenFSTTaskIfNoOpenFIs(applicationDetailsInfo);
        assertTrue(CollectionUtils.isEmpty(applicationDetailsInfo.getApplicationDetails().getCaseHistory()));
    }
}
