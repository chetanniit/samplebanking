/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.ex.ConfigurationException;

@Slf4j
public class CucumberConfigReader {

    public static FileBasedConfiguration readProperties() {
        FileBasedConfiguration configuration = null;
        Parameters params = new Parameters();
        FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
                new FileBasedConfigurationBuilder<FileBasedConfiguration>(
                                PropertiesConfiguration.class)
                        .configure(
                                params.fileBased()
                                        // .setThrowExceptionOnMissing(true)
                                        .setEncoding("UTF-8")
                                        .setFileName(
                                                ApiTestConstants
                                                        .CUCUMBER_CONFIG_PROPERTIES_FILENAME));
        try {
            configuration = builder.getConfiguration();
        } catch (ConfigurationException e) {
            log.error("cucumber config file not found", e);
        }
        return configuration;
    }
}
