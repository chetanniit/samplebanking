/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.stepdefs;

import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Errors;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.GET_APPLICATION_LIST_INPUT_JSON;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.StreamSupport;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;

@Slf4j
public class GetApplicationListStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(GET_APPLICATION_LIST_INPUT_JSON);
    }

    private JsonNode validateAndGetApplications() {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertTrue(totalCount > 0);
        JsonNode applications = responseJsonNode.path(APPLICATIONS);
        Assertions.assertTrue(applications.size() > 0);
        Assertions.assertTrue(applications.isArray());
        return applications;
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) {
        
//        JsonNode testInput = inputsAsJsonNode.get(inputName);
//
//        Assertions.assertEquals(testInput.get(ERROR_CODE).asText(), responseJsonNode.get(RESPONSE_STATUS).asText());

        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    @Given("Get Application List Service endpoint exists")
    public void getSearchApplicationsServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request in Get Application list using input {string} and validate response code")
    public void userSendsRequestInGetApplicationUsingInputAndValidateResponseCode(String inputName)
            throws IOException {

        JsonNode testInput = inputsAsJsonNode.get(inputName);
        RequestSpecification request =
                RestAssured.given()
                        .log()
                        .all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCoordAppTracking())
                        .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request);
        Response response = request.get(inputsAsJsonNode.get(PATH).asText());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());


    }
    
    
    @Then("Verify application list for broker using the input {string}")
    public void verifyApplicationListForBrokerUsingTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        Set<String> applicationReferenceNumbers = new HashSet<>();
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            String applicationReference =
                                    application.get(REFERENCE_NUMBER).asText();
                            Assertions.assertNotNull(applicationReference);
                            Assertions.assertTrue(
                                    applicationReferenceNumbers.add(applicationReference),
                                    ApiTestConstants.Errors.APPLICATIONS_ARE_NOT_UNIQUE);
                            JsonNode applicantDetailArray = application.get(APPLICANTS);
                            Assertions.assertTrue(
                                    applicantDetailArray.size() > 0,
                                    ApiTestConstants.Errors.MISSING_APPLICANTS);
                            
                            Assertions.assertNotNull(application.get(SOURCE_INFO));
                        });
    }
    
    @Then("Verify display of applicant by first name {string}")
    public void verifyApplicantListByApplicantFirstName(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {                            
                            JsonNode applicantDetailArray = application.get(APPLICANTS);
                            Assertions.assertTrue(
                                    applicantDetailArray.size() > 0,
                                    ApiTestConstants.Errors.MISSING_APPLICANTS);
                            StreamSupport.stream(applicantDetailArray.spliterator(), false)
                            .forEach( applicants -> {
                                assertEquals(inputs.get(APPLICANT_FIRST_NAME).asText(), applicants.get(FIRST_NAME).asText());
                            });
                           
                        });
    }
    
    @Then("Verify display of applicant by last name {string}")
    public void verifyApplicantListByApplicantLastName(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {                            
                            JsonNode applicantDetailArray = application.get(APPLICANTS);
                            Assertions.assertTrue(
                                    applicantDetailArray.size() > 0,
                                    ApiTestConstants.Errors.MISSING_APPLICANTS);
                            StreamSupport.stream(applicantDetailArray.spliterator(), false)
                            .forEach( applicants -> {
                                assertEquals(inputs.get(APPLICANT_LAST_NAME).asText(), applicants.get(LAST_NAME).asText());
                            });
                           
                        });
    }
    
    @Then("Verify the error message for the input {string}")
    public void verifyInvalidBrandErrorForTheInput(String inputName) {
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(testInput.get(ERROR_CODE).asText(), responseJsonNode.get(RESPONSE_STATUS).asText());
    }

    @Then("Verify application list returned bad request for a given invalid value {string}")
    public void verifyApplicationListReturnedBadRequestForAGivenInvalidValue(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }
}
