/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StatusDescription;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ApplicationUtilTest {

    @Test
    void testDaysMethodCalls() {
        assertNotNull(getSevenDaysBeforeCurrentDateInUnitedKingdom());
        assertNotNull(getDateMonthBeforeCurrentDateInUnitedKingdom());
        assertNotNull(getDateThreeMonthsBeforeCurrentDateInUnitedKingdom());
        assertNotNull(getDateSixMonthsBeforeCurrentDateInUnitedKingdom());
        assertNotNull(getDateYearBeforeCurrentDateInUnitedKingdom());
    }

    @ParameterizedTest
    @CsvSource({"null,false", "  ,true", "2021-08-13,true"})
    void testDateValidity(String value, String expectation) {
        boolean expect = Boolean.parseBoolean(expectation);
        assertEquals(expect, isValidDate(value));
    }

    @ParameterizedTest
    @CsvSource({
        "null,false",
        "colin.wimble@mortgagemattersdirect.co.uk,true",
        "@mortgagemattersdirect.co.uk,false"
    })
    void testEmailFormat(String email, String expectation) {
        boolean expect = Boolean.parseBoolean(expectation);
        assertEquals(expect, isValidEmail(email));
    }

    @Test
    public void TestStatusDescriptionEnum() {
        assertNull(StatusDescription.getDescription(null));
        assertNull(StatusDescription.getDescription(""));
        assertNull(StatusDescription.getDescription("1"));
        assertEquals("Funds Returned After Completion", StatusDescription.getDescription("A"));
        assertEquals("Funds Returned Before Completion", StatusDescription.getDescription("B"));
        assertEquals("Completed", StatusDescription.getDescription("C"));
        assertEquals("Declined", StatusDescription.getDescription("D"));
        assertEquals("Live", StatusDescription.getDescription("L"));
        assertEquals("Application", StatusDescription.getDescription("P"));
        assertEquals("Refused", StatusDescription.getDescription("R"));
        assertEquals("Refused Illustration", StatusDescription.getDescription("F"));
        assertEquals("Declined Illustration", StatusDescription.getDescription("T"));
        assertEquals("Illustration", StatusDescription.getDescription("I"));
    }

    @Test
    void testConvertName() {
        assertEquals(capitalizeName("mORTgage"), "Mortgage");
        assertEquals(capitalizeName("mortgage"), "Mortgage");
        assertEquals(capitalizeName("TEST"), "Test");
        assertEquals(capitalizeName("testing mortgage"), "Testing Mortgage");
        assertEquals(capitalizeName("tesTing morTGage"), "Testing Mortgage");
    }
}
