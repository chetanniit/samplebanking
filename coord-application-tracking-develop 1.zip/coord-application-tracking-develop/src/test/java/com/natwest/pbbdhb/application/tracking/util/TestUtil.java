/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_FORMAT_YYYYMMDD;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.*;

import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.GMSTaskDescription;
import com.natwest.pbbdhb.application.tracking.model.MilestoneMappingInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.FirmBroker;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.*;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.Products;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Address;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicantInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Application;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationList;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.PropertyInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Status;
import com.natwest.pbbdhb.application.tracking.model.dto.response.common.Page;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.ApplicantDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.CurrentOpenTasksNumber;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.GmsApplicationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.MortgageInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.PageDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.ApplicationDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StageHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StatusInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.GranularTracking;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.*;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.valuation.Details;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.valuation.ValuationInformation;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TestUtil {
    public static final String APPLICANT_DOB = "1994-11-27";
    public static final String APPLICANT_FIRST_NAME = "ULBLN";
    public static final String APPLICANT_LAST_NAME = "EMNJUMJ";
    public static final String PROPERTY_POST_CODE = "ME5 9EH";
    public static final String BROKER_EMAIL_ID = "colin.wimble@mortgagemattersdirect.co.uk";
    public static final String BROKER_FIRST_NAME = "Colin";
    public static final String BROKER_LAST_NAME = "Wimble";
    public static final String BROKER_POST_CODE = "ME5 9LR";
    public static final String FIRM_NAME = "Mortgage Matters Direct";
    public static final String FIRM_POST_CODE = "ME5 9LR";
    public static final String FCA_NUMBER = "405444";
    public static final String DATE_RANGE_ALL = "All";
    public static final String PAGE_NUMBER = "1";
    public static final String RESULT_PER_PAGE = "10";
    public static final String SORT_BY = "Last Modified Date";
    public static final String SORT_ORDER = "Asc";
    public static final String REFERENCE_NUMBER = "84149729";
    public static final String YES = "Yes";
    public static final String TITLE_MR = "Mr";
    public static final String INVALID_USER_EMAIL_ID = "@mortgagemattersdirect.co.uk";
    public static final String INVALID_USER_FIRST_NAME = "Colin&";
    public static final String INVALID_USER_LAST_NAME = "Wimble,";
    public static final String INVALID_USER_FCA_NUMBER = "405444A";
    public static final String INVALID_USER_FIRM_NAME = "Mortgage Matters Direct?";
    public static final String MISSING_BRAND = "Missing request header 'brand'";

    public static ApplicationRequest getApplicationRequest() {
        return ApplicationRequest.builder()
                .applicantDob(APPLICANT_DOB)
                .applicantFirstName(APPLICANT_FIRST_NAME)
                .applicantLastName(APPLICANT_LAST_NAME)
                .propertyPostcode(PROPERTY_POST_CODE)
                .brokerEmailId(BROKER_EMAIL_ID)
                .brokerFirstName(BROKER_FIRST_NAME)
                .brokerLastName(BROKER_LAST_NAME)
                .brokerPostcode(BROKER_POST_CODE)
                .firmPostcode(FIRM_POST_CODE)
                .fcaNumber(FCA_NUMBER)
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }
    
    
    public static ApplicationListRequest getApplicationListRequest() {
        return ApplicationListRequest.builder()
                .applicantDob(APPLICANT_DOB)
                .applicantFirstName(APPLICANT_FIRST_NAME)
                .applicantLastName(APPLICANT_LAST_NAME)
                .propertyPostcode(PROPERTY_POST_CODE)
                .brokerEmailId(BROKER_EMAIL_ID)
                .brokerFirstName(BROKER_FIRST_NAME)
                .brokerLastName(BROKER_LAST_NAME)
                .brokerPostcode(BROKER_POST_CODE)
                .firmPostcode(FIRM_POST_CODE)
                .fcaNumber(FCA_NUMBER)
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }

    public static ApplicationRequest getApplicationRequestForGetApplicationsAPI() {
        return ApplicationRequest.builder()
                .brokerEmailId(BROKER_EMAIL_ID)
                .brokerFirstName(BROKER_FIRST_NAME)
                .brokerLastName(BROKER_LAST_NAME)
                .brokerPostcode(BROKER_POST_CODE)
                .firmPostcode(FIRM_POST_CODE)
                .fcaNumber(FCA_NUMBER)
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }

    public static ApplicationsResponse getApplicationsResponse() {
        return ApplicationsResponse.builder()
                .page(new Page(10, 58, 6, 1))
                .applications(
                        Collections.singletonList(
                                Application.builder()
                                        .applicantInformation(
                                                Collections.singletonList(
                                                        new ApplicantInformation(
                                                                TITLE_MR,
                                                                APPLICANT_FIRST_NAME,
                                                                APPLICANT_LAST_NAME,
                                                                new Date(),
                                                                YES)))
                                        .propertyInformation(
                                                new PropertyInformation(
                                                        new Address(PROPERTY_POST_CODE)))
                                        .status(
                                                new Status(
                                                        new Date(),
                                                        ZonedDateTime.now(),
                                                        "Offer",
                                                        "Your application is under Offer"))
                                        .referenceNumber(REFERENCE_NUMBER)
                                        .build()))
                .build();
    }
    
    
    public static ApplicationListResponse getApplicationListResponse() {
        return ApplicationListResponse.builder()
                .page(new Page(10, 58, 6, 1))
                .applications(
                        Collections.singletonList(
                                ApplicationList.builder().referenceNumber(REFERENCE_NUMBER).build()))
                .build();
    }

    private static Set<CurrentOpenTasksNumber> tasks(String... taskNumbers) {
        Set<CurrentOpenTasksNumber> set = new HashSet<>();
        for (String taskNumber : taskNumbers) {
            set.add(CurrentOpenTasksNumber.builder().taskNumber(taskNumber).build());
        }
        return set;
    }

    public static GmsApplicationResponse getGmsApplicationResponse() {
        return GmsApplicationResponse.builder()
                .page(new PageDetail(10, 58, 6, 1))
                .applications(
                        Collections.singletonList(
                                MortgageInformation.builder()
                                        .applicantDetail(
                                                new HashSet<>(
                                                        Collections.singletonList(
                                                                ApplicantDetail.builder()
                                                                        .dob(new Date())
                                                                        .firstName("EMNJ")
                                                                        .isMainApplicant("YES")
                                                                        .title("Mr")
                                                                        .lastName("HLBCMW")
                                                                        .build())))
                                        .openTasks(
                                                new HashSet<>(
                                                        Collections.singletonList(
                                                                new CurrentOpenTasksNumber("AIP"))))
                                        .propertyPostcode("ME5 8AA")
                                        .referenceNumber("84149729")
                                        .sequenceNumber("01")
                                        .stageNumber(21)
                                        .submissionDate(new Date())
                                        .updatedDate(ZonedDateTime.now())
                                        .build()))
                .build();
    }

    public static ApplicationDetailRequest getApplicationDetailRequest() {
        return ApplicationDetailRequest.builder()
                .brokerEmailId(BROKER_EMAIL_ID)
                .brokerFirstName(BROKER_FIRST_NAME)
                .brokerLastName(BROKER_LAST_NAME)
                .brokerPostcode(BROKER_POST_CODE)
                .firmPostcode(FIRM_POST_CODE)
                .fcaNumber(FCA_NUMBER)
                .build();
    }

    public static ApplicationDetailsResponse getApplicationDetailsResponse() {
        return ApplicationDetailsResponse.builder()
                .productInformation(getProductInformation())
                .solicitorInformation(getSolicitorInformation())
                .applicantInformation(getApplicantInformation())
                .applicationDetails(getHistoryDetails())
                .valuationInformation(getValuationDetail())
                .build();
    }

    public static ValuationDetail getValuationDetail() {
        return ValuationDetail.builder()
                .receivedDate(ZonedDateTime.now())
                .amount(new BigDecimal("400000"))
                .assessmentDate(ZonedDateTime.now())
                .assessmentSLA("2")
                .expiryDate(new Date())
                .fee(new BigDecimal("352"))
                .instructionDate(ZonedDateTime.now())
                .latestBookingDate(ZonedDateTime.now())
                .details(Collections.singletonList(getValuationHistoryDetails()))
                .build();
    }

    public static ValuationHistoryDetail getValuationHistoryDetails() {
        return ValuationHistoryDetail.builder()
                .bookingDate(ZonedDateTime.now())
                .date(ZonedDateTime.now())
                .typeDescription("Mortgage Valuation (Purchase)")
                .note("Valuation Report Received")
                .statusCode("")
                .statusDescription("")
                .typeCode("MV")
                .build();
    }

    public static ValuationInformation getValuationInformation() {
        return ValuationInformation.builder()
                .referenceNumber("84007554")
                .receivedDate(ZonedDateTime.now())
                .amount(new BigDecimal("400000"))
                .assessmentDate(ZonedDateTime.now())
                .assessmentSLA("2")
                .expiryDate(new Date())
                .fee(new BigDecimal("352"))
                .instructionDate(ZonedDateTime.now())
                .latestBookingDate(ZonedDateTime.now())
                .tenure("Freehold")
                .leaseTermRemaining("50")
                .bedroomCount("2")
                .feeStatus("Free")
                .EPCrating("E")
                .details(Collections.singletonList(getValuationDetails()))
                .build();
    }

    public static Details getValuationDetails() {
        return Details.builder()
                .bookingDate(ZonedDateTime.now())
                .date(ZonedDateTime.now())
                .typeDescription("Mortgage Valuation (Purchase)")
                .note("Valuation Report Received")
                .statusCode("")
                .statusDescription("")
                .typeCode("MV")
                .build();
    }

    public static HistoryDetails getHistoryDetails() {
        return HistoryDetails.builder()
                .stageHistory(Collections.singletonList(getStageHistoryDetail()))
                .build();
    }

    public static StageHistoryDetail getStageHistoryDetail() {
        return StageHistoryDetail.builder()
                .code("22")
                .stage("stage")
                .description("Holding Stage")
                .timeClosed(ZonedDateTime.now())
                .timeOpen(ZonedDateTime.now())
                .caseHistory(Collections.singletonList(getCaseHistoryDetail()))
                .build();
    }

    public static CaseHistoryDetail getCaseHistoryDetail() {
        return CaseHistoryDetail.builder()
                .code("R21")
                .description("We have received your client's payslips.")
                .event("event")
                .timeClosed(ZonedDateTime.now())
                .timeOpen(ZonedDateTime.now())
                .build();
    }

    public static ApplicationDetails getApplicationDetails() {
        return ApplicationDetails.builder()
                .caseHistory(Collections.singletonList(getCaseHistory()))
                .stageHistory(Collections.singletonList(getStageHistory()))
                .status(getStatus())
                .build();
    }

    private static StatusInfo getStatus() {
        return StatusInfo.builder()
                .submissionDate("2020/10/27")
                .lastUpdateDate("2021/06/18 T 16:25:41.000")
                .status("Offer")
                .statusDescription("Your application is under Offer")
                .subStatus("Attention")
                .subStatusDescription("")
                .ragStatus(AMBER)
                .ragDescription("Your application is in progress")
                .build();
    }

    public static StageHistory getStageHistory() {
        return StageHistory.builder()
                .code("22")
                .description("")
                .openDateTime(ZonedDateTime.now())
                .closedDateTime(ZonedDateTime.now())
                .build();
    }

    public static GranularTracking getGranularTracking(String state) {
        return GranularTracking.builder().state(state)
                .updatedDate(ZonedDateTime.now())
                .description("Please provide statement(s) evidencing the full deposit amount")
                .gmsCategory("Await")
                .gmsStageNumber("20")
                .requestedDate(ZonedDateTime.now()).build();
    }

    public static List<GranularTracking> getGranularTrackingList() {
        List<GranularTracking> granularTrackingList = new ArrayList<>();
        granularTrackingList.add(getGranularTracking("Open"));
        granularTrackingList.add(getGranularTracking("Close"));
        return granularTrackingList;
    }

    public static GranularTrackingDetail getGranularTrackingDetail(){
        return GranularTrackingDetail.builder().build();
    }

    public static StageHistory getExcludedStageHistory() {
        return StageHistory.builder()
                .code("95")
                .description("")
                .openDateTime(ZonedDateTime.now())
                .closedDateTime(ZonedDateTime.now())
                .build();
    }

    public static CaseHistory getCaseHistory() {
        return CaseHistory.builder()
                .code("A29")
                .description("We have received your client's payslips.")
                .event("event")
                .openDateTime(ZonedDateTime.now())
                .closedDateTime(ZonedDateTime.now())
                .build();
    }

    public static CaseHistory getExcludedCaseHistory() {
        return CaseHistory.builder()
                .code("AU1")
                .description("We have received your client's payslips.")
                .openDateTime(ZonedDateTime.now())
                .closedDateTime(ZonedDateTime.now())
                .build();
    }

    public static List<Applicant> getApplicantInformation() {
        return Collections.singletonList(
                Applicant.builder()
                        .title("MR")
                        .firstName("UNLBMJ")
                        .lastName("BPPK")
                        .isMainApplicant("YES")
                        .address(getAddressInfo())
                        .contact(getContact())
                        .build());
    }

    public static ProductInfo getProductInfo() {
        return ProductInfo.builder()
                .totalLoanAmount("280000")
                .ltv("70")
                .totalRepaymentAmount("1598.63")
                .feeAmount("995")
                .feeIncluded("0")
                .depositAmount("120000")
                .cashback("250")
                .feeStatusCode("PP")
                .mortgageTypeCode("P")
                .products(getProduct())
                .build();
    }

    public static ProductInformation getProductInformation() {
        return ProductInformation.builder()
                .totalLoanAmount("280000")
                .ltv("70")
                .totalRepaymentAmount("1598.63")
                .feeAmount("995")
                .feeIncluded("0")
                .depositAmount("120000")
                .cashback("250")
                .mortgageType("Purchase")
                .feeStatus("Paid")
                .products(getProductList())
                .build();
    }

    /**
     * static method to get list of Product
     *
     * @return List<Product>
     */
    public static List<Products> getProductList() {
        return Collections.singletonList(
                Products.builder()
                        .code("FO25949")
                        .altDesc("2 year fixed (remortgage)")
                        .desc("2yf 1.60% 310823 60% rm BTL")
                        .rate(new BigDecimal("1.6"))
                        .termYears("20")
                        .termMonths("0")
                        .repaymentAmount(new BigDecimal("278.91"))
                        .loanAmount(new BigDecimal("209184"))
                        .build());
    }

    /**
     * static method to get list of Product
     *
     * @return List<Product>
     */
    public static List<Product> getProduct() {
        return Collections.singletonList(
                Product.builder()
                        .code("FO25949")
                        .altDesc("2 year fixed (remortgage)")
                        .desc("2yf 1.60% 310823 60% rm BTL")
                        .rate(new BigDecimal("1.6"))
                        .termYears("20")
                        .termMonths("0")
                        .repaymentAmount(new BigDecimal("278.91"))
                        .loanAmount(new BigDecimal("209184"))
                        .build());
    }

    /**
     * This method return productInfor with Interest only
     *
     * @return ProductInfo
     */
    public static ProductInfo getInterestOnlyProduct() {
        return ProductInfo.builder()
                .products(
                        Collections.singletonList(
                                Product.builder().code("FO25949").interestOnly(true).build()))
                .build();
    }

    public static ProductInfo getPartAndPartProduct() {
        List<Product> list = new ArrayList<>();
        ProductInfo productInfo = ProductInfo.builder().build();
        Product p1 = new Product();
        p1.setCode("FO25949");
        p1.setTermYears("23");
        p1.setTermMonths("1");
        p1.setCapitalAndInterest(true);
        list.add(p1);
        Product p2 = new Product();
        p2.setCode("FO25949");
        p2.setRepaymentAmount(new BigDecimal("278.91"));
        p2.setLoanAmount(new BigDecimal("209184"));
        p2.setTermYears("23");
        p2.setTermMonths("8");
        p2.setInterestOnly(true);
        list.add(p2);
        productInfo.setProducts(list);
        return productInfo;
    }

    public static ProductInfo getCapitalAndInterestProduct() {
        List<Product> list = new ArrayList<>();
        ProductInfo productInfo = ProductInfo.builder().build();
        Product p1 = new Product();
        p1.setCode("FO25949");
        p1.setTermYears("23");
        p1.setTermMonths("1");
        p1.setCapitalAndInterest(true);
        list.add(p1);
        Product p2 = new Product();
        p2.setCode("FO25949");
        p2.setRepaymentAmount(new BigDecimal("278.91"));
        p2.setLoanAmount(new BigDecimal("209184"));
        p2.setTermYears("23");
        p2.setTermMonths("8");
        p2.setInterestOnly(false);
        list.add(p2);
        productInfo.setProducts(list);
        return productInfo;
    }

    public static SolicitorInformation getSolicitorInformation() {
        return SolicitorInformation.builder()
                .firmName("Attwells Solicitors LLP")
                .contactName("Harriet Smith")
                .contact(getContact())
                .address(getAddressInfo())
                .build();
    }

    public static AddressInfo getAddressInfo() {
        return AddressInfo.builder()
                .addressLine1("18 North Hill")
                .addressLine2("")
                .addressLine3("")
                .addressLine4("Colchester")
                .addressLine5("")
                .postCode("CO1 1DZ")
                .build();
    }

    public static Contact getContact() {
        return Contact.builder().email("01206 766 332").phone("laura.catania@attwells.com").build();
    }

    public static ApplicationDetailsInfo getApplicationDetailsInfo() {
        return ApplicationDetailsInfo.builder()
                .productInformation(getProductInfo())
                .solicitorInformation(getSolicitorInformation())
                .applicantInformation(getApplicantInformation())
                .applicationDetails(getApplicationDetails())
                .valuationInformation(getValuationInformation())
                .build();
    }

    public static GMSTaskDescription getTaskDescription() {
        return GMSTaskDescription.builder().description(APPLICANT_PLACE_HOLDER_TEXT).build();
    }

    public static GMSStageDescription getGMSStageDescription() {
        return GMSStageDescription.builder()
                .status("Assessment")
                .description("")
                .statusDetail("Your application is under Assessment")
                .build();
    }

    public static ApplicationRequest getInvalidApplicationRequest() {
        return ApplicationRequest.builder()
                .applicantDob("14/12/1984")
                .applicantFirstName("FRSYCIYFLB")
                .applicantLastName("UNPSN")
                .propertyPostcode("WV12 4EU")
                .brokerEmailId("darren.lenihan@fs.dixonscountrywide.co.uk")
                .brokerFirstName("Darren")
                .brokerLastName("Lenihan")
                .brokerPostcode("WV12 4JR")
                .firmPostcode("WV12 4JR")
                .fcaNumber("301684")
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }

    public static ApplicationRequest getValidApplicationRequestWithSpecialChar() {
        return ApplicationRequest.builder()
                .applicantDob("1984-12-14")
                .applicantFirstName("FRSYCIYFLB")
                .applicantLastName("UNPSN")
                .propertyPostcode("WV12 4EU")
                .brokerEmailId("darren.lenihan@fs.dixonscountrywide.co.uk")
                .brokerFirstName("Darren Noel")
                .brokerLastName("Lenihan")
                .brokerPostcode("WV12 4JR")
                .firmPostcode("WV12 4JR")
                .fcaNumber("301684")
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }

    public static ApplicationRequest getInValidApplicationRequestWithSpecialChar() {
        return ApplicationRequest.builder()
                .applicantDob("14-12-1984")
                .applicantFirstName("FRSYCIYFLB£")
                .applicantLastName("UNPSN@")
                .propertyPostcode("WV12@4EU")
                .brokerEmailId(".co.uk")
                .brokerFirstName("Darren Noel:")
                .brokerLastName("Lenihan,")
                .brokerPostcode("WV12 4JR")
                .firmPostcode("WV12 4JR")
                .fcaNumber("301684")
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }

    public static Map<String, MilestoneMappingInformation> getMilestoneMappingInformation() {
        Map<String, MilestoneMappingInformation> map = new HashMap<>();
        map.put(
                "1",
                MilestoneMappingInformation.builder()
                        .description("Pre-Assessment")
                        .ragStatus("AMBER or GREEN")
                        .tasks(new ArrayList<>())
                        .stages(Collections.singletonList("18"))
                        .build());
        map.put(
                "2",
                MilestoneMappingInformation.builder()
                        .description("Assessment")
                        .ragStatus("GREY OR AMBER or GREEN")
                        .stages(Arrays.asList("20,22,24,25".split(",")))
                        .tasks(Arrays.asList("A29,A30,A12,R29,DR2".split(",")))
                        .build());
        return map;
    }

    public static ApplicationDetailsInfo getApplicationDetailsInfoWithExcludedHistories() {
        return ApplicationDetailsInfo.builder()
                .productInformation(getProductInfo())
                .solicitorInformation(getSolicitorInformation())
                .applicantInformation(getApplicantInformation())
                .applicationDetails(getApplicationDetailsWithExcludedHistories())
                .valuationInformation(getValuationInformation())
                .build();
    }

    public static ApplicationDetails getApplicationDetailsWithExcludedHistories() {
        return ApplicationDetails.builder()
                .caseHistory(Arrays.asList(getCaseHistory(), getExcludedCaseHistory()))
                .stageHistory(Arrays.asList(getStageHistory(), getExcludedStageHistory()))
                .status(getStatus())
                .build();
    }

    public static ApplicationDetailRequest getInvalidApplicationDetailRequest() {
        return ApplicationDetailRequest.builder()
                .brokerEmailId(BROKER_EMAIL_ID)
                .brokerFirstName(BROKER_FIRST_NAME)
                .brokerLastName(BROKER_LAST_NAME)
                .brokerPostcode(BROKER_POST_CODE)
                .firmPostcode(FIRM_POST_CODE)
                .fcaNumber(FCA_NUMBER)
                .userEmailId(INVALID_USER_EMAIL_ID)
                .userFirstName(INVALID_USER_FIRST_NAME)
                .userLastName(INVALID_USER_LAST_NAME)
                .userFirmFCANumber(INVALID_USER_FCA_NUMBER)
                .userPrincipalFCANumber(INVALID_USER_FCA_NUMBER)
                .build();
    }

    public static Date getFormattedDate(String date) throws ParseException {
        DateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYYMMDD);
        return formatter.parse(date);
    }

    public static Map<String, String> getErrorMap() {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("451-completed", "Error 451 : Your client's application has been completed");
        errorMap.put(
                "451-soft-declined",
                "Error 451 : We are sorry but on this occasion we are unable to offer your client a mortgage. If you require further information or wish to appeal this decision please email intermediarydocs@natwest.com including the mortgage reference number");
        errorMap.put(
                "451-declined",
                "Error 451 : We are sorry but on this occasion we are unable to offer your client a mortgage. Thank you for considering NatWest for your mortgage application");
        errorMap.put(
                "451-refused",
                "Error 451 : Your client's mortgage application has now been closed. Thank you for considering NatWest for your mortgage application");
        errorMap.put(
                "500",
                "Error Code 500 : Authorisation failed. Please email fm-050328@rbos.co.uk with the mortgage account number and error code.");
        errorMap.put(
                "503",
                "Error 503 : Service Unavailable. Please try again later. We are aware of an issue and working to resolve this.");
        errorMap.put("413", "Error 413 : Please refine your search and try again.");
        errorMap.put("409", "Error 409 : Case Tracking data not available for this case.");
        errorMap.put("404", "Error 404 : Case Tracking data not available for this case.");
        errorMap.put("401", "Error Code 401 : Authentication failed. Please refresh and try again.");
        errorMap.put("400", "Error Code 400 : Authentication failed. Please contact our technical team on 0345 600 0205.");
        errorMap.put(
                "401-broker-validation-failure",
                "Error Code 401 : Authentication failed. Please contact our technical team on 0345 600 0205.");
        return errorMap;
    }

    public static Map<String, MilestoneMappingInformation>
            getMilestoneMappingInformationWithCancelledStage() {
        Map<String, MilestoneMappingInformation> map = new HashMap<>();

        map.put(
                "1",
                MilestoneMappingInformation.builder()
                        .description("Assessment")
                        .ragStatus("GREEN")
                        .stages(Arrays.asList("20,22,24,25".split(",")))
                        .tasks(Arrays.asList("A29,A30,A12".split(",")))
                        .build());
        map.put(
                "2",
                MilestoneMappingInformation.builder()
                        .description("Valuation")
                        .ragStatus("GREY")
                        .stages(Arrays.asList("30".split(",")))
                        .tasks(Arrays.asList("AVR,SVR,ATR,ARD".split(",")))
                        .build());
        map.put(
                "3",
                MilestoneMappingInformation.builder()
                        .description("Offer")
                        .ragStatus("GREY")
                        .stages(Arrays.asList("28,34,36,40".split(",")))
                        .tasks(Arrays.asList("T21".split(",")))
                        .build());
        map.put(
                "4",
                MilestoneMappingInformation.builder()
                        .description("Completion")
                        .ragStatus("RED")
                        .stages(Arrays.asList("80,84,85,90".split(",")))
                        .tasks(Arrays.asList("T85,T76,N/A,F/C".split(",")))
                        .build());
        return map;
    }

    public static Map<String, MilestoneMappingInformation>
            getMilestoneMappingInformationWithDeclinedStage() {
        Map<String, MilestoneMappingInformation> map = new HashMap<>();

        map.put(
                "1",
                MilestoneMappingInformation.builder()
                        .description("Assessment")
                        .ragStatus("GREEN")
                        .stages(Arrays.asList("20,22,24,25".split(",")))
                        .tasks(Arrays.asList("A29,A30,A12".split(",")))
                        .build());
        map.put(
                "2",
                MilestoneMappingInformation.builder()
                        .description("Valuation")
                        .ragStatus("GREY")
                        .stages(Arrays.asList("30".split(",")))
                        .tasks(Arrays.asList("AVR,SVR,ATR,ARD".split(",")))
                        .build());
        map.put(
                "3",
                MilestoneMappingInformation.builder()
                        .description("Offer")
                        .ragStatus("GREY")
                        .stages(Arrays.asList("28,34,36,40".split(",")))
                        .tasks(Arrays.asList("T21".split(",")))
                        .build());
        map.put(
                "4",
                MilestoneMappingInformation.builder()
                        .description("Completion")
                        .ragStatus("RED")
                        .stages(Arrays.asList("80,84".split(",")))
                        .tasks(Arrays.asList("T85,T76".split(",")))
                        .build());
        return map;
    }

    public static ApplicationDetails getApplicationDetailsObject() {
        List<CaseHistory> caseHistories = new ArrayList<>();
        CaseHistory caseHistory =
                CaseHistory.builder()
                        .code("A29")
                        .description("We have received your client's payslips.")
                        .openDateTime(ZonedDateTime.now())
                        .closedDateTime(ZonedDateTime.now())
                        .build();
        caseHistories.add(caseHistory);
        return ApplicationDetails.builder()
                .caseHistory(caseHistories)
                .stageHistory(Collections.singletonList(getStageHistory()))
                .status(getStatus())
                .build();
    }

    public static ApplicationRequest getInvalidAdminApplicationRequest() {
        return ApplicationRequest.builder()
                .applicantDob(APPLICANT_DOB)
                .applicantFirstName(APPLICANT_FIRST_NAME)
                .applicantLastName(APPLICANT_LAST_NAME)
                .propertyPostcode(PROPERTY_POST_CODE)
                .brokerEmailId(BROKER_EMAIL_ID)
                .brokerFirstName(BROKER_FIRST_NAME)
                .brokerLastName(BROKER_LAST_NAME)
                .brokerPostcode(BROKER_POST_CODE)
                .firmPostcode(FIRM_POST_CODE)
                .fcaNumber(FCA_NUMBER)
                .userEmailId(INVALID_USER_EMAIL_ID)
                .userFirstName(INVALID_USER_FIRST_NAME)
                .userLastName(INVALID_USER_LAST_NAME)
                .userFirmFCANumber(INVALID_USER_FCA_NUMBER)
                .userPrincipalFCANumber(INVALID_USER_FCA_NUMBER)
                .dateRange(DATE_RANGE_ALL)
                .pageNumber(PAGE_NUMBER)
                .resultPerPage(RESULT_PER_PAGE)
                .sortBy(SORT_BY)
                .sortOrder(SORT_ORDER)
                .build();
    }

    public static Set<FirmBroker> getInvalidFirmBrokers() {
        FirmBroker firmBroker1 =
                FirmBroker.builder()
                        .acceptMortgageBusiness("Yes")
                        .brokerEmail("mike.carter@brooksonfinancial.co.uk")
                        .brokerForeName("Carter")
                        .brokerSurname("Mike")
                        .fcaNumber("179752")
                        .build();

        FirmBroker firmBroker2 =
                FirmBroker.builder()
                        .acceptMortgageBusiness("No")
                        .brokerEmail("mike.carter12@brooksonfinancial.co.uk")
                        .brokerForeName("Mike")
                        .brokerSurname("Carter")
                        .fcaNumber("179753")
                        .build();

        Set<FirmBroker> firmBrokerSet = new HashSet<>();
        firmBrokerSet.add(firmBroker1);
        firmBrokerSet.add(firmBroker2);
        return firmBrokerSet;
    }

    public static CaseHistory getCaseHistory(
            String code, String description, String openDate, String closeDate, String status) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        ZonedDateTime openDateTime = ZonedDateTime.parse(openDate, formatter);
        ZonedDateTime closedDateTime = ZonedDateTime.parse(closeDate, formatter);
        return CaseHistory.builder()
                .code(code)
                .description(description)
                .openDateTime(openDateTime)
                .closedDateTime(closedDateTime)
                .status(status)
                .build();
    }

    public static List<CaseHistory> getECotPositiveCaseHistory() {
        List<CaseHistory> caseHistoryList = new ArrayList<>();

        CaseHistory caseHistory =
                getCaseHistory(
                        "R21",
                        "Assess Payslips",
                        "2021-05-27T10:36+00:00",
                        "2021-05-28T09:22+00:00",
                        "Close");
        caseHistoryList.add(caseHistory);

        CaseHistory caseHistory1 =
                getCaseHistory(
                        "AVR",
                        "Await Valuation Report",
                        "2021-05-27T16:23+00:00",
                        "2021-06-10T07:50+00:00",
                        "Close");
        caseHistoryList.add(caseHistory1);

        CaseHistory caseHistory2 =
                getCaseHistory(
                        "R16",
                        "Assess Employer Reference",
                        "2021-06-09T17:35+00:00",
                        "2021-06-10T13:04+00:00",
                        "Close");
        caseHistoryList.add(caseHistory2);

        CaseHistory caseHistory3 =
                getCaseHistory(
                        "SMS",
                        "Other Letter",
                        "2021-06-09T17:35+00:00",
                        "2021-06-10T13:01+00:00",
                        "Close");
        caseHistoryList.add(caseHistory3);

        CaseHistory caseHistory4 =
                getCaseHistory(
                        "SVR",
                        "Assess Valuation Report",
                        "2021-06-10T07:50+00:00",
                        "2021-06-10T13:46+00:00",
                        "Close");
        caseHistoryList.add(caseHistory4);

        CaseHistory caseHistory5 =
                getCaseHistory(
                        "AVR",
                        "Await Valuation Report",
                        "2021-06-10T13:23+00:00",
                        "2021-06-10T13:46+00:00",
                        "Close");
        caseHistoryList.add(caseHistory5);

        CaseHistory caseHistory6 =
                getCaseHistory(
                        "SMS",
                        "Other Letter",
                        "2021-06-14T14:36+00:00",
                        "2021-06-15T12:10+00:00",
                        "Close");
        caseHistoryList.add(caseHistory6);

        CaseHistory caseHistory7 =
                getCaseHistory(
                        "SMS",
                        "Other Letter",
                        "2021-06-14T14:36+00:00",
                        "2021-06-15T12:09+00:00",
                        "Close");
        caseHistoryList.add(caseHistory7);

        CaseHistory caseHistory8 =
                getCaseHistory(
                        "P20",
                        "Assess 2yrs SA302 / Tax Calcs",
                        "2021-06-14T14:36+00:00",
                        "2021-06-15T12:07+00:00",
                        "Close");
        caseHistoryList.add(caseHistory8);

        CaseHistory caseHistory9 =
                getCaseHistory(
                        "T21",
                        "Issue Offer",
                        "2021-06-16T17:21+00:00",
                        "2021-06-16T17:27+00:00",
                        "Close");
        caseHistoryList.add(caseHistory9);

        CaseHistory caseHistory10 =
                getCaseHistory(
                        "DDO",
                        "Signed DDM Outstanding",
                        "2021-06-16T17:27+00:00",
                        "2021-06-16T17:27+00:00",
                        "Close");
        caseHistoryList.add(caseHistory10);

        CaseHistory caseHistory11 =
                getCaseHistory(
                        "ARO",
                        "Await Certificate of Title",
                        "2021-06-16T17:27+00:00",
                        "2021-06-23T12:36+00:00",
                        "Close");
        caseHistoryList.add(caseHistory11);

        CaseHistory caseHistory12 =
                getCaseHistory(
                        "AEC",
                        "Assess E-Certificate of Title",
                        "2021-06-23T12:36+00:00",
                        "2021-06-23T13:06+00:00",
                        "Close");
        caseHistoryList.add(caseHistory12);

        CaseHistory caseHistory13 =
                getCaseHistory(
                        "FNE",
                        "ECOT Assess Prior To Funds Rel",
                        "2021-06-23T13:07+00:00",
                        "2021-06-23T13:14+00:00",
                        "Close");
        caseHistoryList.add(caseHistory13);

        CaseHistory caseHistory14 =
                getCaseHistory(
                        "E/C",
                        "Completed",
                        "2021-06-25T13:56+00:00",
                        "2021-06-25T13:56+00:00",
                        "Close");
        caseHistoryList.add(caseHistory14);
        return caseHistoryList;
    }

    public static List<CaseHistory> getECotNegativeCaseHistory() {
        List<CaseHistory> caseHistoryList = new ArrayList<>();

        CaseHistory caseHistory =
                getCaseHistory(
                        "AVR",
                        "Await Valuation Report",
                        "2021-05-25T10:56+00:00",
                        "2021-05-25T11:20+00:00",
                        "Close");
        caseHistoryList.add(caseHistory);

        CaseHistory caseHistory1 =
                getCaseHistory(
                        "SVR",
                        "Assess Valuation Report",
                        "2021-05-25T11:20+00:00",
                        "2021-05-25T13:30+00:00",
                        "Close");
        caseHistoryList.add(caseHistory1);

        CaseHistory caseHistory2 =
                getCaseHistory(
                        "R21",
                        "Assess Payslips",
                        "2021-05-25T11:36+00:00",
                        "2021-05-25T13:11+00:00",
                        "Close");
        caseHistoryList.add(caseHistory2);

        CaseHistory caseHistory3 =
                getCaseHistory(
                        "T21",
                        "Issue Offer",
                        "2021-06-01T11:55+00:00",
                        "2021-06-01T12:01+00:00",
                        "Close");
        caseHistoryList.add(caseHistory3);

        CaseHistory caseHistory4 =
                getCaseHistory(
                        "DDO",
                        "Signed DDM Outstanding",
                        "2021-06-01T12:01+00:00",
                        "2021-06-16T07:15+00:00",
                        "Close");
        caseHistoryList.add(caseHistory4);

        CaseHistory caseHistory5 =
                getCaseHistory(
                        "ARO",
                        "Await Certificate of Title",
                        "2021-06-01T12:01+00:00",
                        "2021-06-15T12:06+00:00",
                        "Close");
        caseHistoryList.add(caseHistory5);

        CaseHistory caseHistory6 =
                getCaseHistory(
                        "R21",
                        "Assess Payslips",
                        "2021-06-17T12:38+00:00",
                        "2021-06-17T14:30+00:00",
                        "Close");
        caseHistoryList.add(caseHistory6);

        CaseHistory caseHistory7 =
                getCaseHistory(
                        "SRM",
                        "Assess ECOT Manually",
                        "2021-06-17T14:33+00:00",
                        "2021-06-18T11:40+00:00",
                        "Close");
        caseHistoryList.add(caseHistory7);

        CaseHistory caseHistory8 =
                getCaseHistory(
                        "SCM",
                        "ECOT Comps 2nd Check",
                        "2021-06-17T19:06+00:00",
                        "2021-06-18T05:49+00:00",
                        "Close");
        caseHistoryList.add(caseHistory8);

        CaseHistory caseHistory9 =
                getCaseHistory(
                        "ACC",
                        "Await Completion Confirmation",
                        "2021-06-18T12:06+00:00",
                        "2021-06-18T13:35+00:00",
                        "Close");
        caseHistoryList.add(caseHistory9);

        return caseHistoryList;
    }
}
