/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.application.tracking.cucumber.stepdefs.ApiTestUtil;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.springframework.util.Assert;

public class CucumberTestProperties {

    private static FileBasedConfiguration prop = CucumberConfigReader.readProperties();

    private static TestEnvironment testEnv;

    // Commented the Code as its used for apigee implementation
//    public static String getBaseURI() {
//        if (getTestEnv().isAuthEnabled()) {
//            return getTestEnv().getApigeeUrl();
//        } else {
//            return getTestEnv().getPcfUrl();
//        }
//    }

    public static String getContentHeader() {
        return prop.getString("Content-Type");
    }

    public static TestEnvironment getTestEnv() {
        if (null == testEnv) {
            String testEnvProp = System.getProperty("testenv");
            Assert.notNull(testEnvProp, "testenv is null");
            testEnv = TestEnvironment.valueOf(testEnvProp.toUpperCase());
        }
        return testEnv;
    }

    public static String getTestEnvNew() {
        return prop.getString("testEnv");
    }

    public static String getServiceURI(String configURI) {
        if(getTestEnvNew().equals("DEV")) {
            return prop.getString(configURI);
        }
        return prop.getString(configURI).replace("dev.edi01",getTestEnvNew().toLowerCase()+".edi01");
    }

    public static String getJWTTokenForService(String serviceJWTId) throws JsonProcessingException {
        if(getTestEnvNew().equals("DEV")){
            return "";
        }
        return ApiTestUtil.getJWTToken(getTestEnvNew().toLowerCase(),serviceJWTId);
    }

    public static String getJWTTokenCoordAppTracking() throws JsonProcessingException {
        return getJWTTokenForService("coord-app-tracking");
    }

    public static String getBaseURI() {
        return getServiceURI("baseURI");
    }

    public static String getJWTTokenURI() { return prop.getString("JWTTokenURI"); }

    public static String getTestInputPath() {
        return prop.getString("testInputPath");
    }
}
