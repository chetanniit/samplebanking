/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.stepdefs;

import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Errors;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Errors.*;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.GET_APPLICATIONS_INPUT_JSON;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.COMPLETION;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.OFFER;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.application.tracking.jwt.AccessTokenGenerator;
import com.natwest.pbbdhb.application.tracking.jwt.AuthCredentialHolder;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.IOException;
import java.util.stream.StreamSupport;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

@Slf4j
public class GetApplicationsStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(GET_APPLICATIONS_INPUT_JSON);
    }

    private JsonNode validateAndGetApplications() {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertTrue(totalCount > 0);
        JsonNode applications = responseJsonNode.path(APPLICATIONS);
        Assertions.assertTrue(applications.size() > 0);
        Assertions.assertTrue(applications.isArray());
        return applications;
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(
                inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    private void validateArrayBadRequest(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        StringBuilder errorMsg = new StringBuilder();
        for (int i = 0; i < responseJsonNode.get(ERROR_MESSAGE).size(); i++) {
            errorMsg.append(responseJsonNode.get(ERROR_MESSAGE).get(i).asText());
        }
        for (String error : errorMessage) {
            Assertions.assertTrue(errorMsg.toString().contains(error));
        }
        Assertions.assertEquals(1, responseJsonNode.get(ERROR_MESSAGE).size());
        Assertions.assertEquals(
                inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());
    }

    @Given("Get Applications Service endpoint exists")
    public void getSearchApplicationsServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request in Get Application using input {string} and validate response code")
    public void userSendsRequestInGetApplicationUsingInputAndValidateResponseCode(String inputName)
            throws IOException {
        // Commented the Code as its used for apigee implementation
//        RequestSpecification request =
//                RestAssured.given()
//                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
//                        .accept(ContentType.JSON);
//        JsonNode testInput = inputsAsJsonNode.get(inputName);
//        Assertions.assertNotNull(testInput, Errors.INPUTS_MISSING_FOR_SCENARIO);
//        ApiTestUtil.createRequestForInputParams(testInput, request);
//        Response response;
//        if (CucumberTestProperties.getTestEnv().isAuthEnabled()) {
//            AuthCredentialHolder certJson = AccessTokenGenerator.getTokenHolder();
//            Assertions.assertNotNull(certJson.getBearerToken(), "bearerToken should not be null");
//            ApiTestUtil.prepareRequestWithBearerToken(request, certJson);
//            response = request.get(inputsAsJsonNode.get(PATH).asText());
//        } else {
//            response = request.get(inputsAsJsonNode.get(PATH).asText());
//        }
//        log.info(response.getHeaders().asList().toString());
//        log.info(response.getBody().prettyPrint());
//        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
//        Assertions.assertNotNull(response, "response is null");
//        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode testInput = inputsAsJsonNode.get(inputName);
        //ApiTestUtil.convertJsonNodeToCSVFormat(testInput);
        RequestSpecification request =
                RestAssured.given()
                        .log()
                        .all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCoordAppTracking())
                        .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request);
        Response response = request.get(inputsAsJsonNode.get(PATH).asText());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());


    }

    @Then("Verify no applications found for the input {string}")
    public void verifyNoApplicationsFoundForTheInput(String inputName) {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertEquals(0, totalCount);
    }

    @Then("Verify unique applications found for the input {string}")
    public void verifyUniqueApplicationsFoundForTheInput(String inputName) {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertEquals(1, totalCount);

        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(
                                            applicantInformation -> {
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_LAST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(LAST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_DOB),
                                                        applicantInformation.get(DOB));
                                            });
                            Assertions.assertEquals(
                                    inputs.get(PROPERTY_POSTCODE).asText().toLowerCase(),
                                    application
                                            .get(PROPERTY_INFORMATION)
                                            .get(ADDRESS)
                                            .get(POSTCODE)
                                            .asText()
                                            .toLowerCase());
                        });
    }

    @Then("Verify multiple applications found for the input {string}")
    public void verifyMultipleApplicationsFoundForTheInput(String inputName) {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertTrue(totalCount >= 2, Errors.APPLICANT_COUNT_LESS_THAN_2);
    }

    @Then("Verify applications for the input {string}")
    public void verifyJointApplicationsAndApplicantsForTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(
                                            applicantInformation -> {
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_LAST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(LAST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_DOB),
                                                        applicantInformation.get(DOB));
                                            });
                            Assertions.assertEquals(
                                    inputs.get(PROPERTY_POSTCODE).asText().toLowerCase(),
                                    application
                                            .get(PROPERTY_INFORMATION)
                                            .get(ADDRESS)
                                            .get(POSTCODE)
                                            .asText()
                                            .toLowerCase());
                        });
    }

    @Then("Verify applications Reg status Amber for the input {string}")
    public void verifyApplicantsRegStatusAmberForTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode status = applications.get(0).get(STATUS);
        Assertions.assertEquals(
                "Your application is Declined / Cancelled", status.get(STATUS_DESCRIPTION).asText());
    }

    @Then("Verify applications Reg status Red for the input {string}")
    public void verifyApplicantsRegStatusREDForTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode status = applications.get(1).get(STATUS);
        Assertions.assertEquals(
                "Your application is at Assessment",
                status.get(STATUS_DESCRIPTION).asText());
    }

    @Then("Verify unique applications last modified date found for the input {string}")
    public void verifyUniqueApplicationsLastModifiedDateFoundForTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            boolean isApplicantLastUpdatedDateFound =
                                    application
                                            .get(STATUS)
                                            .get(LAST_UPDATED_DATE)
                                            .textValue()
                                            .toLowerCase()
                                            .contains("2021-07-06T18:32+00:00".toLowerCase());
                            Assertions.assertTrue(
                                    isApplicantLastUpdatedDateFound,
                                    Errors.APPLICANT_LAST_UPDATED_DATE_NOT_MATCHED);
                        });
    }

    @Then("Verify unique applications page size found for the input {string}")
    public void verifyUniqueApplicationsPageSizeFoundForTheInput(String inputName) {
        int totalCount = responseJsonNode.get(PAGE).get(SIZE).asInt(0);
        Assertions.assertEquals(10, totalCount);
    }

    @Then("Verify unique applications submission date found for the input {string}")
    public void verifyUniqueApplicationsSubmissionDateFoundForTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            boolean isApplicantLastUpdatedDateFound =
                                    application
                                            .get(STATUS)
                                            .get(SUBMISSION_DATE)
                                            .textValue()
                                            .toLowerCase()
                                            .contains("2021-01-26");
                            Assertions.assertTrue(
                                    isApplicantLastUpdatedDateFound,
                                    Errors.APPLICANT_SUBMISSION_DATE_NOT_MATCHED);
                        });
    }

    @Then(
            "Verify unique applications with valid entry of mandatory fields along with optional field for the input {string}")
    public void
            verifyUniqueApplicationsWithValidEntryOfMandatoryFieldsAlongWithOptionalFieldForTheInput(
                    String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(
                                            applicantInformation -> {
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_LAST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(LAST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_DOB),
                                                        applicantInformation.get(DOB));
                                            });
                            Assertions.assertEquals(
                                    inputs.get(PROPERTY_POSTCODE).asText().toLowerCase(),
                                    application
                                            .get(PROPERTY_INFORMATION)
                                            .get(ADDRESS)
                                            .get(POSTCODE)
                                            .asText()
                                            .toLowerCase());
                        });
    }

    @Then("Verify self link in the response found for the input {string}")
    public void verifySelfLinkInTheResponseFoundForTheInput(String inputName) {
        boolean isSelfLinkFound =
                responseJsonNode
                        .get(LINK)
                        .get(SELF)
                        .get(HREF)
                        .textValue()
                        .
                        //
                        // equalsIgnoreCase("https://v1-coord-application-tracking-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/coord-application-tracking/applications?brokerEmailId=colin.wimble@mortgagemattersdirect.co.uk&brokerFirstName=colin&brokerLastName=wimble&brokerPostcode=ME5 9LR&fcaNumber=405444&firmName=Mortgage Matters Direct&firmPostcode=ME5 9LR&applicantFirstName=Kuoim&applicantLastName=Wuihmp&applicantDob=1994-11-09&propertyPostcode=ME5 0QS&dateRange=All&pageNumber=1&resultPerPage=10&sortBy=Last Modified Date&sortOrder=Desc");
                        contains("/mortgages/v1/application-tracking/applications?brokerEmailId=test@example.com&brokerUserName=WIMBLEC&brokerFirstName=Colin&brokerLastName=Wimble&brokerPostcode=ME5 9LR&fcaNumber=405444&firmPostcode=ME5 9LR&applicantFirstName=Kuoim&applicantLastName=Wuihmp&applicantDob=1994-11-09&propertyPostcode=ME5 0QS&dateRange=All&pageNumber=1&resultPerPage=10&sortBy=Last Modified Date&sortOrder=Desc");

                                //"/mortgages/v1/application-tracking/applications?brokerEmailId=colin.wimble@mortgagemattersdirect.co.uk&brokerFirstName=Colin&brokerLastName=Wimble&brokerPostcode=ME5 9LR&fcaNumber=405444&firmPostcode=ME5 9LR&applicantFirstName=Kuoim&applicantLastName=Wuihmp&applicantDob=1994-11-09&propertyPostcode=ME5 0QS&dateRange=All&pageNumber=1&resultPerPage=10&sortBy=Last Modified Date&sortOrder=Desc");
        //
        // "/mortgages/v1/application-tracking/applications?brokerEmailId=colin.wimble@mortgagemattersdirect.co.uk&brokerFirstName=Colin&brokerLastName=Wimble&brokerPostcode=ME5 9LR&fcaNumber=405444&firmPostcode=ME5 9LR&applicantFirstName=Kuoim&applicantLastName=Wuihmp&applicantDob=1994-11-09&propertyPostcode=ME5 0QS&dateRange=All&pageNumber=1&resultPerPage=10&sortBy=Last Modified Date&sortOrder=Desc"
        Assertions.assertTrue(isSelfLinkFound, Errors.MISSING_SELF_LINK);
    }

    @Then("Verify application self link in the response found for the input {string}")
    public void verifyApplicationSelfLinkInTheResponseFoundForTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            boolean isSelfLinkFound =
                                    application
                                            .get(LINK)
                                            .get(SELF)
                                            .get(HREF)
                                            .textValue()
                                            .
                                            //
                                            // //equalsIgnoreCase("https://v1-coord-application-tracking-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/coord-application-tracking/applicationDetails/84109200?brokerEmailId=colin.wimble@mortgagemattersdirect.co.uk&brokerFirstName=colin&brokerLastName=wimble&fcaNumber=405444&firmName=Mortgage Matters Direct&firmPostcode=ME5 9LR&brokerPostcode=ME5 9LR");
                                            // "/mortgages/v1/application-tracking/applicationDetails/84109200?brokerEmailId=colin.wimble@mortgagemattersdirect.co.uk&brokerFirstName=Colin&brokerLastName=Wimble&fcaNumber=405444&firmPostcode=ME5 9LR&brokerPostcode=ME5 9LR");
                                            contains("/mortgages/v1/application-tracking/applicationDetails/84050162?brokerEmailId=test@example.com&brokerUserName=WIMBLEC&brokerFirstName=Colin&brokerLastName=Wimble&fcaNumber=405444&firmPostcode=ME5 9LR&brokerPostcode=ME5 9LR&userFirstName&userLastName&userEmailId&userFirmFCANumber&userPrincipalFCANumber&userRole");
                                                    //"/mortgages/v1/application-tracking/applicationDetails/83837876?brokerEmailId=colin.wimble@mortgagemattersdirect.co.uk&brokerFirstName=Colin&brokerLastName=Wimble&fcaNumber=405444&firmPostcode=ME5 9LR&brokerPostcode=ME5 9LR&userFirstName&userLastName&userEmailId&userFirmFCANumber&userPrincipalFCANumber&userRole");
                            Assertions.assertTrue(isSelfLinkFound, Errors.MISSING_SELF_LINK);
                        });
    }

    @Then("Verify invalid Broker email id error for the input {string}")
    public void verifyInvalidBrokerEmailIdErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid Broker firstName error for the input {string}")
    public void verifyInvalidBrokerFirstNameErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid Broker lastName error for the input {string}")
    public void verifyInvalidBrokerLastNameErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid Broker fcaNumber error for the input {string}")
    public void verifyInvalidBrokerFcaNumberErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid Broker firmPostcode error for the input {string}")
    public void verifyInvalidBrokerFirmPostcodeErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify Broker in naughty list for the input {string}")
    public void verifyBrokerInNaughtyListForTheInput(String inputName) {
        Assertions.assertEquals(UNAUTHORIZED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(
                inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    @Then(
            "Verify the Application details endPoint status as Assessment based on GMS Stage numbers {string}")
    public void VerifyTheApplicationDetailsForAssessmentBasedOnGMSStageNumbers(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(1);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
    }

    @Then(
            "Verify the Application details endPoint status as Valuation based on GMS Stage numbers {string}")
    public void VerifyTheApplicationDetailsForValuationBasedOnGMSStageNumbers(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is at Valuation", status);
    }

    @Then(
            "Verify the Application details endPoint status as Offer based on GMS Stage numbers {string}")
    public void VerifyTheApplicationDetailsForOfferBasedOnGMSStageNumbers(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS).asText();
        Assertions.assertEquals(OFFER, status);
    }

    @Then(
            "Verify the Application details endPoint status Completion based on GMS Stage numbers {string}")
    public void VerifyTheApplicationDetailsForCompletionBasedOnGMSStageNumbers(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS).asText();
    }

    @Then(
            "Verify the Application details endPoint status description \"Your application is at Assessment\" as per status as Assessment {string}")
    public void VerifyTheApplicationDetailsForYourApplicationIsAtAssessment(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals(STATUS_APPLICATION_ASSESSMENT, status);
    }

    @Then(
            "Verify the Application details endPoint status description \"Your application is at Valuation\" as per status as Valuation {string}")
    public void VerifyTheApplicationDetailsForYourApplicationIsAtValuation(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals(STATUS_APPLICATION_VALUATION, status);
    }

    @Then(
            "Verify the Application details endPoint status description \"Your application is at Offer\" as per status as Offer {string}")
    public void VerifyTheApplicationDetailsForYourApplicationIsAtOffer(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals(STATUS_APPLICATION_OFFER, status);
    }

    @Then(
            "Verify the Application details endPoint status description \"Your application is at Completion\" as per status Completion {string}")
    public void VerifyTheApplicationDetailsForYourApplicationIsAtCompletion(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(1);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
    }

    @Then(
            "Verify user response Red as RAG Status when open task=0 + GMS stage more than 80 {string}")
    public void VerifyTheResponseRedAsRagStatus(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is Declined / Cancelled", status);
    }

    @Then("Verify user response Amber as RAG Status when open task > 0 + gms stage < 80 {string}")
    public void VerifyTheResponseAmberAsRagStatus(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is at Offer", status);
    }

    @Then(
            "Verify user response Red as RAG Status when open task > 0 + GMS stage more than 80 {string}")
    public void VerifyTheResponseRedAsRagStatusWhenOpenTask(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(1);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is Declined / Cancelled", status);
    }

    @Then(
            "Verify user response RAG Status description as \"Your application is in progress\" RAG Status as Amber {string}")
    public void VerifyTheResponseAmberAsRagStatsAsStatusDescription(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is at Assessment", status);
    }

    @Then(
            "Verify user response RAG Status description as \"Your application requires further decision\" RAG Status as Red {string}")
    public void VerifyTheResponseRedAsRagStatsAsStatusDescription(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(1);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is Declined / Cancelled", status);
    }

    @Then(
            "Verify the Status \"Assessment + Valuation\" for the stage number 20 if  AVR or SVR is open {string}")
    public void VerifyTheResponseForTheStageNumber20(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS).asText();
        Assertions.assertEquals(VALUATION, status);
    }

    @Then(
            "Verify the Status \"Assessment + Valuation\" for the stage number 22 if  AVR or SVR is open {string}")
    public void VerifyTheResponseForTheStageNumber22(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(1);
        String status = application.get(STATUS).get(STATUS_DESCRIPTION).asText();
        Assertions.assertEquals("Your application is at Valuation", status);
    }

    @Then(
            "Verify the Status \"Assessment + Valuation\" for the stage number 24 if  AVR or SVR is open {string}")
    public void VerifyTheResponseForTheStageNumber24(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS).asText();
        Assertions.assertEquals(ASSESSMENT, status);
    }

    @Then(
            "Verify the Status \"Assessment + Valuation\" for the stage number 25 if  AVR or SVR is open {string}")
    public void VerifyTheResponseForTheStageNumber25(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(2);
        String status = application.get(STATUS).get(STATUS).asText();
        Assertions.assertEquals(VALUATION, status);
    }

    @Then(
            "Verify the Status and Status Description for the stage number 50 and Open Task as SCC {string}")
    public void VerifyTheResponseForTheStageNumber22IfAvrOrSvrIsClosed(String inputName) {
        JsonNode application = responseJsonNode.get(APPLICATIONS).get(0);
        String status = application.get(STATUS).get(STATUS).asText();
        Assertions.assertEquals(COMPLETION, status);
    }

    @Then("Verify the application status for the response as DeclineCancelled {string}")
    public void verifyTheApplicationStatusForTheResponseAsDeclineCancelled(String inputName) {
        JsonNode applicationsArray = responseJsonNode.get(APPLICATIONS);
        StreamSupport.stream(applicationsArray.spliterator(), false)
                .forEach(
                        application -> {
                            if ("84150045"
                                    .equalsIgnoreCase(
                                            application.get("referenceNumber").asText())) {
                                String status = application.get(STATUS).get(STATUS).asText();
                                Assertions.assertEquals("Declined/Cancelled", status);
                            }
                        });
    }

    @Then("Verify the application status and status description when RAG status is RED {string}")
    public void verifyTheApplicationStatusAndStatusDescriptionWhenRAGStatusIsRED(String inputName) {
        JsonNode applicationsArray = responseJsonNode.get(APPLICATIONS);
        StreamSupport.stream(applicationsArray.spliterator(), false)
                .forEach(
                        application -> {
                            if ("84150045"
                                    .equalsIgnoreCase(
                                            application.get("referenceNumber").asText())) {
                                String status = application.get(STATUS).get(STATUS).asText();
                                String statusDesc =
                                        application.get(STATUS).get(STATUS_DESCRIPTION).asText();
                                Assertions.assertEquals("Declined/Cancelled", status);
                                Assertions.assertEquals(RED_STATUS_DESC, statusDesc);
                            }
                        });
    }

    @Then(
            "Verify the application status and status description when stage is less than {int} {string}")
    public void verifyTheApplicationStatusAndStatusDescriptionWhenStageIsLessThan(
            int arg0, String inputName) {
        JsonNode applicationsArray = responseJsonNode.get(APPLICATIONS);
        StreamSupport.stream(applicationsArray.spliterator(), false)
                .forEach(
                        application -> {
                            if ("84145778"
                                    .equalsIgnoreCase(
                                            application.get("referenceNumber").asText())) {
                                String status = application.get(STATUS).get(STATUS).asText();
                                String statusDesc =
                                        application.get(STATUS).get(STATUS_DESCRIPTION).asText();
                                Assertions.assertNotNull(status);
                                Assertions.assertNotNull(statusDesc);
                            }
                        });
    }

    @Then("Verify the response for invalid email format and invalid firm postcode format {string}")
    public void verifyTheResponseForInvalidEmailFormatAndInvalidBrokerPostcodeFormat(
            String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        StringBuilder errorMsg = new StringBuilder();
        for (int i = 0; i < responseJsonNode.get(ERROR_MESSAGE).size(); i++) {
            errorMsg.append(responseJsonNode.get(ERROR_MESSAGE).get(i).asText());
        }
        for (String error : errorMessage) {
            Assertions.assertTrue(errorMsg.toString().contains(error));
        }
        Assertions.assertEquals(2, responseJsonNode.get(ERROR_MESSAGE).size());
        Assertions.assertEquals(
                inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());
    }

    @Then("Verify the response for invalid  fcaNumber format and invalid page number {string}")
    public void verifyTheResponseForInvalidFcaNumberFormatAndInvalidPageNumber(String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        StringBuilder errorMsg = new StringBuilder();
        for (int i = 0; i < responseJsonNode.get(ERROR_MESSAGE).size(); i++) {
            errorMsg.append(responseJsonNode.get(ERROR_MESSAGE).get(i).asText());
        }
        for (String error : errorMessage) {
            Assertions.assertTrue(errorMsg.toString().contains(error));
        }
        Assertions.assertEquals(2, responseJsonNode.get(ERROR_MESSAGE).size());
        Assertions.assertEquals(
                inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());
    }

    @Then(
            "Verify get application for valid Firm Name for the solicitor information as the input {string}")
    public void verifyGetApplicationForValidFirmNameForTheSolicitorInformationAsTheInput(
            String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(
                                            applicantInformation -> {
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_LAST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(LAST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_DOB),
                                                        applicantInformation.get(DOB));
                                            });
                            Assertions.assertEquals(
                                    inputs.get(PROPERTY_POSTCODE).asText().toLowerCase(),
                                    application
                                            .get(PROPERTY_INFORMATION)
                                            .get(ADDRESS)
                                            .get(POSTCODE)
                                            .asText()
                                            .toLowerCase());
                        });
    }

    @Then(
            "Verify error message Applications service for entered invalid and blank values in mandatory fields for the input {string}")
    public void
            verifyErrorMessageApplicationsServiceForEnteredInvalidAndBlankValuesInMandatoryFieldsForTheInput(
                    String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        StringBuilder errorMsg = new StringBuilder();
        for (int i = 0; i < responseJsonNode.get(ERROR_MESSAGE).size(); i++) {
            errorMsg.append(responseJsonNode.get(ERROR_MESSAGE).get(i).asText());
        }
        for (String error : errorMessage) {
            Assertions.assertTrue(errorMsg.toString().contains(error));
        }
        Assertions.assertEquals(5, responseJsonNode.get(ERROR_MESSAGE).size());
        Assertions.assertEquals(
                inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());
    }

    // 51
    @Then(
            "I should get error for entered single character in applicantFirstName and required values in mandatory applicantLastname and applicantPostcode fields for the input {string}")
    public void
            iShouldGetErrorForEnteredSingleCharacterInApplicantFirstNameAndRequiredValuesInMandatoryApplicantLastnameAndApplicantPostcodeFieldsForTheInput(
                    String inputName) {
        validateArrayBadRequest(responseJsonNode, inputName);
    }

    // 52
    @Then(
            "I should get error for required values in mandatory applicantLastname and applicantPostcode fields for the input {string}")
    public void
            iShouldGetErrorForRequiredValuesInMandatoryApplicantLastnameAndApplicantPostcodeFieldsForTheInput(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 53
    @Then(
            "I should get error for entered single character in applicantLastName and blank value for mandatory propertyPostcode fields for the input {string}")
    public void
            iShouldGetErrorForEnteredSingleCharacterInApplicantLastNameAndBlankValueForMandatoryPropertyPostcodeFieldsForTheInput(
                    String inputName) {
        validateArrayBadRequest(responseJsonNode, inputName);
    }

    // 54
    @Then(
            "I should get error for blank values in mandatory applicantPostcode field for the input {string}")
    public void iShouldGetErrorForBlankValuesInMandatoryApplicantPostcodeFieldForTheInput(
            String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 55
    @Then(
            "I should get error for blank values in mandatory applicantPostcode field when applicantFirstname and applicantLastname provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryApplicantPostcodeFieldWhenApplicantFirstnameAndApplicantLastnameProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 56
    @Then("Verify I should be able to find the list of applicants {string}")
    public void verifyIShouldBeAbleToFindTheListOfApplicants(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }

    // 57
    @Then(
            "I should get error for blank values in mandatory applicantPostcode field when applicantLastname provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryApplicantPostcodeFieldWhenApplicantLastnameProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 58
    @Then(
            "Verify I should be able to find the list of applicants when applicantLastName and propertyPostcode provided {string}")
    public void
            verifyIShouldBeAbleToFindTheListOfApplicantsWhenApplicantLastNameAndPropertyPostcodeProvided(
                    String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }

    // 59
    @Then(
            "I should get error for blank values in mandatory applicantLastname field when applicantFirstName and propertyPostcode provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryApplicantLastnameFieldWhenApplicantFirstNameAndPropertyPostcodeProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 60
    @Then(
            "Verify I should be able to find the list of applicants when applicantFirstName, applicantLastName and propertyPostcode provided {string}")
    public void
            verifyIShouldBeAbleToFindTheListOfApplicantsWhenApplicantFirstNameApplicantLastNameAndPropertyPostcodeProvided(
                    String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }

    @Then(
            "Verify I should be able to find the list of applicants when applicantFirstName, applicantLastName, applicantDOB and propertyPostcode provided {string}")
    public void
            verifyIShouldBeAbleToFindTheListOfApplicantsWhenApplicantFirstNameApplicantLastNameApplicantDOBAndPropertyPostcodeProvided(
                    String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }

    // 62
    @Then(
            "I should get error for blank values in mandatory applicantLastname field when applicantDOB and propertyPostcode provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryApplicantLastnameFieldWhenApplicantDOBAndPropertyPostcodeProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 63
    @Then(
            "I should get error for blank values in mandatory applicantLastname and propertyPostcode field when applicantDOB provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryApplicantLastnameAndPropertyPostcodeFieldWhenApplicantDOBProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 64
    @Then(
            "I should get error for blank values in mandatory propertyPostcode field when applicantDOB and applicantLastName provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryPropertyPostcodeFieldWhenApplicantDOBAndApplicantLastNameProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 65
    @Then(
            "Verify I should be able to find the list of applicants when applicantLastName, applicantDOB and propertyPostcode provided {string}")
    public void
            verifyIShouldBeAbleToFindTheListOfApplicantsWhenApplicantLastNameApplicantDOBAndPropertyPostcodeProvided(
                    String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }

    // 66
    @Then(
            "I should get error for blank values in mandatory applicantLastName field when applicantDOB and propertyPostcode provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryApplicantLastNameFieldWhenApplicantDOBAndPropertyPostcodeProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 67
    @Then(
            "I should get error for blank values in mandatory propertyPostcode field when applicantDOB, applicantFirstName and applicantLastName provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryPropertyPostcodeFieldWhenApplicantDOBApplicantFirstNameAndApplicantLastNameProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    // 68
    @Then(
            "I should get error for blank values in mandatory propertyPostcode and applicantLastName field when applicantDOB and applicantFirstName provided {string}")
    public void
            iShouldGetErrorForBlankValuesInMandatoryPropertyPostcodeAndApplicantLastNameFieldWhenApplicantDOBAndApplicantFirstNameProvided(
                    String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("validate the applications for stage ninety two with {string}")
    public void validateTheApplicationsForStageNinetyTwoWith(String arg0) {
        Assert.assertNotNull(responseJsonNode);
    }

    @Then("verify the status of status object applications for stage ninety two with {string}")
    public void verifyTheStatusOfStatusObjectApplicationsForStageNinetyTwoWith(String arg0) {
        JsonNode applications = validateAndGetApplications();
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            if (application.get(REFERENCE_NUMBER).asText().equals("84140549")) {
                                JsonNode status = application.get(STATUS);
                                Assert.assertEquals(COMPLETION, status.get(STATUS).asText());
                            }
                        });
    }

    @Then(
            "Verify Applicant first name,last name are converted the names in to capitalization in broker get applications for the input {string}")
    public void
            verifyApplicantFirstNameLastNameAreConvertedTheNamesInToCapitalizationInBrokerGetApplicationsForTheInput(
                    String arg0) {
        JsonNode applications = responseJsonNode.get(APPLICATIONS).get(0);
        Assertions.assertTrue(applications.size() > 0);
        Assert.assertEquals(
                "Eycrl", applications.get(APPLICANT_INFORMATION).get(0).get(FIRST_NAME).asText());
        Assert.assertEquals(
                "Hmmsn", applications.get(APPLICANT_INFORMATION).get(0).get(LAST_NAME).asText());
    }

    @Then(
            "Verify irrespective of names coming from GMS,API will always display the name in presentable format in broker get applications for the input {string}")
    public void
            verifyIrrespectiveOfNamesComingFromGMSAPIWillAlwaysDisplayTheNameInPresentableFormatInBrokerGetApplicationsForTheInput(
                    String arg0) {
        JsonNode applications = responseJsonNode.get(APPLICATIONS).get(0);
        Assertions.assertTrue(applications.size() > 0);
        Assert.assertEquals(
                "Eycrl", applications.get(APPLICANT_INFORMATION).get(0).get(FIRST_NAME).asText());
        Assert.assertEquals(
                "Hmmsn", applications.get(APPLICANT_INFORMATION).get(0).get(LAST_NAME).asText());
    }

    @Then("Verify invalid user Firm FCA Number error for the applications input {string}")
    public void verifyInvalidUserFirmFCANumberErrorForTheApplicationsInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user email id error for the applications input {string}")
    public void verifyInvalidUserEmailIdErrorForTheApplicationsInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user First Name error for the applications input {string}")
    public void verifyInvalidUserFirstNameErrorForTheApplicationsInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Last Name error for the applications input {string}")
    public void verifyInvalidUserLastNameErrorForTheApplicationsInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Principle FCA Number error for the applications input {string}")
    public void verifyInvalidUserPrincipleFCANumberErrorForTheApplicationsInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Role error for the applications input {string}")
    public void verifyInvalidUserRoleErrorForTheApplicationsInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify application found for the nft input {string}")
    public void verifyApplicationFoundForTheNftInput(String inputName) {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertEquals(1, totalCount);

        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(
                                            applicantInformation -> {
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(FIRST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_LAST_NAME)
                                                                .asText()
                                                                .toLowerCase(),
                                                        applicantInformation
                                                                .get(LAST_NAME)
                                                                .asText()
                                                                .toLowerCase());
                                                Assertions.assertEquals(
                                                        inputs.get(APPLICANT_DOB),
                                                        applicantInformation.get(DOB));
                                            });
                            Assertions.assertEquals(
                                    inputs.get(PROPERTY_POSTCODE).asText().toLowerCase(),
                                    application
                                            .get(PROPERTY_INFORMATION)
                                            .get(ADDRESS)
                                            .get(POSTCODE)
                                            .asText()
                                            .toLowerCase());
                        });
    }



    @Then("Verify FCA number, surname and postcode but with different first name and email address and both are allowed in CRM for applications the input {string}")
    public void verifyFCANumberSurnameAndPostcodeButWithDifferentFirstNameAndEmailAddressAndBothAreAllowedInCRMForApplicationsTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }


    @Then("Verify FCA number, surname and postcode but with different first name and email address and one is allowed in CRM while other one has left the firm for applications the input {string}")
    public void verifyFCANumberSurnameAndPostcodeButWithDifferentFirstNameAndEmailAddressAndOneIsAllowedInCRMWhileOtherOneHasLeftTheFirmForApplicationsTheInput(String inputName) {
        JsonNode applications = validateAndGetApplications();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(applications.spliterator(), false)
                .forEach(
                        application -> {
                            JsonNode applicantInformationArray =
                                    application.get(APPLICANT_INFORMATION);
                            StreamSupport.stream(applicantInformationArray.spliterator(), false)
                                    .forEach(applicantInformation -> {});
                        });
    }

    @Then("Verify FCA number, surname and postcode but with different first name and email address one has left the firm for applications the input {string}")
    public void verifyFCANumberSurnameAndPostcodeButWithDifferentFirstNameAndEmailAddressOneHasLeftTheFirmForApplicationsTheInput(String inputName) {
        Assertions.assertEquals(UNAUTHORIZED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    @Then("Verify applications returned to the given broker details {string}")
    public void verifyApplicationsReturnedToTheGivenBrokerDetails(String inputName) {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertTrue(totalCount > 0);
    }

    @Then("Verify applications returned bad request for a given invalid broker first name {string}")
    public void verifyApplicationsReturnedBadRequestForAGivenInvalidBrokerFirstName(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify applications returned bad request for a given invalid broker last name {string}")
    public void verifyApplicationsReturnedBadRequestForAGivenInvalidBrokerLastName(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify applications returned bad request for a given invalid broker value {string}")
    public void verifyApplicationsReturnedBadRequestForAGivenInvalidBrokerValue(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }
}
