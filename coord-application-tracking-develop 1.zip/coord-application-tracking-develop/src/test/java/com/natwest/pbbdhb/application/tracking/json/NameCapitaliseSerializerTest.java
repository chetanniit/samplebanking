/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.json;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.Applicant;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

@Slf4j
class NameCapitaliseSerializerTest {

    @Test
    void testSerialise() throws JsonProcessingException {
        Applicant applicant =
                Applicant.builder()
                        .firstName("flow management")
                        .lastName("digital home buying")
                        .title("uicoord application tracking")
                        .build();
        ObjectMapper mapper = new ObjectMapper();
        String applicantJson =
                mapper.writerWithDefaultPrettyPrinter().writeValueAsString(applicant);
        log.info(applicantJson);
        JsonNode applicantJsonNode = mapper.readTree(applicantJson);
        Assertions.assertEquals("Flow Management", applicantJsonNode.get("firstName").asText());
        Assertions.assertEquals("Digital Home Buying", applicantJsonNode.get("lastName").asText());
        Assertions.assertEquals(
                "uicoord application tracking", applicantJsonNode.get("title").asText());
    }
}
