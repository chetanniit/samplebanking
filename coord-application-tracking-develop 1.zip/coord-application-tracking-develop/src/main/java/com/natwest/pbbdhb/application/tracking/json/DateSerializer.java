/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.json;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UTC_TIME_ZONE;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.jackson.JsonComponent;

@JsonComponent
@Slf4j
public class DateSerializer {

    private static final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern(DATE_TIME_FORMAT).withZone(ZoneId.of(UTC_TIME_ZONE));

    public static class Serialize extends JsonSerializer<ZonedDateTime> {

        @Override
        public void serialize(
                ZonedDateTime value, JsonGenerator gen, SerializerProvider serializers) {
            try {
                if (value == null) {
                    gen.writeNull();
                } else {
                    gen.writeString(formatter.format(value));
                }
            } catch (Exception e) {
                log.error("Exception occurred while serialize the date :{}", e);
            }
        }
    }

    public static class Deserialize extends JsonDeserializer<ZonedDateTime> {

        @Override
        public ZonedDateTime deserialize(JsonParser p, DeserializationContext ctxt) {
            try {
                String dateAsString = p.getText();

                if (dateAsString == null) {
                    return null;
                } else {
                    return ZonedDateTime.parse(dateAsString, formatter);
                }
            } catch (Exception e) {
                log.error("Exception occurred while Deserialize the date :{}", e);
            }
            return null;
        }
    }
}
