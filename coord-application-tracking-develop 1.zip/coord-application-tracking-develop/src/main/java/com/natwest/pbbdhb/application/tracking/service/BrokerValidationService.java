/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerValidationResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class BrokerValidationService {

    @Value("${ms.brokerValidate.endpoint}")
    private String brokerValidationURL;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    public BrokerValidationResponse validateBroker(
            BrokerValidationRequest brokerValidationRequest) {
        log.info("validateBroker method entered in BrokerValidationService class");
        ResponseEntity<BrokerValidationResponse> responseEntity;
        responseEntity =
                restTemplate.exchange(
                        brokerValidationURL,
                        HttpMethod.POST,
                        getHeader(brokerValidationRequest),
                        BrokerValidationResponse.class);
        BrokerValidationResponse brokerValidationResponse = responseEntity.getBody();
        log.debug("Response from broker validation service : {}", brokerValidationResponse);
        return brokerValidationResponse;
    }

    private HttpEntity<BrokerValidationRequest> getHeader(
            BrokerValidationRequest brokerValidationRequest) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Content-Type", "application/json");
        return new HttpEntity<>(brokerValidationRequest, httpHeaders);
    }
}
