/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UK_TIME_ZONE;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UTC_TIME_ZONE;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.DateSerializer;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Set;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
public class MortgageInformation {

    private String referenceNumber;
    private String sequenceNumber;
    private Set<ApplicantDetail> applicantDetail;
    private String propertyPostcode;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT, timezone = UK_TIME_ZONE)
    private Date submissionDate;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime updatedDate;

    private int stageNumber;
    private Set<CurrentOpenTasksNumber> openTasks;
}
