/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

/** This class has all the constants related to errors */
public class ErrorConstant {

    public static final String ERROR_CODE_400 = "400";
    public static final String ERROR_CODE_401 = "401";
    public static final String ERROR_CODE_500 = "500";
    public static final String ERROR_CODE_503 = "503";
    public static final String ERROR_CODE_451_COMPLETED = "451-completed";
    public static final String ERROR_CODE_451_SOFT_DECLINED = "451-soft-declined";
    public static final String ERROR_CODE_451_DECLINED = "451-declined";
    public static final String ERROR_CODE_451_REFUSED = "451-refused";
    public static final String ERROR_CODE_401_BROKER_VALIDATION_FAILURE =
            "401-broker-validation-failure";

    public static final String APPLICATION_DETAILS = "applicationDetails";
    public static final String APPLICATIONS = "applications";

    public static final String GMS_APPLICATION_DETAIL = "gms-applicationDetail";
    public static final String GMS_APPLICATION_INFORMATION = "gms-applicationInformation";
    public static final String GMS_VALUATION_INFORMATION = "gms-valuationInformation";
    public static final String GMS_APPLICATIONS = "gms-applications";
    public static final String GMS_BROKER_APPLICATIONS_SEARCH = "gms-brokerApplicationsSearch";

    private ErrorConstant() {}
}
