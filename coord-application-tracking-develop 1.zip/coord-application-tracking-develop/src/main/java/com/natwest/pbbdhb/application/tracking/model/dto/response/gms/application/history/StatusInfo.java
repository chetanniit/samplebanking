/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_FORMAT_YYYYMMDD;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class StatusInfo {

    private String submissionDate;
    private String lastUpdateDate;
    private String status;
    private String statusDescription;
    private String ragStatus;
    private String ragDescription;
    private String subStatus;
    private String subStatusDescription;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT_YYYYMMDD)
    private Date completionDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT_YYYYMMDD)
    private Date expectedEffectiveDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT_YYYYMMDD)
    private Date actualEffectiveDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT_YYYYMMDD)
    private Date declinedDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT_YYYYMMDD)
    private Date refusedDate;
}
