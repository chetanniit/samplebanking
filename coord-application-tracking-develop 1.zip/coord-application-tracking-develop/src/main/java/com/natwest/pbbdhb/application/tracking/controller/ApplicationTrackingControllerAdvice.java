/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.controller;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.BRAND;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.MISSING_BRAND;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.APPLICATIONS;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.APPLICATION_DETAILS;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.ERROR_CODE_400;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.ERROR_CODE_401;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.ERROR_CODE_500;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.ERROR_CODE_503;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.model.exception.ApplicationDetailsProcessFailException;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.model.exception.ErrorResponse;
import com.natwest.pbbdhb.application.tracking.model.exception.GMSErrorResponse;
import com.natwest.pbbdhb.application.tracking.model.exception.GMSStageNotFoundException;
import com.natwest.pbbdhb.application.tracking.model.exception.InvalidApplicantDetailsException;
import com.natwest.pbbdhb.application.tracking.model.exception.LegalReasonException;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class ApplicationTrackingControllerAdvice extends ResponseEntityExceptionHandler {

    private final ObjectMapper objectMapper;
    private final ErrorMessageConfigReader errorMessageConfigReader;

    @ExceptionHandler(BrokerValidationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBrokerValidationsException(
            BrokerValidationException ex, WebRequest request) {
        log.error("BrokerValidationsException : Error messages - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(
                        new ErrorResponse(
                                HttpStatus.UNAUTHORIZED.value(),
                                HttpStatus.UNAUTHORIZED,
                                Collections.singletonList(ex.getMessage()),
                                new Date()));
    }

    @ExceptionHandler(InvalidApplicantDetailsException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> InvalidApplicantDeatilsException(
            InvalidApplicantDetailsException ex, WebRequest request) {
        log.error("InvalidApplicantDeatilsException : Error messages - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(
                        new ErrorResponse(
                                HttpStatus.BAD_REQUEST.value(),
                                HttpStatus.BAD_REQUEST,
                                Collections.singletonList(ex.getMessage()),
                                new Date()));
    }

    @ExceptionHandler(GMSStageNotFoundException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleGMSStageNotFoundException(
            BrokerValidationException ex, WebRequest request) {
        log.error("GMSStageNotFoundException : Error messages - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(
                        new ErrorResponse(
                                HttpStatus.NOT_FOUND.value(),
                                HttpStatus.NOT_FOUND,
                                Collections.singletonList(ex.getMessage()),
                                new Date()));
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(
            ConstraintViolationException exception, WebRequest request) {
        Set<String> errorMessages =
                exception.getConstraintViolations().stream()
                        .map(ConstraintViolation::getMessage)
                        .map(this::constructErrorMessage)
                        .collect(Collectors.toSet());
        log.error(
                "ConstraintViolationException while processing request, Error messages - {}",
                errorMessages);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(
                        new ErrorResponse(
                                HttpStatus.BAD_REQUEST.value(),
                                HttpStatus.BAD_REQUEST,
                                new ArrayList<>(errorMessages),
                                new Date()));
    }

    private String constructErrorMessage(String fieldName) {
        return MessageFormat.format(
                errorMessageConfigReader.getMessage().get(ERROR_CODE_400), fieldName);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {

        List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();

        List<String> errorMessages =
                fieldErrors.stream()
                        .map(DefaultMessageSourceResolvable::getDefaultMessage)
                        .collect(Collectors.toList());

        log.error(
                "MethodArgumentNotValidException while processing request, Error messages - {}",
                errorMessages);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(
                        new ErrorResponse(
                                HttpStatus.BAD_REQUEST.value(),
                                HttpStatus.BAD_REQUEST,
                                errorMessages,
                                new Date()));
    }

    @ExceptionHandler({HttpClientErrorException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpClientErrorException(
            HttpClientErrorException ex, WebRequest request) {
        log.error(
                "http client error exception occurred while processing the request : {}",
                ex.getResponseBodyAsString());
        if (HttpStatus.NOT_FOUND.value() == ex.getRawStatusCode()) {
            GMSErrorResponse gmsErrorResponse = convertToObject(ex.getResponseBodyAsString());
            if (Objects.nonNull(gmsErrorResponse)
                    && Objects.nonNull(gmsErrorResponse.getErrorMessage())) {
                return ResponseEntity.status(ex.getStatusCode())
                        .body(
                                new ErrorResponse(
                                        gmsErrorResponse.getResponseCode(),
                                        gmsErrorResponse.getResponseStatus(),
                                        Collections.singletonList(
                                                getErrorMessage(gmsErrorResponse, request)),
                                        new Date()));
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(
                                new ErrorResponse(
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        HttpStatus.INTERNAL_SERVER_ERROR,
                                        Collections.singletonList(
                                                errorMessageConfigReader
                                                        .getMessage()
                                                        .get(ERROR_CODE_500)),
                                        new Date()));
            }
        }

        if (HttpStatus.FORBIDDEN.value() == ex.getRawStatusCode()) {
            GMSErrorResponse gmsErrorResponse = convertToObject(ex.getResponseBodyAsString());
            return ResponseEntity.status(ex.getStatusCode())
                    .body(
                            new ErrorResponse(
                                    gmsErrorResponse.getResponseCode(),
                                    gmsErrorResponse.getResponseStatus(),
                                    Collections.singletonList(
                                            getErrorMessage(gmsErrorResponse, request)),
                                    new Date()));
        }

        if (HttpStatus.CONFLICT.value() == ex.getRawStatusCode()) {
            GMSErrorResponse gmsErrorResponse = convertToObject(ex.getResponseBodyAsString());
            return ResponseEntity.status(ex.getStatusCode())
                    .body(
                            new ErrorResponse(
                                    gmsErrorResponse.getResponseCode(),
                                    gmsErrorResponse.getResponseStatus(),
                                    Collections.singletonList(
                                            getErrorMessage(gmsErrorResponse, request)),
                                    new Date()));
        }

        if (HttpStatus.PAYLOAD_TOO_LARGE.value() == ex.getRawStatusCode()) {
            GMSErrorResponse gmsErrorResponse = convertToObject(ex.getResponseBodyAsString());
            return ResponseEntity.status(ex.getStatusCode())
                    .body(
                            new ErrorResponse(
                                    gmsErrorResponse.getResponseCode(),
                                    gmsErrorResponse.getResponseStatus(),
                                    Collections.singletonList(
                                            getErrorMessage(gmsErrorResponse, request)),
                                    new Date()));
        }

        if (HttpStatus.UNAUTHORIZED.value() == ex.getRawStatusCode()) {
            return ResponseEntity.status(ex.getStatusCode())
                    .body(
                            new ErrorResponse(
                                    HttpStatus.UNAUTHORIZED.value(),
                                    ex.getStatusCode(),
                                    Collections.singletonList(
                                            errorMessageConfigReader
                                                    .getMessage()
                                                    .get(ERROR_CODE_401)),
                                    new Date()));
        }

        if (HttpStatus.BAD_REQUEST.value() == ex.getRawStatusCode()) {
            GMSErrorResponse gmsErrorResponse = convertToObject(ex.getResponseBodyAsString());
            if (Objects.nonNull(gmsErrorResponse)) {
                return ResponseEntity.status(ex.getStatusCode())
                        .body(
                                new ErrorResponse(
                                        HttpStatus.BAD_REQUEST.value(),
                                        gmsErrorResponse.getResponseStatus(),
                                        Collections.singletonList(
                                                getErrorMessage(gmsErrorResponse, request)),
                                        new Date()));
            }
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(
                        new ErrorResponse(
                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                HttpStatus.INTERNAL_SERVER_ERROR,
                                Collections.singletonList(
                                        errorMessageConfigReader.getMessage().get(ERROR_CODE_500)),
                                new Date()));
    }

    private GMSErrorResponse convertToObject(String content) {
        GMSErrorResponse gmsErrorResponse = GMSErrorResponse.builder().build();
        try {
            gmsErrorResponse = objectMapper.readValue(content, GMSErrorResponse.class);
        } catch (Exception e) {
            log.error("Error occurred while processing the request : {}", content);
        }
        return gmsErrorResponse;
    }

    @ExceptionHandler({HttpServerErrorException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpServerErrorException(
            HttpServerErrorException ex) {
        log.error(
                "Server error occurred while processing the request : {}",
                ex.getResponseBodyAsString());
        if (HttpStatus.SERVICE_UNAVAILABLE.value() == ex.getRawStatusCode()) {
            return ResponseEntity.status(ex.getStatusCode())
                    .body(
                            new ErrorResponse(
                                    HttpStatus.SERVICE_UNAVAILABLE.value(),
                                    ex.getStatusCode(),
                                    Collections.singletonList(
                                            errorMessageConfigReader
                                                    .getMessage()
                                                    .get(ERROR_CODE_503)),
                                    new Date()));
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(
                        new ErrorResponse(
                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                HttpStatus.INTERNAL_SERVER_ERROR,
                                Collections.singletonList(
                                        errorMessageConfigReader.getMessage().get(ERROR_CODE_500)),
                                new Date()));
    }

    @ExceptionHandler(ApplicationDetailsProcessFailException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleApplicationDetailsException(
            ApplicationDetailsProcessFailException ex, WebRequest request) {
        log.error("ApplicationDetailsProcessFailException : Error messages - {}", ex);

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(
                        new ErrorResponse(
                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                HttpStatus.INTERNAL_SERVER_ERROR,
                                Collections.singletonList(
                                        errorMessageConfigReader.getMessage().get(ERROR_CODE_500)),
                                new Date()));
    }

    @ExceptionHandler(LegalReasonException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleLegalReasonException(
            LegalReasonException ex, WebRequest request) {
        log.error("handleLegalReasonException : Error messages - {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS)
                .body(
                        new ErrorResponse(
                                HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS.value(),
                                HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS,
                                Collections.singletonList(ex.getMessage()),
                                new Date()));
    }

    /**
     * Exception to handle if brand is missing in the request header
     *
     * @param exception - MissingRequestHeaderException
     * @param request - WebRequest
     * @return - Error response
     */
    @ExceptionHandler(MissingRequestHeaderException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleMissingRequestHeaderException(
            MissingRequestHeaderException exception, WebRequest request) {
        String errorMessage =
                BRAND.equalsIgnoreCase(exception.getHeaderName())
                        ? MISSING_BRAND
                        : exception.getMessage();
        log.error(
                "Missing request header exception occurred while processing the request: Error messages - {}",
                errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(
                        new ErrorResponse(
                                HttpStatus.BAD_REQUEST.value(),
                                HttpStatus.BAD_REQUEST,
                                Collections.singletonList(errorMessage),
                                new Date()));
    }

    /**
     * Handler to handle the uncaught exceptions
     *
     * @param ex Exception
     * @return ErrorResponse
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorResponse> handleAllUncaughtException(Exception ex) {
        log.error("Unknown error occurred while processing the request", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(
                        new ErrorResponse(
                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                HttpStatus.INTERNAL_SERVER_ERROR,
                                Collections.singletonList(
                                        errorMessageConfigReader.getMessage().get(ERROR_CODE_500)),
                                new Date()));
    }

    private String getErrorMessage(GMSErrorResponse gmsErrorResponse, WebRequest request) {
        String origin = gmsErrorResponse.getOrigin();
        if (Objects.nonNull(origin)) {
            String errorMessage = null;
            switch (origin) {
                case APPLICATIONS:
                    errorMessage =
                            Optional.ofNullable(errorMessageConfigReader.getApplications())
                                    .map(errorMap -> errorMap.get(gmsErrorResponse.getErrorCode()))
                                    .orElse(null);
                    return getErrorMessage(gmsErrorResponse, errorMessage);
                case APPLICATION_DETAILS:
                    errorMessage =
                            Optional.ofNullable(errorMessageConfigReader.getApplicationDetails())
                                    .map(errorMap -> errorMap.get(gmsErrorResponse.getErrorCode()))
                                    .orElse(null);
                    return getErrorMessage(
                            gmsErrorResponse,
                            errorMessage,
                            getReferenceNumberFromURI((ServletWebRequest) request));
                default:
                    return gmsErrorResponse.getErrorMessage();
            }
        }
        return gmsErrorResponse.getErrorMessage();
    }

    private String getErrorMessage(GMSErrorResponse gmsErrorResponse, String errorMessage) {
        return Optional.ofNullable(errorMessage).orElse(gmsErrorResponse.getErrorMessage());
    }

    private String getReferenceNumberFromURI(ServletWebRequest request) {
        String[] splitURI = request.getRequest().getRequestURI().split("/");
        return splitURI[splitURI.length - 1];
    }

    private String getErrorMessage(
            GMSErrorResponse gmsErrorResponse, String errorMessage, String contentToReplace) {
        return Optional.ofNullable(errorMessage)
                .map(error -> MessageFormat.format(error, contentToReplace))
                .orElse(gmsErrorResponse.getErrorMessage());
    }
}
