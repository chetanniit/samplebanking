/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service.impl;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.CANCELLED_STAGE_NUMBER;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.COMPLETED_STAGE_NUMBER;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.GLOBAL_SUB_STATUS;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.MILESTONE_NAME;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.PRODUCT_SWITCH_CANCELLED;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.PRODUCT_SWITCH_STATUS;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.PRODUCT_SWITCH_STATUS_DESCRIPTION;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.RED;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.REFERENCE_NUMBER;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.STAGE_92;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.SUB_STATUS_CANCELLED;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.SUB_STATUS_DECLINED;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.YOUR_APPLICATION;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.*;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.APPLICATION_DETAILS;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.GMS_APPLICATION_DETAIL;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.GMS_APPLICATION_INFORMATION;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.GMS_VALUATION_INFORMATION;
import static com.natwest.pbbdhb.application.tracking.util.RestAPIUtil.getHeader;

import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.service.ApplicationDetailsService;
import com.natwest.pbbdhb.application.tracking.service.GmsStageAndTaskLoader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class ApplicationDetailsServiceImpl implements ApplicationDetailsService {

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired private GmsStageAndTaskLoader stageTaskLoader;

    @Value("${ms.msvc.applications.endpoint:}")
    private String applicationParentEndpoint;

    @Value("${ms.broker.application.info.endpoint:}")
    private String applicationInfoEndpoint;

    @Value("${ms.broker.valuation.info.endpoint:}")
    private String valuationInfoEndpoint;

    @Value("${ms.broker.application.details.endpoint:}")
    private String applicationDetailsEndpoint;

    @Override
    public ResponseEntity<String> getApplicationInfo(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest) {
        log.info(
                "getApplicationInfo method entered in ApplicationDetailsServiceImpl class for the request with referenceNumber:{}",
                referenceNumber);

        String endpoint = applicationParentEndpoint + applicationInfoEndpoint;
        UriComponentsBuilder builder =
                getUriComponentsBuilder(referenceNumber, applicationDetailRequest, endpoint);
        ResponseEntity<String> response =
                getApiResponse(brand, builder, APPLICATION_DETAILS, GMS_APPLICATION_INFORMATION);

        return response;
    }

    @Override
    @Async("asyncExecutor")
    public CompletableFuture<ResponseEntity<String>> getApplicationDetail(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest) {
        ResponseEntity<String> response = null;
        String endpoint = applicationParentEndpoint + applicationDetailsEndpoint;
        UriComponentsBuilder builder =
                getUriComponentsBuilder(referenceNumber, applicationDetailRequest, endpoint);
        try {
            response = getApiResponse(brand, builder, APPLICATION_DETAILS, GMS_APPLICATION_DETAIL);
        } catch (Exception e) {
            log.error(
                    "exception occurred while calling application detail endpoint: {}",
                    e.getMessage());
        }
        return CompletableFuture.completedFuture(response);
    }

    @Override
    @Async("asyncExecutor")
    public CompletableFuture<ResponseEntity<String>> getValuationInformation(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest) {
        ResponseEntity<String> response = null;
        String endpoint = applicationParentEndpoint + valuationInfoEndpoint;
        UriComponentsBuilder builder =
                getUriComponentsBuilder(referenceNumber, applicationDetailRequest, endpoint);
        try {
            response =
                    getApiResponse(brand, builder, APPLICATION_DETAILS, GMS_VALUATION_INFORMATION);
        } catch (Exception e) {
            log.error(
                    "exception occurred while calling valuation information endpoint : {}",
                    e.getMessage());
        }

        return CompletableFuture.completedFuture(response);
    }

    @Override
    public void populateApplicationRagStatus(
            ApplicationDetailsInfo detailsInfo, boolean isProductSwitchApp) {
        if (Objects.nonNull(detailsInfo.getApplicationDetails())) {
            log.info(
                    "inside populateApplicationRagStatus method of Coord Application ApplicationDetailsServiceImpl class");
            String stageNo = getStageNo(detailsInfo);
            log.debug("stageNo : {}", stageNo);

            GMSStageDescription stageDescription = stageTaskLoader.getStageDescription(stageNo);
            stageDescription = validate(stageDescription, stageNo);
            detailsInfo.getApplicationDetails().getStatus().setStatus(stageDescription.getStatus());
            detailsInfo
                    .getApplicationDetails()
                    .getStatus()
                    .setStatusDescription(stageDescription.getStatusDetail());

            if (isProductSwitchApp) {
                detailsInfo.getApplicationDetails().getStatus().setStatus(PRODUCT_SWITCH_STATUS);
                detailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .setStatusDescription(PRODUCT_SWITCH_STATUS_DESCRIPTION);
                detailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .setRagStatus(computeRagStatusForProductSwitchApplication(stageNo));
            } else {
                List<String> openTaskList = getOpenTaskList(detailsInfo);
                log.debug("openTaskList : {}", openTaskList);
                detailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .setRagStatus(computeRagStatus(stageNo, openTaskList.size()));
            }
            populateRagDescription(detailsInfo, isProductSwitchApp);
            log.debug(
                    "RagStatus : {}",
                    detailsInfo.getApplicationDetails().getStatus().getRagStatus());
        }
    }

    private void populateRagDescription(
            ApplicationDetailsInfo detailsInfo, boolean isProductSwitchApp) {
        String ragStatus = detailsInfo.getApplicationDetails().getStatus().getRagStatus();
        if (isProductSwitchApp && RED.equalsIgnoreCase(ragStatus)) {
            String ragDesc = stageTaskLoader.getStatusDescription(PRODUCT_SWITCH_CANCELLED);
            detailsInfo.getApplicationDetails().getStatus().setRagDescription(ragDesc);
        } else {
            String ragDesc = stageTaskLoader.getStatusDescription(ragStatus);
            detailsInfo
                    .getApplicationDetails()
                    .getStatus()
                    .setRagDescription(
                            Objects.nonNull(ragDesc)
                                    ? ragDesc.replace(MILESTONE_NAME, YOUR_APPLICATION)
                                    : null);
        }
    }

    @Override
    public void populateApplicationSubStatus(
            ApplicationDetailsInfo detailsInfo, boolean isProductSwitchApp) {
        if (Objects.nonNull(detailsInfo.getApplicationDetails())) {
            log.info(
                    "inside populateApplicationSubStatus method of Coord Application ApplicationDetailsServiceImpl class");

            List<String> openTaskList = getOpenTaskList(detailsInfo);
            log.debug("openTaskList : {}", openTaskList);
            String stageNo = getStageNo(detailsInfo);

            String subStatus = getSubStatus(openTaskList, stageTaskLoader, stageNo);

            if (isProductSwitchApp && stageNo.compareTo(COMPLETED_STAGE_NUMBER) > 0) {
                subStatus = SUB_STATUS_CANCELLED;
            } else if (Objects.nonNull(stageNo) && stageNo.compareTo(CANCELLED_STAGE_NUMBER) == 0) {
                subStatus = SUB_STATUS_CANCELLED;
            } else if (Objects.nonNull(stageNo)
                    && !STAGE_92.equals(stageNo)
                    && stageNo.compareTo(COMPLETED_STAGE_NUMBER) > 0) {
                subStatus = SUB_STATUS_DECLINED;
            }

            detailsInfo.getApplicationDetails().getStatus().setSubStatus(subStatus);
            setSubStatusDescription(subStatus, detailsInfo);

            log.debug(
                    "SubStatus : {}",
                    detailsInfo.getApplicationDetails().getStatus().getSubStatus());
        }
    }

    private UriComponentsBuilder getUriComponentsBuilder(
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest,
            String endpoint) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(REFERENCE_NUMBER, referenceNumber);

        populatePathParams(builder, urlParams);

        if (Objects.nonNull(applicationDetailRequest))
        populateRequestParams(applicationDetailRequest.toBrokerInformation(), builder);

        log.debug("URL : {} ", builder.toUriString());

        return builder;
    }

    private ResponseEntity<String> getApiResponse(
            String brand, UriComponentsBuilder builder, String origin, String destination) {
        return restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                getHeader(brand, origin, destination),
                String.class);
    }

    private void setSubStatusDescription(String subStatus, ApplicationDetailsInfo detailsInfo) {
        if (Objects.nonNull(subStatus)
                && (subStatus.equalsIgnoreCase(SUB_STATUS_CANCELLED)
                        || subStatus.equalsIgnoreCase(SUB_STATUS_DECLINED))) {
            String subStatusValue = GLOBAL_SUB_STATUS + subStatus;
            detailsInfo
                    .getApplicationDetails()
                    .getStatus()
                    .setSubStatusDescription(stageTaskLoader.getStatusDescription(subStatusValue));
        } else {
            detailsInfo
                    .getApplicationDetails()
                    .getStatus()
                    .setSubStatusDescription(
                            stageTaskLoader.getStatusDescription(
                                    detailsInfo
                                            .getApplicationDetails()
                                            .getStatus()
                                            .getSubStatus()));
        }
    }
}
