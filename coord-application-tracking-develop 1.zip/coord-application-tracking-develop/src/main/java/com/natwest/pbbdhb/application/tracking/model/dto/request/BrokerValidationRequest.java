/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrokerValidationRequest {
    private String fcaNumber;
    private String brokerSurname;
    private String brokerPostcode;
    private String firmPostcode;
}
