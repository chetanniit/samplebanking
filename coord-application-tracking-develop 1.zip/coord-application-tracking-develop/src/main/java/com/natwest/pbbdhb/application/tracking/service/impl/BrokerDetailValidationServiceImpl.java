/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service.impl;

import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.ERROR_CODE_401_BROKER_VALIDATION_FAILURE;

import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerDetailValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerDetailValidationResponse;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.service.BrokerDetailValidationService;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/** This class is used to make call to broker validation service to validate broker */
@Service
@Slf4j
public class BrokerDetailValidationServiceImpl implements BrokerDetailValidationService {

    @Value("${ms.broker.detail.validate.endpoint}")
    private String brokerDetailValidationURL;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired private ErrorMessageConfigReader errorMessageConfigReader;

    /**
     * This method is used to validate the broker
     *
     * @param brokerDetailValidationRequest - request object
     * @return BrokerDetailValidationResponse - response
     */
    public BrokerDetailValidationResponse validateBroker(
            BrokerDetailValidationRequest brokerDetailValidationRequest) {
        log.info("validateBroker method entered in BrokerValidationServiceImpl class");
        BrokerDetailValidationResponse brokerValidationResponse = null;
        try {
            ResponseEntity<BrokerDetailValidationResponse> responseEntity =
                    restTemplate.exchange(
                            brokerDetailValidationURL,
                            HttpMethod.POST,
                            getHeader(brokerDetailValidationRequest),
                            BrokerDetailValidationResponse.class);
            brokerValidationResponse = responseEntity.getBody();
        } catch (HttpClientErrorException.NotFound e) {
            log.error("error occurred while broker detail validation call :", e);
            throw new BrokerValidationException(
                    errorMessageConfigReader
                            .getMessage()
                            .get(ERROR_CODE_401_BROKER_VALIDATION_FAILURE));
        }
        log.debug("Response from broker detail validation service : {}", brokerValidationResponse);
        return brokerValidationResponse;
    }

    /**
     * This method is used to construct the header
     *
     * @param brokerValidationRequest - request object
     * @return HttpEntity - response
     */
    private HttpEntity<BrokerDetailValidationRequest> getHeader(
            BrokerDetailValidationRequest brokerValidationRequest) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Content-Type", "application/json");
        return new HttpEntity<>(brokerValidationRequest, httpHeaders);
    }
}
