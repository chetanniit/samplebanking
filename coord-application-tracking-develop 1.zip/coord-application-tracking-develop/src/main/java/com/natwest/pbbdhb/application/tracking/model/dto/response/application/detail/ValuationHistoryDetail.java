/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UTC_TIME_ZONE;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.DateSerializer;
import java.time.ZonedDateTime;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Data
@Builder
@JsonPropertyOrder({
    "typeCode",
    "typeDescription",
    "statusCode",
    "statusDescription",
    "date",
    "bookingDate",
    "note"
})
public class ValuationHistoryDetail {
    @JsonIgnore private String typeCode;
    private String typeDescription;
    @JsonIgnore private String statusCode;
    private String statusDescription;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime date;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime bookingDate;

    private String note;
}
