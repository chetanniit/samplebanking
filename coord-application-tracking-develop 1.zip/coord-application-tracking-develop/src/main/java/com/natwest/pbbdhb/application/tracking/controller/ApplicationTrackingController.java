/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.controller;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.populateGetApplicationDetailsURI;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.populateHATEOASLink;
import static com.natwest.pbbdhb.application.tracking.util.RestAPIUtil.populateGetApplicationsURI;
import static com.natwest.pbbdhb.application.tracking.util.RestAPIUtil.populateGetApplicationListURI;

import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.ApplicationDetailsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.service.ApplicationTrackingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.hateoas.Link;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

@RestController
@Tag(name = "Mortgage Application Tracking", description = "API for Mortgage Application Tracking")
@RequestMapping("/")
@Slf4j
@Validated
@AllArgsConstructor
public class ApplicationTrackingController {

    private final ApplicationTrackingService applicationTrackingService;

    /**
     * @param brand
     * @param applicationRequest
     * @param validationErrors
     * @return
     * @throws InterruptedException
     * @throws ExecutionException
     * @throws IOException
     */
    @Operation(summary = "Get Applications")
    @ApiResponses(
            value = {
                @ApiResponse(
                        responseCode = "200",
                        description = "Ok",
                        content =
                                @Content(
                                        schema =
                                                @Schema(
                                                        implementation =
                                                                ApplicationsResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad Request"),
                @ApiResponse(responseCode = "404", description = "Broker not found")
            })
    @GetMapping(path = "/applications", produces = "application/json")
    public ApplicationsResponse getApplications(
            @RequestHeader("brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND)
                    String brand,
            @Valid @ModelAttribute @ParameterObject ApplicationRequest applicationRequest,
            BindingResult validationErrors)
            throws InterruptedException, ExecutionException, IOException {
        log.info("getApplications method enters in ApplicationTrackingController class");
        UriComponentsBuilder builder = populateGetApplicationsURI(applicationRequest);
        ApplicationsResponse applicationsResponse =
                applicationTrackingService.getApplications(brand, applicationRequest);
        if (applicationsResponse != null) {
            applicationsResponse.add(Link.of(builder.build().toString()).withSelfRel());
            populateGetApplicationDetailsURI(applicationsResponse, applicationRequest);
        }
        return applicationsResponse;
    }
    
    @Operation(summary = "Get Applications List")
    @ApiResponses(
            value = {
                @ApiResponse(
                        responseCode = "200",
                        description = "Ok",
                        content =
                                @Content(
                                        schema =
                                                @Schema(
                                                        implementation =
                                                                ApplicationListResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad Request"),
                @ApiResponse(responseCode = "404", description = "Broker not found")
            })
    @GetMapping(path = "/applicationList", produces = "application/json")
    public ApplicationListResponse getApplicationList(
            @RequestHeader("brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @ModelAttribute @ParameterObject ApplicationListRequest applicationListRequest, BindingResult validationErrors) 
                    throws InterruptedException, ExecutionException, IOException {
        
        log.info("Enters into GetApplicationList Service");
        UriComponentsBuilder builder = populateGetApplicationListURI(applicationListRequest);
        ApplicationListResponse applicationListResponse =
                applicationTrackingService.getApplicationList(brand, applicationListRequest);
        if (applicationListResponse != null) {
            applicationListResponse.add(Link.of(builder.build().toString()).withSelfRel());
            populateGetApplicationDetailsURI(applicationListResponse, applicationListRequest);
        }
        return applicationListResponse;
    }

    @Operation(summary = "Get Application Detail")
    @ApiResponses(
            value = {
                @ApiResponse(
                        responseCode = "200",
                        description = "Ok",
                        content =
                                @Content(
                                        schema =
                                                @Schema(
                                                        implementation =
                                                                ApplicationDetailsResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad Request"),
                @ApiResponse(responseCode = "404", description = "Application not found"),
                @ApiResponse(responseCode = "400", description = "Access restricted")
            })
    @GetMapping(path = "/applicationDetails/{referenceNumber}", produces = "application/json")
    public ApplicationDetailsResponse getApplicationDetail(
            @RequestHeader("brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND)
                    String brand,
            @PathVariable("referenceNumber")
                    @Pattern(
                            regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS,
                            message = INVALID_REFERENCE_NUMBER)
                    String referenceNumber,
            @Valid @ModelAttribute @ParameterObject
                    ApplicationDetailRequest applicationDetailRequest,
            BindingResult validationErrors) {
        log.info("getApplicationDetail method enters in ApplicationTrackingController class");
        ApplicationDetailsResponse applicationDetailsResponse =
                applicationTrackingService.getApplicationDetail(
                        brand, referenceNumber, applicationDetailRequest);

        populateHATEOASLink(referenceNumber, applicationDetailRequest, applicationDetailsResponse);

        return applicationDetailsResponse;
    }



    @Operation(summary = "Get Case Tracking Details for Customer")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Ok",
                            content =
                            @Content(
                                    schema =
                                    @Schema(
                                            implementation =
                                                    ApplicationDetailsResponse.class))),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "404", description = "Application not found"),
                    @ApiResponse(responseCode = "400", description = "Access restricted")
            })
    @GetMapping("/application/{referenceNumber}/track")
    public ApplicationDetailsResponse getCustomerCaseDetails(
            @RequestHeader("brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND)
                    String brand,
            @PathVariable("referenceNumber")
            @Pattern(
                    regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS,
                    message = INVALID_REFERENCE_NUMBER)
                    String referenceNumber) {
        ApplicationDetailsResponse applicationDetailsResponse =
                applicationTrackingService.getCustomerCaseDetails(
                        brand, referenceNumber);

        populateHATEOASLink(referenceNumber, null, applicationDetailsResponse);
        return applicationDetailsResponse;
    }
}
