/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service.impl;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.*;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.*;
import static org.apache.commons.lang.StringUtils.isNotBlank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.mapper.ApplicationDetailsResponseMapper;
import com.natwest.pbbdhb.application.tracking.model.GMSTaskDescription;
import com.natwest.pbbdhb.application.tracking.model.MilestoneMappingInformation;
import com.natwest.pbbdhb.application.tracking.model.ValuationStatus;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerDetailValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerDetailValidationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerValidationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.FirmBroker;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.*;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.ApplicationDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.GranularTracking;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StageHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.Applicant;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.Product;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInformation;
import com.natwest.pbbdhb.application.tracking.model.exception.ApplicationDetailsProcessFailException;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.model.exception.LegalReasonException;
import com.natwest.pbbdhb.application.tracking.service.ApplicationDetailsService;
import com.natwest.pbbdhb.application.tracking.service.ApplicationTrackingService;
import com.natwest.pbbdhb.application.tracking.service.BrokerDetailValidationService;
import com.natwest.pbbdhb.application.tracking.service.BrokerService;
import com.natwest.pbbdhb.application.tracking.service.BrokerValidationService;
import com.natwest.pbbdhb.application.tracking.service.GmsStageAndTaskLoader;
import com.natwest.pbbdhb.application.tracking.util.ApplicationConstants;
import com.natwest.pbbdhb.application.tracking.util.ApplicationFunctions;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import com.natwest.pbbdhb.application.tracking.util.PropertiesReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class ApplicationTrackingServiceImpl implements ApplicationTrackingService {

    private final BrokerValidationService brokerValidationService;
    private final BrokerService brokerService;
    private final ApplicationDetailsService applicationDetailsService;
    private final ObjectMapper objectMapper;
    private final GmsStageAndTaskLoader stageTaskLoader;
    private final ApplicationDetailsResponseMapper applicationDetailsResponseMapper;
    private final PropertiesReader propertiesReader;
    private final ErrorMessageConfigReader errorMessageConfigReader;
    private final BrokerDetailValidationService brokerDetailValidationService;

    /**
     * This method is used to get the broker applications
     *
     * @param brand - String
     * @param applicationRequest - request object
     * @return ApplicationsResponse - response object
     */
    @Override
    public ApplicationsResponse getApplications(
            String brand, ApplicationRequest applicationRequest) {
        if (propertiesReader.getIsBrokerDetailValidateEndpointEnabled()) {
            BrokerDetailValidationRequest brokerDetailValidationRequest =
                    applicationRequest.toBrokerDetailValidationRequest(propertiesReader.getIsAddBrokerUserNameToDetailValidateEndpoint());
            validateBroker(brokerDetailValidationRequest);
        } else {
            BrokerValidationRequest brokerValidationRequest =
                    applicationRequest.toBrokerValidationRequest();
            validateBroker(brokerValidationRequest);
        }

        return brokerService.getApplications(brand, applicationRequest);
    }
    
    /**
     * This method is used to get the broker application list from mongo db
     *
     * @param brand - String
     * @param applicationListRequest - request object
     * @return ApplicationListResponse - response object
     */
    @Override
    public ApplicationListResponse getApplicationList(
            String brand, ApplicationListRequest applicationListRequest) {
        if (propertiesReader.getIsBrokerDetailValidateEndpointEnabled()) {
            BrokerDetailValidationRequest brokerDetailValidationRequest =
                    applicationListRequest.toBrokerDetailValidationRequest(propertiesReader.getIsAddBrokerUserNameToDetailValidateEndpoint());
            validateBroker(brokerDetailValidationRequest);
        } else {
            BrokerValidationRequest brokerValidationRequest =
                    applicationListRequest.toBrokerValidationRequest();
            validateBroker(brokerValidationRequest);
        }

        return brokerService.getApplicationList(brand, applicationListRequest);
    }

    /**
     * This method is used to get the broker application details
     *
     * @param brand - String
     * @param referenceNumber - String
     * @param applicationDetailRequest - request object
     * @return ApplicationDetailsResponse - response object
     */
    @Override
    public ApplicationDetailsResponse getApplicationDetail(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest) {
        if (propertiesReader.getIsBrokerDetailValidateEndpointEnabled()) {
            BrokerDetailValidationRequest brokerDetailValidationRequest =
                    applicationDetailRequest.toBrokerDetailValidationRequest(propertiesReader.getIsAddBrokerUserNameToDetailValidateEndpoint());
            validateBroker(brokerDetailValidationRequest);
        } else {
            BrokerValidationRequest brokerValidationRequest =
                    applicationDetailRequest.toBrokerValidationRequest();
            validateBroker(brokerValidationRequest);
        }
        return makeCallToApplicationInfoEndpoint(brand, referenceNumber, applicationDetailRequest);
    }


    /**
     * This method is used to get the customer application details for caseTracking
     *
     * @param brand - String
     * @param referenceNumber - String
     * @return ApplicationDetailsResponse - response object
     */
    @Override
    public ApplicationDetailsResponse getCustomerCaseDetails(String brand, String referenceNumber) {
        return makeCallToApplicationInfoEndpoint(brand,referenceNumber,null);
    }

    private ApplicationDetailsResponse makeCallToApplicationInfoEndpoint(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest) {
        ResponseEntity<String> applicationInfoResponse =
                applicationDetailsService.getApplicationInfo(
                        brand, referenceNumber, applicationDetailRequest);

        if (Objects.nonNull(applicationInfoResponse)
                && (applicationInfoResponse.getStatusCodeValue() == 200)) {
            CompletableFuture<ResponseEntity<String>> applicationDetailResponse =
                    applicationDetailsService.getApplicationDetail(
                            brand, referenceNumber, applicationDetailRequest);
            boolean isProductSwitchApp = checkIfProductSwitchApplication(applicationInfoResponse);
            CompletableFuture<ResponseEntity<String>> valuationInformationResponse =
                    isProductSwitchApp
                            ? CompletableFuture.completedFuture(null)
                            : applicationDetailsService.getValuationInformation(
                                    brand, referenceNumber, applicationDetailRequest);
            CompletableFuture.allOf(applicationDetailResponse, valuationInformationResponse).join();

            try {
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

                String response =
                        mergeResponses(
                                objectMapper,
                                applicationInfoResponse.getBody(),
                                getResponseString(applicationDetailResponse),
                                getResponseString(valuationInformationResponse));

                ApplicationDetailsInfo applicationDetailsInfo =
                        objectMapper.readValue(response, ApplicationDetailsInfo.class);
                removeExcludedStages(referenceNumber, applicationDetailsInfo, isProductSwitchApp);
                validateApplicationToBeSuppressed(applicationDetailsInfo);
                removeExcludedTasks(referenceNumber, applicationDetailsInfo, isProductSwitchApp);
                removeOpenFSTTaskIfNoOpenFIs(applicationDetailsInfo);
                populateStageClosingTime(applicationDetailsInfo, isProductSwitchApp);
                addDummyTasksForProductSwitch(applicationDetailsInfo, isProductSwitchApp);
                populateTaskDescription(applicationDetailsInfo);
                applicationDetailsService.populateApplicationRagStatus(
                        applicationDetailsInfo, isProductSwitchApp);
                applicationDetailsService.populateApplicationSubStatus(
                        applicationDetailsInfo, isProductSwitchApp);

                List<StageHistoryDetail> stageHistoryDetails =
                        clubStageAndTaskBasedOnMilestone(
                                applicationDetailsInfo, isProductSwitchApp);
                removeValuationDetailsEntry(applicationDetailsInfo);
                populateMortgageTypeAndFeeStatus(applicationDetailsInfo);
                ApplicationDetailsResponse applicationDetailsResponse =
                        applicationDetailsResponseMapper.toApplicationDetailsResponse(
                                applicationDetailsInfo);

                applicationDetailsResponse.setApplicationDetails(
                        HistoryDetails.builder().stageHistory(stageHistoryDetails).build());
                updateMileStoneRagStatus(applicationDetailsInfo, applicationDetailsResponse);
                updateMileStone(
                        applicationDetailsInfo, applicationDetailsResponse, isProductSwitchApp);
                populateCOTDate(applicationDetailsInfo, applicationDetailsResponse);
                populateExpectedCompletionDate(applicationDetailsInfo, applicationDetailsResponse);
                if (Objects.nonNull(applicationDetailsInfo)
                        && chkOfferGreyStatus(applicationDetailsResponse))
                    populateOfferIssueDate(applicationDetailsInfo, applicationDetailsResponse);
                if (Objects.nonNull(applicationDetailsResponse)
                        && Objects.nonNull(applicationDetailsInfo)) {
                    populateProductInformation(
                            applicationDetailsResponse.getProductInformation(),
                            applicationDetailsInfo.getProductInformation());
                    if (Objects.nonNull(applicationDetailsInfo.getProductInformation())
                            && (applicationDetailsInfo.getProductInformation().getMortgageType()
                                            == "Switch"
                                    || applicationDetailsInfo
                                            .getProductInformation()
                                            .getMortgageTypeCode()
                                            .equals("I"))) {
                        populateExpectedEffectiveDate(
                                applicationDetailsInfo, applicationDetailsResponse);
                        populateActualEffectiveDate(
                                applicationDetailsInfo, applicationDetailsResponse);
                    }
                }
                resetCOTDate(applicationDetailsResponse);
                removeIfFSTTaskPresent(applicationDetailsResponse);
                applicationDetailsResponse.setReferenceNumber(referenceNumber);
                return applicationDetailsResponse;

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new ApplicationDetailsProcessFailException(
                        APPLICATION_DETAILS_REQUEST_PROCESSING_FAIL_ERROR_MESSAGE);
            } catch (IOException | ExecutionException e) {
                throw new ApplicationDetailsProcessFailException(
                        APPLICATION_DETAILS_REQUEST_PROCESSING_FAIL_ERROR_MESSAGE);
            }
        }
        return null;
    }

    public void removeOpenFSTTaskIfNoOpenFIs(ApplicationDetailsInfo applicationDetailsInfo) {
        if (ApplicationFunctions.isAnyNullObjectPresent.test(applicationDetailsInfo)) {
            return;
        }
        if (!ApplicationFunctions.isOpenFIPresent.test(applicationDetailsInfo)) {
            applicationDetailsInfo.getApplicationDetails().getCaseHistory()
                    .removeIf(caseHistoryDetail -> FST.equalsIgnoreCase(caseHistoryDetail.getCode())
                            && Objects.isNull(caseHistoryDetail.getClosedDateTime()));
        }
    }

    private void removeIfFSTTaskPresent(ApplicationDetailsResponse applicationDetailsResponse) {
        Optional.ofNullable(applicationDetailsResponse.getApplicationDetails()).map(HistoryDetails::getStageHistory)
                .orElseGet(Collections::emptyList).forEach(stageHistoryDetail -> {
            if (ASSESSMENT.equalsIgnoreCase(stageHistoryDetail.getDescription())
                    && CollectionUtils.isNotEmpty(stageHistoryDetail.getCaseHistory())) {
                stageHistoryDetail.getCaseHistory().removeIf(caseHistoryDetail -> FST.equalsIgnoreCase(caseHistoryDetail.getDescription()));
            }
        });
    }

    /**
     * Method to populate the stage closing time for product switch application
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param isProductSwitchApp - isProductSwitchApp
     */
    public void populateStageClosingTime(
            ApplicationDetailsInfo applicationDetailsInfo, boolean isProductSwitchApp) {
        if (isProductSwitchApp) {
            Optional.ofNullable(applicationDetailsInfo)
                    .map(ApplicationDetailsInfo::getApplicationDetails)
                    .map(ApplicationDetails::getStageHistory).orElseGet(Collections::emptyList)
                    .stream()
                    .findFirst()
                    .ifPresent(
                            stage -> {
                                if (stage.getCode().compareTo("79") > 0) {
                                    stage.setClosedDateTime(stage.getOpenDateTime());
                                }
                            });
        }
    }

    /**
     * Method to add dummy tasks related to the stage
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param isProductSwitchApp - isProductSwitchApp
     */
    public void addDummyTasksForProductSwitch(
            ApplicationDetailsInfo applicationDetailsInfo, boolean isProductSwitchApp) {
        if (isProductSwitchApp && notNullStageHistory(applicationDetailsInfo)) {
            List<CaseHistory> dummyTasks = new ArrayList<>();
            applicationDetailsInfo
                    .getApplicationDetails()
                    .getStageHistory()
                    .forEach(
                            stage -> {
                                String dummyTaskCode =
                                        stageTaskLoader.getDummyTaskCode(stage.getCode());
                                if (Objects.nonNull(dummyTaskCode)) {
                                    dummyTasks.add(
                                            CaseHistory.builder()
                                                    .code(dummyTaskCode)
                                                    .openDateTime(stage.getOpenDateTime())
                                                    .closedDateTime(stage.getClosedDateTime())
                                                    .status(
                                                            Objects.nonNull(
                                                                            stage
                                                                                    .getClosedDateTime())
                                                                    ? "Close"
                                                                    : "Open")
                                                    .build());
                                }
                            });

            if (CollectionUtils.isNotEmpty(dummyTasks)) {
                if (notNullCaseHistory(applicationDetailsInfo)) {
                    applicationDetailsInfo
                            .getApplicationDetails()
                            .getCaseHistory()
                            .addAll(dummyTasks);
                } else {
                    applicationDetailsInfo.getApplicationDetails().setCaseHistory(dummyTasks);
                }
            }
        }
    }

    private boolean checkIfProductSwitchApplication(
            ResponseEntity<String> applicationInfoResponse) {
        try {
            ApplicationDetailsInfo applicationInfo =
                    objectMapper.readValue(
                            applicationInfoResponse.getBody(), ApplicationDetailsInfo.class);
            ProductInfo productSwitchApp =
                    Optional.ofNullable(applicationInfo)
                            .map(ApplicationDetailsInfo::getProductInformation)
                            .filter(
                                    product ->
                                            PRODUCT_SWITCH_MORTGAGE_TYPE_CODE.equalsIgnoreCase(
                                                    product.getMortgageTypeCode()))
                            .orElse(null);
            return Objects.nonNull(productSwitchApp);
        } catch (JsonProcessingException e) {
            log.error(
                    "Inside checkIfProductSwitchApplication - error occurred while processing the json {}",
                    e.getMessage());
        }
        return false;
    }

    /**
     * Method to populateExpectedCompletionDate
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param applicationDetailsResponse - applicationDetailsResponse
     */
    public void populateExpectedCompletionDate(
            ApplicationDetailsInfo applicationDetailsInfo,
            ApplicationDetailsResponse applicationDetailsResponse) {
        Optional.ofNullable(applicationDetailsInfo)
                .map(ApplicationDetailsInfo::getExpectedCompletionDate)
                .ifPresent(
                        expectedDate -> {
                            if (Objects.nonNull(applicationDetailsResponse.getStatus())) {
                                applicationDetailsResponse
                                        .getStatus()
                                        .setExpectedCompletionDate(expectedDate);
                            } else {
                                applicationDetailsResponse.setStatus(
                                        StatusDetail.builder()
                                                .expectedCompletionDate(expectedDate)
                                                .build());
                            }
                        });
    }

    /**
     * Method to populateOfferIssueDate
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param applicationDetailsResponse - applicationDetailsResponse
     */
    public void populateOfferIssueDate(
            ApplicationDetailsInfo applicationDetailsInfo,
            ApplicationDetailsResponse applicationDetailsResponse) {
        List<CaseHistory> caseHistories =
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                        .filter(line -> "T21".equals(line.getCode()))
                        .collect(Collectors.toList());
        ZonedDateTime offerIssueDate = null;
        if (CollectionUtils.isNotEmpty(caseHistories)
                && Objects.nonNull(caseHistories.get(0).getClosedDateTime())) {
            offerIssueDate = caseHistories.get(0).getClosedDateTime();
        }
        if (Objects.nonNull(applicationDetailsResponse.getStatus())) {
            applicationDetailsResponse.getStatus().setOfferIssueDate(offerIssueDate);
        } else {
            applicationDetailsResponse.setStatus(
                    StatusDetail.builder().offerIssueDate(offerIssueDate).build());
        }
    }

    /**
     * Method to populateExpectedEffectiveDate
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param applicationDetailsResponse - applicationDetailsResponse
     */
    public void populateExpectedEffectiveDate(
            ApplicationDetailsInfo applicationDetailsInfo,
            ApplicationDetailsResponse applicationDetailsResponse) {
        Date expectedDate =
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getExpectedEffectiveDate();
        if (Objects.nonNull(applicationDetailsResponse.getStatus())) {
            applicationDetailsResponse.getStatus().setExpectedEffectiveDate(expectedDate);
        } else {
            applicationDetailsResponse.setStatus(
                    StatusDetail.builder().expectedEffectiveDate(expectedDate).build());
        }
    }

    /**
     * Method to populateActualEffectiveDate
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param applicationDetailsResponse - applicationDetailsResponse
     */
    public void populateActualEffectiveDate(
            ApplicationDetailsInfo applicationDetailsInfo,
            ApplicationDetailsResponse applicationDetailsResponse) {
        List<StageHistory> stageHistories =
                applicationDetailsInfo.getApplicationDetails().getStageHistory().stream()
                        .filter(line -> "80".equals(line.getCode()))
                        .collect(Collectors.toList());
        Date actualEffectiveDate = null;
        if (CollectionUtils.isNotEmpty(stageHistories)
                && Objects.nonNull(stageHistories.get(0).getOpenDateTime())) {
            actualEffectiveDate = Date.from(stageHistories.get(0).getOpenDateTime().toInstant());
        }
        if (Objects.nonNull(applicationDetailsResponse.getStatus())) {
            applicationDetailsResponse.getStatus().setActualEffectiveDate(actualEffectiveDate);
        } else {
            applicationDetailsResponse.setStatus(
                    StatusDetail.builder().actualEffectiveDate(actualEffectiveDate).build());
        }
    }

    private String getResponseString(CompletableFuture<ResponseEntity<String>> response)
            throws InterruptedException, ExecutionException {
        return Optional.ofNullable(response.get()).map(HttpEntity::getBody).orElse(null);
    }

    /**
     * this method is used to club product based on product code
     *
     * @param productInfo - ProductInformation object
     */
    public void populateProductInformation(ProductInformation productInfo, ProductInfo prodInfo) {
        List<Products> productInformationList = new ArrayList<>();
        if (productInfo == null || productInfo.getProducts() == null) {
            return;
        }
        LinkedHashMap<String, List<Products>> listProducts =
                productInfo.getProducts().stream()
                        .collect(
                                Collectors.groupingBy(
                                        Products::getCode,
                                        LinkedHashMap::new,
                                        Collectors.toList()));
        log.debug("listProducts : " + listProducts);
        listProducts.forEach(
                (code, pList) -> {
                    Products productInformation = pList.get(0);
                    DecimalFormat df = new DecimalFormat("#.##");

                    productInformation.setRepaymentAmount(
                            new BigDecimal(
                                    df.format(
                                            pList.stream()
                                                    .map(Products::getRepaymentAmount)
                                                    .filter(Objects::nonNull)
                                                    .mapToDouble(BigDecimal::doubleValue)
                                                    .sum())));
                    productInformation.setLoanAmount(
                            new BigDecimal(
                                    df.format(
                                            pList.stream()
                                                    .map(Products::getLoanAmount)
                                                    .filter(Objects::nonNull)
                                                    .mapToDouble(BigDecimal::doubleValue)
                                                    .sum())));

                    Products product =
                            pList.stream()
                                    .max(
                                            (p1, p2) ->
                                                    p1.getTermYears().equals(p2.getTermYears())
                                                            ? Integer.compare(
                                                                    Integer.parseInt(
                                                                            p1.getTermMonths()),
                                                                    Integer.parseInt(
                                                                            p2.getTermMonths()))
                                                            : Integer.compare(
                                                                    Integer.parseInt(
                                                                            p1.getTermYears()),
                                                                    Integer.parseInt(
                                                                            p2.getTermYears())))
                                    .orElse(new Products());

                    populateRepaymentType(prodInfo.getProducts(), product);
                    productInformation.setTermYears(product.getTermYears());
                    productInformation.setTermMonths(product.getTermMonths());
                    productInformationList.add(productInformation);
                });
        productInfo.setProducts(productInformationList);
    }

    private void populateRepaymentType(List<Product> pList, Products product) {
        log.info("Inside populateRepaymentType method ");
        boolean interestOnly = pList.stream().anyMatch(prod -> prod.isInterestOnly());
        boolean capitalAndInterest = pList.stream().anyMatch(prod -> prod.isCapitalAndInterest());
        if (capitalAndInterest && interestOnly) {
            product.setRepaymentType(PART_AND_PART);
        } else if (capitalAndInterest) {
            product.setRepaymentType(CAPITAL_AND_INTEREST);
        } else if (interestOnly) {
            product.setRepaymentType(INTEREST_ONLY);
        }
    }

    public void validateApplicationToBeSuppressed(ApplicationDetailsInfo applicationDetailsInfo) {
        log.info("validateApplicationToBeSuppressed method enters");
        List<String> suppressStageList = propertiesReader.getApplicationSuppressStageList();
        log.debug("suppressStageList :{}", suppressStageList);
        if (Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())
                && !CollectionUtils.isEmpty(
                        applicationDetailsInfo.getApplicationDetails().getStageHistory())) {

            String currentStageNumber =
                    applicationDetailsInfo.getApplicationDetails().getStageHistory().stream()
                            .findFirst()
                            .map(StageHistory::getCode)
                            .filter(suppressStageList::contains)
                            .orElse(STAGE_00);

            switch (currentStageNumber) {
                case STAGE_80:
                    getApplicationDate(
                            applicationDetailsInfo,
                            ApplicationConstants.APPLICATION_COMPLETED_STATUS_CODE,
                            errorMessageConfigReader.getMessage().get(ERROR_CODE_451_COMPLETED));
                    break;
                case STAGE_84:
                    getApplicationDate(
                            applicationDetailsInfo,
                            ApplicationConstants.APPLICATION_DECLINED_STATUS_CODE,
                            errorMessageConfigReader
                                    .getMessage()
                                    .get(ERROR_CODE_451_SOFT_DECLINED));
                    break;
                case STAGE_85:
                    getApplicationDate(
                            applicationDetailsInfo,
                            ApplicationConstants.APPLICATION_DECLINED_STATUS_CODE,
                            errorMessageConfigReader.getMessage().get(ERROR_CODE_451_DECLINED));
                    break;
                case STAGE_90:
                    getApplicationDate(
                            applicationDetailsInfo,
                            ApplicationConstants.APPLICATION_REFUSED_STATUS_CODE,
                            errorMessageConfigReader.getMessage().get(ERROR_CODE_451_REFUSED));
                    break;
                default:
                    break;
            }
        }
    }

    private void getApplicationDate(
            ApplicationDetailsInfo applicationDetailsInfo,
            String applicationStatus,
            String applicationSuppressMessage) {
        log.info("getApplicationDate method enters");
        Date applicationDateToCheck = null;
        switch (applicationStatus) {
            case ApplicationConstants.APPLICATION_DECLINED_STATUS_CODE:
                if (nonNullStatus(applicationDetailsInfo)
                        && nonNullDate(
                                applicationDetailsInfo
                                        .getApplicationDetails()
                                        .getStatus()
                                        .getDeclinedDate())) {
                    applicationDateToCheck =
                            applicationDetailsInfo
                                    .getApplicationDetails()
                                    .getStatus()
                                    .getDeclinedDate();
                    validateApplication(
                            applicationDateToCheck,
                            propertiesReader.getDeclinedApplicationSuppressDays(),
                            applicationSuppressMessage);
                }

                break;
            case ApplicationConstants.APPLICATION_COMPLETED_STATUS_CODE:
                if (nonNullStatus(applicationDetailsInfo)
                        && nonNullDate(
                                applicationDetailsInfo
                                        .getApplicationDetails()
                                        .getStatus()
                                        .getCompletionDate())) {
                    applicationDateToCheck =
                            applicationDetailsInfo
                                    .getApplicationDetails()
                                    .getStatus()
                                    .getCompletionDate();
                    validateApplication(
                            applicationDateToCheck,
                            propertiesReader.getCompletedApplicationSuppressDays(),
                            applicationSuppressMessage);
                }
                break;
            case ApplicationConstants.APPLICATION_REFUSED_STATUS_CODE:
                if (nonNullStatus(applicationDetailsInfo)
                        && nonNullDate(
                                applicationDetailsInfo
                                        .getApplicationDetails()
                                        .getStatus()
                                        .getRefusedDate())) {
                    applicationDateToCheck =
                            applicationDetailsInfo
                                    .getApplicationDetails()
                                    .getStatus()
                                    .getRefusedDate();
                    validateApplication(
                            applicationDateToCheck,
                            propertiesReader.getRefusedApplicationSuppressDays(),
                            applicationSuppressMessage);
                }
                break;
            default:
                break;
        }
    }

    private boolean nonNullDate(Date applicationDateToCheck) {
        return Objects.nonNull(applicationDateToCheck);
    }

    private boolean nonNullStatus(ApplicationDetailsInfo applicationDetailsInfo) {
        return Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails().getStatus());
    }

    private void validateApplication(
            Date applicationDateToCheck,
            int applicationSuppressDays,
            String applicationSuppressMessage) {
        log.info("validateApplication method enters");
        Date currentDate = null;
        try {
            currentDate = getFormattedDate(new Date());
            if ("Y".equalsIgnoreCase(propertiesReader.getSuppress451Error())) {
                currentDate =
                        new SimpleDateFormat(DATE_FORMAT_YYYYMMDD)
                                .parse(propertiesReader.getSystemDate());
            }
            log.debug(
                    "applicationDateToCheck :{} currentDate :{}",
                    applicationDateToCheck,
                    currentDate);
            if (Objects.nonNull(applicationDateToCheck)
                    && applicationDateToCheck.before(currentDate)
                    && isOlderApplication(
                            applicationDateToCheck, currentDate, applicationSuppressDays)) {
                log.error(
                        "unavailable due to legal reasons exception occurred while processing the request - Error messages - {} ",
                        applicationSuppressMessage);
                throw new LegalReasonException(applicationSuppressMessage);
            }
        } catch (ParseException e) {
            log.error("date parse exception occurred :{}", e.getMessage());
        }
    }

    private boolean isOlderApplication(
            Date applicationDateToCheck, Date currentDate, int applicationSuppressDays) {
        log.info(
                "isOlderApplication method enters with  Application Suppress Days :{}",
                applicationSuppressDays);
        long duration = currentDate.getTime() - applicationDateToCheck.getTime();
        int diffInDays = (int) TimeUnit.MILLISECONDS.toDays(duration);
        log.debug(
                "applicationSuppressDays :{} diffInDays :{}", applicationSuppressDays, diffInDays);
        return (diffInDays > applicationSuppressDays) ? true : false;
    }

    public void populateMortgageTypeAndFeeStatus(ApplicationDetailsInfo applicationDetailsInfo) {
        Optional.ofNullable(applicationDetailsInfo)
                .map(ApplicationDetailsInfo::getProductInformation)
                .orElse(ProductInfo.builder().build())
                .setMortgageType(
                        stageTaskLoader.getMortgageTypeDescription(
                                (applicationDetailsInfo != null
                                                && applicationDetailsInfo.getProductInformation()
                                                        != null)
                                        ? applicationDetailsInfo
                                                .getProductInformation()
                                                .getMortgageTypeCode()
                                        : null));

        Optional.ofNullable(applicationDetailsInfo)
                .map(ApplicationDetailsInfo::getProductInformation)
                .orElse(ProductInfo.builder().build())
                .setFeeStatus(
                        stageTaskLoader.getFeeStatusDescription(
                                (applicationDetailsInfo != null
                                                && applicationDetailsInfo.getProductInformation()
                                                        != null)
                                        ? applicationDetailsInfo
                                                .getProductInformation()
                                                .getFeeStatusCode()
                                        : null));
    }

    public void removeValuationDetailsEntry(ApplicationDetailsInfo applicationDetailsInfo) {
        log.info("removeValuationDetailsEntry method enters");
        if (nonNullValuationDetails(applicationDetailsInfo)) {
            applicationDetailsInfo
                    .getValuationInformation()
                    .getDetails()
                    .removeIf(
                            details ->
                                    Objects.isNull(details.getStatusCode())
                                            || Objects.nonNull(details.getStatusCode())
                                                    && isDetailsEntryToBeRemoved(
                                                            details.getStatusCode()));
        }
    }

    private boolean isDetailsEntryToBeRemoved(String statusCode) {
        return N.equalsIgnoreCase(getValuationStatus(statusCode).getStatus());
    }

    private ValuationStatus getValuationStatus(String statusCode) {
        return Objects.nonNull(stageTaskLoader.getValuationStatus(statusCode))
                ? stageTaskLoader.getValuationStatus(statusCode)
                : ValuationStatus.builder().status("").description("").build();
    }

    private boolean nonNullValuationDetails(ApplicationDetailsInfo applicationDetailsInfo) {
        return Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getValuationInformation())
                && !CollectionUtils.isEmpty(
                        applicationDetailsInfo.getValuationInformation().getDetails());
    }

    /**
     * Method to populate milestone details
     *
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param isProductSwitchApp - isProductSwitchApp
     * @return list of milestones
     */
    public List<StageHistoryDetail> clubStageAndTaskBasedOnMilestone(
            ApplicationDetailsInfo applicationDetailsInfo, boolean isProductSwitchApp) {

        List<StageHistoryDetail> stageHistoryDetailList = new ArrayList<>();
        if (Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())) {
            String latestStageNumber =
                    getLatestStageNumber(applicationDetailsInfo.getApplicationDetails());
            Map<String, List<StageHistory>> existingStageHistoryMap =
                    notNullStageHistory(applicationDetailsInfo)
                            ? applicationDetailsInfo.getApplicationDetails().getStageHistory()
                                    .stream()
                                    .collect(Collectors.groupingBy(StageHistory::getCode))
                            : new HashMap<>();

            Map<String, List<CaseHistory>> existingCaseHistoryMap =
                    notNullCaseHistory(applicationDetailsInfo)
                            ? applicationDetailsInfo.getApplicationDetails().getCaseHistory()
                                    .stream()
                                    .collect(Collectors.groupingBy(CaseHistory::getCode))
                            : new HashMap<>();

            Map<String, List<GranularTracking>> granularTrackingMap =
                    Objects.nonNull(applicationDetailsInfo.getApplicationDetails())
                            && CollectionUtils.isNotEmpty(applicationDetailsInfo.getApplicationDetails().getGranularTracking())
                            ? applicationDetailsInfo.getApplicationDetails().getGranularTracking().stream()
                            		.filter(granularTracking -> StringUtils.isNotEmpty(granularTracking.getDescription())
                                			&& Objects.nonNull(granularTracking.getGmsStageNumber()))
                            .collect(Collectors.groupingBy(GranularTracking::getGmsStageNumber)) : new HashMap<>();

            Map<String, MilestoneMappingInformation> milestoneMappingInformationMap =
                    isProductSwitchApp
                            ? stageTaskLoader.getProductSwitchMilestoneMappingInformation()
                            : stageTaskLoader.getMilestoneMappingInformation();

            IntStream.range(1, milestoneMappingInformationMap.size() + 1)
                    .forEach(
                            milestone -> {
                                MilestoneMappingInformation milestoneMappingInformation =
                                        milestoneMappingInformationMap.get(
                                                String.valueOf(milestone));
                                StageHistoryDetail stageHistoryDetail = new StageHistoryDetail();
                                stageHistoryDetail.setDescription(
                                        milestoneMappingInformation.getDescription());
                                List<String> stages = milestoneMappingInformation.getStages();
                                List<String> tasks = milestoneMappingInformation.getTasks();
                                List<StageHistory> stageHistories =
                                        populateStageHistory(existingStageHistoryMap, stages);
                                List<CaseHistory> caseHistories =
                                        populateCaseHistory(existingCaseHistoryMap, tasks);
                                List<CaseHistoryDetail> caseHistoryDetailList = applicationDetailsResponseMapper.toCaseHistory(caseHistories);
                                List<RequiredActionDetail> requiredActions = new ArrayList<>();
                                addGranularTrackingInfoInCaseHistoryList(granularTrackingMap, caseHistories,
                                        caseHistoryDetailList, stages, requiredActions);
                                populateMilestoneOpenTime(
                                        stageHistoryDetail, stageHistories, caseHistories);
                                populateMilestoneCloseTime(
                                        stageHistoryDetail,
                                        stageHistories,
                                        caseHistories,
                                        isProductSwitchApp);
                                stageHistoryDetail.setCaseHistory(caseHistoryDetailList);
                                setRagStatus(
                                        stageHistoryDetail, latestStageNumber, isProductSwitchApp);
                                setSubStatus(stageHistoryDetail);
                                setCaseHistoryCategory(stageHistoryDetail.getCaseHistory());
                                populateRequiredActions(stageHistoryDetail, requiredActions);
                                removeOpenAwaitTasks(stageHistoryDetail);
                                stageHistoryDetailList.add(stageHistoryDetail);
                            });

            boolean isDeclinedOrCancelledMileStoneExist =
                    Optional.of(stageHistoryDetailList).orElseGet(Collections::emptyList).stream()
                            .anyMatch(this::checkDeclinedOrCancelledMileStonePresence);

            if (isDeclinedOrCancelledMileStoneExist) {
                stageHistoryDetailList.forEach(
                        stageHistoryDetail -> {
                            if (!checkDeclinedOrCancelledMileStonePresence(stageHistoryDetail)) {
                                stageHistoryDetail.setRagStatus(null);
                                stageHistoryDetail.setRagDescription(null);
                                stageHistoryDetail.setSubStatus(null);
                                stageHistoryDetail.setSubStatusDescription(null);
                            }
                        });
            }
        }

        return stageHistoryDetailList;
    }

    private void addGranularTrackingInfoInCaseHistoryList(Map<String, List<GranularTracking>> granularTrackingMap,
                                                          List<CaseHistory> caseHistories, List<CaseHistoryDetail> caseHistoryDetailList,
                                                          List<String> stages, List<RequiredActionDetail> requiredActions) {
        stages.forEach(stage -> Optional.ofNullable(granularTrackingMap.get(stage))
                .orElseGet(Collections::emptyList)
                .forEach(granularTracking -> {
                    if (OPEN.equalsIgnoreCase(granularTracking.getState())) {
                        GranularTrackingDetail granularTrackingDetail = applicationDetailsResponseMapper.toGranularTrackingDetail(granularTracking);
                        RequiredActionDetail requiredActionDetail = RequiredActionDetail.builder()
                                .description(granularTracking.getDescription())
                                .timeOpen(granularTracking.getRequestedDate())
                                .detailedInfo(granularTrackingDetail)
                                .build();
                        requiredActions.add(requiredActionDetail);
                    } else {
                        CaseHistory caseHistory = CaseHistory.builder()
                                .description(granularTracking.getDescription())
                                .status(CLOSE)
                                .openDateTime(granularTracking.getRequestedDate())
                                .closedDateTime(granularTracking.getUpdatedDate())
                                .build();
                        caseHistories.add(caseHistory);
                        caseHistoryDetailList.add(applicationDetailsResponseMapper.toCaseHistoryDetail(caseHistory, granularTracking.getGmsCategory()));
                    }
                }));
        caseHistories.sort(Comparator.comparing(CaseHistory::getOpenDateTime).reversed());
        caseHistoryDetailList.sort(Comparator.comparing(CaseHistoryDetail::getTimeOpen).reversed());
    }

    private String getLatestStageNumber(ApplicationDetails applicationDetails) {
        return Optional.ofNullable(applicationDetails.getStageHistory())
                .orElseGet(Collections::emptyList).stream()
                .findFirst()
                .map(StageHistory::getCode)
                .orElse(null);
    }

    private String getSecondLatestStageNumber(ApplicationDetails applicationDetails) {
        return Optional.ofNullable(applicationDetails.getStageHistory())
                .orElseGet(Collections::emptyList).stream()
                .skip(1)
                .findFirst()
                .map(StageHistory::getCode)
                .orElse(null);
    }

    private void removeOpenAwaitTasks(StageHistoryDetail stageHistoryDetail) {
        List<CaseHistoryDetail> cases =
                Optional.ofNullable(stageHistoryDetail.getCaseHistory())
                        .orElseGet(Collections::emptyList).stream()
                        .filter(
                                caseHistory ->
                                        !(AWAIT.equalsIgnoreCase(caseHistory.getCategory())
                                                && Objects.isNull(caseHistory.getTimeClosed())))
                        .collect(Collectors.toList());
        stageHistoryDetail.setCaseHistory(cases);
    }

    private void populateRequiredActions(StageHistoryDetail stageHistoryDetail, List<RequiredActionDetail> requiredActions) {
        Optional.ofNullable(stageHistoryDetail.getCaseHistory())
                .orElseGet(Collections::emptyList)
                .forEach(
                        caseHistory -> {
                            if (Objects.isNull(caseHistory.getTimeClosed())
                                    && AWAIT.equalsIgnoreCase(caseHistory.getCategory())
                                    && !FST.equalsIgnoreCase(caseHistory.getCode())) {
                                RequiredActionDetail requiredActionDetail =
                                        RequiredActionDetail.builder()
                                                .description(caseHistory.getDescription())
                                                .timeOpen(caseHistory.getTimeOpen())
                                                .build();
                                requiredActions.add(requiredActionDetail);
                            }
                        });

        requiredActions.sort(Comparator.comparing(RequiredActionDetail::getTimeOpen).reversed());
        stageHistoryDetail.setRequiredActions(requiredActions);
    }

    public void setCaseHistoryCategory(List<CaseHistoryDetail> caseHistory) {
        caseHistory.forEach(
                caseHistoryDetail -> {
                    if (Objects.isNull(caseHistoryDetail.getCode())) {
                        return;
                    }
                    caseHistoryDetail.setCategory(
                            stageTaskLoader.isAwaitTask(caseHistoryDetail.getCode())
                                    ? AWAIT
                                    : stageTaskLoader.isAssessTask(caseHistoryDetail.getCode())
                                            ? ASSESS
                                            : null);
                });
    }

    public void setSubStatus(StageHistoryDetail stageHistoryDetail) {
        stageHistoryDetail.setSubStatus(NO_ACTION_REQUIRED);
        List<String> openTask =
                stageHistoryDetail.getCaseHistory().stream()
                        .filter(task -> task.getTimeOpen() != null && task.getTimeClosed() == null)
                        .map(CaseHistoryDetail::getCode)
                        .collect(Collectors.toList());
        for (String task : openTask) {
            if (stageTaskLoader.isAwaitTask(task)) {
                stageHistoryDetail.setSubStatus(ACTION_REQUIRED);
                break;
            }
        }
        stageHistoryDetail.setSubStatusDescription(
                stageTaskLoader.getStatusDescription(stageHistoryDetail.getSubStatus()));
    }

    /**
     * Method to populate rag status for a milestone
     *
     * @param stageHistoryDetail - stageHistoryDetail
     * @param latestStageNumber - latestStageNumber
     * @param isProductSwitchApp - isProductSwitchApp
     */
    public void setRagStatus(
            StageHistoryDetail stageHistoryDetail,
            String latestStageNumber,
            boolean isProductSwitchApp) {
        if (stageHistoryDetail.getDescription().equals(MILESTONE_COMPLETION)
                && Objects.nonNull(latestStageNumber)
                && !STAGE_92.equals(latestStageNumber)
                && latestStageNumber.compareTo("80") > 0) {
            stageHistoryDetail.setRagStatus(RED);
        } else if (PRODUCT_SWITCH_STATUS.equalsIgnoreCase(stageHistoryDetail.getDescription())
                && Objects.nonNull(latestStageNumber)
                && latestStageNumber.compareTo("80") > 0) {
            stageHistoryDetail.setRagStatus(RED);
        } else if (stageHistoryDetail.getTimeOpen() == null) {
            stageHistoryDetail.setRagStatus(
                    (stageHistoryDetail.getDescription().equals(MILESTONE_PRE_ASSESSMENT))
                            ? GREEN
                            : GREY);
        } else if (stageHistoryDetail.getTimeClosed() == null) {
            stageHistoryDetail.setRagStatus(AMBER);
        } else {
            stageHistoryDetail.setRagStatus(GREEN);
        }
        populateMilestoneAndRagDescription(stageHistoryDetail, isProductSwitchApp);
    }

    private void populateMilestoneAndRagDescription(
            StageHistoryDetail stageHistoryDetail, boolean isProductSwitchApp) {
        if (isProductSwitchApp && RED.equalsIgnoreCase(stageHistoryDetail.getRagStatus())) {
            String ragDesc = stageTaskLoader.getStatusDescription(PRODUCT_SWITCH_CANCELLED);
            stageHistoryDetail.setRagDescription(ragDesc);
        } else {
            setMilestoneDescription(stageHistoryDetail);
            String ragDesc =
                    stageTaskLoader.getStatusDescription(stageHistoryDetail.getRagStatus());
            stageHistoryDetail.setRagDescription(
                    (Objects.nonNull(ragDesc)
                                    && Objects.nonNull(stageHistoryDetail.getDescription()))
                            ? ragDesc.replace(MILESTONE_NAME, stageHistoryDetail.getDescription())
                            : null);
        }
    }

    public void setMilestoneDescription(StageHistoryDetail stageHistoryDetail) {
        stageHistoryDetail.setDescription(
                stageHistoryDetail.getRagStatus().equals(RED)
                        ? stageTaskLoader.getStatusDescription(DECLINE)
                        : stageHistoryDetail.getDescription());
    }

    private List<CaseHistory> populateCaseHistory(
            Map<String, List<CaseHistory>> existingCaseHistoryMap, List<String> tasks) {
        List<CaseHistory> caseHistoryList = new ArrayList<>();
        tasks.forEach(
                task ->
                        Optional.ofNullable(existingCaseHistoryMap.get(task))
                                .ifPresent(caseHistoryList::addAll));
        caseHistoryList.removeIf(
                caseHistory ->
                        (StringUtils.equals(caseHistory.getCode(), R29)
                                        || StringUtils.equals(caseHistory.getCode(), DR2))
                                && StringUtils.equals(caseHistory.getStatus(), OPEN));
        caseHistoryList.sort(Comparator.comparing(CaseHistory::getOpenDateTime).reversed());
        return caseHistoryList;
    }

    private List<StageHistory> populateStageHistory(
            Map<String, List<StageHistory>> existingStageHistoryMap, List<String> stages) {
        List<StageHistory> stageHistoryList = new ArrayList<>();
        stages.forEach(
                stage ->
                        Optional.ofNullable(existingStageHistoryMap.get(stage))
                                .ifPresent(stageHistoryList::addAll));
        return stageHistoryList;
    }

    public void populateMilestoneOpenTime(
            StageHistoryDetail stageHistoryDetail,
            List<StageHistory> stageHistoryList,
            List<CaseHistory> caseHistoryList) {
        ZonedDateTime oldestStageOpenTime =
                stageHistoryList.stream()
                        .filter(Objects::nonNull)
                        .min(Comparator.comparing(StageHistory::getOpenDateTime))
                        .map(StageHistory::getOpenDateTime)
                        .orElse(null);
        ZonedDateTime oldestTaskOpenTime =
                caseHistoryList.stream()
                        .filter(Objects::nonNull)
                        .min(Comparator.comparing(CaseHistory::getOpenDateTime))
                        .map(CaseHistory::getOpenDateTime)
                        .orElse(null);
        if (Objects.nonNull(oldestStageOpenTime) && Objects.nonNull(oldestTaskOpenTime)) {
            if (oldestStageOpenTime.isBefore(oldestTaskOpenTime)) {
                stageHistoryDetail.setTimeOpen(oldestStageOpenTime);
            } else {
                stageHistoryDetail.setTimeOpen(oldestTaskOpenTime);
            }
        } else if (Objects.nonNull(oldestTaskOpenTime)) {
            stageHistoryDetail.setTimeOpen(oldestTaskOpenTime);
        } else {
            stageHistoryDetail.setTimeOpen(oldestStageOpenTime);
        }
    }

    /**
     * Method to populate milestone closing time
     *
     * @param stageHistoryDetail - stageHistoryDetail
     * @param stageHistoryList - stageHistoryList
     * @param caseHistoryList - caseHistoryList
     * @param isProductSwitchApp - isProductSwitchApp
     */
    public void populateMilestoneCloseTime(
            StageHistoryDetail stageHistoryDetail,
            List<StageHistory> stageHistoryList,
            List<CaseHistory> caseHistoryList,
            boolean isProductSwitchApp) {
        if (isProductSwitchApp) {
            populateMilestoneClosingTimeForProductSwitch(stageHistoryDetail, stageHistoryList);
        } else {
            if (!checkIfAllTasksAreClosed(caseHistoryList)) {
                return;
            }

            ZonedDateTime latestStageCloseTime = getLatestStageCloseTime(stageHistoryList);
            ZonedDateTime latestTaskCloseTime = getLatestTaskCloseTime(caseHistoryList);

            if (Objects.nonNull(latestStageCloseTime) && Objects.nonNull(latestTaskCloseTime)) {
                if (latestStageCloseTime.isAfter(latestTaskCloseTime)) {
                    stageHistoryDetail.setTimeClosed(latestStageCloseTime);
                } else {
                    stageHistoryDetail.setTimeClosed(latestTaskCloseTime);
                }
            } else if (CollectionUtils.isEmpty(stageHistoryList)
                    && Objects.nonNull(latestTaskCloseTime)) {
                stageHistoryDetail.setTimeClosed(latestTaskCloseTime);
            } else if (CollectionUtils.isEmpty(caseHistoryList)
                    && Objects.nonNull(latestStageCloseTime)) {
                stageHistoryDetail.setTimeClosed(latestStageCloseTime);
            }
        }
    }

    private void populateMilestoneClosingTimeForProductSwitch(
            StageHistoryDetail stageHistoryDetail, List<StageHistory> stageHistoryList) {
        if (!checkIfAllStagesAreClosed(stageHistoryList)) {
            return;
        }
        ZonedDateTime latestStageCloseTime = getLatestStageCloseTime(stageHistoryList);
        stageHistoryDetail.setTimeClosed(latestStageCloseTime);
    }

    /**
     * method to check if all the stages are closed
     *
     * @param stageHistoryList - stageHistoryList
     * @return true or false
     */
    public boolean checkIfAllStagesAreClosed(List<StageHistory> stageHistoryList) {
        if (CollectionUtils.isNotEmpty(stageHistoryList)) {
            return stageHistoryList.stream()
                    .allMatch(stageHistory -> Objects.nonNull(stageHistory.getClosedDateTime()));
        }
        return true;
    }

    private ZonedDateTime getLatestStageCloseTime(List<StageHistory> stageHistoryList) {
        ZonedDateTime lastStageOpenTime =
                stageHistoryList.stream()
                        .filter(Objects::nonNull)
                        .max(Comparator.comparing(StageHistory::getOpenDateTime))
                        .map(StageHistory::getOpenDateTime)
                        .orElse(null);
        if (Objects.nonNull(lastStageOpenTime)) {
            List<StageHistory> stagesOpenedAtSameLastStageOpenTime =
                    stageHistoryList.stream()
                            .filter(stage -> lastStageOpenTime.isEqual(stage.getOpenDateTime()))
                            .collect(Collectors.toList());
            boolean isAllStageClosed =
                    stagesOpenedAtSameLastStageOpenTime.stream()
                            .allMatch(stage -> Objects.nonNull(stage.getClosedDateTime()));
            if (isAllStageClosed) {
                return stagesOpenedAtSameLastStageOpenTime.stream()
                        .max(Comparator.comparing(StageHistory::getClosedDateTime))
                        .map(StageHistory::getClosedDateTime)
                        .orElse(null);
            } else {
                return null;
            }
        }
        return null;
    }

    private ZonedDateTime getLatestTaskCloseTime(List<CaseHistory> caseHistoryList) {
        ZonedDateTime lastTaskOpenTime =
                caseHistoryList.stream()
                        .filter(Objects::nonNull)
                        .max(Comparator.comparing(CaseHistory::getOpenDateTime))
                        .map(CaseHistory::getOpenDateTime)
                        .orElse(null);
        if (Objects.nonNull(lastTaskOpenTime)) {
            List<CaseHistory> tasksOpenedAtSameLastTaskOpenTime =
                    caseHistoryList.stream()
                            .filter(task -> lastTaskOpenTime.isEqual(task.getOpenDateTime()))
                            .collect(Collectors.toList());
            return tasksOpenedAtSameLastTaskOpenTime.stream()
                    .max(Comparator.comparing(CaseHistory::getClosedDateTime))
                    .map(CaseHistory::getClosedDateTime)
                    .orElse(null);
        }
        return null;
    }

    public boolean checkIfAllTasksAreClosed(List<CaseHistory> caseHistoryList) {
        if (CollectionUtils.isNotEmpty(caseHistoryList)) {
            return caseHistoryList.stream()
                    .allMatch(caseHistory -> Objects.nonNull(caseHistory.getClosedDateTime()));
        }
        return true;
    }

    /**
     * Method to remove the excluded stages
     *
     * @param referenceNumber - referenceNumber
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param isProductSwitchApp - isProductSwitchApp
     */
    public void removeExcludedStages(
            String referenceNumber,
            ApplicationDetailsInfo applicationDetailsInfo,
            boolean isProductSwitchApp) {
        List<StageHistory> stageHistories = new ArrayList<>();
        Set<String> removedStages = new HashSet<>();
        if (isProductSwitchApp) {
            removeExcludedStagesForProductSwitchApplication(
                    applicationDetailsInfo, stageHistories, removedStages);
        } else {
            if (notNullStageHistory(applicationDetailsInfo)) {
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStageHistory()
                        .forEach(
                                stageHistory -> {
                                    if (stageTaskLoader.isAllowedStage(stageHistory.getCode())) {
                                        stageHistories.add(stageHistory);
                                    } else {
                                        removedStages.add(stageHistory.getCode());
                                    }
                                });
                applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistories);
            }
        }

        log.debug(
                "Excluded stages: {} from downstream response for reference number: {}",
                removedStages,
                referenceNumber);
    }

    private void removeExcludedStagesForProductSwitchApplication(
            ApplicationDetailsInfo applicationDetailsInfo,
            List<StageHistory> stageHistories,
            Set<String> removedStages) {
        if (notNullStageHistory(applicationDetailsInfo)) {
            Map<String, MilestoneMappingInformation> milestoneMapInfo =
                    stageTaskLoader.getProductSwitchMilestoneMappingInformation();
            applicationDetailsInfo
                    .getApplicationDetails()
                    .getStageHistory()
                    .forEach(
                            stageHistory -> {
                                boolean isStagePresentInMilestoneMapping =
                                        milestoneMapInfo.entrySet().stream()
                                                .anyMatch(
                                                        entry ->
                                                                entry.getValue()
                                                                        .getStages()
                                                                        .contains(
                                                                                stageHistory
                                                                                        .getCode()));
                                if (isStagePresentInMilestoneMapping) {
                                    stageHistories.add(stageHistory);
                                } else {
                                    removedStages.add(stageHistory.getCode());
                                }
                            });
            applicationDetailsInfo.getApplicationDetails().setStageHistory(stageHistories);
        }
    }

    /**
     * Method to remove the excluded tasks
     *
     * @param referenceNumber - referenceNumber
     * @param applicationDetailsInfo - applicationDetailsInfo
     * @param isProductSwitchApp - isProductSwitchApp
     */
    public void removeExcludedTasks(
            String referenceNumber,
            ApplicationDetailsInfo applicationDetailsInfo,
            boolean isProductSwitchApp) {
        List<CaseHistory> caseHistories = new ArrayList<>();
        Set<String> removedTasks = new HashSet<>();
        if (isProductSwitchApp) {
            removeExcludedTasksForProductSwitchApplication(
                    applicationDetailsInfo, caseHistories, removedTasks);
        } else {
            if (notNullCaseHistory(applicationDetailsInfo)) {
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getCaseHistory()
                        .forEach(
                                caseHistory -> {
                                    if (stageTaskLoader.isAllowedTask(caseHistory.getCode())) {
                                        caseHistories.add(caseHistory);
                                    } else {
                                        removedTasks.add(caseHistory.getCode());
                                    }
                                });
                applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistories);
            }
        }
        log.debug(
                "Excluded tasks: {} from downstream response for reference number: {}",
                removedTasks,
                referenceNumber);
    }

    private void removeExcludedTasksForProductSwitchApplication(
            ApplicationDetailsInfo applicationDetailsInfo,
            List<CaseHistory> caseHistories,
            Set<String> removedTasks) {
        if (notNullCaseHistory(applicationDetailsInfo)) {
            Map<String, MilestoneMappingInformation> milestoneMapInfo =
                    stageTaskLoader.getProductSwitchMilestoneMappingInformation();
            applicationDetailsInfo
                    .getApplicationDetails()
                    .getCaseHistory()
                    .forEach(
                            caseHistory -> {
                                boolean isTaskPresentInMilestoneMapping =
                                        milestoneMapInfo.entrySet().stream()
                                                .anyMatch(
                                                        entry ->
                                                                entry.getValue()
                                                                        .getTasks()
                                                                        .contains(
                                                                                caseHistory
                                                                                        .getCode()));
                                if (isTaskPresentInMilestoneMapping) {
                                    caseHistories.add(caseHistory);
                                } else {
                                    removedTasks.add(caseHistory.getCode());
                                }
                            });
            applicationDetailsInfo.getApplicationDetails().setCaseHistory(caseHistories);
        }
    }

    public void populateTaskDescription(ApplicationDetailsInfo applicationDetailsInfo) {
        log.info("populateTaskDescription method enters");
        if (notNullCaseHistory(applicationDetailsInfo)) {
            applicationDetailsInfo
                    .getApplicationDetails()
                    .getCaseHistory()
                    .forEach(
                            caseHistory -> {
                                if (isNotBlank(caseHistory.getCode())) {
                                    populateCaseHistoryDescription(
                                            applicationDetailsInfo, caseHistory);
                                }
                            });
        }
    }

    private void populateCaseHistoryDescription(
            ApplicationDetailsInfo applicationDetailsInfo, CaseHistory caseHistory) {
        GMSTaskDescription gmsTaskDescription =
                stageTaskLoader.getTaskDescription(caseHistory.getCode());
        if (Objects.nonNull(gmsTaskDescription)) {
            log.debug(
                    "$ contains :{}",
                    gmsTaskDescription.getDescription().contains(NAME_PLACE_HOLDER));
            if (isNotBlank(gmsTaskDescription.getDescription())
                    && gmsTaskDescription.getDescription().contains(NAME_PLACE_HOLDER)) {
                String description = setApplicantName(applicationDetailsInfo, gmsTaskDescription);
                caseHistory.setDescription(description);
            } else {
                if (isNotBlank(gmsTaskDescription.getDescription())) {
                    caseHistory.setDescription(gmsTaskDescription.getDescription());
                }
            }
        } else if (FST.equalsIgnoreCase(caseHistory.getCode())) {
            caseHistory.setDescription(FST);
        } else {
            caseHistory.setDescription(
                    stageTaskLoader.getTaskDescription(DEFAULT_TASK_CODE).getDescription());
        }
    }

    private String setApplicantName(
            ApplicationDetailsInfo applicationDetailsInfo, GMSTaskDescription gmsTaskDescription) {
        log.info("setApplicantName method enters");
        String description = null;
        if (isNotBlank(gmsTaskDescription.getDescription())
                && gmsTaskDescription.getDescription().contains(NAME_PLACE_HOLDER)) {
            List<Applicant> applicantInformationList =
                    applicationDetailsInfo.getApplicantInformation();
            String isMainApplicant = parseMainApplicant(gmsTaskDescription);
            log.debug("isMainApplicant :{}", isMainApplicant);
            if (nonNullList(applicantInformationList)) {
                Optional<String> applicantNameToReplace =
                        applicantInformationList.stream()
                                .filter(
                                        applicantInformation ->
                                                applicantInformation
                                                        .getIsMainApplicant()
                                                        .equalsIgnoreCase(isMainApplicant))
                                .map(
                                        applicantInformation ->
                                                String.join(
                                                        " ",
                                                        applicantInformation.getFirstName(),
                                                        applicantInformation.getLastName()))
                                .findFirst();

                description =
                        processApplicantNameAndDescription(
                                gmsTaskDescription,
                                isMainApplicant,
                                applicantNameToReplace.orElse(""));
            }
        }
        return description;
    }

    private String processApplicantNameAndDescription(
            GMSTaskDescription gmsTaskDescription, String isMainApplicant, String applicantName) {
        String placeHolderToReplace =
                isMainApplicant.equalsIgnoreCase(YES)
                        ? APPLICANT_PLACE_HOLDER
                        : JOINT_APPLICANT_PLACE_HOLDER;
        log.debug(
                "isMainApplicant :{} placeHolderToReplace :{} applicantName :{}",
                isMainApplicant,
                placeHolderToReplace,
                applicantName);
        String description =
                gmsTaskDescription.getDescription().replace(placeHolderToReplace, applicantName);
        log.debug("description :{}", description);
        return description;
    }

    private boolean nonNullList(List<?> list) {
        return Objects.nonNull(list) && !list.isEmpty();
    }

    private String parseMainApplicant(GMSTaskDescription gmsTaskDescription) {
        return gmsTaskDescription
                        .getDescription()
                        .toLowerCase()
                        .contains(APPLICANT_PLACE_HOLDER.toLowerCase())
                ? YES
                : NO;
    }

    private boolean notNullStageHistory(ApplicationDetailsInfo applicationDetailsInfo) {
        return Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())
                && Objects.nonNull(
                        applicationDetailsInfo.getApplicationDetails().getStageHistory());
    }

    private boolean notNullCaseHistory(ApplicationDetailsInfo applicationDetailsInfo) {
        return Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails().getCaseHistory());
    }

    private void validateBroker(BrokerValidationRequest request) {
        BrokerValidationResponse response = brokerValidationService.validateBroker(request);
        if (!response.isAllowMortgageBusiness()) {
            log.error("Broker validation failed request : {}", request);
            throw new BrokerValidationException(
                    errorMessageConfigReader
                            .getMessage()
                            .get(ERROR_CODE_401_BROKER_VALIDATION_FAILURE));
        }
    }

    /**
     * @param stageHistoryDetail
     * @return boolean
     */
    private boolean checkDeclinedOrCancelledMileStonePresence(
            StageHistoryDetail stageHistoryDetail) {
        return Objects.nonNull(stageHistoryDetail.getDescription())
                && stageHistoryDetail
                        .getDescription()
                        .equalsIgnoreCase(MILESTONE_DECLINED_OR_CANCELLED)
                && stageHistoryDetail.getRagStatus().equalsIgnoreCase(RED);
    }

    /**
     * this method is used to set COT Date
     *
     * @param applicationDetailsInfo - ApplicationDetailsInfo Object
     * @param response - ApplicationDetailsResponse Object
     */
    public void populateCOTDate(
            ApplicationDetailsInfo applicationDetailsInfo, ApplicationDetailsResponse response) {
        log.info("populateCOTDate method enters");
        if (notNullCaseHistory(applicationDetailsInfo) && chkOfferGreyStatus(response)) {
            applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                    .filter(caseHistory -> ARO.equalsIgnoreCase(caseHistory.getCode()))
                    .findFirst()
                    .ifPresent(
                            task ->
                                    response.getStatus()
                                            .setCotReceivedDate(task.getClosedDateTime()));

            if (Objects.nonNull(response.getStatus().getCotReceivedDate())) {
                populateCotAssessDate(applicationDetailsInfo, response);
                populateCotAcceptedDate(applicationDetailsInfo, response);
            }
        }
    }

    private boolean chkOfferGreyStatus(ApplicationDetailsResponse response) {
        Optional<List<StageHistoryDetail>> historyDetails =
                Optional.ofNullable(response)
                        .map(ApplicationDetailsResponse::getApplicationDetails)
                        .map(HistoryDetails::getStageHistory);
        return historyDetails
                .map(
                        stageHistoryDetails ->
                                stageHistoryDetails.stream()
                                        .noneMatch(
                                                stageHistoryDetail ->
                                                        StringUtils.equals(
                                                                        stageHistoryDetail
                                                                                .getDescription(),
                                                                        OFFER)
                                                                && StringUtils.equals(
                                                                        stageHistoryDetail
                                                                                .getRagStatus(),
                                                                        GREY)))
                .orElse(false);
    }

    /**
     * This method is used to update the RAG status for Offer and Completion milestone
     *
     * @param applicationDetailsInfo - ApplicationDetailsInfo object
     * @param response - ApplicationDetailsResponse object
     */
    public void updateMileStoneRagStatus(
            ApplicationDetailsInfo applicationDetailsInfo, ApplicationDetailsResponse response) {
        if (Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())) {
            String latestStageNumber =
                    getLatestStageNumber(applicationDetailsInfo.getApplicationDetails());
            if (Objects.nonNull(latestStageNumber)
                    && (latestStageNumber.compareTo("28") < 0
                            || latestStageNumber.compareTo("30") == 0)) {
                response.getApplicationDetails()
                        .getStageHistory()
                        .forEach(
                                stageHistoryDetail -> {
                                    if (StringUtils.equals(
                                                    stageHistoryDetail.getDescription(), OFFER)
                                            || StringUtils.equals(
                                                    stageHistoryDetail.getDescription(),
                                                    COMPLETION)) {
                                        stageHistoryDetail.setRagStatus(GREY);
                                        populateMilestoneAndRagDescription(
                                                stageHistoryDetail, false);
                                    }
                                });
            }
        }
    }

    /**
     * This method is used to update the RAG status for Offer and Completion milestone from stage 84
     *
     * @param applicationDetailsInfo - ApplicationDetailsInfo object
     * @param response - ApplicationDetailsResponse object
     * @param isProductSwitchApp - boolean
     */
    public void updateMileStone(
            ApplicationDetailsInfo applicationDetailsInfo,
            ApplicationDetailsResponse response,
            boolean isProductSwitchApp) {
        if (Objects.nonNull(applicationDetailsInfo)
                && Objects.nonNull(applicationDetailsInfo.getApplicationDetails())) {
            String latestStageNumber =
                    getLatestStageNumber(applicationDetailsInfo.getApplicationDetails());
            String secondLatestStageNumber =
                    getSecondLatestStageNumber(applicationDetailsInfo.getApplicationDetails());
            if (Objects.nonNull(latestStageNumber)
                    && Objects.nonNull(secondLatestStageNumber)
                    && secondLatestStageNumber.compareTo("84") == 0) {
                if (latestStageNumber.matches("20|25|30")) {
                    response.getApplicationDetails()
                            .getStageHistory()
                            .forEach(
                                    stageHistoryDetail -> {
                                        if (StringUtils.equals(
                                                stageHistoryDetail.getDescription(), OFFER)) {
                                            stageHistoryDetail.setRagStatus(GREY);
                                            populateMilestoneAndRagDescription(
                                                    stageHistoryDetail, isProductSwitchApp);
                                        }
                                        if (StringUtils.equals(
                                                stageHistoryDetail.getDescription(), COMPLETION)) {
                                            stageHistoryDetail.setDescription(
                                                    MILESTONE_DECLINED_OR_CANCELLED);
                                            stageHistoryDetail.setRagStatus(RED);
                                            populateMilestoneAndRagDescription(
                                                    stageHistoryDetail, isProductSwitchApp);
                                        }
                                    });
                } else if (latestStageNumber.matches("34|36")) {
                    response.getApplicationDetails()
                            .getStageHistory()
                            .forEach(
                                    stageHistoryDetail -> {
                                        if (StringUtils.equals(
                                                stageHistoryDetail.getDescription(), OFFER)) {
                                            stageHistoryDetail.setRagStatus(AMBER);
                                            populateMilestoneAndRagDescription(
                                                    stageHistoryDetail, isProductSwitchApp);
                                        }
                                        if (StringUtils.equals(
                                                stageHistoryDetail.getDescription(), COMPLETION)) {
                                            stageHistoryDetail.setRagStatus(GREY);
                                            populateMilestoneAndRagDescription(
                                                    stageHistoryDetail, isProductSwitchApp);
                                        }
                                    });
                }
            }
        }
    }

    /**
     * This method is used to reset COT date
     *
     * @param response - ApplicationDetailsResponse object
     */
    public void resetCOTDate(ApplicationDetailsResponse response) {
        boolean chk =
                response.getApplicationDetails().getStageHistory().stream()
                        .anyMatch(
                                stageHistoryDetail ->
                                        StringUtils.equals(
                                                        stageHistoryDetail.getDescription(),
                                                        COMPLETION)
                                                && StringUtils.equals(
                                                        stageHistoryDetail.getRagStatus(), GREY));
        if (chk) {
            response.getStatus().setCotAcceptedDate(null);
            response.getStatus().setCotAssessDate(null);
            response.getStatus().setExpectedCompletionDate(null);
        }
    }

    private void validateBroker(BrokerDetailValidationRequest request) {
        log.info(
                "validateBroker method enters for broker detail validate in ApplicationTrackingServiceImpl class : ");
        BrokerDetailValidationResponse response =
                brokerDetailValidationService.validateBroker(request);
        boolean isAllowMortgageBusiness = false;
        if (Objects.nonNull(response) && Objects.nonNull(response.getBrokers()))
            isAllowMortgageBusiness =
                    response.getBrokers().stream()
                            .map(FirmBroker::getAcceptMortgageBusiness)
                            .allMatch(
                                    acceptMortgageBusiness ->
                                            StringUtils.isNotEmpty(acceptMortgageBusiness)
                                                    && YES.equalsIgnoreCase(
                                                            acceptMortgageBusiness));
        if (!isAllowMortgageBusiness) {
            log.error("Broker Detail validation failed request : {}", request);
            throw new BrokerValidationException(
                    errorMessageConfigReader
                            .getMessage()
                            .get(ERROR_CODE_401_BROKER_VALIDATION_FAILURE));
        }
    }

    /**
     * This method is used to set cot assess date
     *
     * @param applicationDetailsInfo - input
     * @param response - input
     */
    void populateCotAssessDate(
            ApplicationDetailsInfo applicationDetailsInfo, ApplicationDetailsResponse response) {
        log.info("populateCotAssessDate method enters now");
        if (applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                .filter(caseHistory -> FNE_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                .findFirst()
                .isPresent()) {
            applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                    .filter(caseHistory -> FNE_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                    .findFirst()
                    .ifPresent(
                            task ->
                                    response.getStatus()
                                            .setCotAssessDate(task.getClosedDateTime()));
        } else if (applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                .filter(caseHistory -> SCM_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                .findFirst()
                .isPresent()) {
            applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                    .filter(caseHistory -> SCM_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                    .findFirst()
                    .ifPresent(
                            task ->
                                    response.getStatus()
                                            .setCotAssessDate(task.getClosedDateTime()));
        } else {
            applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                    .filter(caseHistory -> SRP.equalsIgnoreCase(caseHistory.getCode()))
                    .findFirst()
                    .ifPresent(
                            task ->
                                    response.getStatus()
                                            .setCotAssessDate(task.getClosedDateTime()));
        }
    }

    /**
     * This method is used to set cot accepted date
     *
     * @param applicationDetailsInfo - input
     * @param response - input
     */
    void populateCotAcceptedDate(
            ApplicationDetailsInfo applicationDetailsInfo, ApplicationDetailsResponse response) {
        log.info("populateCotAcceptedDate method enters now");
        if (applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                .filter(caseHistory -> AEC_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                .findFirst()
                .isPresent()) {

            applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                    .filter(caseHistory -> AEC_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                    .findFirst()
                    .ifPresent(
                            task ->
                                    response.getStatus()
                                            .setCotAcceptedDate(task.getOpenDateTime()));
        } else if (applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                .filter(caseHistory -> SRM_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                .findFirst()
                .isPresent()) {
            applicationDetailsInfo.getApplicationDetails().getCaseHistory().stream()
                    .filter(caseHistory -> SRM_TASK_CODE.equalsIgnoreCase(caseHistory.getCode()))
                    .findFirst()
                    .ifPresent(
                            task ->
                                    response.getStatus()
                                            .setCotAcceptedDate(task.getOpenDateTime()));

        } else {
            String latestStageNumber =
                    getLatestStageNumber(applicationDetailsInfo.getApplicationDetails());
            if (Objects.nonNull(applicationDetailsInfo.getApplicationDetails().getStageHistory())
                    && Objects.nonNull(latestStageNumber)
                    && (latestStageNumber.compareTo("50") >= 0)) {
                applicationDetailsInfo.getApplicationDetails().getStageHistory().stream()
                        .filter(stageHistory -> "50".equals(stageHistory.getCode()))
                        .findFirst()
                        .ifPresent(
                                stageHistory ->
                                        response.getStatus()
                                                .setCotAcceptedDate(
                                                        stageHistory.getOpenDateTime()));
            }
        }
    }
}
