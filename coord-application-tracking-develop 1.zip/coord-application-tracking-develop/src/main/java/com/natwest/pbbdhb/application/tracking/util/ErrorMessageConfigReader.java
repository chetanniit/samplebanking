/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/** Property reader to read the properties related to error */
@ConfigurationProperties(prefix = "custom")
@Getter
@Setter
public class ErrorMessageConfigReader {
    private Map<String, String> message;
    private Map<String, String> applications;
    private Map<String, String> applicationDetails;
}
