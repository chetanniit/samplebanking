/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_TIME_FORMAT;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.DateSerializer;
import java.time.ZonedDateTime;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@JsonIgnoreProperties(value = {"stage"})
public class StageHistory {
    private String stage;
    private String code;
    private String description;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
    private ZonedDateTime openDateTime;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
    private ZonedDateTime closedDateTime;
}
