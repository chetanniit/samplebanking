/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.request;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.*;

import com.natwest.pbbdhb.application.tracking.model.exception.InvalidDateRangeValueException;
import com.natwest.pbbdhb.application.tracking.validator.format.AdminEmailConstraint;
import com.natwest.pbbdhb.application.tracking.validator.format.DOBDateConstraint;
import com.natwest.pbbdhb.application.tracking.validator.format.EmailFormat;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@Data
@Schema(description = "Application Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Builder
public class ApplicationRequest {

    @Parameter(required = true)
    @NotNull(message = INVALID_FCA_NUMBER)
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_FCA_NUMBER)
    private String fcaNumber;

    @Parameter(required = true)
    @NotNull(message = INVALID_FIRM_POST_CODE)
    @Pattern(
            regexp = VALIDATE_POST_CODE,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_FIRM_POST_CODE)
    private String firmPostcode;

    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_AND_ATLEAST_TWO_AND_MAX_HUNDRED_CHARACTERS,
            message = INVALID_BROKER_USER_NAME)
    private String brokerUserName;

    @Parameter(required = true)
    @NotNull(message = INVALID_BROKER_FIRST_NAME)
    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_BROKER_FIRST_NAME)
    private String brokerFirstName;

    @Parameter(required = true)
    @NotNull(message = INVALID_BROKER_LAST_NAME)
    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_BROKER_LAST_NAME)
    private String brokerLastName;

    @Parameter(required = true)
    @NotNull(message = INVALID_EMAIL_ID)
    @EmailFormat
    private String brokerEmailId;

    @Parameter(required = true)
    @NotNull(message = INVALID_BROKER_POST_CODE)
    @Pattern(
            regexp = VALIDATE_POST_CODE,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_BROKER_POST_CODE)
    private String brokerPostcode;

    @Parameter(
            description = "date range to find applications",
            example = "LastWeek",
            schema =
            @Schema(
                    type = "string",
                    defaultValue = DEFAULT_DATE_RANGE,
                    allowableValues = {LAST_WEEK, LAST_MONTH, LAST_THREE_MONTH, ALL}))
    @Pattern(
            regexp = VALID_DATE_RANGE,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_DATE_RANGE)
    private String dateRange;

    @Parameter(
            description = "page number to filter applications",
            schema = @Schema(type = "string", defaultValue = DEFAULT_PAGE_NUMBER))
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_PAGE_NUMBER)
    private String pageNumber;

    @Parameter(
            description = "total results per page to filter applications",
            example = "5",
            schema =
            @Schema(
                    type = "string",
                    defaultValue = DEFAULT_RESULT_PER_PAGE,
                    allowableValues = {"5", "10", "15", "20", "50"}))
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_RESULT_PER_PAGE)
    private String resultPerPage;

    @Parameter(
            description = "total results per page to filter applications",
            example = "1",
            schema =
            @Schema(
                    type = "string",
                    defaultValue = DEFAULT_SORT_BY,
                    allowableValues = {LAST_MODIFIED_DATE, SUBMISSION_DATE, STATUS}))
    @Pattern(
            regexp = VALID_SORT_BY,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_SORT_BY)
    private String sortBy;

    @Parameter(
            description = "total results per page to filter applications",
            example = "1",
            schema =
            @Schema(
                    type = "string",
                    defaultValue = DEFAULT_SORT_ORDER,
                    allowableValues = {ASC, DESC}))
    @Pattern(
            regexp = VALID_SORT_ORDER,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_SORT_ORDER)
    private String sortOrder;

    @Pattern(
            regexp = ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MIN_TWO_MAX_OF_FIFTY_CHARACTERS,
            message = INVALID_APPLICANT_FIRST_NAME)
    private String applicantFirstName;

    @Pattern(
            regexp = ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MIN_TWO_MAX_OF_FIFTY_CHARACTERS,
            message = INVALID_APPLICANT_LAST_NAME)
    private String applicantLastName;

    @DOBDateConstraint private String applicantDob;

    @Pattern(
            regexp = VALIDATE_POST_CODE,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_PROPERTY_POST_CODE)
    private String propertyPostcode;

    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_USER_FIRST_NAME)
    private String userFirstName;

    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_USER_LAST_NAME)
    private String userLastName;

    @AdminEmailConstraint private String userEmailId;

    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_USER_FCA_NUMBER)
    private String userFirmFCANumber;

    @Pattern(
            regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS,
            message = INVALID_USER_PRINCIPAL_FCA_NUMBER)
    private String userPrincipalFCANumber;

    private String userRole;

    public BrokerValidationRequest toBrokerValidationRequest() {
        return BrokerValidationRequest.builder()
                .fcaNumber(fcaNumber)
                .brokerSurname(brokerLastName)
                .brokerPostcode(populatePostCodeWithSpace(brokerPostcode))
                .firmPostcode(populatePostCodeWithSpace(firmPostcode))
                .build();
    }

    public String constructSortByParam() {
        return sortBy + SPACE + sortOrder;
    }

    public String constructFromDate() {
        String specifiedDateRange = Optional.ofNullable(dateRange).orElse(LAST_WEEK);
        switch (specifiedDateRange) {
            case LAST_WEEK:
                return getSevenDaysBeforeCurrentDateInUnitedKingdom();

            case LAST_MONTH:
                return getDateMonthBeforeCurrentDateInUnitedKingdom();

            case LAST_THREE_MONTH:
                return getDateThreeMonthsBeforeCurrentDateInUnitedKingdom();

            case ALL:
                // return getDateSixMonthsBeforeCurrentDateInUnitedKingdom();
                return getDateYearBeforeCurrentDateInUnitedKingdom(); // TODO: just for testing,
            // later on it should return
            // date 6 months old only

            default:
                throw new InvalidDateRangeValueException(
                        "Invalid value for dateRange : " + dateRange);
        }
    }

    public BrokerDetailValidationRequest toBrokerDetailValidationRequest(boolean isAddBrokerUserName) {
        return BrokerDetailValidationRequest.builder()
                .fcaNumber(fcaNumber)
                .brokerSurname(brokerLastName)
                .brokerPostcode(populatePostCodeWithSpace(brokerPostcode))
                .brokerForeName(brokerFirstName)
                .brokerEmail(brokerEmailId)
                .brokerUsername(isAddBrokerUserName ? brokerUserName : null)
                .build();
    }
}
