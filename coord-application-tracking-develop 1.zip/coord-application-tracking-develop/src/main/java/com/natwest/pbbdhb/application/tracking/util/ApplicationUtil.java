/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static java.time.LocalDate.now;
import static java.time.format.DateTimeFormatter.ofPattern;
import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.application.tracking.controller.ApplicationTrackingController;
import com.natwest.pbbdhb.application.tracking.model.BrokerInformation;
import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.ApplicationDetailsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.CurrentOpenTasksNumber;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StageHistory;
import com.natwest.pbbdhb.application.tracking.service.GmsStageAndTaskLoader;
import com.opencsv.CSVReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.hateoas.Link;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
public class ApplicationUtil {

    private ApplicationUtil() {}

    public static boolean isValidDate(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return true;
        }
        DateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            return false;
        }
        return Pattern.compile(DATE_PATTERN).matcher(dateStr).matches();
    }

    public static String getSevenDaysBeforeCurrentDateInUnitedKingdom() {
        return getBeforeDate(7);
    }

    public static String getDateMonthBeforeCurrentDateInUnitedKingdom() {
        return getBeforeDate(30);
    }

    public static String getDateThreeMonthsBeforeCurrentDateInUnitedKingdom() {
        return getBeforeDate(90);
    }

    public static String getDateSixMonthsBeforeCurrentDateInUnitedKingdom() {
        return getBeforeDate(120);
    }

    public static String getDateYearBeforeCurrentDateInUnitedKingdom() {
        return getBeforeDate(365);
    }

    public static String getCurrentDateInUnitedKingdom() {
        return now(LONDON_ZONE).format(ofPattern(DATE_FORMAT));
    }

    private static String getBeforeDate(int days) {
        return now(LONDON_ZONE).minusDays(days).format(ofPattern(DATE_FORMAT));
    }

    public static void populatePathParams(
            UriComponentsBuilder builder, Map<String, Object> urlParams) {
        builder.uriVariables(urlParams);
    }

    public static void populateRequestParams(
            BrokerInformation brokerInformation, UriComponentsBuilder builder) {
        builder.replaceQueryParam(EMAIL_ID, brokerInformation.getEmailId())
                .replaceQueryParam(FIRST_NAME, brokerInformation.getFirstName())
                .replaceQueryParam(LAST_NAME, brokerInformation.getLastName())
                .replaceQueryParam(FCA_NUMBER, brokerInformation.getFcaNumber());
    }

    public static String mergeResponses(ObjectMapper mapper, String... responseList)
            throws IOException {
        ObjectNode mergedContent = mapper.createObjectNode();
        for (String response : responseList) {
            if (Objects.nonNull(mergedContent) && isNotBlank(response))
                mergedContent.setAll((ObjectNode) mapper.readTree(response));
        }
        log.debug("mergedContent :{}", mergedContent);
        return mapper.writeValueAsString(mergedContent);
    }

    public static void populateHATEOASLink(
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest,
            ApplicationDetailsResponse applicationDetailsResponse) {
        if (Objects.nonNull(applicationDetailsResponse)) {
            UriComponentsBuilder link =
                    linkTo(
                                    methodOn(ApplicationTrackingController.class)
                                            .getApplicationDetail(
                                                    null, referenceNumber, null, null))
                            .toUriComponentsBuilder();

            Optional.ofNullable(applicationDetailRequest)
                    .ifPresent(
                            request ->
                                    link.replaceQueryParam(
                                                    BROKER_EMAIL_ID, request.getBrokerEmailId())
                                            .replaceQueryParam(
                                                    BROKER_USER_NAME, request.getBrokerUserName())
                                            .replaceQueryParam(
                                                    BROKER_FIRST_NAME, request.getBrokerFirstName())
                                            .replaceQueryParam(
                                                    BROKER_LAST_NAME, request.getBrokerLastName())
                                            .replaceQueryParam(FCA_NUMBER, request.getFcaNumber())
                                            .replaceQueryParam(
                                                    FIRM_POSTCODE, request.getFirmPostcode())
                                            .replaceQueryParam(
                                                    BROKER_POSTCODE, request.getBrokerPostcode())
                                            .replaceQueryParam(
                                                    USER_FIRST_NAME, request.getUserFirstName())
                                            .replaceQueryParam(
                                                    USER_LAST_NAME, request.getUserLastName())
                                            .replaceQueryParam(USER_EMAIL, request.getUserEmailId())
                                            .replaceQueryParam(
                                                    USER_FIRM_FCA_NUMBER,
                                                    request.getUserFirmFCANumber())
                                            .replaceQueryParam(
                                                    USER_PRINCIPAL_FCA_NUMBER,
                                                    request.getUserPrincipalFCANumber())
                                            .replaceQueryParam(USER_ROLE, request.getUserRole()));

            applicationDetailsResponse.add(Link.of(link.build().toUriString()).withSelfRel());
        }
    }

    public static void populateGetApplicationDetailsURI(
            ApplicationsResponse applicationsResponse, ApplicationRequest applicationRequest) {
        if (CollectionUtils.isNotEmpty(applicationsResponse.getApplications())) {
            applicationsResponse
                    .getApplications()
                    .forEach(
                            application -> {
                                UriComponentsBuilder builderLink =
                                        linkTo(
                                                        methodOn(
                                                                        ApplicationTrackingController
                                                                                .class)
                                                                .getApplicationDetail(
                                                                        null,
                                                                        application
                                                                                .getReferenceNumber(),
                                                                        null,
                                                                        null))
                                                .toUriComponentsBuilder();

                                Optional.ofNullable(applicationRequest)
                                        .ifPresent(
                                                request ->
                                                        builderLink
                                                                .replaceQueryParam(
                                                                        BROKER_EMAIL_ID,
                                                                        request.getBrokerEmailId())
                                                                .replaceQueryParam(
                                                                        BROKER_USER_NAME,
                                                                        request
                                                                                .getBrokerUserName())
                                                                .replaceQueryParam(
                                                                        BROKER_FIRST_NAME,
                                                                        request
                                                                                .getBrokerFirstName())
                                                                .replaceQueryParam(
                                                                        BROKER_LAST_NAME,
                                                                        request.getBrokerLastName())
                                                                .replaceQueryParam(
                                                                        FCA_NUMBER,
                                                                        request.getFcaNumber())
                                                                .replaceQueryParam(
                                                                        FIRM_POSTCODE,
                                                                        request.getFirmPostcode())
                                                                .replaceQueryParam(
                                                                        BROKER_POSTCODE,
                                                                        request.getBrokerPostcode())
                                                                .replaceQueryParam(
                                                                        USER_FIRST_NAME,
                                                                        request.getUserFirstName())
                                                                .replaceQueryParam(
                                                                        USER_LAST_NAME,
                                                                        request.getUserLastName())
                                                                .replaceQueryParam(
                                                                        USER_EMAIL,
                                                                        request.getUserEmailId())
                                                                .replaceQueryParam(
                                                                        USER_FIRM_FCA_NUMBER,
                                                                        request
                                                                                .getUserFirmFCANumber())
                                                                .replaceQueryParam(
                                                                        USER_PRINCIPAL_FCA_NUMBER,
                                                                        request
                                                                                .getUserPrincipalFCANumber())
                                                                .replaceQueryParam(
                                                                        USER_ROLE,
                                                                        request.getUserRole()));

                                application.add(
                                        Link.of(builderLink.build().toUriString()).withSelfRel());
                            });
        }
    }
    
    
    
    public static void populateGetApplicationDetailsURI(
            ApplicationListResponse applicationListResponse, ApplicationListRequest applicationListRequest) {
        if (CollectionUtils.isNotEmpty(applicationListResponse.getApplications())) {
            applicationListResponse
                    .getApplications()
                    .forEach(
                            application -> {
                                UriComponentsBuilder builderLink =
                                        linkTo(
                                                        methodOn(
                                                                        ApplicationTrackingController
                                                                                .class)
                                                                .getApplicationDetail(
                                                                        null,
                                                                        application
                                                                                .getReferenceNumber(),
                                                                        null,
                                                                        null))
                                                .toUriComponentsBuilder();

                                Optional.ofNullable(applicationListRequest)
                                        .ifPresent(
                                                request ->
                                                        builderLink
                                                                .replaceQueryParam(
                                                                        BROKER_EMAIL_ID,
                                                                        request.getBrokerEmailId())
                                                                .replaceQueryParam(
                                                                        BROKER_USER_NAME,
                                                                        request
                                                                                .getBrokerUserName())
                                                                .replaceQueryParam(
                                                                        BROKER_FIRST_NAME,
                                                                        request
                                                                                .getBrokerFirstName())
                                                                .replaceQueryParam(
                                                                        BROKER_LAST_NAME,
                                                                        request.getBrokerLastName())
                                                                .replaceQueryParam(
                                                                        FCA_NUMBER,
                                                                        request.getFcaNumber())
                                                                .replaceQueryParam(
                                                                        FIRM_POSTCODE,
                                                                        request.getFirmPostcode())
                                                                .replaceQueryParam(
                                                                        BROKER_POSTCODE,
                                                                        request.getBrokerPostcode())
                                                                .replaceQueryParam(
                                                                        IS_ACTION_REQUIRED,
                                                                        request.getActionRequired())
                                                                .replaceQueryParam(
                                                                        USER_FIRST_NAME,
                                                                        request.getUserFirstName())
                                                                .replaceQueryParam(
                                                                        USER_LAST_NAME,
                                                                        request.getUserLastName())
                                                                .replaceQueryParam(
                                                                        USER_EMAIL,
                                                                        request.getUserEmailId())
                                                                .replaceQueryParam(
                                                                        USER_FIRM_FCA_NUMBER,
                                                                        request
                                                                                .getUserFirmFCANumber())
                                                                .replaceQueryParam(
                                                                        USER_PRINCIPAL_FCA_NUMBER,
                                                                        request
                                                                                .getUserPrincipalFCANumber())
                                                                .replaceQueryParam(
                                                                        USER_ROLE,
                                                                        request.getUserRole()));

                                application.add(
                                        Link.of(builderLink.build().toUriString()).withSelfRel());
                            });
        }
    }

    public static void initMap(File file, Map<String, String> m) throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                m.put(values[0], values[1]);
            }
        }
    }

    public static String getSubStatus(
            List<String> openTaskList, GmsStageAndTaskLoader stageTaskLoader, String stageNo) {
        if (Objects.isNull(stageNo)) {
            return null;
        }
        int assessTaskCount = 0;
        int awaitTaskCount = 0;
        for (String taskCode : openTaskList) {
            if (stageTaskLoader.isAwaitTask(taskCode)) {
                awaitTaskCount++;
            } else if (stageTaskLoader.isAssessTask(taskCode)) {
                assessTaskCount++;
            }
        }
        log.debug("awaitTaskCount= {}, assessTaskCount= {}", awaitTaskCount, assessTaskCount);

        if (awaitTaskCount > 0) {
            return ACTION_REQUIRED;
        }

        return assessTaskCount > 0 ? NO_ACTION_REQUIRED : COMPLETION;
    }

    public static String getStageNo(ApplicationDetailsInfo detailsInfo) {
        return detailsInfo.getApplicationDetails().getStageHistory().stream()
                .map(StageHistory::getCode)
                .findFirst()
                .orElse(null);
    }

    public static List<String> getOpenTaskList(ApplicationDetailsInfo detailsInfo) {
        return detailsInfo.getApplicationDetails().getCaseHistory().stream()
                .filter(task -> task.getClosedDateTime() == null)
                .map(CaseHistory::getCode)
                .collect(Collectors.toList());
    }

    public static String populatePostCodeWithSpace(String postCode) {
        if (!postCode.contains(SPACE)) {
            StringBuilder postCodeBuilder = new StringBuilder(postCode);
            postCodeBuilder.insert(postCodeBuilder.length() - 3, SPACE);
            return postCodeBuilder.toString();
        }
        return postCode;
    }

    public static List<String> constructTaskCodes(Set<CurrentOpenTasksNumber> openTasksNumbers) {
        if (Objects.isNull(openTasksNumbers) || openTasksNumbers.isEmpty()) {
            return new ArrayList<>();
        }

        return new ArrayList<>(openTasksNumbers)
                .stream().map(CurrentOpenTasksNumber::getTaskNumber).collect(Collectors.toList());
    }

    public static String computeRagStatus(String stageNo, int openTaskCount) {
        if (Objects.isNull(stageNo)) {
            return GREY;
        }
        if (!STAGE_92.equals(stageNo) && stageNo.compareTo("80") > 0) {
            return RED;
        }
        return (openTaskCount > 0) ? AMBER : GREEN;
    }

    /**
     * Method to get the rag status for product switch application
     *
     * @param currentStageNo - currentStageNo
     * @return rag status
     */
    public static String computeRagStatusForProductSwitchApplication(String currentStageNo) {
        if (Objects.isNull(currentStageNo) || currentStageNo.compareTo("40") < 0) {
            return GREY;
        } else if (currentStageNo.compareTo("80") > 0) {
            return RED;
        } else if ("80".equals(currentStageNo)) {
            return GREEN;
        } else {
            return AMBER;
        }
    }

    public static boolean isValidEmail(String email) {

        return Objects.isNull(email)
                || (Pattern.compile(EMAIL_PATTERN).matcher(email).matches()
                        && email.length() <= 320);
    }

    public static GMSStageDescription validate(
            GMSStageDescription stageDescription, String stageNo) {
        if (Objects.isNull(stageDescription) || Objects.isNull(stageDescription.getStatus())) {
            log.info("No GMS Stage found with stage no :{} ", stageNo);
            stageDescription = new GMSStageDescription();
        }
        return stageDescription;
    }

    public static Date getFormattedDate(Date date) throws ParseException {
        DateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYYMMDD);
        return formatter.parse(formatter.format(date));
    }

    /**
     * This method is to capitalize the string to follow the standard
     *
     * @param name - String to be capitalized
     * @return String value
     */
    public static String capitalizeName(String name) {
        if (StringUtils.isNotBlank(name)) {
            String capitalizedName = "";
            String splitNames[] = name.split("\\s");
            for (String word : splitNames) {
                capitalizedName += StringUtils.capitalize(StringUtils.lowerCase(word)) + " ";
            }
            return capitalizedName.trim();
        }
        return null;
    }
}
