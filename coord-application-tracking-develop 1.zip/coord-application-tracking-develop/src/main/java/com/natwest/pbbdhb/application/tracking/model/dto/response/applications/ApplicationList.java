/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.applications;

import java.io.Serializable;
import java.util.List;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class ApplicationList extends RepresentationModel<ApplicationList> implements Serializable{    

    private static final long serialVersionUID = -6980437632933650879L;

    private String referenceNumber;
    
    private String caseId;
    
    private boolean actionRequired;
    
    private List<Applicant> applicants;
    
    private Source sourceInfo;
}
