/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.applications;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UK_TIME_ZONE;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.NameCapitaliseSerializer;
import java.util.Date;
import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
public class ApplicantInformation {
    private String title;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String firstName;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String lastName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT, timezone = UK_TIME_ZONE)
    private Date dob;

    private String isMainApplicant;
}
