/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.validator;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.isValidEmail;

import com.natwest.pbbdhb.application.tracking.validator.format.AdminEmailConstraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AdminEmailFormatValidator
        implements ConstraintValidator<AdminEmailConstraint, String> {

    @Override
    public boolean isValid(String email, ConstraintValidatorContext constraintValidatorContext) {
        return isValidEmail(email);
    }
}
