/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class GranularTrackingDetail {
    @Schema(example = "Additional Borrowing")
    private String category;

    @Schema(example = "[\"Balance Amount and Declared Amount Differs\"]")
    private List<String> purpose;

    @Schema(example = "[\"Missing information\"]")
    private List<String> reRequestReason;

    private List<DocumentRequiredFor> requiredFor;

    @Schema(example = "2023-01-01")
    private String fromDate;

    @Schema(example = "2023-01-01")
    private String toDate;

    @Schema(example = "3 months")
    private String timePeriod;

    @Schema(example = "2023-01-01")
    private String dueDate;
}
