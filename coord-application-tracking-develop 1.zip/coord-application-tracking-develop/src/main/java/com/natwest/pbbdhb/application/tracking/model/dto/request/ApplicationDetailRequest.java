/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.request;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.populatePostCodeWithSpace;

import com.natwest.pbbdhb.application.tracking.model.BrokerInformation;
import com.natwest.pbbdhb.application.tracking.validator.format.AdminEmailConstraint;
import com.natwest.pbbdhb.application.tracking.validator.format.EmailFormat;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@Schema(description = "Application Detail Request Object")
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class ApplicationDetailRequest {

    @Parameter(required = true)
    @NotNull(message = INVALID_FCA_NUMBER)
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_FCA_NUMBER)
    private String fcaNumber;

    @Parameter(required = true)
    @NotNull(message = INVALID_FIRM_POST_CODE)
    @Pattern(
            regexp = VALIDATE_POST_CODE,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_FIRM_POST_CODE)
    private String firmPostcode;

    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_AND_ATLEAST_TWO_AND_MAX_HUNDRED_CHARACTERS,
            message = INVALID_BROKER_USER_NAME)
    private String brokerUserName;

    @Parameter(required = true)
    @NotNull(message = INVALID_BROKER_FIRST_NAME)
    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_BROKER_FIRST_NAME)
    private String brokerFirstName;

    @Parameter(required = true)
    @NotNull(message = INVALID_BROKER_LAST_NAME)
    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_BROKER_LAST_NAME)
    private String brokerLastName;

    @Parameter(required = true)
    @NotNull(message = INVALID_EMAIL_ID)
    @EmailFormat
    private String brokerEmailId;

    @Parameter(required = true)
    @NotNull(message = INVALID_BROKER_POST_CODE)
    @Pattern(
            regexp = VALIDATE_POST_CODE,
            flags = Pattern.Flag.CASE_INSENSITIVE,
            message = INVALID_BROKER_POST_CODE)
    private String brokerPostcode;

    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_USER_FIRST_NAME)
    private String userFirstName;

    @Pattern(
            regexp = ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR,
            message = INVALID_USER_LAST_NAME)
    private String userLastName;

    @AdminEmailConstraint private String userEmailId;

    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_USER_FCA_NUMBER)
    private String userFirmFCANumber;

    @Pattern(
            regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS,
            message = INVALID_USER_PRINCIPAL_FCA_NUMBER)
    private String userPrincipalFCANumber;

    private String userRole;

    public BrokerValidationRequest toBrokerValidationRequest() {
        return BrokerValidationRequest.builder()
                .fcaNumber(fcaNumber)
                .brokerSurname(brokerLastName)
                .brokerPostcode(populatePostCodeWithSpace(brokerPostcode))
                .firmPostcode(populatePostCodeWithSpace(firmPostcode))
                .build();
    }

    public BrokerInformation toBrokerInformation() {
        return BrokerInformation.builder()
                .fcaNumber(fcaNumber)
                .emailId(brokerEmailId)
                .firstName(brokerFirstName)
                .lastName(brokerLastName)
                .build();
    }

    public BrokerDetailValidationRequest toBrokerDetailValidationRequest(boolean isAddBrokerUserName) {
        return BrokerDetailValidationRequest.builder()
                .fcaNumber(fcaNumber)
                .brokerSurname(brokerLastName)
                .brokerPostcode(populatePostCodeWithSpace(brokerPostcode))
                .brokerForeName(brokerFirstName)
                .brokerEmail(brokerEmailId)
                .brokerUsername(isAddBrokerUserName ? brokerUserName : null)
                .build();
    }
}
