/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.applications;

import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.PageDetail;

import java.io.Serializable;
import java.util.List;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class ApplicationListAPIResponse extends RepresentationModel<Application> implements Serializable{    
    
    private static final long serialVersionUID = -7011897881493774251L;

    private PageDetail page;
    
    private List<ApplicationList> applications;
}
