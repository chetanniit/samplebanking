/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerDetailValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerDetailValidationResponse;

/** This class has method to validate the broker */
public interface BrokerDetailValidationService {

    BrokerDetailValidationResponse validateBroker(
            BrokerDetailValidationRequest brokerDetailValidationRequest);
}
