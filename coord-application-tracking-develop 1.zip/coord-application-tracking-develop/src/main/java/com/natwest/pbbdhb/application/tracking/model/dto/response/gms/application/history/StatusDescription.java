/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history;

import static org.apache.logging.log4j.util.Strings.isBlank;

public enum StatusDescription {
    A("Funds Returned After Completion"),
    B("Funds Returned Before Completion"),
    C("Completed"),
    D("Declined"),
    L("Live"),
    P("Application"),
    R("Refused"),
    F("Refused Illustration"),
    T("Declined Illustration"),
    I("Illustration");

    StatusDescription(String description) {
        this.description = description;
    }

    public static String getDescription(String status) {
        if (status == null || isBlank(status)) {
            return null;
        }

        try {
            return StatusDescription.valueOf(status.toUpperCase()).description;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private final String description;
}
