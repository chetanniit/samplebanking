/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class SwaggerConfiguration {

    private final String environment;

    private final BuildProperties buildProperties;

    private final String jwtKey;

    private final boolean isSwaggerAuthEnabled;

    public SwaggerConfiguration(
            @Value("${hbo.env:dev}") String environment,
            @Autowired(required = false) BuildProperties buildProperties,
            @Value("${des.transport.iam.jwt-chain.jwt-key:iam-claimsetjwt}") String jwtKey,
            @Value("${swagger.authorize.enable:false}") boolean isSwaggerAuthEnabled) {
        this.environment = environment;
        this.buildProperties = buildProperties;
        this.jwtKey = jwtKey;
        this.isSwaggerAuthEnabled = isSwaggerAuthEnabled;
        if (null == buildProperties) {
            log.error("buildProperties are missing. check the build");
        }
    }

    @Bean
    public OpenAPI springOpenAPI() {
        String api = "https://" + environment + ".bankofapis.com";
        if ("prd".equalsIgnoreCase(environment)) {
            api = "https://banksofapis.com";
        }
        OpenAPI openAPI =
                new OpenAPI()
                        .info(
                                new Info()
                                        .title("Mortgage Application Tracking")
                                        .description("API for Mortgage Application Tracking")
                                        .version(
                                                null == buildProperties
                                                        ? "v1"
                                                        : buildProperties.getVersion())
                                        .license(
                                                new License()
                                                        .name("Natwest Group")
                                                        .url(api + "/terms-and-conditions")))
                        .externalDocs(
                                new ExternalDocumentation()
                                        .description("Mortgage Application Tracking Documentation")
                                        .url(
                                                api
                                                        + "/products/mortgage/mortgage-application-tracking/"));
        addSecurityScheme(openAPI);
        return openAPI;
    }

    private void addSecurityScheme(OpenAPI openAPI) {
        if (isSwaggerAuthEnabled) {
            String jwtToken = "JWT token";
            openAPI.addSecurityItem(new SecurityRequirement().addList(jwtToken))
                    .components(
                            new Components()
                                    .addSecuritySchemes(
                                            jwtToken,
                                            new SecurityScheme()
                                                    .type(SecurityScheme.Type.APIKEY)
                                                    .in(SecurityScheme.In.HEADER)
                                                    .name(jwtKey)));
        }
    }
}
