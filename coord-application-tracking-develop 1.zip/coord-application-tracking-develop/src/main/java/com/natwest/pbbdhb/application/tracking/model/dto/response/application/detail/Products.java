/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail;

import java.math.BigDecimal;
import lombok.*;

/** this class containing Products information used in applicationInformation endPoint */
@Setter
@Getter
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Builder
public class Products {
    private String code;
    private String desc;
    private String altDesc;
    private BigDecimal rate;
    private String termYears;
    private String termMonths;
    private BigDecimal repaymentAmount;
    private BigDecimal loanAmount;
    private String repaymentType;
}
