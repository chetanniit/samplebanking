package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.DateSerializer;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.DocumentRequiredFor;
import lombok.*;

import java.time.ZonedDateTime;
import java.util.List;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UTC_TIME_ZONE;


/**
 * Object to map granular tracking detail from packaging manager
 */
@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class GranularTracking {
    private String state;
    private String description;
    private String category;
    private List<String> purpose;
    private List<String> reRequestReason;
    private List<DocumentRequiredFor> requiredFor;
    private String fromDate;
    private String toDate;
    private String count;
    private String frequency;
    private String dueDate;
    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime requestedDate;
    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime updatedDate;
    private String gmsStageNumber;
    private String gmsCategory;
}
