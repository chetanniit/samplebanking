package com.rbs.pbbdhb.coordinator.email.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.email.model.EmailRequest;

public interface SendEmailService {
	ResponseEntity<String> sendEmail(EmailRequest emailRequest, String brand);
}