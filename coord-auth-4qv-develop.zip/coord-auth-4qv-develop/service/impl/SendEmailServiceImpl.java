package com.rbs.pbbdhb.coordinator.email.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.coordinator.email.service.SendEmailService;
import com.rbs.pbbdhb.email.model.EmailRequest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * SendEmailServiceImpl class
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class SendEmailServiceImpl implements SendEmailService {

	@Autowired
	private RestService restService;

	@Value("${communication.email.base.url}")
	private String emailBaseUrl;

	@Value("${email.send.path}")
	private String emailPath;
	
	@Override
	public ResponseEntity<String> sendEmail(EmailRequest emailRequest,String brand) {
		String url = StringUtils.join(emailBaseUrl, emailPath);
		final ResponseEntity<String> response = sendEmailService(url, createRequestEntity(emailRequest,brand), String.class);
		return response;
	}

	private HttpEntity<EmailRequest> createRequestEntity(EmailRequest emailRequest, String brand) {
		final HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, Constants.CONTENT_TYPE_APPLICATION_JSON);
		headers.add(Constants.BRAND, brand);
		return new HttpEntity<>(emailRequest, headers);
	}

	private <T> ResponseEntity<T> sendEmailService(String url, HttpEntity<?> requestEntity, Class<T> responseType) {
		ResponseEntity<T> exchange = null;
		try {
			exchange = restService.exchange(url, HttpMethod.POST, requestEntity, responseType);
			if (HttpStatus.OK.equals(exchange.getStatusCode())) {
				return exchange;
			} else {
				log.error("Rest call failed for Url: " + url);
			}
		} catch (HttpClientErrorException cex) {
			log.error("Rest call failed for Url: " + url);
			log.error("HttpClientErrorException occurred in sendEmail", cex);
			return new ResponseEntity<>(cex.getStatusCode());
		} catch (HttpStatusCodeException sx) {
			log.error("Rest call failed for Url: " + url);
			log.error("HttpStatusCodeException occurred in sendEmail", sx);
			return new ResponseEntity<>(sx.getStatusCode());
		} catch (RestClientException ex) {
			log.error("Rest call failed for Url: " + url);
			log.error("RestClientException occurred in sendEmail", ex);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("Rest call failed for Url: " + url);
			log.error("Rest call failed with exception: "+e);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

}
