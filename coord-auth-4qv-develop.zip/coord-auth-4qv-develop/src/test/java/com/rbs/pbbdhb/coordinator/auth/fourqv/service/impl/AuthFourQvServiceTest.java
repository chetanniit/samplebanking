package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import static com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants.CST;
import static org.mockito.Mockito.times;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.error.BaseResponse;
import com.rbs.pbbdhb.exception.BusinessException;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@RunWith(MockitoJUnitRunner.class)
public class AuthFourQvServiceTest {

	@Mock
	private RestService restService;

	@Mock
	private ExceptionHelper exceptionHelper;

	@InjectMocks
	private AuthFourQvServiceImpl hlpAuthFourQvService;

	@SpyBean
	private Integer maxFaliedLoginAttempts;

	@Captor
	ArgumentCaptor<BaseResponse> BaseResponseCaptor;
	
	@Mock
	private JourneyMapper journeyMapper;

	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);
		maxFaliedLoginAttempts = 5;
		ReflectionTestUtils.setField(hlpAuthFourQvService, "restService", restService);
		ReflectionTestUtils.setField(hlpAuthFourQvService, "maxFaliedLoginAttempts", maxFaliedLoginAttempts);
		ReflectionTestUtils.setField(hlpAuthFourQvService, "exceptionHelper", exceptionHelper);

	}

	@Test
	public void getAccountLoginDetailsSuccess() {

		AccountLoginDetailsResponse response = new AccountLoginDetailsResponse();
		response.setAccountNumber("12345678");
		response.setChannel("broker");
		response.setFailedAttempts(1);
		response.setJourney("acquisition");

		ResponseEntity<AccountLoginDetailsResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(AccountLoginDetailsResponse.class))).thenReturn(responseEntity);
		AccountLoginDetailsResponse accountLoginDetailsResponse = hlpAuthFourQvService
				.getAccountLoginDetails(response.getChannel(), response.getAccountNumber());
		Assertions.assertEquals("12345678", accountLoginDetailsResponse.getAccountNumber());
		Assertions.assertEquals("broker", accountLoginDetailsResponse.getChannel());
		Assertions.assertEquals("acquisition", accountLoginDetailsResponse.getJourney());
		Assertions.assertEquals(1, accountLoginDetailsResponse.getFailedAttempts());
	}

	@Test
	public void getAccountLoginDetailsReturnNull() {

		AccountLoginDetailsResponse response = new AccountLoginDetailsResponse();
		ResponseEntity<AccountLoginDetailsResponse> responseEntity = new ResponseEntity<>(response,
				HttpStatus.NOT_FOUND);
		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(AccountLoginDetailsResponse.class))).thenReturn(responseEntity);
		AccountLoginDetailsResponse accountLoginDetailsResponse = hlpAuthFourQvService
				.getAccountLoginDetails(response.getChannel(), response.getAccountNumber());
		Assertions.assertEquals(null, accountLoginDetailsResponse.getAccountNumber());

	}

	@Test
	public void createAccountLoginDetailsisSuccessful() {
		AccountLoginDetailsRequest request = AccountLoginDetailsRequest.builder().accountNumber("12345678")
				.channel("broker").status(Constants.ACTIVE).failedAttempts(1).journey(Constants.JOURNEY_ACQUISITION)
				.build();

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<>(HttpStatus.CREATED);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity);

		hlpAuthFourQvService.createAccountLoginDetails(request.getChannel(), request.getAccountNumber(), true);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));
		Mockito.verify(exceptionHelper, times(0)).throwException(Mockito.eq(Exceptions.BUSINESS_EXCEPTION),
				Mockito.eq(HttpStatus.CREATED.value()), Mockito.eq("internal.server.error"));

	}
	
	@Test
	public void createAccountLoginDetailsisSuccessful_msst() {

		AccountLoginDetailsRequest request = AccountLoginDetailsRequest.builder().accountNumber("12345678")
				.channel("broker").status(Constants.ACTIVE).failedAttempts(1).journey(Constants.JOURNEY_ACQUISITION)
				.build();

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<>(HttpStatus.CREATED);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity);

		hlpAuthFourQvService.createAccountLoginDetails(request.getChannel(), request.getAccountNumber(), true);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));
		Mockito.verify(exceptionHelper, times(0)).throwException(Mockito.eq(Exceptions.BUSINESS_EXCEPTION),
				Mockito.eq(HttpStatus.CREATED.value()), Mockito.eq("internal.server.error"));

	}

	@Test
	public void createAccountLoginDetailsisSuccessful_cst() {

		AccountLoginDetailsRequest request = AccountLoginDetailsRequest.builder().accountNumber("12345678")
				.channel("broker").status(Constants.ACTIVE).failedAttempts(1).journey(CST)
				.build();

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<>(HttpStatus.CREATED);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity);

		hlpAuthFourQvService.createAccountLoginDetails(request.getChannel(), request.getAccountNumber(), true);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));
		Mockito.verify(exceptionHelper, times(0)).throwException(Mockito.eq(Exceptions.BUSINESS_EXCEPTION),
				Mockito.eq(HttpStatus.CREATED.value()), Mockito.eq("internal.server.error"));

	}



	@Test
	public void createAccountLoginDetailsisLoginBadRequest() {
		AccountLoginDetailsRequest request = AccountLoginDetailsRequest.builder().accountNumber("1234567")
				.channel("broker").status(Constants.ACTIVE).failedAttempts(1).journey(Constants.JOURNEY_ACQUISITION)
				.build();

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<?>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity);

		hlpAuthFourQvService.createAccountLoginDetails(request.getChannel(), request.getAccountNumber(), true);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void createAccountLoginDetailsThrowException() {
		AccountLoginDetailsRequest request = AccountLoginDetailsRequest.builder().accountNumber("1234567")
				.channel("broker").journey(Constants.JOURNEY_ACQUISITION).build();

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<?>>any(),
				Mockito.eq(BaseResponse.class))).thenThrow(BusinessException.class);
		Assertions.assertThrows(BusinessException.class, () -> {
			hlpAuthFourQvService.createAccountLoginDetails(request.getChannel(), request.getAccountNumber(), false);
		});
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void incrementLockCountLessThanFive() throws Exception {
		int currentFailledAttempt = 3;
		String accountNumber = "12345678";
		String channel = "broker";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);
		hlpAuthFourQvService.incrementLockCount(currentFailledAttempt, accountNumber, channel);

		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void incrementLockCountEqualsFive() throws Exception {
		int currentFailledAttempt = 4;
		String accountNumber = "12345678";
		String channel = "broker";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.incrementLockCount(currentFailledAttempt, accountNumber, channel);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void resetLockForFailedAttemptTest() throws Exception {
		String accountNumber = "12345678";
		String channel = "broker";
		String status = "ACTIVE";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.resetLockForFailedAttempt(accountNumber, channel, status);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void resetLockForSuccessFulLoginTest() throws Exception {
		String accountNumber = "12345678";
		String channel = "broker";
		String status = "ACTIVE";
		
		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.resetLockForSuccessfulLogin(accountNumber, channel, status);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void resetLockForFailedAttemptTest1() throws Exception {
		String accountNumber = "12345678";
		String channel = "broker";
		String status = "LOCKED";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.resetLockForFailedAttempt(accountNumber, channel, status);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void resetLockForSuccessFulLoginTest1() throws Exception {
		String accountNumber = "12345678";
		String channel = "broker";
		String status = "LOCKED";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.resetLockForSuccessfulLogin(accountNumber, channel, status);
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}
	
	@Test
	public void restFailedAttemptsAfter90Days_msst() throws Exception {
		String accountNumber = "12345678";
		String channel = "broker";
		String status = "ACTIVE";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.resetFailedAttemptsAfter90Days(accountNumber, channel, status);
		
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}

	@Test
	public void restFailedAttemptsAfter90Days_msst_locked() throws Exception {
		String accountNumber = "12345678";
		String channel = "broker";
		String status = "LOCKED";

		ResponseEntity<BaseResponse> responseEntity = new ResponseEntity<BaseResponse>(HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT), Mockito.<HttpEntity<String>>any(),
				Mockito.eq(BaseResponse.class))).thenReturn(responseEntity).thenReturn(responseEntity);

		hlpAuthFourQvService.resetFailedAttemptsAfter90Days(accountNumber, channel, status);
		
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.PUT),
				Mockito.<HttpEntity<String>>any(), Mockito.eq(BaseResponse.class));

	}
}