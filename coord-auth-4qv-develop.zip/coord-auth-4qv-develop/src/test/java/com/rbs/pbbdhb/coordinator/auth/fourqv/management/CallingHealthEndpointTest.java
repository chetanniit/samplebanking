package com.rbs.pbbdhb.coordinator.auth.fourqv.management;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.rbs.pbbdhb.coordinator.auth.fourqv.BaseCoordAuth4qvApplicationTest;

public class CallingHealthEndpointTest extends BaseCoordAuth4qvApplicationTest {

  private static final String MANAGEMENT_HEALTH_PATH = MANAGEMENT_PATH + "/health";

  @BeforeAll
  public void setUp() {
    response = getRequestSpecification().get(MANAGEMENT_HEALTH_PATH).then().extract().response();
  }

  @Test
  public void should_return_http_200() {
    assertThat(response.statusCode()).isEqualTo(OK.value());
  }

  @Test
  public void should_return_overall_status_as_UP() {
    assertThat(response.path("status").toString()).isEqualTo("UP");
  }
}
