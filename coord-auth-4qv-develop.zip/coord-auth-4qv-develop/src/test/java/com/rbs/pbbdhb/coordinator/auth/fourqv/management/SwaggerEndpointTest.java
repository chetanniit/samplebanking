package com.rbs.pbbdhb.coordinator.auth.fourqv.management;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.rbs.pbbdhb.coordinator.auth.fourqv.BaseCoordAuth4qvApplicationTest;

public class SwaggerEndpointTest extends BaseCoordAuth4qvApplicationTest {

	private static final String SWAGGER_ENDPOINT = BASE_PATH + "swagger-ui/index.html";

	@BeforeAll
	public void setUp() {
		response = getRequestSpecification().get(SWAGGER_ENDPOINT).then().extract().response();
	}

	@Test
	public void should_return_http_200() {
		assertThat(response.statusCode()).isEqualTo(OK.value());
	}
}
