package com.rbs.pbbdhb.coordinator.auth.fourqv.util;

import static org.junit.Assert.assertEquals;

import java.time.Clock;
import java.time.OffsetDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class DateUtilTest {

	@Test
	public void validateCurrentDateTime() {
		OffsetDateTime offsetDateTime = OffsetDateTime.now(Clock.systemUTC());
		assertEquals(offsetDateTime.getHour(), DateUtil.getUtcCurrentOffsetDateTime().getHour());

	}

}
