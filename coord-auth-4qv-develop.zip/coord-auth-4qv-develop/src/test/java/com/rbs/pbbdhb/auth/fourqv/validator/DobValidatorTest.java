package com.rbs.pbbdhb.auth.fourqv.validator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.DoBValidator;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.exception.BusinessException;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@RunWith(MockitoJUnitRunner.class)
public class DobValidatorTest {

	@InjectMocks
	DoBValidator dobValidator;

	@Mock
	ExceptionHelper exceptionHelper;

	String accountNumber;
	String postcode;
	String surname;
	String dob;
	AuthenticationRequest authenticationRequest;
	CustomerDetails customer1;
	List<String> reasons;
	List<CustomerDetails> borrowers;

	@Before
	public void setUp() throws Exception {
		accountNumber = "12345678";
		postcode = "AB1 2CD";
		surname = "surname";
		dob = "11-04-1995";
		authenticationRequest = AuthenticationRequest.builder().accountNumber(accountNumber).postcode(postcode)
				.surname(surname).dob(dob).build();

		borrowers = new ArrayList<>();
		customer1 = new CustomerDetails();
		customer1.setDob("1995-04-11 00:00:00");
		customer1.setPostCode(postcode);
		customer1.setSurname(surname);
		borrowers.add(customer1);
		CustomerDetails customer2 = new CustomerDetails();
		customer2.setClientId("876254321");
		customer2.setDob("2002-10-04 00:00:00");
		customer2.setPostCode("XY2 4XD");
		customer2.setSurname("Brown");
		borrowers.add(customer2);

		reasons = new ArrayList<String>();
		
		ReflectionTestUtils.setField(dobValidator, "ercDatePattern", "dd-MM-yyyy");

	}

	@Test
	public void validateDOBTest() {
		authenticationRequest.setDob("1995/12/03");

		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), "date.parse.exception");

		assertThrows(BusinessException.class,
				() -> dobValidator.validateDOB(authenticationRequest, borrowers, reasons));
	}

	@Test
	public void validateDOBNotMatchingTest() {
		authenticationRequest.setDob("03-12-1995");
		dobValidator.validateDOB(authenticationRequest, borrowers, reasons);

		assertEquals(1, reasons.size());
	}

	@Test
	public void getConvertedDateParseTest() {
		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), "date.parse.exception");

		assertThrows(BusinessException.class, () -> dobValidator.getConvertedDate("1995/12/03"));
	}

	@Test
	public void validateDOBMatchingTest() {
		dobValidator.validateDOB(authenticationRequest, borrowers, reasons);
		assertEquals(0, reasons.size());
	}

	@Test
	public void parse4QVDobExceptionTest() {

		borrowers.get(0).setDob("03/12/1995");

		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), "date.parse.exception");

		assertThrows(BusinessException.class,
				() -> dobValidator.validateDOB(authenticationRequest, borrowers, reasons));
	}

}
