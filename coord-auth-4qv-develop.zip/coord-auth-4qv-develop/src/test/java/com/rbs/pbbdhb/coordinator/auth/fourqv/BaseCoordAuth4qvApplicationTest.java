package com.rbs.pbbdhb.coordinator.auth.fourqv;

import static io.restassured.RestAssured.given;
import static io.restassured.http.ContentType.JSON;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.TestInstance;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest(
        webEnvironment = RANDOM_PORT,
        properties = {
                "resttemplate.jwtchain.disable=true",
                "des.tomcat.valves.user-principal-context-valves=",
        })
@TestInstance(PER_CLASS)
@TestPropertySource(locations = "classpath:application-test.properties")
public class BaseCoordAuth4qvApplicationTest {
    protected static final String BASE_PATH = "/mortgages/v1/coord-auth-4qv/";
    protected static final String MANAGEMENT_PATH = BASE_PATH + "actuator";

    @LocalServerPort
    private int port;

    protected Response response;

    protected RequestSpecification getRequestSpecification() {
        return given().accept(JSON).contentType(JSON).when().port(port);
    }
}
