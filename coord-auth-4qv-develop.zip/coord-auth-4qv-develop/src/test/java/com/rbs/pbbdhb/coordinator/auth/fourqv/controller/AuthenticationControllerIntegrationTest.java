package com.rbs.pbbdhb.coordinator.auth.fourqv.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Clock;
import java.time.OffsetDateTime;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.MssCustomerDetails;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.FourQvValidationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.AuthFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.GmsFourQvService;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc

@TestPropertySource(locations = "classpath:application-test.properties")

public class AuthenticationControllerIntegrationTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	AuthFourQvService authFourQvService;

	@MockBean
	GmsFourQvService gmsFourQvService;

	HttpHeaders httpHeaders;

	@Before
	public void setup() {

		httpHeaders = new HttpHeaders();
		httpHeaders.add("brand", "nwb");
		httpHeaders.add("channel", "broker");
		httpHeaders.add("journey", "");
		MockitoAnnotations.initMocks(this);
	
	}

	@After
	public void tearDown() {
		httpHeaders = null;
	
	}

	@Test
	public void authenticate_fourqv_400_accountNumber_null() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setAccountNumber(null);

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorMessage").value("Account number is required"));
	}

	@Test
	public void authenticate_fourqv_400_accountNumber_incorrectFormat() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setAccountNumber("1212");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorMessage").value("Account number should be 8 digit"));
	}

	@Test
	public void authenticate_fourqv_400_Surname_null() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setSurname(null);

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("surname is required"));
	}

	@Test
	public void authenticate_fourqv_400_Surname_Blank() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setSurname("    ");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("surname is required"));
	}

	@Test
	public void authenticate_fourqv_400_response() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();

		AuthenticationRequest.setAccountNumber(null);
		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).

				content(json).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	@Test
	public void authenticate_fourqv_400_postcode_null() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setPostcode(null);

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("postcode is required"));
	}

	@Test
	public void authenticate_fourqv_400_postcode_invalid() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setPostcode("XX9XX$%");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("Please enter valid post code"));
	}

	@Test
	public void authenticate_fourqv_200_postcode_valid() throws JsonProcessingException, Exception {
		
		String channel = "broker";
		AuthenticationRequest authenticationRequest = getAuthenticationRequest();
		authenticationRequest.setPostcode("XX99 9XX");
		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(0);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(authFourQvService.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(authenticationRequest.getAccountNumber()))).thenReturn(null);
		Mockito.when(gmsFourQvService.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(authenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void authenticate_fourqv_400_dob_formatIncorrect() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();

		AuthenticationRequest.setDob("2012-12-12");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorMessage").value("Date of birth should be in dd-MM-yyyy format"));
	}

	@Test
	public void authenticate_fourqv_200() throws JsonProcessingException, Exception {
		
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(0);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(
				authFourQvService.getAccountLoginDetails(Mockito.eq(channel), Mockito.eq(request.getAccountNumber())))
				.thenReturn(null);
		Mockito.when(gmsFourQvService.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void authenticate_fourqv_401() throws JsonProcessingException, Exception {
		
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(0);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);

		Mockito.when(
				authFourQvService.getAccountLoginDetails(Mockito.eq(channel), Mockito.eq(request.getAccountNumber())))
				.thenReturn(null);
		Mockito.when(gmsFourQvService.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnauthorized());

	}

	@Test
	public void authenticate_fourqv_423() throws JsonProcessingException, Exception {
	
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(1);
		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(
				authFourQvService.getAccountLoginDetails(Mockito.eq(channel), Mockito.eq(request.getAccountNumber())))
				.thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvService.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(request);
		
		
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isLocked());

	}

	private AuthenticationRequest getAuthenticationRequest() {
		return AuthenticationRequest.builder().accountNumber("40036696").dob("01-01-1987").surname("Smith")
				.postcode("EH14 1UH").build();

	}
	
	@Test
	public void authenticate_fourqv_400_accountNumber_null_msst() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setAccountNumber(null);
		
		httpHeaders.add("journey", "msst");
	
		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorMessage").value("Account number is required"));
	}

	@Test
	public void authenticate_fourqv_400_accountNumber_incorrectFormat_msst() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setAccountNumber("1212");
		
		httpHeaders.add("journey", "msst");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorMessage").value("Account number should be 8 digit"));
	}

	@Test
	public void authenticate_fourqv_400_Surname_null_msst() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setSurname(null);

		httpHeaders.add("journey", "msst");
		
		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("surname is required"));
	}

	@Test
	public void authenticate_fourqv_400_Surname_Blank_msst() throws JsonProcessingException, Exception {

		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setSurname("    ");

		httpHeaders.add("journey", "msst");
		
		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("surname is required"));
	}

	@Test
	public void authenticate_fourqv_400_response_msst() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();

		httpHeaders.add("journey", "msst");
		
		AuthenticationRequest.setAccountNumber(null);
		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).

				content(json).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	@Test
	public void authenticate_fourqv_400_postcode_null_msst() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setPostcode(null);

		httpHeaders.add("journey", "msst");
		
		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("postcode is required"));
	}

	@Test
	public void authenticate_fourqv_400_postcode_invalid_msst() throws JsonProcessingException, Exception {
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();
		AuthenticationRequest.setPostcode("XX9XX$%");
		
		httpHeaders.add("journey", "msst");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorMessage").value("Please enter valid post code"));
	}

	@Test
	public void authenticate_fourqv_200_postcode_valid_msst() throws JsonProcessingException, Exception {
	
		String channel = "broker";
		AuthenticationRequest authenticationRequest = getAuthenticationRequest();
		authenticationRequest.setPostcode("XX99 9XX");
		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(0);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		
		httpHeaders.set("journey", "msst");

		Mockito.when(authFourQvService.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(authenticationRequest.getAccountNumber()))).thenReturn(null);
		Mockito.when(gmsFourQvService.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(authenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void authenticate_fourqv_400_dob_formatIncorrect_msst() throws JsonProcessingException, Exception {
		
		
		AuthenticationRequest AuthenticationRequest = getAuthenticationRequest();

		AuthenticationRequest.setDob("2012-12-12");
		
		httpHeaders.add("journey", "msst");

		String json = new ObjectMapper().writeValueAsString(AuthenticationRequest);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorMessage").value("Date of birth should be in dd-MM-yyyy format"));
	}

	@Test
	public void authenticate_fourqv_200_msst() throws JsonProcessingException, Exception {
		
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();
		
		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(0);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		httpHeaders.set("journey", "msst");
		
		Mockito.when(
				authFourQvService.getAccountLoginDetails(Mockito.eq(channel), Mockito.eq(request.getAccountNumber())))
				.thenReturn(null);
		Mockito.when(gmsFourQvService.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void authenticate_fourqv_401_msst() throws JsonProcessingException, Exception {
	
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(0);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);

		httpHeaders.set("journey", "msst");
		
		Mockito.when(
				authFourQvService.getAccountLoginDetails(Mockito.eq(channel), Mockito.eq(request.getAccountNumber())))
				.thenReturn(null);
		Mockito.when(gmsFourQvService.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnauthorized());

	}

	@Test
	public void authenticate_fourqv_423_msst() throws JsonProcessingException, Exception {
		
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(1);
		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		httpHeaders.set("journey", "msst");
		
		Mockito.when(
				authFourQvService.getAccountLoginDetails(Mockito.eq(channel), Mockito.eq(request.getAccountNumber())))
				.thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvService.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/authenticate").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isLocked());

	}

	@Test
	public void customers_fourqv_200() throws JsonProcessingException, Exception {
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		MssCustomerDetails customer = new MssCustomerDetails();
		customer.setCin("2468101214");
		customer.setDob("01-01-1972");
		customer.setPostCode("SWSERA");
		customer.setSurName("Xxxxx");

		Mockito.when(gmsFourQvService.getCustomer(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(new ResponseEntity<>(customer, HttpStatus.OK));

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/customers").headers(httpHeaders).content(json)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void customers_fourqv_404() throws JsonProcessingException, Exception {
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("XX99 9XX").build();

		MssCustomerDetails customer = new MssCustomerDetails();
		customer.setCin("2468101214");
		customer.setDob("01-01-1972");
		customer.setPostCode("SWSERA");
		customer.setSurName("Xxxxx");

		Mockito.when(gmsFourQvService.getCustomer(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(new ResponseEntity<>(customer, HttpStatus.NOT_FOUND));

		String json = new ObjectMapper().writeValueAsString(request);
		mockMvc.perform(MockMvcRequestBuilders.post("/customers").headers(httpHeaders).content(json)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound());

	}
}
