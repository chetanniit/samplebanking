package com.rbs.pbbdhb.auth.fourqv.validator;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.PostcodeValidator;

@RunWith(MockitoJUnitRunner.class)
public class PostcodeValidatorTest {

	@InjectMocks
	PostcodeValidator postcodeValidator;

	String accountNumber;
	String postcode;
	String surname;
	String dob;
	AuthenticationRequest authenticationRequest;
	CustomerDetails customer1;
	List<String> reasons;
	List<CustomerDetails> borrowers;

	@Before
	public void setUp() throws Exception {
		accountNumber = "12345678";
		postcode = "AB1 2CD";
		surname = "surname";
		dob = "11-04-1995";
		authenticationRequest = AuthenticationRequest.builder().accountNumber(accountNumber).postcode(postcode)
				.surname(surname).dob(dob).build();

		borrowers = new ArrayList<>();
		customer1 = new CustomerDetails();
		customer1.setDob("1995-04-11 00:00:00");
		customer1.setPostCode(postcode);
		customer1.setSurname(surname);
		borrowers.add(customer1);
		CustomerDetails customer2 = new CustomerDetails();
		customer2.setClientId("876254321");
		customer2.setDob("2002-10-04 00:00:00");
		customer2.setPostCode("XY2 4XD");
		customer2.setSurname("Brown");
		borrowers.add(customer2);

		reasons = new ArrayList<String>();

	}

	@Test
	public void validatePostcodeInvalidTest() {
		authenticationRequest.setPostcode("HA1 2CD");
		postcodeValidator.validatePostcode(authenticationRequest, borrowers, reasons);
		assertEquals(1, reasons.size());
	}

	@Test
	public void validatePostcodeSpacesTest() {
		authenticationRequest.setPostcode("AB12CD");
		postcodeValidator.validatePostcode(authenticationRequest, borrowers, reasons);

		assertEquals(0, reasons.size());
	}

	@Test
	public void validatePostcodeValidTest() {
		postcodeValidator.validatePostcode(authenticationRequest, borrowers, reasons);

		assertEquals(0, reasons.size());
	}
}
