package com.rbs.pbbdhb.coordinator.auth.fourqv.util;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.FourQvMSSTResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.DoBValidator;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.PostcodeValidator;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.SurnameValidator;
import com.rbs.pbbdhb.coordinator.email.service.SendEmailService;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.exception.BusinessException;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@RunWith(MockitoJUnitRunner.class)
public class EmailUtilTest {

	@Mock
	private SendEmailService sendEmailService;

	@InjectMocks
	EmailUtil emailUtil;

	@Mock
	private MessageSource messageSource;

	@Mock
	ExceptionHelper exceptionHelper;

	@Mock
	SurnameValidator surnameValidator;
	
	@Mock
	PostcodeValidator postcodeValidator;
	
	@Mock
	DoBValidator dobValidator;

	@Mock
	JourneyMapper journeyMapper;
	
	String accountNumber;
	String postcode;
	String surname;
	String dob;
	AuthenticationRequest authenticationRequest;
	FourQvMSSTResponse msstResponse;
	CustomerDetails customer1;
	List<String> reasons;
	List<CustomerDetails> borrowers;

	@Before
	public void setUp() throws Exception {
		accountNumber = "12345678";
		postcode = "AB1 2CD";
		surname = "surname";
		dob = "11-04-1995";
		authenticationRequest = AuthenticationRequest.builder().accountNumber(accountNumber).postcode(postcode)
				.surname(surname).dob(dob).build();

		borrowers = new ArrayList<>();
		customer1 = new CustomerDetails();
		customer1.setDob("1995-04-11 00:00:00");
		customer1.setPostCode(postcode);
		customer1.setSurname(surname);
		borrowers.add(customer1);
		CustomerDetails customer2 = new CustomerDetails();
		customer2.setClientId("876254321");
		customer2.setDob("2002-10-04 00:00:00");
		customer2.setPostCode("XY2 4XD");
		customer2.setSurname("Brown");
		borrowers.add(customer2);

		reasons = new ArrayList<String>();
		
		Mockito.when(messageSource.getMessage(Mockito.anyString(), Mockito.any(), Mockito.any(Locale.class)))
				.thenReturn("");
	}

	@Test
	public void sendUnsuccessfulLoginAttemptEmailToMopsTest() {
		BrandContextHolder.setCurrentBrand("NWB");
		emailUtil.sendUnsuccessfulLoginAttemptEmailToMops(authenticationRequest, borrowers);

		Mockito.verify(sendEmailService).sendEmail(Mockito.any(), Mockito.any());
	}

	@Test
	public void sendUnsuccessfulLoginAttemptEmailToMopsWithReasonsTest() {
		authenticationRequest.setSurname("wrong");
		authenticationRequest.setPostcode("AB 2CD");
		authenticationRequest.setDob("03-12-1995");
		BrandContextHolder.setCurrentBrand("NWB");

		emailUtil.sendUnsuccessfulLoginAttemptEmailToMops(authenticationRequest, borrowers);

		Mockito.verify(sendEmailService).sendEmail(Mockito.any(), Mockito.any());
	}
	
	@Test
	public void getLoggedInCustomerDetailsNullTest() {
		borrowers = null;

		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), "borrowers.not.found.exception");

		assertThrows(BusinessException.class,
				() -> emailUtil.sendUnsuccessfulLoginAttemptEmailToMops(authenticationRequest, borrowers));
	}

}
