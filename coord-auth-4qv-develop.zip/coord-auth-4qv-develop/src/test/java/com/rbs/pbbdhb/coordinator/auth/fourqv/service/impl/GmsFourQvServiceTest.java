package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.List;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.MssCustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.FourQvValidationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.exception.BusinessException;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@RunWith(MockitoJUnitRunner.class)
public class GmsFourQvServiceTest {

	@Mock
	RestService restService;

	@InjectMocks
	GmsFourQvServiceImpl msvcIntGmsFourQvService;

	AuthenticationRequest fourQvRequet;
	
	@Mock
	ExceptionHelper exceptionHelper;

	@Mock
	private JourneyMapper journeyMapper;


	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);
		fourQvRequet = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1972").surname("Xxxxx")
				.postcode("SWSERA").build();

	}

	@Test
	public void getGmsIntFourQvResponse200() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);
		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQv(fourQvRequet);

		Assertions.assertEquals(200, fourQvValidtion.getFourQvStatus().value());

		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvResponse401() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.UNAUTHORIZED);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQv(fourQvRequet);

		Assertions.assertEquals(401, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvResponse404() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.NOT_FOUND);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQv(fourQvRequet);

		Assertions.assertEquals(404, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}
	
	@Test
	public void getGmsIntFourQvResponseNull() {
		FourQvValidationResponse fourQvValidationResponse = null;

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.NOT_FOUND);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQv(fourQvRequet);

		Assertions.assertEquals(404, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}
	
	@Test
	public void getGmsIntFourQvNatWestResponse200() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);
		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(200, fourQvValidtion.getFourQvStatus().value());

		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvNatWestResponse401() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.UNAUTHORIZED);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(401, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}
	
	@Test
	public void getGmsIntFourQvNatWestResponse404() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.NOT_FOUND);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(404, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvNatWestResponseNull() {
		FourQvValidationResponse fourQvValidationResponse = null;

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.NOT_FOUND);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(404, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}



	@Test
	public void getGmsIntFourQvCSTResponse200() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);
		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.OK);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(200, fourQvValidtion.getFourQvStatus().value());

		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvCSTResponse401() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.UNAUTHORIZED);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(401, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvCSTResponse404() {
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setClientId(null);

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.NOT_FOUND);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(404, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}

	@Test
	public void getGmsIntFourQvCSTResponseNull() {
		FourQvValidationResponse fourQvValidationResponse = null;

		ResponseEntity<FourQvValidationResponse> responseEntity = new ResponseEntity<FourQvValidationResponse>(
				fourQvValidationResponse, HttpStatus.NOT_FOUND);

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class)))
				.thenReturn(responseEntity);

		FourQvValidationResponse fourQvValidtion = msvcIntGmsFourQvService.validateFourQvNatWest(fourQvRequet);

		Assertions.assertEquals(404, fourQvValidtion.getFourQvStatus().value());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(FourQvValidationResponse.class));

	}



	@Test
	public void fetchBorrowers4qvDetails200() {
		List<CustomerDetails> borrowers = new ArrayList<>();
		CustomerDetails borrower1 = new CustomerDetails();
		borrower1.setClientId("2468101214");
		borrower1.setDob("01-01-1972");
		borrower1.setPostCode("SWSERA");
		borrower1.setSurname("Xxxxx");
		borrowers.add(borrower1);

		Mockito.when(restService.exchangeList(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
				ArgumentMatchers.any(HttpEntity.class),
				Mockito.eq(new ParameterizedTypeReference<List<CustomerDetails>>() {
				}))).thenReturn(new ResponseEntity<>(borrowers, HttpStatus.OK));

		List<CustomerDetails> borrowers4qvDetails = msvcIntGmsFourQvService.fetch4qvByMortNum("12345678");

		Assertions.assertNotNull(borrowers4qvDetails);
		Assertions.assertFalse(borrowers4qvDetails.isEmpty());

		Mockito.verify(restService, times(1)).exchangeList(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
				ArgumentMatchers.any(HttpEntity.class),
				Mockito.eq(new ParameterizedTypeReference<List<CustomerDetails>>() {
				}));

	}

	@Test
	public void fetchBorrowers4qvDetails401() {

		List<CustomerDetails> borrowers = new ArrayList<>();
		CustomerDetails borrower1 = new CustomerDetails();
		borrower1.setClientId("2468101214");
		borrower1.setDob("01-01-1972");
		borrower1.setPostCode("SWSERA");
		borrower1.setSurname("Xxxxx");
		borrowers.add(borrower1);

		Mockito.when(restService.exchangeList(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
				ArgumentMatchers.any(HttpEntity.class),
				Mockito.eq(new ParameterizedTypeReference<List<CustomerDetails>>() {
				}))).thenReturn(new ResponseEntity<>(borrowers, HttpStatus.UNAUTHORIZED));

		List<CustomerDetails> borrowers4qvDetails = msvcIntGmsFourQvService.fetch4qvByMortNum("12345678");

		Assertions.assertNull(borrowers4qvDetails);

		Mockito.verify(restService, times(1)).exchangeList(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
				ArgumentMatchers.any(HttpEntity.class),
				Mockito.eq(new ParameterizedTypeReference<List<CustomerDetails>>() {
				}));

	}

	@Test
	public void fetchBorrowers4qvDetailsException() {

		List<CustomerDetails> borrowers = new ArrayList<>();
		CustomerDetails borrower1 = new CustomerDetails();
		borrower1.setClientId("2468101214");
		borrower1.setDob("01-01-1972");
		borrower1.setPostCode("SWSERA");
		borrower1.setSurname("Xxxxx");
		borrowers.add(borrower1);

		Mockito.when(restService.exchangeList(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
				ArgumentMatchers.any(HttpEntity.class),
				Mockito.eq(new ParameterizedTypeReference<List<CustomerDetails>>() {
				}))).thenThrow(new RuntimeException("...") {});

		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				HttpStatus.NOT_FOUND.value(), "error.account.not.exists.message");

		assertThrows(BusinessException.class, () -> msvcIntGmsFourQvService.fetch4qvByMortNum("12345678"));

		Mockito.verify(restService, times(1)).exchangeList(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
				ArgumentMatchers.any(HttpEntity.class),
				Mockito.eq(new ParameterizedTypeReference<List<CustomerDetails>>() {
				}));

	}

	@Test
	public void getCustomers_HttpStatus404() {

		MssCustomerDetails customer = new MssCustomerDetails();

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(MssCustomerDetails.class)))
				.thenReturn(new ResponseEntity<>(customer, HttpStatus.NOT_FOUND));

		ResponseEntity<MssCustomerDetails> customerDetails = msvcIntGmsFourQvService.getCustomer(fourQvRequet);

		Assertions.assertEquals(404, customerDetails.getStatusCodeValue());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(MssCustomerDetails.class));

	}

	@Test
	public void getCustomers_HttpStatus500() {

		MssCustomerDetails customer = new MssCustomerDetails();

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(MssCustomerDetails.class)))
				.thenReturn(new ResponseEntity<>(customer, HttpStatus.INTERNAL_SERVER_ERROR));

		ResponseEntity<MssCustomerDetails> customerDetails = msvcIntGmsFourQvService.getCustomer(fourQvRequet);

		Assertions.assertEquals(500, customerDetails.getStatusCodeValue());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(MssCustomerDetails.class));

	}

	@Test
	public void getCustomerDetails_HttpStatus200() {

		MssCustomerDetails customer = new MssCustomerDetails();
		customer.setCin("2468101214");
		customer.setDob("01-01-1972");
		customer.setPostCode("SWSERA");
		customer.setSurName("Xxxxx");

		Mockito.when(restService.exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
						Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(MssCustomerDetails.class)))
				.thenReturn(new ResponseEntity<>(customer, HttpStatus.OK));

		ResponseEntity<MssCustomerDetails> customerDetails = msvcIntGmsFourQvService.getCustomer(fourQvRequet);

		Assertions.assertNotNull(customerDetails);
		Assertions.assertEquals(200, customerDetails.getStatusCodeValue());
		Mockito.verify(restService, times(1)).exchange(Mockito.any(), Mockito.eq(HttpMethod.POST),
				Mockito.<HttpEntity<AuthenticationRequest>>any(), Mockito.eq(MssCustomerDetails.class));

	}
}
