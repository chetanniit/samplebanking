package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.FourQvValidationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.AuthFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.EmailUtil;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;
import com.rbs.pbbdhb.email.model.EmailRequest;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class AuthenticationServiceTest {

	@Mock
	private ExceptionHelper exceptionHelper;

	@InjectMocks
	AuthenticationServiceImpl authenticationServiceImpl;

	@Mock
	private AuthFourQvService authFourQvServiceImpl;

	@Mock
	private GmsFourQvServiceImpl gmsFourQvServiceImpl;

	@SpyBean
	private Integer maxFaliedLoginAttempts;

	@SpyBean
	private Integer maxLockedOutHours;

	@Mock
	private EmailUtil emailUtil;

	@SpyBean
	private Integer maxResetDays;

	@Mock
	private JourneyMapper journeyMapper;

	@Mock
	private RestService restService;

	@Before
	public void setup() {

		maxFaliedLoginAttempts = 5;
		maxLockedOutHours = 12;
		maxResetDays = 90;
		ReflectionTestUtils.setField(authenticationServiceImpl, "maxFaliedLoginAttempts", maxFaliedLoginAttempts);
		ReflectionTestUtils.setField(authenticationServiceImpl, "maxLockedOutHours", maxLockedOutHours);
		ReflectionTestUtils.setField(authenticationServiceImpl, "maxResetDays", maxResetDays);
		Mockito.when(journeyMapper.isJourneyMSSTOrCST()).thenCallRealMethod();
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(false);
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(false);
		//MockitoAnnotations.initMocks(this);

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_max_attempts_4() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(4), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_journey_acquisition_max_attempts_2() {
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(2);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(2), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_200() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<String> argumentCaptorAcountNumber = ArgumentCaptor.forClass(String.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(authFourQvServiceImpl).createAccountLoginDetails(Mockito.anyString(),
				argumentCaptorAcountNumber.capture(), Mockito.eq(Boolean.TRUE));

		Assertions.assertEquals("12345678", argumentCaptorAcountNumber.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_404() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.NOT_FOUND);

		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<AuthenticationRequest> argumentCaptorAuthenticationRequest = ArgumentCaptor
				.forClass(AuthenticationRequest.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(gmsFourQvServiceImpl).validateFourQv(argumentCaptorAuthenticationRequest.capture());
		Assertions.assertEquals("12345678", argumentCaptorAuthenticationRequest.getValue().getAccountNumber());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_lock_and_hour_Less_than_12() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();
		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountLoginDetailsResponse);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_ok() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals("ACTIVE", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(1), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_reset_failed_attempts() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(12).minusSeconds(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForFailedAttempt(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_200_hour_more_than_12() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(12).minusSeconds(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_send_email_on_third_failure_attempt() {

		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(2);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		List<CustomerDetails> borrowers = new ArrayList<>();
		CustomerDetails customer1 = new CustomerDetails();
		customer1.setClientId("12345678");
		customer1.setDob("11-04-2023");
		customer1.setPostCode("AB1 2CD");
		customer1.setSurname("Smith");
		borrowers.add(customer1);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);
		Mockito.when(gmsFourQvServiceImpl.fetch4qvByMortNum(Mockito.anyString())).thenReturn(borrowers);

		EmailRequest emailRequest = new EmailRequest();
		emailRequest.setNotificationType("msst-unsuccessful-login-mops-notification");
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("email", "");
		parameters.put("toRecipients", "test@email.com");
		parameters.put("subject", "test");

		emailRequest.setParameters(parameters);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Mockito.verify(emailUtil).sendUnsuccessfulLoginAttemptEmailToMops(request, borrowers);

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(2), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_send_email_on_third_failure_attempt_cst() {

		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);

		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(2);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		List<CustomerDetails> borrowers = new ArrayList<>();
		CustomerDetails customer1 = new CustomerDetails();
		customer1.setClientId("12345678");
		customer1.setDob("11-04-2023");
		customer1.setPostCode("AB1 2CD");
		customer1.setSurname("Smith");
		borrowers.add(customer1);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);
		Mockito.when(gmsFourQvServiceImpl.fetch4qvByMortNum(Mockito.anyString())).thenReturn(borrowers);

		EmailRequest emailRequest = new EmailRequest();
		emailRequest.setNotificationType("msst-unsuccessful-login-mops-notification");
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("email", "");
		parameters.put("toRecipients", "test@email.com");
		parameters.put("subject", "test");

		emailRequest.setParameters(parameters);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Mockito.verify(emailUtil).sendUnsuccessfulLoginAttemptEmailToMops(request, borrowers);

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(2), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_max_attempts_4_msst() {

		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(4), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}



	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_max_attempts_4_organic_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(4), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_max_attempts_4_organic_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(4), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_200_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<String> argumentCaptorAcountNumber = ArgumentCaptor.forClass(String.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(authFourQvServiceImpl).createAccountLoginDetails(Mockito.anyString(),
				argumentCaptorAcountNumber.capture(), Mockito.eq(Boolean.TRUE));

		Assertions.assertEquals("12345678", argumentCaptorAcountNumber.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_200_organic_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		fourQvValidationResponse.setMobileNumber("07123456789");

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<String> argumentCaptorAcountNumber = ArgumentCaptor.forClass(String.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(authFourQvServiceImpl).createAccountLoginDetails(Mockito.anyString(),
				argumentCaptorAcountNumber.capture(), Mockito.eq(Boolean.TRUE));

		Assertions.assertEquals("12345678", argumentCaptorAcountNumber.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());
		Assertions.assertEquals("07123456789", authenticationResponse.getMobileNumber());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_200_organic_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		fourQvValidationResponse.setMobileNumber("07123456789");

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<String> argumentCaptorAcountNumber = ArgumentCaptor.forClass(String.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(authFourQvServiceImpl).createAccountLoginDetails(Mockito.anyString(),
				argumentCaptorAcountNumber.capture(), Mockito.eq(Boolean.TRUE));

		Assertions.assertEquals("12345678", argumentCaptorAcountNumber.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());
		Assertions.assertEquals("07123456789", authenticationResponse.getMobileNumber());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_404_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.NOT_FOUND);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<AuthenticationRequest> argumentCaptorAuthenticationRequest = ArgumentCaptor
				.forClass(AuthenticationRequest.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(gmsFourQvServiceImpl).validateFourQvNatWest(argumentCaptorAuthenticationRequest.capture());
		Assertions.assertEquals("12345678", argumentCaptorAuthenticationRequest.getValue().getAccountNumber());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}


	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_404_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.NOT_FOUND);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<AuthenticationRequest> argumentCaptorAuthenticationRequest = ArgumentCaptor
				.forClass(AuthenticationRequest.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(gmsFourQvServiceImpl).validateFourQvNatWest(argumentCaptorAuthenticationRequest.capture());
		Assertions.assertEquals("12345678", argumentCaptorAuthenticationRequest.getValue().getAccountNumber());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_lock_and_hour_Less_than_12_msst() {

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();
		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountLoginDetailsResponse);

		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}


	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_lock_and_hour_Less_than_12_cst() {

		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();
		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountLoginDetailsResponse);

		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_ok_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals("ACTIVE", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}


	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_ok_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals("ACTIVE", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(1), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(1), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_reset_failed_attempts_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(12).minusSeconds(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForFailedAttempt(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}


	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_401_reset_failed_attempts_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(12).minusSeconds(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForFailedAttempt(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_200_hour_more_than_12_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(24).minusSeconds(1);
		OffsetDateTime lastModified = OffsetDateTime.now(Clock.systemUTC()).minusHours(24).minusSeconds(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setLastModified(lastModified);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("broker", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}


	//TODO: this should fail
	@Test
	public void authanticatefourQv_if_account_login_details_not_null_with_status_200_hour_more_than_12_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		OffsetDateTime lockTimeStamp = OffsetDateTime.now(Clock.systemUTC()).minusHours(12).minusSeconds(1);
		OffsetDateTime lastModified = OffsetDateTime.now(Clock.systemUTC()).minusHours(12).minusSeconds(1);

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLockTimeStamp(lockTimeStamp);
		accountLoginDetailsResponse.setLastModified(lastModified);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_400_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.BAD_REQUEST);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<String> argumentCaptorAcountNumber = ArgumentCaptor.forClass(String.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(authFourQvServiceImpl).createAccountLoginDetails(Mockito.anyString(),
				argumentCaptorAcountNumber.capture(), Mockito.eq(Boolean.FALSE));

		Assertions.assertEquals("12345678", argumentCaptorAcountNumber.getValue());
		Assertions.assertEquals(400, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_null_with_status_400_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = null;

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.BAD_REQUEST);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<String> argumentCaptorAcountNumber = ArgumentCaptor.forClass(String.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(authFourQvServiceImpl).createAccountLoginDetails(Mockito.anyString(),
				argumentCaptorAcountNumber.capture(), Mockito.eq(Boolean.FALSE));

		Assertions.assertEquals("12345678", argumentCaptorAcountNumber.getValue());
		Assertions.assertEquals(400, authenticationResponse.getStatus().value());

	}


	@Test
	public void authenticatefourqv_resetattemptsafter90days_iffailedattemptsis1_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(1);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(91));
		BrandContextHolder.setCurrentBrand("NWB");

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetFailedAttemptsAfter90Days(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(0), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authenticatefourqv_resetattemptsafter90days_iffailedattemptsis2_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(2);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(92));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetFailedAttemptsAfter90Days(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(0), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authenticatefourqv_resetattemptsafter90days_iffailedattemptsis3_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(3);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(91));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetFailedAttemptsAfter90Days(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(0), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authenticatefourqv_resetattemptsafter90days_iffailedattemptsis4_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(91));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetFailedAttemptsAfter90Days(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(0), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authenticatefourqv_resetattemptsafter90days_locked_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(5);
		accountLoginDetailsResponse.setStatus(Constants.LOCKED);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(91));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).resetFailedAttemptsAfter90Days(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals("LOCKED", argumentCaptorStatus.getValue());
		Assertions.assertEquals(new Integer(0), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authenticatefourqv_resetattemptsafter90days_4qvsuccessful_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(91));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.OK);
		BrandContextHolder.setCurrentBrand("NWB");
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<String> argumentCaptorStatus = ArgumentCaptor.forClass(String.class);

		Mockito.verify(authFourQvServiceImpl).resetFailedAttemptsAfter90Days(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Mockito.verify(authFourQvServiceImpl).resetLockForSuccessfulLogin(argumentCaptorAccountNumber.capture(),
				argumentCaptorChannel.capture(), argumentCaptorStatus.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals("ACTIVE", argumentCaptorStatus.getValue());
		Assertions.assertEquals(200, authenticationResponse.getStatus().value());

	}

	@Test
	public void authenticatefourqv_resetattemptsafter90days_iffailedattemptsis4_89daytest_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()).minusDays(89));

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);
		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		ArgumentCaptor<String> argumentCaptorAccountNumber = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> argumentCaptorChannel = ArgumentCaptor.forClass(String.class);

		ArgumentCaptor<Integer> argumentCaptorCurrentFailedAttempt = ArgumentCaptor.forClass(Integer.class);

		Mockito.verify(authFourQvServiceImpl).incrementLockCount(argumentCaptorCurrentFailedAttempt.capture(),
				argumentCaptorAccountNumber.capture(), argumentCaptorChannel.capture());

		Assertions.assertEquals("12345678", argumentCaptorAccountNumber.getValue());
		Assertions.assertEquals("organic", argumentCaptorChannel.getValue());
		Assertions.assertEquals(new Integer(4), argumentCaptorCurrentFailedAttempt.getValue());
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_exists__404_msst() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(true);
		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.NOT_FOUND);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<AuthenticationRequest> argumentCaptorAuthenticationRequest = ArgumentCaptor
				.forClass(AuthenticationRequest.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(gmsFourQvServiceImpl).validateFourQvNatWest(argumentCaptorAuthenticationRequest.capture());
		Assertions.assertEquals("12345678", argumentCaptorAuthenticationRequest.getValue().getAccountNumber());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_exists__404_cst() {
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(true);
		String channel = "organic";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.NOT_FOUND);

		Mockito.when(gmsFourQvServiceImpl.validateFourQvNatWest(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<AuthenticationRequest> argumentCaptorAuthenticationRequest = ArgumentCaptor
				.forClass(AuthenticationRequest.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(gmsFourQvServiceImpl).validateFourQvNatWest(argumentCaptorAuthenticationRequest.capture());
		Assertions.assertEquals("12345678", argumentCaptorAuthenticationRequest.getValue().getAccountNumber());
		Assertions.assertEquals(401, authenticationResponse.getStatus().value());

	}

	@Test
	public void authanticatefourqv_if_accountdetails_exists__404() {
		Mockito.when(journeyMapper.isJourneyMSST()).thenReturn(false);
		Mockito.when(journeyMapper.isJourneyCST()).thenReturn(false);

		String channel = "broker";
		AuthenticationRequest request = AuthenticationRequest.builder().accountNumber("12345678").dob("01-01-1987")
				.surname("Surname").postcode("ASC 123").build();

		AccountLoginDetailsResponse accountLoginDetailsResponse = new AccountLoginDetailsResponse();
		accountLoginDetailsResponse.setAccountNumber("12345678");
		accountLoginDetailsResponse.setChannel(channel);
		accountLoginDetailsResponse.setFailedAttempts(4);
		accountLoginDetailsResponse.setStatus(Constants.ACTIVE);
		accountLoginDetailsResponse.setLastModified(OffsetDateTime.now(Clock.systemUTC()));

		Mockito.when(authFourQvServiceImpl.getAccountLoginDetails(Mockito.eq(channel),
				Mockito.eq(request.getAccountNumber()))).thenReturn(accountLoginDetailsResponse);

		FourQvValidationResponse fourQvValidationResponse = new FourQvValidationResponse();
		fourQvValidationResponse.setFourQvStatus(HttpStatus.NOT_FOUND);

		Mockito.when(gmsFourQvServiceImpl.validateFourQv(Mockito.any(AuthenticationRequest.class)))
				.thenReturn(fourQvValidationResponse);

		ArgumentCaptor<AuthenticationRequest> argumentCaptorAuthenticationRequest = ArgumentCaptor
				.forClass(AuthenticationRequest.class);
		AuthenticationResponse authenticationResponse = authenticationServiceImpl.authenticate(channel, request);

		Mockito.verify(gmsFourQvServiceImpl).validateFourQv(argumentCaptorAuthenticationRequest.capture());
		Assertions.assertEquals("12345678", argumentCaptorAuthenticationRequest.getValue().getAccountNumber());
		Assertions.assertEquals(423, authenticationResponse.getStatus().value());

	}
}
