package com.rbs.pbbdhb.coordinator.auth.fourqv.management;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.rbs.pbbdhb.coordinator.auth.fourqv.BaseCoordAuth4qvApplicationTest;

public class CallingInfoEndpointTest extends BaseCoordAuth4qvApplicationTest {

  private static final String MANAGEMENT_INFO_PATH = MANAGEMENT_PATH + "/info";

  @BeforeAll
  public void setUp() {
    response = getRequestSpecification().get(MANAGEMENT_INFO_PATH).then().extract().response();
  }

  @Test
  public void should_return_http_200() {
    assertThat(response.statusCode()).isEqualTo(OK.value());
  }

  @Test
  public void should_return_application_name() {
    assertThat(response.path("build.name").toString()).isEqualTo("coord-auth-4qv");
  }

  @Test
  public void should_return_application_version() {
    assertThat(response.path("build.version").toString()).isNotBlank();
  }
}
