package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import java.io.IOException;
import java.nio.charset.Charset;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.exception.BusinessException;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@RunWith(MockitoJUnitRunner.class)
public class RestServiceImplTest {

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private ExceptionHelper exceptionHelper;

	@Mock
	private ObjectMapper objectMapper;

	@InjectMocks
	private RestServiceImpl restServiceImpl;

	@Test
	public void shouldPostaccountDetailsResponse() {
		AccountLoginDetailsResponse accountDetailsResponse = new AccountLoginDetailsResponse();
		accountDetailsResponse.setAccountNumber("1");
		Mockito.when(restTemplate.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY,
				AccountLoginDetailsResponse.class))
				.thenReturn(new ResponseEntity<AccountLoginDetailsResponse>(accountDetailsResponse, HttpStatus.OK));
		ResponseEntity<AccountLoginDetailsResponse> response = restServiceImpl.exchange("localhost", HttpMethod.POST,
				HttpEntity.EMPTY, AccountLoginDetailsResponse.class);
		Assert.assertNotNull(response);
		Assert.assertNotNull(response.getBody());
		Assert.assertEquals(response.getBody().getAccountNumber(), "1");
	}

	@Test
	public void shouldPostAccountDetailsResponseHttpStatusInvalid() {
		AccountLoginDetailsResponse accountDetailsResponse = new AccountLoginDetailsResponse();
		accountDetailsResponse.setAccountNumber("1");
		Mockito.when(restTemplate.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY,
				AccountLoginDetailsResponse.class)).thenReturn(
						new ResponseEntity<AccountLoginDetailsResponse>(accountDetailsResponse, HttpStatus.CREATED));
		restServiceImpl.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY, AccountLoginDetailsResponse.class);
	}

	@Test
	public void testPostNotFoundException() throws JsonParseException, JsonMappingException, IOException {
		HttpClientErrorException clientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "not found",
				"{\"errorMessage\":\"not found\"}".getBytes(), Charset.defaultCharset());
		AccountLoginDetailsResponse accountDetailsResponse = new AccountLoginDetailsResponse();
		accountDetailsResponse.setErrorMessage("not found");
		Mockito.when(objectMapper.readValue(clientErrorException.getResponseBodyAsByteArray(),
				AccountLoginDetailsResponse.class)).thenReturn((AccountLoginDetailsResponse) accountDetailsResponse);
		Mockito.when(restTemplate.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY,
				AccountLoginDetailsResponse.class)).thenThrow(clientErrorException);
		ResponseEntity<AccountLoginDetailsResponse> response = restServiceImpl.exchange("localhost", HttpMethod.POST,
				HttpEntity.EMPTY, AccountLoginDetailsResponse.class);
		Assert.assertNotNull(response);
		Assert.assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
		Assert.assertNotNull(response.getBody());
		Assert.assertEquals(response.getBody().getErrorMessage(), "not found");

	}

	@Test(expected = BusinessException.class)
	public void testPostRequestTimedOut() throws JsonParseException, JsonMappingException, IOException {
		ResourceAccessException resourceAccessException = new ResourceAccessException("Request Timed Out");
		Mockito.when(restTemplate.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY,
				AccountLoginDetailsResponse.class)).thenThrow(resourceAccessException);
		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				resourceAccessException, HttpStatus.REQUEST_TIMEOUT.value(), "request.timed.out");
		restServiceImpl.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY, AccountLoginDetailsResponse.class);

	}

	@Test(expected = BusinessException.class)
	public void testPostNotFoundExceptionInvalidResponse()
			throws JsonParseException, JsonMappingException, IOException {
		HttpClientErrorException clientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "not found",
				"{\"errorMessage\":\"not found\"}".getBytes(), Charset.defaultCharset());
		AccountLoginDetailsResponse accountDetailsResponse = new AccountLoginDetailsResponse();
		accountDetailsResponse.setErrorMessage("not found");
		IOException ioException = new IOException("error");
		Mockito.when(objectMapper.readValue(clientErrorException.getResponseBodyAsByteArray(),
				AccountLoginDetailsResponse.class)).thenThrow(ioException);
		Mockito.when(restTemplate.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY,
				AccountLoginDetailsResponse.class)).thenThrow(clientErrorException);
		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				ioException, "internal.server.error");
		restServiceImpl.exchange("localhost", HttpMethod.POST, HttpEntity.EMPTY, AccountLoginDetailsResponse.class);

	}

	@Test(expected = BusinessException.class)
	public void testPostInternalErrorUnknownException() throws JsonParseException, JsonMappingException, IOException {
		RestClientException restClientException = new RestClientException("error");
		AccountLoginDetailsResponse accountDetailsResponse = new AccountLoginDetailsResponse();
		accountDetailsResponse.setErrorMessage("not found");
		Mockito.when(
				restTemplate.exchange("localhost", HttpMethod.GET, HttpEntity.EMPTY, AccountLoginDetailsResponse.class))
				.thenThrow(restClientException);
		Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,
				restClientException, "internal.server.error");
		restServiceImpl.exchange("localhost", HttpMethod.GET, HttpEntity.EMPTY, AccountLoginDetailsResponse.class);
	}

}
