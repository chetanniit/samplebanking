package com.rbs.pbbdhb.coordinator.auth.fourqv.model;

import java.util.HashMap;
import java.util.Map;

public class CustomThreadLocal {

	private CustomThreadLocal() {}
	
	private static ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();
	
	public static void setKeyValue(String key, Object obj) {
		Map<String, Object> map = threadLocal.get();
		if(null == map) {
			 map = new HashMap<String, Object>();
			threadLocal.set(map);
		}
		map.put(key, obj);
	}
	
	public static Object getValueByKey(String key) {
		Map<String, Object> map = threadLocal.get();
		if(null == map) {
			return null;
		}
		return map.get(key);
	}
	
	public static void clear() {
		threadLocal.remove();
	}
}
