package com.rbs.pbbdhb.coordinator.auth.fourqv.controller;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.CustomThreadLocal;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.AuthenticationService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;


@RestController
@Tag(name = "AuthenticationController", description = "AuthenticationController")
@Validated
public class AuthenticationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

	@Autowired
	private AuthenticationService authenticationService;
	
	@Autowired
    private JourneyMapper journeyMapper;

	@Operation(description = "Authenticate Customer's 4QV details", operationId = "authenticate", summary = "This API is used to authenticate Customer's 4QV details and returns Customer Unique id, Source Bank and masked Mobile Number(In case of customer channel)")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success Response", content = @Content(schema = @Schema(implementation = AuthenticationResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
			@ApiResponse(responseCode = "401", description = "UnAuthorized Resource", content = @Content),
			@ApiResponse(responseCode = "423", description = "Resource locked", content = @Content),
			@ApiResponse(responseCode = "500", description = "Internal server error", content = @Content) })
	@Parameters({
			@Parameter(name = "brand", schema = @Schema(allowableValues = { "nwb",
					"rbs" }), description = "Brand", required = true, example = "nwb"),
			@Parameter(name = "channel", schema = @Schema(allowableValues = { "broker",
					"organic" }), description = "Channel", required = true, example = "broker") })
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST, consumes = { "application/json" })
	public ResponseEntity<AuthenticationResponse> authenticate(
			@Valid @RequestBody(required = true) AuthenticationRequest request,
			@RequestHeader("brand") @Valid @Pattern(regexp = "(nwb|rbs)", message = "Invalid Brand") String brand,
			@RequestHeader(name = "channel", required = true) String channel,
			@RequestHeader(name = "journey", required = false) String journey) {
		BrandContextHolder.setCurrentBrand(brand);
		journeyMapper.setJourneyInThreadLocal(journey);
		if(journeyMapper.isJourneyMSSTOrCST()) {
			channel = Constants.ORGANIC;
		}
		LOGGER.info("Four Qv Request : {} {}", request, journey);
		AuthenticationResponse response = authenticationService.authenticate(channel, request);
		LOGGER.info("Authentication response : {}", response);
		CustomThreadLocal.clear();
		return new ResponseEntity<AuthenticationResponse>(response, response.getStatus());
	}
}