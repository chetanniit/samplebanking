package com.rbs.pbbdhb.coordinator.auth.fourqv;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;

import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;

@SpringBootApplication
@ComponentScan(basePackages = "com.rbs.pbbdhb")
public class CoordAuth4qvApplication {

	public static void main(String[] args) {
		new SpringApplicationBuilder().environment(new StandardEncryptableEnvironment())
				.sources(CoordAuth4qvApplication.class).run(args);

	}

}
