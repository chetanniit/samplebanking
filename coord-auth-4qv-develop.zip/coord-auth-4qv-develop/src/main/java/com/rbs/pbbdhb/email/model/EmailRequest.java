package com.rbs.pbbdhb.email.model;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailRequest {
	private String notificationType;
	private Map<String, Object> parameters;
}