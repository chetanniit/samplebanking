package com.rbs.pbbdhb.coordinator.auth.fourqv.validator;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;

@Service
public class PostcodeValidator {

	public void validatePostcode(AuthenticationRequest authenticationRequest,
			List<CustomerDetails> borrowers4qvDetailsList, List<String> reasons) {

		boolean isValidPostCode = borrowers4qvDetailsList.stream()
				.anyMatch(borrower -> borrower.getPostCode().replaceAll("0", "O").replaceAll(" ", "").equalsIgnoreCase(
						authenticationRequest.getPostcode().trim().replaceAll("0", "O").replaceAll(" ", "")));

		if (!isValidPostCode) {
			reasons.add(Constants.INVALID_POSTCODE);
		}
	}
}
