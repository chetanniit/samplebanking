package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import static com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants.ORGANIC;

import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.FourQvValidationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.AuthFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.AuthenticationService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.GmsFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.EmailUtil;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

	@Autowired
	private AuthFourQvService authFourQvService;

	@Autowired
	private GmsFourQvService gmsFourQvService;

	@Value("${max.falied.login.attempts}")
	private Integer maxFaliedLoginAttempts;

	@Value("${max.locked.out.hours}")
	private Integer maxLockedOutHours;

	@Autowired
	private EmailUtil emailUtil;

	@Value("${max.reset.days}")
	private Integer maxResetDays;

	@Autowired
	JourneyMapper journeyMapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

//	Pseudo logic
//	check if details exists in Account Login Table  (GET call)
//	if account login details exists yes
//		check if locked
//			if yes
//				check if < 12 hours 
//					if yes
//						return -- account locked
//						return 423 to UI
//					if no
//						validate using gms service
//							if 200
//								reset account login details with login successful
//								return 200 to UI
//							else
//								reset account login details with login unsuccessful
//								return 401 to UI
//			if No
//				validate using gms servie
//					if 200
//						reset account login details with login successful
//						return 200 to UI
//					else
//						increment failed attempts in account login details
//						if max failed attempts					
//							return 423 to UI
//						else
//							return 401 to UI
//	
//	if account login not exists
//		validate using gms servie
//			if 200
//				create Account Login details with login successful
//				return 200 to UI
//			else if 401
//				create Account Login details with login unsuccessful
//				return 401 to UI
//			else 404
//				return 401 to UI	

	@Override
	public AuthenticationResponse authenticate(String channel, AuthenticationRequest request) {
		AccountLoginDetailsResponse existingAccountLoginDetails = authFourQvService.getAccountLoginDetails(channel,
				request.getAccountNumber());
		LOGGER.info("Account login details  :{}", existingAccountLoginDetails);
		FourQvValidationResponse fourQvValidationResponse = null;
		if (Objects.isNull(existingAccountLoginDetails)) {
			fourQvValidationResponse = authenticateLoginDetailsNotExists(request, channel);
		} else {
			fourQvValidationResponse = authenticateLoginDetailsExists(existingAccountLoginDetails, request, channel);
		}

		AuthenticationResponse response = AuthenticationResponse.builder()
				.clientId(fourQvValidationResponse.getClientId()).sourceBank(fourQvValidationResponse.getSourceBank())
				.status(fourQvValidationResponse.getFourQvStatus()).build();

		if (ORGANIC.equals(channel) && HttpStatus.OK.equals(fourQvValidationResponse.getFourQvStatus())) {
			response.setMobileNumber(fourQvValidationResponse.getMobileNumber());
		}else if (ORGANIC.equals(channel) && !HttpStatus.OK.equals(fourQvValidationResponse.getFourQvStatus())) { 
			response.setRemainingAttempts(fourQvValidationResponse.getRemainingAttempts());
		}
			return response;

	}

	private FourQvValidationResponse authenticateLoginDetailsNotExists(AuthenticationRequest request, String channel) {
		boolean isLoginSuccessful = false;

		FourQvValidationResponse fourQvValidationResponse = journeyMapper.isJourneyMSSTOrCST()
				? gmsFourQvService.validateFourQvNatWest(request) :gmsFourQvService.validateFourQv(request);

				
		if (HttpStatus.NOT_FOUND.equals(fourQvValidationResponse.getFourQvStatus())) {
			fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);
		} else {			
			if (HttpStatus.OK.equals(fourQvValidationResponse.getFourQvStatus())) {
				isLoginSuccessful = true;
			}
			authFourQvService.createAccountLoginDetails(channel, request.getAccountNumber(), isLoginSuccessful);
			
			if(!isLoginSuccessful) {
				fourQvValidationResponse.setRemainingAttempts(Constants.MSST_MAX_LOGIN_ATTEMPTS - 1);
			}
		}

		return fourQvValidationResponse;
	}

	private FourQvValidationResponse authenticateLoginDetailsExists(
			AccountLoginDetailsResponse existingAccountLoginDetails, AuthenticationRequest request, String channel) {

		FourQvValidationResponse fourQvValidationResponse = journeyMapper.isJourneyMSSTOrCST()
				? gmsFourQvService.validateFourQvNatWest(request) :gmsFourQvService.validateFourQv(request);

		if (HttpStatus.NOT_FOUND.equals(fourQvValidationResponse.getFourQvStatus()) && journeyMapper.isJourneyMSSTOrCST()) {
			fourQvValidationResponse.setFourQvStatus(HttpStatus.UNAUTHORIZED);

			return fourQvValidationResponse;

		}

		if (journeyMapper.isJourneyMSST() && OffsetDateTime.now(Clock.systemUTC())
				.isAfter(existingAccountLoginDetails.getLastModified().plusDays(maxResetDays))) { // currentDate >

			LOGGER.info("Resetting Failed Login Attempts to 0 after 90 days");
			authFourQvService.resetFailedAttemptsAfter90Days(request.getAccountNumber(), channel,
					existingAccountLoginDetails.getStatus());
			existingAccountLoginDetails.setFailedAttempts(0); // reset failed attempts to 0
			existingAccountLoginDetails.setStatus(Constants.ACTIVE); // reset status to active
		}

		if (existingAccountLoginDetails.getStatus().equals(Constants.LOCKED)) {
			LOGGER.info("Account lock timestamp :{}", existingAccountLoginDetails.getLockTimeStamp());
			LOGGER.info("Max Locked Out Hours :{}", maxLockedOutHours);
			if (existingAccountLoginDetails.getLockTimeStamp().plusHours(maxLockedOutHours)
					.isAfter(OffsetDateTime.now(Clock.systemUTC()))) {
				fourQvValidationResponse = new FourQvValidationResponse();
				fourQvValidationResponse.setFourQvStatus(HttpStatus.LOCKED);
			} else {
				LOGGER.info("FourQvValidationResponse :{}", fourQvValidationResponse);
				if (HttpStatus.OK.equals(fourQvValidationResponse.getFourQvStatus())) {
					authFourQvService.resetLockForSuccessfulLogin(request.getAccountNumber(), channel,
							existingAccountLoginDetails.getStatus());
				} else {
					authFourQvService.resetLockForFailedAttempt(request.getAccountNumber(), channel,
							existingAccountLoginDetails.getStatus());
				}
			}
		} else {
			if (HttpStatus.OK.equals(fourQvValidationResponse.getFourQvStatus())) {
				authFourQvService.resetLockForSuccessfulLogin(request.getAccountNumber(), channel,
						existingAccountLoginDetails.getStatus());
			} else {
				int currentFailedAttempts = existingAccountLoginDetails.getFailedAttempts();
				LOGGER.info("currentFailedAttempts:{}", currentFailedAttempts);
				authFourQvService.incrementLockCount(currentFailedAttempts, request.getAccountNumber(), channel);
				if (currentFailedAttempts == maxFaliedLoginAttempts - 1) {
					fourQvValidationResponse.setFourQvStatus(HttpStatus.LOCKED);
				} else if (currentFailedAttempts == maxFaliedLoginAttempts - 3 && journeyMapper.isJourneyMSSTOrCST()) {

					List<CustomerDetails> borrowers4qvDetailsList = gmsFourQvService
							.fetch4qvByMortNum(request.getAccountNumber());

					emailUtil.sendUnsuccessfulLoginAttemptEmailToMops(request, borrowers4qvDetailsList);
				}
				if (HttpStatus.UNAUTHORIZED.equals(fourQvValidationResponse.getFourQvStatus())
						&& journeyMapper.isJourneyMSSTOrCST()) {
					fourQvValidationResponse
							.setRemainingAttempts(
									Constants.MSST_MAX_LOGIN_ATTEMPTS - 1
											- existingAccountLoginDetails.getFailedAttempts());
				}
			}
		}
		return fourQvValidationResponse;
	}

}
