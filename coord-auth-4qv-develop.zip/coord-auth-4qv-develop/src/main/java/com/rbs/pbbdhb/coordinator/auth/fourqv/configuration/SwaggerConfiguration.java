package com.rbs.pbbdhb.coordinator.auth.fourqv.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfiguration {
    @Autowired
    private BuildProperties buildProperties;

    @Bean
    public OpenAPI coordAuth4qvAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Coordinator - 4QV Authentication APIs")
                        .description("APIs in this microservices will be used to perform 4QV authentication")
                        .version(String.format("v1 / %s", buildProperties.getVersion())));
    }
}
