package com.rbs.pbbdhb.coordinator.auth.fourqv.service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;

public interface AuthFourQvService {

	AccountLoginDetailsResponse getAccountLoginDetails(String channel, String accountNumber);

	void createAccountLoginDetails(String channel, String accountNo,
			boolean isLoginSuccesful);

	void incrementLockCount(int currentFailledAttempt, String accountNumber, String channel);

	void resetLockForFailedAttempt(String accountNumber, String channel, String status);

	void resetLockForSuccessfulLogin(String accountNumber, String channel, String status);
	
	void resetFailedAttemptsAfter90Days(String accountNumber, String channel, String status);

}
