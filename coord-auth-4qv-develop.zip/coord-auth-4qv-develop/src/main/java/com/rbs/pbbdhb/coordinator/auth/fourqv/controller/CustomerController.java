package com.rbs.pbbdhb.coordinator.auth.fourqv.controller;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.CustomThreadLocal;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.MssCustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.GmsFourQvService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

@RestController
@Tag(name = "CustomerController", description = "CustomerSearchController")
@Validated
public class CustomerController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
    private GmsFourQvService gmsFourQvService;

	@Operation(description = "Search customer using 4QV details", operationId = "searchCustomer", summary = "This API is used to search customers using 4QV details and returns customer details")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "", content = @Content(schema = @Schema(implementation = MssCustomerDetails.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
			@ApiResponse(responseCode = "401", description = "UnAuthorized Resource", content = @Content),
			@ApiResponse(responseCode = "500", description = "Internal server error", content = @Content) })
	@Parameters({
			@Parameter(name = "brand", schema = @Schema(allowableValues = { "nwb" }),
					description = "Brand", required = true, example = "nwb")})
	@PostMapping(value = "/customers", consumes={"application/json"}, produces={"application/json"})
	public ResponseEntity<MssCustomerDetails> searchCustomer(
			@Valid @RequestBody(required = true) AuthenticationRequest request,
			@RequestHeader("brand") @Valid @Pattern(regexp = "(nwb)", message = "Invalid Brand") String brand) {
		BrandContextHolder.setCurrentBrand(brand);
		LOGGER.info("Customer search request: {}", request);
		ResponseEntity<MssCustomerDetails> response = gmsFourQvService.getCustomer(request);
		CustomThreadLocal.clear();
		LOGGER.info("Customer search response: {}", response);
		return new ResponseEntity<MssCustomerDetails>(response.getBody(), response.getStatusCode());
	}
}