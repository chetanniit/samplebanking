package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import java.util.List;
import java.util.Objects;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.*;
import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.FourQvValidationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.GmsFourQvRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.GmsFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.GmsFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import java.util.List;
import java.util.Objects;

@Service
public class GmsFourQvServiceImpl implements GmsFourQvService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GmsFourQvServiceImpl.class);

	@Autowired
	private RestService restService;

	@Value("${msvc.int.gms.4qv.service.base.url}")
	private String gmsIntFourQvServiceBaseUrl;

	@Value("${msvc.int.gms.4qv.service.request.path}")
	private String gmsIntFourQvServiceRequestPath;

	@Value("${msvc.int.gms.4qv.service.msst.request.path}")
	private String gmsIntFourQvServiceMSSTRequestPath;

	@Value("${msvc.int.gms.4qv.service.nwb.request.path}")
	private String gmsIntFourQvServiceNWBRequestPath;

	@Value("${msvc.int.gms.4qv.customer.search.request.path}")
	private String gmsIntFourQvCustomerSearchRequestPath;

	@Autowired
	JourneyMapper journeyMapper;

	@Autowired
	private ExceptionHelper exceptionHelper;

	@Override
	public FourQvValidationResponse validateFourQv(AuthenticationRequest request) {

		GmsFourQvRequest fourQvRequest = GmsFourQvRequest.builder().accountNumber(request.getAccountNumber())
				.dob(request.getDob()).surname(request.getSurname()).postcode(request.getPostcode()).build();

		String url = StringUtils.join(gmsIntFourQvServiceBaseUrl, gmsIntFourQvServiceRequestPath);

		ResponseEntity<FourQvValidationResponse> responseEntity = restService.exchange(url, HttpMethod.POST,
				createRequestEntity(fourQvRequest), FourQvValidationResponse.class);

		HttpStatus responseStatus = responseEntity.getStatusCode();
		if (!HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& !HttpStatus.NOT_FOUND.equals(responseEntity.getStatusCode())) {
			responseStatus = HttpStatus.UNAUTHORIZED;
		}

		FourQvValidationResponse fourQvValidationResponse = responseEntity.getBody();

		if (Objects.isNull(fourQvValidationResponse)) {
			fourQvValidationResponse = new FourQvValidationResponse();
		}
		fourQvValidationResponse.setFourQvStatus(responseStatus);

		LOGGER.info("four Qv Validation Response:{}", fourQvValidationResponse);

		return fourQvValidationResponse;

	}

	@Override
	public FourQvValidationResponse validateFourQvNatWest(AuthenticationRequest request) {
		GmsFourQvRequest fourQvRequest = GmsFourQvRequest.builder().accountNumber(request.getAccountNumber())
				.dob(request.getDob()).surname(request.getSurname()).postcode(request.getPostcode()).build();

		String url = StringUtils.join(gmsIntFourQvServiceBaseUrl, gmsIntFourQvServiceNWBRequestPath);

		ResponseEntity<FourQvValidationResponse> responseEntity = restService.exchange(url, HttpMethod.POST,
				createRequestEntity(fourQvRequest), FourQvValidationResponse.class);

		HttpStatus responseStatus = responseEntity.getStatusCode();
		if (!HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& !HttpStatus.UNAUTHORIZED.equals(responseEntity.getStatusCode())) {
			responseStatus = HttpStatus.NOT_FOUND;
		}

		FourQvValidationResponse fourQvValidationResponse = responseEntity.getBody();

		if (Objects.isNull(fourQvValidationResponse)) {
			fourQvValidationResponse = new FourQvValidationResponse();
		}
		fourQvValidationResponse.setFourQvStatus(responseStatus);

		LOGGER.info("four Qv Validation Response:{}", fourQvValidationResponse);

		return fourQvValidationResponse;
	}

	@Override
	public List<CustomerDetails> fetch4qvByMortNum(String accountNumber) {

		List<CustomerDetails> borrower4qvDetails = null;
		String url = StringUtils.join(gmsIntFourQvServiceBaseUrl, gmsIntFourQvServiceMSSTRequestPath);

		try {
			ResponseEntity<List<CustomerDetails>> responseEntity = restService.exchangeList(url, HttpMethod.GET,
					createHeaders(accountNumber), new ParameterizedTypeReference<List<CustomerDetails>>() {
					});
			if (HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				borrower4qvDetails = responseEntity.getBody();
			}
		} catch (Exception e) {
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.NOT_FOUND.value(),
					"error.account.not.exists.message");
		}

		return borrower4qvDetails;

	}

	@Override
	public ResponseEntity<MssCustomerDetails> getCustomer(AuthenticationRequest fourQvRequest) {
		String url = StringUtils.join(gmsIntFourQvServiceBaseUrl, gmsIntFourQvCustomerSearchRequestPath);
		ResponseEntity<MssCustomerDetails> responseEntity = restService.exchange(url, HttpMethod.POST,
				createRequestEntity(fourQvRequest), MssCustomerDetails.class);

		if (!HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& !HttpStatus.NOT_FOUND.equals(responseEntity.getStatusCode())) {
			LOGGER.error("Exception occurred while authenticating account {}", fourQvRequest.getAccountNumber());
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					"internal.server.error");
		} else if (HttpStatus.NOT_FOUND.equals(responseEntity.getStatusCode())) {
			LOGGER.error("No records found for account {}", fourQvRequest.getAccountNumber());
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.NOT_FOUND.value(),
					"error.account.not.exists.message");
		}

		return responseEntity;
	}

	private HttpEntity<GmsFourQvRequest> createRequestEntity(GmsFourQvRequest fourQvRequest) {
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.add(HttpHeaders.CONTENT_TYPE, "application/json");
		requestHeaders.add("brand", BrandContextHolder.getCurrentBrand());

		if (Objects.nonNull(journeyMapper.getJourneyFromThreadLocal()))
			requestHeaders.add("journey", journeyMapper.getJourneyFromThreadLocal());

		final HttpEntity<GmsFourQvRequest> requestEntity = new HttpEntity<GmsFourQvRequest>(fourQvRequest,
				requestHeaders);
		return requestEntity;
	}

	private HttpEntity<AuthenticationRequest> createRequestEntity(AuthenticationRequest fourQvRequest) {
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.add(HttpHeaders.CONTENT_TYPE, "application/json");
		requestHeaders.add("brand", BrandContextHolder.getCurrentBrand());
		final HttpEntity<AuthenticationRequest> requestEntity = new HttpEntity<AuthenticationRequest>(fourQvRequest,
				requestHeaders);
		return requestEntity;
	}

	private HttpEntity<Void> createHeaders(String accountNumber) {
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.add(HttpHeaders.CONTENT_TYPE, "application/json");
		requestHeaders.add("brand", BrandContextHolder.getCurrentBrand());
		requestHeaders.add("account_number", accountNumber);

		if (Objects.nonNull(journeyMapper.getJourneyFromThreadLocal()))
			requestHeaders.add("journey", journeyMapper.getJourneyFromThreadLocal());

		return new HttpEntity<>(requestHeaders);
	}

}
