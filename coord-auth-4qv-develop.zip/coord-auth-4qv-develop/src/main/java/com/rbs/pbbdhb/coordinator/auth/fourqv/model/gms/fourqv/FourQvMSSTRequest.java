package com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv;

import lombok.Data;

@Data
public class FourQvMSSTRequest {
	String accountNumber;
}
