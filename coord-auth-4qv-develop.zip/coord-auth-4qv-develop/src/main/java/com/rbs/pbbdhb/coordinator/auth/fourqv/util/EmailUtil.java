package com.rbs.pbbdhb.coordinator.auth.fourqv.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.DoBValidator;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.PostcodeValidator;
import com.rbs.pbbdhb.coordinator.auth.fourqv.validator.SurnameValidator;
import com.rbs.pbbdhb.coordinator.email.service.SendEmailService;
import com.rbs.pbbdhb.email.model.EmailRequest;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@Component
public class EmailUtil {

	@Autowired
	private SendEmailService sendEmailService;

	@Autowired
	private MessageSource messageSource;

	@Value("${mops.email.nwb}")
	private String mopsNwbEmailAddress;
	
	@Value("${mops.email.rbs}")
	private String mopsRbsEmailAddress;

	private final Logger LOGGER = LoggerFactory.getLogger(EmailUtil.class);

	@Autowired
	private ExceptionHelper exceptionHelper;

	@Autowired
	private SurnameValidator surnameValidator;

	@Autowired
	private DoBValidator dobValidator;
	
	@Autowired
	private PostcodeValidator postcodeValidator;

	@Autowired
	JourneyMapper journeyMapper;

	public void sendUnsuccessfulLoginAttemptEmailToMops(AuthenticationRequest authenticationRequest,
			List<CustomerDetails> borrowers4qvDetailsList) {

		if (CollectionUtils.isEmpty(borrowers4qvDetailsList)) {
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					Constants.BORROWERS_NOT_FOUND_EXCEPTION);
		}

		Map<String, Object> unsuccessfulLoginDetailsMap = collectUnsuccessfulLoginAttemptEmailData(
				authenticationRequest, borrowers4qvDetailsList);
		String email = buildUnsuccessfulLoginAttemptEmail(unsuccessfulLoginDetailsMap);
		sendUnsuccessfulEmailToMops(unsuccessfulLoginDetailsMap.get(Constants.MORTGAGE_ACCOUNT_NUMBER).toString(),
				email);
	}

	private String getReasonForUnsuccessfulLoginAttempt(AuthenticationRequest authenticationRequest,
			List<CustomerDetails> borrowers4qvDetailsList) {
		ArrayList<String> reasons = new ArrayList<>();

		surnameValidator.validateSurname(authenticationRequest, borrowers4qvDetailsList, reasons);
		dobValidator.validateDOB(authenticationRequest, borrowers4qvDetailsList, reasons);
		postcodeValidator.validatePostcode(authenticationRequest, borrowers4qvDetailsList, reasons);

		StringBuilder HTML = new StringBuilder();
		for (String reason : reasons) {
			HTML.append(Constants.BEGIN_ROW);
			HTML.append(Constants.BEGIN_COL + reason + Constants.END_COL);
			HTML.append(Constants.END_ROW);
		}
		return HTML.toString();

	}

	private String createBorrowersHTML(List<CustomerDetails> customerDetails) {
		StringBuilder HTML = new StringBuilder();
		for (int i = 0; i < customerDetails.size(); i++) {
			HTML.append(Constants.BEGIN_ROW);
			HTML.append(Constants.BEGIN_COL + ordinal(i + 1) + " Customer surname:" + Constants.END_COL);
			HTML.append(Constants.BEGIN_COL + toPascalCase(customerDetails.get(i).getSurname()) + Constants.END_COL);
			HTML.append(Constants.END_ROW);
			HTML.append(Constants.BEGIN_ROW);
			HTML.append(Constants.BEGIN_COL + ordinal(i + 1) + " Customer date of birth:" + Constants.END_COL);
			HTML.append(Constants.BEGIN_COL + dobValidator.getConvertedDate(customerDetails.get(i).getDob())
					+ Constants.END_COL);
			HTML.append(Constants.END_ROW);
			HTML.append(Constants.BEGIN_ROW);
			HTML.append(Constants.BEGIN_COL + "postcode:" + Constants.END_COL);
			HTML.append(Constants.BEGIN_COL + customerDetails.get(i).getPostCode() + Constants.END_COL);
			HTML.append(Constants.END_ROW);
		}

		return HTML.toString();
	}

	private String ordinal(int i) {
		String[] suffixes = new String[] { "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };
		switch (i % 100) {
		case 11:
		case 12:
		case 13:
			return i + "th";
		default:
			return i + suffixes[i % 10];
		}
	}

	private Map<String, Object> collectUnsuccessfulLoginAttemptEmailData(AuthenticationRequest authenticationRequest,
			List<CustomerDetails> borrowers4qvDetailsList) {
		Map<String, Object> unsuccessfulLoginDetailsMap = new HashMap<>();
		unsuccessfulLoginDetailsMap.put(Constants.REASON,
				getReasonForUnsuccessfulLoginAttempt(authenticationRequest, borrowers4qvDetailsList));
		unsuccessfulLoginDetailsMap.put(Constants.MORTGAGE_ACCOUNT_NUMBER, authenticationRequest.getAccountNumber());
		unsuccessfulLoginDetailsMap.put(Constants.SURNAME, authenticationRequest.getSurname());
		unsuccessfulLoginDetailsMap.put(Constants.DOB, authenticationRequest.getDob());
		unsuccessfulLoginDetailsMap.put(Constants.POSTCODE, authenticationRequest.getPostcode());
		unsuccessfulLoginDetailsMap.put(Constants.BORROWERS_HTML, createBorrowersHTML(borrowers4qvDetailsList));
		return unsuccessfulLoginDetailsMap;
	}

	private String buildUnsuccessfulLoginAttemptEmail(Map<String, Object> emailMap) {
		String email = messageSource.getMessage("unsuccessful.login.mops.email",
				new Object[] { emailMap.get(Constants.REASON), emailMap.get(Constants.MORTGAGE_ACCOUNT_NUMBER),
						emailMap.get(Constants.SURNAME), emailMap.get(Constants.DOB), emailMap.get(Constants.POSTCODE),
						emailMap.get(Constants.BORROWERS_HTML) },
				Locale.ENGLISH);
		LOGGER.info(email);
		return email;
	}

	private void sendUnsuccessfulEmailToMops(String accountNumber, String email) {
		EmailRequest emailRequest = generateEmailRequestForUnsuccessfulLogin(accountNumber, email);
		sendEmailService.sendEmail(emailRequest, BrandContextHolder.getCurrentBrand());
	}

	private EmailRequest generateEmailRequestForUnsuccessfulLogin(String accountNumber, String email) {
		EmailRequest emailRequest = new EmailRequest();
		emailRequest.setNotificationType(Constants.MSST_UNSUCCESSFUL_LOGIN_MOPS_TEMPLATE);
		Map<String, Object> parameters = new HashMap<>();
		parameters.put(Constants.EMAIL_TEMPLATE, email);
		if(BrandContextHolder.getCurrentBrand().equalsIgnoreCase("rbs"))
			parameters.put(Constants.TO_RECIPIENTS, mopsRbsEmailAddress);
		else
			parameters.put(Constants.TO_RECIPIENTS, mopsNwbEmailAddress);
		if(journeyMapper.isJourneyCST())
			parameters.put(Constants.SUBJECT,
					String.format(Constants.UNSUCCESSFUL_LOGIN_ATTEMPT_EMAIL_SUBJECT_LINE_CST, accountNumber));
		else
		parameters.put(Constants.SUBJECT,
				String.format(Constants.UNSUCCESSFUL_LOGIN_ATTEMPT_EMAIL_SUBJECT_LINE, accountNumber));
		emailRequest.setParameters(parameters);
		return emailRequest;
	}

	private String toPascalCase(String text) {
		char[] characters;
		String finalText = "";
		if (StringUtils.isNotEmpty(text)) {
			characters = text.toLowerCase().toCharArray();
			boolean scFlag = false;
			for (int i = 0; i < characters.length; i++) {
				if (!scFlag && Character.isLetter(characters[i])) {
					characters[i] = Character.toUpperCase(characters[i]);
					scFlag = true;
				} else if (!Character.isLetter(characters[i]) || Character.isWhitespace(characters[i])) {
					scFlag = false;
				}
			}
			finalText = String.valueOf(characters);
		}
		return finalText;
	}

}
