package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.configuration.BrandContextHolder;
import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv.AccountLoginDetailsUpdateRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.AuthFourQvService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.DateUtil;
import com.rbs.pbbdhb.coordinator.auth.fourqv.util.JourneyMapper;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.error.BaseResponse;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@Service
public class AuthFourQvServiceImpl implements AuthFourQvService {

	@Value("${hlpr.auth.4qv.service.base.url}")
	private String hlprAuthFourQvServiceBaseUrl;

	@Value("${hlpr.auth.4qv.service.request.path}")
	private String hlprAuthFourQvServiceRequestPath;

	@Value("${max.falied.login.attempts}")
	private Integer maxFaliedLoginAttempts;

	@Autowired
	private RestService restService;

	@Autowired
	private ExceptionHelper exceptionHelper;

	@Autowired
	JourneyMapper journeyMapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthFourQvServiceImpl.class);

	@Override
	public AccountLoginDetailsResponse getAccountLoginDetails(String channel, String accountNumber) {
		String url = StringUtils.join(hlprAuthFourQvServiceBaseUrl, hlprAuthFourQvServiceRequestPath,
				journeyMapper.getJourneyFromThreadLocal() + "/", channel + "/", accountNumber);
		ResponseEntity<AccountLoginDetailsResponse> responseEntity = restService.exchange(url, HttpMethod.GET,
				createRequestEntity(channel), AccountLoginDetailsResponse.class);
		LOGGER.info("Account Login Details Response: {}", responseEntity.getBody());
		return responseEntity.getBody();

	}

	@Override
	public void createAccountLoginDetails(String channel, String accountNumber, boolean isLoginSuccessful) {
		String url = StringUtils.join(hlprAuthFourQvServiceBaseUrl, hlprAuthFourQvServiceRequestPath);
		AccountLoginDetailsRequest request = null;
		if (isLoginSuccessful) {
			request = AccountLoginDetailsRequest.builder().accountNumber(accountNumber).channel(channel)
					.journey(journeyMapper.getJourneyFromThreadLocal()).failedAttempts(0).status(Constants.ACTIVE)
					.lastLoginDate(DateUtil.getUtcCurrentOffsetDateTime()).build();
		} else {
			request = AccountLoginDetailsRequest.builder().accountNumber(accountNumber).channel(channel)
					.journey(journeyMapper.getJourneyFromThreadLocal()).failedAttempts(1).status(Constants.ACTIVE)
					.build();

		}

		if (journeyMapper.isJourneyMSSTOrCST()) {
			request.setLastModified(DateUtil.getUtcCurrentOffsetDateTime());
		}

		final HttpEntity<AccountLoginDetailsRequest> requestEntity = new HttpEntity<AccountLoginDetailsRequest>(request,
				getRequestHeader());
		ResponseEntity<BaseResponse> responseEntity = restService.exchange(url, HttpMethod.POST, requestEntity,
				BaseResponse.class);
		if (!HttpStatus.CREATED.equals(responseEntity.getStatusCode())) {
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, responseEntity.getStatusCodeValue(),
					"internal.server.error");

		}

	}

	@Override
	public void incrementLockCount(int currentFailedAttempt, String accountNumber, String channel) {
		AccountLoginDetailsUpdateRequest accountLoginDetailsUpdateRequest = null;
		LOGGER.info("Current cout failed attemp :{}", currentFailedAttempt);
		int failedAttempt = currentFailedAttempt + 1;
		if (failedAttempt < maxFaliedLoginAttempts) {
			accountLoginDetailsUpdateRequest = AccountLoginDetailsUpdateRequest.builder().failedAttempts(failedAttempt)
					.status(Constants.ACTIVE).build();
		} else if (failedAttempt == maxFaliedLoginAttempts) {
			accountLoginDetailsUpdateRequest = AccountLoginDetailsUpdateRequest.builder()
					.failedAttempts(maxFaliedLoginAttempts).status(Constants.LOCKED)
					.lockTimeStamp(DateUtil.getUtcCurrentOffsetDateTime()).build();

		}
		LOGGER.info("Incremented failed attemp :{}", failedAttempt);

		updateAccountLoginDetails(channel, accountNumber, accountLoginDetailsUpdateRequest);

	}

	@Override
	public void resetLockForFailedAttempt(String accountNumber, String channel, String status) {
		AccountLoginDetailsUpdateRequest accountLoginDetailsUpdateRequest = null;
		accountLoginDetailsUpdateRequest = AccountLoginDetailsUpdateRequest.builder().failedAttempts(1)
				.status(Constants.ACTIVE).build();
		if (status.equals(Constants.LOCKED)) {
			accountLoginDetailsUpdateRequest.setFailedOtpAttempts(0);
			accountLoginDetailsUpdateRequest.setResendCount(0);
		}
		updateAccountLoginDetails(channel, accountNumber, accountLoginDetailsUpdateRequest);

	}

	@Override
	public void resetLockForSuccessfulLogin(String accountNumber, String channel, String status) {
		AccountLoginDetailsUpdateRequest accountLoginDetailsUpdateRequest = null;
		accountLoginDetailsUpdateRequest = AccountLoginDetailsUpdateRequest.builder().failedAttempts(0)
				.status(Constants.ACTIVE).lastLoginDate(DateUtil.getUtcCurrentOffsetDateTime()).build();
		if (status.equals(Constants.LOCKED)) {
			accountLoginDetailsUpdateRequest.setFailedOtpAttempts(0);
			accountLoginDetailsUpdateRequest.setResendCount(0);
		}
		updateAccountLoginDetails(channel, accountNumber, accountLoginDetailsUpdateRequest);

	}

	@Override
	public void resetFailedAttemptsAfter90Days(String accountNumber, String channel, String status) {
		AccountLoginDetailsUpdateRequest accountLoginDetailsUpdateRequest = null;
		accountLoginDetailsUpdateRequest = AccountLoginDetailsUpdateRequest.builder().failedAttempts(0)
				.status(Constants.ACTIVE).build();

			accountLoginDetailsUpdateRequest.setFailedOtpAttempts(0);
			accountLoginDetailsUpdateRequest.setResendCount(0);
		updateAccountLoginDetails(channel, accountNumber, accountLoginDetailsUpdateRequest);

	}

	private ResponseEntity<BaseResponse> updateAccountLoginDetails(String channel, String accountNumber,
			AccountLoginDetailsUpdateRequest request) {
		LOGGER.info("AccountLoginDetailsUpdateRequest :{}", request);

		String url = StringUtils.join(hlprAuthFourQvServiceBaseUrl, hlprAuthFourQvServiceRequestPath,
				journeyMapper.getJourneyFromThreadLocal() + "/", channel + "/", accountNumber);

		ResponseEntity<BaseResponse> responseEntity = null;
		final HttpEntity<AccountLoginDetailsUpdateRequest> requestEntity = new HttpEntity<AccountLoginDetailsUpdateRequest>(
				request, getRequestHeader());

		responseEntity = restService.exchange(url, HttpMethod.PUT, requestEntity, BaseResponse.class);
		LOGGER.info("AccountLoginDetailsUpdate response :{}", responseEntity.getStatusCodeValue());

		return responseEntity;

	}

	private HttpEntity<Void> createRequestEntity(String channel) {
		HttpHeaders headers = getRequestHeader();
		headers.add("channel", channel);
		return new HttpEntity<Void>(headers);
	}

	private HttpHeaders getRequestHeader() {
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, Constants.CONTENT_TYPE_APPLICATION_JSON);
		headers.add("brand", BrandContextHolder.getCurrentBrand());

		return headers;
	}
}
