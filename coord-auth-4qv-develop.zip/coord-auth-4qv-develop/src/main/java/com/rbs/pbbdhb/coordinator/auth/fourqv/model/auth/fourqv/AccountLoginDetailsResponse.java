package com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv;

import java.time.OffsetDateTime;

import com.rbs.pbbdhb.error.BaseResponse;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Data
@NoArgsConstructor
public class AccountLoginDetailsResponse extends BaseResponse{
	
	private static final long serialVersionUID = 7699227626232617326L;
	
	private String journey;
	private String accountNumber;
	private String channel;
	private String status;

	private int failedAttempts;

	private OffsetDateTime lockTimeStamp;

	private OffsetDateTime dateCreated;

	private OffsetDateTime lastModified;

	private OffsetDateTime lastLoginDate;


}
