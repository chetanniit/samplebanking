package com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv;

import java.time.OffsetDateTime;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Builder
public class AccountLoginDetailsUpdateRequest {

	private Integer failedAttempts;

	private String status;

	@DateTimeFormat(iso = ISO.DATE_TIME)
	private OffsetDateTime lastLoginDate;

	@DateTimeFormat(iso = ISO.DATE_TIME)
	private OffsetDateTime lockTimeStamp;
	
	private Integer failedOtpAttempts;

	private Integer resendCount; 

}
