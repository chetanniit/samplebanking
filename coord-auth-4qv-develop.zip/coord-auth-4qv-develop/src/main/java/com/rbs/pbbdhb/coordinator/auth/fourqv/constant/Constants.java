package com.rbs.pbbdhb.coordinator.auth.fourqv.constant;

public class Constants {
	
	public static String ACTIVE = "ACTIVE";
	public static String LOCKED = "LOCKED";
	
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";

	public static final String ORGANIC = "organic";
	public static final String JOURNEY_ACQUISITION = "acquisition";
	
	public static final int MSST_MAX_LOGIN_ATTEMPTS = 5;

	public static final String MSST = "msst";
	public static final String JOURNEY = "journey";
	public static final String CST = "cst";


	public static final String INVALID_SURNAME = "Surname is not matching";
	public static final String INVALID_POSTCODE = "Postcode is not matching";
	public static final String INVALID_DOB = "DoB is not matching";
	
	public static final String BEGIN_ROW = "<tr>";
	public static final String BEGIN_COL = "<td>";
	public static final String END_ROW = "</tr>";
	public static final String END_COL = "</td>";
	
	public static final String REASON = "reason";
	public static final String MORTGAGE_ACCOUNT_NUMBER = "mortgageAccountNumber";
	public static final String SURNAME = "surname";
	public static final String DOB = "dob";
	public static final String POSTCODE = "postcode";
	public static final String BORROWERS_HTML = "borrowersHTML";

	public static final String MSST_UNSUCCESSFUL_LOGIN_MOPS_TEMPLATE = "msst-unsuccessful-login-mops-notification";
	public static final String EMAIL_TEMPLATE = "emailTemplate";
	public static final String TO_RECIPIENTS = "toRecipients";
	public static final String SUBJECT = "subject";
	public static final String UNSUCCESSFUL_LOGIN_ATTEMPT_EMAIL_SUBJECT_LINE = "%s - Unsuccessful login";
	public static final String UNSUCCESSFUL_LOGIN_ATTEMPT_EMAIL_SUBJECT_LINE_CST = "%s - Mortgage Tracker - Unsuccessful login";

	public static final String BRAND = "brand";
	
	public static final String DATE_PARSE_EXCEPTION = "date.parse.exception";
	public static final String BORROWERS_NOT_FOUND_EXCEPTION = "borrowers.not.found.exception";


}
