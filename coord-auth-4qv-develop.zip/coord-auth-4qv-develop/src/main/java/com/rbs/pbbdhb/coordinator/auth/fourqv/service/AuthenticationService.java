package com.rbs.pbbdhb.coordinator.auth.fourqv.service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationResponse;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;

public interface AuthenticationService {

	AuthenticationResponse authenticate(String channel, AuthenticationRequest request);

}
