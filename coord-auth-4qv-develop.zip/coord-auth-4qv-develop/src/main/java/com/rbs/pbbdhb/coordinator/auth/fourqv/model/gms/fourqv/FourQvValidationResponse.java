package com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv;

import org.springframework.http.HttpStatus;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FourQvValidationResponse {

	private String clientId;
	private String sourceBank;
	private String mobileNumber;
	
	private String errorMessage;
	private HttpStatus fourQvStatus;
	private Integer remainingAttempts;
	
}
