package com.rbs.pbbdhb.coordinator.auth.fourqv.util;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public class DateUtil {

	public static OffsetDateTime getUtcCurrentOffsetDateTime() {
		return OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC);
	}

}
