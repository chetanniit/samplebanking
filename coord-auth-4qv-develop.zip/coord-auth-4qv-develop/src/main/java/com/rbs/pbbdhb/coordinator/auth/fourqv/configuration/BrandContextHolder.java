package com.rbs.pbbdhb.coordinator.auth.fourqv.configuration;

public class BrandContextHolder {
    private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();

    private BrandContextHolder() {
    }

    public static void setCurrentBrand(String brand) {
        contextHolder.set(brand);
    }

    public static String getCurrentBrand() {
        return contextHolder.get();
    }

    public static void clear() {
        contextHolder.remove();
    }
}