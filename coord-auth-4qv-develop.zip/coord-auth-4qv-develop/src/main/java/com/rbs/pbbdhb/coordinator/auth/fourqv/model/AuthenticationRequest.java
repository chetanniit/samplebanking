package com.rbs.pbbdhb.coordinator.auth.fourqv.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.rbs.pbbdhb.common.validation.annotation.Account;
import com.rbs.pbbdhb.common.validation.annotation.Date;
import com.rbs.pbbdhb.common.validation.annotation.Postcode;
import com.rbs.pbbdhb.common.validation.annotation.Surname;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Builder
@Schema(description = "Authentication request (Four Question validation)")
public class AuthenticationRequest {

	@Schema(name = "accountNumber", required = true, description = "Account number should be 8 digits", example = "65266255")
    @NotNull(message = "Account number is required")
    @Account(message = "Account number should be 8 digit")
    private String accountNumber;
	
    @Schema(name = "postcode", required = true, description = "Postcode of the property", example="EH14 1UH")
    @NotNull(message = "postcode is required")
    @Postcode(message="Please enter valid post code")
    private String postcode;

    
    @Schema(name = "surname", required = true, description = "Surname should contain alphabets and following characters -'  Maxlength- 35 characters", example = "Smith")
    @NotBlank(message = "surname is required")
    @Surname(message="Surname should be alphabet and Maxlength- 35 characters")
    private String surname;

    @Schema(name = "dob", required = true, description = "Date of birth should be in dd-MM-yyyy format", example = "21-03-1984")
    @NotNull(message = "Date of birth is required")
    @Date(message = "Date of birth should be in dd-MM-yyyy format")
    private String dob;
}