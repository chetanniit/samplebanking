package com.rbs.pbbdhb.coordinator.auth.fourqv.validator;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;

@Service
public class SurnameValidator {

	public void validateSurname(AuthenticationRequest authenticationRequest,
			List<CustomerDetails> borrowers4qvDetailsList, List<String> reasons) {

		boolean isValidSurname = borrowers4qvDetailsList.stream()
				.anyMatch(borrower -> borrower.getSurname().trim().replaceAll("[^a-zA-Z0-9]", "")
						.equalsIgnoreCase(authenticationRequest.getSurname().trim().replaceAll("[^a-zA-Z0-9]", "")));

		if (!isValidSurname) {
			reasons.add(Constants.INVALID_SURNAME);
		}
	}
}
