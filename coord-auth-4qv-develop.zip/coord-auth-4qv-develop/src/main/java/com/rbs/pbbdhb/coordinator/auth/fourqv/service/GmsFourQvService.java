package com.rbs.pbbdhb.coordinator.auth.fourqv.service;

import java.util.List;

import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.*;
import org.springframework.http.ResponseEntity;

public interface GmsFourQvService {
	FourQvValidationResponse validateFourQv(AuthenticationRequest request);
	List<CustomerDetails> fetch4qvByMortNum(String accountNumber);
	FourQvValidationResponse validateFourQvNatWest(AuthenticationRequest request);
	ResponseEntity<MssCustomerDetails> getCustomer(AuthenticationRequest request);

}
