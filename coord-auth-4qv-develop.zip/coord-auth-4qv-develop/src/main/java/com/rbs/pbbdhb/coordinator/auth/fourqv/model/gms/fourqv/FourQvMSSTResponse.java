package com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv;

import java.util.List;

import lombok.Data;

@Data
public class FourQvMSSTResponse {

	List<CustomerDetails> borrowers;
}
