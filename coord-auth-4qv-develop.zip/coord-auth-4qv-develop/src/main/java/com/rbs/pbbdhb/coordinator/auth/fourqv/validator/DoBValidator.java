package com.rbs.pbbdhb.coordinator.auth.fourqv.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.AuthenticationRequest;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv.CustomerDetails;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@Service
public class DoBValidator {
	
	@Value("${date.pattern.erc.input}")
	private String ercDatePattern;

	@Autowired
	private ExceptionHelper exceptionHelper;

	public void validateDOB(AuthenticationRequest authenticationRequest, List<CustomerDetails> borrowers4qvDetailsList,
			List<String> reasons) {

		LocalDate dobFromRequest = getLocalDateDOBFromAuthenticationRequest(authenticationRequest);

		boolean isValidDOB = borrowers4qvDetailsList.stream()
				.anyMatch(borrower -> dobFromRequest.isEqual(getLocalDateDobFrom4QVResponse(borrower.getDob())));

		if (!isValidDOB) {
			reasons.add(Constants.INVALID_DOB);
		}
	}
	
	private LocalDate getLocalDateDOBFromAuthenticationRequest(AuthenticationRequest authenticationRequest) {
		DateTimeFormatter dateTimeFormatterGMS = DateTimeFormatter.ofPattern(ercDatePattern);
		LocalDate dobFromRequest = null;

		try {
			dobFromRequest = LocalDate.parse(authenticationRequest.getDob(), dateTimeFormatterGMS);
			return dobFromRequest;
		} catch (DateTimeParseException e) {
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					Constants.DATE_PARSE_EXCEPTION);
		}
		return dobFromRequest;
	}
	
	private LocalDate getLocalDateDobFrom4QVResponse(String dob) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDate expectedDob = null;
		try {
			expectedDob = LocalDateTime.parse(dob, dateTimeFormatter).toLocalDate();
			return expectedDob;
		} catch (DateTimeParseException e) {
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					Constants.DATE_PARSE_EXCEPTION);
		}
		return expectedDob;
	}
	
	public String getConvertedDate(String date) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		DateTimeFormatter expectedOutput = DateTimeFormatter.ofPattern(ercDatePattern);
		LocalDate expectedDob = null;
		try {
			expectedDob = LocalDateTime.parse(date, dateTimeFormatter).toLocalDate();
		} catch (DateTimeParseException e) {
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					Constants.DATE_PARSE_EXCEPTION);
		}
		return expectedDob.format(expectedOutput);
	}
}
