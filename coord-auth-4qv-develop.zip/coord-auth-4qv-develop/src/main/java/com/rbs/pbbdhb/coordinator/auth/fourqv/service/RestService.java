package com.rbs.pbbdhb.coordinator.auth.fourqv.service;

import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public interface RestService {

	<T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType);
	<T> ResponseEntity<List<T>> exchangeList(String url, HttpMethod method, HttpEntity<?> requestEntity,
			ParameterizedTypeReference<List<T>> responseType);	

}
