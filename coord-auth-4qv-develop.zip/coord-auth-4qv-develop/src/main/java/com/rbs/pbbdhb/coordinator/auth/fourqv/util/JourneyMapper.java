package com.rbs.pbbdhb.coordinator.auth.fourqv.util;

import org.springframework.stereotype.Component;

import com.rbs.pbbdhb.coordinator.auth.fourqv.constant.Constants;
import com.rbs.pbbdhb.coordinator.auth.fourqv.model.CustomThreadLocal;
@Component
public class JourneyMapper {

	public void setJourneyInThreadLocal(String journey){
		if (journey==null || journey.trim().isEmpty()){
			CustomThreadLocal.setKeyValue(Constants.JOURNEY,Constants.JOURNEY_ACQUISITION);
		}else {
			CustomThreadLocal.setKeyValue(Constants.JOURNEY, journey);
		}
	}

	public String getJourneyFromThreadLocal() {
		return (String) (CustomThreadLocal.getValueByKey(Constants.JOURNEY));
	}

	public Boolean isJourneyMSST(){
		return (Constants.MSST).equalsIgnoreCase((String) (CustomThreadLocal.getValueByKey(Constants.JOURNEY)));
	}

	public Boolean isJourneyCST(){
		return (Constants.CST).equalsIgnoreCase((String) (CustomThreadLocal.getValueByKey(Constants.JOURNEY)));
	}

	public Boolean isJourneyMSSTOrCST(){
		return isJourneyMSST() || isJourneyCST();
	}
}
