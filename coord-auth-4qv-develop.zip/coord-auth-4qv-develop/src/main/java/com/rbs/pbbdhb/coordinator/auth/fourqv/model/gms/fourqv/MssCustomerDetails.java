package com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MssCustomerDetails {

	private String foreName;
	private String surName;
	private String postCode;
	private String accountNumber;
	private String dob;
	private String cin;

}