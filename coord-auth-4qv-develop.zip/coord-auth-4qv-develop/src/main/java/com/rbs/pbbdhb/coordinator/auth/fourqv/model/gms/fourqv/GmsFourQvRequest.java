package com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Builder

public class GmsFourQvRequest {

	private String postcode;

	private String surname;
	private String accountNumber;

	private String dob;

}
