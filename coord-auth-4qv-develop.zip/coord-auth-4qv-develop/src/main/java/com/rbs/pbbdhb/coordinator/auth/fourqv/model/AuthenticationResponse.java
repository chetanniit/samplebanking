package com.rbs.pbbdhb.coordinator.auth.fourqv.model;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Builder
public class AuthenticationResponse {
	
	 @Schema(name = "clientId", description = "Customer Unique Id", example="65266255")
	 private String clientId;

	 @Schema(name = "sourceBank", description = "Source bank of the customer", example="MB")
	 private String sourceBank;
	
	 @Schema(name = "mobileNumber", example="9293949598", description = "Mobile number of the customer. Applicable only when channel is 'customer'")
	 private String mobileNumber;
	
	 @JsonIgnore
	 private HttpStatus status;

	 @Schema(name = "remainingAttempts", example="2", description = "Remaining Attempts")
	 private Integer remainingAttempts;

}