package com.rbs.pbbdhb.coordinator.auth.fourqv.model.auth.fourqv;

import java.time.OffsetDateTime;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Builder
public class AccountLoginDetailsRequest {
	
	private String journey;
	
	private String accountNumber;

	private String channel;
    private Integer failedAttempts;
	
	private String status;

	private OffsetDateTime lastLoginDate;
	
	private OffsetDateTime lastModified;

}
