package com.rbs.pbbdhb.coordinator.auth.fourqv.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.pbbdhb.coordinator.auth.fourqv.service.RestService;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;

@Service
public class RestServiceImpl implements RestService {
	private static final Logger LOGGER = LoggerFactory.getLogger(RestServiceImpl.class);

	@Autowired
	@Qualifier("iamJwtChainSecureRestTemplate")
	private RestTemplate iamJwtChainRestTemplate;

	@Autowired
	private ExceptionHelper exceptionHelper;

	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public <T> ResponseEntity<T> exchange(String url, HttpMethod method, @Nullable HttpEntity<?> requestEntity,
			Class<T> responseType) {

		ResponseEntity<T> response = null;
		try {
			response = iamJwtChainRestTemplate.exchange(url, method, requestEntity, responseType);
			return response;
		} catch (RestClientException ex) {

			if (ex instanceof HttpStatusCodeException) {

				String responseBody = ((HttpStatusCodeException) ex).getResponseBodyAsString();
				LOGGER.error("Rest call failed for Url:" + url + "\nErrorDetails:" + responseBody, ex);
				try {

					if (StringUtils.isNotBlank(responseBody)) {
						response = new ResponseEntity<T>(objectMapper
								.readValue(((HttpStatusCodeException) ex).getResponseBodyAsByteArray(), responseType),
								((HttpStatusCodeException) ex).getStatusCode());
					} else {
						response = new ResponseEntity<T>(((HttpStatusCodeException) ex).getStatusCode());
					}
				} catch (Exception e) {
					exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, e, "internal.server.error");
				}
			} else if (ex instanceof ResourceAccessException) {
				exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, ex, HttpStatus.REQUEST_TIMEOUT.value(),
						"request.timed.out");
			} else {
				exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, ex, "internal.server.error");
			}
		}
		return response;
	}
	
	@Override
	public <T> ResponseEntity<List<T>> exchangeList(String url, HttpMethod method,
			@Nullable HttpEntity<?> requestEntity, ParameterizedTypeReference<List<T>> responseType) {
		return iamJwtChainRestTemplate.exchange(url, method, requestEntity, responseType);
	}
}
