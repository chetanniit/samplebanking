package com.rbs.pbbdhb.coordinator.auth.fourqv.model.gms.fourqv;

import lombok.Data;

@Data
public class CustomerDetails {

	private String surname;
	private String dob;
	private String postCode;
	private String clientId;
}

