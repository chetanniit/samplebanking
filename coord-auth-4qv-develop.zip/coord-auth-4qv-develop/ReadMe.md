# coord-auth-4qv

This is a Spring-Boot micro-service acts as underlying service.

### cord-auth-4qv has following resources :
	POST 	https://${hostname}/mortgages/v1/hlpr-auth-4qv/authenticate
	This API authenticate customer 4QV details and returns 	Customer Unique id, Source Bank and masked Mobile 	Number(In case of 	 	customer channel).

### Underlying services :

a)hlpr-auth-4qv : following endpoint are used

	1)POST  /account-login
	2)PUT /account-login/{channel}/{accountNumber} (Put request)
	3)GET /account-login/{channel}/{accountNumber} (Get request)

b)msvc-int-gms-4qv microservice has following resources :
 	
 	1) POST /account-4qv 
 	

### Running Tests

`mvn clean test` or `mvn clean install` to verify test coverage

### Running Server Locally

By default, the server is configured to run profile **_local_**. So please update password for
**jasypt.encryptor.password=**
and run the server with following command

`mvn clean spring-boot:run` or run the task `spring-boot:run` from IDE

### Build Jobs

[TeamCity Url](https://teamcity-4.dts.fm.rbsgrp.net/project.html?projectId=AgileMarkets_DigitalHomeBuying_JavaArchetype_CoordAuth4qv&tab=projectOverview)

### Swagger Url

[SIT Swagger Url](https://v1-coord-auth-4qv-sit.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/coord-auth-4qv/swagger-ui/)

