
# User guide

Tomcat/Vertx template project provides a working Spring Boot Tomcat application that offers the following functionality:

- Example of how to use Consul to store application configuration settings and the required Consul bootstrap config.

- Example of how to handle encrypted properties.

- CRUD operations: allow to create/read/update/delete a sample resource represented by  'Resource' class.

- Unique  correlation Id / request Id during the whole request processing (logging can make use of it)

    - if the incoming request contains a correlation Id header, the requestId is set to this value
    - The requestId/correlationId is then added in the response correlation header
   
- Endpoints documented and operational via Swagger.


## Overview

The archetypes are generated from template projects. These templates are basically working examples of Spring Boot based applications 
using Tomcat (sync/blocking model) and Vertx (async/non-blocking model) respectively.

Both templates use similar package structure:

    -/configuration - all property and configuration classes
    -/request 
     /controller - all app controllers
     /service - all services
     /client - clients to external apis, dbs etc
    -/helper - any helper classes, for example json parsers, etc
    -/domain - domain objects, enums etc
    -/exception
    -/server - any new filters/interceptors for tomcat, and handlers for vertx
  
### Application Config Properties
  
- Configuration properties are stored in Consul. The Consul details for the app folder are specified in `bootstrap.properties`.

- Encryption properties for all Spring managed property sources (other than bootstrap.properties) can be specified in `application.properties` for testing
 and ideally passed as system properties or vm parameters when deploying the actual app.
 
- `https://ecomm/ui/#/corenet-prd/kv/application/deng/dev/` - endpoint for consul. Click on this link

- Press on reset tokens. Put this consul readonly token there - `18c3b32d-de91-99ac-a5c3-035c72b62784` and then press
 cancel. 
 
- Then type the same endpoint again on same browser window in address bar - `https://ecomm/ui/#/corenet-prd/kv/application/deng/dev/`

- You will be able to see different config's

```
dev/dws-vertx-archetype-sample: Configuration to store any properties required by Vertx Archetype template project`
{
  "server.context.root": "/app",
  "server.http.port": 8080,
  "server.timeout" : 120000,
  "request.correlation.id.header": "x-correlationId"
}
```

```
dev/dws-tomcat-archetype-sample: Configuration to store any properties required by Tomcat Archetype template project

{
  "server.port" : 8080,
  "server.servlet.context-path" : "/app",
  "request.correlation.id.header": "x-correlationId",
  "secret.test.property" : "ENC(Hv+XGgRgJ1O1mUZKuWBAhCDDwoJ+vyQ89ydXGNLfp4o=)",
  "des.tomcat.valves.filter.request-correlation-id-enabled":"true",
  "des.tomcat.valves.filter.request-correlation-id-header-name":"x-correlation-id"
}
```

## Maven Requirements

- a maven `<repository>` for the dws Artifactory repo at https://artifactory.server.rbsgrp.net/artifactory/dws-all-repos 
    - this is needed to to fetch the dws artifacts (parent poms, dws spring boot starters and dws libs) 
    - alternatively you can mirror it in your custom Artifactory location and you won't need the additional `<repository>`
- if you generate the project via `mvn archetype:generate`, then you need to setup maven so that it fetches the archetype catalog from https://artifactory.server.rbsgrp.net/artifactory/dws-all-repos/archetype-catalog.xml

## How to generate a project via mvn command line

If you are a zambezi user then just upgrade to the latest zambezi dev tools which will setup the correct maven settings for you:

    devtools app maven

Or change your maven settings file at `~/.m2/settings.xml` as shown in 
[sample-settings.xml](https://stash.dts.fm.rbsgrp.net/projects/DWS/repos/dws-spring-boot-tomcat-archetype-template/browse/sample-settings.xml) 

If you are not a zambezi user, you'll need to create/edit your settings.xml file according to the maven requirements. 
You can use the same `sample-settings.xml` file as a template. 
If you don't want to use the zambezi repositories, just remove repository called `zambezi-all-repos`
from the `<repositories>`, `<pluginRepositories>` and leave `*` in the `<mirrorOf>` tag.

Then execute the following command:

#### Interactive Mode:

```
mvn archetype:generate
```

Select `dws-spring-boot-[tomcat|vertx]-archetype` from the list and specify the requested parameters. For example:

* groupId: `com.rbs.example`
* artifactId: `my-app`
* version: `1.0.0-SNAPSHOT`
* package: `com.rbs.example.myapp`

Make sure you configured maven so that it fetches the archetype catalog as described on the Maven Requirements section above,
as otherwise the dws archetypes won't show up in the list.

#### Non-Interactive mode 

In the non-interactive mode you need to provide on the command line all the required parameters to generate the project. For example:
 
```
mvn archetype:generate -B -DarchetypeGroupId=com.rbs.dws.archetype -DarchetypeArtifactId=dws-springboot-tomcat-archetype -DarchetypeVersion=1.0.0 -DgroupId=DES -Dversion=1.0.0-SNAPSHOT -Dpackage=com.des.my-app -DartifactId=dws-my-app 
```

## Changes on the pom.xml

Once you have created your project from the archetype, you need to setup a couple of things.

In order to publish your artifact to your custom Artifactory location, you need to update the `artifactory.releases.url` 
and `artifactory.snapshots.url` properties in `pom.xml`. These will be used by the dws parent pom to setup the `<distributionmanagement>`
of your maven project. 

For example:

```
<properties>
    <artifactory.releases.url>https://artifactory.server.rbsgrp.net/artifactory/dws-libs-releases-local</artifactory.releases.url>
    <artifactory.snapshots.url>https://artifactory.server.rbsgrp.net/artifactory/dws-libs-snapshots-local</artifactory.snapshots.url>
</properties>
```
 
Also you need to set the SCM tag in `pom.xml`

#### Note for zambezi users:

Make sure you change the `.teamcity.json` file so that it refers to the right `build_name`s: 
rename `deploy-dws` to `deploy` and `release-dws` to `release`. 

## Setting up your IDE

The code in the libraries included by the dws starter uses Lombok, so you need to install the IntelliJ Lombok plugin in order to compile your project.

# Archetype Developer Guide

The archetype is generated from a template project which can be built, tested, executed and released just like any other projects.
The steps usually are:

1) making changes to the archetype template
2) creating the archetype from the archetype template via the `mvn archetype:create-from-project` command
3) creating a project from the archetype via the `mvn archetype:generate` command


## How to modify the archetype for local testing

1. Make any required changes in the `dws-spring-boot-tomcat-archetype-template` project and make sure it works (unit tests pass, etc)

2. Open a cmd window / terminal, move to the `dws-spring-boot-tomcat-archetype-template` directory and execute the following command:

    `mvn archetype:create-from-project`

3. To install the updated archetype **locally**, navigate to `./target/generated-sources/archetype` and run:

    `mvn install`

    This will install the archetype jar in the local mvn repository and will add an entry in the local `archetype-catalog.xml`.

4. Now you can test the new archetype with a:

    `mvn archetype:generate -DarchetypeCatalog=local`
    
    Which will let you choose the archetype just generated at 3.


## Publishing a new version of the archetype

After you pushed your changes to the archetype template project, you can trigger new snapshot builds and release builds on Teamcity:

https://teamcity-4.dts.fm.rbsgrp.net/project.html?projectId=AgileMarkets_DesWebServices_Java_DwsSpringBootTomcatArchetypeTemplate&tab=projectOverview

First use the `release` build plan to release the archetype template, this will create a new tag.

Then use `release-archetype` build plan which will expect the git tag as a parameter like - `dws-spring-boot-tomcat-archetype-template-1.0.2`.
This build plan will: 

1. generate the archetype from the project via the `mvn archetype:create-from-project` command
2. push the generated archetype code to the stash project containing the archetype itself: https://stash.dts.fm.rbsgrp.net/projects/DWS/repos/dws-spring-boot-tomcat-archetype/browse
3. update the `archetype-catalog.xml` file on Artifactory, at https://artifactory.server.rbsgrp.net/artifactory/dws-libs-releases-local/archetype-catalog.xml so that it can be consumed from the users


