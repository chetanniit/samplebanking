SET DEFINE OFF;
DECLARE
      str varchar2(32767);
    BEGIN
-- insert Napoli Header Template in TEMPLATE table

      str := '<div class="emailTemplateHeaderContainer" style="margin: 0 auto; padding: 8px 0; padding: 0.75em 0; padding: 0.5rem 0; width: 100%; color: white; background: #42145F; border: 0; text-align: center;">
    <img class="emailTemplateHeaderLogo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAABaCAIAAAAJsExNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACdKSURBVHhe7VwFWFXJ+z4YCyoGYd1A1wBz11gVaZRUUEK6MUBCEVQUFVTs7u5ce621O2m7BddauxXb/zszl8PhEiLr35/Pfc73vM9hmPNNnJl3vvlm5pzLtdMNECFCZSASWoRKQSS0CJWCSGgRKgWR0CJUCiKhRagUREKLUCmIhBahUhAJLUKlIBJahEpBJLQIlYJIaBEqBZHQIlQKIqFFqBREQotQKYiEFqFSEAktQqUgElqESkEktAiVgkhoESoFkdAiVAoioUWoFP5fCG2hG2imG2haJKBgqRuolFCEiP+I709osLmDto9XFTevKu5FwKOKe3tdf8t8yUWI+C/4zoQ21w2w0fGdp2GWrtY4qVSTwpBcqumJUg0HVLAy1Q1SykGEiP+C70xok6pBURU7nVFrksnpX+EM8gGRBJe4+uc4+Y7SDVy13OF7KGUiQkSJ8T0JDWo6aPtsLGt4nTO4wBlc5BoIcYGAxAMZXJ0TnDyDk40rZ2qp62+ho5yVCBElw3cjNLxhLPUSKthdVGt0iTM4XwChFWw+y+kncbWOcfIUTrqvVL3gyp2RUCk3ESJKhu9GaBPdIFctzwOlW1zj9POzGeAJncbVOc7JYaFPcHow0vPUW9nq+Jr/Z06bVfYxVHc31PAgUHc3Ku9pqe2vpFMgTCvRhDRtG3V3Y00vJYXvBUudAAstP+MKXkYVlIuw1PFHpLD+UIO+khoP3OWVUWcTTW8lBR4osS3NkGWLsLmWX/uqymr/K6CP0P7oLPMqvkq3SobvQ2iYZxPdwKnl2mcSyhLvokA2I3CGq3eS0+MJnczJj6n9GqVph/GglGfxATYAPi37xvtPG+w7BUAgymGkVfUgC20/JWUhkMpC2z/AcMAQ/6ks4dCg6T2th1pVC8ItJeX/ArAKnCO0qxrQwzK+N+pWLZAvAnWwlXSNchwVT6sxyGdKQuC00PYJqH/+arCYkHbxCQHToAn9hMDpwSZxiIfzJtQE8PgOtUP6u41nOQ/xmxLnPcm1Ua/vxZ4SA7UFjzEszar4uhhExjiPcWvcG62kpFYCfB9Cg47dKrtkqDXFgu98PjYDvHlO5WpTKstBaxAaSONka8r+7qjtZVZSTmOUo4emDVj+4f3H7Fdv37zKfvf2/cO7TwZ4TGxbzlNJWQgkRIMuGLEO+tlv3r15+fbTp8971h6zl3f/jl2OUsBXDJtxkQsObDr55P6zA38lgdB8/5lV9u1YO2T/ppPv3314g/q/fPvxw8fjO9Od6odj2uHz4ZUdfg1NPXAWD/vmZTb0P374tH/jSVtpN5jePMo6AaYVfWKcxjx9+BwPCE1c72Te69VxRNvyRTXL/zcw8NpXDXTWD0fdVk/bduX0jbtZ96McRhUxzxQf34HQ5roB1tp+q9SNb3D14WwUYZ5Pc/V4NjPAVJ8kqDWkQjsQumTb0ozQs+NXf8krqQfPda4XZlZJmRM8CKEr+y4Zu1GRgMrBzcl2sm7fi9DMFE2KWXLz6r8f3n1gRYDQ6FGe0KgGjPSf07ezu0xuZ94LaBNrUlG5jxETZBz37NELhR6Vf28+9GoWjYKEmqRZtPwm912iUKJyMT0TU5lppe9AnRIDoxSPcHR7+stnr1mtnj96GdlhxM9CaDPdwOhKjufUGl0ma0HeGBPHgwEsp9BP4WoxZ4MnNDPSqZxsa+mGblpuJXM8GKFnDVnFWgfy+fNnXD99/DRv2BowAHRRSsLACL1o9AZhKli770loWsSu1UeUihASGsBMMjZiwYf3hPFMB50d6z4BzBN60hgeyG1U6JyPHz+R7KBMrzDtcZ6TQGihMvJHKWtm/E1VaKbs6aTdvsvkXkLokDGJyfP1y2xaIyKP7j37WQgNNmMtuLNMq9tc/Wtcg2ucwfUcwJ/mcZ3TzyBrQZmShWachpFO5+STyxlb6BB3XKmIryI/oSGMFg/uPO5uMcS0kJb6YYTetuwgzT+3CCVCw5vs02nU/VuP+GqA3DMGrYCJRQ68GnxipNo0fw+vRgPkumTsJtPKPsKhi0eA73R0exrVIUq4Lhv/FwykMM8fDUpouPVskmEVe3z/5yA0yAdCx1TueFDjt30azXZrtNil8ceOcq3+1mi9XaP1No0228q12aJhuKmc0d/qf8CvOEkInUtlHjDbqZz8qFodnyouplW/2UgXRmjWWLvXHMXqyrxyAQT9wYTmJT+h4Rd5t4g5n3INd1k1IJsX7WMbI7waauVYJ/Rc0hWhGgsc25EO0yusNgy2d/OYK6eymBrk1YvsUT3nKnkmPxp5Cc3kZyE0YKEb6K7rNqKG2Wipaby0fZzUtp+0Q5TMMVzmFCpz6SZ3C5R7euv5BMg8V5VrnsFJmI8hZDP+BaHTOemGsk0dyNLwm/fviib0m9dvE3vMptOxsln6JkITbmn7Qd+0ItmvUKCiN3IG5wrcYqMV84P+tqUHWBFM9m04QZ0HYikBmFVkayPpun/jCdzla56y/2ynuj2FNUFxPa2HYtphaiSvnEDWpdtwTFFWrrKmd2+HkfduPmRqkAd3noTbDcdKkdfJBR05eBYUQR6qojfKRd2U1QoBHoc8aU5yAE+kNL0wNQstf2NNr36u45QIHWGfyHZaWYMUv2gl/FdCszfmwqp1mCwxHCU1GyptN0hq019mRzgtdwqRu3bTcwvU8/TU8+1bzfFwqbrJdLdOidCIhHmOqNTB+Dv50EwoMUhnX0i95vtHP5N8G8xIWBxCoxtIJ2l6W1ULcqzT07VhpFfzaH/DWP82/T1+7+NUP9y6RjDuEoIKxwylOEu7ZfF+VgQTEJpYaEER6EKUuHjMxk+fiHPMapJ58XZ388E8/5AVqDAuEq72R16HD7x59TY+YBpcFz5PhEeHzX3ziriqTOdi2nW3xr2VLDSyRQyUbWoG41m6NOnt8VsUnrFj7RBwFM8lnCLyA22IB0QOaDRn/Qg3JG9KkmM5jhnDrIov2ZvLOz1Cv6/L2CcPn5PaU4EPHW4zzKjCd9h7+Q6LQnPdQEddr1E1TKZJWo+WmA6XWg6RWg+Q2EVLHSJlncNkLj3kXYL1iJ2eXdEojfrQPKcRwL/wN2art2mPUZ4v8+IgP6HRf9RfpX/pv6umboOmkKYs4VcJjf62rh4UaDRwRI/Zq6duO7gl5czJy9fP3bx17V/g6pl/kvefXTdrZ0LANJeGkehX5sWaa/mCHDPiViwd/9eCEesuZSjmfVrCl+vnby0ZuxHlgsEA/NpeHUcg7dDgGUL+PX30cpDPFNgtVhMQC8Ng/ZydTEEoJNMvX5aO24Tasq13PBoyRObsFtPZu+640o4kwhiHbo17oeh1c3Yl7T0D0l85nXXmxGWMupmDVvawGIKRqcRIHkiOWvm17j+hz6Jtyw+mHjh7Mf365VNZZ09eOb4zAy7T9IErop1GOxtEoFlQsX5u41FJNMiOlYcxc7K6QbBA3Lp0//zha1mDQGdyzBIHMqIKLrcIlJzQFtSBBptxNdYJ7FrNYaak5SRJ29FSk2FSy0FSK9jpaHnH3rJOYXJncNqvlleExHlPGf0U6kkzTuOaysn2lNIPqOxsrBsMB8ZCh+CbloYFEpoPsDBm2yiHkTw5+IRfJTTMRnTn0SAu24IoTGAgk/aejnUbj4SYamGEAgxjH9wmizwmrCZMFFECQR0wgXQzHyx0Jz59+jxj4Ar+WBEEBTPghzAFPh8+fGRbaqd6YSAolMEz25pdwRumQBW/LBqzoV3VXKccfoV1jSAM1FNHL7zLfsd0lOTmlbsLEtfB8zHO5+CygjBjgMGfPxXwUEyePHh+eEuKV7NoND4bjUz4avMBoWSev+XeNArzg7DE4qCEhAaP7bR9nLS8Omt7OWl7OWp7u2h7jqlmvKB68+k1Wk+sYTS6hlliDcsEiVU/qX1vmSPP6clVzJJzbTMCxDxPKGdipetno+tnp+tjr+Njp4vH8C/+6/8FEvrpwxfZr4gN4Fvr8LYUW2lX0EKY8KuENlR3nxC1kClASG75RHEPnXf/2cjQOegGzLP+bWLvZN1X3MibUBElkIWj1oFe4OuZE5fwL6/z14I97XOOYJBtV9NB/E4I5NWLN2/fvGNhRN66/m9A2wHs6B6rTNeGvdIOnmfKuMKZGd5tJkqBFQetMeQ61Q3bMG83csBdJiwrXhSxtE2c9MNNBP4MpiCMW9ja7NeK5Io0AkEcu4XREmmf2Kas+9pZO1gMJEcnNyCUK6dvwHtBJfkSi4mSENpMN6CTttcadZPDpVvuLdNqX5lWuO4u0/pImWYpZRsll22cVLbJybJN0so0nallGSPr0F9q30fWKULmBH+6p9Rlk3oTWGW2f4fA7rIGA6vZ9JI4DKhpE1/DMrGm6TTd1sM0LawwexaP0/kJDTm0OXnTArq9RZsMAbieoKZxBU/SozkJv05oDY8x4fP4fd8ChfYIEYRfPnvdq8OI1mW6BLSJvUfJx0ShQUURJZBFo9ZbaPnaSbtupctHXg0+AKwj2Ik6o6qwpu/fvacpvrx//2HPumPnk68izJTBrYTAaYQEOgFG5b0C2w64de0ef/fRvac9bYYxJxujGg7urj+PIp4pMB0lEcbDA+GbBZXBsEnsPusdHQw5agXkwOT5k5dhNsPa/OK+fs4uRRQVljm7KgmcOvemP4TQcAbg6Y6uYH2D08/i6l/n9Hlc4QwucQ0ucwZAFqefXLpZeE23UJnzYIl1rNQ+WubAOD1Sp/0xtV+T6BlhEldrdhXDATLbRKnleInJdEnruZLmOzXrHVar26OSYzHPWQokNPxFzOCXMzIRpg1OWg0TqF+r3NVhMQk9rtcCpvA2+939248zL9y6mJ55PvUaplrY4A8fFEs0Jgij7+Ev+rTsm3XpNkj26vmb9+8+KG5TgfcC44p4cqVWdt7QNawy7CmQDdQQ+OfyXe+WMWAhM9J/Tt/O4iEvnr0eGTJnyxKy3GSRcFGWjvvLrIofHFbM732dx7KjOHYXzjE9TfRGQaaVyIH/JzpKcVeR/OMnrArOJV05l3z17o0HiCGRnxR3IVP7L8Mij2z1VPHFMDt3UrF7yCsgVcbhC/CeUw+eR+Mw9wmCJyWEVnfHSoY0yIs3mDw/0qxxF1fMHtmvsl8+f80aBDoYqD/IQpvqBvpV6XK0dDP2Vp3wRDDnjNDgIuF0g/Fadl1qBQTJPQZKbeOlVrFwqaUdI+Sdw6VOK8u3SKHmeYt6o8E1bQbLrEdKzCdKjEDo5TpND5eufYqTLfmlpXXx3sIrkNCHtqRgMZfYY9bbbGLS+GbfOG83kmC6ZAm/SmiYOpgiLJLWzt45JmJ+n85jgowGev7ex61xb+/mMT2th04fsBxzPUvOcnh453GwSZytpGuc9yTYVKwXUw6cIwXkyNmky8hzePCMxG4zgVE957C3i8DCgZ6T+Arj+uLpq2inMXSjwMexTmjy/jP8rduZ94KN46b0W/pRMaJwgRudZifrjoeCDZ4UsxgDidc/tIUc6YOLcF2wBn187xm7xe7C08UsgSWgS4NI10aReK51s3e+fvlGqAOrifUfcoY/3c9l3OsXirvkSt+BCW2fAKLby7o7/hrq3SIGNZ83bE364fP3bj6K7DCibTmPHpbxGIRokOUTNoPlSMjkxdPXC0eui/efyhoEblus+wTUlnf3i49vIzToZaXjN0/DnL7CT0gsfGeDAZHXOIMdGq395N5ech9/uVcvWafhEktweoDMLkbWMUzuFF/N5kipuimc3kRdMxB9mMRyrMRkiqTN3BrNd5Srz4x3Mlern6a1SUkJfXhrCloELIGpZjGs6V8+fR3rNgFDH7eKQ2jouBhEeDSNQhjEAhvQowAYhiv+bfOL29jwebArfA4w5CNDZqMI6BuV84TC5oX7SAE5AlcBCdtqeECBATxD/kgCL5l53iwrMBJ20bQi2d8NtUq4fT3XhTi+KwNuQ7jt8GePX/KRmD0wNpAhqr125g7hWm3lpK1wXdhKTsmxQQ5wr3GL1KQy0cHQstQJWDx247u3uaMLJnz6wOWoKmatidGLEMPfevboRUi7+FZl3dCeaDpcAfAeTeTaMHKAxwTPZtEsHkW0LusW1WnU0zzbdk9D2iW0KtOFtQbAOoh1wTfh2whtrBvUs1LnjFJN2Ft1+QmNyEucwVm1xgm6Dm61/ALknkF6nlgOxkvbj61pOkzaLk5q3VdmD4ovq/DHBo0mA6R2IPpIqdlESdvpklartRsdV6sFNh/n9NI56dbSDTtpe371qKUwQjvUDmmj7hZmPZQdLtDuI62fdvCcS4MItHVxCA3AnGMthamWzLaViYXj2x34o7SrU/3wq2dv8jngOmvwKpY/K+KrJ4UM0Oxcr+dp4brw82dMKfATwH7YrTc5y1xcl9JDbKz84P/gX0zguMLsxQdOA2OsawQd+5scekMbl48fPo0Jn4+nAFG8W/S9Qz0Knu4rJ2+FTyx8ZACOmVP9sFQ6t6BEVuiR7amYAdqUdZsUvZgmVVQm+/VbrDTIm9kV82zG4/HJsBewE+ME//4UJ4Uwz/Y6vn/+YpTJ6fOvHwnZzGJgvNeUN/GR+/jKvYLlHt3kbiFyl0hZJ/jQUTLH3jLHXjJH/Dugpl1CDas4mU2ixHKcxHiqpPW8Gs32/lIH5pmtF0/Q1/9Hljcz1yHnkUqVEaIIQqM1Yd7mxK9mqzrW+uj72QmrwQYwtTiEBvBv23KesHAOv4a6N40CJ3z/6Mfg+Xs0jNPVMzf4HCDzhq8tAaExYFCl7SsOQQc5sdxS9p+F7wQSrJlOXjNiJWBFOMRvCsw/HJttyxTmltygRIcFhV28di53jMF1ibAbjirhqYcGz2ArS3YLK1csNlqVdiVtJQCZfNQ9pg9cIVTOunA70GgglncDvSZn51kRfnn071P4P53rh8G6Iy0enH+uPLb25yE0lmhxmh3Oc+QLK+ooF8Dmq5xBUunfY6o7e+n5wDZ3k7uHyl3DZM70sNDPV+4NlxoGO0LWGfyGs5EgaT9aYjZZ0nampOWGyg2S6DkLYzOMdBon21uqvl8VZ9Mi3ywtgtAgEwjtbBBxcvcpEpvT+nBA4c+h6b9KaHQGOsBe3r2vyzhYsqS9Z66fv3U36z54oMDNhw9uP36X/Z4lZwLfEZz4VkKjLNR25qCV/HIN138u38GY6VgrJHlfrgN98+pdtkNnUsl7Yl5jeWxHevtqgXBnH955wkfeuHQbkxIeBA7DEnragnh261J6ZleTuC6NemFhoAQkwbSA1SfUmDy5/6xfl3GwxMIBw4SFTx+/PC12OcY5Ria1+vmc4J+E0KCUk5bXrjKt4B8z7uYnNK5XuQZzK7XzkXuDwdQ2u0bQA3AfPW/G5u7yLmFyZ5jqWKn9EKl1osRivMR4mqT14mq/HSxDtj4YoflDxHRONlPd0Bqmq3AjXTShGSNj3cYzp401PQSGzaZmVzT6olGFEho5w6nobjFk95pjWDYxtQIFKfmcISUmNCaBfq551lsvn77q7TASFMHSCv8y1+Lodiz+SCVRvQj7xOcCN/pu1gOwbYj/NLjyfCRaw6ZmMDlF1wlgL5Ygnt2Cl3I5I+ti+nUwWwkXUq9hOLGTdiZv37wbFjwDMwC8F6yG8+/wQODeXD19Y/nELWE2w6xrBqPxMfPkPubPQGhYR2PdgLHlra8R4hLznB/wnsH1Q2VbRNTs4q3n3VXuDh7DNkfInAL0vLzlPvCnERkqd+kl6xwj7RAntRkmaTdGYjpZYji7Rout5fWFbOZPXpI52SG1uj0rOhTxCx5FExoKsBNW1YPW5ezqs6ZHRw4Nmt66bJfCLDS8PXRblOOoK6dzDq4FnVegMDVIyQgNIJXnb31uZ+auC1Hq6PB5WPXnbFmQuCVjN4HKZABU9nXWD7+YptidxBVzRW/HUXAViB6ERmJ5RxYAdPv50JYUGk3ihXUuXKClUPv44SN8ZTazddDrsX7OrndvFQeoRIkK+xfy4M7jjfN3wx9DY5pr5bhwPwOhsSzzq9IlqdTvoOw5uiunBBAafsgltYYTtWxgjOE6wxL3lDlHyjoH6nl00fP30PP1reUdVMstRM8lUt4pRtYhTmY9XGYxVmo0RdJquU7To6VqJ9HTFsZmHuA0HI/lvzR31PYqzEh/ldAAGtGnRd/r53NnSQTOJV/tXC9s7tA/aQpF7/KExvom2CTuxqU7/F2mUJgI75aY0Bh74NyJXRlQ40tcNXXb4jEb+TUcVmBx3pNBaOgjfzza3zluN7l++rxg5PoNc3fTGBIFoz7Ef6oRfUkIrsvxnen8LVxxt5iAPk9oFI0HhCcGB+nmVbJrSXKjGTJhMZBb1+9N7rvEqlqgwv34nxPakvwInf98dZPrXN0zXH3gbD4g8gpXb4fGH8EyjwC6rQFLDNscI3HsV90JLnX/6p3jqjvEV+swvJrt6KpWE6paTqtqOrtq24W6fyzXabZLnWzVCc2zkND0/KX2QE3rwox0cQgNY2as6U1P2hRbs6zNZw1ehalTQQX6hxEaszOM+uZFZLuNKhNBGIvLK6duwE+FGsPedcdR1nPSPbm9WGJC05d4/FdP3cY0WaGnj188m3QFIVbPO1n3PX7vg/yhj8mzbXnPSTGLc9xuooCBKjxBhLPU1WQQFrVoJZjVo3T3g91i128StCEWo6y2eDRUw79N7LJxf/1z5a5Cg2bLhP2LNodjbaJJppT//S6HBWXDhHImp/KxTQg4u3+XbRQhcQ7WI34F2NxL1imupt1e9Zbn1BqfLtWEQI1eSzU+o8bQ6Kxaw7NqjdK5uozNBREabJYfUavTq6L9fyE0gDBoBDLhLpqaNffdGw9P7DrF2MCMEBTsZN1hhLqbD2ZuK2weU8ZSbGzkAvemUTY1glEoIx+6BwWxl+55KTGhYcDalvMY1XMuK5EU/PkzvAhwggZJ8sPbUq2rB2HVxZKAByGW8fxuNOTD+w85+iQB/GPXhr1QHySxqha0h27M83cf/vtkz9pjO1cd2fXn0aKxe+2xrUsPYDHNxhIDHhAVwHQBL3/WkNUYS2zrmi8CQkq5+6Sn9VDMEuDS/5jQAFwOJ22PzaUbp3FS9lFggUjl5HMrGobIXbDs6y3rFCPt2E9mv6iK0SWu4TVyMN7gsgLkbBy4RDetgXOcfnIhnxsCqZxshkZbGx3fwjbvikloAA0Klw7LJijwbY2VzSdwmU6++JcQWtoNfYa5Vfjm8ctnr7Hkb6vhblqJvCLM2EwJ7eX4a+jZJGIReSk5ocn3hR7htsOe0jUorSMpnYVZYE7Cn2aCd6+Rf8daPc7RCijps/CBjUngMaszOM2+MuTvXki7Dq8dS0YY768CQ719tQJ6gdCUvBHu694kCib84OZk+EV8KRCE18z8m+zl01cRf4ZFYVBsBWtM/XRnLdeC8uQDHZM5+YHS9eKr2YTJnaKlHWNldgNltsNrWu5Rb3Yld/motDdCIuGFn8ox0sI8KZvlu0sZ+Fd2LuK9juITGj0Kns0ZuoZ3PJgya3Se0Lb0M9IFI9YxBXbFkt+7RUz+rwTALRR0hr7YwMt/ITT62/P3PuzTKVqvXEHM6xdv+nQaJfx5BrAEfNpIPzRUSsJilk/cDCcBOrQyPpP7LhVuCz6484S9OUQYXzjgAVOQXSNWLh/gwZoX9Qf1p/Rf+pRSlq9J6oFzTvXD0Br/e0ID5FRF22dF2WZYolFTmstmJf6tKt8ctrmvzD5OapsgaY+V33wdw9OlFL8PRulbAKeBFK42+4o2J0ME5ChuTDlTVKCIs5XiExpg29LJ+8hbxXzn0xSKDlYQWttv4cj14Dgffz7lmlfzaHSGUoaGGu7gX+bFWySLHCma0Ps2nEBCsESYDw8YUdjLI9tSoQnPiCUhQqtxOSPT8/do4biCVwoHaWz4fOHXLry8ff0OU01bDQ+irENWcqAv2+ZjAxj6WHTCZ8jfVgwgLqoEtqGRBZHE1UFuIDEfmXOLOBV48K30xIcVgevlU1kev/XBLULoLgpCs1uP7j2LsEv8oYQGTKoGhVZyOKxWJ4VymqdyDv8I4O8eVas9Wdukv9w+XmqVKLEYIzGdIDHaVaHpVQWhCYPzEloRg8UlPfRWODAIwC/fXLrRV3+h9JsIjeZG5w3wmMg3KGtTFsaVuRxmlXwmRC36+CGXIi+evR7iP7VV6S7Ik1kssArugWvDyL0bTkCTzweiROjtOYRmOikHzmHiNipPzh1Qc6xWYTgFNQww1vRaOXkrlHNzzEm7Y9Vh8otQeQcDCB1qlcDeVs2biOydRdon8uPQrApZF6YeIOOZ+llEGfwe0WMOqoH1JWoL+jKrjEZAzoB1jeAB7hOCjONwF9Uz1yKuxaQ+i7AcRP0xXVC6E5cGzYsrijOt6L1hHt1pyanSxbRr5J19+r0Wb6HZrRdPX8W6T2hd1g25IR8ooAXyzwDFwTcQGqvDdjr+0zTaplHbqURogHEadN/+S8PhNdsPk5Jt5ok1jaZKWk/UMT5Win9Br2AjjUAa9ysjNB0wsjROr5+mjSnZZlGujBDfRGgAHYbGWjuTbkuTPlUwgAVAaHtZN+PyXpgEhSstBGBjYpzHgBCgo62kG7oHXvWV0+TQm6mxAERIaHTh5oV7WTzTQf+NjZgPzxsjB5XEcsqtcW9St5wvbTHkyOeAgl+uYPKRvB60AqOIqfEwr0w/ZmHvXQiN+pcvlzIyMeRQGaZJzKem97jIBbzXwaoET2b5hM1dTeMc6/SEww1N8omhfnhg2wEjQ+Yc2pL6+mX2sOAZ1HUhZj6gTeyjf59iCK2dtbOf6zjPZtFwrzEGwGPzyr72su7Du818fO+psIgDfyUhHj2F5DFOY57cV7zux6771h/HzGMv7w50adwbbWIj6VoCTn8DoQFT3SDfyq67ShnAE2D0zc9pusumt7RSSzgb4yXGM2q2mlSjtVvVLonl7TIpaws6ZVR4HfSHSZEJ4fQpTrqqbHMb7a+/QfqthAbgeMC68C9g8M2KK7HQsm7odcc6oUdyftSCCcJPH7449nf63ysOoQMupWe+z7uiZ2EIT2iUBf4tGr2R3eTVnj95lXLgLMo6uj31n8t3UHlo8tM3xkCE3fCHd8nZtVBAghjnsaA7U+NBWkDLb93s3A+ceAGNYF/RPrwywiAN4pkCXyXIvzfJng8mge3LD+5Zeww1vJ11n72eCmEfODJCg3D3c153fvMqG0N9/6aTG+fuXjlp67pZO45uT+NfxWaZY/xgxkPNwVEkDzaJ418qVCh8+nz17I0Dm5NQsbMnryTtPfMj3oeGpUSFRpUzS6HEPS6gMg9wEY7HvtL1plY3nCw1nFOjeXRVKzPdAAdt7+1lWxf23mmOkTbI4OrCPGN9eUStbkglx+J8B14CQiMJmhVWUPh6JLsyQhNDUtEH86CwY5SMHxMSnTcAERIas+cAz4mwyoinuRBharwsGr0eDSsktGujXhfTruMWU2bXSxlZbk2jCvwhL5QyOnye8OeIIGDJsvF/kZzzuSiBRgMxIJkarZFylZQEtFYmtOB7nAJFmO2J3afIpze0O9C2HeTdT+wmh0fM7eHVeLl+/iYh9Ld71d9GaADurIuW+8bSTdLJFh4xyflA7Cs4vaFCo9mSluOrGzrrepjpBBrpBsVUdDzPNaTvNhFO54XCSNMtvNqpnGy6uqHF196zY2CEnjmYEJo2DLkc3lIUoQH4ajBd+zawbWkqufvQhNCgF3gwc9BKfupXqOEvCZN/WTzma0Bxk4qQ0MgKNTm0lRw4Q5iaQEjkgpHrhIRGteGN7F5DPpHKVSIO9BFibvljZAEwBnpYxt/NOTNnSd5lfxjRg7yZjcyFyvgXxhKrw1NHL9KMFY/DJF8Mi/gS7z+Ndzl8W/V7RD0KiEIrRw2iiMiJgv0OaZfATywoHTnAgeGtiZIg8sqprB/0xQqMNJzamIq2pzjZGa7mqUJwmquZwUnXazcIrd6BHM2gX3UDrXX81vxidIer9w9X7wZXPz+ySHy9LK7W3tL63lVcivN2P8AIPT9xHW09haTsOwMntQhCA0blPLqbDxH+QATk+M4MOzkhNBQIrbX8RofNuyk4BlMSOAyTYpbwnjSTJWM28oQGCNsshpxPybNXLZRlE6gdzdFHQgttv8U5L5nwMiNuBZ5IiZ0MWFbC/T1z/LJClcqr56/DbYbDrCopA8gE9g/LgFVTt+X3bZQEw/XYjvQAw1g8FNLCFqBttyze/+QB8YOLkHfZ7/ZtPNnNfIjSoIKD1L5qAFn4UiOSX25d+9f9tx/11TcICtd2XDmzReot56m3Kgh/zFVvtVi9xShNU3tdbwsdBS/hggdUcV2obrpM3XiJukl+LKbXZepGMRXtzekw4AstAoQKWn6xbhPg9u368wiAwPSBy2Hk0HBKykIgIfgxImT2biRccxQJ9647NjV2GdZD/ByNHGBa/Nv0Xzx6Y9qh81gGwQkB7t9+BPO2dPxf3i1iLHX85iSsVpS+hpQ+0HMSBgPfhQgYa3r7t+6/dtYOUP/545eg2osnr2DkMi/cOrn7FHwSkFjY5SBouO3wnSsPs2xx3bJkP/ltJMEpnRAYDFiqwusgz5LTCEvHbXJpEFnoqKZbb6hnN7PBC0euP7Er48blO1gkvETdnr56fP9Z1sXb8GVXT90Gx52cTQreBSXFVQ3EKIWnB8peSL324M7jV8/J95HZr94+efAcj7nrz6OD/aZgSsGzCx+NAbUiFe45N2nvaXgvaBC06rOHL+Bbnz15efmkzQ61Q9mHPN+EkhAagCdA7S75ke3C0I4e3Cv9GgFoCiBtEaA6xbLNQsCkkW/ryb4P3XjS9uM3DYoAGhouqSIV/QKUN5NCHXQ87BxMIFYz4TbDgK6mcZ3rh4HrrLdQonLpeTMBYKXQix6/9Qm1SsCar6f1UJgunxZ9O8h7kIGXr7YYVHzFWOb8MCsYOmRKITVRJKHnIPkeRwl4XvjfhhoedrLuvq36h7SLx0AKsx7W3WKIT8u+HWv1wDPi2UkNlRLSN57ZDneXxr26mg6KsE+MdhoT5TiqR7sheEw0ArIVDgMlIAfkjCK6olVthwPwTAINB7gYRJLfsfhazQtECQkNwHwqETE/CvxtDZYQ16KhlOqrAKsoHRUofnMUMyHUYDDAbEJi+nGhcPZHqjyZ5DNIDFCDiWU5EGh64V9wpUB9mAOwTZAtbISyjhKK+Sz5gYRgv3LdyC/cFfosDKSS7EfxWMtoKtKakTOXIocfAx2EfKsCbNjnNyvFRMkJLULETwiR0CJUCiKhRagUREKLUCmIhBahUhAJLUKlIBJahEpBJLQIlYJIaBEqBZHQIlQKIqFFqBREQotQKYiEFqFSEAktQqUgElqESkEktAiVgkhoESoFkdAiVAoioUWoFERCi1ApiIQWoVIQCS1CpSASWoRKQSS0CJWCSGgRKgWR0CJUCLoB/wdJT8UJ/SU49QAAAABJRU5ErkJggg==" alt="NWB" style="margin-left: auto; margin-right: auto; display: block; height: 60px; height: 5.625em; height: 3.75rem;">
</div>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'Napoli Header', 'napoli-header', 'HEADER');
    
-- insert Napoli footer Template in TEMPLATE table
    str := '<table class="emailTemplateTableFooterStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #4c4c4c; font-family: RN House Sans Regular, sans-serif; font-size: 14px;" width="100%">
    <tr>
        <td>
            <p style="margin: 16px 0px 16px 0px;"><b>About this Email</b></p>
            <p style="margin: 16px 0px 16px 0px;">
                This email is confidential and intended for the addressee only. Please delete if that is not you.
            </p>
            <p style="margin: 16px 0px 16px 0px;">Please do not reply to this email as the address is not monitored. Visit our <a style="text-decoration: none; color: #AD1982;" href="https://www.natwest.com/support-centre.html">Support Centre</a> if you have any queries and we will be happy to help.</p>
</td>
    </tr>
    <tr>
        <td>
            <p style="margin: 16px 0px 16px 0px;"><b>Important Security Information</b></p>
            <p style="margin: 16px 0px 16px 0px;">
                NatWest will <b>NEVER</b> ask for your full PIN or Password when identifying you on the phone or online, and will NEVER ask for Card Reader codes on the phone, by email or text message.
            </p>
            <p style="margin: 16px 0px 16px 0px;">
                Fraudsters may claim to be the bank, police or other companies you trust to try and access security information.
                If you receive a call or email from NatWest that you are suspicious about, cease the call immediately,
                or forward the email to <a style="text-decoration: none; color: #AD1982;" href="mailto:phishing@natwest.com">phishing@natwest.com</a>.
                Visit <a style="text-decoration: none; color: #AD1982;" href="www.natwest.com/security">www.natwest.com/security</a> for more information and advice.
            </p>
            <p style="margin: 16px 0px 16px 0px;">
                <b>National Westminster Bank Plc. Registered in England and Wales No. 929027. Registered Office: 250 Bishopsgate, London EC2M 4AA. Financial Services Firm Reference 121878.</b>
            </p>
            <p style="margin: 16px 0px 16px 0px;">
                <b>Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority.</b>
            </p>
        </td>
    </tr>
</table>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'Napoli Footer', 'napoli-footer', 'FOOTER');

-- insert XO and ADBO Header Template in TEMPLATE table

str := '<div class="emailTemplateHeaderContainer" style="margin: 0 auto; padding: 8px 0; padding: 0.75em 0; padding: 0.5rem 0; width: 100%; color: white; background: #42145F; border: 0; text-align: center;">
            <img class="emailTemplateHeaderLogo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAABaCAIAAAAJsExNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACdKSURBVHhe7VwFWFXJ+z4YCyoGYd1A1wBz11gVaZRUUEK6MUBCEVQUFVTs7u5ce621O2m7BddauxXb/zszl8PhEiLr35/Pfc73vM9hmPNNnJl3vvlm5pzLtdMNECFCZSASWoRKQSS0CJWCSGgRKgWR0CJUCiKhRagUREKLUCmIhBahUhAJLUKlIBJahEpBJLQIlYJIaBEqBZHQIlQKIqFFqBREQotQKYiEFqFSEAktQqUgElqESkEktAiVgkhoESoFkdAiVAoioUWoFP5fCG2hG2imG2haJKBgqRuolFCEiP+I709osLmDto9XFTevKu5FwKOKe3tdf8t8yUWI+C/4zoQ21w2w0fGdp2GWrtY4qVSTwpBcqumJUg0HVLAy1Q1SykGEiP+C70xok6pBURU7nVFrksnpX+EM8gGRBJe4+uc4+Y7SDVy13OF7KGUiQkSJ8T0JDWo6aPtsLGt4nTO4wBlc5BoIcYGAxAMZXJ0TnDyDk40rZ2qp62+ho5yVCBElw3cjNLxhLPUSKthdVGt0iTM4XwChFWw+y+kncbWOcfIUTrqvVL3gyp2RUCk3ESJKhu9GaBPdIFctzwOlW1zj9POzGeAJncbVOc7JYaFPcHow0vPUW9nq+Jr/Z06bVfYxVHc31PAgUHc3Ku9pqe2vpFMgTCvRhDRtG3V3Y00vJYXvBUudAAstP+MKXkYVlIuw1PFHpLD+UIO+khoP3OWVUWcTTW8lBR4osS3NkGWLsLmWX/uqymr/K6CP0P7oLPMqvkq3SobvQ2iYZxPdwKnl2mcSyhLvokA2I3CGq3eS0+MJnczJj6n9GqVph/GglGfxATYAPi37xvtPG+w7BUAgymGkVfUgC20/JWUhkMpC2z/AcMAQ/6ks4dCg6T2th1pVC8ItJeX/ArAKnCO0qxrQwzK+N+pWLZAvAnWwlXSNchwVT6sxyGdKQuC00PYJqH/+arCYkHbxCQHToAn9hMDpwSZxiIfzJtQE8PgOtUP6u41nOQ/xmxLnPcm1Ua/vxZ4SA7UFjzEszar4uhhExjiPcWvcG62kpFYCfB9Cg47dKrtkqDXFgu98PjYDvHlO5WpTKstBaxAaSONka8r+7qjtZVZSTmOUo4emDVj+4f3H7Fdv37zKfvf2/cO7TwZ4TGxbzlNJWQgkRIMuGLEO+tlv3r15+fbTp8971h6zl3f/jl2OUsBXDJtxkQsObDr55P6zA38lgdB8/5lV9u1YO2T/ppPv3314g/q/fPvxw8fjO9Od6odj2uHz4ZUdfg1NPXAWD/vmZTb0P374tH/jSVtpN5jePMo6AaYVfWKcxjx9+BwPCE1c72Te69VxRNvyRTXL/zcw8NpXDXTWD0fdVk/bduX0jbtZ96McRhUxzxQf34HQ5roB1tp+q9SNb3D14WwUYZ5Pc/V4NjPAVJ8kqDWkQjsQumTb0ozQs+NXf8krqQfPda4XZlZJmRM8CKEr+y4Zu1GRgMrBzcl2sm7fi9DMFE2KWXLz6r8f3n1gRYDQ6FGe0KgGjPSf07ezu0xuZ94LaBNrUlG5jxETZBz37NELhR6Vf28+9GoWjYKEmqRZtPwm912iUKJyMT0TU5lppe9AnRIDoxSPcHR7+stnr1mtnj96GdlhxM9CaDPdwOhKjufUGl0ma0HeGBPHgwEsp9BP4WoxZ4MnNDPSqZxsa+mGblpuJXM8GKFnDVnFWgfy+fNnXD99/DRv2BowAHRRSsLACL1o9AZhKli770loWsSu1UeUihASGsBMMjZiwYf3hPFMB50d6z4BzBN60hgeyG1U6JyPHz+R7KBMrzDtcZ6TQGihMvJHKWtm/E1VaKbs6aTdvsvkXkLokDGJyfP1y2xaIyKP7j37WQgNNmMtuLNMq9tc/Wtcg2ucwfUcwJ/mcZ3TzyBrQZmShWachpFO5+STyxlb6BB3XKmIryI/oSGMFg/uPO5uMcS0kJb6YYTetuwgzT+3CCVCw5vs02nU/VuP+GqA3DMGrYCJRQ68GnxipNo0fw+vRgPkumTsJtPKPsKhi0eA73R0exrVIUq4Lhv/FwykMM8fDUpouPVskmEVe3z/5yA0yAdCx1TueFDjt30azXZrtNil8ceOcq3+1mi9XaP1No0228q12aJhuKmc0d/qf8CvOEkInUtlHjDbqZz8qFodnyouplW/2UgXRmjWWLvXHMXqyrxyAQT9wYTmJT+h4Rd5t4g5n3INd1k1IJsX7WMbI7waauVYJ/Rc0hWhGgsc25EO0yusNgy2d/OYK6eymBrk1YvsUT3nKnkmPxp5Cc3kZyE0YKEb6K7rNqKG2Wipaby0fZzUtp+0Q5TMMVzmFCpz6SZ3C5R7euv5BMg8V5VrnsFJmI8hZDP+BaHTOemGsk0dyNLwm/fviib0m9dvE3vMptOxsln6JkITbmn7Qd+0ItmvUKCiN3IG5wrcYqMV84P+tqUHWBFM9m04QZ0HYikBmFVkayPpun/jCdzla56y/2ynuj2FNUFxPa2HYtphaiSvnEDWpdtwTFFWrrKmd2+HkfduPmRqkAd3noTbDcdKkdfJBR05eBYUQR6qojfKRd2U1QoBHoc8aU5yAE+kNL0wNQstf2NNr36u45QIHWGfyHZaWYMUv2gl/FdCszfmwqp1mCwxHCU1GyptN0hq019mRzgtdwqRu3bTcwvU8/TU8+1bzfFwqbrJdLdOidCIhHmOqNTB+Dv50EwoMUhnX0i95vtHP5N8G8xIWBxCoxtIJ2l6W1ULcqzT07VhpFfzaH/DWP82/T1+7+NUP9y6RjDuEoIKxwylOEu7ZfF+VgQTEJpYaEER6EKUuHjMxk+fiHPMapJ58XZ388E8/5AVqDAuEq72R16HD7x59TY+YBpcFz5PhEeHzX3ziriqTOdi2nW3xr2VLDSyRQyUbWoG41m6NOnt8VsUnrFj7RBwFM8lnCLyA22IB0QOaDRn/Qg3JG9KkmM5jhnDrIov2ZvLOz1Cv6/L2CcPn5PaU4EPHW4zzKjCd9h7+Q6LQnPdQEddr1E1TKZJWo+WmA6XWg6RWg+Q2EVLHSJlncNkLj3kXYL1iJ2eXdEojfrQPKcRwL/wN2art2mPUZ4v8+IgP6HRf9RfpX/pv6umboOmkKYs4VcJjf62rh4UaDRwRI/Zq6duO7gl5czJy9fP3bx17V/g6pl/kvefXTdrZ0LANJeGkehX5sWaa/mCHDPiViwd/9eCEesuZSjmfVrCl+vnby0ZuxHlgsEA/NpeHUcg7dDgGUL+PX30cpDPFNgtVhMQC8Ng/ZydTEEoJNMvX5aO24Tasq13PBoyRObsFtPZu+640o4kwhiHbo17oeh1c3Yl7T0D0l85nXXmxGWMupmDVvawGIKRqcRIHkiOWvm17j+hz6Jtyw+mHjh7Mf365VNZZ09eOb4zAy7T9IErop1GOxtEoFlQsX5u41FJNMiOlYcxc7K6QbBA3Lp0//zha1mDQGdyzBIHMqIKLrcIlJzQFtSBBptxNdYJ7FrNYaak5SRJ29FSk2FSy0FSK9jpaHnH3rJOYXJncNqvlleExHlPGf0U6kkzTuOaysn2lNIPqOxsrBsMB8ZCh+CbloYFEpoPsDBm2yiHkTw5+IRfJTTMRnTn0SAu24IoTGAgk/aejnUbj4SYamGEAgxjH9wmizwmrCZMFFECQR0wgXQzHyx0Jz59+jxj4Ar+WBEEBTPghzAFPh8+fGRbaqd6YSAolMEz25pdwRumQBW/LBqzoV3VXKccfoV1jSAM1FNHL7zLfsd0lOTmlbsLEtfB8zHO5+CygjBjgMGfPxXwUEyePHh+eEuKV7NoND4bjUz4avMBoWSev+XeNArzg7DE4qCEhAaP7bR9nLS8Omt7OWl7OWp7u2h7jqlmvKB68+k1Wk+sYTS6hlliDcsEiVU/qX1vmSPP6clVzJJzbTMCxDxPKGdipetno+tnp+tjr+Njp4vH8C/+6/8FEvrpwxfZr4gN4Fvr8LYUW2lX0EKY8KuENlR3nxC1kClASG75RHEPnXf/2cjQOegGzLP+bWLvZN1X3MibUBElkIWj1oFe4OuZE5fwL6/z14I97XOOYJBtV9NB/E4I5NWLN2/fvGNhRN66/m9A2wHs6B6rTNeGvdIOnmfKuMKZGd5tJkqBFQetMeQ61Q3bMG83csBdJiwrXhSxtE2c9MNNBP4MpiCMW9ja7NeK5Io0AkEcu4XREmmf2Kas+9pZO1gMJEcnNyCUK6dvwHtBJfkSi4mSENpMN6CTttcadZPDpVvuLdNqX5lWuO4u0/pImWYpZRsll22cVLbJybJN0so0nallGSPr0F9q30fWKULmBH+6p9Rlk3oTWGW2f4fA7rIGA6vZ9JI4DKhpE1/DMrGm6TTd1sM0LawwexaP0/kJDTm0OXnTArq9RZsMAbieoKZxBU/SozkJv05oDY8x4fP4fd8ChfYIEYRfPnvdq8OI1mW6BLSJvUfJx0ShQUURJZBFo9ZbaPnaSbtupctHXg0+AKwj2Ik6o6qwpu/fvacpvrx//2HPumPnk68izJTBrYTAaYQEOgFG5b0C2w64de0ef/fRvac9bYYxJxujGg7urj+PIp4pMB0lEcbDA+GbBZXBsEnsPusdHQw5agXkwOT5k5dhNsPa/OK+fs4uRRQVljm7KgmcOvemP4TQcAbg6Y6uYH2D08/i6l/n9Hlc4QwucQ0ucwZAFqefXLpZeE23UJnzYIl1rNQ+WubAOD1Sp/0xtV+T6BlhEldrdhXDATLbRKnleInJdEnruZLmOzXrHVar26OSYzHPWQokNPxFzOCXMzIRpg1OWg0TqF+r3NVhMQk9rtcCpvA2+939248zL9y6mJ55PvUaplrY4A8fFEs0Jgij7+Ev+rTsm3XpNkj26vmb9+8+KG5TgfcC44p4cqVWdt7QNawy7CmQDdQQ+OfyXe+WMWAhM9J/Tt/O4iEvnr0eGTJnyxKy3GSRcFGWjvvLrIofHFbM732dx7KjOHYXzjE9TfRGQaaVyIH/JzpKcVeR/OMnrArOJV05l3z17o0HiCGRnxR3IVP7L8Mij2z1VPHFMDt3UrF7yCsgVcbhC/CeUw+eR+Mw9wmCJyWEVnfHSoY0yIs3mDw/0qxxF1fMHtmvsl8+f80aBDoYqD/IQpvqBvpV6XK0dDP2Vp3wRDDnjNDgIuF0g/Fadl1qBQTJPQZKbeOlVrFwqaUdI+Sdw6VOK8u3SKHmeYt6o8E1bQbLrEdKzCdKjEDo5TpND5eufYqTLfmlpXXx3sIrkNCHtqRgMZfYY9bbbGLS+GbfOG83kmC6ZAm/SmiYOpgiLJLWzt45JmJ+n85jgowGev7ex61xb+/mMT2th04fsBxzPUvOcnh453GwSZytpGuc9yTYVKwXUw6cIwXkyNmky8hzePCMxG4zgVE957C3i8DCgZ6T+Arj+uLpq2inMXSjwMexTmjy/jP8rduZ94KN46b0W/pRMaJwgRudZifrjoeCDZ4UsxgDidc/tIUc6YOLcF2wBn187xm7xe7C08UsgSWgS4NI10aReK51s3e+fvlGqAOrifUfcoY/3c9l3OsXirvkSt+BCW2fAKLby7o7/hrq3SIGNZ83bE364fP3bj6K7DCibTmPHpbxGIRokOUTNoPlSMjkxdPXC0eui/efyhoEblus+wTUlnf3i49vIzToZaXjN0/DnL7CT0gsfGeDAZHXOIMdGq395N5ech9/uVcvWafhEktweoDMLkbWMUzuFF/N5kipuimc3kRdMxB9mMRyrMRkiqTN3BrNd5Srz4x3Mlern6a1SUkJfXhrCloELIGpZjGs6V8+fR3rNgFDH7eKQ2jouBhEeDSNQhjEAhvQowAYhiv+bfOL29jwebArfA4w5CNDZqMI6BuV84TC5oX7SAE5AlcBCdtqeECBATxD/kgCL5l53iwrMBJ20bQi2d8NtUq4fT3XhTi+KwNuQ7jt8GePX/KRmD0wNpAhqr125g7hWm3lpK1wXdhKTsmxQQ5wr3GL1KQy0cHQstQJWDx247u3uaMLJnz6wOWoKmatidGLEMPfevboRUi7+FZl3dCeaDpcAfAeTeTaMHKAxwTPZtEsHkW0LusW1WnU0zzbdk9D2iW0KtOFtQbAOoh1wTfh2whtrBvUs1LnjFJN2Ft1+QmNyEucwVm1xgm6Dm61/ALknkF6nlgOxkvbj61pOkzaLk5q3VdmD4ovq/DHBo0mA6R2IPpIqdlESdvpklartRsdV6sFNh/n9NI56dbSDTtpe371qKUwQjvUDmmj7hZmPZQdLtDuI62fdvCcS4MItHVxCA3AnGMthamWzLaViYXj2x34o7SrU/3wq2dv8jngOmvwKpY/K+KrJ4UM0Oxcr+dp4brw82dMKfATwH7YrTc5y1xcl9JDbKz84P/gX0zguMLsxQdOA2OsawQd+5scekMbl48fPo0Jn4+nAFG8W/S9Qz0Knu4rJ2+FTyx8ZACOmVP9sFQ6t6BEVuiR7amYAdqUdZsUvZgmVVQm+/VbrDTIm9kV82zG4/HJsBewE+ME//4UJ4Uwz/Y6vn/+YpTJ6fOvHwnZzGJgvNeUN/GR+/jKvYLlHt3kbiFyl0hZJ/jQUTLH3jLHXjJH/Dugpl1CDas4mU2ixHKcxHiqpPW8Gs32/lIH5pmtF0/Q1/9Hljcz1yHnkUqVEaIIQqM1Yd7mxK9mqzrW+uj72QmrwQYwtTiEBvBv23KesHAOv4a6N40CJ3z/6Mfg+Xs0jNPVMzf4HCDzhq8tAaExYFCl7SsOQQc5sdxS9p+F7wQSrJlOXjNiJWBFOMRvCsw/HJttyxTmltygRIcFhV28di53jMF1ibAbjirhqYcGz2ArS3YLK1csNlqVdiVtJQCZfNQ9pg9cIVTOunA70GgglncDvSZn51kRfnn071P4P53rh8G6Iy0enH+uPLb25yE0lmhxmh3Oc+QLK+ooF8Dmq5xBUunfY6o7e+n5wDZ3k7uHyl3DZM70sNDPV+4NlxoGO0LWGfyGs5EgaT9aYjZZ0nampOWGyg2S6DkLYzOMdBon21uqvl8VZ9Mi3ywtgtAgEwjtbBBxcvcpEpvT+nBA4c+h6b9KaHQGOsBe3r2vyzhYsqS9Z66fv3U36z54oMDNhw9uP36X/Z4lZwLfEZz4VkKjLNR25qCV/HIN138u38GY6VgrJHlfrgN98+pdtkNnUsl7Yl5jeWxHevtqgXBnH955wkfeuHQbkxIeBA7DEnragnh261J6ZleTuC6NemFhoAQkwbSA1SfUmDy5/6xfl3GwxMIBw4SFTx+/PC12OcY5Ria1+vmc4J+E0KCUk5bXrjKt4B8z7uYnNK5XuQZzK7XzkXuDwdQ2u0bQA3AfPW/G5u7yLmFyZ5jqWKn9EKl1osRivMR4mqT14mq/HSxDtj4YoflDxHRONlPd0Bqmq3AjXTShGSNj3cYzp401PQSGzaZmVzT6olGFEho5w6nobjFk95pjWDYxtQIFKfmcISUmNCaBfq551lsvn77q7TASFMHSCv8y1+Lodiz+SCVRvQj7xOcCN/pu1gOwbYj/NLjyfCRaw6ZmMDlF1wlgL5Ygnt2Cl3I5I+ti+nUwWwkXUq9hOLGTdiZv37wbFjwDMwC8F6yG8+/wQODeXD19Y/nELWE2w6xrBqPxMfPkPubPQGhYR2PdgLHlra8R4hLznB/wnsH1Q2VbRNTs4q3n3VXuDh7DNkfInAL0vLzlPvCnERkqd+kl6xwj7RAntRkmaTdGYjpZYji7Rout5fWFbOZPXpI52SG1uj0rOhTxCx5FExoKsBNW1YPW5ezqs6ZHRw4Nmt66bJfCLDS8PXRblOOoK6dzDq4FnVegMDVIyQgNIJXnb31uZ+auC1Hq6PB5WPXnbFmQuCVjN4HKZABU9nXWD7+YptidxBVzRW/HUXAViB6ERmJ5RxYAdPv50JYUGk3ihXUuXKClUPv44SN8ZTazddDrsX7OrndvFQeoRIkK+xfy4M7jjfN3wx9DY5pr5bhwPwOhsSzzq9IlqdTvoOw5uiunBBAafsgltYYTtWxgjOE6wxL3lDlHyjoH6nl00fP30PP1reUdVMstRM8lUt4pRtYhTmY9XGYxVmo0RdJquU7To6VqJ9HTFsZmHuA0HI/lvzR31PYqzEh/ldAAGtGnRd/r53NnSQTOJV/tXC9s7tA/aQpF7/KExvom2CTuxqU7/F2mUJgI75aY0Bh74NyJXRlQ40tcNXXb4jEb+TUcVmBx3pNBaOgjfzza3zluN7l++rxg5PoNc3fTGBIFoz7Ef6oRfUkIrsvxnen8LVxxt5iAPk9oFI0HhCcGB+nmVbJrSXKjGTJhMZBb1+9N7rvEqlqgwv34nxPakvwInf98dZPrXN0zXH3gbD4g8gpXb4fGH8EyjwC6rQFLDNscI3HsV90JLnX/6p3jqjvEV+swvJrt6KpWE6paTqtqOrtq24W6fyzXabZLnWzVCc2zkND0/KX2QE3rwox0cQgNY2as6U1P2hRbs6zNZw1ehalTQQX6hxEaszOM+uZFZLuNKhNBGIvLK6duwE+FGsPedcdR1nPSPbm9WGJC05d4/FdP3cY0WaGnj188m3QFIVbPO1n3PX7vg/yhj8mzbXnPSTGLc9xuooCBKjxBhLPU1WQQFrVoJZjVo3T3g91i128StCEWo6y2eDRUw79N7LJxf/1z5a5Cg2bLhP2LNodjbaJJppT//S6HBWXDhHImp/KxTQg4u3+XbRQhcQ7WI34F2NxL1imupt1e9Zbn1BqfLtWEQI1eSzU+o8bQ6Kxaw7NqjdK5uozNBREabJYfUavTq6L9fyE0gDBoBDLhLpqaNffdGw9P7DrF2MCMEBTsZN1hhLqbD2ZuK2weU8ZSbGzkAvemUTY1glEoIx+6BwWxl+55KTGhYcDalvMY1XMuK5EU/PkzvAhwggZJ8sPbUq2rB2HVxZKAByGW8fxuNOTD+w85+iQB/GPXhr1QHySxqha0h27M83cf/vtkz9pjO1cd2fXn0aKxe+2xrUsPYDHNxhIDHhAVwHQBL3/WkNUYS2zrmi8CQkq5+6Sn9VDMEuDS/5jQAFwOJ22PzaUbp3FS9lFggUjl5HMrGobIXbDs6y3rFCPt2E9mv6iK0SWu4TVyMN7gsgLkbBy4RDetgXOcfnIhnxsCqZxshkZbGx3fwjbvikloAA0Klw7LJijwbY2VzSdwmU6++JcQWtoNfYa5Vfjm8ctnr7Hkb6vhblqJvCLM2EwJ7eX4a+jZJGIReSk5ocn3hR7htsOe0jUorSMpnYVZYE7Cn2aCd6+Rf8daPc7RCijps/CBjUngMaszOM2+MuTvXki7Dq8dS0YY768CQ719tQJ6gdCUvBHu694kCib84OZk+EV8KRCE18z8m+zl01cRf4ZFYVBsBWtM/XRnLdeC8uQDHZM5+YHS9eKr2YTJnaKlHWNldgNltsNrWu5Rb3Yld/motDdCIuGFn8ox0sI8KZvlu0sZ+Fd2LuK9juITGj0Kns0ZuoZ3PJgya3Se0Lb0M9IFI9YxBXbFkt+7RUz+rwTALRR0hr7YwMt/ITT62/P3PuzTKVqvXEHM6xdv+nQaJfx5BrAEfNpIPzRUSsJilk/cDCcBOrQyPpP7LhVuCz6484S9OUQYXzjgAVOQXSNWLh/gwZoX9Qf1p/Rf+pRSlq9J6oFzTvXD0Br/e0ID5FRF22dF2WZYolFTmstmJf6tKt8ctrmvzD5OapsgaY+V33wdw9OlFL8PRulbAKeBFK42+4o2J0ME5ChuTDlTVKCIs5XiExpg29LJ+8hbxXzn0xSKDlYQWttv4cj14Dgffz7lmlfzaHSGUoaGGu7gX+bFWySLHCma0Ps2nEBCsESYDw8YUdjLI9tSoQnPiCUhQqtxOSPT8/do4biCVwoHaWz4fOHXLry8ff0OU01bDQ+irENWcqAv2+ZjAxj6WHTCZ8jfVgwgLqoEtqGRBZHE1UFuIDEfmXOLOBV48K30xIcVgevlU1kev/XBLULoLgpCs1uP7j2LsEv8oYQGTKoGhVZyOKxWJ4VymqdyDv8I4O8eVas9Wdukv9w+XmqVKLEYIzGdIDHaVaHpVQWhCYPzEloRg8UlPfRWODAIwC/fXLrRV3+h9JsIjeZG5w3wmMg3KGtTFsaVuRxmlXwmRC36+CGXIi+evR7iP7VV6S7Ik1kssArugWvDyL0bTkCTzweiROjtOYRmOikHzmHiNipPzh1Qc6xWYTgFNQww1vRaOXkrlHNzzEm7Y9Vh8otQeQcDCB1qlcDeVs2biOydRdon8uPQrApZF6YeIOOZ+llEGfwe0WMOqoH1JWoL+jKrjEZAzoB1jeAB7hOCjONwF9Uz1yKuxaQ+i7AcRP0xXVC6E5cGzYsrijOt6L1hHt1pyanSxbRr5J19+r0Wb6HZrRdPX8W6T2hd1g25IR8ooAXyzwDFwTcQGqvDdjr+0zTaplHbqURogHEadN/+S8PhNdsPk5Jt5ok1jaZKWk/UMT5Win9Br2AjjUAa9ysjNB0wsjROr5+mjSnZZlGujBDfRGgAHYbGWjuTbkuTPlUwgAVAaHtZN+PyXpgEhSstBGBjYpzHgBCgo62kG7oHXvWV0+TQm6mxAERIaHTh5oV7WTzTQf+NjZgPzxsjB5XEcsqtcW9St5wvbTHkyOeAgl+uYPKRvB60AqOIqfEwr0w/ZmHvXQiN+pcvlzIyMeRQGaZJzKem97jIBbzXwaoET2b5hM1dTeMc6/SEww1N8omhfnhg2wEjQ+Yc2pL6+mX2sOAZ1HUhZj6gTeyjf59iCK2dtbOf6zjPZtFwrzEGwGPzyr72su7Du818fO+psIgDfyUhHj2F5DFOY57cV7zux6771h/HzGMv7w50adwbbWIj6VoCTn8DoQFT3SDfyq67ShnAE2D0zc9pusumt7RSSzgb4yXGM2q2mlSjtVvVLonl7TIpaws6ZVR4HfSHSZEJ4fQpTrqqbHMb7a+/QfqthAbgeMC68C9g8M2KK7HQsm7odcc6oUdyftSCCcJPH7449nf63ysOoQMupWe+z7uiZ2EIT2iUBf4tGr2R3eTVnj95lXLgLMo6uj31n8t3UHlo8tM3xkCE3fCHd8nZtVBAghjnsaA7U+NBWkDLb93s3A+ceAGNYF/RPrwywiAN4pkCXyXIvzfJng8mge3LD+5Zeww1vJ11n72eCmEfODJCg3D3c153fvMqG0N9/6aTG+fuXjlp67pZO45uT+NfxWaZY/xgxkPNwVEkDzaJ418qVCh8+nz17I0Dm5NQsbMnryTtPfMj3oeGpUSFRpUzS6HEPS6gMg9wEY7HvtL1plY3nCw1nFOjeXRVKzPdAAdt7+1lWxf23mmOkTbI4OrCPGN9eUStbkglx+J8B14CQiMJmhVWUPh6JLsyQhNDUtEH86CwY5SMHxMSnTcAERIas+cAz4mwyoinuRBharwsGr0eDSsktGujXhfTruMWU2bXSxlZbk2jCvwhL5QyOnye8OeIIGDJsvF/kZzzuSiBRgMxIJkarZFylZQEtFYmtOB7nAJFmO2J3afIpze0O9C2HeTdT+wmh0fM7eHVeLl+/iYh9Ld71d9GaADurIuW+8bSTdLJFh4xyflA7Cs4vaFCo9mSluOrGzrrepjpBBrpBsVUdDzPNaTvNhFO54XCSNMtvNqpnGy6uqHF196zY2CEnjmYEJo2DLkc3lIUoQH4ajBd+zawbWkqufvQhNCgF3gwc9BKfupXqOEvCZN/WTzma0Bxk4qQ0MgKNTm0lRw4Q5iaQEjkgpHrhIRGteGN7F5DPpHKVSIO9BFibvljZAEwBnpYxt/NOTNnSd5lfxjRg7yZjcyFyvgXxhKrw1NHL9KMFY/DJF8Mi/gS7z+Ndzl8W/V7RD0KiEIrRw2iiMiJgv0OaZfATywoHTnAgeGtiZIg8sqprB/0xQqMNJzamIq2pzjZGa7mqUJwmquZwUnXazcIrd6BHM2gX3UDrXX81vxidIer9w9X7wZXPz+ySHy9LK7W3tL63lVcivN2P8AIPT9xHW09haTsOwMntQhCA0blPLqbDxH+QATk+M4MOzkhNBQIrbX8RofNuyk4BlMSOAyTYpbwnjSTJWM28oQGCNsshpxPybNXLZRlE6gdzdFHQgttv8U5L5nwMiNuBZ5IiZ0MWFbC/T1z/LJClcqr56/DbYbDrCopA8gE9g/LgFVTt+X3bZQEw/XYjvQAw1g8FNLCFqBttyze/+QB8YOLkHfZ7/ZtPNnNfIjSoIKD1L5qAFn4UiOSX25d+9f9tx/11TcICtd2XDmzReot56m3Kgh/zFVvtVi9xShNU3tdbwsdBS/hggdUcV2obrpM3XiJukl+LKbXZepGMRXtzekw4AstAoQKWn6xbhPg9u368wiAwPSBy2Hk0HBKykIgIfgxImT2biRccxQJ9647NjV2GdZD/ByNHGBa/Nv0Xzx6Y9qh81gGwQkB7t9+BPO2dPxf3i1iLHX85iSsVpS+hpQ+0HMSBgPfhQgYa3r7t+6/dtYOUP/545eg2osnr2DkMi/cOrn7FHwSkFjY5SBouO3wnSsPs2xx3bJkP/ltJMEpnRAYDFiqwusgz5LTCEvHbXJpEFnoqKZbb6hnN7PBC0euP7Er48blO1gkvETdnr56fP9Z1sXb8GVXT90Gx52cTQreBSXFVQ3EKIWnB8peSL324M7jV8/J95HZr94+efAcj7nrz6OD/aZgSsGzCx+NAbUiFe45N2nvaXgvaBC06rOHL+Bbnz15efmkzQ61Q9mHPN+EkhAagCdA7S75ke3C0I4e3Cv9GgFoCiBtEaA6xbLNQsCkkW/ryb4P3XjS9uM3DYoAGhouqSIV/QKUN5NCHXQ87BxMIFYz4TbDgK6mcZ3rh4HrrLdQonLpeTMBYKXQix6/9Qm1SsCar6f1UJgunxZ9O8h7kIGXr7YYVHzFWOb8MCsYOmRKITVRJKHnIPkeRwl4XvjfhhoedrLuvq36h7SLx0AKsx7W3WKIT8u+HWv1wDPi2UkNlRLSN57ZDneXxr26mg6KsE+MdhoT5TiqR7sheEw0ArIVDgMlIAfkjCK6olVthwPwTAINB7gYRJLfsfhazQtECQkNwHwqETE/CvxtDZYQ16KhlOqrAKsoHRUofnMUMyHUYDDAbEJi+nGhcPZHqjyZ5DNIDFCDiWU5EGh64V9wpUB9mAOwTZAtbISyjhKK+Sz5gYRgv3LdyC/cFfosDKSS7EfxWMtoKtKakTOXIocfAx2EfKsCbNjnNyvFRMkJLULETwiR0CJUCiKhRagUREKLUCmIhBahUhAJLUKlIBJahEpBJLQIlYJIaBEqBZHQIlQKIqFFqBREQotQKYiEFqFSEAktQqUgElqESkEktAiVgkhoESoFkdAiVAoioUWoFERCi1ApiIQWoVIQCS1CpSASWoRKQSS0CJWCSGgRKgWR0CJUCLoB/wdJT8UJ/SU49QAAAABJRU5ErkJggg==" alt="NWB" style="margin-left: auto; margin-right: auto; display: block; height: 60px; height: 5.625em; height: 3.75rem;">
        </div>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'xo and adbo Header', 'xo-and-adbo-header', 'HEADER');

-- insert XO and ADBO footer Template in TEMPLATE table
    str := '<table class="emailTemplateTableFooterStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #4c4c4c; font-family: RN House Sans Regular, sans-serif; font-size: 14px;" width="100%">
    <tr>
        <td>
            <p style="margin: 16px 0px 16px 0px;"><b>About this Email</b></p>
            <p style="margin: 16px 0px 16px 0px;">
                This email is confidential and intended for the addressee only. Please delete if that is not you.
            </p>
			<p style="margin: 16px 0px 16px 0px;">
				You are receiving this email because you have agreed to receive emails about your application whilst applying online, or through using one of our online tools. If we already hold other contact preferences for you, or you have separately registered to receive other information those preferences will not be impacted. If you have applied or started to apply for a product with us, you will continue to receive important information about your application.
			</p>
            <p style="margin: 16px 0px 16px 0px;">Please do not reply to this email as the address is not monitored. Visit our <a style="text-decoration: none; color: #AD1982;" href="https://www.natwest.com/support-centre.html">Support Centre</a> if you have any queries and we will be happy to help.</p>
</td>
    </tr>
    <tr>
        <td>
            <p style="margin: 16px 0px 16px 0px;"><b>Important Security Information</b></p>
            <p style="margin: 16px 0px 16px 0px;">
				To help you identify our email and as an extra security measure the second half of your postcode is shown at the top. If you have not provided us with this information or your personal details have changed, please contact us to update your details.
			</p>
            <p style="margin: 16px 0px 16px 0px;">
                NatWest will <b>NEVER</b> ask for your full PIN or Password when identifying you on the phone or online, and will NEVER ask for Card Reader codes on the phone, by email or text message. Fraudsters may claim to be the bank, police or other companies you trust to try and access security information.
            </p>
            <p style="margin: 16px 0px 16px 0px;">
                If you receive a call or email from NatWest that you are suspicious about, cease the call immediately, or forward the email to phishing@natwest.com. Visit <a href="https://www.natwest.com/fraud-and-security.html" title="NatWest Security Centre">natwest.com/security</a> for more information and advice.
            </p>
            <p style="margin: 16px 0px 16px 0px;">
                <b>National Westminster Bank Plc. Registered in England and Wales No. 929027. Registered Office: 250 Bishopsgate, London EC2M 4AA. Financial Services Firm Reference 121878.</b>
            </p>
            <p style="margin: 16px 0px 16px 0px;">
                <b>Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority.</b>
            </p>
        </td>
    </tr>
</table>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'xo and adbo Footer', 'xo-and-adbo-footer', 'FOOTER');
    
-- insert Broker FYA Email Template in TEMPLATE table
str := '<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <!-- Start banner -->
    <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td colspan="2">
                <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important!</p>
            </td>
        </tr>
        <tr class="emailTemplateBannerTableWarningNotificationRow" style="background: rgb(242, 242, 248);">
            <td class="emailTemplateBannerTableWarningNotificationIcon" style="width: 24px; background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);" width="24">
                <img class="emailTemplateWarningIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA2FBMVEUAAABhYW1mXGZiYmxoXmhkZGRhYWpjY2tlXmllYWhjYGdlX2lkYWhlYGdkX2ljYWhlYGdkYWhlYGhkYWdjYGhkX2hkYGllYGhlYGhkYGhjYWhkYGlkYGhkYGhkYGdjYGhlYGhkYGhkX2hkYGlkX2hkYGhkYGhkYGhlYWlmYmptaXFxbXR0cHd0cXh3c3p6d359eoCBfYSCf4WMiY+NipCOi5GWlJmbmZ6cmZ6xr7O5t7u7ub29u77DwcTW1dfY19nb2tvc293o5+j09PT19PX6+fr7+/v///8mErf9AAAAJ3RSTlMAFRkaGxwdH0lMTU5pamtsbZGYmZqbnKKqtba319jZ2vHy8/T7/P2PX2s+AAAAAWJLR0RHYL3JewAAAOBJREFUGBltwYlWglAUBdCTihkW0ZxKxUN4R5vnsDmt7v//US54l4Wu9obT3hxEw2E0CDzUtXZSOvZwFZWuYY3x4YSWC2yIQifjEtvFXMvQOc2vWTJNAPtUn/JzydIu0M6ovkXuWEo9hKzk07cxnQB9/quHE6qz+xtWjpDQyaciOVUCQzX+lWeqGMdUFyJPVBH6VI8iV1Q9BFQvMhtRrcPL6HzJB1XqAXt03mX2esvSNoCmYel8MnkYsRA3MNfJuMT6KISWC2wIxzesiddQWdlK6diDBuq8oB8lSdTb8FD6AxLFR8uldLbzAAAAAElFTkSuQmCC" style="vertical-align: bottom;">
            </td>
            <td style="background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);">
                If the application is not being progressed, you can ignore this message and no further action is required.
            </td>
        </tr>
    </table>
    <!-- End banner -->
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${brokerFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Applicant Name<br>
                    ${applicantFullName}
                </p>
				<#if (jointApplicantFullName)?? >
					<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
						Joint Applicant Name<br>
						${jointApplicantFullName}
					</p>
				</#if>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Mortgage Reference Number<br>
                    ${referenceNumber}
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We need more information to complete your mortgage application ref no. ${referenceNumber}. Take action now:
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
								<#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
								<#if (document.documentFor)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
								</#if>
								<#if (document.reRequestReason)?? >
                                	<p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Log on to Broker Portal</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We''re here to help</p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you require an update on your mortgage application you can check progress at any time using our mortgage tracker.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions, please contact us on 0345 600 0205.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}

</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share FYA information with the broker', 
'flow-management-broker-fya-notification', 'MAIN');

-- insert BAPI FYA Email Template in TEMPLATE table
str := '<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <!-- Start banner -->
    <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td colspan="2">
                <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important!</p>
            </td>
        </tr>
        <tr class="emailTemplateBannerTableWarningNotificationRow" style="background: rgb(242, 242, 248);">
            <td class="emailTemplateBannerTableWarningNotificationIcon" style="width: 24px; background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);" width="24">
                <img class="emailTemplateWarningIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA2FBMVEUAAABhYW1mXGZiYmxoXmhkZGRhYWpjY2tlXmllYWhjYGdlX2lkYWhlYGdkX2ljYWhlYGdkYWhlYGhkYWdjYGhkX2hkYGllYGhlYGhkYGhjYWhkYGlkYGhkYGhkYGdjYGhlYGhkYGhkX2hkYGlkX2hkYGhkYGhkYGhlYWlmYmptaXFxbXR0cHd0cXh3c3p6d359eoCBfYSCf4WMiY+NipCOi5GWlJmbmZ6cmZ6xr7O5t7u7ub29u77DwcTW1dfY19nb2tvc293o5+j09PT19PX6+fr7+/v///8mErf9AAAAJ3RSTlMAFRkaGxwdH0lMTU5pamtsbZGYmZqbnKKqtba319jZ2vHy8/T7/P2PX2s+AAAAAWJLR0RHYL3JewAAAOBJREFUGBltwYlWglAUBdCTihkW0ZxKxUN4R5vnsDmt7v//US54l4Wu9obT3hxEw2E0CDzUtXZSOvZwFZWuYY3x4YSWC2yIQifjEtvFXMvQOc2vWTJNAPtUn/JzydIu0M6ovkXuWEo9hKzk07cxnQB9/quHE6qz+xtWjpDQyaciOVUCQzX+lWeqGMdUFyJPVBH6VI8iV1Q9BFQvMhtRrcPL6HzJB1XqAXt03mX2esvSNoCmYel8MnkYsRA3MNfJuMT6KISWC2wIxzesiddQWdlK6diDBuq8oB8lSdTb8FD6AxLFR8uldLbzAAAAAElFTkSuQmCC" style="vertical-align: bottom;">
            </td>
            <td style="background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);">
                If the application is not being progressed, you can ignore this message and no further action is required.
            </td>
        </tr>
    </table>
    <!-- End banner -->
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${brokerFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Applicant Name<br>
                    ${applicantFullName}
                </p>
				<#if (jointApplicantFullName)?? >
					<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
						Joint Applicant Name<br>
						${jointApplicantFullName}
					</p>
				</#if>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Mortgage Reference Number<br>
                    ${referenceNumber}
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We need more information to complete your mortgage application ref no. ${referenceNumber}. Take action now:
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
								<#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
								<#if (document.documentFor)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
								</#if>
								<#if (document.reRequestReason)?? >
                                	<p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We''re here to help</p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you require an update on your mortgage application you can check progress at any time using our mortgage tracker.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions, please contact us on 0345 600 0205.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}

</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share FYA information with the broker',
'flow-management-bapi-fya-notification', 'MAIN');

-- insert Customer FYA Email Template in TEMPLATE table
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <!-- Start banner -->
    <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td colspan="2">
                <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important!</p>
            </td>
        </tr>
        <tr class="emailTemplateBannerTableWarningNotificationRow" style="background: rgb(242, 242, 248);">
            <td class="emailTemplateBannerTableWarningNotificationIcon" style="width: 24px; background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);" width="24">
                <img class="emailTemplateWarningIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA2FBMVEUAAABhYW1mXGZiYmxoXmhkZGRhYWpjY2tlXmllYWhjYGdlX2lkYWhlYGdkX2ljYWhlYGdkYWhlYGhkYWdjYGhkX2hkYGllYGhlYGhkYGhjYWhkYGlkYGhkYGhkYGdjYGhlYGhkYGhkX2hkYGlkX2hkYGhkYGhkYGhlYWlmYmptaXFxbXR0cHd0cXh3c3p6d359eoCBfYSCf4WMiY+NipCOi5GWlJmbmZ6cmZ6xr7O5t7u7ub29u77DwcTW1dfY19nb2tvc293o5+j09PT19PX6+fr7+/v///8mErf9AAAAJ3RSTlMAFRkaGxwdH0lMTU5pamtsbZGYmZqbnKKqtba319jZ2vHy8/T7/P2PX2s+AAAAAWJLR0RHYL3JewAAAOBJREFUGBltwYlWglAUBdCTihkW0ZxKxUN4R5vnsDmt7v//US54l4Wu9obT3hxEw2E0CDzUtXZSOvZwFZWuYY3x4YSWC2yIQifjEtvFXMvQOc2vWTJNAPtUn/JzydIu0M6ovkXuWEo9hKzk07cxnQB9/quHE6qz+xtWjpDQyaciOVUCQzX+lWeqGMdUFyJPVBH6VI8iV1Q9BFQvMhtRrcPL6HzJB1XqAXt03mX2esvSNoCmYel8MnkYsRA3MNfJuMT6KISWC2wIxzesiddQWdlK6diDBuq8oB8lSdTb8FD6AxLFR8uldLbzAAAAAElFTkSuQmCC" style="vertical-align: bottom;">
            </td>
            <td style="background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);">
                If the application is not being progressed, you can ignore this message and no further action is required.
            </td>
        </tr>
    </table>
    <!-- End banner -->
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${applicantFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Applicant Name<br>
                    ${applicantFullName}
                </p>
				<#if (jointApplicantFullName)?? >
					<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
						Joint Applicant Name<br>
						${jointApplicantFullName}
					</p>
				</#if>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Mortgage Reference Number<br>
                    ${referenceNumber}
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We need more information to complete your mortgage application ref no. ${referenceNumber}. Take action now:
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
							    <#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
								<#if (document.reRequestReason)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Log on to Customer Portal</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We''re here to help</p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you require an update on your mortgage application you can check progress at any time using our mortgage tracker.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions, please contact us on 0345 302 0190.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share FYA information with the customer', 
'flow-management-customer-fya-notification', 'MAIN');

-- insert Broker avScan failure Email Template in TEMPLATE table
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${brokerFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    <b>Request for re-upload of Document</b>
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We are writing to inform you that the document you recently uploaded as part of your mortgage application has issues. As a result, we were unable to process your document.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                    <#list documentInfo as document>
                    <tr>
                        <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                            <#if (document.category)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                            </#if>
							<#if (document.requiredFor)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.requiredFor}</p>
                            </#if>
                            <#if (document.originalFileName)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                    <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                </p>
                            </#if>
                        </td>
                    </tr>
                    </#list>
                </table>
            </td>
        </tr>
        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Log on to Broker Portal</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We kindly request that you upload another copy of the document as soon as possible so that we can continue to process your mortgage application. Please ensure that the new copy of the document is clear, legible and free from any viruses.</p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions or concerns, please do not hesitate to reach out to us. Our team is available to assist you and ensure a smooth and seamless process.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                We apologize for any inconvenience this may have caused and appreciate your understanding and cooperation in this matter.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Mark Bullard
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Head of Intermediary Sales, Natwest Intermediary Solutions
                </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to broker', 
'flow-management-broker-avscan-failure-notification', 'MAIN');

-- insert BAPI avScan failure Email Template in TEMPLATE table
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${brokerFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    <b>Request for re-upload of Document</b>
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We are writing to inform you that the document you recently uploaded as part of your mortgage application has issues. As a result, we were unable to process your document.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                    <#list documentInfo as document>
                    <tr>
                        <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                            <#if (document.category)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                            </#if>
							<#if (document.requiredFor)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.requiredFor}</p>
                            </#if>
                            <#if (document.originalFileName)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                    <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                </p>
                            </#if>
                        </td>
                    </tr>
                    </#list>
                </table>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We kindly request that you upload another copy of the document as soon as possible so that we can continue to process your mortgage application. Please ensure that the new copy of the document is clear, legible and free from any viruses.</p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions or concerns, please do not hesitate to reach out to us. Our team is available to assist you and ensure a smooth and seamless process.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                We apologize for any inconvenience this may have caused and appreciate your understanding and cooperation in this matter.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Mark Bullard
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Head of Intermediary Sales, Natwest Intermediary Solutions
                </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to broker',
'flow-management-bapi-avscan-failure-notification', 'MAIN');

-- insert Customer avScan failure Email Template in TEMPLATE table
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${applicantFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    <b>Request for re-upload of Document</b>
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We are writing to inform you that the document you recently uploaded as part of your mortgage application has issues. As a result, we were unable to process your document.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                    <#list documentInfo as document>
                    <tr>
                        <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                            <#if (document.category)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                            </#if>
                            <#if (document.originalFileName)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                    <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                </p>
                            </#if>
                        </td>
                    </tr>
                    </#list>
                </table>
            </td>
        </tr>
        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Log on to Customer Portal</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We kindly request that you upload another copy of the document as soon as possible so that we can continue to process your mortgage application. Please ensure that the new copy of the document is clear, legible and free from any viruses.</p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions or concerns, please do not hesitate to reach out to us. Our team is available to assist you and ensure a smooth and seamless process.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                We apologize for any inconvenience this may have caused and appreciate your understanding and cooperation in this matter.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Mark Bullard
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Head of Intermediary Sales, Natwest Intermediary Solutions
                </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to customer', 
'flow-management-customer-avscan-failure-notification', 'MAIN');

-- insert Customer FYA Email Template in TEMPLATE table for xo channel

INSERT INTO template(content, name, description, type)
VALUES (TO_CLOB(q'[
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>Application-complete</title>
    <link rel="shortcut icon" href="/apps/settings/wcm/designs/responsive_campaign_natwest_personal/clientlibs/resources/favicon.ico"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
     <meta http-equiv="Content-Type" content="text/html" ; charset="UTF-8"/>
    <meta content="width=device-width, initial-scale=1" name="viewport"/><meta name="x-apple-disable-message-reformatting"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta content="telephone=no" name="format-detection"/>
    <meta name="robots" content="noindex"/>]') || TO_CLOB(q'[
     <style type="text/css">#divider__container{width:600px!important}
@media screen and (max-width:600px){#hero_img{background-position:center!important;margin-left:30px!important;margin-right:0!important;margin-top:25px!important;float:left!important;display:inline-block!important;text-align:center!important}
#hero_mobile{display:block!important}}.header__first{margin-bottom:32px}.cta-primary .cta__starts{width:177px}
#outlook a{padding:0}.left{float:left}.right{float:right}.ExternalClass{width:100%}.ExternalClass,.ExternalClass div,.ExternalClass font,.ExternalClass p,.ExternalClass span,.ExternalClass td{line-height:100%}
a[x-apple-data-detectors]{color:inherit!important;text-decoration:none!important;font-size:inherit!important;font-family:inherit!important;font-weight:inherit!important;line-height:inherit!important}.es-desk-hidden{display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0;mso-hide:all}
.es-footer .pixel-13,.es-header .pixel-13{font-size:13px;line-height:18px;display:inline-block}a{color:#1d7b8a!important;text-decoration:underline}
.es-header .pixel-14{font-size:14px;display:inline-block}.es-footer .pixel-14{font-size:14px;display:inline-block}.es-footer p{margin-bottom:27px}
body{color:#4c4c4c;font-family:Arial;margin:0}p{margin:0}.es-p15{padding:15px 15px 15px 15px}.es-header .es-infoblock{padding:15px 14px 15px 16px!important}
.email--iompersonal .es-footer .es-infoblock,.email--nw .es-footer .es-infoblock,.email--nwbus .es-footer .es-infoblock{padding:31px 30px 26px 31px!important}.email--rbs
.es-footer .es-infoblock,.email--rbsbus .es-footer .es-infoblock,.email--ulsnibus .es-footer .es-infoblock,.email--ulsroibus .es-footer .es-infoblock{padding:30px 30px 45px 31px!important}
.email--rbs .logo,.email--rbsbus .logo{height:44px;width:164px;background-size:cover;object-fit:cover}.email--iompersonal
.logo{height:37px;width:380px;background-size:cover;object-fit:cover}.email--iompersonal .left .logo{padding-left:17px}.email--ulsnibus .logo,.email--ulsroibus
.logo{height:40px;width:145px;background-size:cover;object-fit:cover}.email--nw .logo,.email--nwbus .logo{height:61px;width:55px;background-size:cover;object-fit:cover}.email--nwi
.logo{height:62px!important;width:55px;background-size:cover;object-fit:cover}.email--rbs .logo_text,.email--rbsbus .logo_text{padding:28px 27px 28px 27px}.email--ulsnibus
.logo_text,.email--ulsroibus .logo_text{padding:47px 27px 47px 27px}.email--nw .logo_text,.email--nwbus .logo_text{padding:28px 28px 28px 28px}.email--iompersonal .logo_text{padding:28px 28px 28px 28px}@media screen and (max-width:600px){.em__header .es-infoblock p:first-child{margin-bottom:0}]') || TO_CLOB(q'[
.es-header .es-infoblock{padding:15px 15px 15px 15px!important}.email--rbs .logo,.email--rbsbus .logo{height:38px;width:142px;float:right}.email--ulsnibus .logo,.email--ulsroibus .logo{height:32px;width:115px;float:right}.email--iompersonal .logo{height:29px;width:288px;background-size:cover;object-fit:cover}.email--nw .logo,.email--nwbus .logo{height:45px;width:41px;background-size:cover;object-fit:cover}.email--nwi .logo{height:46px!important;width:41px;background-size:cover;object-fit:cover}.email--rbs .logo_text,.email--rbsbus .logo_text{padding:21px 21px 21px 21px}.email--ulsnibus .logo_text,.email--ulsroibus .logo_text{padding:18px 16px 18px 16px!important}.email--iompersonal .logo_text,.email--nw .logo_text,.email--nwbus .logo_text{padding:14px 15px 16px 15px!important}.es-header .pixel-14{font-size:14px}.email--iompersonal .es-footer td.es-infoblock,.email--nw .es-footer td.es-infoblock,.email--nwbus .es-footer td.es-infoblock{padding:23px 15px 13px 15px!important}.email--rbs .es-footer td.es-infoblock,.email--rbsbus .es-footer td.es-infoblock,.email--ulsnibus .es-footer td.es-infoblock,.email--ulsroibus .es-footer td.es-infoblock{padding:25px 22px 7px 15px!important}ol li,p,ul li{line-height:18px!important}h1{font-size:24px!important;text-align:center;line-height:120%!important}
h3{text-align:center}.es-header-body a,.es-header-body ol li,.es-header-body p,.es-header-body ul li{font-size:13px!important}.es-footer-body a,.es-footer-body ol li,.es-footer-body p,.es-footer-body ul li{font-size:10px!important}.es-infoblock a,.es-infoblock ol li,.es-infoblock p,.es-infoblock ul li{font-size:13px!important}[class=gmail-fix]{display:none!important}.es-m-txt-c,.es-m-txt-c h1,.es-m-txt-c h2,.es-m-txt-c h3{text-align:center!important}.es-m-txt-r,.es-m-txt-r h1,.es-m-txt-r h2,.es-m-txt-r h3{text-align:right!important}.es-m-txt-l,.es-m-txt-l h1,.es-m-txt-l h2,.es-m-txt-l h3{text-align:left!important}.es-m-txt-c img,.es-m-txt-l img,.es-m-txt-r img{display:inline!important}.es-adaptive table,.es-btn-fw,.es-btn-fw-brdr,.es-left,.es-right{width:100%}#divider__container{width:100%}.es-content,.es-content table,.es-footer,.es-footer table,.es-header,.es-header table{max-width:600px!important}.es-adapt-td{display:block!important;width:100%!important}.adapt-img{width:100%!important;height:auto!important}.es-hidden,.es-mobile-hidden{display:none!important}table.es-desk-hidden,td.es-desk-hidden,
tr.es-desk-hidden{width:auto!important;overflow:visible!important;float:none!important;max-height:inherit!important;line-height:inherit!important}tr.es-desk-hidden{display:table-row!important}table.es-desk-hidden{display:table!important}td.es-desk-menu-hidden{display:table-cell!important}.esd-block-html table,]') || TO_CLOB(q'[table.es-table-not-adapt{width:auto!important}#divider__container{width:100%!important}}.es-legal-p{padding:14px 12px 14px 19px;margin:0;color:#4d4d4d}.es-legal-p .comp-rich-text{float:left}.es-legal-p .comp-rich-text,.es-legal-p p{height:auto;font-size:11px;font-family:arial;line-height:13px!important;overflow:hidden}.without_borderline{padding-top:10px}.with_borderline{padding-top:20px}.comp-rich-text{font-size:13px;line-height:18px}#onemaincol-center__rte .comp-rich-text{text-align:center!important}.title-comp{font-size:19px!important;margin:0}.onemain-title .title-comp{text-align:left!important}#onemaincol-center__title .title-comp{text-align:center!important}@media screen and (min-width:601px){.email--nw .logo_text,.email--nwbus .logo_text{padding:19px 20px 20px 20px!important}#es-m-p20b{padding:15px!important}#nw_phoimg{height:285px;display:inline-block}.horz__tdstarts{padding:15px 15px 15px 35px!important}#hero-ill_horz{width:600px!important}#horz__img__td{width:132px!important}#horz_td{width:290px!important;height:230px!important}#horz__top__space{display:block!important}#nw_topimg{height:200px!important;width:200px!important}#nwhero_rightimg{height:200px!important;width:200px!important}#es-hero-titleblock{padding-top:102px;padding-bottom:105px;display:block!important}.es-mobile__border{display:none!important}.email--ulsnibus .campaignhero .logo,.email--ulsroibus .campaignhero .logo{width:145px;height:40px}#horz_txtstrt{padding-bottom:0!important}.email--ulsnibus .hero-width,.email--ulsroibus
.hero-width{height:147px!important;width:244px!important}.email--ulsnibus .es-hero-titlecomp td,.email--ulsroibus .es-hero-titlecomp td{padding:16px 17px 26px 17px!important}.email--ulsnibus .es-hero-titlecomp h2,.email--ulsroibus .es-hero-titlecomp h2{font-size:30px!important;line-height:35px!important}}@media screen and (max-width:600px){.es-mobile__border{display:table!important}.es-hero-body{display:none}.email--nw .campaignhero .logo,.email--nwbus .campaignhero .logo,.email--ulsnibus .campaignhero .logo,.email--ulsroibus .campaignhero .logo{height:52px!important;width:47px!important}}#xf__starts .table{width:600px;float:none;margin:0 auto}@media screen and (min-width:601px){#hero_left{width:30px}#titlefont{font-size:28px!important;line-height:32px!important}#rbs__hero__image{height:285px}#hero_td{display:block!important}#rbs_ill-img{height:223px!important;width:223px!important}#email_ill_img{height:32px!important;line-height:32px!important}#hero_top{line-height:0;height:0}#bg-image-illust,#rbs__hero__illu{width:600px}#bg-image-illust #hero_td{padding-left:30px!important}#hero_img{background-position:center!important;margin-left:0!important;margin-right:30px!important;margin-top:0!important;float:right!important;text-align:center!important;width:223px!important;height:223px!important}#hero_img__tr{float:right!important;padding-top:0!important}#email__twill,#email_twill,#illust__firsttitle,#illust_firsttitle{width:195px!important}#illust___secondtitle,#illust__secondtitle,#illust_secondtitle{width:270px!important}#illust__thirdtitle,#illust_thirdtitle{width:173px!important}}@media screen and (max-width:601px){.hero__inline{position:absolute!important}.hero__inline__tr{position:absolute!important;margin-top:30px!important}}@media screen and (min-width:601px){.email--iompersonal .logo_text{padding:19px 20px 20px 20px!important}#horz_txtstrt{padding-bottom:0!important}#es-m-p20b{padding:15px!important}}@media screen and (max-width:600px){.email--iompersonal .campaignhero
.logo{height:52px!important;width:47px!important}}@media screen and (min-width:601px){#get__the--app{width:600px!important}}@media screen and (min-width:600px){#apptable{padding:20px 50px 30px 50px!important}#step{padding-top:37px!important}#appicons{padding-top:28px!important}#getheapp_appleimg,]') || TO_CLOB(q'[#getheapp_googleimg{background-position:center!important}}.table-row-0 .title-comp{font-size:13px!important;text-align:left}
@media screen and (min-width:601px){#table__head{padding:11px 0 11px 11px!important}#table__body{padding:6px 11px 6px 11px!important}#table{width:600px!important}}@media screen and (max-width:600px){#table .comp-rich-text,#table .comp-rich-text p,.table-row-0 .title-comp{font-size:10px!important;line-height:12px!important}#table__body{padding:2px 5px 2px 5px!important}}.txtandicn-img img{height:18px;width:18px}.txtandicn-img{vertical-align:top;word-break:break-all}.txtandicn-rte h2,h3,h4{margin:0;padding:0}@media screen and (min-width:601px){#twothree-strt{padding-left:30px;padding-right:30px;display:flex}#twothreecol_body{display:table;height:100%;vertical-align:top}.threecol_image{vertical-align:top}
#threecol_title{padding:16px 0 0 0!important}#twothree_hide{display:block!important}#twothree_tbl{display:table-cell;width:auto!important}
#two__column #column__width{width:264px!important}#three__column #column__width{width:166px!important}#threecol_rte,#twocolumn__rte{padding:7px 0 0 0!important}#twocolumn__title{padding:17px 0 0 0!important}#threecol_ill{height:86px!important;width:86px}#twothree_pho #threecol_td{display:inline-block!important}#threecol_cta{padding-top:12px!important}#no__bgColor,#threecol_pho{height:86px!important}#twocol_img,#twocol_pho{height:158px!important}#twocol_ill{height:126px!important;width:126px!important}}@media screen and (max-width:600px){#twothree-strt{padding-left:0;padding-right:0}}#threecol_rte ol,#threecol_rte ul,#twocolumn__rte ol,#twocolumn__rte ul{list-style-position:inside}@media screen and (min-width:601px){.email--iompersonal #thirty-seven_split #thirty-sevenimg_ill,.email--nw #thirty-seven_split #thirty-sevenimg_ill,.email--nwbus #thirty-seven_split #thirty-sevenimg_ill{height:171px;width:170px}#thirty-seven_split #es-left,#thirty-seven_split #es-right{width:auto!important}#es-emptyPad__bottom,#es-emptyPad__top{height:0}#author__section--td,#thirty-seven_img{height:240px!important}.email--rbs #thirty-sevenimg_ill,.email--rbsbus #thirty-sevenimg_ill,.email--ulsnibus
#thirty-sevenimg_ill,.email--ulsroibus #thirty-sevenimg_ill{height:163px;width:166px}#thirtyseventy--text__comp{padding-bottom:13px!important}#thirty-sevenimg_lft #thirty-seven_secstarts{padding:0 30px 0 30px!important}#thirty-sevenimg_rht #thirty-seven_secstarts{padding:0 13px 0 30px!important}}#thirty-seven_split .title-comp{text-align:left}.thirty-seven_secstarts{display:table-cell}@media screen and (max-width:600px){#thirty-sevenimg_pho{width:100%}#author__section--td{height:auto!important}}@media screen and (min-width:601px){#mainone__starts{padding:0!important;border-bottom:2px solid #fff}#main1innertbl{width:540px!important}#main1innertbl_noBorder{width:600px!important}#onemaintable1{width:600px!important}#onemaintable2{padding-top:10px!important}#table-bottom{line-height:30px!important;height:30px!important}#main1-ill_withbdr{height:210px;width:210px}
#main1-ill_withoutbdr{height:240px;width:240px}#withoutbdr{height:300px;width:600px}#withbdr{height:270px;width:540px}.img_container_no_border{height:300px!important}.img_container_{height:270px!important;width:540px!important}#onemain-title{padding:20px 30px 0 30px!important}]') || TO_CLOB(q'[#onemain-rte{padding:20px 30px 0 30px!important}#text_icons{padding:0 30px 0!important}#mainone_cta1,#mainone_cta2{padding-top:20px!important}#mainone_cta2{float:left;margin-left:15px!important}#mainone_cta1{float:right;margin-right:15px!important}.showCta{padding:0 30px!important}#onemaincol-left{float:left!important}#onemaincol-center{text-align:center!important}.onemaincol-center{text-align:center!important}.mainone_cta1_with_scta{float:right!important}.mainone_cta2_with_scta{float:left!important}#mainone__hide{display:table-cell!important}#onemain-addesc{padding:20px 30px 0 30px!important}#legal-top{padding:0 30px 0 30px!important}#es-legal-p{margin:0;color:#4d4d4d}#mainone__cta{width:50%!important}#onemain-rte li{margin:0}}#mainone_cta1 .cta-secondary .cta__text,#mainone_cta2 .cta-secondary .cta__text{padding:0 3px!important}#onemaincol-left .cta-secondary{float:left!important;width:auto!important}#onemain-rte li{line-height:18px;letter-spacing:-.13px;padding-bottom:11px;padding-left:4px}#onemain-rte li{list-style-position:outside}#onemain-rte p{margin:0}#onemain-rte ul{padding-left:14px;margin:0;padding-top:8px}#text_icons li{padding-left:20px!important}</style>
</head>
<body>
	<!--[if (mso 16)]>
    <style type="text/css">
    a {text-decoration: underline;}
    </style>
    <![endif]-->
<!--[if gte mso 9]><style>sup { font-size: 100% !important; }
        </style>
    <![endif]-->
<!--[if gte mso 9]>
<xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG></o:AllowPNG>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
</xml>
<![endif]-->
<!--[if mso]>
<style type="text/css">

#horz_txtstrt{
height: 200px !important;
padding-bottom:0px !important;
}
 #es-m-p20b{
        padding:15px !important;
    }
#author__section--td,
#thirty-seven_img {
height: 240px !important;

}

.email--nw #thirty-seven_split #thirty-sevenimg_ill,
.email--nwbus #thirty-seven_split #thirty-sevenimg_ill,
.email--iompersonal #thirty-seven_split #thirty-sevenimg_ill {
height: 171px;
width: 170px;
}

#thirty-seven_split #es-left,
#thirty-seven_split #es-right {
width: auto !important;
}

#es-emptyPad__top,
#es-emptyPad__bottom {
height: 0px;
}

#hero_img__tr{
    float : right !important;
}
 #hero_leftbox{
    position: absolute !important;
    float:left !important;
}

#bg-image-illust #hero_td {
    padding-left: 30px !important;
    position: absolute !important;

}
#email_leftbox_desktop{
    float: left !important;
}
#hero_img{
    float: right !important;
    margin-top:0px !important;
    margin-right:30px !important;
    margin-left:0px !important;
    background-position: center !important;
    display:inline-block !important;
    text-align:center !important;
}
 #rbs_ill-img{
    text-align:center !important;
 }
 #hero_img__tr{
    float:right !important;
    padding-top:0px !important;
}
  #titlefont{
        font-size:28px !important;
        line-height:32px !important;
    }

 @media screen and (max-width:600px) {
     #hero_img{
        float: left !important;
        background-position: center !important;
        display:inline-block !important;
        text-align:center !important;
        background-size: 100px 100px !important;
    }
     #rbs_ill-img{
    width: 175px !important;
    height: 175px !important;
  }

 }
 @media screen and (min-width:600px) {

  #hero_img{
      width:223px !important;
  }
}
#email__twill{
height:6px !important;
}

#illust_firsttitle,#illust__firsttitle,  #email__twill, #email_twill{
    width: 195px !important;
}
#illust_secondtitle, #illust__secondtitle, #illust___secondtitle{
    width: 270px !important;
}]') || TO_CLOB(q'[
#illust_thirdtitle, #illust__thirdtitle{
    width:173px !important;
}

#author__section--td,
#thirty-seven_img {
height: 240px !important;

}

.email--rbs #thirty-sevenimg_ill,
.email--rbsbus #thirty-sevenimg_ill {
height: 163px;
width: 166px;
}

.email--ulsnibus #thirty-sevenimg_ill,
.email--ulsroibus #thirty-sevenimg_ill {
height: 163px;
width: 166px;
}
 .email--ulsnibus .hero-width,
.email--ulsroibus .hero-width{
    height: 147px! important;
    width: 244px! important;
    }
.email--ulsnibus .es-hero-titlecomp td,
.email--ulsroibus .es-hero-titlecomp td{
    padding: 16px 17px 26px 17px! important;
}

.email--ulsnibus .es-hero-titlecomp h2,
.email--ulsroibus .es-hero-titlecomp h2{
font-size: 30px! important;
line-height: 35px! important;
}

#thirtyseventy--text__comp {
padding-bottom: 13px !important;
}

#thirty-sevenimg_lft #thirty-seven_secstarts {
padding: 0px 30px 0px 30px !important;
}

#thirty-sevenimg_rht #thirty-seven_secstarts {
padding: 0px 13px 0px 30px !important;
}
#table-bottom{
line-height:30px!important;
height:30px!important;
}
.email--nw .logo_text,
.email--nwbus .logo_text {
padding: 19px 20px 20px 20px !important;

}

#nw_phoimg {
height: 285px !important;
display: inline-block;
}

.horz__tdstarts {
padding: 15px 15px 15px 35px !important
}

#hero-ill_horz {
width: 600px !important;
}

.horz__img__td {
width: 132px !important;
}

.horz_td {
width: 290px !important;
}

#horz__top__space {
display: block !important;
}

#nwhero_rightimg {
height: 200px !important;
width: 200px !important;
}


#es-hero-titleblock {
padding-top: 102px;
padding-bottom: 105px;
display: block !important;
}

.es-mobile__border {
display: none !important;
}
#hero_left {
width: 30px;
}

#rbs__hero__image {
height: 285px;
}

#hero_td {

display: block !important;
}



#email_ill_img {
height: 32px !important;
line-height: 32px !important;

}

#hero_top {
line-height: 0px;
height: 0px;
}

#bg-image-illust,
#rbs__hero__illu {
width: 600px;
}

#bg-image-illust #hero_td {
padding-left: 30px !important;
}

#table__head {
padding: 11px 0px 11px 11px !important
}

#table__body {
padding: 6px 11px 6px 11px !important;
}

#apptable {

padding: 20px 50px 30px 50px !important;
}

#step {
padding-top: 37px !important;
}

#appicons {
padding-top: 28px !important;
}

#getheapp_appleimg,
#getheapp_googleimg {
background-position: center !important;
}

#twothree-strt {
padding-left: 30px;
padding-right: 30px
}

#threecol_title {
padding: 16px 0px 0px 0px !important;
}


#threecol_rte,
#twocolumn__rte {
padding: 7px 0px 0px 0px !important;
}

#two__column #column__width {
width: 264px !important;
}

#three__column #column__width {
width: 166px !important;
}

#twocolumn__title {
padding: 17px 0px 0px 0px !important;
}

#threecol_ill {
height: 86px;
width: 86px;
}

#threecol_cta {
padding-top: 12px !important;
}

#threecol_pho,
#no__bgColor {
height: 86px !important;
}

#twocol_pho,
#twocol_img {
height: 158px !important;
}


.email--nw .es-footer .es-infoblock,
.email--nwbus .es-footer .es-infoblock,
.email--iompersonal .es-footer .es-infoblock  {
padding: 31px 30px 26px 31px !important;
}

#onemain-rte p {
padding-bottom: 8px;
}

#onemain-rte ul {
padding: 0;
margin: 0;
margin-top: 8px;
}

#onemain-rte li {
margin: 0;
padding: 0;
margin-bottom: 11px;
margin-left: 25px;
margin-top:8px;
}

.es-legal-p p,
.es-legal-p .comp-rich-text {
mso-element-frame-height: 42px;
line-height:13px;
}

#mainone__starts{
padding:0px!important;
}

#onemaintable2 {
    padding-top: 10px !important;
}

#main1-ill_withbdr {
    height: 210px;
    width: 210px;
}

#main1-ill_withoutbdr {
    height: 240px;
    width: 240px;
}
]') || TO_CLOB(q'[
.img_container_no_border{
    height:300px !important;
}

.img_container_{
    height:270px !important;
    width:540px !important;
}

#onemain-title {
padding: 20px 29px 0px 29px !important;
}

#onemain-rte {
padding: 20px 29px 0px 29px !important;
}

#text_icons {
padding: 0px 29px 0px !important;
}

#mainone_cta2,
#mainone_cta1 {
padding-top: 20px !important;
}

#mainone_cta2 {
float: left;
margin-left:15px!important;
}

#mainone_cta1 {
float: right;
margin-right:15px!important;
}

.showCta{
    padding:0px 30px !important;
}

#onemaincol-left{
    float:left !important;
}

#onemaincol-center{
    text-align: center !important;
}

.onemaincol-center{
    text-align: center !important;
}

.mainone_cta1_with_scta {
    float:right !important;
}

.mainone_cta2_with_scta {
    float:left !important;
}

#onemaincol-left .cta-secondary{
    float:left !important;
    width: auto !important;
}

#mainone__hide {
display: table-cell !important;
}

#onemain-addesc {
padding: 20px 29px 0px 29px !important;
}

#legal-top {
    padding:0px 30px 0px 30px !important;
}

#text_icons li{
	padding-left:20px !important;
}

#es-legal-p {
margin: 0;
color: #4d4d4d;
}

#mainone__cta{
 width:50%!important;;
 }

</style>
<![endif]-->


<style type="text/css" nonce>
/* Important - Remove aem-AuthorLayer-Edit styles and this commented line for minifying syles.Gmail have some css limitation */
    div {
        padding: 0px !important;
    }

    #divider__container {
        width: 600px !important;
    }

    @media screen and (max-width:600px) {
        #hero_img{
            background-position: center !important;
            margin-left: 30px !important;
            margin-right: 0px !important;
            margin-top: 25px !important;
            float:left !important;
            display:inline-block !important;
            text-align: center !important;
        }

        #hero_mobile {
            display: block !important;
        }

    }

    .header__first {
        margin-bottom: 32px
    }



    .cta-primary .cta__starts {
        width: 177px;
    }

    #outlook a {
        padding: 0;

    }

    .left {
        float: left;
    }

    .right {
        float: right;
    }

    .ExternalClass {
        width: 100%;
    }

    .ExternalClass,
    .ExternalClass p,
    .ExternalClass span,
    .ExternalClass font,
    .ExternalClass td,
    .ExternalClass div {
        line-height: 100%;
    }



    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }

    .es-desk-hidden {
        display: none;
        float: left;
        overflow: hidden;
        width: 0;
        max-height: 0;
        line-height: 0;
        mso-hide: all;
    }

    .es-header .pixel-13,
    .es-footer .pixel-13 {
        font-size: 13px;
        line-height: 18px;
        display: inline-block;

    }

    a {
        color: #1D7B8A !important;
        text-decoration: underline;
    }

    .es-header .pixel-14 {
        font-size: 14px;
        display: inline-block;
    }

    .es-footer .pixel-14 {
        font-size: 14px;
        display: inline-block;
    }

    .es-footer p {
        margin-bottom: 27px;
    }

    body {
        color: #4c4c4c;
        font-family: Arial;
        margin: 0px;

    }
]') || TO_CLOB(q'[
    p {
        margin: 0;
    }

    .es-p15 {
        padding: 15px 15px 15px 15px;

    }

    .es-header .es-infoblock {
        padding: 15px 14px 15px 16px !important;
    }

    .email--nw .es-footer .es-infoblock,
    .email--nwbus .es-footer .es-infoblock,
    .email--iompersonal .es-footer .es-infoblock {
        padding: 31px 30px 26px 31px !important;
    }

    .email--rbs .es-footer .es-infoblock,
    .email--rbsbus .es-footer .es-infoblock,
    .email--ulsnibus .es-footer .es-infoblock,
    .email--ulsroibus .es-footer .es-infoblock {
        padding: 30px 30px 45px 31px !important;
    }

    .email--rbs .logo,
    .email--rbsbus .logo {
        height: 44px;
        width: 164px;
        background-size: cover;
        object-fit: cover;
    }

	.email--iompersonal .logo {
        height: 37px;
        width: 380px;
        background-size: cover;
        object-fit: cover;
    }

	.email--iompersonal .left .logo {
        padding-left: 17px;
          }

    .email--ulsnibus .logo,
    .email--ulsroibus .logo {
        height: 40px;
        width: 145px;
        background-size: cover;
        object-fit: cover;
    }

    .email--nw .logo,
    .email--nwbus .logo {
        height: 61px;
        width: 55px;
        background-size: cover;
        object-fit: cover;
    }


    .email--nwi .logo {
        height: 62px !important;
        width: 55px;
        background-size: cover;
        object-fit: cover;
    }

    .email--rbs .logo_text,
    .email--rbsbus .logo_text {
        padding: 28px 27px 28px 27px;

    }

    .email--ulsnibus .logo_text,
    .email--ulsroibus .logo_text {
        padding: 47px 27px 47px 27px;

    }

    .email--nw .logo_text,
    .email--nwbus .logo_text {
        padding: 28px 28px 28px 28px;

    }

    .email--iompersonal .logo_text {
        padding: 28px 28px 28px 28px;

    }


    @media screen and (max-width:600px) {

        .em__header .es-infoblock p:first-child {
            margin-bottom: 0px;
        }

        .es-header .es-infoblock {
            padding: 15px 15px 15px 15px !important;
        }

        .email--rbs .logo,
        .email--rbsbus .logo {
            height: 38px;
            width: 142px;
            float: right;
        }

        .email--ulsnibus .logo,
        .email--ulsroibus .logo {
            height: 32px;
            width: 115px;
            float: right;
        }

		.email--iompersonal .logo {
             height: 29px;
             width: 288px;
			 background-size: cover;
             object-fit: cover;
        }

        .email--nw .logo,
        .email--nwbus .logo {
            height: 45px;
            width: 41px;
            background-size: cover;
            object-fit: cover;
        }


        .email--nwi .logo {
            height: 46px !important;
            width: 41px;
            background-size: cover;
            object-fit: cover;
        }

        .email--rbs .logo_text,
        .email--rbsbus .logo_text {
            padding: 21px 21px 21px 21px;
        }

        .email--ulsnibus .logo_text,
        .email--ulsroibus .logo_text {
            padding: 18px 16px 18px 16px !important;
        }

        .email--nw .logo_text,
        .email--nwbus .logo_text,
        .email--iompersonal .logo_text  {
            padding: 14px 15px 16px 15px !important;
        }

        .es-header .pixel-14 {
            font-size: 14px;
        }

        .email--nw .es-footer td.es-infoblock,
        .email--nwbus .es-footer td.es-infoblock,
        .email--iompersonal .es-footer td.es-infoblock {
            padding: 23px 15px 13px 15px !important;
        }
]') || TO_CLOB(q'[
        .email--rbs .es-footer td.es-infoblock,
        .email--rbsbus .es-footer td.es-infoblock,
        .email--ulsnibus .es-footer td.es-infoblock,
        .email--ulsroibus .es-footer td.es-infoblock {
            padding: 25px 22px 7px 15px !important;
        }

        p,
        ul li,
        ol li {

            line-height: 18px !important
        }

        h1 {
            font-size: 24px !important;
            text-align: center;
            line-height: 120% !important
        }



        h3 {

            text-align: center;

        }



        .es-header-body p,
        .es-header-body ul li,
        .es-header-body ol li,
        .es-header-body a {
            font-size: 13px !important
        }

        .es-footer-body p,
        .es-footer-body ul li,
        .es-footer-body ol li,
        .es-footer-body a {
            font-size: 10px !important
        }

        .es-infoblock p,
        .es-infoblock ul li,
        .es-infoblock ol li,
        .es-infoblock a {
            font-size: 13px !important
        }

        *[class="gmail-fix"] {
            display: none !important
        }

        .es-m-txt-c,
        .es-m-txt-c h1,
        .es-m-txt-c h2,
        .es-m-txt-c h3 {
            text-align: center !important
        }

        .es-m-txt-r,
        .es-m-txt-r h1,
        .es-m-txt-r h2,
        .es-m-txt-r h3 {
            text-align: right !important
        }

        .es-m-txt-l,
        .es-m-txt-l h1,
        .es-m-txt-l h2,
        .es-m-txt-l h3 {
            text-align: left !important
        }

        .es-m-txt-r img,
        .es-m-txt-c img,
        .es-m-txt-l img {
            display: inline !important
        }

        .es-adaptive table,
        .es-btn-fw,
        .es-btn-fw-brdr,
        .es-left,
        .es-right {
            width: 100%;
        }

        #divider__container {
            width: 100%;
        }

        .es-content table,
        .es-header table,
        .es-footer table,
        .es-content,
        .es-footer,
        .es-header {
            max-width: 600px !important
        }

        .es-adapt-td {
            display: block !important;
            width: 100% !important
        }

        .adapt-img {
            width: 100% !important;
            height: auto !important
        }





        .es-mobile-hidden,
        .es-hidden {
            display: none !important
        }

        tr.es-desk-hidden,
        td.es-desk-hidden,
        table.es-desk-hidden {
            width: auto !important;
            overflow: visible !important;
            float: none !important;
            max-height: inherit !important;
            line-height: inherit !important
        }

        tr.es-desk-hidden {
            display: table-row !important
        }

        table.es-desk-hidden {
            display: table !important
        }

        td.es-desk-menu-hidden {
            display: table-cell !important
        }

        table.es-table-not-adapt,
        .esd-block-html table {
            width: auto !important
        }
        #divider__container {
            width: 100% !important;
        }
    }

    .es-legal-p {
    padding: 14px 12px 14px 19px;
    margin: 0;
    color: #4d4d4d;
}

.es-legal-p .comp-rich-text {
    float: left;
}

.aem-AuthorLayer-Edit .es-legal-p .comp-rich-text {
    float: none;
}
.aem-AuthorLayer-Edit .es-legal-p {
width:445px;
}
]') || TO_CLOB(q'[
.es-legal-p p,
.es-legal-p .comp-rich-text {
    height: auto;
    font-size: 11px;
    font-family: arial;
    line-height: 13px!important;
    overflow: hidden;
}

.without_borderline{
	padding-top: 10px;
}

.with_borderline{
	padding-top: 20px;
}



.comp-rich-text{
	font-size:13px;
	line-height:18px;
}

#onemaincol-center__rte .comp-rich-text{
    text-align:center!important;
}

.title-comp{
	font-size:19px !important;
    margin:0;

}
.onemain-title .title-comp{
text-align:left!important;
}

#onemaincol-center__title .title-comp{
    text-align:center!important;
}

    @media screen and (min-width:601px) {
    .email--nw .logo_text,
    .email--nwbus .logo_text {
        padding: 19px 20px 20px 20px !important;

    }
    #es-m-p20b{
        padding:15px !important;
    }

    #nw_phoimg {
        height: 285px;
        display: inline-block;
    }

    .horz__tdstarts {
        padding: 15px 15px 15px 35px !important
    }

    #hero-ill_horz {
        width: 600px !important;
    }

    #horz__img__td {
        width: 132px !important;
    }

    #horz_td {
        width: 290px !important;
        height:230px!important;
    }

    #horz__top__space {
        display: block !important;
    }
    #nw_topimg{
    height:200px!important;
    width:200px!important;
    }

    #nwhero_rightimg {
        height: 200px !important;
        width: 200px !important;
    }

    #es-hero-titleblock {
        padding-top: 102px;
        padding-bottom: 105px;
        display: block !important;
    }
    .es-mobile__border{
        display: none !important;
    }

	 .email--ulsnibus .campaignhero .logo,
     .email--ulsroibus .campaignhero .logo {
        width: 145px;
        height: 40px;
    }
    #horz_txtstrt{
        padding-bottom:0px !important;
    }
    .email--ulsnibus .hero-width,
    .email--ulsroibus .hero-width{
 		height: 147px! important;
        width: 244px! important;
     }
    .email--ulsnibus .es-hero-titlecomp td,
    .email--ulsroibus .es-hero-titlecomp td{
        padding: 16px 17px 26px 17px! important;
    }

    .email--ulsnibus .es-hero-titlecomp h2,
    .email--ulsroibus .es-hero-titlecomp h2{
    font-size: 30px! important;
    line-height: 35px! important;
    }
}

@media screen and (max-width:600px) {
    .es-mobile__border {
        display: table !important;
    }

    .es-hero-body {
        display: none;
    }

    .email--nw .campaignhero .logo,
    .email--nwbus .campaignhero .logo,
    .email--ulsnibus .campaignhero .logo,
    .email--ulsroibus .campaignhero .logo{
        height: 52px !important;
        width: 47px !important;

    }

}

.aem-AuthorLayer-Edit #campaign__herostarts{
width:100%;
}


.aem-AuthorLayer-Edit #xf__starts .aem-GridColumn--default--12,
#xf__starts .table,
.aem-AuthorLayer-Edit #xf__starts .aem-Grid-newComponent,.aem-AuthorLayer-Edit .aem-GridColumn--default--12{
    width: 600px;
    float: none;

    margin: 0px auto;
}
    @media screen and (min-width:601px) {
    #hero_left {
        width: 30px;
    }
    #titlefont{
        font-size:28px !important;
        line-height:32px !important;
    }
    #rbs__hero__image {
        height: 285px;
    }

    #hero_td {

        display: block !important;
    }
]') || TO_CLOB(q'[
    #rbs_ill-img {
        height: 223px !important;
        width: 223px !important;
    }

    #email_ill_img {
        height: 32px !important;
        line-height: 32px !important;

    }

    #hero_top {
        line-height: 0px;
        height: 0px;
    }

    #bg-image-illust,
    #rbs__hero__illu {
        width: 600px;
    }

    #bg-image-illust #hero_td {
        padding-left: 30px !important;
    }

     #hero_img{
        background-position: center !important;
        margin-left: 0px !important;
        margin-right: 30px !important;
        margin-top: 0px !important;
        float: right !important;
        text-align: center !important;
        width:223px !important;
        height:223px !important;
    }

     #hero_img__tr{
        float: right !important;
        padding-top:0px !important;
    }
    #illust_firsttitle,#illust__firsttitle,  #email__twill, #email_twill{
        width: 195px !important;
    }
    #illust_secondtitle, #illust__secondtitle, #illust___secondtitle{
        width: 270px !important;
    }
    #illust_thirdtitle, #illust__thirdtitle{
        width:173px !important;
    }
}

@media screen and (max-width:601px) {
    .hero__inline{
        position: absolute !important;
    }
    .hero__inline__tr{
        position: absolute !important;
        margin-top:30px !important;
    }

}


    @media screen and (min-width:601px) {
    .email--iompersonal .logo_text {
         padding: 19px 20px 20px 20px !important;

     }
     #horz_txtstrt{
        padding-bottom:0px !important;
    }
    #es-m-p20b{
        padding:15px !important;
    }
    }

 @media screen and (max-width:600px) {

     .email--iompersonal .campaignhero .logo {
         height: 52px !important;
         width: 47px !important;

     }

 }

 .aem-AuthorLayer-Edit #campaign__herostarts{
 width:100%;
 }

    @media screen and (min-width:601px) {
    #get__the--app{
       width:600px!important;
       }
   }
   @media screen and (min-width:600px) {
       #apptable {
           padding: 20px 50px 30px 50px !important;
       }
       #step {
           padding-top: 37px !important;
       }
       #appicons {
           padding-top: 28px !important;
       }
       #getheapp_appleimg,
       #getheapp_googleimg {
           background-position: center !important;
       }
   }

.table-row-0 .title-comp {
    font-size: 13px !important;
    text-align:left;
}

@media screen and (min-width:601px) {
#table__head{
padding:11px 0px 11px 11px!important
}
#table__body{
    padding:6px 11px 6px 11px!important;
    }

    #table{
    width:600px!important;
    }
}

@media screen and (max-width:600px) {

    #table .comp-rich-text,#table .comp-rich-text p,
    .table-row-0 .title-comp {
        font-size: 10px !important;
        line-height: 12px!important;

    }
    #table__body{
    padding:2px 5px 2px 5px!important;
    }

}
    .txtandicn-img img {
    height: 18px;
    width: 18px;

}

.txtandicn-img {
       vertical-align: top;
    word-break: break-all;

}

.txtandicn-rte h2,h3,h4 {
    margin: 0;
    padding: 0;
}

     @media screen and (min-width:601px) {
    #twothree-strt {
        padding-left: 30px;
        padding-right: 30px;
        display: flex;
    }

    #twothreecol_body {
        display: table;
        height: 100%;
        vertical-align:top;

    }
    .threecol_image{
    vertical-align:top;

    }
    #threecol_title {
        padding: 16px 0px 0px 0px !important;
    }
    #twothree_hide{
    display:block!important;
    }

    #twothree_tbl {
        display: table-cell;
        width:auto!important;
    }
]') || TO_CLOB(q'[
    #two__column #column__width {
        width: 264px !important;
    }

    #three__column #column__width {
        width: 166px !important;
    }

    #threecol_rte,
    #twocolumn__rte {
        padding: 7px 0px 0px 0px !important;
    }

    #twocolumn__title {
        padding: 17px 0px 0px 0px !important;
    }

    #threecol_ill {
        height: 86px!important;
        width: 86px;
    }

    #twothree_pho #threecol_td {
        display: inline-block!important;
    }


    #threecol_cta {
        padding-top: 12px !important;
    }

    #threecol_pho,
    #no__bgColor {
        height: 86px !important;
    }

    #twocol_pho,
    #twocol_img {
        height: 158px !important;
    }
    #twocol_ill{
    height:126px!important;
    width:126px!important;
    }
}

@media screen and (max-width:600px) {
    #twothree-strt {
        padding-left: 0px;
        padding-right: 0px
    }

}

#twocolumn__rte ul,#threecol_rte ul,
#twocolumn__rte ol,#threecol_rte ol{
list-style-position: inside;
}

    @media screen and (min-width:601px) {
    .email--nw #thirty-seven_split #thirty-sevenimg_ill,
    .email--nwbus #thirty-seven_split #thirty-sevenimg_ill,
    .email--iompersonal #thirty-seven_split #thirty-sevenimg_ill {
        height: 171px;
        width: 170px;
    }

    #thirty-seven_split #es-left,
    #thirty-seven_split #es-right {
        width: auto !important;
    }

    #es-emptyPad__top,
    #es-emptyPad__bottom {
        height: 0px;
    }

    #author__section--td,
    #thirty-seven_img {
        height: 240px !important;

    }

    .email--rbs #thirty-sevenimg_ill,
    .email--rbsbus #thirty-sevenimg_ill,
    .email--ulsnibus #thirty-sevenimg_ill,
    .email--ulsroibus #thirty-sevenimg_ill {
        height: 163px;
        width: 166px;
    }


    #thirtyseventy--text__comp {
        padding-bottom: 13px !important;
    }

    #thirty-sevenimg_lft #thirty-seven_secstarts {
        padding: 0px 30px 0px 30px !important;
    }

    #thirty-sevenimg_rht #thirty-seven_secstarts {
        padding: 0px 13px 0px 30px !important;
    }

}


#thirty-seven_split .title-comp {
    text-align: left;
}

.thirty-seven_secstarts {
    display: table-cell;
}

.aem-AuthorLayer-Edit .thirty-seven_secstarts {
    display: revert !important;
    padding: 0px !important;
}

.aem-AuthorLayer-Edit .author__section--td {
    padding: 0px 30px !important;
    width: 338px !important;
}

@media screen and (max-width:600px) {
    #thirty-sevenimg_pho {
        width: 100%;
    }

    #author__section--td {
        height: auto !important;
    }

}

    @media screen and (min-width:601px) {
    #mainone__starts{
        padding:0px!important;
        border-bottom: 2px solid #ffffff;
    }
    #main1innertbl {
        width: 540px !important;
    }

    #main1innertbl_noBorder{
        width: 600px !important;
    }

    #onemaintable1 {
        width: 600px!important;
    }

    #onemaintable2 {
        padding-top: 10px !important;
    }

    #table-bottom {
        line-height: 30px !important;
        height: 30px !important
    }

    #main1-ill_withbdr {
        height: 210px;
        width: 210px;
    }

    #main1-ill_withoutbdr {
        height: 240px;
        width: 240px;
    }

     #withoutbdr{
     height: 300px;
     width:600px;
     }
     #withbdr{
     height: 270px;
     width:540px;
     }
]') || TO_CLOB(q'[
    .img_container_no_border{
        height:300px !important;
    }

    .img_container_{
        height:270px !important;
        width:540px !important;
    }

    #onemain-title {
        padding: 20px 30px 0px 30px !important;
    }

    #onemain-rte {
        padding: 20px 30px 0px 30px !important;
    }

    #text_icons {
        padding: 0px 30px 0px !important;
    }

    #mainone_cta2,
    #mainone_cta1 {
        padding-top: 20px !important;
    }

    #mainone_cta2 {
     float:left;
      margin-left:15px!important;
    }

    #mainone_cta1 {
        float:right;
        margin-right:15px!important;
    }

    .showCta{
        padding:0px 30px !important;
    }

    #onemaincol-left{
        float:left !important;
    }

    #onemaincol-center{
        text-align: center !important;
    }

    .onemaincol-center{
        text-align: center !important;
    }

    .mainone_cta1_with_scta {
        float:right !important;
    }

   .mainone_cta2_with_scta {
        float:left !important;
    }

    #mainone__hide {
        display: table-cell !important;
    }

    #onemain-addesc {
        padding: 20px 30px 0px 30px !important;
    }

    #legal-top {
        padding:0px 30px 0px 30px !important;
    }

    #es-legal-p {
        margin: 0;
        color: #4d4d4d;
    }

    #mainone__cta{
    width:50%!important;;
    }
    #onemain-rte li{
    margin:0px;
    }

}

#mainone_cta1 .cta-secondary .cta__text,
#mainone_cta2 .cta-secondary .cta__text {
    padding: 0px 3px !important;
}

#onemaincol-left .cta-secondary{
    float:left !important;
    width: auto !important;
}

#onemain-rte li {

    line-height: 18px;
    letter-spacing: -0.13px;

    padding-bottom: 11px;
    padding-left: 4px;

}

#onemain-rte li {
    list-style-position: outside;
}

#onemain-rte p {
    margin: 0;
}

#onemain-rte ul {
    padding-left: 14px;
    margin: 0;
    padding-top: 8px;

}

#text_icons li{
	padding-left:20px !important;
}

.aem-AuthorLayer-Edit .txtandicn-rte {
    width: 100%;
    position: relative;
    left: 10px;
    text-align:left;
}


</style>
]') || TO_CLOB(q'[

    <div class="es-wrapper-color">

    <!--[if gte mso 9]>
			<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
				<v:fill type="tile" color="#fff"></v:fill>
			</v:background>
		<![endif]-->

    <table class="email--nw" id="email--nw" color="#4c4c4c" width="100%" cellspacing="0" cellpadding="0">
      <tbody>
        <tr>
          <td width="100%" class="esd-email-paddings" valign="top">
            <div>
              <table cellpadding="0" cellspacing="0" class="es-content esd-header-popover" align="center" bgcolor="#fff"
                style="background-color:#fff">
                <tbody>
                  <tr>
                    <td class="es-adaptive esd-stripe" align="center" id="es-adaptive">
                      <table class="es-content-body" style="background-color: transparent; width:100%!important"
                        width="600" cellspacing="0" cellpadding="0" align="center">
                        <tbody>
                        ]') || TO_CLOB(q'[
                          <tr>
                            <td class="esd-structure " align="left">
                              <table width="100%" cellspacing="0" cellpadding="0" class="es-header">
                                <tbody>
                                  <tr>
                                    <td class="esd-container-frame" width="600" valign="top" align="center">
                                      <table width="100%" cellspacing="0" cellpadding="0">
                                        <tbody>
                                          <tr>
                                            <td align="left" class="">
                                              <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
                                                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                                  <tbody>
                                                    <tr>
                                                      <td width="600" style="padding-top:0px; padding-bottom:0px;">
                                                        <table id="campaign__herostarts" class="container"
                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;"
                                                          border="0" cellpadding="0" cellspacing="0" align="center"
                                                          bgcolor="#5A287D">
                                                          <tr style="border-collapse:collapse">
                                                            <td style="padding:0;margin:0;">
                                                              <table cellpadding="0" cellspacing="0"
                                                                class="es-header es-logo" align="center"
                                                                bgcolor="#5a287d">
                                                                ]') || TO_CLOB(q'[
                                                                <tbody>
                                                                  <tr style=" border-collapse:collapse">
                                                                    <td align="center" style="padding:0;Margin:0;">
                                                                      <table class="es-logo-body" bgcolor="#5a287d"
                                                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:100%!important"
                                                                        cellspacing="0" cellpadding="0" align="center">
                                                                        <tbody>
                                                                          <tr style="border-collapse:collapse">
                                                                            <td class="es-m-logo-td" align="left"
                                                                              style="Margin:0">
                                                                              <table width="100%" cellspacing="0"
                                                                                cellpadding="0" bgcolor="#5a287d"
                                                                                style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                                                <tbody>
                                                                                  <tr style="border-collapse:collapse">
                                                                                    <td valign="top" align="center"
                                                                                      style="padding:0;Margin:0;width:600px">
                                                                                      <table width="100%"
                                                                                        cellspacing="0" cellpadding="0"
                                                                                        role="presentation"
                                                                                        bgcolor="#5a287d"
                                                                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                                                        <tbody>
                                                                                        ]') || TO_CLOB(q'[
                                                                                          <tr
                                                                                            style="border-collapse:collapse">
                                                                                            <td class="logo_text"
                                                                                              align="left"
                                                                                              bgcolor="#5a287d"
                                                                                              style="Margin:0;font-size:0;padding:28px 28px 28px 28px;">
                                                                                              <a target="_self"
                                                                                                class="left"
                                                                                                style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial;text-decoration:none;color:#666666"><img
                                                                                                  class="logo"
                                                                                                  src="https://www.natwest.com/content/dam/natwest/assets/business/email/logos/logo-email-nw-horizontal-stacked-2x.png"
                                                                                                  width="198"
                                                                                                  style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" /></a>
                                                                                            </td>
                                                                                          </tr>
                                                                                        </tbody>
                                                                                      </table>
                                                                                      ]') || TO_CLOB(q'[
                                                                                    </td>
                                                                                  </tr>
                                                                                </tbody>
                                                                              </table>
                                                                            </td>
                                                                          </tr>
                                                                        </tbody>
                                                                      </table>
                                                                    </td>
                                                                  </tr>
                                                                </tbody>
                                                              </table>
                                                            </td>
                                                          </tr>
                                                        </table>
                                                        <style type="text/css">
                                                          .dial {
                                                            background-image: url('https://www.natwest.com/content/dam/natwest/assets/business/email/png-illustrations/illus-email-purple-financial-healthcheck-pen-170x171.png');
                                                          }
                                                        </style>
                                                        ]') || TO_CLOB(q'[
                                                        <table width="100%" class="es-content hero-ill_horz"
                                                          id="hero-ill_horz" align="center" bgcolor="#5A287D"
                                                          cellspacing="0" cellpadding="0"
                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;">
                                                          <tbody>
                                                            <tr style="border-collapse:collapse">
                                                              <td class="horz__tdstarts" align="left"
                                                                style="Margin:0;padding: 0px;padding-top:30px;">
                                                                <!--[if mso]><table cellpadding="0" cellspacing="0"  class="es-right horz__img__td  " id="horz__img__td" align="right" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right;"><![endif]-->
                                                                <table width="100%" cellpadding="0" cellspacing="0"
                                                                  class="es-right horz__img__td  " id="horz__img__td"
                                                                  align="right"
                                                                  style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right;">
                                                                  <tbody>
                                                                    <tr style="border-collapse:collapse">
                                                                      <td class="es-m-p20b" id="es-m-p20b" align="left"
                                                                        style="padding:0;Margin:0;width: 200px;">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                          width="100%"
                                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-position:center top"
                                                                          role="presentation">
                                                                          ]') || TO_CLOB(q'[
                                                                          <tbody>
                                                                            <tr
                                                                              style="border-collapse:collapse;text-align: center;">
                                                                              <td class="dial" align="center"
                                                                                style="padding:0;Margin:0;background:url('https://www.natwest.com/content/dam/natwest/assets/business/email/png-illustrations/illus-email-purple-financial-healthcheck-pen-170x171.png') no-repeat center/ 100% 100%;background-size:100% 100%;background-repeat:no-repeat;display:inline-block;">
                                                                                <!--[if gte mso 9]>
                                                                                <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"
                                                                                style=width:200px;height:200px;position:absolute;">
                                                                                <v:fill type="frame" src="https://www.natwest.com/content/dam/natwest/assets/business/email/png-illustrations/illus-email-purple-financial-healthcheck-pen-170x171.png" color="#5A287D" />
                                                                                <v:textbox inset="0,0,0,0">
                                                                                <![endif]-->
                                                                                ]') || TO_CLOB(q'[
                                                                                <img id="nwhero_rightimg"
                                                                                  src="https://www.natwest.com/content/dam/campaign/transparent.gif"
                                                                                  title="Dial" alt="Dial"
                                                                                  style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"
                                                                                  width="170" height="170" />
                                                                                <!--[if gte mso 9]>
                                                                                </v:textbox>
                                                                                </v:rect>
                                                                                <![endif]-->
                                                                              </td>
                                                                            </tr>
                                                                          </tbody>
                                                                        </table>
                                                                      </td>
                                                                    </tr>
                                                                  </tbody>
                                                                </table>
                                                                <!--[if mso]></table><![endif]-->
                                                                <!--[if mso]><table    cellpadding="0" valign="middle" cellspacing="0" class="es-left  horz_td" id="horz_td" align="left" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left;"><![endif]-->
                                                                <table width="100%" cellpadding="0" cellspacing="0"
                                                                  class="es-left  horz_td" id="horz_td" align="left"
                                                                  style="vertical-align:middle; mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left;">
                                                                  ]') || TO_CLOB(q'[
                                                                  <tbody>
                                                                    <tr style="border-collapse:collapse">
                                                                      <td id="horz_txtstrt" align="left"
                                                                        style="padding:0;padding-bottom:31px;Margin:0;width:261px;text-align: center;vertical-align: middle;padding-top:29px;">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                          width="261"
                                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:261px!important;display: inline-block;"
                                                                          role="presentation">
                                                                          <tbody>
                                                                            <tr style="border-collapse:collapse">
                                                                              <td align="center"
                                                                                style="padding:0;Margin:0;word-break: break-word">
                                                                                <h2
                                                                                  style="Margin:0;mso-line-height-rule:exactly;font-family:Arial;font-size:22px;font-style:normal;font-weight:bold;color:#fff">
                                                                                  We need some more information</h2>
                                                                              </td>
                                                                            </tr>
                                                                            ]') || TO_CLOB(q'[
                                                                          </tbody>
                                                                        </table>
                                                                      </td>
                                                                    </tr>
                                                                  </tbody>
                                                                </table>
                                                                <!--[if mso]></table><![endif]-->
                                                              </td>
                                                            </tr>
                                                          </tbody>
                                                        </table>
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                ]') || TO_CLOB(q'[
                                                <style type="text/css">
                                                  . {
                                                    background-image: url('');
                                                    background-position: center;
                                                    background-size: cover;
                                                    background-repeat: no-repeat;
                                                  }

                                                  @media screen and (max-width:600px) {
                                                    . {
                                                      background-image: url('');
                                                      background-size: 100% 100%;
                                                    }
                                                  }
                                                </style>
                                                ]') || TO_CLOB(q'[
                                                <table id="onemaintable1" class="onemaintable1" width="100%"
                                                  align="center" border="0"
                                                  style="border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                  cellpadding="0" cellspacing="0">
                                                  <tr style="margin:0px; padding:0px;border-collapse: collapse;">
                                                    <td id="mainone__starts"
                                                      style="padding:20px 0px; border-bottom: 2px solid #ffffff; padding-top:20px !important; padding-bottom:0px;">
                                                      <!--[if mso]><table width="540" id="main1innertbl_noBorder" class="main1innertbl" border="0" align="center" style="width:540px;min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;" cellpadding="0" cellspacing="0"><![endif]-->
                                                      <table width="100%" id="main1innertbl_noBorder"
                                                        class="main1innertbl" border="0" align="center"
                                                        style="min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                        cellpadding="0" cellspacing="0">
                                                        ]') || TO_CLOB(q'[
                                                        <tr style="border-collapse: collapse;">
                                                          <td style="margin: 0;padding: 0px;" bgcolor="#5a287d">
                                                            <!--[if mso]><table width="540" id="onemaintable2" class="onemaintable2" cellpadding="0" cellspacing="0" border="0" style="width:600px;border-collapse: collapse;border-spacing: 0px;" align="center" bgcolor="#ffffff"><![endif]-->
                                                            <table width="100%" id="onemaintable2" class="onemaintable2"
                                                              cellpadding="0" cellspacing="0" border="0"
                                                              style="padding-top:3px;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                              align="center" bgcolor="#ffffff">
                                                              <tbody>
                                                                <tr id="onemaincol-left__rte" class="onemaincol-left"
                                                                  style="border-collapse: collapse;">
                                                                  <td id="onemain-rte" class="onemain-rte"
                                                                    style="font-size:13px;letter-spacing:-0.13px;line-height:18px;padding:20px 15px 0px 15px;">
                                                                    ]') || TO_CLOB(q'[
                                                                    <div class="comp-rich-text"
                                                                      style="color:#42145f;font-family:Arial;">
                                                                      <p>Hi ${firstname},</p>
                                                                      <p>&nbsp;</p>
                                                                      <p>We've been reviewing your mortgage application and we need some more information from you to keep your application on the move. Please provide this as soon as possible to prevent any delays to your application. Please ignore this if your application has been declined or you are no longer progressing with it.</p>
                                                                      <p>&nbsp;</p>
                                                                      <p>Log in to your mortgage dashboard to provide us with the requested information</p>
                                                                      <p>&nbsp;</p>
                                                                      <p>Thank you for choosing NatWest</p>
                                                                    </div>
                                                                  </td>
                                                                </tr>
                                                                ]') || TO_CLOB(q'[
                                                                <tr style="border-collapse: collapse;">
                                                                  <td id="onemaincol-left" class="showCta"
                                                                    style="padding:0;Margin:0;padding-top:0px;padding-left:15px;padding-right:15px;background-position:left top"
                                                                    align="left">
                                                                    <!--[if mso]><table id="onemaincol-left" style="width:100%;" cellpadding="0" cellspacing="0"><tr><td style="width:166px;"><![endif]-->
                                                                    <!--[if mso]><table   id="mainone__cta" cellspacing="0" cellpadding="0" align="left" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;"> <![endif]-->
                                                                    <table width="100%" id="mainone__cta"
                                                                      cellspacing="0" cellpadding="0" align="right"
                                                                      style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left;width:100%!important">
                                                                      <tbody>
                                                                      ]') || TO_CLOB(q'[
                                                                        <tr style="border-collapse:collapse">
                                                                          <td id="mainone_cta1" class="mainone_cta1_"
                                                                            style="padding:20px 0px 0px 0px;Margin:0;width:166px;float:left"
                                                                            align="center">
                                                                            <table cellpadding="0" cellspacing="0"
                                                                              align="center" class="cta-primary"
                                                                              style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                                              <tbody>
                                                                                <tr style="border-collapse:collapse">
                                                                                  <td align="center" valign="top"
                                                                                    class="cta__starts"
                                                                                    style="padding:0;Margin:0;width:166px;padding-bottom:1px">
                                                                                    <table cellpadding="0"
                                                                                      cellspacing="0" width="100%"
                                                                                      role="presentation"
                                                                                      bgcolor="#5e10b1"
                                                                                      style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:166px!important;">
                                                                                      ]') || TO_CLOB(q'[
                                                                                      <tbody>
                                                                                        <tr
                                                                                          style="border-collapse:collapse">
                                                                                          <td align="center"
                                                                                            class="cta__text"
                                                                                            id="cta__text"
                                                                                            style="text-align:center;border:1px solid #5e10b1;background:#5e10b1;color:#ffffff;">
                                                                                            <!--[if mso]>
                                                                                            <v:rect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word"
                                                                                            href=${dashboardLink}
                                                                                            style="height:66px;v-text-anchor:middle;border:1px solid #5e10b1;width:156px;color:#ffffff"
                                                                                            strokecolor="#5e10b1"   fillcolor="#5e10b1">
                                                                                            <w:anchorlock/>
                                                                                            <center>
                                                                                            ]') || TO_CLOB(q'[
                                                                                            <![endif]-->
                                                                                            <a class="email__cta"
                                                                                              href=${dashboardLink}
                                                                                              title="Log in to your mortgage dashboard"
                                                                                              target="_blank"
                                                                                              rel="noopener" role="link"
                                                                                              aria-labelledby="Go to your mortgage dashboard"
                                                                                              style="display:block;font-weight:bold;mso-style-priority:100 !important;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial;font-size:13px;line-height:18px;text-align:center;text-decoration:none;color:#ffffff">
                                                                                              <span
                                                                                                class="es-button-border"
                                                                                                style="color:#ffffff;display:block;padding:16px 15px 14px 15px;text-decoration:none">Go
                                                                                                to your mortgage
                                                                                                dashboard</span>
                                                                                            </a>
                                                                                            <!--[if mso]>
                                                                                            </center>
                                                                                            </v:rect>
                                                                                            <![endif]-->
                                                                                          </td>
                                                                                        </tr>
                                                                                      </tbody>
                                                                                    </table>
                                                                                  </td>
                                                                                </tr>
                                                                              </tbody>
                                                                            </table>
                                                                          </td>
                                                                        </tr>
                                                                      </tbody>
                                                                    </table>
                                                                    ]') || TO_CLOB(q'[
                                                                    <!--[if mso]></table> <![endif]-->
                                                                    <!--[if mso]></td><td style="width:24px"></td><td style="width:166px;"><![endif]-->
                                                                    <!--[if mso]></td><td style="width:180px"></td></tr></table><![endif]-->
                                                                  </td>
                                                                </tr>
                                                                <tr style="border-collapse: collapse;">
                                                                  <td colspan="3" height="30"
                                                                    style="line-height:30px;mso-line-height-rule:exactly;padding: 0px;"
                                                                    id="table-bottom">
                                                                    &nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                            <!--[if mso]></table><![endif]-->
                                                          </td>
                                                        </tr>
                                                      </table>
                                                      ]') || TO_CLOB(q'[
                                                      <!--[if mso]></table><![endif]-->
                                                    </td>
                                                  </tr>
                                                </table>
                                                <div style="clear:both;float:none"></div>
                                                <table cellpadding="0" cellspacing="0" class="divider__container"
                                                  id="divider__container" height="10" style="width:100%" border="0"
                                                  align="center">
                                                  <tr align="center">
                                                    <td width="100%" valign="center"
                                                      style="vertical-align:center !important;" class="">
                                                      <hr
                                                        style="background: #5a287d; border: none; color: #5a287d;margin:8px 0px; height: 2px;line-height:2px;mso-line-height-rule:exactly;" />
                                                    </td>
                                                  </tr>
                                                </table>
                                                ]') || TO_CLOB(q'[
                                                <style type="text/css">
                                                  . {
                                                    background-image: url('');
                                                    background-position: center;
                                                    background-size: cover;
                                                    background-repeat: no-repeat;
                                                  }

                                                  @media screen and (max-width:600px) {
                                                    . {
                                                      background-image: url('');
                                                      background-size: 100% 100%;
                                                    }
                                                  }
                                                </style>
                                                ]') || TO_CLOB(q'[
                                                <table id="onemaintable1" class="onemaintable1" width="100%"
                                                  align="center" border="0"
                                                  style="border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                  cellpadding="0" cellspacing="0">
                                                  ]') || TO_CLOB(q'[
                                                  <tr style="margin:0px; padding:0px;border-collapse: collapse;">
                                                    <td id="mainone__starts"
                                                      style="padding:20px 0px; border-bottom: 2px solid #ffffff; padding-top:0px; padding-bottom:0px;">
                                                      <!--[if mso]><table width="540" id="main1innertbl_noBorder" class="main1innertbl" border="0" align="center" style="width:540px;min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;" cellpadding="0" cellspacing="0"><![endif]-->
                                                      <table width="100%" id="main1innertbl_noBorder"
                                                        class="main1innertbl" border="0" align="center"
                                                        style="min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                        cellpadding="0" cellspacing="0">
                                                        <tr style="border-collapse: collapse;">
                                                          <td style="margin: 0;padding: 0px;" bgcolor="#ffffff">
                                                            <!--[if mso]><table width="540" id="onemaintable2" class="onemaintable2" cellpadding="0" cellspacing="0" border="0" style="width:600px;border-collapse: collapse;border-spacing: 0px;" align="center" bgcolor="#ffffff"><![endif]-->
                                                            <table width="100%" id="onemaintable2" class="onemaintable2"
                                                              cellpadding="0" cellspacing="0" border="0"
                                                              style="padding-top:3px;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                              align="center" bgcolor="#ffffff">
                                                              <tbody>]') || TO_CLOB(q'[
                                                                <tr style="border-collapse: collapse;">
                                                                  <td id="text_icons" class="text_icons"
                                                                    style="font-size:13px;letter-spacing:-0.13px;line-height:18px;padding:0px 15px;">
                                                                    <table cellpadding="0" cellspacing="0">
                                                                      <tr style="border-collapse: collapse;">
                                                                        <td style="width: 491px">
                                                                          <table cellpadding="0" cellspacing="0">
                                                                            <tr class="icon-text-row">
                                                                              <td class="txtandicn-img"
                                                                                style="padding:20px 10px 0px 0px;">
                                                                                <img height="14" width="14"
                                                                                  src="https://www.natwest.com/content/dam/natwest_com/student-ucas-emails/nw-images/nw-pers-icon-phone.jpg"
                                                                                  alt="online"
                                                                                  style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;max-width:none!important;"
                                                                                  data-emptytext="Image (Campaign)" />
                                                                              </td>
                                                                              ]') || TO_CLOB(q'[
                                                                              <td class="txtandicn-rte"
                                                                                style="padding-top:20px; vertical-align:bottom;">
                                                                                <div>
                                                                                  <div class="comp-rich-text"
                                                                                    style="color:#42145f;font-family:Arial;">
                                                                                    <p><b>Need some help?</b></p>
                                                                                    <p>&nbsp;</p>
                                                                                    <p>Make an appointment to speak to
                                                                                      one of our mortgage professionals,
                                                                                      on a&nbsp;phone&nbsp;or&nbsp;video
                                                                                      call.</p>
                                                                                    <p>&nbsp;</p>
                                                                                    <p>Call us on&nbsp;<b>0800 096
                                                                                        9527&nbsp;</b>(Relay UK: 18001
                                                                                      0800 096 9527).&nbsp;<span
                                                                                        class="pixel-11">Opening
                                                                                        hours:&nbsp;Mon-Fri 8am-6pm, Sat
                                                                                        9am-4pm, Sun Closed. Excluding
                                                                                        public holidays.</span></p>
                                                                                    <p>&nbsp;</p>
                                                                                    <p><b>Please note, Online Only
                                                                                        products are only available
                                                                                        through our website.</b></p>
                                                                                  </div>
                                                                                </div>
                                                                              </td>
                                                                            </tr>
                                                                          </table>
                                                                        </td>
                                                                      </tr>
                                                                    </table>
                                                                  </td>
                                                                </tr>
                                                                ]') || TO_CLOB(q'[
                                                                <tr style="border-collapse: collapse;">
                                                                  <td colspan="3" height="30"
                                                                    style="line-height:30px;mso-line-height-rule:exactly;padding: 0px;"
                                                                    id="table-bottom">
                                                                    &nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                            <!--[if mso]></table><![endif]-->
                                                          </td>
                                                        </tr>
                                                      </table>
                                                      <!--[if mso]></table><![endif]-->
                                                    </td>
                                                  </tr>
                                                </table>
                                                <div style="clear:both;float:none"></div>
                                                <link rel="stylesheet"
                                                  href="/libs/cq/experience-fragments/components/xfpage/content.min.css"
                                                  type="text/css" />
                                                <div class="xf-content-height">
                                                  <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
                                                    ]') || TO_CLOB(q'[
                                                    <style type="text/css">
                                                      . {
                                                        background-image: url('');
                                                        background-position: center;
                                                        background-size: cover;
                                                        background-repeat: no-repeat;
                                                      }

                                                      @media screen and (max-width:600px) {
                                                        . {
                                                          background-image: url('');
                                                          background-size: 100% 100%;
                                                        }
                                                      }
                                                    </style>
                                                    <table id="onemaintable1" class="onemaintable1" width="100%"
                                                      align="center" border="0"
                                                      style="border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                      cellpadding="0" cellspacing="0">
                                                      <tr style="margin:0px; padding:0px;border-collapse: collapse;">
                                                        <td id="mainone__starts"
                                                          style="padding:20px 0px; border-bottom: 2px solid #ffffff; padding-top:0px; padding-bottom:0px;">
                                                          <!--[if mso]><table width="540" id="main1innertbl_noBorder" class="main1innertbl" border="0" align="center" style="width:540px;min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;" cellpadding="0" cellspacing="0"><![endif]-->
                                                          <table width="100%" id="main1innertbl_noBorder"
                                                            class="main1innertbl" border="0" align="center"
                                                            style="min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                            cellpadding="0" cellspacing="0">
                                                            ]') || TO_CLOB(q'[
                                                            <tr style="border-collapse: collapse;">
                                                              <td style="margin: 0;padding: 0px;" bgcolor="#ffffff">
                                                                <!--[if mso]><table width="540" id="onemaintable2" class="onemaintable2" cellpadding="0" cellspacing="0" border="0" style="width:600px;border-collapse: collapse;border-spacing: 0px;" align="center" bgcolor="#ffffff"><![endif]-->
                                                                <table width="100%" id="onemaintable2"
                                                                  class="onemaintable2" cellpadding="0" cellspacing="0"
                                                                  border="0"
                                                                  style="padding-top:3px;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                                  align="center" bgcolor="#ffffff">
                                                                  <tbody>
                                                                    <tr style="border-collapse: collapse;">
                                                                      <td class="legal-top" id="legal-top"
                                                                        style="padding:0px 15px 0px 15px">
                                                                        <!--[if mso]> <table width="100%" class="with_borderline" border="0" cellpadding="0" cellspacing="0"><![endif]-->
                                                                        <table width="100%" id="es-legal--table"
                                                                          class="es-legal--table with_borderline"
                                                                          align="center" border="0" cellpadding="0"
                                                                          cellspacing="0">
																		  ]') || TO_CLOB(q'[
                                                                          <tr>
                                                                            <td
                                                                              style="vertical-align:center !important; border: 2px solid #5a287d">
                                                                              <table class="" border="0" cellpadding="0"
                                                                                cellspacing="0">
                                                                                <tr style="margin:0px; padding:0px">
                                                                                  <!--[if mso]> <td><![endif]-->
                                                                                  <td id="es-legal-p" class="es-legal-p"
                                                                                    style="font-size:11px; font-family:arial; line-height:13px;padding:20px;margin: 0;">
                                                                                    <div />
                                                                                    <div class="comp-rich-text"
                                                                                      style="color:#42145f;font-family:Arial;">
                                                                                      <p>YOUR HOME MAY BE REPOSSESSED IF
                                                                                        YOU DO NOT KEEP UP REPAYMENTS ON
                                                                                        YOUR MORTGAGE</p>
                                                                                    </div>
                                                                                  </td>
                                                                                  <!--[if mso]></td><![endif]-->
                                                                                </tr>
                                                                              </table>
                                                                            </td>
                                                                          </tr>
                                                                        </table>
                                                                        <!--[if mso]> </table> <![endif]-->
                                                                      </td>
                                                                    </tr>
                                                                    ]') || TO_CLOB(q'[
                                                                    <tr style="border-collapse: collapse;">
                                                                      <td colspan="3" height="30"
                                                                        style="line-height:30px;mso-line-height-rule:exactly;padding: 0px;"
                                                                        id="table-bottom">
                                                                        &nbsp;</td>
                                                                    </tr>
                                                                  </tbody>
                                                                </table>
                                                                <!--[if mso]></table><![endif]-->
                                                              </td>
                                                            </tr>
                                                          </table>
                                                          <!--[if mso]></table><![endif]-->
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <div style="clear:both;float:none"></div>
                                                    ]') || TO_CLOB(q'[
                                                  </div>
                                                </div>
                                              </div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div>
              <div>
                <!--<sly data-sly-include="logo.html"/>-->
                <table cellpadding="0" cellspacing="0" class="es-header es-logo" align="center">
                  <tbody>
                    <tr style=" border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0">
                        <table class="es-logo-body" bgcolor="#5a287d"
                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:100%!important"
                          cellspacing="0" cellpadding="0" align="center">
                          <tbody>
                            <tr style="border-collapse:collapse">
                              <td class="es-m-logo-td" align="left" style="Margin:0">
                                <table width="100%" cellspacing="0" cellpadding="0"
                                  style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                  <tbody>
                                    <tr style="border-collapse:collapse">
                                      <td valign="top" align="center" style="padding:0;Margin:0;width:600px">
                                        <table width="100%" cellspacing="0" cellpadding="0" role="presentation"
                                          bgcolor="#5a287d"
                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                          <tbody>
                                            <tr style="border-collapse:collapse">
                                              <td class="logo_text" align="center" bgcolor="#5a287d"
                                                style="Margin:0;font-size:0;padding:28px 28px 28px 28px;">
                                                <a target="_self"
                                                  style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial;text-decoration:none;color:#666666"><img
                                                    class="logo"
                                                    src="https://www.natwest.com/content/dam/natwest/assets/personal/email/logos/logo-email-nw-stacked-x2.png.png"
                                                    width="55" alt="NatWest logo"
                                                    style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" /></a>
                                              </td>
                                            </tr>]') || TO_CLOB(q'[
                                          </tbody>
                                        </table>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
          </td>
        </tr>
      </tbody>
    </table>

</div>

${templateFooter}
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>]'), 'flow-management-customer-fya-notification-xo', 'This template will be used to share FYA information with the customer for xo from flow management', 'MAIN');

-- insert Customer Reminder FYA Email Template in TEMPLATE table for xo channel

INSERT INTO template(content, name, description, type)
VALUES (TO_CLOB(q'[
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>Application-complete</title>
    <link rel="shortcut icon" href="/apps/settings/wcm/designs/responsive_campaign_natwest_personal/clientlibs/resources/favicon.ico"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
     <meta http-equiv="Content-Type" content="text/html" ; charset="UTF-8"/>
    <meta content="width=device-width, initial-scale=1" name="viewport"/><meta name="x-apple-disable-message-reformatting"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta content="telephone=no" name="format-detection"/>
    <meta name="robots" content="noindex"/>]') || TO_CLOB(q'[
     <style type="text/css">#divider__container{width:600px!important}
@media screen and (max-width:600px){#hero_img{background-position:center!important;margin-left:30px!important;margin-right:0!important;margin-top:25px!important;float:left!important;display:inline-block!important;text-align:center!important}
#hero_mobile{display:block!important}}.header__first{margin-bottom:32px}.cta-primary .cta__starts{width:177px}
#outlook a{padding:0}.left{float:left}.right{float:right}.ExternalClass{width:100%}.ExternalClass,.ExternalClass div,.ExternalClass font,.ExternalClass p,.ExternalClass span,.ExternalClass td{line-height:100%}
a[x-apple-data-detectors]{color:inherit!important;text-decoration:none!important;font-size:inherit!important;font-family:inherit!important;font-weight:inherit!important;line-height:inherit!important}.es-desk-hidden{display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0;mso-hide:all}
.es-footer .pixel-13,.es-header .pixel-13{font-size:13px;line-height:18px;display:inline-block}a{color:#1d7b8a!important;text-decoration:underline}
.es-header .pixel-14{font-size:14px;display:inline-block}.es-footer .pixel-14{font-size:14px;display:inline-block}.es-footer p{margin-bottom:27px}
body{color:#4c4c4c;font-family:Arial;margin:0}p{margin:0}.es-p15{padding:15px 15px 15px 15px}.es-header .es-infoblock{padding:15px 14px 15px 16px!important}
.email--iompersonal .es-footer .es-infoblock,.email--nw .es-footer .es-infoblock,.email--nwbus .es-footer .es-infoblock{padding:31px 30px 26px 31px!important}.email--rbs
.es-footer .es-infoblock,.email--rbsbus .es-footer .es-infoblock,.email--ulsnibus .es-footer .es-infoblock,.email--ulsroibus .es-footer .es-infoblock{padding:30px 30px 45px 31px!important}
.email--rbs .logo,.email--rbsbus .logo{height:44px;width:164px;background-size:cover;object-fit:cover}.email--iompersonal
.logo{height:37px;width:380px;background-size:cover;object-fit:cover}.email--iompersonal .left .logo{padding-left:17px}.email--ulsnibus .logo,.email--ulsroibus
.logo{height:40px;width:145px;background-size:cover;object-fit:cover}.email--nw .logo,.email--nwbus .logo{height:61px;width:55px;background-size:cover;object-fit:cover}.email--nwi
.logo{height:62px!important;width:55px;background-size:cover;object-fit:cover}.email--rbs .logo_text,.email--rbsbus .logo_text{padding:28px 27px 28px 27px}.email--ulsnibus
.logo_text,.email--ulsroibus .logo_text{padding:47px 27px 47px 27px}.email--nw .logo_text,.email--nwbus .logo_text{padding:28px 28px 28px 28px}.email--iompersonal .logo_text{padding:28px 28px 28px 28px}@media screen and (max-width:600px){.em__header .es-infoblock p:first-child{margin-bottom:0}]') || TO_CLOB(q'[
.es-header .es-infoblock{padding:15px 15px 15px 15px!important}.email--rbs .logo,.email--rbsbus .logo{height:38px;width:142px;float:right}.email--ulsnibus .logo,.email--ulsroibus .logo{height:32px;width:115px;float:right}.email--iompersonal .logo{height:29px;width:288px;background-size:cover;object-fit:cover}.email--nw .logo,.email--nwbus .logo{height:45px;width:41px;background-size:cover;object-fit:cover}.email--nwi .logo{height:46px!important;width:41px;background-size:cover;object-fit:cover}.email--rbs .logo_text,.email--rbsbus .logo_text{padding:21px 21px 21px 21px}.email--ulsnibus .logo_text,.email--ulsroibus .logo_text{padding:18px 16px 18px 16px!important}.email--iompersonal .logo_text,.email--nw .logo_text,.email--nwbus .logo_text{padding:14px 15px 16px 15px!important}.es-header .pixel-14{font-size:14px}.email--iompersonal .es-footer td.es-infoblock,.email--nw .es-footer td.es-infoblock,.email--nwbus .es-footer td.es-infoblock{padding:23px 15px 13px 15px!important}.email--rbs .es-footer td.es-infoblock,.email--rbsbus .es-footer td.es-infoblock,.email--ulsnibus .es-footer td.es-infoblock,.email--ulsroibus .es-footer td.es-infoblock{padding:25px 22px 7px 15px!important}ol li,p,ul li{line-height:18px!important}h1{font-size:24px!important;text-align:center;line-height:120%!important}
h3{text-align:center}.es-header-body a,.es-header-body ol li,.es-header-body p,.es-header-body ul li{font-size:13px!important}.es-footer-body a,.es-footer-body ol li,.es-footer-body p,.es-footer-body ul li{font-size:10px!important}.es-infoblock a,.es-infoblock ol li,.es-infoblock p,.es-infoblock ul li{font-size:13px!important}[class=gmail-fix]{display:none!important}.es-m-txt-c,.es-m-txt-c h1,.es-m-txt-c h2,.es-m-txt-c h3{text-align:center!important}.es-m-txt-r,.es-m-txt-r h1,.es-m-txt-r h2,.es-m-txt-r h3{text-align:right!important}.es-m-txt-l,.es-m-txt-l h1,.es-m-txt-l h2,.es-m-txt-l h3{text-align:left!important}.es-m-txt-c img,.es-m-txt-l img,.es-m-txt-r img{display:inline!important}.es-adaptive table,.es-btn-fw,.es-btn-fw-brdr,.es-left,.es-right{width:100%}#divider__container{width:100%}.es-content,.es-content table,.es-footer,.es-footer table,.es-header,.es-header table{max-width:600px!important}.es-adapt-td{display:block!important;width:100%!important}.adapt-img{width:100%!important;height:auto!important}.es-hidden,.es-mobile-hidden{display:none!important}table.es-desk-hidden,td.es-desk-hidden,
tr.es-desk-hidden{width:auto!important;overflow:visible!important;float:none!important;max-height:inherit!important;line-height:inherit!important}tr.es-desk-hidden{display:table-row!important}table.es-desk-hidden{display:table!important}td.es-desk-menu-hidden{display:table-cell!important}.esd-block-html table,]') || TO_CLOB(q'[table.es-table-not-adapt{width:auto!important}#divider__container{width:100%!important}}.es-legal-p{padding:14px 12px 14px 19px;margin:0;color:#4d4d4d}.es-legal-p .comp-rich-text{float:left}.es-legal-p .comp-rich-text,.es-legal-p p{height:auto;font-size:11px;font-family:arial;line-height:13px!important;overflow:hidden}.without_borderline{padding-top:10px}.with_borderline{padding-top:20px}.comp-rich-text{font-size:13px;line-height:18px}#onemaincol-center__rte .comp-rich-text{text-align:center!important}.title-comp{font-size:19px!important;margin:0}.onemain-title .title-comp{text-align:left!important}#onemaincol-center__title .title-comp{text-align:center!important}@media screen and (min-width:601px){.email--nw .logo_text,.email--nwbus .logo_text{padding:19px 20px 20px 20px!important}#es-m-p20b{padding:15px!important}#nw_phoimg{height:285px;display:inline-block}.horz__tdstarts{padding:15px 15px 15px 35px!important}#hero-ill_horz{width:600px!important}#horz__img__td{width:132px!important}#horz_td{width:290px!important;height:230px!important}#horz__top__space{display:block!important}#nw_topimg{height:200px!important;width:200px!important}#nwhero_rightimg{height:200px!important;width:200px!important}#es-hero-titleblock{padding-top:102px;padding-bottom:105px;display:block!important}.es-mobile__border{display:none!important}.email--ulsnibus .campaignhero .logo,.email--ulsroibus .campaignhero .logo{width:145px;height:40px}#horz_txtstrt{padding-bottom:0!important}.email--ulsnibus .hero-width,.email--ulsroibus
.hero-width{height:147px!important;width:244px!important}.email--ulsnibus .es-hero-titlecomp td,.email--ulsroibus .es-hero-titlecomp td{padding:16px 17px 26px 17px!important}.email--ulsnibus .es-hero-titlecomp h2,.email--ulsroibus .es-hero-titlecomp h2{font-size:30px!important;line-height:35px!important}}@media screen and (max-width:600px){.es-mobile__border{display:table!important}.es-hero-body{display:none}.email--nw .campaignhero .logo,.email--nwbus .campaignhero .logo,.email--ulsnibus .campaignhero .logo,.email--ulsroibus .campaignhero .logo{height:52px!important;width:47px!important}}#xf__starts .table{width:600px;float:none;margin:0 auto}@media screen and (min-width:601px){#hero_left{width:30px}#titlefont{font-size:28px!important;line-height:32px!important}#rbs__hero__image{height:285px}#hero_td{display:block!important}#rbs_ill-img{height:223px!important;width:223px!important}#email_ill_img{height:32px!important;line-height:32px!important}#hero_top{line-height:0;height:0}#bg-image-illust,#rbs__hero__illu{width:600px}#bg-image-illust #hero_td{padding-left:30px!important}#hero_img{background-position:center!important;margin-left:0!important;margin-right:30px!important;margin-top:0!important;float:right!important;text-align:center!important;width:223px!important;height:223px!important}#hero_img__tr{float:right!important;padding-top:0!important}#email__twill,#email_twill,#illust__firsttitle,#illust_firsttitle{width:195px!important}#illust___secondtitle,#illust__secondtitle,#illust_secondtitle{width:270px!important}#illust__thirdtitle,#illust_thirdtitle{width:173px!important}}@media screen and (max-width:601px){.hero__inline{position:absolute!important}.hero__inline__tr{position:absolute!important;margin-top:30px!important}}@media screen and (min-width:601px){.email--iompersonal .logo_text{padding:19px 20px 20px 20px!important}#horz_txtstrt{padding-bottom:0!important}#es-m-p20b{padding:15px!important}}@media screen and (max-width:600px){.email--iompersonal .campaignhero
.logo{height:52px!important;width:47px!important}}@media screen and (min-width:601px){#get__the--app{width:600px!important}}@media screen and (min-width:600px){#apptable{padding:20px 50px 30px 50px!important}#step{padding-top:37px!important}#appicons{padding-top:28px!important}#getheapp_appleimg,]') || TO_CLOB(q'[#getheapp_googleimg{background-position:center!important}}.table-row-0 .title-comp{font-size:13px!important;text-align:left}
@media screen and (min-width:601px){#table__head{padding:11px 0 11px 11px!important}#table__body{padding:6px 11px 6px 11px!important}#table{width:600px!important}}@media screen and (max-width:600px){#table .comp-rich-text,#table .comp-rich-text p,.table-row-0 .title-comp{font-size:10px!important;line-height:12px!important}#table__body{padding:2px 5px 2px 5px!important}}.txtandicn-img img{height:18px;width:18px}.txtandicn-img{vertical-align:top;word-break:break-all}.txtandicn-rte h2,h3,h4{margin:0;padding:0}@media screen and (min-width:601px){#twothree-strt{padding-left:30px;padding-right:30px;display:flex}#twothreecol_body{display:table;height:100%;vertical-align:top}.threecol_image{vertical-align:top}
#threecol_title{padding:16px 0 0 0!important}#twothree_hide{display:block!important}#twothree_tbl{display:table-cell;width:auto!important}
#two__column #column__width{width:264px!important}#three__column #column__width{width:166px!important}#threecol_rte,#twocolumn__rte{padding:7px 0 0 0!important}#twocolumn__title{padding:17px 0 0 0!important}#threecol_ill{height:86px!important;width:86px}#twothree_pho #threecol_td{display:inline-block!important}#threecol_cta{padding-top:12px!important}#no__bgColor,#threecol_pho{height:86px!important}#twocol_img,#twocol_pho{height:158px!important}#twocol_ill{height:126px!important;width:126px!important}}@media screen and (max-width:600px){#twothree-strt{padding-left:0;padding-right:0}}#threecol_rte ol,#threecol_rte ul,#twocolumn__rte ol,#twocolumn__rte ul{list-style-position:inside}@media screen and (min-width:601px){.email--iompersonal #thirty-seven_split #thirty-sevenimg_ill,.email--nw #thirty-seven_split #thirty-sevenimg_ill,.email--nwbus #thirty-seven_split #thirty-sevenimg_ill{height:171px;width:170px}#thirty-seven_split #es-left,#thirty-seven_split #es-right{width:auto!important}#es-emptyPad__bottom,#es-emptyPad__top{height:0}#author__section--td,#thirty-seven_img{height:240px!important}.email--rbs #thirty-sevenimg_ill,.email--rbsbus #thirty-sevenimg_ill,.email--ulsnibus
#thirty-sevenimg_ill,.email--ulsroibus #thirty-sevenimg_ill{height:163px;width:166px}#thirtyseventy--text__comp{padding-bottom:13px!important}#thirty-sevenimg_lft #thirty-seven_secstarts{padding:0 30px 0 30px!important}#thirty-sevenimg_rht #thirty-seven_secstarts{padding:0 13px 0 30px!important}}#thirty-seven_split .title-comp{text-align:left}.thirty-seven_secstarts{display:table-cell}@media screen and (max-width:600px){#thirty-sevenimg_pho{width:100%}#author__section--td{height:auto!important}}@media screen and (min-width:601px){#mainone__starts{padding:0!important;border-bottom:2px solid #fff}#main1innertbl{width:540px!important}#main1innertbl_noBorder{width:600px!important}#onemaintable1{width:600px!important}#onemaintable2{padding-top:10px!important}#table-bottom{line-height:30px!important;height:30px!important}#main1-ill_withbdr{height:210px;width:210px}
#main1-ill_withoutbdr{height:240px;width:240px}#withoutbdr{height:300px;width:600px}#withbdr{height:270px;width:540px}.img_container_no_border{height:300px!important}.img_container_{height:270px!important;width:540px!important}#onemain-title{padding:20px 30px 0 30px!important}]') || TO_CLOB(q'[#onemain-rte{padding:20px 30px 0 30px!important}#text_icons{padding:0 30px 0!important}#mainone_cta1,#mainone_cta2{padding-top:20px!important}#mainone_cta2{float:left;margin-left:15px!important}#mainone_cta1{float:right;margin-right:15px!important}.showCta{padding:0 30px!important}#onemaincol-left{float:left!important}#onemaincol-center{text-align:center!important}.onemaincol-center{text-align:center!important}.mainone_cta1_with_scta{float:right!important}.mainone_cta2_with_scta{float:left!important}#mainone__hide{display:table-cell!important}#onemain-addesc{padding:20px 30px 0 30px!important}#legal-top{padding:0 30px 0 30px!important}#es-legal-p{margin:0;color:#4d4d4d}#mainone__cta{width:50%!important}#onemain-rte li{margin:0}}#mainone_cta1 .cta-secondary .cta__text,#mainone_cta2 .cta-secondary .cta__text{padding:0 3px!important}#onemaincol-left .cta-secondary{float:left!important;width:auto!important}#onemain-rte li{line-height:18px;letter-spacing:-.13px;padding-bottom:11px;padding-left:4px}#onemain-rte li{list-style-position:outside}#onemain-rte p{margin:0}#onemain-rte ul{padding-left:14px;margin:0;padding-top:8px}#text_icons li{padding-left:20px!important}</style>
</head>
<body>
	<!--[if (mso 16)]>
    <style type="text/css">
    a {text-decoration: underline;}
    </style>
    <![endif]-->
<!--[if gte mso 9]><style>sup { font-size: 100% !important; }
        </style>
    <![endif]-->
<!--[if gte mso 9]>
<xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG></o:AllowPNG>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
</xml>
<![endif]-->
<!--[if mso]>
<style type="text/css">

#horz_txtstrt{
height: 200px !important;
padding-bottom:0px !important;
}
 #es-m-p20b{
        padding:15px !important;
    }
#author__section--td,
#thirty-seven_img {
height: 240px !important;

}

.email--nw #thirty-seven_split #thirty-sevenimg_ill,
.email--nwbus #thirty-seven_split #thirty-sevenimg_ill,
.email--iompersonal #thirty-seven_split #thirty-sevenimg_ill {
height: 171px;
width: 170px;
}

#thirty-seven_split #es-left,
#thirty-seven_split #es-right {
width: auto !important;
}

#es-emptyPad__top,
#es-emptyPad__bottom {
height: 0px;
}

#hero_img__tr{
    float : right !important;
}
 #hero_leftbox{
    position: absolute !important;
    float:left !important;
}

#bg-image-illust #hero_td {
    padding-left: 30px !important;
    position: absolute !important;

}
#email_leftbox_desktop{
    float: left !important;
}
#hero_img{
    float: right !important;
    margin-top:0px !important;
    margin-right:30px !important;
    margin-left:0px !important;
    background-position: center !important;
    display:inline-block !important;
    text-align:center !important;
}
 #rbs_ill-img{
    text-align:center !important;
 }
 #hero_img__tr{
    float:right !important;
    padding-top:0px !important;
}
  #titlefont{
        font-size:28px !important;
        line-height:32px !important;
    }

 @media screen and (max-width:600px) {
     #hero_img{
        float: left !important;
        background-position: center !important;
        display:inline-block !important;
        text-align:center !important;
        background-size: 100px 100px !important;
    }
     #rbs_ill-img{
    width: 175px !important;
    height: 175px !important;
  }

 }
 @media screen and (min-width:600px) {

  #hero_img{
      width:223px !important;
  }
}
#email__twill{
height:6px !important;
}

#illust_firsttitle,#illust__firsttitle,  #email__twill, #email_twill{
    width: 195px !important;
}
#illust_secondtitle, #illust__secondtitle, #illust___secondtitle{
    width: 270px !important;
}]') || TO_CLOB(q'[
#illust_thirdtitle, #illust__thirdtitle{
    width:173px !important;
}

#author__section--td,
#thirty-seven_img {
height: 240px !important;

}

.email--rbs #thirty-sevenimg_ill,
.email--rbsbus #thirty-sevenimg_ill {
height: 163px;
width: 166px;
}

.email--ulsnibus #thirty-sevenimg_ill,
.email--ulsroibus #thirty-sevenimg_ill {
height: 163px;
width: 166px;
}
 .email--ulsnibus .hero-width,
.email--ulsroibus .hero-width{
    height: 147px! important;
    width: 244px! important;
    }
.email--ulsnibus .es-hero-titlecomp td,
.email--ulsroibus .es-hero-titlecomp td{
    padding: 16px 17px 26px 17px! important;
}

.email--ulsnibus .es-hero-titlecomp h2,
.email--ulsroibus .es-hero-titlecomp h2{
font-size: 30px! important;
line-height: 35px! important;
}

#thirtyseventy--text__comp {
padding-bottom: 13px !important;
}

#thirty-sevenimg_lft #thirty-seven_secstarts {
padding: 0px 30px 0px 30px !important;
}

#thirty-sevenimg_rht #thirty-seven_secstarts {
padding: 0px 13px 0px 30px !important;
}
#table-bottom{
line-height:30px!important;
height:30px!important;
}
.email--nw .logo_text,
.email--nwbus .logo_text {
padding: 19px 20px 20px 20px !important;

}

#nw_phoimg {
height: 285px !important;
display: inline-block;
}

.horz__tdstarts {
padding: 15px 15px 15px 35px !important
}

#hero-ill_horz {
width: 600px !important;
}

.horz__img__td {
width: 132px !important;
}

.horz_td {
width: 290px !important;
}

#horz__top__space {
display: block !important;
}

#nwhero_rightimg {
height: 200px !important;
width: 200px !important;
}


#es-hero-titleblock {
padding-top: 102px;
padding-bottom: 105px;
display: block !important;
}

.es-mobile__border {
display: none !important;
}
#hero_left {
width: 30px;
}

#rbs__hero__image {
height: 285px;
}

#hero_td {

display: block !important;
}



#email_ill_img {
height: 32px !important;
line-height: 32px !important;

}

#hero_top {
line-height: 0px;
height: 0px;
}

#bg-image-illust,
#rbs__hero__illu {
width: 600px;
}

#bg-image-illust #hero_td {
padding-left: 30px !important;
}

#table__head {
padding: 11px 0px 11px 11px !important
}

#table__body {
padding: 6px 11px 6px 11px !important;
}

#apptable {

padding: 20px 50px 30px 50px !important;
}

#step {
padding-top: 37px !important;
}

#appicons {
padding-top: 28px !important;
}

#getheapp_appleimg,
#getheapp_googleimg {
background-position: center !important;
}

#twothree-strt {
padding-left: 30px;
padding-right: 30px
}

#threecol_title {
padding: 16px 0px 0px 0px !important;
}


#threecol_rte,
#twocolumn__rte {
padding: 7px 0px 0px 0px !important;
}

#two__column #column__width {
width: 264px !important;
}

#three__column #column__width {
width: 166px !important;
}

#twocolumn__title {
padding: 17px 0px 0px 0px !important;
}

#threecol_ill {
height: 86px;
width: 86px;
}

#threecol_cta {
padding-top: 12px !important;
}

#threecol_pho,
#no__bgColor {
height: 86px !important;
}

#twocol_pho,
#twocol_img {
height: 158px !important;
}


.email--nw .es-footer .es-infoblock,
.email--nwbus .es-footer .es-infoblock,
.email--iompersonal .es-footer .es-infoblock  {
padding: 31px 30px 26px 31px !important;
}

#onemain-rte p {
padding-bottom: 8px;
}

#onemain-rte ul {
padding: 0;
margin: 0;
margin-top: 8px;
}

#onemain-rte li {
margin: 0;
padding: 0;
margin-bottom: 11px;
margin-left: 25px;
margin-top:8px;
}

.es-legal-p p,
.es-legal-p .comp-rich-text {
mso-element-frame-height: 42px;
line-height:13px;
}

#mainone__starts{
padding:0px!important;
}

#onemaintable2 {
    padding-top: 10px !important;
}

#main1-ill_withbdr {
    height: 210px;
    width: 210px;
}

#main1-ill_withoutbdr {
    height: 240px;
    width: 240px;
}
]') || TO_CLOB(q'[
.img_container_no_border{
    height:300px !important;
}

.img_container_{
    height:270px !important;
    width:540px !important;
}

#onemain-title {
padding: 20px 29px 0px 29px !important;
}

#onemain-rte {
padding: 20px 29px 0px 29px !important;
}

#text_icons {
padding: 0px 29px 0px !important;
}

#mainone_cta2,
#mainone_cta1 {
padding-top: 20px !important;
}

#mainone_cta2 {
float: left;
margin-left:15px!important;
}

#mainone_cta1 {
float: right;
margin-right:15px!important;
}

.showCta{
    padding:0px 30px !important;
}

#onemaincol-left{
    float:left !important;
}

#onemaincol-center{
    text-align: center !important;
}

.onemaincol-center{
    text-align: center !important;
}

.mainone_cta1_with_scta {
    float:right !important;
}

.mainone_cta2_with_scta {
    float:left !important;
}

#onemaincol-left .cta-secondary{
    float:left !important;
    width: auto !important;
}

#mainone__hide {
display: table-cell !important;
}

#onemain-addesc {
padding: 20px 29px 0px 29px !important;
}

#legal-top {
    padding:0px 30px 0px 30px !important;
}

#text_icons li{
	padding-left:20px !important;
}

#es-legal-p {
margin: 0;
color: #4d4d4d;
}

#mainone__cta{
 width:50%!important;;
 }

</style>
<![endif]-->


<style type="text/css" nonce>
/* Important - Remove aem-AuthorLayer-Edit styles and this commented line for minifying syles.Gmail have some css limitation */
    div {
        padding: 0px !important;
    }

    #divider__container {
        width: 600px !important;
    }

    @media screen and (max-width:600px) {
        #hero_img{
            background-position: center !important;
            margin-left: 30px !important;
            margin-right: 0px !important;
            margin-top: 25px !important;
            float:left !important;
            display:inline-block !important;
            text-align: center !important;
        }

        #hero_mobile {
            display: block !important;
        }

    }

    .header__first {
        margin-bottom: 32px
    }



    .cta-primary .cta__starts {
        width: 177px;
    }

    #outlook a {
        padding: 0;

    }

    .left {
        float: left;
    }

    .right {
        float: right;
    }

    .ExternalClass {
        width: 100%;
    }

    .ExternalClass,
    .ExternalClass p,
    .ExternalClass span,
    .ExternalClass font,
    .ExternalClass td,
    .ExternalClass div {
        line-height: 100%;
    }



    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }

    .es-desk-hidden {
        display: none;
        float: left;
        overflow: hidden;
        width: 0;
        max-height: 0;
        line-height: 0;
        mso-hide: all;
    }

    .es-header .pixel-13,
    .es-footer .pixel-13 {
        font-size: 13px;
        line-height: 18px;
        display: inline-block;

    }

    a {
        color: #1D7B8A !important;
        text-decoration: underline;
    }

    .es-header .pixel-14 {
        font-size: 14px;
        display: inline-block;
    }

    .es-footer .pixel-14 {
        font-size: 14px;
        display: inline-block;
    }

    .es-footer p {
        margin-bottom: 27px;
    }

    body {
        color: #4c4c4c;
        font-family: Arial;
        margin: 0px;

    }
]') || TO_CLOB(q'[
    p {
        margin: 0;
    }

    .es-p15 {
        padding: 15px 15px 15px 15px;

    }

    .es-header .es-infoblock {
        padding: 15px 14px 15px 16px !important;
    }

    .email--nw .es-footer .es-infoblock,
    .email--nwbus .es-footer .es-infoblock,
    .email--iompersonal .es-footer .es-infoblock {
        padding: 31px 30px 26px 31px !important;
    }

    .email--rbs .es-footer .es-infoblock,
    .email--rbsbus .es-footer .es-infoblock,
    .email--ulsnibus .es-footer .es-infoblock,
    .email--ulsroibus .es-footer .es-infoblock {
        padding: 30px 30px 45px 31px !important;
    }

    .email--rbs .logo,
    .email--rbsbus .logo {
        height: 44px;
        width: 164px;
        background-size: cover;
        object-fit: cover;
    }

	.email--iompersonal .logo {
        height: 37px;
        width: 380px;
        background-size: cover;
        object-fit: cover;
    }

	.email--iompersonal .left .logo {
        padding-left: 17px;
          }

    .email--ulsnibus .logo,
    .email--ulsroibus .logo {
        height: 40px;
        width: 145px;
        background-size: cover;
        object-fit: cover;
    }

    .email--nw .logo,
    .email--nwbus .logo {
        height: 61px;
        width: 55px;
        background-size: cover;
        object-fit: cover;
    }


    .email--nwi .logo {
        height: 62px !important;
        width: 55px;
        background-size: cover;
        object-fit: cover;
    }

    .email--rbs .logo_text,
    .email--rbsbus .logo_text {
        padding: 28px 27px 28px 27px;

    }

    .email--ulsnibus .logo_text,
    .email--ulsroibus .logo_text {
        padding: 47px 27px 47px 27px;

    }

    .email--nw .logo_text,
    .email--nwbus .logo_text {
        padding: 28px 28px 28px 28px;

    }

    .email--iompersonal .logo_text {
        padding: 28px 28px 28px 28px;

    }


    @media screen and (max-width:600px) {

        .em__header .es-infoblock p:first-child {
            margin-bottom: 0px;
        }

        .es-header .es-infoblock {
            padding: 15px 15px 15px 15px !important;
        }

        .email--rbs .logo,
        .email--rbsbus .logo {
            height: 38px;
            width: 142px;
            float: right;
        }

        .email--ulsnibus .logo,
        .email--ulsroibus .logo {
            height: 32px;
            width: 115px;
            float: right;
        }

		.email--iompersonal .logo {
             height: 29px;
             width: 288px;
			 background-size: cover;
             object-fit: cover;
        }

        .email--nw .logo,
        .email--nwbus .logo {
            height: 45px;
            width: 41px;
            background-size: cover;
            object-fit: cover;
        }


        .email--nwi .logo {
            height: 46px !important;
            width: 41px;
            background-size: cover;
            object-fit: cover;
        }

        .email--rbs .logo_text,
        .email--rbsbus .logo_text {
            padding: 21px 21px 21px 21px;
        }

        .email--ulsnibus .logo_text,
        .email--ulsroibus .logo_text {
            padding: 18px 16px 18px 16px !important;
        }

        .email--nw .logo_text,
        .email--nwbus .logo_text,
        .email--iompersonal .logo_text  {
            padding: 14px 15px 16px 15px !important;
        }

        .es-header .pixel-14 {
            font-size: 14px;
        }

        .email--nw .es-footer td.es-infoblock,
        .email--nwbus .es-footer td.es-infoblock,
        .email--iompersonal .es-footer td.es-infoblock {
            padding: 23px 15px 13px 15px !important;
        }
]') || TO_CLOB(q'[
        .email--rbs .es-footer td.es-infoblock,
        .email--rbsbus .es-footer td.es-infoblock,
        .email--ulsnibus .es-footer td.es-infoblock,
        .email--ulsroibus .es-footer td.es-infoblock {
            padding: 25px 22px 7px 15px !important;
        }

        p,
        ul li,
        ol li {

            line-height: 18px !important
        }

        h1 {
            font-size: 24px !important;
            text-align: center;
            line-height: 120% !important
        }



        h3 {

            text-align: center;

        }



        .es-header-body p,
        .es-header-body ul li,
        .es-header-body ol li,
        .es-header-body a {
            font-size: 13px !important
        }

        .es-footer-body p,
        .es-footer-body ul li,
        .es-footer-body ol li,
        .es-footer-body a {
            font-size: 10px !important
        }

        .es-infoblock p,
        .es-infoblock ul li,
        .es-infoblock ol li,
        .es-infoblock a {
            font-size: 13px !important
        }

        *[class="gmail-fix"] {
            display: none !important
        }

        .es-m-txt-c,
        .es-m-txt-c h1,
        .es-m-txt-c h2,
        .es-m-txt-c h3 {
            text-align: center !important
        }

        .es-m-txt-r,
        .es-m-txt-r h1,
        .es-m-txt-r h2,
        .es-m-txt-r h3 {
            text-align: right !important
        }

        .es-m-txt-l,
        .es-m-txt-l h1,
        .es-m-txt-l h2,
        .es-m-txt-l h3 {
            text-align: left !important
        }

        .es-m-txt-r img,
        .es-m-txt-c img,
        .es-m-txt-l img {
            display: inline !important
        }

        .es-adaptive table,
        .es-btn-fw,
        .es-btn-fw-brdr,
        .es-left,
        .es-right {
            width: 100%;
        }

        #divider__container {
            width: 100%;
        }

        .es-content table,
        .es-header table,
        .es-footer table,
        .es-content,
        .es-footer,
        .es-header {
            max-width: 600px !important
        }

        .es-adapt-td {
            display: block !important;
            width: 100% !important
        }

        .adapt-img {
            width: 100% !important;
            height: auto !important
        }





        .es-mobile-hidden,
        .es-hidden {
            display: none !important
        }

        tr.es-desk-hidden,
        td.es-desk-hidden,
        table.es-desk-hidden {
            width: auto !important;
            overflow: visible !important;
            float: none !important;
            max-height: inherit !important;
            line-height: inherit !important
        }

        tr.es-desk-hidden {
            display: table-row !important
        }

        table.es-desk-hidden {
            display: table !important
        }

        td.es-desk-menu-hidden {
            display: table-cell !important
        }

        table.es-table-not-adapt,
        .esd-block-html table {
            width: auto !important
        }
        #divider__container {
            width: 100% !important;
        }
    }

    .es-legal-p {
    padding: 14px 12px 14px 19px;
    margin: 0;
    color: #4d4d4d;
}

.es-legal-p .comp-rich-text {
    float: left;
}

.aem-AuthorLayer-Edit .es-legal-p .comp-rich-text {
    float: none;
}
.aem-AuthorLayer-Edit .es-legal-p {
width:445px;
}
]') || TO_CLOB(q'[
.es-legal-p p,
.es-legal-p .comp-rich-text {
    height: auto;
    font-size: 11px;
    font-family: arial;
    line-height: 13px!important;
    overflow: hidden;
}

.without_borderline{
	padding-top: 10px;
}

.with_borderline{
	padding-top: 20px;
}



.comp-rich-text{
	font-size:13px;
	line-height:18px;
}

#onemaincol-center__rte .comp-rich-text{
    text-align:center!important;
}

.title-comp{
	font-size:19px !important;
    margin:0;

}
.onemain-title .title-comp{
text-align:left!important;
}

#onemaincol-center__title .title-comp{
    text-align:center!important;
}

    @media screen and (min-width:601px) {
    .email--nw .logo_text,
    .email--nwbus .logo_text {
        padding: 19px 20px 20px 20px !important;

    }
    #es-m-p20b{
        padding:15px !important;
    }

    #nw_phoimg {
        height: 285px;
        display: inline-block;
    }

    .horz__tdstarts {
        padding: 15px 15px 15px 35px !important
    }

    #hero-ill_horz {
        width: 600px !important;
    }

    #horz__img__td {
        width: 132px !important;
    }

    #horz_td {
        width: 290px !important;
        height:230px!important;
    }

    #horz__top__space {
        display: block !important;
    }
    #nw_topimg{
    height:200px!important;
    width:200px!important;
    }

    #nwhero_rightimg {
        height: 200px !important;
        width: 200px !important;
    }

    #es-hero-titleblock {
        padding-top: 102px;
        padding-bottom: 105px;
        display: block !important;
    }
    .es-mobile__border{
        display: none !important;
    }

	 .email--ulsnibus .campaignhero .logo,
     .email--ulsroibus .campaignhero .logo {
        width: 145px;
        height: 40px;
    }
    #horz_txtstrt{
        padding-bottom:0px !important;
    }
    .email--ulsnibus .hero-width,
    .email--ulsroibus .hero-width{
 		height: 147px! important;
        width: 244px! important;
     }
    .email--ulsnibus .es-hero-titlecomp td,
    .email--ulsroibus .es-hero-titlecomp td{
        padding: 16px 17px 26px 17px! important;
    }

    .email--ulsnibus .es-hero-titlecomp h2,
    .email--ulsroibus .es-hero-titlecomp h2{
    font-size: 30px! important;
    line-height: 35px! important;
    }
}

@media screen and (max-width:600px) {
    .es-mobile__border {
        display: table !important;
    }

    .es-hero-body {
        display: none;
    }

    .email--nw .campaignhero .logo,
    .email--nwbus .campaignhero .logo,
    .email--ulsnibus .campaignhero .logo,
    .email--ulsroibus .campaignhero .logo{
        height: 52px !important;
        width: 47px !important;

    }

}

.aem-AuthorLayer-Edit #campaign__herostarts{
width:100%;
}


.aem-AuthorLayer-Edit #xf__starts .aem-GridColumn--default--12,
#xf__starts .table,
.aem-AuthorLayer-Edit #xf__starts .aem-Grid-newComponent,.aem-AuthorLayer-Edit .aem-GridColumn--default--12{
    width: 600px;
    float: none;

    margin: 0px auto;
}
    @media screen and (min-width:601px) {
    #hero_left {
        width: 30px;
    }
    #titlefont{
        font-size:28px !important;
        line-height:32px !important;
    }
    #rbs__hero__image {
        height: 285px;
    }

    #hero_td {

        display: block !important;
    }
]') || TO_CLOB(q'[
    #rbs_ill-img {
        height: 223px !important;
        width: 223px !important;
    }

    #email_ill_img {
        height: 32px !important;
        line-height: 32px !important;

    }

    #hero_top {
        line-height: 0px;
        height: 0px;
    }

    #bg-image-illust,
    #rbs__hero__illu {
        width: 600px;
    }

    #bg-image-illust #hero_td {
        padding-left: 30px !important;
    }

     #hero_img{
        background-position: center !important;
        margin-left: 0px !important;
        margin-right: 30px !important;
        margin-top: 0px !important;
        float: right !important;
        text-align: center !important;
        width:223px !important;
        height:223px !important;
    }

     #hero_img__tr{
        float: right !important;
        padding-top:0px !important;
    }
    #illust_firsttitle,#illust__firsttitle,  #email__twill, #email_twill{
        width: 195px !important;
    }
    #illust_secondtitle, #illust__secondtitle, #illust___secondtitle{
        width: 270px !important;
    }
    #illust_thirdtitle, #illust__thirdtitle{
        width:173px !important;
    }
}

@media screen and (max-width:601px) {
    .hero__inline{
        position: absolute !important;
    }
    .hero__inline__tr{
        position: absolute !important;
        margin-top:30px !important;
    }

}


    @media screen and (min-width:601px) {
    .email--iompersonal .logo_text {
         padding: 19px 20px 20px 20px !important;

     }
     #horz_txtstrt{
        padding-bottom:0px !important;
    }
    #es-m-p20b{
        padding:15px !important;
    }
    }

 @media screen and (max-width:600px) {

     .email--iompersonal .campaignhero .logo {
         height: 52px !important;
         width: 47px !important;

     }

 }

 .aem-AuthorLayer-Edit #campaign__herostarts{
 width:100%;
 }

    @media screen and (min-width:601px) {
    #get__the--app{
       width:600px!important;
       }
   }
   @media screen and (min-width:600px) {
       #apptable {
           padding: 20px 50px 30px 50px !important;
       }
       #step {
           padding-top: 37px !important;
       }
       #appicons {
           padding-top: 28px !important;
       }
       #getheapp_appleimg,
       #getheapp_googleimg {
           background-position: center !important;
       }
   }

.table-row-0 .title-comp {
    font-size: 13px !important;
    text-align:left;
}

@media screen and (min-width:601px) {
#table__head{
padding:11px 0px 11px 11px!important
}
#table__body{
    padding:6px 11px 6px 11px!important;
    }

    #table{
    width:600px!important;
    }
}

@media screen and (max-width:600px) {

    #table .comp-rich-text,#table .comp-rich-text p,
    .table-row-0 .title-comp {
        font-size: 10px !important;
        line-height: 12px!important;

    }
    #table__body{
    padding:2px 5px 2px 5px!important;
    }

}
    .txtandicn-img img {
    height: 18px;
    width: 18px;

}

.txtandicn-img {
       vertical-align: top;
    word-break: break-all;

}

.txtandicn-rte h2,h3,h4 {
    margin: 0;
    padding: 0;
}

     @media screen and (min-width:601px) {
    #twothree-strt {
        padding-left: 30px;
        padding-right: 30px;
        display: flex;
    }

    #twothreecol_body {
        display: table;
        height: 100%;
        vertical-align:top;

    }
    .threecol_image{
    vertical-align:top;

    }
    #threecol_title {
        padding: 16px 0px 0px 0px !important;
    }
    #twothree_hide{
    display:block!important;
    }

    #twothree_tbl {
        display: table-cell;
        width:auto!important;
    }
]') || TO_CLOB(q'[
    #two__column #column__width {
        width: 264px !important;
    }

    #three__column #column__width {
        width: 166px !important;
    }

    #threecol_rte,
    #twocolumn__rte {
        padding: 7px 0px 0px 0px !important;
    }

    #twocolumn__title {
        padding: 17px 0px 0px 0px !important;
    }

    #threecol_ill {
        height: 86px!important;
        width: 86px;
    }

    #twothree_pho #threecol_td {
        display: inline-block!important;
    }


    #threecol_cta {
        padding-top: 12px !important;
    }

    #threecol_pho,
    #no__bgColor {
        height: 86px !important;
    }

    #twocol_pho,
    #twocol_img {
        height: 158px !important;
    }
    #twocol_ill{
    height:126px!important;
    width:126px!important;
    }
}

@media screen and (max-width:600px) {
    #twothree-strt {
        padding-left: 0px;
        padding-right: 0px
    }

}

#twocolumn__rte ul,#threecol_rte ul,
#twocolumn__rte ol,#threecol_rte ol{
list-style-position: inside;
}

    @media screen and (min-width:601px) {
    .email--nw #thirty-seven_split #thirty-sevenimg_ill,
    .email--nwbus #thirty-seven_split #thirty-sevenimg_ill,
    .email--iompersonal #thirty-seven_split #thirty-sevenimg_ill {
        height: 171px;
        width: 170px;
    }

    #thirty-seven_split #es-left,
    #thirty-seven_split #es-right {
        width: auto !important;
    }

    #es-emptyPad__top,
    #es-emptyPad__bottom {
        height: 0px;
    }

    #author__section--td,
    #thirty-seven_img {
        height: 240px !important;

    }

    .email--rbs #thirty-sevenimg_ill,
    .email--rbsbus #thirty-sevenimg_ill,
    .email--ulsnibus #thirty-sevenimg_ill,
    .email--ulsroibus #thirty-sevenimg_ill {
        height: 163px;
        width: 166px;
    }


    #thirtyseventy--text__comp {
        padding-bottom: 13px !important;
    }

    #thirty-sevenimg_lft #thirty-seven_secstarts {
        padding: 0px 30px 0px 30px !important;
    }

    #thirty-sevenimg_rht #thirty-seven_secstarts {
        padding: 0px 13px 0px 30px !important;
    }

}


#thirty-seven_split .title-comp {
    text-align: left;
}

.thirty-seven_secstarts {
    display: table-cell;
}

.aem-AuthorLayer-Edit .thirty-seven_secstarts {
    display: revert !important;
    padding: 0px !important;
}

.aem-AuthorLayer-Edit .author__section--td {
    padding: 0px 30px !important;
    width: 338px !important;
}

@media screen and (max-width:600px) {
    #thirty-sevenimg_pho {
        width: 100%;
    }

    #author__section--td {
        height: auto !important;
    }

}

    @media screen and (min-width:601px) {
    #mainone__starts{
        padding:0px!important;
        border-bottom: 2px solid #ffffff;
    }
    #main1innertbl {
        width: 540px !important;
    }

    #main1innertbl_noBorder{
        width: 600px !important;
    }

    #onemaintable1 {
        width: 600px!important;
    }

    #onemaintable2 {
        padding-top: 10px !important;
    }

    #table-bottom {
        line-height: 30px !important;
        height: 30px !important
    }

    #main1-ill_withbdr {
        height: 210px;
        width: 210px;
    }

    #main1-ill_withoutbdr {
        height: 240px;
        width: 240px;
    }

     #withoutbdr{
     height: 300px;
     width:600px;
     }
     #withbdr{
     height: 270px;
     width:540px;
     }
]') || TO_CLOB(q'[
    .img_container_no_border{
        height:300px !important;
    }

    .img_container_{
        height:270px !important;
        width:540px !important;
    }

    #onemain-title {
        padding: 20px 30px 0px 30px !important;
    }

    #onemain-rte {
        padding: 20px 30px 0px 30px !important;
    }

    #text_icons {
        padding: 0px 30px 0px !important;
    }

    #mainone_cta2,
    #mainone_cta1 {
        padding-top: 20px !important;
    }

    #mainone_cta2 {
     float:left;
      margin-left:15px!important;
    }

    #mainone_cta1 {
        float:right;
        margin-right:15px!important;
    }

    .showCta{
        padding:0px 30px !important;
    }

    #onemaincol-left{
        float:left !important;
    }

    #onemaincol-center{
        text-align: center !important;
    }

    .onemaincol-center{
        text-align: center !important;
    }

    .mainone_cta1_with_scta {
        float:right !important;
    }

   .mainone_cta2_with_scta {
        float:left !important;
    }

    #mainone__hide {
        display: table-cell !important;
    }

    #onemain-addesc {
        padding: 20px 30px 0px 30px !important;
    }

    #legal-top {
        padding:0px 30px 0px 30px !important;
    }

    #es-legal-p {
        margin: 0;
        color: #4d4d4d;
    }

    #mainone__cta{
    width:50%!important;;
    }
    #onemain-rte li{
    margin:0px;
    }

}

#mainone_cta1 .cta-secondary .cta__text,
#mainone_cta2 .cta-secondary .cta__text {
    padding: 0px 3px !important;
}

#onemaincol-left .cta-secondary{
    float:left !important;
    width: auto !important;
}

#onemain-rte li {

    line-height: 18px;
    letter-spacing: -0.13px;

    padding-bottom: 11px;
    padding-left: 4px;

}

#onemain-rte li {
    list-style-position: outside;
}

#onemain-rte p {
    margin: 0;
}

#onemain-rte ul {
    padding-left: 14px;
    margin: 0;
    padding-top: 8px;

}

#text_icons li{
	padding-left:20px !important;
}

.aem-AuthorLayer-Edit .txtandicn-rte {
    width: 100%;
    position: relative;
    left: 10px;
    text-align:left;
}


</style>
]') || TO_CLOB(q'[

    <div class="es-wrapper-color">

    <!--[if gte mso 9]>
			<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
				<v:fill type="tile" color="#fff"></v:fill>
			</v:background>
		<![endif]-->

    <table class="email--nw" id="email--nw" color="#4c4c4c" width="100%" cellspacing="0" cellpadding="0">
      <tbody>
        <tr>
          <td width="100%" class="esd-email-paddings" valign="top">
            <div>
              <table cellpadding="0" cellspacing="0" class="es-content esd-header-popover" align="center" bgcolor="#fff"
                style="background-color:#fff">
                <tbody>
                  <tr>
                    <td class="es-adaptive esd-stripe" align="center" id="es-adaptive">
                      <table class="es-content-body" style="background-color: transparent; width:100%!important"
                        width="600" cellspacing="0" cellpadding="0" align="center">
                        <tbody>
                        ]') || TO_CLOB(q'[
                          <tr>
                            <td class="esd-structure " align="left">
                              <table width="100%" cellspacing="0" cellpadding="0" class="es-header">
                                <tbody>
                                  <tr>
                                    <td class="esd-container-frame" width="600" valign="top" align="center">
                                      <table width="100%" cellspacing="0" cellpadding="0">
                                        <tbody>
                                          <tr>
                                            <td align="left" class="">
                                              <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
                                                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                                  <tbody>
                                                    <tr>
                                                      <td width="600" style="padding-top:0px; padding-bottom:0px;">
                                                        <table id="campaign__herostarts" class="container"
                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;"
                                                          border="0" cellpadding="0" cellspacing="0" align="center"
                                                          bgcolor="#5A287D">
                                                          <tr style="border-collapse:collapse">
                                                            <td style="padding:0;margin:0;">
                                                              <table cellpadding="0" cellspacing="0"
                                                                class="es-header es-logo" align="center"
                                                                bgcolor="#5a287d">
                                                                ]') || TO_CLOB(q'[
                                                                <tbody>
                                                                  <tr style=" border-collapse:collapse">
                                                                    <td align="center" style="padding:0;Margin:0;">
                                                                      <table class="es-logo-body" bgcolor="#5a287d"
                                                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:100%!important"
                                                                        cellspacing="0" cellpadding="0" align="center">
                                                                        <tbody>
                                                                          <tr style="border-collapse:collapse">
                                                                            <td class="es-m-logo-td" align="left"
                                                                              style="Margin:0">
                                                                              <table width="100%" cellspacing="0"
                                                                                cellpadding="0" bgcolor="#5a287d"
                                                                                style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                                                <tbody>
                                                                                  <tr style="border-collapse:collapse">
                                                                                    <td valign="top" align="center"
                                                                                      style="padding:0;Margin:0;width:600px">
                                                                                      <table width="100%"
                                                                                        cellspacing="0" cellpadding="0"
                                                                                        role="presentation"
                                                                                        bgcolor="#5a287d"
                                                                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                                                        <tbody>
                                                                                        ]') || TO_CLOB(q'[
                                                                                          <tr
                                                                                            style="border-collapse:collapse">
                                                                                            <td class="logo_text"
                                                                                              align="left"
                                                                                              bgcolor="#5a287d"
                                                                                              style="Margin:0;font-size:0;padding:28px 28px 28px 28px;">
                                                                                              <a target="_self"
                                                                                                class="left"
                                                                                                style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial;text-decoration:none;color:#666666"><img
                                                                                                  class="logo"
                                                                                                  src="https://www.natwest.com/content/dam/natwest/assets/business/email/logos/logo-email-nw-horizontal-stacked-2x.png"
                                                                                                  width="198"
                                                                                                  style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" /></a>
                                                                                            </td>
                                                                                          </tr>
                                                                                        </tbody>
                                                                                      </table>
                                                                                      ]') || TO_CLOB(q'[
                                                                                    </td>
                                                                                  </tr>
                                                                                </tbody>
                                                                              </table>
                                                                            </td>
                                                                          </tr>
                                                                        </tbody>
                                                                      </table>
                                                                    </td>
                                                                  </tr>
                                                                </tbody>
                                                              </table>
                                                            </td>
                                                          </tr>
                                                        </table>
                                                        <style type="text/css">
                                                          .dial {
                                                            background-image: url('https://www.natwest.com/content/dam/natwest/assets/business/email/png-illustrations/illus-email-purple-financial-healthcheck-pen-170x171.png');
                                                          }
                                                        </style>
                                                        ]') || TO_CLOB(q'[
                                                        <table width="100%" class="es-content hero-ill_horz"
                                                          id="hero-ill_horz" align="center" bgcolor="#5A287D"
                                                          cellspacing="0" cellpadding="0"
                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;">
                                                          <tbody>
                                                            <tr style="border-collapse:collapse">
                                                              <td class="horz__tdstarts" align="left"
                                                                style="Margin:0;padding: 0px;padding-top:30px;">
                                                                <!--[if mso]><table cellpadding="0" cellspacing="0"  class="es-right horz__img__td  " id="horz__img__td" align="right" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right;"><![endif]-->
                                                                <table width="100%" cellpadding="0" cellspacing="0"
                                                                  class="es-right horz__img__td  " id="horz__img__td"
                                                                  align="right"
                                                                  style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right;">
                                                                  <tbody>
                                                                    <tr style="border-collapse:collapse">
                                                                      <td class="es-m-p20b" id="es-m-p20b" align="left"
                                                                        style="padding:0;Margin:0;width: 200px;">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                          width="100%"
                                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-position:center top"
                                                                          role="presentation">
                                                                          ]') || TO_CLOB(q'[
                                                                          <tbody>
                                                                            <tr
                                                                              style="border-collapse:collapse;text-align: center;">
                                                                              <td class="dial" align="center"
                                                                                style="padding:0;Margin:0;background:url('https://www.natwest.com/content/dam/natwest/assets/business/email/png-illustrations/illus-email-purple-financial-healthcheck-pen-170x171.png') no-repeat center/ 100% 100%;background-size:100% 100%;background-repeat:no-repeat;display:inline-block;">
                                                                                <!--[if gte mso 9]>
                                                                                <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"
                                                                                style=width:200px;height:200px;position:absolute;">
                                                                                <v:fill type="frame" src="https://www.natwest.com/content/dam/natwest/assets/business/email/png-illustrations/illus-email-purple-financial-healthcheck-pen-170x171.png" color="#5A287D" />
                                                                                <v:textbox inset="0,0,0,0">
                                                                                <![endif]-->
                                                                                ]') || TO_CLOB(q'[
                                                                                <img id="nwhero_rightimg"
                                                                                  src="https://www.natwest.com/content/dam/campaign/transparent.gif"
                                                                                  title="Dial" alt="Dial"
                                                                                  style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"
                                                                                  width="170" height="170" />
                                                                                <!--[if gte mso 9]>
                                                                                </v:textbox>
                                                                                </v:rect>
                                                                                <![endif]-->
                                                                              </td>
                                                                            </tr>
                                                                          </tbody>
                                                                        </table>
                                                                      </td>
                                                                    </tr>
                                                                  </tbody>
                                                                </table>
                                                                <!--[if mso]></table><![endif]-->
                                                                <!--[if mso]><table    cellpadding="0" valign="middle" cellspacing="0" class="es-left  horz_td" id="horz_td" align="left" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left;"><![endif]-->
                                                                <table width="100%" cellpadding="0" cellspacing="0"
                                                                  class="es-left  horz_td" id="horz_td" align="left"
                                                                  style="vertical-align:middle; mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left;">
                                                                  ]') || TO_CLOB(q'[
                                                                  <tbody>
                                                                    <tr style="border-collapse:collapse">
                                                                      <td id="horz_txtstrt" align="left"
                                                                        style="padding:0;padding-bottom:31px;Margin:0;width:261px;text-align: center;vertical-align: middle;padding-top:29px;">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                          width="261"
                                                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:261px!important;display: inline-block;"
                                                                          role="presentation">
                                                                          <tbody>
                                                                            <tr style="border-collapse:collapse">
                                                                              <td align="center"
                                                                                style="padding:0;Margin:0;word-break: break-word">
                                                                                <h2
                                                                                  style="Margin:0;mso-line-height-rule:exactly;font-family:Arial;font-size:22px;font-style:normal;font-weight:bold;color:#fff">
                                                                                  Reminder: We need some more information</h2>
                                                                              </td>
                                                                            </tr>
                                                                            ]') || TO_CLOB(q'[
                                                                          </tbody>
                                                                        </table>
                                                                      </td>
                                                                    </tr>
                                                                  </tbody>
                                                                </table>
                                                                <!--[if mso]></table><![endif]-->
                                                              </td>
                                                            </tr>
                                                          </tbody>
                                                        </table>
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                ]') || TO_CLOB(q'[
                                                <style type="text/css">
                                                  . {
                                                    background-image: url('');
                                                    background-position: center;
                                                    background-size: cover;
                                                    background-repeat: no-repeat;
                                                  }

                                                  @media screen and (max-width:600px) {
                                                    . {
                                                      background-image: url('');
                                                      background-size: 100% 100%;
                                                    }
                                                  }
                                                </style>
                                                ]') || TO_CLOB(q'[
                                                <table id="onemaintable1" class="onemaintable1" width="100%"
                                                  align="center" border="0"
                                                  style="border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                  cellpadding="0" cellspacing="0">
                                                  <tr style="margin:0px; padding:0px;border-collapse: collapse;">
                                                    <td id="mainone__starts"
                                                      style="padding:20px 0px; border-bottom: 2px solid #ffffff; padding-top:20px !important; padding-bottom:0px;">
                                                      <!--[if mso]><table width="540" id="main1innertbl_noBorder" class="main1innertbl" border="0" align="center" style="width:540px;min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;" cellpadding="0" cellspacing="0"><![endif]-->
                                                      <table width="100%" id="main1innertbl_noBorder"
                                                        class="main1innertbl" border="0" align="center"
                                                        style="min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                        cellpadding="0" cellspacing="0">
                                                        ]') || TO_CLOB(q'[
                                                        <tr style="border-collapse: collapse;">
                                                          <td style="margin: 0;padding: 0px;" bgcolor="#5a287d">
                                                            <!--[if mso]><table width="540" id="onemaintable2" class="onemaintable2" cellpadding="0" cellspacing="0" border="0" style="width:600px;border-collapse: collapse;border-spacing: 0px;" align="center" bgcolor="#ffffff"><![endif]-->
                                                            <table width="100%" id="onemaintable2" class="onemaintable2"
                                                              cellpadding="0" cellspacing="0" border="0"
                                                              style="padding-top:3px;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                              align="center" bgcolor="#ffffff">
                                                              <tbody>
                                                                <tr id="onemaincol-left__rte" class="onemaincol-left"
                                                                  style="border-collapse: collapse;">
                                                                  <td id="onemain-rte" class="onemain-rte"
                                                                    style="font-size:13px;letter-spacing:-0.13px;line-height:18px;padding:20px 15px 0px 15px;">
                                                                    ]') || TO_CLOB(q'[
                                                                    <div class="comp-rich-text"
                                                                      style="color:#42145f;font-family:Arial;">
                                                                      <p>Hi ${firstname},</p>
                                                                      <p>&nbsp;</p>
                                                                      <p>We've been reviewing your mortgage application and we need some more information from you to keep your application on the move. Please provide this as soon as possible to prevent any delays to your application. Please ignore this if your application has been declined or you are no longer progressing with it.</p>
                                                                      <p>&nbsp;</p>
                                                                      <p>Log in to your mortgage dashboard to provide us with the requested information</p>
                                                                      <p>&nbsp;</p>
                                                                      <p>Thank you for choosing NatWest</p>
                                                                    </div>
                                                                  </td>
                                                                </tr>
                                                                ]') || TO_CLOB(q'[
                                                                <tr style="border-collapse: collapse;">
                                                                  <td id="onemaincol-left" class="showCta"
                                                                    style="padding:0;Margin:0;padding-top:0px;padding-left:15px;padding-right:15px;background-position:left top"
                                                                    align="left">
                                                                    <!--[if mso]><table id="onemaincol-left" style="width:100%;" cellpadding="0" cellspacing="0"><tr><td style="width:166px;"><![endif]-->
                                                                    <!--[if mso]><table   id="mainone__cta" cellspacing="0" cellpadding="0" align="left" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;"> <![endif]-->
                                                                    <table width="100%" id="mainone__cta"
                                                                      cellspacing="0" cellpadding="0" align="right"
                                                                      style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left;width:100%!important">
                                                                      <tbody>
                                                                      ]') || TO_CLOB(q'[
                                                                        <tr style="border-collapse:collapse">
                                                                          <td id="mainone_cta1" class="mainone_cta1_"
                                                                            style="padding:20px 0px 0px 0px;Margin:0;width:166px;float:left"
                                                                            align="center">
                                                                            <table cellpadding="0" cellspacing="0"
                                                                              align="center" class="cta-primary"
                                                                              style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                                              <tbody>
                                                                                <tr style="border-collapse:collapse">
                                                                                  <td align="center" valign="top"
                                                                                    class="cta__starts"
                                                                                    style="padding:0;Margin:0;width:166px;padding-bottom:1px">
                                                                                    <table cellpadding="0"
                                                                                      cellspacing="0" width="100%"
                                                                                      role="presentation"
                                                                                      bgcolor="#5e10b1"
                                                                                      style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:166px!important;">
                                                                                      ]') || TO_CLOB(q'[
                                                                                      <tbody>
                                                                                        <tr
                                                                                          style="border-collapse:collapse">
                                                                                          <td align="center"
                                                                                            class="cta__text"
                                                                                            id="cta__text"
                                                                                            style="text-align:center;border:1px solid #5e10b1;background:#5e10b1;color:#ffffff;">
                                                                                            <!--[if mso]>
                                                                                            <v:rect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word"
                                                                                            href=${dashboardLink}
                                                                                            style="height:66px;v-text-anchor:middle;border:1px solid #5e10b1;width:156px;color:#ffffff"
                                                                                            strokecolor="#5e10b1"   fillcolor="#5e10b1">
                                                                                            <w:anchorlock/>
                                                                                            <center>
                                                                                            ]') || TO_CLOB(q'[
                                                                                            <![endif]-->
                                                                                            <a class="email__cta"
                                                                                              href=${dashboardLink}
                                                                                              title="Log in to your mortgage dashboard"
                                                                                              target="_blank"
                                                                                              rel="noopener" role="link"
                                                                                              aria-labelledby="Go to your mortgage dashboard"
                                                                                              style="display:block;font-weight:bold;mso-style-priority:100 !important;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial;font-size:13px;line-height:18px;text-align:center;text-decoration:none;color:#ffffff">
                                                                                              <span
                                                                                                class="es-button-border"
                                                                                                style="color:#ffffff;display:block;padding:16px 15px 14px 15px;text-decoration:none">Go
                                                                                                to your mortgage
                                                                                                dashboard</span>
                                                                                            </a>
                                                                                            <!--[if mso]>
                                                                                            </center>
                                                                                            </v:rect>
                                                                                            <![endif]-->
                                                                                          </td>
                                                                                        </tr>
                                                                                      </tbody>
                                                                                    </table>
                                                                                  </td>
                                                                                </tr>
                                                                              </tbody>
                                                                            </table>
                                                                          </td>
                                                                        </tr>
                                                                      </tbody>
                                                                    </table>
                                                                    ]') || TO_CLOB(q'[
                                                                    <!--[if mso]></table> <![endif]-->
                                                                    <!--[if mso]></td><td style="width:24px"></td><td style="width:166px;"><![endif]-->
                                                                    <!--[if mso]></td><td style="width:180px"></td></tr></table><![endif]-->
                                                                  </td>
                                                                </tr>
                                                                <tr style="border-collapse: collapse;">
                                                                  <td colspan="3" height="30"
                                                                    style="line-height:30px;mso-line-height-rule:exactly;padding: 0px;"
                                                                    id="table-bottom">
                                                                    &nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                            <!--[if mso]></table><![endif]-->
                                                          </td>
                                                        </tr>
                                                      </table>
                                                      ]') || TO_CLOB(q'[
                                                      <!--[if mso]></table><![endif]-->
                                                    </td>
                                                  </tr>
                                                </table>
                                                <div style="clear:both;float:none"></div>
                                                <table cellpadding="0" cellspacing="0" class="divider__container"
                                                  id="divider__container" height="10" style="width:100%" border="0"
                                                  align="center">
                                                  <tr align="center">
                                                    <td width="100%" valign="center"
                                                      style="vertical-align:center !important;" class="">
                                                      <hr
                                                        style="background: #5a287d; border: none; color: #5a287d;margin:8px 0px; height: 2px;line-height:2px;mso-line-height-rule:exactly;" />
                                                    </td>
                                                  </tr>
                                                </table>
                                                ]') || TO_CLOB(q'[
                                                <style type="text/css">
                                                  . {
                                                    background-image: url('');
                                                    background-position: center;
                                                    background-size: cover;
                                                    background-repeat: no-repeat;
                                                  }

                                                  @media screen and (max-width:600px) {
                                                    . {
                                                      background-image: url('');
                                                      background-size: 100% 100%;
                                                    }
                                                  }
                                                </style>
                                                ]') || TO_CLOB(q'[
                                                <table id="onemaintable1" class="onemaintable1" width="100%"
                                                  align="center" border="0"
                                                  style="border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                  cellpadding="0" cellspacing="0">
                                                  ]') || TO_CLOB(q'[
                                                  <tr style="margin:0px; padding:0px;border-collapse: collapse;">
                                                    <td id="mainone__starts"
                                                      style="padding:20px 0px; border-bottom: 2px solid #ffffff; padding-top:0px; padding-bottom:0px;">
                                                      <!--[if mso]><table width="540" id="main1innertbl_noBorder" class="main1innertbl" border="0" align="center" style="width:540px;min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;" cellpadding="0" cellspacing="0"><![endif]-->
                                                      <table width="100%" id="main1innertbl_noBorder"
                                                        class="main1innertbl" border="0" align="center"
                                                        style="min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                        cellpadding="0" cellspacing="0">
                                                        <tr style="border-collapse: collapse;">
                                                          <td style="margin: 0;padding: 0px;" bgcolor="#ffffff">
                                                            <!--[if mso]><table width="540" id="onemaintable2" class="onemaintable2" cellpadding="0" cellspacing="0" border="0" style="width:600px;border-collapse: collapse;border-spacing: 0px;" align="center" bgcolor="#ffffff"><![endif]-->
                                                            <table width="100%" id="onemaintable2" class="onemaintable2"
                                                              cellpadding="0" cellspacing="0" border="0"
                                                              style="padding-top:3px;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                              align="center" bgcolor="#ffffff">
                                                              <tbody>]') || TO_CLOB(q'[
                                                                <tr style="border-collapse: collapse;">
                                                                  <td id="text_icons" class="text_icons"
                                                                    style="font-size:13px;letter-spacing:-0.13px;line-height:18px;padding:0px 15px;">
                                                                    <table cellpadding="0" cellspacing="0">
                                                                      <tr style="border-collapse: collapse;">
                                                                        <td style="width: 491px">
                                                                          <table cellpadding="0" cellspacing="0">
                                                                            <tr class="icon-text-row">
                                                                              <td class="txtandicn-img"
                                                                                style="padding:20px 10px 0px 0px;">
                                                                                <img height="14" width="14"
                                                                                  src="https://www.natwest.com/content/dam/natwest_com/student-ucas-emails/nw-images/nw-pers-icon-phone.jpg"
                                                                                  alt="online"
                                                                                  style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;max-width:none!important;"
                                                                                  data-emptytext="Image (Campaign)" />
                                                                              </td>
                                                                              ]') || TO_CLOB(q'[
                                                                              <td class="txtandicn-rte"
                                                                                style="padding-top:20px; vertical-align:bottom;">
                                                                                <div>
                                                                                  <div class="comp-rich-text"
                                                                                    style="color:#42145f;font-family:Arial;">
                                                                                    <p><b>Need some help?</b></p>
                                                                                    <p>&nbsp;</p>
                                                                                    <p>Make an appointment to speak to
                                                                                      one of our mortgage professionals,
                                                                                      on a&nbsp;phone&nbsp;or&nbsp;video
                                                                                      call.</p>
                                                                                    <p>&nbsp;</p>
                                                                                    <p>Call us on&nbsp;<b>0800 096
                                                                                        9527&nbsp;</b>(Relay UK: 18001
                                                                                      0800 096 9527).&nbsp;<span
                                                                                        class="pixel-11">Opening
                                                                                        hours:&nbsp;Mon-Fri 8am-6pm, Sat
                                                                                        9am-4pm, Sun Closed. Excluding
                                                                                        public holidays.</span></p>
                                                                                    <p>&nbsp;</p>
                                                                                    <p><b>Please note, Online Only
                                                                                        products are only available
                                                                                        through our website.</b></p>
                                                                                  </div>
                                                                                </div>
                                                                              </td>
                                                                            </tr>
                                                                          </table>
                                                                        </td>
                                                                      </tr>
                                                                    </table>
                                                                  </td>
                                                                </tr>
                                                                ]') || TO_CLOB(q'[
                                                                <tr style="border-collapse: collapse;">
                                                                  <td colspan="3" height="30"
                                                                    style="line-height:30px;mso-line-height-rule:exactly;padding: 0px;"
                                                                    id="table-bottom">
                                                                    &nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                            <!--[if mso]></table><![endif]-->
                                                          </td>
                                                        </tr>
                                                      </table>
                                                      <!--[if mso]></table><![endif]-->
                                                    </td>
                                                  </tr>
                                                </table>
                                                <div style="clear:both;float:none"></div>
                                                <link rel="stylesheet"
                                                  href="/libs/cq/experience-fragments/components/xfpage/content.min.css"
                                                  type="text/css" />
                                                <div class="xf-content-height">
                                                  <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
                                                    ]') || TO_CLOB(q'[
                                                    <style type="text/css">
                                                      . {
                                                        background-image: url('');
                                                        background-position: center;
                                                        background-size: cover;
                                                        background-repeat: no-repeat;
                                                      }

                                                      @media screen and (max-width:600px) {
                                                        . {
                                                          background-image: url('');
                                                          background-size: 100% 100%;
                                                        }
                                                      }
                                                    </style>
                                                    <table id="onemaintable1" class="onemaintable1" width="100%"
                                                      align="center" border="0"
                                                      style="border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                      cellpadding="0" cellspacing="0">
                                                      <tr style="margin:0px; padding:0px;border-collapse: collapse;">
                                                        <td id="mainone__starts"
                                                          style="padding:20px 0px; border-bottom: 2px solid #ffffff; padding-top:0px; padding-bottom:0px;">
                                                          <!--[if mso]><table width="540" id="main1innertbl_noBorder" class="main1innertbl" border="0" align="center" style="width:540px;min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;" cellpadding="0" cellspacing="0"><![endif]-->
                                                          <table width="100%" id="main1innertbl_noBorder"
                                                            class="main1innertbl" border="0" align="center"
                                                            style="min-height:50px;border-collapse: collapse;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                            cellpadding="0" cellspacing="0">
                                                            ]') || TO_CLOB(q'[
                                                            <tr style="border-collapse: collapse;">
                                                              <td style="margin: 0;padding: 0px;" bgcolor="#ffffff">
                                                                <!--[if mso]><table width="540" id="onemaintable2" class="onemaintable2" cellpadding="0" cellspacing="0" border="0" style="width:600px;border-collapse: collapse;border-spacing: 0px;" align="center" bgcolor="#ffffff"><![endif]-->
                                                                <table width="100%" id="onemaintable2"
                                                                  class="onemaintable2" cellpadding="0" cellspacing="0"
                                                                  border="0"
                                                                  style="padding-top:3px;border-spacing: 0px;mso-table-lspace:0pt;mso-table-rspace:0pt;"
                                                                  align="center" bgcolor="#ffffff">
                                                                  <tbody>
                                                                    <tr style="border-collapse: collapse;">
                                                                      <td class="legal-top" id="legal-top"
                                                                        style="padding:0px 15px 0px 15px">
                                                                        <!--[if mso]> <table width="100%" class="with_borderline" border="0" cellpadding="0" cellspacing="0"><![endif]-->
                                                                        <table width="100%" id="es-legal--table"
                                                                          class="es-legal--table with_borderline"
                                                                          align="center" border="0" cellpadding="0"
                                                                          cellspacing="0">
																		  ]') || TO_CLOB(q'[
                                                                          <tr>
                                                                            <td
                                                                              style="vertical-align:center !important; border: 2px solid #5a287d">
                                                                              <table class="" border="0" cellpadding="0"
                                                                                cellspacing="0">
                                                                                <tr style="margin:0px; padding:0px">
                                                                                  <!--[if mso]> <td><![endif]-->
                                                                                  <td id="es-legal-p" class="es-legal-p"
                                                                                    style="font-size:11px; font-family:arial; line-height:13px;padding:20px;margin: 0;">
                                                                                    <div />
                                                                                    <div class="comp-rich-text"
                                                                                      style="color:#42145f;font-family:Arial;">
                                                                                      <p>YOUR HOME MAY BE REPOSSESSED IF
                                                                                        YOU DO NOT KEEP UP REPAYMENTS ON
                                                                                        YOUR MORTGAGE</p>
                                                                                    </div>
                                                                                  </td>
                                                                                  <!--[if mso]></td><![endif]-->
                                                                                </tr>
                                                                              </table>
                                                                            </td>
                                                                          </tr>
                                                                        </table>
                                                                        <!--[if mso]> </table> <![endif]-->
                                                                      </td>
                                                                    </tr>
                                                                    ]') || TO_CLOB(q'[
                                                                    <tr style="border-collapse: collapse;">
                                                                      <td colspan="3" height="30"
                                                                        style="line-height:30px;mso-line-height-rule:exactly;padding: 0px;"
                                                                        id="table-bottom">
                                                                        &nbsp;</td>
                                                                    </tr>
                                                                  </tbody>
                                                                </table>
                                                                <!--[if mso]></table><![endif]-->
                                                              </td>
                                                            </tr>
                                                          </table>
                                                          <!--[if mso]></table><![endif]-->
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <div style="clear:both;float:none"></div>
                                                    ]') || TO_CLOB(q'[
                                                  </div>
                                                </div>
                                              </div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div>
              <div>
                <!--<sly data-sly-include="logo.html"/>-->
                <table cellpadding="0" cellspacing="0" class="es-header es-logo" align="center">
                  <tbody>
                    <tr style=" border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0">
                        <table class="es-logo-body" bgcolor="#5a287d"
                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;width:100%!important"
                          cellspacing="0" cellpadding="0" align="center">
                          <tbody>
                            <tr style="border-collapse:collapse">
                              <td class="es-m-logo-td" align="left" style="Margin:0">
                                <table width="100%" cellspacing="0" cellpadding="0"
                                  style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                  <tbody>
                                    <tr style="border-collapse:collapse">
                                      <td valign="top" align="center" style="padding:0;Margin:0;width:600px">
                                        <table width="100%" cellspacing="0" cellpadding="0" role="presentation"
                                          bgcolor="#5a287d"
                                          style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                          <tbody>
                                            <tr style="border-collapse:collapse">
                                              <td class="logo_text" align="center" bgcolor="#5a287d"
                                                style="Margin:0;font-size:0;padding:28px 28px 28px 28px;">
                                                <a target="_self"
                                                  style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial;text-decoration:none;color:#666666"><img
                                                    class="logo"
                                                    src="https://www.natwest.com/content/dam/natwest/assets/personal/email/logos/logo-email-nw-stacked-x2.png.png"
                                                    width="55" alt="NatWest logo"
                                                    style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" /></a>
                                              </td>
                                            </tr>]') || TO_CLOB(q'[
                                          </tbody>
                                        </table>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
          </td>
        </tr>
      </tbody>
    </table>
</div>
${templateFooter}
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>]'), 'flow-management-customer-fya-notification-reminder-xo', 'This template will be used to share reminder FYA information with the customer for xo from flow management', 'MAIN');

-- insert Customer FYA Email Template in TEMPLATE table for adbo channel
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <!-- Start banner -->
    <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td colspan="2">
                <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important!</p>
            </td>
        </tr>
        <tr class="emailTemplateBannerTableWarningNotificationRow" style="background: rgb(242, 242, 248);">
            <td class="emailTemplateBannerTableWarningNotificationIcon" style="width: 24px; background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);" width="24">
                <img class="emailTemplateWarningIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA2FBMVEUAAABhYW1mXGZiYmxoXmhkZGRhYWpjY2tlXmllYWhjYGdlX2lkYWhlYGdkX2ljYWhlYGdkYWhlYGhkYWdjYGhkX2hkYGllYGhlYGhkYGhjYWhkYGlkYGhkYGhkYGdjYGhlYGhkYGhkX2hkYGlkX2hkYGhkYGhkYGhlYWlmYmptaXFxbXR0cHd0cXh3c3p6d359eoCBfYSCf4WMiY+NipCOi5GWlJmbmZ6cmZ6xr7O5t7u7ub29u77DwcTW1dfY19nb2tvc293o5+j09PT19PX6+fr7+/v///8mErf9AAAAJ3RSTlMAFRkaGxwdH0lMTU5pamtsbZGYmZqbnKKqtba319jZ2vHy8/T7/P2PX2s+AAAAAWJLR0RHYL3JewAAAOBJREFUGBltwYlWglAUBdCTihkW0ZxKxUN4R5vnsDmt7v//US54l4Wu9obT3hxEw2E0CDzUtXZSOvZwFZWuYY3x4YSWC2yIQifjEtvFXMvQOc2vWTJNAPtUn/JzydIu0M6ovkXuWEo9hKzk07cxnQB9/quHE6qz+xtWjpDQyaciOVUCQzX+lWeqGMdUFyJPVBH6VI8iV1Q9BFQvMhtRrcPL6HzJB1XqAXt03mX2esvSNoCmYel8MnkYsRA3MNfJuMT6KISWC2wIxzesiddQWdlK6diDBuq8oB8lSdTb8FD6AxLFR8uldLbzAAAAAElFTkSuQmCC" style="vertical-align: bottom;">
            </td>
            <td style="background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);">
                If the application is not being progressed, you can ignore this message and no further action is required.
            </td>
        </tr>
    </table>
    <!-- End banner -->
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Hello ${applicantFullName},<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
					We need more information to complete your additional borrowing application. Take action now:
				</p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
							    <#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
								<#if (document.documentFor)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                </#if>
								<#if (document.reRequestReason)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
                                <#if (document.requestedDate)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Requested Date: ${document.requestedDate}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on online banking:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Log into online banking using the link above</br>
                2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on the mobile app:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Access your Natwest mobile app</br>
                2. Click on the mortgage account you’re applying for additional borrowing on</br>
                3. Click on the ‘additional borrowing’ tile in the apply menu.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you don''t have NatWest online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.onlinebanking.natwest.com/Default.aspx?InnerPage=OLE">Online Banking</a>.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.natwest.com/banking-with-natwest/natwest-app/features.html#tmta">Download the App</a>
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
               You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
               Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
           </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions, please contact us on 0345 302 0190.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share FYA information with the customer for adbo channels',
'flow-management-customer-fya-notification-adbo', 'MAIN');

-- insert Customer avScan failure Email Template in TEMPLATE table for xo and adbo channel

str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${applicantFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
				<#if (referenceNumber)?? >
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Mortgage Reference Number<br>
                    ${referenceNumber}
                </p>
				</#if>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    <b>Request for re-upload of Document</b>
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We are writing to inform you that the document you recently uploaded as part of your mortgage application has issues. As a result, we were unable to process your document.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                    <#list documentInfo as document>
                    <tr>
                        <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                            <#if (document.category)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                            </#if>
                            <#if (document.originalFileName)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                    <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                </p>
                            </#if>
                        </td>
                    </tr>
                    </#list>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    In order to re-upload your document(s) and progress your application, please call our Mortgage Contact Centre:
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Call us on 0800 056 3220
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Relay UK: 18001 0800 056 3220
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Opening hours: Mon-Fri 8am-6pm, Sat 9am-4pm, Sun Closed. Excluding public holidays.
                </p>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to customer for xo and adbo',
'flow-management-customer-avscan-failure-notification-xo-and-adbo', 'MAIN');

-- insert Customer avScan failure Email Template in TEMPLATE table for adbo channel
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Hello ${applicantFullName},<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    <b>Request for re-upload of Document</b>
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We are writing to inform you that the document you recently uploaded as part of your additional borrowing application has issues. As a result, we were unable to process your document.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                    <#list documentInfo as document>
                    <tr>
                        <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                            <#if (document.category)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                            </#if>
                            <#if (document.originalFileName)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                    <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                </p>
                            </#if>
                        </td>
                    </tr>
                    </#list>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We kindly request that you upload another copy of the document as soon as possible so that we can continue to process your additional borrowing application. Please ensure that the new copy of the document is clear, legible and free from any viruses.
                    If you have any questions or concerns, please do not hesitate to reach out to us. Our team is available to assist you and ensure a smooth and seamless process.
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We apologize for any inconvenience this may have caused and appreciate your understanding and cooperation in this matter.
                </p>
            </td>
        </tr>
        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on online banking:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Log into online banking using the link above</br>
                2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on the mobile app:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Access your Natwest mobile app</br>
                2. Click on the mortgage account you’re applying for additional borrowing on</br>
                3. Click on the ‘additional borrowing’ tile in the apply menu.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you don''t have NatWest online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.onlinebanking.natwest.com/Default.aspx?InnerPage=OLE">Online Banking</a>.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.natwest.com/banking-with-natwest/natwest-app/features.html#tmta">Download the App</a>
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
               You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
               Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you have any questions, please contact us on 0345 302 0190.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to customer for adbo',
'flow-management-customer-avscan-failure-notification-adbo', 'MAIN');

-- insert No Packaging Customer Welcome Email Template in TEMPLATE table for adbo
str :='<!DOCTYPE html>
       <html lang="en">
           <head>
               <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
               <meta name="viewport" content="width=device-width, initial-scale=1">
               <meta name="x-apple-disable-message-reformatting">
               <meta name="format-detection" content="telephone=yes">
               <!--[if !mso]><!-->
                   <meta http-equiv="X-UA-Compatible" content="IE=edge">
               <!--<![endif]-->
           </head>
           <style>
       a:hover {
         text-decoration: underline;
       }
       </style>

           ${templateHeader}
           <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
               <tr>
                   <td>
                       <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                           Important.
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                           Hello ${applicantFullName},<br>
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
       				<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                           Following the recent Additional Borrowing application your joint party completed, we require you to agree and complete some additional information to be able to submit to our mortgage centre.
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
       					Please log into the Additional Borrowing dashboard to access your mortgage application.
       				</p>

                   </td>
               </tr>

               <tr>
                   <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                       <div>
                           <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                           style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                           <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                           <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                           <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                           </a>
                       </div>
                   </td>
               </tr>

           <tr class="emailTemplateTableBottom">
               <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        To access your additional borrowing dashboard on online banking:
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        1. Log into online banking using the link above</br>
                        2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                        3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        To access your additional borrowing dashboard on the mobile app:
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        1. Access your Natwest mobile app</br>
                        2. Click on the mortgage account you’re applying for additional borrowing on</br>
                        3. Click on the ‘additional borrowing’ tile in the apply menu.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        If you don''t have NatWest online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.onlinebanking.natwest.com/Default.aspx?InnerPage=OLE">Online Banking</a>.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.natwest.com/banking-with-natwest/natwest-app/features.html#tmta">Download the App</a>
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
                       You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
                       Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       If you have any questions, please contact us on 0345 302 0190.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Kind regards,
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Natwest Mortgage Team
                   </p>
               </td>
           </tr>
           </table>
           ${templateFooter}
       </html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share welcome information with the customer having no packaging requirement for adbo channel',
'flow-management-no-packaging-customer-welcome-notification-adbo', 'MAIN');

-- insert Lapse for Email Template in TEMPLATE table
x := 0;
str := '<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${brokerFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
				<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Thank you for your application for:
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Applicant Name<br>
                    ${applicantFullName}
                </p>
				<#if (jointApplicantFullName)?? >
					<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
						Joint Applicant Name<br>
						${jointApplicantFullName}
					</p>
				</#if>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Mortgage Reference Number<br>
                    ${referenceNumber}
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                     Your case will be lapsed/cancelled from our system if all outstanding documents are not provided within the next 5 days, after this your case will have to be resubmitted on broker portal.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
							    <#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
                                <#if (document.documentFor)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                </#if>
                                <#if (document.reRequestReason)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Log on to Broker Portal</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
             <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                 We''re here to help
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you require an update on your mortgage application you can check progress at any time using our mortgage tracker.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions, please contact us on 0345 600 0205.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Natwest Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}

</html>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share email lapse message for brokers who have submitted cases but not closed all buckets by day 15',
'flow-management-email-lapse-notification', 'MAIN');

commit;

-- insert into EMAIL table

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID, 
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-broker-fya-notification', 'Service-NWDVMGPS', 'Action Required From Broker', 0, 
(select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'), null, 
(select ID FROM template WHERE template.name= 'napoli-footer'), 
(select ID FROM template WHERE template.name= 'napoli-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-bapi-fya-notification', 'Service-NWDVMGPS', 'Action Required From Broker', 0,
(select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'), null,
(select ID FROM template WHERE template.name= 'napoli-footer'),
(select ID FROM template WHERE template.name= 'napoli-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID, 
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-fya-notification', 'Service-NWDVMGPS', 'Action Required From Customer', 0, 
(select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'), null, 
(select ID FROM template WHERE template.name= 'napoli-footer'), 
(select ID FROM template WHERE template.name= 'napoli-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID, 
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-broker-avscan-failure-notification', 'Service-NWDVMGPS', 'Document Upload Failure', 0, 
(select ID FROM template WHERE template.name= 'flow-management-broker-avscan-failure-notification'), null, 
(select ID FROM template WHERE template.name= 'napoli-footer'), 
(select ID FROM template WHERE template.name= 'napoli-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-bapi-avscan-failure-notification', 'Service-NWDVMGPS', 'Document Upload Failure', 0,
(select ID FROM template WHERE template.name= 'flow-management-bapi-avscan-failure-notification'), null,
(select ID FROM template WHERE template.name= 'napoli-footer'),
(select ID FROM template WHERE template.name= 'napoli-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID, 
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-avscan-failure-notification', 'Service-NWDVMGPS', 'Document Upload Failure', 0, 
(select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'), null, 
(select ID FROM template WHERE template.name= 'napoli-footer'), 
(select ID FROM template WHERE template.name= 'napoli-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-fya-notification-xo', 'Service-NWDVMGPS', 'You have outstanding actions against your mortgage application', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo'), null,
(select ID FROM template WHERE template.name= 'xo-footer'),null
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-fya-notification-reminder-xo', 'Service-NWDVMGPS', 'Reminder | You have outstanding actions against your mortgage application', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-reminder-xo'), null,
(select ID FROM template WHERE template.name= 'xo-footer'),null
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-avscan-failure-notification-xo-and-adbo', 'Service-NWDVMGPS', 'Document Upload Failure', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-fya-notification-adbo', 'Service-NWDVMGPS', 'Action Required From Customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-avscan-failure-notification-adbo', 'Service-NWDVMGPS', 'Document Upload Failure', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-no-packaging-customer-welcome-notification-adbo', 'Service-NWDVMGPS', 'Document Upload Failure', 0,
(select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-email-lapse-notification', 'Service-NWDVMGPS', 'Action Required From Customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'), null,
(select ID FROM template WHERE template.name= 'napoli-footer'),
(select ID FROM template WHERE template.name= 'napoli-header')
);

commit;

-- insert into TEMPLATE_KEY table

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'brokerFullName', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'jointApplicantFullName', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-broker-fya-notification'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'brokerFullName', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'jointApplicantFullName', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-bapi-fya-notification'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-broker-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-broker-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-broker-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-broker-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'brokerFullName', (select ID FROM template WHERE template.name= 'flow-management-broker-avscan-failure-notification'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-bapi-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-bapi-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-bapi-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-bapi-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'brokerFullName', (select ID FROM template WHERE template.name= 'flow-management-bapi-avscan-failure-notification'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'dashboardLink', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'firstname', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'dashboardLink', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-reminder-xo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'firstname', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-reminder-xo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));

commit;
END;