DECLARE
      str varchar2(32767);
    BEGIN
-- insert XO and ADBO Header Template in TEMPLATE table for RBS

str := '<div class="emailTemplateHeaderContainer" style="margin: 0 auto; padding: 8px 0; padding: 0.5em 0; padding: 0.5rem 0; width: 100%; color: white; background: #42145F; border: 0; text-align: center;">
            <img alt width="62" height="99" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAACVCAYAAADVCJ0kAAAACXBIWXMAABCcAAAQnAEmzTo0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABGXSURBVHgB7Z1tbBzFGcefPTvBakEsH4oSVcSbirSCgHL5AEjFgYuQqpJQ5XhJVBASZ9QPIBriCNE26QefKzUtpVWctBRQJe6QeGkJYEcQwhd0ByQVpZV8iBIqgeQNqEpEpfpSoEqJ7ek8uzN3c3Oz77PnI9mfZN++zM7M/nd25plnZncN6BEFs2gCDJlfwIKZA2Ia9A+cP4BFyNF1MOVjaJhhiIXRJACnuuNbtNv7jaabttFcDmfsenO6CT3AAI0UzO9bC3AmT0/CoqKuoyeNQuaJK6YJfQ7Nq03zatPFpgGGvQhwnG5rDMJ8Q9cFSSQ4CnwG5ou0JF6Pq/AlEDUBDRSf/h4cgIV63AsQWXCsGuYht4MeWgBX5HMSKlyVVktPHmk+X494XDgEocfg7C7JkTCcKohMvNl8sRoyfDAbzFuLtG6rQCa0J1jiB2DZRL35RzsgnD8j5i3jNFgZMgLB0k5F3+gnuq/gmdixaFIzd+Ofmwcaqp05r6MysWNjDsDiFFpwqp1KwUfM2wqZ2PGh7Z01D2cqqn0Dqo3DQ5fVIGsgk2JdMnTZqY9Pv/+WuLGrDt9g3lKi9mUFMnTQHISF1WInSVGlGOOQoQvadxkcEzd0CM7sbQsyNEJ2iGsdghPI3QUZujFdI8RFqlIWC5CRAqTIl1qCs6uQWSYpQC2TLXxZKOHtq5ChF2wX3QEYgEFh+zrQxMpVF8PIpquc3w/enYXG0WNw4qNPIsVxwYVfhZHNV8GaK1bDp6c+p3G8BzNH3vMNu+KSi531V5+tR04PWT+yFvLXrnXiw3wfpvHoYgEGCvRnumWHj5i3zoGGKmX0x9vg7p9s69h2kp787jt/RU/CDhUHXqj9L5VhxaqLO7YffqYO+3d
        X4DN6AThrrlwNe556sCvsE798DioPPQdh2b5nFLbduxnkfN//vXKsiydD+zY7jzafn3R6mljcqcOlDAm58fYC3P+L0a7t59MSc8Mt18LbrzXg358ED5RU3ni4S0BkzZUWnHfecvjLa65fCC/Mr5//qTIslla8MMf+9gEEseuR+6B493dAle8N9M7Bkv7F/85AEnJ4/U6/f9Cpw6lxngcNbL33Js99mPn9L004ovmxYdPVSgE5N95RcOJCRgLCyiVWBYq96Y6NnvsxfixIGijgP0dwWqlrETxIzDCiXxoijpWrvuYsYyn2w+9iIEFic7DaSgobSHcFNzSZg5+d+m9gmLAlPSgO9/crEJewYiM66nCKiS5bJjixQAPYsodBh+hJwAYyrNiILmvFnZMDTnGPOeGmkz33PRKqlCNLJTpaUWHqdg5aRif1lHDqC1+0WMfH0FKluGbUeN+KrjJZ/fiQmrFohuojZ/IqRVuXHquVfhQ9jtjbnfP4HHSxSHXmVYoFGuk30ftBbASNkxykRL+Ijg1kP4iN4OTUHO1lWpAScUTfsPlq0EmUBjJNsTmplXBOVNGXCmzwd1F/T5piI6kLjqDou+98CHTBRTnx0b9AByj2duqk0mX+eUEdWFaO+lEs6AHoWt1z3+8gKSgK9zq++mwNktIrsTk9KeEc7EQkFV20i/EiHn4mvui9FhsZWDV0uUV/S9AjsGE6+fEnkRtHLNUTP9jbcs1y3nzlr2AY4Di0uI8lDEshNrVTbMMdyyTJ700GjpZ8l7oz0ZPn5/lbGeDJ4/Dentdojwi6bu+mNveKkHH7gRf4wKMvax31oYLXtQp+AbOlL9VkSx947GXYv6sa5RBH7N8qRoviEnXkyB+jntPZrcdOhi6x8SSjio1gFTF63YOhh/OCwE5TkN89CjnQKLiuTgs2rliy4oJm427HptZj++OAuC60WilJBgQ4WEKf0HALu/H8CXRwwYXngy60Cq6jRGEjpctywD
        tFR55OaLRktAr+HG3Vk4BCv/JMHXSBVUvSPCE6LRWtgh947FCixgrNP912cdI8YeOtM09GGhPwt917k2OLh63T0dZGYcLY2jry5NcH4NXHSeqnQbH15ona4dkTD73EqA9CSmAnKGxX+0SPuteYpxVsTotXY4r7se7HEv5pCq5a7YLj7YpzPqJ0FvAEHdub3sJp+KPj5Ak58OghzYPI1Hk1PHRZnhZ1LVOV+STMqDOVlg8th7VXfROG13wdXnvxKOgkbp4QzBM6xdBBpgfD1mqljCZ0HGFPVWc3Gkmapxvv2Ki7a68PHV17FEgXWLrRg5iUs7prj6VJV4nSdfH6tmuvy2bdTRu4KIMJKjbQUqmjdCMzR/8OusgBe9mWDg4/q2ccA+vcPU/9KLbo2EDu/v0PQQfYy5w5cgx0QYfY1q4ATUNs2GPE4S4dVQLWv9fcsN55aiKKqbj1npuo2MnvEATTfWDrHvjog3+CHlIYYkMupSVs0+0Fz5PGun79yBWh6nzXAXUo8EEpvMhYZ4e92G8eetvXx/LZfz5n3kad/QLNQ2xhiTrXj6Ma7vJ6qCoInQ9Mhceo93zUPq7YiPyglN9DVUHwB6aO0E5N2rOt2tCOz6LGRjOIJGJz8HheVd12z+ZEnZoVrBe6UtOAcxhyy+FMTwTXITYiPlSlo2Hsteg9mXmlS2wOF5oLn5ReiU6AnELBUy3husVOi16ITsWey6X5VuGoYqPlUEkwPUJFFPdq2qLjG595laJd9Dhib0/BTEOfdpSZU+mKbjT5g7FaBY8rdloTK6NOV0tLdFrCm+yhKn2mYb+JzekH0XO8hKNBDhrAXl8/is2JI/rPqRNNF9RKsVmVsngKNLB9Tyl02KWZnx1ddHyqTpd/fpGXcKKxhIdhqcTmRBUd3xKkA/zWBC/hNvQInWIneahK77zvUDTRBHcEX4CBBmjgDery9COM2DNHg5393K0adNGCRqDCio7v20qO4WjsCI5FHTRQc
        eaVqCfYhC3ZuN/vQamKMHcFp8f5xYdPUAQRJDr6xHUMHWK3Hn+dd17Zp/9xenjo8hIkfFENCoEjNNfckO9wLGGGd9/5cOhqBOeB4CwpnBcixv34z56GpyanW9vwPVQY9jrqZhXTw7C/eeAPoee4YP5wwAHnxYjx4AV7bOLpxO+7cjEe//j0sbeEt7ptnaLtqLZ3F2LLjtPGPnz3eOgX18jgyaOVgHcN9kD9/NbYYPNpaljlxPFx8/Tw17kIekd7NuIXUVqCX2veNmYA2QsZqXCk+YKjdcs9S03DOmSkRFvbluDsIxE9G/05l6A+lIN8WR6AeBIytLMMBlstvSS4MQ0ZmjHq4nd9OgRn3xWrQ4Y2aC++o9ZQfQNiAjK0gF+ukr/R1iV4Vsr1QS2/rjcfK0ftB2EBA2YWSzL2qT796PkttqWYAncW0aAdnfWqHZ7zUtxuKBmFjKg0aA3h+WJb34lAWOEvQm69+5HOjBBMo9h+U08GgmKgHq6T3xj61kECuYtA03vGz0LwK+K7jjZf2ImeV7+Aob4Yy2GfnhmndXsBMhBako19gzA/GXZCVSTBOfg2z3kYGMPv05yDnxJDkRvoH1kG89WoM9diCS6C4i9ArkBgYAs4L34nZ1u103SHx8g76PpI+o37xIKr+La5NY8vJ18Ew3Lfvp8bZq96MvEdW310VzQNt/5tOs/fwCIuH3cH1Y3mACxrBH1UOiqpCB4W9+tNQ86wnvu6/uD3b1ExLHkbbdBtv2NwPshyGGiVSt0iZmRkZGRkZGRkZGRkZGQsHU7XnhCnSy07nZqGYWiZN64DmkecaOp8PZvma9QjjKXaTsPb0ANo+vyh0NdpmlW/gFWiZpb+laAPoPko80z5hJn1OI85FIMVrDTzyPF8Glc1xGZDe8Teon+Y0TH48mFD+zxQ6BL9m4Ilpktweiuspn84nHYztDM8Dl8u6sJ54JNe/DwKXtVOr/AcRKaZxXmGfNanqcoobqN/eBKJ
        Bx3wdsd4dMXHYfX3QdCYLg8PcRHrcGn7lFAvmcL2HaxelOv7IttvCdtrUpwlYV+Jnegs6aYVHzsuSh0up1njcQrbwqZbFbbLx+ByXgjLqbB1UwqfBy/BWeScKWH7eGf+uoQvSCeJmIqTn5MuDsYzIx03x48l0QTHX7yYY2J6pFPIvLC95pNuVdhGFMszQpwcLrhYYMdAcRV5ZmeldUsSx0lIyNSYsL2m2DamOL4iXlxJOPHYUgzBVUwRqVpUpFsWwhc9tLGkgiMW0ta5kc6COSlnVGUWzrEMmB4Zyktx1PhxbN0k7ZLAL0JJOL7gIRpelKIQrhRD8Fl20hXSXXjMiOlW5W1e+ZHS4cyI6agazX3sFzOGnR9xhHodX1B0io4LxwE7jjdWBXaid7F1m+6vCxktsAuGFwvr2aTmG8Y/yv5WC+dkgfAGu6jp+nZmOrGE5Y5OmkrwMrSnto2TZGZUVVhG07LAlrkAwEpNje1rsH1V0Mu0sGz2IF1bWO4wqVV2OJbMUSFzYq+Jl+Ku+o9yPfttCHHVoW0Dl4SwogA72G+Vht9I/7C+1/2s0Tph2Wa/44p0Xwc91KFdqLCaajWYSjucCVVnqwXhAFGovcRt6bHuw+c7LbZ9nxSdWEU5mZF8G6b4y6qepN8BMIW8obBltt2G9nlZ4gHsTtbZwStDZ02RFxNr2ZpiBki70ZsjitZZQVVOlbTNr66GRxHfHPublcOT5FaKbBbWpH3EI92qKl3i32hys7AgbMO4TfElYzYIdQ8rhRPQ9knwq49d/n3QWU/h8k56TAkkWONa5+EUDQ9WX7waMtnyRjk/qjwqsBV/vH5ez3rPYrq2kG5dSrcZkK5qO193XmTAaooJIUwJeoFQcio+YbAaSNWb10/ppgbptL0tyNAPq7ucxlaoH7OvYaUF6e65zmal2yWtT4PxBoX3NielHmtGRm9IND+cuL1Ni63WezVYGwfSOVDe6OUdx6pT/IuXJnE7RbNSPV3
        2CIuNZ4W0fc74NwYpwdLDXnBR2h7oqUwxT7xNq8Wtw7ETZLHlOrhXrq5ICC2TkuJ4G9KDj/Zg52Ma+oy4gpfYb9VnjkhJCMd7e4gF5/CDtkmtlOM+++4Slm/u5/q9l3QIzkolzm7CxsVmfxNcLOJ63izhkC102zC4AxU7pbgjdZeltB2zksZ5s8/+Rsi8+c3UKrA4LSFe/HuS+3yI6+XjLmQ8x6JwjA2uD8n2iLfANllywuhPmCFq5liifp7CWcXJVKWOTwk88Ih3JmA/pxgUhu3vajSJ94wzhI/Dih6/iiLcLOkchhwn3tR4oIqwcZK4Y3uTwrYZIXEx41NsvagQES0Z1VSKkhRuXMwQi69E2u7RvaTzhDFvZWEbH0Plc0s4VbZe8BGcx1Ug7Tk2LVetQnB+zkXSOSJfVKTBwxWEsDUuTOuEJDFE0VXzL8rgA4u7RrrZK4SZFU9QOt70yZsoeiEobySkWUgk/zfpFFy868TtJbZtRnUuQpw19IfnhX3yDKW6sJyHiGDdhsNX4PqZxWGzMSaABe36TTU7SkzzHfDOmwUxYRcV81Mh7i2/xSf4Pr94oJ1fz5le2GiKjZvcE2r67AsNH7KjmcI4eAOEt6EdEL8VsD8RND+YlzK0NbADDvHb76fjhXxBHtO0pPV8yMTCUoXOTNjC+rAivJhx2eqxhGUbIsLurkkWL5bci9iUijokxzOvOSmBHaQ9mwoD8dJoR52cz25VS9os3q5YxXAzDCkqwtelvFk8bmgP+XXMcRFQXUARS1jGDlyTxR+56mSI58JnMHBztjNOqWGbZeuihSH7JZQNkxSGT1fjcwbnpDQsFk5s/AhLe4a0rYSpgLyVpHTnpLim+IkL27HBy0vxlonkH2LHiY1jQUhH1WjWpDgrRDo3frBF1Hb4HFHYz8L+so/gk0RNjQglmbh3QlUVUNg/5ZG3MUW6ZY94VGahnO4skUbjSTTBLdLt1MP1CluuGVJmMUJe/G1wXa
        5NxUnxhG2vLjtp3574a7L4Gl5VE3HNTvHW63D3CvsxLszTtJeLlXS6jZ0qh3RaRC33LHHvXt6znmbxO+HYcUq3rs92PLYA7Z6oGKf2hj8jIyMjIyMjIyMjIyPjXOf/XgyrB2suvx8AAAAASUVORK5CYII=">
        </div>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'xo and adbo Header', 'xo-and-adbo-header', 'HEADER');

-- insert XO and ADBO footer Template in TEMPLATE table

str := '<table class="emailTemplateTableFooterStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #4c4c4c; font-family: RN House Sans Regular, sans-serif;" width="100%">
            <tr>
                <td>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;"><b>About this Email</b></p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;">
                        This email is confidential and intended for the addressee only. Please delete if that is not you. This is a service message designed to keep you informed of the important information associated with your account.
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;">Please do not reply to this email as the address is not monitored. Visit our <a style="text-decoration: none; color: #AD1982;" href="https://www.rbs.co.uk/support-centre.html">Support Centre</a> if you have any queries and we''ll be happy to help.</p>
        </td>
            </tr>
            <tr>
                <td>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;"><b>Important Security Information</b></p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;">
                        RBS will NEVER ask for your full Security Number or Password when identifying you on the phone or online, and will NEVER ask for Card Reader codes on the phone, by email or text message.
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;">
                        Fraudsters may claim to be the bank, police or other companies you trust to try and access security information.
                        If you receive a call or email from RBS that you are suspicious about, cease the call immediately,
                        or forward the email to <a style="color: #1E808F;" href="mailto:phishing@rbs.com">phishing@rbs.com</a>.
                        Visit <a style="color: #1E808F;" href="www.rbs.co.uk/security">www.rbs.co.uk/security</a> for more information and advice.
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;">
                        <b>The Royal Bank of Scotland plc, Registered in Scotland No 83026. Registered Office: 36 St Andrew Square, Edinburgh EH2 2YB.</b>
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 0.874em; font-size: 0.874rem;">
                        <b>We are authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority.</b>
                    </p>
                </td>
            </tr>
        </table>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'xo and adbo Footer', 'xo-and-adbo-footer', 'FOOTER');

-- insert Customer FYA Email Template in TEMPLATE table for xo and adbo channel

str := '<!DOCTYPE html>
        <html lang="en">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <meta name="x-apple-disable-message-reformatting">
                <meta name="format-detection" content="telephone=yes">
                <!--[if !mso]><!-->
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <!--<![endif]-->
            </head>
            <style>
        a:hover {
          text-decoration: underline;
        }
        </style>

            ${templateHeader}
            <!-- Start banner -->
            <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                <tr>
                    <td colspan="2">
                        <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important!</p>
                    </td>
                </tr>
                <tr class="emailTemplateBannerTableWarningNotificationRow" style="background: rgb(242, 242, 248);">
                    <td class="emailTemplateBannerTableWarningNotificationIcon" style="width: 24px; background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);" width="24">
                        <img class="emailTemplateWarningIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA2FBMVEUAAABhYW1mXGZiYmxoXmhkZGRhYWpjY2tlXmllYWhjYGdlX2lkYWhlYGdkX2ljYWhlYGdkYWhlYGhkYWdjYGhkX2hkYGllYGhlYGhkYGhjYWhkYGlkYGhkYGhkYGdjYGhlYGhkYGhkX2hkYGlkX2hkYGhkYGhkYGhlYWlmYmptaXFxbXR0cHd0cXh3c3p6d359eoCBfYSCf4WMiY+NipCOi5GWlJmbmZ6cmZ6xr7O5t7u7ub29u77DwcTW1dfY19nb2tvc293o5+j09PT19PX6+fr7+/v///8mErf9AAAAJ3RSTlMAFRkaGxwdH0lMTU5pamtsbZGYmZqbnKKqtba319jZ2vHy8/T7/P2PX2s+AAAAAWJLR0RHYL3JewAAAOBJREFUGBltwYlWglAUBdCTihkW0ZxKxUN4R5vnsDmt7v//US54l4Wu9obT3hxEw2E0CDzUtXZSOvZwFZWuYY3x4YSWC2yIQifjEtvFXMvQOc2vWTJNAPtUn/JzydIu0M6ovkXuWEo9hKzk07cxnQB9/quHE6qz+xtWjpDQyaciOVUCQzX+lWeqGMdUFyJPVBH6VI8iV1Q9BFQvMhtRrcPL6HzJB1XqAXt03mX2esvSNoCmYel8MnkYsRA3MNfJuMT6KISWC2wIxzesiddQWdlK6diDBuq8oB8lSdTb8FD6AxLFR8uldLbzAAAAAElFTkSuQmCC" style="vertical-align: bottom;">
                    </td>
                    <td style="background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);">
                        If the application is not being progressed, you can ignore this message and no further action is required.
                    </td>
                </tr>
            </table>
            <!-- End banner -->
            <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Dear ${applicantFullName}<br>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <#if (referenceNumber)?? >
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Mortgage Reference Number<br>
                            ${referenceNumber}
                        </p>
                        </#if>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                        <#if (referenceNumber)?? >
                            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                                We need more information to complete your mortgage application ref no. ${referenceNumber}. Take action now:
                            </p>
                        <#else>
                            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                                We need more information to complete your mortgage application. Take action now:
                            </p>
                        </#if>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        					<#list documents as document>
        						<tr>
        							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
        							    <#if (document.category)?? >
        								    <b>${document.category}</b>
        								</#if>
        								<#if (document.timePeriod)?? >
        								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
        								</#if>
        								<#if (document.documentFor)?? >
                                            <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                        </#if>
        								<#if (document.reRequestReason)?? >
                                            <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                        </#if>
                                        <#if (document.requestedDate)?? >
                                            <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Requested Date: ${document.requestedDate}</p>
                                        </#if>
        							</td>
        						</tr>
        					</#list>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                        <div>
                            <a rel="noopener" target="_blank" href="${mortgageTrackerURL}" style="background-color: #42145F; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                            <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                            <span style="mso-text-raise: 15pt;">Log on to Customer Portal</span> <!--[if mso]>
                            <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                            </a>
                        </div>
                    </td>
                </tr>

            <tr class="emailTemplateTableBottom">
                <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">We''re here to help</p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        If you require an update on your mortgage application you can check progress at any time using our mortgage tracker.
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        If you have any questions, please contact us on 0345 302 0190.
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        Kind regards,
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        The Royal Bank of Scotland Mortgage Team
                    </p>
                </td>
            </tr>
            </table>
            ${templateFooter}
        </html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share FYA information with the customer for xo and adbo channels',
'flow-management-customer-fya-notification-xo-and-adbo', 'MAIN');

-- insert Customer FYA Email Template in TEMPLATE table for adbo channel
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <!-- Start banner -->
    <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td colspan="2">
                <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important!</p>
            </td>
        </tr>
        <tr class="emailTemplateBannerTableWarningNotificationRow" style="background: rgb(242, 242, 248);">
            <td class="emailTemplateBannerTableWarningNotificationIcon" style="width: 24px; background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);" width="24">
                <img class="emailTemplateWarningIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA2FBMVEUAAABhYW1mXGZiYmxoXmhkZGRhYWpjY2tlXmllYWhjYGdlX2lkYWhlYGdkX2ljYWhlYGdkYWhlYGhkYWdjYGhkX2hkYGllYGhlYGhkYGhjYWhkYGlkYGhkYGhkYGdjYGhlYGhkYGhkX2hkYGlkX2hkYGhkYGhkYGhlYWlmYmptaXFxbXR0cHd0cXh3c3p6d359eoCBfYSCf4WMiY+NipCOi5GWlJmbmZ6cmZ6xr7O5t7u7ub29u77DwcTW1dfY19nb2tvc293o5+j09PT19PX6+fr7+/v///8mErf9AAAAJ3RSTlMAFRkaGxwdH0lMTU5pamtsbZGYmZqbnKKqtba319jZ2vHy8/T7/P2PX2s+AAAAAWJLR0RHYL3JewAAAOBJREFUGBltwYlWglAUBdCTihkW0ZxKxUN4R5vnsDmt7v//US54l4Wu9obT3hxEw2E0CDzUtXZSOvZwFZWuYY3x4YSWC2yIQifjEtvFXMvQOc2vWTJNAPtUn/JzydIu0M6ovkXuWEo9hKzk07cxnQB9/quHE6qz+xtWjpDQyaciOVUCQzX+lWeqGMdUFyJPVBH6VI8iV1Q9BFQvMhtRrcPL6HzJB1XqAXt03mX2esvSNoCmYel8MnkYsRA3MNfJuMT6KISWC2wIxzesiddQWdlK6diDBuq8oB8lSdTb8FD6AxLFR8uldLbzAAAAAElFTkSuQmCC" style="vertical-align: bottom;">
            </td>
            <td style="background: rgb(242, 242, 248); padding: 1em; padding: 1rem; font-family: RN House Sans Regular, sans-serif; color: rgb(100, 96, 104);">
                If the application is not being progressed, you can ignore this message and no further action is required.
            </td>
        </tr>
    </table>
    <!-- End banner -->
    <table class="emailTemplateBannerTable" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td colspan="2">
                <p class="emailTemplateWarningBannerTitle" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-family: RN House Sans Regular, sans-serif; font-size: 1.5em; font-size: 1.5rem; font-weight: bold; color: rgb(66, 20, 95);">Important.</p>
            </td>
        </tr>
    </table>
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Hello ${applicantFullName},<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
					Thank you for your additional borrowing application.
				</p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
					We need more information, please provide the following information via your document upload portal:
				</p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
							    <#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
								<#if (document.documentFor)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                </#if>
								<#if (document.reRequestReason)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
                                <#if (document.requestedDate)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Requested Date: ${document.requestedDate}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on online banking:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Log into online banking using the link above</br>
                2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on the mobile app:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Access your RBS mobile app</br>
                2. Click on the mortgage account you’re applying for additional borrowing on</br>
                3. Click on the ‘additional borrowing’ tile in the apply menu.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you don''t have Royal Bank online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.digitalbanking.rbs.co.uk/Default.aspx?InnerPage=OLE">Online Banking</a>.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.rbs.co.uk/banking-with-royal-bank-of-scotland/royal-bank-app.html#tmta">Download the App</a>
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
               You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
               Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
           </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you have any questions, please contact us on 0800 056 3220.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Royal Bank Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share FYA information with the customer for adbo channels',
'flow-management-customer-fya-notification-adbo', 'MAIN');

-- insert Customer avScan failure Email Template in TEMPLATE table for xo and adbo channel

str := '<!DOCTYPE html>
        <html lang="en">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <meta name="x-apple-disable-message-reformatting">
                <meta name="format-detection" content="telephone=yes">
                <!--[if !mso]><!-->
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <!--<![endif]-->
            </head>
            <style>
        a:hover {
          text-decoration: underline;
        }
        </style>

        ${templateHeader}
            <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                <tr>
                    <td>
                        <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                            Important.
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Dear ${applicantFullName}<br>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <#if (referenceNumber)?? >
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Mortgage Reference Number<br>
                            ${referenceNumber}
                        </p>
                        </#if>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            <b>Request for re-upload of Document</b>
                        </p>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            We are writing to inform you that the document you recently uploaded as part of your mortgage application has issues. As a result, we were unable to process your document.
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                            <#list documentInfo as document>
                            <tr>
                                <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                                    <#if (document.category)?? >
                                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                                    </#if>
                                    <#if (document.originalFileName)?? >
                                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                            <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                        </p>
                                    </#if>
                                </td>
                            </tr>
                            </#list>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            In order to re-upload your document(s) and progress your application, please call our Mortgage Contact Centre:
                        </p>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Call us on 0800 056 3220
                        </p>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Relay UK: 18001 0800 056 3220
                        </p>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Opening hours: Mon-Fri 8am-6pm, Sat 9am-4pm, Sun Closed. Excluding public holidays.
                        </p>
                    </td>
                </tr>

            <tr class="emailTemplateTableBottom">
                <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        Kind regards,
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        The Royal Bank of Scotland Mortgage Team
                    </p>
                </td>
            </tr>
            </table>
            ${templateFooter}
        </html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to customer for xo and adbo',
'flow-management-customer-avscan-failure-notification-xo-and-adbo', 'MAIN');

-- insert Customer avScan failure Email Template in TEMPLATE table for adbo channel
str :='<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Hello ${applicantFullName},<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    <b>Request for re-upload of Document</b>
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We are writing to inform you that the document you recently uploaded as part of your additional borrowing application has issues. As a result, we were unable to process your document.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                    <#list documentInfo as document>
                    <tr>
                        <td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
                            <#if (document.category)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.category}</p>
                            </#if>
                            <#if (document.originalFileName)?? >
                                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">${document.originalFileName}<br>
                                    <span class="emailTemplateFontSizeSmall" style="font-size: 1.125em; font-size: 0.75rem;">File not accepted - Anti-virus system detected an issue</span>
                                </p>
                            </#if>
                        </td>
                    </tr>
                    </#list>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We kindly request that you upload another copy of the document as soon as possible so that we can continue to process your additional borrowing application. Please ensure that the new copy of the document is clear, legible and free from any viruses.
                    If you have any questions or concerns, please do not hesitate to reach out to us. Our team is available to assist you and ensure a smooth and seamless process.
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    We apologize for any inconvenience this may have caused and appreciate your understanding and cooperation in this matter.
                </p>
            </td>
        </tr>
        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on online banking:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Log into online banking using the link above</br>
                2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                To access your additional borrowing dashboard on the mobile app:
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                1. Access your RBS mobile app</br>
                2. Click on the mortgage account you’re applying for additional borrowing on</br>
                3. Click on the ‘additional borrowing’ tile in the apply menu.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you don''t have Royal Bank online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.digitalbanking.rbs.co.uk/Default.aspx?InnerPage=OLE">Online Banking</a>.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.rbs.co.uk/banking-with-royal-bank-of-scotland/royal-bank-app.html#tmta">Download the App</a>
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
               You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
               Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
               If you have any questions, please contact us on 0800 056 3220.
           </p>
           <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Royal Bank Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}
</html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share AV scan failed documents to customer for adbo',
'flow-management-customer-avscan-failure-notification-adbo', 'MAIN');

-- insert Customer Welcome Email Template in TEMPLATE table for xo and adbo

str := '<!DOCTYPE html>
        <html lang="en">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <meta name="x-apple-disable-message-reformatting">
                <meta name="format-detection" content="telephone=yes">
                <!--[if !mso]><!-->
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <!--<![endif]-->
            </head>
            <style>
        a:hover {
          text-decoration: underline;
        }
        </style>

            ${templateHeader}
            <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
                <tr>
                    <td>
                        <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                            Important.
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Dear ${applicantFullName}<br>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
        				<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            Thank you for your application.
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                        <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                            We need more information to complete your mortgage application. Take action now:
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        					<#list documents as document>
        						<tr>
        							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
        							    <#if (document.category)?? >
        								    <b>${document.category}</b>
        								</#if>
        								<#if (document.timePeriod)?? >
        								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
        								</#if>
        								<#if (document.documentFor)?? >
                                            <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                        </#if>
        								<#if (document.reRequestReason)?? >
                                            <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                        </#if>
        							</td>
        						</tr>
        					</#list>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                        <div>
                            <a rel="noopener" target="_blank" href="${mortgageTrackerURL}" style="background-color: #42145F; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                            <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                            <span style="mso-text-raise: 15pt;">Log on to Customer Portal</span> <!--[if mso]>
                            <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                            </a>
                        </div>
                    </td>
                </tr>

            <tr class="emailTemplateTableBottom">
                <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        If you require an update on the application, you can check progress at any time using our case tracking service, accessed via your chosen application portal.
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        Kind regards,
                    </p>
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        The Royal Bank of Scotland Mortgage Team
                    </p>
                </td>
            </tr>
            </table>
            ${templateFooter}
        </html>';

 INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share welcome information with the customer for xo and adbo channel',
        'flow-management-customer-welcome-notification-xo-and-adbo', 'MAIN');

-- insert Customer welcome email Template in TEMPLATE table for adbo channel
str := '<!DOCTYPE html>
       <html lang="en">
           <head>
               <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
               <meta name="viewport" content="width=device-width, initial-scale=1">
               <meta name="x-apple-disable-message-reformatting">
               <meta name="format-detection" content="telephone=yes">
               <!--[if !mso]><!-->
                   <meta http-equiv="X-UA-Compatible" content="IE=edge">
               <!--<![endif]-->
           </head>
           <style>
       a:hover {
         text-decoration: underline;
       }
       </style>

           ${templateHeader}
           <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
               <tr>
                   <td>
                       <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                           Important.
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                           Hello ${applicantFullName},<br>
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
       				<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                           Thank you for your additional borrowing application.
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
       					We need more information, please provide the following information via your document upload portal:
       				</p>

                   </td>
               </tr>
               <tr>
                   <td>
                       <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
       					<#list documents as document>
       						<tr>
       							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
       							    <#if (document.category)?? >
       								    <b>${document.category}</b>
       								</#if>
       								<#if (document.timePeriod)?? >
       								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
       								</#if>
       								<#if (document.documentFor)?? >
                                        <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                    </#if>
       								<#if (document.reRequestReason)?? >
                                           <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                    </#if>
       							</td>
       						</tr>
       					</#list>
                       </table>
                   </td>
               </tr>

               <tr>
                   <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                       <div>
                           <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                           style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                           <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                           <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                           <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                           </a>
                       </div>
                   </td>
               </tr>

           <tr class="emailTemplateTableBottom">
               <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        To access your additional borrowing dashboard on online banking:
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        1. Log into online banking using the link above</br>
                        2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                        3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        To access your additional borrowing dashboard on the mobile app:
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        1. Access your RBS mobile app</br>
                        2. Click on the mortgage account you’re applying for additional borrowing on</br>
                        3. Click on the ‘additional borrowing’ tile in the apply menu.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        If you don''t have Royal Bank online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.digitalbanking.rbs.co.uk/Default.aspx?InnerPage=OLE">Online Banking</a>.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.rbs.co.uk/banking-with-royal-bank-of-scotland/royal-bank-app.html#tmta">Download the App</a>
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
                       You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
                       Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       If you have any questions, please contact us on 0800 056 3220.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Kind regards,
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Royal Bank Mortgage Team
                   </p>
               </td>
           </tr>
           </table>
           ${templateFooter}
       </html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share welcome information with the customer for adbo channel',
'flow-management-customer-welcome-notification-adbo', 'MAIN');

commit;

-- insert No Packaging Customer Welcome Email Template in TEMPLATE table for adbo
str := '<!DOCTYPE html>
       <html lang="en">
           <head>
               <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
               <meta name="viewport" content="width=device-width, initial-scale=1">
               <meta name="x-apple-disable-message-reformatting">
               <meta name="format-detection" content="telephone=yes">
               <!--[if !mso]><!-->
                   <meta http-equiv="X-UA-Compatible" content="IE=edge">
               <!--<![endif]-->
           </head>
           <style>
       a:hover {
         text-decoration: underline;
       }
       </style>

           ${templateHeader}
           <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
               <tr>
                   <td>
                       <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                           Important.
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                           Hello ${applicantFullName},<br>
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
       				<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                           Following the recent Additional Borrowing application your joint party completed, we require you to agree and complete some additional information to be able to submit to our mortgage centre.
                       </p>
                   </td>
               </tr>
               <tr>
                   <td>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                       <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
       					Please log into the Additional Borrowing dashboard to access your mortgage application.
       				</p>

                   </td>
               </tr>

               <tr>
                   <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                       <div>
                           <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                           style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                           <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                           <span style="mso-text-raise: 15pt;">Go to your mortgage dashboard</span> <!--[if mso]>
                           <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                           </a>
                       </div>
                   </td>
               </tr>

           <tr class="emailTemplateTableBottom">
               <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
                    <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       If you''re an existing customer, simply log in to online banking or our award-winning mobile app.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        To access your additional borrowing dashboard on online banking:
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        1. Log into online banking using the link above</br>
                        2. Click on manage your mortgage next to the mortgage account you’re applying for additional borrowing on</br>
                        3. On the manage your mortgage home page click on ‘Borrow more’ under your loan to value.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        To access your additional borrowing dashboard on the mobile app:
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        1. Access your RBS mobile app</br>
                        2. Click on the mortgage account you’re applying for additional borrowing on</br>
                        3. Click on the ‘additional borrowing’ tile in the apply menu.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                        If you don''t have Royal Bank online banking or our app you can manage your mortgage application by registering for <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.digitalbanking.rbs.co.uk/Default.aspx?InnerPage=OLE">Online Banking</a>.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       <a style="text-decoration: underline; font-weight: bold; color: #5A287D;" href="https://www.rbs.co.uk/banking-with-royal-bank-of-scotland/royal-bank-app.html#tmta">Download the App</a>
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Our App is available to personal and business banking customers aged 11+ using compatible iOS and Android devices.
                       You''ll need a UK or international mobile number in specific countries. Once registered, you can log in securely with a personalised passcode, facial recognition or fingerprint login.
                       Fingerprint and/or facial recognition are available on selected devices. If you need any help once in the app then just tap the ''Help'' button at the bottom.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       If you have any questions, please contact us on 0800 056 3220.
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Kind regards,
                   </p>
                   <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                       Royal Bank Mortgage Team
                   </p>
               </td>
           </tr>
           </table>
           ${templateFooter}
       </html>';

INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share welcome information with the customer having no packaging requirement for adbo channel',
'flow-management-no-packaging-customer-welcome-notification-adbo', 'MAIN');

-- insert Lapse for Email Template in TEMPLATE table
x := 0;
str := '<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="x-apple-disable-message-reformatting">
        <meta name="format-detection" content="telephone=yes">
        <!--[if !mso]><!-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--<![endif]-->
    </head>
    <style>
a:hover {
  text-decoration: underline;
}
</style>

    ${templateHeader}
    <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
        <tr>
            <td>
                <p class="emailHeadingLarge" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.5em; font-size: 1.5rem; font-weight: bold;">
                    Important.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Dear ${brokerFullName}<br>
                </p>
            </td>
        </tr>
        <tr>
            <td>
				<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Thank you for your application for:
                </p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Applicant Name<br>
                    ${applicantFullName}
                </p>
				<#if (jointApplicantFullName)?? >
					<p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
						Joint Applicant Name<br>
						${jointApplicantFullName}
					</p>
				</#if>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                    Mortgage Reference Number<br>
                    ${referenceNumber}
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;"><b>Action required</b></p>
                <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                     Your case will be lapsed/cancelled from our system if all outstanding documents are not provided within the next 5 days, after this your case will have to be resubmitted on broker portal.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <table class="emailTemplateTableStandard" style="width: 100%; border-collapse: collapse; border: 0; border-spacing: 0; color: #5A287D; font-family: RN House Sans Regular, sans-serif; font-size: 1em; font-size: 1rem; line-height: 1.5em; line-height: 1.5rem;" width="100%">
					<#list documents as document>
						<tr>
							<td class="emailTemplateTableCellDocumentList" style="background-color: #f2f2f8; padding: 8px 16px; padding: 0.5em 1em; padding: 0.5rem 1rem; border-bottom: 16px solid white;" bgcolor="#f2f2f8">
							    <#if (document.category)?? >
								    <b>${document.category}</b>
								</#if>
								<#if (document.timePeriod)?? >
								    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Period: ${document.timePeriod}</p>
								</#if>
                                <#if (document.documentFor)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">For: ${document.documentFor}</p>
                                </#if>
                                <#if (document.reRequestReason)?? >
                                    <p class="emailTemplateFontSizeSmall" style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1.125em; font-size: 0.75rem;">Re-request reason: ${document.reRequestReason}</p>
                                </#if>
							</td>
						</tr>
					</#list>
                </table>
            </td>
        </tr>

        <tr>
            <td class="emailTemplateTableCellCenter" style="text-align: center;" align="center">
                <div>
                    <a rel="noopener" target="_blank" href="${mortgageTrackerURL}"
                    style="background-color: #5e10b1; font-size: 18px; font-family: Helvetica, Arial, sans-serif; font-weight: bold; text-decoration: none; padding: 16px 40px; color: #ffffff; border-radius: 30px; display: inline-block; mso-padding-alt: 0;">
                    <!--[if mso]> <i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">'||'&'||'nbsp;</i> <![endif]-->
                    <span style="mso-text-raise: 15pt;">Log on to Broker Portal</span> <!--[if mso]>
                    <i style="letter-spacing: 25px; mso-font-width: -100%;">'||'&'||'nbsp;</i> <![endif]-->
                    </a>
                </div>
            </td>
        </tr>

    <tr class="emailTemplateTableBottom">
        <td class="emailTemplateTableCellBottom" style="border-bottom: 8px solid #42145f;">
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                We''re here to help
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                If you require an update on your mortgage application you can check progress at any time using our mortgage tracker.
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                Kind regards,
            </p>
            <p style="margin: 16px 0px 16px 0px; margin: 1em 0px 1em 0px; margin: 1rem 0px 1rem 0px; font-size: 1em; font-size: 1rem;">
                The Royal Bank of Scotland Mortgage Team
            </p>
        </td>
    </tr>
    </table>
    ${templateFooter}

</html>';
INSERT INTO template (CONTENT, DESCRIPTION, NAME, TYPE) VALUES(str, 'This template will be used to share email lapse message for brokers who have submitted cases but not closed all buckets by day 15',
'flow-management-email-lapse-notification', 'MAIN');

commit;

-- insert into EMAIL table

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-fya-notification-xo-and-adbo', 'Service-RBDVMGPS', 'Action Required From Customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-fya-notification-adbo', 'Service-RBDVMGPS', 'Action Required From Customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-avscan-failure-notification-xo-and-adbo', 'Service-RBDVMGPS', 'Document Upload Failure', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-avscan-failure-notification-adbo', 'Service-RBDVMGPS', 'Document Upload Failure', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-welcome-notification-xo-and-adbo', 'Service-RBDVMGPS', 'Email for initial submission - customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-xo-and-adbo'), null,
(select ID FROM template WHERE template.name= 'xo-and-adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header')
);

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-customer-welcome-notification-adbo', 'Service-RBDVMGPS', 'Email for initial submission - customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-no-packaging-customer-welcome-notification-adbo', 'Service-RBDVMGPS', 'Email for initial submission - customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'), null,
(select ID FROM template WHERE template.name= 'adbo-footer'),
(select ID FROM template WHERE template.name= 'xo-and-adbo-header'));

INSERT INTO email (BCC_RECIPIENTS, CC_RECIPIENTS, TO_RECIPIENTS, NOTIFICATION_TYPE, SERVICE_USER, SUBJECT, INTERNAL_ONLY, TEMPLATE_ID,
TEMPLATE_COMMON_ID, TEMPLATE_FOOTER_ID, TEMPLATE_HEADER_ID) VALUES
(null, null, null, 'flow-management-email-lapse-notification', 'Service-RBDVMGPS', 'Action Required From Customer', 0,
(select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'), null,
(select ID FROM template WHERE template.name= 'napoli-footer'),
(select ID FROM template WHERE template.name= 'napoli-header'));

commit;

-- insert into TEMPLATE_KEY table

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-xo-and-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-fya-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-xo-and-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-avscan-failure-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-xo-and-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-xo-and-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documents', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-customer-welcome-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'documents', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-no-packaging-customer-welcome-notification-adbo'));

INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'subject', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'toRecipients', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'mortgageTrackerURL', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'documentInfo', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(0, 'referenceNumber', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));
INSERT INTO template_key (MANDATORY, NAME, TEMPLATE_ID) VALUES
(1, 'applicantFullName', (select ID FROM template WHERE template.name= 'flow-management-email-lapse-notification'));

commit;

END;