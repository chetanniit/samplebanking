package com.natwest.pbbdhb.notification.manager.util;

import com.natwest.pbbdhb.notification.manager.model.email.NotificationInfo;
import com.natwest.pbbdhb.notification.manager.model.enums.NotificationTemplate;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import org.junit.jupiter.api.Test;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT;
import static org.junit.jupiter.api.Assertions.*;

class NotificationTemplateNameUtilTest {

    @Test
    void testCustomerNotificationTemplateForXOAndADBOChannel() {
        FIRequest fiRequest = TestUtil.createFiRequestForXOAndADBO();
        fiRequest.setOperation(TestConstants.REQUIRED_DOCS);

        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        assertEquals(NotificationTemplate.CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_XO.getTemplateName(), notificationInfo.getTemplateName());
    }

    @Test
    void testCustomerNotificationTemplateWhenChannelIsNull() {
        FIRequest fiRequest = TestUtil.createFiRequestForXOAndADBO();
        fiRequest.setChannel(null);
        fiRequest.setOperation(TestConstants.REQUIRED_DOCS);

        assertThrows(IllegalArgumentException.class, () -> NotificationTemplateUtil.getNotificationInfo(fiRequest));
    }

    @Test
    void testCustomerNotificationTemplateForBrokerChannel() {
        FIRequest fiRequest = TestUtil.createFiRequestForXOAndADBO();
        fiRequest.setChannel(TestConstants.INTERMEDIARY_NAPOLI);
        fiRequest.setOperation(TestConstants.AV_SCAN_FAILURE_EVENT);

        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        assertEquals(NotificationTemplate.BROKER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE.getTemplateName(), notificationInfo.getTemplateName());
    }

    @Test
    void testCustomerNotificationTemplateForBAPIChannel() {
        FIRequest fiRequest = TestUtil.createFiRequestForBAPI();
        fiRequest.setOperation(TestConstants.REQUIRED_DOCS);

        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        assertEquals(NotificationTemplate.BAPI_WELCOME_NOTIFICATION_TEMPLATE.getTemplateName(), notificationInfo.getTemplateName());
    }

    @Test
    void testCustomerNotificationTemplateForADBO() {
        FIRequest fiRequest = TestUtil.createFiRequestForADBO();
        fiRequest.setOperation(TestConstants.REQUIRED_DOCS);

        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        assertEquals(NotificationTemplate.CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName(), notificationInfo.getTemplateName());
    }

    @Test
    void testCustomerNotificationTemplateForADBOWithNoPackaging() {
        FIRequest fiRequest = TestUtil.createFiRequestForADBOWithNoPackaging();
        fiRequest.setOperation(TestConstants.REQUIRED_DOCS);

        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        assertEquals(NotificationTemplate.NO_PACKAGING_CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName(), notificationInfo.getTemplateName());
        assertEquals(EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT, notificationInfo.getEmailSubject());
    }

}
