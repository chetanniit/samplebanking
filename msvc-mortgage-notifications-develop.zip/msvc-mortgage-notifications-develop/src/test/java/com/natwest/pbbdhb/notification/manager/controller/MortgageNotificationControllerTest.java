package com.natwest.pbbdhb.notification.manager.controller;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.service.impl.MortgageNotificationsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static com.natwest.pbbdhb.notification.manager.util.TestConstants.*;
import static com.natwest.pbbdhb.notification.manager.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = MortgageNotificationController.class, properties = {"spring.profiles.active=test"})
@DisplayName("MortgageNotificationController - MVC Test")
public class MortgageNotificationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MortgageNotificationsServiceImpl mortgageNotificationsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }



    @Test
    void testSendBrokerFYANotification() throws Exception {
        EmailRequest emailRequest = createFYAEmailRequest();
        when(mortgageNotificationsService.sendEmail(NWB_BRAND,emailRequest)).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        MvcResult result = mockMvc.perform(post("/sendEmail")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(emailRequest)))
                .andExpect(status().isOk())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testSendBrokerFYINotification() throws Exception {
        EmailRequest emailRequest = createFYIEmailRequest();
        when(mortgageNotificationsService.sendEmail(NWB_BRAND,emailRequest)).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        MvcResult result = mockMvc.perform(post("/sendEmail")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(emailRequest)))
                .andExpect(status().isOk())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
    }


}
