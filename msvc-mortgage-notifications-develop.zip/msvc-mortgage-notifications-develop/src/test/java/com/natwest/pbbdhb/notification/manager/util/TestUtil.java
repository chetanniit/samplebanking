package com.natwest.pbbdhb.notification.manager.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.enums.NotificationTemplate;
import com.natwest.pbbdhb.notification.manager.model.request.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.List;
import java.util.ArrayList;

import static com.natwest.pbbdhb.notification.manager.util.TestConstants.BROKER_CASE_NOTIFICATION;
import static com.natwest.pbbdhb.notification.manager.util.TestConstants.BROKER_FI_NOTIFICATION;
import static com.natwest.pbbdhb.notification.manager.util.TestConstants.NWB_BRAND;

public class TestUtil {

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static EmailRequest createFYAEmailRequest() {
        return EmailRequest.builder().notificationType(BROKER_CASE_NOTIFICATION).parameters(createFYAEmailParameter()).build();

    }

    public static Map<String, Object> createFYAEmailParameter() {
        Map<String, Object> parameter = new HashMap<>();
        FIRequest fiRequest = createFIRequest();
        parameter.put("subject", " This email is to test Broker FYA template");
        parameter.put("packingRequirementsURL", "www.google.com");
        parameter.put("mortgageTrackerURL", "www.google.com");
        parameter.put("requiredDocuments", fiRequest.getDocumentRequests().stream().map(Document::getDocumentName).collect(Collectors.joining(", ")));
        parameter.put("dueDate", fiRequest.getDocumentRequests().stream().map(Document::getDueDate).collect(Collectors.joining(", ")));
        setBrokerInfo(fiRequest, parameter);
        setApplicantInfo(fiRequest, parameter);
        setMilestone(fiRequest, parameter);
        return parameter;
    }

    public static EmailRequest createFYIEmailRequest() {
        return EmailRequest.builder().notificationType(BROKER_FI_NOTIFICATION).parameters(createFYIEmailParameter()).build();

    }

    public static Map<String, Object> createFYIEmailParameter() {
        Map<String, Object> parameter = new HashMap<>();
        FIRequest fiRequest = createFIRequest();
        parameter.put("mortgageTrackerURL", "www.google.com");
        parameter.put("subject", " This email is to test Broker FYI template");
        parameter.put("requiredDocuments", fiRequest.getDocumentRequests().stream().map(Document::getDocumentName).collect(Collectors.joining(", ")));
        setBrokerInfo(fiRequest, parameter);
        setApplicantInfo(fiRequest, parameter);
        setDocumentDetails(fiRequest, parameter);
        return parameter;
    }

    public static FIRequest createFIRequest() {
        return FIRequest.builder().referenceNumber("84153756").sequenceNumber("01")
                .userFullName("John smith").userRACFId("KENNEJF")
                .documentRequests(Collections.singletonList(getDocument()))
                .applicants(Collections.singletonList(getApplicationInfo()))
                .brokerInfo(getBrokerInfo())
                .build();
    }

    private static Document getDocument() {
        return Document.builder().requiredFor(
                Collections.singletonList(DocumentFor.builder().applicantId("12345").build())
        ).category("payslip").fromDate("2021-06-26").toDate("2021-07-26").dueDate("2022-06-03")
                .reRequestReason(Collections.singletonList("Need to check the expenses")).timePeriod("4 months").build();
    }

    private static ApplicantInformation getApplicationInfo() {
        return ApplicantInformation.builder().title("MR").lastName("HLRJHBRKGP").firstName("EMNJ").applicantId("12345")
                .emailAddress("david@listers.ltd.uk").notificationRequired(true).mobileNumber("3445545803").build();
    }

    private static BrokerInformation getBrokerInfo() {
        return BrokerInformation.builder().emailAddress("david@listers.ltd.uk").firmName("Listers Limited (83738)")
                .fullName("David Sutherland")
                .notificationRequired(true).mobileNumber("3445545803").build();
    }

    private static void setBrokerInfo(FIRequest fiRequest, Map<String, Object> emailParameter) {
        emailParameter.put("brokerFullName", fiRequest.getBrokerInfo().getFullName());
        emailParameter.put("brokerFirmName", fiRequest.getBrokerInfo().getFirmName());
        emailParameter.put("mortgageReference", fiRequest.getReferenceNumber());
        emailParameter.put("toRecipients", fiRequest.getBrokerInfo().getEmailAddress());
    }

    private static void setApplicantInfo(FIRequest fiRequest, Map<String, Object> emailParameter) {

        if (Objects.isNull(fiRequest.getApplicants()) || fiRequest.getApplicants().isEmpty()) {
            return;
        }

        ApplicantInformation applicant = fiRequest.getApplicants().get(0);
        emailParameter.put("clientName", String.join(" ", applicant.getTitle(), applicant.getFirstName(), applicant.getLastName()));
        emailParameter.put("applicantTitle", applicant.getTitle());
        emailParameter.put("applicantFirstName", applicant.getFirstName());
        emailParameter.put("applicantLastName", applicant.getLastName());
        if (fiRequest.getApplicants().size() > 1) {
            ApplicantInformation jointApplicant = fiRequest.getApplicants().get(1);
            emailParameter.put("jointApplicantTitle", jointApplicant.getTitle());
            emailParameter.put("jointApplicantFirstName", jointApplicant.getFirstName());
            emailParameter.put("jointApplicantLastName", jointApplicant.getLastName());
        }

    }

    private static void setDocumentDetails(FIRequest fiRequest, Map<String, Object> emailParameter) {
        if (Objects.isNull(fiRequest.getDocumentRequests()) || fiRequest.getDocumentRequests().isEmpty()) {
            return;
        }
        emailParameter.put("documentPurpose", "To validate income");
        emailParameter.put("documentCategory", fiRequest.getDocumentRequests().stream().map(Document::getCategory).collect(Collectors.joining(", ")));
        emailParameter.put("requiredFor", fiRequest.getDocumentRequests().stream().
                flatMap(document -> document.getRequiredFor().stream().map(documentFor -> documentFor.getApplicantId())).collect(Collectors.joining(", ")));
        emailParameter.put("dueDate", fiRequest.getDocumentRequests().stream().map(Document::getDueDate).collect(Collectors.joining(", ")));
        emailParameter.put("documentTimePeriod", fiRequest.getDocumentRequests().stream().map(Document::getTimePeriod).collect(Collectors.joining(", ")));
        emailParameter.put("reRequestReason", fiRequest.getDocumentRequests().stream()
                .flatMap(document -> document.getReRequestReason().stream()).collect(Collectors.joining(", ")));
    }

    private static void setMilestone(FIRequest fiRequest, Map<String, Object> emailParameter) {
        emailParameter.put("previousMilestoneName", "Valuation");
        emailParameter.put("newMilestoneName", "Offer");
        emailParameter.put("offerStarts", "In Progress");
        emailParameter.put("completionStarts", "Yet to start");
    }

    public static FIRequest createFiRequest() {
        List<ApplicantInformation> applicantInformationList = new ArrayList<>();
        applicantInformationList.add(createApplicantInformation());
        applicantInformationList.add(createApplicantInformation());

        List<Document> documents = new ArrayList<>();
        documents.add(createDocument());
        FIRequest fiRequest = FIRequest.builder().build();
        fiRequest.setBrand(NWB_BRAND);
        fiRequest.setReferenceNumber("80101231");
        fiRequest.setNotificationTemplateName(NotificationTemplate.valueOf("BROKER_FYA_NOTIFICATION_TEMPLATE").getTemplateName());
        fiRequest.setBrokerInfo(createBrokerInformation());
        fiRequest.setApplicants(applicantInformationList);
        fiRequest.setDocumentRequests(documents);
        return fiRequest;
    }

    public static FIRequest createFiRequestForXOAndADBO() {
        List<ApplicantInformation> applicantInformationList = new ArrayList<>();
        applicantInformationList.add(createApplicantInformation());
        applicantInformationList.add(createApplicantInformation());

        List<Document> documents = new ArrayList<>();
        documents.add(createDocument());
        FIRequest fiRequest = FIRequest.builder().build();
        fiRequest.setBrand(NWB_BRAND);
        fiRequest.setReferenceNumber("80101231");
        fiRequest.setBrokerInfo(createBrokerInformation());
        fiRequest.setChannel("INTERNET");
        fiRequest.setApplicants(applicantInformationList);
        fiRequest.setDocumentRequests(documents);
        return fiRequest;
    }

    public static FIRequest createFiRequestForADBO() {
        List<ApplicantInformation> applicantInformationList = new ArrayList<>();
        applicantInformationList.add(createApplicantInformation());
        applicantInformationList.add(createApplicantInformation());

        List<Document> documents = new ArrayList<>();
        documents.add(createDocument());
        FIRequest fiRequest = FIRequest.builder().build();
        fiRequest.setBrand(NWB_BRAND);
        fiRequest.setReferenceNumber("80101231");
        fiRequest.setBrokerInfo(createBrokerInformation());
        fiRequest.setChannel("INTERNET");
        fiRequest.setLoanPurpose("ADDITIONAL_BORROWING");
        fiRequest.setApplicants(applicantInformationList);
        fiRequest.setDocumentRequests(documents);
        return fiRequest;
    }

    public static FIRequest createFiRequestForADBOWithNoPackaging() {
        List<ApplicantInformation> applicantInformationList = new ArrayList<>();
        applicantInformationList.add(createApplicantInformation());
        applicantInformationList.add(createApplicantInformation());

        List<Document> documents = new ArrayList<>();
        FIRequest fiRequest = FIRequest.builder().build();
        fiRequest.setBrand(NWB_BRAND);
        fiRequest.setReferenceNumber("80101231");
        fiRequest.setBrokerInfo(createBrokerInformation());
        fiRequest.setChannel("INTERNET");
        fiRequest.setLoanPurpose("ADDITIONAL_BORROWING");
        fiRequest.setApplicants(applicantInformationList);
        fiRequest.setDocumentRequests(documents);
        return fiRequest;
    }

    public static FIRequest createFiRequestForBAPI() {
        List<ApplicantInformation> applicantInformationList = new ArrayList<>();
        applicantInformationList.add(createApplicantInformation());
        applicantInformationList.add(createApplicantInformation());

        List<Document> documents = new ArrayList<>();
        documents.add(createDocument());
        FIRequest fiRequest = FIRequest.builder().build();
        fiRequest.setBrand(NWB_BRAND);
        fiRequest.setReferenceNumber("80101231");
        fiRequest.setBrokerInfo(createBrokerInformation());
        fiRequest.setChannel("INTERMEDIARY_BROKER_API");
        fiRequest.setApplicants(applicantInformationList);
        fiRequest.setDocumentRequests(documents);
        return fiRequest;
    }

    public static BrokerInformation createBrokerInformation() {
        return BrokerInformation.builder().emailAddress("colin.wimble@uk.co").fullName("Colin Wimble").build();
    }

    public static ApplicantInformation createApplicantInformation() {
        return ApplicantInformation.builder()
                .emailAddress("smith@uk.co")
                .applicantId("12345")
                .notificationRequired(Boolean.TRUE)
                .build();
    }

    public static Document createDocument() {
        List<DocumentFor> documentForList = new ArrayList<>();
        DocumentFor documentFor = DocumentFor.builder().applicantId("12345")
                .build();
        documentForList.add(documentFor);
        documentForList.add(documentFor);
        return Document.builder()
                .category("Payslip")
                .reRequestReason(Collections.singletonList("Missing document"))
                .requiredFor(documentForList)
                .purpose(Collections.singletonList("Missing document"))
                .documentInfo(Collections.singletonList(DocumentInfo.builder().originalFileName("Bonus.pdf").build()))
                .build();
    }
}