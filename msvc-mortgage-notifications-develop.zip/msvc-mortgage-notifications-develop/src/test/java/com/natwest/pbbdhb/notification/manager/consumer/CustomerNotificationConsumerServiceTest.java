package com.natwest.pbbdhb.notification.manager.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.enums.Channel;
import com.natwest.pbbdhb.notification.manager.model.enums.FlowOperation;
import com.natwest.pbbdhb.notification.manager.model.enums.NotificationTemplate;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import com.natwest.pbbdhb.notification.manager.service.EmailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.kafka.support.Acknowledgment;

import static com.natwest.pbbdhb.notification.manager.util.TestConstants.INTERNET;
import static com.natwest.pbbdhb.notification.manager.util.TestUtil.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class CustomerNotificationConsumerServiceTest {

    @InjectMocks
    private CustomerNotificationConsumerService consumerService;

    @Mock
    private EmailService emailService;
    
    private ObjectMapper mapper = new ObjectMapper();
    
    @Mock
    private ObjectMapper objectMapper;

    @Test
    void testListenerCustomerFYA() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setNotificationTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testListenerCustomerFYACaseId() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setReferenceNumber(null);
        fiRequest.setCaseId("case12344");
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setNotificationTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testListenerCustomerAVScanFailure() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.AV_SCAN_FAILURE_EVENT.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setNotificationTemplateName(NotificationTemplate.CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE.getTemplateName());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testListenerCustomerFYAAutoChaser() throws JsonMappingException, JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.AUTO_CHASER.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setNotificationTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testListenerCustomerFYAForXOAndADBO() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequestForXOAndADBO();
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setNotificationTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        fiRequest.setChannel(INTERNET);
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testListenerCustomerWithNoPackagingForADBO() throws JsonMappingException, JsonProcessingException {
        FIRequest fiRequest = createFiRequestForADBOWithNoPackaging();
        fiRequest.setOperation(FlowOperation.REQUIRED_DOCS.getOperationName());
        fiRequest.setNotificationTemplateName(NotificationTemplate.NO_PACKAGING_CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName());
        fiRequest.setChannel(INTERNET);
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testListenerCustomerAVScanFailureForXOAndADBO() throws JsonMappingException, JsonProcessingException {
        FIRequest fiRequest = createFiRequestForXOAndADBO();
        fiRequest.setOperation(FlowOperation.AV_SCAN_FAILURE_EVENT.getOperationName());
        fiRequest.setNotificationTemplateName(NotificationTemplate.CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE_FOR_XO.getTemplateName());
        fiRequest.setChannel(INTERNET);
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }

    @Test
    void testRetryListenerCustomerFYA() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());

        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.retry(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService, times(2)).sendEmail(anyString(), any());
    }
}
