package com.natwest.pbbdhb.notification.manager.validator;

import com.natwest.pbbdhb.notification.manager.validator.format.ReceiverEmailFormatConstraint;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintValidatorContext;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ReceiverEmailFormatValidatorTest {

    @InjectMocks
    private ReceiverEmailFormatValidator validator;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(validator, "isRequired", true);
    }

    @Test
    void testIsValid() {
        boolean isValid = validator.isValid("", mock(ConstraintValidatorContext.class));
        assertFalse(isValid);
    }

    @Test
    void testIsValid2() {
        boolean isValid = validator.isValid("test@test.com", mock(ConstraintValidatorContext.class));
        assertTrue(isValid);
    }

    @Test
    void testInitialize(){
        validator.initialize(mock(ReceiverEmailFormatConstraint.class));
    }


}