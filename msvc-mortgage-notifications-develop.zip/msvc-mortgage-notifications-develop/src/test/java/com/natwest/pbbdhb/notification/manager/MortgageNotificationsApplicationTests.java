package com.natwest.pbbdhb.notification.manager;

import org.junit.Ignore;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

@Ignore
class MortgageNotificationsApplicationTests {

    @Test
    void testContextLoads() {
        Assertions.assertTrue(true);
    }

}
