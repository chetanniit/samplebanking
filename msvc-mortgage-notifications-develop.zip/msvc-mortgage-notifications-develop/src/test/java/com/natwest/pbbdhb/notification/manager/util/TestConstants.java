package com.natwest.pbbdhb.notification.manager.util;

public class TestConstants {

    public static final String NWB_BRAND = "NWB";
    public static final String BRAND = "brand";
    public static final String BROKER_CASE_NOTIFICATION = "flow-management-broker-case-notification";
    public static final String BROKER_FI_NOTIFICATION = "flow-management-broker-fi-notification";
    public static final String DOCUMENT_INFO = "documentInfo";
    public static final String INTERNET = "INTERNET";
    public static final String INTERMEDIARY_NAPOLI = "INTERMEDIARY_NAPOLI";
    public static final String REQUIRED_DOCS = "requiredDocs";
    public static final String AV_SCAN_FAILURE_EVENT = "avScanFailure";
}
