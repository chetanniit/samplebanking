package com.natwest.pbbdhb.notification.manager.util;

import com.natwest.pbbdhb.notification.manager.model.request.ApplicantInformation;
import com.natwest.pbbdhb.notification.manager.model.request.Document;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormat;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.populateApplicantAndAvScanFailedDocDetails;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.getFullName;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.getTimePeriodByFromDateAndToDate;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormatForTimePeriod;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormatForRequestedDate;
import static com.natwest.pbbdhb.notification.manager.util.TestConstants.DOCUMENT_INFO;
import static com.natwest.pbbdhb.notification.manager.util.TestUtil.createFiRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class ApplicationUtilTest {

    @ParameterizedTest
    @CsvSource({"  , ", "2022-11-25,25-11-2022", "abc,abc"})
    void testDateTimeValidity(String value, String expectation) {
        assertEquals(expectation, convertDateFormat(value));
    }

    @Test
    void testPopulateApplicantAndAvScanFailedDocDetails() {
        FIRequest fiRequest = createFiRequest();
        Map<String, Object> emailParameter = new HashMap<>();
        populateApplicantAndAvScanFailedDocDetails(emailParameter, fiRequest.getDocumentRequests());
        assertNotNull(emailParameter.get(DOCUMENT_INFO));
    }

    @Test
    void testPopulateApplicantAndAvScanFailedDocDetailsWithRequiredForIsEmpty() {
        FIRequest fiRequest = createFiRequest();
        fiRequest.getDocumentRequests().get(0).setRequiredFor(null);
        Map<String, Object> emailParameter = new HashMap<>();
        populateApplicantAndAvScanFailedDocDetails(emailParameter, fiRequest.getDocumentRequests());
        assertNotNull(emailParameter.get(DOCUMENT_INFO));
    }

    @Test
    void testGetFullName() {
        String fullName = getFullName(ApplicantInformation.builder().title("Mr").firstName("Harry").lastName("John").build());
        assertEquals("Harry John", fullName);
    }

    @Test
    void testConvertDateFormatForTimePeriod() {
        String convertDateStr = convertDateFormatForTimePeriod("2023-08-30");
        assertEquals("30/08/2023", convertDateStr);
    }

    @Test
    void testConvertDateFormatForTimePeriodNull() {
        String convertDateStr = convertDateFormatForTimePeriod(null);
        assertNull(convertDateStr);
    }

    @Test
    void testConvertDateFormatForTimePeriodParseError() {
        String convertDateStr = convertDateFormatForTimePeriod("202939309-01");
        assertNull(convertDateStr);
    }

    @Test
    void testGetTimePeriodByFromDateAndToDate() {
        String convertDateStr = getTimePeriodByFromDateAndToDate(Document.builder().fromDate("2023-09-20").toDate("2023-12-12").build());
        assertEquals("20/09/2023 to 12/12/2023", convertDateStr);
    }

    @Test
    void testGetTimePeriodByFromDateNull() {
        String convertDateStr = getTimePeriodByFromDateAndToDate(Document.builder().toDate("2023-12-12").build());
        assertNull(convertDateStr);
    }

    @Test
    void testGetTimePeriodByToDateNull() {
        String convertDateStr = getTimePeriodByFromDateAndToDate(Document.builder().fromDate("2023-12-12").build());
        assertNull(convertDateStr);
    }

    @Test
    void testConvertDateFormatForRequestedDate() {
        String convertDateStr = convertDateFormatForRequestedDate("2023-07-20T06:02:00.740");
        assertEquals("20/07/2023", convertDateStr);
    }

    @Test
    void testConvertDateFormatForInvalidRequestedDate() {
        String convertDateStr = convertDateFormatForRequestedDate("2023-20T06:02:00.740");
        assertNull(convertDateStr);
    }

    @Test
    void testConvertDateFormatForRequestedDateNull() {
        String convertDateStr = convertDateFormatForRequestedDate(null);
        assertNull(convertDateStr);
    }
}
