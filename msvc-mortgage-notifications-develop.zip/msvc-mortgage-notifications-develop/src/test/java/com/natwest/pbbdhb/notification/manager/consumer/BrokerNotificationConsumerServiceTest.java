package com.natwest.pbbdhb.notification.manager.consumer;

import static com.natwest.pbbdhb.notification.manager.util.TestUtil.createFiRequest;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.kafka.support.Acknowledgment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.enums.Channel;
import com.natwest.pbbdhb.notification.manager.model.enums.FlowOperation;
import com.natwest.pbbdhb.notification.manager.model.enums.NotificationTemplate;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import com.natwest.pbbdhb.notification.manager.service.EmailService;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class BrokerNotificationConsumerServiceTest {

    @InjectMocks
    private BrokerNotificationConsumerService consumerService;

    @Mock
    private EmailService emailService;
    
    private ObjectMapper mapper = new ObjectMapper();
    
    @Mock
    private ObjectMapper objectMapper;

    @Test
    void testListenerBrokerFYA() throws JsonMappingException, JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setNotificationTemplateName(NotificationTemplate.BROKER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }

    @Test
    void testListenerBrokerFYAChaser() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.CHASER.getOperationName());
        fiRequest.setNotificationTemplateName(NotificationTemplate.BROKER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }

    @Test
    void testListenerBrokerFYAAutoChaser() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.AUTO_CHASER.getOperationName());
        fiRequest.setNotificationTemplateName(NotificationTemplate.BROKER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }

    @Test
    void testRetryListenerBrokerFYA() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.retry(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }

    @Test
    void testListenerBrokerFYAWithoutApplicants() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setApplicants(null);
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setNotificationTemplateName(NotificationTemplate.BROKER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }

    @Test
    void testListenerBrokerFYI() throws JsonMappingException, JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.getDocumentRequests().get(0).setCategory(null);
        fiRequest.setOperation(FlowOperation.FI_REQUEST.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }

    @Test
    void testListenerBrokerAVScanFailure() throws JsonProcessingException {
        FIRequest fiRequest = createFiRequest();
        fiRequest.setOperation(FlowOperation.AV_SCAN_FAILURE_EVENT.getOperationName());
        fiRequest.setChannel(Channel.INTERMEDIARY_NAPOLI.name());
        fiRequest.setNotificationTemplateName(NotificationTemplate.BROKER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE.getTemplateName());
        
        String request = mapper.writeValueAsString(fiRequest);
        doReturn(fiRequest).when(objectMapper).readValue(anyString(), eq(FIRequest.class));
        
        consumerService.listener(request, 1, "topic", 0, mock(Acknowledgment.class));
        verify(emailService).sendEmail(anyString(), any());
    }
}
