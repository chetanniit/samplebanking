package com.natwest.pbbdhb.notification.manager.controller;

import com.natwest.pbbdhb.notification.manager.model.exception.ErrorResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class MortgageNotificationControllerAdviceTest {

    @InjectMocks
    private MortgageNotificationControllerAdvice mortgageNotificationControllerAdvice;

    @Test
    void testHandleHttpClientErrorException() {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.NOT_FOUND);
        ResponseEntity<ErrorResponse> response = mortgageNotificationControllerAdvice.handleHttpClientErrorException(ex);
        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpServerErrorException() {
        HttpServerErrorException ex = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
        ResponseEntity<ErrorResponse> response = mortgageNotificationControllerAdvice.handleHttpServerErrorException(ex);
        assertEquals(500, response.getStatusCodeValue());
    }
}
