package com.natwest.pbbdhb.notification.manager.service;

import com.natwest.pbbdhb.notification.manager.service.impl.MortgageNotificationsServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.natwest.pbbdhb.notification.manager.util.TestConstants.NWB_BRAND;
import static com.natwest.pbbdhb.notification.manager.util.TestUtil.createFYAEmailRequest;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class MortgageNotificationsServiceTest {

    @InjectMocks
    private MortgageNotificationsServiceImpl mortgageNotificationsService;

    @Mock
    private EmailService emailService;

    @Test
    void testSendEmail() {
        mortgageNotificationsService.sendEmail(NWB_BRAND,createFYAEmailRequest());
        verify(emailService, times(1)).sendEmail(anyString(), any());
    }

}
