package com.natwest.pbbdhb.notification.manager.service;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.service.impl.EmailServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class EmailServiceImplTest {

    @InjectMocks
    private EmailServiceImpl emailService;

    @Mock
    private RestTemplate restTemplate;

    public static final String BASE_URL = "https://msvc-customer-communication-v1-hboapiplatform.sit.internal-paas-ms.api.banksvcs.net/mortgages/v1/msvc-customer-communication/email";

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(emailService, "emailServiceEndPoint", BASE_URL);
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @Test
    void testSendEmail() {

        when(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(anyString(), HttpStatus.OK));
        emailService.sendEmail(anyString(), any());
        verify(restTemplate).postForEntity(anyString(), any(), eq(String.class));
    }

    @Test
    void testSendEmailException() {
        when(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        EmailRequest emailRequest = EmailRequest.builder().build();
        assertThrows(
                HttpClientErrorException.class, () -> emailService.sendEmail("NWB", emailRequest));
        verify(restTemplate).postForEntity(anyString(), any(), eq(String.class));
    }

}
