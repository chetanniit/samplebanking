package com.natwest.pbbdhb.notification.manager.util;

import com.natwest.pbbdhb.notification.manager.model.email.NotificationInfo;
import com.natwest.pbbdhb.notification.manager.model.enums.Channel;
import com.natwest.pbbdhb.notification.manager.model.enums.FlowOperation;
import com.natwest.pbbdhb.notification.manager.model.enums.NotificationTemplate;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.CHASER_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.CHASER_EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.FYA_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.GENERIC_AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.GENERIC_CHASER_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.GENERIC_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.GENERIC_FYA_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.XO_GENERIC_CHASER_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.XO_GENERIC_FYA_EMAIL_TEMPLATE_SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.prepareSubject;

@Slf4j
public class NotificationTemplateUtil {

    private NotificationTemplateUtil(){
    }

    public static NotificationInfo getNotificationInfo(FIRequest fiRequest) {
        boolean isADBOCase = ApplicationFunctions.isADBOCaseApplication.test(fiRequest);
        NotificationInfo notificationInfo = NotificationInfo.builder().isADBOCase(isADBOCase).build();
        FlowOperation flowOperation = Arrays.stream(FlowOperation.values())
                .filter(operation1 -> StringUtils.equalsIgnoreCase(fiRequest.getOperation(), operation1.getOperationName()))
                .findFirst().orElse(FlowOperation.DEFAULT);
        Channel channel = Arrays.stream(Channel.values())
                .filter(channelOpt -> StringUtils.equalsIgnoreCase(fiRequest.getChannel(), channelOpt.name()))
                .findFirst().orElse(Channel.DEFAULT);

        switch (channel) {
            case INTERNET:
                populateNotificationInfoForXO(fiRequest, notificationInfo, flowOperation);
                break;
            case INTERMEDIARY_BROKER_API:
                populateNotificationInfoForBAPIChannel(fiRequest, notificationInfo, flowOperation);
                break;
            case BRANCH:
            case INTERMEDIARY:
            case INTERMEDIARY_NAPOLI:
                populateNotificationInfoForBrokerChannel(fiRequest, notificationInfo, flowOperation);
                break;
            default:
                log.error("Invalid channel received for the caseId :{} referenceNumber:{}",fiRequest.getCaseId(),fiRequest.getReferenceNumber());
                throw new IllegalArgumentException(ApplicationConstant.APPLICATION_CHANNEL_IS_NOT_VALID +channel);
        }
        return notificationInfo;
    }

    private static void populateNotificationInfoForBrokerChannel(FIRequest fiRequest, NotificationInfo notificationInfo, FlowOperation flowOperation) {
        if (notificationInfo.isADBOCase()) {
            setCustomerNotificationTemplateForADBO(fiRequest, flowOperation, notificationInfo);
        } else {
            setCustomerNotificationTemplateForBrokerChannel(fiRequest, flowOperation, notificationInfo);
        }
    }

    private static void populateNotificationInfoForBAPIChannel(FIRequest fiRequest, NotificationInfo notificationInfo, FlowOperation flowOperation) {
        if (notificationInfo.isADBOCase()) {
            setCustomerNotificationTemplateForADBO(fiRequest, flowOperation, notificationInfo);
        } else {
            setCustomerNotificationTemplateForBAPIChannel(fiRequest, flowOperation, notificationInfo);
        }
    }

    private static void populateNotificationInfoForXO(FIRequest fiRequest, NotificationInfo notificationInfo, FlowOperation flowOperation) {
        if (notificationInfo.isADBOCase()) {
            setCustomerNotificationTemplateForADBO(fiRequest, flowOperation, notificationInfo);
        } else {
            setCustomerNotificationTemplateForXO(fiRequest, flowOperation, notificationInfo);
        }
    }

    private static void setCustomerNotificationTemplateForADBO(FIRequest fiRequest, FlowOperation flowOperation, NotificationInfo notificationInfo) {
        ApplicationUtil.setEmailForNoPackagingRequiredFlag(fiRequest, notificationInfo);
        switch (flowOperation) {
            case AV_SCAN_FAILURE_EVENT:
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT, GENERIC_AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case REQUIRED_DOCS:
                if(notificationInfo.isEmailForNoPackagingRequired()) {
                    setTemplateNameAndSubjectForNoPackagingRequired(notificationInfo, flowOperation);
                    break;
                }
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(EMAIL_TEMPLATE_SUBJECT, GENERIC_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case FI_REQUEST:
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(FYA_EMAIL_TEMPLATE_SUBJECT, GENERIC_FYA_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case CHASER:
            case AUTO_CHASER:
                if(notificationInfo.isEmailForNoPackagingRequired()) {
                    setTemplateNameAndSubjectForNoPackagingRequired(notificationInfo, flowOperation);
                    break;
                }
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(CHASER_EMAIL_TEMPLATE_SUBJECT, GENERIC_CHASER_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            default:
                log.error(ApplicationConstant.INVALID_FLOW_OPERATION_RECEIVED_FOR_THE_CASE_ID_REFERENCE_NUMBER,fiRequest.getCaseId(),fiRequest.getReferenceNumber());
                throw new IllegalArgumentException(ApplicationConstant.FLOW_OPERATION_IS_NOT_VALID +flowOperation);
        }
    }

    private static void setTemplateNameAndSubjectForNoPackagingRequired(NotificationInfo notificationInfo, FlowOperation flowOperation) {
        notificationInfo.setTemplateName(NotificationTemplate.NO_PACKAGING_CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO.getTemplateName());
        notificationInfo.setEmailSubject(FlowOperation.CHASER.getOperationName().equals(flowOperation.getOperationName()) || FlowOperation.AUTO_CHASER.getOperationName().equals(flowOperation.getOperationName()) ?
                CHASER_EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT : EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT);
    }


    private static void setCustomerNotificationTemplateForXO(FIRequest fiRequest, FlowOperation flowOperation, NotificationInfo notificationInfo) {
        switch (flowOperation) {
            case AV_SCAN_FAILURE_EVENT:
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE_FOR_XO.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT, GENERIC_AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case REQUIRED_DOCS:
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_XO.getTemplateName());
                notificationInfo.setEmailSubject(GENERIC_EMAIL_TEMPLATE_SUBJECT);
                break;
            case FI_REQUEST:
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_FYA_NOTIFICATION_TEMPLATE_FOR_XO.getTemplateName());
                notificationInfo.setEmailSubject(XO_GENERIC_FYA_EMAIL_TEMPLATE_SUBJECT);
                break;
            case CHASER:
            case AUTO_CHASER:
                notificationInfo.setTemplateName(NotificationTemplate.CUSTOMER_CHASER_NOTIFICATION_TEMPLATE_FOR_XO.getTemplateName());
                notificationInfo.setEmailSubject(XO_GENERIC_CHASER_EMAIL_TEMPLATE_SUBJECT);
                break;
            default:
                log.error(ApplicationConstant.INVALID_FLOW_OPERATION_RECEIVED_FOR_THE_CASE_ID_REFERENCE_NUMBER,fiRequest.getCaseId(),fiRequest.getReferenceNumber());
                throw new IllegalArgumentException(ApplicationConstant.FLOW_OPERATION_IS_NOT_VALID +flowOperation);
        }
    }

    private static void setCustomerNotificationTemplateForBrokerChannel(FIRequest fiRequest, FlowOperation flowOperation, NotificationInfo notificationInfo) {
        switch (flowOperation) {
            case AV_SCAN_FAILURE_EVENT:
                notificationInfo.setTemplateName(NotificationTemplate.BROKER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case REQUIRED_DOCS:
                notificationInfo.setTemplateName(NotificationTemplate.BROKER_WELCOME_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(EMAIL_TEMPLATE_SUBJECT, GENERIC_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case FI_REQUEST:
                notificationInfo.setTemplateName(NotificationTemplate.BROKER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(FYA_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case CHASER:
            case AUTO_CHASER:
                notificationInfo.setTemplateName(NotificationTemplate.BROKER_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(CHASER_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case EMAIL_LAPSE:
                notificationInfo.setTemplateName(NotificationTemplate.BROKER_LAPSE_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(CHASER_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            default:
                log.error(ApplicationConstant.INVALID_FLOW_OPERATION_RECEIVED_FOR_THE_CASE_ID_REFERENCE_NUMBER,fiRequest.getCaseId(),fiRequest.getReferenceNumber());
                throw new IllegalArgumentException(ApplicationConstant.FLOW_OPERATION_IS_NOT_VALID +flowOperation);
        }
    }

    private static void setCustomerNotificationTemplateForBAPIChannel(FIRequest fiRequest, FlowOperation flowOperation, NotificationInfo notificationInfo) {
        switch (flowOperation) {
            case AV_SCAN_FAILURE_EVENT:
                notificationInfo.setTemplateName(NotificationTemplate.BAPI_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case REQUIRED_DOCS:
                notificationInfo.setTemplateName(NotificationTemplate.BAPI_WELCOME_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(EMAIL_TEMPLATE_SUBJECT, GENERIC_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case FI_REQUEST:
                notificationInfo.setTemplateName(NotificationTemplate.BAPI_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(FYA_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            case CHASER:
            case AUTO_CHASER:
                notificationInfo.setTemplateName(NotificationTemplate.BAPI_FYA_NOTIFICATION_TEMPLATE.getTemplateName());
                notificationInfo.setEmailSubject(prepareSubject(CHASER_EMAIL_TEMPLATE_SUBJECT, fiRequest.getReferenceNumber()));
                break;
            default:
                log.error(ApplicationConstant.INVALID_FLOW_OPERATION_RECEIVED_FOR_THE_CASE_ID_REFERENCE_NUMBER,fiRequest.getCaseId(),fiRequest.getReferenceNumber());
                throw new IllegalArgumentException(ApplicationConstant.FLOW_OPERATION_IS_NOT_VALID +flowOperation);
        }
    }

}
