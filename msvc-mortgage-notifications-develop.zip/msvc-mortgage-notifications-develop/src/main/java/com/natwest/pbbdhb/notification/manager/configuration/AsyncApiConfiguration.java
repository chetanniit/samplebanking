package com.natwest.pbbdhb.notification.manager.configuration;

import com.asyncapi.v2.binding.kafka.KafkaOperationBinding;
import com.asyncapi.v2.model.info.Info;
import com.asyncapi.v2.model.server.Server;
import com.google.common.collect.ImmutableMap;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import com.natwest.pbbdhb.notification.manager.util.KafkaConfigReader;
import io.github.stavshamir.springwolf.asyncapi.types.ProducerData;
import io.github.stavshamir.springwolf.asyncapi.types.channel.operation.message.header.AsyncHeaders;
import io.github.stavshamir.springwolf.configuration.AsyncApiDocket;
import io.github.stavshamir.springwolf.configuration.EnableAsyncApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableAsyncApi
@Slf4j
public class AsyncApiConfiguration {

    public static final String KAFKA = "kafka";
    public static final ImmutableMap<String, KafkaOperationBinding> KAFKA_BINDING = ImmutableMap.of(KAFKA, new KafkaOperationBinding());
    private final BuildProperties buildProperties;
    private final String bootStrapServers;
    private final KafkaConfigReader configReader;

    public AsyncApiConfiguration(BuildProperties buildProperties,
                                 @Value("${kafka.bootstrapServers}") String bootStrapServers,
                                 KafkaConfigReader configReader) {
        if (null == buildProperties) {
            log.error("buildProperties are missing. check the build");
        }
        this.buildProperties = buildProperties;
        this.bootStrapServers = bootStrapServers;
        this.configReader = configReader;
    }

    @Bean
    public AsyncApiDocket asyncApiDocket() {
        Info info = Info.builder()
                .description("msvc-mortgage-notifications microservice pulls the data out of GMS " +
                        "and creates events for the new system to react to the GMS application changes")
                .version(buildProperties.getVersion())
                .title(buildProperties.getArtifact())
                .build();

        Server kafkaServer = Server.builder()
                .protocol(KAFKA)
                .url(bootStrapServers)
                .build();

        return AsyncApiDocket.builder()
                .basePackage("com.natwest.pbbdhb.notification.manager.consumer")
                .info(info)
                .server(KAFKA, kafkaServer)
                .producers(getProducers())
                .build();
    }

    private List<ProducerData> getProducers() {
        ProducerData brokerNotificationRetryProducer = ProducerData.builder()
                .channelName(configReader.getBrokerNotificationRetryTopic())
                .description("sending gms broker notification retry messages")
                .operationBinding(KAFKA_BINDING)
                .payloadType(FIRequest.class)
                .headers(AsyncHeaders.NOT_USED)
                .build();
        ProducerData brokerNotificationErrorProducer = ProducerData.builder()
                .channelName(configReader.getBrokerNotificationErrorTopic())
                .description("sending gms broker notification error messages")
                .operationBinding(KAFKA_BINDING)
                .payloadType(FIRequest.class)
                .headers(AsyncHeaders.NOT_USED)
                .build();
        ProducerData customerNotificationRetryProducer = ProducerData.builder()
                .channelName(configReader.getCustomerNotificationRetryTopic())
                .description("sending gms customer notification retry messages")
                .operationBinding(KAFKA_BINDING)
                .payloadType(FIRequest.class)
                .headers(AsyncHeaders.NOT_USED)
                .build();
        ProducerData customerNotificationErrorProducer = ProducerData.builder()
                .channelName(configReader.getCustomerNotificationErrorTopic())
                .description("sending gms customer notification error messages")
                .operationBinding(KAFKA_BINDING)
                .payloadType(FIRequest.class)
                .headers(AsyncHeaders.NOT_USED)
                .build();
        List<ProducerData> producers = new ArrayList<>();
        producers.add(brokerNotificationRetryProducer);
        producers.add(brokerNotificationErrorProducer);
        producers.add(customerNotificationRetryProducer);
        producers.add(customerNotificationErrorProducer);
        return producers;
    }
}
