package com.natwest.pbbdhb.notification.manager.controller;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.service.MortgageNotificationsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.INVALID_BRAND;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.VALID_BRANDS;

/**
 * This class works as a controller contains all the endPoint related to mortgage notification
 */
@RestController
@Tag(name = "Mortgage Notification", description = "Mortgage Notification API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class MortgageNotificationController {

    private final MortgageNotificationsService mortgageNotificationsService;
    /**
     * This endpoint will take EmailRequest as input and send email
     * @param brand - allowed values NWB/RBS
     * @param request - EmailRequest
     * @param validationErrors - Validation errors
     * @return String
     */
    @Operation(summary  = "Search Applications for Broker", description = "Search Applications By Broker Information")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Ok",
                    content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request"),
            @ApiResponse(responseCode = "404", description = "No record found"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping(path = "/sendEmail")
    public ResponseEntity<String> sendEmail(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @RequestBody @NotNull EmailRequest request, BindingResult validationErrors){
        log.info("sendEmail method entered in MortgageNotificationController class with brand: {}", brand);
        ResponseEntity<String> response = mortgageNotificationsService.sendEmail(brand, request);
        log.info("email request is complete");
        return response;
    }
}
