package com.natwest.pbbdhb.notification.manager.model.request;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * FIRequest class is the request for requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Task Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class FIRequest {

    private String brand;

    private String referenceNumber;

    private String sequenceNumber;

    private String caseId;

    private String requestId;

    private String userFullName;

    private String userRACFId;

    @Builder.Default
    private List<Document> documentRequests = new ArrayList<>();

    private List<ApplicantInformation> applicants;

    private BrokerInformation brokerInfo;

    private String notificationTemplateName;

    private String operation;

    private String channel;

    private String loanPurpose;
}
