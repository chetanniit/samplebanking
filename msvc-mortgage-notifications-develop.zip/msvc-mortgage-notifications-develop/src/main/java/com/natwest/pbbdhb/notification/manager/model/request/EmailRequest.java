package com.natwest.pbbdhb.notification.manager.model.request;



import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * Class is used as a request for email service
 */
@Data
@Schema(description = "Email Body Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class EmailRequest {

    @Parameter(required = true, description = "notificationType")
    @NotNull(message = "notificationType")
    private String notificationType;

    @Valid
    @Parameter(required = true, description = "Email Parameters")
    @NotNull(message = "parameters")
    private Map<String, Object> parameters;

}
