package com.natwest.pbbdhb.notification.manager.util;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "kafka")
@Getter
@Setter
public class KafkaConfigReader {
    private String brokerGroupId;
    private String customerGroupId;
    private String bootstrapServers;
    private String brokerTopicName;
    private String customerTopicName;
    private String clientId;
    private String acknowledgment;
    private String securityProtocol;
    private String sslKeystoreLocation;
    private String sslKeystorePassword;
    private String brokerNotificationErrorTopic;
    private String brokerNotificationRetryTopic;
    private String customerNotificationErrorTopic;
    private String customerNotificationRetryTopic;
    private String brokerNotificationRetryGroupId;
    private String customerNotificationRetryGroupId;
    private String retryAttempts;
    private String idleBetweenPolls;
}
