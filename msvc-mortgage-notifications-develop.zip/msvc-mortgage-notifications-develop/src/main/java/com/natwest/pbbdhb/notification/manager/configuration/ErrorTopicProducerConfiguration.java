package com.natwest.pbbdhb.notification.manager.configuration;

import com.natwest.pbbdhb.notification.manager.serializer.NotificationErrorRequestSerializer;
import com.natwest.pbbdhb.notification.manager.util.KafkaConfigReader;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.*;

@Configuration
@Slf4j
@ConditionalOnExpression("${msvc.notifications.kafka.producer.enabled:true}")
public class ErrorTopicProducerConfiguration {

    @Autowired
    private KafkaConfigReader config;
    /**
     * KafkaTemplate to produce message to notification retry topic
     * @return KafkaTemplate
     */
    @Bean
    public KafkaTemplate<String, Object> notificationErrorKafkaTemplate() {
        return new KafkaTemplate<>(this.notificationErrorProducerFactory());
    }

    /**
     * ProducerFactory to produce message to notification retry topic
     * @return ProducerFactory
     */
    @Bean
    public ProducerFactory<String, Object> notificationErrorProducerFactory() {
        final Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapServers());
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, NotificationErrorRequestSerializer.class);
        configProps.put(ProducerConfig.ACKS_CONFIG, "-1");
        configProps.put(ProducerConfig.CLIENT_ID_CONFIG, config.getClientId());
        configProps.put(SECURITY_PROTOCOL, config.getSecurityProtocol());
        configProps.put(SSL_KEYSTORE_LOCATION, config.getSslKeystoreLocation());
        configProps.put(SSL_KEYSTORE_PD, config.getSslKeystorePassword());
        return new DefaultKafkaProducerFactory<>(configProps);
    }
}
