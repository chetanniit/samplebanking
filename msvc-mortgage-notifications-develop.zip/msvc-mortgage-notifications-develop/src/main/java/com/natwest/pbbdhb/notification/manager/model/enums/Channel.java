package com.natwest.pbbdhb.notification.manager.model.enums;

import lombok.AllArgsConstructor;

/**
 * Enum class which has list of channel information
 */
@AllArgsConstructor
public enum Channel {
    INTERMEDIARY_BROKER_API,
    INTERMEDIARY,
    BRANCH,
    INTERNET,
    INTERMEDIARY_NAPOLI,
    DEFAULT
}