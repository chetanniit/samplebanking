package com.natwest.pbbdhb.notification.manager;

import com.natwest.pbbdhb.notification.manager.util.ErrorMessageConfigReader;
import com.natwest.pbbdhb.notification.manager.util.KafkaConfigReader;
import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication(scanBasePackageClasses = {MortgageNotificationsApplication.class})
@EnableConfigurationProperties({ErrorMessageConfigReader.class, KafkaConfigReader.class})
public class MortgageNotificationsApplication {


    public static void main(String[] args) {

        new SpringApplicationBuilder().environment(new StandardEncryptableEnvironment()).sources(MortgageNotificationsApplication.class).run(args);
    }
}
