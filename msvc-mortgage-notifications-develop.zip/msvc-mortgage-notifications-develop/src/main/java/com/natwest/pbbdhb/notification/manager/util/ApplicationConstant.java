package com.natwest.pbbdhb.notification.manager.util;

public class ApplicationConstant {

    public static final String BROKER_NOTIFICATION_SUCCESS = "Broker notification sent successfully";
    public static final String CUSTOMER_NOTIFICATION_SUCCESS = "Customer notification sent successfully";

    public static final String INVALID_SENDER_EMAIL = "sender email id";
    public static final String INVALID_RECEIVER_EMAIL = "receiver email id";

    public static final String CSP_VALUE = "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self' data: http://www.w3.org/; font-src 'self'; style-src 'self' 'unsafe-inline';base-uri 'self';form-action 'self'";
    public static final String NO_CACHE = "no-cache";
    public static final String VALID_BRANDS = "(RBS|NWB|rbs|nwb)";
    public static final String INVALID_BRAND = "brand name";

    public static final String SUBJECT = "subject";
    public static final String NWB_BRAND = "nwb";
    public static final String URL = "www.google.com";
    public static final String PACKING_REQUEST_URL = "packingRequirementsURL";
    public static final String MORTGAGE_TRACKER_URL = "mortgageTrackerURL";
    public static final String DASHBOARD_LINK = "dashboardLink";
    public static final String CATEGORY = "category";
    public static final String REFERENCE_NUMBER = "referenceNumber";
    public static final String BROKER_FULL_NAME = "brokerFullName";
    public static final String TO_RECIPIENTS = "toRecipients";
    public static final String APPLICANT_FULL_NAME = "applicantFullName";
    public static final String FIRST_NAME = "firstname";
    public static final String JOINT_APPLICANT_FULL_NAME = "jointApplicantFullName";
    public static final String DOCUMENTS = "documents";
    public static final String DOCUMENT_INFO = "documentInfo";
    public static final String PREVIOUS_MILESTONE_NAME = "previousMilestoneName";
    public static final String NEW_MILESTONE_NAME = "newMilestoneName";
    public static final String OFFER_STARTS = "offerStarts";
    public static final String COMPLETION_STARTS = "completionStarts";
    public static final String OFFER_DATE = "22-03-2022";
    public static final String COMPLETION_DATE = "29-03-2022";
    public static final String COMPLETION = "Completion";
    public static final String OFFER = "Offer";
    public static final String FYA_EMAIL_TEMPLATE_SUBJECT = "Action Required for {0}";
    public static final String EMAIL_TEMPLATE_SUBJECT = "Case update for {0}";
    public static final String CHASER_EMAIL_TEMPLATE_SUBJECT = "Reminder | Action Required for {0}";
    public static final String AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT = "Document upload failed for {0}";
    public static final String GENERIC_AVSCAN_FAILURE_EMAIL_TEMPLATE_SUBJECT = "Document upload failed";
    public static final String GENERIC_FYA_EMAIL_TEMPLATE_SUBJECT = "Action required for your mortgage application";
    public static final String GENERIC_CHASER_EMAIL_TEMPLATE_SUBJECT = "Reminder | Action required for your mortgage application";
    public static final String XO_GENERIC_FYA_EMAIL_TEMPLATE_SUBJECT = "We need some more information";
    public static final String XO_GENERIC_CHASER_EMAIL_TEMPLATE_SUBJECT = "Reminder: We need some more information";
    public static final String GENERIC_EMAIL_TEMPLATE_SUBJECT = "Case update for your mortgage application";
    public static final String EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT = "Agree to your mortgage application";
    public static final String CHASER_EMAIL_TEMPLATE_SUBJECT_FOR_NO_PACKAGING_REQUIREMENT = "Reminder: Agree to your mortgage application";

    public static final String SECURITY_PROTOCOL = "security.protocol";
    public static final String SSL_KEYSTORE_LOCATION = "ssl.keystore.location";
    public static final String SSL_KEYSTORE_PD = "ssl.keystore.password";
    public static final String SSL_ALGORITHM = "ssl.endpoint.identification.algorithm";
    public static final String ERROR_MESSAGE = "Error occurred while processing the request for reference number - {0}, sequence number - {1}";

    public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_DD_MM_YYYY = "dd-MM-yyyy";
    public static final String DELIMITER_COMMA_WITH_SPACE = ", ";
    public static final String DELIMITER_AMPERSAND_WITH_SPACE = " & ";
    public static final String DELIMITER_HYPHEN_WITH_SPACE = " - ";

    public static final String CUSTOM_TIME_PERIOD = "{0} to {1}";
    public static final String YYYY_MM_DD_DATE = "yyyy-MM-dd";
    public static final String DD_MM_YYYY_DATE = "dd/MM/yyyy";

    public static final String XO_CHANNEL = "INTERNET";
    public static final String ADDITIONAL_BORROWING = "ADDITIONAL_BORROWING";
    public static final String APPLICATION_CHANNEL_IS_NOT_VALID = "Application channel is not valid:";
    public static final String FLOW_OPERATION_IS_NOT_VALID = "Flow operation is not valid:";
    public static final String INVALID_FLOW_OPERATION_RECEIVED_FOR_THE_CASE_ID_REFERENCE_NUMBER = "Invalid flowOperation received for the caseId :{} referenceNumber:{}";

    private ApplicationConstant() {
    }
}
