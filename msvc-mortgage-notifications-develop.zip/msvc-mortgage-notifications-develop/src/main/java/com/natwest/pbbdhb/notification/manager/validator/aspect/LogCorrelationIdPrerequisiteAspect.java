package com.natwest.pbbdhb.notification.manager.validator.aspect;

import java.util.UUID;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.rbs.dws.correlation.RequestCorrelationIdContext;
import com.rbs.dws.server.tomcat.valve.RequestCorrelationIdValve;

/**
 * Aspect to add correlation id in context to get it printed in the logger
 */
@Aspect
@Component
public class LogCorrelationIdPrerequisiteAspect {
	
	public static final String DWS_CORRELATION_ID = "dws-correlation-id";
	
    @Before("@annotation(com.natwest.pbbdhb.notification.manager.validator.aspect.LogCorrelationIdPrerequisite)")
    public void populateCorrelationId() {
        String randomCorrelationId = UUID.randomUUID().toString();
        RequestCorrelationIdContext.set(RequestCorrelationIdValve.REQUEST_CORRELATION_ID_MDC_KEY, randomCorrelationId);
        RequestCorrelationIdContext.set(RequestCorrelationIdValve.REQUEST_INTERNAL_CORRELATION_ID_MDC_KEY, randomCorrelationId);
        RequestCorrelationIdContext.set(DWS_CORRELATION_ID, randomCorrelationId);
        MDC.put(RequestCorrelationIdValve.REQUEST_CORRELATION_ID_MDC_KEY, randomCorrelationId);
        MDC.put(RequestCorrelationIdValve.REQUEST_INTERNAL_CORRELATION_ID_MDC_KEY, randomCorrelationId);
    }
}
