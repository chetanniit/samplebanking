package com.natwest.pbbdhb.notification.manager.consumer;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.APPLICANT_FULL_NAME;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.BROKER_FULL_NAME;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.COMPLETION;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.COMPLETION_DATE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.COMPLETION_STARTS;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DELIMITER_COMMA_WITH_SPACE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DELIMITER_HYPHEN_WITH_SPACE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DOCUMENTS;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.JOINT_APPLICANT_FULL_NAME;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.MORTGAGE_TRACKER_URL;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.NEW_MILESTONE_NAME;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.NWB_BRAND;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.OFFER;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.OFFER_DATE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.OFFER_STARTS;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.PACKING_REQUEST_URL;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.PREVIOUS_MILESTONE_NAME;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.REFERENCE_NUMBER;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.SUBJECT;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.TO_RECIPIENTS;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.URL;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormat;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormatForRequestedDate;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.getFullName;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.getTimePeriodByFromDateAndToDate;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.isChaserEvent;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.populateApplicantAndAvScanFailedDocDetails;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.email.Documents;
import com.natwest.pbbdhb.notification.manager.model.email.NotificationInfo;
import com.natwest.pbbdhb.notification.manager.model.enums.FlowOperation;
import com.natwest.pbbdhb.notification.manager.model.request.ApplicantInformation;
import com.natwest.pbbdhb.notification.manager.model.request.Document;
import com.natwest.pbbdhb.notification.manager.model.request.DocumentFor;
import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import com.natwest.pbbdhb.notification.manager.service.EmailService;
import com.natwest.pbbdhb.notification.manager.util.NotificationTemplateUtil;
import com.natwest.pbbdhb.notification.manager.validator.aspect.LogCorrelationIdPrerequisite;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BrokerNotificationConsumerService {

    @Autowired
    private EmailService emailService;

    @Value("${notification.mortgage.tracker.url:}")
    private String mortgageTrackerUrl;
    
    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Kafka listener to consume the message from broker notification topic
     *
     * @param fiRequest      - fiRequest
     * @param offset         - offset
     * @param topic          - topic
     * @param partition      - partition
     * @param acknowledgment - acknowledgment
     */
    @LogCorrelationIdPrerequisite
    @KafkaListener(topics = "#{'${kafka.brokerTopicName}'}", groupId = "#{'${kafka.brokerGroupId}'}",
            containerFactory = "brokerListenerContainerFactory", autoStartup = "${msvc.notifications.kafka.consumer.enabled:true}")
    public void listener(@Payload String request, @Header(KafkaHeaders.OFFSET) int offset, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, Acknowledgment acknowledgment) {
        acknowledgment.acknowledge();
        log.info("Listening message from topic  : {} and partition : {} and offset: {}", topic, partition, offset);
        
		try {
			
			FIRequest fiRequest = objectMapper.readValue(request, FIRequest.class);
			
			log.info("Trying to Acknowledge :{} ", request);
			
			emailNotification(fiRequest);
			
		} catch (JsonProcessingException e) {
			log.error("Error in serializing the request into Object: {}", request);
		}
        
        
    }

    /**
     * Kafka listener to consume the message from broker notification retry topic
     *
     * @param fiRequest      - fiRequest
     * @param offset         - offset
     * @param topic          - topic
     * @param partition      - partition
     * @param acknowledgment - acknowledgment
     */
    @LogCorrelationIdPrerequisite
    @KafkaListener(topics = "#{'${kafka.brokerNotificationRetryTopic}'}", groupId = "#{'${kafka.brokerNotificationRetryGroupId}'}",
            containerFactory = "brokerRetryListenerContainerFactory", autoStartup = "${msvc.notifications.kafka.consumer.enabled:true}")
    public void retry(@Payload String request, @Header(KafkaHeaders.OFFSET) int offset,
                      @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
                      Acknowledgment acknowledgment) {
        acknowledgment.acknowledge();
        log.info("Listening message from retry topic  : {} and partition : {} and offset: {}", topic, partition, offset);
        try {
			
			FIRequest fiRequest = objectMapper.readValue(request, FIRequest.class);
			
			log.info("Trying to Acknowledge :{} ", request);
			
			emailNotification(fiRequest);
			
		} catch (JsonProcessingException e) {
			log.error("Error in serializing the request into Object: {}", request);
		}
    }

    private void emailNotification(FIRequest fiRequest) {
        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        FlowOperation flowOperation = FlowOperation.findByValue(fiRequest.getOperation());
        switch (flowOperation) {
            case AV_SCAN_FAILURE_EVENT:
                sendBrokerAVScanFailureEmail(fiRequest, notificationInfo);
                break;
            case FI_REQUEST:
            case CHASER:
            case EMAIL_LAPSE:
            case AUTO_CHASER:
            case REQUIRED_DOCS:
                emailService.sendEmail(NWB_BRAND, populateBrokerFYATemplate(fiRequest, notificationInfo));
                break;
            default:
                emailService.sendEmail(NWB_BRAND, populateBrokerFYITemplate(fiRequest, notificationInfo));
        }
    }

    private void sendBrokerAVScanFailureEmail(FIRequest fiRequest, NotificationInfo notificationInfo) {
        EmailRequest request = EmailRequest.builder().notificationType(notificationInfo.getTemplateName()).build();
        Map<String, Object> emailParameter = new HashMap<>();
        emailParameter.put(SUBJECT, notificationInfo.getEmailSubject());
        emailParameter.put(MORTGAGE_TRACKER_URL, mortgageTrackerUrl);
        setBrokerInfo(fiRequest, emailParameter);
        populateApplicantAndAvScanFailedDocDetails(emailParameter, fiRequest.getDocumentRequests());
        request.setParameters(emailParameter);
        log.debug("populateBrokerAVScanFailureTemplate emailRequest : {}", request);
        emailService.sendEmail(NWB_BRAND, request);
    }

    private EmailRequest populateBrokerFYITemplate(FIRequest fiRequest, NotificationInfo notificationInfo) {
        EmailRequest request = EmailRequest.builder().notificationType(notificationInfo.getTemplateName()).build();
        Map<String, Object> emailParameter = new HashMap<>();
        emailParameter.put(SUBJECT, notificationInfo.getEmailSubject());
        emailParameter.put(PACKING_REQUEST_URL, URL);
        emailParameter.put(MORTGAGE_TRACKER_URL, URL);
        setBrokerInfo(fiRequest, emailParameter);
        setApplicantInfo(fiRequest, emailParameter);
        setMilestone(emailParameter);
        request.setParameters(emailParameter);
        log.debug("populateBrokerFYITemplate emailRequest : {}", request);
        return request;
    }

    private EmailRequest populateBrokerFYATemplate(FIRequest fiRequest, NotificationInfo notificationInfo) {
        EmailRequest request = EmailRequest.builder().notificationType(notificationInfo.getTemplateName()).build();
        Map<String, Object> emailParameter = new HashMap<>();
        emailParameter.put(MORTGAGE_TRACKER_URL, mortgageTrackerUrl);
        emailParameter.put(SUBJECT, notificationInfo.getEmailSubject());
        emailParameter.put(REFERENCE_NUMBER,
                StringUtils.isNotEmpty(fiRequest.getReferenceNumber())?
                        fiRequest.getReferenceNumber():
                        fiRequest.getCaseId());
        setBrokerInfo(fiRequest, emailParameter);
        setApplicantInfo(fiRequest, emailParameter);
        setDocumentDetails(fiRequest, emailParameter);
        request.setParameters(emailParameter);
        log.debug("populateBrokerFYATemplate emailRequest : {}", request);
        return request;
    }

    private void setBrokerInfo(FIRequest fiRequest, Map<String, Object> emailParameter) {
        Optional.ofNullable(fiRequest.getBrokerInfo()).ifPresent(brokerInfo -> {
            emailParameter.put(BROKER_FULL_NAME, brokerInfo.getFullName());
            emailParameter.put(TO_RECIPIENTS, brokerInfo.getEmailAddress());
        });
    }

    private void setApplicantInfo(FIRequest fiRequest, Map<String, Object> emailParameter) {
        if (CollectionUtils.isEmpty(fiRequest.getApplicants())) {
            return;
        }
        ApplicantInformation applicant = fiRequest.getApplicants().get(0);
        emailParameter.put(APPLICANT_FULL_NAME, getFullName(applicant));
        if (fiRequest.getApplicants().size() > 1) {
            ApplicantInformation jointApplicant = fiRequest.getApplicants().get(1);
            emailParameter.put(JOINT_APPLICANT_FULL_NAME, getFullName(jointApplicant));
        }
    }

    private void setDocumentDetails(FIRequest fiRequest, Map<String, Object> emailParameter) {
        List<Documents> documents = new ArrayList<>();
        Map<String, String> applicantDetailsMap = populateApplicantIdAndApplicantFullName(fiRequest);

        if (isChaserEvent(fiRequest)) {
            fiRequest.getDocumentRequests().sort(Comparator.comparing(Document::getRequestedDate));
        }

        Optional.ofNullable(fiRequest.getDocumentRequests()).orElseGet(Collections::emptyList).forEach(doc -> {

            String purpose = CollectionUtils.isNotEmpty(doc.getPurpose())
                    ? StringUtils.join(doc.getPurpose(), DELIMITER_COMMA_WITH_SPACE) : null;
            String category = Stream.of(doc.getCategory(), purpose).filter(Objects::nonNull)
                    .collect(Collectors.joining(DELIMITER_HYPHEN_WITH_SPACE));

            Documents document = new Documents();
            document.setFromDate(convertDateFormat(doc.getFromDate()));
            document.setToDate(convertDateFormat(doc.getToDate()));
            document.setTimePeriod(Optional.ofNullable(doc.getTimePeriod()).orElse(getTimePeriodByFromDateAndToDate(doc)));
            document.setCategory(category);
            document.setReRequestReason(StringUtils.join(doc.getReRequestReason(), DELIMITER_COMMA_WITH_SPACE));
            if(CollectionUtils.isEmpty(doc.getRequiredFor())){
                document.setDocumentFor(null);
            }else{
                document.setDocumentFor(doc.getRequiredFor().stream()
                        .map(DocumentFor::getApplicantId)
                        .map(applicantDetailsMap::get)
                        .collect(Collectors.joining(DELIMITER_COMMA_WITH_SPACE)));
            }
            document.setDocumentPurpose(purpose);
            document.setDueDate(convertDateFormat(doc.getDueDate()));
            document.setRequestedDate(isChaserEvent(fiRequest) ? convertDateFormatForRequestedDate(doc.getRequestedDate()) : null);
            documents.add(document);
        });
        emailParameter.put(DOCUMENTS, documents);
    }

    private Map<String, String> populateApplicantIdAndApplicantFullName(FIRequest fiRequest) {
        Map<String, String> applicantDetails = new HashMap<>();
        Optional.ofNullable(fiRequest).map(FIRequest::getApplicants).orElseGet(Collections::emptyList)
                .forEach(applicant -> applicantDetails.put(applicant.getApplicantId(), getFullName(applicant)));
        return applicantDetails;
    }

    private void setMilestone(Map<String, Object> emailParameter) {
        emailParameter.put(PREVIOUS_MILESTONE_NAME, OFFER);
        emailParameter.put(NEW_MILESTONE_NAME, COMPLETION);
        emailParameter.put(OFFER_STARTS, OFFER_DATE);
        emailParameter.put(COMPLETION_STARTS, COMPLETION_DATE);
    }
}
