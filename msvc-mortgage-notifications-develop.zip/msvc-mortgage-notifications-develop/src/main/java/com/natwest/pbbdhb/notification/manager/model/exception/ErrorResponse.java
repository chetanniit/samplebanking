package com.natwest.pbbdhb.notification.manager.model.exception;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Setter;
import lombok.Getter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.util.Date;
import java.util.List;

/**
 * Model object to map the values to return error details
 */
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Builder
@Setter
@Getter
@ToString
public class ErrorResponse {
    private int responseCode;
    private HttpStatus responseStatus;
    private List<String> errorMessages;
    private Date timeStamp;
}
