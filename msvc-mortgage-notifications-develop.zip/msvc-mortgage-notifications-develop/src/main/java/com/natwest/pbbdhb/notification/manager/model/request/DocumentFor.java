package com.natwest.pbbdhb.notification.manager.model.request;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DocumentFor class is the used as request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add DocumentFor Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocumentFor {

    private String applicantId;

    private String applicantName;
}
