package com.natwest.pbbdhb.notification.manager.model.request;


import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;


/**
 * Class is used as a request for email service
 */
@Data
@Schema(description = "Email Parameters")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class EmailParameter {

    @Valid
    @Parameter(description= "Title")
    private String title;

    @Valid
    @Parameter(required = true, description= "First Name")
    @NotNull(message = "First Name")
    private String firstName;

    @Valid
    @Parameter(required = true, description= "Last Name")
    @NotNull(message = "Last Name")
    private String lastName;

    @Valid
    @Parameter(required = true, description= "referenceNumber")
    @NotNull(message = "Reference Number")
    private String referenceNumber;

    @Valid
    @Parameter(required = true, description= "documentType")
    @NotNull(message = "Document Type")
    private String documentType;

    @Valid
    @Parameter(required = true, description= "Reason Code")
    @NotNull(message = "Reason Code")
    private String reasonCode;

    @Valid
    @Parameter(description= "Due Date")
    private String dueDate;

    @Valid
    @Parameter(description= "Time Period")
    private String timePeriod;

    @Valid
    @Parameter(required = true, description= "url")
    @NotNull(message = "url")
    private String url;

    @Valid
    @Parameter(required = true, description= "To Recipients")
    @NotNull(message = "To Recipients")
    private String toRecipients;

    @Valid
    @Parameter(description= "Cc Recipients")
    private String ccRecipients;

    @Valid
    @Parameter(description= "Bcc Recipients")
    private String bccRecipients;

    @Valid
    @Parameter(description= "subject")
    private String subject;

}
