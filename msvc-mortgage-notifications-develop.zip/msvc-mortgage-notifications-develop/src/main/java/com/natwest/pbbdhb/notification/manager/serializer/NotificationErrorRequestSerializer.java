package com.natwest.pbbdhb.notification.manager.serializer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.exception.NotificationErrorRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

@Slf4j
public class NotificationErrorRequestSerializer implements Serializer<NotificationErrorRequest> {


    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public byte[] serialize(String topic, NotificationErrorRequest notificationErrorRequest) {
        try {
            return objectMapper.writeValueAsBytes(notificationErrorRequest);
        }
        catch (JsonProcessingException e){
            log.info("Error occurred while serialization");
            return null;
        }

    }

}
