package com.natwest.pbbdhb.notification.manager.configuration;

import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import com.natwest.pbbdhb.notification.manager.util.KafkaConfigReader;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.*;
import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL_IMMEDIATE;
import static org.springframework.kafka.listener.adapter.RetryingMessageListenerAdapter.CONTEXT_RECORD;

@Configuration
@Slf4j
@ConditionalOnExpression("${msvc.notifications.kafka.consumer.enabled:true}")
public class CustomerNotificationConsumerConfiguration {

    @Autowired
    private KafkaConfigReader config;

    @Autowired
    KafkaTemplate<String, Object> notificationRetryKafkaTemplate;

    @Bean
    public ConsumerFactory<String, String> customerConsumerFactory() {
        final Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapServers());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, config.getCustomerGroupId());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class);
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, String.class);
        props.put(SECURITY_PROTOCOL, config.getSecurityProtocol());
        props.put(SSL_KEYSTORE_LOCATION, config.getSslKeystoreLocation());
        props.put(SSL_KEYSTORE_PD, config.getSslKeystorePassword());
        props.put(SSL_ALGORITHM, "");
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> customerListenerContainerFactory() {
        final ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(this.customerConsumerFactory());
        factory.getContainerProperties().setAckMode(MANUAL_IMMEDIATE);
        factory.setRetryTemplate(retryTemplate());
        factory.setRecoveryCallback((context -> {
            log.info("Done with retries and still issue exists. Posting the message to the customer notification retry topic");
            ConsumerRecord errorRecord = (ConsumerRecord) context.getAttribute(CONTEXT_RECORD);
            notificationRetryKafkaTemplate.send(config.getCustomerNotificationRetryTopic(), errorRecord.key().toString(),
                    errorRecord.value());
            return Optional.empty();
        }));
        return factory;
    }

    private RetryTemplate retryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();
        retryTemplate.setRetryPolicy(getSimpleRetryPolicy());
        return retryTemplate;
    }

    private SimpleRetryPolicy getSimpleRetryPolicy() {
        Map<Class<? extends Throwable>, Boolean> exceptionMap = new HashMap<>();
        exceptionMap.put(RuntimeException.class, true);
        return new SimpleRetryPolicy(Integer.parseInt(config.getRetryAttempts()), exceptionMap, true);
    }

}
