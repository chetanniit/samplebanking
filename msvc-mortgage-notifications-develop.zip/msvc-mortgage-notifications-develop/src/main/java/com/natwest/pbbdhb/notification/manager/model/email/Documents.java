package com.natwest.pbbdhb.notification.manager.model.email;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Document class is the used as request for /requestFI endpoint
 *
 */
@Data
@Schema(description = "Add Document Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Documents {

    private String documentFor;

    private String category;

    private String reRequestReason;

    private String documentPurpose;

    private String fromDate;

    private String toDate;

    private String timePeriod;

    private String dueDate;

    private String requestedDate;
}
