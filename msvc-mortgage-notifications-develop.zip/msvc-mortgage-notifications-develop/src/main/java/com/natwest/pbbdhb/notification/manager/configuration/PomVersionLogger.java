package com.natwest.pbbdhb.notification.manager.configuration;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.info.BuildProperties;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Slf4j
@Component
@AllArgsConstructor
public class PomVersionLogger implements CommandLineRunner {

    @Autowired
    private final BuildProperties buildProperties;

    @Override
    public void run(String... args) throws Exception {
        if (Objects.nonNull(buildProperties)) {
            log.info("Microservice Version: [{}], Started Successfully.", buildProperties.getVersion());
        }
    }
}
