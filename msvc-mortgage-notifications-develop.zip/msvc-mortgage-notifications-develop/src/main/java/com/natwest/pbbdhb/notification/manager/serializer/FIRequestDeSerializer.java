package com.natwest.pbbdhb.notification.manager.serializer;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Deserializer;

import java.io.IOException;
import java.util.Map;

@Slf4j
public class FIRequestDeSerializer implements Deserializer<FIRequest> {

    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public FIRequest deserialize(String topic, byte[] data) {
        log.info("Inside deserialize");
        try {
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return objectMapper.readValue(data,FIRequest.class);
        } catch (IOException e) {
            log.info("exception in deserialization");
            return null;
        }
    }
}
