package com.natwest.pbbdhb.notification.manager.util;

/**
 * This class has all the constants related to errors
 */
public class ErrorConstant {

    public static final String ERROR_CODE_400 = "400";
    private ErrorConstant() {}
}
