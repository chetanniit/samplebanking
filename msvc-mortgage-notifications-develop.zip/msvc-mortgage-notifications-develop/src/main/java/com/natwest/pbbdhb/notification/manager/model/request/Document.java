package com.natwest.pbbdhb.notification.manager.model.request;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Document class is the used as request for /requestFI endpoint
 *
 */
@Data
@Schema(description = "Add Document Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Document {

    private List<DocumentFor> requiredFor;

    private String documentIdentifier;

    private String category;

    private String documentName;

    private List<String> reRequestReason;

    private List<String> purpose;

    private String dueDate;

    private String fromDate;

    private String toDate;

    private String timePeriod;

    private String status;

    @Builder.Default
    private List<DocumentInfo> documentInfo = new ArrayList<>();

    private String requestedDate;

    private String chaseId;

    private String requestId;
}
