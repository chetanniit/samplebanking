package com.natwest.pbbdhb.notification.manager.model.email;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NotificationInfo information Object
 *
 */
@Data
@Schema(description = "Add notification information Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NotificationInfo {

    private String templateName;

    private String emailSubject;

    private boolean isADBOCase;

    @Builder.Default
    private boolean isEmailForNoPackagingRequired = false;

}
