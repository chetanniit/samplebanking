package com.natwest.pbbdhb.notification.manager.model.email;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.natwest.pbbdhb.notification.manager.model.request.DocumentInfo;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FailedDocInfo {
    private String category;
    private String originalFileName;
    private String requiredFor;
    private String errorMessage;
}
