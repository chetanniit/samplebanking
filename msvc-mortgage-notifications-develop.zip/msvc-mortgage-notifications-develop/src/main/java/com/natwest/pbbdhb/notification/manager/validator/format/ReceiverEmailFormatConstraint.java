package com.natwest.pbbdhb.notification.manager.validator.format;

import com.natwest.pbbdhb.notification.manager.validator.ReceiverEmailFormatValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.INVALID_RECEIVER_EMAIL;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = ReceiverEmailFormatValidator.class)
public @interface ReceiverEmailFormatConstraint {

    String message() default INVALID_RECEIVER_EMAIL;

    boolean required() default false;

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
