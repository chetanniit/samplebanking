package com.natwest.pbbdhb.notification.manager.model.request;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * BrokerInformation class is the request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Source Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BrokerInformation {

    private String fullName;

    private String firmName;

    private String emailAddress;

    private boolean notificationRequired;

    private String mobileNumber;
}
