package com.natwest.pbbdhb.notification.manager.util;

import com.natwest.pbbdhb.notification.manager.model.email.FailedDocInfo;
import com.natwest.pbbdhb.notification.manager.model.email.NotificationInfo;
import com.natwest.pbbdhb.notification.manager.model.enums.Channel;
import com.natwest.pbbdhb.notification.manager.model.enums.FlowOperation;
import com.natwest.pbbdhb.notification.manager.model.request.ApplicantInformation;
import com.natwest.pbbdhb.notification.manager.model.request.Document;
import com.natwest.pbbdhb.notification.manager.model.request.DocumentFor;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import javax.validation.constraints.NotNull;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Collections;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DATE_FORMAT_DD_MM_YYYY;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DATE_FORMAT_YYYY_MM_DD;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DOCUMENT_INFO;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DELIMITER_AMPERSAND_WITH_SPACE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DELIMITER_HYPHEN_WITH_SPACE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DELIMITER_COMMA_WITH_SPACE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.YYYY_MM_DD_DATE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.DD_MM_YYYY_DATE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.CUSTOM_TIME_PERIOD;

/**
 * This class has utility functions
 */
@Slf4j
public class ApplicationUtil {

    /**
     * Convert date string from yyyy-MM-dd to dd-MM-yyyy format
     *
     * @param dateString - dateString
     * @return formatted date string
     */
    public static String convertDateFormat(String dateString) {
        if (Objects.nonNull(dateString)) {
            try {
                SimpleDateFormat sdfSource = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
                Date date = sdfSource.parse(dateString);
                SimpleDateFormat sdfDestination = new SimpleDateFormat(DATE_FORMAT_DD_MM_YYYY);
                dateString = sdfDestination.format(date);
            } catch (ParseException ex) {
                log.error("Error occurred during date conversion: {}", ex.getMessage());
            }
        }
        return dateString;
    }

    /**
     * This method is used to prepare full name
     * @param applicant - applicant
     * @return full name
     */
    @NotNull
    public static String getFullName(ApplicantInformation applicant) {
        return Stream.of(applicant.getFirstName(), applicant.getLastName())
                .filter(Objects::nonNull)
                .collect(Collectors.joining(" "));
    }

    /**
     * This method is used to prepare full name with title for ADBO case.
     * @param fiRequest - fiRequest
     * @param applicant - applicant
     * @return full name with title for ADBO case else return full name.
     */
    @NotNull
    public static String getFullName(FIRequest fiRequest, ApplicantInformation applicant){
        if(ApplicationFunctions.isADBOCaseApplication.test(fiRequest)){
            return Stream.of(applicant.getTitle(), applicant.getFirstName(), applicant.getLastName())
                    .filter(Objects::nonNull)
                    .collect(Collectors.joining(" "));
        } else{
            return getFullName(applicant);
        }
    }

    /**
     * Method to populate broker av scan failure template details
     *
     * @param emailParameter   - emailParameter
     * @param documentRequests - documentRequests
     */
    public static void populateApplicantAndAvScanFailedDocDetails(Map<String, Object> emailParameter, List<Document> documentRequests) {
        List<FailedDocInfo> failedDocInfoList = new ArrayList<>();
        Optional.ofNullable(documentRequests).orElseGet(Collections::emptyList).forEach(docRequest -> getAVScanFailedDocsInfo(docRequest, failedDocInfoList));
        emailParameter.put(DOCUMENT_INFO, failedDocInfoList);
    }

    private static void getAVScanFailedDocsInfo(Document documentRequest, List<FailedDocInfo> failedDocInfoList) {
        String purpose = CollectionUtils.isNotEmpty(documentRequest.getPurpose())
                ? StringUtils.join(documentRequest.getPurpose(), DELIMITER_COMMA_WITH_SPACE) : null;
        String category = Stream.of(documentRequest.getCategory(), purpose).filter(Objects::nonNull)
                .collect(Collectors.joining(DELIMITER_HYPHEN_WITH_SPACE));
        String requiredFor = getApplicantsName(documentRequest.getRequiredFor());
        Optional.ofNullable(documentRequest.getDocumentInfo()).orElseGet(Collections::emptyList).forEach(docInfo ->
                failedDocInfoList.add(FailedDocInfo.builder()
                        .category(category).requiredFor(requiredFor)
                        .originalFileName(docInfo.getOriginalFileName())
                        .errorMessage(docInfo.getErrorMessage())
                        .build()));
    }

    private static String getApplicantsName(List<DocumentFor> requiredFor) {
        if(CollectionUtils.isEmpty(requiredFor)){
            return null;
        }
        String applicantName = requiredFor.get(0).getApplicantName();
        if(requiredFor.size() > 1){
            applicantName = Stream.of(applicantName, requiredFor.get(1).getApplicantName()).filter(Objects::nonNull)
                    .collect(Collectors.joining(DELIMITER_AMPERSAND_WITH_SPACE));
        }
        return applicantName;
    }

    /**
     * Method to convert yyyy-MM-dd to dd/MM/yyyy
     *
     * @param dateStr - date string
     * @return converted date string
     */
    public static String convertDateFormatForTimePeriod(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return null;
        }
        SimpleDateFormat format1 = new SimpleDateFormat(YYYY_MM_DD_DATE);
        SimpleDateFormat format2 = new SimpleDateFormat(DD_MM_YYYY_DATE);
        try {
            Date date = format1.parse(dateStr);
            return format2.format(date);
        } catch (ParseException e) {
            log.error("Exception occurred while parsing date : {}", dateStr);
            return null;
        }
    }

    public static String convertDateFormatForRequestedDate(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return null;
        }
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        SimpleDateFormat format2 = new SimpleDateFormat(DD_MM_YYYY_DATE);
        try {
            Date date = format1.parse(dateStr);
            return format2.format(date);
        } catch (ParseException e) {
            log.error("Exception occurred while parsing requestedDate : {}", dateStr);
            return null;
        }
    }

    public static boolean isChaserEvent(FIRequest fiRequest) {
        return FlowOperation.CHASER.getOperationName().equalsIgnoreCase(fiRequest.getOperation())
                || FlowOperation.AUTO_CHASER.getOperationName().equalsIgnoreCase(fiRequest.getOperation());
    }

    /**
     * Method to get time period using fromDate and toDate
     *
     * @param document - document
     * @return time period
     */
    public static String getTimePeriodByFromDateAndToDate(Document document) {
        if (Objects.isNull(document.getFromDate()) || Objects.isNull(document.getToDate())) {
            return null;
        }
        return MessageFormat.format(CUSTOM_TIME_PERIOD, convertDateFormatForTimePeriod(document.getFromDate()),
                convertDateFormatForTimePeriod(document.getToDate()));
    }

    public static String prepareSubject(String subject, String referenceNumber) {
        return MessageFormat.format(subject, referenceNumber);
    }

    public static String prepareSubject(String subject, String genericSubject, String referenceNumber) {
        return StringUtils.isBlank(referenceNumber) ? genericSubject : MessageFormat.format(subject, referenceNumber);
    }

    public static void setEmailForNoPackagingRequiredFlag(FIRequest fiRequest, NotificationInfo notificationInfo){
        if(Channel.INTERNET.name().equals(fiRequest.getChannel()) && notificationInfo.isADBOCase()
                && CollectionUtils.isEmpty(fiRequest.getDocumentRequests())) {
            notificationInfo.setEmailForNoPackagingRequired(true);
        }
    }

    private ApplicationUtil() {
    }
}
