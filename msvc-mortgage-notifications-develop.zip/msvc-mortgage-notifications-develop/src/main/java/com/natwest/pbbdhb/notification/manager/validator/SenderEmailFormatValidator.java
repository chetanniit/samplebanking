package com.natwest.pbbdhb.notification.manager.validator;

import com.natwest.pbbdhb.notification.manager.validator.format.SenderEmailFormatConstraint;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Objects;

public class SenderEmailFormatValidator implements ConstraintValidator<SenderEmailFormatConstraint, String> {

    private boolean isRequired;

    @Override
    public void initialize(SenderEmailFormatConstraint emailFormatConstraint) {
        this.isRequired = emailFormatConstraint.required();
    }

    @Override
    public boolean isValid(String email, ConstraintValidatorContext constraintValidatorContext) {
        if(isRequired && StringUtils.isEmpty(email)){
            return false;
        }
        return Objects.isNull(email) || EmailValidator.getInstance()
                .isValid(email);
    }

}
