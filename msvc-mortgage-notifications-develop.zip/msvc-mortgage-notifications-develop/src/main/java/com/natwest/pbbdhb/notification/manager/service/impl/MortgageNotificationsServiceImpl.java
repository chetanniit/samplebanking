package com.natwest.pbbdhb.notification.manager.service.impl;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.service.EmailService;
import com.natwest.pbbdhb.notification.manager.service.MortgageNotificationsService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class MortgageNotificationsServiceImpl implements MortgageNotificationsService {

    private EmailService emailService;


    /**
     * method is used to call Email service to send email
     * @param brand        - allowed values NWB/RBS
     * @param emailRequest - EmailRequest Object
     * @return - String
     */
    @Override
    public ResponseEntity<String> sendEmail(String brand, EmailRequest emailRequest) {
        return emailService.sendEmail(brand, emailRequest);
    }
}
