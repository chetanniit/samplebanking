package com.natwest.pbbdhb.notification.manager.service;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import org.springframework.http.ResponseEntity;

public interface MortgageNotificationsService {

    /**
     * method is used to call Email service to send email
     * @param brand - allowed values NWB/RBS
     * @param emailRequest - EmailRequest Object
     * @return - String
     */
    ResponseEntity<String> sendEmail(String brand, EmailRequest emailRequest);
}
