package com.natwest.pbbdhb.notification.manager.serializer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

@Slf4j
public class FiRequestSerializer implements Serializer<FIRequest> {


    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public byte[] serialize(String topic, FIRequest fiRequest) {
        try {
            return objectMapper.writeValueAsBytes(fiRequest);
        }
        catch (JsonProcessingException e){
            log.info("Error occurred while serialization");
            return null;
        }

    }

}
