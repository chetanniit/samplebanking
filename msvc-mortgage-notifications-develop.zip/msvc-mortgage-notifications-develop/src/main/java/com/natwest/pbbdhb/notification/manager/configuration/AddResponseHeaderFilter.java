package com.natwest.pbbdhb.notification.manager.configuration;

import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.CSP_VALUE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.NO_CACHE;

/**
 * This filter class adds response headers in all the API response.
 */
@Component
public class AddResponseHeaderFilter implements Filter {

    public static final String CONTENT_SECURITY_POLICY = "Content-Security-Policy";
    public static final String CACHE_CONTROL = "Cache-control";
    public static final String PRAGMA = "Pragma";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        httpServletResponse.setHeader(CONTENT_SECURITY_POLICY, CSP_VALUE);
        httpServletResponse.setHeader(CACHE_CONTROL, NO_CACHE);
        httpServletResponse.setHeader(PRAGMA, NO_CACHE);
        filterChain.doFilter(servletRequest, servletResponse);
    }
}
