/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.notification.manager.controller;

import com.natwest.pbbdhb.notification.manager.model.exception.ErrorResponse;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Collections;
import java.util.Date;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class MortgageNotificationControllerAdvice extends ResponseEntityExceptionHandler {

    @ExceptionHandler({HttpClientErrorException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpClientErrorException(
            HttpClientErrorException ex) {
        log.error(
                "HttpClientErrorException occurred while processing notification : {}",
                ex.getResponseBodyAsString(), ex);
        return ResponseEntity.status(ex.getStatusCode())
                .body(
                        new ErrorResponse(
                                ex.getStatusCode().value(),
                                ex.getStatusCode(),
                                Collections.singletonList(
                                        ex.getResponseBodyAsString()),
                                new Date()));
    }

    @ExceptionHandler({HttpServerErrorException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpServerErrorException(
            HttpServerErrorException ex) {
        log.error(
                "HttpServerErrorException occurred while processing notification : {}",
                ex.getResponseBodyAsString(), ex);
        return ResponseEntity.status(ex.getStatusCode())
                .body(
                        new ErrorResponse(
                                ex.getStatusCode().value(),
                                ex.getStatusCode(),
                                Collections.singletonList(
                                        ex.getResponseBodyAsString()),
                                new Date()));
    }
}
