package com.natwest.pbbdhb.notification.manager.model.exception;

import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationErrorRequest {
    private FIRequest request;
    private String errorMessage;
}
