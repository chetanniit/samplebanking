package com.natwest.pbbdhb.notification.manager.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Enum class for notification template
 */
@AllArgsConstructor
@Getter
public enum NotificationTemplate {
    BROKER_FYA_NOTIFICATION_TEMPLATE("flow-management-broker-fya-notification"),
    BAPI_FYA_NOTIFICATION_TEMPLATE("flow-management-bapi-fya-notification"),
    CUSTOMER_FYA_NOTIFICATION_TEMPLATE("flow-management-customer-fya-notification"),
    BROKER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE("flow-management-broker-avscan-failure-notification"),
    BAPI_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE("flow-management-bapi-avscan-failure-notification"),
    CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE("flow-management-customer-avscan-failure-notification"),
    CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE_FOR_XO("flow-management-customer-avscan-failure-notification-xo-and-adbo"),
    CUSTOMER_AVSCAN_FAILURE_NOTIFICATION_TEMPLATE_FOR_ADBO("flow-management-customer-avscan-failure-notification-adbo"),
    BROKER_WELCOME_NOTIFICATION_TEMPLATE("flow-management-broker-welcome-notification"),
    BAPI_WELCOME_NOTIFICATION_TEMPLATE("flow-management-bapi-welcome-notification"),
    CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE("flow-management-customer-welcome-notification"),
    CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_XO("flow-management-customer-welcome-notification-xo-and-adbo"),
    CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO("flow-management-customer-welcome-notification-adbo"),
    NO_PACKAGING_CUSTOMER_WELCOME_NOTIFICATION_TEMPLATE_FOR_ADBO("flow-management-no-packaging-customer-welcome-notification-adbo"),
    CUSTOMER_FYA_NOTIFICATION_TEMPLATE_FOR_XO("flow-management-customer-fya-notification-xo"),
    CUSTOMER_CHASER_NOTIFICATION_TEMPLATE_FOR_XO("flow-management-customer-fya-notification-reminder-xo"),
    CUSTOMER_FYA_NOTIFICATION_TEMPLATE_FOR_ADBO("flow-management-customer-fya-notification-adbo"),
    BROKER_LAPSE_TEMPLATE("flow-management-email-lapse-notification");

    private final String templateName;
}