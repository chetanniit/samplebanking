package com.natwest.pbbdhb.notification.manager.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.email.Documents;
import com.natwest.pbbdhb.notification.manager.model.email.FailedDocInfo;
import com.natwest.pbbdhb.notification.manager.model.email.NotificationInfo;
import com.natwest.pbbdhb.notification.manager.model.enums.Channel;
import com.natwest.pbbdhb.notification.manager.model.enums.FlowOperation;
import com.natwest.pbbdhb.notification.manager.model.request.*;
import com.natwest.pbbdhb.notification.manager.service.EmailService;
import com.natwest.pbbdhb.notification.manager.util.NotificationTemplateUtil;
import com.natwest.pbbdhb.notification.manager.validator.aspect.LogCorrelationIdPrerequisite;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.*;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormat;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.convertDateFormatForRequestedDate;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.getFullName;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.getTimePeriodByFromDateAndToDate;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationUtil.isChaserEvent;

@Slf4j
@Service
public class CustomerNotificationConsumerService {

    @Autowired
    private EmailService emailService;

    @Value("${notification.mortgage.tracker.customer.url:}")
    private String mortgageTrackerCustomerUrl;

    @Value("${rbs.notification.mortgage.tracker.customer.url:}")
    private String rbsMortgageTrackerCustomerUrl;

    @Value("${notification.mortgage.tracker.xo.customer.url:}")
    private String xoMortgageTrackerCustomerUrl;

    @Value("${rbs.notification.mortgage.tracker.xo.customer.url:}")
    private String xoRbsMortgageTrackerCustomerUrl;

    @Value("${notification.mortgage.tracker.adbo.customer.url:}")
    private String adboMortgageTrackerCustomerUrl;

    @Value("${rbs.notification.mortgage.tracker.adbo.customer.url:}")
    private String adboRbsMortgageTrackerCustomerUrl;
    
    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Kafka listener to consume the message from customer notification topic
     *
     * @param fiRequest - fiRequest
     * @param offset - offset
     * @param topic - topic
     * @param partition - partition
     * @param acknowledgment - acknowledgment
     */
    @LogCorrelationIdPrerequisite
    @KafkaListener(topics = "#{'${kafka.customerTopicName}'}", groupId = "#{'${kafka.customerGroupId}'}",
            containerFactory = "customerListenerContainerFactory" , autoStartup = "${msvc.notifications.kafka.consumer.enabled:true}")
    public void listener(@Payload String request, @Header(KafkaHeaders.OFFSET) int offset, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, Acknowledgment acknowledgment) {
        acknowledgment.acknowledge();
        log.info("Listening message from topic  : {} and partition : {} and offset: {}", topic, partition, offset);
        try {
			
			FIRequest fiRequest = objectMapper.readValue(request, FIRequest.class);
			
			log.info("Trying to Acknowledge :{} ", request);
			
			emailNotification(fiRequest);
			
		} catch (JsonProcessingException e) {
			log.error("Error in serializing the request into Object: {}", request);
		}
    }

    /**
     * Kafka listener to consume the message from customer notification retry topic
     *
     * @param fiRequest - fiRequest
     * @param offset - offset
     * @param topic - topic
     * @param partition - partition
     * @param acknowledgment - acknowledgment
     */
    @LogCorrelationIdPrerequisite
    @KafkaListener(topics = "#{'${kafka.customerNotificationRetryTopic}'}", groupId = "#{'${kafka.customerNotificationRetryGroupId}'}",
            containerFactory = "customerRetryListenerContainerFactory" , autoStartup = "${msvc.notifications.kafka.consumer.enabled:true}")
    public void retry(@Payload String request, @Header(KafkaHeaders.OFFSET) int offset, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, Acknowledgment acknowledgment) {
        acknowledgment.acknowledge();
        log.info("Listening message from retry topic  : {} and partition : {} and offset: {}", topic, partition, offset);
        try {
			
			FIRequest fiRequest = objectMapper.readValue(request, FIRequest.class);
			
			log.info("Trying to Acknowledge :{} ", request);
			
			emailNotification(fiRequest);
			
		} catch (JsonProcessingException e) {
			log.error("Error in serializing the request into Object: {}", request);
		}
    }

    private void emailNotification(FIRequest fiRequest) {
        NotificationInfo notificationInfo = NotificationTemplateUtil.getNotificationInfo(fiRequest);
        if (FlowOperation.AV_SCAN_FAILURE_EVENT.getOperationName().equalsIgnoreCase(fiRequest.getOperation())) {
            sendCustomerAVScanFailureEmail(fiRequest, notificationInfo);
        } else {
            sendCustomerFYAEmail(fiRequest, notificationInfo);
        }
    }

    private void sendCustomerAVScanFailureEmail(FIRequest fiRequest, NotificationInfo notificationInfo) {
        Optional.ofNullable(fiRequest.getApplicants()).orElseGet(Collections::emptyList).forEach(applicant -> {
            List<FailedDocInfo> avScanFailedDocs = prepareAVScanFailedDocumentDetails(fiRequest);
            if (StringUtils.isNotEmpty(applicant.getEmailAddress())
                    && applicant.isNotificationRequired()
                    && CollectionUtils.isNotEmpty(avScanFailedDocs)) {
                EmailRequest request = EmailRequest.builder().notificationType(notificationInfo.getTemplateName()).build();
                Map<String, Object> emailParameter = new HashMap<>();
                emailParameter.put(SUBJECT, notificationInfo.getEmailSubject());
                emailParameter.put(MORTGAGE_TRACKER_URL, getMortgageTrackerURL(fiRequest, notificationInfo));
                setReferenceNumber(fiRequest, emailParameter);
                emailParameter.put(APPLICANT_FULL_NAME, getFullName(fiRequest, applicant));
                emailParameter.put(TO_RECIPIENTS, applicant.getEmailAddress());
                emailParameter.put(DOCUMENT_INFO, avScanFailedDocs);
                request.setParameters(emailParameter);
                emailService.sendEmail(fiRequest.getBrand(), request);
            }
        });
    }

    private void setReferenceNumber(FIRequest fiRequest, Map<String, Object> emailParameter) {
        if(!StringUtils.isBlank(fiRequest.getReferenceNumber())){
            emailParameter.put(REFERENCE_NUMBER, fiRequest.getReferenceNumber());
        }
    }

    private void sendCustomerFYAEmail(FIRequest fiRequest, NotificationInfo notificationInfo) {
       Optional.ofNullable(fiRequest.getApplicants()).orElseGet(Collections::emptyList).forEach(applicant -> {
            List<Documents> listOfRequiredDocs = prepareDocumentDetails(fiRequest);

            if (StringUtils.isNotEmpty(applicant.getEmailAddress())
                    && applicant.isNotificationRequired()
                    && (CollectionUtils.isNotEmpty(listOfRequiredDocs) || notificationInfo.isEmailForNoPackagingRequired())) {
                String applicantFullName = getFullName(fiRequest, applicant);
                EmailRequest request = EmailRequest.builder().notificationType(notificationInfo.getTemplateName()).build();
                Map<String, Object> emailParameter = new HashMap<>();
                emailParameter.put(MORTGAGE_TRACKER_URL, getMortgageTrackerURL(fiRequest, notificationInfo));
                emailParameter.put(SUBJECT, notificationInfo.getEmailSubject());
                populateBasicParameters(fiRequest, notificationInfo, emailParameter, applicantFullName);
                emailParameter.put(APPLICANT_FULL_NAME, applicantFullName);
                emailParameter.put(TO_RECIPIENTS, applicant.getEmailAddress());
                emailParameter.put(DOCUMENTS, listOfRequiredDocs);
                request.setParameters(emailParameter);
                emailService.sendEmail(fiRequest.getBrand(), request);
            } else{
                log.info("Skipping send email for the caseId :{} referenceNumber:{}, documentsCount:{}, isEmailForNoPackagingRequired:{}",fiRequest.getCaseId(),fiRequest.getReferenceNumber(),listOfRequiredDocs.size(),notificationInfo.isEmailForNoPackagingRequired());
            }
        });
    }

    private void populateBasicParameters(FIRequest fiRequest, NotificationInfo notificationInfo, Map<String, Object> emailParameter, String applicantFullName) {
        if(XO_CHANNEL.equalsIgnoreCase(fiRequest.getChannel())) {
            emailParameter.put(DASHBOARD_LINK, getMortgageTrackerURL(fiRequest, notificationInfo));
            emailParameter.put(FIRST_NAME, applicantFullName);
            setReferenceNumber(fiRequest, emailParameter);
            return;
        }

        populateBasicParametersForBrokerChannel(fiRequest, emailParameter);
    }

    private void populateBasicParametersForBrokerChannel(FIRequest fiRequest, Map<String, Object> emailParameter) {
        // For Non Internet channel.
        if(StringUtils.isNotEmpty(fiRequest.getReferenceNumber())){
            emailParameter.put(REFERENCE_NUMBER, fiRequest.getReferenceNumber());
        }else{
            emailParameter.put(REFERENCE_NUMBER, fiRequest.getCaseId());
        }
    }

    private List<Documents> prepareDocumentDetails(FIRequest fiRequest) {
        List<Documents> documents = new ArrayList<>();
        boolean isChaser = isChaserEvent(fiRequest);
        if (isChaser) {
            fiRequest.getDocumentRequests().sort(Comparator.comparing(Document::getRequestedDate));
        }
        Optional.ofNullable(fiRequest.getDocumentRequests()).orElseGet(Collections::emptyList).forEach(doc ->
            Optional.ofNullable(fiRequest.getApplicants()).orElseGet(Collections::emptyList).forEach(applicantInformation -> {
                Documents document = getDocuments(doc, isChaser);
                Optional.ofNullable(doc.getRequiredFor()).orElseGet(Collections::emptyList).forEach(requiredFor -> document.setDocumentFor(getFullName(fiRequest, applicantInformation)));
                documents.add(document);
            }));
        return documents;
    }

    private List<FailedDocInfo> prepareAVScanFailedDocumentDetails(FIRequest fiRequest) {
        List<FailedDocInfo> failedDocInfoList = new ArrayList<>();
        Optional.ofNullable(fiRequest.getDocumentRequests()).orElseGet(Collections::emptyList).forEach(docRequest -> {
            String purpose = CollectionUtils.isNotEmpty(docRequest.getPurpose()) ?
                    getCombinedValue(docRequest.getPurpose()) : null;
            String category = Stream.of(docRequest.getCategory(), purpose).filter(Objects::nonNull)
                    .collect(Collectors.joining(DELIMITER_HYPHEN_WITH_SPACE));
            Optional.ofNullable(fiRequest.getApplicants()).orElseGet(Collections::emptyList).forEach(applicantInformation ->
                    Optional.ofNullable(docRequest.getDocumentInfo()).orElseGet(Collections::emptyList)
                            .forEach(docInfo -> failedDocInfoList.add(FailedDocInfo.builder()
                                    .category(category).originalFileName(docInfo.getOriginalFileName())
                                    .requiredFor(getFullName(fiRequest, applicantInformation))
                                    .errorMessage(docInfo.getErrorMessage())
                                    .build()))
            );
        });
        return failedDocInfoList;
    }

    @NotNull
    private Documents getDocuments(Document doc, boolean isChaser) {

        String purpose = CollectionUtils.isNotEmpty(doc.getPurpose()) ?
                getCombinedValue(doc.getPurpose()) : null;
        String category = Stream.of(doc.getCategory(), purpose).filter(Objects::nonNull)
                .collect(Collectors.joining(DELIMITER_HYPHEN_WITH_SPACE));

        return Documents.builder().fromDate(convertDateFormat(doc.getFromDate()))
                .toDate(convertDateFormat(doc.getToDate()))
                .timePeriod(Optional.ofNullable(doc.getTimePeriod()).orElse(getTimePeriodByFromDateAndToDate(doc)))
                .category(category)
                .reRequestReason(getCombinedValue(doc.getReRequestReason()))
                .documentPurpose(purpose)
                .requestedDate(isChaser ? convertDateFormatForRequestedDate(doc.getRequestedDate()) : null)
                .dueDate(convertDateFormat(doc.getDueDate())).build();
    }

    private String getCombinedValue(List<String> docValues) {
        return Optional.ofNullable(docValues)
                .map(values -> String.join(DELIMITER_COMMA_WITH_SPACE, values))
                .orElse(null);
    }

    private String getMortgageTrackerURL(FIRequest fiRequest, NotificationInfo notificationInfo) {
        if (notificationInfo.isADBOCase()){
            return NWB_BRAND.equalsIgnoreCase(fiRequest.getBrand()) ? adboMortgageTrackerCustomerUrl : adboRbsMortgageTrackerCustomerUrl;
        } else if(Channel.INTERNET.name().equalsIgnoreCase(fiRequest.getChannel())){
            return NWB_BRAND.equalsIgnoreCase(fiRequest.getBrand()) ? xoMortgageTrackerCustomerUrl : xoRbsMortgageTrackerCustomerUrl;
        }
        return NWB_BRAND.equalsIgnoreCase(fiRequest.getBrand()) ? mortgageTrackerCustomerUrl : rbsMortgageTrackerCustomerUrl;
    }
}
