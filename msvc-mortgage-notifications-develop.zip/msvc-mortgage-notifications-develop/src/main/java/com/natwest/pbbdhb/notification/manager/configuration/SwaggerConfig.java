package com.natwest.pbbdhb.notification.manager.configuration;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;

/**
 * Swagger configuration
 */
@Slf4j
public class SwaggerConfig {

    private final BuildProperties buildProperties;

    public SwaggerConfig(@Autowired(required = false) BuildProperties buildProperties) {
        this.buildProperties = buildProperties;
        if (null == buildProperties) {
            log.error("buildProperties are missing. check the build");
        }
    }

    @Bean
    public OpenAPI springOpenAPI() {
        return new OpenAPI()
                .info(new Info().title("Mortgage notifications API")
                        .description("Mortgage notifications API is useful to track information on your customers’ NatWest mortgage applications")
                        .version(null == buildProperties ? "V1" : buildProperties.getVersion())
                        .license(new License().name("Natwest Group").url("https://www.natwest.com/website-terms-and-FSCS.html")));
    }
}
