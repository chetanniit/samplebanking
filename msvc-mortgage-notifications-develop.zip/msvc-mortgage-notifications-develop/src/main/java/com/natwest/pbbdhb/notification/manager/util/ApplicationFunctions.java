package com.natwest.pbbdhb.notification.manager.util;

import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;

import java.util.Objects;
import java.util.function.Predicate;

public class ApplicationFunctions {

    private ApplicationFunctions(){
    }

    public static final Predicate<FIRequest> isADBOCaseApplication = fiRequest ->  Objects.nonNull(fiRequest) &&
            ApplicationConstant.ADDITIONAL_BORROWING.equalsIgnoreCase(fiRequest.getLoanPurpose());

}
