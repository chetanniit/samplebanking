package com.natwest.pbbdhb.notification.manager.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * Enum class for operation which is used in notification
 */
@AllArgsConstructor
@Getter
public enum FlowOperation {
    CHASER("chaser"),
    AUTO_CHASER("autoChaser"),
    EMAIL_LAPSE("emailLapse"),
    FI_REQUEST("fiRequest"),
    AV_SCAN_FAILURE_EVENT("avScanFailure"),
    REQUIRED_DOCS("requiredDocs"),
    DEFAULT("default");

    private final String operationName;

    /**
     * Method to find enum by its value
     *
     * @param operation - operation
     * @return FlowOperation
     */
    public static FlowOperation findByValue(final String operation) {
        return Arrays.stream(values()).filter(value -> value.getOperationName().equals(operation)).findFirst().orElse(DEFAULT);
    }
}