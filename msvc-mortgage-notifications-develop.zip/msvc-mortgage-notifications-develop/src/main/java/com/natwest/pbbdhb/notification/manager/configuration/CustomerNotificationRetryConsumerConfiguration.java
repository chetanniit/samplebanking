package com.natwest.pbbdhb.notification.manager.configuration;

import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.ERROR_MESSAGE;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.SECURITY_PROTOCOL;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.SSL_ALGORITHM;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.SSL_KEYSTORE_LOCATION;
import static com.natwest.pbbdhb.notification.manager.util.ApplicationConstant.SSL_KEYSTORE_PD;
import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL_IMMEDIATE;
import static org.springframework.kafka.listener.adapter.RetryingMessageListenerAdapter.CONTEXT_RECORD;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.notification.manager.model.exception.NotificationErrorRequest;
import com.natwest.pbbdhb.notification.manager.model.request.FIRequest;
import com.natwest.pbbdhb.notification.manager.util.KafkaConfigReader;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
@ConditionalOnExpression("${msvc.notifications.kafka.consumer.enabled:true}")
public class CustomerNotificationRetryConsumerConfiguration {

    @Autowired
    private KafkaConfigReader config;

    @Autowired
    KafkaTemplate<String, Object> notificationErrorKafkaTemplate;
    
    @Autowired
    private ObjectMapper objectMapper;

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> customerRetryListenerContainerFactory() {
        final ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(this.customerNotificationRetryConsumerFactory());
        factory.getContainerProperties().setAckMode(MANUAL_IMMEDIATE);
        factory.getContainerProperties().setIdleBetweenPolls(Long.parseLong(config.getIdleBetweenPolls()));
        factory.setRetryTemplate(retryTemplate());
        factory.setRecoveryCallback((context -> {
            log.info("Done with retries and still issue exists. Posting the message to the customer notification error topic");
            ConsumerRecord errorRecord = (ConsumerRecord) context.getAttribute(CONTEXT_RECORD);
            assert errorRecord != null;
            String strFIRequest = (String) errorRecord.value();
            
            FIRequest failedFIRequest = objectMapper.readValue(strFIRequest, FIRequest.class);            
            
            NotificationErrorRequest errorPayload = NotificationErrorRequest.builder().request(failedFIRequest)
                    .errorMessage(getErrorMessage(context.getLastThrowable().getCause().getMessage(), failedFIRequest)).build();
            notificationErrorKafkaTemplate.send(config.getCustomerNotificationErrorTopic(), errorRecord.key().toString(),
                    errorPayload);
            return Optional.empty();
        }));
        return factory;
    }

    private String getErrorMessage(String message, FIRequest failedFIRequest) {
        return Optional.ofNullable(message)
                .orElse(MessageFormat.format(ERROR_MESSAGE, failedFIRequest.getReferenceNumber(),
                        failedFIRequest.getSequenceNumber()));
    }

    @Bean
    public ConsumerFactory<String, String> customerNotificationRetryConsumerFactory() {
        final Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapServers());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, config.getCustomerNotificationRetryGroupId());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class);
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, String.class);
        long maxPoll = new Long(config.getIdleBetweenPolls()) + 1000;
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, Long.toString(maxPoll));
        props.put(SECURITY_PROTOCOL, config.getSecurityProtocol());
        props.put(SSL_KEYSTORE_LOCATION, config.getSslKeystoreLocation());
        props.put(SSL_KEYSTORE_PD, config.getSslKeystorePassword());
        props.put(SSL_ALGORITHM, "");
        return new DefaultKafkaConsumerFactory<>(props);
    }

    private RetryTemplate retryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();
        retryTemplate.setRetryPolicy(getSimpleRetryPolicy());
        return retryTemplate;
    }

    private SimpleRetryPolicy getSimpleRetryPolicy() {
        Map<Class<? extends Throwable>, Boolean> exceptionMap = new HashMap<>();
        exceptionMap.put(RuntimeException.class, true);
        return new SimpleRetryPolicy(Integer.parseInt(config.getRetryAttempts()), exceptionMap, true);
    }
}
