package com.natwest.pbbdhb.notification.manager.service;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import org.springframework.http.ResponseEntity;

/**
 * This Service is used for email notification
 */
public interface EmailService {

    /**
     * Method to send email
     * @param brand - allowed values NWB/RBS
     * @param emailRequest - EmailRequest
     * @return - String
     */
    ResponseEntity<String> sendEmail(String brand, EmailRequest emailRequest);
}
