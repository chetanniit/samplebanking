package com.natwest.pbbdhb.notification.manager.service.impl;

import com.natwest.pbbdhb.notification.manager.model.request.EmailRequest;
import com.natwest.pbbdhb.notification.manager.service.EmailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * Impl class for Email Service and is used for email notification
 */
@Service
@Slf4j
public class EmailServiceImpl implements EmailService {

    @Value("${email.service.endpoint}")
    private String emailServiceEndPoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    /**
     * Method to send email
     * @param brand        - allowed values NWB/RBS
     * @param emailRequest - EmailRequest
     * @return - String
     */
    @Override
    public ResponseEntity<String> sendEmail(String brand, EmailRequest emailRequest) {

        log.info("Calling Email service with Request  : " + emailRequest);

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand.toLowerCase());
        headers.add("Content-Type", "application/json");
        HttpEntity<EmailRequest> httpEntity = new HttpEntity<>(emailRequest, headers);
        ResponseEntity<String> emailResponseEntity;
        log.info("Calling Email service from request : " + emailRequest);
        emailResponseEntity = restTemplate.postForEntity(emailServiceEndPoint, httpEntity, String.class);
        log.info("Response Received from Email service is :" + emailResponseEntity);
        return emailResponseEntity;
    }
}
