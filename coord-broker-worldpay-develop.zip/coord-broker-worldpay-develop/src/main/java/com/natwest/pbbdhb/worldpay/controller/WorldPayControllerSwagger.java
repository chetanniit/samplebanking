package com.natwest.pbbdhb.worldpay.controller;

import com.natwest.pbbdhb.worldpay.model.BrokerRequest;
import com.natwest.pbbdhb.worldpay.model.ErrorResponse;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

/**
 * this is swagger configuration.
 */
@Validated
@SuppressWarnings("PMD")
public interface WorldPayControllerSwagger {

    String BAD_REQUEST_ERROR = "{\"errors\":[\"fcaNumber cannot be null or empty\"]}";
    String SAMPLE_RESPONSE = "{\"paymentUrl\":\"https://sampleurls.rbs.net/payment\"}";
    String UNAUTHORISED_ERROR = "{\"errors\":[\"Unauthorized\"]}";
    String FORBIDDEN_ERROR = "{\"errors\":[\"Forbidden\"]}";
    String NOT_FOUND_ERROR = "{\"errors\":[\"Resource Not Found.\"]}";
    String METHOD_NOT_ALLOWED_ERROR = "{\"errors\":[\"Method Not Allowed\"]}";
    String UNSUPPORTED_MEDIA_TYPE_ERROR = "{\"errors\":[\"Unsupported Media Type\"]}";
    String INTERNAL_SERVER_ERROR = "{\"errors\":[\"Our backend is non-functional, please try again later\"]}";
    String SERVICE_NOT_AVAILABLE_ERROR = "{\"errors\":[\"Service not available\"]}";

    /**
     * this method is to update get payment page from msvc service.
     * @param brand
     * @param clientId
     * @param mortgageRefNumber
     * @param brokerRequest
     * @return ResponseEntity as WorldPayResponse
     */
    @SuppressWarnings("CPD-START")
    @Operation(summary = "Get Payment UI URL")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK",
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    examples = {@ExampleObject(SAMPLE_RESPONSE)})}),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(BAD_REQUEST_ERROR)})}),
            @ApiResponse(responseCode = "401", description = "Not authenticated",
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(UNAUTHORISED_ERROR)})}),
            @ApiResponse(responseCode = "403", description = FORBIDDEN_ERROR,
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(FORBIDDEN_ERROR)})}),
            @ApiResponse(responseCode = "404", description = "Resource not found",
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(NOT_FOUND_ERROR)})}),
            @ApiResponse(responseCode = "405", description = METHOD_NOT_ALLOWED_ERROR,
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(METHOD_NOT_ALLOWED_ERROR)})}),
            @ApiResponse(responseCode = "415", description = UNSUPPORTED_MEDIA_TYPE_ERROR,
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(UNSUPPORTED_MEDIA_TYPE_ERROR)})}),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(INTERNAL_SERVER_ERROR)})}),
            @ApiResponse(responseCode = "503", description = SERVICE_NOT_AVAILABLE_ERROR,
                    content = {@Content(mediaType =
                    MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = {@ExampleObject(SERVICE_NOT_AVAILABLE_ERROR)})})
    })
    @PostMapping(path = "/{mortgageRefNumber}/get-payment-page")
    ResponseEntity<PaymentUrlResponse> getPaymentPageURL(
            @Parameter(description = "Brand", example = "nwb")
            @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
            @RequestHeader(value = "client_id", required = false) String clientId,
            @Parameter(description = "mortgageRefNumber", example = "35273488")
            @Valid @PathVariable("mortgageRefNumber") String mortgageRefNumber,
            @Valid @RequestBody BrokerRequest brokerRequest);

    /**
     * This method is to get payment page from msvc service based on applicationType.
     * @param brand
     * @param clientId
     * @param mortgageRefNumber
     * @param brokerRequest
     * @return ResponseEntity as WorldPayResponse for applicationType
     */
    @SuppressWarnings("CPD-END")
    @Operation(summary = "Get Payment UI URL based on applicationType ")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "OK",
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                examples = {@ExampleObject(SAMPLE_RESPONSE)})}),
        @ApiResponse(responseCode = "400", description = "Bad Request",
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(BAD_REQUEST_ERROR)})}),
        @ApiResponse(responseCode = "401", description = "Not authenticated",
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(UNAUTHORISED_ERROR)})}),
        @ApiResponse(responseCode = "403", description = FORBIDDEN_ERROR,
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(FORBIDDEN_ERROR)})}),
        @ApiResponse(responseCode = "404", description = "Resource not found",
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(NOT_FOUND_ERROR)})}),
        @ApiResponse(responseCode = "405", description = METHOD_NOT_ALLOWED_ERROR,
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(METHOD_NOT_ALLOWED_ERROR)})}),
        @ApiResponse(responseCode = "415", description = UNSUPPORTED_MEDIA_TYPE_ERROR,
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(UNSUPPORTED_MEDIA_TYPE_ERROR)})}),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(INTERNAL_SERVER_ERROR)})}),
        @ApiResponse(responseCode = "503", description = SERVICE_NOT_AVAILABLE_ERROR,
            content = {@Content(mediaType =
                MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class),
                examples = {@ExampleObject(SERVICE_NOT_AVAILABLE_ERROR)})})
    })
    @PostMapping(path = "/adbo/{mortgageRefNumber}/get-payment-page")
    ResponseEntity<PaymentUrlResponse> getAdboPaymentPageURL(
        @Parameter(description = "Brand", example = "nwb")
        @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
        @RequestHeader(value = "client_id", required = false) String clientId,
        @Parameter(description = "mortgageRefNumber", example = "35273488")
        @Valid @PathVariable("mortgageRefNumber") String mortgageRefNumber,
        @Valid @RequestBody BrokerRequest brokerRequest);
}

