package com.natwest.pbbdhb.worldpay.model;

public enum ApplicationType {
  ADDITIONAL_BORROWING
}
