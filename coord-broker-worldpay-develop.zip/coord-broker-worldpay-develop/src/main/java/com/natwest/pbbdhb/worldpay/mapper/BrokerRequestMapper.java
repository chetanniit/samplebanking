package com.natwest.pbbdhb.worldpay.mapper;

import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.worldpay.model.BrokerRequest;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface BrokerRequestMapper {
    BrokerDetails map(BrokerRequest brokerRequest);
}
