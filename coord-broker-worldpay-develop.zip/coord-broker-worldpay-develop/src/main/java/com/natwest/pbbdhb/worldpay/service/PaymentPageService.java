package com.natwest.pbbdhb.worldpay.service;

import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.worldpay.model.PaymentRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import com.natwest.pbbdhb.worldpay.service.client.PaymentPageClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class PaymentPageService {

    private final PaymentPageClient paymentPageClient;

    public PaymentUrlResponse getPaymentPageUrl(BrokerDetails brokerDetails, PaymentRequest paymentRequest,
                                                String brand) {
        return paymentPageClient.getPaymentPageUrl(brokerDetails, paymentRequest, brand);
    }

}
