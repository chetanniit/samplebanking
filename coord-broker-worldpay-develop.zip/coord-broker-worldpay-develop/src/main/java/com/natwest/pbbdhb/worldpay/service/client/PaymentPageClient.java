package com.natwest.pbbdhb.worldpay.service.client;

import com.natwest.pbbdhb.broker.annotation.ValidateBrokerDetails;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.worldpay.model.PaymentRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class PaymentPageClient {

    private final RestTemplate iamJwtChainSecureRestTemplate;
    private final String worldpayEndPoint;

    public PaymentPageClient(@Qualifier("iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
                             @Value("${msvc.worldpay.service.url}") String worldpayEndPoint) {
        this.iamJwtChainSecureRestTemplate = iamJwtChainSecureRestTemplate;
        this.worldpayEndPoint = worldpayEndPoint;
    }

    @ValidateBrokerDetails
    public PaymentUrlResponse getPaymentPageUrl(final BrokerDetails brokerDetails,
                                                final PaymentRequest paymentRequest,
                                                String brand) {

        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.add("brand", brand);
        HttpEntity<PaymentRequest> httpEntity = new HttpEntity<>(paymentRequest, headers);

        log.debug("get-payment-page-url :: calling msvc-worldpay internal service with Mortgage Reference number : {}"
                + " brand {} and Application Type : {}",
            paymentRequest.getMortgageReferenceNumber(), brand, paymentRequest.getApplicationType());

        ResponseEntity<PaymentUrlResponse> responseEntity = iamJwtChainSecureRestTemplate
                .postForEntity(worldpayEndPoint, httpEntity, PaymentUrlResponse.class);
        return responseEntity.getBody();
    }
}
