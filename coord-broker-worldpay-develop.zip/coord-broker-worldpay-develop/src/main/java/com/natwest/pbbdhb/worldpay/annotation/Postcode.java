package com.natwest.pbbdhb.worldpay.annotation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = PostcodeValidator.class)
public @interface Postcode {

    String message() default "Please enter valid post code (e.g. XX99 9XX).";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
