package com.natwest.pbbdhb.worldpay.configuration;

import io.swagger.v3.oas.models.info.Info;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class SwaggerConfiguration {

    @Value("${worldpay.contract.version}")
    private String contractVersion;

    @Autowired
    private BuildProperties buildProperties;

    @Bean
    public GroupedOpenApi paymentDataApi() {
        return GroupedOpenApi.builder()
                .group("PAYMENT-API").addOpenApiCustomiser(openApi -> openApi.setInfo(new Info()
                        .title("Get Payment UI URL API")
                        .description("Get Payment UI URL API")
                        .version(getVersion()))).build();
    }

    private String getVersion() {
        return String.format("v1 / %s / Contract %s", buildProperties.getVersion(), contractVersion);
    }
}
