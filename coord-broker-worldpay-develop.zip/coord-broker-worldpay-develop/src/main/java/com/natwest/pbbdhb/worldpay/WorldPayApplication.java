package com.natwest.pbbdhb.worldpay;

import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Springboot Application.
 */
@SpringBootApplication(scanBasePackageClasses = {WorldPayApplication.class})
public class WorldPayApplication {

    /**
     * The application's main entry point.
     *
     * @param args String args
     */
    public static void main(String[] args) {
        new SpringApplicationBuilder()
                .environment(new StandardEncryptableEnvironment()).sources(WorldPayApplication.class).run(args);
    }
}

