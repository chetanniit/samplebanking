package com.natwest.pbbdhb.worldpay.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings({"PMD.AvoidFieldNameMatchingTypeName"})
public class ErrorMessage {
    private String errorMessage;
    private String message;
    private String responseStatus;
}
