package com.natwest.pbbdhb.worldpay.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * this is response object from WorldPay.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentUrlResponse {
    private String paymentUrl;
}
