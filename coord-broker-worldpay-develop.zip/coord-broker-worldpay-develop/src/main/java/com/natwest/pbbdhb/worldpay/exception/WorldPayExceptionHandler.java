package com.natwest.pbbdhb.worldpay.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.exception.InvalidBrokerException;
import com.natwest.pbbdhb.worldpay.model.ErrorMessage;
import com.natwest.pbbdhb.worldpay.model.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.context.request.WebRequest;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Slf4j
@ControllerAdvice
public class WorldPayExceptionHandler {

    @Autowired
    private ObjectMapper objectMapper;

    @ExceptionHandler({InvalidBrokerException.class})
    public ResponseEntity<ErrorResponse> invalidBrokerResponseException(InvalidBrokerException ex, WebRequest request)
            throws JsonProcessingException {

        if (ex.getException() != null) {
            RestClientResponseException exception = (RestClientResponseException) ex.getException();

            HttpStatus httpStatus = HttpStatus.valueOf(exception.getRawStatusCode());
            String response = exception.getResponseBodyAsString();
            if (exception.getResponseBodyAsString().contains("errorMessage")) {
                response = objectMapper
                        .readValue(exception.getResponseBodyAsString(), ErrorMessage.class).getErrorMessage();
            }
            ErrorResponse message = new ErrorResponse(Arrays.asList(response));

            httpStatus = HttpStatus.NOT_FOUND.equals(httpStatus) ? HttpStatus.FORBIDDEN : httpStatus;
            return ResponseEntity.status(httpStatus).body(message);
        }
        ErrorResponse message = ErrorResponse.builder().errors(Arrays.asList(ex.getMessage())).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @ExceptionHandler({HttpServerErrorException.class})
    public ResponseEntity<ErrorResponse> handleServerErrorException(HttpServerErrorException ex) {
        log.error("HttpServerErrorException during processing {}, status{}", ex.getMessage());
        ErrorResponse errorResponse = ErrorResponse.builder().errors(Arrays.asList(ex.getMessage())).build();
        log.error("HttpServerErrorException during processing error response {} ", errorResponse);
        return ResponseEntity.status(ex.getStatusCode()).body(errorResponse);
    }

    @ExceptionHandler({HttpClientErrorException.class, RestClientException.class,
            HttpMessageNotReadableException.class})
    public ResponseEntity<ErrorResponse> handleBadRequestException(RuntimeException ex) throws JsonProcessingException {

        if (ex instanceof HttpClientErrorException.BadRequest || ex instanceof HttpMessageNotReadableException) {
            String responseBodyAsString = StringUtils.EMPTY;
            if (ex instanceof HttpClientErrorException.BadRequest) {
                 responseBodyAsString = ((HttpClientErrorException.BadRequest) ex).getResponseBodyAsString();
                 log.error("HttpClientErrorException Bad Request: {}", ex.getMessage());
            }
            if (ex instanceof HttpMessageNotReadableException) {
                responseBodyAsString = ex.getMessage();
                log.error("HttpMessageNotReadableException Bad Request: {}", ex.getMessage());
            }

            String message = HttpStatus.BAD_REQUEST.getReasonPhrase();
            if (StringUtils.isNotEmpty(responseBodyAsString) && responseBodyAsString.contains("message")
                    && responseBodyAsString.contains("errorMessage")) {
                ErrorMessage response = objectMapper.readValue(responseBodyAsString, ErrorMessage.class);
                message = Objects.nonNull(response) ? response.getMessage() : message;
            }
            ErrorResponse errorResponse = ErrorResponse.builder().errors(Arrays.asList(message)).build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
        log.error("Error during processing : {}", ex.getMessage());
        ErrorResponse errorResponse = ErrorResponse.builder().errors(Arrays.asList(ex.getMessage())).build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }

    @ExceptionHandler({RuntimeException.class})
    public ResponseEntity<ErrorResponse> handleRuntimeException(RuntimeException ex) {

        String errorMessage = ex.getMessage();
        log.error("Runtime error during processing: {}", errorMessage);

        HttpStatus responseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(responseStatus).body(ErrorResponse.builder().errors(Arrays.asList(errorMessage))
                .build());
    }

    @ExceptionHandler(BindException.class)
    protected ResponseEntity<ErrorResponse> handleMethodArgumentNotValid(BindException ex,
                                                                        WebRequest request) {
        if (ex instanceof MethodArgumentNotValidException) {
            List<ObjectError> fieldErrors = ex.getBindingResult().getAllErrors();

            List<String> errorMessages = fieldErrors.stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.toList());
            ErrorResponse message = ErrorResponse.builder().errors(errorMessages).build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(message);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ErrorResponse.builder().errors(Arrays.asList(HttpStatus.BAD_REQUEST.getReasonPhrase())).build());
    }

}
