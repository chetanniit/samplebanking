package com.natwest.pbbdhb.worldpay.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

/**
 * this is request object from worldpay.
 */

@Setter
@Getter
@Builder
@Schema(description = "Payment Url Request")
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequest {

    @NotEmpty
    @Schema(example = "36118429")
    private String mortgageReferenceNumber;

    private ApplicationType applicationType;
}
