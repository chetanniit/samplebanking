package com.natwest.pbbdhb.worldpay.controller.impl;

import com.natwest.pbbdhb.worldpay.controller.WorldPayControllerSwagger;
import com.natwest.pbbdhb.worldpay.mapper.BrokerRequestMapper;
import com.natwest.pbbdhb.worldpay.model.ApplicationType;
import com.natwest.pbbdhb.worldpay.model.BrokerRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import com.natwest.pbbdhb.worldpay.service.PaymentPageService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

/**
 * this is controller class.
 */
@RestController
@Tag(name = "Get Payment UI URL")
@Slf4j
@RequiredArgsConstructor
@Validated
public class WorldPayController implements WorldPayControllerSwagger {

    private final PaymentPageService paymentPageService;
    private final BrokerRequestMapper brokerRequestMapper;

    @Value("${application.apimetrics.client.id}")
    private String apiMetricsClientId;

    @Override
    public ResponseEntity<PaymentUrlResponse> getPaymentPageURL(String brand, String clientId, String mortgageRefNumber,
                                                                BrokerRequest brokerRequest) {

        if (StringUtils.isNotEmpty(clientId) && apiMetricsClientId.equalsIgnoreCase(clientId)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }

        log.info("get-payment-page-url :: Call for payment page url with Mortgage Reference number : {} brand {}",
                mortgageRefNumber, brand);
        return ResponseEntity.ok(paymentPageService.getPaymentPageUrl(brokerRequestMapper.map(brokerRequest),
                PaymentRequest.builder().mortgageReferenceNumber(mortgageRefNumber).build(), brand));
    }

    @Override
    public ResponseEntity<PaymentUrlResponse> getAdboPaymentPageURL(String brand, String clientId,
        String mortgageRefNumber, BrokerRequest brokerRequest) {

        if (StringUtils.isNotEmpty(clientId) && apiMetricsClientId.equalsIgnoreCase(clientId)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }

        log.info("get-payment-page-url :: Call for payment page url with Mortgage Reference number "
            + "for Adbo application : {}, brand {}", mortgageRefNumber, brand);
        return ResponseEntity.ok(paymentPageService.getPaymentPageUrl(brokerRequestMapper.map(brokerRequest),
            PaymentRequest.builder().mortgageReferenceNumber(mortgageRefNumber)
                .applicationType(ApplicationType.ADDITIONAL_BORROWING).build(), brand));
    }
}
