package com.natwest.pbbdhb.worldpay.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.PostConstruct;

/**
 * Configuration class used to load application properties.
 */
@Configuration
@Slf4j
@ComponentScan("com.natwest.pbbdhb.broker")
public class ApplicationConfiguration {

    @PostConstruct
    public void writeConfigurationToLog() {
        log.info("Starting application by using configuration: {}", this);
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*")
                        .allowedMethods("GET", "POST", "DELETE", "OPTIONS", "HEAD");
            }
        };
    }

}
