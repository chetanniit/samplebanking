package com.natwest.pbbdhb.worldpay.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@SuppressWarnings("PMD")
public class BrokerRequest {

    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9.!#$%'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";

    @Schema(example = "728734", minLength = 4, maxLength = 7,
            description = "Must contain numeric value, fcaNumber allows max 7 characters and min 4 characters",
            required = true)
    @Pattern(regexp = "^[0-9]{4,7}$",
            message = "fcaNumber is invalid or contains less than 4 characters or more than 7 characters")
    @NotEmpty(message = "FCA Number is required")
    private String fcaNumber;

    @Schema(example = "Hanif", description = "Broker surname, maximum 50 characters", required = true, minLength = 2,
            maxLength = 50)
    @Length(max = 50, message = "brokerSurname exceeds max 50 characters length")
    @Length(min = 2, message = "brokerSurname should have min 2 characters")
    @NotEmpty(message = "Broker surname is required")
    private String brokerSurname;

    @Schema(example = "aaliyahhanif", description = "Broker username, maximum 100 characters",
            minLength = 2, maxLength = 100)
    @Length(min = 2, message = "brokerForeName should have min 2 characters")
    @Length(max = 100, message = "brokerSurname exceeds max 50 characters length")
    @NotEmpty(message = "Broker username is required")
    private String brokerUsername;

    @Schema(example = "Aaliyah", description = "Broker ForeName, maximum 50 characters", minLength = 2, maxLength = 50)
    @Length(max = 50, message = "brokerForeName exceeds max 50 characters length")
    @Length(min = 2, message = "brokerForeName should have min 2 characters")
    private String brokerForeName;

    @Schema(example = "B23 6SN", description = "Broker postcode maximum 8 characters", maxLength = 8)
    @Pattern(regexp = "^([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|"
            + "(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9]?[A-Za-z])))) [0-9][A-Za-z]{2})$",
            message = "brokerPostcode is invalid")
    private String brokerPostcode;

    @Schema(example = "aaliyah.hanif@mab.org.uk", maxLength = 72,
            description = "Email address for Broker, maximum characters 72", required = true)
    @Pattern(regexp = EMAIL_PATTERN, message = "Please enter valid email Id for Broker")
    @Length(max = 72, message = "brokerEmail exceeds max 72 characters length")
    @NotEmpty(message = "Email address for Broker is required")
    private String brokerEmail;

}
