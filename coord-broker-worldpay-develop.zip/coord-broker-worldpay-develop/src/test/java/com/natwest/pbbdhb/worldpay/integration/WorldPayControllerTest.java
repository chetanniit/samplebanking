package com.natwest.pbbdhb.worldpay.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.worldpay.mapper.BrokerRequestMapper;
import com.natwest.pbbdhb.worldpay.model.BrokerRequest;
import com.natwest.pbbdhb.worldpay.model.ErrorResponse;
import com.natwest.pbbdhb.worldpay.model.PaymentRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import com.natwest.pbbdhb.worldpay.service.PaymentPageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@ActiveProfiles("test")
public class WorldPayControllerTest extends WireMockIntegrationTest {

    private static final int WAIT_TIME = 2000;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private BrokerRequestMapper mapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private PaymentPageService paymentPageService;
    @Autowired
    private BrokerRequestMapper brokerRequestMapper;

    private BrokerRequest brokerRequest;
    private BrokerDetails brokerDetails;

    @BeforeEach
    public void setup() {
        brokerRequest = new BrokerRequest();
        brokerRequest.setFcaNumber("215121");
        brokerRequest.setBrokerSurname("Ahmed");
        brokerRequest.setBrokerPostcode("B93 0NH");
        brokerRequest.setBrokerEmail("arif.ahmed@bradleyhall.co.uk");
        brokerRequest.setBrokerForeName("Aaliyah");
        brokerRequest.setBrokerUsername("arif.ahmed");

        brokerDetails = brokerRequestMapper.map(brokerRequest);
    }

    @Test
    public void shouldGetPaymentUrlForTheGivenMortgageRefNumber() throws Exception {

        PaymentRequest request = new PaymentRequest();
        request.setMortgageReferenceNumber("36118429");
        Thread.sleep(WAIT_TIME);
        stubBrokerValidationEndpointWithTrue(brokerDetails);
        stubSuccessfulGetPaymentPageUrl(request, "nwb");

        MvcResult result = mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isOk()).andReturn();

        PaymentUrlResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                PaymentUrlResponse.class);

        assertEquals("http://localhost:8989/payment-page-url", response.getPaymentUrl());

    }

    @Test
    public void shouldThrowInvalidBrokerErrorForTheGivenBrokerDetails() throws Exception {
        PaymentRequest request = new PaymentRequest();
        request.setMortgageReferenceNumber("36118429");
        Thread.sleep(WAIT_TIME);
        stubBrokerValidationEndpointWithFalse(brokerDetails);

        MvcResult result = mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isBadRequest()).andReturn();

        ErrorResponse errorResponse = objectMapper.readValue(result.getResponse().getContentAsString(),
                ErrorResponse.class);

        assertEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus());
    }

    @Test
    public void shouldGetErrorMessageForTheMissingBrokerParam() throws Exception {
        brokerRequest.setBrokerSurname(null);
        PaymentRequest request = new PaymentRequest();
        request.setMortgageReferenceNumber("36118429");
        Thread.sleep(WAIT_TIME);

        MvcResult result = mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isBadRequest()).andReturn();

        ErrorResponse errorResponse = objectMapper.readValue(result.getResponse().getContentAsString(),
                ErrorResponse.class);

        assertEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus());
        assertEquals(1, errorResponse.getErrors().size());

    }

    @Test
    public void shouldGetErrorMessageForBadRequestFromEndpoint() throws Exception {
        PaymentRequest request = new PaymentRequest();
        request.setMortgageReferenceNumber("36118429");
        Thread.sleep(WAIT_TIME);
        stubBrokerValidationEndpointWithTrue(brokerDetails);
        stubBadRequestForGetPaymentPageUrl(request, "nwb");

        MvcResult result = mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isBadRequest()).andReturn();

        ErrorResponse errorResponse = objectMapper.readValue(result.getResponse().getContentAsString(),
                ErrorResponse.class);

        assertTrue(errorResponse.getErrors().get(0).contains(HttpStatus.BAD_REQUEST.getReasonPhrase()));

    }

    @Test
    public void shouldGetErrorMessageForServerErrorFromEndpoint() throws Exception {
        PaymentRequest request = new PaymentRequest();
        request.setMortgageReferenceNumber("36118429");
        Thread.sleep(WAIT_TIME);
        stubBrokerValidationEndpointWithTrue(brokerDetails);
        stubServerErrorForGetPaymentPageUrl(request, "nwb");

        MvcResult result = mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isInternalServerError()).andReturn();

        ErrorResponse errorResponse = objectMapper.readValue(result.getResponse().getContentAsString(),
                ErrorResponse.class);

        assertTrue(errorResponse.getErrors().get(0).contains("Server Error"));

    }

    @Test
    void shouldReturnBadRequestIfBrokerReturns401() throws Exception {
        stubBrokerValidationEndpointWithUnauthorised(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isUnauthorized());

    }

    @Test
    void shouldReturnBadRequestIfBrokerReturns500() throws Exception {
        stubBrokerValidationEndpointWithInternalServerError(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/36118429/get-payment-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(brokerRequest)))
                .andExpect(status().isInternalServerError());

    }
}
