package com.natwest.pbbdhb.worldpay.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.natwest.pbbdhb.broker.exception.InvalidBrokerException;
import com.natwest.pbbdhb.worldpay.model.ErrorMessage;
import com.natwest.pbbdhb.worldpay.model.ErrorResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.Arrays;

import static java.nio.charset.Charset.defaultCharset;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.WARN)
@ExtendWith(MockitoExtension.class)
public class WorldPayExceptionHandlerTest {

    @InjectMocks
    private WorldPayExceptionHandler worldPayExceptionHandler;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RuntimeException runtimeException;

    @Mock
    private NoHandlerFoundException noHandlerFoundException;

    @Mock
    private InvalidFormatException invalidFormatException;

    @Test
    public void expectHttpClientErrorException() throws Exception {

        ErrorResponse mockedErrorResponse = ErrorResponse.builder().errors(Arrays.asList("INTERNAL_SERVER_ERROR"))
                .build();
        HttpClientErrorException httpClientErrorException = HttpClientErrorException
                .BadRequest.create("Internal server error",
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Internal server error", null, objectMapper.writeValueAsBytes(mockedErrorResponse),
                        defaultCharset());
        ResponseEntity<ErrorResponse> responseEntity = worldPayExceptionHandler
                .handleBadRequestException(httpClientErrorException);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @Test
    public void expectHttpServerErrorException() throws Exception {

        ErrorResponse mockedErrorResponse = ErrorResponse.builder().errors(Arrays.asList("INTERNAL_SERVER_ERROR"))
                .build();
        HttpServerErrorException httpServerErrorException = HttpServerErrorException
                .BadGateway.create("Internal server error",
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Internal server error", null, objectMapper.writeValueAsBytes(mockedErrorResponse),
                        defaultCharset());

        when(objectMapper.readValue(anyString(), eq(ErrorResponse.class))).thenReturn(mockedErrorResponse);

        ResponseEntity<ErrorResponse> responseEntity = worldPayExceptionHandler
                .handleBadRequestException(httpServerErrorException);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @Test
    public void expectToHandleRuntimeException() throws Exception {

        ResponseEntity<ErrorResponse> responseEntity = worldPayExceptionHandler
                .handleRuntimeException(runtimeException);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    public void shouldHandleInvalidBrokerException() throws JsonProcessingException {

        ErrorMessage errorMessage = mock(ErrorMessage.class);
        when(errorMessage.getErrorMessage()).thenReturn("Bad Request");

        when(objectMapper.readValue(anyString(), eq(ErrorMessage.class))).thenReturn(errorMessage);

        RestClientResponseException exception = mock(RestClientResponseException.class);
        when(exception.getResponseBodyAsString()).thenReturn("{'errorMessage': 'Error Message'}");
        when(exception.getRawStatusCode()).thenReturn(HttpStatus.BAD_REQUEST.value());

        InvalidBrokerException invalidBrokerException = mock(InvalidBrokerException.class);
        when(invalidBrokerException.getException()).thenReturn(exception);
        when(invalidBrokerException.getHttpStatus()).thenReturn(HttpStatus.BAD_REQUEST);
        when(invalidBrokerException.getMessage()).thenReturn("Bad Request");

        ResponseEntity<ErrorResponse> responseEntity = worldPayExceptionHandler
                .invalidBrokerResponseException(invalidBrokerException, null);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

    }

    @Test
    public void handleHttpMessageNotReadableException() throws JsonProcessingException {

        HttpMessageNotReadableException exception = mock(HttpMessageNotReadableException.class);
        when(exception.getMessage()).thenReturn("Message not readable");

        ResponseEntity<ErrorResponse> responseEntity = worldPayExceptionHandler
                .handleBadRequestException(exception);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void handleBindException() throws JsonProcessingException {

        BindException exception = mock(BindException.class);
        when(exception.getMessage()).thenReturn("Message not readable");

        ResponseEntity<ErrorResponse> responseEntity = worldPayExceptionHandler
                .handleMethodArgumentNotValid(exception, null);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }
}



