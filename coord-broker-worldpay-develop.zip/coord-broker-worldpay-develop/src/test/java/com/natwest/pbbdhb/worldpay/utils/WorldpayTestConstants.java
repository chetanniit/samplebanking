package com.natwest.pbbdhb.worldpay.utils;

public class WorldpayTestConstants {
    public static final String MOCK_MSVC_WORLDPAY_URL = "/worldpay/v1/msvc-worldpay/application";
    public static final String WORLDPAY_END_POINT = "worldpayEndPoint";
}
