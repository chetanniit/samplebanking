package com.natwest.pbbdhb.worldpay.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.worldpay.model.PaymentRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import com.natwest.pbbdhb.worldpay.service.client.PaymentPageClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.WARN)
@ExtendWith(MockitoExtension.class)
public class PaymentPageServiceTest {

    private static final String BRAND = "nwb";

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private BrokerDetails brokerDetails;

    @Mock
    private PaymentRequest paymentRequest;

    @Mock
    private PaymentUrlResponse paymentUrlResponse;

    @Mock
    private PaymentPageClient paymentPageClient;

    @InjectMocks
    private PaymentPageService paymentPageService;

    @Test
    void shouldReturnResponseForValidRequest() throws IOException {

        when(paymentPageClient.getPaymentPageUrl(brokerDetails, paymentRequest, BRAND))
                .thenReturn(paymentUrlResponse);

        PaymentUrlResponse response =
                paymentPageService.getPaymentPageUrl(brokerDetails, paymentRequest, BRAND);

        assertNotNull(response);

    }

    private PaymentUrlResponse getResponseBody() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        String result = new String(Files.readAllBytes(Paths
                .get("src", "test", "resources", "response.json")));
        return mapper.readValue(result, PaymentUrlResponse.class);
    }

}
