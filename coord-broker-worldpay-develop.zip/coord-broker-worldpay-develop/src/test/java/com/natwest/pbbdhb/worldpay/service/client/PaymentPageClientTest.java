package com.natwest.pbbdhb.worldpay.service.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.worldpay.model.PaymentRequest;
import com.natwest.pbbdhb.worldpay.model.PaymentUrlResponse;
import com.natwest.pbbdhb.worldpay.utils.WorldpayTestConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.WARN)
@ExtendWith(MockitoExtension.class)
class PaymentPageClientTest {

    private static final String BRAND = "nwb";

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private BrokerDetails brokerDetails;

    @Mock
    private PaymentRequest paymentRequest;

    @InjectMocks
    private PaymentPageClient paymentPageClient;


    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(paymentPageClient, "worldpayEndPoint",
                "/worldpay/v1/msvc-worldpay/application");
    }

    @Test
    void shouldReturnValidResponseForValidRequest() throws IOException {

        when(restTemplate.postForEntity(eq(WorldpayTestConstants.MOCK_MSVC_WORLDPAY_URL),
                any(HttpEntity.class), any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(getResponseBody()));

        PaymentUrlResponse paymentOrderResponse =
                paymentPageClient.getPaymentPageUrl(brokerDetails, paymentRequest, BRAND);

        assertEquals(getResponseBody().getPaymentUrl(),
                paymentOrderResponse.getPaymentUrl());
    }

    @Test
    void shouldReturn400ResponseForInvalidRequest() {

        PaymentRequest request = new PaymentRequest();
        when(restTemplate.postForEntity(eq(WorldpayTestConstants.MOCK_MSVC_WORLDPAY_URL),
                any(HttpEntity.class), any())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));

        assertThrows(HttpClientErrorException.class, () -> {
            paymentPageClient.getPaymentPageUrl(brokerDetails, request, BRAND);
        });
    }

    private PaymentUrlResponse getResponseBody() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        String result = new String(Files.readAllBytes(Paths
                .get("src", "test", "resources", "response.json")));
        return mapper.readValue(result, PaymentUrlResponse.class);
    }
}

