## Overview

This service provides back-end to the ui for spa of Worldpay Integration.
It expects to receive a URL for given mortgageReferenceNumber.
It passes the response from the service layer back to UI and also provides interface for updating of payment status.


## Build the application
```shell script
mvn clean install
```
## Build the application with sonar
```shell script
mvn clean install sonar:sonar -Dsonar.host.url=https://sonar-3.dts.fm.rbsgrp.net/ -Dsonar.login=your_sonar_token -Dsonar.branch.name=your_branch_name

```

## Running unit tests
```shell script
mvn clean test
```


## Running all tests
```shell script
mvn clean verify -P integration-test
```


## Running the application with the "local" spring profile
```shell script
mvn spring-boot:run
```


## Running the application with Consul in IntelliJ
* Check the profile you want to run with: _dev_, _nft_, _uat_ or _prd_.
* Create a run configuration in IntelliJ and add the environment variables from the relevant env-**xxx**.ini in the pcf-config folder.
* Make sure to use the correct value for _jasypt_encryptor_password_ environment variable.
* Disable gen02 security if required: _des.security.iam.jwt-chain.envelope.jwt-verify-signature=false, des.security.iam.jwt-chain.jwt.verify-signature=false_.
* Application should run successfully


## Running the application independently of Consul
* Check the profile you want to run with: _dev_, _nft_, _uat_ or _prd_.
* Copy the properties from the relevant consul-**xxx**.properties in the consul-properties folder into the relevant application-**xxx**.properties file.
* Disable gen02 security if required: _des.security.iam.jwt-chain.envelope.jwt-verify-signature=false, des.security.iam.jwt-chain.jwt.verify-signature=false_.
* Specifiy the desired profile, e.g. `-Dspring.profiles.active=dev`
* Application should run successfully

## Spring Profiles
* _local_ : This is the default and will be active if no other profile is set.
* _dev_ : This profile is active in when running in the dev environment (set in the service's env variables)
* _nft_ : This profile is active in when running in the nft environment (set in the service's env variables)
* _uat_ : This profile is active in when running in the uat environment (set in the service's env variables)


## Endpoint URLs
* _local_ : `http://localhost:8080/<see controller for the api end points>`
* _dev_ : `https://coord-broker-worldpay-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/payments...`
* _nft_ : `https://coord-broker-worldpay--nft.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/payments...`
* _uat_ : `https://coord-broker-worldpay--uat.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/payments...`

## Actuator endpoint (health & info)
See above for the endpoint URLs for the different environments.
* Health endpoint: Returns service state - `.../actuator/health`
* Info endpoint: Returns build info - `.../actuator/info`

e.g. `http://localhost:8080/mortgages/v1/payments/actuator/health`


## Swagger endpoint (api documentation):
See above for the endpoint URLs for the different environments.
* `.../swagger-ui/index.html`

e.g. `v1-coord-broker-worldpay-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/payments/swagger-ui/index.html`
