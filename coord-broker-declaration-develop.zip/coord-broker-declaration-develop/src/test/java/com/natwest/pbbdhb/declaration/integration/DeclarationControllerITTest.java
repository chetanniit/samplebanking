package com.natwest.pbbdhb.declaration.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.declaration.mapper.BrokerRequestMapper;
import com.natwest.pbbdhb.declaration.model.ApplicationType;
import com.natwest.pbbdhb.declaration.model.BrokerRequest;
import com.natwest.pbbdhb.declaration.model.DeclarationDocument;
import com.natwest.pbbdhb.declaration.model.DeclarationRequest;
import com.natwest.pbbdhb.declaration.utils.EmbeddedS3Extension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@ActiveProfiles("test")
@ExtendWith({EmbeddedS3Extension.class})
class DeclarationControllerITTest extends WireMockIntegrationTest {
    public static final int WAIT_TIME = 2000;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private BrokerRequestMapper mapper;
    @Autowired
    private ObjectMapper objectMapper;

    private DeclarationRequest declarationRequest;
    private BrokerDetails brokerDetails;

    @BeforeEach
    void setup() {
        declarationRequest = new DeclarationRequest();

        BrokerRequest brokerRequest = new BrokerRequest();
        brokerRequest.setFcaNumber("215121");
        brokerRequest.setBrokerSurname("Ahmed");
        brokerRequest.setBrokerPostcode("B93 0NH");
        brokerRequest.setBrokerEmail("arif.ahmed@bradleyhall.co.uk");
        brokerRequest.setBrokerUsername("arifAhmed!");

        declarationRequest.setBroker(brokerRequest);
        declarationRequest.setApplicationType(ApplicationType.DIP);
        declarationRequest.setDocumentKey(DeclarationDocument.CUSTOMER_DECLARATION);

        brokerDetails = mapper.map(declarationRequest.getBroker());
    }

    @Test
    void shouldGetDeclarationContentForGivenRequest() throws Exception {
        stubBrokerValidationEndpointWithTrue(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/get-declaration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs")
                        .content(objectMapper.writeValueAsString(declarationRequest)))
                .andExpect(status().isOk()).andExpect(content().string("Test declaration content"));

    }

    @Test
    void shouldReturnBadRequestIfBrokerIsInvalid() throws Exception {
        stubBrokerValidationEndpointWithFalse(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/get-declaration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs")
                        .content(objectMapper.writeValueAsString(declarationRequest)))
                .andExpect(status().isBadRequest());

    }

    @Test
    void shouldReturnBadRequestIfBrokerReturns401() throws Exception {
        stubBrokerValidationEndpointWithUnauthorised(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/get-declaration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs")
                        .content(objectMapper.writeValueAsString(declarationRequest)))
                .andExpect(status().isUnauthorized());

    }

    @Test
    void shouldReturnBadRequestIfBrokerReturns500() throws Exception {
        stubBrokerValidationEndpointWithInternalServerError(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/get-declaration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs")
                        .content(objectMapper.writeValueAsString(declarationRequest)))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void shouldGetBadRequestIfRequestBodyMissAnyRequiredParams() throws Exception {

        declarationRequest.setDocumentKey(null);
        stubBrokerValidationEndpointWithTrue(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/get-declaration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs")
                        .content(objectMapper.writeValueAsString(declarationRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldGetStorageExceptionIfTryToAccessInvalidDocument() throws Exception {
        declarationRequest.setDocumentKey(DeclarationDocument.KNOW_YOUR_PROPERTY_DECLARATION);

        stubBrokerValidationEndpointWithTrue(brokerDetails);
        Thread.sleep(WAIT_TIME);

        mockMvc.perform(post("/get-declaration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs")
                        .content(objectMapper.writeValueAsString(declarationRequest)))
                .andExpect(status().isNotFound());
    }
}
