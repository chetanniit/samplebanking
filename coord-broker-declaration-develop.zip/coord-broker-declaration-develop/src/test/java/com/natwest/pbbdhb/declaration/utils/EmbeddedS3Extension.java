package com.natwest.pbbdhb.declaration.utils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.natwest.pbbdhb.declaration.configuration.S3Config;
import io.findify.s3mock.S3Mock;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.natwest.pbbdhb.declaration.utils.TestBeanProvider.getBean;

@Slf4j
public class EmbeddedS3Extension implements BeforeAllCallback, AfterAllCallback, BeforeEachCallback {

    private static final int PORT = 8001;
    private final S3Mock s3MockApi = createS3Server(PORT);
    private final AtomicBoolean running = new AtomicBoolean(false);

    public static S3Mock createS3Server(int port) {
        return new S3Mock.Builder().withPort(port).withInMemoryBackend().build();
    }

    private static AmazonS3 getS3Client(ExtensionContext extensionContext) {
        return getBean(extensionContext, AmazonS3.class);
    }

    @Override
    public void beforeAll(ExtensionContext extensionContext) {
        if (isNonLocalhost(extensionContext)) {
            return;
        }

        if (running.get()) {
            return;
        }

        log.info("Starting up s3 mock API.");
        s3MockApi.start();

        running.set(true);
    }

    private static void createBucket(AmazonS3 s3Client, String bucketName) {
        s3Client.createBucket(bucketName);

        boolean bucketCreated = s3Client.listBuckets().stream().anyMatch(b -> bucketName.equalsIgnoreCase(b.getName()));

        if (bucketCreated) {
            log.info("Test bucket [{}] created", bucketName);
            return;
        }
        throw new RuntimeException(String.format("Could not create test bucket [%s]", bucketName));
    }

    private static void uploadFile(AmazonS3 s3Client, String bucketName, String filePath,
                                   String contentType) {
        ObjectMetadata objectMetadata = new ObjectMetadata();
        Resource resource = new ClassPathResource(filePath);
        InputStream inputStream = null;

        try {

            log.info("Uploading file to bucket [{}] to file path [{}]", bucketName, filePath);

            inputStream = resource.getInputStream();
            byte[] bytes = FileCopyUtils.copyToByteArray(inputStream);
            objectMetadata.setContentLength(bytes.length);
            objectMetadata.setContentType(contentType);

            s3Client.putObject(new PutObjectRequest(
                    bucketName,
                    "declaration/rbs/DIP/DIP_CustomerCreation.html",
                    new ByteArrayInputStream(bytes),
                    objectMetadata));

            log.info("File uploaded to bucket [{}]. Uploaded file key: [{}]",
                    bucketName,
                    s3Client.getObject(bucketName, "declaration/rbs/DIP/DIP_CustomerCreation.html").getKey());

        } catch (IOException e) {
            log.error("IO exception while uploading file to bucket");
        }

    }

    private S3Config getS3Config(ExtensionContext extensionContext) {
        return getBean(extensionContext, S3Config.class);
    }

    private boolean isNonLocalhost(ExtensionContext extensionContext) {
        return !getS3Config(extensionContext).getEndPoint().contains("localhost");
    }

    @Override
    public void afterAll(ExtensionContext extensionContext) {
        if (isNonLocalhost(extensionContext)) {
            return;
        }

        if (!running.get()) {
            return;
        }

        log.info("Shutting down s3 mock API.");
        s3MockApi.shutdown();

        running.set(false);
    }

    @Override
    public void beforeEach(ExtensionContext extensionContext) {
        String uploadFileContentType = "text/html";
        String uploadFilePath = "declaration/rbs/DIP/DIP_CustomerCreation.html";


        String bucketName = "localbucket";
        log.info("Setting up test bucket [{}]", bucketName);

        getS3Config(extensionContext).setBucket(bucketName);

        createBucket(getS3Client(extensionContext), bucketName);
        uploadFile(getS3Client(extensionContext), bucketName, uploadFilePath, uploadFileContentType);
    }
}
