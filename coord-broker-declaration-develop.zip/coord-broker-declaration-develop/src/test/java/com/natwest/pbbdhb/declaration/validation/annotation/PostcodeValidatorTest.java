package com.natwest.pbbdhb.declaration.validation.annotation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PostcodeValidatorTest {

    @InjectMocks
    private PostcodeValidator postcodeValidator;

    @Test
    void shouldReturnTrueForValidPostCode() {
        assertTrue(postcodeValidator.isValid("RG41 1BG", null));
    }

    @Test
    void shouldReturnFalseForValidPostCode() {
        assertFalse(postcodeValidator.isValid("123@", null));
    }

    @Test
    void shouldReturnTrueForPostCodeisNull() {
        assertTrue(postcodeValidator.isValid(null, null));
    }
}
