package com.natwest.pbbdhb.declaration.service.impl;

import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DeclarationServiceImplTest {

    @Mock
    private StorageService storageService;

    @InjectMocks
    private DeclarationServiceImpl declarationService;

    private String declarationContentFilePath;

    private BrokerDetails brokerDetails;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(declarationService, "declarationContentFilePath",
                "declaration/%s/%s/%s");
        brokerDetails = mock(BrokerDetails.class);

    }

    @Test
    void shouldGetDeclarationContentForGivenRequest() {
        when(storageService.getDocContent("declaration/rbs/DIP/content.html"))
                .thenReturn("Declaration content for RBS");

        String content = declarationService.getDeclaration(brokerDetails, "rbs", "DIP",
                "content.html");

        assertEquals("Declaration content for RBS", content);
    }

}

