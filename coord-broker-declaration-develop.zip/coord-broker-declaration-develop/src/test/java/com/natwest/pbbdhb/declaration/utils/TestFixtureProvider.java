package com.natwest.pbbdhb.declaration.utils;

import com.amazonaws.services.s3.model.S3Object;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;


@UtilityClass
@Slf4j
public class TestFixtureProvider {

    public static String createString() {
        return UUID.randomUUID().toString();
    }

    public static S3Object createS3Object() {
        S3Object s3Object = new S3Object();

        Resource resource = new ClassPathResource("sample.html");
        InputStream inputStream = null;

        try {
            inputStream = resource.getInputStream();
            byte[] bytes = FileCopyUtils.copyToByteArray(inputStream);
            s3Object.setObjectContent(new ByteArrayInputStream(bytes));
            return s3Object;
        } catch (IOException e) {
            log.error("Error while creating S3Object");
        }
        return s3Object;
    }

}
