package com.natwest.pbbdhb.declaration.utils;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

public class TestBeanProvider {
    private TestBeanProvider() {
    }

    public static <T> T getBean(ExtensionContext extensionContext, Class<T> beanClass) {
        return SpringExtension.getApplicationContext(extensionContext).getBean(beanClass);
    }

    public static <T> T getBeanByName(ExtensionContext extensionContext, Class<T> beanClass, String name) {
        return SpringExtension.getApplicationContext(extensionContext).getBean(name, beanClass);
    }
}
