package com.natwest.pbbdhb.declaration.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.broker.model.validation.response.BrokerDetailResponse;
import com.natwest.pbbdhb.broker.model.validation.response.FirmBroker;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.ok;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.serverError;
import static com.github.tomakehurst.wiremock.client.WireMock.unauthorized;


@ExtendWith(SpringExtension.class)
class WireMockIntegrationTest {

    public static final int PORT = 8089;
    @Autowired
    private ObjectMapper objectMapper;

    private WireMockServer wireMockServer = new WireMockServer(PORT);

    @BeforeEach
    void setUp() throws IOException {
        wireMockServer.start();
    }

    @AfterEach
    void tearDown() {
        wireMockServer.stop();
    }

    protected void stubBrokerValidationEndpointWithTrue(BrokerDetails brokerDetails) throws IOException {
        Set<FirmBroker> brokers = new HashSet<>();
        brokers.add(new FirmBroker("Yes"));

        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        brokerDetailResponse.setBrokers(brokers);

        wireMockServer.stubFor(post("/broker/detail-validate")
                .withHeader("content-type", containing("application/json"))
                .withRequestBody(equalToJson(objectMapper.writeValueAsString(brokerDetails),
                        true, true))
                .willReturn(ok().withHeader("content-type", "application/json")
                        .withBody(objectMapper.writeValueAsString(brokerDetailResponse))));
    }

    protected void stubBrokerValidationEndpointWithFalse(BrokerDetails brokerDetails) throws IOException {
        Set<FirmBroker> brokers = new HashSet<>();
        brokers.add(new FirmBroker("No"));

        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        brokerDetailResponse.setBrokers(brokers);

        wireMockServer.stubFor(post("/broker/detail-validate")
                .withHeader("content-type", containing("application/json"))
                .withRequestBody(equalToJson(objectMapper.writeValueAsString(brokerDetails),
                        true, true))
                .willReturn(ok().withHeader("content-type", "application/json")
                        .withBody(objectMapper.writeValueAsString(brokerDetailResponse))));
    }

    protected void stubBrokerValidationEndpointWithUnauthorised(BrokerDetails brokerDetails) throws IOException {

        wireMockServer.stubFor(post("/broker/detail-validate")
                .withHeader("content-type", containing("application/json"))
                .withRequestBody(equalToJson(objectMapper.writeValueAsString(brokerDetails),
                        true, true))
                .willReturn(unauthorized().withHeader("content-type", "application/json")
                        .withBody("Invalid Broker Params")));
    }

    protected void stubBrokerValidationEndpointWithInternalServerError(BrokerDetails brokerDetails) throws IOException {

        wireMockServer.stubFor(post("/broker/detail-validate")
                .withHeader("content-type", containing("application/json"))
                .withRequestBody(equalToJson(objectMapper.writeValueAsString(brokerDetails),
                        true, true))
                .willReturn(serverError().withHeader("content-type", "application/json")
                        .withBody("Internal Server Error")));
    }


    protected void stubRunTimeException() throws IOException {
        throw new RuntimeException();
    }
}
