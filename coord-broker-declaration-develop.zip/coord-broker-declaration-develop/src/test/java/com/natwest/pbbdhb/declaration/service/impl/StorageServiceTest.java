package com.natwest.pbbdhb.declaration.service.impl;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.natwest.pbbdhb.declaration.configuration.S3Config;
import com.natwest.pbbdhb.declaration.exception.StorageException;
import com.natwest.pbbdhb.declaration.utils.TestFixtureProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class StorageServiceTest {

    @Mock
    private S3Config s3Config;

    @Mock
    private AmazonS3 s3Client;

    @InjectMocks
    private StorageService storageService;


    @Test
    void shouldUsesTheStorageRequestParametersWhenStoringDocument()
            throws StorageException {
        S3Object s3Object = TestFixtureProvider.createS3Object();
        when(s3Client.getObject(any(), anyString())).thenReturn(s3Object);
        String documentContent = storageService.getDocContent(TestFixtureProvider.createString());
        assertFalse(documentContent.isEmpty());
        verify(s3Client).getObject(any(), anyString());
    }

    @Test
    void shouldThrowStorageServiceExceptionIfDocNotFount() {
        AmazonServiceException serviceException = new AmazonServiceException("File not found");
        serviceException.setErrorCode("Ket not found");
        serviceException.setStatusCode(HttpStatus.NOT_FOUND.value());
        when(s3Client.getObject(any(), anyString())).thenThrow(serviceException);

        assertThrows(StorageException.class,
                () -> storageService.getDocContent(TestFixtureProvider.createString()));

    }
}

