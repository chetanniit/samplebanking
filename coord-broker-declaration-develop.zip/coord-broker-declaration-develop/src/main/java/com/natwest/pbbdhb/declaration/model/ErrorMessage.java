package com.natwest.pbbdhb.declaration.model;

import lombok.Data;

@Data
@SuppressWarnings("PMD")
public class ErrorMessage {
    private String errorCode;
    private String errorMessage;
}
