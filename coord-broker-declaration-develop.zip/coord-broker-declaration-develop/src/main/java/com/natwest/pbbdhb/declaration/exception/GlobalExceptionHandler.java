package com.natwest.pbbdhb.declaration.exception;

import com.amazonaws.AmazonServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.exception.InvalidBrokerException;
import com.natwest.pbbdhb.declaration.model.ErrorMessage;
import com.natwest.pbbdhb.declaration.model.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.context.request.WebRequest;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @Autowired
    private ObjectMapper objectMapper;

    @ExceptionHandler(InvalidBrokerException.class)
    public ResponseEntity<ErrorResponse> invalidBrokerResponseException(
            InvalidBrokerException ex, WebRequest request) throws JsonProcessingException {
        if (ex.getException() != null) {
            RestClientResponseException exception = (RestClientResponseException) ex.getException();
            String response = exception.getResponseBodyAsString();
            if (exception.getResponseBodyAsString().contains("errorMessage")) {
                response = objectMapper
                        .readValue(exception.getResponseBodyAsString(), ErrorMessage.class).getErrorMessage();
            }
            ErrorResponse message = new ErrorResponse(Arrays.asList(response));

            HttpStatus httpStatus = HttpStatus.NOT_FOUND.equals(HttpStatus.valueOf(exception.getRawStatusCode()))
                    ? HttpStatus.FORBIDDEN : HttpStatus.valueOf(exception.getRawStatusCode());
            return ResponseEntity.status(httpStatus).body(message);
        }
        ErrorResponse message = new ErrorResponse(Arrays.asList(ex.getMessage()));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @ExceptionHandler(StorageException.class)
    public ResponseEntity<ErrorResponse> handleStorageException(StorageException ex,
                                                                WebRequest request) {
        Throwable throwable = ex.getCause();

        ErrorResponse message = new ErrorResponse(Arrays.asList(ex.getMessage()));

        if (throwable instanceof AmazonServiceException) {
            AmazonServiceException serviceException = (AmazonServiceException) throwable;
            return ResponseEntity.status(HttpStatus.valueOf(serviceException.getStatusCode())).body(message);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> anyRunTimeException(Exception ex, WebRequest request) {
        ErrorResponse message = new ErrorResponse(Arrays.asList(ex.getMessage()));
        log.error("Exception occurred : " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @ExceptionHandler(BindException.class)
    protected ResponseEntity<ErrorResponse> handleMethodArgumentNotValid(BindException ex,
                                                                         WebRequest request) {
        if (ex instanceof MethodArgumentNotValidException) {
            List<ObjectError> fieldErrors = ex.getBindingResult().getAllErrors();

            List<String> errorMessages = fieldErrors.stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.toList());

            ErrorResponse errorResponse = new ErrorResponse(errorMessages);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorResponse(Arrays.asList("Invalid parameters")));
    }

}
