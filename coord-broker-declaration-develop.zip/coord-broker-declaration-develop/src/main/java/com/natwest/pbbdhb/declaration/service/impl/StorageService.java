package com.natwest.pbbdhb.declaration.service.impl;

import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.natwest.pbbdhb.declaration.configuration.S3Config;
import com.natwest.pbbdhb.declaration.exception.StorageException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("PMD")
public class StorageService {

    private final S3Config s3Config;
    private final AmazonS3 s3Client;

    public String getDocContent(String documentFullPath) {
        try {
            log.debug("Retrieving the document from S3 : {}", documentFullPath);
            S3Object s3Object = s3Client.getObject(s3Config.getBucket(), documentFullPath);
            String content = new String(IOUtils.toByteArray(s3Object.getObjectContent()), StandardCharsets.UTF_8);
            log.debug("Content Received from S3 bucket");
            try {
                log.debug("Closing the S3 bucket connection");
                s3Object.close();
            } catch (IOException ex) {
                log.error("Error while closing the S3 connection");
                throw new StorageException("Error while closing the connection", ex);
            }
            return content;
        } catch (SdkClientException | IOException ex) {
            String errorMessage = String.format("Could not retrieve document for the path : {}", documentFullPath);
            log.error("{}", errorMessage);
            throw new StorageException(errorMessage, ex);
        }
    }
}

