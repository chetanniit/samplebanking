package com.natwest.pbbdhb.declaration.model;

public enum ApplicationType {
    DIP, FMA
}
