package com.natwest.pbbdhb.declaration.mapper;

import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.declaration.model.BrokerRequest;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface BrokerRequestMapper {
    BrokerDetails map(BrokerRequest broker);
}
