package com.natwest.pbbdhb.declaration;

import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;


@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Get Declarations API", version = "1.0"))
public class DeclarationApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder()
                .environment(new StandardEncryptableEnvironment())
                .sources(DeclarationApplication.class)
                .run(args);
    }
}
