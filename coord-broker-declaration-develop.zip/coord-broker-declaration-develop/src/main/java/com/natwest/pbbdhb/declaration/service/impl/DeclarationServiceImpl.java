package com.natwest.pbbdhb.declaration.service.impl;

import com.natwest.pbbdhb.broker.annotation.ValidateBrokerDetails;
import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.declaration.service.DeclarationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DeclarationServiceImpl implements DeclarationService {

    private final String declarationContentFilePath;
    private final StorageService storageService;

    public DeclarationServiceImpl(@Value("${msvc.broker.declaration.html.file.path}")
                                          String declarationContentFilePath,
                                  StorageService storageService) {
        this.declarationContentFilePath = declarationContentFilePath;
        this.storageService = storageService;
    }

    @Override
    @ValidateBrokerDetails
    public String getDeclaration(BrokerDetails brokerDetails, String brand, String applicationType,
                                 String documentKey) {
        String documentPath = String.format(declarationContentFilePath, brand, applicationType,
                documentKey);
        log.debug("Getting the document for the path : {}", documentPath);

        return storageService.getDocContent(documentPath);
    }
}
