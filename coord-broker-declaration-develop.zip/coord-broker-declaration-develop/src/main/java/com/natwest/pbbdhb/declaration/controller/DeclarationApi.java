package com.natwest.pbbdhb.declaration.controller;

import com.natwest.pbbdhb.declaration.model.Brand;
import com.natwest.pbbdhb.declaration.model.DeclarationRequest;
import com.natwest.pbbdhb.declaration.model.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.context.request.NativeWebRequest;

import jakarta.validation.Valid;
import java.util.Optional;

@SuppressWarnings("PMD")
public interface DeclarationApi {

  String BAD_REQUEST_ERROR = "{\"errors\":[\"fcaNumber cannot be null or empty\"]}";
  String SAMPLE_HTML = "<html>sample</html>";
  String UNAUTHORISED_ERROR = "{\"errors\":[\"Unauthorized\"]}";
  String FORBIDDEN_ERROR = "{\"errors\":[\"Forbidden\"]}";
  String NOT_FOUND_ERROR = "{\"errors\":[\"Resource Not Found.\"]}";
  String METHOD_NOT_ALLOWED_ERROR = "{\"errors\":[\"Method Not Allowed\"]}";
  String UNSUPPORTED_MEDIA_TYPE_ERROR = "{\"errors\":[\"Unsupported Media Type\"]}";
  String INTERNAL_SERVER_ERROR = "{\"errors\":[\"Our backend is non-functional, please try again later\"]}";
  String SERVICE_NOT_AVAILABLE_ERROR = "{\"errors\":[\"Service not available\"]}";

  default Optional<NativeWebRequest> getRequest() {
    return Optional.empty();
  }

  /**
   * Get Declaration
   *
   * @param brand           (required)
   * @param brokerRequest   (required)
   * @return OK (status code 200) or Not Found (status code 404)
   */
  @Operation(summary = "Get Declarations", operationId = "getDeclaration")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "400", description = "Bad Request", content = {@Content(mediaType =
                  MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ErrorResponse.class),
                  examples = {@ExampleObject(value = BAD_REQUEST_ERROR)})}),
          @ApiResponse(responseCode = "200", description = "OK", content = {@Content(mediaType =
                  MediaType.TEXT_HTML_VALUE,
                  examples = {@ExampleObject(value = SAMPLE_HTML)})}),
          @ApiResponse(responseCode = "401", description = "Not Authorised", content = {@Content(mediaType =
                  MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ErrorResponse.class),
                  examples = {@ExampleObject(value = UNAUTHORISED_ERROR)})}),
          @ApiResponse(responseCode = "403", description = "Forbidden", content =
                  {@Content(mediaType =
                          MediaType.APPLICATION_JSON_VALUE,
                          schema = @Schema(implementation = ErrorResponse.class),
                          examples = {@ExampleObject(value = FORBIDDEN_ERROR)})}),
          @ApiResponse(responseCode = "404", description = "Resource not found", content = {@Content(mediaType =
                  MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ErrorResponse.class),
                  examples = {@ExampleObject(value = NOT_FOUND_ERROR)})}),
          @ApiResponse(responseCode = "405", description = "Method Not Allowed", content =
                  {@Content(mediaType =
                          MediaType.APPLICATION_JSON_VALUE,
                          schema = @Schema(implementation = ErrorResponse.class),
                          examples = {@ExampleObject(value = METHOD_NOT_ALLOWED_ERROR)})}),
          @ApiResponse(responseCode = "415", description = "Unsupported Media Type", content = {@Content(mediaType =
                  MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ErrorResponse.class),
                  examples = {@ExampleObject(value = UNSUPPORTED_MEDIA_TYPE_ERROR)})}),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = {@Content(mediaType =
                  MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ErrorResponse.class),
                  examples = {@ExampleObject(value = INTERNAL_SERVER_ERROR)})}),
          @ApiResponse(responseCode = "503", description = "Service not available", content = {@Content(mediaType =
                  MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ErrorResponse.class),
                  examples = {@ExampleObject(value = SERVICE_NOT_AVAILABLE_ERROR)})})
  })

  @PostMapping(value = "/get-declaration",
          consumes = MediaType.APPLICATION_JSON_VALUE,
          produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_HTML_VALUE})
  default ResponseEntity<String> getDeclaration(
          @Valid @Parameter(description = "Brand", example = "nwb")
          @RequestHeader(value = "brand", required = true) Brand brand,
          @Valid @RequestBody DeclarationRequest brokerRequest) {
    return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

  }
}
