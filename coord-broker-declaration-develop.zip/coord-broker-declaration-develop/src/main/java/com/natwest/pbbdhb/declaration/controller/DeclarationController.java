package com.natwest.pbbdhb.declaration.controller;

import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;
import com.natwest.pbbdhb.declaration.mapper.BrokerRequestMapper;
import com.natwest.pbbdhb.declaration.model.Brand;
import com.natwest.pbbdhb.declaration.model.DeclarationRequest;
import com.natwest.pbbdhb.declaration.service.DeclarationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@Tag(name = "Get Declaration")
@Validated
@RequiredArgsConstructor
@Slf4j
public class DeclarationController implements DeclarationApi {

    private final DeclarationService declarationService;
    private final BrokerRequestMapper mapper;

    @Override
    public ResponseEntity<String> getDeclaration(Brand brand, DeclarationRequest declarationRequest) {

        log.debug("Request Received for brand : {} and declaration request : {}", brand.name(),
                declarationRequest.toString());
        BrokerDetails brokerDetails = Objects.nonNull(declarationRequest.getBroker())
                ? mapper.map(declarationRequest.getBroker()) : new BrokerDetails();
        return new ResponseEntity<>(declarationService.getDeclaration(brokerDetails, brand.name(),
                declarationRequest.getApplicationType().name(),
                declarationRequest.getDocumentKey().getDocumentName()), HttpStatus.OK);
    }
}
