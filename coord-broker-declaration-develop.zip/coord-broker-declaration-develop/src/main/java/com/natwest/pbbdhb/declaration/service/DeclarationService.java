package com.natwest.pbbdhb.declaration.service;

import com.natwest.pbbdhb.broker.model.validation.BrokerDetails;

public interface DeclarationService {

    String getDeclaration(BrokerDetails brokerDetails, String brand, String applicationType,
                          String documentKey);
}
