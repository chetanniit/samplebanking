package com.natwest.pbbdhb.declaration.configuration;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.client.builder.AwsClientBuilder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
@Getter
@SuppressWarnings("PMD")
public class S3Config {
    @Value("${s3.client.accessKey:#{null}}")
    private String accessKey;

    @Value("${s3.client.secretKey:#{null}}")
    private String secretKey;

    @Value("${s3.client.endPoint:#{null}}")
    private String endPoint;

    @Value("${s3.client.bucket:#{null}}")
    @Setter
    private String bucket;

    @Value("${s3.client.pathPrefix:#{null}}")
    private String pathPrefix;

    @Value("${s3.client.protocol:HTTPS}")
    private Protocol protocol;

    @Value("${s3.client.connectTimeout:5000}")
    private int connectionTimeout;

    @Value("${s3.client.connectTTL:60000}")
    private long connectionTTL;

    @Value("${s3.client.maxIdle:60000}")
    private long maxIdle;

    @Value("${s3.client.validateIdle:5000}")
    private int validateIdle;

    @Value("${s3.client.reaper:true}")
    private boolean reaper;

    @Value("${s3.client.maxConnections:50}")
    private int maxConnections;

    @Value("${s3.client.requestTimeout:0}")
    private int requestTimeout;

    @Value("${s3.client.socketTimeout:50000}")
    private int socketTimeout;

    @Value("${s3.client.throttleRetries:true}")
    private boolean throttleRetries;

    @Value("${s3.client.useCompression:false}")
    private boolean useCompression;

    @Value("${s3.client.tcpKeepalive:true}")
    private boolean isTcpKeepalive;

    @Value("${s3.client.maxErrorRetry:3}")
    private int maxErrorRetry;

    @Bean
    @ConditionalOnClass(value = StorageConfig.class)
    public ClientConfiguration getClientConfiguration() {
        return new ClientConfiguration()
                .withProtocol(protocol)
                .withConnectionMaxIdleMillis(maxIdle)
                .withValidateAfterInactivityMillis(validateIdle)
                .withConnectionTimeout(connectionTimeout)
                .withConnectionTTL(connectionTTL)
                .withMaxConnections(maxConnections)
                .withReaper(reaper)
                .withGzip(useCompression)
                .withThrottledRetries(throttleRetries)
                .withRequestTimeout(requestTimeout)
                .withSocketTimeout(socketTimeout)
                .withTcpKeepAlive(isTcpKeepalive)
                .withMaxErrorRetry(maxErrorRetry);
    }

    @Bean
    public AwsClientBuilder.EndpointConfiguration getEndpointConfiguration() {
        return new AwsClientBuilder.EndpointConfiguration(endPoint, null);
    }
}
