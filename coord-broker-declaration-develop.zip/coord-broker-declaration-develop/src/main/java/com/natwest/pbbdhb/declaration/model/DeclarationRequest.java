package com.natwest.pbbdhb.declaration.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;


@ToString
@EqualsAndHashCode
@Setter
@Getter
@SuppressWarnings("PMD")
public class DeclarationRequest {

    @Schema
    @NotNull(message = "Broker cannot be null or empty")
    @Valid
    private BrokerRequest broker;

    @Schema(example = "FMA")
    @NotNull(message = "Application type cannot be null or empty")
    private ApplicationType applicationType;

    @Schema(example = "KNOW_YOUR_PROPERTY_DECLARATION")
    @NotNull(message = "Document key cannot be null or empty")
    private DeclarationDocument documentKey;

    @NotNull(message = "Application type cannot be null or empty")
    public ApplicationType getApplicationType() {
        return applicationType;
    }

    @NotNull(message = "Document key cannot be null or empty")
    public DeclarationDocument getDocumentKey() {
        return documentKey;
    }
}
