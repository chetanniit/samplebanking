package com.natwest.pbbdhb.declaration.configuration;

import io.swagger.v3.oas.models.info.Info;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;


@Configuration
public class SwaggerConfiguration {

    @Value("${declaration.contract.version}")
    private String contractVersion;


    @Bean
    public GroupedOpenApi declarationDataApi() {
        return GroupedOpenApi.builder()
                .group("DECLARATION-API").addOpenApiCustomizer(openApi -> openApi.setInfo(new Info()
                        .title("Get Declarations API")
                        .description("Declaration API Specification")
                        .version(getVersion()))).build();
    }

    private String getVersion() {
        return String.format("v1 / %s / Contract %s", buildProperties().getVersion(), contractVersion);
    }
    @Bean
    public BuildProperties buildProperties() {
        return new BuildProperties(new Properties());
    }
}
