package com.natwest.pbbdhb.declaration.model;

@SuppressWarnings("PMD")
public enum Brand {
    nwb, rbs
}
