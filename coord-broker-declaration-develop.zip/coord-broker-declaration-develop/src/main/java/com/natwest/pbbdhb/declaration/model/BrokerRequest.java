package com.natwest.pbbdhb.declaration.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

@Getter
@Setter
@SuppressWarnings("PMD")
public class BrokerRequest {

    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9.!#$%'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";

    @Schema(example = "728734", minLength = 4, maxLength = 7,
            description = "Must contain numeric value, fcaNumber allows max 7 characters and min 4 characters",
            required = true)
    @Pattern(regexp = "[0-9]{4,7}+", message = "fcaNumber is invalid or contains "
        + "less than 4 characters or more than 7 characters")
    @NotEmpty(message = "FCA Number is required")
    private String fcaNumber;

    @Schema(example = "Hanif", description = "Broker surname, maximum 50 characters", required = true, minLength = 2,
            maxLength = 50)
    @NotEmpty(message = "Broker surname is required")
    @Pattern(regexp = "^[A-Za-z0-9 .'-]{2,50}+$", message = "brokerSurname is "
        + "invalid or contains less than 2 characters or more than 50 characters")
    private String brokerSurname;

    @Schema(example = "LincolnAbraham", minLength = 2, maxLength = 100)
    @Length(min = 2, max = 100, message = "brokerUsername has to be between 2 and 100 characters")
    private String brokerUsername;

    @Schema(example = "Aaliyah", description = "Broker ForeName, maximum 50 characters", minLength = 2, maxLength = 50)
    @Pattern(regexp = "^[A-Za-z0-9 .'-]{2,50}+$", message = "brokerForeName is "
        + "invalid or contains less than 2 characters or more than 50 characters")
    private String brokerForeName;

    @Schema(example = "B23 6SN", description = "Broker postcode maximum 8 characters", maxLength = 8)
    @Pattern(regexp = "^([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})"
        + "|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9]?[A-Za-z])))) [0-9][A-Za-z]{2})$",
            message = "brokerPostcode is invalid")
    private String brokerPostcode;

    @Schema(example = "aaliyah.hanif@mab.org.uk", maxLength = 72,
            description = "Email address for Broker, maximum characters 72", required = true)
    @Pattern(regexp = EMAIL_PATTERN, message = "Please enter valid email Id for Broker")
    @NotEmpty(message = "Email address for Broker is required")
    private String brokerEmail;

    public String getFcaNumber() {
        return fcaNumber;
    }

    public String getBrokerPostcode() {
        return brokerPostcode;
    }

    public String getBrokerSurname() {
        return brokerSurname;
    }

    public String getBrokerEmail() {
        return brokerEmail;
    }

    public String getBrokerUsername() {
        return brokerUsername;
    }

    public String getBrokerForeName() {
        return brokerForeName;
    }
}
