package com.natwest.pbbdhb.declaration.configuration;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StorageConfig {

    @Bean
    public AmazonS3 getAmazonS3Client(ClientConfiguration configuration,
                                      AwsClientBuilder.EndpointConfiguration endpointConfiguration,
                                      S3Config s3Config) {

        return AmazonS3ClientBuilder.standard()
                .withClientConfiguration(configuration)
                .withEndpointConfiguration(endpointConfiguration)
                .withCredentials(new AWSStaticCredentialsProvider(
                        new BasicAWSCredentials(s3Config.getAccessKey(), s3Config.getSecretKey())))
                .enablePathStyleAccess()
                .build();
    }
}
