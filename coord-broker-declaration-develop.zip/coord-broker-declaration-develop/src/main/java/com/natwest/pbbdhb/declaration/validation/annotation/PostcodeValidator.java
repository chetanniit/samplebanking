package com.natwest.pbbdhb.declaration.validation.annotation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;


public class PostcodeValidator implements ConstraintValidator<Postcode, String> {

    public static final String VALID_POSTCODE_REGEX =
            "([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|"
                    + "(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\\s?[0-9]"
                    + "[A-Za-z]{2})";

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        if (value != null) {
            String regexp = "^[a-zA-Z0-9 ]+$";
            return Pattern.compile(regexp).matcher(value).matches();
        }
        return true;
    }
}
