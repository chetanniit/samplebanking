package com.natwest.pbbdhb.declaration.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@SuppressWarnings("PMD")
public enum DeclarationDocument {
    CUSTOMER_DECLARATION("DIP_CustomerCreation.html"),
    INTERMEDIARY_DECLARATION("DIP_IntermediaryDeclaration.html"),
    KNOW_YOUR_PROPERTY_DECLARATION("FMA_KnowYourProperty.html"),
    FMA_SUBMISSION_DECLARATION("FMA_Submission.html"),
    DIRECT_DEBT_GUARANTEE("FMA_DirectDebtGuarantee.html"),
    FMA_SUBMISSION_DECLARATION_NAPOLI("NAPOLI_FMA_Submission.html"),
    FMA_NOCONSENT_UK_WITHHOLDING_TAX("FMA_Submission_UKWHT_NC.html"),
    FMA_CONSENT_UK_WITHHOLDING_TAX("FMA_Submission_UKWHT_C.html"),
    FMA_NOT_APPLICABLE_WITHHOLDING_TAX("FMA_Submission_WHT_NA.html"),
    FMA_APPLICABLE_NON_UK_WITHHOLDING_TAX("FMA_Submission_NonUKWHT_A.html");
    private String documentName;
}
