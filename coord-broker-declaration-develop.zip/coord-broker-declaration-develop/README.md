# Spring Boot Integration Declaration microservice

## Brief Overview :
Microservice manage storing declaration data.

## Build the application
```shell script
mvn clean install
```

## Running unit tests
```shell script
run 'TESTS and REPORTS' idea configuration
or
mvn clean test
```

## Running all tests
```shell script
mvn clean verify -P integration-test
```

## Running the application with the "local" spring profile
```shell script
run 'SpringBoot-RUN' idea configuration
or
mvn spring-boot:run
```

## Endpoints documented via Swagger
```shell script
http://localhost:8080/swagger-ui/index.html
```
