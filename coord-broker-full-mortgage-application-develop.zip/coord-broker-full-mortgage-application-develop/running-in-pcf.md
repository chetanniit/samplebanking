# Running in PCF

## References
* [Confluence: PCF Deployment Detail](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/PCF+Deployment+Detail)
* [Confluence: PCF Operations using pcf.sh](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/PCF+Operations+using+pcf.sh)
* [Confluence: PCF Operations using DWS](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/PCF+Operations+using+DWS)
* [Confluence: Deploying a release in PCF or backing out a release](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/Deploying+a+release+in+PCF+or+backing+out+a+release)
* [Confluence: Managing the service lifecyle in RBS PCF](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/Managing+the+service+lifecyle+in+RBS+PCF+-+please+contribute)
* [Confluence: How to set command line arguments for a service in PCF](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/How+to+set+command+line+arguments+for+a+service+in+PCF)
* [Confluence: How to deploy a SNAPSHOT or feature branch build to PCF](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/How+to+deploy+a+SNAPSHOT+or+feature+branch+build+to+PCF)
* [Confluence: Digital Platform (PCF) Technical Notes](https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/Digital+Platform+%28PCF%29+Technical+Notes)


## To see all script options
```shell script
cd .../pcf-config
./scripts/pcf.sh --help
./scripts/deploy.sh --help
```

## To ensure required scripts are available and up to date
```shell script
cd .../msvc-project
git pull
git submodule update --init
git submodule foreach git pull origin master
```

---
## Service Management

### To create the service in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh create-app dev 
```
 
### To create the service's routes in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh create-route dev
```

### To map the service's routes in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh map-route dev
```

### To "deploy" the latest version, stop the current and start the deployed version of a service in the pcf dev space
```shell script
cd .../pcf-config
./scripts/deploy.sh dev LATEST
```
 
### To "deploy" version 1.2.3, stop the current and start the deployed version of a service in the pcf dev space
```shell script
cd .../pcf-config
./scripts/deploy.sh dev 1.2.3
```
 
### To just "deploy" the latest version of a service in the pcf dev space (must stop and start the service to take effect)
```shell script
cd .../pcf-config
./scripts/pcf.sh deploy-app dev -V LATEST
```

### To start the service in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh action-start dev
``` 

### To stop the service in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh action-stop dev
``` 
 
### To restage the service in the pcf dev space, i.e. rebuild the container image (e.g. after an env file change)
```shell script
cd .../pcf-config
./scripts/pcf.sh action-restage dev
``` 

### To get details of the service in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh get-app dev
``` 

### To update the service (memory, quota, buildpack, etc) in the pcf dev space
```shell script
cd .../pcf-config
./scripts/pcf.sh update-app dev
``` 
