# Spring Boot MicroService - coord-dip-to-fma


## Brief Overview :


## Build the application
```shell script
mvn clean install
```


## Running unit tests
```shell script
mvn clean test
```


## Running all tests
```shell script
mvn clean verify -P integration-test
```


## Running the application with the "local" spring profile
```shell script
mvn spring-boot:run
```


## Running the application with Consul in IntelliJ
* Check the profile you want to run with: _dev_, _uat_ or _prd_.
* Create a run configuration in IntelliJ and add the environment variables from the relevant env-**xxx**.ini in the pcf-config folder.
* Make sure to use the correct value for _jasypt_encryptor_password_ environment variable.
* Disable gen02 security if required: _des.security.iam.jwt-chain.envelope.jwt-verify-signature=false, des.security.iam.jwt-chain.jwt.verify-signature=false_.
* Application should run successfully


## Running the application independently of Consul
* Check the profile you want to run with: _dev_, _uat_ or _prd_.
* Copy the properties from the relevant consul-**xxx**.properties in the consul-properties folder into the relevant application-**xxx**.properties file.
* Disable gen02 security if required: _des.security.iam.jwt-chain.envelope.jwt-verify-signature=false, des.security.iam.jwt-chain.jwt.verify-signature=false_.
* Specify the desired profile, e.g. `-Dspring.profiles.active=dev`
* Application should run successfully


## Security
We have integrated gen02 pattern for security and it needs iam-claimsetjwt token when sending a request.  
For details see: http://dp.apps.prod-pcf.lb1.rbsgrp.net/pages/documents/jwt-chain-intro   
To disable gen02 security see: https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/Temporarily+disabling+gen02+security


## Spring Profiles
* _local_ : This is the default and will be active if no other profile is set.   
* _dev_ : This profile is active in when running in the dev environment (set in the service's env variables)
* _uat_ : This profile is active in when running in the uat environment (set in the service's env variables)
* _nft_ : This profile is active in when running in the nft environment (set in the service's env variables)
* _prd_ : This profile is active in when running in the prd environment (set in the service's env variables)


## Endpoint URLs

## Actuator endpoint (health & info)

## Swagger endpoint (api documentation:

## Deploying, running and managing the service in PCF
See **_running-in-pcf.md_**


## Access via Postman
Gen02 security (see **Security** section above) means that a JWT must be presented in an http header when calling a service
using Postman (unless gen02 has been fully disabled). 


## Database details


## Splunk URL details


## Consul URL:
API End Point: `https://ecomm.fm.rbsgrp.net/v1/kv/application/PBBDHB/<env>/`  
UI URL: `https://ecomm.fm.rbsgrp.net/ui/#/corenet-prd/kv/application/PBBDHB/<env>/`  
_where \<env\> is dev, uat or prd_  
Calling the Consul API using Postman: https://confluence.dts.fm.rbsgrp.net/display/PBBDHB/Calling+the+Consul+API+using+Postman
