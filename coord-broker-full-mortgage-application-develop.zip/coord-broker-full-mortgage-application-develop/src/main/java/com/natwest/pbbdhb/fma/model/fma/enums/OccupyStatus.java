package com.natwest.pbbdhb.fma.model.fma.enums;

public enum OccupyStatus {
    OWNER_MORTGAGED, OWNER_NO_MORTGAGE, LIVING_WITH_RELATIVES, OTHER, TENANT
}
