package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.ChapsFeeType;
import com.natwest.pbbdhb.fma.model.fma.enums.ProductFeeType;
import com.natwest.pbbdhb.fma.model.fma.enums.ProductMortgageType;
import com.natwest.pbbdhb.fma.model.fma.enums.ProductTerm;
import com.natwest.pbbdhb.fma.model.fma.enums.ProductType;
import com.natwest.pbbdhb.fma.model.fma.enums.ValuationFeeType;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class ProductDetails {

    @Schema(required = true, maxLength = 12)
    @Length(max = 12)
    @NotBlank(message = "cannot be null or empty")
    private String productCode;

    @Schema(required = true, implementation = ProductType.class)
    @NotNull
    private ProductType productType;

    @Schema(required = true, implementation = ProductTerm.class)
    @NotNull
    private ProductTerm productTerm;

    @Schema(implementation = ValuationFeeType.class, description = "Required if isPortingProduct is false or null")
    @SmartRequired(
            conditions = @SmartCondition(path = "isPortingProduct", values = "false", nullOrEmpty = true),
            message = "required if isPortingProduct is false or null"
    )
    private ValuationFeeType valuationFeesPayType;

    @Schema(implementation = ProductFeeType.class, description = "Required if isPortingProduct is false or null")
    @SmartRequired(
            conditions = @SmartCondition(path = "isPortingProduct", values = "false", nullOrEmpty = true),
            message = "required if isPortingProduct is false or null"
    )
    private ProductFeeType productFeesPayType;

    @Schema(implementation = ChapsFeeType.class, description = "Required if isPortingProduct is false or null")
    @SmartRequired(
            conditions = @SmartCondition(path = "isPortingProduct", values = "false", nullOrEmpty = true),
            message = "required if isPortingProduct is false or null"
    )
    private ChapsFeeType chapsFeesPayType;

    @Schema(minimum = "0", maximum = "100", multipleOf = 0.01, example = "85",
            description = "Required if isPortingProduct is false or null. Percentage.")
    @SmartRequired(
            conditions = @SmartCondition(path = "isPortingProduct", values = "false", nullOrEmpty = true),
            message = "required if isPortingProduct is false or null"
    )
    @Digits(integer = 999, fraction = 2, message = "accepts up to two decimal places")
    @DecimalMin("0")
    @DecimalMax("100")
    private BigDecimal ltv;

    @Schema(example = "false", allowableValues = {"true", "false"},
            description = "Specify if the product is porting product or not. Mustn't be supplied if loanPurpose isn't HOUSE_PURCHASE.")
    @SmartValidation(conditions = {
            @SmartCondition(path = "/loanPurpose", values = "HOUSE_PURCHASE", negate = true),
            @SmartCondition(path = "<field>", nullOrEmpty = true, negate = true)
    }, message = "mustn't be supplied if loanPurpose isn't HOUSE_PURCHASE")
    private Boolean isPortingProduct;

    @Schema(minLength = 5, maxLength = 300,
            description = "Provide porting product information, Required if isPortingProduct is true. Mustn't be supplied if loanPurpose isn't HOUSE_PURCHASE.",
            example = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.")
    @Size(min = 5, max = 300, message = "should be between 5 and 300 characters long")
    @SmartValidation(conditions = {
            @SmartCondition(path = "/loanPurpose", values = "HOUSE_PURCHASE", negate = true),
            @SmartCondition(path = "<field>", nullOrEmpty = true, negate = true)
    }, message = "mustn't be supplied if loanPurpose isn't HOUSE_PURCHASE")
    @SmartRequired(
            conditions = @SmartCondition(path = "isPortingProduct", values = "true"),
            message = "is required if isPortingProduct is true"
    )
    private String portingNotes;

    @Schema(implementation = ProductMortgageType.class, example = "FIRST_TIME_BUYER",
            description = "Required if isPortingProduct is false or null")
    @SmartRequired(
            conditions = @SmartCondition(path = "isPortingProduct", values = "false", nullOrEmpty = true),
            message = "required if isPortingProduct is false or null"
    )
    private ProductMortgageType mortgageType;


}
