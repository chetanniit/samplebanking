package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;

import java.util.Collection;
import java.util.List;

/**
 * Supports check for any object of a class implementing Collection interface<br>
 * Supported operators: {@code ==, =, !=, <>, <, <=, >, >=}<br>
 * Supported values: constant or path as "path:path_to_other_field"<br>
 * Usage example: {@code @SmartCondition(path = "listField", values = {">=", "100"}, smartCheck =
 * SmartCollectionSizeCheck.class)}<br>
 * Usage example: {@code @SmartCondition(path = "setField", values = {">=", "path:../some/field"}, smartCheck =
 * SmartCollectionSizeCheck.class)}
 */
public class SmartCollectionSizeCheck extends AbstractSmartComparableCheck<Object> {

    @Override
    public boolean check(Object actualValue, List<String> conditionValues, SmartContext smartContext) {
        String operator = conditionValues.get(0).trim();
        String toCompare = conditionValues.get(1).trim();
        Object valueToCompare = toCompare.startsWith("path:")
                ? smartContext.getValue(toCompare.substring(5).trim()) : toCompare;
        Integer value = !(actualValue instanceof Collection) ? null : ((Collection<?>) actualValue).size();
        return compare(value, operator, valueToCompare);
    }

}
