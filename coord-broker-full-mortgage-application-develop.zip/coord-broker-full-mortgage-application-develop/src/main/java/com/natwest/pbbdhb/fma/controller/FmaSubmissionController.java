package com.natwest.pbbdhb.fma.controller;

import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.model.error.ErrorResponse;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.service.FmaSubmissionService;
import com.natwest.pbbdhb.fma.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.util.Collections;
import java.util.List;

@RestController
@Slf4j
public class FmaSubmissionController {

    @Autowired
    private FmaSubmissionService fmaSubmissionService;

    @Autowired
    private LocalValidatorFactoryBean localValidatorFactoryBean;

    @Autowired
    private ExecutionContext executionContext;

    @Operation(summary = "Full Mortgage Application", operationId = "full-mortgage-application", tags = {
            "Full Mortgage Application API" }, responses = {
                    @ApiResponse(responseCode = "200", description = "Success", content = {
                            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = FmaResponse.class)) }),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorResponse.class)) }),
                    @ApiResponse(responseCode = "401", description = "Not Authorised", content = { @Content() }),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = { @Content() }),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = { @Content() }),
                    @ApiResponse(responseCode = "422", description = "Unprocessable Entity", content = { @Content() }),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                            @Content() }) })

    @PostMapping(path = "/full-mortgage-application", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @SuppressWarnings("ConstantConditions")
    private FmaResponse fmaSubmission(
            @RequestBody Application application,
            @RequestHeader(Constants.CLIENT_ID) String clientId,
            @RequestHeader(Constants.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
            BindingResult bindingResult) throws MethodArgumentNotValidException {

        log.info("fmaSubmission called");
        log.debug("fmaSubmission: called with application={}", application);
        log.debug("fmaSubmission: called with brand  ={}", brand);

        executionContext.init(application);

        // TODO Remove this WA after postcode regex alignment across all services
        alignPostcodes(application);

        List<Validator> validatorList = Collections.singletonList(localValidatorFactoryBean);

        for (Validator validator : validatorList) {
            validator.validate(application, bindingResult);
            if (bindingResult != null && !CollectionUtils.isEmpty(bindingResult.getAllErrors())) {
                MethodParameter methodParameter = new MethodParameter(ReflectionUtils.findMethod(this.getClass(),
                        "fmaSubmission", Application.class, String.class, String.class, BindingResult.class), 0);

                throw new MethodArgumentNotValidException(methodParameter, bindingResult);
            }
        }

        FmaResponse fmaResponse = fmaSubmissionService.performFmaSubmission(application, clientId, brand);
        log.debug("fmaSubmission: completed with fmaResponse={}", fmaResponse);
        log.info("MI: Success {}", executionContext.toString().replaceAll("(\\s*[\\n\\r]\\s*)+", "\\\\n "));
        return fmaResponse;
    }

    private void alignPostcodes(Application application) {
        if (application == null) {
            return;
        }
        // broker.brokerPostcode
        if (application.getBroker() != null && application.getBroker().getBrokerPostcode() != null) {
            application.getBroker().setBrokerPostcode(
                    fixPostcode(application.getBroker().getBrokerPostcode())
            );
        }
        // solicitor.postcode
        if (application.getSolicitor() != null && application.getSolicitor().getPostcode() != null) {
            application.getSolicitor().setPostcode(
                    fixPostcode(application.getSolicitor().getPostcode())
            );
        }
        // estateAgent.address.postcode
        if (application.getEstateAgent() != null && application.getEstateAgent().getAddress() != null
                && application.getEstateAgent().getAddress().getPostcode() != null) {
            application.getEstateAgent().getAddress().setPostcode(
                    fixPostcode(application.getEstateAgent().getAddress().getPostcode())
            );
        }
        // property.address.postcode
        if (application.getProperty() != null && application.getProperty().getAddress() != null
                && application.getProperty().getAddress().getPostcode() != null
                && !Boolean.TRUE.equals(application.getScottishApplication())
                && !Boolean.TRUE.equals(application.getNorthernIrelandApplication())) {
            application.getProperty().getAddress().setPostcode(
                    fixPostcode(application.getProperty().getAddress().getPostcode())
            );
        }
        // mortgage.otherProperties.address.postcode
        if (application.getMortgage() != null && application.getMortgage().getOtherProperties() != null) {
            application.getMortgage().getOtherProperties().forEach(otherProperty -> {
                if (otherProperty != null && otherProperty.getAddress() != null
                        && "GB".equals(otherProperty.getAddress().getCountryIsoCode())
                        && otherProperty.getAddress().getPostcode() != null) {
                    otherProperty.getAddress().setPostcode(fixPostcode(otherProperty.getAddress().getPostcode()));
                }
            });
        }

        if (application.getApplicants() != null) {
            application.getApplicants().forEach(applicant -> {
                if (applicant == null) {
                    return;
                }
                // applicants.addresses.postcode
                if (applicant.getAddresses() != null) {
                    applicant.getAddresses().forEach(address -> {
                        if (address != null && "GB".equals(address.getCountryIsoCode())
                                && address.getPostcode() != null) {
                            address.setPostcode(fixPostcode(address.getPostcode()));
                        }
                    });
                }
                // applicants.employments.address.postcode
                if (applicant.getEmployments() != null) {
                    applicant.getEmployments().forEach(employment -> {
                        if (employment != null && employment.getAddress() != null
                                && "GB".equals(employment.getAddress().getCountryIsoCode())
                                && employment.getAddress().getPostcode() != null) {
                            employment.getAddress().setPostcode(fixPostcode(employment.getAddress().getPostcode()));
                        }
                    });
                }
            });
        }
    }

    private String fixPostcode(String postcode) {
        if (postcode == null || postcode.matches(Constants.UK_POSTCODE_PATTERN)) {
            return postcode;
        }
        String fixedPostcode = postcode.replaceFirst("([0-9][A-Za-z]{2})$", " $1");
        return fixedPostcode.matches(Constants.UK_POSTCODE_PATTERN) ? fixedPostcode : postcode;
    }

}
