package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import com.natwest.pbbdhb.fma.dto.PatchDto;
import com.natwest.pbbdhb.fma.mapper.cases.CaseMapper;
import com.natwest.pbbdhb.fma.mapper.cases.HardscoreMapper;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.service.CapieUpdateService;
import com.natwest.pbbdhb.fma.service.CaseService;
import com.natwest.pbbdhb.openapi.fma.HardscoreDecision;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.json.JsonPatch;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class CapieUpdateServiceImpl implements CapieUpdateService {
    @Autowired
    private HardscoreMapper mapper;
    @Autowired
    private CaseService caseService;
    @Autowired
    private CaseMapper caseMapper;

    @Override
    public void updateCase(FmaResponse response, String brand, String caseId) {

        updateFmaCase(response, caseId, brand);

    }

    private void updateFmaCase(FmaResponse response, String caseId, String brand) {
        List<PatchDto> patches = new ArrayList<>();
        // TODO This may change in future based on change what needs to update
        HardscoreDecision hardscoreDecision = mapper.toHardScoreDecision(response.getHardscoreDecision());
        if (null != hardscoreDecision) {
            PatchDto hardscoreDecisionPatch = PatchDto.builder().path("/hardscoreDecision")
                    .operation(JsonPatch.Operation.REPLACE).value(hardscoreDecision).build();
            patches.add(hardscoreDecisionPatch);
        }

        if (!CollectionUtils.isEmpty(response.getProducts())) {
            List<ProductDetailsDto> products = caseMapper.mapProductDetails(response.getProducts());
            PatchDto productsPatch = PatchDto.builder().path("/salesIllustrations/" + 0 + "/products")
                    .operation(JsonPatch.Operation.REPLACE).value(products).build();
            patches.add(productsPatch);
        }

        
		if (null != response.getApplSeq()) {
			PatchDto mortgageApplSeqPatch = PatchDto.builder().path("/mortgageApplSeq")
					.operation(JsonPatch.Operation.REPLACE).value(response.getApplSeq()).build();
			patches.add(mortgageApplSeqPatch);

			PatchDto mortgageApplSalesIllusPatch = PatchDto.builder()
					.path("/salesIllustrations/" + 0 + "/mortgageApplSeq").operation(JsonPatch.Operation.REPLACE)
					.value(response.getApplSeq()).build();
			patches.add(mortgageApplSalesIllusPatch);
		}
         

        if (null != response.getMortgageNumber()) {
            PatchDto mortgageReferenceNumberPatch = PatchDto.builder().path("/mortgageReferenceNumber")
                    .operation(JsonPatch.Operation.REPLACE).value(response.getMortgageNumber()).build();
            patches.add(mortgageReferenceNumberPatch);
        }

        if (null != response.getTempReferenceNumber()) {
            PatchDto tempRefNumberPatch = PatchDto.builder().path("/mortgageTempReferenceNumber")
                    .operation(JsonPatch.Operation.REPLACE).value(response.getTempReferenceNumber()).build();
            patches.add(tempRefNumberPatch);
        }
        patches.add(prepareStatusPatch(response));
        caseService.patch(brand, caseId, patches);
        log.info("case data for caseId: {} updated successfully", caseId);
    }

    private PatchDto prepareStatusPatch(FmaResponse response) {
        PatchDto.PatchDtoBuilder statusPatch = PatchDto.builder().path("/applicationStatus")
                .operation(JsonPatch.Operation.REPLACE);
        if ("201".equalsIgnoreCase(response.getStatus())) {
            statusPatch.value(ApplicationStatus.SUBMIT_GMS_STAGE_20.name());
        } else {
            statusPatch.value(ApplicationStatus.SUBMIT_FMA_IN_PROGRESS.name());
        }

        return statusPatch.build();
    }

}