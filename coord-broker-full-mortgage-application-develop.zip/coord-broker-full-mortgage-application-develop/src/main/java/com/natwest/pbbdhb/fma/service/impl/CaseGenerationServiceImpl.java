package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.fma.model.fma.Applicant;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.service.CaseGenerationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class CaseGenerationServiceImpl implements CaseGenerationService {

    @Value("${caseid.generate.endpoint}")
    private String endPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public String generateCaseId(String brand, Application application, String clientId) {
        log.info("generateCaseId: called");
        String caseIdPrefix = getCaseIdPrefix(application);
        log.debug("generateCaseId: called with brand={}, caseIdPrefix={}, clientId={}", brand, caseIdPrefix, clientId);
        log.debug("generateCaseId  endpoint called = {}", endPointUrl);
        HttpHeaders applicationHeaders = createHttpHeaders(brand);
        final HttpEntity requestEntity = new HttpEntity<>(null, applicationHeaders);
        String response = null;
        try {
            response = restTemplate.exchange(endPointUrl + "?caseIdPrefix=" + caseIdPrefix + "&clientId=" + clientId,
                    HttpMethod.GET, requestEntity, String.class).getBody();
            log.debug("Generated Case id : {} completed", response);
        } catch (RestClientException exception) {
            if (log.isErrorEnabled()) {
                log.error("RestClientException occurred for generateCaseId : {}", exception.getMessage());
            }
            throw exception;
        }
        return response;
    }

    private HttpHeaders createHttpHeaders(String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND_HEADER, brand);
        return headers;
    }

    private String getCaseIdPrefix(Application application) {
        Applicant applicant = application.getApplicants().iterator().next();
        String lastName = applicant.getPersonalDetails().getLastName();
        String firstName = applicant.getPersonalDetails().getFirstNames();
        return "BRK" + getFirstNCharacter(lastName, 5)
                + getFirstNCharacter(firstName, 3);

    }

    private String getFirstNCharacter(String name, int length) {
        name = name.replaceAll("[^a-zA-Z1-9]", "");
        return name.substring(0, Math.min(name.length(), length));
    }

}
