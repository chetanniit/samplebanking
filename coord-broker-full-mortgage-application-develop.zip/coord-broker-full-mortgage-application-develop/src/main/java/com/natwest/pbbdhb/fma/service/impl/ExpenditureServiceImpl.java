package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.fma.service.ExpenditureService;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class ExpenditureServiceImpl implements ExpenditureService {

    @Value("${expenditure.endpoint}")
    private String expenditureEndPoint;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public ValidatedCaseExpenseDto createExpense(String caseId, String brand, ValidatedCaseExpenseDto expenseRequest) {
        log.debug("Expense creation called with brand : {}", brand);
        HttpHeaders httpHeaders = createHttpHeaders(brand);
        ResponseEntity<ValidatedCaseExpenseDto> responseEntity = restTemplate.exchange(expenditureEndPoint, HttpMethod.PUT,
                new HttpEntity<>(expenseRequest, httpHeaders), ValidatedCaseExpenseDto.class, caseId);
        if (log.isDebugEnabled()) {
            log.debug("Expense creation Case id : {}, Http Status code ={}, createExpense completed", caseId,
                    responseEntity.getStatusCode());
        }
        return responseEntity.getBody();
    }

    private HttpHeaders createHttpHeaders(String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND_HEADER, brand);
        return headers;
    }
}
