package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ProductMortgageType {
    FIRST_TIME_BUYER, PURCHASE, PURCHASE_SHARED_EQUITY, PURCHASE_H2B_SHARED_EQUITY, REMORTGAGE, REMORTGAGE_H2B_SHARED_EQUITY, ADBO
}
