package com.natwest.pbbdhb.fma.model.fma.enums;

public enum OtherPropertyMortgageRepaymentType {
    REPAYMENT, INTEREST_ONLY, MIXED
}
