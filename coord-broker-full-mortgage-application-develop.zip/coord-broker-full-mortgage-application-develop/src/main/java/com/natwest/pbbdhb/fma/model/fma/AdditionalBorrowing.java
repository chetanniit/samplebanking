package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.ADBORepaymentType;
import com.natwest.pbbdhb.fma.model.fma.enums.AdditionalBorrowingReason;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class AdditionalBorrowing {

    @Schema(example = "10000", required = true, minimum = "1", maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @Digits(integer = 999, fraction = 0 , message = "must be integer")
    @DecimalMin("1")
    @DecimalMax("99999999")
    @NotNull
    private BigDecimal amount;

    @Schema(implementation = AdditionalBorrowingReason.class, required = true)
    @NotNull
    private AdditionalBorrowingReason reason;

    @Schema(description = "required if reason is OTHER or OTHER_DEBT_CONSOLIDATION", maxLength = 150)
    @SmartRequired(conditions = @SmartCondition(path = "reason", values = {"OTHER", "OTHER_DEBT_CONSOLIDATION"}))
    @Size(max = 150)
    private String borrowingDetails;

    @Schema(implementation = ADBORepaymentType.class,
            description = "Required if mortgage.mortgageType is MIXED")
    @SmartRequired(conditions = @SmartCondition(path = "../mortgageType", values = "MIXED"))
    private ADBORepaymentType adboRepaymentType;

}
