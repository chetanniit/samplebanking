package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.PropertyType;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartNumberCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class BasicProperty {

    @Schema(required = true)
    @Valid
    @NotNull
    private UkOrScottishOrNIAddress address;

    @Schema(implementation = PropertyType.class, required = true, example = "HOUSE_NEW_BUILD", description = "Should be one of BUNGALOW_NEW_BUILD, HOUSE_NEW_BUILD, HOUSE_NEW_BUY, FLAT_NEW_BUILD, FLAT_NEW_BUY if builderIncentive is greater than zero")
    @SmartValidation(conditions = {
            @SmartCondition(path = "builderIncentive", values = { ">", "0" }, smartCheck = SmartNumberCheck.class),
            @SmartCondition(path = "type", negate = true, values = {
                    "BUNGALOW_NEW_BUILD", "HOUSE_NEW_BUILD", "HOUSE_NEW_BUY", "FLAT_NEW_BUILD", "FLAT_NEW_BUY"
            })
    }, message = "should be one of BUNGALOW_NEW_BUILD, HOUSE_NEW_BUILD, HOUSE_NEW_BUY, FLAT_NEW_BUILD, FLAT_NEW_BUY")
    @NotNull
    private PropertyType type;

    @Schema(required = true, description = "must be equal or greater then 1", example = "3", pattern = "^0*([1-9]|[1-9][0-9])$")
    @Pattern(regexp = "^0*([1-9]|[1-9][0-9])$")
    @NotBlank(message = "cannot be null or empty")
    private String numberBedrooms;

}
