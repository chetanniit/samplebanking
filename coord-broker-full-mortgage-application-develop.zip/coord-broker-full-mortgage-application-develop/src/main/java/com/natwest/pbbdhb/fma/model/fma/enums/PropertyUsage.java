package com.natwest.pbbdhb.fma.model.fma.enums;

public enum PropertyUsage {
    RESIDENTIAL, CONSENT_TO_LET, BUY_TO_LET
}
