package com.natwest.pbbdhb.fma.context;

import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailResponse;
import com.natwest.pbbdhb.fma.model.brokervalidation.FirmBroker;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.Broker;
import com.natwest.pbbdhb.fma.util.ModelUtils;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationResponse;
import com.natwest.pbbdhb.openapi.fma.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
@Scope(scopeName = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ExecutionContext {

    private static ApplicationContext applicationContext;

    private String lastDownstreamEndpoint;
    private final Map<String, String> contextMap = new LinkedHashMap<>();

    public static ExecutionContext getInstance() {
        return applicationContext.getBean(ExecutionContext.class);
    }

    public void init(Application application) {
        contextMap.put("brokerUsername", ModelUtils.safeGet(application, Application::getBroker, Broker::getBrokerUsername));
        contextMap.put("brokerFcaNumber", ModelUtils.safeGet(application, Application::getBroker, Broker::getFcaNumber));
        contextMap.put("brokerEmail", ModelUtils.safeGet(application, Application::getBroker, Broker::getBrokerEmail));
        contextMap.put("dipId", ModelUtils.safeGet(application, Application::getDipId));
    }

    public void setBrokerDetail(BrokerDetailResponse brokerDetail) {
        FirmBroker firmBroker = ModelUtils.safeGet(
                brokerDetail,
                BrokerDetailResponse::getBrokers,
                Set::stream,
                Stream::findFirst,
                o -> o.orElse(null)
        );
        contextMap.put("brokerFirmName", ModelUtils.safeGet(firmBroker, FirmBroker::getFirmName,
                firmName -> "\"" + firmName.trim().replaceAll("\"", "'") + "\""));
    }

    public void setFmaResponse(FullMortgageApplicationExtendedResponse fmaResponse) {
        contextMap.put("mortgageNumber", ModelUtils.safeGet(fmaResponse, FullMortgageApplicationResponse::getData, ResponseData::getMortgageNumber));
        contextMap.put("tempRefNo", ModelUtils.safeGet(fmaResponse, FullMortgageApplicationResponse::getData, ResponseData::getTempRefNo));
    }

    public void setLastDownstreamEndpoint(String lastDownstreamEndpoint) {
        this.lastDownstreamEndpoint = lastDownstreamEndpoint;
    }

    public String getLastDownstreamEndpoint() {
        return lastDownstreamEndpoint;
    }

    @Override
    public String toString() {
        return "{" + contextMap.entrySet().stream()
                .filter(e -> e.getValue() != null)
                .map(e ->  e.getKey() + "=" + e.getValue())
                .sorted()
                .collect(Collectors.joining(", ")) + "}";
    }

    @Autowired
    private void setApplicationContext(ApplicationContext applicationContext) {
        ExecutionContext.applicationContext = applicationContext;
    }

}
