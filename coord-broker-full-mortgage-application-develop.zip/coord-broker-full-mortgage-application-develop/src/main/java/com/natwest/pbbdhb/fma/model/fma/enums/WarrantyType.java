package com.natwest.pbbdhb.fma.model.fma.enums;

public enum WarrantyType {
    BUILDERS_OWN, FOUNDATION_15, NEW_BUILD, NHBC_CERTIFICATE, OTHER
}
