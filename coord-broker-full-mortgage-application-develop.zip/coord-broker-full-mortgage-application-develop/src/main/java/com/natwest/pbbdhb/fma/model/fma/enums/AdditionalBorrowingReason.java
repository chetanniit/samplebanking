package com.natwest.pbbdhb.fma.model.fma.enums;

public enum AdditionalBorrowingReason {
    HOME_IMPROVEMENT, HOUSE_PURCHASE, HOLIDAY, BUY_NEW_CAR, BUY_USED_CAR, DEBT_CONSOLIDATION, OTHER, OTHER_DEBT_CONSOLIDATION
}
