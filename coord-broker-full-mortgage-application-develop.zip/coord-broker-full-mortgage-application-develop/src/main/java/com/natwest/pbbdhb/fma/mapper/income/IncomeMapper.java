package com.natwest.pbbdhb.fma.mapper.income;

import com.natwest.pbbdhb.income.expense.model.enums.CaseStage;
import com.natwest.pbbdhb.income.expense.model.enums.YesNo;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.OtherIncomeDetailsDto;
import com.natwest.pbbdhb.income.expense.model.income.response.IncomeApplicantDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.Applicant.WorkStatusEnum;
import com.natwest.pbbdhb.openapi.fma.Employment;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import com.natwest.pbbdhb.openapi.fma.OtherIncome;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class IncomeMapper {

    private final JobDetailsMapper detailsMapper;
    private final OtherIncomeMapper otherIncomeMapper;

    public ValidatedCaseIncomeDto convertToIncomeRequest(FullMortgageApplicationRequest fmaRequest,
            Map<Applicant, String> applicantToId) {
        AtomicInteger index = new AtomicInteger(1);
        List<IncomeApplicantDto> incomeApplicants = fmaRequest.getApplicants().stream().map(
                applicant -> convertToIncomeApplicant(applicant, applicantToId.get(applicant), index.getAndIncrement()))
                .collect(Collectors.toList());
        return ValidatedCaseIncomeDto.builder().stage(CaseStage.FMA).applicants(incomeApplicants).build();
    }

    private IncomeApplicantDto convertToIncomeApplicant(Applicant applicant, String id, Integer index) {
        return IncomeApplicantDto.builder().applicantId(id)
                // .excludedIncomeReason("string") field is not available in the jar.
                .sourceOfIncomeVerification(YesNo.N).sickPay(YesNo.N)
                // .breakInEmploymentInLastSixMonths(YesNo.N)//TODO Discussion req how to get this
                .primaryJob(buildPrimaryJobDetails(applicant, index))
                .additionalJobDetails(buildOtherJobDetails(applicant, index))
                .otherIncome(buildOtherIncomeDetails(applicant.getOtherIncomes()))
                // .sickPayImpact(YesNo.No)
                // .sickPayImpactExplanation("string")
                .build();
    }

    private JobDetailsDto buildPrimaryJobDetails(Applicant applicant, Integer index) {
        if (applicant.getEmployments() == null) {
            return null;
        }
        JobDetailsDto details = applicant.getEmployments().stream().filter(Employment::getPrimary).findFirst()
                .flatMap(employment -> Optional.of(applicant.getWorkStatus().equals(WorkStatusEnum.WORKING)
                        ? detailsMapper.toPrimaryJob(employment) : detailsMapper.toJobDetailsNotWorking(employment)))
                .orElse(null);
        if (details != null) {
            details.setJobId("Applicant_" + index + "_" + "JOBID_1");
        }
        return details;
    }

    private List<JobDetailsDto> buildOtherJobDetails(Applicant applicant, Integer applicantIndex) {
        if (applicant.getEmployments() == null) {
            return new ArrayList<>();
        }
        List<JobDetailsDto> jobDetails = applicant.getEmployments().stream().filter(employment -> !employment.getPrimary())
                .map(applicant.getWorkStatus().equals(WorkStatusEnum.WORKING) ? detailsMapper::toPrimaryJob
                        : detailsMapper::toJobDetailsNotWorking)
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(jobDetails)) {
            AtomicInteger index = new AtomicInteger(2);
            jobDetails.forEach((jd) -> {
                jd.setJobId("Applicant_" + applicantIndex + "_" + "JOBID" + "_" + index.getAndIncrement());
            });
        }
        return jobDetails;
    }

    private Map<String, OtherIncomeDetailsDto> buildOtherIncomeDetails(List<OtherIncome> otherIncomes) {
        AtomicInteger index = new AtomicInteger(1);
        if (null != otherIncomes && otherIncomes.size() > 0) {
            return otherIncomes.stream().map(o -> otherIncomeMapper.mapOtherIncome(o)).collect(
                    Collectors.toMap(o -> index.getAndIncrement() + "_" + o.getSourceOfIncome().toString(), o1 -> o1));
        }
        return new HashMap<>();
    }
}
