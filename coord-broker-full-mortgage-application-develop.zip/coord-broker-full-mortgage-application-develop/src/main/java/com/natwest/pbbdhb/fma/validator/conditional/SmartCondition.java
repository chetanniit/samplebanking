package com.natwest.pbbdhb.fma.validator.conditional;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * See conditions() field description of {@link SmartRequired}
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.ANNOTATION_TYPE })
public @interface SmartCondition {

    /**
     * Path to field to be checked.<br>
     * If the path starts with '/' then search is performed from the root object annotated with
     * {@link SmartConditionalRoot} otherwise the search is performed relatively to the current field container
     * node.<br>
     * . means current node<br>
     * .. means parent node<br>
     * {@code <field>} means annotated field<br>
     * [?] means 'any of array elements'<br>
     * [*] means 'all of array elements'<br>
     * example: ../mortgage/additionalBorrowing[?]/reason
     *
     * @return string representing the path
     **/
    String path();

    /**
     * Array of values to be matched as 'any of'
     *
     * @return values to check against fields found by path()
     **/
    String[] values() default {};

    /**
     * If true then null or empty value of fields found by path() meets the condition<br>
     * If false then no check is performed, to make condition to check if the field is not empty please use combination
     * of nullOrEmpty() = true and negate() = true
     *
     * @return true if null or empty value meets the condition
     **/
    boolean nullOrEmpty() default false;

    /**
     * Class to perform some complex check. Must have default constructor.<br>
     * Values obtained by the path field are passed into the check method of the class.
     *
     * @return class to perform some complex check
     **/
    Class<? extends SmartCheck<?>> smartCheck() default SmartCheck.VoidCheck.class;

    /**
     * If true the result of the condition is inverted.<br>
     * <br>
     * Example: if values() is empty and nullOrEmpty() is set to true and negate() is set to true then the condition is
     * met when fields found by path() are not null or empty.<br>
     * <br>
     * Has no influence on path array quantifiers, so @SmartCondition(path = "arr[?]", values = "X", negate = true) is
     * false when at least 'one of' array values is equal to "X" and true otherwise
     *
     * @return true to revert condition behavior
     **/
    boolean negate() default false;

}
