package com.natwest.pbbdhb.fma.model.fma.enums;

public enum Provider {
    RBS, NATWEST, OTHER;

}
