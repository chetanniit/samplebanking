package com.natwest.pbbdhb.fma.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.service.FmaService;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.model.fma.ResponseStatus;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class FmaServiceImpl implements FmaService {
    public static final String CLIENT_ID = "client_id";

    @Value("${fma.endpoint}")
    private String endPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ExecutionContext executionContext;

    @Override
    public FullMortgageApplicationExtendedResponse submitFma(FullMortgageApplicationRequest request, String brand,
            String clientId) {
        log.info("submitFma: called");
        log.debug("submitFma: called with = {}", request);
        log.debug("submitFma  endpoint called = {}", endPointUrl);
        log.debug("submitFma  brand = {}", brand);
        HttpHeaders applicationHeaders = createHttpHeaders(brand, clientId);
        FullMortgageApplicationExtendedResponse fullMortgageApplicationResponse;
        ResponseEntity<FullMortgageApplicationExtendedResponse> responseEntity;
        try {
            responseEntity = restTemplate.postForEntity(endPointUrl, new HttpEntity<>(request, applicationHeaders),
                    FullMortgageApplicationExtendedResponse.class);
        } catch (HttpClientErrorException exception) {
            try {
                responseEntity = new ResponseEntity(
                        objectMapper.readValue(exception.getResponseBodyAsString(),
                                FullMortgageApplicationExtendedResponse.class),
                        exception.getResponseHeaders(), HttpStatus.OK);
            } catch (Exception e) {
                throw exception;
            }
            if (isErrorResponse(responseEntity) && !isHardscoreDeclineCase(exception, responseEntity)) {
                throw exception;
            }
        }
        fullMortgageApplicationResponse = responseEntity.getBody();
        executionContext.setFmaResponse(fullMortgageApplicationResponse);
        final String httpStatus = String.valueOf(responseEntity.getStatusCodeValue());
        fullMortgageApplicationResponse.setResponseStatus(new ResponseStatus(httpStatus));
        return fullMortgageApplicationResponse;
    }

    private boolean isErrorResponse(ResponseEntity<FullMortgageApplicationExtendedResponse> responseEntity) {
        return responseEntity == null || responseEntity.getBody() == null || responseEntity.getBody().getData() == null
                || responseEntity.getBody().getErrors() != null && !responseEntity.getBody().getErrors().isEmpty();
    }

    private boolean isHardscoreDeclineCase(HttpClientErrorException exception,
            ResponseEntity<FullMortgageApplicationExtendedResponse> responseEntity) {
        return HttpStatus.BAD_REQUEST.equals(exception.getStatusCode()) && responseEntity.getBody() != null
                && responseEntity.getBody().getData() != null
                && responseEntity.getBody().getData().getHardscoreDecision() != null
                && "DECLINE".equals(responseEntity.getBody().getData().getHardscoreDecision().getDecision());
    }

    private HttpHeaders createHttpHeaders(String brand, String clientId) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND_HEADER, brand);
        headers.add(CLIENT_ID, clientId);
        return headers;
    }
}
