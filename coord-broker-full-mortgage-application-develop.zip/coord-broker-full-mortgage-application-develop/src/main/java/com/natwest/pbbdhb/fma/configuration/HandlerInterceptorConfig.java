package com.natwest.pbbdhb.fma.configuration;

import com.natwest.pbbdhb.fma.interceptor.HeartbeatInterceptor;
import com.natwest.pbbdhb.fma.interceptor.MethodInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class HandlerInterceptorConfig implements WebMvcConfigurer {

    @Autowired
    private MethodInterceptor methodInterceptor;

    @Autowired
    private HeartbeatInterceptor heartbeatInterceptor;

    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(methodInterceptor);
        registry.addInterceptor(heartbeatInterceptor);
    }

}
