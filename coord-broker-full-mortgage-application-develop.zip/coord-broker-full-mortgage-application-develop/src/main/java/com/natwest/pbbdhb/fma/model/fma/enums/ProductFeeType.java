package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ProductFeeType {
    PAY_UPFRONT, ADD_CAPITALISE_TO_LOAN, NO_FEE
}
