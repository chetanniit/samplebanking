package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;

public interface FmaService extends BaseService {
    FullMortgageApplicationExtendedResponse submitFma(FullMortgageApplicationRequest request, String brand,
            String clientId);
}
