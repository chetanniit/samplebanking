package com.natwest.pbbdhb.fma.mapper.property;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.openapi.fma.PropertyDetails;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.mapstruct.Mapper;

@Mapper(config = MappingConfig.class)
public interface PropertyMapper {

    PropertyDetailsDto toPropertyDetails(PropertyDetails property, String caseId);

}
