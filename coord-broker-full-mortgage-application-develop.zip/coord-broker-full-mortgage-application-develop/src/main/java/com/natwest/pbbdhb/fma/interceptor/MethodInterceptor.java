package com.natwest.pbbdhb.fma.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Arrays;

@Component
@Slf4j
public class MethodInterceptor implements HandlerInterceptor {

    private static final String[] ALLOWED_METHODS = new String[] { "PUT", "POST", "GET", "OPTIONS" };

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        log.debug("Inside Method Interceptor");
        if (Arrays.stream(ALLOWED_METHODS).noneMatch(x -> x.equals(request.getMethod()))) {
            response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            response.setHeader("Allow", "PUT, POST, GET, OPTIONS");
            response.setContentType("message/http");

            return false;
        }
        return true;
    }
}
