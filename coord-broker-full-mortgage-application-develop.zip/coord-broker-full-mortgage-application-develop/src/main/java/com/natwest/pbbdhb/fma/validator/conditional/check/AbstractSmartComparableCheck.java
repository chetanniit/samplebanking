package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.validator.conditional.SmartCheck;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Comparator;

public abstract class AbstractSmartComparableCheck<T> implements SmartCheck<T> {

    /**
     * @param actualValue some kind of number or null
     * @param operator one of {@code ==, =, !=, <>, <, <=, >, >=}
     * @param valueToCompareWith some kind of number or null
     * @return result of comparison
     */
    protected boolean compare(Object actualValue, String operator, Object valueToCompareWith) {
        return compareInternal(actualValue, operator, valueToCompareWith, null);
    }

    /**
     * @param actualValue value to compare
     * @param operator one of {@code ==, =, !=, <>, <, <=, >, >=}
     * @param valueToCompareWith value to compare with
     * @param comparator comparator to use
     * @return result of comparison
     */
    protected boolean compare(T actualValue, String operator, T valueToCompareWith, Comparator<T> comparator) {
        return compareInternal(actualValue, operator, valueToCompareWith, comparator);
    }

    private boolean compareInternal(Object actualValue, String operator, Object valueToCompareWith, Comparator<T> comparator) {

        int comparisonResult;

        if (comparator == null) {
            BigDecimal valueToCompare = normalize(valueToCompareWith);
            BigDecimal value = normalize(actualValue);
            comparisonResult = value != null && valueToCompare != null
                    ? value.compareTo(valueToCompare) : 0;
        } else {
            comparisonResult = actualValue != null && valueToCompareWith != null
                    ? comparator.compare((T) actualValue, (T) valueToCompareWith) : 0;
        }

        switch (operator) {
            case "=":
            case "==":
                return (actualValue == null && valueToCompareWith == null)
                        || (actualValue != null && valueToCompareWith != null && comparisonResult == 0);
            case "!=":
            case "<>":
                return (actualValue == null && valueToCompareWith != null) || (actualValue != null && valueToCompareWith == null)
                        || (actualValue != null && comparisonResult != 0);
            case ">":
                return actualValue != null && valueToCompareWith != null && comparisonResult > 0;
            case ">=":
                return actualValue != null && valueToCompareWith != null && comparisonResult >= 0;
            case "<":
                return actualValue != null && valueToCompareWith != null && comparisonResult < 0;
            case "<=":
                return actualValue != null && valueToCompareWith != null && comparisonResult <= 0;
            default:
                throw new IllegalArgumentException("Incorrect Operator");
        }
    }

    private BigDecimal normalize(Object value) {
        if (value == null || BigDecimal.class.isAssignableFrom(value.getClass())) {
            return (BigDecimal) value;
        } else if (BigInteger.class.isAssignableFrom(value.getClass())) {
            return new BigDecimal((BigInteger) value);
        } else if (Number.class.isAssignableFrom(value.getClass())) {
            return BigDecimal.valueOf(((Number) value).doubleValue());
        } else {
            String stringValue = value.toString().replaceAll("\\s", "");
            return !".".equals(stringValue) && stringValue.matches("[+\\-]?\\d*(\\.\\d*)?")
                    ? new BigDecimal(stringValue)
                    : null;
        }
    }

}
