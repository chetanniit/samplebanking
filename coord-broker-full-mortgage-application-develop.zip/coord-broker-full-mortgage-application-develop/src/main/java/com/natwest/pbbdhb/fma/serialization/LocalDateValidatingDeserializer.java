package com.natwest.pbbdhb.fma.serialization;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatterBuilder;

public class LocalDateValidatingDeserializer extends JsonDeserializer<LocalDate> implements ContextualDeserializer {

    private final LocalDateDeserializer localDateDeserializer;

    public LocalDateValidatingDeserializer() {
        this(null);
    }

    private LocalDateValidatingDeserializer(String pattern) {
        if (StringUtils.isBlank(pattern)) {
            this.localDateDeserializer = new LocalDateDeserializer(new DateTimeFormatterBuilder().toFormatter());
        } else {
            this.localDateDeserializer = new LocalDateDeserializer(new DateTimeFormatterBuilder().appendPattern(pattern).toFormatter());
        }
    }

    @Override
    public LocalDate deserialize(JsonParser parser, DeserializationContext context) throws IOException {
        try {
            return localDateDeserializer.deserialize(parser, context);
        } catch (JsonMappingException e) {
            throw new DeserializationValidationException("has incorrect format", parser);
        }
    }

    @Override
    public JsonDeserializer<?> createContextual(DeserializationContext deserializationContext, BeanProperty beanProperty) throws JsonMappingException {
        JsonFormat jsonFormat = beanProperty.getAnnotation(JsonFormat.class);
        String pattern = jsonFormat == null ? null : jsonFormat.pattern();
        return new LocalDateValidatingDeserializer(pattern);
    }

}
