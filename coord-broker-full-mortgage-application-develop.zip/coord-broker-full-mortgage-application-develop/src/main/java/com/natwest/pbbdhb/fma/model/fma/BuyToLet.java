
package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.IcrTaxRate;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class BuyToLet {

    @Schema(example = "300", minimum = "1", maximum = "99999999", multipleOf = 1, description = "Required if useLettingAgent = true, No decimal places")
    @SmartRequired(
            conditions = @SmartCondition(path = "useLettingAgent", values = "true"),
            message = "required if useLettingAgent = true"
    )
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin("1")
    @DecimalMax("99999999")
    private BigDecimal lettingAgentCost;

    @Schema(minimum = "1", maximum = "8000000", example = "1000", multipleOf = 1, description = "No decimal places", required = true)
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "8000000")
    @DecimalMin(value = "1")
    @NotNull
    private BigDecimal monthlyRentalIncome;

    @Schema(example = "true", allowableValues = { "true", "false" }, required = true)
    @NotNull
    private Boolean useLettingAgent;

    @Schema(implementation = IcrTaxRate.class, required = true, example = "HIGH")
    @NotNull
    private IcrTaxRate icrTaxRate;

    @Schema(example = "false", allowableValues = { "true", "false" }, required = true,
            description = "If \"true\" is selected, then this application cannot proceed as a buy to let and must be progressed as a second residential purchase/remortgage.")
    @SmartValidation(conditions = {
            @SmartCondition(path = "isRentingToImmediateFamilyMember", values = "true"),
            @SmartCondition(path = "/type", values = "BUY_TO_LET")
    }, message = "is \"true\" therefore application cannot proceed as a buy to let and must be progressed as a second residential purchase/remortgage")
    @NotNull
    private Boolean isRentingToImmediateFamilyMember;

    @Schema(example = "true", allowableValues = { "true", "false" }, required = true,
            description = "If \"false\" is selected, then it indicates Consumer Buy to Let borrowing status which is not supported at this stage. The application cannot proceed.")
    @SmartValidation(conditions = {
            @SmartCondition(path = "isForInvestment", values = "false"),
            @SmartCondition(path = "/type", values = "BUY_TO_LET")
    }, message = "is \"false\" and indicates Consumer Buy to Let borrowing status which is not supported at this stage. The application cannot proceed.")
    @NotNull
    private Boolean isForInvestment;

    @Schema(example = "true", allowableValues = { "true", "false" }, required = true,
            description = "If \"false\", then cannot proceed with application.")
    @SmartValidation(conditions = {
            @SmartCondition(path = "isAssuredShortHoldOrShortAssured", values = "false"),
            @SmartCondition(path = "/type", values = "BUY_TO_LET")
    }, message = "is \"false\" therefore the application cannot proceed")
    @NotNull
    private Boolean isAssuredShortHoldOrShortAssured;

    @Schema(example = "true", allowableValues = { "true", "false" }, required = true,
            description = "If \"false\", then cannot procced with application.")
    @SmartValidation(conditions = {
            @SmartCondition(path = "isNotSelectiveLicenceOrHMO", values = "false"),
            @SmartCondition(path = "/type", values = "BUY_TO_LET")
    }, message = "is \"false\" therefore the application cannot proceed")
    @NotNull
    private Boolean isNotSelectiveLicenceOrHMO;

    @Schema(description = "Required if loanPurpose = REMORTGAGE and 3 or more other/back ground properties where 'propertyUsage' = 'BUY_TO_LET' or 'CONSENT_TO_LET' and 'ownershipType' = 'HELD_RBSG' or 'HELD_ELSEWHERE' and propertyRedemption = false OR if loanPurpose = HOUSE_PURCHASE and 3 or more other/back ground properties where 'propertyUsage' = 'BUY_TO_LET' or 'CONSENT_TO_LET' and 'ownershipType' = 'HELD_RBSG' or 'HELD_ELSEWHERE' and propertyRedemption = false")
    @SmartRequired(
            conditions = @SmartCondition(path = "portfolioLandlord", smartCheck = SmartChecks.PortfolioLandlordRequired.class),
            message = "required if loanPurpose = REMORTGAGE and 3 or more other/back ground properties where 'propertyUsage' = 'BUY_TO_LET' or 'CONSENT_TO_LET' and 'ownershipType' = 'HELD_RBSG' or 'HELD_ELSEWHERE' and propertyRedemption = false OR if loanPurpose = HOUSE_PURCHASE and 3 or more other/back ground properties where 'propertyUsage' = 'BUY_TO_LET' or 'CONSENT_TO_LET' and 'ownershipType' = 'HELD_RBSG' or 'HELD_ELSEWHERE' and propertyRedemption = false"
    )
    @Valid
    private PortfolioLandlord portfolioLandlord;

}
