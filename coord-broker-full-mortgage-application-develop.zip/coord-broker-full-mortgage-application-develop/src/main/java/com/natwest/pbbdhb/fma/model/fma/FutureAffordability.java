package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class FutureAffordability {

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean commitmentsDueDuringMortgage;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean otherCommitments;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean personalChangesAmountAffectingTheMortgagePayment;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean propertyExpensesAffectingMortgagePayment;

}
