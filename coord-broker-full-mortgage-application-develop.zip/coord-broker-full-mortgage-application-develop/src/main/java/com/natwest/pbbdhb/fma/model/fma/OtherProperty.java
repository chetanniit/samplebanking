
package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.*;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartCollectionSizeCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class OtherProperty {

    @Schema(minimum = "1", maximum = "99999999", example = "250000", multipleOf = 1,
            description = "Required if otherProperties.mortgageRepaymentType = MIXED, No decimal places ")
    @SmartRequired(
            conditions = @SmartCondition(path = "mortgageRepaymentType", values = "MIXED"),
            message = "required if otherProperties.mortgageRepaymentType = MIXED"
    )
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin("1")
    @DecimalMax(value = "99999999")
    private BigDecimal interestOnlyAmount;

    @Schema(minimum = "1", maximum = "99999999", example = "250000", multipleOf = 1,
            description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE. No decimal places")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin("1")
    @DecimalMax(value = "99999999")
    private BigDecimal outstandingMortgageBalance;

    @Schema(minimum = "1", maximum = "99999999", example = "1000", multipleOf = 1,
            description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE. No decimal places ")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin("1")
    @DecimalMax(value = "99999999")
    private BigDecimal monthlyMortgagePayment;

    @Schema(example = "7", minimum = "0", maximum = "11", description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    @Min(0)
    @Max(11)
    private Integer remainingMortgageTermMonths;

    @Schema(example = "15", minimum = "0", maximum = "99", description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    @Min(0)
    @Max(99)
    private Integer remainingMortgageTermYears;

    @Schema(minimum = "1", maximum = "8000000", example = "1000", multipleOf = 1,
            description = "Required if propertyUsage = BUY_TO_LET or CONSENT_TO_LET. No decimal places")
    @SmartRequired(
            conditions = @SmartCondition(path = "propertyUsage", values = {"BUY_TO_LET", "CONSENT_TO_LET"}),
            message = "required if propertyUsage = BUY_TO_LET or CONSENT_TO_LET"
    )
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin("1")
    @DecimalMax(value = "8000000")
    private BigDecimal monthlyRentalIncome;

    @Schema(example = "false", allowableValues = { "true", "false" },
            description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    private Boolean propertyRedemption;

    @Schema(implementation = OtherPropertyMortgageRepaymentType.class, example = "REPAYMENT",
            description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    private OtherPropertyMortgageRepaymentType mortgageRepaymentType;

    @Schema(implementation = PropertyUsage.class, required = true, example = "BUY_TO_LET")
    @NotNull
    private PropertyUsage propertyUsage;

    @Schema(implementation = Ownership.class, required = true, example = "APPLICANT_ONE")
    @SmartValidation(conditions = {
            @SmartCondition(path = "<field>", values = {"APPLICANT_TWO", "JOINT"}),
            @SmartCondition(path = "/applicants", values = {"<", "2"}, smartCheck = SmartCollectionSizeCheck.class)
    }, message = "can't be APPLICANT_TWO or JOINT if there is only one applicant")
    @NotNull
    private Ownership ownership;

    @Schema(implementation = OwnershipType.class, required = true, example = "HELD_RBSG")
    @NotNull
    private OwnershipType ownershipType;

    @Schema(minimum = "1", maximum = "99999999", example = "1000", multipleOf = 1, required = true, description = "No decimal places")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin("1")
    @DecimalMax(value = "99999999")
    @NotNull
    private BigDecimal estimatedPropertyValue;

    @Schema(required = true)
    @NotNull
    @Valid
    private Address address;

    @Schema(implementation = PropertyType.class, example = "HOUSE_NEW_BUILD", required = true, description = "Property Type")
    @NotNull
    private PropertyType propertyType;

    @Schema(implementation = String.class, example = "2000-01-01", pattern = "yyyy-MM-dd", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @NotNull
    private LocalDate datePurchased;

    @Schema(maxLength = 30, example = "Lender One", description = "Required if ownershipType = HELD_RBSG or HELD_ELSEWHERE")
    @SmartRequired(
            conditions = @SmartCondition(path = "ownershipType", values = {"HELD_RBSG", "HELD_ELSEWHERE"}),
            message = "required if ownershipType = HELD_RBSG or HELD_ELSEWHERE"
    )
    @Size(max = 30)
    private String lenderName;

    @Schema(minimum = "1", maximum = "99", example = "3", required = true, description = "Number of bedrooms")
    @Min(1)
    @Max(99)
    @NotNull
    private Integer numberBedrooms;

    @Schema(minLength = 1, maxLength = 50, description = "Required if propertyRedemption = false")
    @SmartRequired(
            conditions = @SmartCondition(path = "propertyRedemption", values = "false"),
            message = "required if propertyRedemption = false"
    )
    @Size(min = 1, max = 50)
    private String propertyNotes;

    @Schema(minimum = "1", maximum = "99999999", multipleOf = 1, example = "250000", required = true, description = "No decimal places")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMin(value = "1")
    @DecimalMax(value = "99999999")
    @NotNull
    private BigDecimal purchasePrice;

    @Schema(example = "true", allowableValues = {"true", "false"},
            description = "Required if propertyUsage = CONSENT_TO_LET or BUY_TO_LET")
    @SmartRequired(
            conditions = @SmartCondition(path = "propertyUsage", values = {"CONSENT_TO_LET", "BUY_TO_LET"}),
            message = "required if propertyUsage = CONSENT_TO_LET or BUY_TO_LET"
    )
    private Boolean useLettingAgent;

    @Schema(allowableValues = {"true", "false"}, example = "false")
    private Boolean familyLiveInProperty;

}