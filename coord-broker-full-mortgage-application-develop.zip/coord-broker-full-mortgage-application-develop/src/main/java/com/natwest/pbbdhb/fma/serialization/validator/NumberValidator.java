package com.natwest.pbbdhb.fma.serialization.validator;

import com.fasterxml.jackson.core.JsonParser;
import com.google.common.collect.Sets;
import com.natwest.pbbdhb.fma.serialization.DeserializationValidationException;
import com.natwest.pbbdhb.fma.serialization.DeserializationValidator;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Set;

@Component
public class NumberValidator implements DeserializationValidator {

    @Override
    public Set<Class<?>> applicableForTypes() {
        return Sets.newHashSet(Number.class, byte.class, short.class, int.class, long.class, float.class, double.class);
    }

    @Override
    public DeserializationValidationException beforeSerialization(Class<?> targetType, JsonParser jsonParser) throws IOException {
        String stringValue = jsonParser.getValueAsString();
        if (stringValue != null && !stringValue.matches("[-\\+]?\\d+(\\.\\d+)?")) {
            return new DeserializationValidationException("is not a number", jsonParser);
        }
        return null;
    }
}
