package com.natwest.pbbdhb.fma.mapper.income;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.income.expense.model.enums.IncomeFrequency;
import com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType;
import com.natwest.pbbdhb.income.expense.model.income.dto.OtherIncomeDetailsDto;
import com.natwest.pbbdhb.openapi.fma.OtherIncome;
import com.natwest.pbbdhb.openapi.fma.OtherIncome.FrequencyEnum;
import com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = MappingConfig.class)
public interface OtherIncomeMapper {
    @Mapping(target = "otherIncomeFrequency", source = "otherIncome.frequency", qualifiedByName = "getFrequency")
    @Mapping(target = "sourceOfIncome", source = "otherIncome.type", qualifiedByName = "getType")
    @Mapping(target = "otherIncomeAmount", source = "otherIncome.amount")
    OtherIncomeDetailsDto mapOtherIncome(OtherIncome otherIncome);

    @Named("getType")
    default OtherIncomeType mapType(TypeEnum otherIncomeType) {
        return com.natwest.pbbdhb.fma.model.fma.enums.OtherIncomeType.toIncomeOtherIncomeType(otherIncomeType);
    }

    @Named("getFrequency")
    default IncomeFrequency mapType(FrequencyEnum otherIncomeFrequency) {
        return null != otherIncomeFrequency ? IncomeFrequency.valueOf(otherIncomeFrequency.name()) : null;
    }

}
