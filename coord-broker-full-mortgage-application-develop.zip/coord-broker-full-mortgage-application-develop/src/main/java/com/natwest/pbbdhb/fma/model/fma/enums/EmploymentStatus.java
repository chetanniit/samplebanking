package com.natwest.pbbdhb.fma.model.fma.enums;

public enum EmploymentStatus {
    EMPLOYED, NOT_EMPLOYED, SELF_EMPLOYED

}
