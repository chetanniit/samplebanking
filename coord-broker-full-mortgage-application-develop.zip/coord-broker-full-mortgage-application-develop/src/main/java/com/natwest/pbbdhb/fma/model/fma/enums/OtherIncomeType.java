package com.natwest.pbbdhb.fma.model.fma.enums;

import com.google.common.base.Suppliers;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum OtherIncomeType {
    WORKING_FAMILIES_TAX_CREDIT(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.WORKING_FAMILIES_TAX_CREDIT,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_WORKING_FAMILIES_TAX_CREDIT),
    CHILD_BENEFIT(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.CHILD_BENEFIT,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_CHILD_BENEFIT),
    UNIVERSAL_CREDIT(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.UNIVERSAL_CREDIT,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_UNIVERSAL_CREDIT),
    CARERS_ALLOWANCE(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.CARERS_ALLOWANCE,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_CARERS_ALLOWANCE),
    DISABLEMENT_LIVING_ALLOWANCE(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.DISABLEMENT_LIVING_ALLOWANCE,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_DISABLEMENT_LIVING_ALLOWANCE),
    PERSONAL_INDEPENDENT_INCOME(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.PERSONAL_INDEPENDENT_INCOME,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_PERSONAL_INDEPENDENT_INCOME),
    DIVIDEND(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.DIVIDEND,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_DIVIDEND),
    INVESTMENT_INCOME(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.INVESTMENT_INCOME,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_INVESTMENT_INCOME),
    MAINTENANCE(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.MAINTENANCE,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_CHILD_MAINTENANCE),
    PENSION_PRIVATE_OR_EMPLOYERS(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.PENSION_PRIVATE_OR_EMPLOYERS,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_PRIVATE_PENSION),
    PENSION_STATE(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.PENSION_STATE,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_STATE_PENSION),
    RENTAL_INCOME(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.RENTAL_INCOME,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_RENTAL_INCOME),
    TRUST(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.TRUST,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_TRUST),
    OTHER_TAXABLE(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.OTHER_TAXABLE,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_OTHER_TAXABLE),
    OTHER_NON_TAXABLE(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum.OTHER_NON_TAXABLE,
            com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType.ACCEPTABLE_INCOME_BANKSTATEMENT_OTHER_NON_TAXABLE);

    private com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum fmaType;
    private com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType otherIncomeType;

    private static Supplier<Map<com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum, com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType>> mapping = Suppliers
            .memoize(() -> Arrays.stream(OtherIncomeType.values())
                    .collect(Collectors.toMap(k -> k.fmaType, v -> v.otherIncomeType)));

    public static com.natwest.pbbdhb.income.expense.model.enums.OtherIncomeType toIncomeOtherIncomeType(
            com.natwest.pbbdhb.openapi.fma.OtherIncome.TypeEnum fmaType) {
        return mapping.get().get(fmaType);
    }
}
