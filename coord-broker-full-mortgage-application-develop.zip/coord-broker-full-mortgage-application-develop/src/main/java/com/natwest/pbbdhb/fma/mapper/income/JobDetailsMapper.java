package com.natwest.pbbdhb.fma.mapper.income;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.income.expense.model.enums.OccupationType;
import com.natwest.pbbdhb.income.expense.model.enums.TelephoneType;
import com.natwest.pbbdhb.income.expense.model.income.dto.AdditionalJobIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.ContactTelephoneDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import com.natwest.pbbdhb.openapi.fma.Employment;
import com.natwest.pbbdhb.openapi.fma.Income.TypeEnum;
import com.natwest.pbbdhb.openapi.fma.SelfEmployed;
import com.natwest.pbbdhb.openapi.fma.Telephone;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;

@Mapper(config = MappingConfig.class)
public abstract class JobDetailsMapper {

    private AdditionalJobIncomeMapper additionalJobIncomeMapper;

    @Mapping(target = "jobId", expression = "java( org.apache.commons.lang.RandomStringUtils.randomAlphanumeric(10))")
    @Mapping(target = "employmentStatus", source = "employment.employmentStatus")
    @Mapping(target = "employmentType", source = "employment.employmentType")
    @Mapping(target = "occupationType", source = "employment", qualifiedByName = "mapOccupationType")
    @Mapping(target = "industryType", source = "employment.industryType")
    @Mapping(target = "employerName", source = "employment.employerName")
    @Mapping(target = "employerAddress", source = "employment.address") // , qualifiedByName = "mapAddress")
    @Mapping(target = "preferredEmployerTelephone", source = "employment.telephones", qualifiedByName = "mapPreferredTelephone")
    @Mapping(target = "additionalEmployerTelephones", source = "employment.telephones", qualifiedByName = "mapAdditionalTelephones")
    @Mapping(target = "employmentStartDate", source = "employment.startDate")
    @Mapping(target = "employmentEndDate", source = "employment", qualifiedByName = "mapEmploymentEndDate")
    @Mapping(target = "contractEndDate", source = "employment", qualifiedByName = "mapContractEndDate")
    @Mapping(target = "employeeSharePercentage", source = "employment", qualifiedByName = "mapEmployeeSharePercentage")
    @Mapping(target = "basicPayAnnualIncome", source = "employment", qualifiedByName = "mapBasicPayAnnualIncome")
    // @Mapping(target = "reducedBasicPayAnnualIncome", source = "employment", qualifiedByName =
    // "mapReducedBasicPayAnnualIncome") //TODO :: to find out the logic
    @Mapping(target = "additionalIncome", source = ".", qualifiedByName = "getAdditionalIncome") // TODO :: to find out
    // the logic or not
    // needed.
    // @Mapping(target = "payslips", source = "employment.xx")
    @Mapping(target = "selfEmploymentStatus", source = "employment.selfEmployed.businessType") // TODO to confirm
    // weather this is right
    // or not
    @Mapping(target = "businessEstablishmentDate", source = "employment.selfEmployed.selfEmployedDateEstablished")
    /*
     * @Mapping(target = "businessName", source = "employment.selfEmployed.")
     *
     * @Mapping(target = "natureOfBusiness", source = "employment.selfEmployed.")
     */
    @Mapping(target = "yearOneTradingYear", source = "employment.selfEmployed.latestTradingYear")
    @Mapping(target = "yearTwoTradingYear", source = "employment.selfEmployed.previousTradingYear")
    @Mapping(target = "yearOneDirectorSalary", source = "employment.selfEmployed.drawingsLatest")
    @Mapping(target = "yearTwoDirectorSalary", source = "employment.selfEmployed.drawingsPrevious")
    @Mapping(target = "yearOneDividends", source = "employment.selfEmployed.dividendsLatest")
    @Mapping(target = "yearTwoDividends", source = "employment.selfEmployed.dividendsPrevious")
    @Mapping(target = "yearOneProfit", source = "employment.selfEmployed.netProfitLatest")
    @Mapping(target = "yearTwoProfit", source = "employment.selfEmployed.netProfitPrevious")
    // @Mapping(target = "profitExpectedToDecreaseFurther", source = "employment.selfEmployed.") //Missing field
    // @Mapping(target = "decreasingProfitReason", source = "employment.selfEmployed.") //Missing field
    public abstract JobDetailsDto toPrimaryJob(Employment employment);

    @Named("mapEmploymentEndDate")
    public LocalDate mapEmploymentEndDate(Employment employment) {
        return employment.getEndDate() != null
                && LocalDate.parse(employment.getEndDate()).compareTo(LocalDate.now()) < 0
                ? LocalDate.parse(employment.getEndDate()) : null;
    }

    @Named("mapContractEndDate")
    public LocalDate mapContractEndDate(Employment employment) {
        return employment.getEndDate() != null
                && LocalDate.parse(employment.getEndDate()).compareTo(LocalDate.now()) >= 0
                ? LocalDate.parse(employment.getEndDate()) : null;
    }

    @Mapping(target = "employmentStatus", source = "employment.employmentStatus")
    @Mapping(target = "occupationType", source = "employment", qualifiedByName = "mapOccupationType")
    @Mapping(target = "industryType", ignore = true)
    @Mapping(target = "employerName", ignore = true)
    @Mapping(target = "employmentType", ignore = true)
    public abstract JobDetailsDto toJobDetailsNotWorking(Employment employment);

    @Named("mapOccupationType")
    public OccupationType getOccupationType(Employment employment) {
        return nonNull(employment.getOccupationCode()) ? OccupationType.valueOf(employment.getOccupationCode().name())
                : null;
    }

    /*
     * @Named("mapAddress") default com.natwest.pbbdhb.model.common.Address getAddress(Employment employment) { return
     * null; //return OccupationType.valueOf(occupationCode.name()); }
     */

    @Named("mapPreferredTelephone")
    public ContactTelephoneDto getPreferredEmployerTelephone(Set<Telephone> telephones) {
        ContactTelephoneDto telephone = null;

        if (!CollectionUtils.isEmpty(telephones)) {
            List<ContactTelephoneDto> contactTelephones = telephones.stream().filter(Telephone::getPreferred)
                    .map(t -> ContactTelephoneDto.builder().number(t.getNumber())
                            .type(TelephoneType.valueOf(t.getType().name()))
                            .build())
                    .collect(Collectors.toList());
            telephone = CollectionUtils.isEmpty(contactTelephones) ? null : contactTelephones.get(0);

        }
        return telephone;

    }

    @Named("getAdditionalIncome")
    public Map<String, AdditionalJobIncomeDto> getAdditionalIncome(Employment employment) {
        AtomicInteger index = new AtomicInteger(1);
        Map<String, AdditionalJobIncomeDto> addIncomeMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(employment.getIncomes())) {
            addIncomeMap = employment.getIncomes().stream().map((income) -> {
                        if (!income.getType().equals(TypeEnum.BASIC_EARNINGS)) {
                            AdditionalJobIncomeDto addJobIncome = additionalJobIncomeMapper.map(income);
                            return addJobIncome;
                        }
                        return null;
                    }).filter(Objects::nonNull)
                    .collect(Collectors.toMap(o -> index.getAndIncrement() + "_" + o.getType().toString(), o -> o));
        }
        return addIncomeMap;
    }

    @Named("mapAdditionalTelephones")
    public List<ContactTelephoneDto> getAdditionalEmployerTelephones(Set<Telephone> telephones) {
        return telephones != null
                ? telephones
                .stream().filter(t -> !t.getPreferred()).map(
                        t -> ContactTelephoneDto.builder().number(t.getNumber())
                                .type(TelephoneType.valueOf(t.getType().name()))
                                .build())
                .collect(Collectors.toList())
                : null;
    }

    @Named("mapEmployeeSharePercentage")
    public BigDecimal getEmployeeSharePercentage(Employment employment) {
        BigDecimal ownShare = null;
        SelfEmployed selfEmployed = employment.getSelfEmployed();
        if (null != selfEmployed && null != selfEmployed.getOwnShare() && selfEmployed.getOwnShare()
                && null != selfEmployed.getEmployeeShare()) {
            ownShare = selfEmployed.getEmployeeShare();
        }
        return ownShare;
    }

    @Named("mapBasicPayAnnualIncome")
    public BigDecimal getBasicPayAnnualIncome(Employment employment) {
        BigDecimal annualIncomeAmount = null;
        if (null != employment.getIncomes()) {
            annualIncomeAmount = employment.getIncomes().stream().map(income -> {
                BigDecimal amount = null;
                if (income.getType().equals(TypeEnum.BASIC_EARNINGS)) {
                    switch (income.getFrequency()) {
                        case ANNUALLY:
                            amount = income.getAmount();
                            break;
                        case BIANNUALLY:
                            amount = income.getAmount().multiply(BigDecimal.valueOf(2));
                            break;
                        case MONTHLY:
                            amount = income.getAmount().multiply(BigDecimal.valueOf(12));
                            break;
                        case FOUR_WEEKLY:
                            amount = income.getAmount().multiply(BigDecimal.valueOf(13));
                            break;
                        case FORTNIGHTLY:
                            amount = income.getAmount().multiply(BigDecimal.valueOf(26));
                            break;
                        case QUARTERLY:
                            amount = income.getAmount().multiply(BigDecimal.valueOf(4));
                            break;
                        case WEEKLY:
                            amount = income.getAmount().multiply(BigDecimal.valueOf(52));
                            break;
                    }
                }
                return amount;
                // }).filter(b -> null != b).reduce(BigDecimal::add).get();
            }).filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
        }
        return annualIncomeAmount;
    }

    @Autowired
    public void setAdditionalJobIncomeMapper(AdditionalJobIncomeMapper additionalJobIncomeMapper) {
        this.additionalJobIncomeMapper = additionalJobIncomeMapper;
    }

}
