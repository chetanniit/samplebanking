package com.natwest.pbbdhb.fma.model.brokervalidation;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrokerDetailRequest {

    private String fcaNumber;

    private String brokerUsername;

    private String brokerForeName;

    private String brokerSurname;

    private String brokerEmail;

    private String brokerPostcode;

}
