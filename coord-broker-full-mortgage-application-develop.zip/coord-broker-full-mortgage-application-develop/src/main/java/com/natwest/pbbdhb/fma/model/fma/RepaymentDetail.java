package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.RepaymentStrategyStatus;
import com.natwest.pbbdhb.fma.model.fma.enums.RepaymentStrategyType;
import com.natwest.pbbdhb.fma.model.fma.enums.RepaymentVerificationType;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class RepaymentDetail {

    @Schema(implementation = RepaymentVerificationType.class, example = "LETTER")
    private RepaymentVerificationType repaymentVerificationType;

    @Schema(implementation = RepaymentStrategyType.class, example = "MAIN_RESIDENCE", required = true,
            description = "Can be MAIN_RESIDENCE, NOT_MAIN_RESIDENCE, OTHER_MORTGAGE_PROPERTY, UNENCUMBERED_MAIN_RESIDENCE," +
                    " UNENCUMBERED_OTHER_PROPERTY, STOCK_SHARES, UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS," +
                    " ENDOWMENT for Residential application and STOCK_SHARES, UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING," +
                    " OTHER_ASSETS, ENDOWMENT, SALE_OF_PROPERTY for Buy to Let application")
    @SmartValidation(conditions = {
            @SmartCondition(path = "/type", values = "RESIDENTIAL"),
            @SmartCondition(path = "repaymentStrategyType", negate = true, values = {
                    "MAIN_RESIDENCE", "NOT_MAIN_RESIDENCE", "OTHER_MORTGAGE_PROPERTY", "UNENCUMBERED_MAIN_RESIDENCE",
                    "UNENCUMBERED_OTHER_PROPERTY", "STOCK_SHARES", "UNIT_TRUSTS", "OEIC", "ICVC", "PENSION", "SAVING",
                    "OTHER_ASSETS", "ENDOWMENT"
            })
    }, message = "has invalid value for Residential application")
    @SmartValidation(conditions = {
            @SmartCondition(path = "/type", values = "BUY_TO_LET"),
            @SmartCondition(path = "repaymentStrategyType", negate = true, values = {
                    "STOCK_SHARES", "UNIT_TRUSTS", "OEIC", "ICVC", "PENSION", "SAVING", "OTHER_ASSETS",
                    "ENDOWMENT", "SALE_OF_PROPERTY"
            })
    }, message = "has invalid value for Buy to Let application")
    @NotNull
    private RepaymentStrategyType repaymentStrategyType;

    @Schema(implementation = RepaymentStrategyStatus.class, example = "ACTIVE")
    private RepaymentStrategyStatus repaymentStrategyStatus;

    @Schema(implementation = String.class, example = "2010-01-01", pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate repaymentVerificationDate;

    @Schema(required = true, minimum = "0", maximum = "99999999", example = "40000", multipleOf = 1, description = "No decimal places")
    @NotNull
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    private BigDecimal repaymentValue;

    @Schema(implementation = String.class, example = "2022-09-09", pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate repaymentStartDate;

    @Schema(minimum = "1", maximum = "99999999", example = "40000", multipleOf = 1, description = "No decimal places")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "1")
    private BigDecimal repaymentSumAssured;

    @Schema(minimum = "1", maximum = "99999999", example = "40000", multipleOf = 1, description = "No decimal places")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "1")
    private BigDecimal repaymentMonthlyPayment;

    @Schema(minimum = "1", maximum = "99999999", example = "40000", multipleOf = 1, description = "No decimal places")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "1")
    private BigDecimal repaymentValueAtMaturity;

    @Schema(implementation = String.class, example = "2010-01-01", pattern = "yyyy-MM-dd",
            description = "Required if mortgageType is INTEREST_ONLY or MIXED and repaymentStrategyType is STOCK_SHARES," +
                    " UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT")
    @SmartRequired(conditions = {
            @SmartCondition(path = "/mortgage/mortgageType", values = {"INTEREST_ONLY", "MIXED"}),
            @SmartCondition(path = "repaymentStrategyType", values = {
                    "STOCK_SHARES", "UNIT_TRUSTS", "OEIC", "ICVC", "PENSION", "SAVING", "OTHER_ASSETS", "ENDOWMENT"
            })
    }, message = "required if mortgageType is INTEREST_ONLY or MIXED and repaymentStrategyType is STOCK_SHARES," +
            " UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate repaymentMaturityDate;

    @Schema(maxLength = 50, example = "PENSIONS R US",
            description = "Required if mortgageType is INTEREST_ONLY or MIXED and repaymentStrategyType is STOCK_SHARES," +
                    " UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT")
    @SmartRequired(conditions = {
            @SmartCondition(path = "/mortgage/mortgageType", values = {"INTEREST_ONLY", "MIXED"}),
            @SmartCondition(path = "repaymentStrategyType", values = {
                    "STOCK_SHARES", "UNIT_TRUSTS", "OEIC", "ICVC", "PENSION", "SAVING", "OTHER_ASSETS", "ENDOWMENT"
            })
    }, message = "required if mortgageType is INTEREST_ONLY or MIXED and repaymentStrategyType is STOCK_SHARES," +
            " UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT")
    @Size(max = 50)
    private String repaymentProvider;

    @Schema(maxLength = 40, example = "12345678")
    @Size(max = 40)
    private String repaymentReference;

    @Schema(minimum = "0", maximum = "99999999", example = "40000", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    private BigDecimal repaymentMortgageAmount;

    @Schema(minimum = "0", maximum = "99999999", example = "40000", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    private BigDecimal repaymentProjectedValuation;

}
