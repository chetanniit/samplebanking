package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ValuationFeeType {
    PAY_UPFRONT, NO_FEE
}
