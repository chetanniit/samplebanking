package com.natwest.pbbdhb.fma.validator.conditional;

import com.natwest.pbbdhb.fma.exception.TechnicalException;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InaccessibleObjectException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Slf4j
public class SmartConditionalValidator implements ConstraintValidator<SmartConditionalRoot, Object> {

    private SmartConditionalRoot smartConditionalRoot;
    private List<AnnotatedEntity<SmartRequired>> smartRequiredIndex;
    private List<AnnotatedEntity<SmartValidation>> smartValidationIndex;
    private Vortex root;
    private Set<String> uniqueViolations;

    private static boolean testingEnabled = false;
    private static Set<Annotation> firedAnnotationsForTest;

    @Override
    public void initialize(SmartConditionalRoot smartConditionalRoot) {
        this.smartConditionalRoot = smartConditionalRoot;
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        uniqueViolations = new HashSet<>();
        buildIndex(objectToValidate);
        try {
            boolean requiredResult = validateRequired(context);
            boolean validResult = validate(context);
            return requiredResult && validResult;
        } catch (IllegalAccessException e) {
            if (log.isErrorEnabled()) {
                log.error("Can't access a field during class traversal : {}, exception : {}",
                        objectToValidate.getClass().getName(), e);
            }
            return false;
        } catch (NoSuchMethodException e) {
            if (log.isErrorEnabled()) {
                log.error("Method is not present during class traversal : {}, exception : {}",
                        objectToValidate.getClass().getName(), e);
            }
            return false;
        } catch (InvocationTargetException | InstantiationException e) {
            if (log.isErrorEnabled()) {
                log.error("An exception occurred during class traversal : {}, exception : {}",
                        objectToValidate.getClass().getName(), e);
            }
            return false;
        }
    }

    private boolean validateRequired(ConstraintValidatorContext context)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        boolean result = true;
        smartRequiredIndex.sort((a, b) -> ObjectUtils.compare(a.getPath(), b.getPath()));
        for (AnnotatedEntity<SmartRequired> annotatedEntity : smartRequiredIndex) {
            result = validateSmartRequired(annotatedEntity, context) && result; // order is important
        }
        return result;
    }

    private boolean validate(ConstraintValidatorContext context)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        boolean result = true;
        smartValidationIndex.sort((a, b) -> ObjectUtils.compare(a.getPath(), b.getPath()));
        for (AnnotatedEntity<SmartValidation> annotatedEntity : smartValidationIndex) {
            result = validateSmartValidation(annotatedEntity, context) && result; // order is important
        }
        return result;
    }

    private boolean validateSmartValidation(AnnotatedEntity<SmartValidation> annotatedEntity,
                                            ConstraintValidatorContext context)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        SmartValidation smartValidation = annotatedEntity.getAnnotation();
        List<SmartCondition> conditions = cleanupConditions(smartValidation.conditions());
        boolean allConditionsFired = evaluateSmartConditions(
                conditions, annotatedEntity);
        if (allConditionsFired) {
            String message = annotatedEntity.getCustomMessage() == null
                    ? smartValidation.message()
                    : annotatedEntity.getCustomMessage();
            addConstraintViolation(context, message,
                    smartValidation.showPathInMessage() ? annotatedEntity.getPath() : null, annotatedEntity.getAnnotation());
        }
        return !allConditionsFired;
    }

    private boolean validateSmartRequired(AnnotatedEntity<SmartRequired> annotatedEntity,
                                          ConstraintValidatorContext context)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        SmartRequired smartRequired = annotatedEntity.getAnnotation();
        List<Vortex> valuesOfRequired = annotatedEntity.getVortex().getFields().get(annotatedEntity.getFieldName());
        if (!valuesOfRequired.isEmpty() && (smartRequired.allowEmptyString() || hasNotEmptySting(valuesOfRequired))) {
            return true; // required field exists
        }
        List<SmartCondition> conditions = cleanupConditions(smartRequired.conditions());
        String message = annotatedEntity.getCustomMessage() == null
                ? smartRequired.message()
                : annotatedEntity.getCustomMessage();
        if (conditions.isEmpty()) {
            // @SmartRequired has been used without any conditions and works like @NotNull in that case
            addConstraintViolation(context, message,
                    smartRequired.showPathInMessage() ? annotatedEntity.getPath() : null, annotatedEntity.getAnnotation());
            return false;
        } else {
            boolean allConditionsFired = evaluateSmartConditions(
                    conditions, annotatedEntity);
            if (allConditionsFired) {
                addConstraintViolation(context, message,
                        smartRequired.showPathInMessage() ? annotatedEntity.getPath() : null, annotatedEntity.getAnnotation());
            }
            return !allConditionsFired;
        }
    }

    private void addConstraintViolation(ConstraintValidatorContext context, String message, String path, Annotation firedAnnotation) {
        if (testingEnabled && firedAnnotation != null) {
            firedAnnotationsForTest.add(firedAnnotation);
        }
        if (!isUniqueViolation(message, path)) {
            return;
        }
        context.disableDefaultConstraintViolation();
        if (StringUtils.isNotBlank(path)) {
            context.buildConstraintViolationWithTemplate(message).addPropertyNode(path).addConstraintViolation();
        } else {
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
        }
    }

    private boolean isUniqueViolation(String message, String path) {
        return uniqueViolations.add(message + path);
    }

    private List<SmartCondition> cleanupConditions(SmartCondition[] conditions) {
        List<SmartCondition> result = Arrays.asList(conditions);
        result.removeIf(condition -> StringUtils.isBlank(condition.path().trim()) || (condition.values().length == 0
                && !condition.nullOrEmpty() && SmartCheck.VoidCheck.class.equals(condition.smartCheck())));
        return result;
    }

    private boolean hasNotEmptySting(List<Vortex> vortexes)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        for (Vortex vortex : vortexes) {
            if (StringUtils.isNotBlank(vortex.getValue().get())) {
                return true;
            }
        }
        return false;
    }

    private boolean evaluateSmartConditions(Iterable<SmartCondition> smartConditions, AnnotatedEntity<?> annotatedEntity)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        boolean allConditionsFired = true;
        for (SmartCondition smartCondition : smartConditions) {
            allConditionsFired = allConditionsFired && (
                    (
                            !smartCondition.negate() && evaluateSmartCondition(smartCondition,
                                    annotatedEntity.getFieldName(), annotatedEntity.getVortex(),
                                    annotatedEntity.getPath(), annotatedEntity.getAdditionalValues())
                    ) || (
                            smartCondition.negate() && !evaluateSmartCondition(smartCondition,
                                    annotatedEntity.getFieldName(), annotatedEntity.getVortex(),
                                    annotatedEntity.getPath(), annotatedEntity.getAdditionalValues())
                    )
            );
        }
        return allConditionsFired;
    }

    private boolean evaluateSmartCondition(SmartCondition smartCondition, String fieldName,
                                           Vortex sourceVortex, String contextPath, List<String> additionalValues)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        String path = smartCondition.path().trim().replaceAll("<field>", fieldName);
        Vortex vortex = path.startsWith("/") ? root : sourceVortex;
        List<String> expectedValues = new ArrayList<>(Arrays.asList(smartCondition.values()));
        expectedValues.addAll(additionalValues);
        return evaluateSmartConditionPath(vortex, expectedValues, smartCondition.nullOrEmpty(), path.split("/"), 0,
                path, createSmartCheck(smartCondition.smartCheck()), new SmartContextImpl(vortex, contextPath, fieldName));
    }

    private SmartCheck<?> createSmartCheck(Class<? extends SmartCheck<?>> smartCheckClass)
            throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        if (smartCheckClass == null || SmartCheck.VoidCheck.class.isAssignableFrom(smartCheckClass)) {
            return null;
        } else {
            Constructor<? extends SmartCheck<?>> constructor = smartCheckClass.getDeclaredConstructor();
            constructor.setAccessible(true);
            return constructor.newInstance();
        }
    }

    private boolean evaluateSmartConditionPath(Vortex vortex, List<String> expectedValues, boolean nullOrEmpty,
                                               String[] tokens, int position, String path, SmartCheck smartCheck, SmartContext smartContext)
            throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        if (vortex == null) {
            return smartCheck == null ? nullOrEmpty : smartCheck.check(null, expectedValues, smartContext);
        }
        if (position >= tokens.length || ".".equals(tokens[position].trim())) {
            if (smartCheck != null) {
                return smartCheck.check(vortex.getNakedValue().get(), expectedValues, smartContext);
            } else {
                String value = vortex.getValue().get();
                return expectedValues.contains(value) || (nullOrEmpty && StringUtils.isBlank(value));
            }
        }
        String token = tokens[position].trim();
        if (StringUtils.isBlank(token)) {
            return evaluateSmartConditionPath(vortex, expectedValues, nullOrEmpty, tokens, position + 1, path,
                    smartCheck, smartContext);
        } else if ("..".equals(token)) {
            if (vortex.getParent() == null) {
                throw new IllegalAccessException("Path \"" + path + "\" leads beyond root node");
            }
            return evaluateSmartConditionPath(vortex.getParent(), expectedValues, nullOrEmpty, tokens, position + 1,
                    path, smartCheck, smartContext);
        } else if (token.endsWith("[?]") || token.endsWith("[*]")) {
            String fieldName = token.substring(0, token.length() - 3).trim();
            List<Vortex> values = vortex.getFields().get(fieldName);
            if (values == null) {
                throw new IllegalAccessException("\"" + fieldName + "\" field of path \"" + path + "\" not found");
            }
            if (!vortex.getArrayFields().contains(fieldName)) {
                throw new IllegalAccessException("\"" + fieldName + "\" field of path \"" + path + "\" is not array");
            }
            if (token.endsWith("[?]")) {
                boolean result = false;
                for (Vortex value : values) {
                    result = result || evaluateSmartConditionPath(value, expectedValues, nullOrEmpty, tokens,
                            position + 1, path, smartCheck, smartContext);
                }
                return result || (values.isEmpty() && evaluateSmartConditionPath(null, expectedValues, nullOrEmpty,
                        tokens, position + 1, path, smartCheck, smartContext));
            } else if (token.endsWith("[*]")) {
                boolean result = !values.isEmpty();
                for (Vortex value : values) {
                    result = result && evaluateSmartConditionPath(value, expectedValues, nullOrEmpty, tokens,
                            position + 1, path, smartCheck, smartContext);
                }
                return result || (values.isEmpty() && evaluateSmartConditionPath(null, expectedValues, nullOrEmpty,
                        tokens, position + 1, path, smartCheck, smartContext));
            }
            return false; // never happens
        } else {
            List<Vortex> values = vortex.getFields().get(token);
            if (values == null) {
                throw new IllegalAccessException("\"" + token + "\" field of path \"" + path + "\" not found");
            }
            if (vortex.getArrayFields().contains(token) || values.size() > 1) {
                if (smartCheck == null && nullOrEmpty) {
                    return values.isEmpty();
                }
                if (smartCheck != null && position + 1 == tokens.length) {
                    List<Object> nakedValues = new ArrayList<>();
                    for (Vortex value : values) {
                        nakedValues.add(value.getNakedValue().get());
                    }
                    return smartCheck.check(nakedValues, expectedValues, smartContext);
                }
                throw new IllegalAccessException("\"" + token + "\" field of path \"" + path + "\" is array");
            }
            return evaluateSmartConditionPath(values.isEmpty() ? null : values.iterator().next(), expectedValues,
                    nullOrEmpty, tokens, position + 1, path, smartCheck, smartContext);
        }
    }

    private void buildIndex(Object root) {
        this.smartRequiredIndex = new ArrayList<>();
        this.smartValidationIndex = new ArrayList<>();
        this.root = indexObject(new IdentityHashMap<>(), "", null, root);
    }

    private Vortex indexObject(Map<Object, Vortex> visited, String path, Vortex parent, Object object) {
        Vortex existingVortex = visited.get(object);
        if (existingVortex != null) {
            return existingVortex; // to deal with cycle references
        }
        if (object == null || Map.class.isAssignableFrom(object.getClass())
                || Iterable.class.isAssignableFrom(object.getClass()) || object.getClass().isArray()) {
            return null; // we don't support nested collections
        }
        Vortex vortex = new Vortex();
        visited.put(object, vortex);
        vortex.setParent(parent);
        vortex.setNakedValue(() -> object);
        if (!object.getClass().isPrimitive() && Arrays.stream(smartConditionalRoot.scanFieldsInPackages())
                .anyMatch(pkg -> object.getClass().getPackage().getName().startsWith(pkg))) {
            ReflectionUtils.doWithFields(object.getClass(), field -> {
                if (vortex.getFields().containsKey(field.getName())) {
                    return; // do not process fields that are hidden in child classes
                }
                Object fieldObject = getFieldObject(object, field);
                Iterable<Object> fieldValues;
                if (fieldObject == null) {
                    fieldValues = Collections.emptyList();
                } else if (Iterable.class.isAssignableFrom(field.getType())) {
                    fieldValues = (Iterable<Object>) fieldObject;
                } else if (field.getType().isArray()) {
                    if (field.getType().getComponentType().isPrimitive()) {
                        fieldValues = new ArrayList<>();
                        int length = Array.getLength(fieldObject);
                        for (int i = 0; i < length; i++) {
                            ((List<Object>) fieldValues).add(Array.get(fieldObject, i));
                        }
                    } else {
                        fieldValues = Arrays.asList((Object[]) fieldObject);
                    }
                } else {
                    fieldValues = Collections.singletonList(fieldObject);
                }
                boolean isArray = field.getType().isArray() || Iterable.class.isAssignableFrom(field.getType());
                if (isArray) {
                    vortex.getArrayFields().add(field.getName());
                }
                List<Vortex> fieldVortexes = new ArrayList<>();
                Iterator<Object> fieldValuesIterator = fieldValues.iterator();
                for (int i = 0; fieldValuesIterator.hasNext(); i++) {
                    fieldVortexes.add(indexObject(visited, extendPath(path, field.getName(), (isArray ? i : null)),
                            vortex, fieldValuesIterator.next()));
                }
                vortex.getFields().put(field.getName(),
                        fieldVortexes.stream().filter(Objects::nonNull).collect(Collectors.<Vortex>toList()));

                smartRequiredIndex.addAll(getAnnotatedEntities(SmartRequired.class, field,
                        extendPath(path, field.getName(), null), vortex));

                smartValidationIndex.addAll(getAnnotatedEntities(SmartValidation.class, field,
                        extendPath(path, field.getName(), null), vortex));
            });
        }
        Class<?> clazz = object.getClass();
        while (clazz != null && !clazz.isEnum() && !Object.class.equals(clazz)) {
            String pack = clazz.getPackage().getName();
            if (Arrays.stream(smartConditionalRoot.scanFieldsInPackages())
                    .anyMatch(pack::startsWith)) {
                smartValidationIndex.addAll(getAnnotatedEntities(SmartValidation.class, clazz, path, vortex));
            }
            clazz = clazz.getSuperclass();
        }
        return vortex;
    }

    private Object getFieldObject(Object object, Field field) {
        try {
            if (object.getClass().isEnum()) {
                if (object.getClass().isAssignableFrom(field.getType())) {
                    return Enum.valueOf((Class<? extends Enum>) field.getType(), (String) object.getClass().getMethod("name").invoke(object));
                } else {
                    return null;
                }
            } else {
                field.setAccessible(true);
                return field.get(object);
            }
        } catch (InaccessibleObjectException ioex) {
            throw new RuntimeException(String.format("Unable to set field %s.%s accessible! Cause: %s",
                    object.getClass().getName(), field.getName(), ioex.getMessage()), ioex);
        } catch (NoSuchMethodException nsmex) {
            throw new RuntimeException(String.format("Can't find method for %s! Cause: %s",
                    object.getClass().getName(), nsmex.getMessage()), nsmex);
        } catch (InvocationTargetException itex) {
            throw new RuntimeException(String.format("Can't execute method for %s! Cause: %s",
                    object.getClass().getName(), itex.getMessage()), itex);
        } catch (Exception ex) {
            throw new RuntimeException(String.format("Can't set field accessible general exception! Cause: %s",
                    ex.getMessage()), ex);
        }
    }

    private String extendPath(String path, String fieldName, Integer index) {
        return path + (StringUtils.isBlank(path) ? "" : ".") + fieldName + (index == null ? "" : "[" + index + "]");
    }

    private <T extends Annotation> List<AnnotatedEntity<T>> getAnnotatedEntities(
            Class<T> annotationType, Class<?> clazz, String path, Vortex vortex) {
        return getAnnotatedEntities(annotationType, null, path, vortex,
                clazz::getAnnotationsByType, clazz::getDeclaredAnnotations);
    }

    private <T extends Annotation> List<AnnotatedEntity<T>> getAnnotatedEntities(
            Class<T> annotationType, Field field, String path, Vortex vortex) {
        return getAnnotatedEntities(annotationType, field.getName(), path, vortex,
                field::getAnnotationsByType, field::getDeclaredAnnotations);
    }

    private <T extends Annotation> List<AnnotatedEntity<T>> getAnnotatedEntities(
            Class<T> annotationType, String fieldName, String path, Vortex vortex,
            Function<Class<T>, T[]> getAnnotationsByType, Supplier<Annotation[]> getDeclaredAnnotations) {
        List<AnnotatedEntity<T>> result = new ArrayList<>();
        for (T annotation : getAnnotationsByType.apply(annotationType)) {
            if (isEligibleSmartAnnotation(annotation, smartConditionalRoot.scope())) {
                result.add(new AnnotatedEntity<>(annotation, vortex, fieldName, path, Collections.emptyList(), null));
            }
        }
        for (Annotation aliasAnnotation : getDeclaredAnnotations.get()) {
            for (T annotation : aliasAnnotation.annotationType().getAnnotationsByType(annotationType)) {
                if (isEligibleSmartAnnotation(annotation, smartConditionalRoot.scope())) {
                    result.add(new AnnotatedEntity<>(annotation, vortex, fieldName,
                            path, getAdditionalValues(aliasAnnotation), getCustomMessage(aliasAnnotation)));
                }
            }
        }
        return result;
    }

    private boolean isEligibleSmartAnnotation(Annotation annotation, String scope) {
        return annotation.annotationType().isAssignableFrom(SmartRequired.class)
                && ((SmartRequired) annotation).scope().equals(scope)
                || annotation.annotationType().isAssignableFrom(SmartValidation.class)
                && ((SmartValidation) annotation).scope().equals(scope);
    }

    private List<String> getAdditionalValues(Annotation annotation) {
        Method valuesMethod;
        try {
            valuesMethod = annotation.annotationType().getDeclaredMethod("values");
            String[] values = (String[]) valuesMethod.invoke(annotation);
            return values == null ? Collections.emptyList() : Arrays.asList(values);
        } catch (NoSuchMethodException | InvocationTargetException
                 | IllegalAccessException | ClassCastException e) {
            return Collections.emptyList();
        }
    }

    private String getCustomMessage(Annotation annotation) {
        Method valuesMethod;
        try {
            valuesMethod = annotation.annotationType().getDeclaredMethod("message");
            return (String) valuesMethod.invoke(annotation);
        } catch (NoSuchMethodException | InvocationTargetException
                 | IllegalAccessException | ClassCastException e) {
            return null;
        }
    }

    public static void enableTesting() {
        testingEnabled = true;
        firedAnnotationsForTest = Collections.newSetFromMap(new IdentityHashMap<>());
    }

    public static Set<Annotation> getFiredAnnotationsForTest() {
        return firedAnnotationsForTest;
    }

    @Setter
    @Getter
    private static class Vortex {
        private Vortex parent;
        private NakedValueSupplier nakedValue = () -> null;
        private ValueSupplier value = () -> ConvertUtils.convert(nakedValue.get());
        private Map<String, List<Vortex>> fields = new HashMap<>();
        private Set<String> arrayFields = new HashSet<>();
    }

    @AllArgsConstructor
    @Getter
    private static class AnnotatedEntity<T extends Annotation> {
        private T annotation;
        private Vortex vortex;
        private String fieldName;
        private String path;
        private List<String> additionalValues;
        private String customMessage;
    }

    private interface NakedValueSupplier {
        Object get() throws IllegalAccessException, InvocationTargetException, NoSuchMethodException;
    }

    private interface ValueSupplier {
        String get() throws IllegalAccessException, InvocationTargetException, NoSuchMethodException;
    }

    @AllArgsConstructor
    private class SmartContextImpl implements SmartContext {

        private Vortex sourceVortex;
        private String contextPath;
        private String fieldName;

        @Override
        public <T> List<T> getValues(String path) {
            String normalizedPath = path.trim().replaceAll("<field>", fieldName);
            Vortex vortex = normalizedPath.startsWith("/") ? root : sourceVortex;
            ExtractingSmartCheck<Object> extractingSmartCheck = new ExtractingSmartCheck<>();
            try {
                evaluateSmartConditionPath(vortex, Collections.emptyList(), false, normalizedPath.split("/"), 0,
                        normalizedPath, extractingSmartCheck, null);
            } catch (Exception e) {
                // wrapping is permissible because checked exceptions will be managed during condition implementation
                throw RuntimeException.class.isAssignableFrom(e.getClass()) ? (RuntimeException) e
                        : new TechnicalException(e);
            }
            return (List<T>) extractingSmartCheck.getValues();
        }

        @Override
        public String getContextPath() {
            return contextPath;
        }

        private class ExtractingSmartCheck<T> implements SmartCheck<T> {
            private List<T> values = new ArrayList<>();

            @Override
            public boolean check(T actualValue, List<String> conditionValues, SmartContext smartContext) {
                values.add(actualValue);
                return true; // so [*] will collect all values and [?] will collect the first one
            }

            public List<T> getValues() {
                return values;
            }
        }

    }

}
