package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ProductTerm {
    ONE_YEAR, TWO_YEAR, THREE_YEAR, FOUR_YEAR, FIVE_YEAR, SIX_YEAR, SEVEN_YEAR, EIGHT_YEAR, NINE_YEAR, TEN_YEAR
}
