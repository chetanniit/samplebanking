package com.natwest.pbbdhb.fma.model.fma.enums;

public enum PaymentFrequency {
    ANNUALLY, BIANNUALLY, FORTNIGHTLY, FOUR_WEEKLY, MONTHLY, QUARTERLY, WEEKLY
}
