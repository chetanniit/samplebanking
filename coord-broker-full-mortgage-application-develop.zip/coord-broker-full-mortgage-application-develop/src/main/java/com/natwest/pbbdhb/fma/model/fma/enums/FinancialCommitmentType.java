package com.natwest.pbbdhb.fma.model.fma.enums;

import com.google.common.base.Suppliers;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public enum FinancialCommitmentType {

    CHILD_SUPPORT(com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.CHILD_SUPPORT,
            ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_CHILD_SUPPORT), RENT(
                    com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.RENT,
                    ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_GROUND_RENT), SCHOOL_FEES(
                            com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.SCHOOL_FEES,
                            ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_SCHOOL_EDUCATION_FEES), CHILD_CARE_COSTS(
                                    com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.CHILD_CARE_COSTS,
                                    ExpenseCategory.CHILD_CARE), ADULT_CARE_COSTS(
                                            com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.ADULT_CARE_COSTS,
                                            ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_ADULT_CARE_COST), GROUND_RENT(
                                                    com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.GROUND_RENT,
                                                    ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_GROUND_RENT), SERVICE_CHARGE(
                                                            com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.SERVICE_CHARGE,
                                                            ExpenseCategory.OTHER_EXPENDITURE_SERVICE_CHARGES_FOR_LEASEHOLD_PROPERTIES), ESTATE_CHARGE(
                                                                    com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.ESTATE_CHARGE,
                                                                    ExpenseCategory.OTHER_EXPENDITURE_ESTATE_RENT), HELP_TO_BUY_LOAN(
                                                                            com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.HELP_TO_BUY_LOAN,
                                                                            ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_HELP_TO_BUY_LOAN), OTHER_COMMITTED_EXPENDITURE(
                                                                                    com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum.OTHER_COMMITTED_EXPENDITURE,
                                                                                    ExpenseCategory.OTHER_COMMITTED_EXPENDITURE_OTHER);

    private com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum fmaType;
    private ExpenseCategory expenseCategory;

    private static Supplier<Map<com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum, ExpenseCategory>> mapping = Suppliers
            .memoize(() -> Arrays.stream(FinancialCommitmentType.values())
                    .collect(Collectors.toMap(k -> k.fmaType, v -> v.expenseCategory)));

    FinancialCommitmentType(com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum fmaType,
            ExpenseCategory expenseCategory) {
        this.fmaType = fmaType;
        this.expenseCategory = expenseCategory;
    }

    public static ExpenseCategory toExpenseCategory(
            com.natwest.pbbdhb.openapi.fma.FinancialCommitment.TypeEnum fmaType) {
        return mapping.get().get(fmaType);
    }

}
