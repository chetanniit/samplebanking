package com.natwest.pbbdhb.fma.model.fma.enums;

import com.google.common.base.Suppliers;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public enum CreditCardType {

    CREDIT_CARD(com.natwest.pbbdhb.openapi.fma.CreditCard.TypeEnum.CREDIT_CARD,
            ExpenseCategory.CREDIT_CARD), STORE_CARD(com.natwest.pbbdhb.openapi.fma.CreditCard.TypeEnum.STORE_CARD,
                    ExpenseCategory.CREDIT_CARD);

    private com.natwest.pbbdhb.openapi.fma.CreditCard.TypeEnum fmaType;
    private ExpenseCategory expenseCategory;

    private static Supplier<Map<com.natwest.pbbdhb.openapi.fma.CreditCard.TypeEnum, ExpenseCategory>> mapping = Suppliers
            .memoize(() -> Arrays.stream(CreditCardType.values())
                    .collect(Collectors.toMap(k -> k.fmaType, v -> v.expenseCategory)));

    CreditCardType(com.natwest.pbbdhb.openapi.fma.CreditCard.TypeEnum fmaType, ExpenseCategory expenseCategory) {
        this.fmaType = fmaType;
        this.expenseCategory = expenseCategory;
    }

    public static ExpenseCategory toExpenseCategory(com.natwest.pbbdhb.openapi.fma.CreditCard.TypeEnum fmaType) {
        return mapping.get().get(fmaType);
    }

}
