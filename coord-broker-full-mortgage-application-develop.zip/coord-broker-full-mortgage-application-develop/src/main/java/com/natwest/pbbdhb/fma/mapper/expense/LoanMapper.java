package com.natwest.pbbdhb.fma.mapper.expense;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.income.expense.model.enums.YesNo;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import com.natwest.pbbdhb.openapi.fma.Loan;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = MappingConfig.class)
public interface LoanMapper {
    @Mapping(target = "merchantName", source = "loan.provider")
    @Mapping(target = "outstandingBalance", source = "loan.amountOutstanding")
    @Mapping(target = "redeemedOrLessThanSixMonths", source = "loan.toBeRepaid", qualifiedByName = "getRedeemedOrLessThanSixMonths")
    @Mapping(target = "amount", source = "loan.monthlyPayment")
    ExpenseTransactionDto map(Loan loan);

    @Named("getRedeemedOrLessThanSixMonths")
    default YesNo getRedeemedOrLessThanSixMonths(final Boolean redeemedOrLessThanSixMonths) {
        return redeemedOrLessThanSixMonths ? YesNo.Y : YesNo.N;
    }

}
