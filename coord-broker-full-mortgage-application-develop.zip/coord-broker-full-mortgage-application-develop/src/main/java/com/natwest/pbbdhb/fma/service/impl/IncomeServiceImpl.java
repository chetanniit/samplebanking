package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.fma.service.IncomeService;
import com.natwest.pbbdhb.fma.util.Constants;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class IncomeServiceImpl implements IncomeService {

    @Value("${income.endpoint}")
    private String incomeEndPoint;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public ValidatedCaseIncomeDto getIncome(String caseId, String brand) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(Constants.BRAND, brand);
        return restTemplate.exchange(incomeEndPoint, HttpMethod.GET, new HttpEntity<>(httpHeaders),
                ValidatedCaseIncomeDto.class, caseId).getBody();
    }

    @Override
    public ValidatedCaseIncomeDto createIncome(String caseId, String brand, ValidatedCaseIncomeDto incomeRequest) {
        log.debug("Income creation called with brand : {}", brand);
        ResponseEntity<ValidatedCaseIncomeDto> responseEntity = restTemplate.exchange(incomeEndPoint, HttpMethod.PUT,
                new HttpEntity<>(incomeRequest, createHttpHeaders(brand)), ValidatedCaseIncomeDto.class, caseId);
        if (log.isDebugEnabled()) {
            log.debug("Income creation Case id : {}, Http Status code ={}, createIncome completed", caseId,
                    responseEntity.getStatusCode());
        }
        return responseEntity.getBody();
    }

    private HttpHeaders createHttpHeaders(String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND_HEADER, brand);
        return headers;
    }
}
