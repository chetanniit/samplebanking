package com.natwest.pbbdhb.fma.model.fma.enums;

public enum EmploymentType {
    PERMANENT, CONTRACT, TEMPORARY, OTHER
}
