package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailRequest;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailResponse;

public interface BrokerValidationService {

    BrokerDetailResponse validate(BrokerDetailRequest brokerDetailRequest);
}
