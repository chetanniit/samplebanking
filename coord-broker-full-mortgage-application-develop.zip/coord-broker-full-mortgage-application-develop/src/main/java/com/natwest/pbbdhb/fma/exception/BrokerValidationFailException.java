package com.natwest.pbbdhb.fma.exception;

public class BrokerValidationFailException extends RuntimeException {

    public BrokerValidationFailException(String message) {
        super(message);
    }
}
