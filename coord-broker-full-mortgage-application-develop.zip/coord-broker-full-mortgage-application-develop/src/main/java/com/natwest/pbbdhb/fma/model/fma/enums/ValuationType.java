package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ValuationType {
    STANDARD_MORTGAGE_VALUATION
}
