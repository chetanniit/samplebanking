package com.natwest.pbbdhb.fma.validator.conditional;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

/**
 * The annotation may be used to enable conditional validation for object tree. Specify the annotation at any class that
 * shall be used as root class for validation. See also: {@link SmartRequired}, {@link SmartValidation}
 **/
@Documented
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = { SmartConditionalValidator.class })
public @interface SmartConditionalRoot {

    String message() default "field is required";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    /**
     * Only {@link SmartRequired} and {@link SmartValidation} annotations having the same scope will be validated
     * relatively to the current @SmartConditionalRoot.<br>
     * You can have several @SmartConditionalRoot classes within the same object tree with different scopes.
     *
     * @return any string
     **/
    String scope() default "default";

    /**
     * To avoid scanning of useless fields one can specify several packages. Only classes within this packages are
     * scanned for fields during analysis of model objects tree
     *
     * @return array of packages
     **/
    String[] scanFieldsInPackages() default { "com.natwest" };

}
