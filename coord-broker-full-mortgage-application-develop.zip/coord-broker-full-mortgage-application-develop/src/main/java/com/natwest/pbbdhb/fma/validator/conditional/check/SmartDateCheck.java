package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Supported operators: {@code ==, =, !=, <>, <, <=, >, >=}<br>
 * Supported values: constant yyyy-MM-dd or {@code <now>} or path as "path:path_to_other_date_field"<br>
 * Usage example: {@code @SmartCondition(path = "dateField", values = {">=", "2015-03-24"}, smartCheck =
 * SmartDateCheck.class)}<br>
 * Usage example: {@code @SmartCondition(path = "dateField", values = {">=", "path:../some/field"}, smartCheck =
 * SmartDateCheck.class)}
 */
public class SmartDateCheck extends AbstractSmartComparableCheck<LocalDate> {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    public boolean check(LocalDate actualValue, List<String> conditionValues, SmartContext smartContext) {
        String operator = conditionValues.get(0).trim();
        String toCompare = conditionValues.get(1).trim();
        LocalDate valueToCompare = toCompare.startsWith("path:")
                ? smartContext.getValue(toCompare.substring(5).trim())
                : "<now>".equals(toCompare) ? LocalDate.now()
                : LocalDate.parse(toCompare, DATE_FORMATTER);
        return compare(actualValue, operator, valueToCompare, LocalDate::compareTo);
    }

}
