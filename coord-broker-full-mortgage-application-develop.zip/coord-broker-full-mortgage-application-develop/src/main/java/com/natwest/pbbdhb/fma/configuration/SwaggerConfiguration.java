package com.natwest.pbbdhb.fma.configuration;

import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;
import io.micrometer.core.instrument.util.StringUtils;
import io.swagger.v3.core.converter.AnnotatedType;
import io.swagger.v3.core.converter.ModelConverter;
import io.swagger.v3.core.converter.ModelConverterContext;
import io.swagger.v3.core.converter.ModelConverters;
import io.swagger.v3.core.jackson.ModelResolver;
import io.swagger.v3.core.util.Yaml;
import io.swagger.v3.core.util.Yaml31;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.servers.Server;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.converters.ModelConverterRegistrar;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Configuration
@RequiredArgsConstructor
public class SwaggerConfiguration {

    @Autowired
    private ModelConverterRegistrar modelConverterRegistrar;

    private final BuildProperties buildProperties;

    private static Map<String, Set<String>> refFieldDescriptions = new ConcurrentHashMap<>();

    private static final String CHANGELOG_URL = "https://natwest.gitlab-dedicated.com/natwestgroup/Services/RetailBankingDigiTech/OneBankMortgages/DigitalHomeBuying/coord-broker-full-mortgage-application/-/blob/develop/CHANGELOG.md?ref_type=heads";

    @Bean
    public OpenAPI apiInfo(@Value("${build.swagger.generate:false}") boolean buildSwaggerGenerate) throws NoSuchFieldException, IllegalAccessException {
        configureYamlFactory();

        OpenAPI openApi = new OpenAPI().info(new Info().title("Full Mortgage Application API")
                .description("HBO API for Full Mortgage Application"+ String.format("<a href=\"%s\" target=\"_blank\">Open CHANGELOG</a>", CHANGELOG_URL))
                .version(String.format("%s / %s", "V1", buildProperties.getVersion())));

        if (buildSwaggerGenerate) {
            openApi.getInfo().description("API for Full Mortgage Application");
            openApi.servers(Collections.singletonList(
                    new Server().url("https://api.natwest.com/mortgages/v1").description("Base server url")));
        }

        customizeModelResolver();

        return openApi;
    }

    @Bean
    public OpenApiCustomiser openApiCustomiser() {
        return openApi -> {
            forEachProperty(openApi, this::removeDefaultMaxItems, this::removeDefaultMinLength,
                    this::removeDefaultExclusiveMinMax, this::removeInt32FromIntegers);
            removeExcessiveTypeDescriptions(openApi);
        };
    }

    private void configureYamlFactory() {
        configureYamlFactory((YAMLFactory) Yaml.mapper().getFactory());
        configureYamlFactory((YAMLFactory) Yaml31.mapper().getFactory());
    }

    private void configureYamlFactory(YAMLFactory yamlFactory) {
        yamlFactory.disable(YAMLGenerator.Feature.SPLIT_LINES);
        yamlFactory.enable(YAMLGenerator.Feature.INDENT_ARRAYS_WITH_INDICATOR);
    }

    private void removeExcessiveTypeDescriptions(OpenAPI openApi) {
        refFieldDescriptions.forEach((ref, descriptions) -> {
            String schemaName = ref.replaceAll("^#/components/schemas/", "");
            Schema schema = openApi.getComponents().getSchemas().get(schemaName);
            if (schema != null && schema.getDescription() != null && descriptions.contains(schema.getDescription())) {
                schema.setDescription(null);
            }
        });
    }

    @SafeVarargs
    final private void forEachProperty(OpenAPI openApi, Consumer<Schema<?>>... propertySchemaConsumers) {
        openApi.getComponents().getSchemas().values().stream().map(schema -> schema.getProperties())
                .filter(Objects::nonNull).flatMap(properties -> (Stream<Schema<?>>) properties.values().stream())
                .forEach(property -> Arrays.stream(propertySchemaConsumers).forEach(c -> c.accept(property)));
    }

    private void removeDefaultMaxItems(Schema<?> propertySchema) {
        if (propertySchema != null && "array".equals(propertySchema.getType()) && propertySchema.getMaxItems() != null
                && propertySchema.getMaxItems().equals(Integer.MAX_VALUE)) {
            propertySchema.setMaxItems(null);
        }
    }

    private void removeDefaultMinLength(Schema<?> propertySchema) {
        if (propertySchema != null && "string".equals(propertySchema.getType()) && propertySchema.getMinLength() != null
                && propertySchema.getMinLength().equals(0)) {
            propertySchema.setMinLength(null);
        }
    }

    private void removeDefaultExclusiveMinMax(Schema<?> propertySchema) {
        if (propertySchema != null && "number".equals(propertySchema.getType())) {
            if (Boolean.FALSE.equals(propertySchema.getExclusiveMaximum())) {
                propertySchema.setExclusiveMaximum(null);
            }
            if (Boolean.FALSE.equals(propertySchema.getExclusiveMinimum())) {
                propertySchema.setExclusiveMinimum(null);
            }
        }
    }

    private void removeInt32FromIntegers(Schema<?> propertySchema) {
        if (propertySchema != null && "integer".equals(propertySchema.getType())
                && "int32".equals(propertySchema.getFormat())) {
            propertySchema.setFormat(null);
        }
    }

    // Replaces default model resolver with one that transforms $ref fields having description into allOf fields with
    // the description
    private void customizeModelResolver() throws NoSuchFieldException, IllegalAccessException {
        Field modelConvertersField = ModelConverterRegistrar.class.getDeclaredField("modelConvertersInstance");
        modelConvertersField.setAccessible(true);
        ModelConverters modelConverters = (ModelConverters) modelConvertersField.get(modelConverterRegistrar);
        List<ModelConverter> converters = modelConverters.getConverters();
        ModelConverter converterToReplace = converters.stream()
                .filter(converter -> converter instanceof ModelResolver)
                .findFirst()
                .orElse(null);
        if (converterToReplace != null) {
            modelConverters.removeConverter(converterToReplace);
            modelConverters.addConverter(new CustomModelResolver(converterToReplace));
        }
    }

    @AllArgsConstructor
    private static class CustomModelResolver implements ModelConverter {

        private ModelConverter defaultModelResolver;

        @Override
        public Schema resolve(AnnotatedType annotatedType, ModelConverterContext context, Iterator<ModelConverter> next) {

            String fieldDescription = annotatedType.getCtxAnnotations() == null ? null
                    : Stream.of(annotatedType.getCtxAnnotations())
                    .filter(a -> io.swagger.v3.oas.annotations.media.Schema.class.equals(a.annotationType()))
                    .findFirst()
                    .map(a -> ((io.swagger.v3.oas.annotations.media.Schema) a).description())
                    .orElse(null);

            Schema schema = defaultModelResolver.resolve(annotatedType, context, next);

            if ("object".equals(schema.getType()) && StringUtils.isNotEmpty(schema.getName())) {
                Schema refSchema = new Schema(schema.getSpecVersion());
                refSchema.set$ref(Components.COMPONENTS_SCHEMAS_REF + schema.getName());
                schema = refSchema;
            }

            if (StringUtils.isNotEmpty(fieldDescription) && StringUtils.isNotEmpty(schema.get$ref())) {
                Schema newSchema = new Schema(schema.getSpecVersion());
                newSchema.description(fieldDescription);
                schema.description(null);
                newSchema.allOf(new ArrayList<>(Collections.singletonList(schema)));
                refFieldDescriptions.computeIfAbsent(schema.get$ref(), (key) -> Collections.newSetFromMap(new ConcurrentHashMap<>()))
                        .add(fieldDescription);
                return newSchema;
            }

            return schema;
        }

    }


}
