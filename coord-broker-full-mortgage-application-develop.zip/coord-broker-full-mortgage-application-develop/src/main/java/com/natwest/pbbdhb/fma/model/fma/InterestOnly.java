package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class InterestOnly {

    @ArraySchema(schema = @Schema(implementation = RepaymentDetail.class),
            minItems = 1, uniqueItems = true)
    @SmartValidation(
            conditions = @SmartCondition(path = ".", values = "MAIN_RESIDENCE", smartCheck = SmartChecks.CheckRepaymentStrategyType.class),
            message = "should not contains more than one object with repaymentStrategyType = MAIN_RESIDENCE"
    )
    @SmartValidation(
            conditions = @SmartCondition(path = ".", values = "UNENCUMBERED_MAIN_RESIDENCE", smartCheck = SmartChecks.CheckRepaymentStrategyType.class),
            message = "should not contains more than one object with repaymentStrategyType = UNENCUMBERED_MAIN_RESIDENCE"
    )
    @NotNull
    @Size(min = 1)
    @Valid
    private List<RepaymentDetail> repaymentDetails;

    @Schema(required = true, example = "40000", minimum = "1", maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin("1")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal amount;

    @Schema(required = true, example = "11", minimum = "0", maximum = "11")
    @Max(value = 11)
    @Min(value = 0)
    @NotNull
    private Integer termMonths;

    @Schema(required = true, example = "15", minimum = "0", maximum = "99")
    @Max(value = 99)
    @Min(value = 0)
    @NotNull
    private Integer termYears;

}
