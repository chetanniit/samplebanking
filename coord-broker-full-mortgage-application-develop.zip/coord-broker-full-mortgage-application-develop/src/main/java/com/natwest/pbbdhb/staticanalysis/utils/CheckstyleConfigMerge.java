package com.natwest.pbbdhb.staticanalysis.utils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CheckstyleConfigMerge extends AbstractXmlConfigMerge {

    private static final String ATTR_NAME = "name";
    private static final String ATTR_VALUE = "value";

    private static Document resultDocument;

    public static void main(String[] args) throws ParserConfigurationException, IOException, TransformerException, SAXException {
        merge(args[0], args[1], args[2]);
    }

    private static void merge(String checkstyleConfig, String mutatorConfig, String resultConfig) throws ParserConfigurationException, IOException, SAXException, TransformerException {
        if (!new File(checkstyleConfig).exists()) {
            return;
        }
        Document sourceXml = readXml(checkstyleConfig);
        Document mutatorXml = readXml(mutatorConfig);
        Element sourceRoot = sourceXml.getDocumentElement();
        Element mutatorRoot = mutatorXml.getDocumentElement();
        resultDocument = createXml();
        resultDocument.appendChild(mutate(sourceRoot, mutatorRoot));
        saveXml(resultDocument, resultConfig, sourceXml);
    }

    private static Element mutate(Element source, Element mutator) {

        if (mutator.getAttributeNode("remove") != null) {
            return null;
        }

        Element resultElement = resultDocument.createElement(source.getTagName());
        stream(source.getAttributes()).forEach(attr -> resultElement.setAttribute(attr.getNodeName(), attr.getNodeValue()));

        Predicate<Node> isValidElement = node -> Element.class.isAssignableFrom(node.getClass())
                && node.getAttributes().getNamedItem(ATTR_NAME) != null
                && node.getAttributes().getNamedItem(ATTR_NAME).getNodeValue() != null;

        Function<Element, String> key = e -> {
            String id = stream(e.getChildNodes())
                    .filter(isValidElement)
                    .map(node -> (Element) node)
                    .filter(element -> "property".equals(element.getTagName())
                            && "id".equals(element.getAttributes().getNamedItem(ATTR_NAME).getNodeValue()))
                    .findFirst()
                    .map(element -> "_id[" + element.getAttributes().getNamedItem(ATTR_VALUE).getNodeValue() + "]")
                    .orElse("");
            return e.getTagName() + id + "_" + e.getAttributes().getNamedItem(ATTR_NAME).getNodeValue();
        };

        Map<String, Element> mutatorChildrenMap = stream(mutator.getChildNodes())
                .filter(isValidElement)
                .map(node -> (Element) node)
                .collect(Collectors.toMap(key, Function.identity()));

        stream(source.getChildNodes()).forEach(sourceChildNode -> {
            if (!isValidElement.test(sourceChildNode)) {
                resultElement.appendChild(resultDocument.importNode(sourceChildNode, true));
                return;
            }
            Element sourceChildElement = (Element) sourceChildNode;
            String elementKey = key.apply(sourceChildElement);
            Element mutatorChildElement = mutatorChildrenMap.get(elementKey);
            if (mutatorChildElement == null) {
                resultElement.appendChild(resultDocument.importNode(sourceChildNode, true));
            } else {
                Element mutatedElement = mutate(sourceChildElement, mutatorChildElement);
                if (mutatedElement != null) {
                    resultElement.appendChild(mutatedElement);
                }
                mutatorChildrenMap.remove(elementKey);
            }
        });

        mutatorChildrenMap.values()
                .forEach(element -> resultElement.appendChild(resultDocument.importNode(element, true)));

        return resultElement;

    }

}
