package com.natwest.pbbdhb.fma.mapper.applicant;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.openapi.fma.ProofOfId.DocumentClassEnum;
import org.mapstruct.Mapper;

@Mapper(config = MappingConfig.class, uses = { ExistingMortgageMapper.class })
public interface ApplicantMapper {

    ApplicantDto toCreateApplicant(com.natwest.pbbdhb.openapi.fma.Applicant applicant, String caseId,
            Boolean mainApplicant, Boolean consentToFMA);

    default String mapDocumentClass(DocumentClassEnum docClass) {
        return docClass == null ? null : docClass.getValue();
    }

}
