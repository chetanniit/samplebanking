package com.natwest.pbbdhb.fma.mapper.expense;

import com.natwest.pbbdhb.fma.model.fma.enums.CreditCardType;
import com.natwest.pbbdhb.fma.model.fma.enums.FinancialCommitmentType;
import com.natwest.pbbdhb.fma.model.fma.enums.LoanType;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStage;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseFrequency;
import com.natwest.pbbdhb.income.expense.model.enums.YesNo;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseApplicantDto;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.CreditCard;
import com.natwest.pbbdhb.openapi.fma.FinancialCommitment;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import com.natwest.pbbdhb.openapi.fma.Loan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ExpenditureMapper {

    @Autowired
    private CreditCardMapper creditCardMapper;

    @Autowired
    private LoanMapper loanMapper;

    @Autowired
    private FinancialCommitmentMapper financialCommitmentMapper;

    public ValidatedCaseExpenseDto convertToExpenseRequest(FullMortgageApplicationRequest fmaRequest,
            Map<Applicant, String> applicantToId) {
        List<ExpenseApplicantDto> expenseApplicants = fmaRequest.getApplicants().stream()
                .map(applicant -> convertToExpenseApplicant(applicant, applicantToId.get(applicant)))
                .collect(Collectors.toList());
        return ValidatedCaseExpenseDto.builder().stage(CaseStage.FMA).applicants(expenseApplicants).build();
    }

    private ExpenseApplicantDto convertToExpenseApplicant(Applicant applicant, String id) {
        // TODO:: Applicant doesn't have required fields. To map them later.
        // Map<String, MimoExpenseTransaction> mimoTransactions = null;
        return ExpenseApplicantDto.builder().applicantId(id).sourceOfExpenditureVerification(YesNo.N)// As per discussion
                // .mimoTransactions(mimoTransactions)
                .transactions(getExpenseTransactions(applicant)).build();
    }

    private Map<String, ExpenseTransactionDto> getExpenseTransactions(Applicant applicant) {

        AtomicInteger index = new AtomicInteger(1);

        Map<String, ExpenseTransactionDto> transactions = new HashMap<>();
        List<CreditCard> creditCards = applicant.getCreditCards();
        if (null != creditCards && creditCards.size() > 0) {
            transactions.putAll(creditCards.stream().map(c -> {
                ExpenseTransactionDto ccTransaction = creditCardMapper.map(c);
                ccTransaction.setCategoryCode(CreditCardType.toExpenseCategory(c.getType()));
                return ccTransaction;
            }).collect(Collectors.toMap(k -> index.getAndIncrement() + "_" + k.getCategoryCode().name(), o -> o)));
        }

        List<Loan> loans = applicant.getLoans();
        if (null != loans && loans.size() > 0) {
            transactions.putAll(loans.stream().map(l -> {
                ExpenseTransactionDto loanTransaction = loanMapper.map(l);
                loanTransaction.setCategoryCode(LoanType.toExpenseCategory(l.getType()));
                loanTransaction.setFrequency(ExpenseFrequency.MONTHLY);
                return loanTransaction;
            }).collect(Collectors.toMap(k -> index.getAndIncrement() + "_" + k.getCategoryCode().name(), o -> o)));
        }

        List<FinancialCommitment> financialCommitments = applicant.getFinancialCommitments();

        if (null != financialCommitments && financialCommitments.size() > 0) {
            transactions.putAll(financialCommitments.stream().map(fc -> {
                ExpenseTransactionDto fcTransaction = financialCommitmentMapper.map(fc);
                fcTransaction.setCategoryCode(FinancialCommitmentType.toExpenseCategory(fc.getType()));
                fcTransaction.setFrequency(ExpenseFrequency.MONTHLY);
                return fcTransaction;
            }).collect(Collectors.toMap(k -> index.getAndIncrement() + "_" + k.getCategoryCode().name(), o -> o)));
        }

        return transactions;

    }

}