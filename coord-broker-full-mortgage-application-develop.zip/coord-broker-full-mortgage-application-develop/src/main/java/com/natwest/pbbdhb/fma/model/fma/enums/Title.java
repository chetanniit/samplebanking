package com.natwest.pbbdhb.fma.model.fma.enums;

import java.util.Arrays;
import java.util.List;

import static com.natwest.pbbdhb.fma.model.fma.enums.Gender.FEMALE;
import static com.natwest.pbbdhb.fma.model.fma.enums.Gender.MALE;

public enum Title {
    NONE (MALE, FEMALE),
    MR (MALE),
    MRS (FEMALE),
    MISS (FEMALE),
    MS (FEMALE),
    DR (MALE, FEMALE),
    REVEREND (MALE),
    PROFESSOR (MALE, FEMALE),
    SIR (MALE),
    LORD (MALE),
    LADY (FEMALE),
    CAPTAIN (MALE, FEMALE),
    MAJOR (MALE, FEMALE),
    COLONEL (MALE, FEMALE),
    MASTER (MALE),
    HON (MALE, FEMALE),
    MX (MALE, FEMALE),
    SISTER (FEMALE),
    VISCOUNT (MALE),
    COUNTESS (FEMALE),
    EARL (MALE),
    OTHER (MALE, FEMALE);

    private List<Gender> genders;

    Title(Gender... genders) {
        this.genders = Arrays.asList(genders);
    }

    public boolean isApplicableTo(Gender gender) {
        return genders.contains(gender);
    }

}
