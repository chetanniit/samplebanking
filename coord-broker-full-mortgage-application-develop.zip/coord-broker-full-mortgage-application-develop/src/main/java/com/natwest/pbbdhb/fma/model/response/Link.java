package com.natwest.pbbdhb.fma.model.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Link {
    @Schema(example = "https://dev-api.natwest.com/mortgages/v1/documents/12345/get-upload-page")
    private String href;

    public static Link of(String href) {
        return new Link(href);
    }

}
