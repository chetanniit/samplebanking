package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.util.Constants;
import com.natwest.pbbdhb.fma.validator.SmartCountryIsoCodeValidation;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartPathCheck;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartPatternCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class UkOrScottishOrNIAddress extends BasicAddress {

    @Schema(required = true, example = "E11 2NB", maxLength = 8,
            description = "Must be a valid UK postcode. If application.scottishApplication is true, then pattern must match " +
                    Constants.SCT_POSTCODE_PATTERN +"." +
                    " If application.northernIrelandApplication is true, then pattern must match " +
                    Constants.NORTHERN_IRELAND_POSTCODE_PATTERN +"." +
                    " Else for all UK applications, pattern must match " +
                    Constants.UK_POSTCODE_PATTERN)
    @SmartValidation(conditions = {
            @SmartCondition(path = ".", values = {"equals", "property.address.postcode"}, smartCheck = SmartPathCheck.class),
            @SmartCondition(path = "/scottishApplication", values = "true", negate = true),
            @SmartCondition(path = "/northernIrelandApplication", values = "true", negate = true),
            @SmartCondition(path = "postcode", values = Constants.UK_POSTCODE_PATTERN, negate = true, smartCheck = SmartPatternCheck.class)
    }, message = "must be valid UK postcode")
    @SmartValidation(conditions = {
            @SmartCondition(path = ".", values = {"equals", "property.address.postcode"}, smartCheck = SmartPathCheck.class),
            @SmartCondition(path = "/scottishApplication", values = "true"),
            @SmartCondition(path = "/northernIrelandApplication", values = "true", negate = true),
            @SmartCondition(path = "postcode", values = Constants.SCT_POSTCODE_PATTERN, negate = true, smartCheck = SmartPatternCheck.class)
    }, message = "must be valid Scotland postcode")
    @SmartValidation(conditions = {
            @SmartCondition(path = ".", values = {"equals", "property.address.postcode"}, smartCheck = SmartPathCheck.class),
            @SmartCondition(path = "/scottishApplication", values = "true" , negate = true),
            @SmartCondition(path = "/northernIrelandApplication", values = "true"),
            @SmartCondition(path = "postcode", values = Constants.NORTHERN_IRELAND_POSTCODE_PATTERN, negate = true, smartCheck = SmartPatternCheck.class)
    }, message = "Address must be a valid Northern Ireland address")
    @Size(max = 8)
    @NotBlank(message = "cannot be null or empty")
    private String postcode;

    @Schema(required = true, maxLength = 2, example = "GB", pattern = "^GB$", description = "(ISO 3166-1, Alpha-2 code) Must be GB")
    @SmartCountryIsoCodeValidation
    @Pattern(regexp = "^GB$", message = "must be GB")
    @Size(max = 2)
    @NotBlank(message = "cannot be null or empty")
    private String countryIsoCode;

}
