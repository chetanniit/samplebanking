package com.natwest.pbbdhb.fma.serialization;

import com.fasterxml.jackson.core.JsonParser;

import java.io.IOException;
import java.util.Set;

public interface DeserializationValidator {

    Set<Class<?>> applicableForTypes();

    default DeserializationValidationException beforeSerialization(Class<?> targetType, JsonParser jsonParser) throws IOException {
        return null;
    }

    default DeserializationValidationException onSerializationException(Class<?> targetType, JsonParser jsonParser, Throwable rootCause) throws IOException {
        return null;
    }

}
