package com.natwest.pbbdhb.fma.error;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.exception.BrokerValidationFailException;
import com.natwest.pbbdhb.fma.exception.PaymentPathInvalidException;
import com.natwest.pbbdhb.fma.model.error.ErrorResponse;
import com.natwest.pbbdhb.fma.model.error.incoming.IncomingCodeMessageError;
import com.natwest.pbbdhb.fma.model.error.incoming.IncomingProductError;
import com.natwest.pbbdhb.fma.model.error.incoming.capie.CapieError;
import com.natwest.pbbdhb.fma.model.error.incoming.capie.CapieErrorContainer;
import com.natwest.pbbdhb.fma.model.error.incoming.income.IncomeErrorResponse;
import com.natwest.pbbdhb.fma.serialization.DeserializationValidationException;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.Error;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpStatusCodeException;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;

@ControllerAdvice
@Slf4j
public class ErrorHandler {

    private ObjectMapper objectMapper = JsonMapper.builder().build();

    @Value("${application.error-handling.show-exception-message}")
    private boolean showMessage;
    @Value("${application.showbadrequest.pattern}")
    private String showBadRequestPattern;

    @Autowired
    private ExecutionContext executionContext;

    @ExceptionHandler({ Exception.class })
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleUnhandledException(Exception ex) {
        StringBuilder errorMessage = new StringBuilder();
        errorMessage.append(ex.getMessage());
        if (nonNull(ex.getCause())) {
            errorMessage.append(" Cause: ").append(ex.getCause().getMessage());
        }
        logUnexpectedError(HttpStatus.INTERNAL_SERVER_ERROR, "Unhandled exception occurred.", ex);
        return hasMessageToShow(ex)
                ? new ResponseEntity<>(new ErrorResponse(errorMessage.toString()), HttpStatus.INTERNAL_SERVER_ERROR)
                : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler({ BrokerValidationFailException.class })
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBrokerValidationFailureException(BrokerValidationFailException ex) {
        logBusinessError(HttpStatus.FORBIDDEN, "BrokerValidationFail error during processing: {0}", ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler({ PaymentPathInvalidException.class })
    @ResponseBody
    public ResponseEntity<ErrorResponse> handlePaymentPathInvalidException(PaymentPathInvalidException ex) {
        logBusinessError(HttpStatus.BAD_REQUEST, "PaymentPathInvalidException raised: {0}", ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({ JsonProcessingException.class, ParseException.class, HttpMessageNotReadableException.class })
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleJsonProcessingException(Exception exception) {
        ResponseEntity<ErrorResponse> responseEntity = processDeserializationValidationException(exception);
        if (responseEntity != null) {
            return responseEntity;
        }
        InvalidFormatException formatException = findException(exception, InvalidFormatException.class);
        if (formatException != null) {
            logBusinessError(HttpStatus.BAD_REQUEST, "Invalid input JSON at: {0}", renderPath(formatException.getPath()));
            return new ResponseEntity<>(
                    new ErrorResponse(
                            MessageFormat.format("Invalid input JSON at: {0}", renderPath(formatException.getPath()))
                                    + (hasMessageToShow(exception) ? ". " + exception.getMessage() : "")),
                    HttpStatus.BAD_REQUEST);
        }
        JsonProcessingException jsonException = findException(exception, JsonProcessingException.class);
        if (jsonException != null) {
            logBusinessError(HttpStatus.BAD_REQUEST, "Invalid input JSON at line: {0}, column: {1}",
                    jsonException.getLocation().getLineNr(), jsonException.getLocation().getColumnNr());
            return new ResponseEntity<>(
                    new ErrorResponse(MessageFormat.format("Invalid input JSON at line: {0}, column: {1}",
                            jsonException.getLocation().getLineNr(), jsonException.getLocation().getColumnNr())
                            + (hasMessageToShow(exception) ? ". " + exception.getMessage() : "")),
                    HttpStatus.BAD_REQUEST);
        } else {
            logUnexpectedError(HttpStatus.BAD_REQUEST,  "Input processing error.", exception);
            return hasMessageToShow(exception)
                    ? new ResponseEntity<>(new ErrorResponse(exception.getMessage()), HttpStatus.BAD_REQUEST)
                    : new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @ExceptionHandler({ MethodArgumentNotValidException.class })
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        if (log.isDebugEnabled()) {
            log.debug("MethodArgumentNotValid error during processing: {}", ex.getMessage());
        }
        ErrorResponse errorResponse = new ErrorResponse();
        ex.getBindingResult().getAllErrors();

        for (ObjectError objectError : ex.getBindingResult().getAllErrors()) {
            if (objectError instanceof FieldError) {
                FieldError fieldError = (FieldError) objectError;
                errorResponse.addError(fieldError.getField() + " " + fieldError.getDefaultMessage());
            } else {
                errorResponse.addError(objectError.getDefaultMessage());
            }
        }
        if (errorResponse.getErrors() != null) {
            errorResponse.getErrors().sort(String::compareTo);
            logBusinessError(HttpStatus.BAD_REQUEST, "MethodArgumentNotValid [{0}]", String.join(", ", errorResponse.getErrors()));
        } else {
            logBusinessError(HttpStatus.BAD_REQUEST, "MethodArgumentNotValid error");
        }
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({ HttpStatusCodeException.class })
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpStatusCodeException(HttpStatusCodeException ex) {
        String message = ex.getResponseBodyAsString();
        HttpStatusCode statusCode = ex.getStatusCode();
        Pattern p = Pattern.compile(showBadRequestPattern);
        Matcher m = p.matcher(message);
        boolean showBadRequestMessage=m.find();

        ResponseEntity<ErrorResponse> responseEntity;
        if (statusCode.is4xxClientError() && !showMessage && !showBadRequestMessage) {
            responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            responseEntity = extractError(statusCode, message, getExtractors(statusCode), showBadRequestMessage);
        }

        logBusinessError(responseEntity.getStatusCode(), "HttpServerErrorException from \"{0}\": {1}",
                executionContext.getLastDownstreamEndpoint(), message);

        return responseEntity;
    }

    private ResponseEntity<ErrorResponse> extractError(HttpStatusCode defaultStatusCode, String message,
            List<ErrorExtractor> errorExtractors,boolean showBadRequest) {
        for (ErrorExtractor<Object> ext : errorExtractors) {
            try {
                Object error = objectMapper.readValue(message, ext.getJacksonType());
                List<String> messages;
                HttpStatusCode status;
                if (ext.isCollection()) {
                    Collection<Object> errors = (Collection<Object>) error;
                    status = errors.stream().map(err -> ext.getStatusExtractor().apply(err)).filter(Objects::nonNull)
                            .findFirst().orElse(defaultStatusCode);
                    messages = errors.stream()
                            .flatMap(err -> ext.getMessageExtractor().apply(err).stream().filter(Objects::nonNull))
                            .collect(Collectors.toList());
                } else {
                    status = ext.getStatusExtractor().apply(error);
                    messages = ext.getMessageExtractor().apply(error);
                }
                if (status == null || messages == null || messages.isEmpty() || messages.stream().allMatch(Objects::isNull)) {
                    continue;
                }
             messages=messages.stream().map(m->transform(m,showBadRequest)).collect(Collectors.toList());
              
				return !showBadRequest ? showMessage
						? new ResponseEntity<>(new ErrorResponse(executionContext.getLastDownstreamEndpoint(), status.toString(), messages),
								HttpStatus.INTERNAL_SERVER_ERROR)
						: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR)
						: new ResponseEntity<>(new ErrorResponse(messages), status);
            } catch (JsonProcessingException e) {
                // proceed to the next potential error type
            }
        }
        return showMessage ? new ResponseEntity<>(
                new ErrorResponse(executionContext.getLastDownstreamEndpoint(), defaultStatusCode.toString(), message),
                HttpStatus.INTERNAL_SERVER_ERROR) : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

	private String transform(String message,boolean showBadRequest) {
		if (message.contains("validProduct") && showBadRequest) {
			try {
				IncomingProductError error = objectMapper.readValue(message, IncomingProductError.class);
				return error.getMessage();
			} catch (JsonProcessingException e) {
				return message;
			}
		}

		return message;
	}
    
    private String renderPath(List<JsonMappingException.Reference> path) {
        StringBuilder sb = new StringBuilder();
        for (JsonMappingException.Reference reference : path) {
            if (reference.getFieldName() != null) {
                sb.append(".").append(reference.getFieldName());
            }
            if (reference.getIndex() >= 0) {
                sb.append("[").append(reference.getIndex()).append("]");
            }
        }
        String result = sb.toString();
        return result.startsWith(".") ? result.substring(1) : result;
    }

    private <T extends Throwable> T findException(Throwable root, Class<T> toFind) {
        Throwable candidate = root;
        while (candidate != null && !toFind.isAssignableFrom(candidate.getClass())) {
            candidate = candidate.getCause();
        }
        return (T) candidate;
    }

    private boolean hasMessageToShow(Exception exception) {
        return showMessage || HttpStatusCodeException.class.isAssignableFrom(exception.getClass())
                || isNatWestException(exception);
    }

    private boolean isNatWestException(Exception exception) {
        Throwable ex = exception;
        while (ex != null) {
            Package pack = ex.getClass().getPackage();
            if (pack != null && pack.getName().startsWith("com.natwest")) {
                return true;
            }
            ex = ex.getCause();
        }
        return false;
    }

    private ResponseEntity<ErrorResponse> processDeserializationValidationException(Exception ex) {
        DeserializationValidationException exception = findException(ex, DeserializationValidationException.class);
        if (exception != null) {
            String message = MessageFormat.format("{0} {1}",
                        exception.getFieldPath(), exception.getMessage());
            logBusinessError(HttpStatus.BAD_REQUEST, "DeserializationValidation error during processing: {0}", message);
            return new ResponseEntity<>(new ErrorResponse(message), HttpStatus.BAD_REQUEST);
        }
        return null;
    }

    private void logBusinessError(HttpStatusCode status, String message, Object... args) {
        if (log.isErrorEnabled()) {
            log.error(inline(status.toString() + "\n" +
                    "MI: Error " + executionContext.toString() + "\n" +
                    MessageFormat.format(message, args)));
        }
    }

    private void logUnexpectedError(HttpStatus status, String message, Throwable exception) {
        if (!log.isErrorEnabled()) {
            return;
        }

        StringBuilder messageBuilder = new StringBuilder(message);

        // render status
        messageBuilder.append("\n").append(status.toString());

        // render context
        messageBuilder.append("\n").append("MI: Error ").append(executionContext.toString());

        // render exception
        final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        messageBuilder.append("\n").append("Exception message: ").append(exception.getMessage())
                .append("\n").append("Exception: ");
        Throwable cause = exception;
        while (cause != null) {
            try (PrintStream printStream = new PrintStream(outputStream, true, StandardCharsets.UTF_8.name())) {
                exception.printStackTrace(printStream);
                messageBuilder.append(outputStream.toString(StandardCharsets.UTF_8.name()));
                messageBuilder.append("\n");
            } catch (UnsupportedEncodingException e) {
                messageBuilder.append(e.getMessage());
            }
            cause = cause.getCause();
        }

        log.error(inline(messageBuilder.toString()));
    }

    private String inline(String s) {
        return s.trim().replaceAll("(\\s*[\\n\\r]\\s*)+", "\\\\n ");
    }
    
    private List<ErrorExtractor> getExtractors(HttpStatusCode statusCode){
    	return Arrays.asList(
                new ErrorExtractor<>(ErrorResponse.class, ErrorResponse::getErrors, error -> statusCode),
                new ErrorExtractor<>(IncomeErrorResponse.class, error -> Collections.singletonList(error.toString()),
                        error -> Optional.ofNullable(error.getResponseStatus()).orElse(HttpStatus.valueOf(statusCode.value()))),
                new ErrorExtractor<>(CapieErrorContainer.class,
                        error -> error.getErrors().stream().map(CapieError::getMessage).collect(Collectors.toList()),
                        error -> statusCode),
                new ErrorExtractor<>(IncomingCodeMessageError.class,
                        error -> Collections.singletonList(error.getErrorMessage()), error -> statusCode),
                new ErrorExtractor<>(FullMortgageApplicationExtendedResponse.class,
                        error -> error.getErrors().stream().map(Error::getMessage).collect(Collectors.toList()),
                        error -> statusCode));
    }

    @Getter
    private class ErrorExtractor<T> {
        private JavaType jacksonType;
        private Function<T, List<String>> messageExtractor;
        private Function<T, HttpStatusCode> statusExtractor;

        public ErrorExtractor(Class<T> errorType, Function<T, List<String>> messageExtractor,
                Function<T, HttpStatusCode> statusExtractor) {
            this.jacksonType = objectMapper.getTypeFactory().constructType(errorType);
            this.messageExtractor = messageExtractor;
            this.statusExtractor = statusExtractor;
        }

        public ErrorExtractor(Class<? extends Collection> collectionType, Class<T> errorType,
                Function<T, List<String>> messageExtractor, Function<T, HttpStatusCode> statusExtractor) {
            this.jacksonType = objectMapper.getTypeFactory().constructCollectionType(collectionType, errorType);
            this.messageExtractor = messageExtractor;
            this.statusExtractor = statusExtractor;
        }

        public boolean isCollection() {
            return jacksonType instanceof CollectionType;
        }

    }

}
