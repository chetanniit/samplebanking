package com.natwest.pbbdhb.fma.configuration;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.rbs.dws.transport.config.RestContext;
import com.rbs.dws.transport.rest.SecureClientHttpRequestFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Configuration("RestTemplateConfiguration")
@Slf4j
@Import(RestContext.class)
public class RestTemplateConfiguration {

    @Bean("restTemplateForApiCalls")
    @Primary
    public RestTemplate restTemplateForApiCalls(@Value("${iam.rest.template}") boolean isJwtEnabled,
            @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate secureRestTemplate) {
        RestTemplate restTemplate = isJwtEnabled ? secureRestTemplate : new RestTemplate(clientHttpRequestFactory());
        restTemplateSetup(restTemplate);
        return restTemplate;
    }

    @Bean("restTemplateForPatchApiCalls")
    public RestTemplate restTemplateForPatchApiCalls(@Value("${iam.rest.template}") boolean isJwtEnabled,
            @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate secureRestTemplate,
            @Qualifier("iamJwtChainSecureClientHttpRequestFactory") SecureClientHttpRequestFactory<?> factory) {
        RestTemplate restTemplate = isJwtEnabled ? secureRestTemplate : new RestTemplate(clientHttpRequestFactory());
        if (isJwtEnabled) {
            factory.setDefaultMediaType(new MediaType("application", "json-patch+json"));
            restTemplate.setRequestFactory(factory);
        }
        restTemplateSetup(restTemplate);
        return restTemplate;
    }

    private void restTemplateSetup(RestTemplate restTemplate) {
        final ClientHttpRequestFactory requestFactory = restTemplate.getRequestFactory();
        restTemplate.setRequestFactory((uri, httpMethod) -> {
            ExecutionContext.getInstance().setLastDownstreamEndpoint(MessageFormat.format("{0}: {1}", httpMethod.name(), uri.toString()));
            return requestFactory.createRequest(uri, httpMethod);
        });
        for (ObjectMapper objectMapper : getObjectMappers(restTemplate)) {
            objectMapperSetup(objectMapper);
        }
    }

    private void objectMapperSetup(ObjectMapper objectMapper) {
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        SimpleModule module = new SimpleModule();
        module.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        module.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS][.SS][.S]")));
        module.addSerializer(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        module.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS][.SS][.S]")));
        objectMapper.registerModule(module);
    }

    private HttpComponentsClientHttpRequestFactory clientHttpRequestFactory() {
        return new HttpComponentsClientHttpRequestFactory();
    }

    private List<ObjectMapper> getObjectMappers(RestTemplate restTemplate) {
        return restTemplate.getMessageConverters().stream()
                .filter(converter -> AbstractJackson2HttpMessageConverter.class.isAssignableFrom(converter.getClass()))
                .map(c -> ((AbstractJackson2HttpMessageConverter) c).getObjectMapper()).collect(Collectors.toList());
    }

}
