package com.natwest.pbbdhb.fma.model.error.incoming;

import lombok.Getter;

@Getter
public class IncomingProductError {
	private String validateProduct;
	private String productCode;
	private String message;
	private boolean validProduct;
}
