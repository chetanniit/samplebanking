package com.natwest.pbbdhb.fma.mapper.cases;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.openapi.fma.HardscoreDecision;
import org.mapstruct.Mapper;

@Mapper(config = MappingConfig.class)
public interface HardscoreMapper {

    HardscoreDecision toHardScoreDecision(com.natwest.pbbdhb.fma.model.response.HardScoreDecision hardscoreDecsion);

}
