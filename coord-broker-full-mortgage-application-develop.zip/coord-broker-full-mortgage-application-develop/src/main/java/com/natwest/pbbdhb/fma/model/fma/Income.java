package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.IncomeType;
import com.natwest.pbbdhb.fma.model.fma.enums.PaymentFrequency;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Income {

    @Schema(implementation = IncomeType.class, required = true)
    @NotNull
    private IncomeType type;

    @Schema(implementation = PaymentFrequency.class, required = true)
    @NotNull
    private PaymentFrequency frequency;

    @Schema(example = "2000", required = true, maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal amount;

}
