package com.natwest.pbbdhb.fma.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

import jakarta.json.JsonPatch;

@Getter
@Builder
public class PatchDto {
    @JsonProperty("op")
    private JsonPatch.Operation operation;
    private String path;
    private String from;
    private Object value;
}
