package com.natwest.pbbdhb.fma.model.fma.enums;

public enum BusinessType {
    SOLE_TRADER, PARTNERSHIP, LIMITED_COMPANY
}
