package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ChapsFeeType {
    DEDUCT_FROM_ADVANCE, NO_FEE
}
