package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.exception.TechnicalException;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCheck;
import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * The first parameter must be a name of String class method that has one String or CharSequence parameter and returns boolean<br>
 * The method will be applied to the annotated field path (array indexes are trimmed)<br>
 * The second parameter value is passed as the method parameter value<br>
 * Usage example: {@code @SmartCondition(path = ".", values = {"endsWith", "applicants[].email"}, smartCheck = SmartPathCheck.class)}
 */
public class SmartPathCheck implements SmartCheck<Object> {

    @Override
    public boolean check(Object actualValue, List<String> conditionValues, SmartContext smartContext) {
        Method method = getMethod(conditionValues.get(0));
        try {
            return (boolean) method.invoke(smartContext.getContextPath().replaceAll("\\[\\d+\\]", "[]"), conditionValues.get(1));
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new TechnicalException(e);
        }
    }

    private Method getMethod(String name) {
        Method method;
        try {
            method = String.class.getMethod(name, String.class);
        } catch (NoSuchMethodException e) {
            try {
                method = String.class.getMethod(name, CharSequence.class);
            } catch (NoSuchMethodException e1) {
                try {
                    method = String.class.getMethod(name, Object.class);
                } catch (NoSuchMethodException e2) {
                    throw new TechnicalException(e2);
                }
            }
        }
        return method;
    }

}
