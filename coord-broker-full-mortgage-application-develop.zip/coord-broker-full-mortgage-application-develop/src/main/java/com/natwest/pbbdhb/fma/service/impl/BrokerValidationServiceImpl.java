package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailRequest;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailResponse;
import com.natwest.pbbdhb.fma.service.BrokerValidationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class BrokerValidationServiceImpl implements BrokerValidationService {

    @Value("${broker.validation.endpoint}")
    private String endPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ExecutionContext executionContext;

    @Override
    public BrokerDetailResponse validate(BrokerDetailRequest brokerDetailRequest) {
        log.info("brokerValidation: called");
        log.debug("validate: called with validate_brokerDetailRequest = {}", brokerDetailRequest);
        log.debug("Broker validation endpoint called = {}", endPointUrl);

        BrokerDetailResponse brokerDetailResponse = restTemplate.postForObject(endPointUrl, brokerDetailRequest,
                BrokerDetailResponse.class);
        executionContext.setBrokerDetail(brokerDetailResponse);

        log.debug("brokerValidation: validate_brokerDetailResponse={}", brokerDetailResponse);
        log.info("brokerValidation: complete");

        return brokerDetailResponse;
    }
}
