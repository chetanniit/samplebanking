package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.TelephoneType;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class Telephone {

    @Schema(implementation = TelephoneType.class, required = true)
    @NotNull
    private TelephoneType type;

    @Schema(description = "minimum of 10 and maximum of 15 digit number", example = "04412345678", pattern = "^0\\d{9,14}$", required = true)
    @Pattern(regexp = "^0\\d{9,14}$")
    @NotBlank(message = "cannot be null or empty")
    private String number;

    @Schema(required = true, description = "Is this the Preferred contact number", example = "true", allowableValues = {
        "true", "false"})
    @NotNull
    private Boolean preferred;
}
