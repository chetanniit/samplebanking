package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;

public interface IncomeService extends BaseService {

    ValidatedCaseIncomeDto getIncome(String caseId, String brand);

    ValidatedCaseIncomeDto createIncome(String caseId, String brand, ValidatedCaseIncomeDto incomeRequest);
}
