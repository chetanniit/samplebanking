package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class CreditHistory {

    @Schema(required = true, example = "true", allowableValues = { "true",
            "false" }, description = "In the last 6 Years"
                    + " have You ever been insolvent, bankrupt or sequestrated ?")
    @NotNull
    private Boolean bankrupt;

    @Schema(maxLength = 2000, description = "Required if bankrupt is TRUE")
    @SmartRequired(conditions = @SmartCondition(path = "bankrupt", values = "true"))
    @Length(max = 2000)
    private String bankruptDetails;

    @Schema(required = true, example = "true", allowableValues = { "true",
            "false" }, description = "In the last 6 Years have You ever been involved in court proceedings"
                    + " in respect of debt or financial agreements with creditors?")
    @NotNull
    private Boolean courtProceedings;

    @Schema(maxLength = 2000, description = "Required if courtProceedings is TRUE")
    @SmartRequired(conditions = @SmartCondition(path = "courtProceedings", values = "true"))
    @Length(max = 2000)
    private String courtProceedingDetails;

    @Schema(implementation = String.class, example = "2019-01-19", pattern = "yyyy-MM-dd", description = "Required if bankrupt is TRUE")
    @SmartRequired(conditions = @SmartCondition(path = "bankrupt", values = "true"))
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate bankruptcyDate;
}
