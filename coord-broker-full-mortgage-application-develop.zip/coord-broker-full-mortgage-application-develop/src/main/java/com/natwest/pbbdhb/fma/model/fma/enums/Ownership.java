package com.natwest.pbbdhb.fma.model.fma.enums;

public enum Ownership {
    APPLICANT_ONE, APPLICANT_TWO, JOINT
}
