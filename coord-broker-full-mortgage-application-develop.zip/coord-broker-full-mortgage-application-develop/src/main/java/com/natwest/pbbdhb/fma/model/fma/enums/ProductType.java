package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ProductType {
    FIXED, TRACKER
}
