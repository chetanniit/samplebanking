package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.natwest.pbbdhb.fma.model.fma.enums.OccupyStatus;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({ "isCurrentAddress", "ukAddress" })
@Data
@NoArgsConstructor
public class ApplicantAddress extends Address {

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean isCurrentAddress;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean ukAddress;

    @Schema(required = true, implementation = OccupyStatus.class, example = "OWNER_NO_MORTGAGE")
    @NotNull
    private OccupyStatus occupyStatus;

    @Schema(required = true, minimum = "1", maximum = "12", example = "6")
    @NotNull
    @Min(1)
    @Max(12)
    private Integer startMonth;

    @Schema(required = true, minimum = "1900", maximum = "2100", example = "2010")
    @NotNull
    @Min(1900)
    @Max(2100)
    private Integer startYear;

    @Schema(name = "currentPropertyValue", example = "250000", description = "Required if occupyStatus is OWNER_MORTGAGED or OWNER_NO_MORTGAGE and isCurrentAddress=true and loan purpose is HOUSE_PURCHASE, no decimal places", minimum = "1", maximum = "99999999", multipleOf = 1)
    @SmartRequired(conditions = {
            @SmartCondition(path = "occupyStatus", values = { "OWNER_MORTGAGED", "OWNER_NO_MORTGAGE" }),
            @SmartCondition(path = "isCurrentAddress", values = "true"),
            @SmartCondition(path = "/loanPurpose", values = "HOUSE_PURCHASE")
    })
    @DecimalMin("1")
    @DecimalMax("99999999")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal currentPropertyValue;
}