package com.natwest.pbbdhb.fma.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.natwest.pbbdhb.fma.model.gmsstate.BrokerDetail;
import com.natwest.pbbdhb.fma.model.gmsstate.GmsSourceOneSourceTwoResponse;
import com.natwest.pbbdhb.fma.service.GmsProductStateService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GmsProductStateServiceImpl implements GmsProductStateService {

    @Value("${productstate.endpoint}")
    private String endPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    static final String BRAND_HEADER = "brand";

    @Override
    public List<GmsSourceOneSourceTwoResponse> getGmsProductStateResponse(BrokerDetail brokerDetail, String brand) {
        log.info("getGmsProductStateResponse: called");
        log.debug("getGmsProductStateResponse: called with request = {}", brokerDetail);
        log.debug("gms product state called = {}", endPointUrl);
        log.debug("getGmsProductStateResponse: called with brand = {}", brand);

        List<GmsSourceOneSourceTwoResponse> response = restTemplate.exchange(endPointUrl, HttpMethod.POST,
                new HttpEntity<>(brokerDetail, createHttpHeaders(CONTENT_TYPE_APPLICATION_JSON, brand)),
                new ParameterizedTypeReference<List<GmsSourceOneSourceTwoResponse>>() {
                }).getBody();
        log.debug("gmsResponse {}", response);
        log.info("getGmsProductStateResponse: complete");

        return response;
    }

    private HttpHeaders createHttpHeaders(String contentType, String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, contentType);
        headers.add(BRAND_HEADER, brand);
        return headers;
    }

}
