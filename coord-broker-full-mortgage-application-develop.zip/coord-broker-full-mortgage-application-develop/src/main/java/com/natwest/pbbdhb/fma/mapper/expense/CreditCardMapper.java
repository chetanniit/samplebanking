package com.natwest.pbbdhb.fma.mapper.expense;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.income.expense.model.enums.YesNo;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import com.natwest.pbbdhb.openapi.fma.CreditCard;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.util.Objects;

@Mapper(config = MappingConfig.class)
public interface CreditCardMapper {

    @Mapping(target = "merchantName", source = "creditCard.provider")
    @Mapping(target = "outstandingBalance", source = "creditCard.totalBalance")
    @Mapping(target = "redeemedOrLessThanSixMonths", source = "creditCard.toBeRepaid", qualifiedByName = "getRedeemedOrLessThanSixMonths")
    @Mapping(target = "consolidationAmount", source = ".", qualifiedByName = "getConsolidatedAmount")
    ExpenseTransactionDto map(CreditCard creditCard);

    @Named("getRedeemedOrLessThanSixMonths")
    default YesNo getRedeemedOrLessThanSixMonths(final Boolean redeemedOrLessThanSixMonths) {
        return redeemedOrLessThanSixMonths ? YesNo.Y : YesNo.N;
    }

	@Named("getConsolidatedAmount")
	default BigDecimal getPartialRefinanced(final CreditCard creditCard) {

		return Objects.nonNull(creditCard.getPartialRefinanced()) ? creditCard.getPartialRefinanced() : BigDecimal.ZERO;
	}

}
