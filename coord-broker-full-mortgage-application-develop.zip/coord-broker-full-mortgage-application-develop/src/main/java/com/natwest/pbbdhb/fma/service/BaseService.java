package com.natwest.pbbdhb.fma.service;

public interface BaseService {

    String CONTENT_TYPE = "Content-Type";
    String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    String BRAND_HEADER = "brand";

    /** Ready for move to Java 9+ **/

}
