package com.natwest.pbbdhb.fma.model.error;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Setter
@Getter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {

    @Schema(hidden = true)
    @JsonProperty("endpoint")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String endpoint = null;

    @Schema(hidden = true)
    @JsonProperty("statusCode")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String statusCode = null;

    @JsonProperty("errors")
    private List<String> errors = null;

    public ErrorResponse(String error) {
        this.addError(error);
    }

    public ErrorResponse(String endpoint, String statusCode, String error) {
        this.endpoint = endpoint;
        this.statusCode = statusCode;
        this.addError(error);
    }

    public ErrorResponse(Collection<String> errors) {
    	 if (this.errors == null) {
             this.errors = new ArrayList<>();
         }
        this.errors.addAll(errors);
    }

    public final ErrorResponse addError(String error) {
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }

        this.errors.add(error);
        return this;
    }
}
