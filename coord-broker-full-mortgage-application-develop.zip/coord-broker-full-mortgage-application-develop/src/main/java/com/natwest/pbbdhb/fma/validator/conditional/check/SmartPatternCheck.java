package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.exception.TechnicalException;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCheck;
import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;

import java.lang.reflect.Field;
import java.util.List;
import java.util.regex.Pattern;

/**
 * The first parameter is a regular expression to evaluate against the value obtained by the "path" annotation parameter<br>
 * The second and further parameters are optional and may contain names of {@link Pattern} flag constant fields (eg. DOTALL)<br>
 * Usage example: {@code @SmartCondition(path = "path/to/field/to/check", values = {"^ID.*\\d+$", "CASE_INSENSITIVE", "DOTALL"}, smartCheck = SmartPatternCheck.class)}
 */
public class SmartPatternCheck implements SmartCheck<Object> {

    @Override
    public boolean check(Object actualValue, List<String> conditionValues, SmartContext smartContext) {

        if (actualValue == null || actualValue.toString() == null) {
            return false;
        }

        Integer flags = conditionValues.stream().skip(1).map(flagName -> {
            try {
                Field flagField = Pattern.class.getDeclaredField(flagName);
                return (Integer) flagField.get(Pattern.class);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                throw new TechnicalException(e);
            }
        }).reduce(0, (l, r) -> l | r);

        return Pattern.compile(conditionValues.get(0), flags).matcher(actualValue.toString()).find();

    }

}
