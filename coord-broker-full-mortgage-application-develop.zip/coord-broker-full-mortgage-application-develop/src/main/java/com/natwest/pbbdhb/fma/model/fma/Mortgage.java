package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.MortgageRepaymentType;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartCollectionSizeCheck;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@SmartValidation(
        conditions = @SmartCondition(path = "/", negate = true, smartCheck = SmartChecks.DebtConsolidationAmountMatches.class),
        message = "Total amount of loans and credit cards being consolidated should be equal to the amount of additional borrowings for debt consolidation",
        showPathInMessage = false
)
public class Mortgage {

    @Schema(description = "required  if loanPurpose = HOUSE_PURCHASE/REMORTGAGE, no decimal places", minimum = "1", maximum = "99999999", multipleOf = 1)
    @SmartRequired(conditions = @SmartCondition(path = "../loanPurpose", values = { "HOUSE_PURCHASE", "REMORTGAGE" }))
    @DecimalMin(value = "1")
    @DecimalMax(value = "99999999")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal propertyValue;

    @Schema(description = "required if loanPurpose = HOUSE_PURCHASE, no decimal places", minimum = "1", maximum = "99999999", multipleOf = 1)
    @SmartRequired(conditions = @SmartCondition(path = "../loanPurpose", values = "HOUSE_PURCHASE"))
    @DecimalMin(value = "1")
    @DecimalMax(value = "99999999")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal purchasePrice;

    @Schema(description = "required if loanPurpose = REMORTGAGE, no decimal places", minimum = "0", maximum = "99999999", multipleOf = 1)
    @SmartRequired(conditions = @SmartCondition(path = "../loanPurpose", values = "REMORTGAGE"))
    @DecimalMin(value = "0")
    @DecimalMax(value = "99999999")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal outstandingMortgage;

    @ArraySchema(schema = @Schema(implementation = AdditionalBorrowing.class), uniqueItems = true)
    @Valid
    private List<AdditionalBorrowing> additionalBorrowings;

    @Schema(required = true, description = "for a REMORTGAGE journey, mortgageAmount should be equal to sum of additionalBorrowing amount + outstandingMortgage, no decimal places", example = "400000", minimum = "1", maximum = "99999999", multipleOf = 1)
    @SmartValidation(conditions = {
            @SmartCondition(path = "../loanPurpose", values = "REMORTGAGE"),
            @SmartCondition(path = ".", negate = true, smartCheck = SmartChecks.MortgageAmountEqualToAdBoPlusOutstanding.class)
    }, message = "should be equal to sum of additionalBorrowings amount + outstandingMortgage")
    @DecimalMin(value = "1")
    @DecimalMax(value = "99999999")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal mortgageAmount;

    @Schema(required = true, example = "30", minimum = "0", maximum = "99")
    @Min(0)
    @Max(99)
    @NotNull
    private Integer mortgageTermYears;

    @Schema(required = true, example = "11", minimum = "0", maximum = "11")
    @Min(0)
    @Max(11)
    @NotNull
    private Integer mortgageTermMonths;

    @Schema(implementation = MortgageRepaymentType.class, required = true, example = "REPAYMENT")
    @NotNull
    private MortgageRepaymentType mortgageType;

    @Schema(example = "false", allowableValues = { "true",
            "false" }, description = "Required if loanPurpose = REMORTGAGE and levelOfService = ADVISED")
    @SmartRequired(conditions = {
            @SmartCondition(path = "../loanPurpose", values = "REMORTGAGE"),
            @SmartCondition(path = "../levelOfService", values = "ADVISED")
    })
    private Boolean mortgagePrisoner;

    @Schema(example = "true", allowableValues = { "true", "false" })
    private Boolean rightToBuy;

    @Schema(example = "true", allowableValues = { "true", "false" })
    private Boolean mortgageGuarantee;

    @Schema(description = "Required if mortgageType is INTEREST_ONLY or MIXED", implementation = InterestOnly.class)
    @SmartRequired(conditions = @SmartCondition(path = "mortgageType", values = { "INTEREST_ONLY", "MIXED" }))
    @Valid
    private InterestOnly interestOnly;

    @ArraySchema(
            arraySchema = @Schema(description = "Products selected"),
            schema = @Schema(implementation = ProductDetails.class),
            uniqueItems = true, minItems = 1, maxItems = 200
    )
    @Size(min = 1, max = 200)
    @NotNull
    @Valid
    private List<ProductDetails> products;

    @ArraySchema(
            arraySchema = @Schema(description = "required if loanPurpose = HOUSE_PURCHASE"),
            schema = @Schema(implementation = Deposit.class)
    )
    @SmartRequired(conditions = @SmartCondition(path = "../loanPurpose", values = "HOUSE_PURCHASE"))
    @Valid
    private List<Deposit> deposits;

    @ArraySchema(
            arraySchema = @Schema(description = "Provide a list of background properties include Second home, Holiday and Buy to Let homes"),
            schema = @Schema(implementation = OtherProperty.class),
            uniqueItems = true
    )
    @SmartValidation(
    		conditions = {
    		 @SmartCondition(path = "../type", values = "RESIDENTIAL"),
             @SmartCondition(path = "<field>", values = {">", "15"}, smartCheck = SmartCollectionSizeCheck.class)},
            message = "maximum allowed properties is 15"
    )
    @SmartValidation(
    		conditions = {
    		 @SmartCondition(path = "../type", values = "BUY_TO_LET"),
             @SmartCondition(path = "<field>", values = {">", "14"}, smartCheck = SmartCollectionSizeCheck.class)},
            message = "maximum allowed properties is 14"
    )
    @Valid
    private List<OtherProperty> otherProperties;

    @Schema(description = "Required if application.type = BUY_TO_LET")
    @SmartRequired(conditions = @SmartCondition(path = "../type", values = "BUY_TO_LET"))
    @Valid
    private BuyToLet buyToLet;

}
