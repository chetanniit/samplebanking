package com.natwest.pbbdhb.fma.model.fma.enums;

public enum SchemeType {
    HELP_TO_BUY, OTHER
}
