package com.natwest.pbbdhb.fma.model.fma.enums;

public enum LoanPurpose {
    HOUSE_PURCHASE, REMORTGAGE
}
