package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.BusinessType;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartNumberCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class SelfEmployed {

    @Schema(implementation = BusinessType.class, example = "SOLE_TRADER", required = true)
    @NotNull
    private BusinessType businessType;

    @Schema(required = true, implementation = String.class, example = "2010-01-01", pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @NotNull
    @SmartValidation(conditions = {
            @SmartCondition(path = "dateEstablished", negate = true, smartCheck = SmartChecks.SelfEstablishedDate.class)
    }, message = "cannot be older than 99 years and 11 months")
    private LocalDate dateEstablished;

    @Schema(example = "2021", pattern = "^\\d{4}", description = "Latest Full Trading Year", required = true)
    @Pattern(regexp = "^\\d{4}")
    @SmartValidation(
            conditions = @SmartCondition(path = "latestTradingYear", values = { "<=", "path:previousTradingYear" }, smartCheck = SmartNumberCheck.class),
            message = "must be greater than previousTradingYear"
    )
    @NotBlank(message = "cannot be null or empty")
    private String latestTradingYear;

    @Schema(example = "2021", pattern = "^\\d{4}", description = "Required if drawingPrevious or dividendsPrevious is supplied for LIMITED_COMPANY Or netProfitPrevious is supplied for SOLE_TRADER Or PARTNERSHIP")
    @Pattern(regexp = "^\\d{4}")
    @SmartRequired(conditions = {
            @SmartCondition(path = "businessType", values = { "SOLE_TRADER", "PARTNERSHIP" }),
            @SmartCondition(path = "netProfitPrevious", values = { ">=", "0" }, smartCheck = SmartNumberCheck.class)
    })
    @SmartRequired(conditions = {
            @SmartCondition(path = "businessType", values = "LIMITED_COMPANY"),
            @SmartCondition(path = "drawingsPrevious", nullOrEmpty = true, negate = true)
    })
    @SmartRequired(conditions = {
            @SmartCondition(path = "businessType", values = "LIMITED_COMPANY"),
            @SmartCondition(path = "dividendsPrevious", nullOrEmpty = true, negate = true)
    })
    private String previousTradingYear;

    @Schema(minimum = "0", maximum = "99999999", example = "20000", multipleOf = 1, description = "Cumulative Salary from Limited"
            + " Company for Company's Latest Financial Year, required if applicant businessType = LIMITED_COMPANY, no decimal places")
    @SmartRequired(conditions = @SmartCondition(path = "businessType", values = "LIMITED_COMPANY"))
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    private BigDecimal drawingsLatest;

    @Schema(minimum = "0", maximum = "99999999", example = "20000", multipleOf = 1, description = "Cumulative Salary from Limited"
            + " Company for Company's Previous Financial Year, no decimal places")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    private BigDecimal drawingsPrevious;

    @Schema(minimum = "0", maximum = "99999999", example = "50000", multipleOf = 1, description = "Cumulative Dividend from Limited"
            + " Company for Company's Latest Financial Year, no decimal places")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    private BigDecimal dividendsLatest;

    @Schema(minimum = "0", maximum = "99999999", example = "50000", multipleOf = 1, description = "Cumulative Dividend from Limited"
            + " Company for Company's Previous Financial Year, no decimal places")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    private BigDecimal dividendsPrevious;

    @Schema(minimum = "0", maximum = "99999999", example = "70000", multipleOf = 1, description = "Net Profit of Sole "
            + "Trader/Partnership for Current Year, required if applicant businessType in {SOLE_TRADER, PARTNERSHIP}, no decimal places")
    @SmartRequired(conditions = @SmartCondition(path = "businessType", values = { "SOLE_TRADER", "PARTNERSHIP" }))
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    private BigDecimal netProfitLatest;

    @Schema(minimum = "0", maximum = "99999999", example = "70000", multipleOf = 1, description = "Net Profit of Sole"
            + " Trader/Partnership for Previous Year, no decimal places")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    private BigDecimal netProfitPrevious;

    @Schema(example = "true", description = "Own shares in the company?", allowableValues = { "true", "false" })
    private Boolean ownShare;

    @Schema(example = "75", description = "Required if ownShare is true as a percentage 0-100", minimum = "0", maximum = "100", multipleOf = 0.01)
    @SmartRequired(conditions = @SmartCondition(path = "ownShare", values = "true"))
    @Digits(integer = 3, fraction = 2, message = "must be a percentage with up to 2 decimal places")
    @Min(0)
    @Max(100)
    private BigDecimal employeeShare;

}