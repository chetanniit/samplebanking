package com.natwest.pbbdhb.fma.model.fma.enums;

public enum LevelOfService {
    ADVISED, ADVICE_REJECTED, NON_ADVISED, EXECUTION_ONLY
}
