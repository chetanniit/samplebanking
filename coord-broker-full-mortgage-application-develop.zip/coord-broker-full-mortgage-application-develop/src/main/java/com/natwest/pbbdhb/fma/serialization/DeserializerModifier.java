package com.natwest.pbbdhb.fma.serialization;

import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
import org.springframework.stereotype.Component;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class DeserializerModifier extends BeanDeserializerModifier {

    Map<Class<?>, List<DeserializationValidator>> validatorsByClass;

    public DeserializerModifier(Set<DeserializationValidator> validators) {
        this.validatorsByClass = transpose(validators, DeserializationValidator::applicableForTypes);
    }

    @Override
    public JsonDeserializer<?> modifyDeserializer(DeserializationConfig config, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return provideDeserializer(beanDesc, deserializer);
    }

    @Override
    public JsonDeserializer<?> modifyEnumDeserializer(DeserializationConfig config, JavaType type, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return provideDeserializer(beanDesc, deserializer);
    }

    private JsonDeserializer<?> provideDeserializer(BeanDescription beanDesc, JsonDeserializer<?> defaultDeserializer) {
        Class<?> beanClass = beanDesc.getBeanClass();
        Set<DeserializationValidator> validators = validatorsByClass.entrySet().stream()
                .filter(e -> e.getKey().isAssignableFrom(beanClass))
                .flatMap(e -> e.getValue().stream())
                .collect(Collectors.toSet());
        if (!validators.isEmpty()) {
            return new ValidatingDeserializer(defaultDeserializer, beanDesc.getBeanClass(), validators);
        }
        return defaultDeserializer;
    }

    private <K, V> Map<K, List<V>> transpose(Collection<V> collection, Function<V, Collection<K>> byCollection) {
        return collection.stream()
                .flatMap(v -> byCollection.apply(v).stream().map(t -> new AbstractMap.SimpleImmutableEntry<>(t, v)))
                .collect(Collectors.groupingBy(AbstractMap.SimpleImmutableEntry::getKey, Collectors.mapping(AbstractMap.SimpleImmutableEntry::getValue, Collectors.toList())));
    }

}
