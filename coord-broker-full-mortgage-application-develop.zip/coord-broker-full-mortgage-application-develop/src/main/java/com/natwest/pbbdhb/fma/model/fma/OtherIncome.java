package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.OtherIncomeType;
import com.natwest.pbbdhb.fma.model.fma.enums.PaymentFrequency;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class OtherIncome {

    @Schema(implementation = OtherIncomeType.class, required = true)
    @NotNull
    private OtherIncomeType type;

    @Schema(implementation = PaymentFrequency.class, required = true)
    @NotNull
    private PaymentFrequency frequency;

    @Schema(example = "1500", minimum = "1", maximum = "99999999", multipleOf = 1, required = true, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "1")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal amount;

}
