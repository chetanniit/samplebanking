package com.natwest.pbbdhb.fma.exception;

public class PaymentPathInvalidException extends RuntimeException {

    public PaymentPathInvalidException(String message) {
        super(message);
    }
}
