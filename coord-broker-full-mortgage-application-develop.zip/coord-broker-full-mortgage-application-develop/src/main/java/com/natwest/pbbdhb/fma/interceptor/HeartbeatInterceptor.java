package com.natwest.pbbdhb.fma.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
@Slf4j
public class HeartbeatInterceptor implements HandlerInterceptor {

    @Value("${application.heartbeat.client-id}")
    private String heartbeatClientId;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        log.debug("Inside Heartbeat Interceptor");
        if (heartbeatClientId.equals(request.getHeader("client_id"))) {
            response.setStatus(HttpServletResponse.SC_OK);

            return false;
        }
        return true;
    }
}
