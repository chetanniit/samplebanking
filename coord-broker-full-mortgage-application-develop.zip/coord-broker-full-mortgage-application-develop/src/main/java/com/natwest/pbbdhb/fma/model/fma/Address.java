package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.util.Constants;
import com.natwest.pbbdhb.fma.validator.SmartCountryIsoCodeValidation;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartPathCheck;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartPatternCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class Address extends BasicAddress {

    @Schema(example = "E11 2NB", maxLength = 12, description = "Required if countryIsoCode is GB and can be max 8 characters long for GB and 12 for non-GB")
    @SmartValidation(conditions = {
            @SmartCondition(path = "countryIsoCode", values = "GB"),
            @SmartCondition(path = "postcode", nullOrEmpty = true, negate = true),
            @SmartCondition(path = "postcode", values = Constants.UK_POSTCODE_PATTERN, negate = true, smartCheck = SmartPatternCheck.class),
    }, message = "must be valid UK postcode")
    @SmartRequired(
            conditions = @SmartCondition(path = "countryIsoCode", values = "GB"),
            message = "is required if countryIsoCode is GB"
    )
    @Size(max = 12)
    private String postcode;

    @Schema(required = true, maxLength = 2, example = "GB", description = "(ISO 3166-1, Alpha-2 code)")
    @SmartValidation(conditions = {
            @SmartCondition(path = ".", values = {"endsWith", "applicants[].addresses[].countryIsoCode"}, smartCheck = SmartPathCheck.class),
            @SmartCondition(path = "ukAddress", values = "true"),
            @SmartCondition(path = "countryIsoCode", values = "GB", negate = true)
    }, message = "must be GB if ukAddress is true")
    @SmartValidation(conditions = {
            @SmartCondition(path = ".", values = {"endsWith", "applicants[].addresses[].countryIsoCode"}, smartCheck = SmartPathCheck.class),
            @SmartCondition(path = "ukAddress", values = "false"),
            @SmartCondition(path = "countryIsoCode", values = "GB")
    }, message = "cannot be GB if ukAddress is false")
    @SmartCountryIsoCodeValidation
    @Size(max = 2)
    @NotBlank(message = "cannot be null or empty")
    private String countryIsoCode;

}
