package com.natwest.pbbdhb.fma.model.fma.enums;

public enum OwnershipType {
    HELD_RBSG, HELD_ELSEWHERE, UNENCUMBERED
}
