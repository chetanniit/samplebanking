package com.natwest.pbbdhb.fma.model.fma.enums;

public enum AccountHolderType {
    APPLICANT_1, APPLICANT_2, JOINT
}
