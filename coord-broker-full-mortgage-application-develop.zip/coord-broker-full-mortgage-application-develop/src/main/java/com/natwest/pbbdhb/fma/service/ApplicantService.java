package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;

public interface ApplicantService extends BaseService {

    ApplicantDto createApplicant(ApplicantDto applicant, String brand);

}