package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.util.Constants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class Solicitor {

    @Schema(required = true, example = "12345")
    @NotNull
    private Integer associateSequenceNumber;

    @Schema(required = true, minLength = 3, maxLength = 45, example = "Bradleys Property and Probate Lawyers")
    @Length(min = 3, max = 45)
    @NotBlank(message = "cannot be null or empty")
    private String companyName;

    @Schema(maxLength = 100, example = "Martin King")
    @Length(max = 100)
    private String contactName;

    @Schema(minLength = 3, maxLength = 45, example = "BRADLE-1", description = "Branch name of the associate")
    @Size(min = 3, max = 45)
    private String branchName;

    @Schema(example = "E11 2NB", maxLength = 8, required = true, pattern = Constants.UK_POSTCODE_PATTERN,
            description = "Must be valid UK postcode")
    @Pattern(regexp = Constants.UK_POSTCODE_PATTERN, message = "must be valid UK postcode")
    @Size(max = 8)
    @NotBlank(message = "cannot be null or empty")
    private String postcode;

    @Schema(example = "assoc@email.com", maxLength = 72, pattern = ".+@.+\\..+")
    @Email(regexp = ".+@.+\\..+")
    @Size(max = 72)
    private String emailAddress;

}