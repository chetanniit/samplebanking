package com.natwest.pbbdhb.staticanalysis.utils;

import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@SuppressWarnings("PMD.AbstractClassWithoutAbstractMethod")
public abstract class AbstractXmlConfigMerge {

    protected static Document readXml(String xmlFile) throws ParserConfigurationException, IOException, SAXException {

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        DocumentBuilder db = dbf.newDocumentBuilder();
        return db.parse(new File(xmlFile));

    }

    protected static Document createXml() throws ParserConfigurationException {

        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        return documentBuilder.newDocument();

    }

    protected static void saveXml(Document xmlToSave, String filePath, Document sampleXml) throws TransformerException, IOException {

        File dir = new File(filePath.replaceAll("[^/\\\\]*$", ""));
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Can't create directory for the file " + filePath);
        }

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        DocumentType doctype = sampleXml.getDoctype();
        if (doctype != null) {
            transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, doctype.getPublicId());
            transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype.getSystemId());
        }
        DOMSource source = new DOMSource(xmlToSave);
        StreamResult result = new StreamResult(new File(filePath));
        transformer.transform(source, result);

    }

    protected static Stream<Node> stream(NodeList list) {
        return IntStream.range(0, list.getLength()).mapToObj(list::item);
    }

    protected static Stream<Node> stream(NamedNodeMap list) {
        return IntStream.range(0, list.getLength()).mapToObj(list::item);
    }

}
