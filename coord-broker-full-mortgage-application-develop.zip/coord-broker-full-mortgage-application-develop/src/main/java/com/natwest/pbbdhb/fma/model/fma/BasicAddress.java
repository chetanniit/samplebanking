package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@SmartValidation(conditions = {
        @SmartCondition(path = "flat", nullOrEmpty = true),
        @SmartCondition(path = "houseName", nullOrEmpty = true),
        @SmartCondition(path = "houseNumber", nullOrEmpty = true)
}, message = "one of the fields flat/houseNumber/houseName is mandatory")
public class BasicAddress {

    @Schema(description = "One of flat, houseName or houseNumber is required", example = "1", maxLength = 10)
    @Size(max = 10)
    private String flat;

    @Schema(description = "One of flat, houseName or houseNumber is required", example = "bob's house", maxLength = 22)
    @Size(max = 22)
    private String houseName;

    @Schema(description = "One of flat, houseName or houseNumber is required", example = "101", maxLength = 5)
    @Size(max = 5)
    private String houseNumber;

    @Schema(example = "regent street", maxLength = 30, required = true)
    @NotBlank(message = "cannot be null or empty")
    @Size(max = 30)
    private String street;

    @Schema(example = "redbridge", maxLength = 30)
    @Size(max = 30)
    private String district;

    @Schema(example = "london", maxLength = 28, required = true)
    @NotBlank(message = "cannot be null or empty")
    @Size(max = 28)
    private String town;

    @Schema(example = "essex", maxLength = 18)
    @Size(max = 18)
    private String county;

}
