package com.natwest.pbbdhb.fma.mapper.applicant;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.openapi.fma.ExistingMortgage;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface ExistingMortgageMapper {

    @Mapping(target = "type", constant = "RESIDENTIAL")
    ExistingMortgage toCreateApplicantExistingMortgage(
            com.natwest.pbbdhb.openapi.fma.ExistingMortgage existingMortgage);

}
