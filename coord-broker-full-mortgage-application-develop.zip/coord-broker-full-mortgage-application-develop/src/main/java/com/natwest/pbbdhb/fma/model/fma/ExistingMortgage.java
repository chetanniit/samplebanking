package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.MortgageOwnership;
import com.natwest.pbbdhb.fma.model.fma.enums.MortgageType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class ExistingMortgage {

    @Schema(implementation = MortgageType.class, required = true)
    @NotNull
    private MortgageType type;

    @Schema(example = "Lender One", maxLength = 30, required = true)
    @Size(max = 30)
    @NotBlank(message = "cannot be null or empty")
    private String lenderName;

    @Schema(implementation = MortgageOwnership.class, required = true)
    @NotNull
    private MortgageOwnership ownership;

    @Schema(required = true, minimum = "0", maximum = "99999999", example = "990", multipleOf = 1, description = "No decimal places")
    @NotNull
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal monthlyRepaymentAmount;

    @Schema(required = true, minimum = "0", maximum = "99999999", example = "11990", multipleOf = 1, description = "No decimal places")
    @NotNull
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal outstandingAmount;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean redeemingMortgage;

}
