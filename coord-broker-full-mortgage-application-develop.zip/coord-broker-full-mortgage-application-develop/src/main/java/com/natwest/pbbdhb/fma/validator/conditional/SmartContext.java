package com.natwest.pbbdhb.fma.validator.conditional;

import java.util.List;
import java.util.Objects;

public interface SmartContext {

    /**
     * Searches for values by path provided
     *
     * @param path
     *            to field values to be extracted<br>
     *            If the path starts with '/' then search is performed from the root object annotated with
     *            {@link SmartConditionalRoot} otherwise the search is performed relatively to the container node of the
     *            field annotated with {@link SmartCondition}<br>
     *            . means current node<br>
     *            .. means parent node<br>
     *            {@code <field>} means annotated field<br>
     *            [?] means 'get the first array element'<br>
     *            [*] means 'get all array elements'<br>
     *            example: ../mortgage/additionalBorrowing[?]/reason
     * @param <T>
     *            type of the field values
     * @return list of the field values, if no values found then the list contains one null element
     */
    <T> List<T> getValues(String path);

    /**
     * Searches for value by path provided
     *
     * @param path
     *            to the field value to be extracted<br>
     *            If the path starts with '/' then search is performed from the root object annotated with
     *            {@link SmartConditionalRoot} otherwise the search is performed relatively to the container node of the
     *            field annotated with {@link SmartCondition}.<br>
     *            . means current node<br>
     *            .. means parent node<br>
     *            {@code <field>} means annotated field<br>
     *            [?] means 'get the first array element'<br>
     *            [*] means 'get all array elements'<br>
     *            example: ../mortgage/additionalBorrowing[?]/reason
     * @param <T>
     *            type of the field values
     * @return the first non-null value encountered or null
     */
    default <T> T getValue(String path) {
        return (T) getValues(path).stream().filter(Objects::nonNull).findFirst().orElse(null);
    }

    /**
     * @return absolute path from the root object annotated with {@link SmartConditionalRoot}
     * to the node annotated with {@link SmartCondition}
     */
    String getContextPath();

}
