package com.natwest.pbbdhb.fma.validator;

import com.natwest.pbbdhb.fma.mapper.FmaApplicantMapper;
import com.natwest.pbbdhb.fma.model.fma.AdditionalBorrowing;
import com.natwest.pbbdhb.fma.model.fma.Applicant;
import com.natwest.pbbdhb.fma.model.fma.ApplicantAddress;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.Employment;
import com.natwest.pbbdhb.fma.model.fma.InterestOnly;
import com.natwest.pbbdhb.fma.model.fma.MarketingPreferences;
import com.natwest.pbbdhb.fma.model.fma.Mortgage;
import com.natwest.pbbdhb.fma.model.fma.OtherProperty;
import com.natwest.pbbdhb.fma.model.fma.PortfolioLandlord;
import com.natwest.pbbdhb.fma.model.fma.enums.AdditionalBorrowingReason;
import com.natwest.pbbdhb.fma.model.fma.enums.EmploymentStatus;
import com.natwest.pbbdhb.fma.model.fma.enums.LoanPurpose;
import com.natwest.pbbdhb.fma.model.fma.enums.OccupyStatus;
import com.natwest.pbbdhb.fma.model.fma.enums.OwnershipType;
import com.natwest.pbbdhb.fma.model.fma.enums.PropertyUsage;
import com.natwest.pbbdhb.fma.model.fma.enums.RepaymentStrategyType;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCheck;
import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;
import com.natwest.pbbdhb.openapi.fma.Address;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.util.Comparator;
import java.util.Currency;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

import static java.util.Arrays.binarySearch;

public interface SmartChecks {

	class CurrentYearDate implements SmartCheck<LocalDate> {
		@Override
		public boolean check(LocalDate date, List<String> conditionValues, SmartContext smartContext) {
			return date != null && date.getYear() == LocalDate.now().getYear();
		}
	}

	class SelfEstablishedDate implements SmartCheck<LocalDate> {
		@Override
		public boolean check(LocalDate date, List<String> conditionValues, SmartContext smartContext) {
			if(date != null){
			Period employedPeriod  = Period.between(date , LocalDate.now());
			return (employedPeriod.getYears() <= 99 && employedPeriod.getMonths()<=11 || (employedPeriod.getYears() == 99 && employedPeriod.getMonths()==11 && employedPeriod.getDays()==0));
			}
			return false;
		}
	}

	class AtLeastCurrentAge implements SmartCheck<Applicant> {
		@Override
		public boolean check(Applicant applicant, List<String> conditionValues, SmartContext smartContext) {
			return applicant.getIntendedRetirementAge() != null && applicant.getPersonalDetails() != null
					&& applicant.getPersonalDetails().getDateOfBirth() != null
					&& applicant.getIntendedRetirementAge() >= Period
							.between(applicant.getPersonalDetails().getDateOfBirth(), LocalDate.now()).getYears();
		}
	}

	class HasExactlyOneCurrentAddress implements SmartCheck<Applicant> {
		@Override
		public boolean check(Applicant applicant, List<String> conditionValues, SmartContext smartContext) {
			return applicant.getAddresses() != null && applicant.getAddresses().size() != 0
					&& applicant.getAddresses().stream().filter(Objects::nonNull)
							.filter(address -> Boolean.TRUE.equals(address.getIsCurrentAddress())).count() == 1;
		}
	}

	class CheckRepaymentStrategyType implements SmartCheck<InterestOnly> {
		@Override
		public boolean check(InterestOnly interestOnly, List<String> conditionValues, SmartContext smartContext) {
			RepaymentStrategyType checkType = RepaymentStrategyType.valueOf(conditionValues.get(0));
			return interestOnly != null && interestOnly.getRepaymentDetails() != null
					&& interestOnly.getRepaymentDetails().stream().filter(Objects::nonNull)
							.filter(repaymentDetail -> checkType.equals(repaymentDetail.getRepaymentStrategyType()))
							.count() > 1;
		}
	}

	class MortgageAmountEqualToAdBoPlusOutstanding implements SmartCheck<Mortgage> {
		@Override
		public boolean check(Mortgage mortgage, List<String> conditionValues, SmartContext smartContext) {
			if (mortgage == null || mortgage.getMortgageAmount() == null) {
				return false;
			}
			BigDecimal adboAmount = mortgage.getAdditionalBorrowings() == null ? BigDecimal.ZERO
					: mortgage.getAdditionalBorrowings().stream().filter(ab -> null != ab.getAmount())
							.map(AdditionalBorrowing::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
			BigDecimal outstandingAmount = mortgage.getOutstandingMortgage() == null ? BigDecimal.ZERO
					: mortgage.getOutstandingMortgage();
			return mortgage.getMortgageAmount().compareTo(adboAmount.add(outstandingAmount)) == 0;
		}
	}

	class AtLeastOneMainApplicant implements SmartCheck<Application> {

		@Override
		public boolean check(Application application, List<String> conditionValues, SmartContext smartContext) {
			boolean isValid = true;
			if (!CollectionUtils.isEmpty(application.getApplicants())) {
				if (application.getApplicants().size() > 1) {
					isValid = !application.getApplicants().stream().filter(Objects::nonNull)
							.allMatch((a) -> (null != a.getMainApplicant() && a.getMainApplicant()));

					isValid = isValid && application.getApplicants().stream().filter(Objects::nonNull)
							.anyMatch((a) -> (null != a.getMainApplicant() && a.getMainApplicant()));
				} else if (application.getApplicants().get(0) != null) {
					isValid = Boolean.TRUE.equals(application.getApplicants().get(0).getMainApplicant());
				}
			}
			return isValid;
		}

	}

	class NoUkAddressesAtNotGbResident implements SmartCheck<Applicant> {

		@Override
		public boolean check(Applicant applicant, List<String> conditionValues, SmartContext smartContext) {
			// has UK address
			if (applicant == null || applicant.getAddresses() == null || applicant.getAddresses().size() == 0
					|| applicant.getAddresses().stream().filter(Objects::nonNull)
							.anyMatch(address -> Boolean.TRUE.equals(address.getUkAddress()))) {
				return false;
			}
			// UK citizen
			if (applicant.getPersonalDetails() != null
					&& "GB".equalsIgnoreCase(applicant.getPersonalDetails().getNationality())
					&& applicant.getPersonalDetails().getRightToReside() != null
					&& applicant.getPersonalDetails().getRightToReside()) {
				return false;
			}
			return true;
		}

	}

	

	class PortfolioLandlordRequired implements SmartCheck<PortfolioLandlord> {
		@Override
		public boolean check(PortfolioLandlord portfolioLandlord, List<String> conditionValues,
				SmartContext smartContext) {
			LoanPurpose loanPurpose = smartContext.getValue("/loanPurpose");
			List<OtherProperty> otherProperties = smartContext.getValues("../otherProperties[*]");
			if (loanPurpose == null || otherProperties == null || otherProperties.isEmpty()
					|| null == otherProperties.get(0)) {
				return false;
			}
			long propertyCount = otherProperties.stream()
					.filter(property -> !Boolean.TRUE.equals(property.getPropertyRedemption())
							&& (PropertyUsage.BUY_TO_LET.equals(property.getPropertyUsage())
									|| PropertyUsage.CONSENT_TO_LET.equals(property.getPropertyUsage()))
							&& (OwnershipType.HELD_RBSG.equals(property.getOwnershipType())
									|| OwnershipType.HELD_ELSEWHERE.equals(property.getOwnershipType())))
					.count();
			return (LoanPurpose.REMORTGAGE.equals(loanPurpose) || LoanPurpose.HOUSE_PURCHASE.equals(loanPurpose))
					&& propertyCount >= 3;
		}
	}

	class ValidCurrencyCode implements SmartCheck<String> {
		private static final String UPPER_CASE_CURRENCY_REGEX = "[A-Z]{3}";

		@Override
		public boolean check(String currencyCode, List<String> conditionValues, SmartContext smartContext) {
			if (StringUtils.isEmpty(currencyCode)) {
				return true;
			}
			if ("GBP".equalsIgnoreCase(currencyCode)) {
				return false;
			}
			if (!currencyCode.matches(UPPER_CASE_CURRENCY_REGEX)) {
				return false;
			}
			return Currency.getAvailableCurrencies().stream()
					.anyMatch(c -> c.getCurrencyCode().equalsIgnoreCase(currencyCode.trim()));
		}
	}

	class ValidCountryIsoCode implements SmartCheck<String> {
		@Override
		public boolean check(String countryIsoCode, List<String> conditionValues, SmartContext smartContext) {
			return StringUtils.isEmpty(countryIsoCode) || binarySearch(Locale.getISOCountries(), countryIsoCode) >= 0;
		}
	}

	class ValidPeriodAtAddress implements SmartCheck<List<ApplicantAddress>> {
		@Override
		public boolean check(List<ApplicantAddress> applicantAddresses, List<String> conditionValues,
				SmartContext smartContext) {
			List<Address> fmaAddresses = applicantAddresses.stream().filter(Objects::nonNull)
					.map(address -> Address.builder().isCurrentAddress(address.getIsCurrentAddress())
							.startYear(address.getStartYear()).startMonth(address.getStartMonth()).build())
					.collect(Collectors.toList());
			FmaApplicantMapper.setEndDates(fmaAddresses);
			return fmaAddresses.stream().allMatch((address) -> {
				if (address.getStartYear() == null || address.getEndYear() == null
						|| address.getIsCurrentAddress() == null || address.getStartMonth() == null
						|| address.getStartMonth() < 1 || address.getStartMonth() > 12 || address.getEndMonth() == null
						|| address.getEndMonth() < 1 || address.getEndMonth() > 12) {
					return true;
				}
				LocalDate startDate = YearMonth.of(address.getStartYear(), address.getStartMonth()).atDay(1);
				LocalDate endDate = YearMonth.of(
						address.getIsCurrentAddress() || address.getEndYear() == null ? LocalDate.now().getYear()
								: address.getEndYear(),
						address.getIsCurrentAddress() || address.getEndMonth() == null ? LocalDate.now().getMonthValue()
								: address.getEndMonth())
						.atEndOfMonth();
				Period period = Period.between(startDate, endDate);
				return period.toTotalMonths() <= 99 * 12;
			});
		}
	}

	class CurrentAddressOwnerMortgaged implements SmartCheck<ApplicantAddress> {
		@Override
		public boolean check(ApplicantAddress address, List<String> conditionValues, SmartContext smartContext) {
			return address != null && Boolean.TRUE.equals(address.getIsCurrentAddress())
					&& OccupyStatus.OWNER_MORTGAGED.equals(address.getOccupyStatus());
		}
	}

	class OneCurrentPrimaryEmployment implements SmartCheck<List<Employment>> {
		@Override
		public boolean check(List<Employment> employments, List<String> conditionValues, SmartContext smartContext) {
			if (employments == null) {
				return true;
			}
			List<Employment> currentEmployments = employments.stream()
					.filter(employment -> !EmploymentStatus.NOT_EMPLOYED.equals(employment.getEmploymentStatus())
							&& (employment.getEndDate() == null || employment.getEndDate().isAfter(LocalDate.now())))
					.collect(Collectors.toList());
			return currentEmployments.isEmpty() || currentEmployments.stream()
					.filter(employment -> Boolean.TRUE.equals(employment.getPrimary())).count() == 1;
		}
	}

	class CoverLast3Years implements SmartCheck<List<ApplicantAddress>> {
		@Override
		public boolean check(List<ApplicantAddress> applicantAddresses, List<String> conditionValues,
				SmartContext smartContext) {
			if (applicantAddresses == null || applicantAddresses.isEmpty()) {
				return false;
			}
			return applicantAddresses.stream().filter(Objects::nonNull)
					.filter(address -> address.getStartYear() != null && address.getStartMonth() != null)
					.min(Comparator.comparingInt(ApplicantAddress::getStartYear)
							.thenComparingInt(ApplicantAddress::getStartMonth))
					.filter(address -> {
						LocalDate boundary = LocalDate.now().minusYears(3);
						return address.getStartYear() < boundary.getYear()
								|| (address.getStartYear() == boundary.getYear()
										&& address.getStartMonth() <= boundary.getMonthValue());
					}).isPresent();
		}
	}

	class AtLeastOneMarketingPreferencesTrue implements SmartCheck<MarketingPreferences> {

		@Override
		public boolean check(MarketingPreferences marketingPrefernces, List<String> conditionValues,
				SmartContext smartContext) {

			if (null == marketingPrefernces) {
				return false;
			}

			if (Boolean.TRUE.equals(marketingPrefernces.getEmail())
					|| Boolean.TRUE.equals(marketingPrefernces.getPost())
					|| Boolean.TRUE.equals(marketingPrefernces.getTelephone())
					|| Boolean.TRUE.equals(marketingPrefernces.getText())) {
				return true;
			}
			return false;
		}

	}

	class DebtConsolidationAmountMatches implements SmartCheck<Application> {

		@Override
		public boolean check(Application application, List<String> conditionValues, SmartContext smartContext) {
			if (application.getApplicants() == null
					|| application.getMortgage() == null) {
				return true;
			}

			BigDecimal loanSum = application.getApplicants().stream()
					.filter(Objects::nonNull)
					.map(Applicant::getLoans)
					.filter(Objects::nonNull)
					.flatMap(loans -> loans.stream().filter(Objects::nonNull))
					.filter(loan -> Boolean.TRUE.equals(loan.getDebtConsolidation()))
					.map(loan -> loan.getConsolidationAmount() != null
							&& BigDecimal.ZERO.compareTo(loan.getConsolidationAmount()) < 0
							? loan.getConsolidationAmount()
							: loan.getAmountOutstanding() != null
							&& BigDecimal.ZERO.compareTo(loan.getAmountOutstanding()) < 0
							? loan.getAmountOutstanding()
							: BigDecimal.ZERO)
					.reduce(BigDecimal.ZERO, BigDecimal::add);

			BigDecimal creditCardSum = application.getApplicants().stream()
					.filter(Objects::nonNull)
					.map(Applicant::getCreditCards)
					.filter(Objects::nonNull)
					.flatMap(creditCards -> creditCards.stream().filter(Objects::nonNull))
					.filter(creditCard -> Boolean.TRUE.equals(creditCard.getDebtConsolidation()))
					.map(creditCard -> creditCard.getPartialRefinanced() != null
							&& BigDecimal.ZERO.compareTo(creditCard.getPartialRefinanced()) < 0
							? creditCard.getPartialRefinanced()
							: creditCard.getTotalBalance() != null
							&& BigDecimal.ZERO.compareTo(creditCard.getTotalBalance()) < 0
							? creditCard.getTotalBalance()
							: BigDecimal.ZERO)
					.reduce(BigDecimal.ZERO, BigDecimal::add);

			BigDecimal adBoSum = application.getMortgage().getAdditionalBorrowings() == null
					? BigDecimal.ZERO
					: application.getMortgage().getAdditionalBorrowings().stream()
					.filter(Objects::nonNull)
					.filter(adBo -> AdditionalBorrowingReason.DEBT_CONSOLIDATION.equals(adBo.getReason()))
					.map(AdditionalBorrowing::getAmount)
					.filter(Objects::nonNull)
					.reduce(BigDecimal.ZERO, BigDecimal::add);

			return adBoSum.compareTo(loanSum.add(creditCardSum)) == 0;
		}

	}

}
