package com.natwest.pbbdhb.fma.model.fma.enums;

public enum Nationality {
    UNITED_KINGDOM, NON_EU, EU
}
