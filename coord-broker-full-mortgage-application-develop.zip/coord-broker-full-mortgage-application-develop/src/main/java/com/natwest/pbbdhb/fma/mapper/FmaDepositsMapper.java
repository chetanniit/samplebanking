package com.natwest.pbbdhb.fma.mapper;

import com.natwest.pbbdhb.fma.model.fma.Deposit;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface FmaDepositsMapper {

    @Mapping(target = "depositAmount", source = "amount")
    @Mapping(target = "depositType", source = "type")
    @Mapping(target = "depositDetails", source = "details")
    com.natwest.pbbdhb.openapi.fma.Deposit toFmaRequestDeposit(Deposit deposit);

}
