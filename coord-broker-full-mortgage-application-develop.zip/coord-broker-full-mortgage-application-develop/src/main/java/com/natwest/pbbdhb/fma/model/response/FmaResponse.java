package com.natwest.pbbdhb.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.natwest.pbbdhb.openapi.fma.ProductDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class FmaResponse {
    @Schema(hidden = true)
    private String caseId;
    private String mortgageNumber;
    private String tempReferenceNumber;
    private HardScoreDecision hardscoreDecision;
    @JsonIgnore
    private String status;
    @JsonProperty("_links")
    private Map<String, Link> links;
    @JsonIgnore
    private Set<ProductDetails> products;
    @JsonIgnore
    private String applSeq;
}
