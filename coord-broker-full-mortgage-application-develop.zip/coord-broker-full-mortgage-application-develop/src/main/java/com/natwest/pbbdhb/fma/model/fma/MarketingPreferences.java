package com.natwest.pbbdhb.fma.model.fma;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class MarketingPreferences {
	
	@Schema( required = true,example = "true", allowableValues = { "true", "false" })
	@NotNull
    private Boolean email;
	
	@Schema( required = true,example = "true", allowableValues = { "true", "false" })
	@NotNull
	private Boolean text;
	
	@Schema( required = true,example = "true", allowableValues = { "true", "false" })
	@NotNull
	private Boolean telephone;
	
	@Schema( required = true,example = "true", allowableValues = { "true", "false" })
	@NotNull
	private Boolean post;

	
}
