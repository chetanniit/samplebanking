package com.natwest.pbbdhb.fma.mapper.cases;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.cases.dto.DirectDebitDetailsDto;
import com.natwest.pbbdhb.cases.dto.FeeDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.fma.model.fma.BuyToLet;
import com.natwest.pbbdhb.fma.model.fma.DirectDebit;
import com.natwest.pbbdhb.fma.util.Constants;
import com.natwest.pbbdhb.openapi.fma.Application;
import com.natwest.pbbdhb.openapi.fma.Broker;
import com.natwest.pbbdhb.openapi.fma.DirectDebitDetails;
import com.natwest.pbbdhb.openapi.fma.Fee;
import com.natwest.pbbdhb.openapi.fma.Mortgage;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Mapper(config = MappingConfig.class)
public interface CaseMapper {

    
    @Mapping(target = "mortgage", source = "fmaApplication.mortgage", qualifiedByName = "mapMortgageAssisted")
    @Mapping(target = "salesIllustrations", source = "fmaApplication", qualifiedByName = "getSalesIllustration")
    @Mapping(target = "decisionInPrinciples", source = "fmaApplication", qualifiedByName = "getDecisionInPrinciples")
    @Mapping(target = "directDebit", source = "directDebit", qualifiedByName = "mapDirectDebitAssisted")
    @Mapping(target = "applicationStatus", constant  = "FMA_DATA_SUBMITTED_BY_CHANNEL")
    CaseApplicationDto toCaseApplication(Application fmaApplication, @Context BuyToLet buyToLet, @Context DirectDebit directDebit);

    @Mapping(target = "productSelectedDate", source = "productSelectionDate", dateFormat = "yyyy-MM-dd")
    ProductDetailsDto mapProductDetails(com.natwest.pbbdhb.openapi.fma.ProductDetails productDetails);

    List<ProductDetailsDto> mapProductDetails(Set<com.natwest.pbbdhb.openapi.fma.ProductDetails> lstProducts);
    
    @Mapping(target = "feeCode", source = "code")
    @Mapping(target = "feeAction", source = "action")
    @Mapping(target = "feeAmount", source = "amount")
    @Mapping(target = "feePaymentType", source = "paymentType")
    FeeDto mapFee(Fee fee);
    
    @Mapping(target = "buyToLet", source = "buyToLet")
    MortgageDto mapMortgage(Mortgage mortgage, BuyToLet buyToLet);

    @Mapping(target = "consentToFMA", constant = "true")
    @Mapping(target = "details", source = "broker")
    com.natwest.pbbdhb.cases.dto.BrokerDto mapBroker(Broker broker);

    @Mapping(target = "attestation", source = "attestation")
    DirectDebitDetailsDto mapDirectDebit(DirectDebitDetails fmaDirectDebit, Boolean attestation);

    @Named("mapMortgageAssisted")
    default MortgageDto mapMortgageAssisted(Mortgage mortgage, @Context BuyToLet buyToLet) {
        return mapMortgage(mortgage, buyToLet);
    }

    @Named("getSalesIllustration")
    default List<SalesIllustrationDto> getSalesIllustration(com.natwest.pbbdhb.openapi.fma.Application fmaApplication) {
        List<SalesIllustrationDto> salesIllustrations = new ArrayList<>();

        SalesIllustrationDto saIllustration = SalesIllustrationDto.builder().isAccepted(true).selectionDate(LocalDate.now().format(Constants.DATE_FORMATTER))
                .products(mapProductDetails(null == fmaApplication.getMortgage() ? null : fmaApplication.getMortgage().getProducts()))
                .build();

        salesIllustrations.add(saIllustration);
        return salesIllustrations;
    }

    @Named("getDecisionInPrinciples")
    default List<DecisionInPrincipleDto> getDecisionInPrinciple(Application fmaApplication) {
        List<DecisionInPrincipleDto> decInPrinciples = new ArrayList<>();
        decInPrinciples.add(DecisionInPrincipleDto.builder().dipId(fmaApplication.getDipId())
                .dateTime(LocalDateTime.now().format(Constants.DEFAULT_DATETIME_FORMAT)).build());

        return decInPrinciples;
    }

    @Named("mapDirectDebitAssisted")
    default DirectDebitDetailsDto mapDirectDebitAssisted(DirectDebitDetails fmaDirectDebit, @Context DirectDebit directDebit) {
        return mapDirectDebit(fmaDirectDebit, directDebit == null ? null : directDebit.getAttestation());
    }

}
