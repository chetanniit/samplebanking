package com.natwest.pbbdhb.fma.serialization;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.IOException;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public class ValidatingDeserializer extends JsonDeserializer {

    private Class<?> targetType;
    private JsonDeserializer defaultDeserializer;
    private Set<DeserializationValidator> validators;

    protected ValidatingDeserializer(JsonDeserializer defaultDeserializer, Class<?> targetType, Set<DeserializationValidator> validators) {
        super();
        this.defaultDeserializer = defaultDeserializer;
        this.targetType = targetType;
        this.validators = validators;
    }

    @Override
    public Class<?> handledType() {
        return targetType;
    }

    @Override
    public Object deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        try {
            validate(validator -> validator.beforeSerialization(targetType, jsonParser));
            return defaultDeserializer.deserialize(jsonParser, deserializationContext);
        } catch (Exception e) {
            validate(validator -> validator.onSerializationException(targetType, jsonParser, e));
            throw e;
        }
    }

    private void validate(ValidatorFunction validatorFunction)
            throws IOException {
        try {
            Optional<DeserializationValidationException> exception = validators.stream()
                    .map(v -> {
                        try {
                            return validatorFunction.apply(v);
                        } catch (IOException e) {
                            throw new BoxingException(e);
                        }
                    })
                    .filter(Objects::nonNull)
                    .findFirst();

            if (exception.isPresent()) {
                throw exception.get();
            }
        } catch (BoxingException e) {
            throw e.getIoException();
        }
    }

    private interface ValidatorFunction {
        DeserializationValidationException apply(DeserializationValidator v) throws IOException;
    }

    @AllArgsConstructor
    @Getter
    private static class BoxingException extends RuntimeException {
        private IOException ioException;
    }

}
