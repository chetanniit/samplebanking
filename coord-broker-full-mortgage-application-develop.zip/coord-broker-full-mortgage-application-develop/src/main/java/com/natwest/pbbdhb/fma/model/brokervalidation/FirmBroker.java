package com.natwest.pbbdhb.fma.model.brokervalidation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FirmBroker implements Serializable {

    private String userName;
    private String title;
    private String firmName;
    private String fcaNumber;
    private String firmPostcode;
    private String brokerPostcode;
    private String brokerSurname;
    private String acceptMortgageBusiness;
    private String firmAddress1;
    private String firmAddress2;
    private String firmAddress3;
    private String firmAddress4;
    private String firmAddress5;
    private String brokerForeName;
    private String brokerEmail;
    private String brokerTelephoneNumber;
    private String brokerMobileNumber;

}
