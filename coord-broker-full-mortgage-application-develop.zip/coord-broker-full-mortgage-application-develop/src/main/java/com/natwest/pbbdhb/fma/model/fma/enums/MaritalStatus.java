package com.natwest.pbbdhb.fma.model.fma.enums;

public enum MaritalStatus {
    DIVORCED, MARRIED, SEPARATED, SINGLE, ENGAGED, WIDOWED, LIVING_WITH_PARTNER, CIVIL_PARTNERSHIP, SURVIVING_CIVIL_PARTNER
}
