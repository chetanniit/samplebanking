package com.natwest.pbbdhb.fma.validator.conditional;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The annotation is used to mark conditionally required fields and can be used at fields within objects hierarchy whose
 * root class is annotated as {@link SmartConditionalRoot}
 * Also you may create custom annotation and annotate it with {@link SmartValidation} and/or {@link SmartRequired}
 * annotations to encapsulate some checks into the annotation. You may declare String[] values() field in the annotation
 * and it's value will be appended to the end of values() field of all the SmartConditions you declare. As well as you
 * may declare String message() field in the annotation to provide alternative message that will be used instead of
 * message() field of all {@link SmartValidation} and/or {@link SmartRequired} annotations you declare.<br>
 * Examples of custom annotations:<br>
 *
 * <pre>
 * {@code
 * - @Target({ ElementType.FIELD })
 * - @Retention(RetentionPolicy.RUNTIME)
 * - @SmartValidation(
 * -     conditions = @SmartCondition(path = "&lt;field&gt;", negate = true, smartCheck = SmartChecks.ValidCountryIsoCode.class),
 * -     message = "has invalid country iso code value"
 * - )
 * - public @interface SmartCountryIsoCodeValidation {}
 * -
 * -
 * - @Target({ ElementType.FIELD })
 * - @Retention(RetentionPolicy.RUNTIME)
 * - @SmartValidation(
 * -     conditions = @SmartCondition(path = "&lt;field&gt;", values = "endsWith", smartCheck = SmartPathCheck.class),
 * -     message = "default message"
 * - )
 * - public @interface JsonPathEndsWith {
 * -     String[] values(); // set the path ending
 * -     String message(); // provide custom message
 * - }
 * }
 * </pre>
 *
 **/
@Documented
@Repeatable(SmartRequiredMultiple.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface SmartRequired {

    /**
     * All conditions must be true to make the annotated field required.<br>
     * To implement 'or' behavior several @SmartRequired annotations can be specified for the same field.
     *
     * @return array of conditions
     **/
    SmartCondition[] conditions() default {};

    /**
     * @return message to show if the field is invalid
     **/
    String message() default "field is required";

    /**
     * @return true if empty string is valid value for required field
     **/
    boolean allowEmptyString() default false;

    /**
     * If true then the message is prepended by the field path
     *
     * @return true if to show the field path in the message
     **/
    boolean showPathInMessage() default true;

    /**
     * See scope() field description of {@link SmartConditionalRoot} for details
     *
     * @return scope to which this @SmartRequired validation belongs
     **/
    String scope() default "default";

}
