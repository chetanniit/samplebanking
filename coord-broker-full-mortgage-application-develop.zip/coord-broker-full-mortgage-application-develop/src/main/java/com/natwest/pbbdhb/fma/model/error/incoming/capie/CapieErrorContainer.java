package com.natwest.pbbdhb.fma.model.error.incoming.capie;

import lombok.Getter;

import java.util.List;

@Getter
public class CapieErrorContainer {
    private int errorCount;
    private List<CapieError> errors;
}
