package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;

public interface ExpenditureService extends BaseService {

    ValidatedCaseExpenseDto createExpense(String caseId, String brand, ValidatedCaseExpenseDto expenseRequest);
}
