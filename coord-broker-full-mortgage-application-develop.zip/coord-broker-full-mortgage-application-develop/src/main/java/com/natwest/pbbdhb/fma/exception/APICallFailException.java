package com.natwest.pbbdhb.fma.exception;

import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

@Getter
@ToString
public class APICallFailException extends RuntimeException {

    private final HttpStatus httpStatus;

    public APICallFailException(HttpStatus httpStatus, String message) {
        super(message);
        this.httpStatus = httpStatus;
    }
}