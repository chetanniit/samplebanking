package com.natwest.pbbdhb.fma.model.fma;

public enum Interview {

	TELEPHONE, FACE_TO_FACE, NONE
}
