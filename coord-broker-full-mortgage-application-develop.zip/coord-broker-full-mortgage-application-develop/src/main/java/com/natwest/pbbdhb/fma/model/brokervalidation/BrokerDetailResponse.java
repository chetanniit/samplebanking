package com.natwest.pbbdhb.fma.model.brokervalidation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerDetailResponse {

    private Set<FirmBroker> brokers;
    private Set<PaymentPath> paymentPaths;

}
