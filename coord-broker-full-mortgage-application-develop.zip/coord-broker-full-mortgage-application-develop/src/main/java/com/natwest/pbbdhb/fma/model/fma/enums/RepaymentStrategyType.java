package com.natwest.pbbdhb.fma.model.fma.enums;

public enum RepaymentStrategyType {
    MAIN_RESIDENCE,
    NOT_MAIN_RESIDENCE,
    OTHER_MORTGAGE_PROPERTY,
    UNENCUMBERED_MAIN_RESIDENCE,
    UNENCUMBERED_OTHER_PROPERTY,
    STOCK_SHARES,
    UNIT_TRUSTS,
    OEIC,
    ICVC,
    PENSION,
    SAVING,
    OTHER_ASSETS,
    ENDOWMENT,
    SALE_OF_PROPERTY
}
