package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.Tenure;
import com.natwest.pbbdhb.fma.model.fma.enums.WarrantyType;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class PurchaseProperty extends BasicProperty {

    @Schema(example = "2", pattern = "^[0-9]+$", maxLength = 3)
    @Pattern(regexp = "^[0-9]+$")
    @Length(max = 3)
    private String floor;

    @Schema(example = "2", pattern = "^[0-9]+$", maxLength = 2)
    @Pattern(regexp = "^[0-9]+$")
    @Length(max = 2)
    private String storeys;

    @Schema(implementation = WarrantyType.class, example = "NEW_BUILD")
    private WarrantyType warrantyType;

    @Schema(example = "50", pattern = "^[0-9]+$", maxLength = 3)
    @Pattern(regexp = "^[0-9]+$")
    @Length(max = 3)
    private String numberOfFlats;

    @Schema(implementation = Tenure.class, required = true, example = "LEASEHOLD")
    @NotNull
    private Tenure tenure;

    @Schema(example = "119", pattern = "^[0-9]{1,4}$", description = "Required if tenure is LEASEHOLD")
    @SmartRequired(conditions = @SmartCondition(path = "tenure", values = "LEASEHOLD"))
    @Pattern(regexp = "^[0-9]{1,4}$")
    private String remainingLeasehold;

    @Schema(implementation = String.class, required = true, example = "2022-01-20", pattern = "yyyy-MM-dd", description = "Should be current calendar year date if type is BUNGALOW_NEW_BUILD, HOUSE_NEW_BUILD, HOUSE_NEW_BUY,"
            + " FLAT_NEW_BUILD, FLAT_NEW_BUY")
    @SmartValidation(conditions = {
            @SmartCondition(path = "type", values = {
                    "BUNGALOW_NEW_BUILD", "HOUSE_NEW_BUILD", "HOUSE_NEW_BUY", "FLAT_NEW_BUILD", "FLAT_NEW_BUY"
            }),
            @SmartCondition(path = "whenBuilt", negate = true, smartCheck = SmartChecks.CurrentYearDate.class)
    }, message = "should be current calendar year date")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @NotNull
    private LocalDate whenBuilt;

    @Schema(example = "true", allowableValues = { "true", "false" })
    private Boolean localAuthority;

    @Schema(implementation = String.class, example = "2019-01-19", pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate refurbishedDate;

    @Schema(example = "true", allowableValues = { "true", "false" })
    private Boolean nhbcCertificate;

    @Schema(example = "2500", minimum = "0", multipleOf = 1, description = "Applicable if the property is new build (within 2 years), no decimal places")
    @DecimalMin("0")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    private BigDecimal builderIncentive;

    @Schema(required = true)
    @Valid
    @NotNull
    private Valuation valuation;

    @Schema(maximum = "999", example = "11")
    @Max(999)
    private Integer termRemaining;

    @Schema(maxLength = 50)
    @Size(max = 50)
    private String propertyBuilder;

    @Schema(maxLength = 50)
    @Size(max = 50)
    private String propertyDevelopment;
}
