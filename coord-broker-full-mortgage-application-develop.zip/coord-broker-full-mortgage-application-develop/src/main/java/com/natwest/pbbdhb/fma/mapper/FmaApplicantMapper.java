package com.natwest.pbbdhb.fma.mapper;

import com.natwest.pbbdhb.fma.model.fma.Applicant;
import com.natwest.pbbdhb.fma.model.fma.ApplicantAddress;
import com.natwest.pbbdhb.fma.model.fma.CreditCard;
import com.natwest.pbbdhb.fma.model.fma.Employment;
import com.natwest.pbbdhb.fma.model.fma.ExistingMortgage;
import com.natwest.pbbdhb.fma.model.fma.Loan;
import com.natwest.pbbdhb.fma.model.fma.enums.Provider;
import com.natwest.pbbdhb.openapi.fma.Address;
import com.natwest.pbbdhb.openapi.fma.Address.OccupyStatusEnum;
import com.natwest.pbbdhb.openapi.fma.PersonalDetails.GenderEnum;
import com.natwest.pbbdhb.openapi.fma.PersonalDetails.TitleEnum;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Mapper(config = MappingConfig.class , builder = @Builder(disableBuilder = true))
public interface FmaApplicantMapper {
	 List<TitleEnum> FEMALE_TITLES = Arrays.asList(TitleEnum.MISS, TitleEnum.MRS,TitleEnum.MS);

    @Mapping(target = "existingMortgages", source = ".", qualifiedByName = "getExistingMortgages")
    @Mapping(target = "addresses", source = "addresses", qualifiedByName = "toAddressesAssisted")
    @Mapping(target = "personalDetails.mailIndicator", constant = "false") // TODO temporary fix that must be removed
    com.natwest.pbbdhb.openapi.fma.Applicant toFmaRequestApplicant(Applicant applicant);

    @Mapping(target = "selfEmployed.selfEmployedDateEstablished", source = "selfEmployed.dateEstablished")
    com.natwest.pbbdhb.openapi.fma.Employment toFmaRequestEmployment(Employment employement);

    com.natwest.pbbdhb.openapi.fma.ExistingMortgage toFmaRequestExistingMortgage(ExistingMortgage existingMortgage);

    @Mapping(target = "provider", source = ".", qualifiedByName = "getCreditCardProvider")
    @Mapping(target = "partialRefinanced", source = ".", qualifiedByName = "getPartialRefinanced")
    com.natwest.pbbdhb.openapi.fma.CreditCard toFmaRequestCreditCard(CreditCard creditCard);

    @Mapping(target = "provider", source = ".", qualifiedByName = "getLoanProvider")
    @Mapping(target = "consolidationAmount", source = ".", qualifiedByName = "getConsolidationAmount")
    com.natwest.pbbdhb.openapi.fma.Loan toFmaRequestLoan(Loan loan);

    List<Address> toFmaAddresses(List<ApplicantAddress> list);

    @Named("getExistingMortgages")
    default Set<com.natwest.pbbdhb.openapi.fma.ExistingMortgage> getExistingMortgages(Applicant applicant) {
        if (null != applicant.getExistingMortgage()) {
            return Collections.singleton(toFmaRequestExistingMortgage(applicant.getExistingMortgage()));
        }
        return null;
    }

    @Named("getCreditCardProvider")
    default String getCreditCardProvider(CreditCard creditCard) {
        return Provider.OTHER.equals(creditCard.getProvider()) ? creditCard.getOtherProvider() : creditCard.getProvider().name();
    }

    @Named("getPartialRefinanced")
    default BigDecimal getPartialRefinanced(CreditCard creditCard) {
        return Boolean.TRUE.equals(creditCard.getToBeRepaid()) && Boolean.TRUE.equals(creditCard.getDebtConsolidation())
                && (creditCard.getPartialRefinanced() == null || BigDecimal.ZERO.compareTo(creditCard.getPartialRefinanced()) >= 0)
                ? creditCard.getTotalBalance()
                : creditCard.getPartialRefinanced();
    }

    @Named("getConsolidationAmount")
    default BigDecimal getConsolidationAmount(Loan loan) {
        return Boolean.TRUE.equals(loan.getDebtConsolidation())
                && (loan.getConsolidationAmount() == null || BigDecimal.ZERO.compareTo(loan.getConsolidationAmount()) >= 0)
                ? loan.getAmountOutstanding()
                : loan.getConsolidationAmount();
    }

    @Named("getLoanProvider")
    default String getLoanProvider(Loan loan) {
        return Provider.OTHER.equals(loan.getProvider()) ? loan.getOtherProvider() : loan.getProvider().name();
    }

    @Named("toAddressesAssisted")
    default Set<Address> toAddressesAssisted(List<ApplicantAddress> addresses) {
        List<Address> fmaAddresses = toFmaAddresses(addresses);
        if (fmaAddresses == null || fmaAddresses.isEmpty()) {
            return fmaAddresses == null ? null : new LinkedHashSet<>(fmaAddresses);
        }
        setEndDates(fmaAddresses);
        setOriginalPurchasePrice(fmaAddresses);
        Collections.reverse(fmaAddresses);
        return new LinkedHashSet<>(fmaAddresses);
    }

    static void setEndDates(List<Address> fmaAddresses) {
        fmaAddresses.removeIf(Objects::isNull);
        if (fmaAddresses.isEmpty() || fmaAddresses.stream()
                .anyMatch(address -> address.getStartYear() == null || address.getStartMonth() == null)) {
            return;
        }
        fmaAddresses.sort(Comparator.comparingInt(Address::getStartYear).thenComparingInt(Address::getStartMonth));
        Iterator<Address> addressIterator = fmaAddresses.iterator();
        Address address = addressIterator.next();
        while (addressIterator.hasNext()) {
            Address nextAddress = addressIterator.next();
            address.setEndYear(nextAddress.getStartYear());
            address.setEndMonth(nextAddress.getStartMonth());
            address = nextAddress;
        }
    }
    
	static void setOriginalPurchasePrice(List<Address> fmaAddresses) {
		if (CollectionUtils.isEmpty(fmaAddresses)) {
			return;
		}

		List<Address> ownerAddresses = fmaAddresses.stream()
				.filter((a) -> OccupyStatusEnum.OWNER_MORTGAGED == a.getOccupyStatus()
						|| OccupyStatusEnum.OWNER_NO_MORTGAGE == a.getOccupyStatus())
				.collect(Collectors.toList());
		if (CollectionUtils.isEmpty(ownerAddresses)) {
			return;
		}
		for (Address ownerAddr : ownerAddresses) {
			ownerAddr.setOriginalPurchasePrice(BigDecimal.ONE);
		}
	}

	@AfterMapping
	default void applicantGenderMapping(Applicant sourceApplicant,
			@MappingTarget com.natwest.pbbdhb.openapi.fma.Applicant applicant) {
		if (applicant.getPersonalDetails().getTitle() == TitleEnum.MR) {
			applicant.getPersonalDetails().setGender(GenderEnum.MALE);
		} else if (FEMALE_TITLES.contains(applicant.getPersonalDetails().getTitle())) {
			applicant.getPersonalDetails().setGender(GenderEnum.FEMALE);
		}
	}
}
