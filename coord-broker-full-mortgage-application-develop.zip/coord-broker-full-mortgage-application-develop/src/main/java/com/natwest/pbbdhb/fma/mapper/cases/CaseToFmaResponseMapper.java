package com.natwest.pbbdhb.fma.mapper.cases;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.HardscoreDecisionDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailRequest;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.model.response.HardScoreDecision;
import com.natwest.pbbdhb.openapi.fma.ProductDetails;
import com.natwest.pbbdhb.openapi.fma.ResponseData;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Mapper(config = MappingConfig.class)
public interface CaseToFmaResponseMapper {

    @Mapping(target = "caseId", source = "caseId")
    @Mapping(target = "mortgageNumber", source = "mortgageReferenceNumber")
    @Mapping(target = "tempReferenceNumber", source = "mortgageTempReferenceNumber")
    @Mapping(target = "hardscoreDecision", source = "hardscoreDecision", qualifiedByName = "getHardscoreDecision")
    @Mapping(target = "status", source = "caseApplication" , qualifiedByName = "getStatus")
	@Mapping(target = "products", source = "salesIllustrations" , qualifiedByName = "getProducts")
    FmaResponse toFmaResponse(CaseApplicationDto caseApplication);
    
    
	@Named("getStatus")
	static String getStatus(CaseApplicationDto caseApplication) {
		if (Objects.nonNull(caseApplication.getMortgageReferenceNumber())) {
			return String.valueOf(HttpStatus.CREATED.value());
		}
		return null;
	}

	@Named("getHardscoreDecision")
	static HardScoreDecision getHardscoreDecision(HardscoreDecisionDto hardscoreDecisionDto) {
		HardScoreDecision hardScoreDecision = null;
		if (Objects.nonNull(hardscoreDecisionDto)) {
			hardScoreDecision = new ModelMapper().map(hardscoreDecisionDto, HardScoreDecision.class);
		}
		return hardScoreDecision;
	}

	@Named("getProducts")
	static Set<ProductDetails> getProducts(List<SalesIllustrationDto> salesIllustrations) {
		Set<ProductDetails> products = new HashSet<>();
		ModelMapper modelMapper = new ModelMapper();
		if (Objects.nonNull(salesIllustrations)) {
			for(SalesIllustrationDto salesIllustrationDto: salesIllustrations ){
				if(Objects.nonNull(salesIllustrationDto) && Objects.nonNull(salesIllustrationDto.getProducts())){
					for(ProductDetailsDto product : salesIllustrationDto.getProducts()){
						products.add(modelMapper.map(product, ProductDetails.class));
					}
				}
			}
		}
		return products;
	}

}
