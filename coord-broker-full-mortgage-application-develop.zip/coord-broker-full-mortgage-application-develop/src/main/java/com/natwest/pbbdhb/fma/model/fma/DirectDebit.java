package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class DirectDebit {

    @Schema(required = true, maxLength = 18, example = "Test Account")
    @Length(max = 18)
    @NotBlank(message = "cannot be null or empty")
    private String accountName;

    @Schema(description = "sort code should be 6 digit numeric", required = true, example = "603015", pattern = "^[0-9]{6}$")
    @Pattern(regexp = "^[0-9]{6}$")
    @NotBlank(message = "cannot be null or empty")
    private String sortCode;

    @Schema(required = true, example = "12345678", pattern = "^[0-9]{8}$")
    @Pattern(regexp = "^[0-9]{8}$")
    @NotBlank(message = "cannot be null or empty")
    private String accountNumber;

    @Schema(required = true, minimum = "1", maximum = "31", example = "5")
    @Min(1)
    @Max(31)
    @NotNull
    private Integer paymentDayOfTheMonth;

    @Schema(example = "false", allowableValues = { "true", "false" })
    private Boolean attestation;

}
