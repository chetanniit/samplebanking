package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class PortfolioLandlord {

    @Schema(required = true, minimum = "0", maximum = "99", example = "10")
    @Min(0)
    @Max(99)
    @NotNull
    private Integer numberOfYearsAsLandlord;

    @Schema(required = true, example = "false", allowableValues = { "true", "false" })
    @NotNull
    private Boolean planToExtendIn5Years;

    @Schema(minLength = 5, maxLength = 300, description = "Required if planToExtendIn5Years = true")
    @SmartRequired(
            conditions = @SmartCondition(path = "planToExtendIn5Years", values = "true"),
            message = "required if planToExtendIn5Years = true"
    )
    @Size(min = 5, max = 300)
    private String extendNotes;

    @Schema(required = true, example = "false", allowableValues = { "true", "false" })
    @NotNull
    private Boolean planToSellIn5Years;

    @Schema(minLength = 5, maxLength = 300, description = "Required if planToSellIn5Years = true")
    @SmartRequired(
            conditions = @SmartCondition(path = "planToSellIn5Years", values = "true"),
            message = "required if planToSellIn5Years = true"
    )
    @Size(min = 5, max = 300)
    private String sellNotes;

}
