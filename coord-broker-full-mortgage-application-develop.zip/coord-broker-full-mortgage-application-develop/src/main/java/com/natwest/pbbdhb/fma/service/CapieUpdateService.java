package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.fma.model.response.FmaResponse;

public interface CapieUpdateService {

    void updateCase(FmaResponse response, String brand, String caseId);

}
