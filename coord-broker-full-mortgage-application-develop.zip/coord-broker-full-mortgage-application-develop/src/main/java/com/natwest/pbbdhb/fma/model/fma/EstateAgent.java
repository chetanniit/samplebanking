package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class EstateAgent {

    @Schema(required = true, maxLength = 45)
    @Length(max = 45)
    @NotBlank(message = "cannot be null or empty")
    private String agencyName;

    @Schema(required = true)
    @Valid
    @NotNull
    private UkAddress address;

    @ArraySchema(
            schema = @Schema(implementation = Telephone.class, required = true),
            minItems = 1, maxItems = 4, uniqueItems = true
    )
    @Valid
    @NotNull
    @Size(min = 1, max = 4)
    private List<Telephone> telephones;
}
