package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;

public interface FmaSubmissionService {

    FmaResponse performFmaSubmission(Application application, String clientId, String brand);
}
