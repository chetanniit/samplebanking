package com.natwest.pbbdhb.fma.mapper.expense;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import com.natwest.pbbdhb.openapi.fma.FinancialCommitment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface FinancialCommitmentMapper {

    @Mapping(target = "amount", source = "financialCommitment.monthlyPayments") // monthlyPayments and
                                                                                // paymentsContinuing both are mapped to
                                                                                // amount in dip-fma lib
    @Mapping(target = "redeemedOrLessThanSixMonths", constant = "N")
    ExpenseTransactionDto map(FinancialCommitment financialCommitment);

}
