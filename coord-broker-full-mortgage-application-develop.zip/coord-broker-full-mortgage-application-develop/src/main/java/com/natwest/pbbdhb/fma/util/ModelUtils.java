package com.natwest.pbbdhb.fma.util;

import java.util.function.Function;

public class ModelUtils {

    public static <T, R> R safeGet(T object,
                                   Function<T, R> getR) {
        return typelessGet(object, getR);
    }

    public static <T, A, R> R safeGet(T object,
                                      Function<T, A> getA, Function<A, R> getR) {
        return typelessGet(object, getA, getR);
    }

    public static <T, A, B, R> R safeGet(T object,
                                         Function<T, A> getA, Function<A, B> getB, Function<B, R> getR) {
        return typelessGet(object, getA, getB, getR);
    }

    public static <T, A, B, C, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, R> getR) {
        return typelessGet(object, getA, getB, getC, getR);
    }

    public static <T, A, B, C, D, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getR);
    }

    public static <T, A, B, C, D, E, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, E> getE,
            Function<E, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getE, getR);
    }

    public static <T, A, B, C, D, E, F, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, E> getE,
            Function<E, F> getF, Function<F, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getE, getF, getR);
    }

    public static <T, A, B, C, D, E, F, G, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, E> getE,
            Function<E, F> getF, Function<F, G> getG, Function<G, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getE, getF, getG, getR);
    }

    public static <T, A, B, C, D, E, F, G, H, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, E> getE,
            Function<E, F> getF, Function<F, G> getG, Function<G, H> getH, Function<H, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getE, getF, getG, getH, getR);
    }

    public static <T, A, B, C, D, E, F, G, H, I, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, E> getE,
            Function<E, F> getF, Function<F, G> getG, Function<G, H> getH, Function<H, I> getI, Function<I, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getE, getF, getG, getH, getI, getR);
    }

    public static <T, A, B, C, D, E, F, G, H, I, J, R> R safeGet(
            T object,
            Function<T, A> getA, Function<A, B> getB, Function<B, C> getC, Function<C, D> getD, Function<D, E> getE,
            Function<E, F> getF, Function<F, G> getG, Function<G, H> getH, Function<H, I> getI, Function<I, J> getJ,
            Function<J, R> getR) {
        return typelessGet(object, getA, getB, getC, getD, getE, getF, getG, getH, getI, getJ, getR);
    }

    private static <T, R> R typelessGet(T object, Function... gets) {
        Object step = object;
        for (Function get : gets) {
            if (step == null) {
                return null;
            }
            step = get.apply(step);
        }
        return (R) step;
    }

}
