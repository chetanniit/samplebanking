package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.fma.model.fma.Application;

public interface CaseGenerationService extends BaseService {

    String generateCaseId(String brand, Application application, String clientId);
}
