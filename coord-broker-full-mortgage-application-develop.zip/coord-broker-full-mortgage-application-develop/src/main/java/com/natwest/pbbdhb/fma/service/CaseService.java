package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.search.CriteriaDto;
import com.natwest.pbbdhb.fma.dto.PatchDto;

import java.util.List;

public interface CaseService extends BaseService {

    CaseApplicationDto createCase(CaseApplicationDto caseApplication, String brand);
    CaseApplicationDto searchCasesByDipId(CriteriaDto criteriaDto, String brand);
    CaseApplicationDto patch(String brand, String caseId, List<PatchDto> jsonPatch);

}
