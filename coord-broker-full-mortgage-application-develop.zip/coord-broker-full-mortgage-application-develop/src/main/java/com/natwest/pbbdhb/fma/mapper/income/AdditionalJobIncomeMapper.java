package com.natwest.pbbdhb.fma.mapper.income;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.income.expense.model.enums.AdditionalIncomeType;
import com.natwest.pbbdhb.income.expense.model.income.dto.AdditionalJobIncomeDto;
import com.natwest.pbbdhb.model.request.incomeexpenditure.AdditionalIncomeTypes;
import com.natwest.pbbdhb.openapi.fma.Income;
import com.natwest.pbbdhb.openapi.fma.Income.TypeEnum;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

@Mapper(config = MappingConfig.class)
public interface AdditionalJobIncomeMapper {
    Set<TypeEnum> BONUS_TYPE_SET = EnumSet.of(TypeEnum.BONUS_DISCRETIONARY_PAID_ANNUALLY,
            TypeEnum.BONUS_DISCRETIONARY_PAID_BI_ANNUALLY, TypeEnum.BONUS_DISCRETIONARY_PAID_MONTHLY,
            TypeEnum.BONUS_DISCRETIONARY_PAID_QUARTERLY);
    Set<TypeEnum> BONUS_GUR_SET = EnumSet.of(TypeEnum.BONUS_GUARANTEED_PAID_ANNUALLY,
            TypeEnum.BONUS_GUARANTEED_PAID_BI_ANNUALLY, TypeEnum.BONUS_GUARANTEED_PAID_MONTHLY,
            TypeEnum.BONUS_GUARANTEED_PAID_QUARTERLY);

    @Mapping(target = "type", source = ".", qualifiedByName = "getAdditionalIncomeType")
    AdditionalJobIncomeDto map(Income income);

    @Named("getAdditionalIncomeType")
    default AdditionalIncomeType getAdditionalIncomeType(Income income) {
        if (BONUS_TYPE_SET.contains(income.getType())) {
            return AdditionalIncomeType.ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_BONUS_DISCRETIONARY;
        }

        if (BONUS_GUR_SET.contains(income.getType())) {
            return AdditionalIncomeType.ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_BONUS_GUARANTEED;
        }

        return Arrays.stream(AdditionalIncomeType.values())
                .filter(ai -> AdditionalIncomeTypes.getIncomeTypeForAdditionalIncomeType(ai)
                        .equalsIgnoreCase(income.getType().toString())).findFirst()
                .orElse(null);

    }

}
