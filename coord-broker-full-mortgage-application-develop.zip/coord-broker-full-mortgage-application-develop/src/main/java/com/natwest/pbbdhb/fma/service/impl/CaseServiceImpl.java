package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.fma.dto.PatchDto;
import com.natwest.pbbdhb.cases.dto.search.CriteriaDto;
import com.natwest.pbbdhb.fma.model.fma.CaseSearchResponse;
import com.natwest.pbbdhb.fma.service.CaseService;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;
import java.util.Objects;

import static java.util.Objects.nonNull;

@Service
@Slf4j
@Setter
public class CaseServiceImpl implements CaseService {

    @Value("${case.create.endpoint}")
    private String endPointUrl;

    @Value("${case.search.endpoint}")
    private String searchEndPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("restTemplateForPatchApiCalls")
    private RestTemplate restTemplatePatch;

    @Override
    public CaseApplicationDto createCase(CaseApplicationDto caseApplication, String brand) {
        log.info("createCase: called");
        log.debug("createCase: called with input= {}, brand= {}", caseApplication, brand);
        log.debug("createCase  endpoint called = {}", endPointUrl);
        HttpHeaders applicationHeaders = createHttpHeaders(brand);

        return restTemplate.postForObject(endPointUrl, new HttpEntity<>(caseApplication, applicationHeaders),
                CaseApplicationDto.class);

    }

    @Override
    public CaseApplicationDto searchCasesByDipId(CriteriaDto criteriaDto, String brand) {
        log.info("searchCasesByDipId: called");
        Integer page = 0;
        Integer size = 1;
        log.debug("searchCasesByDipId: called with brand={}, page={}, size={}", brand, page, size);
        log.debug("searchCasesByDipId  endpoint called = {}", searchEndPointUrl);
        HttpHeaders applicationHeaders = createHttpHeaders(brand);
        CaseSearchResponse response;
        HttpEntity<CriteriaDto> httpEntity = new HttpEntity<>(criteriaDto, applicationHeaders);
        try {
            response = restTemplate.postForObject(searchEndPointUrl + "?page=" + page + "&size=" + size, httpEntity, CaseSearchResponse.class);
            log.debug("searchCasesByDipId : {} completed", response);
        } catch (RestClientException exception) {
            if (log.isErrorEnabled()) {
                log.error("RestClientException occurred for generateCaseId : {}", exception.getMessage());
            }
            throw exception;
        }
        if(nonNull(response) && response.getContent().size() > 0) {
            log.debug("searchCasesByDipId : caseApplication fetched = {}", response);
            return Objects.requireNonNull(response).getContent().get(0);
        }

        log.info("searchCasesByDipId: completed");
        return null;
    }

    @Override
    public CaseApplicationDto patch(String brand, String caseId, List<PatchDto> jsonPatch) {
        log.debug("patch case: called with brand= {}", brand);
        Map<String, String> params = newHashMap();
        params.put("caseId", caseId);

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(endPointUrl + "/{caseId}");
        String url = uriBuilder.buildAndExpand(params).toUriString();
        HttpHeaders httpHeaders = createHttpHeaders(brand);

        return restTemplatePatch.exchange(url, HttpMethod.PATCH, new HttpEntity<>(jsonPatch, httpHeaders),
                CaseApplicationDto.class, params).getBody();
    }

    private HttpHeaders createHttpHeaders(String brand) {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
            headers.add(BRAND_HEADER, brand);
            return headers;
        }
}