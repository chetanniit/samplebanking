package com.natwest.pbbdhb.fma.mapper.gmsstate;

import com.natwest.pbbdhb.fma.mapper.MappingConfig;
import com.natwest.pbbdhb.fma.model.gmsstate.BrokerDetail;
import com.natwest.pbbdhb.openapi.fma.Broker;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = MappingConfig.class)
public interface BrokerProductStateMapper {
    @Mapping(target = "fcaReference", source = "fcaNumber")
    @Mapping(target = "networkInfo", source = "paymentPathName")
    @Mapping(target = "address.postcode", source = "brokerPostcode")
    BrokerDetail toBrokerDetailRequest(Broker broker);

}
