package com.natwest.pbbdhb.fma.model.fma.enums;

public enum MortgageOwnership {
    JOINT, SINGLE
}
