package com.natwest.pbbdhb.fma.helper;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.model.response.Link;
import com.natwest.pbbdhb.openapi.fma.Fee;
import com.natwest.pbbdhb.openapi.fma.Fee.ActionEnum;
import com.natwest.pbbdhb.openapi.fma.Fee.PaymentTypeEnum;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LinkHelper {
    @Value("${worldplay.url}")
    private String worldplayURL;

    @Value("${docupload.url}")
    private String docUploadURL;

    static final String RESPONSE_STATUS_CREATED = "201";
    static final String PAYMENT_URL = "paymentUrl";
    static final String DOC_URL = "documentsUploadUrl";

    public void addLinks(FmaResponse response) {
        if (RESPONSE_STATUS_CREATED.equalsIgnoreCase(response.getStatus())) {
            String docUploadUrl = String.format(docUploadURL, response.getMortgageNumber());
            String wpUrl = String.format(worldplayURL, response.getMortgageNumber());
            Map<String, Link> links = new HashMap<>();
			if (!CollectionUtils.isEmpty(getFeesForPayment(response))) {
				links.put(PAYMENT_URL, Link.of(wpUrl));
			}
            links.put(DOC_URL, Link.of(docUploadUrl));
            response.setLinks(links);
        }
    }
    
	private List<Fee> getFeesForPayment(FmaResponse response) {
		return response.getProducts().stream().filter((p) -> !CollectionUtils.isEmpty(p.getFees()))
				.flatMap((p) -> p.getFees().stream()).filter(this::isApplicableFee).collect(Collectors.toList());
	}

	private boolean isApplicableFee(Fee fee) {
		return ActionEnum.NO_ACTION.equals(fee.getAction()) && PaymentTypeEnum.CARD_PAYMENT.equals(fee.getPaymentType())
				&& Objects.nonNull(fee.getAmount()) && fee.getAmount().compareTo(BigDecimal.ZERO) > 0
				&& Objects.nonNull(fee.getType()) && (fee.getType().toLowerCase(Locale.ROOT).contains("product")
						|| fee.getType().toLowerCase(Locale.ROOT).contains("val"));
	}
   
    

}
