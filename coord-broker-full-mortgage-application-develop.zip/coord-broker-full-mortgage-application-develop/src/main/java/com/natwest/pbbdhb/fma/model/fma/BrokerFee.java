package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerFee {

    @Schema(required = true, minimum = "0", maximum = "99999999", multipleOf = 1, example = "150",
            description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal amount;

    

}
