package com.natwest.pbbdhb.fma.model.response;

public enum Decision {
    DECLINE, ACCEPT, REFER
}
