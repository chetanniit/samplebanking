package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.Gender;
import com.natwest.pbbdhb.fma.model.fma.enums.MaritalStatus;
import com.natwest.pbbdhb.fma.model.fma.enums.Title;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.SmartCountryIsoCodeValidation;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class PersonalDetails {

    @Schema(implementation = Title.class, required = true)
    @NotNull
    private Title title;

    @Schema(maxLength = 15, description = "Required if title = Other")
    @SmartRequired(conditions = @SmartCondition(path = "title", values = "OTHER"))
    @Size(max = 15)
    private String otherTitle;

    @Schema(example = "James", required = true, minLength = 1, maxLength = 15)
    @Size(min = 1, max = 15)
    @NotBlank(message = "cannot be null or empty")
    private String firstNames;

    @Schema(example = "John", maxLength = 25)
    @Size(max = 25)
    private String middleNames;

    @Schema(example = "Smith", required = true, minLength = 2, maxLength = 25)
    @Size(min = 2, max = 25)
    @NotBlank(message = "cannot be null or empty")
    private String lastName;

    @Schema(implementation = Gender.class, description = "If title is Mr/Ms/Mrs/Miss, gender is not required and will be defaulted. For all other titles, gender is conditional mandatory.", example = "MALE")
    @SmartRequired(conditions = {
            @SmartCondition(path = "title", values = {"MR","MISS","MRS","MS"}, negate = true)
    }, message = "Gender must be provided as MALE or FEMALE for selected title")
    private Gender gender;

    @Schema(implementation = String.class, example = "2000-01-01", pattern = "yyyy-MM-dd", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @NotNull
    private LocalDate dateOfBirth;

    @Schema(implementation = MaritalStatus.class, required = true)
    @NotNull
    private MaritalStatus maritalStatus;

    @Schema(required = true, description = "(ISO 3166-1, Alpha-2 code)", maxLength = 2, example = "GB")
    @SmartCountryIsoCodeValidation
    @NotBlank(message = "cannot be null or empty")
    @Size(max = 2)
    private String nationality;

    @Schema(description = "required if nationality is Non GB", example = "true", allowableValues = { "true", "false" })
    @SmartRequired(conditions = {
            @SmartCondition(path = "nationality", values = "GB", negate = true)
    })
    @SmartValidation(conditions = {
            @SmartCondition(path = "nationality", values = "GB"),
            @SmartCondition(path = "<field>", values = {"false"})
    }, message = "Right to reside cannot be false")
    private Boolean rightToReside;

    @Schema(required = true, maxLength = 2, example = "GB", description = "(ISO 3166-1, Alpha-2 code)")
    @SmartCountryIsoCodeValidation
    @Size(max = 2)
    @NotBlank(message = "cannot be null or empty")
    private String countryOfResidenceIsoCode;

    @ArraySchema(
            arraySchema = @Schema(description = "Customer telephone numbers"),
            schema = @Schema(implementation = Telephone.class, required = true),
            minItems = 1, uniqueItems = true
    )
    @Valid
    @NotNull
    @Size(min = 1)
    private List<Telephone> telephones;

    @Schema(required = true, pattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$", maxLength = 45, example = "applicant@email.com")
    @Email(regexp = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$")
    @Size(max = 45)
    @NotBlank(message = "cannot be null or empty")
    private String email;

}
