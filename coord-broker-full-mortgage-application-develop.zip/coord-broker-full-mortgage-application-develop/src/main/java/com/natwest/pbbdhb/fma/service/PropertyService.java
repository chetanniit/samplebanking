package com.natwest.pbbdhb.fma.service;

import com.natwest.pbbdhb.fma.dto.PatchDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;

import java.util.List;

public interface PropertyService extends BaseService {

    PropertyDetailsDto createProperty(PropertyDetailsDto property, String brand);

}