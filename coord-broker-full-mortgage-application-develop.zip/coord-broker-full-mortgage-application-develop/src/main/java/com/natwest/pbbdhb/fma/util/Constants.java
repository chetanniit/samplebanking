package com.natwest.pbbdhb.fma.util;

import java.time.format.DateTimeFormatter;

public interface Constants {
    DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    DateTimeFormatter DEFAULT_DATETIME_FORMAT = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss");
    String CLIENT_ID = "client_id";
    String BRAND = "brand";
    String UK_POSTCODE_PATTERN = "^(([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?)))) [0-9][A-Za-z]{2}$";
    String SCT_POSTCODE_PATTERN = "(?i)^(AB|DD|DG|EH|FK|G|HS|IV|KA|KW|KY|ML|PA|PH|TD|ZE)[0-9][A-Z0-9]?[ ]{1}[0-9][A-Z]{2}$";
    String NORTHERN_IRELAND_POSTCODE_PATTERN = "(?i)^BT([0-9][A-Z0-9]?[ ]{1}[0-9][A-Z]{2})$";
}
