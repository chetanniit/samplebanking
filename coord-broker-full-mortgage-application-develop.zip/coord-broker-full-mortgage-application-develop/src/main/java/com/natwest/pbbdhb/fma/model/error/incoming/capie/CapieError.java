package com.natwest.pbbdhb.fma.model.error.incoming.capie;

import lombok.Getter;

@Getter
public class CapieError {
    private String object;
    private String field;
    private String message;
}
