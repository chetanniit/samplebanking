package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class BankDetails {

    @Schema(implementation = String.class, example = "2021-01-31", required = true, pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @NotNull
    private LocalDate dateOpened;

    @Schema(required = true, example = "NatWest", maxLength = 30)
    @Size(max = 30)
    @NotBlank(message = "cannot be null or empty")
    private String bankName;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean debitCard;

    @Schema(example = "12345678", required = true, pattern = "^[0-9]{8}$")
    @Pattern(regexp = "^[0-9]{8}$")
    @NotBlank(message = "cannot be null or empty")
    private String accountNumber;

    @Schema(example = "603015", description = "sortcode should be 6 digit numeric", required = true, pattern = "^[0-9]{6}$")
    @Pattern(regexp = "^[0-9]{6}$")
    @NotBlank(message = "cannot be null or empty")
    private String sortCode;

    @Schema(required = true, maxLength = 18, example = "Temper Mane", description = "Account Holder Name")
    @Length(max = 18)
    @NotBlank(message = "cannot be null or empty")
    private String accountName;
}
