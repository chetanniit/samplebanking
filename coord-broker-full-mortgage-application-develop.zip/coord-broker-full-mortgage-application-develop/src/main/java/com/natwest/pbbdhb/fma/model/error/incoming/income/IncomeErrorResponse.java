package com.natwest.pbbdhb.fma.model.error.incoming.income;

import lombok.Getter;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

@Getter
public class IncomeErrorResponse {
    private HttpStatus responseStatus;
    private String errorMessage;
    private String statusCode;
    private String message;
    private String success;

    @Override
    public String toString() {
        return StringUtils.isNotBlank(errorMessage) ? errorMessage : message;
    }
}
