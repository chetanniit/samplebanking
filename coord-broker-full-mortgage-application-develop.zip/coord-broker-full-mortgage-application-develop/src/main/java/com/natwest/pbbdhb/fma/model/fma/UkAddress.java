package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.util.Constants;
import com.natwest.pbbdhb.fma.validator.SmartCountryIsoCodeValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class UkAddress extends BasicAddress {

    @Schema(required = true, example = "E11 2NB", maxLength = 8, pattern = Constants.UK_POSTCODE_PATTERN,
            description = "Must be valid UK postcode")
    @Pattern(regexp = Constants.UK_POSTCODE_PATTERN, message = "must be valid UK postcode")
    @Size(max = 8)
    @NotBlank(message = "cannot be null or empty")
    private String postcode;

    @Schema(required = true, maxLength = 2, example = "GB", pattern = "^GB$", description = "(ISO 3166-1, Alpha-2 code) Must be GB")
    @SmartCountryIsoCodeValidation
    @Pattern(regexp = "^GB$", message = "must be GB")
    @Size(max = 2)
    @NotBlank(message = "cannot be null or empty")
    private String countryIsoCode;

}
