package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.search.*;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import com.natwest.pbbdhb.fma.exception.BrokerValidationFailException;
import com.natwest.pbbdhb.fma.exception.PaymentPathInvalidException;
import com.natwest.pbbdhb.fma.helper.LinkHelper;
import com.natwest.pbbdhb.fma.mapper.FmaMapper;
import com.natwest.pbbdhb.fma.mapper.FmaResponseMapper;
import com.natwest.pbbdhb.fma.mapper.applicant.ApplicantMapper;
import com.natwest.pbbdhb.fma.mapper.cases.CaseMapper;
import com.natwest.pbbdhb.fma.mapper.cases.CaseToFmaResponseMapper;
import com.natwest.pbbdhb.fma.mapper.expense.ExpenditureMapper;
import com.natwest.pbbdhb.fma.mapper.gmsstate.BrokerProductStateMapper;
import com.natwest.pbbdhb.fma.mapper.income.IncomeMapper;
import com.natwest.pbbdhb.fma.mapper.property.PropertyMapper;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailRequest;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailResponse;
import com.natwest.pbbdhb.fma.model.brokervalidation.FirmBroker;
import com.natwest.pbbdhb.fma.model.brokervalidation.PaymentPath;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.Broker;
import com.natwest.pbbdhb.fma.model.fma.BuyToLet;
import com.natwest.pbbdhb.fma.model.fma.DirectDebit;
import com.natwest.pbbdhb.fma.model.gmsstate.GmsSourceOneSourceTwoResponse;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.service.ApplicantService;
import com.natwest.pbbdhb.fma.service.BrokerValidationService;
import com.natwest.pbbdhb.fma.service.CapieUpdateService;
import com.natwest.pbbdhb.fma.service.CaseGenerationService;
import com.natwest.pbbdhb.fma.service.CaseService;
import com.natwest.pbbdhb.fma.service.ExpenditureService;
import com.natwest.pbbdhb.fma.service.FmaService;
import com.natwest.pbbdhb.fma.service.FmaSubmissionService;
import com.natwest.pbbdhb.fma.service.GmsProductStateService;
import com.natwest.pbbdhb.fma.service.IncomeService;
import com.natwest.pbbdhb.fma.service.PropertyService;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus.*;

@Service
@Slf4j
public class FmaSubmissionServiceImpl implements FmaSubmissionService {

    private static final List<ApplicationStatus> APPLICATION_STATUSES = Arrays.asList(SUBMIT_GMS_MOPS, SUBMIT_FMA_IN_PROGRESS, HARDSCORE_DECLINED);
    @Value("${application.response.show-case-id}")
    private boolean showCaseId;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private BrokerValidationService brokerValidationService;

    @Autowired
    private CaseGenerationService caseGenerationService;

    @Autowired
    private CaseService caseService;

    @Autowired
    private CaseMapper caseMapper;

    @Autowired
    private ApplicantService applicantService;

    @Autowired
    private ApplicantMapper applicantMapper;

    @Autowired
    private PropertyService propertyService;

    @Autowired
    private PropertyMapper propertyMapper;

    @Autowired
    private IncomeService incomeService;

    @Autowired
    private IncomeMapper incomeMapper;

    @Autowired
    private ExpenditureService expenditureService;

    @Autowired
    private ExpenditureMapper expenditureMapper;

    @Autowired
    private CapieUpdateService capieUpdateService;

    @Autowired
    private FmaService fmaService;

    @Autowired
    private FmaMapper fmaMapper;

    @Autowired
    private FmaResponseMapper fmaResponseMapper;

    @Autowired
    private LinkHelper linkHelper;

    @Autowired
    private GmsProductStateService gmsProductStateService;

    @Autowired
    private BrokerProductStateMapper brokerProductStateMapper;

    @Autowired
    private CaseToFmaResponseMapper caseToFmaResponseMapper;

    @Value("${broker.default.id}")
    private Integer brokerDefaultId;

    @Override
    public FmaResponse performFmaSubmission(Application application, String clientId, String brand) {
        log.info("Perform FMA called");
        log.debug("Perform FMA called with input:{}", application);
        log.debug("Perform FMA called with brand:{}", brand);
        BrokerDetailResponse brokerDetailResponse = validateBrokerAndPaymentPath(application.getBroker());
        log.debug("Broker and Payment Path validated");

        if(application.getDipId()!= null) {
            CaseApplicationDto caseApplicationDto = getCaseApplicationDto(application, brand);

            if (Objects.nonNull(caseApplicationDto) && Objects.nonNull(caseApplicationDto.getApplicationStatus())) {
                 ApplicationStatus status = ApplicationStatus.valueOf(caseApplicationDto.getApplicationStatus());
                if (SUBMIT_GMS_STAGE_20.equals(status)) {
                    FmaResponse fmaResponse = caseToFmaResponseMapper.toFmaResponse(caseApplicationDto);
                    linkHelper.addLinks(fmaResponse);
                    return fmaResponse;
                } else if (APPLICATION_STATUSES.contains(status)) {
                    return caseToFmaResponseMapper.toFmaResponse(caseApplicationDto);
                }
            }
        }

        String caseId = caseGenerationService.generateCaseId(brand, application, clientId);
        log.info("caseId generated = {}", caseId);

        FullMortgageApplicationRequest request = fmaMapper.toFMARequest(application, getBroker(brokerDetailResponse));
        request.getApplication().setCaseId(caseId);
        request.getApplication().getBroker().setPaymentPathName(application.getBroker().getPaymentPathName());
        
        setBrokerNetworkIdAndId(request, brand);

        log.info("CAPIE CREATE IN PROGRESS");
        createCase(request, application.getMortgage().getBuyToLet(), application.getDirectDebit(), brand, clientId);
        log.debug("CAPIE Case created");
        Map<Applicant, String> applicantToId = createApplicants(request, brand, application);
        log.debug("CAPIE Applicant created");
        createProperty(request, brand);
        log.debug("CAPIE Property created");
        createIncome(request, brand, applicantToId);
        log.debug("CAPIE Income created");
        createExpense(request, brand, applicantToId);
        log.debug("CAPIE Expense created");
        log.info("CAPIE CREATE COMPLETE");

        FullMortgageApplicationExtendedResponse response = performFMASubmission(request, brand, clientId);
        log.info("FMA Call Complete with response = {}", response);
        log.info("CAPIE case {} should be updated by CAPIE FMA LISTENER", caseId);

        FmaResponse fmaResponse = fmaResponseMapper.toFmaResponse(response.getData(),response.getResponseStatus().getStatus());
        if (showCaseId) {
            fmaResponse.setCaseId(caseId);
        }
        fmaResponse.setStatus(response.getResponseStatus().getStatus());
        linkHelper.addLinks(fmaResponse);
        log.info("CAPIE UPDATE IN PROGRESS");
        updateCap(brand, caseId, fmaResponse);
        log.info("CAPIE UPDATE COMPLETE");
        return fmaResponse;
    }

    private CaseApplicationDto getCaseApplicationDto(Application application, String brand) {
        CriteriaDto criteriaDto = new CriteriaDto();
        QueryDto queryDto = new QueryDto();
        SimpleOperatorDto simpleOperatorDto = new SimpleOperatorDto();
        simpleOperatorDto.setCompareType(SimpleOperatorDto.CompareType.EQ);
        simpleOperatorDto.setField("decisionInPrinciples.dipId");
        simpleOperatorDto.setValue(application.getDipId());
        queryDto.setOperator(simpleOperatorDto);
        criteriaDto.setQuery(queryDto);

        List<OrderDto> OrderDtoList = new ArrayList<>();
        OrderDto orderDto = new OrderDto();
        orderDto.setDirection(Sort.Direction.DESC);
        orderDto.setField("createdDate");
        orderDto.setNullHandling(Sort.NullHandling.NULLS_LAST);
        OrderDtoList.add(orderDto);
        SortDto sortDto = new SortDto();
        sortDto.setOrders(OrderDtoList);
        criteriaDto.setSort(sortDto);

        log.debug("calling capie to fetch data using existing dipId");
        CaseApplicationDto caseApplicationDto = caseService.searchCasesByDipId(criteriaDto, brand);
        log.debug("search call to capie completed, caseApplicationDto={} ", caseApplicationDto);

        return caseApplicationDto;
    }

    private BrokerDetailResponse validateBrokerAndPaymentPath(Broker broker) {
        log.info("Validate broker and payment path called");
        log.debug("Validate broker and payment path called for broker:{}", broker);

        BrokerDetailResponse brokerDetailResponse;
        try {
            brokerDetailResponse = brokerValidationService.validate(modelMapper.map(broker, BrokerDetailRequest.class));
        } catch (HttpStatusCodeException e) {
            if (e.getStatusCode().is4xxClientError()) {
                if (log.isWarnEnabled()) {
                    log.warn("BROKER IS NOT FOUND FOR FCA NUMBER: {} (Surname: {})", broker.getFcaNumber(),
                            broker.getBrokerSurname());
                }
                if (log.isErrorEnabled() && !HttpStatus.NOT_FOUND.equals(e.getStatusCode())) {
                    log.error("Error on broker validate", e);
                }
                throw new BrokerValidationFailException(
                        "Broker doesn't have permission to submit, " + "please contact the lender directly");
            } else {
                throw e;
            }
        }
        if (!isValidBroker(brokerDetailResponse)) {
            if (log.isWarnEnabled()) {
                log.warn("BROKER BUSINESS NOT ALLOWED FOR FCA NUMBER: {} (Surname: {})", broker.getFcaNumber(),
                        broker.getBrokerSurname());
            }
            throw new BrokerValidationFailException(
                    "Broker doesn't have permission to submit, " + "please contact the lender directly");
        }
        if (!isValidPaymentPath(broker, brokerDetailResponse)) {
            if (log.isWarnEnabled()) {
                log.warn("Payment Path Details not valid - paymentPathName: {}, paymentPathId: {} )",
                        broker.getPaymentPathName(), broker.getPaymentPathId());
            }
            throw new PaymentPathInvalidException("Payment Path Name and/or ID is invalid");
        }

        log.info("Validate broker and payment path completed");
        return brokerDetailResponse;
    }

    private boolean isValidBroker(BrokerDetailResponse brokerDetailResponse) {
        return brokerDetailResponse.getBrokers() != null && !brokerDetailResponse.getBrokers().isEmpty()
                && brokerDetailResponse.getBrokers().stream()
                        .allMatch(broker -> "Yes".equalsIgnoreCase(broker.getAcceptMortgageBusiness()));
    }

    private boolean isValidPaymentPath(Broker broker, BrokerDetailResponse brokerDetailResponse) {
        Set<PaymentPath> paymentPaths = brokerDetailResponse.getPaymentPaths();
        return paymentPaths != null && !paymentPaths.isEmpty()
                && paymentPaths.stream()
                        .anyMatch(paymentPath -> broker.getPaymentPathId().equals(paymentPath.getPaymentPathID())
                                && broker.getPaymentPathName().equals(paymentPath.getPaymentPathName()));
    }

    private void createCase(FullMortgageApplicationRequest fmaRequest,
                            BuyToLet buyToLet,
                            DirectDebit directDebit,
                            String brand,
                            String clientId) {
        CaseApplicationDto caseApplication = caseMapper.toCaseApplication(fmaRequest.getApplication(), buyToLet, directDebit);
        caseApplication.getBroker().setTppId(clientId);
        caseService.createCase(caseApplication, brand);
    }

    private Map<Applicant, String> createApplicants(FullMortgageApplicationRequest fmaRequest, String brand,
            Application application) {
        String caseId = fmaRequest.getApplication().getCaseId();
        Map<Applicant, String> applicantMap = new IdentityHashMap<>();
        AtomicInteger atomicIndex = new AtomicInteger(0);

        fmaRequest.getApplicants().forEach(applicant -> {
            Integer index = atomicIndex.getAndIncrement();
            applicantMap.put(applicant,
                    applicantService.createApplicant(applicantMapper.toCreateApplicant(applicant, caseId,
                            application.getApplicants().get(index).getMainApplicant(),
                            application.getApplicants().get(index).getConsentToFMA()), brand).getApplicantId());
        });

        return applicantMap;
    }

    private void createProperty(FullMortgageApplicationRequest fmaRequest, String brand) {
        propertyService.createProperty(propertyMapper.toPropertyDetails(fmaRequest.getApplication().getProperty(),
                fmaRequest.getApplication().getCaseId()), brand);
    }

    private void createIncome(FullMortgageApplicationRequest fmaRequest, String brand,
            Map<Applicant, String> applicantToId) {
        incomeService.createIncome(fmaRequest.getApplication().getCaseId(), brand,
                incomeMapper.convertToIncomeRequest(fmaRequest, applicantToId));

    }

    private void createExpense(FullMortgageApplicationRequest fmaRequest, String brand,
            Map<Applicant, String> applicantToId) {
        expenditureService.createExpense(fmaRequest.getApplication().getCaseId(), brand,
                expenditureMapper.convertToExpenseRequest(fmaRequest, applicantToId));

    }

    private FullMortgageApplicationExtendedResponse performFMASubmission(FullMortgageApplicationRequest request,
            String brand, String clientId) {

        return fmaService.submitFma(request, brand, clientId);

    }

    private void updateCap(String brand, String caseId, FmaResponse response) {
        try {
            capieUpdateService.updateCase(response, brand, caseId);
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("exception in updating capie details : {}", e.getMessage());
            }
        }

    }

    private void setBrokerNetworkIdAndId(FullMortgageApplicationRequest fmaRequest, String brand) {
        log.debug("Gms Product state api called");
        List<GmsSourceOneSourceTwoResponse> gmsResponses = gmsProductStateService
                .getGmsProductStateResponse(brokerProductStateMapper
                        .toBrokerDetailRequest(fmaRequest.getApplication().getBroker()), brand);

        log.debug("response from gms product state {}", gmsResponses);
        com.natwest.pbbdhb.openapi.fma.Broker broker = fmaRequest.getApplication().getBroker();
        if (!CollectionUtils.isEmpty(gmsResponses)) {
            broker.setId(null != gmsResponses.get(0).getSource1() ? Integer.valueOf(gmsResponses.get(0).getSource1())
                    : null);
            broker.setNetworkId(null != gmsResponses.get(0).getSource2()
                    ? Integer.valueOf(gmsResponses.get(0).getSource2()) : null);
        }
		else {
			log.info("empty response received from gms state setting default id");
			broker.setId(brokerDefaultId);
		}

    }

	private FirmBroker getBroker(BrokerDetailResponse brokerDetailResponse) {
		FirmBroker broker = brokerDetailResponse.getBrokers().stream().findFirst().get();
		if (null != broker) {
			log.debug(
					"broker from broker detail validate response fcaNumber {},brokerTelephoneNumber {}, brokerMobilenumber {}",
					broker.getFcaNumber(), broker.getBrokerTelephoneNumber(), broker.getBrokerMobileNumber());
		}
		return broker;
	}
}
