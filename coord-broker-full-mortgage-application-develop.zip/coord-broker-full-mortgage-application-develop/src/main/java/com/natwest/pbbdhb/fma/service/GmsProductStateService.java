package com.natwest.pbbdhb.fma.service;

import java.util.List;

import com.natwest.pbbdhb.fma.model.gmsstate.BrokerDetail;
import com.natwest.pbbdhb.fma.model.gmsstate.GmsSourceOneSourceTwoResponse;

public interface GmsProductStateService {
    List<GmsSourceOneSourceTwoResponse> getGmsProductStateResponse(BrokerDetail brokerDetail, String brand);
}
