package com.natwest.pbbdhb.fma.serialization;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonStreamContext;
import lombok.Getter;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Getter
public class DeserializationValidationException extends RuntimeException {

    private JsonLocation location;
    private String fieldPath;

    public DeserializationValidationException(String msg, JsonParser jsonParser) {
        super(msg);
        this.location = jsonParser.getTokenLocation();
        this.fieldPath = calculatePath(jsonParser.getParsingContext());
    }

    private String calculatePath(JsonStreamContext parsingContext) {
        List<String> tokens = streamOf(parsingContext, JsonStreamContext::getParent)
                .map(ctx -> ctx.inRoot() ? ""
                            : ctx.inArray() ? "[" + ctx.getCurrentIndex() + "]"
                            : "." + ctx.getCurrentName()
                )
                .collect(Collectors.toList());
        Collections.reverse(tokens);
        return String.join("", tokens).replaceAll("^\\.", "");
    }

    private <T> Stream<T> streamOf(T head, Function<T, T> getNextOrNull) {
        return StreamSupport.stream(iterableOf(head, getNextOrNull).spliterator(), false);
    }

    private <T> Iterable<T> iterableOf(T head, Function<T, T> getNextOrNull) {
        return () -> new Iterator<T>() {
            private T next = head;
            @Override
            public boolean hasNext() {
                return next != null;
            }
            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                T current = next;
                next = getNextOrNull.apply(current);
                return current;
            }
        };
    }

}
