package com.natwest.pbbdhb.fma.validator.conditional;

import java.util.List;

/**
 * Implement this interface to provide some custom logic for {@link SmartCondition}.<br>
 * Implementation must have default constructor.
 **/
public interface SmartCheck<T> {

    /**
     * The method is called instead of direct comparison of actual field value with predefined ones.
     *
     * @param actualValue
     *            actual value of the field
     * @param conditionValues
     *            list of constant values specified in {@link SmartCondition} annotation
     * @param smartContext
     *            context to extract additional data
     * @return
     */
    boolean check(T actualValue, List<String> conditionValues, SmartContext smartContext);

    /**
     * Just a Void implementation of the interface to use as default implementation
     */
    final class VoidCheck implements SmartCheck<Object> {
        @Override
        public boolean check(Object actualValue, List<String> annotationValues, SmartContext smartContext) {
            return false;
        }
    }

}
