package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.LoanType;
import com.natwest.pbbdhb.fma.model.fma.enums.Provider;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class Loan {

    @Schema(implementation = LoanType.class, required = true)
    @NotNull
    private LoanType type;

    @Schema(implementation = Provider.class, example = "RBS", required = true)
    @NotNull
    private Provider provider;

    @Schema(maxLength = 30, description = "Required if provider = OTHER", example = "HSBC")
    @SmartRequired(
            conditions = @SmartCondition(path = "provider", values = "OTHER"),
            message = "required when provider is other"
    )
    @Length(max = 30)
    private String otherProvider;

    @Schema(example = "300", required = true, minimum = "0", maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin("0")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal monthlyPayment;

    @Schema(example = "10000", minimum = "0", maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin("0")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal amountOutstanding;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean toBeRepaid;

    @Schema(example = "true", allowableValues = { "true", "false" })
    private Boolean debtConsolidation;

    @Schema(example = "0", minimum = "0", maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin("0")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    private BigDecimal consolidationAmount;

}
