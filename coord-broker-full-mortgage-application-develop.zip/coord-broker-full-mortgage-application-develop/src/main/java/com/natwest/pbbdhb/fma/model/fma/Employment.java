package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.EmploymentPaymentFrequency;
import com.natwest.pbbdhb.fma.model.fma.enums.EmploymentStatus;
import com.natwest.pbbdhb.fma.model.fma.enums.EmploymentType;
import com.natwest.pbbdhb.fma.model.fma.enums.IndustryType;
import com.natwest.pbbdhb.fma.model.fma.enums.OccupationCode;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartDateCheck;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class Employment {

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean primary;

    @Schema(implementation = EmploymentStatus.class, required = true)
    @NotNull
    private EmploymentStatus employmentStatus;

    @Schema(implementation = EmploymentType.class, required = true)
    @NotNull
    private EmploymentType employmentType;

    @Schema(implementation = OccupationCode.class, required = true)
    @NotNull
    private OccupationCode occupationCode;

    @Schema(implementation = IndustryType.class, description = "Required if employmentStatus is EMPLOYED or SELF_EMPLOYED")
    @SmartRequired(
            conditions = @SmartCondition(path = "employmentStatus", values = {"EMPLOYED", "SELF_EMPLOYED"}),
            message = "required if employmentStatus is EMPLOYED or SELF_EMPLOYED"
    )
    private IndustryType industryType;

    @Schema(implementation = String.class, example = "2010-01-01", pattern = "yyyy-MM-dd", description = "required when employmentStatus is EMPLOYED")
    @SmartRequired(conditions = @SmartCondition(path = "employmentStatus", values = "EMPLOYED"))
    @SmartValidation(conditions = {
            @SmartCondition(path = "primary", values = "true"),
            @SmartCondition(path = "<field>", values = {">", "<now>"}, smartCheck = SmartDateCheck.class)
    }, message = "cannot be in the future if primary is true")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate startDate;

    @Schema(implementation = String.class, example = "2015-01-01", pattern = "yyyy-MM-dd", description = "required if employmentType = CONTRACT")
    @SmartRequired(conditions = {
            @SmartCondition(path = "employmentStatus", values = "NOT_EMPLOYED", negate = true),
            @SmartCondition(path = "employmentType", values = "CONTRACT")
    })
    @SmartValidation(conditions = {
            @SmartCondition(path = "employmentStatus", values = "NOT_EMPLOYED", negate = true),
            @SmartCondition(path = "primary", values = "true"),
            @SmartCondition(path = "employmentType", values = "CONTRACT"),
            @SmartCondition(path = "<field>", values = {"<=", "<now>"}, smartCheck = SmartDateCheck.class)
    }, message = "should be in the future for employmentType CONTRACT if primary is true")
    @SmartValidation(conditions = {
            @SmartCondition(path = "employmentStatus", values = "NOT_EMPLOYED", negate = true),
            @SmartCondition(path = "primary", values = "true"),
            @SmartCondition(path = "employmentType", values = "CONTRACT", negate = true),
            @SmartCondition(path = "<field>", nullOrEmpty = true, negate = true)
    }, message = "cannot be provided for employmentType other than CONTRACT if primary is true")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate endDate;

    @ArraySchema(
            arraySchema = @Schema(description = "required if applicant employmentStatus = EMPLOYED"),
            schema = @Schema(implementation = Income.class),
            uniqueItems = true
    )
    @SmartRequired(conditions = @SmartCondition(path = "employmentStatus", values = "EMPLOYED"))
    @Valid
    private List<Income> incomes;

    @Schema(example = "XYZ Ltd", maxLength = 30, description = "Required if employmentStatus is EMPLOYED or SELF_EMPLOYED")
    @SmartRequired(
            conditions = @SmartCondition(path = "employmentStatus", values = {"EMPLOYED", "SELF_EMPLOYED"}),
            message = "required if employmentStatus is EMPLOYED or SELF_EMPLOYED"
    )
    @Size(max = 30)
    private String employerName;

    @Schema(description = "Required if employmentStatus is EMPLOYED or SELF_EMPLOYED")
    @SmartRequired(
            conditions = @SmartCondition(path = "employmentStatus", values = {"EMPLOYED", "SELF_EMPLOYED"}),
            message = "required if employmentStatus is EMPLOYED or SELF_EMPLOYED"
    )
    @Valid
    private Address address;

    @Schema(implementation = EmploymentPaymentFrequency.class, example = "MONTHLY")
    private EmploymentPaymentFrequency paymentFrequency;

    @Schema(description = "Required if employmentStatus is SELF_EMPLOYED", implementation = SelfEmployed.class)
    @SmartRequired(conditions = @SmartCondition(path = "employmentStatus", values = "SELF_EMPLOYED"))
    @Valid
    private SelfEmployed selfEmployed;

    @ArraySchema(
            schema = @Schema(implementation = Telephone.class),
            minItems = 1, uniqueItems = true
    )
    @Valid
    @Size(min = 1)
    private List<Telephone> telephones;
}