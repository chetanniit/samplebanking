package com.natwest.pbbdhb.fma.validator;

import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@SmartValidation(
        conditions = @SmartCondition(path = "<field>", negate = true, smartCheck = SmartChecks.ValidCountryIsoCode.class),
        message = "has invalid country iso code value"
)
public @interface SmartCountryIsoCodeValidation {}
