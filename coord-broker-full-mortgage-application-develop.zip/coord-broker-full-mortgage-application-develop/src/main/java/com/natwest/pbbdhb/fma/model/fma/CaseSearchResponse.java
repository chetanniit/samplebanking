package com.natwest.pbbdhb.fma.model.fma;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CaseSearchResponse {
    List<CaseApplicationDto> content;
}
