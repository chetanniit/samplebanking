package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.fma.model.fma.enums.ApplicationType;
import com.natwest.pbbdhb.fma.model.fma.enums.BuyerType;
import com.natwest.pbbdhb.fma.model.fma.enums.LevelOfService;
import com.natwest.pbbdhb.fma.model.fma.enums.LoanPurpose;
import com.natwest.pbbdhb.fma.model.fma.enums.SchemeType;
import com.natwest.pbbdhb.fma.model.fma.enums.TranscriptValuer;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartConditionalRoot;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartNumberCheck;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@SmartConditionalRoot
public class Application {

    @ArraySchema(
            schema = @Schema(implementation = Applicant.class, required = true),
            minItems = 1, maxItems = 2, uniqueItems = true
    )
    @Valid
    @NotNull
    @Size(min = 1, max = 2)
    @SmartValidation(
            conditions = @SmartCondition(path = ".", negate = true, smartCheck = SmartChecks.AtLeastOneMainApplicant.class),
            message = "atmost one applicant required to have mainApplicant as true"
    )
    private List<Applicant> applicants;

    @Schema(required = true)
    @Valid
    @NotNull
    private Broker broker;

    @Schema(required = true, maxLength = 50)
    @Length(max = 50)
    @NotBlank(message = "cannot be null or empty")
    private String dipId;

    @Schema(hidden = true)
    @JsonIgnore
    private String caseId;

    @Schema(implementation = ApplicationType.class, required = true, example = "RESIDENTIAL")
    @NotNull
    private ApplicationType type;

    @Schema(implementation = LoanPurpose.class, required = true, example = "HOUSE_PURCHASE")
    @NotNull
    private LoanPurpose loanPurpose;
    
    @Schema(implementation = Interview.class, required = true, example = "TELEPHONE")
    @NotNull
    private Interview interview;

    @Schema(required = true, example = "false", allowableValues = { "true", "false" })
    @NotNull
    private Boolean scottishApplication;

    @Schema(example = "false", allowableValues = { "true", "false" })
    @SmartValidation(conditions = {
            @SmartCondition(path = "scottishApplication", values = "true"),
            @SmartCondition(path = "<field>", values = "true")
    }, message = "Both scottishApplication and northernIrelandApplication cannot be true", showPathInMessage = false)
    private Boolean northernIrelandApplication;

    @Schema(implementation = TranscriptValuer.class, example = "CONNELLS", description = "Required if loanPurpose = HOUSE_PURCHASE and scottishApplication = true")
    @SmartRequired(conditions = {
            @SmartCondition(path = "scottishApplication", values = "true"),
            @SmartCondition(path = "loanPurpose", values = "HOUSE_PURCHASE")
    }, message = "is required if loanPurpose is HOUSE_PURCHASE and scottishApplication is true")
    private TranscriptValuer transcriptValuer;

    @Schema(implementation = String.class, example = "2020-01-01", pattern = "yyyy-MM-dd", description = "Required if loanPurpose = HOUSE_PURCHASE and scottishApplication = true")
    @SmartRequired(conditions = {
            @SmartCondition(path = "scottishApplication", values = "true"),
            @SmartCondition(path = "loanPurpose", values = "HOUSE_PURCHASE")
    }, message = "is required if loanPurpose is HOUSE_PURCHASE and scottishApplication is true")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateValidatingDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate transcriptValuationDate;

    @Schema(hidden = true, required = true)
    @JsonIgnore
    @NotBlank(message = "cannot be null or empty")
    private final String channel = "INTERMEDIARY_BROKER_API";

    @Schema(hidden = true, required = true)
    @JsonIgnore
    @NotBlank(message = "cannot be null or empty")
    private final String marketingSource = "A1";

    @Schema(implementation = BuyerType.class, required = true, example = "FIRST_TIME_BUYER")
    @NotNull
    private BuyerType buyerType;

    @Schema(required = true, example = "false", allowableValues = { "true", "false" })
    @NotNull
    private Boolean govtSharedEquityScheme;

    @Schema(implementation = SchemeType.class, description = "Required if govtSharedEquityScheme = true")
    @SmartRequired(
            conditions = @SmartCondition(path = "govtSharedEquityScheme", values = "true"),
            message = "is required if Government Shared Equity Scheme is true"
    )
    private SchemeType schemeType;

    @Schema(maxLength = 50, description = "Required if govtSharedEquityScheme = true and  schemeType = OTHER")
    @SmartRequired(conditions = {
            @SmartCondition(path = "govtSharedEquityScheme", values = "true"),
            @SmartCondition(path = "schemeType", values = "OTHER")
    }, message = "is required if Government Shared Equity Scheme is true and Scheme Type is OTHER")
    @Length(max = 50)
    private String schemeName;

    @Schema(description = "Required if govtSharedEquityScheme = true", example = "true", allowableValues = { "true",
            "false" })
    @SmartValidation(conditions = {
            @SmartCondition(path = "govtSharedEquityScheme", values = "true"),
            @SmartCondition(path = "mainResidence", values = "true", negate = true)
    }, message = "must be true if govtSharedEquityScheme = true")
    private Boolean mainResidence;

    @Schema(hidden = true, required = true)
    @JsonIgnore
    @NotBlank(message = "cannot be null or empty")
    private final String additionalServicesRequired = "EKYC";

    @Schema(required = true)
    @Valid
    @NotNull
    private DirectDebit directDebit;

    @Schema(required = true)
    @Valid
    @NotNull
    private PurchaseProperty property;

    @Schema
    @Valid
    private EstateAgent estateAgent;

    @Schema(description = "Required if (loanPurpose = HOUSE_PURCHASE) or (loanPurpose = REMORTGAGE and mortgageAmount >= 2M) or (loanPurpose = REMORTGAGE and no free legal product)")
    @SmartRequired(
            conditions = @SmartCondition(path = "loanPurpose", values = "HOUSE_PURCHASE"),
            message = "required if loanPurpose = HOUSE_PURCHASE"
    )
    @SmartRequired(conditions = {
            @SmartCondition(path = "loanPurpose", values = "REMORTGAGE"),
            @SmartCondition(path = "mortgage/mortgageAmount", values = { ">=", "2 000 000" }, smartCheck = SmartNumberCheck.class)
    }, message = "required if loanPurpose = REMORTGAGE AND mortgageAmount >= to 2M")
    @Valid
    private Solicitor solicitor;

    @Schema(required = true)
    @Valid
    @NotNull
    private Mortgage mortgage;

    @Schema(implementation = LevelOfService.class, required = true, example = "ADVISED",
            description = "Type of service offered. Must be NON_ADVISED for Buy to Let application. Must be ADVISED when additionalBorrowing.reason is DEBT_CONSOLIDATION or mortgage.rightToBuy is true or mortgage.mortgageType is INTEREST_ONLY.")
    @SmartValidation(conditions = {
            @SmartCondition(path = "type", values = "BUY_TO_LET"),
            @SmartCondition(path = "<field>", values = "NON_ADVISED", negate = true)
    }, message = "must be NON_ADVISED for Buy to Let application")
    @SmartValidation(conditions = {
            @SmartCondition(path = "mortgage/additionalBorrowings[?]/reason", values = "DEBT_CONSOLIDATION"),
            @SmartCondition(path = "<field>", values = "ADVISED", negate = true)
    }, message = "must be ADVISED when additionalBorrowing.reason is DEBT_CONSOLIDATION")
    @SmartValidation(conditions = {
            @SmartCondition(path = "mortgage/rightToBuy", values = "true"),
            @SmartCondition(path = "<field>", values = "ADVISED", negate = true)
    }, message = "must be ADVISED when mortgage.rightToBuy is true")
    @SmartValidation(conditions = {
            @SmartCondition(path = "mortgage/mortgageType", values = "INTEREST_ONLY"),
            @SmartCondition(path = "<field>", values = "ADVISED", negate = true)
    }, message = "must be ADVISED when mortgage.mortgageType is INTEREST_ONLY")
    @NotNull
    private LevelOfService levelOfService;

    @Schema(required = true, minimum = "0", maximum = "99", example = "0")
    @Min(value = 0)
    @Max(value = 99)
    @NotNull
    private Integer numberOfDependantsOver18;

    @Schema(required = true, minimum = "0", maximum = "99", example = "1")
    @Min(value = 0)
    @Max(value = 99)
    @NotNull
    private Integer numberOfDependantsUnder18;

    @Schema(required = true, example = "false", allowableValues = { "true", "false" })
    @NotNull
    private Boolean repayMortgageCurrencyNotSterling;

    @Schema(description = "ISO 4217 currency code , Required if repayMortgageCurrencyNotSterling = true", example = "USD", minLength = 3, maxLength = 3)
    @SmartValidation(
            conditions = @SmartCondition(path = "repayMortgageCurrency", negate = true, smartCheck = SmartChecks.ValidCurrencyCode.class),
            message = "has invalid currency value"
    )
    @SmartRequired(
            conditions = @SmartCondition(path = "repayMortgageCurrencyNotSterling", values = "true"),
            message = "required when repayMortgageCurrencyNotSterling is true"
    )
    @Size(min = 3, max = 3)
    private String repayMortgageCurrency;

    @Schema(example = "0.8", description = "currency exchange rate, Required if repayMortgageCurrencyNotSterling = true")
    @SmartValidation(conditions = {
            @SmartCondition(path = "repayMortgageCurrencyNotSterling", values = "true"),
            @SmartCondition(path = "currencyExchangeRate", values = { "<=", "0" }, smartCheck = SmartNumberCheck.class)
    }, message = "should be greater then 0 if repayMortgageCurrencyNotSterling = true")
    @SmartRequired(
            conditions = @SmartCondition(path = "repayMortgageCurrencyNotSterling", values = "true"),
            message = "is required if repayMortgageCurrencyNotSterling is true"
    )
    @Digits(integer = 3, fraction = 2)
    private BigDecimal currencyExchangeRate;

    @Schema(description = "Any rational notes for the Underwritter from broker", minLength = 5, maxLength = 1000, example = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum")
    @Size(min = 5, max = 1000, message = "should be between 5 and 1000")
    private String caseNotes;

}
