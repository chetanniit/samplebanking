package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;
import org.apache.commons.beanutils.ConvertUtils;

import java.util.List;

/**
 * Counts values matching predefined list of values and compares the count with a constant
 * Supported operators: {@code ==, =, !=, <>, <, <=, >, >=}<br>
 * Order of parameters: path_to_field_to_cunt, operator, constant_to_compare_count_with, value1, value2, value3, ...<br>
 * Usage example: {@code @SmartCondition(path = ".", values = {"someList[*]/fieldToMatch", ">=", "2", "value1",
 * "value2"}, smartCheck = SmartCountValuesCheck.class)}
 */
public class SmartCountValuesCheck extends AbstractSmartComparableCheck<Object> {

    @Override
    public boolean check(Object actualValue, List<String> conditionValues, SmartContext smartContext) {
        String path = conditionValues.get(0).trim();
        String operator = conditionValues.get(1).trim();
        String valueToCompareCount = conditionValues.get(2).trim();

        List<String> expectedValues = conditionValues.subList(3, conditionValues.size());
        List<Object> actualValues = smartContext.getValues(path);
        Long matchingValuesCount = actualValues.stream()
                .map(ConvertUtils::convert)
                .filter(expectedValues::contains)
                .count();

        return compare(matchingValuesCount, operator, valueToCompareCount);
    }

}
