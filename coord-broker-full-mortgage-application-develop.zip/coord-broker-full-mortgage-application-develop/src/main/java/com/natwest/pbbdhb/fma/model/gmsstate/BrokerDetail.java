package com.natwest.pbbdhb.fma.model.gmsstate;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrokerDetail {
    private String fcaReference;
    private String firmName;
    private String networkInfo;
    private Address address;

}
