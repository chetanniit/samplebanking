package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.RelationshipType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Dependant {

    @Schema(required = true, example = "John Smith")
    @NotBlank(message = "cannot be null or empty")
    private String name;

    @Schema(implementation = RelationshipType.class, required = true)
    @NotNull
    private RelationshipType relationship;

}
