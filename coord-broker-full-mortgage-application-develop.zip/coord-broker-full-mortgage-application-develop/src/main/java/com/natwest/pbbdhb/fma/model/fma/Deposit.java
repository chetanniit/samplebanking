package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.DepositType;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Deposit {

    @Schema(example = "20000", required = true, minimum = "1", maximum = "99999999", multipleOf = 1, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "1")
    @Digits(integer = 999, fraction = 0,  message = "must be integer")
    @NotNull
    private BigDecimal amount;

    @Schema(implementation = DepositType.class, required = true)
    @NotNull
    private DepositType type;

    @Schema(maxLength = 50, example = "Saving for a retirement", description = "Required if type is OTHER_SAVINGS")
    @SmartRequired(
            conditions = @SmartCondition(path = "type", values = "OTHER_SAVINGS"),
            message = "is required if type is OTHER_SAVINGS"
    )
    @Size(max = 50)
    private String details;
}
