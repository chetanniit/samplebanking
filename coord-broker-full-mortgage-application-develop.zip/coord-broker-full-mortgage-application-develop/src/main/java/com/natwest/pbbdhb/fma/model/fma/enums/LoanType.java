package com.natwest.pbbdhb.fma.model.fma.enums;

import com.google.common.base.Suppliers;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public enum LoanType {

    HIRE_PURCHASE(com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum.HIRE_PURCHASE, ExpenseCategory.LOANS_CAR), SECURED_LOAN(
            com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum.SECURED_LOAN,
            ExpenseCategory.LOANS_SECURED), UNSECURED_LOAN(com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum.UNSECURED_LOAN,
                    ExpenseCategory.LOANS_UNSECURED), STUDENT_LOAN(
                            com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum.STUDENT_LOAN,
                            ExpenseCategory.LOANS_STUDENT), PERSONAL_CONTRACT_PURCHASE(
                                    com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum.PERSONAL_CONTRACT_PURCHASE,
                                    ExpenseCategory.LOANS_PERSONAL_CONTRACT_PURCHASE);

    private com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum fmaType;
    private ExpenseCategory expenseCategory;

    private static Supplier<Map<com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum, ExpenseCategory>> mapping = Suppliers
            .memoize(() -> Arrays.stream(LoanType.values())
                    .collect(Collectors.toMap(k -> k.fmaType, v -> v.expenseCategory)));

    LoanType(com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum fmaType, ExpenseCategory expenseCategory) {
        this.fmaType = fmaType;
        this.expenseCategory = expenseCategory;
    }

    public static ExpenseCategory toExpenseCategory(com.natwest.pbbdhb.openapi.fma.Loan.TypeEnum fmaType) {
        return mapping.get().get(fmaType);
    }

}
