package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.fma.util.Constants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Broker {

    @Schema(example = "123456", required = true, minLength = 4, maxLength = 7, pattern = "^[0-9]{4,7}$", description = "Must contain numeric value, fcaNumber allows max 7 characters and min 4 characters")
    @Pattern(regexp = "^[0-9]{4,7}$", message = "is invalid or contains less than 4 characters or more than 7 characters")
    @Length(min = 4, max = 7, message = "should have min 4 max 7 characters")
    @NotBlank(message = "cannot be null or empty")
    private String fcaNumber;

    @Schema(example = "brokerUsername", required = true, minLength = 2, maxLength = 100)
    @Length(min = 2, max = 100, message = "should have min 2 max 100 characters")
    @NotBlank(message = "cannot be null or empty")
    private String brokerUsername;

    @Schema(example = "brokerSurname", required = true, minLength = 2, maxLength = 50, pattern = "^[a-zA-Z0-9\\-\\.' ]{2,50}$", description = "Broker surname, maximum 50 characters")
    @Length(min = 2, max = 50, message = "should have min 2 max 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9\\-\\.' ]{2,50}$")
    @NotBlank(message = "cannot be null or empty")
    private String brokerSurname;

    @Schema(example = "brokerForeName", minLength = 2, maxLength = 50, pattern = "^[a-zA-Z0-9\\-\\.' ]{2,50}$", description = "Broker Forename, maximum 50 characters")
    @Length(min = 2, max = 50, message = "should have min 2 max 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9\\-\\.' ]{2,50}$")
    private String brokerForeName;

    @Schema(example = "EC2R 8AH", maxLength = 8, description = "Broker postcode maximum 8 characters and must be valid UK postcode", pattern = Constants.UK_POSTCODE_PATTERN)
    @Pattern(regexp = Constants.UK_POSTCODE_PATTERN, message = "must be valid UK postcode")
    @Length(max = 8, message = "should have max 8 characters")
    private String brokerPostcode;

    @Schema(example = "broker.email@somemail.com", required = true, maxLength = 72, description = "Email address for Broker, maximum characters 72")
    @Pattern(regexp = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$", message = "Please enter valid email Id for Broker")
    @Length(max = 72, message = "should have max 72 characters")
    @NotBlank(message = "cannot be null or empty")
    private String brokerEmail;

    @Schema(example = "paymentPathName", required = true, maxLength = 256)
    @Length(max = 256, message = "should have max 256 characters")
    @NotBlank(message = "cannot be null or empty")
    private String paymentPathName;

    @Schema(example = "123456789", required = true, maxLength = 9)
    @Length(max = 9)
    @NotBlank(message = "cannot be null or empty")
    private String paymentPathId;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    @AssertTrue(message = "has to be true to proceed")
    private Boolean consentToFMA;

    @Schema(required = true)
    @NotNull
    @Valid
    private BrokerFee fee;

}
