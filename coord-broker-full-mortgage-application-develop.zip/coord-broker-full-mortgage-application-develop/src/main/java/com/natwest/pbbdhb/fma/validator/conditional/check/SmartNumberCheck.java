package com.natwest.pbbdhb.fma.validator.conditional.check;

import com.natwest.pbbdhb.fma.validator.conditional.SmartContext;

import java.util.List;

/**
 * Supported operators: {@code ==, =, !=, <>, <, <=, >, >=}<br>
 * Supported values: constant or path as "path:path_to_other_field"<br>
 * Usage example: {@code @SmartCondition(path = "numField", values = {">=", "100"}, smartCheck =
 * SmartNumberCheck.class)}<br>
 * Usage example: {@code @SmartCondition(path = "numField", values = {">=", "path:../some/field"}, smartCheck =
 * SmartNumberCheck.class)}
 */
public class SmartNumberCheck extends AbstractSmartComparableCheck<Object> {

    @Override
    public boolean check(Object actualValue, List<String> conditionValues, SmartContext smartContext) {
        String operator = conditionValues.get(0).trim();
        String toCompare = conditionValues.get(1).trim();
        Object valueToCompare = toCompare.startsWith("path:")
                ? smartContext.getValue(toCompare.substring(5).trim()) : toCompare;
        return compare(actualValue, operator, valueToCompare);
    }

}
