package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.WorkStatus;
import com.natwest.pbbdhb.fma.validator.SmartChecks;
import com.natwest.pbbdhb.fma.validator.conditional.SmartCondition;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class Applicant {
    @Schema(required = true, example = "true", allowableValues = { "true",
            "false" }, description = "Atmost one applicant required to have mainApplicant as true")
    @NotNull
    private Boolean mainApplicant;

    @Schema(required = true)
    @Valid
    @NotNull
    private PersonalDetails personalDetails;

    @ArraySchema(
            schema = @Schema(implementation = ApplicantAddress.class, required = true),
            arraySchema = @Schema(description = "Minimum 3 years addresses required"),
            minItems = 1, maxItems = 7, uniqueItems = true
    )
    @SmartValidation(
            conditions = @SmartCondition(path = ".", smartCheck = SmartChecks.NoUkAddressesAtNotGbResident.class),
            message = "at least one ukAddress should be true"
    )
    @SmartValidation(
            conditions = @SmartCondition(path = ".", negate = true, smartCheck = SmartChecks.HasExactlyOneCurrentAddress.class),
            message = "must have exactly 1 current address"
    )
    @SmartValidation(
            conditions = @SmartCondition(path = "<field>", negate = true, smartCheck = SmartChecks.ValidPeriodAtAddress.class),
            message = "period at address must be between 0 to 99 years"
    )
    @SmartValidation(
            conditions = @SmartCondition(path = "<field>", negate = true, smartCheck = SmartChecks.CoverLast3Years.class),
            message = "minimum 3 years addresses required"
    )
    @Size(min = 1, max = 7)
    @Valid
    @NotNull
    private List<ApplicantAddress> addresses;

    @Schema(implementation = WorkStatus.class, example = "WORKING", required = true)
    @NotNull
    private WorkStatus workStatus;

    @Schema(example = "70", minimum = "18", maximum = "99", description = "Required if workStatus is WORKING and should be at least current age")
    @SmartRequired(conditions = @SmartCondition(path = "workStatus", values = "WORKING"))
    @SmartValidation(conditions = {
            @SmartCondition(path = "intendedRetirementAge", nullOrEmpty = true, negate = true),
            @SmartCondition(path = ".", negate = true, smartCheck = SmartChecks.AtLeastCurrentAge.class)
    }, message = "should be at least current age")
    @Min(value = 18)
    @Max(value = 99)
    private Integer intendedRetirementAge;

    @ArraySchema(schema = @Schema(implementation = Employment.class),
            arraySchema = @Schema(description = "Covers current and previous/past employment details"),
            uniqueItems = true)
    @SmartValidation(
            conditions = @SmartCondition(path = "<field>", negate = true,
                    smartCheck = SmartChecks.OneCurrentPrimaryEmployment.class),
            message = "one current employment should be primary"
    )
    @Valid
    private List<Employment> employments;

    @ArraySchema(schema = @Schema(implementation = OtherIncome.class), uniqueItems = true)
    @Valid
    private List<OtherIncome> otherIncomes;

    @Schema(description = "Capture customer's Main Residence Mortgage ONLY. Required if current address has occupyStatus = OWNER_MORTGAGED")
    @SmartValidation(conditions = {
            @SmartCondition(path = "<field>", nullOrEmpty = true, negate = true),
            @SmartCondition(path = "addresses[?]", negate = true, smartCheck = SmartChecks.CurrentAddressOwnerMortgaged.class)
    }, message = "must be empty if current address has occupyStatus other than OWNER_MORTGAGED")
    @SmartRequired(
            conditions = @SmartCondition(path = "addresses[?]", smartCheck = SmartChecks.CurrentAddressOwnerMortgaged.class),
            message = "required if current address has occupyStatus = OWNER_MORTGAGED"
    )
    @Valid
    private ExistingMortgage existingMortgage;

    @ArraySchema(schema = @Schema(implementation = CreditCard.class), uniqueItems = true)
    @Valid
    private List<CreditCard> creditCards;

    @ArraySchema(schema = @Schema(implementation = Loan.class), uniqueItems = true)
    @Valid
    private List<Loan> loans;

    @ArraySchema(schema = @Schema(implementation = FinancialCommitment.class), uniqueItems = true)
    @Valid
    private List<FinancialCommitment> financialCommitments;

    @Schema(required = true)
    @Valid
    @NotNull
    private BankDetails mainBankDetails;

    @Schema(required = true)
    @Valid
    @NotNull
    private CreditHistory creditHistory;

    @Schema(description = "Required if application type is RESIDENTIAL")
    @SmartRequired(
            conditions = @SmartCondition(path = "../type", values = "RESIDENTIAL"),
            message = "required if application type is RESIDENTIAL"
    )
    @Valid
    private FutureAffordability futureAffordability;

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    private Boolean movingToPropertyAtCompletion;

    @Schema(hidden = true)
    @JsonIgnore
    private final String kycChannel = "TPI";

    @Schema(required = true, example = "true", allowableValues = { "true", "false" })
    @NotNull
    @AssertTrue(message = "has to be true to proceed")
    private Boolean consentToFMA;
    
    @Schema(example = "true", allowableValues = { "true", "false" })
    private Boolean newToBank;
    
    @SmartRequired(
            conditions = @SmartCondition(path = "newToBank", values = "true"),
            message = "is required when newToBank is true"
    )
	@SmartValidation(conditions = {
			@SmartCondition(path = "newToBank", values = "false"),
			@SmartCondition(path = "<field>", smartCheck = SmartChecks.AtLeastOneMarketingPreferencesTrue.class) }, message = "should not be true if newToBank is false")
    @Schema(description = "marketingPreferences is required when newToBank is true")
    @Valid
    private MarketingPreferences marketingPreferences;
}
