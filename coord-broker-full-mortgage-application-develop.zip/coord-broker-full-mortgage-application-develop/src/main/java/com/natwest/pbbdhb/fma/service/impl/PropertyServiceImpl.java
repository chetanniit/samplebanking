package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.fma.service.PropertyService;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class PropertyServiceImpl implements PropertyService {

    @Value("${property.create.endpoint}")
    private String endPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public PropertyDetailsDto createProperty(PropertyDetailsDto property, String brand) {
        log.info("createProperty: called");
        log.debug("createProperty: called with = {}", property);
        log.debug("createProperty  endpoint called = {}", endPointUrl);
        log.debug("createProperty: called with brand = {}", brand);

        return restTemplate.postForObject(endPointUrl,
                new HttpEntity<>(property, createHttpHeaders(brand)),
                PropertyDetailsDto.class);
    }

    private HttpHeaders createHttpHeaders(String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND_HEADER, brand);
        return headers;
    }

}
