package com.natwest.pbbdhb.fma.model.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class Packaging {

    private String app1AccountsReq;
    private String app1BankStmntsReq;
    private String app1PaySlipsReq;
    private String app1PerAndBusBankStmntsReq;
    private String app1TaxCalc;
    private String app2AccountsReq;
    private String app2BankStmntsReq;
    private String app2PaySlipsReq;
    private String app2PerAndBusBankStmntsReq;
    private String app2TaxCalc;
}
