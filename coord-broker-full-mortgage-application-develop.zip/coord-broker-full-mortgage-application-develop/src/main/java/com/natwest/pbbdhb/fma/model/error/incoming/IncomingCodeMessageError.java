package com.natwest.pbbdhb.fma.model.error.incoming;

import lombok.Getter;

@Getter
public class IncomingCodeMessageError {
    private String errorCode;
    private String errorMessage;
}
