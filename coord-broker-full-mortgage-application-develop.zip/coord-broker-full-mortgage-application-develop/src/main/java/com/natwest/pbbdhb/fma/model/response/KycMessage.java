package com.natwest.pbbdhb.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KycMessage {
    private String message;
    private String code;
    @JsonIgnore
    private Boolean applicant1IdRequired;
    @JsonIgnore
    private Boolean applicant2IdRequired;
}
