package com.natwest.pbbdhb.fma.mapper;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.http.HttpStatus;

import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.openapi.fma.ResponseData;

@Mapper(config = MappingConfig.class)
public interface FmaResponseMapper {

    @Mapping(target = "tempReferenceNumber", source = "tempRefNo")
    @Mapping(target = "mortgageNumber", source = "responseData" ,qualifiedByName = "mortgageNumber")
    FmaResponse toFmaResponse(ResponseData responseData , @Context String  responseStatus);
    
    
	@Named("mortgageNumber")
	static String getMortgageNumber(ResponseData responseData, @Context String responseStatus) {
		if (String.valueOf(HttpStatus.CREATED.value()).equalsIgnoreCase(responseStatus)
				&& StringUtils.isBlank(responseData.getTempRefNo())) {
			return responseData.getMortgageNumber();
		}
		return null;
	}

}
