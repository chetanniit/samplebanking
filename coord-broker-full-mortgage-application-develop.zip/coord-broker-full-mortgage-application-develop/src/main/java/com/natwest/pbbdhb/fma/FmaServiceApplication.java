package com.natwest.pbbdhb.fma;

import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication(exclude = {
        MongoAutoConfiguration.class,
        MongoDataAutoConfiguration.class
})
public class FmaServiceApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder().environment(new StandardEncryptableEnvironment())
                .sources(FmaServiceApplication.class).run(args);
     
    }
}
