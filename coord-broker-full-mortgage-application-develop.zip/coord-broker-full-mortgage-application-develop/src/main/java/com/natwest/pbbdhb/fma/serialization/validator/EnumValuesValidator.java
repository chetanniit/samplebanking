package com.natwest.pbbdhb.fma.serialization.validator;

import com.fasterxml.jackson.core.JsonParser;
import com.natwest.pbbdhb.fma.serialization.DeserializationValidationException;
import com.natwest.pbbdhb.fma.serialization.DeserializationValidator;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class EnumValuesValidator implements DeserializationValidator {

    @Override
    public Set<Class<?>> applicableForTypes() {
        return Collections.singleton(Enum.class);
    }

    @Override
    public DeserializationValidationException beforeSerialization(Class<?> targetType, JsonParser jsonParser) throws IOException {
        Enum[] enumConstants = ((Class<Enum>) targetType).getEnumConstants();
        String stringValue = jsonParser.getValueAsString();
        if (stringValue != null) {
            if (!stringValue.trim().equals(stringValue)
                    || Arrays.stream(enumConstants).noneMatch(e -> e.toString().equals(stringValue))){
                String message = MessageFormat.format(
                        "permissible values are [{0}]",
                        Arrays.stream(enumConstants).map(Enum::toString).collect(Collectors.joining(", "))
                );
                return new DeserializationValidationException(message, jsonParser);
            }
        }
        return null;
    }
}
