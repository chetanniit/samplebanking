package com.natwest.pbbdhb.fma.model.fma.enums;

public enum ADBORepaymentType {
    REPAYMENT, INTEREST_ONLY
}
