package com.natwest.pbbdhb.fma.model.fma;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.fma.model.fma.enums.FinancialCommitmentType;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class FinancialCommitment {

    @Schema(implementation = FinancialCommitmentType.class, required = true)
    @NotNull
    private FinancialCommitmentType type;

    @Schema(example = "2000", maximum = "99999999", minimum = "0", multipleOf = 1, required = true, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    @NotNull
    private BigDecimal monthlyPayments;

    @Schema(example = "1000", maximum = "99999999", minimum = "0", multipleOf = 1, required = true, description = "No decimal places")
    @DecimalMax(value = "99999999")
    @DecimalMin(value = "0")
    @Digits(integer = 999, fraction = 0, message = "must be integer")
    @NotNull
    private BigDecimal paymentsContinuing;

    @Schema(allowableValues = {"true", "false"}, example = "false")
    private Boolean familyLiveInProperty;
}