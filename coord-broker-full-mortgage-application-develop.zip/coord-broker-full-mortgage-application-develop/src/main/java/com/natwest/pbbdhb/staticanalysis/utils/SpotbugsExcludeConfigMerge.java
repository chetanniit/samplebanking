package com.natwest.pbbdhb.staticanalysis.utils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;

public class SpotbugsExcludeConfigMerge extends AbstractXmlConfigMerge {

    public static void main(String[] args) throws ParserConfigurationException, IOException, TransformerException, SAXException {
        merge(args[0], args[1], args[2]);
    }

    private static void merge(String spotbugsConfig, String mutatorConfig, String resultConfig) throws ParserConfigurationException, IOException, SAXException, TransformerException {
        if (!new File(spotbugsConfig).exists()) {
            return;
        }
        Document sourceXml = readXml(spotbugsConfig);
        Document mutatorXml = readXml(mutatorConfig);
        Element sourceRoot = sourceXml.getDocumentElement();
        Element mutatorRoot = mutatorXml.getDocumentElement();
        Document resultDocument = createXml();
        Node resultRoot = resultDocument.importNode(sourceRoot, true);
        stream(mutatorRoot.getChildNodes())
                .forEach(node -> resultRoot.appendChild(resultDocument.importNode(node, true)));
        resultDocument.appendChild(resultRoot);
        saveXml(resultDocument, resultConfig, sourceXml);
    }

}
