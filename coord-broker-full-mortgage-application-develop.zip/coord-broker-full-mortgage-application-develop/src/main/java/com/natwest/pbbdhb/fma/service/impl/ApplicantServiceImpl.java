package com.natwest.pbbdhb.fma.service.impl;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.fma.service.ApplicantService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class ApplicantServiceImpl implements ApplicantService {

    @Value("${applicant.create.endpoint}")
    private String endPointUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public ApplicantDto createApplicant(ApplicantDto applicant, String brand) {

        log.info("createApplicant: called");
        log.debug("createApplicant: called with = {}", applicant);
        log.debug("createApplicant  endpoint called = {}", endPointUrl);
        log.debug("createApplicant  with brand called = {}", brand);
        HttpHeaders applicationHeaders = createHttpHeaders(brand);

        return restTemplate.postForObject(endPointUrl, new HttpEntity<>(applicant, applicationHeaders),
                ApplicantDto.class);
    }

    private HttpHeaders createHttpHeaders(String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND_HEADER, brand);
        return headers;
    }

}
