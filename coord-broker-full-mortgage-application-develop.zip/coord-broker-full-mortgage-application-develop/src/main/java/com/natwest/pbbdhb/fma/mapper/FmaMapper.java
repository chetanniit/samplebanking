package com.natwest.pbbdhb.fma.mapper;

import com.natwest.pbbdhb.fma.model.brokervalidation.FirmBroker;
import com.natwest.pbbdhb.fma.model.fma.AdditionalBorrowing;
import com.natwest.pbbdhb.fma.model.fma.Applicant;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.BrokerFee;
import com.natwest.pbbdhb.fma.model.fma.Mortgage;
import com.natwest.pbbdhb.fma.model.fma.ProductDetails;
import com.natwest.pbbdhb.fma.model.fma.enums.ApplicationType;
import com.natwest.pbbdhb.fma.model.fma.enums.LevelOfService;
import com.natwest.pbbdhb.fma.util.Constants;
import com.natwest.pbbdhb.openapi.fma.Broker;
import com.natwest.pbbdhb.openapi.fma.BrokerFee.PayableAtEnum;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import com.natwest.pbbdhb.openapi.fma.PropertyDetails;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Mapper(config = MappingConfig.class, uses = { FmaApplicantMapper.class, FmaDepositsMapper.class }, builder = @Builder(disableBuilder = true))
public interface FmaMapper {

    default FullMortgageApplicationRequest toFMARequest(Application application,
                                                        FirmBroker broker) {
        FullMortgageApplicationRequest fullMortgageApplicationRequest = new FullMortgageApplicationRequest();
        fullMortgageApplicationRequest.setApplication(
                toFmaApplication(application, broker, application.getBroker().getFee()));
        fullMortgageApplicationRequest.setApplicants(toFmaApplicants(application.getApplicants()));
        return fullMortgageApplicationRequest;
    }

    List<com.natwest.pbbdhb.openapi.fma.Applicant> toFmaApplicants(List<Applicant> applicants);

    @Mapping(target = "applicationType", source = "application.type")
    @Mapping(target = "property.propertyTenure", source = "application.property.tenure")
    @Mapping(target = "property.wallType", constant = "BRICKS_AND_MORTAR")
    @Mapping(target = "property.usage", source = "application.type", qualifiedByName = "toPropertyUsage")
    @Mapping(target = "property.propertyClass", constant = "RESIDENTIAL")
    @Mapping(target = "directDebit.sortcode", source = "application.directDebit.sortCode")
    @Mapping(target = "broker", source = "broker", qualifiedByName = "toFmaBrokerAssisted")
    @Mapping(target = "mortgage", source = "application", qualifiedByName = "toFmaMortgageAssisted")
    @Mapping(target = "serviceLevel.levelOfService", source = "application.levelOfService")
    @Mapping(target = "serviceLevel.interview", source = "application.interview")
    com.natwest.pbbdhb.openapi.fma.Application toFmaApplication(Application application,
                                                                FirmBroker broker,
                                                                @Context BrokerFee brokerFee);

    @Mapping(target = "firmAddressLine1", source = "broker.firmAddress1")
    @Mapping(target = "firmAddressLine2", source = "broker.firmAddress2")
    @Mapping(target = "firmAddressLine3", source = "broker.firmAddress3")
    @Mapping(target = "firmAddressLine4", source = "broker.firmAddress4")
    @Mapping(target = "firmAddressLine5", source = "broker.firmAddress5")
    @Mapping(target = "brokerTitle", source = "broker.title")
    @Mapping(target = "brokerForename", source = "broker.brokerForeName")
    @Mapping(target = "brokerUsername", source = "broker.userName")
    @Mapping(target = "brokerTelephoneNumber", source = "broker.brokerTelephoneNumber", qualifiedByName = "toFmaBrokerTelephoneNumber")
    @Mapping(target = "fee", source = "brokerFee")
    com.natwest.pbbdhb.openapi.fma.Broker toFmaBroker(FirmBroker broker, BrokerFee brokerFee);

    @Mapping(target = "payableAt", source = "brokerFee", qualifiedByName = "toPayableAtAssisted")
    com.natwest.pbbdhb.openapi.fma.BrokerFee toBrokerFee(BrokerFee brokerFee);


    com.natwest.pbbdhb.openapi.fma.Mortgage toFmaMortgage(Mortgage mortgage);

    @Mapping(target = "calculationType", source = "adboRepaymentType")
    com.natwest.pbbdhb.openapi.fma.AdditionalBorrowing toFmaAdditionalBorrowing(AdditionalBorrowing additionalBorrowing);

    @Mapping(target = "chapsFees", source = "chapsFeesPayType")
    @Mapping(target = "productFees", source = "productFeesPayType")
    @Mapping(target = "valuationFees", source = "valuationFeesPayType")
    @Mapping(target = "productSelectionDate", source = "isPortingProduct", qualifiedByName = "toProductSelectionDate")
    com.natwest.pbbdhb.openapi.fma.ProductDetails toFmaProduct(ProductDetails product);

    @Named("toPropertyUsage")
    default PropertyDetails.UsageEnum toPropertyUsage(ApplicationType applicationType) {
        return ApplicationType.BUY_TO_LET.equals(applicationType)
                ? PropertyDetails.UsageEnum.FULLY_LET
                : PropertyDetails.UsageEnum.OWNER_OCCUPIED;
    }

    @Named("toFmaMortgageAssisted")
    default com.natwest.pbbdhb.openapi.fma.Mortgage toFmaMortgageAssisted(Application application) {
        com.natwest.pbbdhb.openapi.fma.Mortgage fmaMortgage = toFmaMortgage(application.getMortgage());
        fmaMortgage.setMortgageAdvised(
                application.getLevelOfService() == null
                        ? null
                        : LevelOfService.ADVISED.equals(application.getLevelOfService())
                        ? com.natwest.pbbdhb.openapi.fma.Mortgage.MortgageAdvisedEnum.ADVICE
                        : com.natwest.pbbdhb.openapi.fma.Mortgage.MortgageAdvisedEnum.REJECTED_ADVICE_EXECUTION_ONLY
        );
        return fmaMortgage;
    }

    @Named("toFmaBrokerTelephoneNumber")
    default String toFmaBrokerTelephoneNumber(String brokerTelephoneNumber) {
        return brokerTelephoneNumber == null ? null : brokerTelephoneNumber.replaceAll("\\D", "");
    }

    @Named("toFmaBrokerAssisted")
    default com.natwest.pbbdhb.openapi.fma.Broker toFmaBrokerAssisted(FirmBroker broker, @Context BrokerFee brokerFee) {
        Broker fmaBroker = toFmaBroker(broker, brokerFee);
		if (fmaBroker != null && broker != null && StringUtils.isEmpty(fmaBroker.getBrokerTelephoneNumber())
				&& StringUtils.isNotEmpty(broker.getBrokerMobileNumber())) {
			fmaBroker.setBrokerTelephoneNumber(broker.getBrokerMobileNumber().replaceAll("\\s", ""));
		}
        return fmaBroker;
    }

    @Named("toProductSelectionDate")
    default String toProductSelectionDate(Boolean isPortingProduct) {
        return Boolean.TRUE.equals(isPortingProduct) ? null : LocalDate.now().format(Constants.DATE_FORMATTER);
    }

    @Named("toPayableAtAssisted")
    default com.natwest.pbbdhb.openapi.fma.BrokerFee.PayableAtEnum toPayableAtAssisted(BrokerFee brokerFee) {
        return brokerFee.getAmount() != null && BigDecimal.ZERO.compareTo(brokerFee.getAmount()) < 0
                ? PayableAtEnum.COMPLETION : null;
    }

}
