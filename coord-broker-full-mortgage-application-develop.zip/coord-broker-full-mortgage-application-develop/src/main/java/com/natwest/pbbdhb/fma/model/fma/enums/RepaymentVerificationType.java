package com.natwest.pbbdhb.fma.model.fma.enums;

public enum RepaymentVerificationType {
    LETTER, POLICY_DOCUMENT, PHOTO_EVIDENCE, SURVEYOR_REPORT
}
