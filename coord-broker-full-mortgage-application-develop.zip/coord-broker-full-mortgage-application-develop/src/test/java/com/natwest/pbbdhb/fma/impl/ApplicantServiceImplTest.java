package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.fma.service.ApplicantService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class ApplicantServiceImplTest {
    @Autowired
    private ApplicantService applicantService;

    @Value("${applicant.create.endpoint}")
    private String endPointUrl;

    @MockBean
    @Qualifier("restTemplateForApiCalls")
    private RestTemplate restTemplate;

    @Test
    void testMakeApplicantCreateCallWithValidRequest() {
        ApplicantDto req = ApplicantDto.builder().build();
        ApplicantDto resp = ApplicantDto.builder().build();
        when(restTemplate.postForObject(eq(endPointUrl), Mockito.any(HttpEntity.class), eq(ApplicantDto.class)))
                .thenReturn(resp);
        applicantService.createApplicant(req, "nwb");

        verify(restTemplate).postForObject(anyString(), Mockito.any(HttpEntity.class), eq(ApplicantDto.class));
    }
}
