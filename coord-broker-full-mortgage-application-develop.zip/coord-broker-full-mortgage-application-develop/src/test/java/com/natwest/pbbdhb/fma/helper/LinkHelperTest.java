package com.natwest.pbbdhb.fma.helper;

import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.openapi.fma.Fee;
import com.natwest.pbbdhb.openapi.fma.Fee.ActionEnum;
import com.natwest.pbbdhb.openapi.fma.Fee.PaymentTypeEnum;
import com.natwest.pbbdhb.openapi.fma.ProductDetails;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { LinkHelper.class })
public class LinkHelperTest {
    @Autowired
    private LinkHelper linkHelper;

    @Test
    public void testAddLinks() {
    	Set<ProductDetails> products=new HashSet<ProductDetails>();
        FmaResponse response = FmaResponse.builder().mortgageNumber("1234").status("201").products(products).build();
        linkHelper.addLinks(response);
        assertNotNull(response.getLinks());
        assertEquals("https://dev-api.natwest.com/mortgages/v1/documents/1234/get-upload-page",
                response.getLinks().get("documentsUploadUrl").getHref());
        assertNull( response.getLinks().get("paymentUrl"));

    }
    
	public void testAddLinks_Payment() {
		Set<ProductDetails> products = new HashSet<>();
		Fee fee = Fee.builder().action(ActionEnum.NO_ACTION).amount(BigDecimal.TEN)
				.paymentType(PaymentTypeEnum.CARD_PAYMENT).type("ADMIN_FEE_FOR_VALUATION").build();
		Set<Fee> fees = new HashSet<Fee>();
		fees.add(fee);
		ProductDetails product = ProductDetails.builder().fees(fees).build();
		products.add(product);
		FmaResponse response = FmaResponse.builder().mortgageNumber("1234").status("201").products(products).build();
		linkHelper.addLinks(response);
		assertNotNull(response.getLinks());
		assertEquals("https://dev-api.natwest.com/mortgages/v1/documents/1234/get-upload-page",
				response.getLinks().get("documentsUploadUrl").getHref());
		assertEquals("https://dev-api.natwest.com/mortgages/v1/payments/1234/get-payment-page",
				response.getLinks().get("paymentUrl").getHref());
	}

}
