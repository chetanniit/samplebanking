package com.natwest.pbbdhb.fma.mapper.income;

import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
public class IncomeMapperTest extends AbstractMapperTest {

    private OtherIncomeMapperImpl otherIncomeMapper;
    private JobDetailsMapperImpl jobDetailsMapper;
    private IncomeMapper incomeMapper;

    @BeforeEach
    public void setup() {
        otherIncomeMapper = new OtherIncomeMapperImpl();

        jobDetailsMapper = new JobDetailsMapperImpl();
        jobDetailsMapper.setAdditionalJobIncomeMapper(new AdditionalJobIncomeMapperImpl());

        incomeMapper = new IncomeMapper(jobDetailsMapper, otherIncomeMapper);
    }

    @Test
    public void testFmaRequestToValidatedCaseIncome() {
        FullMortgageApplicationRequest fmaRequest = loadInputModel("input/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);

        ValidatedCaseIncomeDto validatedCaseIncome = incomeMapper.convertToIncomeRequest(fmaRequest,
                getApplicantToIdMap(fmaRequest));

        assertOutputModelMatches("output/ValidatedCaseIncome.json", validatedCaseIncome);
    }

    @Test
    public void testFmaRequestToValidatedCaseIncomeApplicantNotWorking() {
        FullMortgageApplicationRequest fmaRequest = loadInputModel(
                "input/FullMortgageApplicationRequest.json",
                "{ \"applicants\" : [{ \"workStatus\" : \"NOT_WORKING\" , \"employments\" : [{\"employmentStatus\" : \"NOT_EMPLOYED\"}]}]}",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);

        ValidatedCaseIncomeDto validatedCaseIncome = incomeMapper.convertToIncomeRequest(fmaRequest,
                getApplicantToIdMap(fmaRequest));

        assertOutputModelMatches("output/ValidatedCaseIncomeNotWorkingApp.json", validatedCaseIncome);
    }

    private Map<Applicant, String> getApplicantToIdMap(FullMortgageApplicationRequest applicationRequest) {
        AtomicInteger id = new AtomicInteger(0);
        return applicationRequest.getApplicants().stream().collect(
                Collectors.toMap(a -> a, a -> String.valueOf(id.getAndIncrement()), (a, b) -> a, IdentityHashMap::new));
    }

}
