package com.natwest.pbbdhb.fma.serialization.validator;

import com.fasterxml.jackson.core.JsonParser;
import com.natwest.pbbdhb.fma.model.fma.enums.Title;
import com.natwest.pbbdhb.fma.serialization.DeserializationValidator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertAll;

@SpringBootTest(classes = {BooleanValidator.class, EnumValuesValidator.class, IntegerValidator.class, NumberValidator.class})
@ExtendWith(MockitoExtension.class)
public class DeserializationValidatorTest {

    @Mock
    private JsonParser jsonParser;

    @Autowired
    private BooleanValidator booleanValidator;

    @Autowired
    private EnumValuesValidator enumValuesValidator;

    @Autowired
    private IntegerValidator integerValidator;

    @Autowired
    private NumberValidator numberValidator;

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "true  | null",
            "true  | true",
            "true  | false",
            "false | 0",
            "false | 1",
            "false | abcd",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testBooleanValidator(Boolean valid, String fieldValue) throws IOException {
        String value = "null".equals(fieldValue) ? null : fieldValue;
        Mockito.when(jsonParser.getValueAsString()).thenReturn(value);
        if (valid) {
            assertForAllTypes(booleanValidator, jsonParser, Assertions::assertNull);
        } else {
            assertForAllTypes(booleanValidator, jsonParser, Assertions::assertNotNull);
        }
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "true  | null",
            "true  | REVEREND",
            "false | Reverend",
            "false | 0",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testEnumValuesValidator(Boolean valid, String fieldValue) throws IOException {
        String value = "null".equals(fieldValue) ? null : fieldValue;
        Mockito.when(jsonParser.getValueAsString()).thenReturn(value);
        if (valid) {
            Assertions.assertNull(enumValuesValidator.beforeSerialization(Title.class, jsonParser));
        } else {
            Assertions.assertNotNull(enumValuesValidator.beforeSerialization(Title.class, jsonParser));
        }
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "true  | null",
            "true  | 10",
            "true  | +100",
            "true  | -981",
            "true  | -0",
            "false | 0.1",
            "false | abc",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testIntegerValidator(Boolean valid, String fieldValue) throws IOException {
        String value = "null".equals(fieldValue) ? null : fieldValue;
        Mockito.when(jsonParser.getValueAsString()).thenReturn(value);
        if (valid) {
            assertForAllTypes(integerValidator, jsonParser, Assertions::assertNull);
        } else {
            assertForAllTypes(integerValidator, jsonParser, Assertions::assertNotNull);
        }
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "true  | null",
            "true  | 10",
            "true  | +100",
            "true  | -981",
            "true  | -0",
            "true  | 0.1",
            "true  | -123.5",
            "false | abc",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testNumberValidator(Boolean valid, String fieldValue) throws IOException {
        String value = "null".equals(fieldValue) ? null : fieldValue;
        Mockito.when(jsonParser.getValueAsString()).thenReturn(value);
        if (valid) {
            assertForAllTypes(numberValidator, jsonParser, Assertions::assertNull);
        } else {
            assertForAllTypes(numberValidator, jsonParser, Assertions::assertNotNull);
        }
    }

    private void assertForAllTypes(DeserializationValidator validator, JsonParser jsonParser, Consumer<Object> assertion) {
        assertAll(
                validator.applicableForTypes().stream()
                .map(clazz -> (Executable) () -> assertion.accept(validator.beforeSerialization(clazz, jsonParser)))
                .toArray(Executable[]::new)
        );
    }

}
