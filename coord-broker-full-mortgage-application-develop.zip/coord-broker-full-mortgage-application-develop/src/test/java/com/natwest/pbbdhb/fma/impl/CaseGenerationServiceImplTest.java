package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.fma.model.fma.Applicant;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.PersonalDetails;
import com.natwest.pbbdhb.fma.service.CaseGenerationService;
import com.natwest.pbbdhb.fma.service.impl.CaseGenerationServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { CaseGenerationServiceImpl.class })
public class CaseGenerationServiceImplTest {

    @Autowired
    private CaseGenerationService caseGenerationService;

    @Value("${caseid.generate.endpoint}")
    private String endPointUrl;

    @MockBean
    @Qualifier("restTemplateForApi")
    private RestTemplate restTemplate;

    @Test
    void testGenerateCaseIdRequest() {
        Application application = new Application();
        List<Applicant> list = new ArrayList<>();
        Applicant applicant = new Applicant();
        PersonalDetails personalDetails = new PersonalDetails();
        personalDetails.setFirstNames("Gaurav");
        personalDetails.setLastName("Mitra");
        applicant.setPersonalDetails(personalDetails);
        list.add(applicant);
        application.setApplicants(list);
        when(restTemplate.exchange(eq(endPointUrl + "?caseIdPrefix=BRKMitraGau&clientId=375gAhv1Rw9IxUSCABkDJ5rbs"),
                eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                        .thenReturn(new ResponseEntity<>("dummyCaseId", HttpStatus.OK));

        String casedId = caseGenerationService.generateCaseId("nwb", application, "375gAhv1Rw9IxUSCABkDJ5rbs");
        assertEquals("dummyCaseId", casedId);
    }
}
