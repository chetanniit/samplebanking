package com.natwest.pbbdhb.fma.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Charsets;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.enums.ApplicationType;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class JsonUtils {

    /**
     * Merges valid request with provided mutatorJson in the following way:<br>
     * - if field or array element of mutatorJson has null value then the field / array element is removed<br>
     * - if field is omitted in mutatorJson then the field is preserved<br>
     * - if array element is equal to empty object {} in mutatorJson then original value is preserved<br>
     * Example:
     * 
     * <pre>
     *   validRequest: {"a":"x", "b":"y",  "c":"z", "d":["1", "2", "3", "4"]}
     *   mutatorJson:  {"a":"F", "b":null,          "d":[ {}, "9", null]    }
     *   result:       {"a":"F",           "c":"z", "d":["1", "9",      "4"]}
     * </pre>
     *
     * @param mutatorJson
     *            - json to mutate valid request json
     * @return mutated valid request json
     */
    public static String getMutatedRequestJson(ApplicationType applicationType, String mutatorJson) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode validRootNode = objectMapper.readTree(getValidRequestJson(applicationType));
            JsonNode mutatorRootNode = objectMapper.readTree(mutatorJson);
            mutate((ObjectNode) validRootNode, (ObjectNode) mutatorRootNode);
            return objectMapper.writeValueAsString(validRootNode);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public static Application getMutatedRequest(ApplicationType applicationType, String mutatorJson) {
        try {
            return new ObjectMapper().readValue(getMutatedRequestJson(applicationType, mutatorJson), Application.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String getValidRequestJson(ApplicationType applicationType) {
        return ApplicationType.RESIDENTIAL.equals(applicationType)
                ? getJson("brokerFmaValidResidentialRequest.json")
                : getJson("brokerFmaValidBuyToLetRequest.json");
    }

    public static Application getValidRequest(ApplicationType applicationType) {
        try {
            return new ObjectMapper().readValue(getValidRequestJson(applicationType), Application.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String getJson(String jsonFileName) {
        return getJson(jsonFileName, null);
    }

    public static String getJson(String jsonFileName, String mutatorJson) {
        try {
            String json = IOUtils.toString(Paths.get("src", "test", "resources", "__files", jsonFileName).toUri(),
                    Charsets.UTF_8);
            if (mutatorJson == null || !Pattern.compile("\\w").matcher(mutatorJson).find()) {
                return json;
            }
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(json);
            JsonNode mutatorRootNode = objectMapper.readTree(mutatorJson);
            mutate((ObjectNode) rootNode, (ObjectNode) mutatorRootNode);
            return objectMapper.writeValueAsString(rootNode);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static void mutate(ObjectNode target, ObjectNode source) {
        Iterator<Map.Entry<String, JsonNode>> sourceIterator = source.fields();
        while (sourceIterator.hasNext()) {
            Map.Entry<String, JsonNode> sourceField = sourceIterator.next();
            String sourceKey = sourceField.getKey();
            JsonNode sourceValue = sourceField.getValue();
            JsonNode targetValue = target.get(sourceKey);
            if (sourceField.getValue().isNull()) {
                target.remove(sourceKey);
            } else if ((!sourceValue.isObject() && !sourceValue.isArray()) || targetValue == null) {
                target.set(sourceKey, sourceValue);
            } else if (sourceValue.isObject() && targetValue.isObject()) {
                mutate((ObjectNode) targetValue, (ObjectNode) sourceValue);
            } else if (sourceValue.isArray() && targetValue.isArray()) {
                mutate((ArrayNode) targetValue, (ArrayNode) sourceValue);
            }
        }
    }

    private static void mutate(ArrayNode target, ArrayNode source) {
        Iterator<JsonNode> sourceIterator = source.elements();
        Iterator<JsonNode> targetIterator = target.elements();
        List<JsonNode> result = new ArrayList<>();
        while (sourceIterator.hasNext() && targetIterator.hasNext()) {
            JsonNode sourceNode = sourceIterator.next();
            JsonNode targetNode = targetIterator.next();
            if (sourceNode.isNull()) {
            } else if (sourceNode.isObject() && sourceNode.isEmpty()) {
                result.add(targetNode);
            } else if ((!sourceNode.isObject() && !sourceNode.isArray()) || targetNode == null) {
                result.add(sourceNode);
            } else if (sourceNode.isObject() && targetNode.isObject()) {
                mutate((ObjectNode) targetNode, (ObjectNode) sourceNode);
                result.add(targetNode);
            } else if (sourceNode.isArray() && targetNode.isArray()) {
                mutate((ArrayNode) targetNode, (ArrayNode) sourceNode);
                result.add(targetNode);
            } else {
                result.add(targetNode);
            }
        }
        while (sourceIterator.hasNext()) {
            JsonNode sourceNode = sourceIterator.next();
            if (!sourceNode.isNull()) {
                result.add(sourceNode);
            }
        }
        while (targetIterator.hasNext()) {
            result.add(targetIterator.next());
        }
        target.removeAll().addAll(result);
    }

}
