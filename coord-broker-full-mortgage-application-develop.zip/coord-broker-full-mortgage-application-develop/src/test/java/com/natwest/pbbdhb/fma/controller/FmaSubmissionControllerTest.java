package com.natwest.pbbdhb.fma.controller;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.enums.ApplicationType;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.service.FmaSubmissionService;
import com.natwest.pbbdhb.fma.util.JsonUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.MockitoAnnotations;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = FmaSubmissionController.class)
@Import(ObjectMapperTestConfiguration.class)
public class FmaSubmissionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private FmaSubmissionService fmaSubmissionService;

    @MockBean
    private ExecutionContext executionContext;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testTheBankOfApiRequestIntegrity() throws Exception {

        // !!!############# ATTENTION #############!!!
        // The test request and response JSONs are used in the Bank of API portal documentation
        // If the test is failing please fix the JSON in a laconic way that will also suit the BoA requirements
        // Do not place any sensitive information in the JSON and avoid meaningless field values like
        // "string", "test", ...

        String theBoaRequestJson = JsonUtils.getJson("bankOfApiSampleRequest.json");
        String theBoaResponseJson = JsonUtils.getJson("bankOfApiSampleResponse.json");

        // request integrity testing
        when(fmaSubmissionService.performFmaSubmission(any(Application.class), anyString(), anyString()))
                .thenReturn(new FmaResponse());
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(theBoaRequestJson))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE));

        // response integrity testing
        Assertions.assertDoesNotThrow(() -> objectMapper.readValue(theBoaResponseJson, FmaResponse.class));
    }

    @Test
    void testValidRequestIntegrity() throws Exception {
        String residentialRequest = JsonUtils.getValidRequestJson(ApplicationType.RESIDENTIAL);
        String buyToLetRequest = JsonUtils.getValidRequestJson(ApplicationType.BUY_TO_LET);
        Assertions.assertAll(
                () -> Assertions.assertDoesNotThrow(() -> objectMapper.readValue(residentialRequest, Application.class)),
                () -> Assertions.assertDoesNotThrow(() -> objectMapper.readValue(buyToLetRequest, Application.class))
        );
    }

    @Test
    void validateResponseFromFmaSubmission() throws Exception {
        String request = JsonUtils.getValidRequestJson(ApplicationType.RESIDENTIAL);
        FmaResponse fmaResponse = FmaResponse.builder().caseId("caseId").mortgageNumber("mortgageN")
                .tempReferenceNumber("tempRefNo").build();
        when(fmaSubmissionService.performFmaSubmission(any(Application.class), any(String.class), any(String.class)))
                .thenReturn(fmaResponse);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs").header("client_id", "client_id").content(request))
                .andDo(print()).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(containsString(
                        "{\"caseId\":\"caseId\",\"mortgageNumber\":\"mortgageN\",\"tempReferenceNumber\":\"tempRefNo\"}")));
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | { \"applicants\" : [{ \"addresses\" : [{ \"postcode\" : \"EH114FF\" }]}]}",
            "RESIDENTIAL | { \"applicants\" : [{ \"employments\" : [{ \"address\" : { \"postcode\" : \"NG15FS\" }}]}]}",
            "RESIDENTIAL | { \"broker\" : { \"brokerPostcode\" : \"B236SN\" }}",
            "RESIDENTIAL | { \"solicitor\" : { \"postcode\" : \"GU167HP\" }}",
            "RESIDENTIAL | { \"estateAgent\" : { \"address\" : { \"postcode\" : \"E112NB\" }}}",
            "RESIDENTIAL | { \"property\" : { \"address\" : { \"postcode\" : \"NG15FS\" }}}",
            "BUY_TO_LET  | { \"mortgage\" : { \"otherProperties\" : [{ \"address\" : { \"postcode\" : \"E112NB\" }}]}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void validatePostcodeFix(ApplicationType applicationType, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);

        FmaResponse fmaResponse = FmaResponse.builder().caseId("caseId").mortgageNumber("mortgageN")
                .tempReferenceNumber("tempRefNo").build();
        when(fmaSubmissionService.performFmaSubmission(any(Application.class), any(String.class), any(String.class)))
                .thenReturn(fmaResponse);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs").header("client_id", "client_id").content(request))
                .andDo(print()).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(containsString(
                        "{\"caseId\":\"caseId\",\"mortgageNumber\":\"mortgageN\",\"tempReferenceNumber\":\"tempRefNo\"}")));
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | {\"northernIrelandApplication\" : true , \"property\" : { \"address\" : { \"postcode\" : \"BT20 5YG\" }}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void validatePostcodes(ApplicationType applicationType, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);

        FmaResponse fmaResponse = FmaResponse.builder().caseId("caseId").mortgageNumber("mortgageN")
                .tempReferenceNumber("tempRefNo").build();
        when(fmaSubmissionService.performFmaSubmission(any(Application.class), any(String.class), any(String.class)))
                .thenReturn(fmaResponse);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "rbs").header("client_id", "client_id").content(request))
                .andDo(print()).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(containsString(
                        "{\"caseId\":\"caseId\",\"mortgageNumber\":\"mortgageN\",\"tempReferenceNumber\":\"tempRefNo\"}")));
    }

    @DisplayName("Test Null Fields Stability")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL",
            "BUY_TO_LET"
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testNullFieldsStability(ApplicationType applicationType) throws Exception {

        when(fmaSubmissionService.performFmaSubmission(any(Application.class), anyString(), anyString()))
                .thenReturn(new FmaResponse());
        String request = JsonUtils.getValidRequestJson(applicationType);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonTree = objectMapper.readTree(request);
        List<Executable> assertions = new ArrayList<>();
        nullFieldsStabilityInJson(objectMapper, jsonTree, jsonTree, assertions);

        Logger logger = (Logger) LoggerFactory.getLogger("com.natwest.pbbdhb");
        Level initialLogLevel = logger.getLevel();
        logger.setLevel(Level.OFF);
        try {
            Assertions.assertAll(assertions.toArray(new Executable[0]));
        } finally {
            logger.setLevel(initialLogLevel);
        }

    }

    private void nullFieldsStabilityInJson(ObjectMapper objectMapper, JsonNode jsonTree, JsonNode currentNode, List<Executable> assertions) throws JsonProcessingException {
        if (currentNode.isArray()) {
            ArrayNode arrayNode = (ArrayNode) currentNode;
            int size = arrayNode.size();
            for (int i = 0; i < size; i++) {
                JsonNode child = arrayNode.set(i, (JsonNode) null);
                String json = objectMapper.writeValueAsString(jsonTree);
                assertions.add(getExecutableForJson(json));
                arrayNode.set(i, child);
                nullFieldsStabilityInJson(objectMapper, jsonTree, child, assertions);
            }
            List<JsonNode> children = StreamSupport
                    .stream(arrayNode.spliterator(), false)
                    .collect(Collectors.toList());
            arrayNode.removeAll();
            String json = objectMapper.writeValueAsString(jsonTree);
            assertions.add(getExecutableForJson(json));
            if (size > 1) {
                arrayNode.add((JsonNode) null);
                json = objectMapper.writeValueAsString(jsonTree);
                assertions.add(getExecutableForJson(json));
                arrayNode.removeAll();
                arrayNode.add(children.get(0));
                json = objectMapper.writeValueAsString(jsonTree);
                assertions.add(getExecutableForJson(json));
                nullFieldsStabilityInJson(objectMapper, jsonTree, arrayNode.get(0), assertions);
            } else if (size == 1) {
                arrayNode.add((JsonNode) null);
                arrayNode.add((JsonNode) null);
                json = objectMapper.writeValueAsString(jsonTree);
                assertions.add(getExecutableForJson(json));
                arrayNode.removeAll();
                arrayNode.add(children.get(0));
                arrayNode.add(children.get(0));
                json = objectMapper.writeValueAsString(jsonTree);
                assertions.add(getExecutableForJson(json));
                nullFieldsStabilityInJson(objectMapper, jsonTree, arrayNode.get(0), assertions);
                nullFieldsStabilityInJson(objectMapper, jsonTree, arrayNode.get(1), assertions);
            }
            arrayNode.removeAll();
            children.forEach(arrayNode::add);
        } else if (currentNode.isObject()) {
            ObjectNode objectNode = (ObjectNode) currentNode;
            Iterator<String> fieldNameIterator = objectNode.fieldNames();
            List<String> fieldNames = new ArrayList<>();
            while (fieldNameIterator.hasNext()) {
                fieldNames.add(fieldNameIterator.next());
            }
            for (String fieldName : fieldNames) {
                JsonNode child = objectNode.get(fieldName);
                if (child.isNull()) {
                    continue;
                }
                objectNode.set(fieldName, null);
                String json = objectMapper.writeValueAsString(jsonTree);
                assertions.add(getExecutableForJson(json));
                objectNode.set(fieldName, child);
                nullFieldsStabilityInJson(objectMapper, jsonTree, child, assertions);
            }
        }
    }

    private Executable getExecutableForJson(String json) {
        return () -> this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(json))
                .andExpect((m) -> {
                    if (!HttpStatus.valueOf(m.getResponse().getStatus()).is2xxSuccessful()
                            && !HttpStatus.valueOf(m.getResponse().getStatus()).is4xxClientError()) {
                        throw new AssertionError("Unexpected Result for request: " + json);
                    }
                }).andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE));
    }

}
