package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.fma.configuration.ApplicationConfiguration;
import com.natwest.pbbdhb.fma.model.gmsstate.BrokerDetail;
import com.natwest.pbbdhb.fma.model.gmsstate.GmsSourceOneSourceTwoResponse;
import com.natwest.pbbdhb.fma.serialization.DeserializerModifier;
import com.natwest.pbbdhb.fma.service.GmsProductStateService;
import com.natwest.pbbdhb.fma.service.impl.GmsProductStateServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { GmsProductStateServiceImpl.class, DeserializerModifier.class })
@Import(ApplicationConfiguration.class)
public class GmsProductStateServiceImplTest {
	@Autowired
	private GmsProductStateService gmsProductStateService;

	@Value("${productstate.endpoint}")
	private String endPointUrl;

	@MockBean
	@Qualifier("restTemplateForApi")
	private RestTemplate restTemplate;

	@Test
	void testGetGmsProductStateResponse() {
		List<GmsSourceOneSourceTwoResponse> responses = new ArrayList<>();
		GmsSourceOneSourceTwoResponse response = new GmsSourceOneSourceTwoResponse();
		response.setSource1("1234");
		responses.add(response);
		BrokerDetail detail = new BrokerDetail();

		when(restTemplate.exchange(eq(endPointUrl), eq(HttpMethod.POST), any(HttpEntity.class),
				ArgumentMatchers.<ParameterizedTypeReference<List<GmsSourceOneSourceTwoResponse>>>any()))
						.thenReturn(new ResponseEntity<>(responses, HttpStatus.OK));

		List<GmsSourceOneSourceTwoResponse> lstResponse = gmsProductStateService.getGmsProductStateResponse(detail,
				"nwb");
		verify(restTemplate).exchange(eq(endPointUrl), eq(HttpMethod.POST), any(HttpEntity.class),
				ArgumentMatchers.<ParameterizedTypeReference<List<GmsSourceOneSourceTwoResponse>>>any());
		assertTrue(lstResponse.size() > 0);
		assertEquals("1234", lstResponse.get(0).getSource1());
	}

	@Test
	void testGetGmsProductStateResponse_error() {
		BrokerDetail detail = new BrokerDetail();
		when(restTemplate.exchange(eq(endPointUrl), eq(HttpMethod.POST), any(HttpEntity.class),
				ArgumentMatchers.<ParameterizedTypeReference<List<GmsSourceOneSourceTwoResponse>>>any()))
						.thenThrow(new RestClientException("exception occured during connection"));

		assertThrows(RestClientException.class, () -> gmsProductStateService.getGmsProductStateResponse(detail, "nwb"));
	}
}
