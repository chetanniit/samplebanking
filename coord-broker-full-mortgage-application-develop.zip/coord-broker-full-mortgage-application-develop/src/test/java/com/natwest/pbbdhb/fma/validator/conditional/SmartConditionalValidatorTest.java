package com.natwest.pbbdhb.fma.validator.conditional;

import com.natwest.pbbdhb.fma.validator.conditional.check.SmartNumberCheck;
import com.natwest.pbbdhb.fma.validator.conditional.check.SmartPathCheck;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.validation.ConstraintValidatorContext;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.math.BigDecimal;
import java.time.Month;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SmartConditionalValidatorTest {

    @Mock
    private ConstraintValidatorContext validatorContext;

    @Mock
    private ConstraintValidatorContext.ConstraintViolationBuilder violationBuilder;

    @Mock
    private ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext nodeBuilder;

    @Test
    public void testValidationSuccessful() {
        when(validatorContext.buildConstraintViolationWithTemplate(any())).thenReturn(violationBuilder);
        when(violationBuilder.addPropertyNode(any())).thenReturn(nodeBuilder);

        SmartConditionalValidator validator = new SmartConditionalValidator();

        validator.initialize(Root.class.getAnnotation(SmartConditionalRoot.class));
        validator.isValid(createExample(), validatorContext);

        assertAll(() -> verify(validatorContext).buildConstraintViolationWithTemplate("Test message"),
                () -> verify(validatorContext)
                        .buildConstraintViolationWithTemplate("At least one child must have empty string"),
                () -> verify(validatorContext, times(2))
                        .buildConstraintViolationWithTemplate("Test array element validation"),
                () -> verify(validatorContext, times(2))
                        .buildConstraintViolationWithTemplate("json path ends with '.childOneString'"),
                () -> verify(violationBuilder, times(22)).addPropertyNode(any()),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testParentInt"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testParentLong"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testParentIntNegate"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testParentBigDecimal"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testParentEnum"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testMultiple"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testMultipleConditions"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testSiblingAllMatch"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testAnyMatch"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testNotEmptySet"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testSmartCheckCurrent"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testSmartCheck"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testSmartCheckWithContext"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testSmartNumberCheck"),
                () -> verify(violationBuilder).addPropertyNode("rootChildTwo.testSmartNumberPathCheck"),
                () -> verify(violationBuilder).addPropertyNode("rootChildList[0].testInsideCollection"),
                () -> verify(violationBuilder).addPropertyNode("rootChildList[1].testInsideCollection"),
                () -> verify(violationBuilder).addPropertyNode("rootChildList[0]"),
                () -> verify(violationBuilder).addPropertyNode("rootChildList[1]"),
                () -> verify(violationBuilder).addPropertyNode("rootChildList[0].childOneString"),
                () -> verify(violationBuilder).addPropertyNode("rootChildList[1].childOneString"),
                () -> verify(violationBuilder, never()).addPropertyNode("rootChildTwo.testChildScope"));

        validator.initialize(ChildTwo.class.getAnnotation(SmartConditionalRoot.class));
        validator.isValid(createExample().getRootChildTwo(), validatorContext);

        verify(violationBuilder).addPropertyNode("testChildScope");

    }

    private Root createExample() {
        ChildOne childOne = new ChildOne();
        childOne.setChildOneString("abc");
        childOne.setChildOneSecondString("xxx");
        childOne.setCycleReference(childOne);
        return new Root(10, 5L, null, new HashSet<>(Arrays.asList("111", "222", "333")),
                Arrays.asList(childOne, new ChildOne("abc", null, childOne, null)), Month.APRIL, new ChildTwo(3));
    }

    @AllArgsConstructor
    @Getter
    @SmartConditionalRoot
    private static class Root {

        private final int rootInt;
        private final Long rootLong;
        private final BigDecimal rootBigDecimal;
        private final Set<String> rootStringSet;

        @SmartValidation(conditions = {
                @SmartCondition(path = "rootChildList[?]/cycleReference/childOneString", nullOrEmpty = true, negate = true),
                @SmartCondition(path = "rootChildList[*]/cycleReference/childOneString", values = "abc")
        }, message = "At least one child must have empty string")
        private final List<ChildOne> rootChildList;
        private final Month rootEnum;

        private final ChildTwo rootChildTwo;

    }

    @NoArgsConstructor
    @AllArgsConstructor
    @Setter
    @SmartValidation(
            conditions = @SmartCondition(path = "../rootInt", values = "10"),
            message = "Test array element validation"
    )
    private static class ChildOne {

        @JsonPathEndsWith(values = ".childOneString", message = "json path ends with '.childOneString'")
        private String childOneString;

        private String childOneSecondString;

        private ChildOne cycleReference;

        @SmartRequired(conditions = @SmartCondition(path = "../rootInt", values = "10"))
        private Integer testInsideCollection;

    }

    @SmartConditionalRoot(scope = "child")
    private static class ChildTwo {

        private final int childTwoInt;
        @SmartRequired(conditions = @SmartCondition(path = "../rootInt", values = "10"), message = "Test message")
        private String testParentInt;
        @SmartRequired(conditions = @SmartCondition(path = "../rootLong", values = { "5", "20" }))
        private String testParentLong;
        @SmartRequired(conditions = @SmartCondition(path = "../rootInt", values = "15", negate = true))
        private String testParentIntNegate;
        @SmartRequired(conditions = @SmartCondition(path = "../rootBigDecimal", nullOrEmpty = true))
        private String testParentBigDecimal;
        @SmartRequired(conditions = @SmartCondition(path = "../rootEnum", values = "APRIL"))
        private String testParentEnum;
        @SmartRequired(conditions = @SmartCondition(path = "../rootEnum", values = "APRIL"))
        @SmartRequired(conditions = @SmartCondition(path = "../rootEnum", values = "MARCH"))
        private String testMultiple;
        @SmartRequired(conditions = { @SmartCondition(path = "../rootBigDecimal", nullOrEmpty = true),
                @SmartCondition(path = "/rootLong", values = { "5", "20" }), })
        private String testMultipleConditions;
        @SmartRequired(conditions = @SmartCondition(path = "../rootChildList[*]/childOneString", values = "abc"))
        private String testSiblingAllMatch;
        @SmartRequired(conditions = @SmartCondition(path = "../rootStringSet[?]", values = "111"))
        private String testAnyMatch;
        @SmartRequired(scope = "child", conditions = @SmartCondition(path = "/childTwoInt", values = "3"))
        private String testChildScope;
        @SmartRequired(conditions = @SmartCondition(path = "../rootStringSet", nullOrEmpty = true, negate = true))
        private String testNotEmptySet;
        @SmartRequired(conditions = @SmartCondition(path = ".", values = "test", smartCheck = SmartCheckCurrentTest.class, negate = true))
        private String testSmartCheckCurrent;
        @SmartRequired(conditions = @SmartCondition(path = "../rootChildList[*]", smartCheck = SmartCheckTest.class))
        private String testSmartCheck;
        @SmartRequired(conditions = @SmartCondition(path = "testSmartCheckWithContext", smartCheck = SmartCheckWithContextTest.class))
        private String testSmartCheckWithContext;
        @SmartRequired(conditions = @SmartCondition(path = "../rootInt", values = { "<", "15" }, smartCheck = SmartNumberCheck.class))
        private String testSmartNumberCheck;
        @SmartRequired(conditions = @SmartCondition(path = "../rootInt", values = { ">", "path:../rootLong" }, smartCheck = SmartNumberCheck.class))
        private String testSmartNumberPathCheck;

        public ChildTwo(int childTwoInt) {
            this.childTwoInt = childTwoInt;
        }

    }

    private static class SmartCheckCurrentTest implements SmartCheck<ChildTwo> {
        @Override
        public boolean check(ChildTwo actualValue, List<String> conditionValues, SmartContext smartContext) {
            return !"test".equals(conditionValues.iterator().next());
        }
    }

    private static class SmartCheckTest implements SmartCheck<ChildOne> {
        @Override
        public boolean check(ChildOne actualValue, List<String> conditionValues, SmartContext smartContext) {
            return "abc".equals(actualValue.childOneString);
        }
    }

    private static class SmartCheckWithContextTest implements SmartCheck<String> {
        @Override
        public boolean check(String actualValue, List<String> conditionValues, SmartContext smartContext) {
            List<ChildOne> children1 = smartContext.getValues("../rootChildList[?]");
            List<ChildOne> children2 = smartContext.getValues("../rootChildList[*]");
            List<String> childrenStr = smartContext.getValues("../rootChildList[?]/childOneString");
            List<String> childrenSecStr = smartContext.getValues("../rootChildList[*]/childOneSecondString");
            return actualValue == null && children1.size() == 1 && children2.size() == 2 && childrenStr.size() == 1
                    && childrenStr.get(0).equals("abc") && childrenSecStr.size() == 2
                    && childrenSecStr.get(0).equals("xxx") && childrenSecStr.get(1) == null;
        }
    }

    @Target({ ElementType.FIELD })
    @Retention(RetentionPolicy.RUNTIME)
    @SmartValidation(
            conditions = @SmartCondition(path = "<field>", values = "endsWith", smartCheck = SmartPathCheck.class),
            message = "default message"
    )
    @interface JsonPathEndsWith {
        String[] values(); // set the path ending
        String message(); // provide custom message
    }

}
