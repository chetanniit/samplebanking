package com.natwest.pbbdhb.fma.mapper.gmsstate;

import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.fma.model.gmsstate.BrokerDetail;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BrokerProductStateMapperTest extends AbstractMapperTest {

    @InjectMocks
    private BrokerProductStateMapperImpl brokerProductStateMapper;

    @Test
    public void testFirmBrokerToBrokerDetail() {
        FullMortgageApplicationRequest request = loadInputModel("input/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);

        BrokerDetail brokerDetail = brokerProductStateMapper.toBrokerDetailRequest(request.getApplication().getBroker());

        assertOutputModelMatches("output/BrokerDetail.json", brokerDetail);
    }
}
