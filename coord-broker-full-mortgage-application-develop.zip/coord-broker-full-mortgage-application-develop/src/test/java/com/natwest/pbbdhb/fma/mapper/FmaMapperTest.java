package com.natwest.pbbdhb.fma.mapper;

import com.natwest.pbbdhb.fma.model.brokervalidation.FirmBroker;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.openapi.fma.Address;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@ExtendWith(MockitoExtension.class)
@Slf4j
public class FmaMapperTest extends AbstractMapperTest {

    @Spy
    private final FmaApplicantMapper fmaApplicantMapper = new FmaApplicantMapperImpl();
    @Spy
    private final FmaDepositsMapper fmaDepositsMapper = new FmaDepositsMapperImpl();
    @InjectMocks
    private FmaMapperImpl fmaMapper;

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "{} | {} | {}",
            "{ \"broker\" : { \"fee\" : { \"amount\" : 0 }}} | {} | { \"application\" : { \"broker\" : { \"fee\" : { \"amount\" : 0 , \"payableAt\" : null }}}}",
            "{} | { \"brokerTelephoneNumber\" : null } | { \"application\" : { \"broker\" : { \"brokerTelephoneNumber\" : \"(044)678-23-987\" }}}",
            "{} | { \"brokerTelephoneNumber\" : null , \"brokerMobileNumber\" : \"07342 066 424\"} | { \"application\" : { \"broker\" : { \"brokerTelephoneNumber\" : \"07342066424\" }}}",
            "{} | { \"brokerTelephoneNumber\" : \"\" } | { \"application\" : { \"broker\" : { \"brokerTelephoneNumber\" : \"(044)678-23-987\" }}}",
            "{ \"applicants\" : [{ \"addresses\" : [{},{ \"occupyStatus\" : \"OWNER_MORTGAGED\" }]}]} | {} | {\"applicants\":[{\"addresses\":[{},{\"originalPurchasePrice\":1,\"occupyStatus\":\"OWNER_MORTGAGED\"}]}]}",
            "{ \"applicants\" : [{ \"addresses\" : [{},{ \"occupyStatus\" : \"OWNER_NO_MORTGAGE\" }]}]} | {} | {\"applicants\":[{\"addresses\":[{},{\"originalPurchasePrice\":1,\"occupyStatus\":\"OWNER_NO_MORTGAGE\"}]}]}",
            "{ \"applicants\" : [{ \"personalDetails\" : { \"title\" : \"MR\", \"gender\" : \"FEMALE\"}}]} | {} | {\"applicants\":[{\"personalDetails\":{\"title\":\"MR\",\"gender\":\"MALE\"}}]}",
            "{ \"applicants\" : [{ \"personalDetails\" : { \"title\" : \"MRS\", \"gender\" : \"MALE\"}}]} | {} | {\"applicants\":[{\"personalDetails\":{\"title\":\"MRS\",\"gender\":\"FEMALE\"}}]}"
    }, delimiter = '|', maxCharsPerColumn = 10000)
    public void testApplicationToFullMortgageApplicationRequest(String inputApplicationMutatorJson,
                                                                String inputBrokerMutatorJson,
                                                                String outputMutatorJson) {
        Application application = loadInputModel("input/Application.json", inputApplicationMutatorJson, Application.class);
        FirmBroker firmBroker = loadInputModel("input/FirmBroker.json", inputBrokerMutatorJson, FirmBroker.class);

        FullMortgageApplicationRequest fullMortgageApplicationRequest =
                fmaMapper.toFMARequest(application, firmBroker);

        fullMortgageApplicationRequest.getApplication().getMortgage().getProducts().forEach(
                product -> product.setProductSelectionDate(null));
        
       
        assertOutputModelMatches("output/FullMortgageApplicationRequest.json", outputMutatorJson, fullMortgageApplicationRequest);
    }


    // if fails then seems like new fields have been added into "input/Application.json" and mapped to FullMortgageApplicationRequest
    // to fix please add corresponding field values into "input/FullMortgageApplicationRequest.json" directly
    // modify outputApplication only if the fields are not populated by mappers but by some custom code
    @Test
    public void testFullMortgageApplicationRequestInputMatchesOutput() {
        List<Field> ignore = new ArrayList<>(Arrays.asList(FMA_REQUEST_FIELDS_TO_IGNORE));
        ignore.addAll(Arrays.asList(
                field(com.natwest.pbbdhb.openapi.fma.Broker.class, "id"),
                field(com.natwest.pbbdhb.openapi.fma.Broker.class, "networkId"),
                field(com.natwest.pbbdhb.openapi.fma.Broker.class, "paymentPathName"),
                field(com.natwest.pbbdhb.openapi.fma.ProductDetails.class, "productSelectionDate"),
                field(com.natwest.pbbdhb.openapi.fma.Address.class, "originalPurchasePrice")
        ));

        FullMortgageApplicationRequest outputApplication = loadInputModel(
                "output/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class,
                ignore.toArray(new Field[0]));

        outputApplication.getApplication().getBroker().setId(273432);
        outputApplication.getApplication().getBroker().setNetworkId(32687234);
        outputApplication.getApplication().getBroker().setPaymentPathName("Mortgage Advice Bureau (L&G)");
        outputApplication.getApplication().getMortgage().getProducts().forEach(
                product -> product.setProductSelectionDate("2022-09-29"));
        Iterator<Address> itr = outputApplication.getApplicants().get(0).getAddresses().iterator();
        itr.next().setOriginalPurchasePrice(BigDecimal.valueOf(250000));
        itr.next().setOriginalPurchasePrice(BigDecimal.valueOf(50000));
        assertOutputModelMatches("input/FullMortgageApplicationRequest.json", outputApplication);
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "{ \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 0 , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]} | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 10000 , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : null , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]} | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 10000 , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 4000 , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]} | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 4000 , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : false , \"partialRefinanced\" : null , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]} | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : false , \"partialRefinanced\" : null , \"toBeRepaid\" : true , \"totalBalance\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : null , \"toBeRepaid\" : false , \"totalBalance\" : 10000 }]}]} | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : null , \"toBeRepaid\" : false , \"totalBalance\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 0 , \"toBeRepaid\" : false , \"totalBalance\" : 10000 }]}]} | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true , \"partialRefinanced\" : 0 , \"toBeRepaid\" : false , \"totalBalance\" : 10000 }]}]}",
  }, delimiter = '|', maxCharsPerColumn = 10000)
    public void testCreditCardPartialRefinanced(String inputApplicationMutatorJson,
                                                String outputMutatorJson) {
        Application application = loadInputModel("input/Application.json", inputApplicationMutatorJson, Application.class);
        FirmBroker firmBroker = loadInputModel("input/FirmBroker.json", FirmBroker.class);

        FullMortgageApplicationRequest fullMortgageApplicationRequest =
                fmaMapper.toFMARequest(application, firmBroker);

        fullMortgageApplicationRequest.getApplication().getMortgage().getProducts().forEach(
                product -> product.setProductSelectionDate(null));

        assertOutputModelMatches("output/FullMortgageApplicationRequest.json", outputMutatorJson, fullMortgageApplicationRequest);
    }

    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "{ \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : true ,  \"consolidationAmount\" : 0 ,    \"amountOutstanding\" : 10000 }]}]} | { \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : true ,  \"consolidationAmount\" : 10000 , \"amountOutstanding\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : true ,  \"consolidationAmount\" : null , \"amountOutstanding\" : 10000 }]}]} | { \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : true ,  \"consolidationAmount\" : 10000 , \"amountOutstanding\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : true ,  \"consolidationAmount\" : 4000 , \"amountOutstanding\" : 10000 }]}]} | { \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : true ,  \"consolidationAmount\" : 4000 ,  \"amountOutstanding\" : 10000 }]}]}",
            "{ \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : false , \"consolidationAmount\" : null , \"amountOutstanding\" : 10000 }]}]} | { \"applicants\" : [{ \"loans\" : [{ \"debtConsolidation\" : false , \"consolidationAmount\" : null ,  \"amountOutstanding\" : 10000 }]}]}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    public void testLoansConsolidationAmount(String inputApplicationMutatorJson,
                                             String outputMutatorJson) {
        Application application = loadInputModel("input/Application.json", inputApplicationMutatorJson, Application.class);
        FirmBroker firmBroker = loadInputModel("input/FirmBroker.json", FirmBroker.class);

        FullMortgageApplicationRequest fullMortgageApplicationRequest =
                fmaMapper.toFMARequest(application, firmBroker);

        fullMortgageApplicationRequest.getApplication().getMortgage().getProducts().forEach(
                product -> product.setProductSelectionDate(null));

        assertOutputModelMatches("output/FullMortgageApplicationRequest.json", outputMutatorJson, fullMortgageApplicationRequest);
    }

}
