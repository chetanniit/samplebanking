package com.natwest.pbbdhb.fma.util;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.lang.reflect.Field;

public class SwaggerUtils {

    public static Class<?> extractFieldClassType(Field field) {
        Schema schema = field.getAnnotation(Schema.class);
        ArraySchema arraySchema = field.getAnnotation(ArraySchema.class);
        if (schema != null && !schema.implementation().equals(Void.class)) {
            return schema.implementation();
        } else if (arraySchema != null && !arraySchema.schema().implementation().equals(Void.class)) {
            return arraySchema.schema().implementation();
        } else {
            return extractFieldClassType(field.getType());
        }
    }

    private static Class<?> extractFieldClassType(Class<?> fieldType) {
        if (fieldType.isArray()) {
            return extractFieldClassType(fieldType.getComponentType());
        } else if (!fieldType.isPrimitive()) {
            return fieldType;
        }
        return null;
    }

}
