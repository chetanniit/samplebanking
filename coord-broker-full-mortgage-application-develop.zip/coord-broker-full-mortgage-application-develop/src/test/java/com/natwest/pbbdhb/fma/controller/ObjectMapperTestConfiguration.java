package com.natwest.pbbdhb.fma.controller;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.natwest.pbbdhb.fma.serialization.DeserializerModifier;
import lombok.SneakyThrows;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.lang.reflect.Field;

@TestConfiguration
@ComponentScan("com.natwest.pbbdhb.fma.serialization")
public class ObjectMapperTestConfiguration {

    @Bean
    public JsonMapper jsonMapper(DeserializerModifier deserializerModifier) {
        SimpleModule module = new SimpleModule();
        module.setDeserializerModifier(deserializerModifier);
        return JsonMapper.builder().configure(MapperFeature.ALLOW_FINAL_FIELDS_AS_MUTATORS, false)
                .configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
                .configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT, false)
                .annotationIntrospector(new JacksonAnnotationIntrospector() {
                    @SneakyThrows
                    @Override
                    public JsonIgnoreProperties.Value findPropertyIgnoralByName(MapperConfig<?> config, Annotated a) {
                        JsonIgnoreProperties.Value value = super.findPropertyIgnoralByName(config, a);
                        Field ignoreUnknown = JsonIgnoreProperties.Value.class.getDeclaredField("_ignoreUnknown");
                        ignoreUnknown.setAccessible(true);
                        ignoreUnknown.set(value, false);
                        return value;
                    }
                })
                // .configure(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS, true) // bugged in jackson below 2.5.1
                .addModule(module).addModule(new JavaTimeModule()).build();
    }

}
