package com.natwest.pbbdhb.fma.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.service.FmaService;
import com.natwest.pbbdhb.fma.service.impl.FmaServiceImpl;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { FmaServiceImpl.class })
public class FmaServiceImplTest {
    @Autowired
    private FmaService fmaService;

    @Value("${fma.endpoint}")
    private String endPointUrl;

    @MockBean
    private RestTemplate restTemplate;

    @MockBean
    private ObjectMapper objectMapper;

    @MockBean
    private ExecutionContext executionContext;

    @Test
    void testMakeSumbitFMAWithValidRequest() {
        ResponseEntity<FullMortgageApplicationExtendedResponse> response = new ResponseEntity<FullMortgageApplicationExtendedResponse>(
                new FullMortgageApplicationExtendedResponse(), HttpStatus.ACCEPTED);
        FullMortgageApplicationRequest req = FullMortgageApplicationRequest.builder().build();
        when(restTemplate.postForEntity(eq(endPointUrl), Mockito.any(HttpEntity.class),
                eq(FullMortgageApplicationExtendedResponse.class))).thenReturn(response);
        fmaService.submitFma(req, "nwb", "123456");
        verify(restTemplate).postForEntity(anyString(), Mockito.any(HttpEntity.class),
                eq(FullMortgageApplicationExtendedResponse.class));
    }

}
