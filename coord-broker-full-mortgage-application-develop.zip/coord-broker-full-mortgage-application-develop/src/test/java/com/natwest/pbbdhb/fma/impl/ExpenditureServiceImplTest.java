package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.fma.service.impl.ExpenditureServiceImpl;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStage;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { ExpenditureServiceImpl.class })
public class ExpenditureServiceImplTest {

    @Autowired
    private ExpenditureServiceImpl expenditureService;

    @Value("${expenditure.endpoint}")
    private String endPointUrl;

    @MockBean
    private RestTemplate restTemplate;

    @Test
    void testCreateExpense() {
        when(restTemplate.exchange(eq(endPointUrl), eq(HttpMethod.PUT), any(HttpEntity.class),
                eq(ValidatedCaseExpenseDto.class), eq("CaseID"))).thenReturn(
                        new ResponseEntity<>(ValidatedCaseExpenseDto.builder().version(1).stage(CaseStage.FMA).build(),
                                HttpStatus.OK));
        ValidatedCaseExpenseDto expenseRequest = ValidatedCaseExpenseDto.builder().version(1).stage(CaseStage.FMA).build();
        ValidatedCaseExpenseDto expense = expenditureService.createExpense("CaseID", "nwb", expenseRequest);
        verify(restTemplate).exchange(eq(endPointUrl), eq(HttpMethod.PUT), any(HttpEntity.class),
                eq(ValidatedCaseExpenseDto.class), eq("CaseID"));
        assertEquals(1, expense.getVersion());
        assertEquals(CaseStage.FMA, expense.getStage());
    }
}
