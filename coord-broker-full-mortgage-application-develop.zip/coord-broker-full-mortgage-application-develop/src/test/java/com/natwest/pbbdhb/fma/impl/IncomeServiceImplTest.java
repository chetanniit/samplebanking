package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.fma.service.impl.IncomeServiceImpl;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStage;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { IncomeServiceImpl.class })
public class IncomeServiceImplTest {

    @Autowired
    private IncomeServiceImpl incomeService;

    @Value("${income.endpoint}")
    private String endPointUrl;

    @MockBean
    private RestTemplate restTemplate;

    @Test
    void testGetIncome() {
        when(restTemplate.exchange(eq(endPointUrl), eq(HttpMethod.GET), any(HttpEntity.class),
                eq(ValidatedCaseIncomeDto.class), eq("CaseID"))).thenReturn(
                        new ResponseEntity<>(ValidatedCaseIncomeDto.builder().version(1).stage(CaseStage.FMA).build(),
                                HttpStatus.OK));

        ValidatedCaseIncomeDto income = incomeService.getIncome("CaseID", "nwb");

        verify(restTemplate).exchange(eq(endPointUrl), eq(HttpMethod.GET), any(HttpEntity.class),
                eq(ValidatedCaseIncomeDto.class), eq("CaseID"));
        assertEquals(1, income.getVersion());
        assertEquals(CaseStage.FMA, income.getStage());
    }

    @Test
    void testCreateIncome() {
        when(restTemplate.exchange(eq(endPointUrl), eq(HttpMethod.PUT), any(HttpEntity.class),
                eq(ValidatedCaseIncomeDto.class), eq("CaseID"))).thenReturn(
                        new ResponseEntity<>(ValidatedCaseIncomeDto.builder().version(1).stage(CaseStage.FMA).build(),
                                HttpStatus.OK));
        ValidatedCaseIncomeDto incomeRequest = ValidatedCaseIncomeDto.builder().version(1).stage(CaseStage.FMA).build();

        ValidatedCaseIncomeDto income = incomeService.createIncome("CaseID", "nwb", incomeRequest);

        verify(restTemplate).exchange(eq(endPointUrl), eq(HttpMethod.PUT), any(HttpEntity.class),
                eq(ValidatedCaseIncomeDto.class), eq("CaseID"));
        assertEquals(1, income.getVersion());
        assertEquals(CaseStage.FMA, income.getStage());
    }
}
