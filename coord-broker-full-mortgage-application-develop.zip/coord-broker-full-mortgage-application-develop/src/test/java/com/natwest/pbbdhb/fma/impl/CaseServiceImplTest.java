package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.search.CriteriaDto;
import com.natwest.pbbdhb.fma.dto.PatchDto;
import com.natwest.pbbdhb.fma.model.fma.CaseSearchResponse;
import com.natwest.pbbdhb.fma.service.CaseService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class CaseServiceImplTest {
    @Autowired
    private CaseService caseService;

    @Value("${case.create.endpoint}")
    private String endPointUrl;

    @Value("${case.search.endpoint}")
    private String searchEndPointUrl;

    @MockBean
    @Qualifier("restTemplateForApiCalls")
    private RestTemplate restTemplate;

    @MockBean
    @Qualifier("restTemplateForPatchApiCalls")
    private RestTemplate restTemplatePatch;

    @Test
    void testMakeCaseCreateCallWithValidRequest() {
        CaseApplicationDto caseApplReq = CaseApplicationDto.builder().build();
        CaseApplicationDto caseApplResp = CaseApplicationDto.builder().build();
        when(restTemplate.postForObject(eq(endPointUrl), Mockito.any(HttpEntity.class), eq(CaseApplicationDto.class)))
                .thenReturn(caseApplResp);
        caseService.createCase(caseApplReq, "nwb");

        verify(restTemplate).postForObject(anyString(), Mockito.any(HttpEntity.class), eq(CaseApplicationDto.class));
    }


    @Test
    void testSearchCasesByDipId() {
        CriteriaDto caseAppSearchReq = new CriteriaDto();
        CaseSearchResponse caseSearchResponse = CaseSearchResponse.builder().content(Collections.singletonList(CaseApplicationDto.builder().build())).build();
        when(restTemplate.postForObject(eq(searchEndPointUrl+ "?page=0" + "&size=1"), Mockito.any(HttpEntity.class), eq(CaseSearchResponse.class)))
                .thenReturn(caseSearchResponse);
        caseService.searchCasesByDipId(caseAppSearchReq , "nwb");
        verify(restTemplate).postForObject(anyString(), Mockito.any(HttpEntity.class), eq(CaseSearchResponse.class));
    }
    @Test
    void testPatchCaseCallWithValidRequest() {

        PatchDto patchDto = PatchDto.builder().build();
        List<PatchDto> patches = new ArrayList<>();
        patches.add(patchDto);

        when(restTemplatePatch.exchange(eq(endPointUrl + "/1234"), eq(HttpMethod.PATCH), any(HttpEntity.class),
                eq(CaseApplicationDto.class), Mockito.anyMap())).thenReturn(
                        new ResponseEntity<>(CaseApplicationDto.builder().version("1").build(), HttpStatus.OK));
        CaseApplicationDto application = caseService.patch("nwb", "1234", patches);

        verify(restTemplatePatch).exchange(eq(endPointUrl + "/1234"), eq(HttpMethod.PATCH), any(HttpEntity.class),
                eq(CaseApplicationDto.class), Mockito.anyMap());
        assertEquals("1", application.getVersion());
    }

}
