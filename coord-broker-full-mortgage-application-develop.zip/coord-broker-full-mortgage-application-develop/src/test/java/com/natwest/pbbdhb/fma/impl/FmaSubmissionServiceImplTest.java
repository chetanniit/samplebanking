package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.fma.configuration.ApplicationConfiguration;
import com.natwest.pbbdhb.fma.exception.BrokerValidationFailException;
import com.natwest.pbbdhb.fma.exception.PaymentPathInvalidException;
import com.natwest.pbbdhb.fma.helper.LinkHelper;
import com.natwest.pbbdhb.fma.mapper.FmaMapper;
import com.natwest.pbbdhb.fma.mapper.FmaResponseMapper;
import com.natwest.pbbdhb.fma.mapper.applicant.ApplicantMapper;
import com.natwest.pbbdhb.fma.mapper.cases.CaseMapper;
import com.natwest.pbbdhb.fma.mapper.cases.CaseToFmaResponseMapper;
import com.natwest.pbbdhb.fma.mapper.expense.ExpenditureMapper;
import com.natwest.pbbdhb.fma.mapper.gmsstate.BrokerProductStateMapper;
import com.natwest.pbbdhb.fma.mapper.income.IncomeMapper;
import com.natwest.pbbdhb.fma.mapper.property.PropertyMapper;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailRequest;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailResponse;
import com.natwest.pbbdhb.fma.model.brokervalidation.FirmBroker;
import com.natwest.pbbdhb.fma.model.brokervalidation.PaymentPath;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.Broker;
import com.natwest.pbbdhb.fma.model.fma.enums.ApplicationType;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.serialization.DeserializerModifier;
import com.natwest.pbbdhb.fma.service.ApplicantService;
import com.natwest.pbbdhb.fma.service.BrokerValidationService;
import com.natwest.pbbdhb.fma.service.CapieUpdateService;
import com.natwest.pbbdhb.fma.service.CaseGenerationService;
import com.natwest.pbbdhb.fma.service.CaseService;
import com.natwest.pbbdhb.fma.service.ExpenditureService;
import com.natwest.pbbdhb.fma.service.FmaService;
import com.natwest.pbbdhb.fma.service.FmaSubmissionService;
import com.natwest.pbbdhb.fma.service.GmsProductStateService;
import com.natwest.pbbdhb.fma.service.IncomeService;
import com.natwest.pbbdhb.fma.service.PropertyService;
import com.natwest.pbbdhb.fma.service.impl.FmaSubmissionServiceImpl;
import com.natwest.pbbdhb.fma.util.JsonUtils;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.model.fma.ResponseStatus;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import com.natwest.pbbdhb.openapi.fma.ResponseData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { FmaSubmissionServiceImpl.class, DeserializerModifier.class })
@Import(ApplicationConfiguration.class)
public class FmaSubmissionServiceImplTest {

    @Autowired
    private FmaSubmissionService fmaSubmissionService;

    @MockBean
    private BrokerValidationService brokerValidationService;

    @MockBean
    @Qualifier("restTemplateForApi")
    private RestTemplate restTemplate;

    @MockBean
    private ModelMapper modelMapper;

    @MockBean
    private CaseService caseService;

    @MockBean
    private CaseMapper caseMapper;

    @MockBean
    private ApplicantService applicantService;

    @MockBean
    private ApplicantMapper applicantMapper;

    @MockBean
    private IncomeService incomeService;
    @MockBean
    private IncomeMapper incomeMapper;

    @MockBean
    private ExpenditureService expenditureService;
    @MockBean
    private ExpenditureMapper expenditureMapper;
    @MockBean
    private PropertyService propertyService;
    @MockBean
    private PropertyMapper propertyMapper;

    @MockBean
    private CapieUpdateService capUpdateService;
    @MockBean
    private FmaService fmaService;
    @MockBean
    private FmaMapper fmaMapper;
    @MockBean
    private FmaResponseMapper fmaResponseMapper;
    @MockBean
    private CaseGenerationService caseGenerationService;
    @MockBean
    private LinkHelper linkHelper;
    @MockBean
    private GmsProductStateService gmsProductStateService;
    @MockBean
    private BrokerProductStateMapper brokerProductStateMapper;
    @MockBean
    private CaseToFmaResponseMapper caseToFmaResponseMapper;

    @Test
    void performFMASuccess() {
        ArgumentCaptor<Boolean> captor = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<FullMortgageApplicationRequest> fmaReqCaptor = ArgumentCaptor.forClass(FullMortgageApplicationRequest.class);
        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        ResponseStatus status = new ResponseStatus();
        status.setStatus("201");
        FirmBroker broker = new FirmBroker();
        broker.setAcceptMortgageBusiness("Yes");
        PaymentPath paymentPath = PaymentPath.builder().paymentPathID("253722111")
                .paymentPathName("Mortgage Advice Bureau (L&G)").build();
        brokerDetailResponse.setBrokers(Collections.singleton(broker));
        brokerDetailResponse.setPaymentPaths(Collections.singleton(paymentPath));
        when(brokerValidationService.validate(any(BrokerDetailRequest.class))).thenReturn(brokerDetailResponse);
        when(modelMapper.map(any(Broker.class), same(BrokerDetailRequest.class))).thenReturn(new BrokerDetailRequest());
        when(modelMapper.map(any(Application.class), same(Application.class))).thenReturn(new Application());
        when(caseMapper.toCaseApplication(any(), any(), any())).thenReturn(CaseApplicationDto.builder().broker(new BrokerDto()).build());
        ApplicantDto app = new ApplicantDto();
        app.setApplicantId("AAA");
        List<Applicant> applicants = new ArrayList<>();
        Applicant applicant = new Applicant();
        applicants.add(applicant);
        when(fmaMapper.toFMARequest(Mockito.any(), Mockito.any())).thenReturn(FullMortgageApplicationRequest.builder()
                .application(com.natwest.pbbdhb.openapi.fma.Application.builder()
                        .broker(com.natwest.pbbdhb.openapi.fma.Broker.builder().build())
                        .build()).applicants(applicants)
                .build());
        when(applicantService.createApplicant(Mockito.any(), Mockito.any())).thenReturn(app);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(null), eq(String.class)))
                .thenReturn(new ResponseEntity<>("", HttpStatus.OK));
        Application application = JsonUtils.getValidRequest(ApplicationType.RESIDENTIAL);

        when(caseGenerationService.generateCaseId(anyString(), any(Application.class), anyString()))
                .thenReturn("dummyCaseId");
        FullMortgageApplicationExtendedResponse response = new FullMortgageApplicationExtendedResponse();
        response.setData(ResponseData.builder().build());
        response.setResponseStatus(new ResponseStatus("201"));
        when(fmaService.submitFma(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
        when(fmaResponseMapper.toFmaResponse(any(ResponseData.class),Mockito.anyString())).thenReturn(new FmaResponse());
        FmaResponse fmaResponse = fmaSubmissionService.performFmaSubmission(application, "clientId", "brand");
        Mockito.verify(applicantMapper, Mockito.times(1)).toCreateApplicant(Mockito.any(), Mockito.any(),
                captor.capture(), Mockito.any());
        Mockito.verify(fmaService, Mockito.times(1)).submitFma(fmaReqCaptor.capture(),Mockito.any(), Mockito.any());
        assertTrue(captor.getValue());
        FullMortgageApplicationRequest request= fmaReqCaptor.getValue();
        assertEquals("dummyCaseId", fmaResponse.getCaseId());
        assertEquals(313799,request.getApplication().getBroker().getId());
    }

    @Test
    void performFMAForInvalidBroker() {
        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        FirmBroker broker = new FirmBroker();
        broker.setAcceptMortgageBusiness("No");
        brokerDetailResponse.setBrokers(Collections.singleton(broker));
        when(modelMapper.map(any(Broker.class), same(BrokerDetailRequest.class))).thenReturn(new BrokerDetailRequest());
        when(brokerValidationService.validate(any(BrokerDetailRequest.class))).thenReturn(brokerDetailResponse);
        Application application = JsonUtils.getValidRequest(ApplicationType.RESIDENTIAL);
        when(caseGenerationService.generateCaseId(anyString(), any(Application.class), anyString()))
                .thenReturn("dummyCaseId");
        assertThrows(BrokerValidationFailException.class,
                () -> fmaSubmissionService.performFmaSubmission(application, "clientId", "brand"));
    }

    @ParameterizedTest(name = "{index}: {arguments}")
    @CsvSource(value = { "123456789;Paradigm Mortgage Club (DA)", "229181986;Wrong Name" }, delimiter = ';')
    void performFMAForInvalidPaymentPath(String paymentPathId, String paymentPathName) {
        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        FirmBroker broker = new FirmBroker();
        broker.setAcceptMortgageBusiness("Yes");
        PaymentPath paymentPath = PaymentPath.builder().paymentPathID(paymentPathId).paymentPathName(paymentPathName)
                .build();
        brokerDetailResponse.setBrokers(Collections.singleton(broker));
        brokerDetailResponse.setPaymentPaths(Collections.singleton(paymentPath));
        when(modelMapper.map(any(Broker.class), same(BrokerDetailRequest.class))).thenReturn(new BrokerDetailRequest());
        when(brokerValidationService.validate(any(BrokerDetailRequest.class))).thenReturn(brokerDetailResponse);
        Application application = JsonUtils.getValidRequest(ApplicationType.RESIDENTIAL);
        when(caseGenerationService.generateCaseId(anyString(), any(Application.class), anyString()))
                .thenReturn("dummyCaseId");
        assertThrows(PaymentPathInvalidException.class,
                () -> fmaSubmissionService.performFmaSubmission(application, "clientId", "brand"));
    }

    @Test
    void performFMASuccessJointApplicant() {
        ArgumentCaptor<Boolean> captor = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<Boolean> captorConsent = ArgumentCaptor.forClass(Boolean.class);
        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        ResponseStatus status = new ResponseStatus();
        status.setStatus("201");
        FirmBroker broker = new FirmBroker();
        broker.setAcceptMortgageBusiness("Yes");
        PaymentPath paymentPath = PaymentPath.builder().paymentPathID("253722111")
                .paymentPathName("Mortgage Advice Bureau (L&G)").build();
        brokerDetailResponse.setBrokers(Collections.singleton(broker));
        brokerDetailResponse.setPaymentPaths(Collections.singleton(paymentPath));
        when(brokerValidationService.validate(any(BrokerDetailRequest.class))).thenReturn(brokerDetailResponse);
        when(modelMapper.map(any(Broker.class), same(BrokerDetailRequest.class))).thenReturn(new BrokerDetailRequest());
        when(modelMapper.map(any(Application.class), same(Application.class))).thenReturn(new Application());
        when(caseMapper.toCaseApplication(any(), any(), any())).thenReturn(CaseApplicationDto.builder().broker(new BrokerDto()).build());
        ApplicantDto app = new ApplicantDto();
        app.setApplicantId("AAA");
        List<Applicant> applicants = new ArrayList<>();
        Applicant applicant = new Applicant();
        Applicant secondApplicant = new Applicant();
        applicants.add(applicant);
        applicants.add(secondApplicant);
        when(fmaMapper.toFMARequest(Mockito.any(), Mockito.any())).thenReturn(FullMortgageApplicationRequest.builder()
                .application(com.natwest.pbbdhb.openapi.fma.Application.builder()
                        .broker(com.natwest.pbbdhb.openapi.fma.Broker.builder().build())
                        .build()).applicants(applicants)
                .build());
        when(applicantService.createApplicant(Mockito.any(), Mockito.any())).thenReturn(app);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(null), eq(String.class)))
                .thenReturn(new ResponseEntity<>("", HttpStatus.OK));
        Application application = JsonUtils.getValidRequest(ApplicationType.RESIDENTIAL);
        com.natwest.pbbdhb.fma.model.fma.Applicant applicantNotMain = new com.natwest.pbbdhb.fma.model.fma.Applicant ();
        applicantNotMain.setMainApplicant(false);
        applicantNotMain.setConsentToFMA(true);
        application.getApplicants().add(applicantNotMain);
        when(caseGenerationService.generateCaseId(anyString(), any(Application.class), anyString()))
                .thenReturn("dummyCaseId");
        FullMortgageApplicationExtendedResponse response = new FullMortgageApplicationExtendedResponse();
        response.setData(ResponseData.builder().build());
        response.setResponseStatus(new ResponseStatus("201"));
        when(fmaService.submitFma(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
        when(fmaResponseMapper.toFmaResponse(any(ResponseData.class),Mockito.anyString())).thenReturn(new FmaResponse());
        FmaResponse fmaResponse = fmaSubmissionService.performFmaSubmission(application, "clientId", "brand");

        assertEquals("dummyCaseId", fmaResponse.getCaseId());
        Mockito.verify(applicantMapper, Mockito.times(2)).toCreateApplicant(Mockito.any(), Mockito.any(),
                captor.capture(), captorConsent.capture());
        List<Boolean> lstMainApplicantCaptor = captor.getAllValues();
        List<Boolean> lstConsentToFma = captorConsent.getAllValues();
        assertTrue(lstMainApplicantCaptor.get(0));
        assertFalse(lstMainApplicantCaptor.get(1));
        assertTrue(lstConsentToFma.get(0));
        assertTrue(lstConsentToFma.get(1));
    }
}
