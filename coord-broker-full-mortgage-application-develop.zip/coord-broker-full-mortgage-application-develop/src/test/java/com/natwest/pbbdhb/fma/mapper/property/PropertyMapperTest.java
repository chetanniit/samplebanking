package com.natwest.pbbdhb.fma.mapper.property;

import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PropertyMapperTest extends AbstractMapperTest {

    @InjectMocks
    private PropertyMapperImpl propertyMapper;

    @Test
    public void testFmaPropertyToMsvcProperty() {
        FullMortgageApplicationRequest fmaRequest = loadInputModel("input/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);

        PropertyDetailsDto msvcProperty = propertyMapper.toPropertyDetails(fmaRequest.getApplication().getProperty(),
                fmaRequest.getApplication().getCaseId());

        assertOutputModelMatches("output/PropertyDetails.json", msvcProperty);
    }

}
