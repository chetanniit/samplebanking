package com.natwest.pbbdhb.fma.mapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.natwest.pbbdhb.fma.util.JsonUtils;
import com.natwest.pbbdhb.openapi.fma.Address;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.Application;
import com.natwest.pbbdhb.openapi.fma.Broker;
import com.natwest.pbbdhb.openapi.fma.DirectDebitDetails;
import com.natwest.pbbdhb.openapi.fma.Mortgage;
import com.natwest.pbbdhb.openapi.fma.ProductDetails;
import com.natwest.pbbdhb.openapi.fma.PropertyDetails;
import com.natwest.pbbdhb.openapi.fma.SolicitorDetails;
import org.junit.jupiter.api.Assertions;
import org.opentest4j.AssertionFailedError;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class AbstractMapperTest {

    protected static final Field[] FMA_REQUEST_FIELDS_TO_IGNORE = new Field[] {
            field(Mortgage.class, "mortgageAdvisor"),
            field(Mortgage.class, "existingMortgageTransfer"),
            field(SolicitorDetails.class, "alphaKey"),
            field(SolicitorDetails.class, "associateType"),
            field(SolicitorDetails.class, "branchCode"),
            field(SolicitorDetails.class, "companyCode"),
            field(SolicitorDetails.class, "documentExchangeNumber"),
            field(SolicitorDetails.class, "solePractitioner"),
            field(SolicitorDetails.class, "status"),
            field(SolicitorDetails.class, "telephones"),
            field(Broker.class, "firmAddressCity"),
            field(Broker.class, "firmAddressCountry"),
            field(Broker.class, "firmAddressCounty"),
            field(Application.class, "ieChecks"),
            field(Application.class, "applSeq"),
            field(Application.class, "branch"),
            field(Application.class, "contactPermission"),
            field(Application.class, "currencyExchangeRate"),
            field(Application.class, "exceptionPolicies"),
            field(Application.class, "marketingSchemeNumber"),
            field(Application.class, "mortgageReferenceNumber"),
            field(Application.class, "repayMortgageCurrency"),
            field(Application.class, "repayMortgageCurrencyNotSterling"),
            field(Application.class, "bpid"),
            field(Applicant.class, "cin"),
            field(Applicant.class, "clientId"),
            field(Applicant.class, "multiCins"),
            field(Applicant.class, "proofOfIds"),
            field(Applicant.class, "existingCustomerChecks"),
            field(Applicant.class, "kycChecks"),
            field(Address.class, "endYear"),
            field(Address.class, "endMonth"),
            field(PropertyDetails.class, "consentToShareDetailsWithSurveyProvider"),
            field(PropertyDetails.class, "declarationKnowYourProperty"),
            field(ProductDetails.class, "fees"),
            field(DirectDebitDetails.class, "paymentDayOfTheMonth")
    };

    private ObjectMapper objectMapper;

    public AbstractMapperTest() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
        objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        JacksonAnnotationIntrospector annotationIntrospector = new JacksonAnnotationIntrospector() {
            @Override
            protected boolean _isIgnorable(Annotated a) {
                return false;
            }

            @Override
            public JsonIgnoreProperties.Value findPropertyIgnoralByName(MapperConfig<?> config, Annotated a) {
                return JsonIgnoreProperties.Value.empty();
            }

            @Override
            public JsonProperty.Access findPropertyAccess(Annotated m) {
                return null;
            }

            @Override
            public Boolean isIgnorableType(AnnotatedClass ac) {
                return null;
            }
        };
        objectMapper.setAnnotationIntrospector(annotationIntrospector);

        SimpleModule module = new SimpleModule();
        module.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        module.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS][.SS][.S]")));
        module.addSerializer(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        module.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS][.SS][.S]")));
        objectMapper.registerModule(module);

    }

    protected static Field field(Class<?> clazz, String field) {
        try {
            return clazz.getDeclaredField(field);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * !!! Use allowEmpty to ignore fields that are totally not used in the coord-broker-FMA service<br>
     * !!! If some field is used at least once then provide a value in the json file
     */
    protected <T> T loadInputModel(String inputModelJsonFile, Class<T> modelClass, Field... allowEmpty) {
        return loadInputModel(inputModelJsonFile, null, modelClass, allowEmpty);
    }

    protected <T> T loadInputModel(String inputModelJsonFile, String inputModelMutatorJson, Class<T> modelClass, Field... allowEmpty) {
        assertAllFieldsAreSet(loadModel(inputModelJsonFile, modelClass, null), allowEmpty);
        return loadModel(inputModelJsonFile, modelClass, inputModelMutatorJson);
    }

    private <T> T loadModel(String inputModelJsonFile, Class<T> modelClass, String inputModelMutatorJson) {
        String inputJson = JsonUtils.getJson("mapper/" + inputModelJsonFile, inputModelMutatorJson);
        try {
            return objectMapper.readValue(inputJson, modelClass);
        } catch (Exception e) {
            throw new AssertionError("Incorrect JSON: " + e.getMessage(), e);
        }
    }

    protected <T> void assertOutputModelMatches(String outputModelJsonFile, T mappedOutputModel) {
        assertOutputModelMatches(outputModelJsonFile, null, mappedOutputModel);
    }

    protected <T> void assertOutputModelMatches(String outputModelJsonFile, String outputModelMutatorJson, T mappedOutputModel) {
        JsonNode mappedOutputTree;
        try {
            mappedOutputTree = objectMapper.readTree(objectMapper.writeValueAsString(mappedOutputModel));
        } catch (Exception e) {
            throw new AssertionError("Can't serialize provided output model: " + e.getMessage(), e);
        }
        JsonNode ethalonOutputTree;
        try {
            ethalonOutputTree = objectMapper.readTree(
                    JsonUtils.getJson("mapper/" + outputModelJsonFile, outputModelMutatorJson));
        } catch (JsonProcessingException e) {
            throw new AssertionError("Can't load output model JSON: " + e.getMessage(), e);
        }
        try {
            Assertions.assertEquals(ethalonOutputTree, mappedOutputTree);
        } catch (AssertionFailedError e) {
            throw new AssertionFailedError(e.getMessage(), ethalonOutputTree.toPrettyString(), mappedOutputTree.toPrettyString());
        }
    }

    private <T> void assertAllFieldsAreSet(T object, Field... allowEmpty) {
        Set<String> violations = assertAllFieldsAreSet(object, new HashSet<>(Arrays.asList(allowEmpty)),
                Collections.newSetFromMap(new IdentityHashMap<>()), "");
        if (!violations.isEmpty()) {
            throw new AssertionError("Some fields have no values: \n"
                    + violations.stream().sorted().collect(Collectors.joining(" \n")));
        }
    }

    private <T> Set<String> assertAllFieldsAreSet(T object, Set<Field> allowEmpty, Set<Object> visited, String path) {

        if (object == null || visited.contains(object)) {
            return Collections.emptySet();
        }
        visited.add(object);

        Class<?> clazz = object.getClass();

        HashSet<String> violations = new HashSet<>();

        if (Iterable.class.isAssignableFrom(clazz)) {
            int i = 0;
            for (Object obj : ((Iterable<?>) object)) {
                violations.addAll(assertAllFieldsAreSet(obj, allowEmpty, visited, path + "[" + i++ + "]"));
            }
        } else if (clazz.isArray() && !clazz.getComponentType().isPrimitive()) {
            int i = 0;
            for (Object obj : ((Object[]) object)) {
                violations.addAll(assertAllFieldsAreSet(obj, allowEmpty, visited, path + "[" + i++ + "]"));
            }
        } else if (Map.class.isAssignableFrom(clazz)) {
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) object).entrySet()) {
                Object obj = entry.getValue();
                Object key = entry.getKey();
                violations.addAll(assertAllFieldsAreSet(obj, allowEmpty, visited,
                        path + ("".equals(path) ? "" : ".") + key.toString()));
            }
        }

        if (clazz.getPackage() == null || !clazz.getPackage().getName().startsWith("com.natwest")) {
            return violations;
        }

        List<Field> fields = collectFields(clazz);
        fields.removeAll(allowEmpty);

        violations.addAll(fields.stream().peek(field -> field.setAccessible(true)).filter(field -> {
            Object value = safeGet(field, object);
            violations.addAll(assertAllFieldsAreSet(value, allowEmpty, visited,
                    path + ("".equals(path) ? "" : ".") + field.getName()));
            if (value != null && !"".equals(value) && allowEmpty.contains(field)) {
                violations.add(field.getDeclaringClass().getName() + "." + field.getName() + " (" +
                        path + ("".equals(path) ? "" : ".") + field.getName() + ") is marked as ignored but has not null value");
            }
            return value == null || "".equals(value);
        }).map(field -> field.getDeclaringClass().getName() + "." + field.getName() + " (" +
                path + ("".equals(path) ? "" : ".") + field.getName() + ")").collect(Collectors.toList()));

        return violations;

    }

    private Object safeGet(Field field, Object object) {
        try {
            return field.get(object);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    private List<Field> collectFields(Class<?> clazz) {
        List<Field> fields = new ArrayList<>(Arrays.asList(clazz.getDeclaredFields()));
        if (clazz.getSuperclass().getPackage().getName().startsWith("com.natwest")) {
            fields.addAll(collectFields(clazz.getSuperclass()));
        }
        return fields;
    }

}
