package com.natwest.pbbdhb.fma.controller;

import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.fma.enums.ApplicationType;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.service.FmaSubmissionService;
import com.natwest.pbbdhb.fma.util.JsonUtils;
import com.natwest.pbbdhb.fma.util.SwaggerUtils;
import com.natwest.pbbdhb.fma.validator.conditional.SmartConditionalRoot;
import com.natwest.pbbdhb.fma.validator.conditional.SmartConditionalValidator;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import jakarta.validation.Constraint;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = FmaSubmissionController.class)
@Import(ObjectMapperTestConfiguration.class)
class FmaSubmissionValidationTest {

    private static final String NEW_LINE = "\n";

    private static Map<Annotation, String> smartAnnotationsIndex = new IdentityHashMap<>();

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FmaSubmissionService fmaSubmissionService;

    @MockBean
    private ExecutionContext executionContext;

    @BeforeAll
    static void indexSmartValidations() {
        indexSmartValidations(Application.class);
        SmartConditionalValidator.enableTesting();
    }

    static private void indexSmartValidations(Class<?> clazz) {
        addAnnotationsToIndex(getAnnotations(SmartValidation.class, clazz), clazz.getName());
        if (clazz.getSuperclass().getPackage().getName().startsWith("com.natwest.pbbdhb.fma.model")) {
            indexSmartValidations(clazz.getSuperclass());
        }
        for (Field field : clazz.getDeclaredFields()) {
            addAnnotationsToIndex(getAnnotations(SmartValidation.class, field), clazz.getName() + "." + field.getName());
            addAnnotationsToIndex(getAnnotations(SmartRequired.class, field), clazz.getName() + "." + field.getName());
            Class<?> fieldClass = SwaggerUtils.extractFieldClassType(field);
            if (fieldClass != null && !fieldClass.isEnum() && fieldClass.getPackage().getName().startsWith("com.natwest.pbbdhb.fma.model")) {
                indexSmartValidations(fieldClass);
            }
        }
    }

    private static <T extends Annotation> List<T> getAnnotations(Class<T> annotationType, Class<?> clazz) {
        List<T> result = new ArrayList<>(Arrays.asList(clazz.getAnnotationsByType(annotationType)));
        for (Annotation classAnnotation : clazz.getDeclaredAnnotations()) {
            result.addAll(Arrays.asList(classAnnotation.annotationType().getAnnotationsByType(annotationType)));
        }
        return result;
    }

    private static <T extends Annotation> List<T> getAnnotations(Class<T> annotationType, Field field) {
        List<T> result = new ArrayList<>(Arrays.asList(field.getAnnotationsByType(annotationType)));
        for (Annotation fieldAnnotation : field.getDeclaredAnnotations()) {
            result.addAll(Arrays.asList(fieldAnnotation.annotationType().getAnnotationsByType(annotationType)));
        }
        return result;
    }

    static private <T extends Annotation> void addAnnotationsToIndex(List<T> annotations, String path) {
        if (annotations == null) {
            return;
        }
        smartAnnotationsIndex.putAll(annotations.stream()
                .collect(Collectors.toMap(Function.identity(), k -> path)));
    }

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(fmaSubmissionService.performFmaSubmission(any(Application.class), anyString(), anyString()))
                .thenReturn(new FmaResponse());
    }

    @DisplayName("Test Valid Requests Integrity")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | {}",
            "BUY_TO_LET | {}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testValidRequestIntegrity(ApplicationType applicationType,String requestMutator) throws Exception {
    	 String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE));
    }

    @DisplayName("Test No Javax Constraints")
    @Test
    void testNoJavaxConstraints() throws Exception {
        noJavaxConstraintsInClass(Application.class, new HashSet<>());
    }

    private void noJavaxConstraintsInClass(Class<?> clazz, Set<Class<?>> visited) {
        if (clazz == null || visited.contains(clazz)
                || clazz.getPackage() == null || !clazz.getPackage().getName().startsWith("com.natwest")) {
            return;
        }
        visited.add(clazz);

        Class<?> classChain = clazz;
        while (classChain.getPackage().getName().startsWith("com.natwest")) {

            Class<? extends Annotation> javaxValidatorAnnotation = Stream.concat(
                    Stream.of(classChain.getAnnotations()),
                            Stream.of(classChain.getDeclaredFields()).flatMap(field -> Stream.of(field.getAnnotations()))
                    )
                    .map(Annotation::annotationType)
                    .filter(annotation -> !SmartConditionalRoot.class.equals(annotation))
                    .filter(annotation -> annotation.getPackage().getName().startsWith("com.natwest"))
                    .filter(annotation -> annotation.getAnnotation(Constraint.class) != null)
                    .findFirst()
                    .orElse(null);

            if (javaxValidatorAnnotation != null) {
                throw new AssertionError("Javax constraint @" + javaxValidatorAnnotation.getSimpleName() +
                        " is used in class " + classChain.getName() + ". Please use @SmartValidation or @SmartRequired instead." +
                        " Look into javadoc of @SmartValidation and @SmartRequired files for details.");
            }

            for (Field field : clazz.getDeclaredFields()) {
                noJavaxConstraintsInClass(field.getType(), visited);
            }

            classChain = classChain.getSuperclass();
        }
    }

    @DisplayName("Test Broker Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"broker.consentToFMA has to be true to proceed\"] | { \"broker\" : { \"consentToFMA\" : false }}",
            "RESIDENTIAL | [\"broker.brokerPostcode must be valid UK postcode\"] | { \"broker\" : { \"brokerPostcode\" : \"123\" }}"
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testBrokerSectionRelatedValidation(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test Applicant Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[0].consentToFMA has to be true to proceed\"] | { \"applicants\" : [{ \"consentToFMA\" : false }]}",
            "RESIDENTIAL | [\"applicants atmost one applicant required to have mainApplicant as true\"] | { \"applicants\" : [{}, { \"mainApplicant\" : true }]}",
            "RESIDENTIAL | [\"applicants atmost one applicant required to have mainApplicant as true\"] | { \"applicants\" : [{\"mainApplicant\" : true}, { \"mainApplicant\" : true }]}",
            "RESIDENTIAL | [\"applicants[1].existingMortgage required if current address has occupyStatus = OWNER_MORTGAGED\"] | { \"applicants\" : [{}, { \"existingMortgage\" : null, \"addresses\" : [{ \"isCurrentAddress\": true , \"occupyStatus\" : \"OWNER_MORTGAGED\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].existingMortgage must be empty if current address has occupyStatus other than OWNER_MORTGAGED\"] | { \"applicants\" : [{ \"addresses\" : [{ \"occupyStatus\" : \"LIVING_WITH_RELATIVES\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].intendedRetirementAge should be at least current age\"] | { \"applicants\" : [{ \"intendedRetirementAge\" : 20 }]}",
            "RESIDENTIAL | [\"applicants[0].addresses must have exactly 1 current address\"] | { \"applicants\" : [{ \"addresses\" : [{ \"isCurrentAddress\" : true }, { \"isCurrentAddress\" : true }]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses at least one ukAddress should be true\"] | { \"applicants\" : [{ \"addresses\" : [{ \"ukAddress\" : false, \"countryIsoCode\" : \"US\"}], \"personalDetails\" : {\"rightToReside\": false, \"nationality\" : \"US\"}}]}",
            "RESIDENTIAL | [\"applicants[0].personalDetails.lastName size must be between 2 and 25\"] | { \"applicants\" : [{ \"personalDetails\" : {\"lastName\": \"awsqedrftgyhujikolp zxcvbnmqw\"}}]}",
            "RESIDENTIAL | [\"applicants[0].personalDetails.lastName size must be between 2 and 25\"] | { \"applicants\" : [{ \"personalDetails\" : {\"lastName\": \"a\"}}]}",
            "RESIDENTIAL | [\"applicants[0].intendedRetirementAge field is required\"] | { \"applicants\" : [{ \"workStatus\" : \"WORKING\", \"intendedRetirementAge\" : null }]}",
            "RESIDENTIAL | [\"applicants[0].addresses must have exactly 1 current address\"] | { \"applicants\" : [{ \"addresses\" : [{ \"isCurrentAddress\" : true }, { \"isCurrentAddress\" : true }]}]}",
            "RESIDENTIAL | [\"applicants[0].futureAffordability required if application type is RESIDENTIAL\"] | {\"applicants\" : [{ \"futureAffordability\" : null }]}",
            "RESIDENTIAL | [\"applicants[0].marketingPreferences is required when newToBank is true\"] | {\"applicants\" : [{ \"newToBank\":true,\"marketingPreferences\":null}]}",
            "RESIDENTIAL | [\"applicants[0].marketingPreferences should not be true if newToBank is false\"] | {\"applicants\" : [{ \"newToBank\":false,\"marketingPreferences\":{\"email\":false,\"text\":false,\"telephone\":false,\"post\":true}}]}",
}, delimiter = '|', maxCharsPerColumn = 10000)
    void testApplicantSectionValidation(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));

    }

    @DisplayName("Test Mortgage Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"mortgage.mortgageTermMonths must be less than or equal to 11\"] | { \"mortgage\" : { \"mortgageTermMonths\" : 12 }}",
            "BUY_TO_LET  | [\"mortgage.buyToLet field is required\"] | { \"mortgage\" : { \"buyToLet\" : null }}",
            "BUY_TO_LET  | [\"mortgage.buyToLet.monthlyRentalIncome must be less than or equal to 8000000\"] | { \"mortgage\" : { \"buyToLet\" : {\"monthlyRentalIncome\" : 8000001}}}",
            "BUY_TO_LET  | [\"mortgage.otherProperties[0].monthlyRentalIncome must be less than or equal to 8000000\"] | { \"mortgage\" : { \"otherProperties\" :[{ \"monthlyRentalIncome\" : 8000001}]}}",
            "BUY_TO_LET  | [\"mortgage.otherProperties maximum allowed properties is 14\"] | { \"mortgage\" : { \"otherProperties\" :[{\"interestOnlyAmount\":250000,\"outstandingMortgageBalance\":250000,\"monthlyMortgagePayment\":1000,\"remainingMortgageTermMonths\":7,\"remainingMortgageTermYears\":15,\"monthlyRentalIncome\":1000,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"RESIDENTIAL\",\"ownership\":\"APPLICANT_ONE\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1000,\"address\":{\"flat\":\"1\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"101\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":3,\"propertyNotes\":\"SomeRedemptionNotes\",\"purchasePrice\":250000,\"useLettingAgent\":true},{\"interestOnlyAmount\":250001,\"outstandingMortgageBalance\":250001,\"monthlyMortgagePayment\":1001,\"remainingMortgageTermMonths\":8,\"remainingMortgageTermYears\":16,\"monthlyRentalIncome\":1001,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1001,\"address\":{\"flat\":\"2\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"102\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-02\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":2,\"propertyNotes\":\"SomeRedemptionNotes2\",\"purchasePrice\":250001,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false}]}}",
            "RESIDENTIAL | [\"mortgage.otherProperties maximum allowed properties is 15\"] | { \"mortgage\" : { \"otherProperties\" :[{\"interestOnlyAmount\":250000,\"outstandingMortgageBalance\":250000,\"monthlyMortgagePayment\":1000,\"remainingMortgageTermMonths\":7,\"remainingMortgageTermYears\":15,\"monthlyRentalIncome\":1000,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"RESIDENTIAL\",\"ownership\":\"APPLICANT_ONE\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1000,\"address\":{\"flat\":\"1\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"101\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":3,\"propertyNotes\":\"SomeRedemptionNotes\",\"purchasePrice\":250000,\"useLettingAgent\":true},{\"interestOnlyAmount\":250001,\"outstandingMortgageBalance\":250001,\"monthlyMortgagePayment\":1001,\"remainingMortgageTermMonths\":8,\"remainingMortgageTermYears\":16,\"monthlyRentalIncome\":1001,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1001,\"address\":{\"flat\":\"2\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"102\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-02\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":2,\"propertyNotes\":\"SomeRedemptionNotes2\",\"purchasePrice\":250001,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false},{\"interestOnlyAmount\":250002,\"outstandingMortgageBalance\":250002,\"monthlyMortgagePayment\":1002,\"remainingMortgageTermMonths\":6,\"remainingMortgageTermYears\":14,\"monthlyRentalIncome\":1002,\"propertyRedemption\":false,\"mortgageRepaymentType\":\"REPAYMENT\",\"propertyUsage\":\"BUY_TO_LET\",\"ownership\":\"APPLICANT_TWO\",\"ownershipType\":\"HELD_RBSG\",\"estimatedPropertyValue\":1002,\"address\":{\"flat\":\"3\",\"houseName\":\"bob'shouse\",\"houseNumber\":\"103\",\"street\":\"regentstreet\",\"district\":\"redbridge\",\"town\":\"london\",\"county\":\"essex\",\"postcode\":\"E11 2NB\",\"countryIsoCode\":\"GB\"},\"propertyType\":\"HOUSE_NEW_BUILD\",\"datePurchased\":\"2000-01-01\",\"lenderName\":\"LenderOne\",\"numberBedrooms\":4,\"propertyNotes\":\"SomeRedemptionNotes3\",\"purchasePrice\":250002,\"useLettingAgent\":false}]}}",
            "RESIDENTIAL | [\"mortgage.mortgageAmount should be equal to sum of additionalBorrowings amount + outstandingMortgage\"] | {\"loanPurpose\" : \"REMORTGAGE\", \"mortgage\" : { \"mortgageAmount\" : 123 }}",
            "RESIDENTIAL | [\"mortgage.deposits field is required\"] | {\"loanPurpose\" : \"HOUSE_PURCHASE\" , \"mortgage\" : { \"deposits\" : null }}",
            "RESIDENTIAL | [\"mortgage.interestOnly field is required\"] | {\"mortgage\" : { \"interestOnly\" : null , \"mortgageType\" : \"MIXED\" }}",
            "RESIDENTIAL | [\"mortgage.mortgagePrisoner field is required\"] | {\"loanPurpose\" : \"REMORTGAGE\" , \"levelOfService\" : \"ADVISED\" , \"mortgage\" : { \"mortgagePrisoner\" : null }}",
            "RESIDENTIAL | [\"mortgage.outstandingMortgage field is required\"] | {\"loanPurpose\" : \"REMORTGAGE\" , \"mortgage\" : { \"outstandingMortgage\" : null , \"mortgageAmount\" : 20000 }}}",
            "RESIDENTIAL | [\"mortgage.propertyValue field is required\"] | {\"loanPurpose\" : \"HOUSE_PURCHASE\" , \"mortgage\" : { \"propertyValue\" : null }}",
            "RESIDENTIAL | [\"mortgage.purchasePrice field is required\"] | {\"loanPurpose\" : \"HOUSE_PURCHASE\" , \"mortgage\" : { \"purchasePrice\" : null }}",
    }, delimiter = '|', maxCharsPerColumn = 100000)
    void testMortgageSectionValidation(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));

    }
    
    @DisplayName("Test Self Employed Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.employeeShare must be a percentage with up to 2 decimal places\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"employeeShare\" : 75.9999 }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.previousTradingYear field is required\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"netProfitPrevious\" : 75 }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.previousTradingYear field is required\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"businessType\" : \"LIMITED_COMPANY\", \"drawingsPrevious\" : 75,  \"drawingsLatest\" : 75 }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.latestTradingYear must be greater than previousTradingYear\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : {  \"latestTradingYear\" : 2021,  \"previousTradingYear\" : 2021 }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.previousTradingYear field is required\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"businessType\" : \"LIMITED_COMPANY\", \"dividendsPrevious\" : 75, \"drawingsLatest\" : 75  }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.drawingsLatest field is required\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"drawingsLatest\" : null , \"businessType\" : \"LIMITED_COMPANY\" }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.employeeShare field is required\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"employeeShare\" : null , \"ownShare\" : true }}]}]}",
            "RESIDENTIAL | [\"applicants[1].employments[0].selfEmployed.netProfitLatest field is required\"] | { \"applicants\" : [{}, { \"employments\" : [{ \"selfEmployed\" : { \"netProfitLatest\" : null , \"businessType\" : \"PARTNERSHIP\" }}]}]}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testSelfEmployedSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));

    }

    @DisplayName("Test credit card Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[1].creditCards[0].otherProvider required when provider is other\"] | { \"applicants\" : [{}, { \"creditCards\" : [{ \"provider\" : \"OTHER\"}]}]}",
            "RESIDENTIAL | [\"applicants[0].creditCards[0].partialRefinanced required when debtConsolidation is true and toBeRepaid is false\"] | { \"applicants\" : [{ \"creditCards\" : [{ \"toBeRepaid\" : false , \"debtConsolidation\" : true }]}], \"mortgage\" : { \"additionalBorrowings\" : [{ \"amount\" : 500 , \"reason\" : \"DEBT_CONSOLIDATION\" }]}, \"levelOfService\" : \"ADVISED\" }",
            "RESIDENTIAL | [\"applicants[0].creditCards[0].partialRefinanced should be less or equal to totalBalance\"] | { \"applicants\" : [{ \"creditCards\" : [{ \"totalBalance\" : 100 , \"toBeRepaid\" : false , \"debtConsolidation\" : true , \"partialRefinanced\" : 10000 }]}], \"mortgage\" : { \"additionalBorrowings\" : [{ \"reason\" : \"DEBT_CONSOLIDATION\" }]}, \"levelOfService\" : \"ADVISED\" }",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testCreditCardSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test loan Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[1].loans[0].otherProvider required when provider is other\"] | { \"applicants\" : [{}, { \"loans\" : [{ \"provider\" : \"OTHER\"}]}]}", }, delimiter = '|', maxCharsPerColumn = 10000)
    void testLoanSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test application Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"currencyExchangeRate is required if repayMortgageCurrencyNotSterling is true\"] |  { \"repayMortgageCurrencyNotSterling\" : true, \"repayMortgageCurrency\" : \"USD\" }",
            "RESIDENTIAL | [\"repayMortgageCurrency required when repayMortgageCurrencyNotSterling is true\"] |   { \"repayMortgageCurrencyNotSterling\" : true, \"currencyExchangeRate\" : 0.8 }",
            "RESIDENTIAL | [\"repayMortgageCurrency has invalid currency value\"] |  { \"repayMortgageCurrencyNotSterling\" : true, \"repayMortgageCurrency\" : \"ABC\",\"currencyExchangeRate\" : 0.8 }",
            "RESIDENTIAL | [\"repayMortgageCurrency has invalid currency value\"] |  { \"repayMortgageCurrencyNotSterling\" : true, \"repayMortgageCurrency\" : \"GBP\",\"currencyExchangeRate\" : 0.8 }",
            "RESIDENTIAL | [\"repayMortgageCurrency has invalid currency value\"] |  { \"repayMortgageCurrencyNotSterling\" : true, \"repayMortgageCurrency\" : \"usd\",\"currencyExchangeRate\" : 0.8 }",
            "RESIDENTIAL | [\"currencyExchangeRate should be greater then 0 if repayMortgageCurrencyNotSterling = true\"] |  { \"repayMortgageCurrencyNotSterling\" : true, \"repayMortgageCurrency\" : \"USD\",\"currencyExchangeRate\" : 0 }",
            "RESIDENTIAL | [\"currencyExchangeRate numeric value out of bounds (<3 digits>.<2 digits> expected)\"] |  { \"repayMortgageCurrencyNotSterling\" : true, \"repayMortgageCurrency\" : \"USD\",\"currencyExchangeRate\" : 100.222 }",
            "RESIDENTIAL | [\"mainResidence must be true if govtSharedEquityScheme = true\"] | { \"govtSharedEquityScheme\" : true, \"mainResidence\" : false }",
            "RESIDENTIAL | [\"schemeName is required if Government Shared Equity Scheme is true and Scheme Type is OTHER\"] | { \"schemeName\" : null, \"govtSharedEquityScheme\" : true , \"schemeType\" : \"OTHER\" }",
            "RESIDENTIAL | [\"schemeType is required if Government Shared Equity Scheme is true\"] | { \"govtSharedEquityScheme\" : true , \"schemeType\" : null }",
            "RESIDENTIAL | [\"solicitor required if loanPurpose = HOUSE_PURCHASE\"] | { \"solicitor\" : null , \"loanPurpose\" : \"HOUSE_PURCHASE\" }",
            "RESIDENTIAL | [\"solicitor required if loanPurpose = REMORTGAGE AND mortgageAmount >= to 2M\"] | { \"solicitor\" : null , \"loanPurpose\" : \"REMORTGAGE\" , \"mortgage\" : { \"mortgageAmount\" : 2000000 , \"outstandingMortgage\" : 1980000 }}",
            "RESIDENTIAL | [\"transcriptValuer is required if loanPurpose is HOUSE_PURCHASE and scottishApplication is true\"] | { \"transcriptValuer\" : null, \"loanPurpose\" : \"HOUSE_PURCHASE\" , \"scottishApplication\" : true , \"property\" : { \"address\" : { \"postcode\" : \"HS3A 7ZW\" }}}",
            "RESIDENTIAL | [\"transcriptValuationDate is required if loanPurpose is HOUSE_PURCHASE and scottishApplication is true\"] | { \"transcriptValuationDate\" : null , \"loanPurpose\" : \"HOUSE_PURCHASE\" , \"scottishApplication\" : true , \"property\" : { \"address\" : { \"postcode\" : \"HS3A 7ZW\" }}}",
            "RESIDENTIAL | [\"levelOfService must be ADVISED when additionalBorrowing.reason is DEBT_CONSOLIDATION\"] | { \"applicants\" : [{ \"creditCards\" : [{},{ \"totalBalance\" : 10000 }]}], \"mortgage\" : { \"additionalBorrowings\" : [{ \"reason\" : \"DEBT_CONSOLIDATION\" }]}}",
            "RESIDENTIAL | [\"levelOfService must be ADVISED when mortgage.rightToBuy is true\"] | { \"levelOfService\" : \"NON_ADVISED\" , \"mortgage\" : {\"rightToBuy\": true }}",
            "RESIDENTIAL | [\"levelOfService must be ADVISED when mortgage.mortgageType is INTEREST_ONLY\"] | { \"levelOfService\" : \"NON_ADVISED\" , \"mortgage\" : {\"mortgageType\": \"INTEREST_ONLY\" }}",
            "RESIDENTIAL | [\"Both scottishApplication and northernIrelandApplication cannot be true\"] | { \"scottishApplication\" : true , \"northernIrelandApplication\" : true , \"property\" : { \"address\" : { \"postcode\" : \"EH22 3NX\" }}}",
            "BUY_TO_LET  | [\"levelOfService must be NON_ADVISED for Buy to Let application\"] | { \"levelOfService\" : \"ADVISED\" }",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testApplicationSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test Property Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"property.whenBuilt should be current calendar year date\"] | { \"property\" : { \"whenBuilt\" : \"2000-01-01\", \"type\" : \"HOUSE_NEW_BUY\" } }",
            "RESIDENTIAL | [\"property.type should be one of BUNGALOW_NEW_BUILD, HOUSE_NEW_BUILD, HOUSE_NEW_BUY, FLAT_NEW_BUILD, FLAT_NEW_BUY\"] | { \"property\" : { \"type\" : \"HOUSE_DETACHED\", \"builderIncentive\" : 10000 } }",
            "RESIDENTIAL | [\"property.remainingLeasehold field is required\"] | { \"property\" : { \"remainingLeasehold\" : null, \"tenure\" : \"LEASEHOLD\" }}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testPropertySection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test interestOnly Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"mortgage.interestOnly.repaymentDetails should not contains more than one object with repaymentStrategyType = MAIN_RESIDENCE\"] | { \"mortgage\" : { \"interestOnly\" : { \"repaymentDetails\" : [{ \"repaymentStrategyType\" : \"MAIN_RESIDENCE\"}, { \"repaymentStrategyType\" : \"MAIN_RESIDENCE\"}]}}}",
            "RESIDENTIAL | [\"mortgage.interestOnly.repaymentDetails should not contains more than one object with repaymentStrategyType = UNENCUMBERED_MAIN_RESIDENCE\"] | { \"mortgage\" : { \"interestOnly\" : { \"repaymentDetails\" : [{ \"repaymentStrategyType\" : \"UNENCUMBERED_MAIN_RESIDENCE\"}, { \"repaymentStrategyType\" : \"UNENCUMBERED_MAIN_RESIDENCE\"}]}}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testInterestOnlySection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test repaymentDetails Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"mortgage.interestOnly.repaymentDetails[0].repaymentStrategyType has invalid value for Residential application\"] | { \"mortgage\" : { \"interestOnly\" : { \"repaymentDetails\" : [{ \"repaymentStrategyType\" : \"SALE_OF_PROPERTY\" }]}}}",
            "BUY_TO_LET  | [\"mortgage.interestOnly.repaymentDetails[0].repaymentStrategyType has invalid value for Buy to Let application\"] | { \"mortgage\" : { \"interestOnly\" : { \"repaymentDetails\" : [{ \"repaymentStrategyType\" : \"MAIN_RESIDENCE\" }]}}}",
            "RESIDENTIAL | [\"mortgage.interestOnly.repaymentDetails[0].repaymentMaturityDate required if mortgageType is INTEREST_ONLY or MIXED and repaymentStrategyType is STOCK_SHARES, UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT\"] | { \"mortgage\" : { \"mortgageType\" : \"MIXED\" , \"interestOnly\" : { \"repaymentDetails\" : [{ \"repaymentStrategyType\" : \"SAVING\" , \"repaymentMaturityDate\" : null }]}}}",
            "RESIDENTIAL | [\"mortgage.interestOnly.repaymentDetails[0].repaymentProvider required if mortgageType is INTEREST_ONLY or MIXED and repaymentStrategyType is STOCK_SHARES, UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT\"] | { \"mortgage\" : { \"mortgageType\" : \"MIXED\" , \"interestOnly\" : { \"repaymentDetails\" : [{ \"repaymentStrategyType\" : \"SAVING\" , \"repaymentProvider\" : null }]}}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testRepaymentDetailsSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test address Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[0].addresses[0].postcode must be valid UK postcode\"] | { \"applicants\" : [{ \"addresses\" : [{ \"countryIsoCode\" : \"GB\", \"postcode\" : \"123\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses[0].currentPropertyValue field is required\"] | { \"applicants\" : [{ \"addresses\" : [{ \"currentPropertyValue\" : null }]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses[1].postcode size must be between 0 and 12\"] | { \"applicants\" : [{ \"addresses\" : [{}, { \"countryIsoCode\" : \"US\", \"postcode\" : \"1234567890123\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].address.postcode size must be between 0 and 12\"] | { \"applicants\" : [{ \"employments\" : [{ \"address\" : { \"countryIsoCode\" : \"US\", \"postcode\" : \"1234567890123\" }}]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses[1].countryIsoCode has invalid country iso code value\"] | { \"applicants\" : [{ \"addresses\" : [{}, { \"countryIsoCode\" : \"XX\" }]}]}",
            "RESIDENTIAL | [\"property.address.countryIsoCode must be GB\"] | { \"property\" : { \"address\" : { \"countryIsoCode\" : \"US\" }}}",
            "RESIDENTIAL | [\"applicants[0].addresses[0].countryIsoCode must be GB if ukAddress is true\"] | { \"applicants\" : [{ \"addresses\" : [{ \"ukAddress\" : true, \"countryIsoCode\" : \"US\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses[1].countryIsoCode cannot be GB if ukAddress is false\"] | { \"applicants\" : [{ \"addresses\" : [{}, { \"ukAddress\" : false, \"countryIsoCode\" : \"GB\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses period at address must be between 0 to 99 years\"] | { \"applicants\" : [{ \"addresses\" : [{\"startYear\" : 1900}, {\"startYear\" : 2100}]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses minimum 3 years addresses required\"] | { \"applicants\" : [{ \"addresses\" : [{\"startYear\" : 2040}, {\"startYear\" : 2040}]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses[0] one of the fields flat/houseNumber/houseName is mandatory\"] | { \"applicants\" : [{ \"addresses\" : [{ \"flat\" : null, \"houseName\" : null, \"houseNumber\" : null }]}]}",
            "RESIDENTIAL | [\"applicants[0].addresses[0].postcode is required if countryIsoCode is GB\"] | { \"applicants\" : [{ \"addresses\" : [{ \"postcode\" : null, \"countryIsoCode\" : \"GB\" }]}]}",
            "RESIDENTIAL | [\"property.address.postcode must be valid UK postcode\"] | {\"scottishApplication\" : false , \"property\" : { \"address\" : { \"postcode\" : \"XXX\" }}}",
            "RESIDENTIAL | [\"property.address.postcode must be valid Scotland postcode\"] | {\"scottishApplication\" : true , \"property\" : { \"address\" : { \"postcode\" : \"XXX\" }}}",
            "RESIDENTIAL | [\"property.address.postcode Address must be a valid Northern Ireland address\"] | {\"northernIrelandApplication\" : true , \"property\" : { \"address\" : { \"postcode\" : \"XXX\" }}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testAddressSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test additionalBorrowings Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"mortgage.additionalBorrowings[0].borrowingDetails field is required\"] | { \"mortgage\" : {\"additionalBorrowings\": [{ \"reason\" : \"OTHER\", \"borrowingDetails\" : null }]}}",
            "RESIDENTIAL | [\"mortgage.additionalBorrowings[0].adboRepaymentType field is required\"] | { \"mortgage\" : {\"mortgageType\" : \"MIXED\", \"additionalBorrowings\": [{ \"adboRepaymentType\" : null }]}}",
            "RESIDENTIAL | [\"Total amount of loans and credit cards being consolidated should be equal to the amount of additional borrowings for debt consolidation\"] | { \"applicants\" : [{ \"creditCards\" : [{ \"debtConsolidation\" : true }]}]}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testAdditionalBorrowingsSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test creditHistory Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[0].creditHistory.bankruptDetails field is required\"] | { \"applicants\" : [{ \"creditHistory\" : { \"bankruptDetails\" : null , \"bankrupt\" : true }}]}",
            "RESIDENTIAL | [\"applicants[0].creditHistory.bankruptcyDate field is required\"] | { \"applicants\" : [{ \"creditHistory\" : { \"bankruptcyDate\" : null , \"bankrupt\" : true , \"bankruptDetails\" : \"some details\" }}]}",
            "RESIDENTIAL | [\"applicants[0].creditHistory.courtProceedingDetails field is required\"] | { \"applicants\" : [{ \"creditHistory\" : { \"courtProceedingDetails\" : null , \"courtProceedings\" : true }}]}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testCreditHistorySection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test deposits Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"mortgage.deposits[0].details is required if type is OTHER_SAVINGS\"] | { \"mortgage\" : { \"deposits\" : [{ \"details\" : null , \"type\" : \"OTHER_SAVINGS\" }]}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testDepositsSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test employments Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[0].employments[0].endDate field is required\"] | { \"applicants\" : [{ \"employments\" : [{ \"endDate\" : null, \"employmentStatus\" : \"EMPLOYED\", \"employmentType\" : \"CONTRACT\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].incomes field is required\"] | { \"applicants\" : [{ \"employments\" : [{ \"incomes\" : null, \"employmentStatus\" : \"EMPLOYED\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].selfEmployed field is required\"] | { \"applicants\" : [{ \"employments\" : [{ \"selfEmployed\" : null, \"employmentStatus\" : \"SELF_EMPLOYED\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].startDate field is required\"] | { \"applicants\" : [{ \"employments\" : [{ \"startDate\" : null, \"employmentStatus\" : \"EMPLOYED\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments one current employment should be primary\"] | { \"applicants\" : [{ \"employments\" : [{ \"primary\" : true }, { \"primary\" : true }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].industryType required if employmentStatus is EMPLOYED or SELF_EMPLOYED\"] | { \"applicants\" : [{ \"employments\" : [{ \"employmentStatus\" : \"EMPLOYED\" , \"industryType\" : null }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].employerName required if employmentStatus is EMPLOYED or SELF_EMPLOYED\"] | { \"applicants\" : [{ \"employments\" : [{ \"employmentStatus\" : \"EMPLOYED\" , \"employerName\" : null }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[1].address required if employmentStatus is EMPLOYED or SELF_EMPLOYED\"] | { \"applicants\" : [{ \"employments\" : [{}, { \"employmentStatus\" : \"EMPLOYED\" , \"address\" : null }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].endDate cannot be provided for employmentType other than CONTRACT if primary is true\"] | { \"applicants\" : [{ \"employments\" : [{ \"employmentStatus\" : \"EMPLOYED\" , \"primary\" : \"true\" , \"employmentType\" : \"PERMANENT\" , \"endDate\" : \"2030-01-01\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[1].endDate should be in the future for employmentType CONTRACT if primary is true\"] | { \"applicants\" : [{ \"employments\" : [{ \"primary\" : \"false\" , \"endDate\" : \"2010-01-01\" }, { \"employmentStatus\" : \"EMPLOYED\" , \"primary\" : \"true\" , \"employmentType\" : \"CONTRACT\" , \"endDate\" : \"2010-01-01\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].startDate cannot be in the future if primary is true\"] | { \"applicants\" : [{ \"employments\" : [{ \"primary\" : \"true\" , \"startDate\" : \"2040-01-01\" }]}]}",
            "RESIDENTIAL | [\"applicants[0].employments[0].selfEmployed.dateEstablished cannot be older than 99 years and 11 months\"] | { \"applicants\" : [{ \"employments\" : [{ \"selfEmployed\" : { \"businessType\": \"SOLE_TRADER\", \"dateEstablished\": \"1924-02-02\", \"latestTradingYear\": \"2024\",\"netProfitLatest\": 3400 }, \"employmentStatus\" : \"SELF_EMPLOYED\" }]}]}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testEmploymentsSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test personalDetails Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"applicants[1].personalDetails.otherTitle field is required\"] | { \"applicants\" : [{}, { \"personalDetails\" : {\"title\" : \"OTHER\"}, \"addresses\" : [{ \"occupyStatus\" : \"OWNER_MORTGAGED\"}]}]}",
            "RESIDENTIAL | [\"applicants[1].personalDetails.rightToReside field is required\"] | { \"applicants\" : [{}, { \"personalDetails\" : {\"rightToReside\" : null , \"nationality\" : \"US\" }}]}",
            "RESIDENTIAL | [\"applicants[1].personalDetails.rightToReside Right to reside cannot be false\"] | { \"applicants\" : [{}, { \"personalDetails\" : {\"rightToReside\" : false , \"nationality\" : \"GB\" }}]}",
            "RESIDENTIAL | [\"applicants[1].personalDetails.gender Gender must be provided as MALE or FEMALE for selected title\"] | { \"applicants\" : [{}, { \"personalDetails\" : {\"title\" :  \"NONE\" , \"gender\" :null }}]}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testPersonalDetailsSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test products Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"mortgage.products[0].portingNotes is required if isPortingProduct is true\"] | {\"mortgage\" : { \"mortgageTermMonths\" : 11,  \"products\" : [{ \"isPortingProduct\" : true}]}}",
            "RESIDENTIAL | [\"mortgage.products[0].valuationFeesPayType required if isPortingProduct is false or null\"] | { \"mortgage\" : { \"products\" : [{ \"isPortingProduct\" : false, \"valuationFeesPayType\" : null }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].productFeesPayType required if isPortingProduct is false or null\"] | { \"mortgage\" : { \"products\" : [{ \"isPortingProduct\" : false, \"productFeesPayType\" : null }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].chapsFeesPayType required if isPortingProduct is false or null\"] | { \"mortgage\" : { \"products\" : [{ \"isPortingProduct\" : false, \"chapsFeesPayType\" : null }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].ltv required if isPortingProduct is false or null\"] | { \"mortgage\" : { \"products\" : [{ \"isPortingProduct\" : false, \"ltv\" : null }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].ltv accepts up to two decimal places\"] | { \"mortgage\" : { \"products\" : [{ \"ltv\" : 50.123 }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].mortgageType required if isPortingProduct is false or null\"] | { \"mortgage\" : { \"products\" : [{ \"isPortingProduct\" : false, \"mortgageType\" : null }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].isPortingProduct mustn't be supplied if loanPurpose isn't HOUSE_PURCHASE\"] | { \"loanPurpose\" : \"REMORTGAGE\" , \"mortgage\" : { \"products\" : [{ \"isPortingProduct\" : false }]}}",
            "RESIDENTIAL | [\"mortgage.products[0].portingNotes mustn't be supplied if loanPurpose isn't HOUSE_PURCHASE\"] | { \"loanPurpose\" : \"REMORTGAGE\" , \"mortgage\" : { \"products\" : [{ \"portingNotes\" : \"Some Notes\" }]}}",
            }, delimiter = '|', maxCharsPerColumn = 10000)
    void testProductsSectionValidation(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test buyToLet Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "BUY_TO_LET | [\"mortgage.buyToLet.isAssuredShortHoldOrShortAssured is \\\"false\\\" therefore the application cannot proceed\"] | { \"mortgage\" : { \"buyToLet\" : { \"isAssuredShortHoldOrShortAssured\" : false }}}",
            "BUY_TO_LET | [\"mortgage.buyToLet.isForInvestment is \\\"false\\\" and indicates Consumer Buy to Let borrowing status which is not supported at this stage. The application cannot proceed.\"] | { \"mortgage\" : { \"buyToLet\" : { \"isForInvestment\" : false }}}",
            "BUY_TO_LET | [\"mortgage.buyToLet.isNotSelectiveLicenceOrHMO is \\\"false\\\" therefore the application cannot proceed\"] | { \"mortgage\" : { \"buyToLet\" : { \"isNotSelectiveLicenceOrHMO\" : false }}}",
            "BUY_TO_LET | [\"mortgage.buyToLet.isRentingToImmediateFamilyMember is \\\"true\\\" therefore application cannot proceed as a buy to let and must be progressed as a second residential purchase/remortgage\"] | { \"mortgage\" : { \"buyToLet\" : { \"isRentingToImmediateFamilyMember\" : true }}}",
            "BUY_TO_LET | [\"mortgage.buyToLet.lettingAgentCost required if useLettingAgent = true\"] | { \"mortgage\" : { \"buyToLet\" : { \"useLettingAgent\" : true , \"lettingAgentCost\" : null }}}",
            "BUY_TO_LET | [\"mortgage.buyToLet.portfolioLandlord required if loanPurpose = REMORTGAGE and 3 or more other/back ground properties where 'propertyUsage' = 'BUY_TO_LET' or 'CONSENT_TO_LET' and 'ownershipType' = 'HELD_RBSG' or 'HELD_ELSEWHERE' and propertyRedemption = false OR if loanPurpose = HOUSE_PURCHASE and 3 or more other/back ground properties where 'propertyUsage' = 'BUY_TO_LET' or 'CONSENT_TO_LET' and 'ownershipType' = 'HELD_RBSG' or 'HELD_ELSEWHERE' and propertyRedemption = false\"] | { \"loanPurpose\" : \"HOUSE_PURCHASE\" , \"mortgage\" : { \"otherProperties\" : [{ \"propertyUsage\" : \"CONSENT_TO_LET\" }] , \"buyToLet\" : { \"portfolioLandlord\" : null }}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testBuyToLetSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test otherProperties Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "BUY_TO_LET | [\"mortgage.otherProperties[0].useLettingAgent required if propertyUsage = CONSENT_TO_LET or BUY_TO_LET\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"propertyUsage\" : \"CONSENT_TO_LET\" , \"useLettingAgent\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].monthlyRentalIncome required if propertyUsage = BUY_TO_LET or CONSENT_TO_LET\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"propertyUsage\" : \"CONSENT_TO_LET\" , \"monthlyRentalIncome\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].interestOnlyAmount required if otherProperties.mortgageRepaymentType = MIXED\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"mortgageRepaymentType\" : \"MIXED\" , \"interestOnlyAmount\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].lenderName required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"lenderName\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].monthlyMortgagePayment required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"monthlyMortgagePayment\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].mortgageRepaymentType required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"mortgageRepaymentType\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].outstandingMortgageBalance required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"outstandingMortgageBalance\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].propertyRedemption required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"propertyRedemption\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].remainingMortgageTermMonths required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"remainingMortgageTermMonths\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].remainingMortgageTermYears required if ownershipType = HELD_RBSG or HELD_ELSEWHERE\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"ownershipType\" : \"HELD_ELSEWHERE\" , \"remainingMortgageTermYears\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].propertyNotes required if propertyRedemption = false\"] | { \"mortgage\" : { \"otherProperties\" : [{ \"propertyRedemption\" : false , \"propertyNotes\" : null }]}}",
            "BUY_TO_LET | [\"mortgage.otherProperties[0].ownership can't be APPLICANT_TWO or JOINT if there is only one applicant\"] | { \"applicants\" : [{}, null, null, null] , \"mortgage\" : { \"otherProperties\" : [{ \"ownership\" : \"APPLICANT_TWO\" }, null, null, null]}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testOtherPropertiesSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test portfolioLandlord Section")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "BUY_TO_LET | [\"mortgage.buyToLet.portfolioLandlord.extendNotes required if planToExtendIn5Years = true\"] | { \"mortgage\" : { \"buyToLet\" : { \"portfolioLandlord\" : { \"planToExtendIn5Years\" : true , \"extendNotes\" : null }}}}",
            "BUY_TO_LET | [\"mortgage.buyToLet.portfolioLandlord.sellNotes required if planToSellIn5Years = true\"] | { \"mortgage\" : { \"buyToLet\" : { \"portfolioLandlord\" : { \"planToSellIn5Years\" : true , \"sellNotes\" : null }}}}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testPortfolioLandlordSection(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @DisplayName("Test Pre-Deserialization Validators")
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
            "RESIDENTIAL | [\"transcriptValuationDate has incorrect format\"] | { \"transcriptValuationDate\" : \"abc\"}",
            "RESIDENTIAL | [\"scottishApplication permissible values are [true, false]\"] | { \"scottishApplication\" : \"abc\"}",
            "RESIDENTIAL | [\"type permissible values are [RESIDENTIAL, BUY_TO_LET]\"] | { \"type\" : \"abc\"}",
            "RESIDENTIAL | [\"numberOfDependantsOver18 is not integer\"] | { \"numberOfDependantsOver18\" : 0.5}",
            "RESIDENTIAL | [\"currencyExchangeRate is not a number\"] | { \"currencyExchangeRate\" : \"abc\"}",
    }, delimiter = '|', maxCharsPerColumn = 10000)
    void testPreDeserializationValidators(ApplicationType applicationType, String expectedValue, String requestMutator) throws Exception {
        String request = JsonUtils.getMutatedRequestJson(applicationType, requestMutator);
        this.mockMvc
                .perform(post("/full-mortgage-application").contentType(MediaType.APPLICATION_JSON)
                        .header("client_id", "7cad57a7-5991-0406-e053-0100007fad2f").header("brand", "nwb")
                        .content(request))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().string(containsString(expectedValue)));
    }

    @AfterAll
    static void testAllSmartValidationsFired() {
        smartAnnotationsIndex.keySet().removeAll(SmartConditionalValidator.getFiredAnnotationsForTest());

        if (!smartAnnotationsIndex.isEmpty()) {
            throw new AssertionError(NEW_LINE + smartAnnotationsIndex.entrySet().stream()
                    .map(e -> e.getValue() + " is annotated with @" +
                            e.getKey().annotationType().getSimpleName() + " but isn't tested")
                    .sorted()
                    .collect(Collectors.joining(NEW_LINE)));
        }
    }



}