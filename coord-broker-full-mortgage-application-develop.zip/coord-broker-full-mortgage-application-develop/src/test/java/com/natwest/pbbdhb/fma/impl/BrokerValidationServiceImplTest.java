package com.natwest.pbbdhb.fma.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.fma.context.ExecutionContext;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailRequest;
import com.natwest.pbbdhb.fma.model.brokervalidation.BrokerDetailResponse;
import com.natwest.pbbdhb.fma.service.BrokerValidationService;
import com.natwest.pbbdhb.fma.service.impl.BrokerValidationServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { BrokerValidationServiceImpl.class })
class BrokerValidationServiceImplTest {

    @Autowired
    private BrokerValidationService brokerValidationService;

    @Value("${broker.validation.endpoint}")
    private String endPointUrl;

    @MockBean
    @Qualifier("restTemplateForApi")
    private RestTemplate restTemplate;

    @MockBean
    private ObjectMapper objectMapper;

    @MockBean
    private ExecutionContext executionContext;

    @Test
    void testMakeBrokerValCallWithRequestAsMock() {
        BrokerDetailRequest brokerDetailRequest = mock(BrokerDetailRequest.class);
        BrokerDetailResponse brokerDetailResponse = mock(BrokerDetailResponse.class);
        when(restTemplate.postForObject(eq(endPointUrl), eq(brokerDetailRequest), eq(BrokerDetailResponse.class)))
                .thenReturn(brokerDetailResponse);
        brokerValidationService.validate(brokerDetailRequest);

        verify(restTemplate).postForObject(anyString(), eq(brokerDetailRequest), eq(BrokerDetailResponse.class));
    }

    @Test
    void testMakeBrokerValCallWithRequestAsObject() {
        BrokerDetailRequest brokerDetailRequest = new BrokerDetailRequest();
        BrokerDetailResponse brokerDetailResponse = new BrokerDetailResponse();
        when(restTemplate.postForObject(eq(endPointUrl), eq(brokerDetailRequest), eq(BrokerDetailResponse.class)))
                .thenReturn(brokerDetailResponse);
        brokerValidationService.validate(brokerDetailRequest);

        verify(restTemplate).postForObject(anyString(), eq(brokerDetailRequest), eq(BrokerDetailResponse.class));
    }
}