package com.natwest.pbbdhb.fma.mapper.applicant;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ApplicantMapperTest extends AbstractMapperTest {

    @Spy
    private final ExistingMortgageMapper existingMortgageMapper = new ExistingMortgageMapperImpl();
    @InjectMocks
    private ApplicantMapperImpl applicantMapper;

    @Test
    public void testFmaApplicantToMsvcApplicant() {
        FullMortgageApplicationRequest fmaRequest = loadInputModel("input/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);

        ApplicantDto msvcApplicant = applicantMapper.toCreateApplicant(fmaRequest.getApplicants().iterator().next(),
                fmaRequest.getApplication().getCaseId(), fmaRequest.getApplicants().size() == 1 ? true : null, true);

        assertOutputModelMatches("output/MsvcApplicant.json", msvcApplicant);
    }

}
