package com.natwest.pbbdhb.fma.mapper;

import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.openapi.fma.ResponseData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class FmaResponseMapperTest extends AbstractMapperTest {

    @InjectMocks
    private FmaResponseMapperImpl fmaResponseMapper;

  
    @ParameterizedTest(name = "value index = {index}, argument = {arguments}")
    @CsvSource(value = {
           
            "{ \"tempRefNo\" : null} | {\"tempReferenceNumber\" : null} | 201",
            "{} | {\"mortgageNumber\" : null} | 201",
            "{} | {\"mortgageNumber\" : null} | 202"
    		
         
    }, delimiter = '|', maxCharsPerColumn = 10000)
    public void testMsvcFmaResponseToFmaResponse(String inputMutator, String outputMutator, String status) {
        ResponseData responseData = loadInputModel("input/FullMortgageApplicationResponseData.json",
        		inputMutator,  ResponseData.class);

        FmaResponse fmaResponse = fmaResponseMapper.toFmaResponse(responseData,status);

        assertOutputModelMatches("output/FmaResponse.json",outputMutator, fmaResponse);
    }

}
