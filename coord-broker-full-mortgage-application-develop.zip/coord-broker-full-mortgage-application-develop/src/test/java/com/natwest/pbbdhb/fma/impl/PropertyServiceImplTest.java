package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.fma.service.PropertyService;
import com.natwest.pbbdhb.fma.service.impl.PropertyServiceImpl;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { PropertyServiceImpl.class })
public class PropertyServiceImplTest {
    @Autowired
    private PropertyService propertyService;

    @Value("${property.create.endpoint}")
    private String endPointUrl;

    @MockBean
    @Qualifier("restTemplateForApi")
    private RestTemplate restTemplate;

    @Test
    void testCreatePropertyWithValidRequest() {
        PropertyDetailsDto req = PropertyDetailsDto.builder().build();
        PropertyDetailsDto resp = PropertyDetailsDto.builder().build();
        when(restTemplate.postForObject(eq(endPointUrl), Mockito.any(HttpEntity.class), eq(PropertyDetailsDto.class)))
                .thenReturn(resp);
        propertyService.createProperty(req, "nwb");

        verify(restTemplate).postForObject(anyString(), Mockito.any(HttpEntity.class), eq(PropertyDetailsDto.class));
    }
}
