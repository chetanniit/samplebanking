package com.natwest.pbbdhb.fma.impl;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.fma.mapper.cases.CaseMapper;
import com.natwest.pbbdhb.fma.mapper.cases.HardscoreMapper;
import com.natwest.pbbdhb.fma.model.response.Decision;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.fma.model.response.HardScoreDecision;
import com.natwest.pbbdhb.fma.service.CapieUpdateService;
import com.natwest.pbbdhb.fma.service.CaseService;
import com.natwest.pbbdhb.fma.service.impl.CapieUpdateServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { CapieUpdateServiceImpl.class })
public class CapieUpdateServiceImplTest {
    @Autowired
    private CapieUpdateService capUpdateService;

    @MockBean
    private HardscoreMapper mapper;

    @MockBean
    private CaseService caseService;

    @MockBean
    private CaseMapper caseMapper;

    @Test
    public void testUpdateCAP_PostiveCase() {
        CaseApplicationDto application = new CaseApplicationDto();
        List<ApplicantDto> applicants = new ArrayList<>();
        ApplicantDto applicant = new ApplicantDto();
        applicant.setApplicantId("ABCD1234");
        applicants.add(applicant);

        FmaResponse response = FmaResponse.builder().tempReferenceNumber("24062022122544714VJRKPE")
                .hardscoreDecision(HardScoreDecision.builder().decision(Decision.REFER).build())
                .mortgageNumber("84081871").status("201").applSeq("01").build();
        Mockito.when(caseService.patch(eq("nwb"), eq("12345"), Mockito.any())).thenReturn(application);

        capUpdateService.updateCase(response, "nwb", "12345");

        verify(caseService, times(1)).patch(eq("nwb"), eq("12345"), anyList());
    }

    @Test
    public void testUpdateCAP_Exception() {
        CaseApplicationDto application = new CaseApplicationDto();

        List<ApplicantDto> applicants = new ArrayList<>();
        ApplicantDto applicant = new ApplicantDto();
        applicant.setApplicantId("ABCD1234");
        applicants.add(applicant);

        FmaResponse response = FmaResponse.builder().tempReferenceNumber("24062022122544714VJRKPE")
                .hardscoreDecision(HardScoreDecision.builder().decision(Decision.REFER).build())
                .mortgageNumber("84081871").status("201").build();
        Mockito.when(caseService.patch(eq("nwb"), eq("12345"), Mockito.any()))
                .thenThrow(new RestClientException("exception while connecting"));

        assertThrows(RestClientException.class, () -> capUpdateService.updateCase(response, "nwb", "12345"));

    }

}
