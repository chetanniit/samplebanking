package com.natwest.pbbdhb.fma.mapper.cases;

import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.fma.model.response.HardScoreDecision;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class HardScoreMapperTest extends AbstractMapperTest {

    @InjectMocks
    private HardscoreMapperImpl hardscoreMapper;

    @Test
    public void testHardScoreDecisionToCaseHardScoreDecision() {
        HardScoreDecision hardScoreDecision = loadInputModel("input/HardScoreDecision.json", HardScoreDecision.class);

        com.natwest.pbbdhb.openapi.fma.HardscoreDecision caseHardScoreDecision = hardscoreMapper
                .toHardScoreDecision(hardScoreDecision);

        assertOutputModelMatches("output/CaseHardScoreDecision.json", caseHardScoreDecision);
    }

}
