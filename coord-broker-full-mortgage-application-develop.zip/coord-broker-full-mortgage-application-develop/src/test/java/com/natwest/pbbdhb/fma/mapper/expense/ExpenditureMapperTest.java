package com.natwest.pbbdhb.fma.mapper.expense;

import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.openapi.fma.Applicant;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
public class ExpenditureMapperTest extends AbstractMapperTest {

    @Spy
    private final CreditCardMapper creditCardMapper = new CreditCardMapperImpl();
    @Spy
    private final LoanMapper loanMapper = new LoanMapperImpl();
    @Spy
    private final FinancialCommitmentMapper financialCommitmentMapper = new FinancialCommitmentMapperImpl();
    @InjectMocks
    private ExpenditureMapper expenditureMapper;

    @Test
    public void testFmaRequestToValidatedCaseExpense() {
        FullMortgageApplicationRequest fmaRequest = loadInputModel("input/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);

        ValidatedCaseExpenseDto validatedCaseExpense = expenditureMapper.convertToExpenseRequest(fmaRequest,
                getApplicantToIdMap(fmaRequest));

        assertOutputModelMatches("output/ValidatedCaseExpense.json", validatedCaseExpense);
    }

    private Map<Applicant, String> getApplicantToIdMap(FullMortgageApplicationRequest applicationRequest) {
        AtomicInteger id = new AtomicInteger(0);
        return applicationRequest.getApplicants().stream().collect(
                Collectors.toMap(a -> a, a -> String.valueOf(id.getAndIncrement()), (a, b) -> a, IdentityHashMap::new));
    }

}
