package com.natwest.pbbdhb.fma.swagger;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.serialization.LocalDateValidatingDeserializer;
import com.natwest.pbbdhb.fma.util.SwaggerUtils;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequired;
import com.natwest.pbbdhb.fma.validator.conditional.SmartRequiredMultiple;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidation;
import com.natwest.pbbdhb.fma.validator.conditional.SmartValidationMultiple;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.junit.jupiter.api.Test;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SwaggerCorrectnessTest {

    // change to Mode.DESCRIBE to get csv representation of the model
    private static final Mode mode = Mode.TEST;

    // Set for false-positive violations
    private static final Set<String> SUPPRESS = Stream.of(
            "broker.brokerEmail: pattern misaligned")
            .collect(Collectors.toCollection(HashSet::new));

    @Test
    public void testSwaggerCorrectness() {
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>();
        traverse(Application.class, "", fieldDescriptors);
        if (mode == Mode.TEST) {
            validate(fieldDescriptors);
        } else {
            describe(fieldDescriptors);
        }
    }

    private void validate(List<FieldDescriptor> fieldDescriptors) {
        Map<String, List<String>> errors = new HashMap<>();

        List<BiConsumer<Schema, FieldDescriptor>> schemaValidators = Arrays.asList((schema, descriptor) -> {
            if (Enum.class.isAssignableFrom(descriptor.getClazz())
                    && !Objects.equals(schema.implementation(), descriptor.getClazz())) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("implementation misaligned");
            }
        }, (schema, descriptor) -> {
            if (Enum.class.isAssignableFrom(descriptor.getClazz()) && StringUtils.isNotBlank(schema.example())
                    && !Arrays.stream((Enum[]) descriptor.getClazz().getEnumConstants())
                            .anyMatch(e -> e.name().equals(schema.example()))) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("example misaligned");
            }
        }, (schema, descriptor) -> {
            if (descriptor.getClazz().getPackage().getName().startsWith("com.natwest")
                    && !Enum.class.isAssignableFrom(descriptor.getClazz())
                    && descriptor.getAnnotation(Valid.class) == null) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("add @Valid");
            }
        }, (schema, descriptor) -> {
            if (descriptor.getArraySchema() != null) {
                return;
            }
            if (schema.required() && descriptor.getAnnotation(NotNull.class) == null
                    && descriptor.getAnnotation(NotBlank.class) == null
                    && descriptor.getAnnotation(NotEmpty.class) == null) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("required misaligned");
            } else if (!schema.required() && (descriptor.getAnnotation(NotNull.class) != null
                    || descriptor.getAnnotation(NotBlank.class) != null
                    || descriptor.getAnnotation(NotEmpty.class) != null)) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("required misaligned");
            }
        }, (schema, descriptor) -> {
            if (schema.multipleOf() != 0 && schema.multipleOf() <= 1
                    && descriptor.getAnnotation(Digits.class) == null) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("add @Digits");
            }
        }, (schema, descriptor) -> {
            if (descriptor.getArraySchema() != null) {
                return;
            }
            if (schema.minLength() != 0
                    && (descriptor.getAnnotation(Length.class) == null
                            || descriptor.getAnnotation(Length.class).min() != schema.minLength())
                    && (descriptor.getAnnotation(Size.class) == null
                            || descriptor.getAnnotation(Size.class).min() != schema.minLength())) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("minLength misaligned");
            } else if (descriptor.getAnnotation(Length.class) != null
                    && descriptor.getAnnotation(Length.class).min() != schema.minLength()
                    || descriptor.getAnnotation(Size.class) != null
                            && descriptor.getAnnotation(Size.class).min() != schema.minLength()) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("minLength misaligned");
            }
        }, (schema, descriptor) -> {
            if (descriptor.getArraySchema() != null) {
                return;
            }
            if (schema.maxLength() != Integer.MAX_VALUE
                    && (descriptor.getAnnotation(Length.class) == null
                            || descriptor.getAnnotation(Length.class).max() != schema.maxLength())
                    && (descriptor.getAnnotation(Size.class) == null
                            || descriptor.getAnnotation(Size.class).max() != schema.maxLength())) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("maxLength misaligned");
            } else if (descriptor.getAnnotation(Length.class) != null
                    && descriptor.getAnnotation(Length.class).max() != schema.maxLength()
                    || descriptor.getAnnotation(Size.class) != null
                            && descriptor.getAnnotation(Size.class).max() != schema.maxLength()) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("maxLength misaligned");
            }
        }, (schema, descriptor) -> {
            if (schema.pattern().length() > 0
                    && (descriptor.getAnnotation(JsonFormat.class) == null
                            || !schema.pattern().equals(descriptor.getAnnotation(JsonFormat.class).pattern()))
                    && (descriptor.getAnnotation(Pattern.class) == null
                            || !schema.pattern().equals(descriptor.getAnnotation(Pattern.class).regexp()))
                    && (descriptor.getAnnotation(Email.class) == null
                            || (!".*".equals(descriptor.getAnnotation(Email.class).regexp())
                                    && !schema.pattern().equals(descriptor.getAnnotation(Email.class).regexp())))) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("pattern misaligned");
            } else if (schema.pattern().length() == 0 && (descriptor.getAnnotation(JsonFormat.class) != null
                    || descriptor.getAnnotation(Pattern.class) != null
                    || descriptor.getAnnotation(Email.class) != null)) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("pattern misaligned");
            }
        }, (schema, descriptor) -> {
            if (schema.maximum().length() > 0
                    && (descriptor.getAnnotation(DecimalMax.class) == null
                            || !schema.maximum().equals(descriptor.getAnnotation(DecimalMax.class).value()))
                    && (descriptor.getAnnotation(Max.class) == null
                            || !schema.maximum().equals(String.valueOf(descriptor.getAnnotation(Max.class).value())))) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("maximum misaligned");
            } else if (schema.maximum().length() == 0 && (descriptor.getAnnotation(DecimalMax.class) != null
                    || descriptor.getAnnotation(Max.class) != null)) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("maximum misaligned");
            }
        }, (schema, descriptor) -> {
            if (schema.minimum().length() > 0
                    && (descriptor.getAnnotation(DecimalMin.class) == null
                            || !schema.minimum().equals(descriptor.getAnnotation(DecimalMin.class).value()))
                    && (descriptor.getAnnotation(Min.class) == null
                            || !schema.minimum().equals(String.valueOf(descriptor.getAnnotation(Min.class).value())))) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("minimum misaligned");
            } else if (schema.minimum().length() == 0 && (descriptor.getAnnotation(DecimalMin.class) != null
                    || descriptor.getAnnotation(Min.class) != null)) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("minimum misaligned");
            }
        }, (schema, descriptor) -> {
            if (Boolean.class.equals(descriptor.getClazz())
                    && !Arrays.equals(schema.allowableValues(), new String[] { "true", "false" })) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("allowableValues misaligned");
            }
        }, (schema, descriptor) -> {
            if (schema.required() && descriptor.getAnnotation(SmartRequired.class) != null) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("remove required");
            }
        }, (schema, descriptor) -> {
            if (LocalDate.class.equals(descriptor.getRawFieldType())
                    && (descriptor.getAnnotation(JsonDeserialize.class) == null
                    || !LocalDateValidatingDeserializer.class.equals(descriptor.getAnnotation(JsonDeserialize.class).using()))) {
                errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("invalid JsonDeserialize");
            }
        });

        List<BiConsumer<ArraySchema, FieldDescriptor>> arraySchemaValidators = Arrays.asList(

                (arraySchema, descriptor) -> {
                    if (arraySchema.schema() != null && arraySchema.schema().description().length() > 0) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add(
                                "description for an array field should be in arraySchema property instead of schema property");
                    }
                }, (arraySchema, descriptor) -> {
                    if (arraySchema.schema() == null
                            || !Objects.equals(arraySchema.schema().implementation(), descriptor.getClazz())) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>())
                                .add("implementation misaligned");
                    }
                }, (arraySchema, descriptor) -> {
                    if ((arraySchema.schema() != null && arraySchema.schema().required()
                            || arraySchema.arraySchema() != null && arraySchema.arraySchema().required())
                            && descriptor.getAnnotation(NotNull.class) == null) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("add @NotNull");
                    }
                }, (arraySchema, descriptor) -> {
                    if (arraySchema.minItems() > 0 && arraySchema.minItems() < Integer.MAX_VALUE
                            && (descriptor.getAnnotation(Size.class) == null
                                    || descriptor.getAnnotation(Size.class).min() != arraySchema.minItems())
                            && !(arraySchema.minItems() == 1 && arraySchema.maxItems() < 0
                                    && descriptor.getAnnotation(NotEmpty.class) != null)) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("minItems misaligned");
                    } else if (descriptor.getAnnotation(Size.class) != null
                            && descriptor.getAnnotation(Size.class).min() > 0
                            && descriptor.getAnnotation(Size.class).min() != arraySchema.minItems()) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("minItems misaligned");
                    }
                }, (arraySchema, descriptor) -> {
                    if (arraySchema.maxItems() > 0 && (descriptor.getAnnotation(Size.class) == null
                            || descriptor.getAnnotation(Size.class).max() != arraySchema.maxItems())) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("maxItems misaligned");
                    } else if (descriptor.getAnnotation(Size.class) != null
                            && descriptor.getAnnotation(Size.class).max() < Integer.MAX_VALUE
                            && descriptor.getAnnotation(Size.class).max() != arraySchema.maxItems()) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("maxItems misaligned");
                    }
                }, (arraySchema, descriptor) -> {
                    if ((arraySchema.schema() != null && arraySchema.schema().required()
                            || arraySchema.arraySchema() != null && arraySchema.arraySchema().required())
                            && descriptor.getAnnotation(SmartRequired.class) != null) {
                        errors.computeIfAbsent(descriptor.getPath(), k -> new ArrayList<>()).add("remove required");
                    }
                });

        for (FieldDescriptor descriptor : fieldDescriptors) {
            if (descriptor.getSchema() != null) {
                for (BiConsumer<Schema, FieldDescriptor> schemaValidator : schemaValidators) {
                    schemaValidator.accept(descriptor.getSchema(), descriptor);
                }
            }
            if (descriptor.getArraySchema() != null) {
                for (BiConsumer<ArraySchema, FieldDescriptor> arraySchemaValidator : arraySchemaValidators) {
                    arraySchemaValidator.accept(descriptor.getArraySchema(), descriptor);
                }
            }
        }

        List<String> errorList = errors.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .map(e -> e.getKey() + ": " + String.join(", ", e.getValue())).collect(Collectors.toList());

        Set<String> uslessSuppress = new HashSet<>(SUPPRESS);
        uslessSuppress.removeAll(errorList);
        uslessSuppress = uslessSuppress.stream().map(s -> "Remove useless suppress: \"" + s + "\"")
                .collect(Collectors.toSet());

        errorList.removeAll(SUPPRESS);
        errorList.addAll(uslessSuppress);

        if (!errorList.isEmpty()) {
            throw new AssertionError("\n" + String.join("\n", errorList) + "\n");
        }
    }

    private void describe(List<FieldDescriptor> fieldDescriptors) {
        fieldDescriptors.sort(Comparator.comparing(FieldDescriptor::getPath));
        List<String> rows = new ArrayList<>();
        rows.add(toCsvRow(Arrays.asList("Field", "Type", "Annotations", "Schema", "Enum", "Smart")));
        for (FieldDescriptor descriptor : fieldDescriptors) {
            rows.add(toCsvRow(Arrays.asList(descriptor.getPath(), descriptor.getClazz().getSimpleName(),
                    descriptor.getAnnotations().stream().map(a -> a.annotationType().getSimpleName())
                            .filter(x -> !Arrays.asList("Schema", "ArraySchema", "Valid").contains(x)).sorted()
                            .collect(Collectors.joining("\n")),
                    descriptor.getParams().entrySet().stream().sorted(Map.Entry.comparingByKey())
                            .map(e -> e.getKey() + ": " + e.getValue()).collect(Collectors.joining("\n")),
                    !Enum.class.isAssignableFrom(descriptor.getClazz()) ? ""
                            : Arrays.stream(((Class<Enum<?>>) descriptor.getClazz()).getEnumConstants()).map(Enum::name)
                                    .collect(Collectors.joining("\n")),
                    descriptor.getAnnotations().stream().flatMap(a -> {
                        if (SmartRequiredMultiple.class.equals(a.annotationType())) {
                            return Stream.of(((SmartRequiredMultiple) a).value());
                        }
                        if (SmartValidationMultiple.class.equals(a.annotationType())) {
                            return Stream.of(((SmartValidationMultiple) a).value());
                        }
                        return Stream.of(a);
                    }).filter(a -> SmartRequired.class.equals(a.annotationType())
                            || SmartValidation.class.equals(a.annotationType()))
                            .map(a -> renderAnnotation(a, "").trim()).collect(Collectors.joining("\n")))));
        }
        throw new AssertionError("\n\n" + String.join("\n", rows) + "\n");
    }

    private String toCsvRow(List<String> items) {
        return "\"" + items.stream().map(i -> i.replaceAll("\"", "\"\"")).collect(Collectors.joining("\";\"")) + "\"";
    }

    private String renderAnnotation(Annotation annotation, String padding) {
        StringBuilder sb = new StringBuilder();
        sb.append(padding).append("@").append(annotation.annotationType().getSimpleName()).append("(").append("\n");
        for (Method method : annotation.annotationType().getDeclaredMethods()) {
            method.setAccessible(true);
            Object value;
            try {
                value = method.invoke(annotation);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            if (!method.getReturnType().isArray() && !Objects.equals(value, method.getDefaultValue())
                    || method.getReturnType().isArray()
                            && !Arrays.equals((Object[]) value, (Object[]) method.getDefaultValue())) {
                sb.append(padding).append("  ").append(method.getName()).append(" = ");
                if (method.getReturnType().isArray() && ((Object[]) value).length > 1) {
                    sb.append("{").append("\n");
                    if (Annotation.class.isAssignableFrom(method.getReturnType().getComponentType())) {
                        for (Annotation subAnnotation : ((Annotation[]) value)) {
                            sb.append(renderAnnotation(subAnnotation, padding + "    "));
                        }
                    } else {
                        for (Object object : ((Object[]) value)) {
                            sb.append(padding).append("    ").append(ConvertUtils.convert(object)).append("\n");
                        }
                    }
                    sb.append(padding).append("  }").append("\n");
                } else {
                    if (method.getReturnType().isArray() && ((Object[]) value).length == 1) {
                        value = ((Object[]) value)[0];
                    }
                    if (Annotation.class.isAssignableFrom(value.getClass())) {
                        sb.append(renderAnnotation((Annotation) value, padding + "  "));
                    } else {
                        sb.append(ConvertUtils.convert(value));
                    }
                }
                sb.append("\n");
            }
        }
        sb.append(padding).append(")").append("\n");
        return sb.toString().replaceAll("\n\n+", "\n").replaceAll("= +", "= ");
    }

    private void traverse(Class<?> clazz, String path, List<FieldDescriptor> fieldDescriptors) {
        if (clazz == null) {
            return;
        }
        List<Field> fields = getAnnotatedFields(clazz, Schema.class);
        fields.addAll(getAnnotatedFields(clazz, ArraySchema.class));
        for (Field field : fields) {
            fieldDescriptors.add(describeField(field, path));
            traverse(SwaggerUtils.extractFieldClassType(field), path + (path.length() > 0 ? "." : "") + field.getName() +
                            (field.getType().isArray() || Collection.class.isAssignableFrom(field.getType()) ? "[]" : ""),
                    fieldDescriptors);
        }
    }

    private FieldDescriptor describeField(Field field, String path) {
        FieldDescriptor descriptor = new FieldDescriptor();
        descriptor.setPath(path + (path.length() > 0 ? "." : "") + field.getName() +
                (field.getType().isArray() || Collection.class.isAssignableFrom(field.getType()) ? "[]" : ""));
        Class<?> fieldType = SwaggerUtils.extractFieldClassType(field);
        descriptor.setClazz(fieldType != null ? fieldType : field.getType());
        descriptor.setRawFieldType(field.getType());
        descriptor.setAnnotations(Arrays.asList(field.getDeclaredAnnotations()));

        BiFunction<Annotation, String, Map<String, String>> annotationParamsExtractor = (annotation, keyPrefix) -> {
            Map<String, String> params = new HashMap<>();
            if (annotation == null) {
                return params;
            }
            for (Method method : Schema.class.isAssignableFrom(annotation.getClass())
                    ? Schema.class.getDeclaredMethods() : ArraySchema.class.getDeclaredMethods()) {
                if (method.getParameterCount() > 0 || Annotation.class.isAssignableFrom(method.getReturnType())
                        || method.getReturnType().isArray()
                                && Annotation.class.isAssignableFrom(method.getReturnType().getComponentType())) {
                    continue;
                }
                method.setAccessible(true);
                Object value;
                try {
                    value = method.invoke(annotation);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                if (!method.getReturnType().isArray() && !Objects.equals(value, method.getDefaultValue())
                        || method.getReturnType().isArray()
                                && !Arrays.equals((Object[]) value, (Object[]) method.getDefaultValue())) {
                    params.put(keyPrefix + method.getName(),
                            method.getReturnType().isArray() ? Arrays.stream(((Object[]) value))
                                    .map(ConvertUtils::convert).collect(Collectors.joining(", "))
                                    : ConvertUtils.convert(value));
                }
            }
            return params;
        };

        doWithAnnotation(field, Schema.class, schema -> {
            descriptor.setSchema(schema);
            descriptor.getParams().putAll(annotationParamsExtractor.apply(schema, ""));
        });
        doWithAnnotation(field, ArraySchema.class, arraySchema -> {
            descriptor.setArraySchema(arraySchema);
            descriptor.setSchema(arraySchema.schema());
            descriptor.setSchemaOfArray(arraySchema.arraySchema());
            descriptor.getParams().putAll(annotationParamsExtractor.apply(arraySchema, "arr."));
            descriptor.getParams().putAll(annotationParamsExtractor.apply(arraySchema.arraySchema(), "arr."));
            descriptor.getParams().putAll(annotationParamsExtractor.apply(arraySchema.schema(), ""));
        });
        return descriptor;
    }

    private <T extends Annotation> void doWithAnnotation(Field field, Class<T> annotation, Consumer<T> consumer) {
        Arrays.stream(field.getDeclaredAnnotations()).filter(a -> annotation.isAssignableFrom(a.getClass()))
                .forEach(a -> consumer.accept((T) a));
    }

    private List<Field> getAnnotatedFields(Class<?> clazz, Class<? extends Annotation> annotation) {
        List<Field> fields = Arrays.stream(clazz.getDeclaredFields()).filter(
                f -> Arrays.stream(f.getDeclaredAnnotations()).anyMatch(a -> annotation.isAssignableFrom(a.getClass())))
                .collect(Collectors.toList());
        if (clazz.getSuperclass() != null && !clazz.getSuperclass().equals(Object.class)) {
            fields.addAll(getAnnotatedFields(clazz.getSuperclass(), annotation));
        }
        return fields;
    }

    @Data
    private static class FieldDescriptor {
        private String path;
        private Class<?> clazz;
        private Class<?> rawFieldType;
        private ArraySchema arraySchema;
        private Schema schema;
        private Schema schemaOfArray;
        private List<Annotation> annotations;
        private Map<String, String> params = new HashMap<>();

        public <T extends Annotation> T getAnnotation(Class<T> annotation) {
            return (T) annotations.stream().filter(a -> annotation.isAssignableFrom(a.getClass())).findFirst()
                    .orElse(null);
        }
    }

    private enum Mode {
        TEST, DESCRIBE
    }

}
