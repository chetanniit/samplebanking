package com.natwest.pbbdhb.fma.mapper.cases;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.fma.mapper.AbstractMapperTest;
import com.natwest.pbbdhb.fma.model.fma.Application;
import com.natwest.pbbdhb.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class CaseMapperTest extends AbstractMapperTest {

    @InjectMocks
    private CaseMapperImpl caseMapper;

    @Test
    public void testFmaRequestToCaseApplication() {
        FullMortgageApplicationRequest fmaRequest = loadInputModel("input/FullMortgageApplicationRequest.json",
                FullMortgageApplicationRequest.class, FMA_REQUEST_FIELDS_TO_IGNORE);
        Application application = loadInputModel("input/Application.json", Application.class);

        CaseApplicationDto caseApplication = caseMapper.toCaseApplication(
                fmaRequest.getApplication(), application.getMortgage().getBuyToLet(), application.getDirectDebit());
        caseApplication.getDecisionInPrinciples().get(0).setDateTime("2024-06-02");
        caseApplication.getSalesIllustrations().iterator().next().setSelectionDate("2022-11-01");

        assertOutputModelMatches("output/CaseApplication.json", caseApplication);
    }
    
    @Test
    public void testCaseProductFeeMappingUpdateCall() {
    	Field[] fieldsToignore = new Field[] {
                field(FmaResponse.class, "caseId"),
                field(FmaResponse.class, "links"),
                field(FmaResponse.class, "status"),
                field(FmaResponse.class, "applSeq"),
    	};
        FmaResponse fmaResponse = loadInputModel("input/FmaResponse.json",
              FmaResponse.class, fieldsToignore);
        

        List<ProductDetailsDto> productDetails = caseMapper.mapProductDetails(fmaResponse.getProducts());

        assertOutputModelMatches("output/ProductDetails.json", productDetails);
    }
    

}
