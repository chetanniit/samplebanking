# Spring Boot MicroService msvc-int-openbanking

## Brief Overview :
This Serves as a micro service to call Open Banking API.

## To run the application in local
1. Set the values for following properties in application-local.properties file
     -ob.client.proxy.username & ob.client.proxy.password
2. Remove the comments in following files:
   - in OpenBankingApplicationConfig.java: remove the comments for beans: customRestTemplate, userProxyRestTemplate and functions: httpClient function and userProxyHttpClient.
   - in all the service files except RestServiceImpl.java: remove the comments for restTemplate variable declarartion and for all the rest calls made with restTemplate
3. Add comments in following files:
   - in all the service files: Add the comments for restService variable declarartion and for all the rest calls made with restService

## To run the application in PCF (Make sure you do this before pushing code to Bitbucket)
1. Remove the values for following properties in application-local.properties file
    - ob.client.proxy.username & ob.client.proxy.password
2. Remove the comments in following file:
   - in all the service files: Remove the comments for restService variable declarartion and for all the rest calls made with restService
3. Add comments in following files:
   - in OpenBankingApplicationConfig.java: add the comments for beans: customRestTemplate, userProxyRestTemplate and functions: httpClient function and userProxyHttpClient .
   - in all the service files except RestServiceImpl.java  : add the comments for restTemplate variable declarartion and for all the rest calls made with restTemplate

## Build the application
```shell script
mvn clean install
```

## Running unit tests
```shell script
mvn clean test
```
