package com.rbs.pbbdhb.openbanking.model.payment;

import com.fasterxml.jackson.annotation.JsonValue;

public enum OBReadRefundAccount1Code {

	YES("Yes"), NO("No");

	private String value;

	OBReadRefundAccount1Code(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}

	@JsonValue
	public String getValue() {
		return value;
	}

}

