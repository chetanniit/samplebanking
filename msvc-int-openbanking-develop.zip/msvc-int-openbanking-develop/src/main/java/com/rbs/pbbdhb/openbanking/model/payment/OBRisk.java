package com.rbs.pbbdhb.openbanking.model.payment;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * The Risk section is sent by the initiating party to the ASPSP. It is used to
 * specify additional details for risk scoring for Payments.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(getterVisibility = JsonAutoDetect.Visibility.NONE)
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class  OBRisk {

	@JsonProperty("MerchantCategoryCode")
	@Size(min = 3, max = 4)
	private String merchantCategoryCode = null;

	@JsonProperty("MerchantCustomerIdentification")
	@Size(min = 1, max = 70)
	private String merchantCustomerIdentification = null;
}
