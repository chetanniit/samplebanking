package com.rbs.pbbdhb.openbanking.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * FinalTokenResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class FinalTokenResponse extends BaseResponse {

	public String access_token;

	public String token_type;

	public String refresh_token;

}
