package com.rbs.pbbdhb.openbanking.model.common;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * IamTokenResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@Builder
public class IamTokenResponse extends BaseResponse {

	private String iamToken;

	private String jwt;

}
