package com.rbs.pbbdhb.openbanking.service.impl;

import java.security.interfaces.RSAPrivateKey;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import com.rbs.pbbdhb.openbanking.common.CustomThreadLocal;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.config.KeytoolHelper;
import com.rbs.pbbdhb.openbanking.model.common.JwsHeaders;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;
import com.rbs.pbbdhb.openbanking.service.PaymentService;
import com.rbs.pbbdhb.openbanking.service.RestService;

	/**
 * payment service impl
 * 
 * @author gunasm
 *
 */
@Service
public class PaymentServiceImpl implements PaymentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentServiceImpl.class);
	private static ObjectMapper objectMapper = configureMapper();
	@Autowired
	RestService restService;
	/*@Autowired
	@Qualifier("userProxyRestTemplate")
	RestTemplate restService;*/
	
	@Value("${ob.auth.client.tppid}")
	private String tppId;
	
	@Value("${ob.auth.clientId}")
	private String clientId;

	@Value("${ob.client.financial.id}")
	private String financialId;
		
	@Value("${ob.api.payment.nwb.path}")
	private String paymentUrlNwb;
	
	@Value("${ob.api.payment.rbs.path}")
	private String paymentUrlRbs;
	
	@Value("${ob.auth.client.jks.path}")
	private Resource clientJksPath;
	
	@Value("${ob.auth.client.jks.password}")
	private String clientJksPassword;
	
	@Value("${ob.auth.client.kid}")
	private String kid;
	
	@Value("${ob.trust.anchor.value}")
	private String trustAnchor;
		
	@Autowired
	private ExceptionHelper exceptionHelper;

	@Override
	public ResponseEntity<OBWriteDomesticConsent> createDomesticPayment(String finalToken, OBWriteDomesticConsent domesticConsent, String brand) {
		
		String paymentUrl = (brand.equalsIgnoreCase(Constants.NWB) ? paymentUrlNwb : paymentUrlRbs);
		
		LOGGER.debug("Initiating Payment for brand - {}, payment Url - {}",brand,paymentUrl);
		
		String requestBody = toJson(domesticConsent);

		//LOGGER.debug("requestBody ::" + requestBody);

		String jwsSignatureValue = setRequestSignature(requestBody, tppId,
				clientId);

		String interactionId = UUID.randomUUID().toString();
		LOGGER.info("payments - payment interaction id for cin : {} , {}",
				CustomThreadLocal.getValueByKey(Constants.ENC_CIN),
				interactionId);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(Constants.AUTHORIZATION, "Bearer " + finalToken);
		headers.set(Constants.X_FAPI_FINANCIAL_ID, financialId);
		headers.set(Constants.X_IDEMPOTENCY_KEY, UUID.randomUUID().toString().replace("-", "").substring(0, 29));
		headers.set(Constants.X_JWS_SIGNATURE, jwsSignatureValue);
		headers.set(Constants.X_FAPI_INERACTION_ID, interactionId);

		HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
		
		ResponseEntity<OBWriteDomesticConsent> response = restService.exchange(paymentUrl, HttpMethod.POST, entity,
				OBWriteDomesticConsent.class);

		validation(response.getBody());
		
		LOGGER.debug(response.getBody().getData().toString());
		LOGGER.debug("Interaction id : " + response.getHeaders().get("X-Fapi-Interaction-Id"));
		return response;
	}

	private String setRequestSignature(String requestBody, String tppId, String clientId) {

		StringBuilder issuer = new StringBuilder().append(tppId).append("/").append(clientId);
		return signWithDetachedJws(requestBody, issuer.toString());
	}

	public String signWithDetachedJws(String message, String issuer) {
		JsonWebSignature jws = createJwsSigner(message, issuer);
		try {
			return jws.getDetachedContentCompactSerialization();
		} catch (JoseException e) {
			throw new RuntimeException(e);
		}
	}

	private JsonWebSignature createJwsSigner(String payload, String issuer) {
		return createJwsSignerImpl(payload, issuer);
	}

	private JsonWebSignature createJwsSignerImpl(String payload, String issuer) {
		JsonWebSignature jws = new JsonWebSignature();
		jws.setPayload(payload);
		jws.setKey(privateKey(clientJksPath.getFilename(), clientJksPassword, clientId));		
		headers(issuer).forEach((k, v) -> jws.getHeaders().setObjectHeaderValue(k, v));		
		jws.setCriticalHeaderNames(JwsHeaders.CRITICAL_HEADER_CLAIMS.toArray(new String[0]));
		return jws;
	}

	private Map<String, Object> headers(String issuer) {
		Map<String, Object> headers = Maps.newHashMap();
		headers.put(HeaderParameterNames.ALGORITHM, AlgorithmIdentifiers.RSA_PSS_USING_SHA256);
		headers.put(HeaderParameterNames.KEY_ID, kid);
		headers.put(JwsHeaders.ISSUED_AT, Instant.now().getEpochSecond());
		headers.put(JwsHeaders.ISSUER, issuer);
		headers.put(JwsHeaders.TRUST_ANCHOR, trustAnchor);
		return headers;
	}

	private RSAPrivateKey privateKey(String keystorePath, String keystorePassword, String alias) {
		try {
			return (RSAPrivateKey) KeytoolHelper.key(keystorePath, keystorePassword, alias);
		} catch (Exception e) {
			throw new RuntimeException(String.format(
					"There was a problem getting the private key with alias %s from %s", alias, keystorePath), e);
		}
	}

	public String toJson(final Object object) {
		try {
			return objectMapper.writeValueAsString(object);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static ObjectMapper configureMapper() {
		final ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(JsonParser.Feature.ALLOW_COMMENTS, true);

		return mapper;
	}
	
	private void validation(OBWriteDomesticConsent body) {
		if(null == body.getData()){
			LOGGER.info("No Data present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}

		else if(null == body.getData().getInitiation()){
			LOGGER.info("No Data->Initiation present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(null == body.getData().getStatus()){
			LOGGER.info("No Data->Status present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(null == body.getData().getInitiation().getInstructedAmount()){
			LOGGER.info("No Data->Initiation->InstructedAmount present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(Strings.isNullOrEmpty(body.getData().getInitiation().getInstructedAmount().getAmount())){
			LOGGER.info("No Data->Initiation->InstructedAmount->Amount present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(Strings.isNullOrEmpty(body.getData().getInitiation().getInstructedAmount().getCurrency())){
			LOGGER.info("No Data->Initiation->InstructedAmount->Currency present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(null == body.getData().getInitiation().getDebtorAccount()){
			LOGGER.info("No Data->Initiation->DebtorAccount present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(Strings.isNullOrEmpty(body.getData().getInitiation().getDebtorAccount().getIdentification())){
			LOGGER.info("No Data->Initiation->DebtorAccount->Identification present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(Strings.isNullOrEmpty(body.getData().getDomesticPaymentId())){
			LOGGER.info("No Data->DomesticPaymentId present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
		
		else if(null == body.getData().getInitiation().getRemittanceInformation()){
			LOGGER.info("No Data->Initiation->RemittanceInformation present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}

		else if (Strings.isNullOrEmpty(body.getData().getInitiation().getRemittanceInformation().getReference())){
			LOGGER.info("No Data->Initiation->RemittanceInformation->Reference present in OB API call response {}", body);		
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
		}
	}

}
