package com.rbs.pbbdhb.openbanking.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * AccountResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@Data
public class AccountResponse {

	@JsonProperty(value = "Data")
	public AccountResponseData data;

}
