package com.rbs.pbbdhb.openbanking.service;

import java.security.GeneralSecurityException;

import org.springframework.http.ResponseEntity;

import com.nimbusds.jose.JOSEException;
import com.rbs.pbbdhb.openbanking.model.common.IamTokenResponse;

/**
 * Service for Token Generation
 * 
 * @author gunasm
 *
 */
public interface IamTokenGeneratorService {

	/**
	 * 
	 * @param scope scope
	 * @param brand nwb/rbs
	 * @return iamToken response
	 * @throws RuntimeException
	 * @throws JOSEException
	 * @throws GeneralSecurityException
	 */
	ResponseEntity<IamTokenResponse> generateIamToken(String scope, String brand) throws RuntimeException,JOSEException,GeneralSecurityException;
	
}
