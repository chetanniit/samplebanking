package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentRequest;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;

/**
 * Payment service
 * 
 * @author gunasm
 *
 */
public interface IBPService {

	/**
	 * Get Accounts along with Balance domestic 
	 * 
	 * @param cin cin
	 * @param brand brand
	 * @return AccountBalanceResponse
	 */
	public ResponseEntity<AccountBalanceResponse> getAccountBalances(String cin, String brand);

	/**
	 * Generate domestic payment consent
	 * 
	 * @param cin cin
	 * @param accountNumber accountNumber
	 * @param brand brand
	 * @param iBPPaymentRequest iBPPaymentRequest
	 * @return iBPPaymentResponse
	 */
	ResponseEntity<IBPPaymentResponse> createDomesticPayment( String cin, String accountNumber, String brand, IBPPaymentRequest iBPPaymentRequest, String source);
}
