package com.rbs.pbbdhb.openbanking.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * LoginHintTokenResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class LoginHintTokenResponse extends BaseResponse {

	public String login_hint_token;
}
