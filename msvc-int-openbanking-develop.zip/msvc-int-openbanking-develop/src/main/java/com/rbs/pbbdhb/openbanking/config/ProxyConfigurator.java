package com.rbs.pbbdhb.openbanking.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProxyConfigurator {

    @Value("${msvc.openbanking.proxyHost}")
    private String proxyHost;

    @Value("${proxy.port}")
    private String proxyPort;

    @Value("${msvc.openbanking.nonProxyHosts}")
    private String nonProxyHosts;

    public void setProxy() {
        System.setProperty("http.proxyHost", proxyHost);
        System.setProperty("http.proxyPort", proxyPort);
        System.setProperty("https.proxyHost", proxyHost);
        System.setProperty("https.proxyPort", proxyPort);
        System.setProperty("http.nonProxyHosts", nonProxyHosts);
    }
}
