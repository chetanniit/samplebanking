package com.rbs.pbbdhb.openbanking.model.payment;

import com.rbs.pbbdhb.error.BaseResponse;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * OBWriteDomesticConsent4
 */

@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class IBPPaymentResponse extends BaseResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 175841500506761428L;

	@Schema(name = "domesticPaymentId",description = "domestic payment Id",example = "06a64ceed4854e868cc5724ec2940031")
	private String domesticPaymentId;

	@Schema(name = "amount",description = "amount",example = "200")
	private String amount;

	@Schema(name = "currency",description = "currency",example = "GBP")
	private String currency;

	@Schema(name = "transactionStatus",description = "transaction status",example = "AcceptedSettlementCompleted")
	private String transactionStatus;

	@Schema(name = "transactionId",description = "transaction Id",example = "1dbP106a2402065783054a163f70f20231212100508180h")
	private String transactionId;

	@Schema(name = "debtorSortCodeAccountNumber",description = "debtor sort code account number",example = "83198495_STPLSI_20231115131901")
	private String debtorSortCodeAccountNumber;		

}
