package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;

/**
 * Payment service
 * 
 * @author gunasm
 *
 */
public interface PaymentService {

	/**
	 * Generate domestic payment consent
	 * 
	 * @param token token
	 * @param domesticConsent domesticConsent
	 * @param brand brand
	 * @return oBWriteDomesticConsent
	 */
	ResponseEntity<OBWriteDomesticConsent> createDomesticPayment(String token, OBWriteDomesticConsent domesticConsent, String brand);
}
