package com.rbs.pbbdhb.openbanking.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;

import groovy.transform.ToString;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * CreditLine
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@Data
public class CreditLine {

	@JsonProperty(value = "Included")
	public boolean included;

	@JsonProperty(value = "Amount")
	public Amount amount;

	@JsonProperty(value = "Type")
	public String type;
}
