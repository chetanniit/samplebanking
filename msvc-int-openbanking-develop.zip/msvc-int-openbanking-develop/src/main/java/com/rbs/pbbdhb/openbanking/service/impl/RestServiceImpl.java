package com.rbs.pbbdhb.openbanking.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.service.RestService;

@Service
public class RestServiceImpl implements RestService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RestServiceImpl.class);

	@Autowired
	@Qualifier("appProxyRestTemplate")
	private RestTemplate restTemplate;

	@Autowired
	private ExceptionHelper exceptionHelper;

	@Autowired
	private ObjectMapper objectMapper;

	@Override
	@Deprecated
	public <T> ResponseEntity<T> get(String url, Class<T> clazz) {

		ResponseEntity<T> response = null;
		try {
			response = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY, clazz);
			if (HttpStatus.OK.equals(response.getStatusCode())) {
				ResponseEntity responseEntity = new ResponseEntity(response.getBody(),
						getResponseHeaders(response.getHeaders()), response.getStatusCode());
				return responseEntity;
			}
			LOGGER.debug("Rest call failed for Url:" + url + "\nErrorDetails: StatusCode:"
					+ response.getStatusCodeValue() + " Response:" + response.getBody().toString());
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, response.getStatusCodeValue(),
					"internal.server.error");
		} catch (RestClientException ex) {

			if (ex instanceof HttpStatusCodeException) {
				LOGGER.debug("Rest call failed for Url:" + url + "\nErrorDetails:"
						+ ((HttpStatusCodeException) ex).getResponseBodyAsString(), ex);
				try {
					response = new ResponseEntity<T>(
							objectMapper.readValue(((HttpStatusCodeException) ex).getResponseBodyAsByteArray(), clazz),
							((HttpStatusCodeException) ex).getStatusCode());
				} catch (Exception e) {
					exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, e, "internal.server.error");
				}
			} else if (ex instanceof ResourceAccessException) {
				exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, ex, HttpStatus.REQUEST_TIMEOUT.value(),
						"request.timed.out");
			} else {
				exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, ex, "internal.server.error");
			}
		}
		return response;
	}

	@Override
	public <T> ResponseEntity<T> exchange(String url, HttpMethod method, @Nullable HttpEntity<?> requestEntity,
			Class<T> responseType) {

		ResponseEntity<T> response = null;
		try {
			response = restTemplate.exchange(url, method, requestEntity, responseType);
			if (response.getStatusCode().is2xxSuccessful()) {
				ResponseEntity responseEntity = new ResponseEntity(response.getBody(),
						getResponseHeaders(response.getHeaders()), response.getStatusCode());
				return responseEntity;
			}
			LOGGER.debug("Rest call failed for Url:" + url + "\nErrorDetails: StatusCode:"
					+ response.getStatusCodeValue() + " Response:" + response.getBody().toString());
			exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, response.getStatusCodeValue(),
					"internal.server.error");
		} catch (RestClientException ex) {

			if (ex instanceof HttpStatusCodeException) {

				String responseBody = ((HttpStatusCodeException) ex).getResponseBodyAsString();
				LOGGER.debug("Rest call failed for Url:" + url + "\nErrorDetails:" + responseBody, ex);
				try {

					if (StringUtils.isNotBlank(responseBody)) {
						response = new ResponseEntity<T>(objectMapper
								.readValue(((HttpStatusCodeException) ex).getResponseBodyAsByteArray(), responseType),
								((HttpStatusCodeException) ex).getStatusCode());
					} else {
						response = new ResponseEntity<T>(((HttpStatusCodeException) ex).getStatusCode());
					}
				} catch (Exception e) {
					exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, e, Constants.INTERNAL_SERVER_ERROR);
				}
			} else if (ex instanceof ResourceAccessException) {
				LOGGER.debug("Rest call failed ( ResourceAccessException) for Url:" + url);
				exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, ex, HttpStatus.REQUEST_TIMEOUT.value(),
						 Constants.REQUEST_TIMED_OUT);
			} else {
				exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, ex,  Constants.INTERNAL_SERVER_ERROR);
			}
		}
		return response;
	}

	private HttpHeaders getResponseHeaders(HttpHeaders headers) {
		return headers.entrySet().stream()
				.filter(entry -> !entry.getKey().equalsIgnoreCase(HttpHeaders.TRANSFER_ENCODING))
				.collect(HttpHeaders::new, (httpHeaders, entry) -> httpHeaders.addAll(entry.getKey(), entry.getValue()),
						HttpHeaders::putAll);
	}

}