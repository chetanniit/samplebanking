package com.rbs.pbbdhb.openbanking.model.account;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import groovy.transform.ToString;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * AccountDetails
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@Data
public class AccountDetails {

	@JsonProperty(value = "AccountId")
	public String accountId;

	@JsonProperty(value = "Currency")
	public String currency;

	@JsonProperty(value = "AccountType")
	public String accountType;

	@JsonProperty(value = "AccountSubType")
	public String accountSubType;

	@JsonProperty(value = "Description")
	public String description;

	@JsonProperty(value = "Account")
	public List<Account> accounts;

}
