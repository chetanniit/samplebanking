package com.rbs.pbbdhb.openbanking.config;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Key tool helper class
 * 
 * @author gunasm
 *
 */
@Component 
public class KeytoolHelper {

	@Value("${ob.auth.clientId}")
	private String clientId;	

	@Value("${ob.auth.client.jks.password}")
	private String clientJksPassword;
	
	public static KeyStore getKeystore(final String keyStorePath, final String keyStorePassword) {
        try {
            String keyStoreType = keyStoreType(keyStorePath);
            final KeyStore keyStore = KeyStore.getInstance(keyStoreType);
            InputStream is=Thread.currentThread().getContextClassLoader().getResourceAsStream(keyStorePath);
            keyStore.load(is, keyStorePassword.toCharArray());

            return keyStore;
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
    }

    private static String keyStoreType(String keyStorePath) {
        String keyStoreType;
        if(keyStorePath.endsWith(Constants.P12)) {
            keyStoreType = Constants.PKCS12;
        } else {
            keyStoreType = Constants.JKS;
        }
        return keyStoreType;
    }

    private static boolean isP12File(String keyStorePath) {
        return keyStoreType(keyStorePath).equalsIgnoreCase(Constants.PKCS12);
    }

    public static Certificate getCertificate(final String keyStorePath, final String keyStorePassword, final String alias) throws RuntimeException,GeneralSecurityException{
        return KeytoolHelper.getKeystore(keyStorePath, keyStorePassword).getCertificate(alias);
    }

    public static Key key(final String keyStorePath, final String keyStorePassword, final String alias) throws RuntimeException,GeneralSecurityException{
        String keystoreAlias = determineAlias(keyStorePath, alias);
        return KeytoolHelper.getKeystore(keyStorePath, keyStorePassword).getKey(keystoreAlias, keyStorePassword.toCharArray());
    }

    private static String determineAlias(String keyStorePath, String alias) {
        return isP12File(keyStorePath) ? "1" : alias; // p12 files do not contain an aliasName - their entries are returned numbered by java.security.KeyStore
    }

    public static List<String> aliases(final String keyStorePath, final String keyStorePassword) throws RuntimeException,GeneralSecurityException{
        List<String> aliases = new ArrayList<String>();
        Enumeration<String> enmALias = KeytoolHelper.getKeystore(keyStorePath, keyStorePassword).aliases();
        while (enmALias.hasMoreElements()) {
            String alias = (String) enmALias.nextElement();
            aliases.add(alias);
        }
        return aliases;
    }

    public static String aliasesString(final String keyStorePath, final String keyStorePassword) throws RuntimeException,GeneralSecurityException {
        List<String> aliases = new ArrayList<String>();
        Enumeration<String> enmALias = KeytoolHelper.getKeystore(keyStorePath, keyStorePassword).aliases();
        while (enmALias.hasMoreElements()) {
            String alias = (String) enmALias.nextElement();
            aliases.add(alias);
        }
        return aliases.toString();
    }

    public PublicKey publicKey(final String keyStorePath, final String keyStorePassword, final String alias) {
        KeyStore keystore = getKeystore(keyStorePath, keyStorePassword);
        try {
            return keystore.getCertificate(alias).getPublicKey();
        } catch (KeyStoreException e) {
            throw new RuntimeException(e);
        }
    }

	public KeyStore createKeyStore(InputStream publicCertIn, String privateKeyIn)
			throws IOException, GeneralSecurityException {

		KeyStore keyStore = createEmptyKeyStore();

		X509Certificate publicCert = loadCertificate(publicCertIn);
		PrivateKey privateKey = loadPrivateKey(privateKeyIn);

		keyStore.setCertificateEntry(clientId, publicCert);

		keyStore.setKeyEntry(clientId, privateKey, clientJksPassword.toCharArray(),
				new Certificate[] { publicCert });

		return keyStore;
	}

	public static KeyStore createEmptyKeyStore() throws IOException, GeneralSecurityException {

		KeyStore keyStore = KeyStore.getInstance(Constants.JKS);
		keyStore.load(null, null);
		return keyStore;
	}

	public static X509Certificate loadCertificate(InputStream publicCertIn)
			throws IOException, GeneralSecurityException {
        CertificateFactory factory = CertificateFactory.getInstance(Constants.X_59);
		X509Certificate cert = (X509Certificate) factory.generateCertificate(publicCertIn);
		return cert;
	}

	public static PrivateKey loadPrivateKey(String privateKeyIn) throws IOException, GeneralSecurityException {

		// need the full file - org.apache.commons.io.IOUtils is handy
		//byte[] fullFileAsBytes = IOUtils.toByteArray(privateKeyIn);
		// remember this is supposed to be a text source with the BEGIN/END and base64
		// in the middle of the file
		//String fullFileAsString = new String(fullFileAsBytes);

		// nifty regular expression to extract out between BEGIN/END
		Pattern parse = Pattern.compile("(?m)(?s)^---*BEGIN.*---*$(.*)^---*END.*---*$.*");
		String encoded = parse.matcher(privateKeyIn).replaceFirst("$1");

		// decode the Base64 string
		byte[] keyDecoded = Base64.getMimeDecoder().decode(encoded);

		// for my example, the source is in common PKCS#8 format
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyDecoded);

		// from there we can use the KeyFactor to generate
		KeyFactory keyFactory = KeyFactory.getInstance(Constants.RSA);
		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

		return privateKey;
	}
}
