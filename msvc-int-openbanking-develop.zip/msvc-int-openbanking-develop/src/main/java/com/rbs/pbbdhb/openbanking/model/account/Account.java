package com.rbs.pbbdhb.openbanking.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * Account
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class Account {

	@JsonProperty(value = "SchemeName")
	public String schemeName;

	@JsonProperty(value = "Identification")
	public String identification;

	@JsonProperty(value = "Name")
	public String name;

}
