package com.rbs.pbbdhb.openbanking.model.account;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import groovy.transform.ToString;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * AccountBalance
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@Data
public class AccountBalance {

	@JsonProperty(value = "AccountId")
	public String accountId;

	@JsonProperty(value="Amount")
	public Amount amount;
	
	@JsonProperty(value = "CreditDebitIndicator")
	public String creditDebitIndicator;

	@JsonProperty(value = "Type")
	public String type;

	@JsonProperty(value = "CreditLine")
	public List<CreditLine> creditLine;

	@JsonProperty(value = "DateTime")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	public LocalDateTime dateTime;
}
