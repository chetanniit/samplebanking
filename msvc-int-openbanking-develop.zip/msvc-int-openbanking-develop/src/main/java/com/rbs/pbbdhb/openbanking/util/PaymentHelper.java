package com.rbs.pbbdhb.openbanking.util;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentRequest;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;
import com.rbs.pbbdhb.openbanking.model.payment.OBCashAccountCreditor;
import com.rbs.pbbdhb.openbanking.model.payment.OBCashAccountDebtor;
import com.rbs.pbbdhb.openbanking.model.payment.OBDomestic;
import com.rbs.pbbdhb.openbanking.model.payment.OBDomesticInstructedAmount;
import com.rbs.pbbdhb.openbanking.model.payment.OBRemittanceInformation;
import com.rbs.pbbdhb.openbanking.model.payment.OBRisk;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDataDomesticConsent;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;

@Component
public class PaymentHelper {

	@Value("${ob.service.creditor.nwb.account.sortcode.account.number}")
	private String creditorSortCodeAccountNumberNwb;

	@Value("${ob.service.creditor.rbs.account.sortcode.account.number}")
	private String creditorSortCodeAccountNumberRbs;

	private static final String STP_ORDER_TXT = "STP-LSI-DPCPAYMENT";
	private static final String ORDER_ID_DATE_TIME_PATTERN = "yyMMddHHmmss";


	public OBWriteDomesticConsent createRequest(IBPPaymentRequest request, String brand, String accountNumber, String source) {

		String creditorSortCodeAccountNumber = (brand.equalsIgnoreCase(Constants.NWB) ? creditorSortCodeAccountNumberNwb : creditorSortCodeAccountNumberRbs);

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(ORDER_ID_DATE_TIME_PATTERN);
		String orderIdDateTime = LocalDateTime.now().format(dateTimeFormatter);
		String endToEndId = getSTPOrderText(source)+orderIdDateTime;

		return OBWriteDomesticConsent
			.builder()
			.risk(OBRisk.builder().build())
			.data(OBWriteDataDomesticConsent
				.builder()
				.initiation(OBDomestic.builder()
				.instructionIdentification(UUID.randomUUID().toString().replace("-", "").substring(0, 32))
				.endToEndIdentification(endToEndId)
				.instructedAmount(OBDomesticInstructedAmount.builder().amount(request.getAmount()).currency(request.getCurrency()).build())
				.debtorAccount(OBCashAccountDebtor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(request.getDebtorSortCodeAccountNumber()).build())
				.creditorAccount(OBCashAccountCreditor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(creditorSortCodeAccountNumber).name("Natwest").build())
				.remittanceInformation(OBRemittanceInformation.builder().unstructured("unstructured").reference(accountNumber).build()) //TODO
				.build()).build()).build();
	}

	public IBPPaymentResponse createResponse(OBWriteDomesticConsent response) {
		return IBPPaymentResponse.builder().amount(response.getData().getInitiation().getInstructedAmount().getAmount())
				.currency(response.getData().getInitiation().getInstructedAmount().getCurrency())
				.debtorSortCodeAccountNumber(response.getData().getInitiation().getDebtorAccount().getIdentification())
				.domesticPaymentId(response.getData().getDomesticPaymentId())
				.transactionId(response.getData().getInitiation().getRemittanceInformation().getReference())
				.transactionStatus(response.getData().getStatus())
				.build();
	}
	
	private String getSTPOrderText(String source) {
		switch(source.toLowerCase()) {
		case Constants.REDEMPTIONS:
			return Constants.REDEMPTION_CLOSURE_STP_ORDER_TXT;
		case Constants.LUMPSUM:
			return STP_ORDER_TXT;
		default:
			return Constants.EMPTY_STRING;
		}
	}
}
