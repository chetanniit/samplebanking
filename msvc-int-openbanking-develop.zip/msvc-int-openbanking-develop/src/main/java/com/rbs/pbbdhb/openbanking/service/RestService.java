package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public interface RestService {

	<T> ResponseEntity<T> get(String url, Class<T> clazz);

	<T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType);

}