package com.rbs.pbbdhb.openbanking.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;

import groovy.transform.ToString;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * Amount
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@Data
public class Amount {

	@JsonProperty(value = "Amount")
	public String amount;

	@JsonProperty(value = "Currency")
	public String currency;


}
