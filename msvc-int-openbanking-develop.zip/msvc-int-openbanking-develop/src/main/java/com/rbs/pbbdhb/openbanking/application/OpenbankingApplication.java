package com.rbs.pbbdhb.openbanking.application;

import java.security.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.nimbusds.jose.crypto.bc.BouncyCastleProviderSingleton;

/**
 * Runner class for Openbanking integration service
 * 
 * @author gunasm
 *
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.rbs.pbbdhb")
public class OpenbankingApplication {

	static{
        System.setProperty("jdk.tls.maxHandshakeMessageSize", "50000"); 
    }

	/**
	 * Runner method for Openbanking Application
	 * 
	 * @param args args
	 */
	public static void main(String[] args) {
		Security.addProvider(BouncyCastleProviderSingleton.getInstance());
		SpringApplication.run(OpenbankingApplication.class,args);
	}

}
