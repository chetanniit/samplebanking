package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.account.AccountAccessConsentsResponse;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;

/**
 * GenerateConsentService
 * 
 * @author gunasm
 *
 */
public interface GenerateConsentService {

	/**
	 * generate Consent Token
	 * 
	 * @param iamToken iamToken
	 * @param brand brand
	 * @return token
	 */
	ResponseEntity<AccountAccessConsentsResponse> generateAccountConsentToken(String iamToken, String brand);

	/**
	 * Generate domestic payment consent
	 * 
	 * @param token token
	 * @param domesticConsent domesticConsent
	 * @param brand brand
	 * @return consent
	 */
	ResponseEntity<OBWriteDomesticConsent> generatePaymentConsent(String token, OBWriteDomesticConsent domesticConsent, String brand);
	
}
