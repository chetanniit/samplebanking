package com.rbs.pbbdhb.openbanking.controller;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbs.pbbdhb.openbanking.common.CustomThreadLocal;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;
import com.rbs.pbbdhb.openbanking.service.IBPService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller class to to provide endpoints to get data from GMS
 * 
 * @author gunasm
 *
 */
@RestController
@RequestMapping("/")
@Tag(description = "Accounts Controller", name = "Accounts Controller")
@Validated
@Slf4j
public class AccountsController {

	@Autowired
	private IBPService ibpService;

	/**
	 * Method to get account Details based on the cin number
	 * 
	 * @param cin         cin
	 * @param brand       brand
	 * @return AccountBalanceResponse
	 */
	@Operation(description = "Get Account balances", method = "getAccountBalances",
			summary = "Returns Http Status")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "OK",content = @Content(schema = @Schema(implementation = AccountBalanceResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content=@Content),
			@ApiResponse(responseCode = "401", description = "Not authenticated", content=@Content),
			@ApiResponse(responseCode = "404", description = "Resource not found", content=@Content),
			@ApiResponse(responseCode = "500", description = "Internal server error", content=@Content),
			@ApiResponse(responseCode = "503", description = "Service not available", content=@Content)})
	@Parameters({
			@Parameter(name = "brand",example = "nwb",in = ParameterIn.HEADER),
			@Parameter(name = "cin",example = "1938370002",in = ParameterIn.HEADER)
	})
	@GetMapping(path = "account-details/balances")
	public ResponseEntity<AccountBalanceResponse> getAccountBalances(@RequestHeader("cin") String cin,
			@RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand) {
		log.info("getAccountDetails for {} with brand {}", cin, brand);
		CustomThreadLocal.setKeyValue(Constants.ENC_CIN, getEncCin(cin));
		return ibpService.getAccountBalances(cin, brand);
	}

	private String getEncCin(String cin) {
		StringBuilder formated = new StringBuilder("*****");
		formated.append(cin.substring(5));
		return formated.toString();
	}
}
