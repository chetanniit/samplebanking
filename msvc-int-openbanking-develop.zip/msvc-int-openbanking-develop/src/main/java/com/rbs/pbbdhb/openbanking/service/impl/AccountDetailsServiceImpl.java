package com.rbs.pbbdhb.openbanking.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.account.Account;
import com.rbs.pbbdhb.openbanking.model.account.AccountBalance;
import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;
import com.rbs.pbbdhb.openbanking.model.account.AccountDetails;
import com.rbs.pbbdhb.openbanking.model.account.AccountResponse;
import com.rbs.pbbdhb.openbanking.model.account.Balance;
import com.rbs.pbbdhb.openbanking.model.account.Balance.BalanceBuilder;
import com.rbs.pbbdhb.openbanking.model.account.CreditLine;
import com.rbs.pbbdhb.openbanking.service.AccountDetailsService;
import com.rbs.pbbdhb.openbanking.service.RestService;

/**
 * Generate Token Service
 * 
 * @author gunasm
 *
 */
@Service
public class AccountDetailsServiceImpl implements AccountDetailsService {

	private static final Logger log = LoggerFactory.getLogger(AccountDetailsServiceImpl.class);	
	
	@Value("${ob.api.accounts.nwb.path}")
	private String accountsPathNwb;
	
	@Value("${ob.api.accounts.rbs.path}")
	private String accountsPathRbs;

	@Value("${ob.api.accounts.balances.nwb.path}")
	private String balancesPathNwb;
	
	@Value("${ob.api.accounts.balances.rbs.path}")
	private String balancesPathRbs;

	@Value("${ob.client.financial.id}")
	private String financialId;
	
	@Autowired
	RestService restService;


	 /*@Autowired
	 @Qualifier("userProxyRestTemplate")
	 RestTemplate restService;*/

	
	@Autowired
	private ExceptionHelper exceptionHelper;

	@Override
	public ResponseEntity<AccountBalanceResponse> getAccountDetails(String token, String brand) {
		
		String accountsPath = (brand.equalsIgnoreCase(Constants.NWB) ? accountsPathNwb : accountsPathRbs);
		
		String balancesPath = (brand.equalsIgnoreCase(Constants.NWB) ? balancesPathNwb : balancesPathRbs);
		
		log.debug("Fetching account balance for brand - {}, accounts Url - {}, balance Url - {}",brand,accountsPath, balancesPath);		
		
		HttpHeaders headers = httpHeaders(token, financialId);
		BalanceBuilder builder = Balance.builder();
		
		ResponseEntity<AccountResponse> response = null;
		List<Balance> balanceList = new ArrayList<>();
					
		response = restService.exchange(accountsPath,
					HttpMethod.GET, new HttpEntity<String>(headers), AccountResponse.class);

		log.info("Account API call response: " + response);	
				 
		if(null== response.getBody() || null == response.getBody().getData() || null == response.getBody().getData().getAccountDetails()){
			 log.debug("No response recieved for Accounts API call");
			 exceptionHelper.throwException(Exceptions.BUSINESS_EXCEPTION, Constants.INTERNAL_SERVER_ERROR);
			 return ResponseEntity.status(HttpStatus.NOT_FOUND).body(AccountBalanceResponse.builder().accountBalances(balanceList).build());
			 
		}
		
		for(AccountDetails account: response.getBody().getData().getAccountDetails()){						 
			
			 log.info("Getting details for Account Id - " +account.getAccountId());
			 
			 builder.accountType(account.getAccountType()).subType(account.getAccountSubType()).description(account.getDescription());
			 
			 if(null == account.getAccounts()){
				 log.debug("No Account Present, for Account Id: "+account.getAccountId()); 
				continue;
			 }	
			 
			 Optional<Account> acct_o = account.getAccounts().stream().filter(a->a.getSchemeName().equalsIgnoreCase("UK.OBIE.SortCodeAccountNumber")).findFirst();
			 	
			 if(!acct_o.isPresent()){
				log.debug("No Account detail (sort code & account number) present");
				continue;
			 }
			 
			 Account acct = acct_o.get();		 
			 
			 if(StringUtils.isEmpty(acct.getIdentification())){
				 log.debug("Account Data (Sort Code & Account Number) not Present");
				continue;
			 }
			builder.sortCode(acct.getIdentification().substring(0, 6)).accountNumber(acct.getIdentification().substring(6)).name(acct.getName());			 
			
			String path = String.format(balancesPath, account.getAccountId());
			 
			ResponseEntity<AccountResponse> acctResp = restService.exchange(path,
					 HttpMethod.GET, new HttpEntity<String>(headers), AccountResponse.class);

			log.info("Account Balance API call response: " + acctResp);	
			
			if(null== acctResp.getBody() || null == acctResp.getBody().getData() || null == acctResp.getBody().getData().getAccountBalance()){
				log.debug("Account Balance not present in the response from OB API call");		
				continue;
			}
			 
			 Optional<AccountBalance> acctBal_o = acctResp.getBody().getData().getAccountBalance().stream().filter(a->a.getType().equalsIgnoreCase(Constants.EXPECTED)).findFirst();
			 	
			 if(!acctBal_o.isPresent()){
				  log.debug("No Account detail present for Type - EXPECTED");					  
				continue;
			 }
			 
			 AccountBalance acctBal = acctBal_o.get();
			 
			 if (StringUtils.isEmpty(acctBal.getCreditDebitIndicator())){
				 log.debug("Account Data (CreditDebitIndicator) not Present");
				continue;
			}

			boolean NoCreditline = false;
			 
			 if(null == acctBal.getCreditLine()){
				 log.info("No Creditline present");
				builder.arrangedOverdraft(null);
				NoCreditline = true;
			 }
			 else{
				 
				Optional<CreditLine> creditLinePa_o = acctBal.getCreditLine().stream()
						.filter(a -> a.getType().equalsIgnoreCase(Constants.PRE_AGREED)).findFirst();
				Optional<CreditLine> creditLineAvl_o = acctBal.getCreditLine().stream()
						.filter(a -> a.getType().equalsIgnoreCase(Constants.AVAILABLE)).findFirst();
				 
				if (creditLineAvl_o.isPresent() && creditLinePa_o.isPresent()) {

					CreditLine creditLineAvl = creditLineAvl_o.get();
					CreditLine creditLinePa = creditLinePa_o.get();

					builder.arrangedOverdraft(new BigDecimal(creditLineAvl.getAmount().getAmount()));

					if (creditLineAvl.isIncluded()) {
						if (acctBal.getCreditDebitIndicator().trim().equalsIgnoreCase(Constants.DEBIT)) {
							BigDecimal currentBal = new BigDecimal(acctBal.getAmount().getAmount()).negate();
							builder.currentBalance(
									currentBal.subtract(new BigDecimal(creditLinePa.getAmount().getAmount())));

						} else if (acctBal.getCreditDebitIndicator().trim().equalsIgnoreCase(Constants.CREDIT)) {
							BigDecimal currentBal = new BigDecimal(acctBal.getAmount().getAmount());
							builder.currentBalance(
									currentBal.subtract(new BigDecimal(creditLinePa.getAmount().getAmount())));
						} else {
							log.debug("Unknown CreditDebitIndicator (Included - true): "
									+ acctBal.getCreditDebitIndicator());
							continue;
						}
					 }
					else {
						log.debug("Creditline not included");
						NoCreditline = true;
					}
				 }
				else {
					log.debug("Creditline not present");
					NoCreditline = true;
				}
			}

			if (NoCreditline) {
				if (acctBal.getCreditDebitIndicator().trim().equalsIgnoreCase(Constants.DEBIT)) {
					builder.currentBalance(new BigDecimal(acctBal.getAmount().getAmount()).negate());
				} else if (acctBal.getCreditDebitIndicator().trim().equalsIgnoreCase(Constants.CREDIT)) {
					builder.currentBalance(new BigDecimal(acctBal.getAmount().getAmount()));
				}
				 else{
					log.debug("Unknown CreditDebitIndicator: " + acctBal.getCreditDebitIndicator());
					continue;
				 }
			 }
			 
			 builder.balanceLastUpdatedTime(acctBal.getDateTime()).currency(acctBal.getAmount().getCurrency());
			
			 balanceList.add(builder.build());
			
		 }		 
		 
		 return ResponseEntity.ok(AccountBalanceResponse.builder().accountBalances(balanceList).build());
	}

	private HttpHeaders httpHeaders(String token, String financialId) {
		HttpHeaders headers = new HttpHeaders();
		headers.set(Constants.AUTHORIZATION, "Bearer " + token);
		headers.set(Constants.X_FAPI_FINANCIAL_ID, financialId);		
		return headers;
	}
}

