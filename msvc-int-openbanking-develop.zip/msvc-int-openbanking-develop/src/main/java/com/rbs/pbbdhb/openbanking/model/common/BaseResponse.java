package com.rbs.pbbdhb.openbanking.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * FinalTokenResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class BaseResponse{
	
	public String error;
	
	public String error_description;
	
	public String error_uri;

}
