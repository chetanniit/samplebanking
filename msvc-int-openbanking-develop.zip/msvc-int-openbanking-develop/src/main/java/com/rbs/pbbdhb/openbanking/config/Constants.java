package com.rbs.pbbdhb.openbanking.config;

/**
 * Application Constants
 * 
 * @author gunasm
 *
 */
public final class Constants {

	public static final String INTERNAL_SERVER_ERROR = "internal.server.error";
	public static final String PAYMENTS = "payments";
	public static final String ACCOUNTS = "accounts";
	public static final String NWB = "nwb";
	public static final String RBS = "rbs";
	public static final String NO_ACCOUNTS_AVAILABLE = "NO_ACCOUNTS_AVAILABLE";

	public static final String AVAILABLE = "Available";

	public static final String EXPECTED = "Expected";

	public static final String PRE_AGREED = "Pre-Agreed";
	public static final String JKS = "JKS";

	public static final String JWS = "JWS";

	public static final String DEBIT = "Debit";

	public static final String CREDIT = "Credit";
	public static final String X_59 = "X.509";
	public static final String RSA = "RSA";
	public static final String PKCS12 = "pkcs12";
	public static final String P12 = ".p12";
	public static final String REQUEST_TIMED_OUT = "request.timed.out";
	public static final String AUTHORIZATION = "Authorization";
	public static final String X_FAPI_FINANCIAL_ID = "x-fapi-financial-id";
	public static final String CLIENT_ASSERTION_TYPE = "client_assertion_type";
	public static final String CLIENT_ASSERTION = "client_assertion";
	public static final String CIN = "cin";
	public static final String SCOPE = "scope";
	public static final String LOGIN_HINT = "login_hint";
	public static final String INTENT_ID = "intent_id";
	public static final String CUSTOMER_TYPE = "customerType";
	public static final String AUTH_REQ_ID = "auth_req_id";
	public static final String GRANT_TYPE = "grant_type";
	public static final String X_IDEMPOTENCY_KEY = "x-idempotency-key";
	public static final String X_JWS_SIGNATURE = "x-jws-signature";
	public static final String CLIENT_ID = "client_id";
	public static final String X_FAPI_INERACTION_ID = "x-fapi-interaction-id";
	public static final String ENC_CIN = "enc_cin";
	public static final String AUD = "aud";
	public static final String API_CIBA = ".api.ciba";
	public static final String SUB = "sub";
	public static final String ISS = "iss";
	public static final String CUST_TYPE = "cust_type";
	public static final String IAT = "iat";
	public static final String EXP = "exp";
	public static final String JTI = "jti";

	public static final String REDEMPTIONS = "redemptions";
	public static final String REDEMPTION_CLOSURE_STP_ORDER_TXT = "STP-RCI-DPCPAYMENT";
	
	public static final String LUMPSUM = "lumpsum";
	public static final String EMPTY_STRING = "";
}
