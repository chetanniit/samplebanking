package com.rbs.pbbdhb.openbanking.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * AccessTokenResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class AccessTokenResponse extends BaseResponse{

	private String access_token;

	private String token_type;

	private int expires_in;
}
