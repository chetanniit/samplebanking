package com.rbs.pbbdhb.openbanking.common;

import java.util.HashMap;
import java.util.Map;

/**
 * class to hold thread variables
 * 
 *
 */
public class CustomThreadLocal {

	private CustomThreadLocal() {}
	
	private static ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();
	
	/**
	 * sets key value
	 * @param key key
	 * @param obj obj
	 *
	 */
	public static void setKeyValue(String key, Object obj) {
		Map<String, Object> map = threadLocal.get();
		if(null == map) {
			 map = new HashMap<>();
			threadLocal.set(map);
		}
		map.put(key, obj);
	}
	
	/**
	 * get value by key
	 * 
	 * @param key key
	 * @return Object
	  */
	
	public static Object getValueByKey(String key) {
		Map<String, Object> map = threadLocal.get();
		if(null == map) {
			return null;
		}
		return map.get(key);
	}
	
	/**
	 * To Clear
	 * 
	 */
	public static void clear() {
		threadLocal.remove();
	}
}
