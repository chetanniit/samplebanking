package com.rbs.pbbdhb.openbanking.model.payment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * OBWriteDataDomesticConsent4
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class OBWriteDataDomesticConsent {

	@JsonProperty("DomesticPaymentId")
	private String domesticPaymentId;

	@JsonProperty("ConsentId")
	private String consentId;

	@JsonProperty("Initiation")
	@NotNull
	@Valid
	private OBDomestic initiation = null;

	@JsonProperty("Status")
	private String status;
}

