package com.rbs.pbbdhb.openbanking.service.impl;

import java.security.interfaces.RSAPrivateKey;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.collect.Maps;
import com.rbs.pbbdhb.openbanking.common.CustomThreadLocal;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.config.KeytoolHelper;
import com.rbs.pbbdhb.openbanking.model.account.AccountAccessConsentsResponse;
import com.rbs.pbbdhb.openbanking.model.account.AccountRequest;
import com.rbs.pbbdhb.openbanking.model.account.AccountRequestData;
import com.rbs.pbbdhb.openbanking.model.account.Risk;
import com.rbs.pbbdhb.openbanking.model.common.JwsHeaders;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;
import com.rbs.pbbdhb.openbanking.service.GenerateConsentService;
import com.rbs.pbbdhb.openbanking.service.RestService;

/**
 * GenerateConsent Service
 *
 * @author gunasm
 *
 */
@Service
public class GenerateConsentServiceImpl implements GenerateConsentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GenerateConsentServiceImpl.class);

	private static ObjectMapper objectMapper = configureMapper();

	@Value("#{'${ob.client.permissions}'.split(',')}")
	private List<String> permissions;

	@Value("${ob.client.financial.id}")
	private String financialId;

	@Value("${ob.auth.clientId}")
	private String clientId;

	@Value("${ob.api.account.consent.nwb.path}")
	private String consentUrlNwb;

	@Value("${ob.api.account.consent.rbs.path}")
	private String consentUrlRbs;

	@Value("${ob.api.payment.consent.nwb.path}")
	private String paymentConsentUrlNwb;

	@Value("${ob.api.payment.consent.rbs.path}")
	private String paymentConsentUrlRbs;

	@Value("${ob.auth.client.tppid}")
	private String tppId;

	@Value("${ob.auth.client.jks.path}")
	private Resource clientJksPath;

	@Value("${ob.auth.client.jks.password}")
	private String clientJksPassword;

	@Value("${ob.auth.client.kid}")
	private String kid;

	@Value("${ob.trust.anchor.value}")
	private String trustAnchor;

	@Autowired
	RestService restService;

	/*@Autowired
	@Qualifier("userProxyRestTemplate")
	RestTemplate restService;*/



	@Override
	public ResponseEntity<AccountAccessConsentsResponse> generateAccountConsentToken(String iamToken, String brand) {

		String consentUrl = (brand.equalsIgnoreCase(Constants.NWB) ? consentUrlNwb : consentUrlRbs);
		
		LOGGER.debug("Generating account consent token for brand - {}, consent Url - {}",brand,consentUrl);

		HttpHeaders headers = httpHeaders(iamToken, financialId);

		AccountRequestData data = new AccountRequestData();
		data.setPermissions(permissions);

		AccountRequest accountRequest = new AccountRequest();
		accountRequest.setData(data);
		accountRequest.setRisk(new Risk());

		HttpEntity<AccountRequest> entity = new HttpEntity<>(accountRequest, headers);

		ResponseEntity<AccountAccessConsentsResponse> response = restService.exchange(consentUrl, HttpMethod.POST,
				entity, AccountAccessConsentsResponse.class);

		return response;
	}

	private HttpHeaders httpHeaders(String iamToken, String financialId) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(Constants.AUTHORIZATION, "Bearer " + iamToken);
		headers.set(Constants.X_FAPI_FINANCIAL_ID, financialId);
		return headers;
	}

	@Override
	public ResponseEntity<OBWriteDomesticConsent> generatePaymentConsent(String token, OBWriteDomesticConsent domesticConsent, String brand) {

		String paymentConsentUrl = (brand.equalsIgnoreCase(Constants.NWB) ? paymentConsentUrlNwb : paymentConsentUrlRbs);

		LOGGER.debug("Generating payment consent token for brand - {}, consent Url - {}",brand,paymentConsentUrl);

		String requestBody = toJson(domesticConsent);

		String jwsSignatureValue = setRequestSignature(requestBody, tppId,
				clientId);

		String interactionId = UUID.randomUUID().toString();
		LOGGER.info("payment - consent interaction id for cin : {} , {}",
				CustomThreadLocal.getValueByKey(Constants.ENC_CIN),
				interactionId);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(Constants.AUTHORIZATION, "Bearer " + token);
		headers.set(Constants.X_FAPI_FINANCIAL_ID, financialId);
		headers.set(Constants.X_IDEMPOTENCY_KEY, UUID.randomUUID().toString().replace("-", ""));
		headers.set(Constants.X_JWS_SIGNATURE, jwsSignatureValue);
		headers.set(Constants.X_FAPI_INERACTION_ID, interactionId);

		HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
		
		ResponseEntity<OBWriteDomesticConsent> response = restService.exchange(paymentConsentUrl, HttpMethod.POST, entity,
				OBWriteDomesticConsent.class);

		LOGGER.debug("consent created for cin :" + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		return response;
	}

	private String setRequestSignature(String requestBody, String tppId, String clientId) {

		StringBuilder issuer = new StringBuilder().append(tppId).append("/").append(clientId);
		return signWithDetachedJws(requestBody, issuer.toString());
	}

	public String signWithDetachedJws(String message, String issuer) {
		JsonWebSignature jws = createJwsSigner(message, issuer);
		try {
			return jws.getDetachedContentCompactSerialization();
		} catch (JoseException e) {
			throw new RuntimeException(e);
		}
	}

	private JsonWebSignature createJwsSigner(String payload, String issuer) {
		return createJwsSignerImpl(payload, issuer);
	}

	private JsonWebSignature createJwsSignerImpl(String payload, String issuer) {
		JsonWebSignature jws = new JsonWebSignature();
		jws.setPayload(payload);
		jws.setKey(privateKey(clientJksPath.getFilename(), clientJksPassword, clientId));
		headers(issuer).forEach((k, v) -> jws.getHeaders().setObjectHeaderValue(k, v));
		jws.setCriticalHeaderNames(JwsHeaders.CRITICAL_HEADER_CLAIMS.toArray(new String[0]));
		return jws;
	}

	private Map<String, Object> headers(String issuer) {
		Map<String, Object> headers = Maps.newHashMap();
		headers.put(HeaderParameterNames.ALGORITHM, AlgorithmIdentifiers.RSA_PSS_USING_SHA256);
		headers.put(HeaderParameterNames.KEY_ID, kid);
		headers.put(JwsHeaders.ISSUED_AT, Instant.now().getEpochSecond());
		headers.put(JwsHeaders.ISSUER, issuer);
		headers.put(JwsHeaders.TRUST_ANCHOR, trustAnchor);
		return headers;
	}

	private RSAPrivateKey privateKey(String keystorePath, String keystorePassword, String alias) {
		try {
			return (RSAPrivateKey) KeytoolHelper.key(keystorePath, keystorePassword, alias);
		} catch (Exception e) {
			throw new RuntimeException(String.format(
					"There was a problem getting the private key with alias %s from %s", alias, keystorePath), e);
		}
	}

	public static String toJson(final Object object) {
		try {
			return objectMapper.writeValueAsString(object);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static ObjectMapper configureMapper() {
		final ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(JsonParser.Feature.ALLOW_COMMENTS, true);

		return mapper;
	}
}