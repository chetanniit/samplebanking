package com.rbs.pbbdhb.openbanking.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * BcAuthorized Token Response
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class BcAuthorizedTokenResponse extends BaseResponse {

	public String auth_req_id;

	public String expires_in;

}
