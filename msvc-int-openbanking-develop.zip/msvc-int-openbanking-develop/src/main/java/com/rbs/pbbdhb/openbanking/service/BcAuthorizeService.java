package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.common.BcAuthorizedTokenResponse;

/**
 * BcAuthorizeService
 * 
 * @author gunasm
 *
 */
public interface BcAuthorizeService {

	/**
	 * 
	 * @param consentId consentId
	 * @param jwt jwt
	 * @param cin cin
	 * @param scope scope
	 * @param brand brand
	 * @return bcAuthorizedTokenResponse
	 * @throws Exception 
	 */
	ResponseEntity<BcAuthorizedTokenResponse> getBcAuthorized(String consentId, String jwt, String cin,
			String scope, String brand) throws Exception;
	
}
