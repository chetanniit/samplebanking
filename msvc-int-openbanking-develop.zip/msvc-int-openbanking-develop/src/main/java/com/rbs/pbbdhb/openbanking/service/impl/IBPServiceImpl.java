package com.rbs.pbbdhb.openbanking.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.rbs.pbbdhb.openbanking.common.CustomThreadLocal;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.account.AccountAccessConsentsResponse;
import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;
import com.rbs.pbbdhb.openbanking.model.common.BcAuthorizedTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.FinalTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.IamTokenResponse;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentRequest;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;
import com.rbs.pbbdhb.openbanking.service.AccountDetailsService;
import com.rbs.pbbdhb.openbanking.service.BcAuthorizeService;
import com.rbs.pbbdhb.openbanking.service.FinalTokenService;
import com.rbs.pbbdhb.openbanking.service.GenerateConsentService;
import com.rbs.pbbdhb.openbanking.service.IBPService;
import com.rbs.pbbdhb.openbanking.service.IamTokenGeneratorService;
import com.rbs.pbbdhb.openbanking.service.PaymentService;
import com.rbs.pbbdhb.openbanking.util.PaymentHelper;

/**
 * Generate Token Service
 * 
 * @author gunasm
 *
 */
@Service
public class IBPServiceImpl implements IBPService {

	private static final Logger log = LoggerFactory.getLogger(IBPServiceImpl.class);

	@Autowired
	private IamTokenGeneratorService generateIamTokenService;
	
	@Autowired
	private GenerateConsentService generateConsentService;
	
	@Autowired
	private BcAuthorizeService bcAuthorizeService;
	
	@Autowired
	private FinalTokenService finalTokenService;
	
	@Autowired
	private AccountDetailsService accountDetailsService;
	
	@Autowired
	private PaymentService paymentService;
	
	@Autowired
	private PaymentHelper paymentHelper;
	
	@Override
	public ResponseEntity<AccountBalanceResponse> getAccountBalances(String cin, String brand) {
		ResponseEntity<IamTokenResponse> resp = null;
		try {
			resp = generateIamTokenService.generateIamToken(Constants.ACCOUNTS,brand);
		
		} catch (Exception e) {			
			log.error("Something went wrong while generating IAM token",e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(generateAccountsResponse(resp.getBody().getError_description()));
		}
		
		if(Strings.isNullOrEmpty(resp.getBody().getIamToken()) || Strings.isNullOrEmpty(resp.getBody().getJwt())){
			log.debug("Not able to generate IAM token.");
			return ResponseEntity.status(resp.getStatusCode()).body(generateAccountsResponse(resp.getBody().getError_description()));
		}
		
		log.info("iamToken is generated for cin: " + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		ResponseEntity<AccountAccessConsentsResponse> consentResp = generateConsentService.generateAccountConsentToken(resp.getBody().getIamToken(),brand);
		
		if(null == consentResp.getBody().getData() || Strings.isNullOrEmpty(consentResp.getBody().getData().getConsentId())){
			log.debug("Not able to generate consent for Accounts.");
			return ResponseEntity.status(consentResp.getStatusCode()).body(generateAccountsResponse(consentResp.getBody().getError_description()));
		}		
		
		String consentToken = consentResp.getBody().getData().getConsentId();
				
		log.info("Consent token is generated for cin: " + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));

		ResponseEntity<BcAuthorizedTokenResponse> bcAuthorizedResp;
		try {
			bcAuthorizedResp = bcAuthorizeService.getBcAuthorized(consentToken, resp.getBody().getJwt(), cin, Constants.ACCOUNTS,brand);
		} catch (Exception e) {
			log.error("Something went wrong while generating BC Authorize token",e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(generateAccountsResponse(resp.getBody().getError_description()));
		}
		
		if(Strings.isNullOrEmpty(bcAuthorizedResp.getBody().getAuth_req_id())){
			log.debug("Not able to Generate BC Authorize token.");
			return ResponseEntity.status(bcAuthorizedResp.getStatusCode()).body(generateAccountsResponse(bcAuthorizedResp.getBody().getError_description()));
		}
		
		String bcAuthorizedToken = bcAuthorizedResp.getBody().getAuth_req_id();

		log.debug("bc Authorized token generated for cin ::" + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		ResponseEntity<FinalTokenResponse> finalTokenResp = finalTokenService.getFinalToken(bcAuthorizedToken, resp.getBody().getJwt(),brand);		
		
		if (Strings.isNullOrEmpty(finalTokenResp.getBody().getAccess_token())){
			
			log.debug("Final token is not generated. Response from OB API: {}, error code: {}",finalTokenResp.getBody().getError_description(),finalTokenResp.getStatusCode());
			return ResponseEntity.status(finalTokenResp.getStatusCode()).body(generateAccountsResponse(finalTokenResp.getBody().getError_description()));
		}
		
		log.debug("final token generated for cin ::" + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		ResponseEntity<AccountBalanceResponse> accountBalance = accountDetailsService.getAccountDetails(finalTokenResp.getBody().getAccess_token(),brand);
		log.info("Returning response now: "+accountBalance);
		
		return accountBalance;
	}

	private AccountBalanceResponse generateAccountsResponse(String errorMessage) {
		AccountBalanceResponse resp = new AccountBalanceResponse(Lists.newArrayList());
		resp.setErrorMessage(errorMessage);
		return resp;
	}
	
	private IBPPaymentResponse generatePaymentsResponse(String errorMessage) {
		IBPPaymentResponse resp = new IBPPaymentResponse();
		resp.setErrorMessage(errorMessage);
		return resp;
	}
	
	@Override
	public ResponseEntity<IBPPaymentResponse> createDomesticPayment(String cin, String accountNumber, String brand,
			IBPPaymentRequest request, String source) {
		OBWriteDomesticConsent domesticConsent = paymentHelper.createRequest(request, brand, accountNumber, source);
		ResponseEntity<IamTokenResponse> resp = null;
		
		try{
			resp = generateIamTokenService.generateIamToken(Constants.PAYMENTS,brand);

		} catch (Exception e) {			
			log.error("Something went wrong while generating IAM token",e);
			return new ResponseEntity<IBPPaymentResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(Strings.isNullOrEmpty(resp.getBody().getIamToken()) || Strings.isNullOrEmpty(resp.getBody().getJwt())){
			log.debug("Not able to generate IAM token.");
			return ResponseEntity.status(resp.getStatusCode()).body(generatePaymentsResponse(resp.getBody().getError_description()));
		}
		
		log.info("iamToken is generated for cin: " + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		ResponseEntity<OBWriteDomesticConsent> obWriteDomesticConsent = generateConsentService
				.generatePaymentConsent(resp.getBody().getIamToken(), domesticConsent,brand);
		
		if(null == obWriteDomesticConsent.getBody().getData() || Strings.isNullOrEmpty(obWriteDomesticConsent.getBody().getData().getConsentId())){
			log.debug("Not able to generate consent for Payments.");
			return ResponseEntity.status(obWriteDomesticConsent.getStatusCode()).body(generatePaymentsResponse(obWriteDomesticConsent.getBody().getError_description()));
		}		
		
		String consentToken = obWriteDomesticConsent.getBody().getData().getConsentId();
				
		log.info("Consent token is generated for cin: " + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
			
		ResponseEntity<BcAuthorizedTokenResponse> bcAuthorizedResp;
		try {
			bcAuthorizedResp = bcAuthorizeService.getBcAuthorized(consentToken,
					 resp.getBody().getJwt(), cin,Constants.PAYMENTS,brand);
		} catch (Exception e) {
			log.error("Something went wrong while generating BC Authorize token",e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(generatePaymentsResponse(resp.getBody().getError_description()));
		}
		
		if(Strings.isNullOrEmpty(bcAuthorizedResp.getBody().getAuth_req_id())){
			log.debug("Not able to Generate BC Authorize token.");
			return ResponseEntity.status(bcAuthorizedResp.getStatusCode()).body(generatePaymentsResponse(bcAuthorizedResp.getBody().getError_description()));
		}
		
		String bcAuthorizedToken = bcAuthorizedResp.getBody().getAuth_req_id();
		
		log.debug("bc Authorized token generated for cin ::" + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		ResponseEntity<FinalTokenResponse> tokenResp = finalTokenService.getFinalToken(bcAuthorizedToken,
				resp.getBody().getJwt(),brand);

		if (Strings.isNullOrEmpty(tokenResp.getBody().getAccess_token())){
			
			log.debug("Final token is not generated, returning server error. Response from OB API: {}",tokenResp.getBody().getError_description());
			return ResponseEntity.status(tokenResp.getStatusCode()).body(generatePaymentsResponse(tokenResp.getBody().getError_description()));
		}
		
		log.debug("final token generated for cin ::" + CustomThreadLocal.getValueByKey(Constants.ENC_CIN));
		
		ResponseEntity<OBWriteDomesticConsent> paymentDetails = paymentService
				.createDomesticPayment(tokenResp.getBody().getAccess_token(), obWriteDomesticConsent.getBody(),brand);
		log.info("Returning response now: " + paymentDetails);
		
		if (!paymentDetails.getStatusCode().is2xxSuccessful()) {
			log.debug("Payment API call failed. Response from OB API: {}",paymentDetails.getBody().getError_description());
			return ResponseEntity.status(tokenResp.getStatusCode()).body(generatePaymentsResponse(paymentDetails.getBody().getError_description()));
		}
		
		IBPPaymentResponse response = paymentHelper.createResponse(paymentDetails.getBody());
		return ResponseEntity.status(paymentDetails.getStatusCode()).body(response);
	}	
	
}
