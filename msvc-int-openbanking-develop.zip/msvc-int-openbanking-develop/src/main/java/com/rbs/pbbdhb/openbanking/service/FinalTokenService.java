package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.common.FinalTokenResponse;

/**
 * FinalTokenService
 * 
 * @author gunasm
 *
 */
public interface FinalTokenService {

	/**
	 * Final Token Service
	 * 
	 * @param bcAuthorizedToken bcAuthorizedToken
	 * @param iamToken iamToken
	 * @param brand brand
	 * @return finalToken
	 */
	ResponseEntity<FinalTokenResponse> getFinalToken(String bcAuthorizedToken, String iamToken, String brand);
	
}
