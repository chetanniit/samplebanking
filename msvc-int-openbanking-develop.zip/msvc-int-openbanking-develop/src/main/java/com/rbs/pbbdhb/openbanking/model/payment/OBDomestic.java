package com.rbs.pbbdhb.openbanking.model.payment;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * The Initiation payload is sent by the initiating party to the ASPSP. It is
 * used to request movement of funds from the debtor account to a creditor for a
 * single domestic payment.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(getterVisibility = JsonAutoDetect.Visibility.NONE)
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class OBDomestic {

	@JsonProperty("InstructionIdentification")
	@Size(min = 1, max = 35)
	@NotNull
	private String instructionIdentification = null;

	@JsonProperty("EndToEndIdentification")
	@Size(min = 1, max = 35)
	@NotNull
	private String endToEndIdentification = null;

	@JsonProperty("LocalInstrument")
	@Size(min = 1, max = 50)
	private String localInstrument = null;

	@JsonProperty("InstructedAmount")
	@NotNull
	@Valid
	private OBDomesticInstructedAmount instructedAmount = null;

	@JsonProperty("DebtorAccount")
	@NotNull
	@Valid
	private OBCashAccountDebtor debtorAccount = null;

	@JsonProperty("CreditorAccount")
	@NotNull
	@Valid
	private OBCashAccountCreditor creditorAccount = null;

	@JsonProperty("RemittanceInformation")
	@Valid
	private OBRemittanceInformation remittanceInformation = null;

}

