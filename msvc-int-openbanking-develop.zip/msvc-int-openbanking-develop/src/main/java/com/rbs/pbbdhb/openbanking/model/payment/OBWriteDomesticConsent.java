package com.rbs.pbbdhb.openbanking.model.payment;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.pbbdhb.openbanking.model.common.BaseResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * OBWriteDomesticConsent4
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(getterVisibility = JsonAutoDetect.Visibility.NONE)
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class OBWriteDomesticConsent extends BaseResponse {

	@JsonProperty("Data")
	@NotNull
	@Valid
	private OBWriteDataDomesticConsent data = null;

	@JsonProperty("Risk")
	@NotNull
	@Valid
	private OBRisk risk = null;
}
