package com.rbs.pbbdhb.openbanking.service.impl;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.rbs.pbbdhb.openbanking.common.CustomThreadLocal;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.common.FinalTokenResponse;
import com.rbs.pbbdhb.openbanking.service.FinalTokenService;
import com.rbs.pbbdhb.openbanking.service.RestService;

/**
 * Generate Token Service
 * 
 * @author gunasm
 *
 */
@Service
public class FinalTokenServiceImpl implements FinalTokenService {

	private static final Logger log = LoggerFactory.getLogger(FinalTokenServiceImpl.class);	
	
	@Value("${ob.auth.token.nwb.path}")
	private String tokenUrlNwb;
	
	@Value("${ob.auth.token.rbs.path}")
	private String tokenUrlRbs;
	
	@Value("${ob.client.assertion.type}")
	private String clientAssertionType;	
	
	@Value("${ob.client.grant.type.ciba}")
	private String grantType;	
	
	@Autowired
	RestService restService;

	/*@Autowired
	@Qualifier("customRestTemplate")
	RestTemplate restService;*/
		

	@Override
	public ResponseEntity<FinalTokenResponse> getFinalToken(String bcAuthorizedToken, String iamToken, String brand) {
		
		String tokenPath = (brand.equalsIgnoreCase(Constants.NWB) ? tokenUrlNwb : tokenUrlRbs);
		
		log.debug("Generating Final token for brand - {}, token Url - {}",brand,tokenPath);
		
		MultiValueMap<String, String> finalTokenBodyParamsMap = finalTokenParams(bcAuthorizedToken, iamToken);
		
		String interactionId = UUID.randomUUID().toString();
		log.info("Interaction id for cin : {} , {}", CustomThreadLocal.getValueByKey(Constants.ENC_CIN), interactionId);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set(Constants.X_FAPI_INERACTION_ID, interactionId);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(finalTokenBodyParamsMap, headers);
		ResponseEntity<FinalTokenResponse> response = restService.exchange(tokenPath, HttpMethod.POST, entity,
					FinalTokenResponse.class);

		return response;
	}

	private MultiValueMap<String, String> finalTokenParams(String bcAuthorizedToken, String iamToken) {
		MultiValueMap<String, String> finalTokenBodyParamsMap = new LinkedMultiValueMap<>();

		finalTokenBodyParamsMap.add(Constants.CLIENT_ASSERTION_TYPE, clientAssertionType);
		finalTokenBodyParamsMap.add(Constants.CLIENT_ASSERTION, iamToken);
		finalTokenBodyParamsMap.add(Constants.AUTH_REQ_ID, bcAuthorizedToken);
		finalTokenBodyParamsMap.add(Constants.GRANT_TYPE, grantType);
		return finalTokenBodyParamsMap;
	}
}
