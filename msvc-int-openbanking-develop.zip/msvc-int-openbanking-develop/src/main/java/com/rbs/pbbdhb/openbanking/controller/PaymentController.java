package com.rbs.pbbdhb.openbanking.controller;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbs.pbbdhb.openbanking.common.CustomThreadLocal;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentRequest;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;
import com.rbs.pbbdhb.openbanking.service.IBPService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * Payment controller for IBP/domestic payment
 * 
 * @author gunasm
 *
 */
@RestController
@RequestMapping("/")
@Tag(description = "Payment Controller", name = "Payment Controller")
@Slf4j
public class PaymentController {

	@Autowired
	private IBPService ibpService;

	@Operation(description = "Make domestic payments", method = "createDomesticPayment",
			summary = "Returns Http Status")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created",content = @Content(schema = @Schema(implementation = IBPPaymentResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content=@Content),
			@ApiResponse(responseCode = "401", description = "Not authenticated", content=@Content),
			@ApiResponse(responseCode = "404", description = "Resource not found", content=@Content),
			@ApiResponse(responseCode = "500", description = "Internal server error", content=@Content),
			@ApiResponse(responseCode = "503", description = "Service not available", content=@Content)})
	@Parameters({
			@Parameter(name = "brand",example = "nwb",in = ParameterIn.HEADER),
			@Parameter(name = "account_number",example = "35168072",in = ParameterIn.HEADER),
			@Parameter(name = "cin",example = "1938370002",in = ParameterIn.HEADER),
			@Parameter(name = "source", example="redemptions", in = ParameterIn.HEADER)
	})
	@PostMapping(path = "/domesticPayments", produces = { "application/json" })
	public ResponseEntity<IBPPaymentResponse> createDomesticPayment(@RequestHeader("cin") String cin,
			@RequestHeader("account_number") @Valid @NotNull(message = "account number can not be null") String accountNumber,
			@RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
			@RequestHeader("source") @Valid @Pattern(regexp = "(lumpsum|redemptions)", message = "Invalid source") String source,
			@RequestBody IBPPaymentRequest request) {
		log.info("createDomesticPayment for {} with brand {}", cin, brand);
		CustomThreadLocal.setKeyValue(Constants.ENC_CIN, getEncCin(cin));
		ResponseEntity<IBPPaymentResponse> response = ibpService.createDomesticPayment(cin, accountNumber, brand, request, source);
		log.info("Payment response : {}", response.getBody());
		return response;
	}

	private String getEncCin(String cin) {
		StringBuilder formated = new StringBuilder("*****");
		formated.append(cin.substring(5));
		return formated.toString();
	}
	

}
