package com.rbs.pbbdhb.openbanking.model.account;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Balance
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Balance {

    @Schema(name = "accountNumber",description = "account number",example = "32586084")
    private String accountNumber;

    @Schema(name = "currentBalance",description = "current balance",example = "42338.42")
    private BigDecimal currentBalance;

    @Schema(name = "arrangedOverdraft",description = "arranged overdraft",example = "5249.38")
    private BigDecimal arrangedOverdraft;

    @Schema(name = "accountType",description = "account type",example = "Personal")
    private String accountType;

    @Schema(name = "subType",description = "subtype",example = "CurrentAccount")
    private String subType;

    @Schema(name = "description",description = "description",example = "SELECT ACCOUNT")
    private String description;

    @Schema(name = "sortCode",description = "sort code",example = "606002")
    private String sortCode;

    @Schema(name = "name",description = "name",example = "LFLJKL")
    private String name;

    @Schema(name = "currency",description = "currency",example = "GBP")
    private String currency;

    @Schema(name = "balanceLastUpdatedTime",description = "balance last updated time",example = "05-12-2023T09:17:33.938Z")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy'T'HH:mm:ss.SSS'Z'")
	private LocalDateTime balanceLastUpdatedTime;

}
