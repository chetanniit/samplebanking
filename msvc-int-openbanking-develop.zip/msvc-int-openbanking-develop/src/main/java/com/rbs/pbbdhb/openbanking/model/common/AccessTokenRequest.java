package com.rbs.pbbdhb.openbanking.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import jakarta.validation.constraints.NotEmpty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * AccessTokenRequest
 * 
 * @author gunasm
 *
 */
@ToString
@EqualsAndHashCode
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({ "client_id", "scope", "client_assertion_type", "grant_type" })
public class AccessTokenRequest {

	@NotEmpty(message = "Please enter client_id")
	private String client_id;

	@NotEmpty(message = "Please enter scope")
	private String scope;

	@NotEmpty(message = "Please enter client_assertion_type")
	private String client_assertion_type;

	@NotEmpty(message = "Please enter grant_type")
	private String grant_type;

}
