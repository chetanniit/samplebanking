package com.rbs.pbbdhb.openbanking.service.impl;

import java.security.GeneralSecurityException;
import java.security.interfaces.RSAPrivateKey;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.config.KeytoolHelper;
import com.rbs.pbbdhb.openbanking.model.common.AccessTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.IamTokenResponse;
import com.rbs.pbbdhb.openbanking.service.IamTokenGeneratorService;
import com.rbs.pbbdhb.openbanking.service.RestService;

import net.minidev.json.JSONObject;

/**
 * Generate Iam Token Service Impl
 * 
 * @author gunasm
 *
 */
@Service
public class IamTokenGeneratorServiceImpl implements IamTokenGeneratorService {

	private static final Logger log = LoggerFactory.getLogger(IamTokenGeneratorServiceImpl.class);	

	@Value("${ob.auth.clientId}")
	private String clientId;

	@Value("${ob.auth.token.nwb.path}")
	private String tokenUrlNwb;
	
	@Value("${ob.auth.token.rbs.path}")
	private String tokenUrlRbs;

	@Value("${ob.auth.client.jks.path}")
	private Resource clientJksPath;

	@Value("${ob.auth.client.jks.password}")
	private String clientJksPassword;

	@Value("${ob.auth.client.kid}")
	private String kid;
	
	@Value("${ob.client.assertion.type}")
	private String clientAssertionType;	
	
	@Value("${ob.client.grant.type.credentials}")
	private String grantType;
	
	@Autowired
	RestService restService;

	/*@Autowired
	@Qualifier("customRestTemplate")
	RestTemplate restService;*/
	
	@Override
	public ResponseEntity<IamTokenResponse> generateIamToken(String scope, String brand) throws RuntimeException,JOSEException,GeneralSecurityException{
		
		String tokenUrl = (brand.equalsIgnoreCase(Constants.NWB) ? tokenUrlNwb : tokenUrlRbs);
		
		log.debug("Generating IAM token for brand - {}, tokenUrl - {}",brand,tokenUrl);
		
		Map<String, Object> claims = new HashMap<>();

		claims.put(Constants.SUB, clientId); // client id
		claims.put(Constants.AUD, tokenUrl);
		claims.put(Constants.SCOPE, scope);
		claims.put(Constants.ISS, clientId);
		claims.put(Constants.IAT, System.currentTimeMillis() / 1000);
		claims.put(Constants.EXP, (System.currentTimeMillis() + (1000 * 60 * 60)) / 1000);
		claims.put(Constants.JTI, UUID.randomUUID().toString());

		RSAPrivateKey key = (RSAPrivateKey) KeytoolHelper.key(clientJksPath.getFilename(), clientJksPassword,clientId);

		JWSSigner jwsSigner = new RSASSASigner(key);

		JWSObject jwsObject = new JWSObject(
				new JWSHeader.Builder(JWSAlgorithm.PS256).type(new JOSEObjectType(Constants.JWS))
						.keyID(kid).build(),
				new Payload(new JSONObject(claims).toJSONString()));

		jwsObject.sign(jwsSigner);	
		log.info("JWS generated");
		
		String jwt = jwsObject.serialize();

		MultiValueMap<String, String> tokenBodyParamsMap = new LinkedMultiValueMap<>();

		tokenBodyParamsMap.add(Constants.CLIENT_ID, clientId);
		tokenBodyParamsMap.add(Constants.SCOPE, scope);
		tokenBodyParamsMap.add(Constants.CLIENT_ASSERTION_TYPE, clientAssertionType);
		tokenBodyParamsMap.add(Constants.CLIENT_ASSERTION, jwt);
		tokenBodyParamsMap.add(Constants.GRANT_TYPE, grantType);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(tokenBodyParamsMap, headers);
		
		ResponseEntity<AccessTokenResponse> response = restService.exchange(tokenUrl, HttpMethod.POST, entity,
				AccessTokenResponse.class);

		IamTokenResponse resp = IamTokenResponse.builder().jwt(jwt).iamToken(response.getBody().getAccess_token()).build();
		
		return ResponseEntity.status(response.getStatusCode()).body(resp);
		
	}
}
