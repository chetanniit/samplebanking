package com.rbs.pbbdhb.openbanking.model.account;

import java.util.List;

import com.rbs.pbbdhb.error.BaseResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * AccountDetailResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountBalanceResponse extends BaseResponse {

    private static final long serialVersionUID = 6131314620875633111L;

    private List<Balance> accountBalances;
}
