package com.rbs.pbbdhb.openbanking.model.payment;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OBWriteDomesticConsent4
 */


@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor

public class DomesticPaymentRequest{

	@Pattern(regexp = "^\\d{1,13}$|^\\d{1,13}\\.\\d{1,5}$")
	@NotNull
	private String amount;
	
	@Pattern(regexp = "^[A-Z]{3,3}$",message="currency is invalid")
	@NotNull
	private String currency;
	
	@Size(min = 1, max = 70)
	@NotNull
	private String debtorAccountNumber;
	
	@Size(min = 1, max = 70)
	@NotNull
	private String debtorAccountSortCode;

}
