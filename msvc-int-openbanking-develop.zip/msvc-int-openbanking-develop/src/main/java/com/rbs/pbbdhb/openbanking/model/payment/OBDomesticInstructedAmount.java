package com.rbs.pbbdhb.openbanking.model.payment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * Amount of money to be moved between the debtor and creditor, before deduction
 * of charges, expressed in the currency as ordered by the initiating party.
 * Usage: This amount has to be transported unchanged through the transaction
 * chain.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class OBDomesticInstructedAmount {

	@JsonProperty("Amount")
	@Pattern(regexp = "^\\d{1,13}$|^\\d{1,13}\\.\\d{1,5}$")
	@NotNull
	private String amount = null;

	@JsonProperty("Currency")
	@Pattern(regexp = "^[A-Z]{3,3}$",message="Currency is invalid")
	@NotNull
	private String currency = null;
}
