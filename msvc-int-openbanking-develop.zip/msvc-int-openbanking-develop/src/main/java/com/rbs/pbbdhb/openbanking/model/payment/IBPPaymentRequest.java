package com.rbs.pbbdhb.openbanking.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OBWriteDomesticConsent4
 */


@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor

public class IBPPaymentRequest{

	@Schema(name = "amount",description = "amount",example = "200")
	@Pattern(regexp = "^\\d{1,13}$|^\\d{1,13}\\.\\d{1,5}$")
	@NotNull
	private String amount;

	@Schema(name = "currency",description = "currency",example = "GBP")
	@Pattern(regexp = "^[A-Z]{3,3}$", message="Currency is invalid")
	@NotNull
	private String currency;

	@Schema(name = "debtorSortCodeAccountNumber",description = "debtor sort code account number",example = "83198495_STPLSI_20231115131901")
	@Size(min = 1, max = 70)
	@NotNull
	private String debtorSortCodeAccountNumber;

}
