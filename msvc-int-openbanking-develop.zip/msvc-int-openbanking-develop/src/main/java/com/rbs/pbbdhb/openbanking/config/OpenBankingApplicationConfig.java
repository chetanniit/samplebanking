package com.rbs.pbbdhb.openbanking.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;

import jakarta.annotation.PostConstruct;
import javax.net.ssl.SSLContext;

import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactoryBuilder;
import org.apache.hc.client5.http.ssl.TrustSelfSignedStrategy;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * Config class for application
 * 
 * @author gunasm
 *
 */
@Configuration
public class OpenBankingApplicationConfig {
	
	@Value("${msvc.openbanking.proxyHost}")
	private String appProxyUrl;
		
	@Value("#{new Integer('${proxy.port}')}")
	private Integer proxyPort;
	
	@Value("${ob.client.transport.public.certificate}")
	private String cert;
	
	@Value("${ob.client.transport.private.key}")
	private String privateKey;
	
	@Value("${ob.client.transport.private.key.password}")
	private String certPassword;	

	@Value("${ob.client.transport.truststore.path}")
	private Resource truststorePath;	
	
	@Value("${ob.truststore.password}")
	private String trustPass;

	@Value("${ob.client.proxy.url}")
	private String userProxyUrl;

	@Value("${ob.client.proxy.username}")
	private String userName;

	@Value("${ob.client.proxy.password}")
	private String password;

	@Value("${ob.client.proxy.domain}")
	private String domain;

	@Value("#{new Boolean('${ob.client.proxy.enabled}')}")
	private Boolean enabled;

	@Autowired
	ProxyConfigurator proxyConfigurator;

	@Autowired
	KeytoolHelper keytoolHelper;

	@Bean("appProxyRestTemplate")
	public RestTemplate appProxyRestTemplate() {
		ClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(appProxyHttpClient());
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
		return restTemplate;
	}
	
	@Bean
	public ObjectMapper objectMapper() {
		final ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(JsonParser.Feature.ALLOW_COMMENTS, true);
		return mapper;
	}

	public HttpClient appProxyHttpClient(){
		final SSLContext sslContext;
		try {
			sslContext = sslContext();
		} catch (Exception e) {
			throw new IllegalStateException("Failed to setup client SSL context", e);
		}

		HttpHost myProxy = new HttpHost(appProxyUrl,proxyPort);
		SSLConnectionSocketFactory socketFactory = SSLConnectionSocketFactoryBuilder.create()
				.setSslContext(sslContext)
				.build();
		PoolingHttpClientConnectionManager connectionManager = PoolingHttpClientConnectionManagerBuilder.create()
				.setSSLSocketFactory(socketFactory)
				.build();
		return HttpClientBuilder.create()
				.setConnectionManager(connectionManager)
				.setProxy(myProxy)
				.build();
	}
	
	public SSLContext sslContext() throws GeneralSecurityException, IOException, RuntimeException {
		SSLContext sslContext = null;
		InputStream publicCertin = new ByteArrayInputStream(new String(cert.getBytes(), StandardCharsets.US_ASCII).getBytes());

		KeyStore keyStore = keytoolHelper.createKeyStore(publicCertin, privateKey);

		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
		InputStream is = getClass().getClassLoader().getResourceAsStream(truststorePath.getFilename());
		trustStore.load(is, trustPass.toCharArray());

		sslContext = SSLContextBuilder.create().loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
				.loadKeyMaterial(keyStore, certPassword.toCharArray())
				.build();
		return sslContext;
	}
	
	@PostConstruct
    public void init() {
		Logger log = LoggerFactory.getLogger(OpenBankingApplicationConfig.class);
		if(enabled){
			log.info("User Proxy is set!!");
		}
		else{
			log.info("App Proxy is set!!");
			proxyConfigurator.setProxy();
		}
    }

}
