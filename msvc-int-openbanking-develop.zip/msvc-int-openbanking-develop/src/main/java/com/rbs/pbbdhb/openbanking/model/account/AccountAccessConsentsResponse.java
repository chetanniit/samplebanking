package com.rbs.pbbdhb.openbanking.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.pbbdhb.openbanking.model.common.BaseResponse;

import lombok.Getter;
import lombok.Setter;

/**
 * AccountAccessConsentsResponse
 * 
 * @author gunasm
 *
 */
@Getter
@Setter
public class AccountAccessConsentsResponse extends BaseResponse{

	@JsonProperty(value = "Data")
	public AccountRequestData data;

	@JsonProperty(value = "Risk")
	public Risk risk;

}
