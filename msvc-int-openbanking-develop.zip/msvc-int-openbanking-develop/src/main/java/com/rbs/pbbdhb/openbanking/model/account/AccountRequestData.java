package com.rbs.pbbdhb.openbanking.model.account;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * AccountRequestData
 * 
 * @author gunasm
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountRequestData {

	@JsonProperty(value = "Permissions")
	private List<String> permissions;

	@JsonProperty(value = "ExpirationDateTime")
	private String expirationDateTime;

	@JsonProperty(value = "TransactionFromDateTime")
	private String transactionFromDateTime;

	@JsonProperty(value = "TransactionToDateTime")
	private String transactionToDateTime;

	@JsonProperty(value = "ConsentId")
	private String consentId;
}
