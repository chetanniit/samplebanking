package com.rbs.pbbdhb.openbanking.model.common;

import java.util.List;

import org.jose4j.jwx.HeaderParameterNames;

import com.google.common.collect.ImmutableList;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class JwsHeaders {

	public static final String ISSUED_AT = "http://openbanking.org.uk/iat";
	public static final String ISSUER = "http://openbanking.org.uk/iss";
	public static final String TRUST_ANCHOR = "http://openbanking.org.uk/tan";
	public static final List<String> CRITICAL_HEADER_CLAIMS = ImmutableList.<String>builder().add(ISSUED_AT).add(ISSUER)
			.add(TRUST_ANCHOR).build();
	public static final List<String> ALL_HEADER_CLAIMS = ImmutableList.<String>builder().addAll(CRITICAL_HEADER_CLAIMS)
			.add(HeaderParameterNames.ALGORITHM).add(HeaderParameterNames.TYPE).add(HeaderParameterNames.CONTENT_TYPE)
			.add(HeaderParameterNames.KEY_ID).add(HeaderParameterNames.CRITICAL).build();

}
