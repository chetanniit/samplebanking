  package com.rbs.pbbdhb.openbanking.service.impl;

import java.security.GeneralSecurityException;
import java.security.interfaces.RSAPrivateKey;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.config.KeytoolHelper;
import com.rbs.pbbdhb.openbanking.model.common.BcAuthorizedTokenResponse;
import com.rbs.pbbdhb.openbanking.service.BcAuthorizeService;
import com.rbs.pbbdhb.openbanking.service.RestService;

import net.minidev.json.JSONObject;

  /**
 * BcAuthorizeServiceImpl
 * 
 * @author gunasm
 *
 */
@Service
public class BcAuthorizeServiceImpl implements BcAuthorizeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BcAuthorizeServiceImpl.class);	
	
	@Value("${ob.auth.bc.authorize.nwb.path}")
	private String bcAuthorizePathNwb;	
	
	@Value("${ob.auth.bc.authorize.rbs.path}")
	private String bcAuthorizePathRbs;	
	
	@Value("${ob.client.assertion.type}")
	private String clientAssertionType;	
	
	@Value("${ob.auth.clientId}")
	private String clientId;
	
	@Value("${ob.auth.client.jks.path}")
	private Resource clientJksPath;

	@Value("${ob.auth.client.jks.password}")
	private String clientJksPassword;
	
	@Value("${ob.auth.client.kid}")
	private String kid;
	
	@Value("${ob.accounts.accountType}")
	private String accountType;
	
	@Autowired
	RestService restService;	

	/*@Autowired
	@Qualifier("customRestTemplate")
	RestTemplate restService;*/

	@Override
	public ResponseEntity<BcAuthorizedTokenResponse> getBcAuthorized(String consentId, String jwt, String cin, String scope, String brand) throws Exception {
		MultiValueMap<String, String> bcAuthorizeBodyParamsMap = bcAuthorizeParams(consentId, brand, jwt, cin,
				accountType,scope);
		String bcAuthorizePath = (brand.equalsIgnoreCase(Constants.NWB) ? bcAuthorizePathNwb : bcAuthorizePathRbs);
		
		LOGGER.debug("Generating BC Authorize Id for brand - {}, Url - {}",brand,bcAuthorizePath);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(bcAuthorizeBodyParamsMap, headers);
		
		ResponseEntity<BcAuthorizedTokenResponse> response = restService.exchange(bcAuthorizePath, HttpMethod.POST,
				entity, BcAuthorizedTokenResponse.class);
		return response;
	}

	private MultiValueMap<String, String> bcAuthorizeParams(String consentId, String brand, String jwt,
			String cin, String accountType, String scope) throws Exception {
		MultiValueMap<String, String> bcAuthorizeBodyParamsMap = new LinkedMultiValueMap<>();
		bcAuthorizeBodyParamsMap.add(Constants.CLIENT_ASSERTION_TYPE, clientAssertionType);
		bcAuthorizeBodyParamsMap.add(Constants.CLIENT_ASSERTION, jwt);
		bcAuthorizeBodyParamsMap.add(Constants.CIN, cin);
		bcAuthorizeBodyParamsMap.add(Constants.SCOPE, scope);
		bcAuthorizeBodyParamsMap.add(Constants.CUSTOMER_TYPE, accountType);
		bcAuthorizeBodyParamsMap.add(Constants.INTENT_ID, consentId);
		bcAuthorizeBodyParamsMap.add(Constants.LOGIN_HINT, generateLoginHint(cin, brand));
		return bcAuthorizeBodyParamsMap;
	}

	protected String generateLoginHint(String cin, String brand) throws RuntimeException,JOSEException,GeneralSecurityException {

		Map<String, Object> claims = new HashMap<>();	
		
		claims.put(Constants.SUB, cin); 
		claims.put(Constants.AUD, brand+Constants.API_CIBA);
		claims.put(Constants.ISS, clientId);		
		claims.put(Constants.CIN, cin);		
		claims.put(Constants.CUST_TYPE, accountType);
		
		RSAPrivateKey key = (RSAPrivateKey) KeytoolHelper.key(clientJksPath.getFilename(), clientJksPassword,clientId);

		JWSSigner jwsSigner = new RSASSASigner(key);

		JWSObject jwsObject = new JWSObject(
				new JWSHeader.Builder(JWSAlgorithm.PS256).type(new JOSEObjectType(Constants.JWS))
						.keyID(kid).build(),
				new Payload(new JSONObject(claims).toJSONString()));

		jwsObject.sign(jwsSigner);		
		String jwt = jwsObject.serialize();
		LOGGER.info("JWT generated (login Hint): "+jwt);
		
		return jwt;
	}
}
