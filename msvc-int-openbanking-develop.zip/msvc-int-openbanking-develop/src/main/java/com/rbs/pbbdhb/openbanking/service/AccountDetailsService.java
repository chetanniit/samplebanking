package com.rbs.pbbdhb.openbanking.service;

import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;

/**
 * Service for Account Details
 * 
 * @author gunasm
 *
 */
public interface AccountDetailsService {

	/**
	 * Account Details Service
	 *
	 * @param token token
	 * @param brand brand
	 * @return accountBalanceResponse
	 *
	 */
	ResponseEntity<AccountBalanceResponse> getAccountDetails(String token, String brand);
	
}
