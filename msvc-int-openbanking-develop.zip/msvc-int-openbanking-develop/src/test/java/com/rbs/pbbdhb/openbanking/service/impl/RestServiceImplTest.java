package com.rbs.pbbdhb.openbanking.service.impl;

import java.io.IOException;
import java.nio.charset.Charset;

import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.exception.BusinessException;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
public class RestServiceImplTest {

        @Mock
        private RestTemplate restTemplate;

        @Mock
        private ExceptionHelper exceptionHelper;

        @Mock
        private ObjectMapper objectMapper;

        @InjectMocks
        private RestServiceImpl restServiceImpl;

        private final String LOCALHOST = "localhost";

        @Test
        public void shouldGetIBPPaymentResponse() {
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setDomesticPaymentId("675675765");
            ibpPaymentResponse.setAmount("67567");
            ibpPaymentResponse.setCurrency("GBP");
            ibpPaymentResponse.setTransactionId("87667");
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.GET, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenReturn(new ResponseEntity<>(ibpPaymentResponse, HttpStatus.OK));
            ResponseEntity<IBPPaymentResponse> response = restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            Assertions.assertNotNull(response);
            Assertions.assertNotNull(response.getBody());
            Assertions.assertEquals(response.getBody().getDomesticPaymentId(), "675675765");
        }

        @Test
        public void shouldGetIBPPaymentResponseHttpStatusInvalid() {
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setDomesticPaymentId("675675765");
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.GET, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenReturn(new ResponseEntity<>(ibpPaymentResponse, HttpStatus.CREATED));
            restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.CREATED.value(),"internal.server.error");
        }

        @Test
        public void testNotFoundException() throws IOException {
            HttpClientErrorException clientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "not found", "{\"errorMessage\":\"not found\"}".getBytes(), Charset.defaultCharset()) ;
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setErrorMessage("not found");
            Mockito.when(objectMapper.readValue(clientErrorException.getResponseBodyAsByteArray(),IBPPaymentResponse.class)).thenReturn(ibpPaymentResponse);
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.GET, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(clientErrorException);
            ResponseEntity<IBPPaymentResponse> response = restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            Assertions.assertNotNull(response);
            Assertions.assertEquals(HttpStatus.NOT_FOUND,response.getStatusCode());
            Assertions.assertNotNull(response.getBody());
            Assertions.assertEquals(response.getBody().getErrorMessage(), "not found");
        }

        @Test
        public void testRequestTimedOut() {
            ResourceAccessException resourceAccessException = new ResourceAccessException("Request Timed Out") ;
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.GET, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(resourceAccessException);
            Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, resourceAccessException, HttpStatus.REQUEST_TIMEOUT.value(), "request.timed.out");
            Assertions.assertThrows(BusinessException.class,()->{
                restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            });
        }

        @Test
        public void testNotFoundExceptionInvalidResponse() throws IOException {
            HttpClientErrorException clientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "not found", "{\"errorMessage\":\"not found\"}".getBytes(), Charset.defaultCharset()) ;
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setErrorMessage("not found");
            IOException ioException = new IOException("error");
            Mockito.when(objectMapper.readValue(clientErrorException.getResponseBodyAsByteArray(),IBPPaymentResponse.class)).thenThrow(ioException);
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.GET, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(clientErrorException);
            Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, ioException, "internal.server.error");
            Assertions.assertThrows(BusinessException.class,()->{
                restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            });
        }

        @Test
        public void testInternalErrorUnknownException() throws IOException {
            RestClientException restClientException = new RestClientException("error");
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setErrorMessage("not found");
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.GET, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(restClientException);
            Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, restClientException, "internal.server.error");
            Assertions.assertThrows(BusinessException.class,()->{
                restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            });
        }


        @Test
        public void shouldPostIBPPaymentResponse() {
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setAmount("564");
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenReturn(new ResponseEntity<>(ibpPaymentResponse, HttpStatus.OK));
            ResponseEntity<IBPPaymentResponse> response = restServiceImpl.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            Assertions.assertNotNull(response);
            Assertions.assertNotNull(response.getBody());
            Assertions.assertEquals(response.getBody().getAmount(), "564");
        }

        @Test
        public void shouldPostIBPPaymentResponseHttpStatusInvalid() {
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setAmount("564");
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenReturn(new ResponseEntity<>(ibpPaymentResponse, HttpStatus.BAD_REQUEST));
            restServiceImpl.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, HttpStatus.BAD_REQUEST.value(),"internal.server.error");
        }


        @Test
        public void testPostNotFoundException() throws JsonParseException, JsonMappingException, IOException {
            HttpClientErrorException clientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "not found", "{\"errorMessage\":\"not found\"}".getBytes(), Charset.defaultCharset()) ;
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setErrorMessage("not found");
            Mockito.when(objectMapper.readValue(clientErrorException.getResponseBodyAsByteArray(),IBPPaymentResponse.class)).thenReturn(ibpPaymentResponse);
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(clientErrorException);
            ResponseEntity<IBPPaymentResponse> response = restServiceImpl.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            Assertions.assertNotNull(response);
            Assertions.assertEquals(HttpStatus.NOT_FOUND,response.getStatusCode());
            Assertions.assertNotNull(response.getBody());
            Assertions.assertEquals(response.getBody().getErrorMessage(), "not found");
        }

        @Test
        public void testPostRequestTimedOut() throws JsonParseException, JsonMappingException, IOException {
            ResourceAccessException resourceAccessException = new ResourceAccessException("Request Timed Out") ;
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(resourceAccessException);
            Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, resourceAccessException, HttpStatus.REQUEST_TIMEOUT.value(), "request.timed.out");
            Assertions.assertThrows(BusinessException.class,()->{
                restServiceImpl.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            });
        }

        @Test
        public void testPostNotFoundExceptionInvalidResponse() throws JsonParseException, JsonMappingException, IOException {
            HttpClientErrorException clientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "not found", "{\"errorMessage\":\"not found\"}".getBytes(), Charset.defaultCharset()) ;
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setErrorMessage("not found");
            IOException ioException = new IOException("error");
            Mockito.when(objectMapper.readValue(clientErrorException.getResponseBodyAsByteArray(),IBPPaymentResponse.class)).thenThrow(ioException);
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(clientErrorException);
            Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, ioException, "internal.server.error");
            Assertions.assertThrows(BusinessException.class,()->{
                restServiceImpl.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            });
        }

        @Test
        public void testPostInternalErrorUnknownException() throws JsonParseException, JsonMappingException, IOException {
            RestClientException restClientException = new RestClientException("error");
            IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
            ibpPaymentResponse.setErrorMessage("not found");
            Mockito.when(restTemplate.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class)).thenThrow(restClientException);
            Mockito.doThrow(BusinessException.class).when(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION, restClientException, "internal.server.error");
            Assertions.assertThrows(BusinessException.class,()->{
                restServiceImpl.exchange(LOCALHOST, HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            });
        }

        @Test
        public void testForGetResourceAccessException(){
            Mockito.when(restTemplate.exchange(LOCALHOST,HttpMethod.GET, HttpEntity.EMPTY,IBPPaymentResponse.class)).thenThrow(ResourceAccessException.class);
            ResponseEntity<IBPPaymentResponse> ibpPaymentResponseResponseEntity = restServiceImpl.get(LOCALHOST, IBPPaymentResponse.class);
            Mockito.verify(restTemplate).exchange(LOCALHOST,HttpMethod.GET, HttpEntity.EMPTY,IBPPaymentResponse.class);
        }

        @Test
        public void testForExchangeResourceAccessException(){
            Mockito.when(restTemplate.exchange(LOCALHOST,HttpMethod.POST, HttpEntity.EMPTY,IBPPaymentResponse.class)).thenThrow(ResourceAccessException.class);
            ResponseEntity<IBPPaymentResponse> ibpPaymentResponseResponseEntity = restServiceImpl.exchange(LOCALHOST,HttpMethod.POST, HttpEntity.EMPTY, IBPPaymentResponse.class);
            Mockito.verify(restTemplate).exchange(LOCALHOST,HttpMethod.POST, HttpEntity.EMPTY,IBPPaymentResponse.class);
        }
}

