package com.rbs.pbbdhb.openbanking.util;

import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.payment.*;
import jakarta.validation.constraints.Size;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@ExtendWith(MockitoExtension.class)
public class PaymentHelperTest {

    @InjectMocks
    private PaymentHelper paymentHelper;

    private String creditorSortCodeAccountNumberNwb = "5464747555";

    private String creditorSortCodeAccountNumberRbs = "5464747555";

    @Test
    public void createRequest(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        MockedStatic<LocalDateTime> mockedLocalDateTime = Mockito.mockStatic(LocalDateTime.class,
				Mockito.CALLS_REAL_METHODS);
		LocalDateTime now = LocalDateTime.of(2024, 06, 17, 10, 41, 55);
		mockedLocalDateTime.when(LocalDateTime::now).thenReturn(now);

        OBWriteDomesticConsent consent = paymentHelper.createRequest(request,"NWB","7573", Constants.LUMPSUM);
        Assertions.assertNotNull(consent);
        Assertions.assertEquals("STP-LSI-DPCPAYMENT240617104155", 
        		consent.getData().getInitiation().getEndToEndIdentification());
        mockedLocalDateTime.close();
    }
    
    @Test
    public void createRequest_redemptions(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        MockedStatic<LocalDateTime> mockedLocalDateTime = Mockito.mockStatic(LocalDateTime.class,
				Mockito.CALLS_REAL_METHODS);
		LocalDateTime now = LocalDateTime.of(2024, 06, 17, 10, 41, 55);
		mockedLocalDateTime.when(LocalDateTime::now).thenReturn(now);
      OBWriteDomesticConsent consent = paymentHelper.createRequest(request,"NWB","7573", Constants.REDEMPTIONS);
        Assertions.assertNotNull(consent);
        Assertions.assertEquals("STP-RCI-DPCPAYMENT240617104155", 
        		consent.getData().getInitiation().getEndToEndIdentification());
        mockedLocalDateTime.close();
    }
    
    @Test
    public void createRequest_unknownSource(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        MockedStatic<LocalDateTime> mockedLocalDateTime = Mockito.mockStatic(LocalDateTime.class,
				Mockito.CALLS_REAL_METHODS);
		LocalDateTime now = LocalDateTime.of(2024, 06, 17, 10, 41, 55);
		mockedLocalDateTime.when(LocalDateTime::now).thenReturn(now);
      OBWriteDomesticConsent consent = paymentHelper.createRequest(request,"NWB","7573", "test");
        Assertions.assertNotNull(consent);
        Assertions.assertEquals("240617104155", 
        		consent.getData().getInitiation().getEndToEndIdentification());
        mockedLocalDateTime.close();
    }
    
    @Test
    public void createRequest_RedemptionsUpperCase(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        MockedStatic<LocalDateTime> mockedLocalDateTime = Mockito.mockStatic(LocalDateTime.class,
				Mockito.CALLS_REAL_METHODS);
		LocalDateTime now = LocalDateTime.of(2024, 06, 17, 10, 41, 55);
		mockedLocalDateTime.when(LocalDateTime::now).thenReturn(now);
      OBWriteDomesticConsent consent = paymentHelper.createRequest(request,"NWB","7573", "REDEMPTIONS");
        Assertions.assertNotNull(consent);
        Assertions.assertEquals("STP-RCI-DPCPAYMENT240617104155", 
        		consent.getData().getInitiation().getEndToEndIdentification());
        mockedLocalDateTime.close();
    }
    
    @Test
    public void createRequest_RBS_redemptions(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        MockedStatic<LocalDateTime> mockedLocalDateTime = Mockito.mockStatic(LocalDateTime.class,
				Mockito.CALLS_REAL_METHODS);
		LocalDateTime now = LocalDateTime.of(2024, 06, 17, 10, 41, 55);
		mockedLocalDateTime.when(LocalDateTime::now).thenReturn(now);
        OBWriteDomesticConsent consent = paymentHelper.createRequest(request,"RBS","7573", Constants.REDEMPTIONS);
        Assertions.assertNotNull(consent);
        Assertions.assertEquals("STP-RCI-DPCPAYMENT240617104155", 
        		consent.getData().getInitiation().getEndToEndIdentification());
        mockedLocalDateTime.close();
    }
    
    @Test
    public void createRequest_RBS(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        MockedStatic<LocalDateTime> mockedLocalDateTime = Mockito.mockStatic(LocalDateTime.class,
				Mockito.CALLS_REAL_METHODS);
		LocalDateTime now = LocalDateTime.of(2024, 06, 17, 10, 41, 55);
		mockedLocalDateTime.when(LocalDateTime::now).thenReturn(now);
        OBWriteDomesticConsent consent = paymentHelper.createRequest(request,"RBS","7573", Constants.LUMPSUM);
        Assertions.assertNotNull(consent);
        Assertions.assertNotNull(consent);
        Assertions.assertEquals("STP-LSI-DPCPAYMENT240617104155", 
        		consent.getData().getInitiation().getEndToEndIdentification());
        mockedLocalDateTime.close();
    }

    @Test
    public void createResponse(){
        String brand = "NWB";
        String creditorSortCodeAccountNumber = (brand.equalsIgnoreCase(Constants.NWB) ? creditorSortCodeAccountNumberNwb : creditorSortCodeAccountNumberRbs);
        String STP_ORDER_TXT = "STP-LSI-DPCPAYMENT";
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
        String orderIdDateTime = LocalDateTime.now().format(dateTimeFormatter);
        String endToEndId = STP_ORDER_TXT+orderIdDateTime;
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        @Size(min = 1, max = 35) String accountNumber = "34566";
        OBWriteDomesticConsent response = OBWriteDomesticConsent
                .builder()
                .risk(OBRisk.builder().build())
                .data(OBWriteDataDomesticConsent
                        .builder()
                        .initiation(OBDomestic.builder()
                                .instructionIdentification(UUID.randomUUID().toString().replace("-", "").substring(0, 32))
                                .endToEndIdentification(endToEndId)
                                .instructedAmount(OBDomesticInstructedAmount.builder().amount(request.getAmount()).currency(request.getCurrency()).build())
                                .debtorAccount(OBCashAccountDebtor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(request.getDebtorSortCodeAccountNumber()).build())
                                .creditorAccount(OBCashAccountCreditor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(creditorSortCodeAccountNumber).name("Natwest").build())
                                .remittanceInformation(OBRemittanceInformation.builder().unstructured("unstructured").reference(accountNumber).build()) //TODO
                                .build()).build()).build();
        IBPPaymentResponse actualResponse = paymentHelper.createResponse(response);
        Assertions.assertNotNull(actualResponse);
    }
    
    @Test
    public void createResponse_NWB_Redemptions(){
        String brand = "NWB";
        String creditorSortCodeAccountNumber = (brand.equalsIgnoreCase(Constants.NWB) ? creditorSortCodeAccountNumberNwb : creditorSortCodeAccountNumberRbs);
        String STP_ORDER_TXT = "STP-RCI-DPCPAYMENT";
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
        String orderIdDateTime = LocalDateTime.now().format(dateTimeFormatter);
        String endToEndId = STP_ORDER_TXT+orderIdDateTime;
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        @Size(min = 1, max = 35) String accountNumber = "34566";
        OBWriteDomesticConsent response = OBWriteDomesticConsent
                .builder()
                .risk(OBRisk.builder().build())
                .data(OBWriteDataDomesticConsent
                        .builder()
                        .initiation(OBDomestic.builder()
                                .instructionIdentification(UUID.randomUUID().toString().replace("-", "").substring(0, 32))
                                .endToEndIdentification(endToEndId)
                                .instructedAmount(OBDomesticInstructedAmount.builder().amount(request.getAmount()).currency(request.getCurrency()).build())
                                .debtorAccount(OBCashAccountDebtor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(request.getDebtorSortCodeAccountNumber()).build())
                                .creditorAccount(OBCashAccountCreditor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(creditorSortCodeAccountNumber).name("Natwest").build())
                                .remittanceInformation(OBRemittanceInformation.builder().unstructured("unstructured").reference(accountNumber).build()) //TODO
                                .build()).build()).build();
        IBPPaymentResponse actualResponse = paymentHelper.createResponse(response);
        Assertions.assertNotNull(actualResponse);
    }

    @Test
    public void createResponse_RBS(){
        String brand = "RBS";
        String creditorSortCodeAccountNumber = (brand.equalsIgnoreCase(Constants.NWB) ? creditorSortCodeAccountNumberNwb : creditorSortCodeAccountNumberRbs);
        String STP_ORDER_TXT = "STP-LSI-DPCPAYMENT";
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
        String orderIdDateTime = LocalDateTime.now().format(dateTimeFormatter);
        String endToEndId = STP_ORDER_TXT+orderIdDateTime;
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        @Size(min = 1, max = 35) String accountNumber = "34566";
        OBWriteDomesticConsent response = OBWriteDomesticConsent
                .builder()
                .risk(OBRisk.builder().build())
                .data(OBWriteDataDomesticConsent
                        .builder()
                        .initiation(OBDomestic.builder()
                                .instructionIdentification(UUID.randomUUID().toString().replace("-", "").substring(0, 32))
                                .endToEndIdentification(endToEndId)
                                .instructedAmount(OBDomesticInstructedAmount.builder().amount(request.getAmount()).currency(request.getCurrency()).build())
                                .debtorAccount(OBCashAccountDebtor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(request.getDebtorSortCodeAccountNumber()).build())
                                .creditorAccount(OBCashAccountCreditor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(creditorSortCodeAccountNumber).name("Natwest").build())
                                .remittanceInformation(OBRemittanceInformation.builder().unstructured("unstructured").reference(accountNumber).build()) //TODO
                                .build()).build()).build();
        IBPPaymentResponse actualResponse = paymentHelper.createResponse(response);
        Assertions.assertNotNull(actualResponse);
    }
    
    @Test
    public void createResponse_RBS_Redemptions(){
        String brand = "RBS";
        String creditorSortCodeAccountNumber = (brand.equalsIgnoreCase(Constants.NWB) ? creditorSortCodeAccountNumberNwb : creditorSortCodeAccountNumberRbs);
        String STP_ORDER_TXT = "STP-RCI-DPCPAYMENT";
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
        String orderIdDateTime = LocalDateTime.now().format(dateTimeFormatter);
        String endToEndId = STP_ORDER_TXT+orderIdDateTime;
        IBPPaymentRequest request = new IBPPaymentRequest();
        request.setAmount("54647");
        request.setCurrency("GBP");
        request.setAmount("46747");
        @Size(min = 1, max = 35) String accountNumber = "34566";
        OBWriteDomesticConsent response = OBWriteDomesticConsent
                .builder()
                .risk(OBRisk.builder().build())
                .data(OBWriteDataDomesticConsent
                        .builder()
                        .initiation(OBDomestic.builder()
                                .instructionIdentification(UUID.randomUUID().toString().replace("-", "").substring(0, 32))
                                .endToEndIdentification(endToEndId)
                                .instructedAmount(OBDomesticInstructedAmount.builder().amount(request.getAmount()).currency(request.getCurrency()).build())
                                .debtorAccount(OBCashAccountDebtor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(request.getDebtorSortCodeAccountNumber()).build())
                                .creditorAccount(OBCashAccountCreditor.builder().schemeName("UK.OBIE.SortCodeAccountNumber").identification(creditorSortCodeAccountNumber).name("Natwest").build())
                                .remittanceInformation(OBRemittanceInformation.builder().unstructured("unstructured").reference(accountNumber).build()) //TODO
                                .build()).build()).build();
        IBPPaymentResponse actualResponse = paymentHelper.createResponse(response);
        Assertions.assertNotNull(actualResponse);
    }
}
