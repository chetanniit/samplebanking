package com.rbs.pbbdhb.openbanking.service.impl;

import com.nimbusds.jose.crypto.bc.BouncyCastleProviderSingleton;
import com.rbs.pbbdhb.openbanking.model.common.AccessTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.IamTokenResponse;
import com.rbs.pbbdhb.openbanking.service.RestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.security.Security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class IamTokenGeneratorServiceImplTest {

    @Mock
    private RestService restService;

    @Mock
    private Resource clientJKSPath;

    @InjectMocks
    private IamTokenGeneratorServiceImpl iamTokenGeneratorService;

     @BeforeEach
     public void init(){
         when(clientJKSPath.getFilename()).thenReturn("testmock1234.jks");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"clientId","testmock1234");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"clientJksPassword","abcdef");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"kid","kjVRgP0U9v0vNt3M7ihYIXecNC0");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"grantType","abcdefgh");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"clientAssertionType","abcdefgh");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"tokenUrlNwb","tokenUrlNwb/");
         ReflectionTestUtils.setField(iamTokenGeneratorService,"tokenUrlRbs","tokenUrlRbs/");
     }

    @Test
    public void shouldGenerateIamToken_NWB(){
        AccessTokenResponse accessTokenResponse = new AccessTokenResponse();
        accessTokenResponse.setAccess_token("4467836");
        accessTokenResponse.setToken_type("bdcfgh");
        accessTokenResponse.setExpires_in(76);
        ResponseEntity<IamTokenResponse> actualResponse = null;
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accessTokenResponse));
        try {
            Security.addProvider(BouncyCastleProviderSingleton.getInstance());
            actualResponse = iamTokenGeneratorService.generateIamToken("abcdef","NWB");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
    }

    @Test
    public void shouldGenerateIamToken_RBS(){
        AccessTokenResponse accessTokenResponse = new AccessTokenResponse();
        accessTokenResponse.setAccess_token("4467836");
        accessTokenResponse.setToken_type("bdcfgh");
        accessTokenResponse.setExpires_in(76);
        ResponseEntity<IamTokenResponse> actualResponse = null;
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accessTokenResponse));
        try {
            Security.addProvider(BouncyCastleProviderSingleton.getInstance());
            actualResponse = iamTokenGeneratorService.generateIamToken("abcdef","RBS");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
    }

}
