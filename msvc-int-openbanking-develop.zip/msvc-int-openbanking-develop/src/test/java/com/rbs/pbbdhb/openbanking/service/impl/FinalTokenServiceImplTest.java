package com.rbs.pbbdhb.openbanking.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.rbs.pbbdhb.openbanking.model.common.FinalTokenResponse;
import com.rbs.pbbdhb.openbanking.service.RestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class FinalTokenServiceImplTest {

    @InjectMocks
    private FinalTokenServiceImpl finalTokenService;

    @Mock
    private RestService restService;


    @BeforeEach
    public void init() {
        ReflectionTestUtils.setField(finalTokenService, "tokenUrlNwb", "bcAuthorizePathNwb/");
        ReflectionTestUtils.setField(finalTokenService, "tokenUrlRbs", "bcAuthorizePathRbs/");
        ReflectionTestUtils.setField(finalTokenService, "clientAssertionType", "abcdef");
        ReflectionTestUtils.setField(finalTokenService, "grantType", "abcdef");
    }

    @Test
    public void shouldGetFinalToken_NWB(){
        FinalTokenResponse finalTokenResponse = new FinalTokenResponse();
        finalTokenResponse.setRefresh_token("1234");
        finalTokenResponse.setToken_type("abcd");
        finalTokenResponse.setRefresh_token("12345");
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(finalTokenResponse));
        ResponseEntity<FinalTokenResponse> actualResponse = finalTokenService.getFinalToken("12345","12345","NWB");
        assertEquals(HttpStatus.OK,actualResponse.getStatusCode());
        assertNotNull(actualResponse.getBody());
    }

    @Test
    public void shouldGetFinalToken_RBS(){
        FinalTokenResponse finalTokenResponse = new FinalTokenResponse();
        finalTokenResponse.setRefresh_token("1234");
        finalTokenResponse.setToken_type("abcd");
        finalTokenResponse.setRefresh_token("12345");
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(finalTokenResponse));
        ResponseEntity<FinalTokenResponse> actualResponse = finalTokenService.getFinalToken("12345","12345","RBS");
        assertEquals(HttpStatus.OK,actualResponse.getStatusCode());
        assertNotNull(actualResponse.getBody());
    }

}