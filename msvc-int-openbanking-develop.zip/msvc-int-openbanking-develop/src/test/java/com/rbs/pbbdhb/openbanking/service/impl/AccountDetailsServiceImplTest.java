package com.rbs.pbbdhb.openbanking.service.impl;

import com.rbs.pbbdhb.openbanking.model.account.*;
import com.rbs.pbbdhb.openbanking.service.RestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AccountDetailsServiceImplTest {

  @Mock
  private RestService restService;

  @InjectMocks
  private AccountDetailsServiceImpl accountDetailsService;

  @BeforeEach
  public void init() {
    ReflectionTestUtils.setField(accountDetailsService, "accountsPathNwb", "accountsPathNwb/");
    ReflectionTestUtils.setField(accountDetailsService, "accountsPathRbs", "accountsPathRbs/");
    ReflectionTestUtils.setField(accountDetailsService, "balancesPathNwb", "balancesPathNwb/");
    ReflectionTestUtils.setField(accountDetailsService, "balancesPathRbs", "balancesPathRbs/");
    ReflectionTestUtils.setField(accountDetailsService, "financialId", "12345");

  }

    @Test
    public void noAccountsFound_RBS(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        details.setAccounts(null);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","RBS");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsFound_nwb(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        details.setAccounts(null);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsDetailsPresent_nwb(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("123456647578585Sakshi");
        acc.setName("sakshi");
        acc.setSchemeName("");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsDetailsPresent_rbs(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("123456647578585Sakshi");
        acc.setName("sakshi");
        acc.setSchemeName("");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","RBS");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsDataPresent_nwb(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsDataPresent_rbs(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","RBS");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsBalancePresent_nwb(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        accountResponseData.setAccountBalance(null);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void noAccountsBalancePresent_rbs(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();
        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");
        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);
        accountResponse.setData(accountResponseData);
        accountResponseData.setAccountDetails(accDetails);
        accountResponseData.setAccountBalance(null);
        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("123","RBS");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void shouldGetAccountDetails_Expected(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("Expected");
        accountBalance.setCreditDebitIndicator("");
        Amount amount = new Amount();
        amount.setAmount("");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);
        CreditLine creditLine = new CreditLine();
        creditLine.setAmount(amount);
        creditLine.setType("");
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine);
        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().toString());
    }

    @Test
    public void shouldGetAccountDetails_ForwardAvailable_CreditLineCase1(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("ForwardAvailable");
        accountBalance.setCreditDebitIndicator("Credit");
        Amount amount = new Amount();
        amount.setAmount("400");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);
        CreditLine creditLine = new CreditLine();
        creditLine.setAmount(null);
        creditLine.setType("");
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine);
        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().getAccountBalances().toString());

    }

    @Test
    public void shouldGetAccountDetails_ForwardAvailable_CreditLineCase2(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("ForwardAvailable");
        accountBalance.setCreditDebitIndicator("Debit");
        Amount amount = new Amount();
        amount.setAmount("400");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);
        CreditLine creditLine = new CreditLine();
        creditLine.setAmount(null);
        creditLine.setType("");
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine);
        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().getAccountBalances().toString());
    }

    @Test
    public void shouldGetAccountDetails_ForwardAvailable_CreditLineCase3_1(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("ForwardAvailable");
        accountBalance.setCreditDebitIndicator("Debit");
        Amount amount = new Amount();
        amount.setAmount("400");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);

        Amount amount1 = new Amount();
        amount1.setAmount("100");
        amount1.setCurrency("GBP");
        CreditLine creditLine1 = new CreditLine();
        creditLine1.setAmount(amount1);
        creditLine1.setType("Pre-Agreed");
        CreditLine creditLine2 = new CreditLine();
        Amount amount2 = new Amount();
        amount2.setAmount("500");
        amount2.setCurrency("GBP");
        creditLine2.setAmount(amount2);
        creditLine2.setType("Available");
        creditLine2.setIncluded(true);
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine1);
        creditList.add(creditLine2);

        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().getAccountBalances().toString());
    }

    @Test
    public void shouldGetAccountDetails_ForwardAvailable_CreditLineCase3_2(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("ForwardAvailable");
        accountBalance.setCreditDebitIndicator("Credit");
        Amount amount = new Amount();
        amount.setAmount("400");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);

        Amount amount1 = new Amount();
        amount1.setAmount("100");
        amount1.setCurrency("GBP");
        CreditLine creditLine1 = new CreditLine();
        creditLine1.setAmount(amount1);
        creditLine1.setType("Pre-Agreed");
        creditLine1.setIncluded(true);
        CreditLine creditLine2 = new CreditLine();
        Amount amount2 = new Amount();
        amount2.setAmount("500");
        amount2.setCurrency("GBP");
        creditLine2.setAmount(amount2);
        creditLine2.setType("Available");
        creditLine2.setIncluded(true);
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine1);
        creditList.add(creditLine2);

        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().getAccountBalances().toString());
    }

    @Test
    public void shouldGetAccountDetails_ForwardAvailable_CreditLineCase4_1(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("ForwardAvailable");
        accountBalance.setCreditDebitIndicator("Debit");
        Amount amount = new Amount();
        amount.setAmount("400");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);

        Amount amount1 = new Amount();
        amount1.setAmount("100");
        amount1.setCurrency("GBP");
        CreditLine creditLine1 = new CreditLine();
        creditLine1.setAmount(amount1);
        creditLine1.setType("Pre-Agreed");
        CreditLine creditLine2 = new CreditLine();
        Amount amount2 = new Amount();
        amount2.setAmount("500");
        amount2.setCurrency("GBP");
        creditLine2.setAmount(amount2);
        creditLine2.setType("Available");
        creditLine2.setIncluded(false);
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine1);
        creditList.add(creditLine2);

        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().getAccountBalances().toString());
    }

    @Test
    public void shouldGetAccountDetails_ForwardAvailable_CreditLineCase4_2(){
        AccountResponse accountResponse = new AccountResponse();
        AccountResponseData accountResponseData = new AccountResponseData();

        List<AccountDetails> accDetails = new ArrayList<>();
        AccountDetails details = new AccountDetails();
        details.setAccountId("123");
        details.setAccountType("Personal");
        details.setCurrency("current");
        details.setAccountSubType("csa");
        details.setDescription("description");

        List<Account> account = new ArrayList<>();
        Account acc = new Account();
        acc.setIdentification("abcdegh");
        acc.setName("sakshi");
        acc.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        account.add(acc);
        details.setAccounts(account);
        accDetails.add(details);

        List<AccountBalance> accBal = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setAccountId("123");
        accountBalance.setType("ForwardAvailable");
        accountBalance.setCreditDebitIndicator("Credit");
        Amount amount = new Amount();
        amount.setAmount("400");
        amount.setCurrency("GBP");
        accountBalance.setAmount(amount);

        Amount amount1 = new Amount();
        amount1.setAmount("100");
        amount1.setCurrency("GBP");
        CreditLine creditLine1 = new CreditLine();
        creditLine1.setAmount(amount1);
        creditLine1.setType("Pre-Agreed");
        CreditLine creditLine2 = new CreditLine();
        Amount amount2 = new Amount();
        amount2.setAmount("500");
        amount2.setCurrency("GBP");
        creditLine2.setAmount(amount2);
        creditLine2.setType("Available");
        creditLine2.setIncluded(false);
        List<CreditLine> creditList = new ArrayList<>();
        creditList.add(creditLine1);
        creditList.add(creditLine2);

        accountBalance.setCreditLine(creditList);
        accBal.add(accountBalance);

        accountResponseData.setAccountBalance(accBal);
        accountResponseData.setAccountDetails(accDetails);
        accountResponse.setData(accountResponseData);

        when(restService.exchange(any(),eq(HttpMethod.GET),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountResponse));
        ResponseEntity<AccountBalanceResponse> actualResponse = accountDetailsService.getAccountDetails("12345","NWB");
        Logger log = LoggerFactory.getLogger(AccountDetailsServiceImplTest.class);
        log.info(actualResponse.getBody().getAccountBalances().toString());
    }

}
