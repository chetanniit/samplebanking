package com.rbs.pbbdhb.openbanking.model.payment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
public class DomesticPaymentRequestTest {

    @Test
    public void testEquals() {
        DomesticPaymentRequest domesticPaymentRequest1 = new DomesticPaymentRequest();
        domesticPaymentRequest1.setAmount("6464");
        domesticPaymentRequest1.setCurrency("GBP");
        domesticPaymentRequest1.setDebtorAccountNumber("6545");
        domesticPaymentRequest1.setDebtorAccountSortCode("6745564");

        DomesticPaymentRequest domesticPaymentRequest2 = new DomesticPaymentRequest();
        domesticPaymentRequest2.setAmount("6464");
        domesticPaymentRequest2.setCurrency("GBP");
        domesticPaymentRequest2.setDebtorAccountNumber("6545");
        domesticPaymentRequest2.setDebtorAccountSortCode("6745564");

        Assertions.assertTrue(domesticPaymentRequest1.equals(domesticPaymentRequest2));
    }

    @Test
    public void testHashCode() {
        DomesticPaymentRequest domesticPaymentRequest1 = new DomesticPaymentRequest();
        domesticPaymentRequest1.setAmount("6464");
        domesticPaymentRequest1.setCurrency("GBP");
        domesticPaymentRequest1.setDebtorAccountNumber("6545");
        domesticPaymentRequest1.setDebtorAccountSortCode("6745564");
        Assertions.assertNotEquals(0,domesticPaymentRequest1.hashCode());
    }

    @Test
    public void testToString() {
        DomesticPaymentRequest domesticPaymentRequest1 = new DomesticPaymentRequest();
        domesticPaymentRequest1.setAmount("6464");
        domesticPaymentRequest1.setCurrency("GBP");
        domesticPaymentRequest1.setDebtorAccountNumber("6545");
        domesticPaymentRequest1.setDebtorAccountSortCode("6745564");
        Logger log = LoggerFactory.getLogger(DomesticPaymentRequestTest.class);
        log.info(domesticPaymentRequest1.toString());
    }

    @Test
    public void toBuilder() {
        DomesticPaymentRequest domesticPaymentRequest1 = new DomesticPaymentRequest();
        domesticPaymentRequest1.setAmount("6464");
        domesticPaymentRequest1.setCurrency("GBP");
        domesticPaymentRequest1.setDebtorAccountNumber("6545");
        domesticPaymentRequest1.setDebtorAccountSortCode("6745564");
        Logger log = LoggerFactory.getLogger(DomesticPaymentRequestTest.class);
        log.info(domesticPaymentRequest1.toBuilder().toString());
    }
}