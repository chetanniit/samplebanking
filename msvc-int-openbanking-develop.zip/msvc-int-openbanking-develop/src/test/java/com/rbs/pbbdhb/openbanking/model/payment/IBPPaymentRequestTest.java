package com.rbs.pbbdhb.openbanking.model.payment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
public class IBPPaymentRequestTest {

    @Test
    public void testEquals() {
        IBPPaymentRequest ibpPaymentRequest1 = new IBPPaymentRequest();
        ibpPaymentRequest1.setCurrency("GBP");
        ibpPaymentRequest1.setAmount("65465");
        ibpPaymentRequest1.setDebtorSortCodeAccountNumber("6765765");

        IBPPaymentRequest ibpPaymentRequest2 = new IBPPaymentRequest();
        ibpPaymentRequest2.setCurrency("GBP");
        ibpPaymentRequest2.setAmount("65465");
        ibpPaymentRequest2.setDebtorSortCodeAccountNumber("6765765");
        Assertions.assertTrue(ibpPaymentRequest1.equals(ibpPaymentRequest2));

    }

    @Test
    public void testHashCode() {
        IBPPaymentRequest ibpPaymentRequest1 = new IBPPaymentRequest();
        ibpPaymentRequest1.setCurrency("GBP");
        ibpPaymentRequest1.setAmount("65465");
        ibpPaymentRequest1.setDebtorSortCodeAccountNumber("6765765");
        Assertions.assertNotEquals(0,ibpPaymentRequest1.hashCode());
    }

    @Test
    public void testToString() {
        IBPPaymentRequest ibpPaymentRequest1 = new IBPPaymentRequest();
        ibpPaymentRequest1.setCurrency("GBP");
        ibpPaymentRequest1.setAmount("65465");
        ibpPaymentRequest1.setDebtorSortCodeAccountNumber("6765765");
        Logger log = LoggerFactory.getLogger(IBPPaymentRequestTest.class);
        log.info(ibpPaymentRequest1.toString());
    }

    @Test
    public void toBuilder() {
        IBPPaymentRequest ibpPaymentRequest1 = new IBPPaymentRequest();
        ibpPaymentRequest1.setCurrency("GBP");
        ibpPaymentRequest1.setAmount("65465");
        ibpPaymentRequest1.setDebtorSortCodeAccountNumber("6765765");
        Logger log = LoggerFactory.getLogger(IBPPaymentRequestTest.class);
        log.info(ibpPaymentRequest1.toBuilder().toString());
    }
}