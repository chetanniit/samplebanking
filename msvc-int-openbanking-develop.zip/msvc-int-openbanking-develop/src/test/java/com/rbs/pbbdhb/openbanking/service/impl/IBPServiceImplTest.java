package com.rbs.pbbdhb.openbanking.service.impl;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.account.AccountAccessConsentsResponse;
import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;
import com.rbs.pbbdhb.openbanking.model.account.AccountDetails;
import com.rbs.pbbdhb.openbanking.model.account.AccountRequestData;
import com.rbs.pbbdhb.openbanking.model.account.Risk;
import com.rbs.pbbdhb.openbanking.model.common.BcAuthorizedTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.FinalTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.IamTokenResponse;
import com.rbs.pbbdhb.openbanking.model.common.LoginHintTokenResponse;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentRequest;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDataDomesticConsent;
import com.rbs.pbbdhb.openbanking.model.payment.OBWriteDomesticConsent;
import com.rbs.pbbdhb.openbanking.service.AccountDetailsService;
import com.rbs.pbbdhb.openbanking.service.BcAuthorizeService;
import com.rbs.pbbdhb.openbanking.service.FinalTokenService;
import com.rbs.pbbdhb.openbanking.service.GenerateConsentService;
import com.rbs.pbbdhb.openbanking.service.IamTokenGeneratorService;
import com.rbs.pbbdhb.openbanking.service.PaymentService;
import com.rbs.pbbdhb.openbanking.util.PaymentHelper;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class IBPServiceImplTest {

    @Mock
    private IamTokenGeneratorService generateIamTokenService;

    @Mock
    private GenerateConsentService generateConsentService;

    @Mock
    private BcAuthorizeService bcAuthorizeService;

    @Mock
    private FinalTokenService finalTokenService;

    @Mock
    private AccountDetailsService accountDetailsService;

    @Mock
    private PaymentService paymentService;

    @Mock
    private PaymentHelper paymentHelper;

    @InjectMocks
    private IBPServiceImpl ibpService;
    
    private String accountType = "accounts";
    private String cin = "123093494";
    private String brand = "nwb";
    private String accountNumber = "12345678";

    @Test
    public void generateAccountBalanceResponse() throws Exception {
        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setAccounts(new ArrayList<>());
        accountDetails.setAccountType("");
        accountDetails.setAccountId(new String());
        accountDetails.setAccountSubType(new String());
        accountDetails.setDescription(new String());
        accountDetails.setCurrency(new String());
        ResponseEntity<AccountBalanceResponse> value = new ResponseEntity(
                accountDetails,
                HttpStatus.OK);
        FinalTokenResponse finalTokenResponse = new FinalTokenResponse();
        finalTokenResponse.setAccess_token("1");
        ResponseEntity<FinalTokenResponse> testFinalTokenResponse = new ResponseEntity<>(
                finalTokenResponse,
                HttpStatus.OK);
        IamTokenResponse tokenResponse = IamTokenResponse.builder().iamToken("111").jwt("1111").build();

        try {
            Mockito.when(generateIamTokenService.generateIamToken(ArgumentMatchers.any(),
                    ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(tokenResponse));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Mockito.when(accountDetailsService.getAccountDetails(ArgumentMatchers.any(),
                ArgumentMatchers.anyString())).thenReturn(value);

        AccountAccessConsentsResponse consentsResponse = new AccountAccessConsentsResponse();
        AccountRequestData data= new AccountRequestData();
        data.setConsentId("1111");
        consentsResponse.setData(data);
        consentsResponse.setRisk(new Risk());
        Mockito.when(generateConsentService.generateAccountConsentToken(ArgumentMatchers.any(),
                ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(consentsResponse));


        LoginHintTokenResponse tokenLoginResponse = new LoginHintTokenResponse();
        tokenLoginResponse.setLogin_hint_token("11");

        BcAuthorizedTokenResponse authTokenResponse = new BcAuthorizedTokenResponse();
        authTokenResponse.setAuth_req_id("111");
        authTokenResponse.setExpires_in("20");
        Mockito.when(bcAuthorizeService.getBcAuthorized(ArgumentMatchers.any(),
                ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(ResponseEntity.ok(authTokenResponse));
        Mockito.when(
                        finalTokenService.getFinalToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),
                                ArgumentMatchers.anyString()))
                .thenReturn(testFinalTokenResponse);

        ResponseEntity<AccountBalanceResponse> accountBalanceResponseResponseEntity = ibpService.getAccountBalances(
                cin, brand);
        Assertions.assertNotNull(accountBalanceResponseResponseEntity.getBody());
    }

    @Test
    public void returnDomesticPaymentBody() throws Exception {
        IBPPaymentRequest request = new IBPPaymentRequest();
        OBWriteDomesticConsent consent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent data = new OBWriteDataDomesticConsent();
        data.setConsentId("1");
        OBWriteDomesticConsent consent2 = OBWriteDomesticConsent.builder().data(data).build();
        consent2.getData().setConsentId("11");
        OBWriteDomesticConsent consent3 = new OBWriteDomesticConsent();
        IamTokenResponse tokenResponse = IamTokenResponse.builder().iamToken("111").jwt("1111").build();
        FinalTokenResponse finalTokenResponse = new FinalTokenResponse();
        finalTokenResponse.setAccess_token("1");
        ResponseEntity<FinalTokenResponse> testFinalTokenResponse = new ResponseEntity<>(
                finalTokenResponse,
                HttpStatus.OK);

        try {
            Mockito.when(generateIamTokenService.generateIamToken(ArgumentMatchers.any(),
                    ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(tokenResponse));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Mockito.when(paymentHelper.createRequest(ArgumentMatchers.any(), ArgumentMatchers.anyString(),
                        ArgumentMatchers.anyString(), ArgumentMatchers.eq(Constants.LUMPSUM)))
                .thenReturn(consent);

        Mockito.when(generateConsentService.generatePaymentConsent(ArgumentMatchers.anyString(),
                        ArgumentMatchers.any(), ArgumentMatchers.anyString()))
                .thenReturn(ResponseEntity.ok(consent2));

        LoginHintTokenResponse tokenLoginResponse = new LoginHintTokenResponse();
        tokenLoginResponse.setLogin_hint_token("11");

        BcAuthorizedTokenResponse authTokenResponse = new BcAuthorizedTokenResponse();
        authTokenResponse.setAuth_req_id("111");
        authTokenResponse.setExpires_in("20");

        Mockito.when(bcAuthorizeService.getBcAuthorized(ArgumentMatchers.any(),
                ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(ResponseEntity.ok(authTokenResponse));

        Mockito.when(
                        finalTokenService.getFinalToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),
                                ArgumentMatchers.anyString()))
                .thenReturn(testFinalTokenResponse);

        Mockito.when(
                        paymentService.createDomesticPayment(ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                                ArgumentMatchers.anyString()))
                .thenReturn(ResponseEntity.ok(consent3));

        ResponseEntity<IBPPaymentResponse> paymentResponseResponseEntity = ibpService.createDomesticPayment(
                cin, accountNumber, brand, request, Constants.LUMPSUM);
        Assertions.assertNotNull(paymentResponseResponseEntity);
    }
    
    @Test
    public void returnDomesticPaymentBodyRedemptions() throws Exception {
        IBPPaymentRequest request = new IBPPaymentRequest();
        OBWriteDomesticConsent consent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent data = new OBWriteDataDomesticConsent();
        data.setConsentId("1");
        OBWriteDomesticConsent consent2 = OBWriteDomesticConsent.builder().data(data).build();
        consent2.getData().setConsentId("11");
        OBWriteDomesticConsent consent3 = new OBWriteDomesticConsent();
        IamTokenResponse tokenResponse = IamTokenResponse.builder().iamToken("111").jwt("1111").build();
        FinalTokenResponse finalTokenResponse = new FinalTokenResponse();
        finalTokenResponse.setAccess_token("1");
        ResponseEntity<FinalTokenResponse> testFinalTokenResponse = new ResponseEntity<>(
                finalTokenResponse,
                HttpStatus.OK);

        try {
            Mockito.when(generateIamTokenService.generateIamToken(ArgumentMatchers.any(),
                    ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(tokenResponse));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Mockito.when(paymentHelper.createRequest(ArgumentMatchers.any(), ArgumentMatchers.anyString(),
                        ArgumentMatchers.anyString(), ArgumentMatchers.eq(Constants.REDEMPTIONS)))
                .thenReturn(consent);

        Mockito.when(generateConsentService.generatePaymentConsent(ArgumentMatchers.anyString(),
                        ArgumentMatchers.any(), ArgumentMatchers.anyString()))
                .thenReturn(ResponseEntity.ok(consent2));

        LoginHintTokenResponse tokenLoginResponse = new LoginHintTokenResponse();
        tokenLoginResponse.setLogin_hint_token("11");

        BcAuthorizedTokenResponse authTokenResponse = new BcAuthorizedTokenResponse();
        authTokenResponse.setAuth_req_id("111");
        authTokenResponse.setExpires_in("20");

        Mockito.when(bcAuthorizeService.getBcAuthorized(ArgumentMatchers.any(),
                ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(ResponseEntity.ok(authTokenResponse));

        Mockito.when(
                        finalTokenService.getFinalToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),
                                ArgumentMatchers.anyString()))
                .thenReturn(testFinalTokenResponse);

        Mockito.when(
                        paymentService.createDomesticPayment(ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                                ArgumentMatchers.anyString()))
                .thenReturn(ResponseEntity.ok(consent3));

        ResponseEntity<IBPPaymentResponse> paymentResponseResponseEntity = ibpService.createDomesticPayment(
                cin, accountNumber, brand, request, Constants.REDEMPTIONS);
        Assertions.assertNotNull(paymentResponseResponseEntity);
    }

    @SneakyThrows
    @Test
    public void getAccountBalancesExceptionCase(){
        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setAccounts(new ArrayList<>());
        accountDetails.setAccountType("");
        accountDetails.setAccountId(new String());
        accountDetails.setAccountSubType(new String());
        accountDetails.setDescription(new String());
        accountDetails.setCurrency(new String());
        ResponseEntity<AccountBalanceResponse> value = new ResponseEntity(accountDetails, HttpStatus.OK);
        IamTokenResponse tokenResponse = IamTokenResponse.builder().iamToken("111").jwt("1111").build();

        try {
            Mockito.when(generateIamTokenService.generateIamToken(ArgumentMatchers.any(),
                    ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(tokenResponse));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        AccountAccessConsentsResponse consentsResponse = new AccountAccessConsentsResponse();
        AccountRequestData data= new AccountRequestData();
        data.setConsentId("1111");
        consentsResponse.setData(data);
        consentsResponse.setRisk(new Risk());
        Mockito.when(generateConsentService.generateAccountConsentToken(ArgumentMatchers.any(),
                ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(consentsResponse));


        LoginHintTokenResponse tokenLoginResponse = new LoginHintTokenResponse();
        tokenLoginResponse.setLogin_hint_token("11");

        BcAuthorizedTokenResponse authTokenResponse = new BcAuthorizedTokenResponse();
        authTokenResponse.setAuth_req_id("111");
        authTokenResponse.setExpires_in("20");
        Mockito.when(bcAuthorizeService.getBcAuthorized(ArgumentMatchers.any(),
                ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.any(), ArgumentMatchers.any())).thenThrow(new RuntimeException());

        ResponseEntity<AccountBalanceResponse> accountBalanceResponseResponseEntity = ibpService.getAccountBalances(
                cin, brand);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,accountBalanceResponseResponseEntity.getStatusCode());
    }


    @Test
    @SneakyThrows
    public void testForCreateDomesticPaymentExceptionCaseRedemptions(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        OBWriteDomesticConsent consent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent data = new OBWriteDataDomesticConsent();
        data.setConsentId("1");
        OBWriteDomesticConsent consent2 = OBWriteDomesticConsent.builder().data(data).build();
        consent2.getData().setConsentId("11");
        OBWriteDomesticConsent consent3 = new OBWriteDomesticConsent();
        IamTokenResponse tokenResponse = IamTokenResponse.builder().iamToken("111").jwt("1111").build();
//        FinalTokenResponse finalTokenResponse = new FinalTokenResponse();
//        finalTokenResponse.setAccess_token("1");
//        ResponseEntity<FinalTokenResponse> testFinalTokenResponse = new ResponseEntity<>(
//                finalTokenResponse,
//                HttpStatus.OK);

        try {
            Mockito.when(generateIamTokenService.generateIamToken(ArgumentMatchers.any(),
                    ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(tokenResponse));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Mockito.when(paymentHelper.createRequest(ArgumentMatchers.any(), ArgumentMatchers.anyString(),
                        ArgumentMatchers.anyString(), ArgumentMatchers.eq(Constants.REDEMPTIONS)))
                .thenReturn(consent);

        Mockito.when(generateConsentService.generatePaymentConsent(ArgumentMatchers.anyString(),
                        ArgumentMatchers.any(), ArgumentMatchers.anyString()))
                .thenReturn(ResponseEntity.ok(consent2));

        LoginHintTokenResponse tokenLoginResponse = new LoginHintTokenResponse();
        tokenLoginResponse.setLogin_hint_token("11");

        BcAuthorizedTokenResponse authTokenResponse = new BcAuthorizedTokenResponse();
        authTokenResponse.setAuth_req_id("111");
        authTokenResponse.setExpires_in("20");

        Mockito.when(bcAuthorizeService.getBcAuthorized(ArgumentMatchers.any(),
                ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.any(), ArgumentMatchers.any())).thenThrow(new RuntimeException());


        ResponseEntity<IBPPaymentResponse> paymentResponseResponseEntity = ibpService.createDomesticPayment(
                cin, accountNumber, brand, request, Constants.REDEMPTIONS);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,paymentResponseResponseEntity.getStatusCode());
    }

    @Test
    @SneakyThrows
    public void testForCreateDomesticPaymentExceptionCase(){
        IBPPaymentRequest request = new IBPPaymentRequest();
        OBWriteDomesticConsent consent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent data = new OBWriteDataDomesticConsent();
        data.setConsentId("1");
        OBWriteDomesticConsent consent2 = OBWriteDomesticConsent.builder().data(data).build();
        consent2.getData().setConsentId("11");
        OBWriteDomesticConsent consent3 = new OBWriteDomesticConsent();
        IamTokenResponse tokenResponse = IamTokenResponse.builder().iamToken("111").jwt("1111").build();

        try {
            Mockito.when(generateIamTokenService.generateIamToken(ArgumentMatchers.any(),
                    ArgumentMatchers.anyString())).thenReturn(ResponseEntity.ok(tokenResponse));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Mockito.when(paymentHelper.createRequest(ArgumentMatchers.any(), ArgumentMatchers.anyString(),
                        ArgumentMatchers.anyString(), ArgumentMatchers.eq(Constants.LUMPSUM)))
                .thenReturn(consent);

        Mockito.when(generateConsentService.generatePaymentConsent(ArgumentMatchers.anyString(),
                        ArgumentMatchers.any(), ArgumentMatchers.anyString()))
                .thenReturn(ResponseEntity.ok(consent2));

        LoginHintTokenResponse tokenLoginResponse = new LoginHintTokenResponse();
        tokenLoginResponse.setLogin_hint_token("11");

        BcAuthorizedTokenResponse authTokenResponse = new BcAuthorizedTokenResponse();
        authTokenResponse.setAuth_req_id("111");
        authTokenResponse.setExpires_in("20");

        Mockito.when(bcAuthorizeService.getBcAuthorized(ArgumentMatchers.any(),
                ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.any(), ArgumentMatchers.any())).thenThrow(new RuntimeException());


        ResponseEntity<IBPPaymentResponse> paymentResponseResponseEntity = ibpService.createDomesticPayment(
                cin, accountNumber, brand, request, Constants.LUMPSUM);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,paymentResponseResponseEntity.getStatusCode());
    }

}
