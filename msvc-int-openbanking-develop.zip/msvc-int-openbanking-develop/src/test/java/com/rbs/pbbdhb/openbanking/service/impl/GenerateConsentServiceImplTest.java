package com.rbs.pbbdhb.openbanking.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.nimbusds.jose.crypto.bc.BouncyCastleProviderSingleton;
import com.rbs.pbbdhb.openbanking.model.account.AccountAccessConsentsResponse;
import com.rbs.pbbdhb.openbanking.model.account.AccountRequestData;
import com.rbs.pbbdhb.openbanking.model.payment.*;
import com.rbs.pbbdhb.openbanking.service.RestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.security.Security;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class GenerateConsentServiceImplTest {

    @InjectMocks
    private GenerateConsentServiceImpl generateConsentService;

    @Mock
    private RestService restService;

    @Mock
    private Resource clientJKSPath;

    @BeforeEach
    public void init() {
        ReflectionTestUtils.setField(generateConsentService, "financialId", "8765");
        ReflectionTestUtils.setField(generateConsentService, "clientId", "testmock1234");
        ReflectionTestUtils.setField(generateConsentService, "consentUrlNwb", "consentUrlNwb/");
        ReflectionTestUtils.setField(generateConsentService, "consentUrlRbs", "consentUrlRbs/");
        ReflectionTestUtils.setField(generateConsentService, "paymentConsentUrlNwb", "paymentConsentUrlNwb/");
        ReflectionTestUtils.setField(generateConsentService, "paymentConsentUrlRbs", "paymentConsentUrlRbs/");
        ReflectionTestUtils.setField(generateConsentService, "tppId", "6542fec525228b64ee");
        ReflectionTestUtils.setField(generateConsentService, "clientJksPassword", "abcdef");
        ReflectionTestUtils.setField(generateConsentService, "kid", "kjVRgP0U9v0vNt3M7ihYIXecNC0");
        ReflectionTestUtils.setField(generateConsentService, "trustAnchor", "openbanking.org.uk");
    }

    @Test
    public void shouldGenerateAccountConsentToken_NWB() {
        AccountAccessConsentsResponse accountAccessConsentsResponse = new AccountAccessConsentsResponse();
        AccountRequestData accountRequestData = new AccountRequestData();
        List<String> listPermissions = new ArrayList<>();
        listPermissions.add("admin");
        accountRequestData.setConsentId("1234");
        accountRequestData.setExpirationDateTime("123456");
        accountAccessConsentsResponse.setData(accountRequestData);
        when(restService.exchange(any(), eq(HttpMethod.POST), any(), any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountAccessConsentsResponse));
        ResponseEntity<AccountAccessConsentsResponse> actualResponse = generateConsentService.generateAccountConsentToken("12345", "NWB");
        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
    }

    @Test
    public void shouldGenerateAccountConsentToken_RBS() {
        AccountAccessConsentsResponse accountAccessConsentsResponse = new AccountAccessConsentsResponse();
        AccountRequestData accountRequestData = new AccountRequestData();
        List<String> listPermissions = new ArrayList<>();
        listPermissions.add("admin");
        accountRequestData.setConsentId("1234");
        accountRequestData.setExpirationDateTime("123456");
        accountAccessConsentsResponse.setData(accountRequestData);
        when(restService.exchange(any(), eq(HttpMethod.POST), any(), any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountAccessConsentsResponse));
        ResponseEntity<AccountAccessConsentsResponse> actualResponse = generateConsentService.generateAccountConsentToken("12345", "RBS");
        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
    }

    @Test
    public void shouldGeneratePaymentConsent_NWB(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        when(clientJKSPath.getFilename()).thenReturn("testmock1234.jks");
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = generateConsentService.generatePaymentConsent("bcg675hdhw",obWriteDomesticConsent,"NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
    }

    @Test
    public void shouldGeneratePaymentConsent_RBS(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        when(clientJKSPath.getFilename()).thenReturn("testmock1234.jks");
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = generateConsentService.generatePaymentConsent("bcg675hdhw",obWriteDomesticConsent,"RBS");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
    }
}
