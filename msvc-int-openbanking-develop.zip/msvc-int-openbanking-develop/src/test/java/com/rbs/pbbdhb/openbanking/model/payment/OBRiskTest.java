package com.rbs.pbbdhb.openbanking.model.payment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
public class OBRiskTest {

    @Test
    public void testEquals() {
        OBRisk obRisk1 = new OBRisk();
        obRisk1.setMerchantCategoryCode("87567567");
        obRisk1.setMerchantCustomerIdentification("hfhgfgh");

        OBRisk obRisk2 = new OBRisk();
        obRisk2.setMerchantCategoryCode("87567567");
        obRisk2.setMerchantCustomerIdentification("hfhgfgh");
        Assertions.assertTrue(obRisk1.equals(obRisk2));
    }

    @Test
    public void testHashCode() {
        OBRisk obRisk1 = new OBRisk();
        obRisk1.setMerchantCategoryCode("87567567");
        obRisk1.setMerchantCustomerIdentification("hfhgfgh");
        Assertions.assertNotEquals(0,obRisk1.hashCode());
    }

    @Test
    public void toBuilder() {
        OBRisk obRisk1 = new OBRisk();
        obRisk1.setMerchantCategoryCode("87567567");
        obRisk1.setMerchantCustomerIdentification("hfhgfgh");

        Logger log = LoggerFactory.getLogger(OBRiskTest.class);
        log.info(obRisk1.toBuilder().toString());
    }
}