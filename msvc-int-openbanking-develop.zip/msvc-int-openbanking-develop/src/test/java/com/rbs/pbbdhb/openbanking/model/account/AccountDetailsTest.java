package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AccountDetailsTest {

    @Test
    public void testEquals() {
        AccountDetails accountDetails1 = new AccountDetails();
        accountDetails1.setAccountId("65456");
        accountDetails1.setCurrency("GBP");
        accountDetails1.setAccountType("Personal");
        accountDetails1.setDescription("Description");

        AccountDetails accountDetails2 = new AccountDetails();
        accountDetails2.setAccountId("65456");
        accountDetails2.setCurrency("GBP");
        accountDetails2.setAccountType("Personal");
        accountDetails2.setDescription("Description");

        Assertions.assertTrue(accountDetails1.equals(accountDetails2));
    }

    @Test
    public void testHashCode() {
        AccountDetails accountDetails1 = new AccountDetails();
        accountDetails1.setAccountId("65456");
        accountDetails1.setCurrency("GBP");
        accountDetails1.setAccountType("Personal");
        accountDetails1.setDescription("Description");
        Assertions.assertNotEquals(0,accountDetails1.hashCode());
    }
}