package com.rbs.pbbdhb.openbanking.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.security.Security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.nimbusds.jose.crypto.bc.BouncyCastleProviderSingleton;
import com.rbs.pbbdhb.openbanking.model.common.BcAuthorizedTokenResponse;
import com.rbs.pbbdhb.openbanking.service.RestService;

@ExtendWith(MockitoExtension.class)
public class BcAuthorizeServiceImplTest {

	static{
		Security.addProvider(BouncyCastleProviderSingleton.getInstance());
	}

    @InjectMocks
    private BcAuthorizeServiceImpl bcAuthorizeService;

    @Mock
    private RestService restService;
   
    @BeforeEach
    public void init() {
    
        ReflectionTestUtils.setField(bcAuthorizeService, "bcAuthorizePathNwb", "bcAuthorizePathNwb/");
        ReflectionTestUtils.setField(bcAuthorizeService, "bcAuthorizePathRbs", "bcAuthorizePathRbs/");
        ReflectionTestUtils.setField(bcAuthorizeService, "clientAssertionType", "abcdef");        
        ReflectionTestUtils.setField(bcAuthorizeService, "accountType", "Personal");        
        ReflectionTestUtils.setField(bcAuthorizeService, "clientJksPath", new ClassPathResource("3Bh2b0B5raDW0yaiQ5vk92rbs_signing.jks"));
        ReflectionTestUtils.setField(bcAuthorizeService, "clientJksPassword", "changeit");
        ReflectionTestUtils.setField(bcAuthorizeService, "clientId", "3Bh2b0B5raDW0yaiQ5vk92rbs");
        ReflectionTestUtils.setField(bcAuthorizeService, "kid", "kjVRgP0U9v0vNt3M7ihYIXecNC0");
    }
    

    @Test
    public void shouldGetBcAuthorized_NWB() throws Exception{
        BcAuthorizedTokenResponse bcAuthorizedTokenResponse = new BcAuthorizedTokenResponse();
        bcAuthorizedTokenResponse.setExpires_in("1234");
        bcAuthorizedTokenResponse.setAuth_req_id("111");
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(bcAuthorizedTokenResponse));
        ResponseEntity<BcAuthorizedTokenResponse> actualResponse = bcAuthorizeService.getBcAuthorized("12345","12345","456001","abcdef","NWB");
        assertEquals(HttpStatus.OK,actualResponse.getStatusCode());
        assertNotNull(actualResponse.getBody());
    }

    @Test
    public void shouldGetBcAuthorized_RBS() throws Exception{
        BcAuthorizedTokenResponse bcAuthorizedTokenResponse = new BcAuthorizedTokenResponse();
        bcAuthorizedTokenResponse.setExpires_in("1234");
        bcAuthorizedTokenResponse.setAuth_req_id("111");
        
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(bcAuthorizedTokenResponse));
        ResponseEntity<BcAuthorizedTokenResponse> actualResponse = bcAuthorizeService.getBcAuthorized("12345","12345","456001","abcdef","RBS");
        assertEquals(HttpStatus.OK,actualResponse.getStatusCode());
        assertNotNull(actualResponse.getBody());
    }

}