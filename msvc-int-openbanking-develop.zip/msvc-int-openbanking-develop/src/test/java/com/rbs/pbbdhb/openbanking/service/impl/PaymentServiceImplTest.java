package com.rbs.pbbdhb.openbanking.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.nimbusds.jose.crypto.bc.BouncyCastleProviderSingleton;
import com.rbs.pbbdhb.enums.Exceptions;
import com.rbs.pbbdhb.helper.ExceptionHelper;
import com.rbs.pbbdhb.openbanking.model.payment.*;
import com.rbs.pbbdhb.openbanking.service.RestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.security.Security;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceImplTest {

    @Mock
    private RestService restService;

    @Mock
    private Resource clientJKSPath;

    @Mock
    private ExceptionHelper exceptionHelper;

    @InjectMocks
    private PaymentServiceImpl paymentService;

    @BeforeEach
    public void init(){
        when(clientJKSPath.getFilename()).thenReturn("testmock1234.jks");
        ReflectionTestUtils.setField(paymentService,"clientId","testmock1234");
        ReflectionTestUtils.setField(paymentService,"clientJksPassword","abcdef");
        ReflectionTestUtils.setField(paymentService, "financialId", "8765");
        ReflectionTestUtils.setField(paymentService, "paymentUrlNwb", "paymentUrlNwb/");
        ReflectionTestUtils.setField(paymentService, "paymentUrlRbs", "paymentUrlRbs/");
        ReflectionTestUtils.setField(paymentService, "kid", "kjVRgP0U9v0vNt3M7ihYIXecNC0");
        ReflectionTestUtils.setField(paymentService, "trustAnchor", "openbanking.org.uk");
        ReflectionTestUtils.setField(paymentService, "tppId", "6542fec525228b64ee");
    }

    @Test
    public void createDomesticPayment_NWB(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        OBRemittanceInformation remittanceInformation = new OBRemittanceInformation();
        remittanceInformation.setUnstructured("abcdef");
        remittanceInformation.setReference("hgfhgfh");
        obDomestic.setRemittanceInformation(remittanceInformation);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent.setRisk(obRisk);
        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
    }

    @Test
    public void createDomesticPayment_RBS(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        OBRemittanceInformation remittanceInformation = new OBRemittanceInformation();
        remittanceInformation.setUnstructured("abcdef");
        remittanceInformation.setReference("hgfhgfh");
        obDomestic.setRemittanceInformation(remittanceInformation);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent.setRisk(obRisk);
        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "RBS");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
    }

    @Test
    public void createDomesticPayment_NoInitiation(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent.setRisk(obRisk);
        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK, domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_NoStatus(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK, domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_NoInstructedAmount(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK, domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_InstructedAmountNoAmount(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_InstructedAmountNoCurrency(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_NoDebtorAccount(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_DebtorAccountNoIdentification(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_NoDomesticPaymentId(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_NoRemittance(){
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor =new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(),eq(HttpMethod.POST),any(),any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf",obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK,domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }

    @Test
    public void createDomesticPayment_RemittanceNoReference() {
        OBWriteDomesticConsent obWriteDomesticConsent = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent.setConsentId("35625472");
        obWriteDataDomesticConsent.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent.setStatus("jhsf");
        OBDomestic obDomestic = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor = new OBCashAccountCreditor();
        obCashAccountCreditor.setIdentification("14354328767Sakshi");
        obCashAccountCreditor.setName("Sakshi");
        obCashAccountCreditor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic.setCreditorAccount(obCashAccountCreditor);
        OBCashAccountDebtor obCashAccountDebtor = new OBCashAccountDebtor();
        obCashAccountDebtor.setIdentification("123456877696Sakshi");
        obCashAccountDebtor.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor.setName("Sakshi");
        obDomestic.setDebtorAccount(obCashAccountDebtor);
        obDomestic.setInstructionIdentification("jhgjhh");
        obDomestic.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount = new OBDomesticInstructedAmount();
        instructedAmount.setAmount("87687");
        instructedAmount.setCurrency("GBP");
        obDomestic.setInstructedAmount(instructedAmount);
        OBRemittanceInformation remittanceInformation = new OBRemittanceInformation();
        remittanceInformation.setUnstructured("abcdef");
        obDomestic.setRemittanceInformation(remittanceInformation);
        obWriteDataDomesticConsent.setInitiation(obDomestic);
        OBRisk obRisk = new OBRisk();
        obRisk.setMerchantCategoryCode("87567567");
        obRisk.setMerchantCustomerIdentification("hfhgfgh");

        obWriteDomesticConsent.setData(obWriteDataDomesticConsent);
        when(restService.exchange(any(), eq(HttpMethod.POST), any(), any())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(obWriteDomesticConsent));
        Security.addProvider(BouncyCastleProviderSingleton.getInstance());
        ResponseEntity<OBWriteDomesticConsent> domesticConsent = paymentService.createDomesticPayment("jhghf", obWriteDomesticConsent, "NWB");
        assertEquals(HttpStatus.OK, domesticConsent.getStatusCode());
        Mockito.verify(exceptionHelper).throwException(Exceptions.BUSINESS_EXCEPTION,"internal.server.error");
    }
}