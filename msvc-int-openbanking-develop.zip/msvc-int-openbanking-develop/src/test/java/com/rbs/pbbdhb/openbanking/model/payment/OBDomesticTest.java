package com.rbs.pbbdhb.openbanking.model.payment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
public class OBDomesticTest {

    @Test
    public void testEquals() {
        OBDomestic obDomestic1 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor1 = new OBCashAccountCreditor();
        obCashAccountCreditor1.setIdentification("14354328767Sakshi");
        obCashAccountCreditor1.setName("Sakshi");
        obCashAccountCreditor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic1.setCreditorAccount(obCashAccountCreditor1);
        OBCashAccountDebtor obCashAccountDebtor1 =new OBCashAccountDebtor();
        obCashAccountDebtor1.setIdentification("123456877696Sakshi");
        obCashAccountDebtor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor1.setName("Sakshi");
        obDomestic1.setDebtorAccount(obCashAccountDebtor1);
        obDomestic1.setInstructionIdentification("jhgjhh");
        obDomestic1.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount1 = new OBDomesticInstructedAmount();
        instructedAmount1.setAmount("87687");
        instructedAmount1.setCurrency("GBP");
        obDomestic1.setInstructedAmount(instructedAmount1);
        OBRemittanceInformation remittanceInformation1 = new OBRemittanceInformation();
        remittanceInformation1.setUnstructured("abcdef");
        remittanceInformation1.setReference("hgfhgfh");
        obDomestic1.setRemittanceInformation(remittanceInformation1);

        OBDomestic obDomestic2 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor2 = new OBCashAccountCreditor();
        obCashAccountCreditor2.setIdentification("14354328767Sakshi");
        obCashAccountCreditor2.setName("Sakshi");
        obCashAccountCreditor2.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic2.setCreditorAccount(obCashAccountCreditor2);
        OBCashAccountDebtor obCashAccountDebtor2 =new OBCashAccountDebtor();
        obCashAccountDebtor2.setIdentification("123456877696Sakshi");
        obCashAccountDebtor2.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor2.setName("Sakshi");
        obDomestic2.setDebtorAccount(obCashAccountDebtor2);
        obDomestic2.setInstructionIdentification("jhgjhh");
        obDomestic2.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount2 = new OBDomesticInstructedAmount();
        instructedAmount2.setAmount("87687");
        instructedAmount2.setCurrency("GBP");
        obDomestic2.setInstructedAmount(instructedAmount2);
        OBRemittanceInformation remittanceInformation2= new OBRemittanceInformation();
        remittanceInformation2.setUnstructured("abcdef");
        remittanceInformation2.setReference("hgfhgfh");
        obDomestic2.setRemittanceInformation(remittanceInformation2);

        Assertions.assertTrue(obDomestic1.equals(obDomestic2));
    }

    @Test
    public void testHashCode() {
        OBDomestic obDomestic1 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor1 = new OBCashAccountCreditor();
        obCashAccountCreditor1.setIdentification("14354328767Sakshi");
        obCashAccountCreditor1.setName("Sakshi");
        obCashAccountCreditor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic1.setCreditorAccount(obCashAccountCreditor1);
        OBCashAccountDebtor obCashAccountDebtor1 =new OBCashAccountDebtor();
        obCashAccountDebtor1.setIdentification("123456877696Sakshi");
        obCashAccountDebtor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor1.setName("Sakshi");
        obDomestic1.setDebtorAccount(obCashAccountDebtor1);
        obDomestic1.setInstructionIdentification("jhgjhh");
        obDomestic1.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount1 = new OBDomesticInstructedAmount();
        instructedAmount1.setAmount("87687");
        instructedAmount1.setCurrency("GBP");
        obDomestic1.setInstructedAmount(instructedAmount1);
        OBRemittanceInformation remittanceInformation1 = new OBRemittanceInformation();
        remittanceInformation1.setUnstructured("abcdef");
        remittanceInformation1.setReference("hgfhgfh");
        obDomestic1.setRemittanceInformation(remittanceInformation1);
        Assertions.assertNotEquals(0,obDomestic1.hashCode());
    }

    @Test
    public void toBuilder() {
        OBDomestic obDomestic1 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor1 = new OBCashAccountCreditor();
        obCashAccountCreditor1.setIdentification("14354328767Sakshi");
        obCashAccountCreditor1.setName("Sakshi");
        obCashAccountCreditor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic1.setCreditorAccount(obCashAccountCreditor1);
        OBCashAccountDebtor obCashAccountDebtor1 =new OBCashAccountDebtor();
        obCashAccountDebtor1.setIdentification("123456877696Sakshi");
        obCashAccountDebtor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor1.setName("Sakshi");
        obDomestic1.setDebtorAccount(obCashAccountDebtor1);
        obDomestic1.setInstructionIdentification("jhgjhh");
        obDomestic1.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount1 = new OBDomesticInstructedAmount();
        instructedAmount1.setAmount("87687");
        instructedAmount1.setCurrency("GBP");
        obDomestic1.setInstructedAmount(instructedAmount1);
        OBRemittanceInformation remittanceInformation1 = new OBRemittanceInformation();
        remittanceInformation1.setUnstructured("abcdef");
        remittanceInformation1.setReference("hgfhgfh");
        obDomestic1.setRemittanceInformation(remittanceInformation1);
        Logger log = LoggerFactory.getLogger(OBDomesticTest.class);
        log.info(obDomestic1.toBuilder().toString());
    }
}