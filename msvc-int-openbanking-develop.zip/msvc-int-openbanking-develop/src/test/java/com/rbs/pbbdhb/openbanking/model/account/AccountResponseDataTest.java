package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class AccountResponseDataTest {

    @Test
    public void testEquals() {
        AccountResponseData accountResponseData1 = new AccountResponseData();
        List<AccountBalance> list1 = new ArrayList<>();
        AccountBalance accountBalance1 = new AccountBalance();
        accountBalance1.setAccountId("65456");
        accountBalance1.setType("Expected");
        list1.add(accountBalance1);
        accountResponseData1.setAccountBalance(list1);
        List<AccountDetails> list2 = new ArrayList<>();
        AccountDetails accountDetails1 = new AccountDetails();
        accountDetails1.setAccountType("Personal");
        list2.add(accountDetails1);
        accountResponseData1.setAccountDetails(list2);

        AccountResponseData accountResponseData2 = new AccountResponseData();
        List<AccountBalance> list3 = new ArrayList<>();
        AccountBalance accountBalance2 = new AccountBalance();
        accountBalance2.setAccountId("65456");
        accountBalance2.setType("Expected");
        list3.add(accountBalance2);
        accountResponseData2.setAccountBalance(list3);
        List<AccountDetails> list4 = new ArrayList<>();
        AccountDetails accountDetails2 = new AccountDetails();
        accountDetails2.setAccountType("Personal");
        list4.add(accountDetails2);
        accountResponseData2.setAccountDetails(list4);

        Assertions.assertTrue(accountResponseData1.equals(accountResponseData2));
    }

    @Test
    public  void testHashCode() {
        AccountResponseData accountResponseData1 = new AccountResponseData();
        List<AccountBalance> list1 = new ArrayList<>();
        AccountBalance accountBalance1 = new AccountBalance();
        accountBalance1.setAccountId("65456");
        accountBalance1.setType("Expected");
        list1.add(accountBalance1);
        accountResponseData1.setAccountBalance(list1);
        List<AccountDetails> list2 = new ArrayList<>();
        AccountDetails accountDetails1 = new AccountDetails();
        accountDetails1.setAccountType("Personal");
        list2.add(accountDetails1);
        accountResponseData1.setAccountDetails(list2);
        Assertions.assertNotEquals(0,accountResponseData1.hashCode());
    }
}