package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AccountBalanceTest {

    @Test
    public void testEquals() {
        AccountBalance accountBalance1 = new AccountBalance();
        accountBalance1.setAccountId("7656");
        accountBalance1.setType("Expected");
        Amount amount1 = new Amount();
        amount1.setCurrency("GBP");
        amount1.setAmount("564564");
        accountBalance1.setAmount(amount1);

        AccountBalance accountBalance2 = new AccountBalance();
        accountBalance2.setAccountId("7656");
        accountBalance2.setType("Expected");
        Amount amount2 = new Amount();
        amount2.setCurrency("GBP");
        amount2.setAmount("564564");
        accountBalance2.setAmount(amount2);

        Assertions.assertTrue(accountBalance1.equals(accountBalance2));
    }

    @Test
    public void testHashCode() {
        AccountBalance accountBalance1 = new AccountBalance();
        accountBalance1.setAccountId("7656");
        accountBalance1.setType("Expected");
        Amount amount1 = new Amount();
        amount1.setCurrency("GBP");
        amount1.setAmount("564564");
        accountBalance1.setAmount(amount1);

        Assertions.assertNotEquals(0,accountBalance1.hashCode());
    }
}