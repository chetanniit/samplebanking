package com.rbs.pbbdhb.openbanking.model.payment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
public class OBWriteDomesticConsentTest {

    @Test
    public void testEquals() {
        OBWriteDomesticConsent obWriteDomesticConsent1 = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent1 = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent1.setConsentId("35625472");
        obWriteDataDomesticConsent1.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent1.setStatus("jhsf");
        OBDomestic obDomestic1 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor1 = new OBCashAccountCreditor();
        obCashAccountCreditor1.setIdentification("14354328767Sakshi");
        obCashAccountCreditor1.setName("Sakshi");
        obCashAccountCreditor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic1.setCreditorAccount(obCashAccountCreditor1);
        OBCashAccountDebtor obCashAccountDebtor1 =new OBCashAccountDebtor();
        obCashAccountDebtor1.setIdentification("123456877696Sakshi");
        obCashAccountDebtor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor1.setName("Sakshi");
        obDomestic1.setDebtorAccount(obCashAccountDebtor1);
        obDomestic1.setInstructionIdentification("jhgjhh");
        obDomestic1.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount1 = new OBDomesticInstructedAmount();
        instructedAmount1.setAmount("87687");
        instructedAmount1.setCurrency("GBP");
        obDomestic1.setInstructedAmount(instructedAmount1);
        OBRemittanceInformation remittanceInformation1 = new OBRemittanceInformation();
        remittanceInformation1.setUnstructured("abcdef");
        remittanceInformation1.setReference("hgfhgfh");
        obDomestic1.setRemittanceInformation(remittanceInformation1);
        obWriteDataDomesticConsent1.setInitiation(obDomestic1);
        OBRisk obRisk1 = new OBRisk();
        obRisk1.setMerchantCategoryCode("87567567");
        obRisk1.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent1.setRisk(obRisk1);
        obWriteDomesticConsent1.setData(obWriteDataDomesticConsent1);

        OBWriteDomesticConsent obWriteDomesticConsent2 = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent2 = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent2.setConsentId("35625472");
        obWriteDataDomesticConsent2.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent2.setStatus("jhsf");
        OBDomestic obDomestic2 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor2 = new OBCashAccountCreditor();
        obCashAccountCreditor2.setIdentification("14354328767Sakshi");
        obCashAccountCreditor2.setName("Sakshi");
        obCashAccountCreditor2.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic2.setCreditorAccount(obCashAccountCreditor2);
        OBCashAccountDebtor obCashAccountDebtor2 =new OBCashAccountDebtor();
        obCashAccountDebtor2.setIdentification("123456877696Sakshi");
        obCashAccountDebtor2.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor2.setName("Sakshi");
        obDomestic2.setDebtorAccount(obCashAccountDebtor2);
        obDomestic2.setInstructionIdentification("jhgjhh");
        obDomestic2.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount2 = new OBDomesticInstructedAmount();
        instructedAmount2.setAmount("87687");
        instructedAmount2.setCurrency("GBP");
        obDomestic2.setInstructedAmount(instructedAmount2);
        OBRemittanceInformation remittanceInformation2 = new OBRemittanceInformation();
        remittanceInformation2.setUnstructured("abcdef");
        remittanceInformation2.setReference("hgfhgfh");
        obDomestic2.setRemittanceInformation(remittanceInformation2);
        obWriteDataDomesticConsent2.setInitiation(obDomestic2);
        OBRisk obRisk2 = new OBRisk();
        obRisk2.setMerchantCategoryCode("87567567");
        obRisk2.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent2.setRisk(obRisk2);
        obWriteDomesticConsent2.setData(obWriteDataDomesticConsent2);

        Assertions.assertTrue(obWriteDomesticConsent1.equals(obWriteDomesticConsent2));
    }

    @Test
    public void testHashCode() {
        OBWriteDomesticConsent obWriteDomesticConsent1 = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent1 = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent1.setConsentId("35625472");
        obWriteDataDomesticConsent1.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent1.setStatus("jhsf");
        OBDomestic obDomestic1 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor1 = new OBCashAccountCreditor();
        obCashAccountCreditor1.setIdentification("14354328767Sakshi");
        obCashAccountCreditor1.setName("Sakshi");
        obCashAccountCreditor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic1.setCreditorAccount(obCashAccountCreditor1);
        OBCashAccountDebtor obCashAccountDebtor1 =new OBCashAccountDebtor();
        obCashAccountDebtor1.setIdentification("123456877696Sakshi");
        obCashAccountDebtor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor1.setName("Sakshi");
        obDomestic1.setDebtorAccount(obCashAccountDebtor1);
        obDomestic1.setInstructionIdentification("jhgjhh");
        obDomestic1.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount1 = new OBDomesticInstructedAmount();
        instructedAmount1.setAmount("87687");
        instructedAmount1.setCurrency("GBP");
        obDomestic1.setInstructedAmount(instructedAmount1);
        OBRemittanceInformation remittanceInformation1 = new OBRemittanceInformation();
        remittanceInformation1.setUnstructured("abcdef");
        remittanceInformation1.setReference("hgfhgfh");
        obDomestic1.setRemittanceInformation(remittanceInformation1);
        obWriteDataDomesticConsent1.setInitiation(obDomestic1);
        OBRisk obRisk1 = new OBRisk();
        obRisk1.setMerchantCategoryCode("87567567");
        obRisk1.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent1.setRisk(obRisk1);
        obWriteDomesticConsent1.setData(obWriteDataDomesticConsent1);

        Assertions.assertNotEquals(0,obWriteDomesticConsent1.hashCode());
    }

    @Test
    public void toBuilder() {
        OBWriteDomesticConsent obWriteDomesticConsent1 = new OBWriteDomesticConsent();
        OBWriteDataDomesticConsent obWriteDataDomesticConsent1 = new OBWriteDataDomesticConsent();
        obWriteDataDomesticConsent1.setConsentId("35625472");
        obWriteDataDomesticConsent1.setDomesticPaymentId("765675");
        obWriteDataDomesticConsent1.setStatus("jhsf");
        OBDomestic obDomestic1 = new OBDomestic();
        OBCashAccountCreditor obCashAccountCreditor1 = new OBCashAccountCreditor();
        obCashAccountCreditor1.setIdentification("14354328767Sakshi");
        obCashAccountCreditor1.setName("Sakshi");
        obCashAccountCreditor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obDomestic1.setCreditorAccount(obCashAccountCreditor1);
        OBCashAccountDebtor obCashAccountDebtor1 =new OBCashAccountDebtor();
        obCashAccountDebtor1.setIdentification("123456877696Sakshi");
        obCashAccountDebtor1.setSchemeName("UK.OBIE.SortCodeAccountNumber");
        obCashAccountDebtor1.setName("Sakshi");
        obDomestic1.setDebtorAccount(obCashAccountDebtor1);
        obDomestic1.setInstructionIdentification("jhgjhh");
        obDomestic1.setEndToEndIdentification("abcdefgh");
        OBDomesticInstructedAmount instructedAmount1 = new OBDomesticInstructedAmount();
        instructedAmount1.setAmount("87687");
        instructedAmount1.setCurrency("GBP");
        obDomestic1.setInstructedAmount(instructedAmount1);
        OBRemittanceInformation remittanceInformation1 = new OBRemittanceInformation();
        remittanceInformation1.setUnstructured("abcdef");
        remittanceInformation1.setReference("hgfhgfh");
        obDomestic1.setRemittanceInformation(remittanceInformation1);
        obWriteDataDomesticConsent1.setInitiation(obDomestic1);
        OBRisk obRisk1 = new OBRisk();
        obRisk1.setMerchantCategoryCode("87567567");
        obRisk1.setMerchantCustomerIdentification("hfhgfgh");
        obWriteDomesticConsent1.setRisk(obRisk1);
        obWriteDomesticConsent1.setData(obWriteDataDomesticConsent1);

        Logger log = LoggerFactory.getLogger(OBWriteDomesticConsentTest.class);
        log.info(obWriteDataDomesticConsent1.toBuilder().toString());
    }
}