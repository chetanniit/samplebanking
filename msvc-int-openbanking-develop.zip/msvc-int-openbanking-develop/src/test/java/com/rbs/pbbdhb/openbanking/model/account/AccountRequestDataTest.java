package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AccountRequestDataTest {

    @Test
    public void testEquals() {
        AccountRequestData accountRequestData1 = new AccountRequestData();
        accountRequestData1.setConsentId("765");
        accountRequestData1.setExpirationDateTime("13072022");
        AccountRequestData accountRequestData2 = new AccountRequestData();
        accountRequestData2.setConsentId("765");
        accountRequestData2.setExpirationDateTime("13072022");
        Assertions.assertTrue(accountRequestData1.equals(accountRequestData2));

    }

    @Test
    public void testHashCode() {
        AccountRequestData accountRequestData1 = new AccountRequestData();
        accountRequestData1.setConsentId("765");
        accountRequestData1.setExpirationDateTime("13072022");
        Assertions.assertNotEquals(0,accountRequestData1.hashCode());
    }

    @Test
    public void testToString() {
        AccountRequestData accountRequestData1 = new AccountRequestData();
        accountRequestData1.setConsentId("765");
        accountRequestData1.setExpirationDateTime("13072022");
        Assertions.assertNotNull(accountRequestData1.toString());
    }
}