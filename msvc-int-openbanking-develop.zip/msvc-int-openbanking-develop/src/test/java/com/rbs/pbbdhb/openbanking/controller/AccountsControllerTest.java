package com.rbs.pbbdhb.openbanking.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.model.account.AccountBalanceResponse;
import com.rbs.pbbdhb.openbanking.model.account.Balance;
import com.rbs.pbbdhb.openbanking.service.IBPService;

@ExtendWith(MockitoExtension.class)
public class AccountsControllerTest {

  @Mock
  private IBPService ibpService;
  @InjectMocks
  private AccountsController accountsController;

  String accType = "Personal";
  String cin = "64656";
  String brand = "nwb";
  String brand1= "rbs";

  @Test
  public void shouldGetAccountBalances_NWB(){
    AccountBalanceResponse accountBalanceResponse = new AccountBalanceResponse();
    List<Balance> list = new ArrayList<>();
    Balance balance = new Balance();
    balance.setCurrentBalance(BigDecimal.valueOf(7656));
    balance.setAccountType("Personal");
    balance.setDescription("description");
    balance.setAccountNumber("64564");
    balance.setSortCode("645645");
    balance.setName("Sakshi");
    list.add(balance);
    accountBalanceResponse.setAccountBalances(list);
    Mockito.when(ibpService.getAccountBalances(cin,brand)).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountBalanceResponse));
    ResponseEntity<AccountBalanceResponse> actualResponse = accountsController.getAccountBalances(cin,brand);
    Mockito.verify(ibpService).getAccountBalances(cin,brand);
    Assertions.assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
  }

  @Test
  public void shouldGetAccountBalances_RBS(){
    AccountBalanceResponse accountBalanceResponse = new AccountBalanceResponse();
    List<Balance> list = new ArrayList<>();
    Balance balance = new Balance();
    balance.setCurrentBalance(BigDecimal.valueOf(7656));
    balance.setAccountType("Personal");
    balance.setDescription("description");
    balance.setAccountNumber("64564");
    balance.setSortCode("645645");
    balance.setName("Sakshi");
    list.add(balance);
    accountBalanceResponse.setAccountBalances(list);
    Mockito.when(ibpService.getAccountBalances(cin,brand1)).thenReturn(ResponseEntity.status(HttpStatus.OK).body(accountBalanceResponse));
    ResponseEntity<AccountBalanceResponse> actualResponse = accountsController.getAccountBalances(cin,brand1);
    Mockito.verify(ibpService).getAccountBalances(cin,brand1);
    Assertions.assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
  }
}