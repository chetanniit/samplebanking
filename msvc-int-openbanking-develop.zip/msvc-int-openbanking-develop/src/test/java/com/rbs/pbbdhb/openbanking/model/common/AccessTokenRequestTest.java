package com.rbs.pbbdhb.openbanking.model.common;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AccessTokenRequestTest {

    @Test
    public void testEquals() {
        AccessTokenRequest accessTokenRequest1 = new AccessTokenRequest();
        accessTokenRequest1.setClient_id("75675");
        accessTokenRequest1.setGrant_type("gfgf");
        accessTokenRequest1.setScope("hgchgj");
        accessTokenRequest1.setClient_assertion_type("jhfhg");

        AccessTokenRequest accessTokenRequest2 = new AccessTokenRequest();
        accessTokenRequest2.setClient_id("75675");
        accessTokenRequest2.setGrant_type("gfgf");
        accessTokenRequest2.setScope("hgchgj");
        accessTokenRequest2.setClient_assertion_type("jhfhg");

        Assertions.assertTrue(accessTokenRequest1.equals(accessTokenRequest2));
    }

    @Test
    public void testHashCode() {
        AccessTokenRequest accessTokenRequest1 = new AccessTokenRequest();
        accessTokenRequest1.setClient_id("75675");
        accessTokenRequest1.setGrant_type("gfgf");
        accessTokenRequest1.setScope("hgchgj");
        accessTokenRequest1.setClient_assertion_type("jhfhg");
        Assertions.assertNotEquals(0,accessTokenRequest1.hashCode());
    }

    @Test
    public void testToString() {
        AccessTokenRequest accessTokenRequest1 = new AccessTokenRequest();
        accessTokenRequest1.setClient_id("75675");
        accessTokenRequest1.setGrant_type("gfgf");
        accessTokenRequest1.setScope("hgchgj");
        accessTokenRequest1.setClient_assertion_type("jhfhg");
        Assertions.assertNotNull(accessTokenRequest1.toString());
    }
}