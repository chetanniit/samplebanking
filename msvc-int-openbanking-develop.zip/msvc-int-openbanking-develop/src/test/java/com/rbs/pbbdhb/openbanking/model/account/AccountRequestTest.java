package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class AccountRequestTest {

    @Test
    public void testEquals() {
        AccountRequest accountRequest1 = new AccountRequest();
        AccountRequestData accountRequestData1 = new AccountRequestData();
        accountRequestData1.setConsentId("765");
        accountRequestData1.setExpirationDateTime("13072022");
        accountRequest1.setData(accountRequestData1);
        AccountRequest accountRequest2 = new AccountRequest();
        AccountRequestData accountRequestData2 = new AccountRequestData();
        accountRequestData2.setConsentId("765");
        accountRequestData2.setExpirationDateTime("13072022");
        accountRequest2.setData(accountRequestData2);

        Assertions.assertTrue(accountRequest1.equals(accountRequest2));

    }

    @Test
    public void testHashCode() {
        AccountRequest accountRequest1 = new AccountRequest();
        AccountRequestData accountRequestData1 = new AccountRequestData();
        accountRequestData1.setConsentId("765");
        accountRequestData1.setExpirationDateTime("13072022");
        accountRequest1.setData(accountRequestData1);
        Assertions.assertNotEquals(0,accountRequest1.hashCode());
    }

    @Test
    public void testToString() {
        AccountRequest accountRequest1 = new AccountRequest();
        AccountRequestData accountRequestData1 = new AccountRequestData();
        accountRequestData1.setConsentId("765");
        accountRequestData1.setExpirationDateTime("13072022");
        accountRequest1.setData(accountRequestData1);
        Assertions.assertNotNull(accountRequest1.toString());
    }
}