package com.rbs.pbbdhb.openbanking.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.rbs.pbbdhb.openbanking.config.Constants;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentRequest;
import com.rbs.pbbdhb.openbanking.model.payment.IBPPaymentResponse;
import com.rbs.pbbdhb.openbanking.service.IBPService;

@ExtendWith(MockitoExtension.class)
public class PaymentControllerTest {

  @Mock
  private IBPService ibpService;

  @InjectMocks
  private PaymentController paymentController;

  private String cin = "123093";
  private String NATWEST = "nwb";
  private String RBS = "rbs";
  private String accountNumber = "12345678";

  @Test
  public void returnDomesticPaymentBody_nwb() {
   IBPPaymentRequest ibpPaymentRequest = new IBPPaymentRequest();
   ibpPaymentRequest.setAmount("67565");
   ibpPaymentRequest.setCurrency("GBP");
   ibpPaymentRequest.setDebtorSortCodeAccountNumber("53456");
   IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
   ibpPaymentResponse.setDomesticPaymentId("65454");
   ibpPaymentResponse.setCurrency("GBP");
   ibpPaymentResponse.setAmount("67565");
   ibpPaymentResponse.setTransactionStatus("successful");
   ibpPaymentResponse.setDebtorSortCodeAccountNumber("53456");
   ibpPaymentResponse.setTransactionId("545");
    Mockito.when(ibpService.createDomesticPayment(cin,accountNumber, NATWEST,ibpPaymentRequest, Constants.LUMPSUM)).thenReturn(ResponseEntity.status(HttpStatus.CREATED).body(ibpPaymentResponse));
    ResponseEntity<IBPPaymentResponse> actualResponse = paymentController.createDomesticPayment(cin,accountNumber, NATWEST,Constants.LUMPSUM,ibpPaymentRequest);
    Mockito.verify(ibpService).createDomesticPayment(cin,accountNumber, NATWEST,ibpPaymentRequest, Constants.LUMPSUM);
    Assertions.assertEquals(HttpStatus.CREATED, actualResponse.getStatusCode());
  }
  
  @Test
  public void returnDomesticPaymentBody_nwb_redemptions() {
   IBPPaymentRequest ibpPaymentRequest = new IBPPaymentRequest();
   ibpPaymentRequest.setAmount("67565");
   ibpPaymentRequest.setCurrency("GBP");
   ibpPaymentRequest.setDebtorSortCodeAccountNumber("53456");
   IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
   ibpPaymentResponse.setDomesticPaymentId("65454");
   ibpPaymentResponse.setCurrency("GBP");
   ibpPaymentResponse.setAmount("67565");
   ibpPaymentResponse.setTransactionStatus("successful");
   ibpPaymentResponse.setDebtorSortCodeAccountNumber("53456");
   ibpPaymentResponse.setTransactionId("545");
    Mockito.when(ibpService.createDomesticPayment(cin,accountNumber,NATWEST,ibpPaymentRequest, Constants.REDEMPTIONS)).thenReturn(ResponseEntity.status(HttpStatus.CREATED).body(ibpPaymentResponse));
    ResponseEntity<IBPPaymentResponse> actualResponse = paymentController.createDomesticPayment(cin,accountNumber,NATWEST,Constants.REDEMPTIONS,ibpPaymentRequest);
    Mockito.verify(ibpService).createDomesticPayment(cin,accountNumber,NATWEST,ibpPaymentRequest, Constants.REDEMPTIONS);
    Assertions.assertEquals(HttpStatus.CREATED, actualResponse.getStatusCode());
  }
    @Test
    public void returnDomesticPaymentBody_rbs() {
        IBPPaymentRequest ibpPaymentRequest = new IBPPaymentRequest();
        ibpPaymentRequest.setAmount("67565");
        ibpPaymentRequest.setCurrency("GBP");
        ibpPaymentRequest.setDebtorSortCodeAccountNumber("53456");
        IBPPaymentResponse ibpPaymentResponse = new IBPPaymentResponse();
        ibpPaymentResponse.setDomesticPaymentId("65454");
        ibpPaymentResponse.setCurrency("GBP");
        ibpPaymentResponse.setAmount("67565");
        ibpPaymentResponse.setTransactionStatus("successful");
        ibpPaymentResponse.setDebtorSortCodeAccountNumber("53456");
        ibpPaymentResponse.setTransactionId("545");
        Mockito.when(ibpService.createDomesticPayment(cin,accountNumber,RBS,ibpPaymentRequest,Constants.LUMPSUM)).thenReturn(ResponseEntity.status(HttpStatus.OK).body(ibpPaymentResponse));
        ResponseEntity<IBPPaymentResponse> actualResponse = paymentController.createDomesticPayment(cin,accountNumber,RBS,Constants.LUMPSUM,ibpPaymentRequest);
        Mockito.verify(ibpService).createDomesticPayment(cin,accountNumber,RBS,ibpPaymentRequest,Constants.LUMPSUM);
        Assertions.assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
    }
}