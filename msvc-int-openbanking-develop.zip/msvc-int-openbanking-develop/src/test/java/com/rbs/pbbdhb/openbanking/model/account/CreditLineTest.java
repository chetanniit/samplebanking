package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CreditLineTest {

    @Test
    public void testEquals() {
        CreditLine creditLine1 = new CreditLine();
        Amount amount1 = new Amount();
        amount1.setAmount("656");
        amount1.setCurrency("GBP");
        creditLine1.setAmount(amount1);
        creditLine1.setType("Pre-Agreed");
        creditLine1.setIncluded(true);
        CreditLine creditLine2 = new CreditLine();
        Amount amount2 = new Amount();
        amount2.setAmount("656");
        amount2.setCurrency("GBP");
        creditLine2.setAmount(amount2);
        creditLine2.setType("Pre-Agreed");
        creditLine2.setIncluded(true);

        Assertions.assertTrue(creditLine1.equals(creditLine2));
    }

    @Test
    public void testHashCode() {
        CreditLine creditLine1 = new CreditLine();
        Amount amount1 = new Amount();
        amount1.setAmount("656");
        amount1.setCurrency("GBP");
        creditLine1.setAmount(amount1);
        creditLine1.setType("Pre-Agreed");
        creditLine1.setIncluded(true);
        Assertions.assertNotEquals(0,creditLine1.hashCode());
    }
}