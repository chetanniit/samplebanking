package com.rbs.pbbdhb.openbanking.model.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AmountTest {

    @Test
    public void testEquals() {
        Amount amount1 = new Amount();
        amount1.setAmount("7657");
        amount1.setCurrency("GBP");
        Amount amount2 = new Amount();
        amount2.setAmount("7657");
        amount2.setCurrency("GBP");
        Assertions.assertTrue(amount1.equals(amount2));
    }

    @Test
    public void testHashCode() {
        Amount amount1 = new Amount();
        amount1.setAmount("7657");
        amount1.setCurrency("GBP");
        Assertions.assertNotEquals(0,amount1.hashCode());
    }
}