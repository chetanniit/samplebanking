# Spring Boot MicroService - ui-coord-broker-dashboard

## Brief Overview :

This is UI coord microservice for broker dashboard

## Build the application

```shell script
mvn clean install
```

## Running unit tests

```shell script
mvn clean test
```

## Running all tests

```shell script
mvn clean verify -DskipITs=false
```
## Running the application with the "local" spring profile

```shell script
mvn spring-boot:run
```

## Swagger endpoint (api documentation):

See above for the endpoint URLs for the different environments.

* `.../ui-coord-broker-dashboard/swagger-ui/index.html`

e.g. `http://localhost:8080/mortgages/v1/ui-coord-broker-dashboard/swagger-ui/index.html`

## PCF configuration and deployment

For working with PCF, you need to open your terminal inside the `pcf-config` directory.

Once inside there, you can call either of the following commands, which should explain how they
work.

```bash
# To see PCF commands
./scripts/pcf.sh --help
```

### Deploying a snapshot build

```bash
./scripts/deploy.sh {ENV} - pcf_url={SNAPSHOT_URL}
```

Example: `./scripts/deploy.sh dev - pcf_url=https://artifactory.server.rbsgrp.net/artifactory/pbbdhb-libs-snapshots-local/com/natwest/pbbdhb/ui-coord-consent/0.1.0-SNAPSHOT/ui-coord-consent-0.1.0-20211006.112502-1-dist.jar`

### Deploying a release build

```bash
./scripts/deploy.sh {ENV} {VERSION}
```

Example: `./scripts/deploy.sh dev 0.1.0`

### Deploying latest release build

```bash
./scripts/deploy.sh {ENV} LATEST
```

Example: `./scripts/deploy.sh dev LATEST`