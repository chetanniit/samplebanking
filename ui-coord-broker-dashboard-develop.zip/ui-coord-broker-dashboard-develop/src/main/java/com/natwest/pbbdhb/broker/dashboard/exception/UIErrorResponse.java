package com.natwest.pbbdhb.broker.dashboard.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.http.HttpStatus;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@AllArgsConstructor
@Builder
@Data
public class UIErrorResponse {
    private HttpStatus responseStatus;
    private String responseCode;
    private List<String> errorMessages;
    private String statusCode;
    private String message;
    private String success;
    private String errorCode;
    private String originOfErrorServiceName;

}

