package com.natwest.pbbdhb.broker.dashboard.model.enums;

@SuppressWarnings("PMD.FieldNamingConventions")
public enum Title {
    Mr,
    Mrs,
    None,
    Miss,
    Ms,
    Dr,
    Reverend,
    Professor,
    Sir,
    Lord,
    Lady,
    Captain,
    Major,
    Colonel,
    General,
    Master,
    Hon,
    Mx,
    Sister,
    Viscount,
    Countess,
    Earl,
    Other;
}
