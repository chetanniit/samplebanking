package com.natwest.pbbdhb.broker.dashboard.exception.handler;

public class LogMessageSubtype {

  public static String ERROR_RESPONSE = "ErrorResponse";
}
