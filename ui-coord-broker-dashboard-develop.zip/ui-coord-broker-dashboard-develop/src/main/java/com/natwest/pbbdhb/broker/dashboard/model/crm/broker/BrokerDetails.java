
package com.natwest.pbbdhb.broker.dashboard.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BrokerDetails {

    @JsonProperty("mbs_brokerid")
    private String brokerID;
    @JsonProperty("mbs_username")
    private String userName;
    @JsonProperty("mbs_title")
    private String title;
    @JsonProperty("mbs_brokername")
    private String brokerName;
    @JsonProperty("mbs_firstname")
    private String firstName;
    @JsonProperty("mbs_lastname")
    private String lastName;
    @JsonProperty("mbs_middlename")
    private String middleName;
    @JsonProperty("mbs_emailaddress")
    private String emailAddress;
    @JsonProperty("mbs_mobilenumber")
    private String mobileNumber;
    @JsonProperty("mbs_businessphone")
    private String businessPhone;
    @JsonProperty("mbs_brokerpostcode")
    private String brokerPostcode;

}
