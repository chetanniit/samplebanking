package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class ApplicantNotFoundException extends RuntimeException {

    public ApplicantNotFoundException(String message) {
        super(message);
    }
}