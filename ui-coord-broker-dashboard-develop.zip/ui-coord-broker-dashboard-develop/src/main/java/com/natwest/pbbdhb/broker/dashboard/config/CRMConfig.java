package com.natwest.pbbdhb.broker.dashboard.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Setter
@Getter
public class CRMConfig {
    @Value("${crm.access.token.endpoint}")
    private String crmAccessTokenEndpoint;

    @Value("${crm.jwt.thumbprint}")
    private String thumbprint;

    @Value("${crm.jwt.pwd}")
    private String pwd;

    @Value("${crm.jwt.cert}")
    private String pfxcert;

    @Value("${crm.jwt.aud}")
    private String aud;

    @Value("${crm.jwt.client.id}")
    private String confidentialClientID;

    @Value("${crm.token.grant}")
    private String grant;

    @Value("${crm.token.scope}")
    private String scope;

    @Value("${crm.token.tenant}")
    private String tenant;

    @Value("${crm.token.resource}")
    private String resource;

    @Value("${crm.token.client_assertion_type}")
    private String assertion;

    @Value("${crm.header.xft}")
    private String xftHeader;
}
