package com.natwest.pbbdhb.broker.dashboard.model.tiles;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@Schema(description = "Payment Request")
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequest {

    @NotEmpty
    @Schema(example = "36118429")
    private String mortgageReferenceNumber;

}
