package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CaseDto {

  private String mortgageReferenceNumber;
  private String mortgageTempReferenceNumber;
  private String caseId;
  private String brokerUsername;
  private List<UiApplicant> applicants;
}
