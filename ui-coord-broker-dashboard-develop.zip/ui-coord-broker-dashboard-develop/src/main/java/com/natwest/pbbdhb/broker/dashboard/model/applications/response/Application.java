package com.natwest.pbbdhb.broker.dashboard.model.applications.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode(callSuper = false)
public class Application {
    private String referenceNumber;
    private List<ApplicantInformation> applicantInformation;
    private PropertyInformation propertyInformation;
    private Status status;
}
