package com.natwest.pbbdhb.broker.dashboard.dto;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class SubmittedCase {

  private String caseId;
  private String lastUpdated;
  private String mortgageReferenceNumber;
  private String mortgageTempReferenceNumber;
  private List<ApplicantDto> applicants = new ArrayList<>();

}
