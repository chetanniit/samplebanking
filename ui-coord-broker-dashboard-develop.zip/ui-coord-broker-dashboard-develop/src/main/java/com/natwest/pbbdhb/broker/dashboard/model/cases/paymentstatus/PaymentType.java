package com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus;

public enum PaymentType {

    CARD_PAYMENT,
    CHEQUE,
    DIRECT_DEBIT,
    FEE_MANAGEMENT_SYSTEM,
    INTER_BRANCH_PAYMENT,
    CREDIT_CARD

}
