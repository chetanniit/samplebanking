package com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker;


import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class BrokerAssociations {
    private String userName;
    private List<AssociatedBrokerDetails> associateBrokers;
    private List<AssociatedBrokerDetails> grantedAccessBrokers;
    private List<AssociatedBrokerDetails> dissociateBrokers;
    private List<BrokerAdminDetails> associateBrokerAdmins;
    private List<BrokerAdminDetails> dissociateBrokerAdmins;
}
