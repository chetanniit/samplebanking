package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.PropertyInformation;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;
import java.util.Objects;

@Mapper(config = SpringMapperConfig.class, uses = AddressMapper.class)
public abstract class ApplicationDetailsToPropertyInformationMapper {

    @Mapping(target = "addressInfo", source = "propertyInformation.address")
    @Mapping(target = "propertyType", source = "valuationInformation.propertyType")
    @Mapping(target = "yearOfBuild", source = "valuationInformation.yearBuild")
    @Mapping(target = "valuationType", source = "valuationInformation.details", qualifiedByName =
            "getValuationType")
    @Mapping(target = "confirmValuationAmount", source = "valuationInformation.amount")
    public abstract PropertyInformation toPropertyInformation(ApplicationDetailsResponse applicationDetailsResponse);

    @Named("getValuationType")
    public String getValuationType(List<ValuationHistoryDetail> details) {
        if (Objects.nonNull(details) && !details.isEmpty()) {
            return details.get(0).getTypeDescription();
        }
        return null;
    }
}
