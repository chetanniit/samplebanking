package com.natwest.pbbdhb.broker.dashboard.controller;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.FirmDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.exception.UIErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping("/account-management")
public interface AccountManagementControllerSwagger {

  @Operation(summary = "Change Password")
  @ApiResponses(value = {
  @ApiResponse(responseCode = "204", description = "OK"),
  @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
  @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @PostMapping(path = "/password-change", produces = APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.NO_CONTENT)
  void changePassword(@RequestBody BrokerPasswordRequest request);

  @Operation(summary = "Retrieve security questions")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = BrokerQuestionsResponse.class))),
  @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
  @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @GetMapping(path = "/security-questions", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<BrokerQuestionsResponse> getSecurityQuestions();

  @Operation(summary = "Change security questions")
  @ApiResponses(value = {@ApiResponse(responseCode = "204", description = "No content"),
  @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @PutMapping(path = "/security-questions")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  void changeSecurityQuestions(@RequestBody ChangeSecurityQuestionsRequest request);

  @Operation(summary = "Retrieve broker details")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = BrokerDetailsResponse.class))),
  @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
  @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @GetMapping(path = "/broker-details", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<BrokerDetailsResponse> getBrokerDetails();

  @Operation(summary = "Update broker details")
  @ApiResponses(value = {@ApiResponse(responseCode = "204", description = "OK", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateBrokerDetailsResponse.class))),
  @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @PutMapping(path = "/broker-details")
  ResponseEntity<UpdateBrokerDetailsResponse> updateBrokerDetails(@RequestBody BrokerDetails request);

  @Operation(summary = "Retrieve firm details")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = FirmDetailsResponse.class))),
  @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
  @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
      APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @GetMapping(path = "/firm-details", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<FirmDetailsResponse> getFirmDetails(@RequestParam String fcanumber);

}
