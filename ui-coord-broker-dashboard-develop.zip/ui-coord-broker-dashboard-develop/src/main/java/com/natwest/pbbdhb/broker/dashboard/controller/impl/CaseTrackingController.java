package com.natwest.pbbdhb.broker.dashboard.controller.impl;

import com.natwest.pbbdhb.broker.dashboard.controller.CaseTrackingControllerSwagger;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.PaymentUrlResponse;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseTrackingService;
import com.natwest.pbbdhb.broker.dashboard.service.DocumentsUploadService;
import com.natwest.pbbdhb.broker.dashboard.service.PaymentService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@RestController
@AllArgsConstructor
@Slf4j
public class CaseTrackingController implements CaseTrackingControllerSwagger {

    private CaseTrackingService caseTrackingService;
    private CaseService caseService;
    private PaymentService paymentService;
    private DocumentsUploadService documentsUploadService;

    @Override
    public CaseTrackingResponse applications(String brokerUserName, String brand,
                                             String mortgageRefNumber
            , String lastName, String postcode
            , String pageNumber, String resultsPerPage
    ) {
        log.info("applications: Retrieving applications with broker username: {}.",
            brokerUserName);
        if (isNotBlank(mortgageRefNumber)) {
            log.info("applications: Retrieving applications with "
                + "mortgageRefNumber: {}.", mortgageRefNumber);
            return caseTrackingService.getApplicationByMortgageReference(brokerUserName, mortgageRefNumber, brand);
        }

      CaseTrackingResponse applications = caseTrackingService.getApplications(brokerUserName,
          pageNumber, resultsPerPage, lastName, postcode,
          brand);
      log.info("applications: Applications for user: {}, retrieved successfully.", brokerUserName);
      return applications;
    }

    @Override
    public TrackingApplicationDetailResponse application(String brokerUserName, String mortgageRefNumber,
                                                         String brand) {
        log.info("application: Retrieving application with selected broker"
            + " username: {}.", brokerUserName);
        TrackingApplicationDetailResponse trackingApplicationDetailResponse =
                caseTrackingService.getApplication(brokerUserName, mortgageRefNumber, brand);
        if (Objects.nonNull(trackingApplicationDetailResponse)) {
            caseService.getCaseDetails(mortgageRefNumber, brand, trackingApplicationDetailResponse);
        }
        log.info("application: Application with broker: {},"
            + " successfully retrieved.", brokerUserName);
        return trackingApplicationDetailResponse;
    }

    @Override
    public PaymentUrlResponse getFeePaymentPage(String mortgageRefNumber, String brand) {
        log.info("getFeePaymentPage: Retrieving fee payment page with"
                + " mortgageRefNumber: {}.", mortgageRefNumber);
      PaymentUrlResponse response = paymentService.getFeePaymentPage(mortgageRefNumber, brand);
        log.info("getFeePaymentPage: Fee payment page with mortgageRefNumber: {},"
                + " successfully retrieved.", mortgageRefNumber);
        return response;
    }

    @Override
    public DocumentsUploadURLResponse getDocumentUploadPage(String mortgageRefNumber, String brand) {
        log.info("getDocumentUploadPage: Retrieving document upload page with "
                + "mortgageRefNumber: {}.", mortgageRefNumber);
      DocumentsUploadURLResponse response = documentsUploadService.getDocumentsUploadURL(
          mortgageRefNumber, brand);
        log.info("getDocumentUploadPage: Document upload page with mortgageRefNumber: {} "
                + "successfully retrieved.", mortgageRefNumber);
        return response;
    }
}
