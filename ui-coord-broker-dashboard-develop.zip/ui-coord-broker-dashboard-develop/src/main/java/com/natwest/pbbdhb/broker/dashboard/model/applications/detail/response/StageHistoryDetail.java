/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.broker.dashboard.json.DateSerializer;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.ZonedDateTime;
import java.util.List;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UTC_TIME_ZONE;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class StageHistoryDetail {
    @JsonIgnore private String stage;
    @JsonIgnore private String code;
    private String description;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime timeOpen;

    @JsonDeserialize(using = DateSerializer.Deserialize.class)
    @JsonSerialize(using = DateSerializer.Serialize.class)
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UTC_TIME_ZONE)
    private ZonedDateTime timeClosed;

    private String ragStatus;
    private String ragDescription;
    private String subStatus;
    private String subStatusDescription;
    private List<CaseHistoryDetail> caseHistory;
    private List<RequiredActionDetail> requiredActions;
}
