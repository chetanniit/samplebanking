package com.natwest.pbbdhb.broker.dashboard.exception.handler;

import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes.NO_ACCESS_TO_BROKER;
import static com.natwest.pbbdhb.broker.dashboard.exception.handler.EventLogger.logException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicationsServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.AssociatedBrokerNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.CaseNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangePasswordException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangeSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.exception.CrmServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.DocumentDownloadException;
import com.natwest.pbbdhb.broker.dashboard.exception.FeePaymentIntegrationException;
import com.natwest.pbbdhb.broker.dashboard.exception.HttpCustomException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveFirmDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.exception.SessionTokenFetchFailureException;
import com.natwest.pbbdhb.broker.dashboard.exception.UIErrorResponse;
import com.natwest.pbbdhb.broker.dashboard.exception.UpdateBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

  private static final String ERROR_SOURCE = "DASHBOARD";
  private static final String SOMETHING_WENT_WRONG_IN_UNDERLYING_SERVICE =
      "Something went wrong in underlying " +
          "service";
  private static final String CORRECT_PERMISSIONS_MESSAGE =
      "You do not have permission to view this case. Please " +
          "ensure correct permissions are granted via case access management";
  private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
  private static final String USER_NOT_FOUND = "USER_NOT_FOUND";

  @Autowired
  ObjectMapper objectMapper;

  @ExceptionHandler({ApplicantServiceException.class, ApplicationsServiceException.class,
      DocumentDownloadException.class, FeePaymentIntegrationException.class, IntegrationException.class,
      SessionTokenFetchFailureException.class})
  @ResponseBody
  public ResponseEntity<UIErrorResponse> handleCustomException(Exception customException) throws
      JsonProcessingException {

    String errorSource = setErrorSource(customException);

    Exception ex = ((HttpCustomException) customException).getException();

    log.error("In handleCustomException, message: {}", ex.getMessage());

    if (ex instanceof HttpClientErrorException
        && !(ex instanceof HttpClientErrorException.Unauthorized)) {

      log.error("HttpClientErrorException message: {}", ex.getMessage());
      HttpClientErrorException httpClientErrorException = (HttpClientErrorException) ex;

      ResponseEntity<UIErrorResponse> notFoundResponse = buildNotFoundResponse(
          httpClientErrorException);
      if (notFoundResponse != null) {
        return notFoundResponse;
      }

      UIErrorResponse trackingServiceUIErrorResponse =
          objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(),
              UIErrorResponse.class);
      trackingServiceUIErrorResponse.setErrorCode(
          String.valueOf(httpClientErrorException.getRawStatusCode()));
      trackingServiceUIErrorResponse.setOriginOfErrorServiceName(errorSource);

      if (ex instanceof HttpClientErrorException.Forbidden) {
        HttpClientErrorException.Forbidden forbiddenException = (HttpClientErrorException.Forbidden) ex;
        String responseCode = trackingServiceUIErrorResponse.getResponseCode();
        buildHttpClientExceptionLog(forbiddenException);
        if (StringUtils.isNotBlank(responseCode) && responseCode.contains("403")) {
          log.error("HttpClientErrorException Forbidden from tracking service");
          UIErrorResponse uiErrorResponse =
              UIErrorResponse.builder().errorCode(HttpStatus.BAD_REQUEST.toString())
                  .errorMessages(Arrays.asList(CORRECT_PERMISSIONS_MESSAGE)).build();
          return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(uiErrorResponse);
        }
      }

      buildHttpClientExceptionLog(httpClientErrorException);
      buildErrorMessagesForResponse(trackingServiceUIErrorResponse);

      return ResponseEntity.status(httpClientErrorException.getStatusCode())
          .body(trackingServiceUIErrorResponse);
    }
    if (ex instanceof HttpClientErrorException.Unauthorized) {
      log.error("HttpClientErrorException.Unauthorized message: {}", ex.getMessage());
      log.error("HttpClientErrorException.Unauthorized cause: {}", ex.getCause());
      if (ex.getCause() != null) {
        log.error("HttpClientErrorException.Unauthorized cause.getCause : {}",
            ex.getCause().getCause());
      }
      HttpClientErrorException.Unauthorized unauthorizedException = (HttpClientErrorException.Unauthorized) ex;
      buildHttpClientExceptionLog(unauthorizedException);
      HttpStatusCode httpStatus = unauthorizedException.getStatusCode();
      return ResponseEntity.status(httpStatus).body(UIErrorResponse.builder()
          .errorCode(String.valueOf(httpStatus.value()))
          .errorMessages(Lists.newArrayList(ex.getMessage()))
          .originOfErrorServiceName(errorSource)
          .build());
    }

    if (ex instanceof HttpServerErrorException) {
      log.error("HttpServerErrorException message: {}", ex.getMessage());
      HttpServerErrorException httpServerErrorException = (HttpServerErrorException) ex;
      buildHttpClientExceptionLog(httpServerErrorException);
      HttpStatusCode httpStatus = httpServerErrorException.getStatusCode();
      return ResponseEntity.status(httpStatus).body(UIErrorResponse.builder()
          .errorCode(String.valueOf(httpStatus.value()))
          .errorMessages(Lists.newArrayList(SOMETHING_WENT_WRONG_IN_UNDERLYING_SERVICE))
          .originOfErrorServiceName(errorSource)
          .build());
    }

    if (ex instanceof HttpMessageNotReadableException) {
      log.error("HttpMessageNotReadableException message: {}", ex.getMessage());
      HttpMessageNotReadableException httpMessageNotReadableException = (HttpMessageNotReadableException) ex;
      ErrorResponse errorResponse = buildCustomErrorLog(HttpStatus.BAD_REQUEST.value(),
          "HTTP Message Not " +
              "Readable", "HTTP Message " +
              "Not Readable");
      logException(httpMessageNotReadableException, errorResponse);
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
          .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
          .errorMessages(Lists.newArrayList(SOMETHING_WENT_WRONG_IN_UNDERLYING_SERVICE))
          .originOfErrorServiceName(errorSource)
          .build());
    }

    buildCustomErrorLog(HttpStatus.INTERNAL_SERVER_ERROR.value(), customException.getMessage(),
        ((HttpCustomException) customException).getException().getMessage());
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(UIErrorResponse.builder()
        .errorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()))
        .errorMessages(Lists.newArrayList(SOMETHING_WENT_WRONG_IN_UNDERLYING_SERVICE))
        .originOfErrorServiceName(errorSource)
        .build());
  }

  private void buildErrorMessagesForResponse(UIErrorResponse trackingServiceUIErrorResponse) {
    if (CollectionUtils.isEmpty(trackingServiceUIErrorResponse.getErrorMessages())) {
      trackingServiceUIErrorResponse.setErrorMessages(
          Lists.newArrayList(trackingServiceUIErrorResponse.getMessage()));
    } else {
      List messagesToDisplay = trackingServiceUIErrorResponse.getErrorMessages().stream()
          .filter(e -> e.contains(":"))
          .map(s -> s.split(":")[1])
          .collect(Collectors.toList());
      if (!CollectionUtils.isEmpty(messagesToDisplay)) {
        trackingServiceUIErrorResponse.setErrorMessages(messagesToDisplay);
      }
    }
  }

  @ExceptionHandler({RuntimeException.class, CaseNotFoundException.class,
      MRNValidateFailureException.class})
  @ResponseBody
  public ResponseEntity<UIErrorResponse> handleRuntimeException(RuntimeException ex) {
    if (ex instanceof MRNValidateFailureException || ex instanceof SessionTokenFetchFailureException
        || ex instanceof CaseNotFoundException) {
      logException(ex,
          buildCustomErrorLog(HttpStatus.BAD_REQUEST.value(), ex.getMessage(), ex.getMessage()));
      ResponseEntity<UIErrorResponse> body =
          ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
              .errorCode(HttpStatus.BAD_REQUEST.toString())
              .errorMessages(Lists.newArrayList(ex.getMessage()))
              .originOfErrorServiceName(setErrorSource(ex))
              .build());
      return body;
    }
    ResponseEntity<UIErrorResponse> notFoundResponse = buildNotFoundResponse(ex);
    if (notFoundResponse != null) {
      return notFoundResponse;
    }
    String errorMessage = ex.getMessage();
    logException(ex,
        buildCustomErrorLog(HttpStatus.INTERNAL_SERVER_ERROR.value(), errorMessage, errorMessage));
    HttpStatus responseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
    ResponseEntity<UIErrorResponse> body = ResponseEntity.status(responseStatus)
        .body(UIErrorResponse.builder()
            .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
            .errorMessages(Lists.newArrayList(errorMessage))
            .build());
    log.error("Unexpected exception occurred", ex);
    return body;
  }

  @ExceptionHandler(ChangePasswordException.class)
  private ResponseEntity<UIErrorResponse> handleResetPasswordException(
      ChangePasswordException ex) {
    switch (ex.getCode()) {
      case USER_NOT_FOUND:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(ErrorCodes.USER_NOT_FOUND.toString())
            .message("The username can not be found")
            .build());
      case INVALID_DETAILS:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(ErrorCodes.INVALID_DETAILS.toString())
            .message("The credentials entered are invalid.")
            .build());
      case ACCOUNT_LOCKED:
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(UIErrorResponse.builder()
            .errorCode(ErrorCodes.ACCOUNT_LOCKED.toString())
            .message("Account is locked, please try again later.")
            .build());
      default:
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(UIErrorResponse.builder()
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
                .message("Our backend is non-functional, please try again later.")
                .build());
    }
  }

  @ExceptionHandler(CrmServiceException.class)
  private ResponseEntity<UIErrorResponse> handleCrmServiceException(
      CrmServiceException ex) {
    switch (ex.getCode()) {
      case INTERNAL_SERVER_ERROR:
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(UIErrorResponse.builder()
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
                .errorMessages(Collections.singletonList(INTERNAL_SERVER_ERROR))
                .build());
      default:
        return null;
    }
  }

  @ExceptionHandler(RetrieveSecurityQuestionsException.class)
  private ResponseEntity<UIErrorResponse> handleRetrieveSecurityQuestionsException(
      RetrieveSecurityQuestionsException ex) {
    switch (ex.getCode()) {
      case ACCOUNT_LOCKED:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList("ACCOUNT_LOCKED"))
            .build());
      case USER_NOT_FOUND:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList(USER_NOT_FOUND))
            .build());
      case MEMORABLE_QUESTIONS_LOCKED:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList("MEMORABLE_QUESTIONS_LOCKED"))
            .build());
      case INTERNAL_SERVER_ERROR:
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(UIErrorResponse.builder()
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
                .errorMessages(Collections.singletonList(INTERNAL_SERVER_ERROR))
                .build());
      default:
        return null;
    }
  }

  @ExceptionHandler(RetrieveBrokerDetailsException.class)
  private ResponseEntity<UIErrorResponse> handleRetrieveBrokerDetailsException(
      RetrieveBrokerDetailsException ex) {
    switch (ex.getCode()) {
      case USER_NOT_FOUND:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList(USER_NOT_FOUND))
            .build());
      case INTERNAL_SERVER_ERROR:
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(UIErrorResponse.builder()
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
                .errorMessages(Collections.singletonList(INTERNAL_SERVER_ERROR))
                .build());
      default:
        return null;
    }
  }

  @ExceptionHandler(UpdateBrokerDetailsException.class)
  private ResponseEntity<UIErrorResponse> handleUpdateBrokerDetailsException(
      UpdateBrokerDetailsException ex) {
    switch (ex.getCode()) {
      case USER_NOT_FOUND:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList(USER_NOT_FOUND))
            .build());
      case INTERNAL_SERVER_ERROR:
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(UIErrorResponse.builder()
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
                .errorMessages(Collections.singletonList(INTERNAL_SERVER_ERROR))
                .build());
      default:
        return null;
    }
  }

  @ExceptionHandler(RetrieveFirmDetailsException.class)
  private ResponseEntity<UIErrorResponse> handleRetrieveFirmDetailsException(
      RetrieveFirmDetailsException ex) {
    switch (ex.getCode()) {
      case USER_NOT_FOUND:
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList(USER_NOT_FOUND))
            .build());
      case INTERNAL_SERVER_ERROR:
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(UIErrorResponse.builder()
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
                .errorMessages(Collections.singletonList(INTERNAL_SERVER_ERROR))
                .build());
      default:
        return null;
    }
  }

  @ExceptionHandler(AssociatedBrokerNotFoundException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  private ResponseEntity<UIErrorResponse> handleAssociatedBrokerNotFoundException(
      AssociatedBrokerNotFoundException ex) {

    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
        .errorCode(NO_ACCESS_TO_BROKER.name())
        .errorMessages(Lists.newArrayList(ex.getMessage()))
        .originOfErrorServiceName(setErrorSource(ex))
        .build());

  }

  @ExceptionHandler(ChangeSecurityQuestionsException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  private ResponseEntity<UIErrorResponse> handleChangeSecurityQuestionsException(
      ChangeSecurityQuestionsException ex) {

    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(UIErrorResponse.builder()
        .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString())
        .errorMessages(Collections.singletonList(INTERNAL_SERVER_ERROR))
        .build());
  }

  @ExceptionHandler(PermissionDeniedException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<UIErrorResponse> handlePermissionDenied(PermissionDeniedException ex) {
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(Collections.singletonList(ex.getDescription()))
            .build());
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<UIErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
    logException(ex,
            buildCustomErrorLog(HttpStatus.BAD_REQUEST.value(), ex.getMessage(), ex.getMessage()));
    List<String> violations = new ArrayList<>();
    if (!CollectionUtils.isEmpty(ex.getFieldErrors())) {
      violations = ex.getFieldErrors().stream().map(fe -> fe.getField() + " : " + fe.getDefaultMessage()).
              collect(Collectors.toList());
    }
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(UIErrorResponse.builder()
            .errorCode(HttpStatus.BAD_REQUEST.toString())
            .errorMessages(violations)
            .build());
  }

  private ResponseEntity<UIErrorResponse> buildNotFoundResponse(RuntimeException ex) {
    if (ex instanceof HttpStatusCodeException) {
      HttpStatusCodeException httpStatusCodeException = (HttpStatusCodeException) ex;
      if (HttpStatus.NOT_FOUND.equals(httpStatusCodeException.getStatusCode())) {
        buildHttpClientExceptionLog((HttpStatusCodeException) ex);
        ResponseEntity<UIErrorResponse> body =
            ResponseEntity.status(HttpStatus.NOT_FOUND).body(UIErrorResponse.builder()
                .errorCode(HttpStatus.NOT_FOUND.toString())
                .errorMessages(Lists.newArrayList(ex.getMessage()))
                .originOfErrorServiceName(setErrorSource(ex))
                .build());
        return body;
      }
    }
    return null;
  }

  private ErrorResponse buildHttpClientExceptionLog(HttpStatusCodeException exception) {
    ErrorResponse error = buildErrorResponse(exception);
    logError(exception, error);
    return error;
  }

  protected ErrorResponse buildErrorResponse(HttpStatusCodeException exception) {
    return ErrorResponse.builder()
        .status(exception.getStatusCode().value())
        .title(exception.getStatusText())
        .description(
            exception.getResponseBodyAsString() != null ? exception.getResponseBodyAsString()
                : "An " +
                    "unknown error occurred")
        .build();
  }

  // logs errors in a consistent format for application error monitoring tools
  private void logError(Throwable ex, ErrorResponse error) {
    // log the entire stack trace for detailed debugging
    log.error(ex.getMessage(), ex);
    // log errors using our common reporting format
    logException(ex, error);
  }

  private ErrorResponse buildCustomErrorLog(int status, String title, String description) {
    ErrorResponse errorResponse = ErrorResponse.builder()
        .status(status)
        .title(title)
        .description(description)
        .build();
    return errorResponse;
  }

  private String setErrorSource(Exception exception) {
    if (exception instanceof ApplicantServiceException) {
      return "APPLICANT";
    } else if (exception instanceof ApplicationsServiceException) {
      return "APPLICATION_TRACKING";
    } else if (exception instanceof MRNValidateFailureException
        || exception instanceof CaseNotFoundException) {
      return "MSVC_CASE";
    } else if (exception instanceof SessionTokenFetchFailureException) {
      return "DOCUMENT_UPLOAD_INTEGRATION";
    } else if (exception instanceof FeePaymentIntegrationException) {
      return "FEE_PAYMENT_INTEGRATION";
    } else if (exception instanceof DocumentDownloadException) {
      return "SALES_ESIS_INTEGRATION";
    } else {
      return ERROR_SOURCE;
    }
  }
}
