package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.ApplicantInformation;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.UiApplicantInformation;
import com.natwest.pbbdhb.broker.dashboard.util.AppUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = SpringMapperConfig.class)
public interface ApplicantInformationToUiApplicantInformationMapper {

    @Mapping(target = "isMainApplicant", source = "isMainApplicant", qualifiedByName = "getIsMainApplicant")
    UiApplicantInformation toApplicantInformation(ApplicantInformation applicantInformation);

    @Named("getIsMainApplicant")
    default Boolean getIsMainApplicant(String isMainApplicant) {
        return AppUtil.getIsMainApplicant(isMainApplicant);
    }
}
