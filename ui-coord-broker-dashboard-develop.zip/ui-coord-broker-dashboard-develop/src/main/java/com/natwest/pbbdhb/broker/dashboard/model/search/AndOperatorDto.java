package com.natwest.pbbdhb.broker.dashboard.model.search;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

import static com.natwest.pbbdhb.broker.dashboard.model.search.OperatorDto.OperatorType.AND;

@Setter
@Getter
@Builder
public class AndOperatorDto extends OperatorDto {
    private List<OperatorDto> operators;

    @Override
    public OperatorType getType() {
        return AND;
    }
}
