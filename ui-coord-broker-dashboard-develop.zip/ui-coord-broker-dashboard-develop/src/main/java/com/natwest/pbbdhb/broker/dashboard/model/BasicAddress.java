package com.natwest.pbbdhb.broker.dashboard.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BasicAddress {

    private String postcode;

}

