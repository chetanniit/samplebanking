package com.natwest.pbbdhb.broker.dashboard.model.search;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FieldsDto {
}
