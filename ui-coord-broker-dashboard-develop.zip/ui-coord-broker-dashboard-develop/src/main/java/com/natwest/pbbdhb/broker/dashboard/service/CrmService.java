package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;

public interface CrmService {

  BrokerCoreResponse getBrokerDetails(String username);

  AdminCoreResponse getAdminDetails(String username);

  BrokerAssociationsResponse getBrokerAssociations(String username);

  BrokerAssociationsResponse getBrokerUnAssociations(String username);

  AdminAssociationsResponse getAdminAssociations(String username);

  BrokerPermissionsResponse associateBrokerToBroker(String username, String brokerToAssociate);

  BrokerPermissionsResponse unAssociateBrokerToBroker(String username, String brokerToUnAssociate);

  BrokerPermissionsResponse associateBrokerToAdmin(String username, String adminToAssociate);

  BrokerPermissionsResponse unAssociateBrokerToAdmin(String username, String adminToUnAssociate);

}
