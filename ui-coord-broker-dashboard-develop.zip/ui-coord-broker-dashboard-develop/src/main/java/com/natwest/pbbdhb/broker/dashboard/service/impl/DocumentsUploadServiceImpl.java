package com.natwest.pbbdhb.broker.dashboard.service.impl;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.broker.dashboard.authorisation.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.broker.dashboard.service.ApplicantService;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAccessService;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAuthTokenService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.DocumentsUploadService;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Service
@Slf4j
public class DocumentsUploadServiceImpl implements DocumentsUploadService {

    private CaseService caseService;
    private ApplicantService applicantService;
    private BrokerAuthTokenService brokerAuthTokenService;
    private String documentUploadURL;
    private UserClaimsProvider userClaimsProvider;
    private AccessPermissionChecker accessPermissionChecker;
    private final BrokerAccessService brokerAccessService;

    public DocumentsUploadServiceImpl(@Value("${spa.document.upload.url}") String documentUploadURL,
                                      CaseService caseService,
                                      ApplicantService applicantService,
                                      BrokerAuthTokenService brokerAuthTokenService,
                                      UserClaimsProvider userClaimsProvider,
                                      AccessPermissionChecker accessPermissionChecker,
        BrokerAccessService brokerAccessService) {
        this.caseService = caseService;
        this.applicantService = applicantService;
        this.brokerAuthTokenService = brokerAuthTokenService;
        this.documentUploadURL = documentUploadURL;
        this.userClaimsProvider = userClaimsProvider;
        this.accessPermissionChecker = accessPermissionChecker;
        this.brokerAccessService = brokerAccessService;
    }

    @Override
    public DocumentsUploadURLResponse getDocumentsUploadURL(String mortgageReferenceNumber, String brand) {
        log.debug("getDocumentsUploadURL: Retrieving documents upload URL with "
                + "mortgageReferenceNumber: {} and brand: {}."
                , mortgageReferenceNumber, brand);
        try {
            String username = userClaimsProvider.getBrokerUsername();
            CaseApplication caseData = searchCaseByMrn(mortgageReferenceNumber, brand);
            String caseId = caseData.getCaseId();
            String caseOwnerUsername = caseData.getBroker().getBrokerUsername();

            boolean requestedBrokerIsAccessible = brokerAccessService.checkRequestedBrokerHasAccess(caseOwnerUsername);
            if (!requestedBrokerIsAccessible) {
                log.error("Error in getDocumentsUploadURL for caseId {} and brokerUsername {} : {}",
                        caseId, userClaimsProvider.getBrokerUsername(), MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION);
                throw new PermissionDeniedException(MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION);
            }

            Set<String> caseIds = Collections.singleton(caseId);
            List<Applicant> applicants = applicantService.getApplicants(caseIds, brand);
            Applicant mainApplicant = applicants.get(0);

            String sessionToken = brokerAuthTokenService.getSessionAuthToken(caseId, mortgageReferenceNumber,
                    username,
                    mainApplicant, brand);

            log.debug("getDocumentsUploadURL: Documents upload URL for"
                    + " mortgageReferenceNumber: {}, brand: {} and broker username: {}"
                    + " - Retrieved successfully.", mortgageReferenceNumber, brand, username);

            return DocumentsUploadURLResponse.builder().documentUploadURL(String.format(documentUploadURL,
                    sessionToken)).build();

        } catch (JsonProcessingException e) {
            log.error("getDocumentsUploadURL: Unable to convert Broker entity to string");
        }
        return DocumentsUploadURLResponse.builder().documentUploadURL(StringUtils.EMPTY).build();
    }

    private CaseApplication searchCaseByMrn(String mortgageRefNumber, String brand) throws JsonProcessingException {
      log.debug("getCaseId: Retrieving caseId for mortgageRefNumber: {} and brand: {}.",
          mortgageRefNumber, brand);
      CaseSearchResponse response = caseService.getCaseSearchByMortgageRefNumber(mortgageRefNumber, brand);
      if (response == null || response.getContent() == null || response.getContent().isEmpty() || ObjectUtils.isEmpty(response.getContent().get(0))) {
        log.debug("getCaseId: No case record returned for mortgageReferenceNumber: {}"
            + " and brand: {}.", mortgageRefNumber, brand);
        throw new MRNValidateFailureException("getCaseId: Invalid mortgageRefNumber: "
            + mortgageRefNumber);
      }
      log.debug("getCaseId: Case with mortgageReferenceNumber: {} and brand: {} - retrieved successfully.",
          mortgageRefNumber, brand);
      return response.getContent().get(0);
    }

}
