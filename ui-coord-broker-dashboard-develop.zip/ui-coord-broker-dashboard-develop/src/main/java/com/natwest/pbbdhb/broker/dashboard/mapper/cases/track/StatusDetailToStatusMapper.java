package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.StatusDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Status;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_FORMAT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT;

@Mapper(config = SpringMapperConfig.class)
public interface StatusDetailToStatusMapper {

    @Mapping(target = "submissionDate", source = "submissionDate", dateFormat = DATE_FORMAT)
    @Mapping(target = "lastUpdatedDate", source = "lastUpdatedDate", dateFormat = DATE_TIME_FORMAT)
    Status toStatus(StatusDetail statusDetail);
}
