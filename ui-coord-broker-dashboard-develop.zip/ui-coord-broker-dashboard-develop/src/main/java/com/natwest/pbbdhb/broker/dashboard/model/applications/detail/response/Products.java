/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/** this class containing Product information used in applicationInformation endPoint */
@Setter
@Getter
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Builder
public class Products {
    private String code;
    private String desc;
    private String altDesc;
    private BigDecimal rate;
    private String termYears;
    private String termMonths;
    private BigDecimal repaymentAmount;
    private BigDecimal loanAmount;
    private String repaymentType;
}
