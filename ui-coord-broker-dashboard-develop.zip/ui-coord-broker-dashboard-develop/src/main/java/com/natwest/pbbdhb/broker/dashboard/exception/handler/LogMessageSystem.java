package com.natwest.pbbdhb.broker.dashboard.exception.handler;

public class LogMessageSystem {

    public static String NAPOLI = "Napoli";
}
