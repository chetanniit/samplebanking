package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class ApplicationsServiceException extends HttpCustomException {

    public ApplicationsServiceException(Exception exception) {
        super(exception);
    }

}