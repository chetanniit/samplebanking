package com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
@Builder
public class Fee {
    private FeeCode feeCode;
    private FeeAction feeAction;
    private BigDecimal feeAmount;
    private PaymentType feePaymentType;
    private String type;
    private Boolean isPaymentMade;
    private String orderId;
    private String paidDate;
}
