package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class FeePaymentIntegrationException extends HttpCustomException {

    public FeePaymentIntegrationException(Exception exception) {
        super(exception);
    }
}