package com.natwest.pbbdhb.broker.dashboard.mapper.crm;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.AdminCoreResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = SpringMapperConfig.class)
public interface AdminCoreResponseToDtoMapper {

    @Mapping(constant = "ADMIN", target = "userType")
    @Mapping(source = "brokerAdminName", target = "fullName")
    BrokerDetailsDto toDto(AdminCoreResponse adminCoreResponse);
}
