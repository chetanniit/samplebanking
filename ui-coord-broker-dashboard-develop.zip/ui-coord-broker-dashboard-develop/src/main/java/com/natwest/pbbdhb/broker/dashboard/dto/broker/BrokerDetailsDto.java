package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerDetailsDto {
    private String userName;
    private String fullName;
    private String firstName;
    private String lastName;
    private UserType userType;
    private String emailAddress;
    private AccessStatus accessStatus;
    private String fcaNumber;
    private String principalFCANumber;
}
