package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;

public interface BrokerAuthTokenService {
    String getSessionAuthToken(String caseId, String mortgageReferenceNumber, String broker, Applicant mainApplicant,
                               String brand);
}
