package com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus;

public enum PaymentStatus {
    AUTHORISED,
    CANCELLED,
    UNKNOWN
}
