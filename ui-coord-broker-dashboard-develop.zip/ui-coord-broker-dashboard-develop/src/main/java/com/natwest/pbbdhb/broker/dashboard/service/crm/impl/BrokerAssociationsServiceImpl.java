package com.natwest.pbbdhb.broker.dashboard.service.crm.impl;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAdminDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociations;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerAssociationsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BrokerAssociationsServiceImpl implements BrokerAssociationsService {

    private final CrmService crmService;
    private final UserClaimsProvider userClaimsProvider;

    @Override
    public BrokerAssociations getAssociations(String firstName, String lastName, AccessStatus accessStatus) {

        String loggedInUserName = userClaimsProvider.getBrokerUsername();
        BrokerType brokerType = userClaimsProvider.getBrokerType();

        if (BrokerType.BROKER.equals(brokerType)) {
          log.debug("getAssociations: Retrieving associations for broker: {}.",
              loggedInUserName);
            return getBrokerAssociations(loggedInUserName, firstName, lastName, accessStatus);
        }

        log.debug("getAssociations: Retrieving associations for admin: {}.",
            loggedInUserName);
        return getAdminAssociation(loggedInUserName, firstName, lastName, accessStatus);

    }

    public void mapLoggedInAdminAssociations(AssociationsDto associationsDto) {
        BrokerType brokerType = userClaimsProvider.getBrokerType();

        if (BrokerType.ADMIN.equals(brokerType) && !CollectionUtils.isEmpty(associationsDto.getBrokers())) {
          log.debug("mapLoggedInAdminAssociations: Mapping admin associations for {}.",
              userClaimsProvider.getBrokerUsername());
            modifyAccessTypeToAccessGranted(associationsDto);
        }
    }

    private void modifyAccessTypeToAccessGranted(AssociationsDto associationsDto) {
      log.debug("modifyAccessTypeToAccessGranted: Modifying access type of {} to access granted.",
          userClaimsProvider.getBrokerUsername());
        associationsDto.getBrokers().stream()
                .forEach(brokerDetail -> brokerDetail.setAccessStatus(AccessStatus.ACCESS_GRANTED));
    }

    private BrokerAssociations getBrokerAssociations(String userName, String firstName, String lastName,
                                                     AccessStatus accessStatus) {
        log.debug("getBrokerAssociations: Retrieving broker associations of userName: {},"
                + " firstName: {}, lastName: {}.",
            userName, firstName, lastName);
        BrokerAssociations associations = BrokerAssociations.builder().build();

        if (Objects.isNull(accessStatus) || AccessStatus.ASSOCIATED.equals(accessStatus)) {
            log.debug("getBrokerAssociations: Retrieving broker associations "
                + "of userName: {}, firstName: {}, lastName: {}, where accessStatus is: {}.",
                userName, firstName, lastName, accessStatus);
            BrokerAssociationsResponse brokerAssociations =
                    crmService.getBrokerAssociations(userName);
            List<AssociatedBrokerDetails> brokers = filterBrokerResults(brokerAssociations.getBrokers(),
                    firstName, lastName);
            List<BrokerAdminDetails> admins = filterAdminResults(brokerAssociations.getAdmins(),
                    firstName, lastName);
            associations.setAssociateBrokers(brokers);
            associations.setAssociateBrokerAdmins(admins);
        }
        if (Objects.isNull(accessStatus) || AccessStatus.DISASSOCIATED.equals(accessStatus)) {
          log.debug("getBrokerAssociations: Retrieving broker associations "
              + "of userName: {}, firstName: {}, lastName: {}, where accessStatus is: {}.",
              userName, firstName, lastName, accessStatus);
            BrokerAssociationsResponse brokerUnAssociations =
                    crmService.getBrokerUnAssociations(userName);
            List<AssociatedBrokerDetails> brokers = filterBrokerResults(brokerUnAssociations.getBrokers(),
                    firstName, lastName);
            List<BrokerAdminDetails> admins = filterAdminResults(brokerUnAssociations.getAdmins(),
                    firstName, lastName);
            associations.setDissociateBrokers(brokers);
            associations.setDissociateBrokerAdmins(admins);
        }
        if (Objects.isNull(accessStatus) || AccessStatus.ACCESS_GRANTED.equals(accessStatus)) {
          log.debug("getBrokerAssociations: Retrieving broker associations "
              + "of userName: {}, firstName: {}, lastName: {}, where accessStatus is: {}.",
              userName, firstName, lastName, accessStatus);
            BrokerAssociationsResponse brokerAssociations =
                    crmService.getBrokerAssociations(userName);
            List<AssociatedBrokerDetails> brokers =
                    filterBrokerResults(brokerAssociations.getGrantedPermissionBrokers(),
                            firstName, lastName);
            associations.setGrantedAccessBrokers(brokers);
        }
        log.debug("getBrokerAssociations: Broker associations of userName: {}, "
                + "firstName: {},lastName: {}, successfully retrieved.",
            userName, firstName, lastName);
        return associations;
    }

    private BrokerAssociations getAdminAssociation(String userName, String firstName,
                                                   String lastName, AccessStatus accessStatus) {

        if (AccessStatus.ACCESS_GRANTED.equals(accessStatus)) {
            accessStatus = AccessStatus.ASSOCIATED;
        }
        if (Objects.nonNull(accessStatus) && !AccessStatus.ASSOCIATED.equals(accessStatus)) {
            return BrokerAssociations.builder().build();
        }

        log.debug("getAdminAssociation: Retrieving admin association of userName: {},"
                + " firstName: {},lastName: {}.", userName, firstName, lastName);
        AdminAssociationsResponse adminAssociations = crmService.getAdminAssociations(userName);

        List<AssociatedBrokerDetails> brokers = filterBrokerResults(adminAssociations.getBrokers(),
                firstName, lastName);
        log.debug("getAdminAssociation: Admin association of userName: {},"
                + " firstName: {}, lastName: {}, successfully retrieved.",
            userName, firstName, lastName);
        return BrokerAssociations.builder().associateBrokers(brokers).build();
    }

    private List<AssociatedBrokerDetails> filterBrokerResults(List<AssociatedBrokerDetails> brokers,
                                                              String firstName, String lastName) {

        log.debug("filterBrokerResults: Filtering broker results for firstName: {},"
            + " lastName: {}.", firstName, lastName);
        return brokers.stream()
                .filter(broker -> Objects.isNull(firstName) || firstName.equalsIgnoreCase(broker.getFirstName()))
                .filter(broker -> Objects.isNull(lastName) || lastName.equalsIgnoreCase(broker.getLastName()))
                .collect(Collectors.toList());
    }

    private List<BrokerAdminDetails> filterAdminResults(List<BrokerAdminDetails> admins,
                                                        String firstName, String lastName) {

        log.debug("filterAdminResults: Filtering admin results for firstName: {},"
            + " lastName: {}.", firstName, lastName);
        return admins.stream()
                .filter(admin -> Objects.isNull(firstName) || firstName.equalsIgnoreCase(admin.getFirstName()))
                .filter(admin -> Objects.isNull(lastName) || lastName.equalsIgnoreCase(admin.getLastName()))
                .collect(Collectors.toList());
    }
}
