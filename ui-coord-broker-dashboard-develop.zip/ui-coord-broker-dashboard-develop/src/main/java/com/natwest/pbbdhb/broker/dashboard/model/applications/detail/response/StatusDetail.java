/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.ZonedDateTime;
import java.util.Date;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_FORMAT_YYYYMMDD;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UK_TIME_ZONE;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class StatusDetail {

    private String submissionDate;
    private String lastUpdatedDate;
    private String status;
    private String statusDescription;
    private String ragStatus;
    private String ragDescription;
    private String subStatus;
    private String subStatusDescription;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date expectedCompletionDate;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date completionDate;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date declinedDate;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date refusedDate;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_TIME_FORMAT,
            timezone = UK_TIME_ZONE)
    private ZonedDateTime offerIssueDate;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date expectedEffectiveDate;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date actualEffectiveDate;

    private ZonedDateTime cotReceivedDate;
    private ZonedDateTime cotAssessDate;

    private ZonedDateTime cotAcceptedDate;
}
