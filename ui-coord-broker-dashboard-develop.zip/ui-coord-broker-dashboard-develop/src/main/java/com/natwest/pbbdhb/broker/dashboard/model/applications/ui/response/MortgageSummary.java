package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Date;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_FORMAT_YYYYMMDD;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UK_TIME_ZONE;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MortgageSummary {
    private String mortgageReferenceNumber;
    private String applicationStatus;
    private LocalDateTime latestOfferDate;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = DATE_FORMAT_YYYYMMDD,
            timezone = UK_TIME_ZONE)
    private Date expectedCompletionDate;
    private Milestones milestones;
    private Boolean isFmaComplete;
    private String mafDocumentName;
    private ApplicationType applicationType;
}
