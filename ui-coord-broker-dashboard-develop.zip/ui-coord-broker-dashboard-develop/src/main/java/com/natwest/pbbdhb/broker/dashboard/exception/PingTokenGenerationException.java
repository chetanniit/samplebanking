package com.natwest.pbbdhb.broker.dashboard.exception;

public class PingTokenGenerationException extends RuntimeException {

    public PingTokenGenerationException(String message) {
        super(message);
    }
}
