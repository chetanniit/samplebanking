package com.natwest.pbbdhb.broker.dashboard.service.documents;

import java.util.Optional;

public interface DocumentDownloadService {
    Optional<byte[]> getESISDocument(String fileName);
    Optional<byte[]> getFMADocument(String brand, String fileName);
}
