package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class LogMessageBuilder {

  String type;
  String subtype;
  String description;
  Exception exception;

  public String getLogMessage() {
    StringBuilder sb = new StringBuilder();
    if (exception != null) {
      sb.append(" type=");
      sb.append(exception.getClass().getSimpleName());
      sb.append(" description=\"");
      if (exception.getMessage() != null) {
        sb.append(exception.getMessage().replace("\"", "'"));
      }
      sb.append("\"");
    } else {
      sb.append(" type=");
      sb.append(type);
      sb.append(" description=\"");
      if (description != null) {
        sb.append(description.replace("\"", "'"));
      }
      sb.append("\"");
    }

    if (subtype != null) {
      sb.append(" subtype=");
      sb.append(subtype);
    }

    return sb.toString();
  }
}