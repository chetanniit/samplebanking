package com.natwest.pbbdhb.broker.dashboard.controller;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPermissionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SubmittedCaseDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus;
import com.natwest.pbbdhb.broker.dashboard.exception.UIErrorResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping("/broker")
public interface BrokerControllerSwagger {

  @Operation(summary = "Get User Details")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = BrokerDetailsDto.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @GetMapping(path = "/details", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<BrokerDetailsDto> details();

  @Operation(summary = "Get Associations")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = AssociationsDto.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @GetMapping(path = "/associations", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<AssociationsDto> associations(@RequestParam(required = false) String firstName,
      @RequestParam(required = false) String lastName,
      @RequestParam(required = false) AccessStatus accessStatus);

  @Operation(summary = "Get Submitted Case")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = SubmittedCaseDto.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @GetMapping(path = "/submitted-case/{caseId}", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<SubmittedCaseDto> getSubmittedCase(@PathVariable String caseId,
                                                    @Parameter(description = "Brand", example = "nwb")
                                                    @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
                                                        message = "Invalid Brand") String brand);

  @Operation(summary = "Manage Permissions")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = BrokerPermissionsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @PutMapping(path = "/permission", produces = APPLICATION_JSON_VALUE)
  ResponseEntity<BrokerPermissionsResponse> updateBrokerPermissions(
      @RequestBody BrokerPermissionsRequest request);


  @Operation(summary = "Update New Password")
  @ApiResponses(value = {@ApiResponse(responseCode = "204", description = "OK"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
  @PostMapping(path = "/password-change", produces = APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.NO_CONTENT)
  void updateBrokerPassword(@RequestBody BrokerPasswordRequest request);


}
