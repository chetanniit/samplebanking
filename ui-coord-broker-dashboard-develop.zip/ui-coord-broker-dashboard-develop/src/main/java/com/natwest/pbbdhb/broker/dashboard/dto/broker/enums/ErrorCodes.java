package com.natwest.pbbdhb.broker.dashboard.dto.broker.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.NonNull;

public enum ErrorCodes {
  INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR"),
  INVALID_CREDENTIALS("INVALID_CREDENTIALS"),
  OTP_EXPIRED("OTP_EXPIRED"),
  OTP_VALIDATION_FAILED("OTP_VALIDATION_FAILED"),
  UNAUTHORISED("UNAUTHORISED"),
  INVALID_DETAILS("INVALID_DETAILS"),
  ACCOUNT_LOCKED("ACCOUNT_LOCKED"),
  USER_ALREADY_EXISTS("USER_ALREADY_EXISTS"),
  USER_NOT_FOUND("USER_NOT_FOUND"),
  INCORRECT_MEMORABLE_QUESTION_ANSWERS("INCORRECT_MEMORABLE_QUESTION_ANSWERS"),
  MEMORABLE_QUESTIONS_LOCKED("MEMORABLE_QUESTIONS_LOCKED"),
  MEMORABLE_QUESTION_EXIST("MEMORABLE_QUESTION_EXIST"),
  QUESTIONS_NOT_RETRIEVED("QUESTIONS_NOT_RETRIEVED"),
  NO_ACCESS_TO_BROKER("NO_ACCESS_TO_BROKER");

  private final String value;

  ErrorCodes(@NonNull String value) {
    this.value = value;
  }

  @JsonCreator
  public static ErrorCodes fromValue(String text) {
    for (ErrorCodes code : ErrorCodes.values()) {
      if (code.value.equals(text)) {
        return code;
      }
    }
    return null;
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }
}
