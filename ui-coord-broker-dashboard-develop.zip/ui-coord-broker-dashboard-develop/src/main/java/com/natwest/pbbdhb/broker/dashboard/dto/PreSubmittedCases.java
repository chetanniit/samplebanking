package com.natwest.pbbdhb.broker.dashboard.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PreSubmittedCases {
    private List<PreSubmittedCase> preSubmittedCases;
    private Integer totalPages;
    private Integer size;
    private Integer number;
    private Long totalElements;

}
