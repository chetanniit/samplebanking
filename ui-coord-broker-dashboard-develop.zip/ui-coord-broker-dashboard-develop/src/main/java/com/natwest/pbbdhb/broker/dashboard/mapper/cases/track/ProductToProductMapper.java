package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.Products;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.Product;
import org.mapstruct.Mapper;

@Mapper(config = SpringMapperConfig.class)
public interface ProductToProductMapper {
    Product toProduct(Products products);
}
