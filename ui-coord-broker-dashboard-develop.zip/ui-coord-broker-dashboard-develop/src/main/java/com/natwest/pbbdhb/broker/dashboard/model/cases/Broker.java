package com.natwest.pbbdhb.broker.dashboard.model.cases;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Broker {

    private String fcaNumber;

    private String brokerSurname;

    @JsonProperty("brokerForename")
    private String brokerForeName;

    private String brokerPostcode;

    private String brokerEmail;

    private String brokerUsername;
}