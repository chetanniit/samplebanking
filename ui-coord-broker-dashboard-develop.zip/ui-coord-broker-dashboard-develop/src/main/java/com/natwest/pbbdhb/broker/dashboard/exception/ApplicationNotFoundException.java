package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class ApplicationNotFoundException extends RuntimeException {

    public ApplicationNotFoundException(String message) {
        super(message);
    }
}