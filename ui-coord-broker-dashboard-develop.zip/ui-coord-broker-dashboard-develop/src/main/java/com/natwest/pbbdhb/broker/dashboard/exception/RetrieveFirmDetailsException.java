package com.natwest.pbbdhb.broker.dashboard.exception;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;

public class RetrieveFirmDetailsException extends RuntimeException {

  private final ErrorCodes code;
  private final int httpStatus;

  public RetrieveFirmDetailsException(int httpStatus, ErrorCodes code, String message) {
    super(message);
    this.httpStatus = httpStatus;
    this.code = code;
  }

  public ErrorCodes getCode() {
    return code;
  }

  public int getHttpStatus() {
    return httpStatus;
  }
}
