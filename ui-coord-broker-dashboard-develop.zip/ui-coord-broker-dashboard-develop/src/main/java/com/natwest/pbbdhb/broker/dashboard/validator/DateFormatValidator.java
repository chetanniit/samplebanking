package com.natwest.pbbdhb.broker.dashboard.validator;

import com.natwest.pbbdhb.broker.dashboard.validator.annotation.DateFormat;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.time.LocalDate;
import java.time.chrono.IsoEra;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoField;
import java.util.Locale;

public class DateFormatValidator implements ConstraintValidator<DateFormat, CharSequence> {
    private DateTimeFormatter dateTimeFormatter;
    private DateFormat.DateConstraint constraint;

    @Override
    public void initialize(DateFormat annotation) {
        this.dateTimeFormatter = new DateTimeFormatterBuilder()
                .appendPattern(annotation.pattern())
                .parseDefaulting(ChronoField.ERA, IsoEra.CE.getValue())
                .toFormatter(Locale.UK)
                .withResolverStyle(ResolverStyle.STRICT);

        this.constraint = annotation.constraint();
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        try {
            LocalDate parsedDate = LocalDate.parse(value, dateTimeFormatter);
            return isDateConstraintMet(parsedDate);
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    private boolean isDateConstraintMet(LocalDate parsedDate) {
        LocalDate today = LocalDate.now();
        LocalDate yesterday = today.minusDays(1);
        LocalDate tomorrow = today.plusDays(1);

        switch (this.constraint) {
            case NONE:
                return true;
            case PAST:
                return today.isAfter(parsedDate);
            case NOT_FUTURE:
                return tomorrow.isAfter(parsedDate);
            case NOT_PAST:
                return yesterday.isBefore(parsedDate);
            case FUTURE:
                return today.isBefore(parsedDate);
            default:
                return false;
        }
    }
}

