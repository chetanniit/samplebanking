package com.natwest.pbbdhb.broker.dashboard.model.enums;

public enum DocumentUploadStatus {
  DOCUMENTS_OUTSTANDING,
  DOCUMENTS_UPLOADED,
  FURTHER_INFORMATION_REQUIRED,
  ASSESSING_DOCUMENTS
}
