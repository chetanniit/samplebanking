package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class ApplicantServiceException extends HttpCustomException {

    public ApplicantServiceException(Exception exception) {
        super(exception);
    }
}
