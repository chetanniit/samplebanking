package com.natwest.pbbdhb.broker.dashboard.controller.impl;

import com.natwest.pbbdhb.broker.dashboard.controller.AccountManagementControllerSwagger;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.FirmDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.service.AuthService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Slf4j
public class AccountManagementController implements AccountManagementControllerSwagger {

  private final AuthService authService;
  private final UserService userService;


  @Override
  public void changePassword(
      @RequestBody @Valid BrokerPasswordRequest request) {
    String brokerUsername = userService.getBrokerUsername();
    log.info("changePassword: Updating password for user: {}.", brokerUsername);

    authService.updateBrokerUserPassword(brokerUsername, request.getCurrentPassword(),
        request.getNewPassword());

    log.info("changePassword: User: {}, password successfully updated.",
        brokerUsername);
  }

  @Override
  public ResponseEntity<BrokerQuestionsResponse> getSecurityQuestions() {
    String brokerUsername = userService.getBrokerUsername();
    log.info("getSecurityQuestions: Retrieving security questions for user: {}.",
        brokerUsername);

    BrokerQuestionsResponse brokerQuestionsResponse = authService.getSecurityQuestions(
        brokerUsername);

    log.info("getSecurityQuestions: Security questions for user: {},"
        + " successfully retrieved.", brokerUsername);

    return ResponseEntity.ok(brokerQuestionsResponse);
  }

  @Override
  public void changeSecurityQuestions(@RequestBody @Valid ChangeSecurityQuestionsRequest request) {
    String brokerUsername = userService.getBrokerUsername();

    log.info("changeSecurityQuestions: Updating security questions for user: {}.",
        brokerUsername);

    authService.changeSecurityQuestions(brokerUsername, request);

    log.info("changeSecurityQuestions: Security questions for user: {},"
        + " successfully updated.", brokerUsername);
  }

  @Override
  public ResponseEntity<BrokerDetailsResponse> getBrokerDetails() {
    String brokerUsername = userService.getBrokerUsername();

    log.info("getBrokerDetails: Retrieving broker details for user: {}.",
        brokerUsername);

    BrokerDetailsResponse brokerDetailsResponse = authService.getBrokerDetails(brokerUsername);

    log.info("getBrokerDetails: Broker details for user: {},"
        + " successfully retrieved.", brokerUsername);

    return ResponseEntity.ok(brokerDetailsResponse);
  }

  @Override
  public ResponseEntity<UpdateBrokerDetailsResponse> updateBrokerDetails(BrokerDetails request) {
    String brokerUsername = userService.getBrokerUsername();

    log.info("updateBrokerDetails: Updating broker details for user: {}.",
        brokerUsername);

    UpdateBrokerDetailsResponse updateBrokerDetailsResponse = authService.updateBrokerDetails(
        brokerUsername, request);

    log.info("updateBrokerDetails: Broker details for user: {},"
        + " successfully updated.", brokerUsername);

    return ResponseEntity.ok(updateBrokerDetailsResponse);
  }

  @Override
  public ResponseEntity<FirmDetailsResponse> getFirmDetails(String fcanumber) {
    log.info("getFirmDetails: Retrieving firm details for fcanumber: {}.",
        fcanumber);

    FirmDetailsResponse firmDetailsResponse = authService.getFirmDetails(fcanumber);

    log.info("getFirmDetails: Firm details for fcanumber: {},"
        + " successfully retrieved.", fcanumber);

    return ResponseEntity.ok(firmDetailsResponse);
  }
}
