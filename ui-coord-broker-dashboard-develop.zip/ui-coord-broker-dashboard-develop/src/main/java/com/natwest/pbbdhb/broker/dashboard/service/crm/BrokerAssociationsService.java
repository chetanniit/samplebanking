package com.natwest.pbbdhb.broker.dashboard.service.crm;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociations;

public interface BrokerAssociationsService {

    BrokerAssociations getAssociations(String firstName, String lastName, AccessStatus accessStatus);
    void mapLoggedInAdminAssociations(AssociationsDto associationResultsDto);
}
