package com.natwest.pbbdhb.broker.dashboard.exception.handler;

public class LogMessageType {

  public static String EXCEPTION = "Exception";
}

