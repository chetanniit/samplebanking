package com.natwest.pbbdhb.broker.dashboard.model.applications.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@Data
@Schema(description = "Application Object")
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Builder
public class ApplicationDetailRequest {

    private String fcaNumber;
    private String firmPostcode;
    private String brokerFirstName;
    private String brokerLastName;
    private String brokerEmailId;
    private String brokerPostcode;
}
