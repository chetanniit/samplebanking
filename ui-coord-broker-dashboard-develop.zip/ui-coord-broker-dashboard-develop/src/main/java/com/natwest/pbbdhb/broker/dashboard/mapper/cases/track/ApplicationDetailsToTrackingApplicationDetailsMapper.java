package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = SpringMapperConfig.class, uses = {ApplicationDetailsToMortgageSummaryMapper.class,
        ApplicantToUiApplicantMapper.class, ProductInformationToProductInfoMapper.class, AddressMapper.class})
public interface ApplicationDetailsToTrackingApplicationDetailsMapper {

    @Mapping(target = "mortgageSummary", source = ".")
    @Mapping(target = "applicants", source = "applicantInformation")
    @Mapping(target = "propertyAddress", source = "propertyInformation.address")
    @Mapping(target = "productInfo", source = "productInformation")
    TrackingApplicationDetailResponse toResponse(ApplicationDetailsResponse applicationDetailsResponse);
}
