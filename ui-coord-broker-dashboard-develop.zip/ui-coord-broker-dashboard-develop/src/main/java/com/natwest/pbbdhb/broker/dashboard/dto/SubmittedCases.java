package com.natwest.pbbdhb.broker.dashboard.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SubmittedCases {
  private List<SubmittedCase> submittedCases;
  private Integer totalPages;
  private Integer size;
  private Integer number;
  private Long totalElements;

}
