package com.natwest.pbbdhb.broker.dashboard.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BrokerCoreResponse {

    @JsonProperty("mbs_broker")
    private BrokerDetails broker;
    @JsonProperty("mbs_brokerUpdateRequest")
    private BrokerUpdateRequest brokerUpdateRequest;
    @JsonProperty("mbs_firm")
    private FirmDetails firmDetails;
    @JsonProperty("mbs_message")
    private String message;
}
