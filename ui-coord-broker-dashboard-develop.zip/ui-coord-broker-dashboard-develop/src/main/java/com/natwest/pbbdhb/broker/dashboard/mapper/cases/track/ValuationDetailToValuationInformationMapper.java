package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ValuationInformation;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT_WITHOUT_T;

@Mapper(config = SpringMapperConfig.class)
public abstract class ValuationDetailToValuationInformationMapper {

    @Mapping(target = "valuationInstructionDate", source = "instructionDate", qualifiedByName = "getLocalDateTime")
    @Mapping(target = "valuationDate", source = "latestBookingDate", qualifiedByName = "getLocalDateTime")
    @Mapping(target = "valuationReceived", source = "receivedDate", qualifiedByName = "getLocalDateTime")
    @Mapping(target = "valuationAccepted", source = "assessmentDate", qualifiedByName = "getLocalDateTime")
    @Mapping(target = "valuationFeeAmount", source = "fee")
    public abstract ValuationInformation toValuationInformation(ValuationDetail valuationDetail);

    @Named("getLocalDateTime")
    public String getLocalDateTime(ZonedDateTime sourceDateTime) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT_WITHOUT_T);
        return dateTimeFormatter.format(sourceDateTime);
    }
}
