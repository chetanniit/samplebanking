package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.broker.dashboard.authorisation.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.mapper.ProductChangeEventMapper;
import com.natwest.pbbdhb.broker.dashboard.model.SuccessResponse;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAccessService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.ProducerService;
import com.natwest.pbbdhb.broker.dashboard.service.ProductChangeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.MSG_PRODUCT_CHANGE_PERMISSION;

@Slf4j
@Service
public class ProductChangeServiceImpl implements ProductChangeService {
    private final ProducerService producerService;
    private final ProductChangeEventMapper productChangeEventMapper;
    private final CaseService caseService;
    private final UserClaimsProvider userClaimsProvider;
    private final BrokerAccessService brokerAccessService;

    public ProductChangeServiceImpl(ProducerService producerService,
                                    ProductChangeEventMapper productChangeEventMapper,
                                    CaseService caseService,
                                    UserClaimsProvider userClaimsProvider,
                                    BrokerAccessService brokerAccessService) {
        this.producerService = producerService;
        this.productChangeEventMapper = productChangeEventMapper;
        this.caseService = caseService;
        this.userClaimsProvider = userClaimsProvider;
        this.brokerAccessService = brokerAccessService;
    }

    @Override
    public SuccessResponse changeProduct(ProductChangeRequest productChangeRequest, String caseId, String brand) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("product change request received for caseId: {}, brand: {},brokerUsername: {}", caseId, brand, brokerUsername);
        CaseApplicationDto caseResponse = caseService.getCaseByCaseId(caseId, brand);
        //Both admin and case owner broker allowed to product change
        if (null == caseResponse.getBroker() || !brokerAccessService.checkRequestedBrokerHasAccess(caseResponse.getBroker().getBrokerUsername())) {
            log.error("Error in productChange for caseId {} and brokerUsername {} : {}",
                    caseId, userClaimsProvider.getBrokerUsername(), MSG_PRODUCT_CHANGE_PERMISSION);
            throw new PermissionDeniedException(MSG_PRODUCT_CHANGE_PERMISSION);
        }
        String mrn = getMrn(caseResponse, brand);

        producerService.sendProductChangeEvent(productChangeEventMapper.mapProductChangeEvent(productChangeRequest, caseId, mrn, brand));

        return SuccessResponse.builder().message("Product Change Request Submitted Successfully").build();
    }


    private String getMrn(CaseApplicationDto caseResponse, String caseId) {
        if (!StringUtils.hasText(caseResponse.getMortgageReferenceNumber())) {
            log.debug("getMrn: no mrn found for caseId {}.", caseId);
            throw new MRNValidateFailureException("getMrn: no mrn found for caseId: "
                    + caseId);
        }

        return caseResponse.getMortgageReferenceNumber();
    }


}
