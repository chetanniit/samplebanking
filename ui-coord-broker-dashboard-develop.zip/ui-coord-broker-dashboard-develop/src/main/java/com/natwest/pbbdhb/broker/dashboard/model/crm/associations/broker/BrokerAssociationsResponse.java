
package com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class BrokerAssociationsResponse {

    @JsonProperty("mbs_brokerAdmins")
    private List<BrokerAdminDetails> admins;
    @JsonProperty("mbs_brokers")
    private List<AssociatedBrokerDetails> brokers;
    @JsonProperty("mbs_grantedPermissionBrokers")
    private List<AssociatedBrokerDetails> grantedPermissionBrokers;
    @JsonProperty("mbs_message")
    private String message;

}
