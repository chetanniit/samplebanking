package com.natwest.pbbdhb.broker.dashboard.dto.broker.enums;

public enum NonSTPFieldCategory {
  NAME, EMAIL, ADDRESS;
}
