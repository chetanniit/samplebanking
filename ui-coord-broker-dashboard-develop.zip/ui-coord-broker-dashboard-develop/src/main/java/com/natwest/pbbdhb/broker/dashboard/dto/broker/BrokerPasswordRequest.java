package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrokerPasswordRequest {
    @NotNull
    private String currentPassword;
    @NotNull
    private String newPassword;
}
