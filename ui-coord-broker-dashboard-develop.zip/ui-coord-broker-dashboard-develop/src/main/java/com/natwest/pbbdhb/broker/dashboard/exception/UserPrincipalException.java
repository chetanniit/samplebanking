package com.natwest.pbbdhb.broker.dashboard.exception;

public class UserPrincipalException extends RuntimeException {

  public UserPrincipalException(String message, Exception e) {
    super(message, e);
  }

  public UserPrincipalException(String message) {
    super(message);
  }
}
