package com.natwest.pbbdhb.broker.dashboard.mapper.crm;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import static com.natwest.pbbdhb.broker.dashboard.util.AppUtil.buildFullName;

@Mapper(config = SpringMapperConfig.class)
public interface BrokerCoreResponseToDtoMapper {

    @Mapping(source = "broker.userName", target = "userName")
    @Mapping(source = "broker.firstName", target = "firstName")
    @Mapping(source = "broker.lastName", target = "lastName")
    @Mapping(source = "broker.emailAddress", target = "emailAddress")
    @Mapping(source = "firmDetails.fcaNumber", target = "fcaNumber")
    @Mapping(source = "firmDetails.principleFCANumber", target = "principalFCANumber")
    @Mapping(constant = "BROKER", target = "userType")
    @Mapping(source = "broker", target = "fullName", qualifiedByName = "mapName")
    BrokerDetailsDto toDto(BrokerCoreResponse brokerCoreResponse);

    @Named("mapName")
    default String mapName(BrokerDetails broker) {

        return buildFullName(broker.getFirstName(), broker.getLastName());
    }
}
