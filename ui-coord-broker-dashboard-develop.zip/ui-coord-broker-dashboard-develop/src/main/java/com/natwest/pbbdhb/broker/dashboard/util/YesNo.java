package com.natwest.pbbdhb.broker.dashboard.util;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum YesNo {
    Y(true),
    N(false),
    Yes(true),
    No(false),
    YES(true),
    NO(false),
    True(true),
    False(false);

    private boolean booleanValue;

    public Boolean booleanValue() {
        return this.booleanValue;
    }
}
