/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.model.applications.ui;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Date;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_FORMAT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT_WITHOUT_T;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UK_TIME_ZONE;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
public class Status {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT, timezone = UK_TIME_ZONE)
    private Date submissionDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT_WITHOUT_T, timezone = UK_TIME_ZONE)
    private LocalDateTime lastUpdatedDate;

    private String status;
    private String statusDescription;
}
