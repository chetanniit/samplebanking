package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.PermissionType;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class BrokerPermissionsRequest {
    @NotNull
    private String userNameToAssociate;
    @NotNull
    private UserType userType;
    @NotNull
    private PermissionType permissionType;
}
