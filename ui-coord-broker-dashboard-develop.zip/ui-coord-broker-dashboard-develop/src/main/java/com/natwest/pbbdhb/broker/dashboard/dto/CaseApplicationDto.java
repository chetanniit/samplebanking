package com.natwest.pbbdhb.broker.dashboard.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDto;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@SuperBuilder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CaseApplicationDto {

  private String mortgageReferenceNumber;
  private String mortgageTempReferenceNumber;
  private String mafDocumentUrl;
  private List<SalesIllustrationDto> salesIllustrations;
  private BrokerDto broker;

}
