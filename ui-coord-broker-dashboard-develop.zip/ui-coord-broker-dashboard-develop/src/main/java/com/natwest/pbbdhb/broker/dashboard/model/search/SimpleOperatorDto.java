package com.natwest.pbbdhb.broker.dashboard.model.search;

import java.util.Set;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import static com.natwest.pbbdhb.broker.dashboard.model.search.OperatorDto.OperatorType.SIMPLE;

@Setter
@Getter
@Builder
public class SimpleOperatorDto extends OperatorDto {
    private CompareType compareType;
    private String field;
    private String value;
    private Set<String> values;

    public enum CompareType {
        EQ, EQ_IGNORE_CASE, DATE_EQ, LIKE, IN, DATE_TIME_BETWEEN
    }

    @Override
    public OperatorType getType() {
        return SIMPLE;
    }
}
