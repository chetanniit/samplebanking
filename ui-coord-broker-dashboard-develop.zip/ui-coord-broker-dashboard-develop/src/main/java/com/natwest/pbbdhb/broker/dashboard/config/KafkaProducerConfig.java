package com.natwest.pbbdhb.broker.dashboard.config;

import lombok.val;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;

import static org.apache.kafka.clients.CommonClientConfigs.SECURITY_PROTOCOL_CONFIG;
import static org.apache.kafka.clients.producer.ProducerConfig.BOOTSTRAP_SERVERS_CONFIG;
import static org.apache.kafka.clients.producer.ProducerConfig.CLIENT_ID_CONFIG;
import static org.apache.kafka.clients.producer.ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG;
import static org.apache.kafka.clients.producer.ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG;
import static org.apache.kafka.clients.producer.ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG;
import static org.apache.kafka.common.config.SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG;
import static org.apache.kafka.common.config.SslConfigs.SSL_KEYSTORE_TYPE_CONFIG;
import static org.apache.kafka.common.config.SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG;

@Configuration
public class KafkaProducerConfig {
    @Value("${kafka.key-store-cloud-path}")
    private  String keyStoreCloudPath;
    @Bean
    public ProducerFactory<String, Object> producerFactory(
            @Value("${spring.kafka.bootstrap-servers}") String bootstrapServers,
            @Value("${spring.kafka.security.protocol}") String securityProtocol,
            @Value("${spring.kafka.ssl.key-store-type}") String keystoreType,
            @Value("${spring.kafka.ssl.key-store-location}") String keystoreLocation,
            @Value("${spring.kafka.ssl.key-store-password}") String keystorePassword,
            @Value("${kafka.client-id}") String clientId
    ) {
        val props = new HashMap<String, Object>() {{
            put(BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            put(ENABLE_IDEMPOTENCE_CONFIG, true);
            put(KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            put(VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
            put(SECURITY_PROTOCOL_CONFIG, securityProtocol);
            put(SSL_KEYSTORE_TYPE_CONFIG, keystoreType);
            put(SSL_KEYSTORE_LOCATION_CONFIG, getKeystoreLocation(keystoreLocation));
            put(SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword);
            put(CLIENT_ID_CONFIG, clientId);
        }};

        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean
    public KafkaTemplate<String, Object> wireKafkaTemplate(@Qualifier("producerFactory") ProducerFactory<String, Object> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }


    private static final String CLASSPATH = "classpath:";

    private String getKeystoreLocation(String keystoreLocation) {
        if (keystoreLocation != null && keystoreLocation.contains(CLASSPATH)) {
            return keyStoreCloudPath + keystoreLocation.replace(CLASSPATH, "");
        }
        return keystoreLocation;
    }

}
