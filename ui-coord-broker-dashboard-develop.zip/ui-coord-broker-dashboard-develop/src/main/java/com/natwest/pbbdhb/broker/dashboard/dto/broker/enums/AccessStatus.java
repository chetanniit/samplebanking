package com.natwest.pbbdhb.broker.dashboard.dto.broker.enums;

public enum AccessStatus {
    ASSOCIATED, DISASSOCIATED, ACCESS_GRANTED
}
