package com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus;

public enum FeeAction {

    ADD_CAPITALISE_TO_LOAN,
    DEDUCT_FROM_ADVANCE,
    NO_ACTION
}
