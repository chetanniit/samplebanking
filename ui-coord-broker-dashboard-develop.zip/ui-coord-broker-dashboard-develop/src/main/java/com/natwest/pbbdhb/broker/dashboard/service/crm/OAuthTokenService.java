package com.natwest.pbbdhb.broker.dashboard.service.crm;

import com.natwest.pbbdhb.broker.dashboard.model.OAuthTokenData;

public interface OAuthTokenService {

    OAuthTokenData generatePingToken();
}
