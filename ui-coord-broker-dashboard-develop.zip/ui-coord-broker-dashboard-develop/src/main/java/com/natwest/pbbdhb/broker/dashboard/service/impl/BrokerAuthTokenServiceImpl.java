package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.natwest.pbbdhb.broker.dashboard.exception.SessionTokenFetchFailureException;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.BrokerAuthTokenRequest;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.BrokerAuthTokenResponse;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAuthTokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class BrokerAuthTokenServiceImpl implements BrokerAuthTokenService {

    private String brokerAuthTokenEndpoint;
    private final RestTemplate restTemplate;

    public BrokerAuthTokenServiceImpl(@Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
                                      @Value("${broker.auth.token.endpoint}") String brokerAuthTokenEndpoint){
        this.brokerAuthTokenEndpoint = brokerAuthTokenEndpoint;
        this.restTemplate = restTemplate;
    }

    @Override
    public String getSessionAuthToken(String caseId, String mortgageReferenceNumber, String broker,
                                      Applicant mainApplicant, String brand) {

        BrokerAuthTokenRequest request = BrokerAuthTokenRequest.builder()
                .brokerUserName(broker)
                .applicantId(mainApplicant.getApplicantId())
                .caseId(caseId)
                .cin(mainApplicant.getCin()).build();

        log.debug("getSessionAuthToken: Calling broker auth token service at url {} for"
                + " caseId: {}, mortgageReferenceNumber: {} and brand: {}.",
                brokerAuthTokenEndpoint,caseId,mortgageReferenceNumber,brand);

        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.add("brand", brand);
        HttpEntity<BrokerAuthTokenRequest> httpEntity = new HttpEntity<>(request, headers);
        BrokerAuthTokenResponse response =null;
        try {
            response= restTemplate.postForObject(brokerAuthTokenEndpoint, httpEntity, BrokerAuthTokenResponse.class);
        } catch (RestClientResponseException ex) {
            log.warn("getSessionAuthToken: RestClientResponseException occurred while "
                + "calling Auth token service: {}", ex.getMessage());
            throw new SessionTokenFetchFailureException(ex);
        } catch (Exception ex) {
            log.warn("getSessionAuthToken: Error while fetching session auth token for"
                    + " caseId: {}, mortgageReferenceNumber: {} and brand: {}. Error: {}",
                    caseId, mortgageReferenceNumber,brand,ex.getMessage());
            throw new SessionTokenFetchFailureException(ex);
        }
        log.debug("getSessionAuthToken: Broker auth token generated successfully for"
                + " caseId: {}, mortgageReferenceNumber: {} and brand: {}.",
            caseId, mortgageReferenceNumber,brand);
        return response.getAccessToken();
    }
}
