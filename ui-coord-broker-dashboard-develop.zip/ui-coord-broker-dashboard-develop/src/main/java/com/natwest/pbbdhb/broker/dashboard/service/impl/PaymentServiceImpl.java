package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.natwest.pbbdhb.broker.dashboard.exception.FeePaymentIntegrationException;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.Fee;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.FeeAction;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.PaymentType;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.ProductDetails;
import com.natwest.pbbdhb.broker.dashboard.model.cases.SalesIllustration;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.PaymentRequest;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.PaymentUrlResponse;
import com.natwest.pbbdhb.broker.dashboard.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PaymentServiceImpl implements PaymentService {

    private String worldpayUrl;
    private final RestTemplate iamJwtChainSecureRestTemplate;

    public PaymentServiceImpl(@Qualifier(value = "iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
                                 @Value("${worldpay.url}") String worldpayUrl){
        this.iamJwtChainSecureRestTemplate = iamJwtChainSecureRestTemplate;
        this.worldpayUrl = worldpayUrl;
    }

    @Override
    public boolean isValidPaymentRequest(CaseApplication caseApplication) {
      log.debug("isValidPaymentRequest: Checking isValidPaymentRequest");
        return !CollectionUtils.isEmpty(getApplicableFees(caseApplication));
    }

    @Override
    public boolean isPaymentMade(CaseApplication caseApplication) {
        log.debug("isValidPaymentRequest: Checking isPaymentMade");
        return getApplicableFees(caseApplication).stream().filter(
                f -> Objects.nonNull(f.getIsPaymentMade()) && f.getIsPaymentMade()).findAny().isPresent();
    }

    @Override
    public PaymentUrlResponse getFeePaymentPage(String mortgageRefNumber, String brand) {
        try{
            final HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
            headers.add("brand", brand);

            HttpEntity<PaymentRequest> httpEntity = new HttpEntity<>(PaymentRequest.builder().mortgageReferenceNumber(mortgageRefNumber).build(),
                    headers);

            log.debug("getFeePaymentPage: Calling msvc-worldpay service with"
                + " mortgageRefNumber: {} and brand: {} to get Payment page url.",
                mortgageRefNumber, brand);

            ResponseEntity<PaymentUrlResponse> responseEntity = iamJwtChainSecureRestTemplate
                    .postForEntity(worldpayUrl, httpEntity, PaymentUrlResponse.class);

            return responseEntity.getBody();
        } catch (RestClientResponseException ex) {
            log.warn("getFeePaymentPage: RestClientResponseException occurred while calling"
                + " worldpay service with mortgageRefNumber: {} and brand: {}: {}",
                mortgageRefNumber, brand, ex.getMessage());
            throw new FeePaymentIntegrationException(ex);
        } catch (Exception exception) {
            log.warn("getFeePaymentPage: Fee Payment url retrieval request with mortgageRefNumber: {} and"
                + " brand: {} - Failed: {}", mortgageRefNumber, brand, exception.getMessage());
            throw new FeePaymentIntegrationException(exception);
        }
    }

    private Optional<SalesIllustration> getSalesIllustration(CaseApplication caseApplication) {
        log.debug("getSalesIllustration: Retrieving sales illustration for caseId: {}.",
            caseApplication.getCaseId());
        return caseApplication.getSalesIllustrations().stream().filter(Objects::nonNull)
                .filter(salesIllustration -> salesIllustration.getIsAccepted()).findFirst();
    }

    private ProductDetails getProductDetails(CaseApplication caseApplication) {
        log.debug("getProductDetails: Retrieving product details for caseId: {}.",
            caseApplication.getCaseId());
        Optional<SalesIllustration> salesIllustration = getSalesIllustration(caseApplication);
        return salesIllustration.isPresent() && !CollectionUtils.isEmpty(salesIllustration.get().getProducts())
                ? salesIllustration.get().getProducts().get(0) : null;
    }

    private List<Fee> getFees(CaseApplication caseApplication) {
        log.debug("getFees: Retrieving fees for caseId: {}.", caseApplication.getCaseId());
        ProductDetails productDetails = getProductDetails(caseApplication);
        return Objects.nonNull(productDetails) ? productDetails.getFees() : Collections.emptyList();
    }

    private List<Fee> getApplicableFees(CaseApplication caseApplication) {
        log.debug("getApplicableFees: Retrieving applicable fees for caseId: {}.",
            caseApplication.getCaseId());
        return getFees(caseApplication).stream().filter(Objects::nonNull).filter(fee ->
                        FeeAction.NO_ACTION.equals(fee.getFeeAction())
                                && PaymentType.CARD_PAYMENT.equals(fee.getFeePaymentType())
                                && (Objects.nonNull(fee.getFeeAmount()) && fee.getFeeAmount().compareTo(BigDecimal.ZERO) > 0)
                                && Objects.nonNull(fee.getType())
                                && (fee.getType().toLowerCase(Locale.ROOT).contains("product")
                                || fee.getType().toLowerCase(Locale.ROOT).contains("val")))
                .collect(Collectors.toList());
    }
}
