package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingDocumentResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;

public interface CaseTrackingService {

    CaseTrackingResponse getApplications(String brokerUserName, String pageNumber, String resultsPerPage,
                                         String lastName, String postcode, String brand);

    TrackingApplicationDetailResponse getApplication(String brokerUserName, String mortgageRefNumber, String brand);

    CaseTrackingResponse getApplicationByMortgageReference(String brokerUserName, String mortgageRefNumber,
                                                           String brand);

  CaseTrackingDocumentResponse getApplicationDocuments(String mortgageRefNumber, String brand);
}
