package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PrincipalFcaFirm {

  @NotNull
  private String name;

  @NotNull
  private String fcaNumber;

}
