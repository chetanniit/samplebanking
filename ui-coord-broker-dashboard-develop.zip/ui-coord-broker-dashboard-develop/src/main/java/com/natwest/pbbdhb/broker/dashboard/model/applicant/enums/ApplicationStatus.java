package com.natwest.pbbdhb.broker.dashboard.model.applicant.enums;

public enum ApplicationStatus {
    SUBMIT_FMA_IN_PROGRESS,
    SUBMIT_GMS_MOPS,
    SUBMIT_GMS_STAGE_20,
    SALES_ILLUSTRATION_SUCCESSFUL,
    SALES_ILLUSTRATION_FAILED;

    public boolean isLockedForUpdate() {
        return this.equals(SUBMIT_FMA_IN_PROGRESS) || this.equals(SUBMIT_GMS_MOPS);
    }
}
