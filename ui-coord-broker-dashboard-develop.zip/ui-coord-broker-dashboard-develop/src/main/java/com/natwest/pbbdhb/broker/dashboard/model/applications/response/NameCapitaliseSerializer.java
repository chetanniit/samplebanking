package com.natwest.pbbdhb.broker.dashboard.model.applications.response;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;


public class NameCapitaliseSerializer extends JsonSerializer<String> {

    @Override
    public void serialize(
            String value, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {
        jsonGenerator.writeString(capitalizeName(value));
    }

    private static String capitalizeName(String name) {
        if (StringUtils.isNotBlank(name)) {
            String capitalizedName = "";
            String splitNames[] = name.split("\\s");
            for (String word : splitNames) {
                capitalizedName += StringUtils.capitalize(StringUtils.lowerCase(word)) + " ";
            }
            return capitalizedName.trim();
        }
        return null;
    }
}
