package com.natwest.pbbdhb.broker.dashboard.util;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

import static java.util.Objects.isNull;

public interface DataUtils {

    static <T> T toDataObject(Map<String, Object> source, Class<T> type) {
        if(isNull(source) || source.isEmpty()) {
            return null;
        }

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.convertValue(source, type);
        } catch (Exception ex) {
            return null;
        }
    }
}
