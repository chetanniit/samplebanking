package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.NonSTPFieldCategory;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerDetailsResponse {

  @NotNull
  private BrokerDetails brokerDetails;

  @NotNull
  private List<NonSTPFieldCategory> processingFields;

}
