package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.request.ApplicationsRequest;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Mapper(config = SpringMapperConfig.class)
public interface BrokerCoreResponseToApplicationRequestMapper {

    @Mapping(target = "fromDate", expression = "java(getFromDate())")
    @Mapping(target = "toDate", expression = "java(getToDate())")
    @Mapping(target = "brokerEmailId", source = "broker.emailAddress")
    @Mapping(target = "brokerFirstName", source = "broker.firstName")
    @Mapping(target = "brokerLastName", source = "broker.lastName")
    @Mapping(target = "brokerPostcode", source = "broker.brokerPostcode")
    @Mapping(target = "firmPostcode", source = "firmDetails.firmAddressPostcode")
    @Mapping(target = "fcaNumber", source = "firmDetails.fcaNumber")
    @Mapping(target = "pageNumber", constant = "1")
    @Mapping(target = "resultPerPage", constant = "50")
    ApplicationsRequest toApplicationRequest(BrokerCoreResponse brokerDetailsResponse);

    @Named("getFromDate")
    default String getFromDate() {
        return getLocalDateTime().minus(180, ChronoUnit.DAYS).toString();
    }

    @Named("getToDate")
    default String getToDate() {
        return getLocalDateTime().toString();
    }

    default LocalDateTime getLocalDateTime() {
        return LocalDateTime.now();
    }

}
