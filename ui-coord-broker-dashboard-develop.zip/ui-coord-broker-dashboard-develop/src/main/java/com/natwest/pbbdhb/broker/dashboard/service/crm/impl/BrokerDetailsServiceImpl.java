package com.natwest.pbbdhb.broker.dashboard.service.crm.impl;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.mapper.crm.AdminCoreResponseToDtoMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.crm.BrokerCoreResponseToDtoMapper;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerDetailsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BrokerDetailsServiceImpl implements BrokerDetailsService {

    private final CrmService crmService;
    private final UserClaimsProvider userClaimsProvider;
    private final BrokerCoreResponseToDtoMapper brokerCoreResponseToDtoMapper;
    private final AdminCoreResponseToDtoMapper adminCoreResponseToDtoMapper;

    @Override
    public BrokerDetailsDto getUserDetails() {
        String brokerUserName = userClaimsProvider.getBrokerUsername();
        log.debug("getUserDetails: Retrieving user details of broker: {}.",
            brokerUserName);

        BrokerType brokerType = userClaimsProvider.getBrokerType();
        if (BrokerType.BROKER.equals(brokerType)) {
            log.debug("getUserDetails: Retrieving user details of broker: {},"
                + " broker type is broker.", brokerUserName);
            return brokerCoreResponseToDtoMapper.toDto(crmService.getBrokerDetails(brokerUserName));
        } else {
            log.debug("getUserDetails: Retrieving user details of admin: {},",
                brokerUserName);
            return adminCoreResponseToDtoMapper.toDto(crmService.getAdminDetails(brokerUserName));
        }
    }
}
