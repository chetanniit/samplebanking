package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.PaymentUrlResponse;

public interface PaymentService {
     boolean isValidPaymentRequest(CaseApplication caseApplication);
     boolean isPaymentMade(CaseApplication caseApplication);
     PaymentUrlResponse getFeePaymentPage(String mortgageRefNumber, String brand);
}
