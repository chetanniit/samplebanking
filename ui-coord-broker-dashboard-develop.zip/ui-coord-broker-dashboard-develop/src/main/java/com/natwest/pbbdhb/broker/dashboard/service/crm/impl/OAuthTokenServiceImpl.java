package com.natwest.pbbdhb.broker.dashboard.service.crm.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.config.CRMConfig;
import com.natwest.pbbdhb.broker.dashboard.exception.PingTokenGenerationException;
import com.natwest.pbbdhb.broker.dashboard.model.OAuthTokenData;
import com.natwest.pbbdhb.broker.dashboard.service.crm.OAuthTokenService;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.SecureDigestAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.DatatypeConverter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Calendar;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.ALGORITHM;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.AUD;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.CLIENT_ASSERTION_TYPE;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.CLIENT_ID;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.EXPIRY;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.GRANT_TYPE;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.ISS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.JTI;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.JWT_VAL;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.KID;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.NBF;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.RESOURCE;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SCOPE;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUB;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.TENANT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.TYPE;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.X5T;

@Slf4j
@Service
public class OAuthTokenServiceImpl implements OAuthTokenService {

    private final static String SIGNATURE_ALGORITHM = "RS256";
    private final CRMConfig crmConfig;
    private final RestTemplate restTemplate;

    public OAuthTokenServiceImpl(CRMConfig crmConfig,
                                 @Qualifier(value = "proxyRestTemplate") RestTemplate restTemplate) {
        this.crmConfig = crmConfig;
        this.restTemplate = restTemplate;
    }

    public OAuthTokenData generatePingToken() {
        log.debug("generatePingToken: Generating Ping Token...");

        MultiValueMap<String, String> paramsMap = new LinkedMultiValueMap<>();
        paramsMap.add(GRANT_TYPE, crmConfig.getGrant());
        paramsMap.add(SCOPE, crmConfig.getScope());
        paramsMap.add(CLIENT_ID, crmConfig.getConfidentialClientID());
        paramsMap.add(TENANT, crmConfig.getTenant());
        paramsMap.add(RESOURCE, crmConfig.getResource());
        paramsMap.add(CLIENT_ASSERTION_TYPE, crmConfig.getAssertion());

        String signedJwt;
        try {
            signedJwt = generateSignedJwt();
            log.debug("generatePingToken: Generating ping token, signedJwt is: {}...",
                signedJwt);
        } catch (NoSuchAlgorithmException | KeyStoreException | CertificateException
                | IOException | UnrecoverableKeyException e) {
            throw new PingTokenGenerationException("Exception while generating Ping token while" +
                    " fetching access token: " + e.getMessage());
        }
        paramsMap.add("client_assertion", signedJwt);
        log.debug("generatePingToken: Generated JWT Token: {}", signedJwt);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(paramsMap, headers);

        try {
            log.debug(new ObjectMapper().writeValueAsString(entity));
        } catch (JsonProcessingException e) {
            log.error("Unable to convert entity to string");
        }

        ResponseEntity<OAuthTokenData> response =
                restTemplate.exchange(crmConfig.getCrmAccessTokenEndpoint(),
                        HttpMethod.POST, entity,
                        OAuthTokenData.class);
        log.debug("generatePingToken: Access Token successfully generated: "
            + response.getBody());
        return response.getBody();

    }

    private String generateSignedJwt() throws NoSuchAlgorithmException, KeyStoreException, CertificateException,
            IOException, UnrecoverableKeyException {
        log.debug("generateSignedJwt: Generating signed JWT...");

        Calendar expiredTime = Calendar.getInstance();
        expiredTime.add(Calendar.MINUTE, 60);

        Map<String, Object> claims = new ConcurrentHashMap<>();
        claims.put(AUD, crmConfig.getAud());
        claims.put(JTI, UUID.randomUUID().toString());
        claims.put(ISS, crmConfig.getConfidentialClientID());
        claims.put(SUB, crmConfig.getConfidentialClientID());
        claims.put(EXPIRY, (System.currentTimeMillis() + (1000 * 60 * 60 * 60)) / 1000);
        claims.put(NBF, (System.currentTimeMillis() + (1000 * 60)) / 1000);

        //We will sign our JWT with our ApiKey secret
        byte[] pvtKeySecretBytes = DatatypeConverter.parseBase64Binary(crmConfig.getPfxcert());
        InputStream targetStream = new ByteArrayInputStream(pvtKeySecretBytes);
        KeyStore keyStore = KeyStore.getInstance("pkcs12");
        keyStore.load(targetStream, crmConfig.getPwd().toCharArray());
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        keyStore.store(outputStream, crmConfig.getPwd().toCharArray());
        SecureDigestAlgorithm alg = Jwts.SIG.RS256;
        Key k = keyStore.getKey("1",
                crmConfig.getPwd().toCharArray());
        JwtBuilder builder = Jwts.builder();
        builder.header().add(TYPE, JWT_VAL)
                .add(KID, crmConfig.getThumbprint())
                .add(X5T, crmConfig.getXftHeader())
                .add(ALGORITHM, SIGNATURE_ALGORITHM);
        builder.issuedAt(new DateTime().toDate());
        builder.expiration(new DateTime().plusMinutes(60).toDate());
        builder.claims(claims);
        builder.signWith(k, alg);
        log.debug("generateSignedJwt: Signed JWT successfully generated.");
        return builder.compact();

    }
}
