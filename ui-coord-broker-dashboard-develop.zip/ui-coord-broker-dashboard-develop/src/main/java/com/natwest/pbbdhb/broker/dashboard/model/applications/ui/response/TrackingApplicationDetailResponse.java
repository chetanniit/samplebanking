package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.SolicitorInformation;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrackingApplicationDetailResponse {
    private MortgageSummary mortgageSummary;
    private List<UiApplicant> applicants;
    private AddressInfo propertyAddress;
    private ProductInfo productInfo;
    private SolicitorInformation solicitorInformation;
}
