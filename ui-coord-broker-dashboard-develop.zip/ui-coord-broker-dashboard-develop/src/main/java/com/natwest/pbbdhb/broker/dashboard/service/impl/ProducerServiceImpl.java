package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.natwest.pbbdhb.broker.dashboard.kafka.dto.ProductChangeEventDto;
import com.natwest.pbbdhb.broker.dashboard.service.ProducerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class ProducerServiceImpl implements ProducerService {
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Value("${kafka.product-change-event-topic-name}")
    private String topicName;

    @Override
    public void sendProductChangeEvent(ProductChangeEventDto productChangeEventDto) {
        log.info("Sending product change event for mrn: {}", productChangeEventDto.getReferenceNumber());

        Message<ProductChangeEventDto> message = MessageBuilder.withPayload(productChangeEventDto)
                .setHeader(KafkaHeaders.TOPIC, topicName)
                .setHeader(KafkaHeaders.KEY, productChangeEventDto.getReferenceNumber()).build();

        CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(message);
        log.debug("future from template {}", future);
        future.whenComplete((result, throwable) -> {
            if (throwable == null) {
                log.debug("Kafka event; Message:OUTGOING; Topic:{}; Result:SUCCESS; Message:{};", topicName, "product change event sent");
                log.info("Kafka event; Message:OUTGOING; Topic:{}; Result:SUCCESS;", topicName);
            } else {
                log.debug("Kafka event; Message:OUTGOING; Topic:{}; Result:FAILURE; Response:{}; Message:{};", topicName, throwable.getMessage(), "product change event not sent");
                log.error("Kafka event; Message:OUTGOING; Topic:{}; Result:FAILURE; Response:{}", topicName,
                        throwable.getMessage());
            }
        });

        log.info("product change event with mrn: {} sent", productChangeEventDto.getReferenceNumber());

    }
}
