package com.natwest.pbbdhb.broker.dashboard.util;

import com.natwest.pbbdhb.broker.dashboard.model.applications.request.ApplicationsRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.BRAND_HEADER_NAME;

public class AppUtil {

    private static final String FCA_NUMBER = "fcaNumber";
    private static final String BROKER_EMAIL_ID = "brokerEmailId";
    private static final String BROKER_LAST_NAME = "brokerLastName";
    private static final String APPLICANT_LAST_NAME = "applicantLastName";
    private static final String BROKER_FIRST_NAME = "brokerFirstName";
    private static final String BROKER_POSTCODE = "brokerPostcode";
    private static final String FIRM_POSTCODE = "firmPostcode";
    private static final String PROPERTY_POSTCODE = "propertyPostcode";
    private static final String DATE_RANGE = "dateRange";
    private static final String SORT_BY = "sortBy";
    private static final String SORT_ORDER = "sortOrder";
    private static final String PAGE_NUMBER = "pageNumber";
    private static final String RESULT_PER_PAGE = "resultPerPage";

    public static void populateRequestParams(
            ApplicationsRequest request, UriComponentsBuilder builder) {
        Optional.ofNullable(request)
                .ifPresent(
                        applicationsRequest ->
                                builder.replaceQueryParam(
                                        FCA_NUMBER, applicationsRequest.getFcaNumber())
                                        .replaceQueryParam(
                                                FIRM_POSTCODE, applicationsRequest.getFirmPostcode())
                                        .replaceQueryParam(
                                                BROKER_FIRST_NAME, applicationsRequest.getBrokerFirstName())
                                        .replaceQueryParam(
                                                BROKER_LAST_NAME, applicationsRequest.getBrokerLastName())
                                        .replaceQueryParam(
                                                BROKER_EMAIL_ID, applicationsRequest.getBrokerEmailId())
                                        .replaceQueryParam(
                                                BROKER_POSTCODE, applicationsRequest.getBrokerPostcode())
                                        .replaceQueryParam(
                                                DATE_RANGE, applicationsRequest.getDateRange())
                                        .replaceQueryParam(
                                                RESULT_PER_PAGE, applicationsRequest.getResultPerPage())
                                        .replaceQueryParam(
                                                SORT_BY, applicationsRequest.getSortBy())
                                        .replaceQueryParam(
                                                SORT_ORDER, applicationsRequest.getSortOrder()));
        if (Objects.nonNull(request)) {
            if (Objects.nonNull(request.getApplicantLastName())) {
                builder.replaceQueryParam(
                        APPLICANT_LAST_NAME, request.getApplicantLastName());
            }
            if (Objects.nonNull(request.getPropertyPostcode())) {
                builder.replaceQueryParam(
                        PROPERTY_POSTCODE, request.getPropertyPostcode());
            }
            if (Objects.nonNull(request.getPageNumber())) {
                builder.replaceQueryParam(
                        PAGE_NUMBER, request.getPageNumber());
            }
        }
    }


    public static void populateRequestParamsForApplicationDetail(ApplicationsRequest request,
                                                                 UriComponentsBuilder builder) {
        Optional.ofNullable(request)
                .ifPresent(
                        applicationDetailRequest ->
                                builder.replaceQueryParam(
                                        FCA_NUMBER, applicationDetailRequest.getFcaNumber())
                                        .replaceQueryParam(
                                                FIRM_POSTCODE, applicationDetailRequest.getFirmPostcode())
                                        .replaceQueryParam(
                                                BROKER_FIRST_NAME, applicationDetailRequest.getBrokerFirstName())
                                        .replaceQueryParam(
                                                BROKER_LAST_NAME, applicationDetailRequest.getBrokerLastName())
                                        .replaceQueryParam(
                                                BROKER_EMAIL_ID, applicationDetailRequest.getBrokerEmailId())
                                        .replaceQueryParam(
                                                BROKER_POSTCODE, applicationDetailRequest.getBrokerPostcode()));
    }

    public static Boolean getIsMainApplicant(String isMainApplicant) {
        return StringUtils.isNotBlank(isMainApplicant) ? YesNo.valueOf(isMainApplicant).booleanValue() : null;
    }

    public static String buildFullName(String firstName, String lastName) {
        StringBuilder nameBuilder = new StringBuilder(firstName)
                .append(" ").append(lastName);

        return nameBuilder.toString();
    }

    public static HttpHeaders buildBrandAndContentTypeHeaders(String brand, String contentType) {
      final HttpHeaders headers = new HttpHeaders();
      headers.add(HttpHeaders.CONTENT_TYPE, contentType);
      headers.add(BRAND_HEADER_NAME, brand);
      return headers;
    }
}
