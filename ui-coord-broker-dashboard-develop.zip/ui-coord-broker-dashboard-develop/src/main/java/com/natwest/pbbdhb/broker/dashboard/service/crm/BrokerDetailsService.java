package com.natwest.pbbdhb.broker.dashboard.service.crm;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;

public interface BrokerDetailsService {
    BrokerDetailsDto getUserDetails();
}
