package com.natwest.pbbdhb.broker.dashboard.mapper;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerSecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SecurityQuestion;
import org.mapstruct.Mapper;

@Mapper(config = SpringMapperConfig.class)
public interface SecurityQuestionToBrokerSecurityQuestionMapper {
  BrokerSecurityQuestion toSecurityQuestion(SecurityQuestion input);

}
