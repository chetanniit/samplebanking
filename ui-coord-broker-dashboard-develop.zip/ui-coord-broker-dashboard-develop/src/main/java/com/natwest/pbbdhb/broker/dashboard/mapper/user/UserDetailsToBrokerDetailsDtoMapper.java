package com.natwest.pbbdhb.broker.dashboard.mapper.user;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = SpringMapperConfig.class)
public interface UserDetailsToBrokerDetailsDtoMapper {

    @Mapping(target = "firstName", source = "brokerFirstName")
    @Mapping(target = "lastName", source = "brokerLastName")
    @Mapping(target = "userType", source = "brokerType")
    @Mapping(target = "emailAddress", source = "brokerEmailId")
    BrokerDetailsDto toBrokerDetails(UserDetails userDetails);
}
