package com.natwest.pbbdhb.broker.dashboard.mapper.crm;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType;
import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAdminDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociations;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import org.mapstruct.Mapper;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(config = SpringMapperConfig.class)
public class BrokerAssociationsToDtoMapper {

    public AssociationsDto mapAssociations(BrokerAssociations associations) {
        AssociationsDto dto = AssociationsDto.builder().build();

        List<BrokerDetailsDto> allAssociations = new ArrayList<>();

        List<AssociatedBrokerDetails> associateBrokers = associations.getAssociateBrokers();
        if (!CollectionUtils.isEmpty(associateBrokers)) {
            List<BrokerDetailsDto> brokers = associateBrokers.stream().map(broker ->
                    getBrokerDetailsDto(broker, AccessStatus.ASSOCIATED)
            ).collect(Collectors.toList());
            allAssociations.addAll(brokers);
        }

        List<AssociatedBrokerDetails> grantedAccessBrokers = associations.getGrantedAccessBrokers();
        if (!CollectionUtils.isEmpty(grantedAccessBrokers)) {
            List<BrokerDetailsDto> brokers = grantedAccessBrokers.stream().map(broker ->
                    getBrokerDetailsDto(broker, AccessStatus.ACCESS_GRANTED)
            ).collect(Collectors.toList());
            allAssociations.addAll(brokers);
        }

        List<AssociatedBrokerDetails> dissociatedBrokers = associations.getDissociateBrokers();
        if (!CollectionUtils.isEmpty(dissociatedBrokers)) {
            List<BrokerDetailsDto> brokers =
                    dissociatedBrokers.stream().map(broker ->
                            getBrokerDetailsDto(broker, AccessStatus.DISASSOCIATED)
                    ).collect(Collectors.toList());
            allAssociations.addAll(brokers);
        }

        List<BrokerAdminDetails> associateBrokerAdmins = associations.getAssociateBrokerAdmins();
        if (!CollectionUtils.isEmpty(associateBrokerAdmins)) {
            List<BrokerDetailsDto> admins =
                    associateBrokerAdmins.stream().map(broker ->
                            getBrokerDetailsDto(broker, AccessStatus.ASSOCIATED)
                    ).collect(Collectors.toList());
            allAssociations.addAll(admins);
        }

        List<BrokerAdminDetails> dissociateBrokerAdmins = associations.getDissociateBrokerAdmins();
        if (!CollectionUtils.isEmpty(dissociateBrokerAdmins)) {
            List<BrokerDetailsDto> admins =
                    dissociateBrokerAdmins.stream().map(broker ->
                            getBrokerDetailsDto(broker, AccessStatus.DISASSOCIATED)
                    ).collect(Collectors.toList());
            allAssociations.addAll(admins);
        }

        dto.setBrokers(allAssociations);

        return dto;
    }

    private BrokerDetailsDto getBrokerDetailsDto(AssociatedBrokerDetails brokerDetails,
                                                 AccessStatus accessStatus) {

                return BrokerDetailsDto.builder()
                        .fcaNumber(brokerDetails.getFcaNumber())
                        .fullName(brokerDetails.getBrokerAdminName())
                        .firstName(brokerDetails.getFirstName())
                        .lastName(brokerDetails.getLastName())
                        .userName(brokerDetails.getUserName())
                        .userType(UserType.BROKER)
                        .principalFCANumber(brokerDetails.getPrincipalFCANumber())
                        .emailAddress(brokerDetails.getEmailAddress())
                        .accessStatus(accessStatus)
                        .build();
    }

    private BrokerDetailsDto getBrokerDetailsDto(BrokerAdminDetails adminDetails,
                                                 AccessStatus accessStatus) {
        return BrokerDetailsDto.builder()
                .fcaNumber(adminDetails.getFcaNumber())
                .fullName(adminDetails.getBrokerAdminName())
                .firstName(adminDetails.getFirstName())
                .lastName(adminDetails.getLastName())
                .userName(adminDetails.getUserName())
                .userType(UserType.ADMIN)
                .principalFCANumber(adminDetails.getPrincipalFCANumber())
                .emailAddress(adminDetails.getEmailAddress())
                .accessStatus(accessStatus)
                .build();
    }
}
