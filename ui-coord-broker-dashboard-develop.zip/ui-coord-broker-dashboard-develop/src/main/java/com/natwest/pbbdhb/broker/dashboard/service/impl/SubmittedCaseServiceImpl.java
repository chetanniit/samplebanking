package com.natwest.pbbdhb.broker.dashboard.service.impl;

import static com.google.common.collect.Iterables.isEmpty;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FEE_TYPE_PRODUCT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FEE_TYPE_VAL;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.CaseActionDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.CaseDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SubmittedCaseDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicationsServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.AssociatedBrokerNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.mapper.MsvcApplicantToUiApplicantMapper;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingDocumentResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.Fee;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.FeeAction;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.PaymentType;
import com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus;
import com.natwest.pbbdhb.broker.dashboard.service.ApplicantService;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAccessService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseTrackingService;
import com.natwest.pbbdhb.broker.dashboard.service.SubmittedCaseService;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SubmittedCaseServiceImpl implements SubmittedCaseService {

  private final CaseTrackingService caseTrackingService;
  private final CaseService caseService;
  private final UserClaimsProvider userClaimsProvider;
  private final ApplicantService applicantService;
  private final MsvcApplicantToUiApplicantMapper msvcApplicantToUiApplicantMapper;
  private final BrokerAccessService brokerAccessService;

  public SubmittedCaseServiceImpl(
      CaseTrackingService caseTrackingService,
      CaseService caseService,
      UserClaimsProvider userClaimsProvider,
      ApplicantService applicantService,
      MsvcApplicantToUiApplicantMapper msvcApplicantToUiApplicantMapper,
      BrokerAccessService brokerAccessService) {
    this.caseTrackingService = caseTrackingService;
    this.caseService = caseService;
    this.userClaimsProvider = userClaimsProvider;
    this.applicantService = applicantService;
    this.msvcApplicantToUiApplicantMapper = msvcApplicantToUiApplicantMapper;
    this.brokerAccessService = brokerAccessService;
  }

  @Override
  public SubmittedCaseDto getSubmittedCase(String caseId, String brand) {

    String brokerUsername = userClaimsProvider.getBrokerUsername();

    CaseDto caseDto = CaseDto.builder().caseId(caseId).build();
    SubmittedCaseDto submittedCaseDto = SubmittedCaseDto.builder().build();
    CaseActionDto caseActionDto = new CaseActionDto();

    CaseApplicationDto caseApplicationDto = getCaseFromCapie(caseId, brand, brokerUsername);
    String caseBrokerUsername = caseApplicationDto.getBroker() == null ?
        null : caseApplicationDto.getBroker().getBrokerUsername();
    log.debug("getSubmittedCase: Checking if brokerUsername {} has access to case {} belonging to {}", brokerUsername, caseId, caseBrokerUsername);
    Boolean requestedBrokerIsAccessible = brokerAccessService.checkRequestedBrokerHasAccess(caseBrokerUsername);
    if (!requestedBrokerIsAccessible) {
      log.debug("getSubmittedCase: brokerUsername {} does not have access to case {} - Throwing AssociatedBrokerNotFoundException",
          brokerUsername, caseId);
      throw new AssociatedBrokerNotFoundException(400, ErrorCodes.NO_ACCESS_TO_BROKER, "No access to the broker");
    }
    log.debug("getSubmittedCase: brokerUsername {} has access to case {}", brokerUsername, caseId);

    // FE requires the broker username to call the old case-tracking url
    caseDto.setBrokerUsername(caseBrokerUsername);

    List<Fee> fees = getFees(caseApplicationDto, caseId, brand, brokerUsername);

    Boolean hasFees = hasFees(fees);
    log.debug("getSubmittedCase: Setting hasFees to {} for caseId: {},"
            + " brokerUsername: {}, and brand {}.", hasFees, caseId, brokerUsername, brand);
    caseActionDto.setHasFees(hasFees);
    Boolean isFeePaymentComplete;
    if(hasFees) {
      isFeePaymentComplete = isFeePaymentComplete(fees);
    } else {
      isFeePaymentComplete = null;
    }
    log.debug("getSubmittedCase: Setting isFeePaymentComplete to {} for caseId: {},"
            + " brokerUsername: {} and brand {}.",
        isFeePaymentComplete, caseId, brokerUsername, brand);
    caseActionDto.setIsFeePaymentComplete(isFeePaymentComplete);

    String mortgageReferenceNumber = caseApplicationDto.getMortgageReferenceNumber();
    log.debug("getSubmittedCase: Setting mortgageReferenceNumber to {} for caseId: {},"
            + " brokerUsername: {} and brand: {}.",
        mortgageReferenceNumber, caseId, brokerUsername, brand);
    caseDto.setMortgageReferenceNumber(mortgageReferenceNumber);
    String mortgageTempReferenceNumber = caseApplicationDto.getMortgageTempReferenceNumber();

    List<UiApplicant> applicants = getApplicants(caseId, brand, brokerUsername);
    caseDto.setApplicants(applicants);
    log.debug("getSubmittedCase: Setting applicants to {} for caseId: {},"
        + " brokerUsername: {} and brand: {}.", applicants, caseId, brokerUsername, brand);

    String mafDocumentUrl = caseApplicationDto.getMafDocumentUrl();
    if(StringUtils.isNotBlank(mafDocumentUrl)) {
      String mafDocumentName = StringUtils.substringAfterLast(mafDocumentUrl, "/");
      log.debug("getSubmittedCase: Setting isFmaComplete to true and mafDocumentName"
              + " to: {} for caseId: {}, brokerUsername: {} and brand: {}.",
          mafDocumentName, caseId, brokerUsername, brand);
      caseActionDto.setIsFmaComplete(true);
      caseActionDto.setMafDocument(mafDocumentName);
    } else {
      log.debug("getSubmittedCase: Setting isFmaComplete to false and mafDocumentName to"
          + " null for caseId: {}, brokerUsername: {} and brand: {}.", caseId, brokerUsername, brand);
      caseActionDto.setIsFmaComplete(false);
      caseActionDto.setMafDocument(null);
    }

    if(StringUtils.isNotBlank(mortgageReferenceNumber)) {

      CaseTrackingDocumentResponse applicationDocuments;
      try {
        applicationDocuments = caseTrackingService.getApplicationDocuments(mortgageReferenceNumber, brand);
        log.debug("getSubmittedCase: caseTrackingService successfully called to get"
                + " application documents with caseId: {}, mortgageRefNumber: {},"
                + " brokerUsername: {} and brand: {}.",
            caseId, mortgageReferenceNumber, brokerUsername, brand);
      } catch(ApplicationsServiceException ex) {
        log.error("getSubmittedCase: Caught ApplicationServiceException while calling"
            + " caseTrackingService to get application documents with caseId: {},"
            + " brokerUsername: {} and brand: {}.", caseId, brokerUsername, brand);
        applicationDocuments = null;
      }

      caseActionDto.setDocumentUploadStatus(getDocumentUploadStatus(applicationDocuments, caseId, brokerUsername));

      Boolean isCaseTrackingDisplay = getIsCaseTrackingDisplay(caseId, mortgageReferenceNumber, brand,
          caseBrokerUsername == null ? brokerUsername : caseBrokerUsername);
      log.debug("getSubmittedCase: Setting isCaseTrackingAvailable to {} for caseId: {},"
              + " mortgageReferenceNumber: {}, brokerUsername: {} and brand {}.",
          isCaseTrackingDisplay, caseId, mortgageReferenceNumber, brokerUsername, brand);
      caseActionDto.setIsCaseTrackingAvailable(isCaseTrackingDisplay);
    } else {
        log.debug("getSubmittedCase: Setting mortgageTempReferenceNumber to {} for"
                + " caseId: {}, brokerUsername {} and brand {}.",
        mortgageTempReferenceNumber, caseId, brokerUsername, brand);
        caseDto.setMortgageTempReferenceNumber(mortgageTempReferenceNumber);
        log.debug(
            "getSubmittedCase: Setting isCaseTrackingAvailable to false for caseId: {},"
                + " mortgageTempReferenceNumber: {}, brokerUsername: {} and brand: {}.",
            caseId, mortgageTempReferenceNumber, brokerUsername, brand);
        caseActionDto.setIsCaseTrackingAvailable(false);
    }

    submittedCaseDto.setCaseDto(caseDto);
    submittedCaseDto.setCaseAction(caseActionDto);
    return submittedCaseDto;
  }

  private List<UiApplicant> getApplicants(String caseId, String brand, String brokerUsername) {
    log.debug(
        "getApplicants: Getting applicants for caseId: {}, brokerUsername: {} and brand: {}.",
        caseId, brokerUsername, brand);
    try {
      List<Applicant> applicantList = applicantService.getApplicants(brand, caseId);
      log.debug("getApplicants: Successfully called with caseId: {}, brokerUsername: {} and brand: {}.",
          caseId, brokerUsername, brand);
      return applicantList.stream().map(msvcApplicantToUiApplicantMapper::toUiApplicant).collect(
          Collectors.toList());
    } catch (IntegrationException ex) {
      log.warn(
          "getApplicants: Caught IntegrationException while calling getApplicants with caseId: {},"
              + " brokerUsername: {} and brand: {} - rethrowing.",
          caseId, brokerUsername, brand);
      throw ex;
    }
  }

  private List<Fee> getFees(CaseApplicationDto caseApplication, String caseId, String brand, String brokerUsername) {
    log.debug("getFees: Retrieving fees for caseId: {}, brokerUsername: {} and brand: {}.",
        caseId, brokerUsername, brand);
    List<Fee> fees = getFees(caseApplication).stream().filter(Objects::nonNull).filter(fee ->
            FeeAction.NO_ACTION.name().equalsIgnoreCase(fee.getFeeAction().name())
                && PaymentType.CARD_PAYMENT.name().equalsIgnoreCase(fee.getFeePaymentType().name())
                && nonNull(fee.getFeeAmount())
                && fee.getFeeAmount().compareTo(BigDecimal.ZERO) > 0
                && nonNull(fee.getType())
                && (fee.getType().toLowerCase(Locale.ROOT).contains(FEE_TYPE_PRODUCT)
                || fee.getType().toLowerCase(Locale.ROOT).contains(FEE_TYPE_VAL)))
        .collect(Collectors.toList());
    log.debug("getFees: Fees for caseId: {}, brokerUsername: {} and brand: {}"
            + " retrieved successfully: {}", caseId, brokerUsername, brand, fees);
    return fees;
  }

  private Boolean hasFees(List<Fee> fees) {
    log.debug("hasFees: Checking if application has fees.");
      return !fees.isEmpty();
  }

  private Boolean isFeePaymentComplete(List<Fee> fees) {
    log.debug("isFeePaymentComplete: Checking if payment of fees has been completed.");
      return fees.isEmpty() || fees.stream().noneMatch(
          f -> isNull(f.getIsPaymentMade()) || !f.getIsPaymentMade());
  }


  private List<Fee> getFees(CaseApplicationDto caseApplication) {
    log.debug("getFees: Retrieving fees.");
    List<ProductDetailsDto> productDetails = getProductDetails(caseApplication);
    List<Fee> fees = new ArrayList<>();
    productDetails.forEach(p -> fees.addAll(p.getFees()));
    log.debug("getFees: Fees retrieved successfully.");
    return fees;
  }

  private List<ProductDetailsDto> getProductDetails(CaseApplicationDto caseApplication) {
    log.debug("getProductDetails: Retrieving product details.");
    List<SalesIllustrationDto> salesIllustration = getSalesIllustration(caseApplication);
    List<ProductDetailsDto> productDetailsDtos = new ArrayList<>();
    salesIllustration.forEach(s -> productDetailsDtos.addAll(s.getProducts()));
    log.debug("getProductDetails: Product details retrieved successfully.");
    return productDetailsDtos;
  }
  private List<SalesIllustrationDto> getSalesIllustration(CaseApplicationDto caseApplication) {
    log.debug("getSalesIllustration: Retrieving sales illustration.");
    if (caseApplication.getSalesIllustrations() == null || isEmpty(caseApplication.getSalesIllustrations())) {
      return new ArrayList<>();
    }
    return caseApplication.getSalesIllustrations().stream().filter(Objects::nonNull)
        .filter(s -> s.getIsAccepted() != null && s.getIsAccepted()).collect(Collectors.toList());
  }

  private CaseApplicationDto getCaseFromCapie(String caseId, String brand, String brokerUsername) {
    try {
      log.debug("getCaseFromCapie: Retrieving application with caseId: {},"
              + " brokerUsername: {} and brand: {}.",
          caseId, brokerUsername, brand);
      CaseApplicationDto caseApplicationDto = caseService.getCaseByCaseId(caseId, brand);
      log.debug("getCaseFromCapie: Case with caseId: {}, brokerUsername: {} and brand: {},"
              + "retrieved successfully.",
          caseId, brokerUsername, brand);
      return caseApplicationDto;
    } catch (IntegrationException ex) {
      log.warn(
          "getCaseFromCapie: Caught IntegrationException while calling caseService to get"
              + " case with caseId: {}, brokerUsername: {} and brand: {} - rethrowing",
          caseId, brokerUsername, brand);
      throw ex;
    }
  }

  private Boolean getIsCaseTrackingDisplay(String caseId, String mortgageReferenceNumber, String brand, String brokerUsername) {
    log.debug("getIsCaseTrackingDisplay: Calling caseTrackingService to get application with "
            + "caseId: {}, brokerUsername: {} and brand: {}.",
        caseId, brokerUsername, brand);
    try {
      TrackingApplicationDetailResponse trackingApplicationDetailResponse = caseTrackingService.getApplication(
          brokerUsername, mortgageReferenceNumber, brand);
      log.debug("getIsCaseTrackingDisplay: caseTrackingService successfully called to get "
              + "application with caseId: {}, brokerUsername: {} and brand: {}.",
          caseId, brokerUsername, brand);
      return trackingApplicationDetailResponse != null;
    } catch (ApplicationsServiceException ex) {
      log.error("getIsCaseTrackingDisplay: Caught ApplicationServiceException while calling"
              + " caseTrackingService to get application with caseId: {}, brokerUsername: {}"
              + " and brand: {}.", caseId, brokerUsername, brand);
      return null;
    }
  }

  private DocumentUploadStatus getDocumentUploadStatus(CaseTrackingDocumentResponse applicationDocuments, String caseId, String brokerUsername) {
    log.debug("getDocumentUploadStatus: Checking applicationDocuments to workout document status for "
        + "caseId: {}, Broker username: {}.", caseId, brokerUsername);
    if (applicationDocuments == null) {
      return null;
    }

    if (checkIfStatusDocumentsOutstanding(applicationDocuments, caseId, brokerUsername)) {
      return DocumentUploadStatus.DOCUMENTS_OUTSTANDING;
    } else if(checkIfStatusAssessingDocuments(applicationDocuments, caseId, brokerUsername)) {
      return DocumentUploadStatus.ASSESSING_DOCUMENTS;
    } else if (checkIfStatusDocumentsUploaded(applicationDocuments, caseId, brokerUsername)) {
      return DocumentUploadStatus.DOCUMENTS_UPLOADED;
    } else if (checkIfStatusFurtherInformationRequired(applicationDocuments, caseId, brokerUsername)) {
      return DocumentUploadStatus.FURTHER_INFORMATION_REQUIRED;
    }

    return null;
  }

  private boolean checkIfStatusDocumentsOutstanding(CaseTrackingDocumentResponse applicationDocuments, String caseId, String brokerUsername) {
    log.debug("checkIfStatusDocumentsOutstanding: Checking if document status is DOCUMENT_OUTSTANDING"
        + " for caseId: {}, Broker username: {}.", caseId, brokerUsername);
    return !applicationDocuments.getPackagingStatus().getIsBasicPackagingReceived();
  }

  private boolean checkIfStatusAssessingDocuments(CaseTrackingDocumentResponse applicationDocuments, String caseId, String brokerUsername) {
    log.debug("checkIfStatusDocumentsOutstanding: Checking if document status is ASSESSING_DOCUMENTS"
        + " for caseId: {}, Broker username: {}.", caseId, brokerUsername);
    return applicationDocuments.getPackagingStatus().getIsSIRequested()
        == applicationDocuments.getPackagingStatus().getIsSIReceived() &&
        applicationDocuments.isPST() && !applicationDocuments.isPSTComplete();
  }

  private boolean checkIfStatusDocumentsUploaded(CaseTrackingDocumentResponse applicationDocuments, String caseId, String brokerUsername) {
    log.debug("checkIfStatusDocumentsOutstanding: Checking if document status is DOCUMENTS_UPLOADED"
        + " for caseId: {}, Broker username: {}.", caseId, brokerUsername);
    return !applicationDocuments.getPackagingStatus().getIsSIRequested() ||
        applicationDocuments.getPackagingStatus().getIsSIRequested() && applicationDocuments.getPackagingStatus().getIsSIReceived();
  }

  private boolean checkIfStatusFurtherInformationRequired(CaseTrackingDocumentResponse applicationDocuments, String caseId, String brokerUsername) {
    log.debug("checkIfStatusDocumentsOutstanding: Checking if document status is FURTHER_INFORMATION_REQUIRED"
        + " for caseId: {}, Broker username: {}.", caseId, brokerUsername);
    return !applicationDocuments.getPackagingStatus().getIsSIReceived();
  }
}
