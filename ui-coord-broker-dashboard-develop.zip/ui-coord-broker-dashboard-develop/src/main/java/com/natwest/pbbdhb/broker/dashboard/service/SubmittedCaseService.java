package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.SubmittedCaseDto;

public interface SubmittedCaseService {

    SubmittedCaseDto getSubmittedCase(String caseId, String brand);

}
