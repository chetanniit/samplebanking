package com.natwest.pbbdhb.broker.dashboard.exception;

public class InvalidPasswordException extends RuntimeException{

    public InvalidPasswordException(String userName) {
        super("Invalid password given for user name : "+ userName);
    }
}
