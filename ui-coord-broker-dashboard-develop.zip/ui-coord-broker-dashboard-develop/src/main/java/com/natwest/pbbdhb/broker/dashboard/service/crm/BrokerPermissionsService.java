package com.natwest.pbbdhb.broker.dashboard.service.crm;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.PermissionType;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;

public interface BrokerPermissionsService {
    BrokerPermissionsResponse managePermission(String userName, UserType userType,
                                               PermissionType permissionType);
}
