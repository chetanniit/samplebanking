package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.PageApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.AssociatedBrokerNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.CaseNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.mapper.CaseToPreSubmittedCaseMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.CaseToSubmittedCaseMapper;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.MortgageSummary;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ProductInfo;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus;
import com.natwest.pbbdhb.broker.dashboard.model.search.AndOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.CriteriaDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.OperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.OrOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.OrderDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.QueryDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.SimpleOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.SimpleOperatorDto.CompareType;
import com.natwest.pbbdhb.broker.dashboard.model.search.SortDto;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.ApplicantService;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAccessService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import com.natwest.pbbdhb.broker.dashboard.service.PaymentService;

import com.natwest.pbbdhb.broker.dashboard.util.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUBMIT_FMA_IN_PROGRESS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUBMIT_GMS_MOPS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.BRAND_HEADER_NAME;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.CASE_ID;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.springframework.data.domain.Sort.Direction.DESC;

@Slf4j
@Service
public class CaseServiceImpl implements CaseService {

  private static final int INDEX = 0;
  private static final int ZERO = 0;
  private static final long TOTAL_ELEMENTS = 0L;
  private static final String IS_ESIS = "isEsis";
  private static final String HAS_COMPLETED_DIP = "journeyData.hasCompletedDip";
  private static final String DOCUMENT_URLS = "salesIllustrations.documentUrls";
  private static final String APPLICATION_STATUS = "applicationStatus";
  private static final String SUBMIT_FMA_COMPLETED = "COMPLETED";
  private static final String SEPARATOR = "/";
  private static final String BROKER_USERNAME = "broker.brokerUsername";
  private static final String FCA_NUMBER = "broker.fcaNumber";
  private static final String MODIFIED_DATE = "modifiedDate";
  private static final int ONE = 1;
  private static final int INDEX_ZERO = 0;
  private static final String NO_APPLICABLE_FEES = "No Applicable fees";
  private static final String MORTGAGE_REFERENCE_NUMBER = "mortgageReferenceNumber";
  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
  private static final String SUBMIT_GMS_STAGE_20 = "SUBMIT_GMS_STAGE_20";
  private static final int DEFAULT_NUMBER_OF_RESULTS = 60;
  private final RestTemplate iamJwtChainSecureRestTemplate;
  private final String caseServiceSearchUrl;
  private final String caseServiceGetUrl;
  private final CaseToPreSubmittedCaseMapper caseToPreSubmittedCasesMapper;
  private final ApplicantService applicantService;
  private final Boolean checkForCapiePaymentStatus;
  private final PaymentService paymentService;
  private final UserClaimsProvider userClaimsProvider;
  private final CaseToSubmittedCaseMapper caseToSubmittedCasesMapper;
  private CrmService crmService;
  private final BrokerAccessService brokerAccessService;


  public CaseServiceImpl(
      @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
      @Value("${msvc.case.service.search.url}") String caseServiceSearchUrl,
      @Value("${msvc.case.service.get.url}") String caseServiceGetUrl,
      @Value("${check.for.capie.payment.status}") Boolean checkForCapiePaymentStatus,
      CaseToPreSubmittedCaseMapper caseToPreSubmittedCasesMapper,
      ApplicantService applicantService,
      PaymentService paymentService,
      UserClaimsProvider userClaimsProvider,
      CaseToSubmittedCaseMapper caseToSubmittedCasesMapper,
      CrmService crmService,
      BrokerAccessService brokerAccessService) {
    this.iamJwtChainSecureRestTemplate = iamJwtChainSecureRestTemplate;
    this.caseServiceSearchUrl = caseServiceSearchUrl;
    this.caseServiceGetUrl = caseServiceGetUrl;
    this.caseToPreSubmittedCasesMapper = caseToPreSubmittedCasesMapper;
    this.applicantService = applicantService;
    this.checkForCapiePaymentStatus = checkForCapiePaymentStatus;
    this.paymentService = paymentService;
    this.userClaimsProvider = userClaimsProvider;
    this.caseToSubmittedCasesMapper = caseToSubmittedCasesMapper;
    this.crmService = crmService;
    this.brokerAccessService = brokerAccessService;
  }

  @Override
  public PreSubmittedCases getPreSubmittedCases(String brokerUsername, String fcaNumber, String brand, String page,
      String size, String lastName, String postcode, String dateOfBirth, String type, String status) {

    log.debug(
        "getPreSubmittedCases: Retrieving pre submitted cases for broker: {}.", brokerUsername);

    status = StringUtils.replaceChars(status, '+', ' ');
    List<Applicant> applicants = null;
    CriteriaDto criteriaDto;
    ApplicationType applicationType = Optional.ofNullable(type).map(ApplicationType::valueOf)
        .orElse(null);
    ApplicationStatus applicationStatus = Optional.ofNullable(status)
        .map(ApplicationStatus::fromLabel).orElse(ApplicationStatus.NONE);

    // when applicant filters are applied, fetch applicants first
    if (isNotEmpty(lastName) || isNotEmpty(postcode) || isNotEmpty(dateOfBirth)) {
      log.debug(
          "getPreSubmittedCases: Calling applicant service with filters - lastName: {}, postcode: {},"
              + " dateOfBirth: {}.", lastName, postcode, dateOfBirth);
      try {
        applicants = applicantService.getApplicants(lastName, postcode, dateOfBirth, brand);
        log.debug("getPreSubmittedCases: Number of applicants found: {}", applicants.size());
      } catch (ApplicantNotFoundException applicantNotFoundException) {
        log.debug("getPreSubmittedCases: No applicants found!");
        return emptyCaseResult();
      }

      if (applicants == null || applicants.isEmpty()) {
        return emptyCaseResult();
      }

      List<String> caseIdsFromApplicants = applicants.stream()
          .map(Applicant::getCaseId)
          .collect(Collectors.toList());
      criteriaDto = createBrokerCriteria(brokerUsername, fcaNumber, applicationType, applicationStatus,
          caseIdsFromApplicants);
    } else {
      criteriaDto = createBrokerCriteria(brokerUsername, fcaNumber, applicationType, applicationStatus, null);
    }

    PageApplicationDto response = callCaseSearchService(brokerUsername, brand, page, size,
        criteriaDto);

    if (response == null) {
      return emptyCaseResult();
    }

    List<CaseApplication> cases = response.getContent();
    Map<String, CaseApplication> casesMap = cases.stream().collect(Collectors.
        toMap(CaseApplication::getCaseId, caseApplication -> caseApplication));

    // when no filtering by applicant details - fetch applicants for case IDs
    if (!(isNotEmpty(lastName) || isNotEmpty(postcode) || isNotEmpty(dateOfBirth))) {
      Set<String> caseIds = casesMap.keySet();
      log.debug("getPreSubmittedCases: Calling applicant service for caseIds {}.", caseIds);
      try {
        applicants = applicantService.getApplicants(caseIds, brand);
        log.debug("getPreSubmittedCases: Number of applicants found: {}", applicants.size());
      } catch (ApplicantNotFoundException applicantNotFoundException) {
        log.debug("getPreSubmittedCases: No applicants found!");
        return emptyCaseResult();
      }
    }

    PreSubmittedCases preSubmittedCases = mapPreSubmittedCases(casesMap, applicants, response);
    log.debug("getPreSubmittedCases: Case search completed for brokerUsername - {}", brokerUsername);

    return preSubmittedCases;
  }
  @Override
  public SubmittedCases getSubmittedCases(String brokerUsername, String fcaNumber, String brand, String page,
      String size, String mortgageRefNumber, String lastName, String postcode, String dateOfBirth) {

    boolean requestedBrokerIsAccessible = brokerAccessService.checkRequestedBrokerHasAccess(brokerUsername);

    if (!requestedBrokerIsAccessible) {
        throw new AssociatedBrokerNotFoundException(400, ErrorCodes.NO_ACCESS_TO_BROKER, "No access to the broker");
    }

    log.debug(
        "getSubmittedCases: Retrieving submitted cases for broker: {}.",
        brokerUsername);

    List<Applicant> applicants = null;
    CriteriaDto criteriaDto;
    boolean optionalCriteriaPresent = isOptionalCriteriaPresent(lastName, postcode, dateOfBirth);

    // when applicant filters are applied, fetch applicants first
    if (optionalCriteriaPresent) {
      log.debug(
          "getSubmittedCases: Calling applicant service with filters - lastName: {}, postcode: {},"
              + " dateOfBirth: {} for Broker: {}.", lastName, postcode, dateOfBirth, brokerUsername);
      try {
        applicants = applicantService.getApplicants(lastName, postcode, dateOfBirth, brand);
      } catch (ApplicantNotFoundException applicantNotFoundException) {
        return emptySubmittedCaseResult();
      }
      if (applicants == null || applicants.isEmpty() || applicants.size() < 1 ) {
        log.debug("getSubmittedCases: No applicants found for Broker: {}.",brokerUsername);
        return emptySubmittedCaseResult();
      }

      Set<String> caseIdsFromApplicants = applicants.stream()
          .map(Applicant::getCaseId)
          .collect(Collectors.toSet());
      log.debug("getSubmittedCases: {} applicants found for {} cases for broker {}.",
          applicants.size(), caseIdsFromApplicants.size(), brokerUsername);

      criteriaDto = createBrokerCriteriaForSubmittedCase(brokerUsername, fcaNumber, mortgageRefNumber, caseIdsFromApplicants);
    } else {
      criteriaDto = createBrokerCriteriaForSubmittedCase(brokerUsername, fcaNumber, mortgageRefNumber, null);
    }

    PageApplicationDto caseSearchResponse = callCaseSearchService(brokerUsername, brand, page, size,
        criteriaDto);

    if (caseSearchResponse != null && !optionalCriteriaPresent && caseSearchResponse.getTotalElements() > DEFAULT_NUMBER_OF_RESULTS) {
      log.debug("getSubmittedCases: Total number of cases in response: {}, limited to 60.",
          caseSearchResponse.getTotalElements());
      caseSearchResponse = new PageApplicationDto(caseSearchResponse.getContent(),
          PageRequest.of(Integer.parseInt(page), Integer.parseInt(size)), DEFAULT_NUMBER_OF_RESULTS);
    }

    if (caseSearchResponse == null || caseSearchResponse.getTotalElements() < 1) {
      log.debug("getSubmittedCases: No cases found for Broker: {}.", brokerUsername);
      return emptySubmittedCaseResult();
    }

    List<CaseApplication> cases = caseSearchResponse.getContent();

    Map<String, CaseApplication> casesMap = cases.stream().collect(Collectors.
        toMap(CaseApplication::getCaseId, caseApplication -> caseApplication));

    // when no filtering by applicant details - fetch applicants for case IDs
    if (!optionalCriteriaPresent) {
      Set<String> caseIds = casesMap.keySet();
      log.debug("getSubmittedCases: Calling applicant service for caseIds: {}.", caseIds);
      try {
        applicants = applicantService.getApplicants(caseIds, brand);
        log.debug("getSubmittedCases: Number of applicants found: {}", applicants.size());
      } catch (ApplicantNotFoundException applicantNotFoundException) {
        log.debug("getSubmittedCases: No applicants found for Broker: {}.", brokerUsername);
        return emptySubmittedCaseResult();
      }
      if (applicants == null || applicants.isEmpty() || applicants.size() < 1) {
        log.debug("getSubmittedCases: No applicants found for Broker: {}.",brokerUsername);
        return emptySubmittedCaseResult();
      }
    }
    SubmittedCases submittedCases = mapSubmittedCases(casesMap, applicants, caseSearchResponse);
    log.debug("getSubmittedCases: {} submittedCases found for broker: {}.",
        submittedCases.getSubmittedCases().size(), brokerUsername);

    return submittedCases;
  }

  private boolean checkRequestedBrokerHasAccess(String brokerUsername) {
    String loggedInUserName = userClaimsProvider.getBrokerUsername();
    BrokerType brokerType = userClaimsProvider.getBrokerType();
    if (brokerUsername.equals(loggedInUserName)) {
      log.debug("checkRequestedBrokerHasAccess: Logged-in broker matches the requested broker: {}.",
          brokerUsername);
      return true;
    }

    if (!BrokerType.ADMIN.equals(brokerType)) {
      log.debug("checkRequestedBrokerHasAccess: Requested broker: {}, is not accessible for logged-in "
          + "broker: {}.", brokerUsername, loggedInUserName);
      return false;
    }
    AdminAssociationsResponse adminAssociationsResponse = crmService.getAdminAssociations(loggedInUserName);

    List<String> associatedBrokers = adminAssociationsResponse.getBrokers().stream()
        .map(AssociatedBrokerDetails::getUserName)
        .collect(Collectors.toList());

    if(associatedBrokers == null || associatedBrokers.isEmpty()) {
      log.debug("checkRequestedBrokerHasAccess: Associated Brokers not found for Admin broker: {}.",
          loggedInUserName);
      return false;
    }

    if (associatedBrokers.contains(brokerUsername)) {
      log.debug("checkRequestedBrokerHasAccess: Broker: {} is associated with Admin: {}.",
          brokerUsername, loggedInUserName);
      return true;
    }
    log.debug("checkRequestedBrokerHasAccess: Associated Brokers not found for Admin: {}.", loggedInUserName);
    return false;
  }

  private boolean isOptionalCriteriaPresent(String lastName, String postcode, String dateOfBirth) {
    return isNotEmpty(lastName) || isNotEmpty(postcode) || isNotEmpty(dateOfBirth);
  }

  private CriteriaDto createBrokerCriteriaForSubmittedCase(String brokerUsername, String fcaNumber,
      String mortgageRefNumber, Set<String> caseIds) {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    // broker operator
    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ_IGNORE_CASE)
        .field(BROKER_USERNAME)
        .value(brokerUsername)
        .build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    // fcaNumber operator
    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(FCA_NUMBER)
        .value(fcaNumber)
        .build();
    mainQueryAndOperators.add(equalToFcaNumber);

    // mortgageRefNumber operator
    if (mortgageRefNumber != null) {
      SimpleOperatorDto equalMortgageRefNumber = SimpleOperatorDto
          .builder()
          .compareType(CompareType.EQ_IGNORE_CASE)
          .field(MORTGAGE_REFERENCE_NUMBER)
          .value(mortgageRefNumber)
          .build();
      mainQueryAndOperators.add(equalMortgageRefNumber);
    }

    // mortgageRefNumber not empty operator
    SimpleOperatorDto notEmptyMortgageReferenceNumberOperator = SimpleOperatorDto
          .builder()
          .compareType(CompareType.LIKE)
          .field(MORTGAGE_REFERENCE_NUMBER)
          .value("")
          .build();
    mainQueryAndOperators.add(notEmptyMortgageReferenceNumberOperator);

    SimpleOperatorDto operatorFmaApplicationStatusSubmitGmsMops = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_GMS_MOPS)
        .build();

    SimpleOperatorDto operatorFmaApplicationStatusSubmitGmsMops20 = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_GMS_STAGE_20)
        .build();

    List<OperatorDto> orOperators = new ArrayList<>();
    orOperators.add(operatorFmaApplicationStatusSubmitGmsMops);
    orOperators.add(operatorFmaApplicationStatusSubmitGmsMops20);

    OrOperatorDto orOperator = OrOperatorDto.builder()
        .operators(orOperators)
        .build();
    mainQueryAndOperators.add(orOperator);

    // logic for case ids (from Applicant)
    if (!CollectionUtils.isEmpty(caseIds)) {
      OperatorDto caseIdsOperator = SimpleOperatorDto.builder()
          .compareType(CompareType.IN)
          .field("_id")
          .values(caseIds)
          .build();
      mainQueryAndOperators.add(caseIdsOperator);
    }

    // main query
    AndOperatorDto mainQueryAndOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder()
            .field(MODIFIED_DATE)
            .direction(DESC.name())
            .build());
    SortDto sortDto = SortDto.builder()
        .orders(orders)
        .build();

    QueryDto query = QueryDto.builder()
        .operator(mainQueryAndOperator)
        .build();

    return CriteriaDto.builder()
        .query(query)
        .sort(sortDto)
        .build();
  }

  private SubmittedCases mapSubmittedCases(Map<String, CaseApplication> casesMap,
      List<Applicant> applicants,
      PageApplicationDto caseSearchResponse) {

    log.debug("mapSubmittedCases: Mapping submitted cases...");

    SubmittedCases submittedCases = new SubmittedCases();
    submittedCases.setTotalPages(caseSearchResponse.getTotalPages());
    submittedCases.setSize(caseSearchResponse.getSize());
    submittedCases.setNumber(caseSearchResponse.getNumber());
    submittedCases.setTotalElements(caseSearchResponse.getTotalElements());
    List<SubmittedCase> submittedCasesList = new ArrayList<>();

    log.debug("mapSubmittedCases: Found applicants for submitted cases in applicant api.");
    Map<String, List<Applicant>> applicantsMap = getApplicantsMap(applicants);
    List<CaseApplication> cases = caseSearchResponse.getContent();
    cases.forEach(caseApplication -> {
      if(caseApplication.getMortgageReferenceNumber() != null) {
        SubmittedCase submittedCase = caseToSubmittedCasesMapper.toSubmittedCase(
            casesMap.get(caseApplication.getCaseId()),
            applicantsMap.get(caseApplication.getCaseId()));
        submittedCasesList.add(submittedCase);
      }
    });
    submittedCases.setSubmittedCases(submittedCasesList);

    log.debug("mapSubmittedCases: Submitted cases successfully mapped.");
    return submittedCases;
  }

  private PageApplicationDto callCaseSearchService(String brokerUsername, String brand,
      String page, String size, CriteriaDto criteria) {
    String url = UriComponentsBuilder.fromHttpUrl(caseServiceSearchUrl)
        .queryParam("page", page)
        .queryParam("size", size).toUriString();
    ParameterizedTypeReference<Page<CaseSearchResponse>> responseType =
        new ParameterizedTypeReference<Page<CaseSearchResponse>>() {
        };
    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    headers.add(BRAND_HEADER_NAME, brand);
    log.debug("callCaseSearchService: Calling case search on url {} to get case details on brand: {}.",
        url, brand);
    log.debug("callCaseSearchService: Calling case search with headers: " + headers);
    HttpEntity<CriteriaDto> httpEntity = new HttpEntity<>(criteria, headers);
    ResponseEntity<PageApplicationDto> dtoResponseEntity;
    try {
      dtoResponseEntity = iamJwtChainSecureRestTemplate.exchange(
          url,
          HttpMethod.POST, httpEntity, PageApplicationDto.class);
    } catch (RestClientException e) {
      log.debug("callCaseSearchService: Error when calling Case Search service!", e);
      throw e;
    }
    PageApplicationDto response = dtoResponseEntity.getBody();
    if (Objects.isNull(response) || Objects.isNull(response.getContent())
        || response.getContent().size() < ONE
        || ObjectUtils.isEmpty(response.getContent().get(INDEX))) {

      log.debug("callCaseSearchService: No case records found for broker: {}.", brokerUsername);
      return null;
    } else {
      log.debug("callCaseSearchService: {} Case records returned for broker: {}.",
          response.getContent().size(), brokerUsername);
      return response;
    }
  }

  private CriteriaDto createBrokerCriteria(String brokerUsername, String fcaNumber,
      ApplicationType type, ApplicationStatus status, List<String> caseIds) {

    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    // broker operator
    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ_IGNORE_CASE)
        .field(BROKER_USERNAME)
        .value(brokerUsername)
        .build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    // FCA number operator
    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(FCA_NUMBER)
        .value(fcaNumber)
        .build();

    // FMA operators
    SimpleOperatorDto operatorFmaApplicationStatusFmaInProgressNotSubmittedToGMS = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS)
        .build();

    SimpleOperatorDto operatorFmaApplicationStatusSubmitGmsMops = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_GMS_MOPS)
        .build();

    SimpleOperatorDto operatorFmaApplicationStatusFmaInProgress = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_FMA_IN_PROGRESS)
        .build();

    SimpleOperatorDto operatorForEmptyList = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_FMA_COMPLETED)
        .build();

    OrOperatorDto operatorForFmaSubmissionInProgress = OrOperatorDto.builder()
        .operators(Arrays.asList(
            operatorFmaApplicationStatusSubmitGmsMops,
            operatorFmaApplicationStatusFmaInProgress))
        .build();

    OrOperatorDto operatorForFmaStatusAll = OrOperatorDto.builder()
        .operators(Arrays.asList(
            operatorFmaApplicationStatusFmaInProgressNotSubmittedToGMS,
            operatorFmaApplicationStatusSubmitGmsMops,
            operatorFmaApplicationStatusFmaInProgress
        ))
        .build();

    // AIP operators
    SimpleOperatorDto operatorForAipIsNullEsis = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(IS_ESIS)
        .build();

    SimpleOperatorDto operatorForAipIsNotEsis = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(IS_ESIS)
        .value(Boolean.FALSE.toString())
        .build();

    SimpleOperatorDto operatorForAipNullApplicationStatus = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(APPLICATION_STATUS)
        .build();

    SimpleOperatorDto operatorForAipHasCompletedDipTrue = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(HAS_COMPLETED_DIP)
        .value(Boolean.TRUE.toString())
        .build();

    SimpleOperatorDto operatorForAipHasCompletedDipFalse = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(HAS_COMPLETED_DIP)
        .value(Boolean.FALSE.toString())
        .build();

    SimpleOperatorDto operatorForAipHasCompletedDipNull = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(HAS_COMPLETED_DIP)
        .build();

    OrOperatorDto aipTypeNotHasCompletedEsisOrOperator = OrOperatorDto.builder()
        .operators(
            Arrays.asList(operatorForAipHasCompletedDipNull, operatorForAipHasCompletedDipFalse))
        .build();

    OrOperatorDto aipTypeNotEsisOrOperator = OrOperatorDto.builder()
        .operators(Arrays.asList(operatorForAipIsNullEsis, operatorForAipIsNotEsis))
        .build();

    // ESIS operators
    SimpleOperatorDto operatorForEsisIsEsis = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(IS_ESIS)
        .value(Boolean.TRUE.toString())
        .build();

    SimpleOperatorDto operatorForEsisDocumentUrlsEmpty = SimpleOperatorDto
        .builder()
        .compareType(CompareType.EQ)
        .field(DOCUMENT_URLS)
        .build();

    SimpleOperatorDto operatorForEsisDocumentUrlsPresent = SimpleOperatorDto
        .builder()
        .compareType(CompareType.LIKE)
        .field(DOCUMENT_URLS)
        .value("http")
        .build();

    // Logic for type and status
    if (type == ApplicationType.FMA) {
      mainQueryAndOperators.add(equalToFcaNumber);
      switch (status) {
        case IN_PROGRESS:
          mainQueryAndOperators.add(operatorFmaApplicationStatusFmaInProgressNotSubmittedToGMS);
          break;
        case SUBMISSION_IN_PROGRESS:
          mainQueryAndOperators.add(operatorForFmaSubmissionInProgress);
          break;
        case COMPLETED:
          mainQueryAndOperators.add(operatorForEmptyList);
          break;
        default:
          mainQueryAndOperators.add(operatorForFmaStatusAll);
          break;
      }
    } else if (type == ApplicationType.AIP) {
      mainQueryAndOperators.add(equalToFcaNumber);
      switch (status) {
        case IN_PROGRESS:
          mainQueryAndOperators.add(aipTypeNotEsisOrOperator);
          mainQueryAndOperators.add(operatorForAipNullApplicationStatus);
          mainQueryAndOperators.add(aipTypeNotHasCompletedEsisOrOperator);
          break;
        case SUBMISSION_IN_PROGRESS:
          mainQueryAndOperators.add(operatorForEmptyList);
          break;
        case COMPLETED:
          mainQueryAndOperators.add(aipTypeNotEsisOrOperator);
          mainQueryAndOperators.add(operatorForAipNullApplicationStatus);
          mainQueryAndOperators.add(operatorForAipHasCompletedDipTrue);
          break;
        default:
          mainQueryAndOperators.add(aipTypeNotEsisOrOperator);
          mainQueryAndOperators.add(operatorForAipNullApplicationStatus);
          break;
      }
    } else if (type == ApplicationType.ESIS) {
      List<OperatorDto> andOperators = new ArrayList<>();
      switch (status) {
        case IN_PROGRESS:
          andOperators.add(operatorForEsisIsEsis);
          andOperators.add(operatorForEsisDocumentUrlsEmpty);
          break;
        case SUBMISSION_IN_PROGRESS:
          andOperators.add(operatorForEmptyList);
          break;
        case COMPLETED:
          andOperators.add(operatorForEsisIsEsis);
          andOperators.add(operatorForEsisDocumentUrlsPresent);
          break;
        default:
          andOperators.add(operatorForEsisIsEsis);
          break;
      }
      mainQueryAndOperators.addAll(andOperators);
    } else {
      // previous logic applied when no FMA filter
      List<OperatorDto> orOperatorsNonEsis = new ArrayList<>();
      orOperatorsNonEsis.add(operatorFmaApplicationStatusSubmitGmsMops);
      orOperatorsNonEsis.add(operatorFmaApplicationStatusFmaInProgressNotSubmittedToGMS);
      orOperatorsNonEsis.add(operatorFmaApplicationStatusFmaInProgress);
      orOperatorsNonEsis.add(operatorForAipNullApplicationStatus);
      List<OperatorDto> orOperators = new ArrayList<>();
      OrOperatorDto orOperatorNonEsis = OrOperatorDto.builder()
          .operators(orOperatorsNonEsis)
          .build();
      List<OperatorDto> andOperatorsNonEsis = new ArrayList<>();
      andOperatorsNonEsis.add(equalToFcaNumber);
      andOperatorsNonEsis.add(orOperatorNonEsis);
      AndOperatorDto andOperatorNonEsis = AndOperatorDto.builder()
          .operators(andOperatorsNonEsis)
          .build();
      orOperators.add(andOperatorNonEsis);
      orOperators.add(operatorForEsisIsEsis);
      OrOperatorDto orOperator = OrOperatorDto.builder()
          .operators(orOperators)
          .build();
      mainQueryAndOperators.add(orOperator);
    }

    // logic for case ids (from Applicant)
    if (!CollectionUtils.isEmpty(caseIds)) {
      OperatorDto caseIdsOperator = SimpleOperatorDto.builder()
          .compareType(CompareType.IN)
          .field("_id")
          .values(Sets.newHashSet(caseIds))
          .build();
      mainQueryAndOperators.add(caseIdsOperator);
    }

    // main query
    AndOperatorDto mainQueryAndOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder()
            .field(MODIFIED_DATE)
            .direction(DESC.name())
            .build());
    SortDto sortDto = SortDto.builder()
        .orders(orders)
        .build();

    QueryDto query = QueryDto.builder()
        .operator(mainQueryAndOperator)
        .build();

    return CriteriaDto.builder()
        .query(query)
        .sort(sortDto)
        .build();
  }

  @Override
  public void getCaseDetails(String mortgageRefNumber, String brand,
      TrackingApplicationDetailResponse applicationDetailsResponse) {

    log.debug("getCaseDetails: Retrieving case details for for mortgageRefNumber: {} "
            + "and brand: {}.", mortgageRefNumber, brand);
    ProductInfo productInfo = applicationDetailsResponse.getProductInfo();
    MortgageSummary mortgageSummary = applicationDetailsResponse.getMortgageSummary();

    try {

      CaseSearchResponse response = getCaseSearchByMortgageRefNumber(mortgageRefNumber, brand);
      CaseApplication caseApplication = response.getContent().get(INDEX_ZERO);
      String mafDocumentUrl = caseApplication.getMafDocumentUrl();
      String fileName = StringUtils.substringAfterLast(mafDocumentUrl, SEPARATOR);
      Boolean isFmaComplete = isNotBlank(fileName);
      mortgageSummary.setIsFmaComplete(isFmaComplete);
      mortgageSummary.setApplicationType(
          com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ApplicationType.NAPOLI);
      if (isFmaComplete) {
        mortgageSummary.setMafDocumentName(fileName);
      }
      if (checkForCapiePaymentStatus) {
        if (paymentService.isValidPaymentRequest(caseApplication)) {
          productInfo.setIsFeePaymentComplete(paymentService.isPaymentMade(caseApplication));
          productInfo.setPaymentTileStatus(StringUtils.EMPTY);
        } else {
          productInfo.setIsFeePaymentComplete(Boolean.FALSE);
          productInfo.setPaymentTileStatus(NO_APPLICABLE_FEES);
        }
      }

    } catch (CaseNotFoundException ex) {
      log.debug("getCaseDetails: No case record returned for mortgageRefNumber: {} "
          + "and brand: {}.", mortgageRefNumber, brand);
      log.debug(
          "getCaseDetails: Assuming that this case is either old case or came from other than"
              + " Napoli portal like Focus etc");

      productInfo.setIsFeePaymentComplete(Boolean.FALSE);
      productInfo.setPaymentTileStatus(NO_APPLICABLE_FEES);
      mortgageSummary.setIsFmaComplete(Boolean.FALSE);
      mortgageSummary.setApplicationType(
          com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ApplicationType.LEGACY);
    }

  }

  @Override
  public CaseSearchResponse getCaseSearchByMortgageRefNumber(String mortgageRefNumber,
      String brand) {
    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    headers.add(BRAND_HEADER_NAME, brand);
    log.debug(
        "getCaseSearchByMortgageRefNumber: Calling case search on url {} to get case details for mortgage "
            + "reference number: {} and brand: {}.", caseServiceSearchUrl, mortgageRefNumber, brand);
    log.debug("getCaseSearchByMortgageRefNumber: Calling case search with Headers: " + headers);
    SimpleOperatorDto simpleOperator = SimpleOperatorDto.builder().
        compareType(CompareType.EQ).field("mortgageReferenceNumber").
        value(mortgageRefNumber).build();
    QueryDto query = QueryDto.builder().operator(simpleOperator).build();
    CriteriaDto criteria = CriteriaDto.builder().query(query).build();
    HttpEntity<CriteriaDto> httpEntity = new HttpEntity<>(criteria, headers);
    CaseSearchResponse response =
        iamJwtChainSecureRestTemplate.postForObject(caseServiceSearchUrl, httpEntity,
            CaseSearchResponse.class);
    if (Objects.isNull(response) || Objects.isNull(response.getContent())
        || response.getContent().size() < ONE
        || ObjectUtils.isEmpty(response.getContent().get(INDEX_ZERO))) {
      log.debug("getCaseSearchByMortgageRefNumber: No case record returned for mortgageRefNumber: {}"
          + " and brand: {}.", mortgageRefNumber, brand);
      throw new CaseNotFoundException("getCaseSearchByMortgageRefNumber: No case record returned");
    }
    log.debug("getCaseSearchByMortgageRefNumber: Case search for mortgage reference number: {},"
        + " brand: {} successfully completed.", mortgageRefNumber, brand);
    return response;
  }

  @Override
  public CaseApplicationDto getCaseByCaseId(String caseId, String brand) {
    UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(caseServiceGetUrl);
    Map<String, Object> uriVariables = new HashMap<>();
    uriVariables.put(CASE_ID, caseId);
    builder.uriVariables(uriVariables);
    URI url = builder.build().toUri();
    log.debug("getCaseByCaseId: Calling {} to get case with caseId {}.", url, caseId);

    try {
      CaseApplicationDto caseApplicationDto = iamJwtChainSecureRestTemplate.exchange(
          url,
          HttpMethod.GET,
          new HttpEntity<>(AppUtil.buildBrandAndContentTypeHeaders(brand, MediaType.APPLICATION_JSON_VALUE)),
          CaseApplicationDto.class).getBody();
      if (Objects.isNull(caseApplicationDto)) {
        log.debug("getCaseByCaseId: No case record returned for caseId {} and brand {} - throwing"
                + " CaseNotFoundException",
            caseId, brand);
        throw new CaseNotFoundException("getCaseByCaseId: No case record returned");
      }
      if(Objects.isNull(caseApplicationDto.getMortgageReferenceNumber()) && Objects.isNull(caseApplicationDto.getMortgageTempReferenceNumber())) {
        log.debug("getCaseByCaseId: Case returned for caseId {} and brand {} has null"
                + " mortgageReferenceNumber and mortgageTempReferenceNumber - throwing"
                + " CaseNotFoundException", caseId, brand);
        throw new IntegrationException("getCaseByCaseId: Case returned with null "
            + "mortgageReferenceNumber and mortgageTempReferenceNumber");
      }
      log.debug("getCaseByCaseId: Case with caseId {} successfully retrieved", caseId);
      return caseApplicationDto;
    } catch (IntegrationException ex) {
      log.warn("getCaseByCaseId: Inside CaseService: Caught IntegrationException for"
              + " caseId {}: {} - rethrowing", caseId, ex.getMessage());
      throw ex;
    } catch (CaseNotFoundException | RestClientException ex) {
      log.warn("getCaseByCaseId: A {} occurred while calling {} to get case with caseId {}: {}",
          ex.getClass().getSimpleName(), url, caseId, ex.getMessage());
      throw new IntegrationException(ex.getMessage());
    } catch (Throwable t) {
      String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
      log.warn("getCaseByCaseId: An unexpected exception occurred while calling {} to get case"
              + " with caseId {}: {}", url, caseId, message);
      throw t;
    }
  }

  private PreSubmittedCases mapPreSubmittedCases(Map<String, CaseApplication> casesMap,
      List<Applicant> applicants,
      PageApplicationDto response) {
    log.debug("mapPreSubmittedCases: Mapping pre submitted cases...");
    PreSubmittedCases preSubmittedCases = new PreSubmittedCases();
    preSubmittedCases.setTotalPages(response.getTotalPages());
    preSubmittedCases.setSize(response.getSize());
    preSubmittedCases.setNumber(response.getNumber());
    preSubmittedCases.setTotalElements(response.getTotalElements());
    List<PreSubmittedCase> preSubmittedCasesList = new ArrayList<>();

    if (ObjectUtils.isNotEmpty(applicants)) {
      log.debug("mapPreSubmittedCases: Found applicants for pre submitted cases in applicant api.");
      Map<String, List<Applicant>> applicantsMap = getApplicantsMap(applicants);
      List<CaseApplication> cases = response.getContent();
      cases.forEach(caseApplication -> {
        PreSubmittedCase preSubmittedCase = caseToPreSubmittedCasesMapper.toPreSubmittedCase(
            casesMap.get(caseApplication.getCaseId()),
            applicantsMap.get(caseApplication.getCaseId()));
        if (Objects.nonNull(preSubmittedCase)) {
          preSubmittedCasesList.add(preSubmittedCase);
        }
      });
      preSubmittedCases.setPreSubmittedCases(preSubmittedCasesList);
    }
    log.debug("mapPreSubmittedCases: Pre submitted cases successfully mapped.");
    return preSubmittedCases;
  }


  private Map<String, List<Applicant>> getApplicantsMap(List<Applicant> applicants) {

    log.debug("getApplicantsMap: Retrieving applicants map...");
    Map<String, List<Applicant>> applicantsMap = new HashMap<>();
    applicants.stream().forEach(applicant -> {
      String applicantCaseId = applicant.getCaseId();
      List<Applicant> caseApplicants = applicantsMap.get(applicantCaseId);
      if (caseApplicants == null) {
        caseApplicants = new ArrayList<>();
        applicantsMap.put(applicantCaseId, caseApplicants);
      }
      caseApplicants.add(applicant);
    });
    log.debug("getApplicantsMap: Applicants map successfully retrieved, number of applicants"
        + " found {}.", applicantsMap.size());
    return applicantsMap;
  }

  private PreSubmittedCases emptyCaseResult() {
    log.debug("emptyCaseResult: Retrieving empty pre submitted case.");
    return PreSubmittedCases.builder()
        .preSubmittedCases(Collections.EMPTY_LIST)
        .totalPages(ZERO)
        .totalElements(TOTAL_ELEMENTS)
        .size(ZERO)
        .number(ZERO)
        .build();
  }

  private SubmittedCases emptySubmittedCaseResult() {
    log.debug("emptySubmittedCaseResult: Retrieving empty submitted case.");
    return SubmittedCases.builder()
        .submittedCases(Collections.EMPTY_LIST)
        .totalPages(ZERO)
        .totalElements(TOTAL_ELEMENTS)
        .size(ZERO)
        .number(ZERO)
        .build();

  }
}