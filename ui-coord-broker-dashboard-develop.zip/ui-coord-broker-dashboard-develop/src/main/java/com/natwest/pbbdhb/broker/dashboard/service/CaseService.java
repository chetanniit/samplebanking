package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseSearchResponse;

public interface CaseService {
    PreSubmittedCases getPreSubmittedCases(String brokerUsername, String fcaNumber, String brand, String page, String size, String lastName, String postcode, String dateOfBirth, String type, String status);
    SubmittedCases getSubmittedCases(String brokerUsername, String fcaNumber, String brand, String page, String size, String mortgageRefNumber, String lastName, String postcode, String dateOfBirth);
    void getCaseDetails(String mortgageRefNumber, String brand, TrackingApplicationDetailResponse response);
    CaseSearchResponse getCaseSearchByMortgageRefNumber(String mortgageRefNumber, String brand);
    CaseApplicationDto getCaseByCaseId(String caseId, String brand);
}
