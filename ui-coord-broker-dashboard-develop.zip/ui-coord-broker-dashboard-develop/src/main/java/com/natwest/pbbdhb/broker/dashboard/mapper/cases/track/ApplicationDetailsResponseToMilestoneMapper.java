package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.HistoryDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.StageHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.AssessmentMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CancelledDeclinedMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CompletionMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.Milestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.Milestones;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.OfferMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.Update;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ValuationHistory;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ValuationMilestone;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT_WITHOUT_T;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.GREEN_RAG_STATUS;

@Slf4j
@Mapper(config = SpringMapperConfig.class, injectionStrategy = InjectionStrategy.FIELD)
public abstract class ApplicationDetailsResponseToMilestoneMapper {

    @Autowired
    private ValuationDetailToValuationInformationMapper valuationDetailToValuationInformationMapper;
    @Autowired
    private ApplicationDetailsToPropertyInformationMapper applicationDetailsToPropertyInformationMapper;

    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT_WITHOUT_T);
    private final static String ACTION_REQUIRED = "Action required";
    private final static String NO_ACTION_REQUIRED = "No Action required";
    private final static String VALUATION = "Valuation";
    private final static String ASSESSMENT = "Assessment";
    private final static String OFFER = "Offer";
    private final static String COMPLETION = "Completion";
    private final static String RED_RAG_STATUS = "RED";
    private final static String AMBER_RAG_STATUS = "AMBER";
    private final static String GREY_RAG_STATUS = "GREY";
    private final static String NULL_RAG_STATUS = "NULL_RAG_STATUS";
    private final static String CANCELLED = "Cancelled";
    private final static String IN_PROGRESS = "In Progress";
    private final static String COMPLETED = "Completed";
    private final static String NOT_STARTED = "Not Started";
    private final static String DECLINED_CANCELLED = "Declined/Cancelled";
    private final static String CANCELLED_DECLINED = "Cancelled/Declined";

    @Mapping(target = "valuation", source = ".", qualifiedByName = "getValuation")
    @Mapping(target = "assessment", source = ".", qualifiedByName = "getAssessment")
    @Mapping(target = "offer", source = ".", qualifiedByName = "getOffer")
    @Mapping(target = "completion", source = ".", qualifiedByName = "getCompletion")
    @Mapping(target = "cancelledDecline", source = ".", qualifiedByName = "getCancelledDecline")
    public abstract Milestones toMilestones(ApplicationDetailsResponse applicationDetailsResponse);

    @Named("getValuation")
    public ValuationMilestone getValuation(ApplicationDetailsResponse applicationDetailsResponse) {
        ValuationMilestone valuationMileStone = null;
        StageHistoryDetail stageHistoryDetail =
                getMatchedStageHistoryDetail(applicationDetailsResponse.getApplicationDetails(), VALUATION);
        if (Objects.nonNull(stageHistoryDetail)) {
            valuationMileStone = ValuationMilestone.builder().build();
            populateMilestoneData(stageHistoryDetail, VALUATION, valuationMileStone);

            valuationMileStone.setValuationInformation(valuationDetailToValuationInformationMapper
                    .toValuationInformation(applicationDetailsResponse.getValuationInformation()));
            valuationMileStone.setPropertyInformation(applicationDetailsToPropertyInformationMapper
                    .toPropertyInformation(applicationDetailsResponse));

            setUpdates(valuationMileStone, stageHistoryDetail);

            if (Objects.nonNull(applicationDetailsResponse.getValuationInformation())) {
                log.info("Setting valuation information updates on milestone.");
                List<ValuationHistoryDetail> valuationHistoryDetails = applicationDetailsResponse
                        .getValuationInformation().getDetails();
                List<Update> valuationHistory = valuationHistoryDetails.stream().map(valuationHistoryDetail ->
                        Update.builder().description(valuationHistoryDetail.getStatusDescription())
                                .dateTime(getFormattedDateTime(valuationHistoryDetail.getDate())).build()).collect(Collectors.toList());
                valuationMileStone.setValuationHistory(ValuationHistory.builder().updates(valuationHistory).build());
            }
        }
        return valuationMileStone;
    }

    @Named("getOffer")
    public OfferMilestone getOffer(ApplicationDetailsResponse applicationDetailsResponse) {
        OfferMilestone offerMilestone = null;
        StageHistoryDetail stageHistoryDetail =
                getMatchedStageHistoryDetail(applicationDetailsResponse.getApplicationDetails(), OFFER);
        if (Objects.nonNull(stageHistoryDetail)) {
            offerMilestone = OfferMilestone.builder().build();
            populateMilestoneData(stageHistoryDetail, OFFER, offerMilestone);

            List<Update> actionRequired = stageHistoryDetail.getRequiredActions().stream()
                    .map(requiredActionDetail -> Update.builder().description(requiredActionDetail.getDescription())
                            .dateTime(getFormattedDateTime(requiredActionDetail.getTimeOpen())).build()).collect(Collectors.toList());
            offerMilestone.setActionRequired(actionRequired);

            setUpdates(offerMilestone, stageHistoryDetail);
        }
        return offerMilestone;
    }

    @Named("getCompletion")
    public CompletionMilestone getCompletion(ApplicationDetailsResponse applicationDetailsResponse) {
        CompletionMilestone completionMilestone = null;
        StageHistoryDetail stageHistoryDetail =
                getMatchedStageHistoryDetail(applicationDetailsResponse.getApplicationDetails(), COMPLETION);
        if (Objects.nonNull(stageHistoryDetail)) {
            completionMilestone = CompletionMilestone.builder().build();
            populateMilestoneData(stageHistoryDetail, COMPLETION, completionMilestone);

            List<Update> actionRequired = stageHistoryDetail.getRequiredActions().stream()
                    .map(requiredActionDetail -> Update.builder().description(requiredActionDetail.getDescription())
                            .dateTime(getFormattedDateTime(requiredActionDetail.getTimeOpen())).build()).collect(Collectors.toList());
            completionMilestone.setActionRequired(actionRequired);

            setUpdates(completionMilestone, stageHistoryDetail);
        }
        return completionMilestone;
    }

    @Named("getAssessment")
    public AssessmentMilestone getAssessment(ApplicationDetailsResponse applicationDetailsResponse) {
        AssessmentMilestone assessmentMileStone = null;
        StageHistoryDetail stageHistoryDetail =
                getMatchedStageHistoryDetail(applicationDetailsResponse.getApplicationDetails(), ASSESSMENT);

        if (Objects.nonNull(stageHistoryDetail)) {
           assessmentMileStone = getAssessmentMilestone(stageHistoryDetail);
        }

        return assessmentMileStone;
    }

    private AssessmentMilestone getAssessmentMilestone(StageHistoryDetail stageHistoryDetail) {

        AssessmentMilestone assessmentMileStone;

        String ragStatus = Objects.nonNull(stageHistoryDetail.getRagStatus()) ?
                stageHistoryDetail.getRagStatus() : NULL_RAG_STATUS;

        assessmentMileStone = AssessmentMilestone.builder().description(ASSESSMENT)
                .currentStatus(currentStatus(ragStatus))
                .build();

        if (AMBER_RAG_STATUS.equals(ragStatus)) {
            if (ACTION_REQUIRED.equalsIgnoreCase(stageHistoryDetail.getSubStatus())) {
                assessmentMileStone.setCurrentStatus(ACTION_REQUIRED);
            } else if (NO_ACTION_REQUIRED.equalsIgnoreCase(stageHistoryDetail.getSubStatus())) {
                assessmentMileStone.setCurrentStatus(IN_PROGRESS);
            }
        }

        if (GREEN_RAG_STATUS.equals(ragStatus)) {
            assessmentMileStone.setIsComplete(true);
        } else if (AMBER_RAG_STATUS.equals(ragStatus) && ACTION_REQUIRED.equalsIgnoreCase(
            stageHistoryDetail.getSubStatus())) {
            assessmentMileStone.setIsComplete(false);
        }

        if (ACTION_REQUIRED.equalsIgnoreCase(stageHistoryDetail.getSubStatus())) {
            assessmentMileStone.setIsDocumentUploadComplete(Boolean.FALSE);
        } else if (NO_ACTION_REQUIRED.equalsIgnoreCase(stageHistoryDetail.getSubStatus())) {
            assessmentMileStone.setIsDocumentUploadComplete(Boolean.TRUE);
        }

        if (Objects.nonNull(stageHistoryDetail.getRequiredActions())) {
            List<Update> actionRequired = stageHistoryDetail.getRequiredActions().stream()
                    .map(requiredActionDetail -> Update.builder().description(requiredActionDetail.getDescription())
                            .dateTime(getFormattedDateTime(requiredActionDetail.getTimeOpen())).build()).collect(Collectors.toList());
            assessmentMileStone.setActionRequired(actionRequired);
        }
        setUpdates(assessmentMileStone, stageHistoryDetail);
        return assessmentMileStone;
    }

  @Named("getCancelledDecline")
    public CancelledDeclinedMilestone getCancelledDecline(ApplicationDetailsResponse applicationDetailsResponse) {
        CancelledDeclinedMilestone cancelledDeclineMilestone = null;
        StageHistoryDetail stageHistoryDetail =
                getMatchedStageHistoryDetail(applicationDetailsResponse.getApplicationDetails(), DECLINED_CANCELLED);

        if (Objects.nonNull(stageHistoryDetail)) {
            cancelledDeclineMilestone = CancelledDeclinedMilestone.builder().description(DECLINED_CANCELLED)
                    .currentStatus(CANCELLED_DECLINED)
                    .build();

            List<Update> actionRequired = stageHistoryDetail.getRequiredActions().stream()
                    .map(requiredActionDetail -> Update.builder().description(requiredActionDetail.getDescription())
                            .dateTime(getFormattedDateTime(requiredActionDetail.getTimeOpen())).build()).collect(Collectors.toList());
            cancelledDeclineMilestone.setActionRequired(actionRequired);

            setUpdates(cancelledDeclineMilestone, stageHistoryDetail);
        }
        return cancelledDeclineMilestone;
    }

    public StageHistoryDetail getMatchingStageHistory(List<StageHistoryDetail> stageHistoryDetails, String status) {
        Optional<StageHistoryDetail> stageHistoryDetailOptional = stageHistoryDetails.stream().
                filter(stageHistoryDetail -> status.equals(stageHistoryDetail.getDescription()))
                .findFirst();
        return stageHistoryDetailOptional.isPresent() ? stageHistoryDetailOptional.get() : null;
    }

    private StageHistoryDetail getMatchedStageHistoryDetail(HistoryDetails historyDetails, String description) {
        if (Objects.nonNull(historyDetails.getStageHistory()) && !historyDetails.getStageHistory().isEmpty()) {
            return getMatchingStageHistory(historyDetails.getStageHistory(), description);
        }
        return null;
    }

    private void populateMilestoneData(StageHistoryDetail stageHistoryDetail, String description, Milestone milestone) {
        milestone.setDescription(description);
        String ragStatus = Objects.nonNull(stageHistoryDetail.getRagStatus()) ?
                stageHistoryDetail.getRagStatus() : NULL_RAG_STATUS;
        milestone.setCurrentStatus(currentStatus(ragStatus));
        if (COMPLETED.equals(milestone.getCurrentStatus())) {
            milestone.setIsComplete(true);
        }
    }

    private void setUpdates(Milestone milestone, StageHistoryDetail stageHistoryDetail) {
        if (Objects.nonNull(stageHistoryDetail.getCaseHistory())) {
            List<Update> updates = stageHistoryDetail.getCaseHistory().stream()
                    .map(caseHistoryDetail -> Update.builder().description(caseHistoryDetail.getDescription())
                            .dateTime(getFormattedDateTime(caseHistoryDetail.getTimeClosed())).build()).collect(Collectors.toList());
            milestone.setUpdates(updates);
        }
    }

    private String getFormattedDateTime(ZonedDateTime timeClosed) {
        return Objects.nonNull(timeClosed) ? dateTimeFormatter.format(timeClosed) : StringUtils.EMPTY;
    }

    private String currentStatus(String ragStatus) {
        switch (ragStatus) {
            case RED_RAG_STATUS:
                return CANCELLED;
            case AMBER_RAG_STATUS:
                return IN_PROGRESS;
            case GREEN_RAG_STATUS:
                return COMPLETED;
            case GREY_RAG_STATUS:
                return NOT_STARTED;
            default:
                return StringUtils.EMPTY;
        }
    }
}
