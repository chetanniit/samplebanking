package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;

public interface UserService {
    Boolean getCheckForUserPrincipal();
    UserDetails getDetails();
    String getBrokerUsername();
    String getBrokerFcaNumber(String brokerUsername);
}
