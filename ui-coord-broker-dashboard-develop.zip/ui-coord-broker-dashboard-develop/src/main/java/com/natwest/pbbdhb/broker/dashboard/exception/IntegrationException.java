package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class IntegrationException extends RuntimeException {

    public IntegrationException(String message) {
        super(message);
    }
}