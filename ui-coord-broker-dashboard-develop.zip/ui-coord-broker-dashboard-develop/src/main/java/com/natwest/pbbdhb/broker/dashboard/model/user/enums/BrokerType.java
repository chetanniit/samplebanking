package com.natwest.pbbdhb.broker.dashboard.model.user.enums;

public enum BrokerType {
  ADMIN,
  BROKER
}
