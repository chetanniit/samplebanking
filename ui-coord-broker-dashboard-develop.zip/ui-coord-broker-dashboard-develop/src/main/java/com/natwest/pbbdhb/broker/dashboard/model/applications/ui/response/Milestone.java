package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.List;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@SuperBuilder
public class Milestone {
    private String description;
    private String currentStatus;
    private Boolean isComplete;
    private List<Update> updates;
}
