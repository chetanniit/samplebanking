package com.natwest.pbbdhb.broker.dashboard.mapper;

import com.natwest.pbbdhb.broker.dashboard.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonAddress;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;
import com.natwest.pbbdhb.broker.dashboard.model.cases.Broker;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CaseToSubmittedCaseMapper {


  public SubmittedCase toSubmittedCase(CaseApplication caseApplication, List<Applicant> applicants) {
    log.debug("toSubmittedCase: Mapping submittedCase with CaseId: {} for Broker:{}.",
        caseApplication.getCaseId(), caseApplication.getBroker().getBrokerUsername());
    SubmittedCase submittedCase = new SubmittedCase();

    submittedCase.setCaseId(caseApplication.getCaseId());
    submittedCase.setLastUpdated(caseApplication.getModifiedDate());
    submittedCase.setMortgageReferenceNumber(caseApplication.getMortgageReferenceNumber());
    submittedCase.setMortgageTempReferenceNumber(caseApplication.getMortgageTempReferenceNumber());
    if (applicants != null && !applicants.isEmpty()) {
      for (Applicant applicant : applicants) {
        setApplicant(submittedCase, applicant, caseApplication.getBroker());
      }
    }
    submittedCase.setLastUpdated(caseApplication.getModifiedDate());

    return submittedCase;
  }

  private void setApplicant(SubmittedCase submittedCase, Applicant applicantModel, Broker broker) {

    List<ApplicantDto> applicants = submittedCase.getApplicants();
    ApplicantDto applicantDto = new ApplicantDto();
    String applicantCaseId = applicantModel.getCaseId();
    String caseId = submittedCase.getCaseId();
    log.debug("setApplicant: Setting applicant for submittedCaseId: {},"
            + " applicantCaseId: {}, Broker: {}.",
        caseId, applicantCaseId, broker.getBrokerUsername());
    if (!caseId.equals(applicantCaseId)) {
      log.debug("setApplicant: Case application caseId and applicantCaseId did"
              + " not match for Broker: {}, Case application caseId: {}, applicantCaseId {}.",
          broker.getBrokerUsername(), caseId, applicantCaseId);
      return;
    }
    Optional<PersonAddress> currentAddress =
        personAddressesStream(applicantModel.getAddresses())
            .filter(address -> (Objects.nonNull(address.getIsCurrentAddress()) && address.getIsCurrentAddress()))
            .findFirst();

    if (currentAddress.isPresent()) {
      applicantDto.setPostcode(currentAddress.get().getPostcode());
    } else {
      log.error("setApplicant: Current address is not present for the "
              + "applicant. ApplicantId: {}",
          applicantModel.getApplicantId());
    }

    PersonDetails personalDetails = applicantModel.getPersonalDetails();
    if (Objects.nonNull(personalDetails)) {
      applicantDto.setFirstNames(personalDetails.getFirstNames());
      applicantDto.setLastName(personalDetails.getLastName());
      applicantDto.setDateOfBirth(personalDetails.getDateOfBirth());
    }

    applicants.add(applicantDto);
  }
  private Stream<PersonAddress> personAddressesStream(Collection<PersonAddress> collection) {
    return Optional.ofNullable(collection)
        .map(Collection::stream)
        .orElseGet(Stream::empty);
  }
}
