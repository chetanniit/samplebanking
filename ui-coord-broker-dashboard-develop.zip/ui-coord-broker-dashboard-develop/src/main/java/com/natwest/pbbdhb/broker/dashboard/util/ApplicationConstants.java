package com.natwest.pbbdhb.broker.dashboard.util;

/**
 * The application constants.
 */
public final class ApplicationConstants {

    public static final String FEE_TYPE_PRODUCT = "product";
    public static final String FEE_TYPE_VAL = "val";
    public static final String JWT_VAL = "JWT";
    public static final String GRANT_TYPE = "grant_type";
    public static final String AUD = "aud";
    public static final String JTI = "jti";
    public static final String ISS = "iss";
    public static final String SUB = "sub";
    public static final String EXPIRY = "exp";
    public static final String NBF = "nbf";
    public static final String TYPE = "typ";
    public static final String KID = "kid";
    public static final String X5T = "x5t";
    public static final String ALGORITHM = "alg";
    public static final String SCOPE = "scope";
    public static final String CLIENT_ID = "client_id";
    public static final String RESOURCE = "resource";
    public static final String TENANT = "tenant";
    public static final String CLIENT_ASSERTION_TYPE = "client_assertion_type";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";
    public static final String UK_TIME_ZONE = "Europe/London";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mmxxx";
    public static final String DATE_TIME_FORMAT_WITHOUT_T = "yyyy-MM-dd HH:mm:ss";
    public static final String UTC_TIME_ZONE = "UTC";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String GREEN_RAG_STATUS = "GREEN";
    public static final String BRAND_HEADER_NAME = "brand";
    public static final String CASE_ID = "caseId";
    public static final String REST_CLIENT_EXCEPTION_LOG_MSG = "RestClientResponseException Exception occurred while calling MSVC broker auth service: {}";
    public static final String UNEXPECTED_ERROR_MSG = "Unexpected error occurred";
    public static final String FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS = "FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS";
    public static final String SUBMIT_GMS_MOPS = "SUBMIT_GMS_MOPS";
    public static final String SUBMIT_FMA_IN_PROGRESS = "SUBMIT_FMA_IN_PROGRESS";
    public static final String FMA_SUBMITTED = "fmaSubmitted";
    public static final String MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION = "User does not have permission to get document upload url.";
    public static final String MSG_NO_MAF_DOWNLOAD_PERMISSION = "User does not have permission to download maf document.";
    public static final String MSG_PRODUCT_CHANGE_PERMISSION = "User does not have permission for product change.";
    public static final String BRAND_DEFAULT = "nwb";


    private ApplicationConstants() {
    }
}
