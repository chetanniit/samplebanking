package com.natwest.pbbdhb.broker.dashboard.model.enums;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ApplicationStatus {
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    SUBMISSION_IN_PROGRESS("Submission In Progress"),
    NONE("None");
    private String label;
    public static ApplicationStatus fromLabel(String label) {
        return Arrays.stream(ApplicationStatus.values())
            .filter(status -> status.getLabel().equalsIgnoreCase(label))
            .findFirst()
            .orElse(NONE);
    }
}
