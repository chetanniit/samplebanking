package com.natwest.pbbdhb.broker.dashboard.exception;

public class LogMessageType {

  public static String DATA_RETRIEVAL = "DataRetrieval";
  public static String JWT = "JWT";
  public static String FIREWALL = "Firewall";
  public static String OTP = "OTP";
}