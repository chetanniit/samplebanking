package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class HttpCustomException extends RuntimeException {
    private Exception exception;
}
