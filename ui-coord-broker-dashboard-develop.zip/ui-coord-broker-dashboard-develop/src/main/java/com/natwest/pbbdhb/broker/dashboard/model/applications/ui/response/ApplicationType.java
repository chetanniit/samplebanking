package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.NonNull;

public enum ApplicationType {

  NAPOLI("Napoli"),
  LEGACY("Legacy");

  private final String value;

  ApplicationType(@NonNull String value) {
    this.value = value;
  }

  /**
   * Create an enum value from a String equivalent
   *
   * @param text The original string value
   * @return ClientDocumentState
   */
  @JsonCreator
  public static ApplicationType fromValue(String text) {
    for (ApplicationType code : ApplicationType.values()) {
      if (code.value.equals(text)) {
        return code;
      }
    }
    return null;
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }

}
