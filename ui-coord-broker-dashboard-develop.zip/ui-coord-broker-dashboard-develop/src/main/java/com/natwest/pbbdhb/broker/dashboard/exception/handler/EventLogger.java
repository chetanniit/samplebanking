package com.natwest.pbbdhb.broker.dashboard.exception.handler;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EventLogger {

    public static void logException(Throwable ex, ErrorResponse error) {
        log.error(
                LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.EXCEPTION)
                        .subtype(LogMessageSubtype.ERROR_RESPONSE)
                        .description(String.format(
                                "exception=%s message=%s error=%s",
                                ex != null ? ex.getClass().getSimpleName(): "",
                                error != null ? removeSpaces(String.format("%d-%s", error.getStatus(), error.getTitle())) : "",
                                error))
                        .build());
    }

    // application logs are space-delimited key-value pairs
    // we will need to remove additional spaces
    private static String removeSpaces(String text) {
        if (text == null) {
            return "";
        }
        return text.replaceAll("\\s+","-");
    }
}
