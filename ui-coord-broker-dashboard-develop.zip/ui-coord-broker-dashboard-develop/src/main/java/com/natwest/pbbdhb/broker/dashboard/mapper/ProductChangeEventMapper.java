package com.natwest.pbbdhb.broker.dashboard.mapper;

import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.kafka.dto.ProductChangeEventDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = SpringMapperConfig.class)
public interface ProductChangeEventMapper {
    @Mapping(constant = "PRODUCT_CHANGE", target = "type")
    @Mapping(source = "productChangeRequest.productTermYears", target = "productTermYears", qualifiedByName = "getProductTermYears")
    @Mapping(source = "productChangeRequest.productType", target = "productType", qualifiedByName = "getProductType")
    @Mapping(source = "mrn", target = "referenceNumber")
    ProductChangeEventDto mapProductChangeEvent(ProductChangeRequest productChangeRequest, String caseId, String mrn, String brand);

    @Named("getProductTermYears")
    default String getProductTermYears(String productTermYears) {
        ProductChangeRequest.ProductTermYears productTerm = ProductChangeRequest.ProductTermYears.valueOf(productTermYears);
        return productTerm.getValue();
    }

    @Named("getProductType")
    default String getProductType(String productType) {
        ProductChangeRequest.ProductType type = ProductChangeRequest.ProductType.valueOf(productType);
        return type.getValue();
    }
}
