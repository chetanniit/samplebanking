package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChangeSecurityQuestionsRequest {

  @NotNull
  private List<SecurityQuestion> securityQuestions;

}
