package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class PermissionDeniedException extends RuntimeException {
    final String description;

    public PermissionDeniedException(String description) {
        super(description);
        this.description = description;
    }

    public PermissionDeniedException(String description, Throwable cause) {
        super(description, cause);
        this.description = description;
    }
}
