package com.natwest.pbbdhb.broker.dashboard.exception;

public class InvalidBrokerPermissionRequest extends RuntimeException {
    public InvalidBrokerPermissionRequest(String message) {
        super(message);
    }
}
