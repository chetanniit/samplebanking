package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrokerDetailsChangeRequest {

  @NotNull
  private String username;

  private String title;

  private String firstName;

  private String lastName;

  private String email;

  private String mobilePhone;

  private String businessPhone;

  private String addressLine1;

  private String addressLine2;

  private String addressLine3;

  private String city;

  private String county;

  private String country;

  private String postcode;

  private String fcaNumber;

  private String tradingName;

  private List<PaymentPath> paymentPaths;

  private String nationality;

  private ResidentialAddress residentialAddress;

}
