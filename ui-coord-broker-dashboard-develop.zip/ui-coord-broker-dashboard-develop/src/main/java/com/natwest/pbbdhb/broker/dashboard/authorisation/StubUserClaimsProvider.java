package com.natwest.pbbdhb.broker.dashboard.authorisation;

import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.toggles.ConditionalOnUserClaimsStubMode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Mock of user claims provider that returns hardcoded values that would be retrieved from the JWT
 * in production.
 */
@Service
@Slf4j
@ConditionalOnUserClaimsStubMode
public class StubUserClaimsProvider implements UserClaimsProvider {

  private static final String STUB_USER_NAME = "AshHughes07";

  @Override
  public String getBrokerUsername() {
    log.info("getBrokerUsername: Returning hardcoded username user claim: {}.", STUB_USER_NAME);
    return STUB_USER_NAME;
  }

  @Override
  public BrokerType getBrokerType() {
    log.info("getBrokerType: Returning broker type.");
    return BrokerType.BROKER;
  }
}
