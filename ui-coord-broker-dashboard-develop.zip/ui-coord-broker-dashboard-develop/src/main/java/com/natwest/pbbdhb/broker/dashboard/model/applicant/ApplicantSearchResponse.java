package com.natwest.pbbdhb.broker.dashboard.model.applicant;

import lombok.Data;

import java.util.List;
@Data
public class ApplicantSearchResponse {
    List<Applicant> content;
}
