package com.natwest.pbbdhb.broker.dashboard.authorisation;

import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.toggles.ConditionalOnUserClaimsIamMode;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.security.GeneralSecurityException;
import java.util.Optional;

/**
 * Responsible for retrieving user claims related to a specific request.
 * <p>
 * Each request will hold claims within a UserPrincipal. This class will retrieve the current
 * request's UserPrincipal and will then extract the specific claims required.
 */
@Slf4j
@Service
@ConditionalOnUserClaimsIamMode
public class IamUserClaimsProvider implements UserClaimsProvider {

    private static final String BROKER_ROLE = "brokerRole";
    private static final String USER_NAME = "userName";

    private final UserPrincipalProvider userPrincipalProvider;

    public IamUserClaimsProvider(
            @Qualifier("simpleUserPrincipalProvider") UserPrincipalProvider userPrincipalProvider) {
        this.userPrincipalProvider = userPrincipalProvider;
    }

    @Override
    public String getBrokerUsername() {
      log.info("getBrokerUsername: Returning brokerUsername.");
        return getStringClaim(USER_NAME);
    }

    @Override
    public BrokerType getBrokerType() {
      log.info("getBrokerType: Returning broker type.");
        return BrokerType.valueOf(getStringClaim(BROKER_ROLE));
    }

    private String getStringClaim(
        final String claimName) {
        final String claimValue = (String) getClaim(claimName);

        if (StringUtils.isNotBlank(claimValue)) {
          log.info("getStringClaim: Returning claim value for claim: {}.", claimName);
            return claimValue;
        }
        log.warn("getStringClaim: Could not retrieve claim: {}", claimName);
        throw new IllegalStateException("Could not retrieve claim: " + claimName);
    }

    private Object getClaim(String claimName) {
      log.info("getClaim: Returning claimName: {}.", claimName);
        return getUserPrincipal().getProperty(claimName);
    }

    private UserPrincipal getUserPrincipal() {
        try {
            return Optional.ofNullable(userPrincipalProvider.get())
                    .orElseThrow(() -> new IllegalStateException("getUserPrincipal: UserPrincipal "
                        + "cannot be null"));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("getUserPrincipal: Unable to retrieve UserPrincipal", e);
        }
    }
}
