package com.natwest.pbbdhb.broker.dashboard.controller.impl;

import com.natwest.pbbdhb.broker.dashboard.controller.BrokerControllerSwagger;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPermissionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SubmittedCaseDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus;
import com.natwest.pbbdhb.broker.dashboard.mapper.crm.BrokerAssociationsToDtoMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.user.UserDetailsToBrokerDetailsDtoMapper;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociations;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.service.AuthService;
import com.natwest.pbbdhb.broker.dashboard.service.SubmittedCaseService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerAssociationsService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerDetailsService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerPermissionsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Slf4j
public class BrokerController implements BrokerControllerSwagger {

  private final AuthService authService;
  private final BrokerAssociationsService brokerAssociationsService;
  private final BrokerPermissionsService brokerPermissionsService;
  private final BrokerAssociationsToDtoMapper brokerAssociationsToDtoMapper;
  private final UserDetailsToBrokerDetailsDtoMapper userDetailsToBrokerDetailsDtoMapper;

  private final UserService userService;
  private final BrokerDetailsService brokerDetailsService;
  private final SubmittedCaseService submittedCaseService;

  @Override
  public ResponseEntity<BrokerDetailsDto> details() {
    log.info("details: Retrieving details for broker: {}.",
        userService.getBrokerUsername());
    BrokerDetailsDto brokerDetailsDto;
    if (userService.getCheckForUserPrincipal()) {
      log.info("details: Inside details where check for user principal is enabled.");
      UserDetails userDetails = userService.getDetails();
      brokerDetailsDto =
          userDetailsToBrokerDetailsDtoMapper.toBrokerDetails(userDetails);
    } else {
      log.info("details: Inside details where check for user principal is disabled.");
      brokerDetailsDto = brokerDetailsService.getUserDetails();
    }
    log.info("details: Details for broker: {}, successfully retrieved.",
        userService.getBrokerUsername());
    return ResponseEntity.ok(brokerDetailsDto);
  }

  @Override
  public ResponseEntity<AssociationsDto> associations(String firstName, String lastName,
      AccessStatus accessStatus) {

    log.info("associations: Retrieving associations for {} {}. Access status: {}.",
        firstName, lastName, accessStatus);
    BrokerAssociations brokerAssociations =
        brokerAssociationsService.getAssociations(firstName, lastName, accessStatus);
    AssociationsDto associationResultsDto =
        brokerAssociationsToDtoMapper.mapAssociations(brokerAssociations);
    brokerAssociationsService.mapLoggedInAdminAssociations(associationResultsDto);
    log.info("associations: Associations for {} {}, successfully retrieved.",
        firstName, lastName);
    return ResponseEntity.ok(associationResultsDto);
  }

  @Override
  public ResponseEntity<SubmittedCaseDto> getSubmittedCase(String caseId, String brand) {
    String brokerUsername = userService.getBrokerUsername();
    log.info("getSubmittedCase: Retrieving submitted case with caseId: {} and"
            + " brokerUsername: {}.", caseId, brokerUsername);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(caseId, brand);

    log.info("getSubmittedCase: Submitted case with caseId: {} and brokerUsername: {}"
            + " successfully retrieved: {}.", caseId, brokerUsername, submittedCaseDto);
    return ResponseEntity.ok(submittedCaseDto);
  }

  @Override
  public ResponseEntity<BrokerPermissionsResponse> updateBrokerPermissions(
      BrokerPermissionsRequest request) {
    log.info("updateBrokerPermissions: Updating permissions for {}.",
        request.getUserNameToAssociate());
    BrokerPermissionsResponse response =
        brokerPermissionsService.managePermission(request.getUserNameToAssociate(),
            request.getUserType(), request.getPermissionType());
    log.info("updateBrokerPermissions: {} for {}: Successful.",
        request.getPermissionType(), request.getUserNameToAssociate());
    return ResponseEntity.ok(response);
  }

  @Override
  public void updateBrokerPassword(
      BrokerPasswordRequest request) {
    String brokerUsername = userService.getBrokerUsername();
    log.info("updateBrokerPassword: Updating password for user {}.", brokerUsername);

    authService.updateBrokerUserPassword(brokerUsername, request.getCurrentPassword(),
        request.getNewPassword());

    log.info("updateBrokerPassword: Broker: {}, password successfully updated.", brokerUsername);
  }
}
