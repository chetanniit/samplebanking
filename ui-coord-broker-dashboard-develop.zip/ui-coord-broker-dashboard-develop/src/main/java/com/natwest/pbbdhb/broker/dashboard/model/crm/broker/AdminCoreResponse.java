
package com.natwest.pbbdhb.broker.dashboard.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AdminCoreResponse {

    @JsonProperty("mbs_brokerAdminID")
    private String brokerAdminID;
    @JsonProperty("mbs_businessPhone")
    private String businessPhone;
    @JsonProperty("mbs_emailAddress")
    private String emailAddress;
    @JsonProperty("mbs_fcaNumber")
    private String fcaNumber;
    @JsonProperty("mbs_firmName")
    private String firmName;
    @JsonProperty("mbs_firstName")
    private String firstName;
    @JsonProperty("mbs_lastName")
    private String lastName;
    @JsonProperty("mbs_brokerAdminName")
    private String brokerAdminName;
    @JsonProperty("mbs_message")
    private String message;
    @JsonProperty("mbs_middleName")
    private String middleName;
    @JsonProperty("mbs_mobilePhone")
    private String mobilePhone;
    @JsonProperty("mbs_principalFCANumber")
    private String principalFCANumber;
    @JsonProperty("mbs_startDate")
    private String startDate;
    @JsonProperty("mbs_title")
    private String title;
    @JsonProperty("mbs_userName")
    private String userName;
}
