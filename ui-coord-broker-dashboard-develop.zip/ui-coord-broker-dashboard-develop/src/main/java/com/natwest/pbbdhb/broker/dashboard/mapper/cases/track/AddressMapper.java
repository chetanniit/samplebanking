package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.AddressInfo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = SpringMapperConfig.class)
public interface AddressMapper {

    @Mapping(target = "postcode", source = "postCode")
    AddressInfo toAddress(com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.AddressInfo sourceAddress);
}
