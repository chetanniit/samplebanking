package com.natwest.pbbdhb.broker.dashboard.model.applicant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Applicant {
    private String applicantId;
    private String caseId;
    private PersonDetails personalDetails;
    private List<PersonAddress> addresses;
    private String cin;
    private Boolean mainApplicant;
}
