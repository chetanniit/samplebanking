package com.natwest.pbbdhb.broker.dashboard.dto;

import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
@Data
public class PreSubmittedCase {

    private String caseId;
    //@Schema(example = "2023-12-31 21:50:20")
    private String lastUpdated;
    @Schema(implementation = ApplicationType.class,allowableValues = "AIP,FMA,ESIS")
    private ApplicationType type ;
    @Schema(implementation = ApplicationStatus.class,allowableValues = "IN_PROGRESS,SUBMIT_FMA_IN_PROGRESS,COMPLETED")
    private String applicationStatus;
    private Esis esis;
    private List<ApplicantDto> applicants = new ArrayList<>();
}
