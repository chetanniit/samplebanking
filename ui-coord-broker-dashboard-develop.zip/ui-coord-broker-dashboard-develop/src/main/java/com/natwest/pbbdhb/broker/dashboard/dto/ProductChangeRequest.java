package com.natwest.pbbdhb.broker.dashboard.dto;

import com.natwest.pbbdhb.broker.dashboard.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.dashboard.validator.annotation.ValidateEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductChangeRequest {
    @NotBlank
    private String productCode;

    @NotBlank
    @Schema(implementation = ProductTermYears.class, example = "FIVE_YEAR")
    @ValidateEnum(enumClass = ProductChangeRequest.ProductTermYears.class)
    private String productTermYears;

    @NotBlank
    @Schema(implementation = ProductType.class, example = "FIXED")
    @ValidateEnum(enumClass = ProductChangeRequest.ProductType.class)
    private String productType;

    @NotNull
    @Digits(integer = 999, fraction = 2, message = "accepts up to two decimal places")
    @DecimalMin("0")
    @DecimalMax("100")
    private BigDecimal productInterestRate;

    @DateFormat(pattern = "yyyy-MM-dd")
    @Schema(implementation = String.class, example = "2026-10-06", pattern = "yyyy-MM-dd")
    private String productEndDate;

    @Min(value = 0)
    @Max(value = 100)
    @NotNull
    private Long productLtv;

    @NotBlank
    @Size(max = 200, message = "should be less then 200")
    private String productFee;

    @Size(max = 200, message = "should be less then 200")
    private String otherInfo;


    @Getter
    @AllArgsConstructor
    public enum ProductType {
        FIXED("Fixed"),
        TRACKER("Tracker"),
        STANDARD_VARIABLE_RATE("Standard Variable Rate");

        private final String value;
    }

    @Getter
    @AllArgsConstructor
    public enum ProductTermYears {
        ONE_YEAR("1 year"),
        TWO_YEAR("2 year"),
        THREE_YEAR("3 year"),
        FOUR_YEAR("4 year"),
        FIVE_YEAR("5 year"),
        SIX_YEAR("6 year"),
        SEVEN_YEAR("7 year"),
        EIGHT_YEAR("8 year"),
        NINE_YEAR("9 year"),
        TEN_YEAR("10 year"),
        STANDARD_VARIABLE_RATE("Standard Variable Rate"),
        OTHER("Other");

        private final String value;
    }
}
