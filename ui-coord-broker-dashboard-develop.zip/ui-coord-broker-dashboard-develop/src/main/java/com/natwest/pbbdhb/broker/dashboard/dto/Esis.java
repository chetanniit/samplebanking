package com.natwest.pbbdhb.broker.dashboard.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class Esis {

    @Schema(example = "CASEID-1048724706032310034.pdf")
    private String fileName;
    @Schema(example = "Esis document created ")
    private String description;

}