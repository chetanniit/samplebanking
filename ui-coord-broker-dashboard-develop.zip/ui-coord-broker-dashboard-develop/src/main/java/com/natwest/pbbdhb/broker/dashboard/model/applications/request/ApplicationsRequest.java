package com.natwest.pbbdhb.broker.dashboard.model.applications.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@Data
@Schema(description = "Application Object")
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Builder
public class ApplicationsRequest {

    private String fromDate;
    private String toDate;
    private String brokerEmailId;
    private String brokerFirstName;
    private String brokerLastName;
    private String applicantLastName;
    private String fcaNumber;
    private String pageNumber;
    private String resultPerPage;
    private String dateRange;
    private String firmPostcode;
    private String brokerPostcode;
    private String propertyPostcode;
    private String sortBy;
    private String sortOrder;
}
