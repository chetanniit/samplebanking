package com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Applicant {
    private String title;
    private String firstName;
    private String lastName;
    private String dob;
    private String isMainApplicant;
    private Contact contact;
    private AddressInfo address;
}
