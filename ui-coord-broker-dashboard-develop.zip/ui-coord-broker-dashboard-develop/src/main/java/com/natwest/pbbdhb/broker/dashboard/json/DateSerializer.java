/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.jackson.JsonComponent;

import java.io.IOException;
import java.time.DateTimeException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_TIME_FORMAT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UTC_TIME_ZONE;

/** This class used to send serialize and deserialize dateTime */
@Slf4j
@JsonComponent
public class DateSerializer {

    private static final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern(DATE_TIME_FORMAT).withZone(ZoneId.of(UTC_TIME_ZONE));

    public static class Deserialize extends JsonDeserializer<ZonedDateTime> {

        /** This class used to send deserialize dateTime */
        @Override
        public ZonedDateTime deserialize(JsonParser p, DeserializationContext ctxt) {
            try {
                String dateAsString = p.getText();

                if (dateAsString == null) {
                    return null;
                } else {
                    return ZonedDateTime.parse(dateAsString, formatter);
                }
            } catch (DateTimeParseException | IOException e) {
                log.error("DateTimeParseException Exception while Deserializing date", e);
            } catch (DateTimeException | IndexOutOfBoundsException e) {
                log.error("Exception while Deserializing date", e);
            }
            return null;
        }
    }

    /** This class used to send serialize dateTime */
    public static class Serialize extends JsonSerializer<ZonedDateTime> {

        @Override
        public void serialize(
                ZonedDateTime value, JsonGenerator gen, SerializerProvider serializers) {
            try {
                if (value == null) {
                    gen.writeNull();
                } else {
                    gen.writeString(formatter.format(value));
                }
            } catch (IOException e) {
                log.error("Exception while serializing date", e);
            }
        }
    }
}
