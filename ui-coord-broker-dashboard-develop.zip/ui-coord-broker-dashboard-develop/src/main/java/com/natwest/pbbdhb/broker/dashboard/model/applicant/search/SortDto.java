package com.natwest.pbbdhb.broker.dashboard.model.applicant.search;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class SortDto {
    private List<OrderDto> orders;
}
