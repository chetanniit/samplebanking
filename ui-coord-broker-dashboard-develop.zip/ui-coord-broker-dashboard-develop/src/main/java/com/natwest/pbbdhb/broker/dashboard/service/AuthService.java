package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.FirmDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.UpdateBrokerDetailsResponse;

public interface AuthService {

  void updateBrokerUserPassword(String userName, String currentPassword, String newPassword);

  BrokerQuestionsResponse getSecurityQuestions(String username);

  void changeSecurityQuestions(String username, ChangeSecurityQuestionsRequest request);

  BrokerDetailsResponse getBrokerDetails(String username);

  UpdateBrokerDetailsResponse updateBrokerDetails(String username, BrokerDetails brokerDetails);

  FirmDetailsResponse getFirmDetails(String fcaNumber);
}
