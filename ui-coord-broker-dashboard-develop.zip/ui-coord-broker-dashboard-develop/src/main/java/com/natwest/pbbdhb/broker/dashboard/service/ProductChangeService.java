package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.model.SuccessResponse;

public interface ProductChangeService {
    SuccessResponse changeProduct(ProductChangeRequest productChangeRequest, String caseId, String brand);
}
