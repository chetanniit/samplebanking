package com.natwest.pbbdhb.broker.dashboard.service.impl;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.REST_CLIENT_EXCEPTION_LOG_MSG;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UNEXPECTED_ERROR_MSG;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.CrmServiceException;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import java.util.Optional;

@Service
@Slf4j
public class CrmServiceImpl implements CrmService {

  private final String brokerDetailsEndpoint;
  private final String adminDetailsEndpoint;
  private final String brokerAssociationsEndpoint;
  private final String brokerUnAssociationsEndpoint;
  private final String adminAssociationsEndpoint;
  private final String associateBrokerToBrokerEndpoint;
  private final String unAssociateBrokerToBrokerEndpoint;
  private final String associateBrokerToAdminEndpoint;
  private final String unAssociateBrokerToAdminEndpoint;
  private final RestTemplate restTemplate;

  public CrmServiceImpl(@Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
                        @Value("${msvc.crm.broker.details.url}") String brokerDetailsEndpoint,
                        @Value("${msvc.crm.admin.details.url}") String adminDetailsEndpoint,
                        @Value("${msvc.crm.broker.associations.url}") String brokerAssociationsEndpoint,
                        @Value("${msvc.crm.broker.unassociations.url}") String brokerUnAssociationsEndpoint,
                        @Value("${msvc.crm.admin.associations.url}") String adminAssociationsEndpoint,
                        @Value("${msvc.crm.broker.association.broker.url}") String associateBrokerToBrokerEndpoint,
                        @Value("${msvc.crm.broker.unassociation.broker.url}") String unAssociateBrokerToBrokerEndpoint,
                        @Value("${msvc.crm.broker.association.admin.url}") String associateBrokerToAdminEndpoint,
                        @Value("${msvc.crm.broker.unassociation.admin.url}") String unAssociateBrokerToAdminEndpoint) {
    this.restTemplate = restTemplate;
    this.brokerDetailsEndpoint = brokerDetailsEndpoint;
    this.adminDetailsEndpoint = adminDetailsEndpoint;
    this.brokerAssociationsEndpoint = brokerAssociationsEndpoint;
    this.brokerUnAssociationsEndpoint = brokerUnAssociationsEndpoint;
    this.adminAssociationsEndpoint = adminAssociationsEndpoint;
    this.associateBrokerToBrokerEndpoint = associateBrokerToBrokerEndpoint;
    this.unAssociateBrokerToBrokerEndpoint = unAssociateBrokerToBrokerEndpoint;
    this.associateBrokerToAdminEndpoint = associateBrokerToAdminEndpoint;
    this.unAssociateBrokerToAdminEndpoint = unAssociateBrokerToAdminEndpoint;
  }

  @Override
  public BrokerCoreResponse getBrokerDetails(String username) {
    String url = String.format(brokerDetailsEndpoint, username);
    log.debug("getBrokerDetails: Getting broker details for username: {}, from url {}",
        username, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerCoreResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.GET, request, BrokerCoreResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("getBrokerDetails: Get broker details called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getBrokerDetails: Get broker details request for username: {} - Failed: {}",
          username, exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getBrokerDetails: Broker details request failed");
    }
  }

  @Override
  public AdminCoreResponse getAdminDetails(String username) {
    String url = String.format(adminDetailsEndpoint, username);
    log.debug("getAdminDetails: Getting admin details for username: {}, at url {}",
        username, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    AdminCoreResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.GET, request, AdminCoreResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("getAdminDetails: Get admin details called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getAdminDetails: Get admin details request for username: {} - Failed: {}",
          username, exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getAdminDetails: Admin details request failed");
    }
  }

  @Override
  public BrokerAssociationsResponse getBrokerAssociations(String username) {
    String url = String.format(brokerAssociationsEndpoint, username);
    log.debug("getBrokerAssociations: Getting broker associations for username: {}, at url {}",
        username, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerAssociationsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.GET, request, BrokerAssociationsResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("getBrokerAssociations: Get broker associations called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getBrokerAssociations: Get broker associations request for username: {} - Failed: {}",
          exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getBrokerAssociations: Broker associations request failed");
    }
  }

  @Override
  public BrokerAssociationsResponse getBrokerUnAssociations(String username) {
    String url = String.format(brokerUnAssociationsEndpoint, username);
    log.debug("getBrokerAssociations:Getting broker unassociations for username: {}, at url {}",
        username, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerAssociationsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.GET, request, BrokerAssociationsResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("getBrokerAssociations: Get broker unassociations called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getBrokerAssociations: Get broker unassociations request for username: {} - Failed: {}",
          exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getBrokerAssociations: Broker unassociations request failed");
    }
  }

  @Override
  public AdminAssociationsResponse getAdminAssociations(String username) {
    String url = String.format(adminAssociationsEndpoint, username);
    log.debug("getBrokerAssociations: Getting admin associations for username: {}, at url {}",
        username, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    AdminAssociationsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.GET, request, AdminAssociationsResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("getBrokerAssociations: Get admin associations called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getBrokerAssociations: Get admin associations request for username: {} - Failed: {}",
          exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getBrokerAssociations: Admin associations request failed");
    }
  }

  @Override
  public BrokerPermissionsResponse associateBrokerToBroker(String username, String brokerToAssociate) {
    String url = String.format(associateBrokerToBrokerEndpoint, username, brokerToAssociate);
    log.debug("associateBrokerToBroker: Calling associate broker to broker for username: {}"
            + " and broker to associate username: {}, at url {}",
        username, brokerToAssociate, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerPermissionsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.POST, request, BrokerPermissionsResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("associateBrokerToBroker: Associate broker to broker called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("associateBrokerToBroker: Associate broker to broker request for username: {}"
              + " and broker to assossiate username: {} - Failed: {}",
          username, brokerToAssociate, exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "associateBrokerToBroker: Associate broker to broker request"
          + " failed");
    }
  }

  @Override
  public BrokerPermissionsResponse unAssociateBrokerToBroker(String username, String brokerToUnAssociate) {
    String url = String.format(unAssociateBrokerToBrokerEndpoint, username, brokerToUnAssociate);
    log.debug("unAssociateBrokerToBroker: Calling unassociate broker to broker for username: {} and"
        + " broker to unassociate: {} at url {}", username, brokerToUnAssociate, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerPermissionsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.POST, request, BrokerPermissionsResponse.class))
          .map(HttpEntity::getBody)
          .orElse(null);
      log.debug("unAssociateBrokerToBroker: Unassociate broker to broker called successfully for"
              + " username: {}.", username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("unAssociateBrokerToBroker: Unassociate broker to broker request for username: {} and"
          + " broker to unassociate username: {} - Failed: {}",
          username, brokerToUnAssociate, exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "unAssociateBrokerToBroker: Unassociate broker to broker"
          + " request failed");
    }
  }

  @Override
  public BrokerPermissionsResponse associateBrokerToAdmin(String username, String adminToAssociate) {
    String url = String.format(associateBrokerToAdminEndpoint, username, adminToAssociate);
    log.debug("associateBrokerToAdmin: Calling associate broker to admin for username: {}"
        + " and admin to associate: {}, at url {}", username, adminToAssociate, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerPermissionsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.POST, request, BrokerPermissionsResponse.class))
          .map(HttpEntity::getBody)
          .orElse(null);
      log.debug("associateBrokerToAdmin: Associate broker to admin called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("associateBrokerToAdmin: Associate broker to admin request for username: {}"
          + " and admin to associate {} - Failed: {}",
          username, adminToAssociate, exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "associateBrokerToAdmin: Associate broker to admin"
          + " request failed");
    }
  }

  @Override
  public BrokerPermissionsResponse unAssociateBrokerToAdmin(String username, String adminToUnAssociate) {
    String url = String.format(unAssociateBrokerToAdminEndpoint, username, adminToUnAssociate);
    log.debug("unAssociateBrokerToAdmin: Calling unassociate broker to admin for username: {}"
        + " and admin to unassociate: {}, at url {}", username, adminToUnAssociate, url);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<Void> request = new HttpEntity<>(headers);
    BrokerPermissionsResponse response = null;
    try {
      response = Optional.ofNullable(restTemplate.exchange(url, HttpMethod.POST, request, BrokerPermissionsResponse.class))
        .map(HttpEntity::getBody)
        .orElse(null);
      log.debug("unAssociateBrokerToAdmin: Unassociate broker to admin called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new CrmServiceException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("unAssociateBrokerToAdmin: Unassociate broker to admin request for username: {} "
          + "and admin to unassociate: {} - Failed: {}", username, adminToUnAssociate, exception.getMessage(), exception);
      throw new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "unAssociateBrokerToAdmin: Unassociate broker to admin"
          + " request failed");
    }
  }

}
