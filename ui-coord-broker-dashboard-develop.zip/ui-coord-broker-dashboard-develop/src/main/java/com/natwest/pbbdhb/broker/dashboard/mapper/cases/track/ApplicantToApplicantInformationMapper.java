package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.UiApplicantInformation;
import com.natwest.pbbdhb.broker.dashboard.util.AppUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = SpringMapperConfig.class)
public interface ApplicantToApplicantInformationMapper {

    @Mapping(target = "isMainApplicant", source = "isMainApplicant", qualifiedByName = "getIsMainApplicant")
    UiApplicantInformation toApplicantInformation(Applicant applicant);

    @Named("getIsMainApplicant")
    default Boolean getIsMainApplicant(String isMainApplicant) {
        return AppUtil.getIsMainApplicant(isMainApplicant);
    }
}
