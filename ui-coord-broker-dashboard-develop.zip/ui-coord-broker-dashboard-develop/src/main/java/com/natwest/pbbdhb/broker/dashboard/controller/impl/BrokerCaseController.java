package com.natwest.pbbdhb.broker.dashboard.controller.impl;

import com.natwest.pbbdhb.broker.dashboard.controller.BrokerCaseControllerSwagger;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.model.SuccessResponse;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.ProductChangeService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import com.natwest.pbbdhb.broker.dashboard.service.documents.DocumentDownloadService;
import io.jsonwebtoken.lang.Collections;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;

@RestController
@Slf4j
@AllArgsConstructor
@Validated
public class BrokerCaseController implements BrokerCaseControllerSwagger {

    private final CaseService caseService;
    private final DocumentDownloadService documentDownloadService;
    private final UserService userService;
    private final ProductChangeService productChangeService;

    @Override
    public ResponseEntity<PreSubmittedCases> getPreSubmittedCases(String brand,
                                                                  String pageNumber,
                                                                  String resultsPerPage,
                                                                  String lastName,
                                                                  String postcode,
                                                                  String dateOfBirth,
                                                                  String type,
                                                                  String status) {
        final String brokerUserName = userService.getBrokerUsername();
        final String fcaNumber = userService.getDetails().getFcaNumber();
        log.info("getPreSubmittedCases: Retrieving pre-submitted cases for"
            + " broker: {} and brand: {}.", brokerUserName, brand);
        PreSubmittedCases preSubmittedCases = caseService.getPreSubmittedCases(brokerUserName, fcaNumber, brand, pageNumber,
                resultsPerPage, lastName, postcode, dateOfBirth, type, status);
          log.info("getPreSubmittedCases: Pre-submitted cases for broker: {}."
                  + " {} cases successfully retrieved.",
              brokerUserName, Collections.size(preSubmittedCases.getPreSubmittedCases()));

        return ResponseEntity.ok(preSubmittedCases);
    }

    @Override
    public ResponseEntity<SubmittedCases> getSubmittedCases(String brand,
                                                            String pageNumber,
                                                            String resultsPerPage,
                                                            String brokerUsername,
                                                            String mortgageReferenceNumber,
                                                            String lastName,
                                                            String postcode,
                                                            String dateOfBirth) {

        final String fcaNumber = userService.getBrokerFcaNumber(brokerUsername);
        log.info("getSubmittedCases: Retrieving submitted cases for broker {} "
                + "with fcaNumber {} and brand {}.", brokerUsername, fcaNumber, brand);
        SubmittedCases submittedCases = caseService.getSubmittedCases(brokerUsername, fcaNumber, brand, pageNumber,
            resultsPerPage, mortgageReferenceNumber, lastName, postcode, dateOfBirth);
          log.info("getSubmittedCases: Submitted cases for broker: {}, with"
                  + " fcaNumber {}, {} cases successfully retrieved.",
              brokerUsername, fcaNumber, Collections.size(submittedCases.getSubmittedCases()));
        return ResponseEntity.ok(submittedCases);
    }

    @Override
    public ResponseEntity<InputStreamResource> getESISDocument(String documentName) {
        final String brokerUserName = userService.getBrokerUsername();
        log.info("getESISDocument: Retrieving ESIS document for broker: {}, and documentName: {}.",
            brokerUserName, documentName);

        return documentDownloadService.getESISDocument(documentName)
                .map(pdfInputStream -> {
                            log.info("getESISDocument: Successful getStoredESIS"
                                + " call for document: {}.", documentName);
                            HttpHeaders headers = new HttpHeaders();
                            headers.add("Content-Disposition", "inline; filename=" + documentName);
                            return ResponseEntity.ok()
                                    .headers(headers)
                                    .contentType(MediaType.APPLICATION_PDF)
                                    .body(new InputStreamResource(new ByteArrayInputStream(pdfInputStream)));
                        }
                ).orElseGet(() -> {
                            log.info("getESISDocument: Error in getStoredESIS"
                                + " call for document: {}", documentName);
                            return ResponseEntity.notFound().build();
                        }
                );
    }

    @Override
    public ResponseEntity<InputStreamResource> getMafDocument(String brand, String documentName) {
        final String brokerUserName = userService.getBrokerUsername();
        log.info("getMafDocument: Retrieving MAF document for broker: {}, and"
                + " documentName: {} ", brokerUserName, documentName);
        return documentDownloadService.getFMADocument(brand, documentName)
                .map(pdfInputStream -> {
                            log.info("getMafDocument: Successful getMAF call"
                                    + " for document: {}", documentName);
                            HttpHeaders headers = new HttpHeaders();
                            headers.add("Content-Disposition", "inline; filename=" + documentName);
                            return ResponseEntity.ok()
                                    .headers(headers)
                                    .contentType(MediaType.APPLICATION_PDF)
                                    .body(new InputStreamResource(new ByteArrayInputStream(pdfInputStream)));
                        }
                ).orElseGet(() -> {
                            log.info("getMafDocument: Error in MAF download"
                                    + " for document: {}", documentName);
                            return ResponseEntity.notFound().build();
                        }
                );
    }

    @Override
    public ResponseEntity<SuccessResponse> submitProductChange(ProductChangeRequest request, String caseId, String brand) {
        final String brokerUserName = userService.getBrokerUsername();
        log.info("submitProductChange: submit product change request for broker: {}, and"
                + " caseId: {} ", brokerUserName, caseId);
        SuccessResponse successResponse = productChangeService.changeProduct(request, caseId, brand);

        return ResponseEntity.ok(successResponse);
    }


}
