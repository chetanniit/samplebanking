package com.natwest.pbbdhb.broker.dashboard.model.cases;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CaseApplication {

    private String caseId;

    private String modifiedDate;

    private String mortgageReferenceNumber;

    private String mortgageTempReferenceNumber;

    private List<SalesIllustration> salesIllustrations;

    private Map<String, Object> journeyData;

    private String applicationStatus;

    private List<DecisionInPrinciple> decisionInPrinciples;

    private String channel;

    private Boolean isEsis;

    private String mafDocumentUrl;

    private Broker broker;
}
