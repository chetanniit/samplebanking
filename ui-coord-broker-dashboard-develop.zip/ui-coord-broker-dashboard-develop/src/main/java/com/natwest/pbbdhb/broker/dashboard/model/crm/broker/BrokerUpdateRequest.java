package com.natwest.pbbdhb.broker.dashboard.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BrokerUpdateRequest {

    @JsonProperty("mbs_requesttype")
    private String requesttype;
    @JsonProperty("mbs_status")
    private String status;
}
