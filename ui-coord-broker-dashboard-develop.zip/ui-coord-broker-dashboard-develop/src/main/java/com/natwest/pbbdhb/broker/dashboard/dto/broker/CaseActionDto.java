package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingDocumentResponse;
import com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CaseActionDto {

  private DocumentUploadStatus documentUploadStatus;
  private Boolean isFeePaymentComplete;
  private Boolean hasFees;
  private Boolean isCaseTrackingAvailable;
  private Boolean isFmaComplete;
  private String mafDocument;

}
