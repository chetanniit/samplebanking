package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.ApplicantSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.search.AndOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.search.OperatorDto;
import com.natwest.pbbdhb.broker.dashboard.service.ApplicantService;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.dashboard.util.AppUtil.buildBrandAndContentTypeHeaders;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.CASE_ID;

@Service
@Slf4j
public class ApplicantServiceImpl implements ApplicantService {

    public static final String LAST_NAME_FIELD = "personalDetails.lastName";
    public static final String POSTCODE_FIELD = "addresses.postcode";
    public static final String DATE_OF_BIRTH_FIELD = "personalDetails.dateOfBirth";
    private final RestTemplate iamJwtChainSecureRestTemplate;
    private final String applicantsSearchUrl;
    private final String applicantsGetUrl;

    public ApplicantServiceImpl(@Qualifier("iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
                                @Value("${msvc.applicant.service.search.url}") String applicantsSearchUrl,
                                @Value("${msvc.applicant.service.get.url}") String applicantsGetUrl) {
        this.iamJwtChainSecureRestTemplate = iamJwtChainSecureRestTemplate;
        this.applicantsSearchUrl = applicantsSearchUrl;
        this.applicantsGetUrl = applicantsGetUrl;
    }

    @Override
    public List<Applicant> getApplicants(Set<String> caseIds, String brand) {
        log.debug("getApplicants: Retrieving applicants for caseIds: {}", caseIds);

        SimpleOperatorDto simpleOperator = SimpleOperatorDto.builder()
            .compareType(SimpleOperatorDto.CompareType.IN)
            .field("caseId")
            .values(caseIds)
            .build();
        QueryDto query = QueryDto.builder().operator(simpleOperator).build();
        CriteriaDto criteria = CriteriaDto.builder().query(query).build();

        return callGetApplicants(criteria, brand);
    }

    @Override
    public List<Applicant> getApplicants(String lastName, String postcode, String dateOfBirth, String brand) {
        log.debug("getApplicants: Retrieving applicants for filters: lastName:{},"
                + " postcode: {}, dateOfBirth: {}, brand: {}.",
            lastName, postcode, dateOfBirth, brand);
        postcode = StringUtils.replaceChars(postcode, '+', ' ');
        List<OperatorDto> operators = new ArrayList<>();
        if (StringUtils.isNotEmpty(lastName)) {
            SimpleOperatorDto lastNameOperator = SimpleOperatorDto.builder()
                .compareType(CompareType.LIKE)
                .field(LAST_NAME_FIELD)
                .value(lastName)
                .build();
            operators.add(lastNameOperator);
        }
        if (StringUtils.isNotEmpty(postcode)) {
            SimpleOperatorDto postcodeOperator = SimpleOperatorDto.builder()
                .compareType(CompareType.EQ)
                .field(POSTCODE_FIELD)
                .value(postcode.toUpperCase())
                .build();
            operators.add(postcodeOperator);
        }
        if (StringUtils.isNotEmpty(dateOfBirth)) {
            SimpleOperatorDto dateOfBirthOperator = SimpleOperatorDto.builder()
                .compareType(CompareType.DATE_EQ)
                .field(DATE_OF_BIRTH_FIELD)
                .value(dateOfBirth)
                .build();
            operators.add(dateOfBirthOperator);
        }

        QueryDto query;

        if (operators.size() == 1) {
            query = QueryDto.builder().operator(operators.get(0)).build();
        } else {
            AndOperatorDto queryAndOperator = AndOperatorDto.builder().operators(operators).build();
            query = QueryDto.builder().operator(queryAndOperator).build();
        }
        CriteriaDto criteria = CriteriaDto.builder().query(query).build();

        return callGetApplicants(criteria, brand);
    }

    @Override
    public List<Applicant> getApplicants(String brand, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(applicantsGetUrl);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID, caseId);
        builder.uriVariables(urlParams);

        URI url = builder.build().toUri();
        log.debug("getApplicants: Calling {} to get applicants.", url);

        List<Applicant> applicantDtoList;
        try {
            applicantDtoList = iamJwtChainSecureRestTemplate.exchange(
                url,
                HttpMethod.GET,
                new HttpEntity<>(buildBrandAndContentTypeHeaders(brand,
                    MediaType.APPLICATION_JSON_VALUE)),
                new ParameterizedTypeReference<List<Applicant>>() {
                }).getBody();

            if(applicantDtoList != null) {
                List<String> applicantIds = applicantDtoList.stream()
                    .map(applicant -> applicant.getApplicantId()).collect(
                        Collectors.toList());
                log.debug("getApplicants: Applicants with caseId {} and applicantIds {} "
                        + "successfully retrieved.", caseId, applicantIds);
            } else {
                throw new HttpClientErrorException(HttpStatus.NOT_FOUND,
                    String.format("getApplicants: Null response body returned from %s to get applicants for caseId %s", url, caseId));
            }
        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to get applicants with caseId {}: {}", url, caseId, ex.getMessage());
            throw new IntegrationException(ex.getMessage());
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            log.warn("An unexpected exception occurred while calling {} to get applicants with caseId {}: {}", url, caseId, message);
            throw t;
        }
        return applicantDtoList;
    }

    private List<Applicant> callGetApplicants(CriteriaDto criteria, String brand) {
        log.debug("callGetApplicants: Creating headers for call to applicant service.");

      HttpHeaders headers = buildBrandAndContentTypeHeaders(brand,
          MediaType.APPLICATION_JSON_VALUE);
      HttpEntity<CriteriaDto> httpEntity = new HttpEntity<>(criteria, headers);
        ApplicantSearchResponse response;
        log.debug("callGetApplicants: Calling Applicants service with Headers: {}.", headers);
        try {
            Map<String, Object> uriVariables = new HashMap<>();
            uriVariables.put("page", 0);
            uriVariables.put("size", 100);
            response = iamJwtChainSecureRestTemplate.postForObject(applicantsSearchUrl, httpEntity, ApplicantSearchResponse.class, uriVariables);
            if (response == null || response.getContent() == null || response.getContent().size() < 1 || ObjectUtils.isEmpty(response.getContent().get(0))) {
                log.debug("callGetApplicants: No Applicants found.");
                throw new ApplicantNotFoundException("Exception - Applicant not found");
            }
        } catch (RestClientResponseException ex) {
            if (ex instanceof HttpClientErrorException) {
                log.warn("HttpClientError Exception occurred while calling applicant service: {}", ex.getMessage());
                if (HttpStatus.NOT_FOUND == ((HttpClientErrorException) ex).getStatusCode()) {
                    throw new ApplicantNotFoundException("Exception - Applicant not found");
                }
            }
            log.warn("RestClientResponseException Exception occurred while calling applicant service: {}", ex.getMessage());
            throw new ApplicantServiceException(ex);
        } catch (Exception exception) {
            log.warn("Applicant retrieval request failed: {}", exception.getMessage());
            if (exception.getMessage().contains("Applicant not found")) {
                throw new ApplicantNotFoundException("Exception - Applicant not found");
            }
            throw new ApplicantServiceException(exception);
        }
        log.debug("callGetApplicants: Call to applicant service successful.");
        return response.getContent();
    }

}
