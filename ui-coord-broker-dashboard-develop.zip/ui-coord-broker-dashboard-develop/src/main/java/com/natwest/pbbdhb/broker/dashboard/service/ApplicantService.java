package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;

import java.util.List;
import java.util.Set;

public interface ApplicantService {
    List<Applicant> getApplicants(Set<String> caseIds, String brand);
    List<Applicant> getApplicants(String lastName, String postcode, String dateOfBirth, String brand);
    List<Applicant> getApplicants(String brand, String caseId);
}
