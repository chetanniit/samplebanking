package com.natwest.pbbdhb.broker.dashboard.model.applicant.search;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.EXISTING_PROPERTY,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = OrOperatorDto.class, name = "OR"),
        @JsonSubTypes.Type(value = AndOperatorDto.class, name = "AND"),
        @JsonSubTypes.Type(value = SimpleOperatorDto.class, name = "SIMPLE")
})
public abstract class OperatorDto {

    public enum OperatorType {
        OR, AND, SIMPLE
    }

    public abstract OperatorType getType();

}
