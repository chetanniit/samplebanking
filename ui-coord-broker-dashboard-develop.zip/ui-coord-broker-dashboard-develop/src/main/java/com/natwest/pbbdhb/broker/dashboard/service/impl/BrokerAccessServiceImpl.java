package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.BrokerAccessService;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BrokerAccessServiceImpl implements BrokerAccessService {

  private final UserClaimsProvider userClaimsProvider;
  private CrmService crmService;

  public BrokerAccessServiceImpl(UserClaimsProvider userClaimsProvider, CrmService crmService) {
    this.userClaimsProvider = userClaimsProvider;
    this.crmService = crmService;
  }

  @Override
  public boolean checkRequestedBrokerHasAccess(String brokerUsername) {

    String loggedInUserName = userClaimsProvider.getBrokerUsername();
    BrokerType brokerType = userClaimsProvider.getBrokerType();

    if(brokerUsername == null) {
      log.debug("checkRequestedBrokerHasAccess: No brokerUsername provided to check association with"
          + " loggedInUsername {}", loggedInUserName);
      return false;
    }

    if (brokerUsername.equals(loggedInUserName)) {
      log.debug("checkRequestedBrokerHasAccess: loggedInUsername {} matches the requested brokerUsername {}",
          loggedInUserName, brokerUsername);
      return true;
    }

    if (BrokerType.ADMIN.equals(brokerType)) {
      AdminAssociationsResponse adminAssociationsResponse = crmService.getAdminAssociations(
          loggedInUserName);

      if (adminAssociationsResponse == null) {
        log.debug("checkRequestedBrokerHasAccess: CrmResponse is null for loggedInUserName {}",
            loggedInUserName);
        return false;
      }

      return isBrokerAssociate(brokerUsername, loggedInUserName, adminAssociationsResponse.getBrokers(), brokerType);

    } else {
      BrokerAssociationsResponse brokerAssociationsResponse = crmService.getBrokerAssociations(
          loggedInUserName);

      if(brokerAssociationsResponse == null) {
        log.debug("checkRequestedBrokerHasAccess: CrmResponse is null for loggedInUserName {}",
            loggedInUserName);
        return false;
      }
      List<AssociatedBrokerDetails> associatedBrokerDetails = new ArrayList<>();
      if(brokerAssociationsResponse.getBrokers() != null) {
        associatedBrokerDetails.addAll(brokerAssociationsResponse.getBrokers());
      }
      if(brokerAssociationsResponse.getGrantedPermissionBrokers() != null) {
        associatedBrokerDetails.addAll(brokerAssociationsResponse.getGrantedPermissionBrokers());
      }
      return isBrokerAssociate(brokerUsername, loggedInUserName, associatedBrokerDetails, brokerType);
    }
  }

  private boolean isBrokerAssociate(String brokerUsername, String loggedInUserName,
      List<AssociatedBrokerDetails> associatedBrokerDetails, BrokerType brokerType) {

    if (associatedBrokerDetails == null || associatedBrokerDetails.isEmpty()) {
      log.debug("isBrokerAssociate: brokerUsername {} is not associated with {} "
              + "loggedInUsername {}: no associates found",
          brokerUsername, brokerType, loggedInUserName);
      return false;
    }

    List<String> associatedBrokers = associatedBrokerDetails.stream()
        .map(AssociatedBrokerDetails::getUserName).toList();

    if (associatedBrokers.contains(brokerUsername)) {
      log.debug("isBrokerAssociate: brokerUsername {} is associated with {} loggedInUsername {}",
          brokerUsername, brokerType, loggedInUserName);
      return true;
    } else {
      log.debug("isBrokerAssociate: brokerUsername {} is not associated with {} loggedInUsername {}",
          brokerUsername, brokerType, loggedInUserName);
      return false;
    }
  }


}
