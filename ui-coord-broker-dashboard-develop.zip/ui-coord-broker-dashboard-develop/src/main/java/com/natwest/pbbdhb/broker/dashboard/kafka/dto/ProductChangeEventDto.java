package com.natwest.pbbdhb.broker.dashboard.kafka.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductChangeEventDto {
    private String type;
    private String brand;
    private String caseId;
    private String referenceNumber;
    private String productCode;
    private String productTermYears;
    private String productType;
    private BigDecimal productInterestRate;
    private String productEndDate;
    private Long productLtv;
    private String productFee;
    private String otherInfo;


}
