package com.natwest.pbbdhb.broker.dashboard.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.Fee;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@SuperBuilder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductDetailsDto {
    private List<Fee> fees;
}
