package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Case;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = SpringMapperConfig.class, uses = {StatusDetailToStatusMapper.class,
        ApplicantToApplicantInformationMapper.class})
public interface ApplicationDetailsResponseToCaseMapper {
    @Mapping(target = "mortgageReferenceNumber", source = "referenceNumber")
    @Mapping(target = "applicants", source = "applicantInformation")
    @Mapping(target = "status", source = "status")
    @Mapping(target = "postcode", source = "propertyInformation.address.postCode")
    Case toCase(ApplicationDetailsResponse applicationDetailsResponse);
}
