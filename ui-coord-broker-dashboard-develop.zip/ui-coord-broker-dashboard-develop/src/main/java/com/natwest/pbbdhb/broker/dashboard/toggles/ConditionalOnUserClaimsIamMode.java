package com.natwest.pbbdhb.broker.dashboard.toggles;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Beans with this annotation will only be created if user claims is using IAM mode.
 */
@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@ConditionalOnProperty(name = "features.user-claims-mode", havingValue = "iam")
public @interface ConditionalOnUserClaimsIamMode {

}
