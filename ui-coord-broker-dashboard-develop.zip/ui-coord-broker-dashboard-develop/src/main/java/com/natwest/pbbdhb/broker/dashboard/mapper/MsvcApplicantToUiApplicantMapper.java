package com.natwest.pbbdhb.broker.dashboard.mapper;

import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.AddressMapper;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import com.natwest.pbbdhb.broker.dashboard.util.AppUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = SpringMapperConfig.class, uses = AddressMapper.class)
public interface MsvcApplicantToUiApplicantMapper {

    @Mapping(target = "name", source = ".", qualifiedByName = "buildName")
    @Mapping(target = "title", source = "personalDetails.title")
    @Mapping(target = "isMainApplicant", source = "mainApplicant")
    @Mapping(target = "dob", ignore = true)
    @Mapping(target = "email", ignore = true)
    @Mapping(target = "correspondenceAddress", ignore = true)
    UiApplicant toUiApplicant(Applicant applicant);

    @Named("buildName")
    default String buildName(Applicant applicant) {
        PersonDetails personDetails = applicant.getPersonalDetails();
        return personDetails == null ? null :
            AppUtil.buildFullName(personDetails.getFirstNames(), personDetails.getLastName());
    }

}
