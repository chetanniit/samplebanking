package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrokerChangeQuestionsRequest {

  @NotNull
  private String username;

  @NotNull
  private List<BrokerSecurityQuestion> questions;

}
