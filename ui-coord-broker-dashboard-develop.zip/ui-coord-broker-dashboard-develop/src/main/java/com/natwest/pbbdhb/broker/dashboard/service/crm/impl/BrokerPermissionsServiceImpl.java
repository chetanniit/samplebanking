package com.natwest.pbbdhb.broker.dashboard.service.crm.impl;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.PermissionType;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType;
import com.natwest.pbbdhb.broker.dashboard.exception.InvalidBrokerPermissionRequest;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerPermissionsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BrokerPermissionsServiceImpl implements BrokerPermissionsService {

    private final CrmService crmService;
    private final UserClaimsProvider userClaimsProvider;

    @Override
    public BrokerPermissionsResponse managePermission(String userName, UserType userType, PermissionType permissionType) {

        String loggedInUserName = userClaimsProvider.getBrokerUsername();
        BrokerType brokerType = userClaimsProvider.getBrokerType();
        log.debug("managePermission: Managing permissions to {} to {}.",
            permissionType, userName);

        if (BrokerType.BROKER.equals(brokerType)) {
            if (UserType.BROKER.equals(userType)) {
              return manageBrokerPermissions(loggedInUserName, userName, permissionType);
            }
            else {
                return manageAdminPermissions(loggedInUserName, userName, permissionType);
            }
        }
        else {
            if (UserType.BROKER.equals(userType)) {
                if (PermissionType.REMOVE_ACCESS.equals(permissionType)) {
                    return manageAdminPermissions(userName, loggedInUserName, permissionType);
                }
                throw new InvalidBrokerPermissionRequest("Admin Can't grant/request access to broker");
            }
            throw new InvalidBrokerPermissionRequest("Admin Can't grant/remove access to another " +
                    "admin");
        }
    }

    private BrokerPermissionsResponse manageBrokerPermissions(String loggedInUserName,
                                                              String userName, PermissionType permissionType) {
      log.debug("manageBrokerPermissions: Updating broker permissions to {} to {}.",
          permissionType, userName);
        if (PermissionType.GRANT_ACCESS.equals(permissionType)){
            return crmService.associateBrokerToBroker(loggedInUserName, userName);
        }
        return crmService.unAssociateBrokerToBroker(loggedInUserName, userName);
    }

    private BrokerPermissionsResponse manageAdminPermissions(String loggedInUserName,
                                                              String userName, PermissionType permissionType) {
      log.debug("manageAdminPermissions: Updating admin permissions to {} to {}.",
          permissionType, userName);
        if (PermissionType.GRANT_ACCESS.equals(permissionType)){
            return crmService.associateBrokerToAdmin(loggedInUserName, userName);
        }
        return crmService.unAssociateBrokerToAdmin(loggedInUserName, userName);
    }
}
