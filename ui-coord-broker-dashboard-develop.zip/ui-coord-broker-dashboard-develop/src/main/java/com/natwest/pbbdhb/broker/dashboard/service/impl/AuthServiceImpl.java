package com.natwest.pbbdhb.broker.dashboard.service.impl;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.REST_CLIENT_EXCEPTION_LOG_MSG;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UNEXPECTED_ERROR_MSG;
import static java.lang.String.format;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerChangeQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerSecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangePasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.FirmDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.UpdateBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangeSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangePasswordException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveFirmDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.mapper.SecurityQuestionToBrokerSecurityQuestionMapper;
import com.natwest.pbbdhb.broker.dashboard.service.AuthService;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class AuthServiceImpl implements AuthService {

  private final String passwordChangeEndpoint;
  private final String retrieveSecurityQuestionsEndpoint;
  private final String changeSecurityQuestionsEndpoint;
  private final String brokerDetailsEndpoint;
  private final String firmDetailsEndpoint;
  private final RestTemplate restTemplate;
  private final SecurityQuestionToBrokerSecurityQuestionMapper securityQuestionToBrokerSecurityQuestionMapper;

  public AuthServiceImpl(@Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
      @Value("${msvc.password.change.url}") String passwordChangeEndpoint,
      @Value("${msvc.security.questions.get.url}") String retrieveSecurityQuestionsEndpoint,
      @Value("${msvc.security.questions.change.url}") String changeSecurityQuestionsEndpoint,
      @Value("${msvc.broker.broker-details.url}") String brokerDetailsEndpoint,
      @Value("${msvc.broker.firm-details.url}") String firmDetailsEndpoint,
      SecurityQuestionToBrokerSecurityQuestionMapper securityQuestionToBrokerSecurityQuestionMapper) {
    this.passwordChangeEndpoint = passwordChangeEndpoint;
    this.restTemplate = restTemplate;
    this.retrieveSecurityQuestionsEndpoint = retrieveSecurityQuestionsEndpoint;
    this.changeSecurityQuestionsEndpoint = changeSecurityQuestionsEndpoint;
    this.brokerDetailsEndpoint = brokerDetailsEndpoint;
    this.firmDetailsEndpoint = firmDetailsEndpoint;
    this.securityQuestionToBrokerSecurityQuestionMapper = securityQuestionToBrokerSecurityQuestionMapper;
  }

  @Override
  public void updateBrokerUserPassword(String userName, String currentPassword,
      String newPassword) {
    ChangePasswordRequest changePasswordRequest =
        ChangePasswordRequest.builder()
            .currentPassword(currentPassword)
            .newPassword(newPassword)
            .username(userName)
            .build();

    log.debug("updateBrokerUserPassword: Calling change password auth service at url {} for username: {}.",
        passwordChangeEndpoint, userName);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    HttpEntity<ChangePasswordRequest> httpEntity = new HttpEntity<>(changePasswordRequest,
        headers);

    try {
      restTemplate.postForObject(passwordChangeEndpoint, httpEntity, Void.class);
      log.debug("updateBrokerUserPassword: Change password called successfully for username: {}.",
          userName);
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCodes.USER_NOT_FOUND.toString())) {
        throw new ChangePasswordException(httpStatusBadRequest, ErrorCodes.USER_NOT_FOUND,
            format("updateBrokerUserPassword: User not found for user: '%s'", userName));
      }
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCodes.INVALID_DETAILS.toString())) {
        throw new ChangePasswordException(httpStatusBadRequest, ErrorCodes.INVALID_DETAILS,
            "Password not valid");
      }
      log.warn(
          "updateBrokerUserPassword: Reset password request failed with unexpected 400 BadRequest"
              + " response", ex);
      throw new ChangePasswordException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "updateBrokerUserPassword: Reset password request failed");
    } catch (HttpClientErrorException.Unauthorized ex) {
      final int httpStatusUnauthorised = HttpStatus.UNAUTHORIZED.value();
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCodes.ACCOUNT_LOCKED.toString())) {
        throw new ChangePasswordException(httpStatusUnauthorised, ErrorCodes.ACCOUNT_LOCKED,
            format("updateBrokerUserPassword: Account locked for user: '%s'", userName));
      }
      log.warn(
          "updateBrokerUserPassword: Reset password request failed with unexpected 400 BadRequest"
              + " response", ex);
      throw new ChangePasswordException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "updateBrokerUserPassword: Reset password request failed");
    } catch (Exception ex) {
      log.warn("updateBrokerUserPassword: Request failed", ex);
      throw new ChangePasswordException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "updateBrokerUserPassword: Reset password request failed");
    }
  }

  @Override
  public BrokerQuestionsResponse getSecurityQuestions(String username) {

    log.debug("getSecurityQuestions: Calling get security questions auth service at url {}"
            + " for username: {}.", retrieveSecurityQuestionsEndpoint, username);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    BrokerQuestionsRequest request = BrokerQuestionsRequest.builder()
        .username(username)
        .build();
    HttpEntity<BrokerQuestionsRequest> httpEntity = new HttpEntity<>(request,
        headers);
    BrokerQuestionsResponse response = null;
    try {
      response = restTemplate.postForObject(
          retrieveSecurityQuestionsEndpoint, httpEntity,
          BrokerQuestionsResponse.class);
      log.debug("getSecurityQuestions: Get security questions called successfully for username: {}.",
          request.getUsername());
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCodes.USER_NOT_FOUND.toString())) {
        throw new RetrieveSecurityQuestionsException(httpStatusBadRequest,
            ErrorCodes.USER_NOT_FOUND,
            format("getSecurityQuestions: User not found for user: '%s'", username));
      }
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCodes.MEMORABLE_QUESTIONS_LOCKED.toString())) {
        throw new RetrieveSecurityQuestionsException(httpStatusBadRequest,
            ErrorCodes.MEMORABLE_QUESTIONS_LOCKED, "getSecurityQuestions: Memorable questions locked");
      }
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new RetrieveSecurityQuestionsException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getSecurityQuestions: Get security questions request failed: {}", exception.getMessage());
      throw new RetrieveSecurityQuestionsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getSecurityQuestions: Memorable questions request failed");
    }
  }


  @Override
  public void changeSecurityQuestions(String username, ChangeSecurityQuestionsRequest request) {
    log.debug("changeSecurityQuestions: Calling change security questions at url {} for username: {}.",
        changeSecurityQuestionsEndpoint, username);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");

    List<BrokerSecurityQuestion> questions = request.getSecurityQuestions().stream().map(
        securityQuestionToBrokerSecurityQuestionMapper::toSecurityQuestion).collect(
        Collectors.toList());

    BrokerChangeQuestionsRequest brokerChangeQuestionsRequest = BrokerChangeQuestionsRequest.builder()
        .username(username)
        .questions(questions)
        .build();
    HttpEntity<BrokerChangeQuestionsRequest> httpEntity = new HttpEntity<>(
        brokerChangeQuestionsRequest,
        headers);

    try {
      restTemplate.postForObject(changeSecurityQuestionsEndpoint, httpEntity, Void.class);
      log.debug("changeSecurityQuestions: Change security questions called successfully for"
              + " username: {}.", username);
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.debug("changeSecurityQuestions: Security question already exists: {}", ex.getMessage());
      throw new RetrieveFirmDetailsException(httpStatusBadRequest,
          ErrorCodes.MEMORABLE_QUESTION_EXIST, "changeSecurityQuestions: Security question already exists");
    } catch (HttpClientErrorException ex) {
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      final int httpStatusBadRequest = HttpStatus.INTERNAL_SERVER_ERROR.value();
      throw new ChangeSecurityQuestionsException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR,
          format("changeSecurityQuestions: Change security questions request for user %s failed",
              username));
    } catch (Exception exception) {
      log.warn("changeSecurityQuestions: Change security questions request failed: {}",
          exception.getMessage(), exception);
      throw new ChangeSecurityQuestionsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR,
          format("changeSecurityQuestions: Change security questions request for user %s failed"
              + " with unexpected error", username));
    }
  }

  @Override
  public BrokerDetailsResponse getBrokerDetails(String username) {
    log.debug("getBrokerDetails: Calling get broker details auth service at url {} for "
            + "username: {}.", brokerDetailsEndpoint, username);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    BrokerDetailsResponse response = null;
    String url = brokerDetailsEndpoint + "/" + username;
    try {
      response = restTemplate.getForObject(url, BrokerDetailsResponse.class);
      log.debug("getBrokerDetails: Get broker details called successfully for username: {}.",
          username);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCodes.USER_NOT_FOUND.toString())) {
        throw new RetrieveBrokerDetailsException(httpStatusBadRequest,
            ErrorCodes.USER_NOT_FOUND,
            format("getBrokerDetails: User not found for user: '%s'", username));
      }
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new RetrieveBrokerDetailsException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.warn("getBrokerDetails: Get broker details request failed: {}", exception.getMessage(), exception);
      throw new RetrieveBrokerDetailsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getBrokerDetails: Broker details request failed");
    }
  }

  @Override
  public UpdateBrokerDetailsResponse updateBrokerDetails(String username, BrokerDetails brokerDetails) {
    log.debug("updateBrokerDetails: Calling update broker details auth service at url {} for"
            + " username: {}.", brokerDetailsEndpoint, username);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");

    BrokerDetailsChangeRequest brokerDetailsChangeRequest = BrokerDetailsChangeRequest.builder()
        .username(username)
        .title(brokerDetails.getTitle())
        .firstName(brokerDetails.getFirstName())
        .lastName(brokerDetails.getLastName())
        .email(brokerDetails.getEmail())
        .mobilePhone(brokerDetails.getMobilePhone())
        .businessPhone(brokerDetails.getBusinessPhone())
        .addressLine1(brokerDetails.getAddressLine1())
        .addressLine2(brokerDetails.getAddressLine2())
        .addressLine3(brokerDetails.getAddressLine3())
        .city(brokerDetails.getCity())
        .county(brokerDetails.getCounty())
        .postcode(brokerDetails.getPostcode())
        .fcaNumber(brokerDetails.getFcaNumber())
        .tradingName(brokerDetails.getTradingName())
        .paymentPaths(brokerDetails.getPaymentPaths())
        .nationality(brokerDetails.getNationality())
        .residentialAddress(brokerDetails.getResidentialAddress())
        .build();
    HttpEntity<BrokerDetailsChangeRequest> httpEntity = new HttpEntity<>(
        brokerDetailsChangeRequest,
        headers);
    ResponseEntity<UpdateBrokerDetailsResponse> response = null;

    try {
      response = restTemplate.exchange(brokerDetailsEndpoint, HttpMethod.PUT, httpEntity, UpdateBrokerDetailsResponse.class);
      log.debug("updateBrokerDetails: Change broker details called successfully for username: {}.",
          username);
      return response.getBody();
    } catch (HttpClientErrorException ex) {
      log.warn(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      final int httpStatusBadRequest = HttpStatus.INTERNAL_SERVER_ERROR.value();
      throw new UpdateBrokerDetailsException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR,
          format("updateBrokerDetails: Change broker details request for user %s failed", username));
    } catch (Exception exception) {
      log.warn("updateBrokerDetails: Change broker details request failed: {}",
          exception.getMessage(), exception);
      throw new UpdateBrokerDetailsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR,
          format("updateBrokerDetails: Change broker details request for user %s failed with "
              + "unexpected error", username));
    }
  }

  @Override
  public FirmDetailsResponse getFirmDetails(String fcaNumber) {
    log.debug("getFirmDetails: Calling get firm details auth service at url {} for"
            + " fcaNumber: {}.", brokerDetailsEndpoint, fcaNumber);

    final HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
    FirmDetailsResponse response = null;
    final String url = firmDetailsEndpoint + "/" + fcaNumber;
    try {
      response = restTemplate.getForObject(url, FirmDetailsResponse.class);
      log.debug("getFirmDetails: Get firm details called successfully for fcaNumber: {}.",
          fcaNumber);
      return response;
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      log.debug(REST_CLIENT_EXCEPTION_LOG_MSG, ex.getMessage());
      throw new RetrieveFirmDetailsException(httpStatusBadRequest,
          ErrorCodes.INTERNAL_SERVER_ERROR, UNEXPECTED_ERROR_MSG);
    } catch (Exception exception) {
      log.debug("getFirmDetails: Get firm details request failed: {}",
          exception.getMessage(), exception);
      throw new RetrieveFirmDetailsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          ErrorCodes.INTERNAL_SERVER_ERROR, "getFirmDetails: Firm details request failed");
    }
  }
}
