package com.natwest.pbbdhb.broker.dashboard.service.impl;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicationNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicationsServiceException;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.ApplicationDetailsResponseToCaseMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.ApplicationDetailsToTrackingApplicationDetailsMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.ApplicationsResponseToCaseTrackingResponseMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.BrokerCoreResponseToApplicationRequestMapper;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.request.ApplicationsRequest;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.ApplicationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.Page;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Case;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingDocumentResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.service.CaseTrackingService;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import com.natwest.pbbdhb.broker.dashboard.util.AppUtil;
import io.jsonwebtoken.lang.Collections;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.natwest.pbbdhb.broker.dashboard.util.AppUtil.buildFullName;

@Service
@Slf4j
public class CaseTrackingServiceImpl implements CaseTrackingService {

    private static final String LAST_MODIFIED_DATE = "Last Modified Date";
    private static final String DESC = "Desc";
    private static final String MORTGAGE_REF_NUMBER = "mortgageRefNumber";
    private static final String DATE_RANGE_ALL = "All"; // Pascal case is correct, confirmed against Swagger
    private static final int ONE = 1;
    private static final int ZERO = 0;
    private final RestTemplate iamJwtChainSecureRestTemplate;
    private UserService userService;
    private String applicationsUrl;
    private String applicationDetailsUrl;
    private String applicationDocumentsUrl;
    private CrmService crmService;
    private BrokerCoreResponseToApplicationRequestMapper brokerCoreResponseToApplicationRequestMapper;
    private ApplicationsResponseToCaseTrackingResponseMapper applicationsResponseToCaseTrackingResponseMapper;
    private ApplicationDetailsToTrackingApplicationDetailsMapper applicationDetailsToTrackingApplicationDetailsMapper;
    private ApplicationDetailsResponseToCaseMapper applicationDetailsResponseToCaseMapper;

    public CaseTrackingServiceImpl(@Qualifier(value = "iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
                                   UserService userService,
                                   @Value("${applications.url}") String applicationsUrl,
                                   @Value("${application.details.url}") String applicationDetailsUrl,
                                   @Value("${application.documents.url}") String applicationDocumentsUrl,
                                   CrmService crmService,
                                   BrokerCoreResponseToApplicationRequestMapper brokerCoreResponseToApplicationRequestMapper,
                                   ApplicationsResponseToCaseTrackingResponseMapper applicationsResponseToCaseTrackingResponseMapper,
                                   ApplicationDetailsToTrackingApplicationDetailsMapper applicationDetailsToTrackingApplicationDetailsMapper,
                                   ApplicationDetailsResponseToCaseMapper applicationDetailsResponseToCaseMapper
    ) {
        this.iamJwtChainSecureRestTemplate = iamJwtChainSecureRestTemplate;
        this.userService = userService;
        this.applicationsUrl = applicationsUrl;
        this.applicationDetailsUrl = applicationDetailsUrl;
        this.applicationDocumentsUrl = applicationDocumentsUrl;
        this.crmService = crmService;
        this.brokerCoreResponseToApplicationRequestMapper = brokerCoreResponseToApplicationRequestMapper;
        this.applicationsResponseToCaseTrackingResponseMapper = applicationsResponseToCaseTrackingResponseMapper;
        this.applicationDetailsToTrackingApplicationDetailsMapper =
                applicationDetailsToTrackingApplicationDetailsMapper;
        this.applicationDetailsResponseToCaseMapper = applicationDetailsResponseToCaseMapper;
    }

    @Override
    public CaseTrackingResponse getApplications(String brokerUserName, String pageNumber, String resultsPerPage,
                                                String lastName, String postcode, String brand) {
        log.debug("getApplications: Retrieving applications...");

        ApplicationsRequest applicationsRequest = buildApplicationsRequest(brokerUserName, pageNumber, resultsPerPage
                , lastName, postcode);
        String fcaNumber = applicationsRequest.getFcaNumber();
        log.debug("getApplications: Retrieving applications where fca number is: {}.",
            fcaNumber);

        HttpEntity httpEntity = new HttpEntity<>(AppUtil.buildBrandAndContentTypeHeaders(brand,
            MediaType.APPLICATION_JSON_VALUE));
        try {
            UriComponentsBuilder builder =
                    UriComponentsBuilder.fromHttpUrl(applicationsUrl);
            AppUtil.populateRequestParams(applicationsRequest, builder);
            log.debug("getApplications: calling  application  url: {} to get "
                    + "applications response, brand is: {}.",
                    applicationsUrl, brand);
            ResponseEntity<ApplicationsResponse> response =
                    iamJwtChainSecureRestTemplate.exchange(
                            builder.build().encode().toUri(),
                            HttpMethod.GET,
                            httpEntity,
                            ApplicationsResponse.class);
            ApplicationsResponse applicationsResponse = response.getBody();
            if (!Collections.isEmpty(applicationsResponse.getApplications())) {
                log.debug("getApplications: {} applications received from application"
                        + " tracking.", applicationsResponse.getApplications().size());
            }
            CaseTrackingResponse caseTrackingResponse =
                    applicationsResponseToCaseTrackingResponseMapper.toCaseTrackingResponse(applicationsResponse);
            String brokerFullName = buildFullName(applicationsRequest.getBrokerFirstName(),
                    applicationsRequest.getBrokerLastName());
            List<Case> cases = caseTrackingResponse.getCases();
            if (!Collections.isEmpty(cases)) {
                log.debug("getApplications: {} cases received after mapping.",
                    cases.size());
                for (Case aCase : cases) {
                    if (Objects.nonNull(aCase)) {
                        aCase.setBrokerName(brokerFullName);
                    }
                }
            } else {
                caseTrackingResponse.setCases(Lists.newArrayList());
            }
            return caseTrackingResponse;
        } catch (RestClientResponseException ex) {
            if (ex instanceof HttpClientErrorException) {
                log.warn("getApplications: HttpClientError Exception"
                    + " service: {}", ex.getMessage());
                if (HttpStatus.NOT_FOUND == ((HttpClientErrorException) ex).getStatusCode()) {
                    throw new ApplicationNotFoundException("getApplications: Exception - "
                        + "Applications not found for broker with FCA number: " + fcaNumber);
                }
            }
            log.warn("getApplications: RestClientResponseException occurred: {}", ex.getMessage());
            throw new ApplicationsServiceException(ex);
        } catch (Exception exception) {
            log.warn("getApplications: Application retrieval request failed: {}",
                exception.getMessage());
            throw new ApplicationsServiceException(exception);
        }
    }

    @Override
    public TrackingApplicationDetailResponse getApplication(String brokerUserName, String mortgageRefNumber,
                                                            String brand) {
        log.debug("getApplication: Retrieving application where broker user name is: {}.",
                brokerUserName);
        ApplicationsRequest applicationDetailRequest = getApplicationsRequest(brokerUserName);
        ApplicationDetailsResponse applicationDetailsResponse = getApplicationDetail(applicationDetailRequest,
                mortgageRefNumber, brand);
        log.debug("getApplication: Application retrieved successfully.");
        if (Objects.nonNull(applicationDetailsResponse)) {
            return applicationDetailsToTrackingApplicationDetailsMapper.toResponse(applicationDetailsResponse);
        } else {
            return null;
        }

    }

    private ApplicationDetailsResponse getApplicationDetail(ApplicationsRequest applicationDetailRequest,
                                                            String mortgageRefNumber,
                                                            String brand) {


        String fcaNumber = applicationDetailRequest.getFcaNumber();
        log.debug("getApplicationDetail: retrieving application detail where fcaNumber is: {}.",
            fcaNumber);

        HttpEntity httpEntity = new HttpEntity<>(AppUtil.buildBrandAndContentTypeHeaders(brand,
            MediaType.APPLICATION_JSON_VALUE));
        try {
            UriComponentsBuilder builder =
                    UriComponentsBuilder.fromHttpUrl(applicationDetailsUrl);
            Map<String, Object> uriVariables = new HashMap<>();
            uriVariables.put(MORTGAGE_REF_NUMBER, mortgageRefNumber);
            builder.uriVariables(uriVariables);
            AppUtil.populateRequestParamsForApplicationDetail(applicationDetailRequest, builder);
            log.debug("getApplicationDetail: Application detail retrieved successfully.");
            return getApplicationDetailsResponse(httpEntity, builder);

        } catch (RestClientResponseException ex) {
            if (ex instanceof HttpClientErrorException) {
                log.debug("getApplicationDetail: HttpClientError Exception occurred: {}", ex.getMessage());
                if (HttpStatus.NOT_FOUND == ((HttpClientErrorException) ex).getStatusCode()) {
                    log.debug("Inside caseTrackingService: Application not found for "
                        + "mortgageRefNumber : {}", mortgageRefNumber);
                    return null;
                }
            }
            log.warn("getApplicationDetail: RestClientResponseException Exception occurred: {}",
                    ex.getMessage());
            throw new ApplicationsServiceException(ex);
        } catch (Exception exception) {
            log.warn("getApplicationDetail: Application retrieval request failed: {}",
                exception.getMessage());
            throw new ApplicationsServiceException(exception);
        }
    }

    public CaseTrackingResponse getApplicationByMortgageReference(String brokerUserName, String mortgageRefNumber,
                                                                  String brand) {
        log.debug("getApplicationByMortgageReference: retrieving application by mortgage reference number"
            + " where selected broker is: {} and mortgage reference number is: {}.",
            brokerUserName, mortgageRefNumber);
        ApplicationsRequest applicationDetailRequest = getApplicationsRequest(brokerUserName);
        ApplicationDetailsResponse applicationDetailsResponse = getApplicationDetail(applicationDetailRequest,
                mortgageRefNumber, brand);
        if (Objects.nonNull(applicationDetailsResponse)) {
            Case applicationCase = applicationDetailsResponseToCaseMapper.toCase(applicationDetailsResponse);
            applicationCase.setBrokerName(buildFullName(applicationDetailRequest.getBrokerFirstName(),
                    applicationDetailRequest.getBrokerLastName()));
            log.debug("getApplicationByMortgageReference: Application successfully retrieved by"
                + " mortgageReferenceNumber: {}.", mortgageRefNumber);
            Page page = Page.builder().number(ONE).size(ONE).totalPages(ONE).totalElements(ONE).build();
            return CaseTrackingResponse.builder().cases(Lists.newArrayList(applicationCase)).page(page).build();
        } else {
            Page page = Page.builder().number(ZERO).size(ZERO).totalPages(ZERO).totalElements(ZERO).build();
            return CaseTrackingResponse.builder().cases(Lists.newArrayList()).page(page).build();
        }
    }

  @Override
  public CaseTrackingDocumentResponse getApplicationDocuments(String mortgageRefNumber,
      String brand) throws ApplicationsServiceException {
    String brokerUsername = userService.getBrokerUsername();
    HttpEntity httpEntity = new HttpEntity<>(AppUtil.buildBrandAndContentTypeHeaders(brand,
        MediaType.APPLICATION_JSON_VALUE));
    UriComponentsBuilder builder =
        UriComponentsBuilder.fromHttpUrl(applicationDocumentsUrl);
    Map<String, Object> uriVariables = new HashMap<>();
    uriVariables.put(MORTGAGE_REF_NUMBER, mortgageRefNumber);
    builder.uriVariables(uriVariables);
    URI uri = builder.build().encode().toUri();
    log.debug("getApplicationDocuments: Calling {} to get application documents with"
            + " mortgageRefNumber: {}, brokerUsername: {} and brand {}.",
        uri, mortgageRefNumber, brokerUsername, brand);
    try {
      ResponseEntity<CaseTrackingDocumentResponse> response =
          iamJwtChainSecureRestTemplate.exchange(
              uri,
              HttpMethod.GET,
              httpEntity,
              CaseTrackingDocumentResponse.class);

      CaseTrackingDocumentResponse applicationDocumentsResponse = response.getBody();
      if (applicationDocumentsResponse != null) {
        log.debug("getApplicationDocuments: {} successfully called to retrieved application"
                + " documents with mortgageRefNumber {}, brokerUsername {}, and brand {}.",
            uri, mortgageRefNumber, brokerUsername, brand);
        return applicationDocumentsResponse;
      } else {
        log.debug("getApplicationDocuments: {} returned null body while retrieving application"
                + " documents with mortgageRefNumber: {}, brokerUsername: {} and brand {} - throwing"
                + " ApplicationsServiceException.", uri, mortgageRefNumber, brokerUsername, brand);
        return null;
      }
    } catch (RestClientException ex) {
      if (ex instanceof HttpClientErrorException) {
        log.error("CaseTrackingService: An Http Client Error Exception occurred while calling"
                + " {} to retrieve application documents with mortgageRefNumber: {},"
                + " brokerUsername: {} and brand {}: {}",
            uri, mortgageRefNumber, brokerUsername, brand, ex.getMessage());
      } else {
        log.error(
            "CaseTrackingService: A rest client exception occurred while calling {} to"
                + " retrieve application documents with mortgageRefNumber: {}, brokerUsername: {}"
                + " and brand {}: {}",
            uri, mortgageRefNumber, brokerUsername, brand, ex.getMessage());
      }
      return null;
    } catch (Throwable t) {
      String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
      log.error("getApplicationDocuments: An unexpected exception occurred while calling {} to"
              + " retrieve application documents with mortgageRefNumber: {}, brokerUsername: {}"
              + " and brand {}: {}", uri, mortgageRefNumber, brokerUsername, brand, message);
      return null;
    }
  }

  private ApplicationsRequest getApplicationsRequest(String brokerUserName) {

        log.debug("getApplicationsRequest: retrieving applications request for {}...",
            brokerUserName);
        ApplicationsRequest applicationDetailRequest = buildApplicationsRequest(brokerUserName, StringUtils.EMPTY,
                StringUtils.EMPTY,
                StringUtils.EMPTY, StringUtils.EMPTY);
        log.debug("getApplicationsRequest: Application request for broker: {} "
            + "retrieved successfully.", brokerUserName);
        return applicationDetailRequest;
    }

    private ApplicationDetailsResponse getApplicationDetailsResponse(HttpEntity httpEntity,
                                                                     UriComponentsBuilder builder) {
        log.debug("getApplicationDetailsResponse: retrieving application details response...");
        ResponseEntity<ApplicationDetailsResponse> response =
                iamJwtChainSecureRestTemplate.exchange(
                        builder.build().encode().toUri(),
                        HttpMethod.GET,
                        httpEntity,
                        ApplicationDetailsResponse.class);
        log.debug("getApplicationDetailsResponse: Application details response retrieved successfully.");
        ApplicationDetailsResponse applicationDetailsResponse = response.getBody();
        return applicationDetailsResponse;
    }

    private ApplicationsRequest buildApplicationsRequest(String brokerUserName, String pageNumber,
                                                         String resultsPerPage, String lastName, String postcode) {
        ApplicationsRequest applicationsRequest;
        log.debug("buildApplicationsRequest: Building application request where brokerUserName"
                + " is: {}.", brokerUserName);

        Boolean isSelectedBrokerAndLoggedInBrokerSame = brokerUserName.equals(userService.getBrokerUsername());
        if (userService.getCheckForUserPrincipal() && isSelectedBrokerAndLoggedInBrokerSame) {
            log.debug("buildApplicationsRequest: Inside build application request where check for user principal is enabled.");
            UserDetails brokerDetails = userService.getDetails();
            applicationsRequest = ApplicationsRequest.builder()
                    .fcaNumber(brokerDetails.getFcaNumber())
                    .firmPostcode(brokerDetails.getFirmPostcode())
                    .brokerFirstName(brokerDetails.getBrokerFirstName())
                    .brokerLastName(brokerDetails.getBrokerLastName())
                    .brokerEmailId(brokerDetails.getBrokerEmailId())
                    .brokerPostcode(brokerDetails.getBrokerPostcode())
                    .build();
        } else {
            log.debug("buildApplicationsRequest: Inside build application request where check for user principal is disabled.");
            BrokerCoreResponse brokerCoreResponse = crmService.getBrokerDetails(brokerUserName);
            applicationsRequest =
                    brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse);
        }

        applicationsRequest.setSortBy(LAST_MODIFIED_DATE);
        applicationsRequest.setSortOrder(DESC);
        applicationsRequest.setDateRange(DATE_RANGE_ALL);

        if (StringUtils.isNotBlank(lastName)) {
            applicationsRequest.setApplicantLastName(lastName);
        }
        if (StringUtils.isNotBlank(postcode)) {
            applicationsRequest.setPropertyPostcode(postcode.toUpperCase(Locale.ROOT));
        }

        boolean isLastNameAndPostCodeSearch = StringUtils.isBlank(lastName) && StringUtils.isBlank(postcode);

        if (StringUtils.isNotBlank(pageNumber) && isLastNameAndPostCodeSearch) {
            applicationsRequest.setPageNumber(pageNumber);
        }
        if (StringUtils.isNotBlank(resultsPerPage)) {
            applicationsRequest.setResultPerPage(resultsPerPage);
        }

        log.debug("buildApplicationsRequest: Application request built successfully.");
        return applicationsRequest;
    }
}
