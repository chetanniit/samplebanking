package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import com.natwest.pbbdhb.broker.dashboard.util.AppUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = SpringMapperConfig.class, uses = AddressMapper.class)
public interface ApplicantToUiApplicantMapper {

    @Mapping(target = "name", source = ".", qualifiedByName = "buildName")
    @Mapping(target = "email", source = "contact.email")
    @Mapping(target = "correspondenceAddress", source = "address")
    @Mapping(target = "isMainApplicant", source = "isMainApplicant", qualifiedByName = "getIsMainApplicant")
    UiApplicant toUiApplicant(Applicant applicant);

    @Named("buildName")
    default String buildName(Applicant applicant) {
        return applicant.getFirstName() + " " +
                applicant.getLastName();
    }

    @Named("getIsMainApplicant")
    default Boolean getIsMainApplicant(String isMainApplicant) {
        return AppUtil.getIsMainApplicant(isMainApplicant);
    }
}
