package com.natwest.pbbdhb.broker.dashboard.model.applicant.search;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class QueryDto {
    private OperatorDto operator;
}
