package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;


@Getter
public class MRNValidateFailureException extends RuntimeException {
    public MRNValidateFailureException(String message) {
        super(message);
    }
}
