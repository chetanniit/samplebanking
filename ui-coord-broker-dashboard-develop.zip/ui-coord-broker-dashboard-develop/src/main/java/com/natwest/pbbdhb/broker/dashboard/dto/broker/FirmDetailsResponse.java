package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FirmDetailsResponse {

  private String brokerType;

  private String fcaNumber;

  private List<String> tradingNames;

  private List<PaymentPath> paymentPaths;

  private List<PrincipalFcaFirm> principalFcaFirms;

}
