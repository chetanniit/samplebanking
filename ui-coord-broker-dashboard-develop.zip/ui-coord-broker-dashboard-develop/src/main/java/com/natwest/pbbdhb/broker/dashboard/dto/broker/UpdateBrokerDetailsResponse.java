package com.natwest.pbbdhb.broker.dashboard.dto.broker;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.NonSTPFieldCategory;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.RequestedType;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateBrokerDetailsResponse {

  @NotNull
  private List<RequestedType> requestedTypes;

  @NotNull
  private List<NonSTPFieldCategory> processingFields;

}
