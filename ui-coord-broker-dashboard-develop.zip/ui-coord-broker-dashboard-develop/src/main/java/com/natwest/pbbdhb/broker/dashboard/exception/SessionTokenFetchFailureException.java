package com.natwest.pbbdhb.broker.dashboard.exception;


import lombok.Getter;

@Getter
public class SessionTokenFetchFailureException extends HttpCustomException {
    public SessionTokenFetchFailureException(Exception exception) {
        super(exception);
    }
}
