package com.natwest.pbbdhb.broker.dashboard.service.impl;

import static com.natwest.pbbdhb.broker.dashboard.util.AppUtil.buildFullName;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.FirmDetails;
import com.natwest.pbbdhb.broker.dashboard.service.CrmService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

    private UserClaimsProvider userClaimsProvider;
    private Boolean checkForUserPrincipal;
    private final CrmService crmService;

    public UserServiceImpl(UserClaimsProvider userClaimsProvider,
                           @Value("${check.for.user.principal}") Boolean checkForUserPrincipal,
                           CrmService crmService) {
        this.userClaimsProvider = userClaimsProvider;
        this.checkForUserPrincipal = checkForUserPrincipal;
        this.crmService = crmService;
    }

    @Override
    public Boolean getCheckForUserPrincipal() {
        return checkForUserPrincipal;
    }

    public UserDetails getDetails() {
        log.debug("getDetails: Getting user details...");

        switch (userClaimsProvider.getBrokerType()) {
            case ADMIN:
              log.debug("getDetails: Creating user details for admin.");
                return createAdminUserDetails();
            case BROKER:
              log.debug("getDetails: Creating user details for broker.");
              return createBrokerUserDetails();
            default:
                throw new IllegalStateException("Unexpected value: " + userClaimsProvider.getBrokerType());
        }
    }

    public String getBrokerFcaNumber(String brokerUsername) {
        log.debug("getBrokerFcaNumber: Retrieving broker fca number for brokerUsername: {}.",
            brokerUsername);
        final BrokerCoreResponse brokerResponse = crmService.getBrokerDetails(brokerUsername);
        log.debug("getBrokerFcaNumber: Broker fca number for broker username: {},"
                + " successfully retrieved.", brokerUsername);
        return brokerResponse.getFirmDetails().getFcaNumber();
    }

    public String getBrokerUsername() {
      log.debug("getBrokerUsername: Retrieving broker username.");
        return userClaimsProvider.getBrokerUsername();
    }

    private UserDetails createBrokerUserDetails() {
      log.debug("createBrokerUserDetails: Creating broker user details.");
        final BrokerCoreResponse brokerResponse =
                crmService.getBrokerDetails(userClaimsProvider.getBrokerUsername());
        final BrokerDetails brokerDetails = brokerResponse.getBroker();
        final FirmDetails firmDetails = brokerResponse.getFirmDetails();

        return UserDetails.builder()
                .userName(userClaimsProvider.getBrokerUsername())
                .fullName(buildFullName(brokerDetails.getFirstName(), brokerDetails.getLastName()))
                .brokerType(userClaimsProvider.getBrokerType())
                .brokerFirstName(brokerDetails.getFirstName())
                .brokerLastName(brokerDetails.getLastName())
                .brokerEmailId(brokerDetails.getEmailAddress())
                .brokerPostcode(brokerDetails.getBrokerPostcode())
                .fcaNumber(firmDetails.getFcaNumber())
                .firmPostcode(firmDetails.getFirmAddressPostcode())
                .principalFCANumber(firmDetails.getPrincipleFCANumber())
                .build();
    }

    private UserDetails createAdminUserDetails() {
      log.debug("createAdminUserDetails: Creating admin user details.");
        final AdminCoreResponse adminResponse = crmService.getAdminDetails(userClaimsProvider.getBrokerUsername());

        return UserDetails.builder()
                .userName(userClaimsProvider.getBrokerUsername())
                .fullName(buildFullName(adminResponse.getFirstName(), adminResponse.getLastName()))
                .brokerType(userClaimsProvider.getBrokerType())
                .brokerFirstName(adminResponse.getFirstName())
                .brokerLastName(adminResponse.getLastName())
                .brokerEmailId(adminResponse.getEmailAddress())
                .build();
    }
}
