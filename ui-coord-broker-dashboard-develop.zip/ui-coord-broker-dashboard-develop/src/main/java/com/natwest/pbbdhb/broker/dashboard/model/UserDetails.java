package com.natwest.pbbdhb.broker.dashboard.model;

import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class UserDetails {
    private String userName;
    private String fullName;
    private BrokerType brokerType;
    private String fcaNumber;
    private String firmPostcode;
    private String brokerFirstName;
    private String brokerLastName;
    private String brokerEmailId;
    private String brokerPostcode;
    private String principalFCANumber;
}
