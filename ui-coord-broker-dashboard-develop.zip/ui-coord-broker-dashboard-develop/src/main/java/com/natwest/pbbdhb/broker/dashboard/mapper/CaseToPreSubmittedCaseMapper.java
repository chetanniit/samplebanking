package com.natwest.pbbdhb.broker.dashboard.mapper;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FMA_SUBMITTED;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUBMIT_FMA_IN_PROGRESS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUBMIT_GMS_MOPS;

import com.natwest.pbbdhb.broker.dashboard.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.dashboard.dto.Esis;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonAddress;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;
import com.natwest.pbbdhb.broker.dashboard.model.cases.Broker;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import com.natwest.pbbdhb.broker.dashboard.model.cases.DecisionInPrinciple;
import com.natwest.pbbdhb.broker.dashboard.model.cases.SalesIllustration;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationType;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Component
@Slf4j
public class CaseToPreSubmittedCaseMapper {


    private static final String SEPARATOR = "/";
    private static final String ESIS_DESCRIPTION = "esisDescription";

    public PreSubmittedCase toPreSubmittedCase(CaseApplication caseApplication, List<Applicant> applicants) {
        log.debug("toPreSubmittedCase: Mapping preSubmittedCase with caseId: {}"
                + " for broker: {}.",
            caseApplication.getCaseId(), caseApplication.getBroker().getBrokerUsername());
        PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
        setApplicationTypeAndStatus(preSubmittedCase, caseApplication);
        if (Objects.isNull(preSubmittedCase.getType())) {
            log.debug("toPreSubmittedCase: Omitting failure case.");
            return null;
        }
        preSubmittedCase.setCaseId(caseApplication.getCaseId());
        preSubmittedCase.setLastUpdated(caseApplication.getModifiedDate());
        if (applicants != null && !applicants.isEmpty()) {
          for (Applicant applicant : applicants) {
            setApplicant(preSubmittedCase, applicant, caseApplication.getBroker());
          }
        }
        preSubmittedCase.setLastUpdated(caseApplication.getModifiedDate());

        log.debug("toPreSubmittedCase: PreSubmittedCase with caseId: {} for "
                + "broker: {} mapped successfully.",
            caseApplication.getCaseId(), caseApplication.getBroker().getBrokerUsername());
        return preSubmittedCase;
    }

    private void setApplicationTypeAndStatus(PreSubmittedCase preSubmittedCase, CaseApplication caseApplication) {
        log.debug("setApplicationTypeAndStatus: Setting application type and status for "
                + "broker: {}, caseId: {}.",
            caseApplication.getBroker().getBrokerUsername(), caseApplication.getCaseId());
        String applicationStatus = caseApplication.getApplicationStatus();
        List<DecisionInPrinciple> decisionInPrinciples = caseApplication.getDecisionInPrinciples();
        boolean isStatusEmpty = StringUtils.isBlank(applicationStatus);
        boolean isDipBlockEmpty = CollectionUtils.isEmpty(decisionInPrinciples);
        log.debug("setApplicationTypeAndStatus: Broker: {}, CaseId: {}, isDipBlockEmpty: {}.",
            caseApplication.getBroker().getBrokerUsername(), caseApplication.getCaseId(), isDipBlockEmpty);
        if (isDipBlockEmpty) {
            preSubmittedCase.setType(ApplicationType.AIP);
            preSubmittedCase.setApplicationStatus(ApplicationStatus.IN_PROGRESS.getLabel());
        } else if (isStatusEmpty) {
            preSubmittedCase.setType(ApplicationType.AIP);
            preSubmittedCase.setApplicationStatus(ApplicationStatus.COMPLETED.getLabel());
        }

        Boolean isEsis = caseApplication.getIsEsis();
        log.debug("setApplicationTypeAndStatus: Broker: {}, CaseId: {}, isEsis {}.",
            caseApplication.getBroker().getBrokerUsername(), caseApplication.getCaseId(), isEsis);
        if (isEsis != null && isEsis) {
            preSubmittedCase.setApplicationStatus(ApplicationStatus.IN_PROGRESS.getLabel());
            preSubmittedCase.setType(ApplicationType.ESIS);
            SalesIllustration salesIllustration = caseApplication.getSalesIllustrations().get(0);
            if (Objects.nonNull(salesIllustration)) {
                List<String> documentUrls = salesIllustration.getDocumentUrls();
                if (!CollectionUtils.isEmpty(documentUrls)) {
                    preSubmittedCase.setApplicationStatus(ApplicationStatus.COMPLETED.getLabel());
                    String url = documentUrls.get(0);
                    if (StringUtils.isNotBlank(url)) {
                        Esis esis = new Esis();
                        String fileName = StringUtils.substringAfterLast(url, SEPARATOR);
                        fileName = StringUtils.isNotBlank(fileName) ? fileName : StringUtils.substringAfterLast(url,
                                SEPARATOR);
                        if (StringUtils.isNotBlank(fileName)) {
                            esis.setFileName(fileName);
                            preSubmittedCase.setEsis(esis);
                            Map<String, Object> journeyData = caseApplication.getJourneyData();
                            if (Objects.nonNull(journeyData) && Objects.nonNull(journeyData.get(ESIS_DESCRIPTION))) {
                                esis.setDescription(journeyData.get(ESIS_DESCRIPTION).toString());
                            }
                        }

                    }
                }
            }
        }
        log.debug("setApplicationTypeAndStatus: Broker: {}, CaseId: {}, isStatusEmpty {}.",
            caseApplication.getBroker().getBrokerUsername(), caseApplication.getCaseId(), isStatusEmpty);
        if (!isStatusEmpty && (applicationStatus.equals(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS) ||
                applicationStatus.equals(SUBMIT_GMS_MOPS) || applicationStatus.equals(SUBMIT_FMA_IN_PROGRESS))) {

            preSubmittedCase.setType(ApplicationType.FMA);
            Boolean fmaSubmitted = (Boolean) Optional.ofNullable(caseApplication.getJourneyData())
                .orElse(Collections.emptyMap()).get(FMA_SUBMITTED);
            log.debug("setApplicationTypeAndStatus: Broker: {}, CaseId: {},"
                    + " applicationStatus {}, fmaSubmitted {}.",
                caseApplication.getBroker().getBrokerUsername(), caseApplication.getCaseId(), applicationStatus, fmaSubmitted);

            if (applicationStatus.equals(SUBMIT_GMS_MOPS)
                || applicationStatus.equals(SUBMIT_FMA_IN_PROGRESS)
                || (fmaSubmitted != null && fmaSubmitted)) {
                preSubmittedCase.setApplicationStatus(ApplicationStatus.SUBMISSION_IN_PROGRESS.getLabel());
            } else {
                preSubmittedCase.setApplicationStatus(ApplicationStatus.IN_PROGRESS.getLabel());
            }

        }
    }

    private void setApplicant(PreSubmittedCase preSubmittedCase, Applicant applicantModel, Broker broker) {

        List<ApplicantDto> applicants = preSubmittedCase.getApplicants();
        ApplicantDto applicantDto = new ApplicantDto();
        String applicantCaseId = applicantModel.getCaseId();
        String caseId = preSubmittedCase.getCaseId();
        log.debug("setApplicant: Setting applicant for preSubmittedCaseId: {},"
                + " applicantCaseId: {}, broker: {}.",
            caseId, applicantCaseId, broker.getBrokerUsername());
        if (caseId.equals(applicantCaseId)) {
            Optional<PersonAddress> currentAddress =
                    personAddressesStream(applicantModel.getAddresses())
                            .filter(address -> (Objects.nonNull(address.getIsCurrentAddress()) && address.getIsCurrentAddress()))
                            .findFirst();

            boolean isNotEsisType = preSubmittedCase.getType() != ApplicationType.ESIS;
            if (currentAddress.isPresent()) {
                applicantDto.setPostcode(currentAddress.get().getPostcode());
            } else if (isNotEsisType) {
                log.error("setApplicant: Broker: {}, ApplicantId: {}, isEsis: false."
                        + "Message: Current address is not present for the applicant.",
                    broker.getBrokerUsername(), applicantModel.getApplicantId());
            }

            PersonDetails personalDetails = applicantModel.getPersonalDetails();
            if (Objects.nonNull(personalDetails)) {
                applicantDto.setFirstNames(personalDetails.getFirstNames());
                applicantDto.setLastName(personalDetails.getLastName());
                applicantDto.setDateOfBirth(personalDetails.getDateOfBirth());
            }
        } else {
            log.error("setApplicant: Broker: {}, Case application caseId: {},"
                    + " Applicant caseId: {}, Message: Case application caseId and applicant caseId"
                    + " did not match.", broker.getBrokerUsername(), caseId, applicantCaseId);
        }
        applicants.add(applicantDto);
    }

    private Stream<PersonAddress> personAddressesStream(Collection<PersonAddress> collection) {
        return Optional.ofNullable(collection)
                .map(Collection::stream)
                .orElseGet(Stream::empty);
    }
}