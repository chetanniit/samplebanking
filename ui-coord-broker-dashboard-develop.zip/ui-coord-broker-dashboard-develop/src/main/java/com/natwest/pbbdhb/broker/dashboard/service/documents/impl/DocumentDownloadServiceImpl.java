package com.natwest.pbbdhb.broker.dashboard.service.documents.impl;

import com.natwest.pbbdhb.broker.dashboard.authorisation.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.exception.DocumentDownloadException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.service.documents.DocumentDownloadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.MSG_NO_MAF_DOWNLOAD_PERMISSION;

@Service
@Slf4j
public class DocumentDownloadServiceImpl implements DocumentDownloadService {

    private String esisEndpoint;
    private String fmaEndpoint;
    private RestTemplate restTemplate;
    private UserClaimsProvider userClaimsProvider;
    private AccessPermissionChecker accessPermissionChecker;

    public DocumentDownloadServiceImpl(@Value("${msvc.esis.document.download.url}") String esisEndpoint,
                                       @Value("${msvc.fma.document.download.url}") String fmaEndpoint,
                                       RestTemplate iamJwtChainSecureRestTemplate,
                                       UserClaimsProvider userClaimsProvider,
                                       AccessPermissionChecker accessPermissionChecker) {
        this.esisEndpoint = esisEndpoint;
        this.fmaEndpoint = fmaEndpoint;
        this.restTemplate = iamJwtChainSecureRestTemplate;
        this.userClaimsProvider = userClaimsProvider;
        this.accessPermissionChecker = accessPermissionChecker;
    }

    @Override
    public Optional<byte[]> getESISDocument(String fileName) {
        log.debug("getESISDocument: Retrieving ESIS document, fileName: {}.",
            fileName);

        return getDocument(fileName, esisEndpoint);
    }

    @Override
    public Optional<byte[]> getFMADocument(String brand, String fileName) {
        log.debug("getFMADocument: Retrieving FMA document, fileName: {}.",
                fileName);
        String caseId = getCaseIdFromFileName(fileName);
        log.debug("caseId obtained from document name {}", caseId);
        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
            log.error("Error downloading maf document with caseId {} and brokerUsername {} and fileName {} : {}",
                    caseId, userClaimsProvider.getBrokerUsername(), fileName, MSG_NO_MAF_DOWNLOAD_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_MAF_DOWNLOAD_PERMISSION);
        }
        return getDocument(fileName, fmaEndpoint);
    }

    private Optional<byte[]> getDocument(String fileName, String esisEndpoint) {
        log.debug("getDocument: Retrieving document, fileName: {},"
                + " esisEndPoint: {}.", fileName, esisEndpoint);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity httpEntity = new HttpEntity<>(headers);

        ResponseEntity<byte[]> response;
        try {
            response = restTemplate.exchange(String.format(esisEndpoint, fileName), HttpMethod.GET
                    , httpEntity,
                    byte[].class);
            log.debug("getDocument: Document successfully retrieved.");
        } catch (RestClientException ex) {
            throw new DocumentDownloadException(ex);
        }

        return Optional.of(response.getBody());
    }

    private String getCaseIdFromFileName(String documentName) {
        String[] docAttributes = documentName.split("-");
        return docAttributes[1];
    }
}
