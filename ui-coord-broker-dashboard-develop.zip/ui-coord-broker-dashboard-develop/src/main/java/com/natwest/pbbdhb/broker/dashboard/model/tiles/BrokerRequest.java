package com.natwest.pbbdhb.broker.dashboard.model.tiles;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@Data
@Schema(description = "Broker Object")
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Builder
public class BrokerRequest {
    private String fcaNumber;
    private String brokerSurname;
    private String brokerForeName;
    private String brokerPostcode;
    private String brokerEmail;
    private String brokerUsername;
}