package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.ApplicationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = SpringMapperConfig.class, uses = ApplicationToCaseMapper.class)
public interface ApplicationsResponseToCaseTrackingResponseMapper {

    @Mapping(target = "cases", source = "applications")
    CaseTrackingResponse toCaseTrackingResponse(ApplicationsResponse applicationsResponse);
}
