/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.broker.dashboard.util.BigDecimalSerializer;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductInfo {
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal totalLoanAmount;
    private String ltv;
    private String applicationType;
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal feeAmount;
    private String feeStatus;
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal cashback;
    private BigDecimal monthlyRepaymentAmount;
    private List<Product> products;
    private Boolean isFeePaymentComplete;
    private String paymentTileStatus;
}
