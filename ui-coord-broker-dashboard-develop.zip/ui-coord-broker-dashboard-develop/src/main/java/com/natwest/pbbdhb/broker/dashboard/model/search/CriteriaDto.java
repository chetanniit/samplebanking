package com.natwest.pbbdhb.broker.dashboard.model.search;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class CriteriaDto {
    private QueryDto query;
    private FieldsDto fields;
    private SortDto sort;
}
