package com.natwest.pbbdhb.broker.dashboard.controller;

import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.exception.UIErrorResponse;
import com.natwest.pbbdhb.broker.dashboard.model.SuccessResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;

public interface BrokerCaseControllerSwagger {
    @Operation(summary = "Get pre submitted cases for the broker")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = PreSubmittedCases.class))),
            @ApiResponse(responseCode = "400", description = "BAD_REQUEST", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "NOT_AUTHENTICATED", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "403", description = "FORBIDDEN", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/broker/cases", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PreSubmittedCases> getPreSubmittedCases(@Parameter(description = "Brand",
            example = "nwb") @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
            message = "Invalid Brand") String brand,
                                                           @RequestParam(name = "pageNumber", required = false,
                                                                   defaultValue = "0") String pageNumber,
                                                           @RequestParam(name = "resultsPerPage", required = false,
                                                                   defaultValue = "15") String resultsPerPage,
                                                           @RequestParam(name = "lastName", required = false) String lastName,
                                                           @RequestParam(name = "postcode", required = false) String postcode,
                                                           @RequestParam(name = "dateOfBirth", required = false) String dateOfBirth,
                                                           @RequestParam(name = "type", required = false) String type,
                                                           @RequestParam(name = "status", required = false) String status);

    @Operation(summary = "Get submitted cases for the broker")
    @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SubmittedCases.class))),
          @ApiResponse(responseCode = "400", description = "BAD_REQUEST", content = @Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = UIErrorResponse.class))),
          @ApiResponse(responseCode = "401", description = "NOT_AUTHENTICATED", content = @Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = UIErrorResponse.class))),
          @ApiResponse(responseCode = "403", description = "FORBIDDEN", content = @Content(mediaType = APPLICATION_JSON_VALUE
              , schema = @Schema(implementation = UIErrorResponse.class))),
          @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND", content = @Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = UIErrorResponse.class))),
          @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR", content = @Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/broker/submitted-cases", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SubmittedCases> getSubmittedCases(@Parameter(description = "Brand",
        example = "nwb") @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
        message = "Invalid Brand") String brand,
                                                           @RequestParam(name = "pageNumber", required = false,
                                                                   defaultValue = "0") String pageNumber,
                                                           @RequestParam(name = "resultsPerPage", required = false,
                                                                   defaultValue = "15") String resultsPerPage,
                                                           @RequestParam(name = "brokerUsername") String brokerUsername,
                                                           @RequestParam(name = "mortgageReferenceNumber", required = false) String mortgageReferenceNumber,
                                                           @RequestParam(name = "lastName", required = false) String lastName,
                                                           @RequestParam(name = "postcode", required = false) String postcode,
                                                           @RequestParam(name = "dateOfBirth", required = false) String dateOfBirth);

    @Operation(summary = "Get ESIS Document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(mediaType =
                APPLICATION_PDF_VALUE)),
            @ApiResponse(responseCode = "400", description = "BAD_REQUEST", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "NOT_AUTHENTICATED", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "SERVICE_NOT_AVAILABLE", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/esis/{documentName}",
            produces = APPLICATION_PDF_VALUE)
    ResponseEntity<InputStreamResource> getESISDocument(@PathVariable String documentName);

    @Operation(summary = "Get MAF Document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(mediaType =
                APPLICATION_PDF_VALUE)),
            @ApiResponse(responseCode = "400", description = "BAD_REQUEST", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "NOT_AUTHENTICATED", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "SERVICE_NOT_AVAILABLE", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/maf/{documentName}",
            produces = APPLICATION_PDF_VALUE)
    ResponseEntity<InputStreamResource> getMafDocument(@Parameter(description = "Brand",
            example = "nwb") @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
            message = "Invalid Brand") String brand, @PathVariable String documentName);

    @Operation(summary = "Submit Product Change")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(mediaType =
                    APPLICATION_JSON_VALUE, schema = @Schema(implementation = SuccessResponse.class))),
            @ApiResponse(responseCode = "400", description = "BAD_REQUEST", content = @Content(mediaType =
                    APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "NOT_AUTHENTICATED", content = @Content(mediaType =
                    APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND", content = @Content(mediaType =
                    APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR", content = @Content(mediaType =
                    APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "SERVICE_NOT_AVAILABLE", content = @Content(mediaType =
                    APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @PostMapping(path = "/{caseId}/product-change",
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SuccessResponse> submitProductChange(@RequestBody @Valid ProductChangeRequest request, @PathVariable String caseId, @Parameter(description = "Brand",
            example = "nwb") @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
            message = "Invalid Brand") String brand);
}
