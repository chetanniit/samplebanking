package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ProductInformation;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ProductInfo;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;

@Mapper(config = SpringMapperConfig.class, uses = ProductToProductMapper.class)
public interface ProductInformationToProductInfoMapper {

    String TO_BE_PAID_ON_COMPLETION_FEE_STATUS = "To be paid on completion";
    String PAID_FEE_STATUS = "Paid";
    String PAID_FEE_STATUS_LOAN = "Added to Loan";
    String FREE = "Free";

    @Mapping(target = " isFeePaymentComplete", source = "feeStatus", qualifiedByName = "deriveFeePaymentComplete")
    @Mapping(target = "monthlyRepaymentAmount", source = "totalRepaymentAmount")
    @Mapping(target = "applicationType", source = "mortgageType")
    @Mapping(target = "feeAmount", source = "feeAmount", qualifiedByName = "deriveFeeAmount", defaultExpression =
            "java(BigDecimal.ZERO)")
    ProductInfo toProductInfo(ProductInformation productInformation);

    @Named("deriveFeePaymentComplete")
    default Boolean deriveFeePaymentComplete(String feeStatus) {
        if (TO_BE_PAID_ON_COMPLETION_FEE_STATUS.equals(feeStatus)) {
            return false;
        } else if (PAID_FEE_STATUS.equals(feeStatus) || FREE.equals(feeStatus) || PAID_FEE_STATUS_LOAN.equals(feeStatus)) {
            return true;
        }
        return null; //NOSONAR
    }

    @Named("deriveFeeAmount")
    default BigDecimal deriveFeeAmount(String feeAmount) {
        return StringUtils.isNotBlank(feeAmount) ? new BigDecimal(feeAmount) : BigDecimal.ZERO;
    }
}
