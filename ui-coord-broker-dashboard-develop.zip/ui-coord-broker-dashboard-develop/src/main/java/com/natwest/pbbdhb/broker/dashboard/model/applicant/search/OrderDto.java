package com.natwest.pbbdhb.broker.dashboard.model.applicant.search;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Sort;

@Setter
@Getter
public class OrderDto {
    private Sort.Direction direction = Sort.Direction.DESC;
    private String field;
    private boolean ignoreCase;
    private Sort.NullHandling nullHandling = Sort.NullHandling.NATIVE;
}

