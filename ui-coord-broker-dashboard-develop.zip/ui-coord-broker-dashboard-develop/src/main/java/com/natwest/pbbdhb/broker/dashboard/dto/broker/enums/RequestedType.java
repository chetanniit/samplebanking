package com.natwest.pbbdhb.broker.dashboard.dto.broker.enums;

public enum RequestedType {
    STP, NON_STP
}
