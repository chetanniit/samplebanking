package com.natwest.pbbdhb.broker.dashboard.model.applicant;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PersonDetails {

    private String firstNames;
    private String lastName;
    private String title;
    private LocalDate dateOfBirth;

}
