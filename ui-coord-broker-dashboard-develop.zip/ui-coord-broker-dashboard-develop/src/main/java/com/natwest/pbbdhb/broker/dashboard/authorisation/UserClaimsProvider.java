package com.natwest.pbbdhb.broker.dashboard.authorisation;

import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;

/**
 * Provides user claims related to a specific request.
 */
public interface UserClaimsProvider {
    String getBrokerUsername();

    BrokerType getBrokerType();
}
