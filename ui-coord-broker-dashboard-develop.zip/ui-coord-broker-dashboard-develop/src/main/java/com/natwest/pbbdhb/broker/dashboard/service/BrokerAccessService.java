package com.natwest.pbbdhb.broker.dashboard.service;

public interface BrokerAccessService {

  boolean checkRequestedBrokerHasAccess(String brokerUsername);

}
