package com.natwest.pbbdhb.broker.dashboard.dto.broker.enums;

public enum PermissionType {
    GRANT_ACCESS, REMOVE_ACCESS
}
