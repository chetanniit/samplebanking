package com.natwest.pbbdhb.broker.dashboard.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@Builder
@Schema(description = "Case applicant")
@AllArgsConstructor
@NoArgsConstructor
public class ApplicantDto {

    @Schema(example = "Gary")
    private String firstNames;
    @Schema(example = "Baker")
    private String lastName;
    @Schema(example = "1978-12-31")
    private LocalDate dateOfBirth;
    @Schema(example = "SE11 9XB")
    private String postcode;

}
