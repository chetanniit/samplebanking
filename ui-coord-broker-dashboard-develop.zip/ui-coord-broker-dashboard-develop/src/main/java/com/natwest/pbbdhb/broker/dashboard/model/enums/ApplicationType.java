package com.natwest.pbbdhb.broker.dashboard.model.enums;

public enum ApplicationType {
    AIP,
    FMA,
    ESIS
}
