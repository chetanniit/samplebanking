package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.kafka.dto.ProductChangeEventDto;

public interface ProducerService {
    void sendProductChangeEvent(ProductChangeEventDto productChangeEventDto);
}
