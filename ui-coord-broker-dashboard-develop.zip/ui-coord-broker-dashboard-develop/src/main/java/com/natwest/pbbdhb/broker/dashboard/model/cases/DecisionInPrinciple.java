package com.natwest.pbbdhb.broker.dashboard.model.cases;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DecisionInPrinciple {

    private String dipId;

    private String decisionUniqueId;

}
