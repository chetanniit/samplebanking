package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.model.tiles.DocumentsUploadURLResponse;

public interface DocumentsUploadService {
    DocumentsUploadURLResponse getDocumentsUploadURL(String mortgageReferenceNumber, String brand);
}
