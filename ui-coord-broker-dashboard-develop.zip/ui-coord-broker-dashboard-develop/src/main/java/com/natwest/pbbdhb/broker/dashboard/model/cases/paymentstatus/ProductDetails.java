package com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductDetails {

    private String productCode;

    private String productType;

    private String productTerm;

    //private BigDecimal rateOfInterest;

    private Long ltv;

    private String productSelectedDate;

    private List<Fee> fees;
}

