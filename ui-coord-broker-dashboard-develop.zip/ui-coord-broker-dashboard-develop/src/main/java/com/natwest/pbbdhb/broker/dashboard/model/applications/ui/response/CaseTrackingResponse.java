package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.natwest.pbbdhb.broker.dashboard.model.applications.response.Page;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Case;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
public class CaseTrackingResponse {
    private Page page;
    private List<Case> cases;
}
