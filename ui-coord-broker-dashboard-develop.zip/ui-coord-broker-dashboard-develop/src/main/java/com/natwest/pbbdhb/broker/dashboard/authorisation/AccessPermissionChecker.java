package com.natwest.pbbdhb.broker.dashboard.authorisation;

import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDto;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class AccessPermissionChecker {

    private final CaseService caseService;

    private final UserClaimsProvider userClaimsProvider;

    public boolean isBroker() {
        BrokerType brokerType = userClaimsProvider.getBrokerType();
        log.debug("Broker type for broker with brokerUsername {} is {}", userClaimsProvider.getBrokerUsername(), brokerType.name());
        return BrokerType.BROKER.equals(brokerType);
    }

    public boolean isCaseOwner(String brand, String caseId) {
        if (!isBroker()) {
            log.debug("Broker with brokerUsername {} and case id {} is not broker", userClaimsProvider.getBrokerUsername(), caseId);
            return false;
        }

        String loggedInUser = getLoggedInUser();
        if (loggedInUser == null) {
            log.debug("Broker with brokerUsername {} and case id {} is not logged in", userClaimsProvider.getBrokerUsername(), caseId);
            return false;
        }

        String caseOwner = getCaseOwner(brand, caseId);
        return loggedInUser.equalsIgnoreCase(caseOwner);
    }

    private String getLoggedInUser() {
        return userClaimsProvider.getBrokerUsername();
    }

    private String getCaseOwner(String brand, String caseId) {
        CaseApplicationDto caseApplicationDto = caseService.getCaseByCaseId(caseId, brand);
        BrokerDto brokerDto = caseApplicationDto.getBroker();
        if (brokerDto == null) {
            log.debug("Broker details for broker with brokerUsername {} and case id {} are null", userClaimsProvider.getBrokerUsername(), caseId);
            return null;
        }

        return brokerDto.getBrokerUsername();
    }
}
