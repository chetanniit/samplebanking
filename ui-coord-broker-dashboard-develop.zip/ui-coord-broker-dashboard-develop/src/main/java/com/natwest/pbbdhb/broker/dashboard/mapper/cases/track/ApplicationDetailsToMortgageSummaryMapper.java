package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.mapper.SpringMapperConfig;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.HistoryDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.StageHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.Milestones;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.MortgageSummary;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.Objects;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.GREEN_RAG_STATUS;

@Mapper(config = SpringMapperConfig.class, injectionStrategy = InjectionStrategy.FIELD)
public abstract class ApplicationDetailsToMortgageSummaryMapper {

    @Autowired
    private ApplicationDetailsResponseToMilestoneMapper applicationDetailsResponseToMilestoneMapper;

    @Mapping(target = "mortgageReferenceNumber", source = "referenceNumber")
    @Mapping(target = "applicationStatus", source = "status.status")
    @Mapping(target = "latestOfferDate", source = ".", qualifiedByName = "getLatestOfferDate")
    @Mapping(target = "expectedCompletionDate", source = "status.expectedCompletionDate")
    @Mapping(target = "milestones", source = ".", qualifiedByName = "setMilestones")
    public abstract MortgageSummary toMortgageSummary(ApplicationDetailsResponse applicationDetailsResponse);

    @Named("getLatestOfferDate")
    public LocalDateTime getLatestOfferDate(ApplicationDetailsResponse applicationDetailsResponse) {
        String status = applicationDetailsResponse.getStatus().getStatus();
        HistoryDetails applicationDetails = applicationDetailsResponse.getApplicationDetails();
        if (StringUtils.isNotBlank(status) && Objects.nonNull(applicationDetails.getStageHistory())
                && !applicationDetails.getStageHistory().isEmpty()) {
            StageHistoryDetail matchedStageHistoryDetail =
                    applicationDetailsResponseToMilestoneMapper.getMatchingStageHistory(applicationDetailsResponse.getApplicationDetails().getStageHistory(),
                            status);
            if (Objects.nonNull(matchedStageHistoryDetail) && GREEN_RAG_STATUS.equals(matchedStageHistoryDetail.getRagStatus())
                    && Objects.nonNull(matchedStageHistoryDetail.getTimeClosed())) {
                ZonedDateTime offerDateFromSource = matchedStageHistoryDetail.getTimeClosed();
                return offerDateFromSource.toLocalDateTime();
            }
        }
        return null;
    }

    @Named("setMilestones")
    public Milestones setMilestones(ApplicationDetailsResponse applicationDetailsResponse) {
        return applicationDetailsResponseToMilestoneMapper.toMilestones(applicationDetailsResponse);
    }
}
