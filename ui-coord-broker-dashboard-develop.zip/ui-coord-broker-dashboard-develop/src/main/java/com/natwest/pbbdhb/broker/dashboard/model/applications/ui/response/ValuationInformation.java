package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.broker.dashboard.util.BigDecimalSerializer;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ValuationInformation {
    private String valuationInstructionDate;
    private String valuationDate;
    private String valuationReceived;
    private String valuationAccepted;
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal valuationFeeAmount;
}
