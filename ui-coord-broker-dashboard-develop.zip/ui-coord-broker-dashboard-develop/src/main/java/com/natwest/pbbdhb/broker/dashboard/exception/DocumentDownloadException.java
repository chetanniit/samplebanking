package com.natwest.pbbdhb.broker.dashboard.exception;

public class DocumentDownloadException extends HttpCustomException{

    public DocumentDownloadException(Exception ex) {
        super(ex);
    }
}
