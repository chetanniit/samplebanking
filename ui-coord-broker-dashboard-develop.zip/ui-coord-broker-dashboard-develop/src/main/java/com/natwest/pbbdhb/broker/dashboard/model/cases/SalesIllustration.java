package com.natwest.pbbdhb.broker.dashboard.model.cases;

import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.ProductDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class SalesIllustration {

    private List<String> documentUrls;
    private Boolean isAccepted;
    private List<ProductDetails> products;
}
