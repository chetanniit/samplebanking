package com.natwest.pbbdhb.broker.dashboard.exception;

import lombok.Getter;

@Getter
public class CaseNotFoundException extends RuntimeException {

    public CaseNotFoundException(String message) {
        super(message);
    }
}