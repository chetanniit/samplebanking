/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.broker.dashboard.model.applications.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.DATE_FORMAT;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.UK_TIME_ZONE;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
public class ApplicantInformation {
    private String title;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String firstName;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String lastName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT, timezone = UK_TIME_ZONE)
    private Date dob;

    private String isMainApplicant;
}
