package com.natwest.pbbdhb.broker.dashboard.dto.broker.enums;

public enum UserType {
    BROKER, ADMIN
}
