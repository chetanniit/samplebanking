package com.natwest.pbbdhb.broker.dashboard.controller;

import com.natwest.pbbdhb.broker.dashboard.exception.UIErrorResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.PaymentUrlResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;


import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

public interface CaseTrackingControllerSwagger {

    @Operation(summary = "Get applications for a broker")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "", content = @Content(schema =
    @Schema(implementation = CaseTrackingResponse.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/broker/{brokerUserName}/applications", produces = APPLICATION_JSON_VALUE)
    CaseTrackingResponse applications(@PathVariable String brokerUserName,
                                      @Parameter(description = "Brand", example = "nwb")
                                      @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
                                              message = "Invalid Brand") String brand,
                                      @RequestParam(name = "mortgageRefNumber", required = false) String mortgageRefNumber
            , @RequestParam(name = "lastName", required = false) String lastName
            , @RequestParam(name = "postcode", required = false) String postcode
            , @RequestParam(name = "pageNumber", required = false) String pageNumber
            , @RequestParam(name = "resultsPerPage", required = false) String resultsPerPage
    );

    @Operation(summary = "Get selected application for a broker")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "", content = @Content(schema =
    @Schema(implementation = TrackingApplicationDetailResponse.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/broker/{brokerUserName}/case/{mortgageRefNumber}", produces = APPLICATION_JSON_VALUE)
    TrackingApplicationDetailResponse application(@PathVariable String brokerUserName,
                                                  @PathVariable String mortgageRefNumber,
                                                  @Parameter(description = "Brand"
                                                          , example =
                                                          "nwb") @RequestHeader("brand") @Valid @Pattern(regexp =
                                                          "(rbs|nwb)",
                                                          message = "Invalid Brand") String brand);

    @Operation(summary = "Get fee payment page")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "", content = @Content(schema =
    @Schema(implementation = PaymentUrlResponse.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/payment/{mortgageRefNumber}", produces = APPLICATION_JSON_VALUE)
    PaymentUrlResponse getFeePaymentPage(@PathVariable String mortgageRefNumber,
                                         @Parameter(description = "Brand", example = "nwb")
                                         @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)", message =
                                                 "Invalid Brand") String brand);

    @Operation(summary = "Get document upload page")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "", content = @Content(schema =
    @Schema(implementation = DocumentsUploadURLResponse.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Not authenticated", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "Service not available", content = @Content(mediaType =
                APPLICATION_JSON_VALUE, schema = @Schema(implementation = UIErrorResponse.class)))})
    @GetMapping(path = "/documents/{mortgageRefNumber}", produces = APPLICATION_JSON_VALUE)
    DocumentsUploadURLResponse getDocumentUploadPage(@PathVariable String mortgageRefNumber,
                                                     @Parameter(description = "Brand", example = "nwb")
                                                     @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand);

}
