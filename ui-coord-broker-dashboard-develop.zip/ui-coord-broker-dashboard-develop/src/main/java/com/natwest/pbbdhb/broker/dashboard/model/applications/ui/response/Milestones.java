package com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Milestones {
    private ValuationMilestone valuation;
    private AssessmentMilestone assessment;
    private OfferMilestone offer;
    private CompletionMilestone completion;
    private CancelledDeclinedMilestone cancelledDecline;
}
