package com.natwest.pbbdhb.broker.dashboard.model.applications.ui;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@Builder
public class Case {
    private String mortgageReferenceNumber;
    private List<UiApplicantInformation> applicants;
    private Status status;
    private String brokerName;
    private String postcode;
}
