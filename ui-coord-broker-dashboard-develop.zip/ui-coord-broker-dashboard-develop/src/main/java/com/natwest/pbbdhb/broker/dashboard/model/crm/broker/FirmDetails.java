
package com.natwest.pbbdhb.broker.dashboard.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FirmDetails {

    @JsonProperty("mbs_firmid")
    private String firmID;
    @JsonProperty("mbs_firmname")
    private String firmName;
    @JsonProperty("mbs_fcanumber")
    private String fcaNumber;
    @JsonProperty("mbs_principlefcanumber")
    private String principleFCANumber;
    @JsonProperty("mbs_firmaddress_line1")
    private String firmAddressLine1;
    @JsonProperty("mbs_firmaddress_line2")
    private String firmAddressLine2;
    @JsonProperty("mbs_firmaddress_line3")
    private String firmAddressLine3;
    @JsonProperty("mbs_firmaddress_postcode")
    private String firmAddressPostcode;
    @JsonProperty("mbs_firmaddress_city")
    private String firmAddressCity;
    @JsonProperty("mbs_firmaddress_country")
    private String firmAddressCountry;
    @JsonProperty("mbs_firmaddress_county")
    private String firmAddressCounty;
    @JsonProperty("mbs_firmassociatenumber")
    private String firmAssociateNumber;
    @JsonProperty("mbs_statusdate")
    private String statusDate;
}
