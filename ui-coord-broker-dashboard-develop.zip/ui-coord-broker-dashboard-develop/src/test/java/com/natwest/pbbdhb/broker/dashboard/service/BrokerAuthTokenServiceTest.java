package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.exception.HttpCustomException;
import com.natwest.pbbdhb.broker.dashboard.exception.SessionTokenFetchFailureException;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.BrokerAuthTokenResponse;
import com.natwest.pbbdhb.broker.dashboard.service.impl.BrokerAuthTokenServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public class BrokerAuthTokenServiceTest {

    private static final String TOKEN_END_POINT="tokenurl";
    private static final String CASE_ID="caseId";
    private static final String stubUsername = "hello23";
    private static final String SESSION_TOKEN = "token";

    @InjectMocks
    BrokerAuthTokenServiceImpl brokerAuthTokenService;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(brokerAuthTokenService, "brokerAuthTokenEndpoint", TOKEN_END_POINT);
    }

    @Test
    void testGetSessionAuthToken(){
        Applicant applicant = Applicant.builder().applicantId("123").build();
        when(restTemplate.postForObject(eq(TOKEN_END_POINT), any(), eq(BrokerAuthTokenResponse.class)))
                .thenReturn(BrokerAuthTokenResponse.builder().accessToken(SESSION_TOKEN).build());
        String response = brokerAuthTokenService.getSessionAuthToken(CASE_ID, "MRN",
                stubUsername, applicant, "nwb");
        assertEquals(SESSION_TOKEN, response);
    }

    @Test
    void testGetSessionAuthTokenException(){
        Applicant applicant = Applicant.builder().applicantId("123").build();
        when(restTemplate.postForObject(eq(TOKEN_END_POINT), any(), eq(BrokerAuthTokenResponse.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        SessionTokenFetchFailureException thrown = Assertions.assertThrows(SessionTokenFetchFailureException.class, () -> {
            brokerAuthTokenService.getSessionAuthToken(CASE_ID, "MRN", stubUsername, applicant, "nwb");
        }, "Exception");

        Exception ex = ((HttpCustomException) thrown).getException();
        assertEquals("404 NOT_FOUND", ex.getMessage());
    }

}


