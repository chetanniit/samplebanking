package com.natwest.pbbdhb.broker.dashboard.model;

import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class ProductChangeRequestValidationTest extends AbstractValidationTest<ProductChangeRequest> {


    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid ProductChangeRequest", (Consumer<ProductChangeRequest>) a -> {/* no-op */}, EMPTY_SET),
                Arguments.of("productLtv below minimum", (Consumer<ProductChangeRequest>) a -> {
                    a.setProductLtv(-1L);
                }, singleton(TestValidationError.create("productLtv", "must be greater than or equal to 0"))),
                Arguments.of("productTermYears invalid", (Consumer<ProductChangeRequest>) a -> {
                    a.setProductTermYears("Invalid");
                }, singleton(TestValidationError.create("productTermYears", "must be any of: ONE_YEAR, TWO_YEAR, THREE_YEAR, FOUR_YEAR, FIVE_YEAR, SIX_YEAR, SEVEN_YEAR, EIGHT_YEAR, NINE_YEAR, TEN_YEAR, STANDARD_VARIABLE_RATE, OTHER"))),
                Arguments.of("productEndDate invalid", (Consumer<ProductChangeRequest>) a -> {
                    a.setProductEndDate("2222-00-12");
                }, singleton(TestValidationError.create("productEndDate", "must be a valid date in format 'yyyy-MM-dd'"))),
                Arguments.of("productType invalid", (Consumer<ProductChangeRequest>) a -> {
                    a.setProductType("invalid");
                }, singleton(TestValidationError.create("productType", "must be any of: FIXED, TRACKER, STANDARD_VARIABLE_RATE"))),
                Arguments.of("productInterestRate more then 2 decimal places", (Consumer<ProductChangeRequest>) a -> {
                    a.setProductInterestRate(new BigDecimal("99.9999"));
                }, singleton(TestValidationError.create("productInterestRate", "accepts up to two decimal places")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testProductChangeRequestValidations(String testDescription, Consumer<ProductChangeRequest> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, this::createProductChangeRequest, mutator, expectedErrorMessages);
    }

    private ProductChangeRequest createProductChangeRequest() {
        return ProductChangeRequest.builder()
                .productLtv(100L)
                .productCode("F012345")
                .productTermYears(ProductChangeRequest.ProductTermYears.EIGHT_YEAR.name())
                .productInterestRate(new BigDecimal(100))
                .productType(ProductChangeRequest.ProductType.FIXED.name()).productEndDate("2024-01-10")
                .productFee("Fee Product")
                .productEndDate("2024-10-10")
                .otherInfo("Other Info").build();
    }
}
