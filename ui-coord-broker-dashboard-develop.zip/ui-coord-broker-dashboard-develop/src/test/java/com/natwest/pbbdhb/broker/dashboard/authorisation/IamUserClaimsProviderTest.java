package com.natwest.pbbdhb.broker.dashboard.authorisation;

import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.security.GeneralSecurityException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IamUserClaimsProviderTest {

    private static final String USER_NAME = "TestUser";
    private static final BrokerType BROKER_TYPE = BrokerType.BROKER;
    private static final String BROKER_TYPE_VALUE = "BROKER";

    @InjectMocks
    private IamUserClaimsProvider iamUserClaimsProvider;

    @Mock
    private UserPrincipalProvider userPrincipalProvider;

    @Mock
    private UserPrincipal userPrincipal;

    @BeforeEach
    public void setUp() throws GeneralSecurityException {
        iamUserClaimsProvider = new IamUserClaimsProvider(userPrincipalProvider);
        when(userPrincipalProvider.get()).thenReturn(userPrincipal);
    }

    @Test
    public void shouldGetBrokerName() {
        when(userPrincipal.getProperty("userName")).thenReturn(USER_NAME);
        String userName = iamUserClaimsProvider.getBrokerUsername();
        assertEquals(USER_NAME, userName);
    }

    @Test
    public void shouldGetBrokerRole() {
        when(userPrincipal.getProperty("brokerRole")).thenReturn(BROKER_TYPE_VALUE);
        BrokerType brokerType = iamUserClaimsProvider.getBrokerType();
        assertEquals(BROKER_TYPE_VALUE, brokerType.name());
    }

    @Test
    public void throwsIllegalStateExceptionExceptionWhenNoUserPrincipalFound() throws GeneralSecurityException {
        when(userPrincipalProvider.get()).thenReturn(null);
        assertThrows(IllegalStateException.class, () -> iamUserClaimsProvider.getBrokerUsername());
    }

    @Test
    public void throwsIllegalStateExceptionExceptionWhenGeneralSecurityException() throws GeneralSecurityException {
        when(userPrincipalProvider.get()).thenThrow(new GeneralSecurityException());
        assertThrows(IllegalStateException.class, () -> iamUserClaimsProvider.getBrokerUsername());
    }

    @Test
    public void throwsIllegalStateExceptionExceptionWhenNoClaimFound() {
        assertThrows(IllegalStateException.class, () -> iamUserClaimsProvider.getBrokerUsername());
    }
}