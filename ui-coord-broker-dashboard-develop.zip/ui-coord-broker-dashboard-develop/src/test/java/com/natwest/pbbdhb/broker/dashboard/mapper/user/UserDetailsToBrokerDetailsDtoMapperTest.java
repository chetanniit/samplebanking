package com.natwest.pbbdhb.broker.dashboard.mapper.user;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class UserDetailsToBrokerDetailsDtoMapperTest {

    public static final String USERNAME = "TestUser";
    public static final String FULL_NAME = "Test User";
    public static final String FIRST_NAME = "Test";
    public static final String LAST_NAME = "User";
    public static final String EMAIL_ID = "test@test.com";
    public static final String FCA_NUMBER = "12345678";
    @InjectMocks
    private UserDetailsToBrokerDetailsDtoMapperImpl userDetailsToBrokerDetailsDtoMapper;

    @Test
    void should_map_user_details_to_broker_details() {
        UserDetails userDetails = UserDetails.builder().userName(USERNAME).fullName(FULL_NAME)
                .brokerFirstName(FIRST_NAME).brokerLastName(LAST_NAME).brokerType(BrokerType.BROKER)
                .brokerEmailId(EMAIL_ID).fcaNumber(FCA_NUMBER).principalFCANumber(FCA_NUMBER).build();

        BrokerDetailsDto brokerDetails = userDetailsToBrokerDetailsDtoMapper.toBrokerDetails(userDetails);

        assertEquals(brokerDetails.getFirstName(), FIRST_NAME);
        assertEquals(brokerDetails.getLastName(), LAST_NAME);
        assertEquals(brokerDetails.getUserType(), UserType.BROKER);
        assertEquals(brokerDetails.getEmailAddress(), EMAIL_ID);
        assertEquals(brokerDetails.getFullName(), FULL_NAME);
        assertEquals(brokerDetails.getFcaNumber(), FCA_NUMBER);
        assertEquals(brokerDetails.getPrincipalFCANumber(), FCA_NUMBER);
    }

    @Test
    void should_map_admin_user_details_to_broker_details() {
        UserDetails userDetails = UserDetails.builder().userName(USERNAME).fullName(FULL_NAME)
                .brokerFirstName(FIRST_NAME).brokerLastName(LAST_NAME).brokerType(BrokerType.ADMIN)
                .brokerEmailId(EMAIL_ID).fcaNumber(FCA_NUMBER).principalFCANumber(FCA_NUMBER).build();

        BrokerDetailsDto brokerDetails = userDetailsToBrokerDetailsDtoMapper.toBrokerDetails(userDetails);

        assertEquals(brokerDetails.getFirstName(), FIRST_NAME);
        assertEquals(brokerDetails.getLastName(), LAST_NAME);
        assertEquals(brokerDetails.getUserType(), UserType.ADMIN);
        assertEquals(brokerDetails.getEmailAddress(), EMAIL_ID);
        assertEquals(brokerDetails.getFullName(), FULL_NAME);
        assertEquals(brokerDetails.getFcaNumber(), FCA_NUMBER);
        assertEquals(brokerDetails.getPrincipalFCANumber(), FCA_NUMBER);
    }

    @Test
    void should_return_null() {
        UserDetails userDetails = null;
        assertNull(userDetailsToBrokerDetailsDtoMapper.toBrokerDetails(userDetails));
    }

    @Test
    void should_return_null_for_all_values() {
        UserDetails userDetails = UserDetails.builder().build();

        BrokerDetailsDto brokerDetails = userDetailsToBrokerDetailsDtoMapper.toBrokerDetails(userDetails);

        assertNull(brokerDetails.getFirstName());
        assertNull(brokerDetails.getLastName());
        assertNull(brokerDetails.getUserType());
        assertNull(brokerDetails.getEmailAddress());
        assertNull(brokerDetails.getUserName());
        assertNull(brokerDetails.getFullName());
        assertNull(brokerDetails.getFcaNumber());
        assertNull(brokerDetails.getPrincipalFCANumber());
    }
}