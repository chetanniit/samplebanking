package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDto;
import com.natwest.pbbdhb.broker.dashboard.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.kafka.dto.ProductChangeEventDto;
import com.natwest.pbbdhb.broker.dashboard.mapper.ProductChangeEventMapper;
import com.natwest.pbbdhb.broker.dashboard.model.SuccessResponse;
import com.natwest.pbbdhb.broker.dashboard.service.impl.ProductChangeServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProductChangeServiceTest {
    private static final String DEFAULT_CASE_ID = "AB12345";
    private static final String DEFAULT_BRAND = "nwb";
    @InjectMocks
    private ProductChangeServiceImpl productChangeService;
    @Mock
    private ProducerService producerService;
    @Mock
    private ProductChangeEventMapper productChangeEventMapper;
    @Mock
    private CaseService caseService;
    @Mock
    private UserClaimsProvider userClaimsProvider;
    @Mock
    private BrokerAccessService brokerAccessService;

    @Test
    public void changeProductSuccess() {
        ProductChangeRequest productChangeRequest = ProductChangeRequest.builder().build();
        ProductChangeEventDto productChangeEventDto = ProductChangeEventDto.builder().build();
        CaseApplicationDto caseApplication = CaseApplicationDto.builder().broker(BrokerDto.builder().brokerUsername("TestBroker").build()).mortgageReferenceNumber("AB123454").build();

        when(caseService.getCaseByCaseId(eq(DEFAULT_CASE_ID), eq(DEFAULT_BRAND))).thenReturn(caseApplication);
        when(brokerAccessService.checkRequestedBrokerHasAccess(eq("TestBroker"))).thenReturn(true);
        when(productChangeEventMapper.mapProductChangeEvent(any(ProductChangeRequest.class), anyString(), anyString(), anyString())).thenReturn(productChangeEventDto);

        SuccessResponse successResponse = productChangeService.changeProduct(productChangeRequest, DEFAULT_CASE_ID, DEFAULT_BRAND);
        Mockito.verify(producerService, times(1)).sendProductChangeEvent(eq(productChangeEventDto));
        assertEquals("Product Change Request Submitted Successfully", successResponse.getMessage());
    }


    @Test
    public void changeProduct_PermissionDeniedException() {
        ProductChangeRequest productChangeRequest = ProductChangeRequest.builder().build();
        ProductChangeEventDto productChangeEventDto = ProductChangeEventDto.builder().build();
        CaseApplicationDto caseApplication = CaseApplicationDto.builder().broker(BrokerDto.builder().brokerUsername("TestBroker").build()).mortgageReferenceNumber("AB123454").build();

        when(caseService.getCaseByCaseId(eq(DEFAULT_CASE_ID), eq(DEFAULT_BRAND))).thenReturn(caseApplication);
        when(brokerAccessService.checkRequestedBrokerHasAccess(eq("TestBroker"))).thenReturn(false);

        assertThrows(PermissionDeniedException.class, () -> productChangeService.changeProduct(productChangeRequest, DEFAULT_CASE_ID, DEFAULT_BRAND));
    }

    @Test
    public void changeProduct_MrnValidationException() {
        ProductChangeRequest productChangeRequest = ProductChangeRequest.builder().build();
        ProductChangeEventDto productChangeEventDto = ProductChangeEventDto.builder().build();
        CaseApplicationDto caseApplication = CaseApplicationDto.builder().broker(BrokerDto.builder().brokerUsername("TestBroker").build()).mortgageReferenceNumber(null).build();

        when(caseService.getCaseByCaseId(eq(DEFAULT_CASE_ID), eq(DEFAULT_BRAND))).thenReturn(caseApplication);
        when(brokerAccessService.checkRequestedBrokerHasAccess(eq("TestBroker"))).thenReturn(true);

        assertThrows(MRNValidateFailureException.class, () -> productChangeService.changeProduct(productChangeRequest, DEFAULT_CASE_ID, DEFAULT_BRAND));
    }

}
