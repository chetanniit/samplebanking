package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.common.AssociatedBrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.impl.BrokerAccessServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@Profile("test")
@ExtendWith(SpringExtension.class)
public class BrokerAccessServiceTest {

  private static final String TEST_BROKER_USERNAME = "AshHughes07";
  private static final String TEST_BROKER_USERNAME_ASSOCIATE = "AshHughes07_associate";


  @Mock
  private UserClaimsProvider userClaimsProvider;

  @Mock
  private CrmService crmService;

  @InjectMocks
  private BrokerAccessServiceImpl brokerAccessService;

  @Test
  void testCheckRequestedBrokerHasAccess_For_LoggedInUser_Equals_BrokerUsername_shouldReturn_true() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME);

    assertTrue(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_LoggedInUser_When_BrokerUsernameIsNull_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(null);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_AdminUser_CrmGetAdminAssociationsResponseContainsUserName_shouldReturn_true() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);

    AdminAssociationsResponse adminAssociationsResponse = new AdminAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setUserName(TEST_BROKER_USERNAME_ASSOCIATE);
    adminAssociationsResponse.setBrokers(Collections.singletonList(associatedBrokerDetails));
    when(crmService.getAdminAssociations(TEST_BROKER_USERNAME)).thenReturn(adminAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertTrue(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_AdminUser_CrmGetAdminAssociationsResponseIsNull_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);
        when(crmService.getAdminAssociations(TEST_BROKER_USERNAME)).thenReturn(null);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_AdminUser_CrmGetAdminAssociationsResponseGetBrokersIsNull_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);

    AdminAssociationsResponse adminAssociationsResponse = new AdminAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setUserName(TEST_BROKER_USERNAME_ASSOCIATE);
    adminAssociationsResponse.setBrokers(null);
    when(crmService.getAdminAssociations(TEST_BROKER_USERNAME)).thenReturn(adminAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_AdminUser_CrmGetAdminAssociationsResponseGetBrokersIsEmpty_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);

    AdminAssociationsResponse adminAssociationsResponse = new AdminAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setUserName(TEST_BROKER_USERNAME_ASSOCIATE);

    adminAssociationsResponse.setBrokers(new ArrayList<>());
    when(crmService.getAdminAssociations(TEST_BROKER_USERNAME)).thenReturn(adminAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_AdminUser_CrmGetAdminAssociationsResponseGetBrokersDoesNotContainUserName_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);

    AdminAssociationsResponse adminAssociationsResponse = new AdminAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setBrokerAdminName("OTHER_NAME");
    adminAssociationsResponse.setBrokers(Collections.singletonList(associatedBrokerDetails));

    when(crmService.getAdminAssociations(TEST_BROKER_USERNAME)).thenReturn(adminAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_BrokerUser_CrmGetBrokerAssociationsResponseContainsUserName_shouldReturn_true() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

    BrokerAssociationsResponse brokerAssociationsResponse = new BrokerAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setUserName(TEST_BROKER_USERNAME_ASSOCIATE);
    brokerAssociationsResponse.setBrokers(Collections.singletonList(associatedBrokerDetails));
    when(crmService.getBrokerAssociations(TEST_BROKER_USERNAME)).thenReturn(brokerAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertTrue(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_BrokerUser_CrmGetBrokerAssociationsResponseIsNull_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
    when(crmService.getBrokerAssociations(TEST_BROKER_USERNAME)).thenReturn(null);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_BrokerUser_CrmGetBrokerAssociationsResponseGetBrokersIsNull_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

    BrokerAssociationsResponse brokerAssociationsResponse = new BrokerAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setUserName(TEST_BROKER_USERNAME_ASSOCIATE);
    brokerAssociationsResponse.setBrokers(null);
    when(crmService.getBrokerAssociations(TEST_BROKER_USERNAME)).thenReturn(brokerAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_BrokerUser_CrmGetBrokerAssociationsResponseGetBrokersIsEmpty_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

    BrokerAssociationsResponse brokerAssociationsResponse = new BrokerAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setUserName(TEST_BROKER_USERNAME_ASSOCIATE);

    brokerAssociationsResponse.setBrokers(new ArrayList<>());
    when(crmService.getBrokerAssociations(TEST_BROKER_USERNAME)).thenReturn(brokerAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

  @Test
  void testCheckRequestedBrokerHasAccess_For_BrokerUser_CrmGetBrokerAssociationsResponseGetBrokersDoesNotContainUserName_shouldReturn_false() {

    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

    BrokerAssociationsResponse brokerAssociationsResponse = new BrokerAssociationsResponse();
    AssociatedBrokerDetails associatedBrokerDetails = new AssociatedBrokerDetails();
    associatedBrokerDetails.setBrokerAdminName("OTHER_NAME");
    brokerAssociationsResponse.setBrokers(Collections.singletonList(associatedBrokerDetails));

    when(crmService.getBrokerAssociations(TEST_BROKER_USERNAME)).thenReturn(brokerAssociationsResponse);

    Boolean hasAccess = brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE);

    assertFalse(hasAccess);
  }

}
