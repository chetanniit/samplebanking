package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.CaseHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.HistoryDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.RequiredActionDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.StageHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.AssessmentMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CancelledDeclinedMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ValuationMilestone;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.GREEN_RAG_STATUS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ApplicationDetailsResponseToMilestoneMapperTest {

    private final static String ASSESSMENT = "Assessment";
    private final static String VALUATION = "Valuation";
    private final static String DECLINED_CANCELLED = "Declined/Cancelled";
    private final static String AMBER_RAG_STATUS = "AMBER";
    private final static String ACTION_REQUIRED = "Action required";
    private final static String NO_ACTION_REQUIRED = "No action required";
    private final static String NO_ACTION_REQUIRED_A = "No Action required";
    private final static String IN_PROGRESS = "In Progress";
    private final static String COMPLETED = "Completed";
    public static final String STARTED_UPDATE = "Started";
    public static final String CANCELLED_DECLINED = "Cancelled/Declined";
    private final ZonedDateTime zonedDateTime = ZonedDateTime.of(2023, 03, 26,
            0, 0, 0, 0, ZoneId.of("GMT"));
    private final String closedDateTime = "2023-03-26 00:00:00";
    private final String openedTime = "2023-03-26 00:00:00";

    @Mock
    private ValuationDetailToValuationInformationMapper valuationDetailToValuationInformationMapper;
    @Mock
    private ApplicationDetailsToPropertyInformationMapper applicationDetailsToPropertyInformationMapper;

    @InjectMocks
    private ApplicationDetailsResponseToMilestoneMapperImpl applicationDetailsResponseToMilestoneMapper;

    @Mock
    private ApplicationDetailsResponse applicationDetailsResponse;

    @Mock
    private HistoryDetails historyDetails;

    @BeforeEach
    public void setUp() {
        when(applicationDetailsResponse.getApplicationDetails()).thenReturn(historyDetails);
    }

    @Test
    void should_build_valuation_milestone() {
        when(historyDetails.getStageHistory()).thenReturn(valuationStageHistory(StringUtils.EMPTY));
        when(applicationDetailsResponse.getValuationInformation()).thenReturn(buildValuationDetail());

        ValuationMilestone valuationMilestone =
                applicationDetailsResponseToMilestoneMapper.getValuation(applicationDetailsResponse);

        assertEquals(COMPLETED, valuationMilestone.getCurrentStatus());
        assertEquals(VALUATION, valuationMilestone.getDescription());
        assertTrue(valuationMilestone.getIsComplete());
        assertNotNull(valuationMilestone.getUpdates());
        assertEquals(1, valuationMilestone.getUpdates().size());
        assertEquals(STARTED_UPDATE, valuationMilestone.getUpdates().get(0).getDescription());
        assertEquals(closedDateTime, valuationMilestone.getUpdates().get(0).getDateTime());
        assertNotNull(valuationMilestone.getValuationHistory());
        assertNotNull(valuationMilestone.getValuationHistory());
        assertEquals(1, valuationMilestone.getValuationHistory().getUpdates().size());
        assertEquals(STARTED_UPDATE, valuationMilestone.getValuationHistory().getUpdates().get(0).getDescription());
        assertEquals(closedDateTime, valuationMilestone.getValuationHistory().getUpdates().get(0).getDateTime());
    }

    @Test
    void should_build_assessment_milestone() {

        when(historyDetails.getStageHistory()).thenReturn(assessmentStageHistory(ACTION_REQUIRED));
        AssessmentMilestone assessmentMilestone =
                applicationDetailsResponseToMilestoneMapper.getAssessment(applicationDetailsResponse);

        assertEquals(ACTION_REQUIRED, assessmentMilestone.getCurrentStatus());
        assertFalse(assessmentMilestone.getIsComplete());
        assertNotNull(assessmentMilestone.getActionRequired());
        assertEquals(1, assessmentMilestone.getActionRequired().size());
        assertEquals(STARTED_UPDATE, assessmentMilestone.getActionRequired().get(0).getDescription());
        assertEquals(openedTime, assessmentMilestone.getActionRequired().get(0).getDateTime());
    }

    @Test
    void should_send_back_in_progress_for_assessment_milestone() {
        List<StageHistoryDetail> stageHistory = assessmentStageHistory(NO_ACTION_REQUIRED);
        stageHistory.get(0).setRagStatus(GREEN_RAG_STATUS);
        when(historyDetails.getStageHistory()).thenReturn(stageHistory);

        AssessmentMilestone assessmentMilestone =
                applicationDetailsResponseToMilestoneMapper.getAssessment(applicationDetailsResponse);

        assertEquals(COMPLETED, assessmentMilestone.getCurrentStatus());
        assertTrue(assessmentMilestone.getIsComplete());
    }

    @Test
    void should_send_back_in_progress_for_no_action_required_assessment_milestone() {
        List<StageHistoryDetail> stageHistory = assessmentStageHistory(NO_ACTION_REQUIRED);
        when(historyDetails.getStageHistory()).thenReturn(stageHistory);
        AssessmentMilestone assessmentMilestone =
                applicationDetailsResponseToMilestoneMapper.getAssessment(applicationDetailsResponse);

        assertEquals(IN_PROGRESS, assessmentMilestone.getCurrentStatus());
        assertNull(assessmentMilestone.getIsComplete());
        assertTrue(assessmentMilestone.getIsDocumentUploadComplete());
    }

    @Test
    void should_send_back_is_document_upload_status_as_false_assessment_milestone() {
        List<StageHistoryDetail> stageHistory = assessmentStageHistory(ACTION_REQUIRED);
        when(historyDetails.getStageHistory()).thenReturn(stageHistory);
        AssessmentMilestone assessmentMilestone =
                applicationDetailsResponseToMilestoneMapper.getAssessment(applicationDetailsResponse);

        assertEquals(ACTION_REQUIRED, assessmentMilestone.getCurrentStatus());
        assertFalse(assessmentMilestone.getIsComplete());
        assertFalse(assessmentMilestone.getIsDocumentUploadComplete());
    }

    @Test
    void should_send_back_in_progress_for_no_action_required_A_assessment_milestone() {
        List<StageHistoryDetail> stageHistory = assessmentStageHistory(NO_ACTION_REQUIRED_A);
        when(historyDetails.getStageHistory()).thenReturn(stageHistory);
        AssessmentMilestone assessmentMilestone =
                applicationDetailsResponseToMilestoneMapper.getAssessment(applicationDetailsResponse);

        assertEquals(IN_PROGRESS, assessmentMilestone.getCurrentStatus());
        assertNull(assessmentMilestone.getIsComplete());
    }

    @Test
    void should_build_cancellation_declined_milestone() {
        when(historyDetails.getStageHistory()).thenReturn(cancelledDeclineStageHistory(CANCELLED_DECLINED));
        CancelledDeclinedMilestone cancelledDeclinedMilestone =
                applicationDetailsResponseToMilestoneMapper.getCancelledDecline(applicationDetailsResponse);

        assertEquals(CANCELLED_DECLINED, cancelledDeclinedMilestone.getCurrentStatus());
        assertEquals(DECLINED_CANCELLED, cancelledDeclinedMilestone.getDescription());
    }

    private List<StageHistoryDetail> valuationStageHistory(String action) {
        CaseHistoryDetail historyDetail = CaseHistoryDetail.builder().description(STARTED_UPDATE).timeClosed(zonedDateTime).build();
        List<CaseHistoryDetail> historyDetails = Lists.newArrayList(historyDetail);
        StageHistoryDetail valuationStage = buildStageHistoryDetail(GREEN_RAG_STATUS, VALUATION, action);
        valuationStage.setCaseHistory(historyDetails);
        return Lists.newArrayList(valuationStage);
    }

    private List<StageHistoryDetail> assessmentStageHistory(String action) {
        RequiredActionDetail requiredActionDetail = RequiredActionDetail.builder()
                .description(STARTED_UPDATE).timeOpen(zonedDateTime).build();
        List<RequiredActionDetail> requiredActionDetails = Lists.newArrayList(requiredActionDetail);
        StageHistoryDetail assessmentStage = buildStageHistoryDetail(AMBER_RAG_STATUS, ASSESSMENT, action);
        assessmentStage.setRequiredActions(requiredActionDetails);
        return Lists.newArrayList(assessmentStage);
    }

    private List<StageHistoryDetail> cancelledDeclineStageHistory(String action) {
        RequiredActionDetail requiredActionDetail = RequiredActionDetail.builder()
                .description(STARTED_UPDATE).timeOpen(zonedDateTime).build();
        List<RequiredActionDetail> requiredActionDetails = Lists.newArrayList(requiredActionDetail);
        StageHistoryDetail assessmentStage = buildStageHistoryDetail(AMBER_RAG_STATUS, DECLINED_CANCELLED, action);
        assessmentStage.setRequiredActions(requiredActionDetails);
        return Lists.newArrayList(assessmentStage);
    }

    private ValuationDetail buildValuationDetail() {
        ValuationHistoryDetail valuationHistoryDetail = ValuationHistoryDetail.builder()
                .statusDescription(STARTED_UPDATE).date(zonedDateTime).build();
        return ValuationDetail.builder()
                .details(Lists.newArrayList(valuationHistoryDetail)).build();
    }

    private StageHistoryDetail buildStageHistoryDetail(String ragStatus, String mileStoneType, String subStatus) {
        return StageHistoryDetail.builder().description(mileStoneType)
                .ragStatus(ragStatus).subStatus(subStatus).build();
    }
}