package com.natwest.pbbdhb.broker.dashboard.mapper;

import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.kafka.dto.ProductChangeEventDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.params.provider.Arguments.arguments;

@ExtendWith(MockitoExtension.class)
public class ProductChangeEventMapperTest {
    @InjectMocks
    ProductChangeEventMapperImpl productChangeEventMapper;

    @Test
    public void testMapProductChangeEvent() {
        ProductChangeEventDto productChangeEventDto = productChangeEventMapper.mapProductChangeEvent(createProductChangeRequest(), "AB12345", "801234", "nwb");
        assertAll(
                () -> assertEquals("AB12345", productChangeEventDto.getCaseId()),
                () -> assertEquals("nwb", productChangeEventDto.getBrand()),
                () -> assertEquals("801234", productChangeEventDto.getReferenceNumber()),
                () -> assertEquals("PRODUCT_CHANGE", productChangeEventDto.getType()),
                () -> assertEquals("F012345", productChangeEventDto.getProductCode()),
                () -> assertEquals("8 year", productChangeEventDto.getProductTermYears()),
                () -> assertEquals(200L, productChangeEventDto.getProductLtv()),
                () -> assertEquals(100, productChangeEventDto.getProductInterestRate().intValue()),
                () -> assertEquals("Fee Product", productChangeEventDto.getProductFee()),
                () -> assertEquals("Other Info", productChangeEventDto.getOtherInfo()),
                () -> assertEquals("Fixed", productChangeEventDto.getProductType())
        );

    }

    @ParameterizedTest
    @MethodSource("productTypeToValue")
    public void testMapProductChangeEvent_AllProductTypes(String productType, String productTypeValue) {
        ProductChangeRequest productChangeRequest = createProductChangeRequest();
        productChangeRequest.setProductType(productType);
        ProductChangeEventDto productChangeEventDto = productChangeEventMapper.mapProductChangeEvent(productChangeRequest, "AB12345", "801234", "nwb");
        assertEquals(productTypeValue, productChangeEventDto.getProductType());
    }

    @ParameterizedTest
    @MethodSource("productTermYearsToValue")
    public void testMapProductChangeEvent_AllProductTermYears(String productTermYears, String productTermYearsValue) {
        ProductChangeRequest productChangeRequest = createProductChangeRequest();
        productChangeRequest.setProductTermYears(productTermYears);
        ProductChangeEventDto productChangeEventDto = productChangeEventMapper.mapProductChangeEvent(productChangeRequest, "AB12345", "801234", "nwb");
        assertEquals(productTermYearsValue, productChangeEventDto.getProductTermYears());
    }


    private static Stream<Arguments> productTypeToValue() {
        return Stream.of(
                arguments("FIXED", "Fixed"),
                arguments("TRACKER", "Tracker"),
                arguments("STANDARD_VARIABLE_RATE", "Standard Variable Rate")
        );
    }

    private static Stream<Arguments> productTermYearsToValue() {
        return Stream.of(
                arguments("ONE_YEAR", "1 year"),
                arguments("TWO_YEAR", "2 year"),
                arguments("THREE_YEAR", "3 year"),
                arguments("FOUR_YEAR", "4 year"),
                arguments("FIVE_YEAR", "5 year"),
                arguments("SIX_YEAR", "6 year"),
                arguments("SEVEN_YEAR", "7 year"),
                arguments("EIGHT_YEAR", "8 year"),
                arguments("NINE_YEAR", "9 year"),
                arguments("TEN_YEAR", "10 year"),
                arguments("STANDARD_VARIABLE_RATE", "Standard Variable Rate"),
                arguments("OTHER", "Other")
        );
    }


    private ProductChangeRequest createProductChangeRequest() {
        return ProductChangeRequest.builder()
                .productLtv(200L)
                .productCode("F012345")
                .productTermYears(ProductChangeRequest.ProductTermYears.EIGHT_YEAR.name())
                .productInterestRate(new BigDecimal(100))
                .productType(ProductChangeRequest.ProductType.FIXED.name()).productEndDate("19/05/2026")
                .productFee("Fee Product")
                .otherInfo("Other Info").build();
    }
}
