package com.natwest.pbbdhb.broker.dashboard.service;

import static java.lang.String.format;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.UpdateBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangePasswordException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangeSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveFirmDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.mapper.SecurityQuestionToBrokerSecurityQuestionMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.SecurityQuestionToBrokerSecurityQuestionMapperImpl;
import com.natwest.pbbdhb.broker.dashboard.service.impl.AuthServiceImpl;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

@ExtendWith(SpringExtension.class)
public class AuthServiceTest {

  private static final String PASSWORD_CHANGE_URL = "https://test/v2/account-management/password-change";
  private static final String CHALLENGE_QUESTIONS_URL = "https://test/v2/account-management/challenge-questions";
  private static final String CHANGE_QUESTIONS_URL = "https://test/v2/account-management/change-questions";
  private static final String BROKER_DETAILS_URL = "https://test/v2/account-management/broker-details";
  private static final String FIRM_DETAILS_URL = "https://test/v2/account-management/firm-details";
  private static final String CASE_ID = "ID20221201071011831152";
  private static final String USERNAME = "user";
  private static final String CURRENT_PASSWORD = "currPass";
  private static final String NEW_PASSWORD = "newPass";
  private static final String FCA_NUMBER = "123456";

  @InjectMocks
  AuthServiceImpl authService;

  @Mock
  private RestTemplate iamJwtChainSecureRestTemplate;

  private SecurityQuestionToBrokerSecurityQuestionMapper securityQuestionToBrokerSecurityQuestionMapper;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(authService, "passwordChangeEndpoint", PASSWORD_CHANGE_URL);
    ReflectionTestUtils.setField(authService, "retrieveSecurityQuestionsEndpoint",
        CHALLENGE_QUESTIONS_URL);
    ReflectionTestUtils.setField(authService, "changeSecurityQuestionsEndpoint",
        CHANGE_QUESTIONS_URL);
    ReflectionTestUtils.setField(authService, "brokerDetailsEndpoint",
        BROKER_DETAILS_URL);
    ReflectionTestUtils.setField(authService, "firmDetailsEndpoint",
        FIRM_DETAILS_URL);
    securityQuestionToBrokerSecurityQuestionMapper = new SecurityQuestionToBrokerSecurityQuestionMapperImpl();
    ReflectionTestUtils.setField(authService, "securityQuestionToBrokerSecurityQuestionMapper",
        securityQuestionToBrokerSecurityQuestionMapper);
  }

  @Test
  void testUpdateBrokerUserPassword() {
    authService.updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/password-change"), any(), any());

  }

  @Test
  void testUpdateBrokerUserPasswordUserNotFound() {
    doThrow(new ChangePasswordException(400, ErrorCodes.USER_NOT_FOUND,
        format("User not found for user: '%s'", USERNAME)))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(PASSWORD_CHANGE_URL), any(), any());

    Assertions.assertThrows(ChangePasswordException.class, () ->
        authService.updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/password-change"), any(), any());

  }

  @Test
  void testUpdateBrokerUserPasswordInvalidDetails() {
    doThrow(new ChangePasswordException(400, ErrorCodes.INVALID_DETAILS,
        "Password not valid"))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(PASSWORD_CHANGE_URL), any(), any());

    Assertions.assertThrows(ChangePasswordException.class, () ->
        authService.updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/password-change"), any(), any());

  }

  @Test
  void testUpdateBrokerUserPasswordOtherBadRequest() {
    doThrow(new ChangePasswordException(400, ErrorCodes.OTP_EXPIRED,
        "Password not valid"))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(PASSWORD_CHANGE_URL), any(), any());

    Assertions.assertThrows(ChangePasswordException.class, () ->
        authService.updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/password-change"), any(), any());

  }

  @Test
  void testUpdateBrokerUserPasswordAccountLocked() {
    doThrow(new ChangePasswordException(401, ErrorCodes.ACCOUNT_LOCKED,
        format("Account locked for user: '%s'", USERNAME)))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(PASSWORD_CHANGE_URL), any(), any());

    Assertions.assertThrows(ChangePasswordException.class, () ->
        authService.updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/password-change"), any(), any());

  }


  @Test
  void testChallengeQuestionsSuccess() {
    authService.getSecurityQuestions(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/challenge-questions"), any(), any());

  }

  @Test
  void testChallengeQuestionsUserNotFound() {
    doThrow(new RetrieveSecurityQuestionsException(400,
        ErrorCodes.USER_NOT_FOUND,
        format("User not found for user: '%s'", USERNAME)))
        .when(iamJwtChainSecureRestTemplate)
        .postForObject(eq(CHALLENGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(RetrieveSecurityQuestionsException.class, () ->
        authService.getSecurityQuestions(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/challenge-questions"), any(), any());

  }

  @Test
  void testChallengeQuestionsMemorableQuestionsLocked() {
    doThrow(new RetrieveSecurityQuestionsException(400,
        ErrorCodes.MEMORABLE_QUESTIONS_LOCKED, "Memorable questions locked"))
        .when(iamJwtChainSecureRestTemplate)
        .postForObject(eq(CHALLENGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(RetrieveSecurityQuestionsException.class, () ->
        authService.getSecurityQuestions(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/challenge-questions"), any(), any());

  }

  @Test
  void testChallengeQuestionsOtherBadRequestException() {
    doThrow(new RetrieveSecurityQuestionsException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .postForObject(eq(CHALLENGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(RetrieveSecurityQuestionsException.class, () ->
        authService.getSecurityQuestions(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/challenge-questions"), any(), any());
  }

  @Test
  void testChallengeQuestionsOtherException() {
    doThrow(new RetrieveSecurityQuestionsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Memorable questions request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .postForObject(eq(CHALLENGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(RetrieveSecurityQuestionsException.class, () ->
        authService.getSecurityQuestions(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/challenge-questions"), any(), any());
  }

  @Test
  void testChangeQuestionsSuccess() {
    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(
            Collections.singletonList(SecurityQuestion.builder()
                .question("Q")
                .answer("A")
                .build()))
        .build();
    authService.changeSecurityQuestions(USERNAME, request);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/change-questions"), any(), any());

  }

  @Test
  void testChangeQuestionsThrowsBadRequest() {
    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(
            Collections.singletonList(SecurityQuestion.builder()
                .question("Q")
                .answer("A")
                .build()))
        .build();

    doThrow(new ChangeSecurityQuestionsException(400, ErrorCodes.MEMORABLE_QUESTION_EXIST,
        format("Security question already exists")))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(CHANGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(ChangeSecurityQuestionsException.class, () ->
        authService.changeSecurityQuestions(USERNAME, request));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/change-questions"), any(), any());
  }

  @Test
  void testChangeQuestionsThrowsException() {
    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(
            Collections.singletonList(SecurityQuestion.builder()
                .question("Q")
                .answer("A")
                .build()))
        .build();

    doThrow(new ChangeSecurityQuestionsException(500, ErrorCodes.INTERNAL_SERVER_ERROR,
        format("Change security questions request failed", USERNAME)))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(CHANGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(ChangeSecurityQuestionsException.class, () ->
        authService.changeSecurityQuestions(USERNAME, request));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/change-questions"), any(), any());
  }

  @Test
  void testChangeQuestionsThrowsUnexpectedException() {
    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(
            Collections.singletonList(SecurityQuestion.builder()
                .question("Q")
                .answer("A")
                .build()))
        .build();

    doThrow(new ChangeSecurityQuestionsException(500, ErrorCodes.INTERNAL_SERVER_ERROR,
        format("Change security questions request failed with unexpected error", USERNAME)))
        .when(iamJwtChainSecureRestTemplate).postForObject(eq(CHANGE_QUESTIONS_URL), any(), any());

    Assertions.assertThrows(ChangeSecurityQuestionsException.class, () ->
        authService.changeSecurityQuestions(USERNAME, request));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .postForObject(eq("https://test/v2/account-management/change-questions"), any(), any());
  }

  @Test
  void testRetrieveBrokerDetailsSuccess() {
    authService.getBrokerDetails(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/broker-details/" + USERNAME), any());

  }

  @Test
  void testRetrieveBrokerDetailsFailedUserNotFound() {
    doThrow(new RetrieveBrokerDetailsException(400,
        ErrorCodes.USER_NOT_FOUND,
        format("User not found for user: '%s'", USERNAME)))
        .when(iamJwtChainSecureRestTemplate)
        .getForObject(eq(BROKER_DETAILS_URL + "/" + USERNAME), any());

    Assertions.assertThrows(RetrieveBrokerDetailsException.class, () ->
        authService.getBrokerDetails(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/broker-details/" + USERNAME), any());

  }

  @Test
  void testRetrieveBrokerDetailsFailedOtherBadRequestException() {
    doThrow(new RetrieveBrokerDetailsException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .getForObject(eq(BROKER_DETAILS_URL + "/" + USERNAME), any());

    Assertions.assertThrows(RetrieveBrokerDetailsException.class, () ->
        authService.getBrokerDetails(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/broker-details/" + USERNAME), any());
  }

  @Test
  void testRetrieveBrokerDetailsOtherException() {
    doThrow(new RetrieveBrokerDetailsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Broker details request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .getForObject(eq(BROKER_DETAILS_URL + "/" + USERNAME), any());

    Assertions.assertThrows(RetrieveBrokerDetailsException.class, () ->
        authService.getBrokerDetails(USERNAME));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/broker-details/" + USERNAME), any());
  }

  @Test
  void testUpdateBrokerDetailsSuccess() {
    when(iamJwtChainSecureRestTemplate.exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class))).thenReturn(
        ResponseEntity.of(Optional.of(UpdateBrokerDetailsResponse.builder().build())));

    authService.updateBrokerDetails(USERNAME, BrokerDetails.builder().build());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));

  }

  @Test
  void testUpdateBrokerDetailsFailedUserNotFound() {
    doThrow(new UpdateBrokerDetailsException(400,
        ErrorCodes.USER_NOT_FOUND,
        format("User not found for user: '%s'", USERNAME)))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));

    Assertions.assertThrows(UpdateBrokerDetailsException.class, () ->
        authService.updateBrokerDetails(USERNAME, BrokerDetails.builder().build()));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));

  }

  @Test
  void testUpdateBrokerDetailsFailedOtherBadRequestException() {
    doThrow(new UpdateBrokerDetailsException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));

    Assertions.assertThrows(UpdateBrokerDetailsException.class, () ->
        authService.updateBrokerDetails(USERNAME, BrokerDetails.builder().build()));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));
  }

  @Test
  void testUpdateBrokerDetailsOtherException() {
    doThrow(new UpdateBrokerDetailsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Broker details request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));

    Assertions.assertThrows(UpdateBrokerDetailsException.class, () ->
        authService.updateBrokerDetails(USERNAME, BrokerDetails.builder().build()));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(BROKER_DETAILS_URL), eq(HttpMethod.PUT), any(), eq(UpdateBrokerDetailsResponse.class));
  }

  @Test
  void testRetrieveFirmDetailsSuccess() {
    authService.getFirmDetails(FCA_NUMBER);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/firm-details/" + FCA_NUMBER), any());

  }

  @Test
  void testRetrieveFirmDetailsFailedUserNotFound() {
    doThrow(new RetrieveFirmDetailsException(400,
        ErrorCodes.USER_NOT_FOUND,
        format("User not found for user: '%s'", USERNAME)))
        .when(iamJwtChainSecureRestTemplate)
        .getForObject(eq(FIRM_DETAILS_URL + "/" + FCA_NUMBER), any());

    Assertions.assertThrows(RetrieveFirmDetailsException.class, () ->
        authService.getFirmDetails(FCA_NUMBER));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/firm-details/" + FCA_NUMBER), any());

  }

  @Test
  void testRetrieveFirmDetailsFailedOtherBadRequestException() {
    doThrow(new RetrieveFirmDetailsException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .getForObject(eq(FIRM_DETAILS_URL + "/" + FCA_NUMBER), any());

    Assertions.assertThrows(RetrieveFirmDetailsException.class, () ->
        authService.getFirmDetails(FCA_NUMBER));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/firm-details/" + FCA_NUMBER), any());
  }

  @Test
  void testRetrieveFirmDetailsOtherException() {
    doThrow(new RetrieveFirmDetailsException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Firm details request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .getForObject(eq(FIRM_DETAILS_URL + "/" + FCA_NUMBER), any());

    Assertions.assertThrows(RetrieveFirmDetailsException.class, () ->
        authService.getFirmDetails(FCA_NUMBER));

    verify(iamJwtChainSecureRestTemplate, times(1))
        .getForObject(eq("https://test/v2/account-management/firm-details/" + FCA_NUMBER), any());
  }
}
