package com.natwest.pbbdhb.broker.dashboard.controller;

import static java.lang.String.format;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.controller.impl.AccountManagementController;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.FirmDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.PaymentPath;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ResidentialAddress;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangePasswordException;
import com.natwest.pbbdhb.broker.dashboard.exception.ChangeSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveBrokerDetailsException;
import com.natwest.pbbdhb.broker.dashboard.exception.RetrieveSecurityQuestionsException;
import com.natwest.pbbdhb.broker.dashboard.service.AuthService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.web.bind.annotation.ResponseBody;

@WebMvcTest(AccountManagementController.class)
public class AccountManagementControllerUnitTest {

  public static final String USERNAME = "username";
  public static final String CURRENT_PASSWORD = "oldPass";
  public static final String NEW_PASSWORD = "newPass";
  public static final String FCA_NUMBER = "123456";
  @MockBean
  private AuthService authService;
  @MockBean
  private UserService userService;

  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private ObjectMapper objectMapper;

  @Test
  public void shouldChangePassword() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .currentPassword(CURRENT_PASSWORD)
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request)
        .andExpect(status().isNoContent());

    verify(authService, times(1)).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD,
        NEW_PASSWORD);
  }

  @Test
  public void shouldChangePasswordFailed400UserNotFound() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    doThrow(
        new ChangePasswordException(400,
            ErrorCodes.USER_NOT_FOUND,
            format("User not found for user: '%s'", USERNAME)))
        .when(authService).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .currentPassword(CURRENT_PASSWORD)
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest());

    verify(authService, times(1)).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD,
        NEW_PASSWORD);
  }

  @Test
  public void shouldChangePasswordFailed400InvalidDetails() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    doThrow(
        new ChangePasswordException(401,
            ErrorCodes.INVALID_DETAILS,
            "Password not valid"))
        .when(authService).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .currentPassword(CURRENT_PASSWORD)
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest())
        .andExpect(content().json("{\"message\":\"The credentials entered are invalid.\",\"errorCode\":\"INVALID_DETAILS\"}"));

    verify(authService, times(1)).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD,
        NEW_PASSWORD);
  }

  @Test
  public void shouldChangePasswordFailed401AccountLocked() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    doThrow(
        new ChangePasswordException(401,
            ErrorCodes.ACCOUNT_LOCKED,
            format("Account locked for user: %s", USERNAME)))
        .when(authService).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .currentPassword(CURRENT_PASSWORD)
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request)
        .andExpect(status().isUnauthorized());

    verify(authService, times(1)).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD,
        NEW_PASSWORD);
  }

  @Test
  public void shouldChangePasswordFailed500InternalServerError() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    doThrow(
        new ChangePasswordException(500,
            ErrorCodes.INTERNAL_SERVER_ERROR,
            "Reset password request failed"))
        .when(authService).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD, NEW_PASSWORD);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .currentPassword(CURRENT_PASSWORD)
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request)
        .andExpect(status().isInternalServerError());

    verify(authService, times(1)).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD,
        NEW_PASSWORD);
  }

  @Test
  public void shouldGetSecurityQuestions() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);
    BrokerQuestionsResponse response = BrokerQuestionsResponse.builder()
        .securityQuestions(Collections.singletonList("TEST"))
        .build();
    when(authService.getSecurityQuestions(USERNAME)).thenReturn(response);

    RequestBuilder request = get("/account-management/security-questions");

    this.mockMvc.perform(request)
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON));

    verify(authService, times(1)).getSecurityQuestions(any());
  }

  @Test
  public void shouldGetSecurityQuestionsFailed400UserNotFound() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    when(authService.getSecurityQuestions(USERNAME)).thenThrow(
        new RetrieveSecurityQuestionsException(400,
            ErrorCodes.USER_NOT_FOUND,
            format("User not found for user: '%s'", USERNAME)));

    RequestBuilder request = get("/account-management/security-questions");

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest());

    verify(authService, times(1)).getSecurityQuestions(any());
  }

  @Test
  public void shouldGetSecurityQuestionsFailed400MemorableQuestionsLocked() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    when(authService.getSecurityQuestions(USERNAME)).thenThrow(
        new RetrieveSecurityQuestionsException(400,
            ErrorCodes.MEMORABLE_QUESTIONS_LOCKED,
            format("Memorable questions locked")));

    RequestBuilder request = get("/account-management/security-questions");

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest());

    verify(authService, times(1)).getSecurityQuestions(any());
  }

  @Test
  public void shouldGetSecurityQuestionsFailed500InternalServerError() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    when(authService.getSecurityQuestions(USERNAME)).thenThrow(
        new RetrieveSecurityQuestionsException(500,
            ErrorCodes.INTERNAL_SERVER_ERROR,
            format("Memorable questions request failed")));

    RequestBuilder request = get("/account-management/security-questions");

    this.mockMvc.perform(request)
        .andExpect(status().isInternalServerError());

    verify(authService, times(1)).getSecurityQuestions(any());
  }

  @Test
  public void shouldChangeSecurityQuestions() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(Collections.singletonList(SecurityQuestion.builder()
            .question("TEST")
            .answer("TEST")
            .build()))
        .build();
    doNothing().when(authService).changeSecurityQuestions(any(), any());

    this.mockMvc.perform(put("/account-management/security-questions")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(authService, times(1)).changeSecurityQuestions(any(), any());
  }

  @Test
  public void shouldChangeSecurityQuestionsFailed500() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    doThrow(new ChangeSecurityQuestionsException(500, ErrorCodes.INTERNAL_SERVER_ERROR,
        format("Change security questions request failed", USERNAME)))
        .when(authService).changeSecurityQuestions(any(), any());

    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(Collections.singletonList(SecurityQuestion.builder()
            .question("TEST")
            .answer("TEST")
            .build()))
        .build();

    this.mockMvc.perform(put("/account-management/security-questions")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isInternalServerError());

    verify(authService, times(1)).changeSecurityQuestions(any(), any());
  }

  @Test
  public void shouldGetBrokerDetails() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);
    BrokerDetailsResponse response = BrokerDetailsResponse.builder()
        .brokerDetails(BrokerDetails.builder().build())
        .build();
    when(authService.getBrokerDetails(USERNAME)).thenReturn(response);

    RequestBuilder request = get("/account-management/broker-details");

    this.mockMvc.perform(request)
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON));

    verify(authService, times(1)).getBrokerDetails(any());
  }

  @Test
  @ResponseBody
  public void shouldUpdateBrokerDetails() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);
    BrokerDetailsResponse response = BrokerDetailsResponse.builder()
        .brokerDetails(BrokerDetails.builder().build())
        .build();
    when(authService.getBrokerDetails(USERNAME)).thenReturn(response);

    ResidentialAddress residentialAddress = ResidentialAddress.builder()
        .postcode("EH11 1PR")
        .county("county")
        .city("city")
        .countryOfAddress("GB")
        .addressLine1("test 1")
        .addressLine2("test 2")
        .addressLine3("test 3")
        .build();

    List<PaymentPath> paymentPaths = new ArrayList<>();
    paymentPaths.add(PaymentPath.builder().paymentId("123").name("name").build());

    BrokerDetails brokerDetails = BrokerDetails.builder()
        .title("Mr")
        .tradingName("Trading Name")
        .postcode("POST CODE")
        .mobilePhone("07090909099")
        .lastName("Test")
        .firstName("John")
        .email("email@email.com")
        .county("county")
        .city("City")
        .businessPhone("12345678")
        .addressLine1("Line 1")
        .addressLine2("Line 2")
        .addressLine3("Line 3")
        .paymentPaths(paymentPaths)
        .nationality("GB")
        .residentialAddress(residentialAddress)
        .build();

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .title("Mr")
        .tradingName("Trading Name")
        .postcode("POST CODE")
        .mobilePhone("07090909099")
        .lastName("Test")
        .firstName("John")
        .email("email@email.com")
        .county("county")
        .city("City")
        .businessPhone("12345678")
        .addressLine1("Line 1")
        .addressLine2("Line 2")
        .addressLine3("Line 3")
        .paymentPaths(paymentPaths)
        .nationality("GB")
        .residentialAddress(residentialAddress)
        .build();

    this.mockMvc.perform(put("/account-management/broker-details")
        .contentType(MediaType.APPLICATION_JSON)
        .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk());

    verify(authService, times(1)).updateBrokerDetails(USERNAME, brokerDetails);
  }

  @Test
  public void shouldGetBrokerDetailsFailed400UserNotFound() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    when(authService.getBrokerDetails(USERNAME)).thenThrow(
        new RetrieveBrokerDetailsException(400,
            ErrorCodes.USER_NOT_FOUND,
            format("User not found for user: '%s'", USERNAME)));

    RequestBuilder request = get("/account-management/broker-details");

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest());

    verify(authService, times(1)).getBrokerDetails(any());
  }

  @Test
  public void shouldGetBrokerDetailsFailed500InternalServerError() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    when(authService.getBrokerDetails(USERNAME)).thenThrow(
        new RetrieveBrokerDetailsException(500,
            ErrorCodes.INTERNAL_SERVER_ERROR,
            format("Memorable questions request failed")));

    RequestBuilder request = get("/account-management/broker-details");

    this.mockMvc.perform(request)
        .andExpect(status().isInternalServerError());

    verify(authService, times(1)).getBrokerDetails(any());
  }

  @Test
  public void shouldGetFirmDetails() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);
    FirmDetailsResponse response = FirmDetailsResponse.builder()
        .build();
    when(authService.getFirmDetails(FCA_NUMBER)).thenReturn(response);

    RequestBuilder request = get(String.format("/account-management/firm-details?fcanumber=%s", FCA_NUMBER));

    this.mockMvc.perform(request)
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON));

    verify(authService, times(1)).getFirmDetails(any());
  }

  @Test
  public void shouldGetFirmDetailsFailed500InternalServerError() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    when(authService.getFirmDetails(FCA_NUMBER)).thenThrow(
        new RetrieveBrokerDetailsException(500,
            ErrorCodes.INTERNAL_SERVER_ERROR,
            format("Firm details request failed")));

    RequestBuilder request = get(String.format("/account-management/firm-details?fcanumber=%s", FCA_NUMBER));

    this.mockMvc.perform(request)
        .andExpect(status().isInternalServerError());

    verify(authService, times(1)).getFirmDetails(any());
  }
}
