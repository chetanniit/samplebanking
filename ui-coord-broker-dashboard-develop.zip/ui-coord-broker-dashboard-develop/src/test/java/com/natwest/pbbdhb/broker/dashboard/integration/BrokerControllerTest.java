package com.natwest.pbbdhb.broker.dashboard.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPermissionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.CaseActionDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.CaseDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SubmittedCaseDto;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.service.CaseTrackingService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus.ACCESS_GRANTED;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus.ASSOCIATED;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus.DISASSOCIATED;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.PermissionType.GRANT_ACCESS;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.PermissionType.REMOVE_ACCESS;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType.ADMIN;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType.BROKER;
import static com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus.DOCUMENTS_UPLOADED;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.BRAND_HEADER_NAME;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_BROKER_USERNAME;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_DEFAULT_BRAND;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_MORTGAGE_REFERENCE_NUMBER;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.getDefaultCaseTrackingDocumentResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
@ComponentScan("com.natwest.pbbdhb.broker.dashboard.config.broker")
public class BrokerControllerTest extends WireMockIntegrationTest {

    public static final String BROKER_USERNAME = "AshHughes07";
    public static final String ASSOCIATE_BROKER = "hello23";
    public static final String ADMIN_USERNAME = "StokesB";
    private static final String FCA_NUMBER = "fcaNumber";
    private static final String FIRM_POSTCODE = "firmPostcode";
    private static final String BROKER_SURNAME = "brokerSurname";
    private static final String BROKER_FORE_NAME = "brokerForeName";
    private static final String BROKER_EMAIL = "brokerEmail";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    @Mock
    private CaseTrackingService caseTrackingService;

    @BeforeEach
    void setUp() throws IOException {
        super.setUp();
    }

    @AfterEach
    void tearDown() {
        super.tearDown();
    }

    @Test
    void shouldGetBrokerDetails() throws Exception {
        stubBrokerDetailsForValidBrokerEndpoint(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/details")).andExpect(status().isOk()).andReturn();
        BrokerDetailsDto brokerDetailsDto = objectMapper.readValue(result.getResponse().getContentAsString(),
                BrokerDetailsDto.class);

        assertNotNull(brokerDetailsDto);
        assertEquals(BROKER_USERNAME, brokerDetailsDto.getUserName());
        assertEquals("593672", brokerDetailsDto.getFcaNumber());
    }

    @Test
    void shouldGetErrorForInValidBrokerDetails() throws Exception {
        stubInvalidBrokerForValidBrokerEndpoint(BROKER_USERNAME);

        MvcResult result = mockMvc.perform(get("/broker/details")).andExpect(status().isOk()).andReturn();
        BrokerDetailsDto brokerDetailsDto = objectMapper.readValue(result.getResponse().getContentAsString(),
                BrokerDetailsDto.class);

        assertNull(brokerDetailsDto.getUserName());
    }

    @Test
    void shouldGetActiveBrokerAssociationsResponse() throws Exception {
        stubGetBrokerAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?accessStatus=" + ASSOCIATED))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto = objectMapper.readValue(result.getResponse().getContentAsString(),
                AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> associatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType())).collect(Collectors.toList());

        List<BrokerDetailsDto> associatedAdmins = brokers.stream().filter(brokerDetailsDto ->
                ADMIN.equals(brokerDetailsDto.getUserType())).collect(Collectors.toList());

        assertTrue(brokers.size() == 5);
        assertTrue(associatedBrokers.size() == 2);
        assertTrue(associatedAdmins.size() == 3);

        associatedBrokers.forEach(brokerDetailsDto -> assertEquals(ASSOCIATED,
                (brokerDetailsDto.getAccessStatus())));
        associatedAdmins.forEach(brokerDetailsDto -> assertEquals(ASSOCIATED,
                (brokerDetailsDto.getAccessStatus())));

    }

    @Test
    void shouldGetDisassociatedBrokersResponse() throws Exception {
        stubGetBrokerDisAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?accessStatus=" + DISASSOCIATED))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(),
                        AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> associatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType())).collect(Collectors.toList());

        List<BrokerDetailsDto> associatedAdmins = brokers.stream().filter(brokerDetailsDto ->
                ADMIN.equals(brokerDetailsDto.getUserType())).collect(Collectors.toList());

        assertTrue(brokers.size() == 5);
        assertTrue(associatedBrokers.size() == 2);
        assertTrue(associatedAdmins.size() == 3);

        associatedBrokers.forEach(brokerDetailsDto -> assertEquals(DISASSOCIATED,
                (brokerDetailsDto.getAccessStatus())));
        associatedAdmins.forEach(brokerDetailsDto -> assertEquals(DISASSOCIATED,
                (brokerDetailsDto.getAccessStatus())));

    }

    @Test
    void shouldGetAccessGrantedBrokers() throws Exception {
        stubGetBrokerAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?accessStatus=" + ACCESS_GRANTED))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> associatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType())).collect(Collectors.toList());

        assertTrue(brokers.size() == 1);
        assertTrue(associatedBrokers.size() == 1);
        associatedBrokers.forEach(brokerDetailsDto -> assertEquals(ACCESS_GRANTED,
                (brokerDetailsDto.getAccessStatus())));

    }

    @Test
    void shouldGetAllAssociatedBrokers() throws Exception {
        stubGetBrokerAssociations(BROKER_USERNAME);
        stubGetBrokerDisAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> associatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && ASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> associatedAdmins = brokers.stream().filter(brokerDetailsDto ->
                ADMIN.equals(brokerDetailsDto.getUserType()) && ASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> disAssociatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && DISASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> disAssociatedAdmins = brokers.stream().filter(brokerDetailsDto ->
                ADMIN.equals(brokerDetailsDto.getUserType()) && DISASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> accessGrantedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && ACCESS_GRANTED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());

        assertTrue(brokers.size() == 11);
        assertTrue(associatedBrokers.size() == 2);
        assertTrue(associatedAdmins.size() == 3);
        assertTrue(accessGrantedBrokers.size() == 1);
        assertTrue(disAssociatedBrokers.size() == 2);
        assertTrue(disAssociatedAdmins.size() == 3);


    }

    @Test
    void shouldGetAssociatedBrokersByFirstAndLastName() throws Exception {
        stubGetBrokerAssociations(BROKER_USERNAME);
        stubGetBrokerDisAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?firstName=Aaliyah&lastName=Hanif"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> disAssociatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && DISASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> accessGrantedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && ACCESS_GRANTED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());

        assertEquals(2, brokers.size());
        assertEquals("Aaliyah", disAssociatedBrokers.get(0).getFirstName());
        assertEquals("Hanif", disAssociatedBrokers.get(0).getLastName());
        assertEquals(DISASSOCIATED, disAssociatedBrokers.get(0).getAccessStatus());
        assertEquals("Aaliyah", accessGrantedBrokers.get(0).getFirstName());
        assertEquals("Hanif", accessGrantedBrokers.get(0).getLastName());
        assertEquals(ACCESS_GRANTED, accessGrantedBrokers.get(0).getAccessStatus());

    }

    @Test
    void shouldGetAssociatedBrokersByFirstName() throws Exception {
        stubGetBrokerAssociations(BROKER_USERNAME);
        stubGetBrokerDisAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?firstName=Aaliyah"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> disAssociatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && DISASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> accessGrantedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && ACCESS_GRANTED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());

        assertEquals(2, brokers.size());
        assertEquals("Aaliyah", disAssociatedBrokers.get(0).getFirstName());
        assertEquals("Hanif", disAssociatedBrokers.get(0).getLastName());
        assertEquals(DISASSOCIATED, disAssociatedBrokers.get(0).getAccessStatus());
        assertEquals("Aaliyah", accessGrantedBrokers.get(0).getFirstName());
        assertEquals("Hanif", accessGrantedBrokers.get(0).getLastName());
        assertEquals(ACCESS_GRANTED, accessGrantedBrokers.get(0).getAccessStatus());

    }

    @Test
    void shouldGetAssociatedBrokersByLastName() throws Exception {
        stubGetBrokerAssociations(BROKER_USERNAME);
        stubGetBrokerDisAssociations(BROKER_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?lastName=Hanif"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();
        List<BrokerDetailsDto> disAssociatedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && DISASSOCIATED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());
        List<BrokerDetailsDto> accessGrantedBrokers = brokers.stream().filter(brokerDetailsDto ->
                BROKER.equals(brokerDetailsDto.getUserType()) && ACCESS_GRANTED.equals(brokerDetailsDto.getAccessStatus()))
                .collect(Collectors.toList());

        assertEquals(2, brokers.size());
        assertEquals("Aaliyah", disAssociatedBrokers.get(0).getFirstName());
        assertEquals("Hanif", disAssociatedBrokers.get(0).getLastName());
        assertEquals(DISASSOCIATED, disAssociatedBrokers.get(0).getAccessStatus());
        assertEquals("Aaliyah", accessGrantedBrokers.get(0).getFirstName());
        assertEquals("Hanif", accessGrantedBrokers.get(0).getLastName());
        assertEquals(ACCESS_GRANTED, accessGrantedBrokers.get(0).getAccessStatus());

    }

    @Test
    void shouldGrantAccessToBrokerToBroker() throws Exception {
        Thread.sleep(2000);
        stubBrokerToBrokerPermissionRequest(BROKER_USERNAME, ASSOCIATE_BROKER);
        BrokerPermissionsRequest request =
                BrokerPermissionsRequest.builder().userNameToAssociate(ASSOCIATE_BROKER)
                        .userType(BROKER)
                        .permissionType(GRANT_ACCESS)
                        .build();

        MvcResult result =
                mockMvc.perform(put("/broker/permission").contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                        .andExpect(status().isOk()).andReturn();

        BrokerPermissionsResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                BrokerPermissionsResponse.class);

        assertEquals("Successfully Granted Permission to Broker", response.getMessage());
    }

    @Test
    void shouldRemoveAccessToBrokerToBroker() throws Exception {
        Thread.sleep(2000);
        stubRemoveBrokerToBrokerPermissionRequest(BROKER_USERNAME, ASSOCIATE_BROKER);

        BrokerPermissionsRequest request =
                BrokerPermissionsRequest.builder().userNameToAssociate(ASSOCIATE_BROKER)
                        .userType(BROKER)
                        .permissionType(REMOVE_ACCESS)
                        .build();

        MvcResult result =
                mockMvc.perform(put("/broker/permission").contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                        .andExpect(status().isOk()).andReturn();

        BrokerPermissionsResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                BrokerPermissionsResponse.class);

        assertEquals("Successfully Removed Permission to Broker", response.getMessage());
    }

    @Test
    void shouldGrantAccessToBrokerToAdmin() throws Exception {
        Thread.sleep(2000);
        stubBrokerToAdminPermissionRequest(BROKER_USERNAME, ADMIN_USERNAME);

        BrokerPermissionsRequest request =
                BrokerPermissionsRequest.builder().userNameToAssociate(ADMIN_USERNAME)
                        .userType(ADMIN)
                        .permissionType(GRANT_ACCESS)
                        .build();

        MvcResult result =
                mockMvc.perform(put("/broker/permission").contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                        .andExpect(status().isOk()).andReturn();
        BrokerPermissionsResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                BrokerPermissionsResponse.class);

        assertEquals("Successfully Granted Permission to Admin", response.getMessage());
    }

    @Test
    void shouldRemoveAccessToBrokerToAdmin() throws Exception {
        Thread.sleep(2000);
        stubRemoveBrokerToAdminPermissionRequest(BROKER_USERNAME, ADMIN_USERNAME);

        BrokerPermissionsRequest request =
                BrokerPermissionsRequest.builder().userNameToAssociate(ADMIN_USERNAME)
                        .userType(ADMIN)
                        .permissionType(REMOVE_ACCESS)
                        .build();

        MvcResult result =
                mockMvc.perform(put("/broker/permission").contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                        .andExpect(status().isOk()).andReturn();

        BrokerPermissionsResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                BrokerPermissionsResponse.class);

        assertEquals("Successfully Removed Permission to Admin", response.getMessage());
    }


  @Test
  public void shouldRetrieveSubmittedCase_ok() throws Exception {
    Thread.sleep(2000);
    stubGetCase(TEST_CASE_ID);
    stubBrokerDetailsForValidBrokerEndpoint(BROKER_USERNAME);
    stubGetApplicantsByCaseId(TEST_CASE_ID);
    stubGetApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER);
    when(userService.getDetails()).thenReturn(getUserDetails());
    stubGetApplicationDetailsForApplicationTracking(TEST_MORTGAGE_REFERENCE_NUMBER);
    stubGetBrokerCase();

    MvcResult mvcResult = this.mockMvc.perform(get("/broker/submitted-case/" + TEST_CASE_ID)
            .contentType(MediaType.APPLICATION_JSON)
            .header(BRAND_HEADER_NAME, TEST_DEFAULT_BRAND))
        .andExpect(status().isOk())
        .andReturn();
    SubmittedCaseDto submittedCaseDto = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        SubmittedCaseDto.class);
    CaseDto caseDto = submittedCaseDto.getCaseDto();
    assertEquals(TEST_CASE_ID, caseDto.getCaseId());
    assertEquals(TEST_MORTGAGE_REFERENCE_NUMBER, caseDto.getMortgageReferenceNumber());
    List<UiApplicant> applicants = caseDto.getApplicants();
    assertEquals(2, applicants.size());
    assertTrue(applicants.stream().anyMatch(a-> a.getIsMainApplicant() && "Test Applicant".equals(a.getName()) && "Mr".equals(a.getTitle())));
    assertTrue(applicants.stream().anyMatch(a-> !a.getIsMainApplicant() && "Another Applicant Test".equals(a.getName()) && "Lord".equals(a.getTitle())));
    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertTrue(caseActionDto.getIsCaseTrackingAvailable());
    assertEquals(DOCUMENTS_UPLOADED, caseActionDto.getDocumentUploadStatus());
    assertTrue(caseActionDto.getIsFeePaymentComplete());
    assertTrue(caseActionDto.getIsFmaComplete());
    assertEquals("test.pdf", caseActionDto.getMafDocument());
    assertNull(caseDto.getMortgageTempReferenceNumber());

  }

  private UserDetails getUserDetails() {
    return UserDetails.builder().fcaNumber(FCA_NUMBER).fullName(BROKER_FORE_NAME + BROKER_SURNAME)
        .brokerFirstName(BROKER_FORE_NAME).brokerLastName(BROKER_SURNAME).firmPostcode(FIRM_POSTCODE).brokerEmailId(BROKER_EMAIL).build();
  }
}
