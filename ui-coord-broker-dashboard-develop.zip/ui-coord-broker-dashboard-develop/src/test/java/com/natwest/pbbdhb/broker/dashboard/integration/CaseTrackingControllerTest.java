package com.natwest.pbbdhb.broker.dashboard.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Case;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Status;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ApplicationType;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.AssessmentMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CompletionMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.MortgageSummary;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.OfferMilestone;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ValuationMilestone;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.TimeZone;

import static com.natwest.pbbdhb.broker.dashboard.integration.BrokerControllerTest.BROKER_USERNAME;
import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
@ComponentScan("com.natwest.pbbdhb.broker.dashboard.config.broker")
public class CaseTrackingControllerTest extends WireMockIntegrationTest {

    private static final String SOLICITOR_INFORMATION_FIRM_NAME = "Blossom Law Solicitors LLP";
    private static final String MORTGAGE_REF_NUMBER = "84151927";
    private static final int ONE = 1;
    private static final int PAGE_SIZE_FIFTY = 50;
    private static final String FIRST_APPLICANT_FIRST_NAME = "Kplj";
    private static final String SECOND_APPLICANT_FIRST_NAME = "H";
    private static final String SUBMISSION_DATE = "2021-06-24T00:00:00";
    private static final String LAST_UPDATED_DATE = "2021-06-25T11:39";
    private static final String VALUATION = "Valuation";
    private static final String IN_PROGRESS = "In Progress";
    private static final String YOUR_APPLICATION_IS_AT_VALUATION = "Your application is at Valuation";
    private static final String BROKER_NAME = "Ashley  Hughes";
    private static final String POST_CODE = "RG23 7FT";
    private static final String ADDRESS_LINE_1 = "74, Nmzbmpxy Xqxdm";
    private static final String VALUATION_TYPE = "Standard Mortgage Valuation";
    private static final String COMPLETED = "Completed";
    private static final String ASSESSMENT_UPDATE = "We have received your payslips. We will assess this and will " +
            "contact you if we need any further information.";
    private static final String ASSESSMENT_DATE = "2021-06-25 10:51:00";
    private static final String ASSESSMENT = "Assessment";
    private static final String OFFER = "Offer";
    private static final String NOT_STARTED = "Not Started";
    private static final int TWO = 2;
    private static final String COMPLETION = "Completion";
    private static final String FIRST_APPLICANT_NAME = "H Hxxhxi";
    private static final String ADDRESS_LINE_ONE = "0, Nximwqmovm";
    private static final String SECOND_APPLICANT_NAME = "Kplj Gbrmmrsnu";
    private static final String PROPERTY_ADDRESS_LINE_ONE = "74, Nmzbmpxy Xqxdm";
    private static final BigDecimal PRODUCT_INFO_TOTAL_LOAN_AMOUNT = new BigDecimal("262200.00");
    private static final String FEE_STATUS = "Added to Loan";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private DateFormat dateFormat;

    @BeforeEach
    void setUp() throws IOException {
        dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/London"));
        super.setUp();
    }

    @AfterEach
    void tearDown() {
        super.tearDown();
    }

    @Test
    void shouldGetApplications() throws Exception {

        stubBrokerDetailsForValidBrokerEndpoint(BROKER_USERNAME);
        stubGetApplicationsForApplicationTracking();

        MvcResult result =
                mockMvc.perform(get("/broker/" + BROKER_USERNAME + "/applications").header("brand", "nwb"))
                        .andExpect(status().isOk()).andReturn();

        CaseTrackingResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                CaseTrackingResponse.class);
        assertEquals(ONE, response.getPage().getNumber());
        assertEquals(PAGE_SIZE_FIFTY, response.getPage().getSize());
        assertEquals(ONE, response.getPage().getTotalElements());
        assertEquals(ONE, response.getPage().getTotalPages());
        assertNotNull(response.getCases());
        assertEquals(1, response.getCases().size());
        Case theCase = response.getCases().get(0);
        assertEquals(MORTGAGE_REF_NUMBER, theCase.getMortgageReferenceNumber());
        assertEquals(2, theCase.getApplicants().size());
        assertEquals(FIRST_APPLICANT_FIRST_NAME, theCase.getApplicants().get(0).getFirstName());
        assertFalse(theCase.getApplicants().get(0).getIsMainApplicant());
        assertEquals(SECOND_APPLICANT_FIRST_NAME, theCase.getApplicants().get(1).getFirstName());
        assertTrue(theCase.getApplicants().get(1).getIsMainApplicant());
        Status status = theCase.getStatus();
        assertEquals(SUBMISSION_DATE, dateFormat.format(status.getSubmissionDate()));
        assertEquals(LAST_UPDATED_DATE, status.getLastUpdatedDate().toString());
        assertEquals(VALUATION, status.getStatus());
        assertEquals(YOUR_APPLICATION_IS_AT_VALUATION, status.getStatusDescription());
        assertEquals(BROKER_NAME, theCase.getBrokerName());
        assertEquals(POST_CODE, theCase.getPostcode());
    }

    @Test
    void shouldGetApplicationsByMortgageReferenceNumber() throws Exception {

        stubBrokerDetailsForValidBrokerEndpoint(BROKER_USERNAME);
        stubGetApplicationDetailsForApplicationTracking(MORTGAGE_REF_NUMBER);

        MvcResult result =
                mockMvc.perform(get("/broker/" + BROKER_USERNAME + "/applications").header("brand", "nwb")
                .param("mortgageRefNumber", MORTGAGE_REF_NUMBER))
                        .andExpect(status().isOk()).andReturn();

        CaseTrackingResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                CaseTrackingResponse.class);

        assertEquals(ONE, response.getPage().getNumber());
        assertEquals(ONE, response.getPage().getSize());
        assertEquals(ONE, response.getPage().getTotalElements());
        assertEquals(ONE, response.getPage().getTotalPages());
        assertNotNull(response.getCases());
        assertEquals(1, response.getCases().size());
        Case theCase = response.getCases().get(0);
        assertEquals(MORTGAGE_REF_NUMBER, theCase.getMortgageReferenceNumber());
        assertEquals(2, theCase.getApplicants().size());
        assertEquals("H", theCase.getApplicants().get(0).getFirstName());
        assertTrue(theCase.getApplicants().get(0).getIsMainApplicant());
        assertEquals("Kplj", theCase.getApplicants().get(1).getFirstName());
        assertFalse(theCase.getApplicants().get(1).getIsMainApplicant());
        Status status = theCase.getStatus();
        assertEquals(SUBMISSION_DATE, dateFormat.format(status.getSubmissionDate()));
        assertEquals(LAST_UPDATED_DATE, status.getLastUpdatedDate().toString());
        assertEquals(VALUATION, status.getStatus());
        assertEquals(YOUR_APPLICATION_IS_AT_VALUATION, status.getStatusDescription());
        assertEquals(BROKER_NAME, theCase.getBrokerName());
        assertEquals(POST_CODE, theCase.getPostcode());
    }

    @Test
    void shouldGetApplicationDetails() throws Exception {

        stubBrokerDetailsForValidBrokerEndpoint(BROKER_USERNAME);
        stubGetApplicationDetailsForApplicationTracking(MORTGAGE_REF_NUMBER);
        stubGetCaseWithMortgageReferenceNumber(MORTGAGE_REF_NUMBER);

        MvcResult result =
                mockMvc.perform(get("/broker/" + BROKER_USERNAME + "/case/" + MORTGAGE_REF_NUMBER).header("brand",
                        "nwb"))
                        .andExpect(status().isOk()).andReturn();

        TrackingApplicationDetailResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
                TrackingApplicationDetailResponse.class);

        assertMortgageSummary(response.getMortgageSummary());
        assertEquals(TWO, response.getApplicants().size());
        assertEquals(FIRST_APPLICANT_NAME, response.getApplicants().get(0).getName());
        assertEquals(ADDRESS_LINE_ONE, response.getApplicants().get(0).getCorrespondenceAddress().getAddressLine1());
        assertTrue(response.getApplicants().get(0).getIsMainApplicant());
        assertEquals(SECOND_APPLICANT_NAME, response.getApplicants().get(1).getName());
        assertEquals(PROPERTY_ADDRESS_LINE_ONE, response.getPropertyAddress().getAddressLine1());
        assertEquals(PRODUCT_INFO_TOTAL_LOAN_AMOUNT, response.getProductInfo().getTotalLoanAmount());
        assertEquals(FEE_STATUS, response.getProductInfo().getFeeStatus());
        assertFalse(response.getProductInfo().getIsFeePaymentComplete());
        assertEquals(BigDecimal.valueOf(995.00).setScale(2), response.getProductInfo().getFeeAmount());
        assertEquals(SOLICITOR_INFORMATION_FIRM_NAME, response.getSolicitorInformation().getFirmName());
    }

    @Test
    void shouldGetLegacyApplicationDetails() throws Exception {

        stubBrokerDetailsForValidBrokerEndpoint(BROKER_USERNAME);
        stubGetApplicationDetailsForApplicationTracking(MORTGAGE_REF_NUMBER);
        stubGetLegacyCaseWithMortgageReferenceNumber(MORTGAGE_REF_NUMBER);

        MvcResult result =
            mockMvc.perform(get("/broker/" + BROKER_USERNAME + "/case/" + MORTGAGE_REF_NUMBER).header("brand",
                    "nwb"))
                .andExpect(status().isOk()).andReturn();

        TrackingApplicationDetailResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
            TrackingApplicationDetailResponse.class);

        assertMortgageSummary(response.getMortgageSummary(), ApplicationType.LEGACY);
        assertEquals(TWO, response.getApplicants().size());
        assertEquals(FIRST_APPLICANT_NAME, response.getApplicants().get(0).getName());
        assertEquals(ADDRESS_LINE_ONE, response.getApplicants().get(0).getCorrespondenceAddress().getAddressLine1());
        assertTrue(response.getApplicants().get(0).getIsMainApplicant());
        assertEquals(SECOND_APPLICANT_NAME, response.getApplicants().get(1).getName());
        assertEquals(PROPERTY_ADDRESS_LINE_ONE, response.getPropertyAddress().getAddressLine1());
        assertEquals(PRODUCT_INFO_TOTAL_LOAN_AMOUNT, response.getProductInfo().getTotalLoanAmount());
        assertEquals(FEE_STATUS, response.getProductInfo().getFeeStatus());
        assertFalse(response.getProductInfo().getIsFeePaymentComplete());
        assertEquals(BigDecimal.valueOf(995.00).setScale(2), response.getProductInfo().getFeeAmount());
        assertEquals(SOLICITOR_INFORMATION_FIRM_NAME, response.getSolicitorInformation().getFirmName());
    }

    private void assertMortgageSummary(MortgageSummary mortgageSummary) {
        assertMortgageSummary(mortgageSummary,ApplicationType.NAPOLI);
    }

    private void assertMortgageSummary(MortgageSummary mortgageSummary, ApplicationType applicationType) {
        assertEquals(applicationType, mortgageSummary.getApplicationType());
        assertEquals(MORTGAGE_REF_NUMBER, mortgageSummary.getMortgageReferenceNumber());
        assertEquals(VALUATION, mortgageSummary.getApplicationStatus());
        assertNotNull(mortgageSummary.getMilestones());
        assertNotNull(mortgageSummary.getMilestones().getValuation());
        assertValuationMilestone(mortgageSummary.getMilestones().getValuation());
        assertAssessmentMilestone(mortgageSummary.getMilestones().getAssessment());
        assertOfferMilestone(mortgageSummary.getMilestones().getOffer());
        assertCompletionMilestone(mortgageSummary.getMilestones().getCompletion());
        assertNull(mortgageSummary.getMilestones().getCancelledDecline());
        assertFalse(mortgageSummary.getIsFmaComplete());
    }

    private void assertValuationMilestone(ValuationMilestone valuationMilestone) {
        assertNotNull(valuationMilestone.getValuationInformation());
        assertNotNull(valuationMilestone.getPropertyInformation());
        assertNotNull(valuationMilestone.getPropertyInformation().getAddressInfo());
        assertEquals(ADDRESS_LINE_1, valuationMilestone.getPropertyInformation().getAddressInfo().getAddressLine1());
        assertEquals(POST_CODE, valuationMilestone.getPropertyInformation().getAddressInfo().getPostcode());
        assertEquals(VALUATION_TYPE, valuationMilestone.getPropertyInformation().getValuationType());
        assertNotNull(valuationMilestone.getValuationHistory());
        assertEquals(VALUATION, valuationMilestone.getDescription());
        assertEquals(IN_PROGRESS, valuationMilestone.getCurrentStatus());
        assertNull(valuationMilestone.getIsComplete());
    }

    private void assertAssessmentMilestone(AssessmentMilestone assessmentMilestone) {
        assertTrue(assessmentMilestone.getIsDocumentUploadComplete());
        assertEquals(COMPLETED, assessmentMilestone.getCurrentStatus());
        assertEquals(ASSESSMENT, assessmentMilestone.getDescription());
        assertTrue(assessmentMilestone.getIsComplete());
        assertEquals(TWO, assessmentMilestone.getUpdates().size());
        assertEquals(ASSESSMENT_UPDATE, assessmentMilestone.getUpdates().get(0).getDescription());
        assertEquals(ASSESSMENT_DATE, assessmentMilestone.getUpdates().get(0).getDateTime());
    }

    private void assertOfferMilestone(OfferMilestone offerMilestone) {
        assertEquals(OFFER, offerMilestone.getDescription());
        assertEquals(NOT_STARTED, offerMilestone.getCurrentStatus());
    }

    private void assertCompletionMilestone(CompletionMilestone completionMilestone) {
        assertEquals(COMPLETION, completionMilestone.getDescription());
        assertEquals(NOT_STARTED, completionMilestone.getCurrentStatus());
    }
}
