package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.ValuationInformation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
public class ValuationDetailToValuationInformationMapperTest {

    private static final String EXPECTED_DATE = "2023-03-25 01:01:20";
    private static final BigDecimal FEE = new BigDecimal("500");

    @InjectMocks
    private ValuationDetailToValuationInformationMapperImpl valuationDetailToValuationInformationMapper;

    @Test
    public void should_map_valuation_detail_to_valuation_information() {
        ZonedDateTime zonedDateTime = ZonedDateTime.of(2023, 03, 25, 01, 01, 20, 10, ZoneId.of("UTC"));

        ValuationDetail valuationDetail = ValuationDetail.builder()
                .instructionDate(zonedDateTime)
                .latestBookingDate(zonedDateTime)
                .receivedDate(zonedDateTime)
                .assessmentDate(zonedDateTime)
                .fee(FEE).build();

        ValuationInformation valuationInformation = valuationDetailToValuationInformationMapper
                .toValuationInformation(valuationDetail);
        assertEquals(EXPECTED_DATE, valuationInformation.getValuationInstructionDate());
        assertEquals(EXPECTED_DATE, valuationInformation.getValuationDate());
        assertEquals(EXPECTED_DATE, valuationInformation.getValuationReceived());
        assertEquals(EXPECTED_DATE, valuationInformation.getValuationAccepted());
        assertEquals(FEE, valuationInformation.getValuationFeeAmount());
    }

    @Test
    public void should_return_null_when_valuation_detail_is_null() {

        ValuationDetail valuationDetail = null;

        ValuationInformation valuationInformation = valuationDetailToValuationInformationMapper
                .toValuationInformation(valuationDetail);

        assertNull(valuationInformation);
    }
}