package com.natwest.pbbdhb.broker.dashboard.util;

import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductDetailsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDto;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonAddress;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingDocumentResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.PackagingStatus;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.Fee;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.FeeAction;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.FeeCode;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.PaymentType;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FEE_TYPE_PRODUCT;


public class TestUtil {

  public static final String TEST_CASE_ID = "ID20221201071011831152";
  public static final String TEST_MORTGAGE_REFERENCE_NUMBER = "84212844";
  public static final String TEST_DEFAULT_BRAND = "nwb";
  public static final String TEST_BROKER_USERNAME = "broker123";

  public static Applicant buildDefaultApplicant() {
    return Applicant.builder()
        .applicantId("12345")
        .mainApplicant(true)
        .caseId(TEST_CASE_ID)
        .cin("1234")
        .addresses(buildDefaultAddresses())
        .personalDetails(buildDefaultPersonalDetails())
        .build();
  }

  public static UiApplicant buildDefaultUiApplicant(Applicant applicant) {
    PersonDetails personDetails = applicant.getPersonalDetails();
    return UiApplicant.builder()
    .isMainApplicant(applicant.getMainApplicant())
        .title(personDetails.getTitle())
        .name(personDetails.getFirstNames() + " " + personDetails.getLastName())
        .build();
  }

  public static List<PersonAddress> buildDefaultAddresses() {
    List<PersonAddress> personAddresses = new ArrayList<>();
    personAddresses.add(PersonAddress.builder()
        .isCurrentAddress(true)
        .postcode("EH11 1PT")
        .build());
    return personAddresses;
  }

  public static PersonDetails buildDefaultPersonalDetails() {
    return PersonDetails.builder()
        .firstNames("First Name")
        .lastName("Last Name")
        .title("Lord")
        .dateOfBirth(LocalDate.of(1980, 01, 01))
        .build();
  }

  public static CaseApplicationDto buildDefaultCaseApplication(Boolean isFeePaymentComplete) {
    return CaseApplicationDto.builder()
        .mafDocumentUrl("https://uat.mg7ec603.lb4.rbsgrp.net/FMA/MAF-QP1688981807271-10072023083648195CGNGDV.pdf")
        .mortgageReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
        .broker(BrokerDto.builder().brokerUsername(TEST_BROKER_USERNAME).build())
        .salesIllustrations(isFeePaymentComplete ? buildDefaultSalesIllustrationWithPaidFees() : buildDefaultSalesIllustration())
        .build();
  }

  public static List<SalesIllustrationDto> buildDefaultSalesIllustrationWithPaidFees() {
    List<SalesIllustrationDto> salesIllustrationDtos = new ArrayList<>();
    List<Fee> fees = new ArrayList<>();
    fees.add(Fee.builder()
        .feeAction(FeeAction.NO_ACTION)
        .feeAmount(BigDecimal.TEN)
        .feeCode(FeeCode.A01)
        .feePaymentType(PaymentType.CARD_PAYMENT)
        .isPaymentMade(true)
        .orderId("123")
        .paidDate("01/02/2023")
        .type(FEE_TYPE_PRODUCT)
        .build());
    fees.add(Fee.builder()
        .feeAction(FeeAction.NO_ACTION)
        .feeAmount(BigDecimal.TEN)
        .feeCode(FeeCode.A01)
        .feePaymentType(PaymentType.CARD_PAYMENT)
        .isPaymentMade(true)
        .orderId("123")
        .paidDate("01/02/2023")
        .type(FEE_TYPE_PRODUCT)
        .build());
    List<Fee> fees2 = new ArrayList<>();
    fees2.add(Fee.builder()
        .feeAction(FeeAction.ADD_CAPITALISE_TO_LOAN)
        .feeAmount(BigDecimal.TEN)
        .feeCode(FeeCode.A01)
        .feePaymentType(PaymentType.CARD_PAYMENT)
        .isPaymentMade(true)
        .orderId("123")
        .paidDate("01/02/2023")
        .type(FEE_TYPE_PRODUCT)
        .build());
    List<ProductDetailsDto> productDetailsDtos = new ArrayList<>();
    List<ProductDetailsDto> productDetailsDtos2 = new ArrayList<>();
    productDetailsDtos.add(ProductDetailsDto.builder()
        .fees(fees)
        .build());
    productDetailsDtos2.add(ProductDetailsDto.builder()
        .fees(fees2)
        .build());
    SalesIllustrationDto salesIllustrationDto = SalesIllustrationDto.builder()
        .isAccepted(true)
        .products(productDetailsDtos)
        .build();

    SalesIllustrationDto salesIllustrationDto2 = SalesIllustrationDto.builder()
        .isAccepted(false)
        .products(productDetailsDtos2)
        .build();

    salesIllustrationDtos.add(salesIllustrationDto);
    salesIllustrationDtos.add(salesIllustrationDto2);
    return salesIllustrationDtos;
  }

  public static List<SalesIllustrationDto> buildDefaultSalesIllustration() {
    List<SalesIllustrationDto> salesIllustrationDtos = new ArrayList<>();
    List<Fee> fees = new ArrayList<>();
    fees.add(Fee.builder()
        .feeAction(FeeAction.NO_ACTION)
        .feeAmount(BigDecimal.TEN)
        .feeCode(FeeCode.A01)
        .feePaymentType(PaymentType.CARD_PAYMENT)
        .isPaymentMade(true)
        .orderId("123")
        .paidDate("01/02/2023")
        .type(FEE_TYPE_PRODUCT)
        .build());
    fees.add(Fee.builder()
        .feeAction(FeeAction.NO_ACTION)
        .feeAmount(BigDecimal.TEN)
        .feeCode(FeeCode.A01)
        .feePaymentType(PaymentType.CARD_PAYMENT)
        .isPaymentMade(false)
        .orderId("123")
        .paidDate("01/02/2023")
        .type(FEE_TYPE_PRODUCT)
        .build());
    List<Fee> fees2 = new ArrayList<>();
    fees2.add(Fee.builder()
        .feeAction(FeeAction.ADD_CAPITALISE_TO_LOAN)
        .feeAmount(BigDecimal.TEN)
        .feeCode(FeeCode.A01)
        .feePaymentType(PaymentType.CARD_PAYMENT)
        .isPaymentMade(true)
        .orderId("123")
        .paidDate("01/02/2023")
        .type(FEE_TYPE_PRODUCT)
        .build());
    List<ProductDetailsDto> productDetailsDtos = new ArrayList<>();
    List<ProductDetailsDto> productDetailsDtos2 = new ArrayList<>();
    productDetailsDtos.add(ProductDetailsDto.builder()
        .fees(fees)
        .build());
    productDetailsDtos2.add(ProductDetailsDto.builder()
        .fees(fees2)
        .build());
    SalesIllustrationDto salesIllustrationDto = SalesIllustrationDto.builder()
        .isAccepted(true)
        .products(productDetailsDtos)
        .build();

    SalesIllustrationDto salesIllustrationDto2 = SalesIllustrationDto.builder()
        .isAccepted(false)
        .products(productDetailsDtos2)
        .build();

    salesIllustrationDtos.add(salesIllustrationDto);
    salesIllustrationDtos.add(salesIllustrationDto2);
    return salesIllustrationDtos;
  }

  public static TrackingApplicationDetailResponse getDefaultTrackingApplicationDetailResponse() {
    return TrackingApplicationDetailResponse.builder()
        .build();
  }

  public static CaseTrackingDocumentResponse getDefaultCaseTrackingDocumentResponse(
      Boolean isPackagingComplete, Boolean isSiRequested, Boolean isSiReceived, Boolean isPST, Boolean isPSTComplete) {
    return CaseTrackingDocumentResponse.builder()
        .packagingStatus(PackagingStatus.builder()
            .isBasicPackagingReceived(isPackagingComplete)
            .isSIRequested(isSiRequested)
            .isSIReceived(isSiReceived)
            .build())
        .isPST(isPST)
        .isPSTComplete(isPSTComplete)
        .build();
  }

  public static <T> Set<ConstraintViolation<T>> getConstraintViolations(T valueToCheck) {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    Validator validator = factory.getValidator();
    return validator.validate(valueToCheck);
  }


}
