package com.natwest.pbbdhb.broker.dashboard.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.ErrorCodes;
import com.natwest.pbbdhb.broker.dashboard.exception.CrmServiceException;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.service.impl.CrmServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

@ExtendWith(SpringExtension.class)
public class CrmServiceTest {

  private static final String BROKER_DETAILS_URL = "https://test/v2/crm/broker/details/%s";
  private static final String ADMIN_DETAILS_URL = "https://test/v2/crm/admin/details/%s";
  private static final String BROKER_ASSOCIATIONS_URL = "https://test/v2/crm/broker/associations/%s";
  private static final String BROKER_UNASSOCIATIONS_URL = "https://test/v2/crm/broker/unassociations/%s";
  private static final String ADMIN_ASSOCIATIONS_URL = "https://test/v2/crm/admin/associations/%s";
  private static final String ASSOCIATE_BROKER_TO_BROKER_URL = "https://test/v2/crm/broker/association/%s/broker/%s";
  private static final String UNASSOCIATE_BROKER_TO_BROKER_URL = "https://test/v2/crm/broker/unassociation/%s/broker/%s";
  private static final String ASSOCIATE_BROKER_TO_ADMIN_URL = "https://test/v2/crm/broker/association/%s/admin/%s";
  private static final String UNASSOCIATE_BROKER_TO_ADMIN_URL = "https://test/v2/crm/broker/unassociation/%s/admin/%s";
  private static final String USERNAME = "12345";
  private static final String OTHER_USERNAME = "54321";

  @InjectMocks
  CrmServiceImpl crmService;

  @Mock
  private RestTemplate iamJwtChainSecureRestTemplate;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(crmService, "brokerDetailsEndpoint", BROKER_DETAILS_URL);
    ReflectionTestUtils.setField(crmService, "adminDetailsEndpoint", ADMIN_DETAILS_URL);
    ReflectionTestUtils.setField(crmService, "brokerAssociationsEndpoint", BROKER_ASSOCIATIONS_URL);
    ReflectionTestUtils.setField(crmService, "brokerUnAssociationsEndpoint", BROKER_UNASSOCIATIONS_URL);
    ReflectionTestUtils.setField(crmService, "adminAssociationsEndpoint", ADMIN_ASSOCIATIONS_URL);
    ReflectionTestUtils.setField(crmService, "associateBrokerToBrokerEndpoint", ASSOCIATE_BROKER_TO_BROKER_URL);
    ReflectionTestUtils.setField(crmService, "unAssociateBrokerToBrokerEndpoint", UNASSOCIATE_BROKER_TO_BROKER_URL);
    ReflectionTestUtils.setField(crmService, "associateBrokerToAdminEndpoint", ASSOCIATE_BROKER_TO_ADMIN_URL);
    ReflectionTestUtils.setField(crmService, "unAssociateBrokerToAdminEndpoint", UNASSOCIATE_BROKER_TO_ADMIN_URL);
  }

  @Test
  void testGetBrokerDetailsSuccess() {
    crmService.getBrokerDetails(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerCoreResponse.class));
  }

  @Test
  void testGetBrokerDetailsFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(BROKER_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerCoreResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getBrokerDetails(USERNAME));
    assertEquals("getBrokerDetails: Broker details request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerCoreResponse.class));
  }

  @Test
  void testGetBrokerDetailsOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Broker details request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(BROKER_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerCoreResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getBrokerDetails(USERNAME));
    assertEquals("getBrokerDetails: Broker details request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerCoreResponse.class));
  }

  @Test
  void testGetAdminDetailsSuccess() {
    crmService.getAdminDetails(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ADMIN_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminCoreResponse.class));
  }

  @Test
  void testGetAdminDetailsFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ADMIN_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminCoreResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getAdminDetails(USERNAME));
    assertEquals("getAdminDetails: Admin details request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ADMIN_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminCoreResponse.class));
  }

  @Test
  void testGetAdminDetailsOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Admin details request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ADMIN_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminCoreResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getAdminDetails(USERNAME));
    assertEquals("getAdminDetails: Admin details request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ADMIN_DETAILS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminCoreResponse.class));
  }

  @Test
  void testGetBrokerAssociationsSuccess() {
    crmService.getBrokerAssociations(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));
  }

  @Test
  void testGetBrokerAssociationsFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(BROKER_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getBrokerAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Broker associations request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));
  }

  @Test
  void testGetBrokerAssociationsOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Broker associations request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(BROKER_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getBrokerAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Broker associations request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));
  }

  @Test
  void testGetBrokerUnAssociationsSuccess() {
    crmService.getBrokerUnAssociations(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_UNASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));
  }

  @Test
  void testGetBrokerUnAssociationsFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(BROKER_UNASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getBrokerUnAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Broker unassociations request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_UNASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));
  }

  @Test
  void testGetBrokerUnAssociationsOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Broker unassociations request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(BROKER_UNASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getBrokerUnAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Broker unassociations request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(BROKER_UNASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(BrokerAssociationsResponse.class));
  }

  @Test
  void testGetAdminAssociationsSuccess() {
    crmService.getAdminAssociations(USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ADMIN_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminAssociationsResponse.class));
  }

  @Test
  void testGetAdminAssociationsFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ADMIN_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminAssociationsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getAdminAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Admin associations request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ADMIN_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminAssociationsResponse.class));
  }

  @Test
  void testGetAdminAssociationsOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Admin associations request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ADMIN_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminAssociationsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.getAdminAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Admin associations request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ADMIN_ASSOCIATIONS_URL, USERNAME)), eq(HttpMethod.GET), any(), eq(AdminAssociationsResponse.class));
  }

  @Test
  void testAssociateBrokerToBrokerSuccess() {
    crmService.associateBrokerToBroker(USERNAME, OTHER_USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testAssociateBrokerToBrokerFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.associateBrokerToBroker(USERNAME, OTHER_USERNAME));
    assertEquals("associateBrokerToBroker: Associate broker to broker request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testAssociateBrokerToBrokerOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Associate broker to broker request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.associateBrokerToBroker(USERNAME, OTHER_USERNAME));
    assertEquals("associateBrokerToBroker: Associate broker to broker request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testUnAssociateBrokerToBrokerSuccess() {
    crmService.unAssociateBrokerToBroker(USERNAME, OTHER_USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testUnAssociateBrokerToBrokerFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.unAssociateBrokerToBroker(USERNAME, OTHER_USERNAME));
    assertEquals("unAssociateBrokerToBroker: Unassociate broker to broker request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testUnAssociateBrokerToBrokerOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unassociate broker to broker request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.unAssociateBrokerToBroker(USERNAME, OTHER_USERNAME));
    assertEquals("unAssociateBrokerToBroker: Unassociate broker to broker request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_BROKER_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testAssociateBrokerToAdminSuccess() {
    crmService.associateBrokerToAdmin(USERNAME, OTHER_USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testAssociateBrokerToAdminFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.associateBrokerToAdmin(USERNAME, OTHER_USERNAME));
    assertEquals("associateBrokerToAdmin: Associate broker to admin request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testAssociateBrokerToAdminOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Associate broker to admin request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.associateBrokerToAdmin(USERNAME, OTHER_USERNAME));
    assertEquals("associateBrokerToAdmin: Associate broker to admin request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(ASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testUnAssociateBrokerToAdminSuccess() {
    crmService.unAssociateBrokerToAdmin(USERNAME, OTHER_USERNAME);

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testUnAssociateBrokerToAdminFailedBadRequestException() {
    doThrow(new CrmServiceException(400,
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unexpected error occurred"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.unAssociateBrokerToAdmin(USERNAME, OTHER_USERNAME));
    assertEquals("unAssociateBrokerToAdmin: Unassociate broker to admin request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

  @Test
  void testUnAssociateBrokerToAdminOtherException() {
    doThrow(new CrmServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        ErrorCodes.INTERNAL_SERVER_ERROR, "Unassociate broker to admin request failed"))
        .when(iamJwtChainSecureRestTemplate)
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));

    CrmServiceException crmServiceException = Assertions.assertThrows(CrmServiceException.class,
        () -> crmService.unAssociateBrokerToAdmin(USERNAME, OTHER_USERNAME));
    assertEquals("unAssociateBrokerToAdmin: Unassociate broker to admin request failed", crmServiceException.getMessage());

    verify(iamJwtChainSecureRestTemplate, times(1))
        .exchange(eq(String.format(UNASSOCIATE_BROKER_TO_ADMIN_URL, USERNAME, OTHER_USERNAME)), eq(HttpMethod.POST), any(), eq(BrokerPermissionsResponse.class));
  }

}
