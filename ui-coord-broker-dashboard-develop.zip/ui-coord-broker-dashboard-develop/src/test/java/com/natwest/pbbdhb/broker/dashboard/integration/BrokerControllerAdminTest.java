package com.natwest.pbbdhb.broker.dashboard.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.AssociationsDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;
import java.util.List;

import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus.ACCESS_GRANTED;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.AccessStatus.ASSOCIATED;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.UserType.BROKER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@ActiveProfiles("admin")
@AutoConfigureMockMvc
@ComponentScan("com.natwest.pbbdhb.broker.dashboard.config.admin")
public class BrokerControllerAdminTest extends WireMockIntegrationTest {

    private static final String ADMIN_USERNAME = "StokesB";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() throws IOException {
        super.setUp();
    }

    @AfterEach
    void tearDown() {
        super.tearDown();
    }

    @Test
    void shouldGetAdminDetails() throws Exception {
        stubDetailsDetailsForValidAdminEndpoint("StokesB");

        MvcResult result = mockMvc.perform(get("/broker/details")).andExpect(status().isOk()).andReturn();
        BrokerDetailsDto brokerDetailsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(),
                        BrokerDetailsDto.class);

        assertNotNull(brokerDetailsDto);
        assertEquals("StokesB", brokerDetailsDto.getUserName());
        assertEquals("500230", brokerDetailsDto.getFcaNumber());
    }

    @Test
    void shouldGetErrorForInValidAdminUserName() throws Exception {
        stubInvalidAdminForAdminDetailsEndpoint("StokesB");

        MvcResult result = mockMvc.perform(get("/broker/details")).andExpect(status().isOk()).andReturn();
        BrokerDetailsDto brokerDetailsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(),
                        BrokerDetailsDto.class);

        assertNull(brokerDetailsDto.getUserName());
    }

    @Test
    void shouldGetAssociatedBrokersForAdmin() throws Exception {
        stubGetAdminAssociations(ADMIN_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations")).andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();

        assertEquals(1, brokers.size());
        assertEquals(BROKER, brokers.get(0).getUserType());
        assertEquals(ACCESS_GRANTED, brokers.get(0).getAccessStatus());
        assertEquals("WimbleC11", brokers.get(0).getUserName());

    }

    @Test
    void shouldGetAssociatedBrokersForAdminsByFirstAndLastName() throws Exception {
        stubGetAdminAssociations(ADMIN_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?firstName=Colin" +
                                "&lastName=WimbleZ"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();

        assertEquals(1, brokers.size());
        assertEquals("Colin", brokers.get(0).getFirstName());
        assertEquals("WimbleZ", brokers.get(0).getLastName());

    }

    @Test
    void shouldGetAssociatedBrokersForAdminsByFirstName() throws Exception {
        stubGetAdminAssociations(ADMIN_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?firstName=Colin"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();

        assertEquals(1, brokers.size());
        assertEquals("Colin", brokers.get(0).getFirstName());
        assertEquals("WimbleZ", brokers.get(0).getLastName());

    }

    @Test
    void shouldGetAssociatedBrokersForAdminsByLastName() throws Exception {
        stubGetAdminAssociations(ADMIN_USERNAME);

        MvcResult result =
                mockMvc.perform(get("/broker/associations?lastName=WimbleZ"))
                        .andExpect(status().isOk()).andReturn();
        AssociationsDto associationsDto =
                objectMapper.readValue(result.getResponse().getContentAsString(), AssociationsDto.class);

        List<BrokerDetailsDto> brokers = associationsDto.getBrokers();

        assertEquals(1, brokers.size());
        assertEquals("Colin", brokers.get(0).getFirstName());
        assertEquals("WimbleZ", brokers.get(0).getLastName());

    }
}
