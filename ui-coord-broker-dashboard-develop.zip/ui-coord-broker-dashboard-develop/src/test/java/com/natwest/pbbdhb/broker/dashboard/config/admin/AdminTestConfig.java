package com.natwest.pbbdhb.broker.dashboard.config.admin;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.config.OAuthTokenServiceTestImpl;
import com.natwest.pbbdhb.broker.dashboard.config.TestStubUserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.service.crm.OAuthTokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Configuration
@Profile("admin")
public class AdminTestConfig {

    @Autowired
    private RestTemplate restTemplate;

    @Bean
    @Qualifier(value = "oauthTokenService")
    @Primary
    public OAuthTokenService oauthTokenService() throws NoSuchAlgorithmException, KeyManagementException {
        return new OAuthTokenServiceTestImpl();
    }

    @Bean
    @Primary
    public RestTemplate proxyRestTemplate() throws NoSuchAlgorithmException, KeyManagementException {
        List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
        messageConverters.add(converter);
        this.restTemplate.setMessageConverters(messageConverters);
        return restTemplate;
    }

    @Bean
    @Primary
    public UserClaimsProvider userClaimsProvider() {
        return new TestStubUserClaimsProvider();
    }
}
