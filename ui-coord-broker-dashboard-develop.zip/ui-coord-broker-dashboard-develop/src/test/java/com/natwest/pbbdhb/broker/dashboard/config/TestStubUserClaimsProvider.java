package com.natwest.pbbdhb.broker.dashboard.config;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestStubUserClaimsProvider implements UserClaimsProvider {
    private static final String stubUsername = "StokesB";

    @Override
    public String getBrokerUsername() {
        log.info("Returning hardcoded username user claim: {}", stubUsername);
        return stubUsername;
    }

    @Override
    public BrokerType getBrokerType() {
        return BrokerType.ADMIN;
    }
}
