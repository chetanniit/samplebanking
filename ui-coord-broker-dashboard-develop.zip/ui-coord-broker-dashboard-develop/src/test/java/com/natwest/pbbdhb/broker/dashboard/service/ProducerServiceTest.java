package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.kafka.dto.ProductChangeEventDto;
import com.natwest.pbbdhb.broker.dashboard.service.impl.ProducerServiceImpl;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProducerServiceTest {
    private final ProductChangeEventDto testEvent = createEvent();
    @Mock
    private KafkaTemplate<String, Object> template;

    @InjectMocks
    private ProducerServiceImpl producerService;

    @Captor
    private ArgumentCaptor<Message> msgCaptor;


    @BeforeEach
    public void setup() {
        ReflectionTestUtils.setField(producerService, "topicName", "testAmendTopic");
    }

    @Test
    public void sendProductChangeEventSuccess() {
        RecordMetadata metadata = new RecordMetadata(new TopicPartition("topic", 0), 0, 0, 1234567890L, 1024, 1024);
        when(template.send(Mockito.any(Message.class))).thenReturn(CompletableFuture.completedFuture(new SendResult<>(new ProducerRecord<>("aBCD", ProductChangeEventDto.builder().build()), metadata)));

        producerService.sendProductChangeEvent(createEvent());
        Mockito.verify(template, times(1)).send(msgCaptor.capture());
        Message msg = msgCaptor.getValue();
        assertEquals("testAmendTopic", msg.getHeaders().get("kafka_topic"));
        assertEquals(testEvent, msg.getPayload());
    }



    private ProductChangeEventDto createEvent() {
        return ProductChangeEventDto.builder().referenceNumber("ABCDE1234").build();
    }

}
