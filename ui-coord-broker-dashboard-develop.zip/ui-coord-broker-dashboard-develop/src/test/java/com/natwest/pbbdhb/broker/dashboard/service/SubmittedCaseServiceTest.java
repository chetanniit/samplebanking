package com.natwest.pbbdhb.broker.dashboard.service;

import static com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus.ASSESSING_DOCUMENTS;
import static com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus.DOCUMENTS_OUTSTANDING;
import static com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus.DOCUMENTS_UPLOADED;
import static com.natwest.pbbdhb.broker.dashboard.model.enums.DocumentUploadStatus.FURTHER_INFORMATION_REQUIRED;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_BROKER_USERNAME;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_DEFAULT_BRAND;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_MORTGAGE_REFERENCE_NUMBER;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.buildDefaultApplicant;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.buildDefaultCaseApplication;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.buildDefaultUiApplicant;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.getDefaultCaseTrackingDocumentResponse;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.getDefaultTrackingApplicationDetailResponse;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.CaseActionDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.CaseDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SubmittedCaseDto;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicationsServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.AssociatedBrokerNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.mapper.MsvcApplicantToUiApplicantMapper;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.impl.SubmittedCaseServiceImpl;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;

@ExtendWith(SpringExtension.class)
public class SubmittedCaseServiceTest {

    @InjectMocks
    SubmittedCaseServiceImpl submittedCaseService;
    @Mock
    private MsvcApplicantToUiApplicantMapper msvcApplicantToUiApplicantMapper;
    @Mock
    private ApplicantService applicantService;
    @Mock
    private UserClaimsProvider userClaimsProvider;
    @Mock
    private CaseService caseService;
    @Mock
    private CaseTrackingService caseTrackingService;
    @Mock
    private BrokerAccessService brokerAccessService;


    @Test
    void testGetSubmittedCase_ok() {
      CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
          .isCaseTrackingAvailable(true)
          .documentUploadStatus(DOCUMENTS_UPLOADED)
          .isFeePaymentComplete(true)
          .hasFees(true)
          .isFmaComplete(true)
          .mafDocument("MAF-QP1688981807271-10072023083648195CGNGDV.pdf")
          .build();
      CaseDto caseDtoExpected = CaseDto.builder()
          .caseId(TEST_CASE_ID)
          .mortgageReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
          .build();

      List<Applicant> applicantListExpected = new ArrayList<>();
      applicantListExpected.add(buildDefaultApplicant());
      when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
      when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
      when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
          .thenReturn(getDefaultTrackingApplicationDetailResponse());
      when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
          .thenReturn(getDefaultCaseTrackingDocumentResponse(true, true, true, true, true));
      when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
          .thenReturn(applicantListExpected);
      CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);

      when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
          .thenReturn(caseApplicationDto);
      when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
          .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

      SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);
      CaseDto caseDto = submittedCaseDto.getCaseDto();

      List<UiApplicant> applicantList = caseDto.getApplicants();
      assertEquals(caseDtoExpected.getCaseId(), caseDto.getCaseId());
      assertEquals(applicantListExpected.size(), applicantList.size());
      assertApplicantsAreEquals(applicantListExpected, applicantList);
      CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
      assertEquals(caseActionDtoExpected.getIsCaseTrackingAvailable(), caseActionDto.getIsCaseTrackingAvailable());
      assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
      assertEquals(caseActionDtoExpected.getIsFeePaymentComplete(), caseActionDto.getIsFeePaymentComplete());
      assertEquals(caseActionDtoExpected.getIsFmaComplete(), caseActionDto.getIsFmaComplete());
      assertEquals(caseActionDtoExpected.getMafDocument(), caseActionDto.getMafDocument());
      assertEquals(caseActionDtoExpected.getHasFees(), caseActionDto.getHasFees());
      assertEquals(caseDtoExpected.getMortgageReferenceNumber(), caseDto.getMortgageReferenceNumber());
      assertEquals(TEST_BROKER_USERNAME, caseDto.getBrokerUsername());
      assertNull(caseDto.getMortgageTempReferenceNumber());
  }

  @Test
  void testGetSubmittedCaseForAssociate_ok() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .isCaseTrackingAvailable(true)
        .documentUploadStatus(DOCUMENTS_UPLOADED)
        .isFeePaymentComplete(true)
        .hasFees(true)
        .isFmaComplete(true)
        .mafDocument("MAF-QP1688981807271-10072023083648195CGNGDV.pdf")
        .build();
    CaseDto caseDtoExpected = CaseDto.builder()
        .caseId(TEST_CASE_ID)
        .mortgageReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
        .build();
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(true);
    caseApplicationDtoExpected.setBroker(BrokerDto.builder().brokerUsername("associate").build());

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess("associate")).thenReturn(true);
    when(caseTrackingService.getApplication("associate", TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultTrackingApplicationDetailResponse());
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(true, true, true, true, true));
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenReturn(applicantListExpected);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDtoExpected);
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);
    CaseDto caseDto = submittedCaseDto.getCaseDto();

    List<UiApplicant> applicantList = caseDto.getApplicants();
    assertEquals(caseDtoExpected.getCaseId(), caseDto.getCaseId());
    assertEquals(applicantListExpected.size(), applicantList.size());
    assertApplicantsAreEquals(applicantListExpected, applicantList);
    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getIsCaseTrackingAvailable(), caseActionDto.getIsCaseTrackingAvailable());
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
    assertEquals(caseActionDtoExpected.getIsFeePaymentComplete(), caseActionDto.getIsFeePaymentComplete());
    assertEquals(caseActionDtoExpected.getIsFmaComplete(), caseActionDto.getIsFmaComplete());
    assertEquals(caseActionDtoExpected.getMafDocument(), caseActionDto.getMafDocument());
    assertEquals(caseActionDtoExpected.getHasFees(), caseActionDto.getHasFees());
    assertEquals(caseDtoExpected.getMortgageReferenceNumber(), caseDto.getMortgageReferenceNumber());
    assertNull(caseDto.getMortgageTempReferenceNumber());
  }

    @Test
    void testGetSubmittedCase_False_ok() {
      CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
          .isCaseTrackingAvailable(false)
          .documentUploadStatus(DOCUMENTS_OUTSTANDING)
          .isFeePaymentComplete(false)
          .isFmaComplete(false)
          .hasFees(true)
          .build();
      CaseDto caseDtoExpected = CaseDto.builder()
          .caseId(TEST_CASE_ID)
          .mortgageReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
          .build();
      CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
      caseApplicationDtoExpected.setMafDocumentUrl(null);

      List<Applicant> applicantListExpected = new ArrayList<>();
      applicantListExpected.add(buildDefaultApplicant());
      when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
      when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
      when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
          .thenReturn(null);
      when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
          .thenReturn(getDefaultCaseTrackingDocumentResponse(false, false, false, false, false));
      when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
          .thenReturn(applicantListExpected);
      when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
          .thenReturn(caseApplicationDtoExpected);
      when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
          .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

      SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);
      CaseDto caseDto = submittedCaseDto.getCaseDto();
      List<UiApplicant> applicantList = caseDto.getApplicants();
      assertEquals(caseDtoExpected.getCaseId(), caseDto.getCaseId());
      assertEquals(applicantListExpected.size(), applicantList.size());
      assertApplicantsAreEquals(applicantListExpected, applicantList);
      CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
      assertEquals(caseActionDtoExpected.getIsCaseTrackingAvailable(), caseActionDto.getIsCaseTrackingAvailable());
      assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
      assertEquals(caseActionDtoExpected.getIsFeePaymentComplete(), caseActionDto.getIsFeePaymentComplete());
      assertEquals(caseActionDtoExpected.getIsFmaComplete(), caseActionDto.getIsFmaComplete());
      assertEquals(caseActionDtoExpected.getMafDocument(), caseActionDto.getMafDocument());
      assertEquals(caseActionDtoExpected.getHasFees(), caseActionDto.getHasFees());
      assertEquals(caseDtoExpected.getMortgageReferenceNumber(), caseDto.getMortgageReferenceNumber());
      assertNull(caseDto.getMortgageTempReferenceNumber());
  }

  @Test
  void testGetSubmittedCase_Nulls_ok() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .isCaseTrackingAvailable(null)
        .documentUploadStatus(null)
        .isFeePaymentComplete(null)
        .hasFees(false)
        .isFmaComplete(false)
        .build();
    CaseDto caseDtoExpected = CaseDto.builder()
        .caseId(TEST_CASE_ID)
        .mortgageReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
        .build();
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
    caseApplicationDtoExpected.setMafDocumentUrl(null);
    caseApplicationDtoExpected.setSalesIllustrations(null);

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenThrow(new ApplicationsServiceException(new RestClientException("Case Tracking Unavailable")));
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(null);
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenReturn(applicantListExpected);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDtoExpected);
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);
    CaseDto caseDto = submittedCaseDto.getCaseDto();
    List<UiApplicant> applicantList = caseDto.getApplicants();
    assertEquals(caseDtoExpected.getCaseId(), caseDto.getCaseId());
    assertEquals(applicantListExpected.size(), applicantList.size());
    assertApplicantsAreEquals(applicantListExpected, applicantList);
    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getIsCaseTrackingAvailable(), caseActionDto.getIsCaseTrackingAvailable());
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
    assertEquals(caseActionDtoExpected.getIsFeePaymentComplete(), caseActionDto.getIsFeePaymentComplete());
    assertEquals(caseActionDtoExpected.getIsFmaComplete(), caseActionDto.getIsFmaComplete());
    assertEquals(caseActionDtoExpected.getMafDocument(), caseActionDto.getMafDocument());
    assertEquals(caseActionDtoExpected.getHasFees(), caseActionDto.getHasFees());
    assertEquals(caseDtoExpected.getMortgageReferenceNumber(), caseDto.getMortgageReferenceNumber());
    assertNull(caseDto.getMortgageTempReferenceNumber());
  }

  @Test
  void testGetSubmittedCaseSIRequestedButNotReceivedReturns_FURTHER_INFORMATION_REQUIRED_Enum() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(FURTHER_INFORMATION_REQUIRED)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(true, true, false, false, false));

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCaseBasicPackagingNotReceivedReturns_DOCUMENTS_OUTSTANDING_Enum() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(DOCUMENTS_OUTSTANDING)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(false, false, false, false, false));

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCaseIsPstCaseButPstNotCompletedReturns_ASSESSING_DOCUMENTS_Enum() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(ASSESSING_DOCUMENTS)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(true, false, false, true, false));

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCaseSINotRequestedReturns_DOCUMENTS_UPLOADED_Enum() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(DOCUMENTS_UPLOADED)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(true, false, false, false, false));

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCaseSIRequestedANDSIReceivedReturns_DOCUMENTS_UPLOADED_Enum() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(DOCUMENTS_UPLOADED)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(true, true, true, false, false));

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCaseNullApplicationDocsReturnsNull() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(null)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(null);

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCaseGetApplicationDocsThrowsApplicationsServiceExceptionReturnsNull() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .documentUploadStatus(null)
        .build();

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenThrow(ApplicationsServiceException.class);

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(true);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDto);

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);

    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertNull(caseActionDto.getDocumentUploadStatus());
  }

  @Test
  void testGetSubmittedCase_noMortgageReferenceNumber_ok() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .isCaseTrackingAvailable(false)
        .documentUploadStatus(null)
        .isFeePaymentComplete(false)
        .isFmaComplete(false)
        .build();
    CaseDto caseDtoExpected = CaseDto.builder()
        .caseId(TEST_CASE_ID)
        .mortgageReferenceNumber(null)
        .mortgageTempReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
        .build();
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
    caseApplicationDtoExpected.setMafDocumentUrl(null);
    caseApplicationDtoExpected.setMortgageTempReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER);
    caseApplicationDtoExpected.setMortgageReferenceNumber(null);

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(null);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(false, false, false, false, false));
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenReturn(applicantListExpected);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDtoExpected);
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);
    CaseDto caseDto = submittedCaseDto.getCaseDto();

    List<UiApplicant> applicantList = caseDto.getApplicants();
    assertEquals(caseDtoExpected.getCaseId(), caseDto.getCaseId());
    assertEquals(applicantListExpected.size(), applicantList.size());
    assertApplicantsAreEquals(applicantListExpected, applicantList);
    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getIsCaseTrackingAvailable(), caseActionDto.getIsCaseTrackingAvailable());
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
    assertEquals(caseActionDtoExpected.getIsFeePaymentComplete(), caseActionDto.getIsFeePaymentComplete());
    assertEquals(caseActionDtoExpected.getIsFmaComplete(), caseActionDto.getIsFmaComplete());
    assertEquals(caseActionDtoExpected.getMafDocument(), caseActionDto.getMafDocument());
    assertEquals(caseDtoExpected.getMortgageTempReferenceNumber(), caseDto.getMortgageTempReferenceNumber());
    assertNull(caseDto.getMortgageReferenceNumber());
  }

  @Test
  void testGetSubmittedCase_caseTrackingThrowsException_null_ok() {
    CaseActionDto caseActionDtoExpected = CaseActionDto.builder()
        .isCaseTrackingAvailable(null)
        .documentUploadStatus(DOCUMENTS_OUTSTANDING)
        .isFeePaymentComplete(false)
        .isFmaComplete(false)
        .build();
    CaseDto caseDtoExpected = CaseDto.builder()
        .caseId(TEST_CASE_ID)
        .mortgageReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER)
        .build();
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
    caseApplicationDtoExpected.setMafDocumentUrl(null);

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenThrow(new ApplicationsServiceException(new Exception("Test Exception")));
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(false, false, false, false, false));
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenReturn(applicantListExpected);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDtoExpected);
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    SubmittedCaseDto submittedCaseDto = submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND);
    CaseDto caseDto = submittedCaseDto.getCaseDto();

    List<UiApplicant> applicantList = caseDto.getApplicants();
    assertEquals(caseDtoExpected.getCaseId(), caseDto.getCaseId());
    assertEquals(applicantListExpected.size(), applicantList.size());
    assertApplicantsAreEquals(applicantListExpected, applicantList);
    CaseActionDto caseActionDto = submittedCaseDto.getCaseAction();
    assertEquals(caseActionDtoExpected.getIsCaseTrackingAvailable(), caseActionDto.getIsCaseTrackingAvailable());
    assertEquals(caseActionDtoExpected.getDocumentUploadStatus(), caseActionDto.getDocumentUploadStatus());
    assertEquals(caseActionDtoExpected.getIsFeePaymentComplete(), caseActionDto.getIsFeePaymentComplete());
    assertEquals(caseActionDtoExpected.getIsFmaComplete(), caseActionDto.getIsFmaComplete());
    assertEquals(caseActionDtoExpected.getMafDocument(), caseActionDto.getMafDocument());
    assertEquals(caseDtoExpected.getMortgageReferenceNumber(), caseDto.getMortgageReferenceNumber());
    assertNull(caseDto.getMortgageTempReferenceNumber());
  }

  @Test
  void testGetSubmittedCase_getCaseThrowsIntegrationException_rethrows_IntegrationException() {
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
    caseApplicationDtoExpected.setMafDocumentUrl(null);

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(null);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(false, false, false, false, false));
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenReturn(applicantListExpected);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenThrow(new IntegrationException("Get case integration exception test"));
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    assertThatThrownBy(() -> submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .isInstanceOf(IntegrationException.class)
        .message().isEqualTo("Get case integration exception test");
  }

  @Test
  void testGetSubmittedCase_getApplicationDocumentsThrowsIntegrationException_rethrows_IntegrationException() {
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
    caseApplicationDtoExpected.setMafDocumentUrl(null);

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(null);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenThrow(new IntegrationException("Get application documents integration exception test"));
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenReturn(applicantListExpected);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDtoExpected);
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    assertThatThrownBy(() -> submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .isInstanceOf(IntegrationException.class)
        .message().isEqualTo("Get application documents integration exception test");

  }

  @Test
  void testGetSubmittedCase_getApplicantsThrowsIntegrationException_rethrows_IntegrationException() {
    CaseApplicationDto caseApplicationDtoExpected = buildDefaultCaseApplication(false);
    caseApplicationDtoExpected.setMafDocumentUrl(null);

    List<Applicant> applicantListExpected = new ArrayList<>();
    applicantListExpected.add(buildDefaultApplicant());
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    when(caseTrackingService.getApplication(TEST_BROKER_USERNAME, TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(null);
    when(caseTrackingService.getApplicationDocuments(TEST_MORTGAGE_REFERENCE_NUMBER, TEST_DEFAULT_BRAND))
        .thenReturn(getDefaultCaseTrackingDocumentResponse(false, false, false, false, false));
    when(applicantService.getApplicants(TEST_DEFAULT_BRAND, TEST_CASE_ID))
        .thenThrow(new IntegrationException("Get applicants integration exception test"));
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(caseApplicationDtoExpected);
    when(msvcApplicantToUiApplicantMapper.toUiApplicant(applicantListExpected.get(0)))
        .thenReturn(buildDefaultUiApplicant(applicantListExpected.get(0)));

    assertThatThrownBy(() -> submittedCaseService.getSubmittedCase(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .isInstanceOf(IntegrationException.class)
        .message().isEqualTo("Get applicants integration exception test");

  }

  @Test
  void testGetSubmittedCase_whenBrokerDoesNotHaveAccess_ThrowsException() throws IOException {

    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(false);
    when(caseService.getCaseByCaseId(TEST_CASE_ID, TEST_DEFAULT_BRAND))
        .thenReturn(buildDefaultCaseApplication(true));

    AssociatedBrokerNotFoundException error = Assertions
        .assertThrows(AssociatedBrokerNotFoundException.class, () ->
            submittedCaseService.getSubmittedCase(TEST_CASE_ID, "nwb"),
            "Associated Brokers not found");

  }

  private void assertApplicantsAreEquals(List<Applicant> applicantsExpected, List<UiApplicant> applicants) {
      applicantsExpected.forEach(ae -> {
        assertTrue(applicants.stream().anyMatch(a ->
            ae.getMainApplicant().equals(a.getIsMainApplicant()) &&
            (ae.getPersonalDetails().getFirstNames() + " " + ae.getPersonalDetails().getLastName()).equals(a.getName()) &&
            ae.getPersonalDetails().getTitle().equals(a.getTitle())));
      });


  }
}
