package com.natwest.pbbdhb.broker.dashboard.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerChangeQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerSecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangePasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.ApplicantSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.search.AndOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.CriteriaDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.OperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.OrOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.OrderDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.QueryDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.SimpleOperatorDto;
import com.natwest.pbbdhb.broker.dashboard.model.search.SimpleOperatorDto.CompareType;
import com.natwest.pbbdhb.broker.dashboard.model.search.SortDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_CASE_ID;
import static org.springframework.data.domain.Sort.Direction.DESC;

class WireMockIntegrationTest {

  private static final String FCA_NUMBER = "593672";
  private static final String FIRM_POST_CODE = "RG21%208EN";
  private static final String BROKER_FIRST_NAME = "Ashley%20";
  private static final String BROKER_LAST_NAME = "Hughes";
  private static final String BROKER_EMAIL_ID = "test@example.com";
  private static final String BROKER_POST_CODE = "RG21%208EN";
  private static final String ALL = "All";
  private static final String PAGE_NUMBER = "1";
  private static final String RESULT_PER_PAGE = "50";
  private static final String LAST_MODIFIED_DATE = "Last%20Modified%20Date";
  private static final String SORT_DESC = "Desc";
  private static final String BROKER_USERNAME = "AshHughes07";
  private static final String MODIFIED_DATE = "modifiedDate";
  private static final String IS_ESIS = "isEsis";
  private static final String APPLICATION_STATUS = "applicationStatus";
  private static final String FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS = "FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS";
  private static final String SUBMIT_GMS_MOPS = "SUBMIT_GMS_MOPS";
  private static final String SUBMIT_FMA_IN_PROGRESS = "SUBMIT_FMA_IN_PROGRESS";
  private static final String HAS_COMPLETED_DIP = "journeyData.hasCompletedDip";
  private static final String DOCUMENT_URLS = "salesIllustrations.documentUrls";
  public static final String CASE_ID_FIELD = "_id";
  private static final String SUBMIT_GMS_STAGE_20 = "SUBMIT_GMS_STAGE_20";
  public static final String CRITERIA_MORTGAGE_CASEID = "mortgageRefNumber_caseIds";
  public static final String CRITERIA_MORTGAGE_REFERENCE_NUMBER = "mortgageReferenceNumber";
  private final String ACCESS_TOKEN =
      "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL3BiYm53aXN1YXQuY3JtNC5keW5hbWljcy5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83YzkxN2RiMC03MWYyLTQzOGUtOTU1NC0zODhmZmNhYjg3NjQvIiwiaWF0IjoxNjc5NjYwMzkyLCJuYmYiOjE2Nzk2NjAzOTIsImV4cCI6MTY3OTY2NDI5MiwiYWlvIjoiRTJaZ1lQaHFwSGt5dXNEOHZVdkZncDhGc3ozekFBPT0iLCJhcHBpZCI6IjY3NTcyYTg1LWM0NjUtNDJiNC05MWI5LTQ5YThlNzNlZTNhZCIsImFwcGlkYWNyIjoiMiIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzdjOTE3ZGIwLTcxZjItNDM4ZS05NTU0LTM4OGZmY2FiODc2NC8iLCJvaWQiOiJkOTFlOGIzOS0zZDljLTRiYTQtYWRjOC1iNzhmNGM1MmQ3ZTYiLCJyaCI6IjAuQVJFQXNIMlJmUEp4amtPVlZEaVBfS3VIWkFjQUFBQUFBQUFBd0FBQUFBQUFBQUFSQUFBLiIsInN1YiI6ImQ5MWU4YjM5LTNkOWMtNGJhNC1hZGM4LWI3OGY0YzUyZDdlNiIsInRpZCI6IjdjOTE3ZGIwLTcxZjItNDM4ZS05NTU0LTM4OGZmY2FiODc2NCIsInV0aSI6Ik5ITURHMWIwOFVPU1h4Z2RSQjhVQUEiLCJ2ZXIiOiIxLjAifQ.hkV6fmJfV2jmvuWad5R9fZ894KluBH5N-K6W8cDh1-w-Ko1HCo3fjJhd0Rwo-K1kXoPQ49I0mkJFd8QmtRAh2VMihvN-W8MGxgWHmBy9jYEcGk6dl3_4HDLC3_o2wx-pSaL0MxtK2gjx-oDT_zISpscg2zu3RUZ_KMSoUUduL8UXpRS-MX0YTTa-5V0wKjMR8wsvp5Z4tmnkenwbyLRlN88INDYEgrg67_C4Ls7CGF0DNfLTWdJ5XDIa0uHEO6EFyknTF17mqjiER-JXeh87LNjCg6TztZYKQPjgHsgBVrBwIRA1JRa6buveh48cvxvZNJ4rg2UVDJTDdZmoU75__Q";

  private static final int PORT = 8089;

  @Autowired
  private ObjectMapper objectMapper;

  private WireMockServer wireMockServer = new WireMockServer(
      options()
          .port(PORT)
          .extensions(NoKeepAliveTransformer.class));

  @BeforeEach
  void setUp() throws IOException {
    wireMockServer.start();
  }

  @AfterEach
  void tearDown() {
    wireMockServer.stop();
  }

  void stubBrokerDetailsForValidBrokerEndpoint(String username) throws IOException {

    wireMockServer.stubFor(get("/mortgages/v1/msvc-broker-auth/crm/broker/details/" + username)
        .withHeader("Content-Type", containing("application/json"))
//        .withHeader("Authorization", containing(ACCESS_TOKEN))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm/ValidBrokerDetails.json"))));
  }

  void stubInvalidBrokerForValidBrokerEndpoint(String username) throws IOException {

    wireMockServer.stubFor(get("/mortgages/v1/msvc-broker-auth/crm/broker/details/" + username)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm/InvalidBrokerDetails.json"))));
  }

  void stubDetailsDetailsForValidAdminEndpoint(String username) throws IOException {

    wireMockServer.stubFor(get("/mortgages/v1/msvc-broker-auth/crm/admin/details/" + username)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm/ValidAdminDetails.json"))));
  }

  void stubInvalidAdminForAdminDetailsEndpoint(String username) throws IOException {
    wireMockServer.stubFor(get("/mortgages/v1/msvc-broker-auth/crm/admin/details/" + username)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm/InvalidAdminDetails.json"))));
  }

  void stubGetBrokerAssociations(String username) throws IOException {

    wireMockServer.stubFor(get("/mortgages/v1/msvc-broker-auth/crm/broker/associations/" + username)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm/BrokerAssociations.json"))));
  }

  void stubGetBrokerDisAssociations(String username) throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/msvc-broker-auth/crm/broker/unassociations/" + username)
            .withHeader("Content-Type", containing("application/json"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(getRequestBody("crm/BrokerDisassciations.json"))));
  }

  void stubGetAdminAssociations(String username) throws IOException {
    wireMockServer.stubFor(get("/mortgages/v1/msvc-broker-auth/crm/admin/associations/" + username)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm/AdminAssociations.json"))));
  }

  void stubBrokerToBrokerPermissionRequest(String userName, String grantAccessTo)
      throws IOException {
    BrokerPermissionsResponse permissionsResponse = new BrokerPermissionsResponse();
    permissionsResponse.setMessage("Successfully Granted Permission to Broker");
    wireMockServer.stubFor(post(
        "/mortgages/v1/msvc-broker-auth/crm/broker/association/" + userName + "/broker/"
            + grantAccessTo)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(objectMapper.writeValueAsString(permissionsResponse))));
  }

  void stubRemoveBrokerToBrokerPermissionRequest(String userName, String grantAccessTo)
      throws IOException {
    BrokerPermissionsResponse permissionsResponse = new BrokerPermissionsResponse();
    permissionsResponse.setMessage("Successfully Removed Permission to Broker");

    wireMockServer.stubFor(post(
        "/mortgages/v1/msvc-broker-auth/crm/broker/unassociation/" + userName + "/broker/"
            + grantAccessTo)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(objectMapper.writeValueAsString(permissionsResponse))));
  }


  void stubBrokerToAdminPermissionRequest(String userName, String grantAccessTo)
      throws IOException {
    BrokerPermissionsResponse permissionsResponse = new BrokerPermissionsResponse();
    permissionsResponse.setMessage("Successfully Granted Permission to Admin");
    wireMockServer.stubFor(post(
        "/mortgages/v1/msvc-broker-auth/crm/broker/association/" + userName + "/admin/"
            + grantAccessTo)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(objectMapper.writeValueAsString(permissionsResponse))));

  }

  void stubRemoveBrokerToAdminPermissionRequest(String userName, String grantAccessTo)
      throws IOException {
    BrokerPermissionsResponse permissionsResponse = new BrokerPermissionsResponse();
    permissionsResponse.setMessage("Successfully Removed Permission to Admin");
    wireMockServer.stubFor(post(
        "/mortgages/v1/msvc-broker-auth/crm/broker/unassociation/" + userName + "/admin/"
            + grantAccessTo)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(objectMapper.writeValueAsString(permissionsResponse))));

  }

  void stubGetApplicationsForApplicationTracking() throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/application-tracking/applications?fcaNumber=" + FCA_NUMBER +
            "&firmPostcode=" + FIRM_POST_CODE + "&brokerFirstName=" + BROKER_FIRST_NAME
            + "&brokerLastName=" + BROKER_LAST_NAME +
            "&brokerEmailId=" + BROKER_EMAIL_ID + "&brokerPostcode=" + BROKER_POST_CODE
            + "&dateRange=" + ALL +
            "&resultPerPage=" + RESULT_PER_PAGE + "&sortBy=" + LAST_MODIFIED_DATE +
            "&sortOrder=" + SORT_DESC + "&pageNumber=" + PAGE_NUMBER)
            .withHeader("Content-Type", equalTo("application/json"))
            .withHeader("brand", equalTo("nwb"))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody(
                    "tracking/applications_response_from_application_tracking.json"))));
  }

  void stubGetApplicationDetailsForApplicationTracking(String mortgageRefNumber)
      throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/application-tracking/applicationDetails/" + mortgageRefNumber +
            "?fcaNumber=" + FCA_NUMBER +
            "&firmPostcode=" + FIRM_POST_CODE + "&brokerFirstName=" + BROKER_FIRST_NAME
            + "&brokerLastName=" + BROKER_LAST_NAME +
            "&brokerEmailId=" + BROKER_EMAIL_ID + "&brokerPostcode=" + BROKER_POST_CODE)
            .withHeader("Content-Type", equalTo("application/json"))
            .withHeader("brand", equalTo("nwb"))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody(
                    "tracking/application_details_response_from_application_tracking" +
                        ".json"))));
  }

  void stubGetCaseWithMortgageReferenceNumber(String mortgageRefNumber) throws IOException {
    SimpleOperatorDto operatorDto = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field("mortgageReferenceNumber").value(mortgageRefNumber).build();
    QueryDto queryDto = QueryDto.builder().operator(operatorDto).build();

    CriteriaDto criteriaDto = CriteriaDto.builder().query(queryDto).build();
    wireMockServer.stubFor(post("/v2/cases/search")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetLegacyCaseWithMortgageReferenceNumber(String mortgageRefNumber) throws IOException {
    SimpleOperatorDto operatorDto = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field("mortgageReferenceNumber").value(mortgageRefNumber).build();
    QueryDto queryDto = QueryDto.builder().operator(operatorDto).build();

    CriteriaDto criteriaDto = CriteriaDto.builder().query(queryDto).build();
    wireMockServer.stubFor(post("/v2/cases/search")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody("{}")));
  }

  void stubGetCase() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(CompareType.EQ).field("broker.fcaNumber").value(FCA_NUMBER).build();

    SimpleOperatorDto isEsis = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(IS_ESIS).
        value(Boolean.TRUE.toString()).build();

    List<OperatorDto> orOperatorsNonEsis = new ArrayList<>();

    SimpleOperatorDto applicationStatusFmaForMops = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(SUBMIT_GMS_MOPS).build();
    orOperatorsNonEsis.add(applicationStatusFmaForMops);

    SimpleOperatorDto applicationStatusInProgress = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS).build();
    orOperatorsNonEsis.add(applicationStatusInProgress);

    SimpleOperatorDto applicationStatusFmaInProgress = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(SUBMIT_FMA_IN_PROGRESS).build();
    orOperatorsNonEsis.add(applicationStatusFmaInProgress);

    SimpleOperatorDto applicationStatusNull = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).build();
    orOperatorsNonEsis.add(applicationStatusNull);

    OrOperatorDto orOperatorNonEsis = OrOperatorDto.builder()
        .operators(orOperatorsNonEsis)
        .build();

    List<OperatorDto> andOperatorsNonEsis = Arrays.asList(equalToFcaNumber, orOperatorNonEsis);

    AndOperatorDto andOperatorNonEsis = AndOperatorDto.builder()
        .operators(andOperatorsNonEsis)
        .build();

    List<OperatorDto> orOperators = Arrays.asList(andOperatorNonEsis, isEsis);

    OrOperatorDto orOperator = OrOperatorDto.builder()
        .operators(orOperators)
        .build();

    mainQueryAndOperators.add(orOperator);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseWithCaseIds(List<String> caseIds) throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(CompareType.EQ).field("broker.fcaNumber").value(FCA_NUMBER).build();

    SimpleOperatorDto isEsis = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(IS_ESIS).
        value(Boolean.TRUE.toString()).build();

    List<OperatorDto> orOperatorsNonEsis = new ArrayList<>();

    SimpleOperatorDto applicationStatusFmaForMops = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(SUBMIT_GMS_MOPS).build();
    orOperatorsNonEsis.add(applicationStatusFmaForMops);

    SimpleOperatorDto applicationStatusInProgress = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS).build();
    orOperatorsNonEsis.add(applicationStatusInProgress);

    SimpleOperatorDto applicationStatusFmaInProgress = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(SUBMIT_FMA_IN_PROGRESS).build();
    orOperatorsNonEsis.add(applicationStatusFmaInProgress);

    SimpleOperatorDto applicationStatusNull = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).build();
    orOperatorsNonEsis.add(applicationStatusNull);
    OrOperatorDto orOperatorNonEsis = OrOperatorDto.builder()
        .operators(orOperatorsNonEsis)
        .build();

    List<OperatorDto> andOperatorsNonEsis = Arrays.asList(equalToFcaNumber, orOperatorNonEsis);
    AndOperatorDto andOperatorNonEsis = AndOperatorDto.builder()
        .operators(andOperatorsNonEsis)
        .build();
    List<OperatorDto> orOperators = Arrays.asList(andOperatorNonEsis, isEsis);

    OrOperatorDto orOperator = OrOperatorDto.builder()
        .operators(orOperators)
        .build();
    mainQueryAndOperators.add(orOperator);

    OperatorDto caseIdsOperator = SimpleOperatorDto.builder()
        .compareType(CompareType.IN)
        .field(CASE_ID_FIELD)
        .values(Sets.newHashSet(caseIds))
        .build();
    mainQueryAndOperators.add(caseIdsOperator);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCase(String caseId) throws IOException {

    wireMockServer.stubFor(get("/v2/cases/" + caseId)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("get_case_response.json"))));
  }

  void stubGetCaseFilteredByFMAInProgress() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    List<OperatorDto> fmaAndOperators = new ArrayList<>();
    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value(FCA_NUMBER).build();
    SimpleOperatorDto operatorFmaApplicationStatusInProgress = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS)
        .build();
    fmaAndOperators.add(equalToFcaNumber);
    fmaAndOperators.add(operatorFmaApplicationStatusInProgress);

    mainQueryAndOperators.addAll(fmaAndOperators);
    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByFMASubmissionInProgress() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value(FCA_NUMBER).build();
    mainQueryAndOperators.add(equalToFcaNumber);

    SimpleOperatorDto operatorFmaApplicationStatusSubmitGmsMops = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_GMS_MOPS)
        .build();
    SimpleOperatorDto operatorFmaApplicationStatusSubmitFmaInProgress = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value(SUBMIT_FMA_IN_PROGRESS)
        .build();
    OrOperatorDto operatorForFmaSubmissionInProgress = OrOperatorDto.builder()
        .operators(Arrays.asList(
            operatorFmaApplicationStatusSubmitGmsMops,
            operatorFmaApplicationStatusSubmitFmaInProgress))
        .build();

    mainQueryAndOperators.add(operatorForFmaSubmissionInProgress);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators).build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByFMACompleted() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();

    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value(FCA_NUMBER).build();

    mainQueryAndOperators.add(equalToFcaNumber);

    SimpleOperatorDto operatorFmaApplicationStatusCompleted = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value("COMPLETED")
        .build();

    mainQueryAndOperators.add(operatorFmaApplicationStatusCompleted);

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByAIPInProgress() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value(FCA_NUMBER).build();
    mainQueryAndOperators.add(equalToFcaNumber);

    SimpleOperatorDto operatorAipEsisIsNull = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(IS_ESIS)
        .value(null)
        .build();

    SimpleOperatorDto operatorAipEsisIsFalse = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(IS_ESIS)
        .value(Boolean.FALSE.toString())
        .build();

    SimpleOperatorDto operatorAipApplicationStatusIsNull = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .build();

    SimpleOperatorDto operatorForAipHasCompletedDipFalse = SimpleOperatorDto
        .builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(HAS_COMPLETED_DIP)
        .value(Boolean.FALSE.toString())
        .build();

    SimpleOperatorDto operatorForAipHasCompletedDipNull = SimpleOperatorDto
        .builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(HAS_COMPLETED_DIP)
        .build();

    OrOperatorDto aipTypeNotHasCompletedEsisOrOperator = OrOperatorDto.builder()
        .operators(
            Arrays.asList(operatorForAipHasCompletedDipNull, operatorForAipHasCompletedDipFalse))
        .build();

    OrOperatorDto operatorNotEsis = OrOperatorDto.builder()
        .operators(Arrays.asList(operatorAipEsisIsNull, operatorAipEsisIsFalse))
        .build();

    mainQueryAndOperators.add(operatorNotEsis);
    mainQueryAndOperators.add(operatorAipApplicationStatusIsNull);
    mainQueryAndOperators.add(aipTypeNotHasCompletedEsisOrOperator);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByAIPSubmissionInProgress() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value(FCA_NUMBER).build();
    mainQueryAndOperators.add(equalToFcaNumber);

    SimpleOperatorDto operatorEmptyList = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value("COMPLETED")
        .build();
    mainQueryAndOperators.add(operatorEmptyList);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByAIPCompleted() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value(FCA_NUMBER).build();
    mainQueryAndOperators.add(equalToFcaNumber);

    SimpleOperatorDto operatorAipEsisIsNull = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(IS_ESIS)
        .value(null)
        .build();

    SimpleOperatorDto operatorAipEsisIsFalse = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(IS_ESIS)
        .value(Boolean.FALSE.toString())
        .build();

    OrOperatorDto operatorNotEsis = OrOperatorDto.builder()
        .operators(Arrays.asList(operatorAipEsisIsNull, operatorAipEsisIsFalse))
        .build();
    mainQueryAndOperators.add(operatorNotEsis);

    SimpleOperatorDto operatorAipApplicationStatusIsNull = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .build();
    mainQueryAndOperators.add(operatorAipApplicationStatusIsNull);

    SimpleOperatorDto operatorAipHasCompletedDip = SimpleOperatorDto.builder()
        .compareType(CompareType.EQ)
        .field(HAS_COMPLETED_DIP)
        .value(Boolean.TRUE.toString())
        .build();
    mainQueryAndOperators.add(operatorAipHasCompletedDip);

    AndOperatorDto mainQueryAndOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryAndOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByESISInProgress() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto operatorEsisIsEsisTrue = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(IS_ESIS)
        .value(Boolean.TRUE.toString())
        .build();
    mainQueryAndOperators.add(operatorEsisIsEsisTrue);

    SimpleOperatorDto operatorForEsisDocumentUrlsEmpty = SimpleOperatorDto
        .builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(DOCUMENT_URLS)
        .build();
    mainQueryAndOperators.add(operatorForEsisDocumentUrlsEmpty);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByESISSubmissionInProgress() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);


    SimpleOperatorDto operatorEmptyList = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(APPLICATION_STATUS)
        .value("COMPLETED")
        .build();
    mainQueryAndOperators.add(operatorEmptyList);

    AndOperatorDto mainQueryOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetCaseFilteredByESISCompleted() throws IOException {
    List<OperatorDto> mainQueryAndOperators = new ArrayList<>();

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(BROKER_USERNAME).build();
    mainQueryAndOperators.add(equalToBrokerUsername);

    SimpleOperatorDto operatorAipEsisIsTrue = SimpleOperatorDto.builder()
        .compareType(SimpleOperatorDto.CompareType.EQ)
        .field(IS_ESIS)
        .value(Boolean.TRUE.toString())
        .build();
    mainQueryAndOperators.add(operatorAipEsisIsTrue);

    SimpleOperatorDto operatorForEsisDocumentUrlsPresent = SimpleOperatorDto
        .builder()
        .compareType(CompareType.LIKE)
        .field(DOCUMENT_URLS)
        .value("http")
        .build();
    mainQueryAndOperators.add(operatorForEsisDocumentUrlsPresent);

    AndOperatorDto mainQueryAndOperator = AndOperatorDto.builder()
        .operators(mainQueryAndOperators)
        .build();

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(mainQueryAndOperator).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("tracking/case_response_from_case_service.json"))));
  }

  void stubGetApplicants(String caseId) throws IOException {
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto operatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.IN)
            .field("caseId").values(Sets.newHashSet(caseId)).build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto queryDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto.builder()
            .operator(operatorDto).build();

    ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
    applicantSearchResponse.setContent(
        Lists.newArrayList(Applicant.builder().applicantId("12345678").caseId(caseId).build()));

    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto criteriaDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto.builder()
            .query(queryDto).build();
    wireMockServer.stubFor(post("/v2/applicants/search")
        .withHeader("Content-Type", containing("application/json"))
        .withHeader("brand", containing("nwb"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("applicants_response_from_applicant_service.json"))));
  }

  void stubGetZeroApplicants(String caseId) throws IOException {
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto operatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.IN)
            .field("caseId").values(Sets.newHashSet(caseId)).build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto queryDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto.builder()
            .operator(operatorDto).build();

    ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
    applicantSearchResponse.setContent(
        Lists.newArrayList(Applicant.builder().applicantId("12345678").caseId(caseId).build()));

    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto criteriaDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto.builder()
            .query(queryDto).build();
    wireMockServer.stubFor(post("/v2/applicants/search")
        .withHeader("Content-Type", containing("application/json"))
        .withHeader("brand", containing("nwb"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("empty_applicants_response_from_applicant_service.json"))));
  }

  void stubGetApplicantsByCaseId(String caseId) throws IOException {
    ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
    applicantSearchResponse.setContent(
        Lists.newArrayList(Applicant.builder().applicantId("12345678").caseId(caseId).build()));

    wireMockServer.stubFor(get("/v2/applicants/case/" + caseId)
        .withHeader("Content-Type", containing("application/json"))
        .withHeader("brand", containing("nwb"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("get_applicants_for_caseId_response.json"))));
  }

  void stubGetApplicantsByLastName(String lastName) throws IOException {
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto operatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.LIKE)
            .field("personalDetails.lastName").value(lastName).build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto queryDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto.builder()
            .operator(operatorDto).build();

    ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
    applicantSearchResponse.setContent(
        Lists.newArrayList(Applicant.builder().applicantId("12345678").build()));

    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto criteriaDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto.builder()
            .query(queryDto).build();
    wireMockServer.stubFor(post("/v2/applicants/search")
        .withHeader("Content-Type", containing("application/json"))
        .withHeader("brand", containing("nwb"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("applicants_response_from_applicant_service.json"))));
  }

  void stubGetApplicantsByLastNameAndPostcode(String lastName, String postcode) throws IOException {
    List<com.natwest.pbbdhb.broker.dashboard.model.applicant.search.OperatorDto> operators = new ArrayList<>();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto nameOperatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.LIKE)
            .field("personalDetails.lastName").value(lastName).build();
    operators.add(nameOperatorDto);
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto postcodeOperatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.EQ)
            .field("addresses.postcode").value(postcode).build();
    operators.add(postcodeOperatorDto);
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.AndOperatorDto andOperator = com.natwest.pbbdhb.broker.dashboard.model.applicant.search.AndOperatorDto.builder()
        .operators(operators).build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto queryDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto.builder()
            .operator(andOperator).build();

    ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
    applicantSearchResponse.setContent(
        Lists.newArrayList(Applicant.builder().applicantId("12345678").build()));

    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto criteriaDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto.builder()
            .query(queryDto).build();
    wireMockServer.stubFor(post("/v2/applicants/search")
        .withHeader("Content-Type", containing("application/json"))
        .withHeader("brand", containing("nwb"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("applicants_response_from_applicant_service.json"))));
  }

  void stubGetApplicantsByLastNameAndDob(String lastName, String dateOfBirth) throws IOException {
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto lastNameOperatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.LIKE)
            .field("personalDetails.lastName")
            .value(lastName)
            .build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto dobOperatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.builder()
            .compareType(
                com.natwest.pbbdhb.broker.dashboard.model.applicant.search.SimpleOperatorDto.CompareType.DATE_EQ)
            .field("personalDetails.dateOfBirth")
            .value(dateOfBirth)
            .build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.AndOperatorDto andOperatorDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.AndOperatorDto.builder()
            .operators(Arrays.asList(lastNameOperatorDto, dobOperatorDto))
            .build();
    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto queryDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.QueryDto.builder()
            .operator(andOperatorDto).build();

    ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
    applicantSearchResponse.setContent(
        Lists.newArrayList(Applicant.builder().applicantId("12345678").build()));

    com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto criteriaDto =
        com.natwest.pbbdhb.broker.dashboard.model.applicant.search.CriteriaDto.builder()
            .query(queryDto).build();
    wireMockServer.stubFor(post("/v2/applicants/search")
        .withHeader("Content-Type", containing("application/json"))
        .withHeader("brand", containing("nwb"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("applicants_response_from_applicant_service.json"))));
  }

  void stubUpdateBrokerUserPassword() throws IOException {

    ChangePasswordRequest changePasswordRequest =
        ChangePasswordRequest.builder()
            .currentPassword("456")
            .newPassword("123")
            .username("AshHughes07")
            .build();

    wireMockServer.stubFor(post("/mortgages/v1/msvc-broker-auth/account-management/password-change")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(changePasswordRequest)))
        .willReturn(aResponse()
            .withStatus(200)));
  }


  void stubGetSecurityQuestions() throws IOException {
    BrokerQuestionsRequest request = BrokerQuestionsRequest.builder()
        .username(BROKER_USERNAME)
        .build();

    wireMockServer.stubFor(
        post("/mortgages/v1/msvc-broker-auth/account-management/challenge-questions")
            .withHeader("Content-Type", containing("application/json"))
            .withRequestBody(containing(objectMapper.writeValueAsString(request)))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody("challenge_questions_response_from_msvc_broker.json"))));

  }


  void stubChangeSecurityQuestions() throws IOException {
    BrokerChangeQuestionsRequest request = BrokerChangeQuestionsRequest.builder()
        .username(BROKER_USERNAME)
        .questions(Collections.singletonList(BrokerSecurityQuestion.builder()
            .question("Question?")
            .answer("Answer")
            .build()))
        .build();

    wireMockServer.stubFor(
        post("/mortgages/v1/msvc-broker-auth/account-management/change-questions")
            .withHeader("Content-Type", containing("application/json"))
            .withRequestBody(containing(objectMapper.writeValueAsString(request)))
            .willReturn(aResponse()
                .withStatus(204)));
  }

  void stubGetBrokerDetails() throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/msvc-broker-auth/account-management/broker-details/AshHughes07")
            .withHeader("Content-Type", containing("application/json"))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody("broker_details_response.json"))));
  }

  void stubGetBrokerDetails(String username) throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/msvc-broker-auth/account-management/broker-details/" + username)
            .withHeader("Content-Type", containing("application/json"))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody("broker_details_response.json"))));
  }

  void stubGetFirmDetails() throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/msvc-broker-auth/account-management/firm-details/593672")
            .withHeader("Content-Type", containing("application/json"))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody("firm_details_response.json"))));
  }

  void stubUpdateBrokerDetails() throws IOException {

    wireMockServer.stubFor(put("/mortgages/v1/msvc-broker-auth/account-management/broker-details")
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("update_broker_details_response.json"))));
  }

  void stubGetBrokerCase() throws IOException {

    wireMockServer.stubFor(get("/broker/submitted-cae/" + TEST_CASE_ID)
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("submitted_case_response.json"))));
    ;
  }

  void stubGetApplicationDocuments(String mortgageReferenceNumber) throws IOException {

    wireMockServer.stubFor(
        get("/mortgages/v1/msvc-application-tracking/application/" + mortgageReferenceNumber
            + "/documents")
            .withHeader("Content-Type", containing("application/json"))
            .willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withStatus(200)
                .withBody(getRequestBody("get_application_documents_response.json"))));
    ;
  }

  private String getRequestBody(String fileName) throws IOException {
    return new String(Files.readAllBytes(Paths.get("src", "test", "resources", fileName)));
  }

  void stubGetCasesWithCriteria(String criteria, boolean isBroker) throws IOException {

    SimpleOperatorDto equalToBrokerUsername = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("broker.brokerUsername").
        value(isBroker ? BROKER_USERNAME : "WimbleC11").build();

    SimpleOperatorDto equalToFcaNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field("broker.fcaNumber").
        value("593672").build();

    SimpleOperatorDto equalToMortgageRefNumber = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ_IGNORE_CASE).field("mortgageReferenceNumber").
        value("31664716").build();

    SimpleOperatorDto notEmptyMortgageRefNumber = SimpleOperatorDto.builder().
        compareType(CompareType.LIKE).field("mortgageReferenceNumber").
        value("").build();

    List<OperatorDto> operatorForAppStatus = new ArrayList<>();

    SimpleOperatorDto applicationStatusFmaForMops = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(SUBMIT_GMS_MOPS).build();

    operatorForAppStatus.add(applicationStatusFmaForMops);

    SimpleOperatorDto applicationStatusFmaForMops20 = SimpleOperatorDto.builder().
        compareType(SimpleOperatorDto.CompareType.EQ).field(APPLICATION_STATUS).
        value(SUBMIT_GMS_STAGE_20).build();

    operatorForAppStatus.add(applicationStatusFmaForMops20);

    OperatorDto caseIdsOperator = SimpleOperatorDto.builder()
        .compareType(CompareType.IN)
        .field("_id")
        .values(Collections.singleton("ID20230329140023905042"))
        .build();

    OrOperatorDto.OrOperatorDtoBuilder orOperatorDtoBuilder = OrOperatorDto.builder();

    OrOperatorDto orOperatorDto = orOperatorDtoBuilder.operators(operatorForAppStatus).build();

    AndOperatorDto.AndOperatorDtoBuilder andOperatorDtoBuilder = AndOperatorDto.builder();

    AndOperatorDto andOperatorDto = null;

    if (CRITERIA_MORTGAGE_CASEID.equals(criteria)) {
      andOperatorDto = andOperatorDtoBuilder.operators(
          Arrays.asList(equalToBrokerUsername, equalToFcaNumber, equalToMortgageRefNumber,
              notEmptyMortgageRefNumber, orOperatorDto, caseIdsOperator)).build();
    } else if (CRITERIA_MORTGAGE_REFERENCE_NUMBER.equals(criteria)) {
      andOperatorDto = andOperatorDtoBuilder.operators(
          Arrays.asList(equalToBrokerUsername, equalToFcaNumber, equalToMortgageRefNumber,
              notEmptyMortgageRefNumber, orOperatorDto)).build();
    } else {
      andOperatorDto = andOperatorDtoBuilder.operators(
          Arrays.asList(equalToBrokerUsername, equalToFcaNumber, notEmptyMortgageRefNumber,
              orOperatorDto, caseIdsOperator))
          .build();
    }

    ArrayList<OrderDto> orders =
        Lists.newArrayList(OrderDto.builder().field(MODIFIED_DATE).direction(DESC.name()).build());
    SortDto sortDto = SortDto.builder().orders(orders).build();

    QueryDto query = QueryDto.builder().operator(andOperatorDto).build();
    CriteriaDto criteriaDto = CriteriaDto.builder().query(query).sort(sortDto).build();
    wireMockServer.stubFor(post("/v2/cases/search?page=0&size=15")
        .withHeader("Content-Type", containing("application/json"))
        .withRequestBody(containing(objectMapper.writeValueAsString(criteriaDto)))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withStatus(200)
            .withBody(getRequestBody("submitted-cases/case_response_from_case_service.json"))));
  }
}
