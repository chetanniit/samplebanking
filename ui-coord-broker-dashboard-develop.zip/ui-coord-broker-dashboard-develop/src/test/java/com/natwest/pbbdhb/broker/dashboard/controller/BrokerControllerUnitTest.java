package com.natwest.pbbdhb.broker.dashboard.controller;

import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_BROKER_USERNAME;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.controller.impl.BrokerController;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.mapper.crm.BrokerAssociationsToDtoMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.user.UserDetailsToBrokerDetailsDtoMapper;
import com.natwest.pbbdhb.broker.dashboard.service.AuthService;
import com.natwest.pbbdhb.broker.dashboard.service.SubmittedCaseService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerAssociationsService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerDetailsService;
import com.natwest.pbbdhb.broker.dashboard.service.crm.BrokerPermissionsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(BrokerController.class)
public class BrokerControllerUnitTest {

  @MockBean
  private AuthService authService;
  @MockBean
  private UserService userService;
  @MockBean
  private BrokerAssociationsService brokerAssociationsService;
  @MockBean
  private BrokerPermissionsService brokerPermissionsService;
  @MockBean
  private BrokerAssociationsToDtoMapper brokerAssociationsToDtoMapper;
  @MockBean
  private UserDetailsToBrokerDetailsDtoMapper userDetailsToBrokerDetailsDtoMapper;
  @MockBean
  private BrokerDetailsService brokerDetailsService;
  @MockBean
  private SubmittedCaseService submittedCaseService;

  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private ObjectMapper objectMapper;

  @Test
  public void shouldUpdateBrokerPassword() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    BrokerPasswordRequest request = BrokerPasswordRequest.builder()
        .currentPassword("TESTPASSOLD")
        .newPassword("TESTPASSNEW")
        .build();
    doNothing().when(authService).updateBrokerUserPassword(TEST_BROKER_USERNAME, request.getCurrentPassword(),
        request.getNewPassword());

    this.mockMvc.perform(post("/broker/password-change")
        .contentType(MediaType.APPLICATION_JSON)
        .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(authService, times(1)).updateBrokerUserPassword(any(), any(), any());
  }





}
