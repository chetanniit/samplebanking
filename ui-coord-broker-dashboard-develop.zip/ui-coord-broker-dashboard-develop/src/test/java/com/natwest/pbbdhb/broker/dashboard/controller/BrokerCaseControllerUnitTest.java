package com.natwest.pbbdhb.broker.dashboard.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.natwest.pbbdhb.broker.dashboard.controller.impl.BrokerCaseController;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.ProductChangeRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.model.SuccessResponse;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.ProductChangeService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import com.natwest.pbbdhb.broker.dashboard.service.documents.DocumentDownloadService;

import java.math.BigDecimal;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {BrokerCaseController.class})
public class BrokerCaseControllerUnitTest {

    public static final String ESIS_DOCUMENT = "EsisDocument";
    public static final String MAF_DOCUMENT = "mafDocument";
    private static final String TEST_BROKER_USERNAME = "AshHughes07";
    private static final String TEST_FCA_NUMBER = "123456";
    private static final String SUBMITTED_CASE_URL = "/broker/submitted-cases";
    private static final String PRE_SUBMITTED_CASE_URL = "/broker/cases";
    private static final String PRODUCT_CHANGE_URL = "/A1234567/product-change";
    private static final String TEST_BROKER_USERNAME_PARAM = "brokerUsername";

    @MockBean
    private CaseService caseService;
    @MockBean
    private DocumentDownloadService documentDownloadService;
    @MockBean
    private UserService userService;
    @MockBean
    private ProductChangeService productChangeService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
    }

    @Test
    public void retrieveESISDocument() throws Exception {
        byte[] pdfData = "ESIS document contents".getBytes();
        Optional<byte[]> byteResponse = Optional.of(pdfData);
        when(documentDownloadService.getESISDocument(eq(ESIS_DOCUMENT))).thenReturn(byteResponse);

        RequestBuilder request = get("/esis/EsisDocument")
                .contentType(MediaType.APPLICATION_JSON);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF_VALUE));
    }

    @Test
    public void retrieveMAFDocument() throws Exception {
        byte[] pdfData = "MAF document contents".getBytes();
        Optional<byte[]> byteResponse = Optional.of(pdfData);
        when(documentDownloadService.getFMADocument(eq("nwb"), eq(MAF_DOCUMENT))).thenReturn(byteResponse);

        RequestBuilder request = get("/maf/mafDocument")
                .header("brand", "nwb")
                .contentType(MediaType.APPLICATION_JSON);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF_VALUE));
    }

  @Test
  public void shouldGetSubmittedCases200Response() throws Exception {
    SubmittedCase submittedCase = new SubmittedCase();
    submittedCase.setCaseId("12345");
    submittedCase.setMortgageReferenceNumber("12345");
    submittedCase.setLastUpdated("2002/09/09");
    submittedCase.setApplicants(null);
    SubmittedCases submittedCases = SubmittedCases.builder()
        .submittedCases(Collections.singletonList(submittedCase))
        .totalPages(1)
        .totalElements(1L)
        .size(1)
        .number(1)
        .build();
    when(userService.getBrokerFcaNumber(TEST_BROKER_USERNAME)).thenReturn(TEST_FCA_NUMBER);
    when(caseService.getSubmittedCases(TEST_BROKER_USERNAME, TEST_FCA_NUMBER, "nwb","0","15",
        null,null,null,null)).thenReturn(submittedCases);

    RequestBuilder request = get(SUBMITTED_CASE_URL)
        .queryParam(TEST_BROKER_USERNAME_PARAM,TEST_BROKER_USERNAME)
        .header("brand","nwb")
        .contentType(MediaType.APPLICATION_JSON);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }

  @Test
  public void shouldGetPreSubmittedCases200Response() throws Exception {
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("12345");
    preSubmittedCase.setLastUpdated("2002/09/09");
    preSubmittedCase.setApplicants(null);
    PreSubmittedCases preSubmittedCases = PreSubmittedCases.builder()
        .preSubmittedCases(Collections.singletonList(preSubmittedCase))
        .totalPages(1)
        .totalElements(1L)
        .size(1)
        .number(1)
        .build();
    when(userService.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(userService.getDetails()).thenReturn(UserDetails.builder().fcaNumber(TEST_FCA_NUMBER).build());
    when(caseService.getPreSubmittedCases(TEST_BROKER_USERNAME, TEST_FCA_NUMBER,"nwb","0","15",
        null,null,null,null,null)).thenReturn(preSubmittedCases);

    RequestBuilder request = get(PRE_SUBMITTED_CASE_URL)
        .queryParam(TEST_BROKER_USERNAME_PARAM,TEST_BROKER_USERNAME)
        .header("brand","nwb")
        .contentType(MediaType.APPLICATION_JSON);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }

    @Test
    public void shouldSubmitProductChange200Response() throws Exception {
        ProductChangeRequest productChangeRequest = ProductChangeRequest.builder().
                productCode("F012345").
                productFee("no fee").productType("FIXED").
                productTermYears("TWO_YEAR").productLtv(60L).productInterestRate(new BigDecimal("10")).build();
        when(productChangeService.changeProduct(eq(productChangeRequest), eq("nwb"), eq("A1234567"))).thenReturn(SuccessResponse.builder().build());
        RequestBuilder request = post(PRODUCT_CHANGE_URL)
                .contentType("application/json")
                .content(new ObjectMapper().writeValueAsString(productChangeRequest))
                .header("brand", "nwb")
                .contentType(MediaType.APPLICATION_JSON);

        this.mockMvc.perform(request)
                .andExpect(status().isOk());
    }

    @Test
    public void shouldSubmitProductChange400Response() throws Exception {
        ProductChangeRequest productChangeRequest = ProductChangeRequest.builder().
                productCode(null).
                productFee("no fee").productType("FIXED").
                productTermYears("TWO_YEAR").productLtv(60L).productInterestRate(new BigDecimal("10")).build();
        when(productChangeService.changeProduct(eq(productChangeRequest), eq("nwb"), eq("A1234567"))).thenReturn(SuccessResponse.builder().build());
        RequestBuilder request = post(PRODUCT_CHANGE_URL)
                .contentType("application/json")
                .content(new ObjectMapper().writeValueAsString(productChangeRequest))
                .header("brand", "nwb")
                .contentType(MediaType.APPLICATION_JSON);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest());
    }

}
