package com.natwest.pbbdhb.broker.dashboard.integration;

import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.RequestedType.NON_STP;
import static com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.RequestedType.STP;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.FirmDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.enums.NonSTPFieldCategory;
import java.io.IOException;
import java.util.Collections;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
@ComponentScan("com.natwest.pbbdhb.broker.dashboard.config.broker")
public class AccountManagementControllerTest extends WireMockIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() throws IOException {
        super.setUp();
    }

    @AfterEach
    void tearDown() {
        super.tearDown();
    }


    @Test
    public void shouldChangePassword() throws Exception {
        stubUpdateBrokerUserPassword();

        BrokerPasswordRequest request = BrokerPasswordRequest.builder()
            .newPassword("123")
            .currentPassword("456").build();

            mockMvc.perform(post("/account-management/password-change")
                    .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNoContent()).andReturn();
    }

    @Test
    public void shouldGetSecurityQuestions() throws Exception {
        stubGetSecurityQuestions();

        MvcResult result =
            mockMvc.perform(get("/account-management/security-questions"))
                .andExpect(status().isOk()).andReturn();

        BrokerQuestionsResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
            BrokerQuestionsResponse.class);

        assertEquals(5, response.getSecurityQuestions().size());
    }

    @Test
    public void shouldChangeSecurityQuestions() throws Exception {
        stubChangeSecurityQuestions();

        ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()

            .securityQuestions(Collections.singletonList(SecurityQuestion.builder()
                .question("Question?")
                .answer("Answer")
                .build()))
            .build();

            mockMvc.perform(put("/account-management/security-questions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNoContent()).andReturn();

    }

    @Test
    public void shouldGetBrokerDetails() throws Exception {
        stubGetBrokerDetails();

        MvcResult mvcResult = mockMvc.perform(get("/account-management/broker-details"))
            .andExpect(status().isOk()).andReturn();

        BrokerDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
            BrokerDetailsResponse.class);

        assertEquals("Liverpool", response.getBrokerDetails().getCity());
        assertEquals(NonSTPFieldCategory.NAME, response.getProcessingFields().get(0));
        assertEquals(NonSTPFieldCategory.EMAIL, response.getProcessingFields().get(1));
        assertEquals(NonSTPFieldCategory.ADDRESS, response.getProcessingFields().get(2));
    }

    @Test
    public void shouldGetFirmDetails() throws Exception {
        stubGetFirmDetails();



        MvcResult mvcResult = mockMvc.perform(get("/account-management/firm-details?fcanumber=593672"))
            .andExpect(status().isOk()).andReturn();

        FirmDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
            FirmDetailsResponse.class);

        assertEquals("593672", response.getFcaNumber());
    }

    @Test
    public void shouldUpdateBrokerDetails() throws Exception {
        stubUpdateBrokerDetails();

        BrokerDetails request = BrokerDetails.builder().build();

        MvcResult mvcResult = mockMvc.perform(put("/account-management/broker-details")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isOk()).andReturn();

        UpdateBrokerDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
            UpdateBrokerDetailsResponse.class);

        assertEquals(NonSTPFieldCategory.NAME, response.getProcessingFields().get(0));
        assertEquals(NonSTPFieldCategory.EMAIL, response.getProcessingFields().get(1));
        assertEquals(NonSTPFieldCategory.ADDRESS, response.getProcessingFields().get(2));
        assertEquals(STP, response.getRequestedTypes().get(0));
        assertEquals(NON_STP, response.getRequestedTypes().get(1));
    }

}