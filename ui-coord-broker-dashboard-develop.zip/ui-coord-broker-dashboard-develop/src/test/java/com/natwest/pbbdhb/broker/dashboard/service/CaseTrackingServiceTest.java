package com.natwest.pbbdhb.broker.dashboard.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicationsServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.HttpCustomException;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.ApplicationDetailsResponseToCaseMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.ApplicationDetailsToTrackingApplicationDetailsMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.ApplicationsResponseToCaseTrackingResponseMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.cases.track.BrokerCoreResponseToApplicationRequestMapper;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.request.ApplicationsRequest;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.ApplicationsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Case;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingDocumentResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.CaseTrackingResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.PackagingStatus;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.TrackingApplicationDetailResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.service.impl.CaseTrackingServiceImpl;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(SpringExtension.class)
public class CaseTrackingServiceTest {
    private static final String APPLICATIONS_URL = "https://test/mortgages/v1/application-tracking/applications";
    private static final String APPLICATION_DOCUMENTS_URL = "https://test/mortgages/v1/application-tracking/application/{mortgageRefNumber}/documents";
    private static final String APPLICATION_DETAILS_URL = "https://test/mortgages/v1/application-tracking" +
            "/applicationDetails/{mortgageRefNumber}";
    private static final String FCA_NUMBER = "fcaNumber";
    private static final String FIRM_POSTCODE = "firmPostcode";
    private static final String BROKER_SURNAME = "brokerSurname";
    private static final String BROKER_FORE_NAME = "brokerForeName";
    private static final String BROKER_EMAIL = "brokerEmail";
    private static final String TEST_BROKER = "cphillips1";
    private static final String TEST_MRN = "84109387";

    @InjectMocks
    CaseTrackingServiceImpl caseTrackingService;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private RestTemplate iamJwtChainSecureRestTemplate;
    @Mock
    private CrmService crmService;
    @Mock
    private BrokerCoreResponseToApplicationRequestMapper brokerCoreResponseToApplicationRequestMapper;
    @Mock
    private ApplicationsResponseToCaseTrackingResponseMapper applicationsResponseToCaseTrackingResponseMapper;
    @Mock
    private ApplicationDetailsToTrackingApplicationDetailsMapper applicationDetailsToTrackingApplicationDetailsMapper;
    @Mock
    private ApplicationDetailsResponseToCaseMapper applicationDetailsResponseToCaseMapper;

    @Mock
    private UserService userService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(caseTrackingService, "applicationsUrl", APPLICATIONS_URL);
        ReflectionTestUtils.setField(caseTrackingService, "applicationDetailsUrl", APPLICATION_DETAILS_URL);
        ReflectionTestUtils.setField(caseTrackingService, "applicationDocumentsUrl", APPLICATION_DOCUMENTS_URL);
        objectMapper = new ObjectMapper();
    }

    @Test
    void testGetApplications() throws IOException {
        ApplicationsResponse applicationsResponse = objectMapper.readValue(getRequestBody(
            "applications_tracking_response.json"), ApplicationsResponse.class);
        CaseTrackingResponse caseTrackingResponse = objectMapper.readValue(getRequestBody(
            "applications_tracking_to_case_tracking_response.json"),
            CaseTrackingResponse.class);

        when(userService.getBrokerUsername()).thenReturn(TEST_BROKER);
        when(userService.getCheckForUserPrincipal()).thenReturn(true);
        when(userService.getDetails()).thenReturn(getUserDetails());
        when(applicationsResponseToCaseTrackingResponseMapper.toCaseTrackingResponse(applicationsResponse)).thenReturn(caseTrackingResponse);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
            eq(ApplicationsResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(applicationsResponse));

        CaseTrackingResponse response = caseTrackingService.getApplications(TEST_BROKER, null, null, null, null,
            "nwb");
        assertEquals(6, response.getCases().size());

    }

    @Test
    void testGetApplications_setsDateRangeWithValueAll() throws IOException {
        ApplicationsResponse applicationsResponse = objectMapper.readValue(getRequestBody(
            "applications_tracking_response.json"), ApplicationsResponse.class);
        CaseTrackingResponse caseTrackingResponse = objectMapper.readValue(getRequestBody(
            "applications_tracking_to_case_tracking_response.json"),
            CaseTrackingResponse.class);

        when(userService.getBrokerUsername()).thenReturn(TEST_BROKER);
        when(userService.getCheckForUserPrincipal()).thenReturn(true);
        when(userService.getDetails()).thenReturn(getUserDetails());
        when(applicationsResponseToCaseTrackingResponseMapper.toCaseTrackingResponse(applicationsResponse)).thenReturn(caseTrackingResponse);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
            eq(ApplicationsResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(applicationsResponse));

        CaseTrackingResponse response = caseTrackingService.getApplications(TEST_BROKER, null, null, null, null,
            "nwb");
        assertEquals(6, response.getCases().size());

        ArgumentCaptor<URI> uriCaptor = ArgumentCaptor.forClass(URI.class);
        verify(iamJwtChainSecureRestTemplate).exchange(uriCaptor.capture(), eq(HttpMethod.GET), any(),
            eq(ApplicationsResponse.class));
        assertTrue(uriCaptor.getValue().getQuery().contains("dateRange=All"));
    }

    @Test
    void testGetApplicationsWithException() {
        when(userService.getBrokerUsername()).thenReturn(TEST_BROKER);
        when(userService.getCheckForUserPrincipal()).thenReturn(true);
        when(userService.getDetails()).thenReturn(getUserDetails());
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationsResponse.class))).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        ApplicationsServiceException thrown = Assertions.assertThrows(ApplicationsServiceException.class, () -> {
            caseTrackingService.getApplications(TEST_BROKER, null, null, null, null, "nwb");
        }, "Exception");

        Exception ex = ((HttpCustomException) thrown).getException();
        assertEquals("500 INTERNAL_SERVER_ERROR", ex.getMessage());
    }

    @Test
    void testGetApplicationsWithNotFoundException() {
        when(userService.getBrokerUsername()).thenReturn(TEST_BROKER);
        when(userService.getCheckForUserPrincipal()).thenReturn(true);
        when(userService.getDetails()).thenReturn(getUserDetails());
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationsResponse.class))).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        RuntimeException thrown = Assertions.assertThrows(RuntimeException.class, () -> {
            caseTrackingService.getApplications(TEST_BROKER, null, null, null, null, "nwb");
        }, "Exception - Applications not found for broker with FCA number: fcaNumber");

        assertEquals("getApplications: Exception - Applications not found for broker with FCA number: fcaNumber", thrown.getMessage());
    }

    @Test
    void testGetApplicationDetail() throws IOException {
        ApplicationDetailsResponse applicationDetailsResponse = objectMapper.readValue(getRequestBody(
                "application_tracking_detail_response.json"), ApplicationDetailsResponse.class);
        BrokerCoreResponse brokerCoreResponse = objectMapper.readValue(getRequestBody("broker_core_response.json"),
                BrokerCoreResponse.class);
        ApplicationsRequest applicationsRequest = objectMapper.readValue(getRequestBody(
                "broker_core_response_to_applications_request.json"), ApplicationsRequest.class);
        TrackingApplicationDetailResponse trackingApplicationDetailResponse = objectMapper.readValue(getRequestBody(
                "application_tracking_detail_to_tracking_detail_response.json"),
                TrackingApplicationDetailResponse.class);

        when(crmService.getBrokerDetails(TEST_BROKER)).thenReturn(brokerCoreResponse);
        when(brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse)).thenReturn(applicationsRequest);
        when(applicationDetailsToTrackingApplicationDetailsMapper.toResponse(applicationDetailsResponse)).thenReturn(trackingApplicationDetailResponse);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationDetailsResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(applicationDetailsResponse));

        TrackingApplicationDetailResponse response = caseTrackingService.getApplication(TEST_BROKER, TEST_MRN, "nwb");
        assertEquals(1, response.getApplicants().size());
    }

    @Test
    void testGetApplicationDetailWithException() throws IOException {
        BrokerCoreResponse brokerCoreResponse = objectMapper.readValue(getRequestBody("broker_core_response.json"),
                BrokerCoreResponse.class);
        ApplicationsRequest applicationsRequest = objectMapper.readValue(getRequestBody(
                "broker_core_response_to_applications_request.json"), ApplicationsRequest.class);

        when(crmService.getBrokerDetails(TEST_BROKER)).thenReturn(brokerCoreResponse);
        when(brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse)).thenReturn(applicationsRequest);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationDetailsResponse.class))).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        ApplicationsServiceException thrown = Assertions.assertThrows(ApplicationsServiceException.class, () -> {
            caseTrackingService.getApplication(TEST_BROKER, TEST_MRN, "nwb");
        }, "Exception");

        Exception ex = ((HttpCustomException) thrown).getException();
        assertEquals("500 INTERNAL_SERVER_ERROR", ex.getMessage());
    }

    @Test
    void testGetApplicationDetailWithNotFoundException() throws IOException {
        BrokerCoreResponse brokerCoreResponse = objectMapper.readValue(getRequestBody("broker_core_response.json"),
                BrokerCoreResponse.class);
        ApplicationsRequest applicationsRequest = objectMapper.readValue(getRequestBody(
                "broker_core_response_to_applications_request.json"), ApplicationsRequest.class);

        when(crmService.getBrokerDetails(TEST_BROKER)).thenReturn(brokerCoreResponse);
        when(brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse)).thenReturn(applicationsRequest);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationDetailsResponse.class))).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        CaseTrackingResponse caseTrackingResponse = caseTrackingService.getApplicationByMortgageReference(TEST_BROKER
                , TEST_MRN, "nwb");
        assertEquals(caseTrackingResponse.getCases().size(), 0);
    }

    @Test
    void testGetApplicationByMortgageReference() throws IOException {
        ApplicationDetailsResponse applicationDetailsResponse = objectMapper.readValue(getRequestBody(
                "application_tracking_detail_response.json"), ApplicationDetailsResponse.class);
        BrokerCoreResponse brokerCoreResponse = objectMapper.readValue(getRequestBody("broker_core_response.json"),
                BrokerCoreResponse.class);
        ApplicationsRequest applicationsRequest = objectMapper.readValue(getRequestBody(
                "broker_core_response_to_applications_request.json"), ApplicationsRequest.class);
        Case applicationDetailsToCase = objectMapper.readValue(getRequestBody(
                "application_tracking_detail_to_case.json"), Case.class);

        when(crmService.getBrokerDetails(TEST_BROKER)).thenReturn(brokerCoreResponse);
        when(brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse)).thenReturn(applicationsRequest);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationDetailsResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(applicationDetailsResponse));
        when(applicationDetailsResponseToCaseMapper.toCase(applicationDetailsResponse)).thenReturn(applicationDetailsToCase);

        CaseTrackingResponse response = caseTrackingService.getApplicationByMortgageReference(TEST_BROKER, TEST_MRN,
                "nwb");
        assertEquals(1, response.getCases().size());
        assertEquals(TEST_MRN, response.getCases().get(0).getMortgageReferenceNumber());
    }

    @Test
    void testGetApplicationByMortgageReferenceWithException() throws IOException {
        BrokerCoreResponse brokerCoreResponse = objectMapper.readValue(getRequestBody("broker_core_response.json"),
                BrokerCoreResponse.class);
        ApplicationsRequest applicationsRequest = objectMapper.readValue(getRequestBody(
                "broker_core_response_to_applications_request.json"), ApplicationsRequest.class);

        when(crmService.getBrokerDetails(TEST_BROKER)).thenReturn(brokerCoreResponse);
        when(brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse)).thenReturn(applicationsRequest);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationDetailsResponse.class))).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        ApplicationsServiceException thrown = Assertions.assertThrows(ApplicationsServiceException.class, () -> {
            caseTrackingService.getApplicationByMortgageReference(TEST_BROKER, TEST_MRN, "nwb");
        }, "Exception");

        Exception ex = ((HttpCustomException) thrown).getException();
        assertEquals("500 INTERNAL_SERVER_ERROR", ex.getMessage());
    }

    @Test
    void testGetApplicationByMortgageReferenceWithNotFoundException() throws IOException {
        BrokerCoreResponse brokerCoreResponse = objectMapper.readValue(getRequestBody("broker_core_response.json"),
                BrokerCoreResponse.class);
        ApplicationsRequest applicationsRequest = objectMapper.readValue(getRequestBody(
                "broker_core_response_to_applications_request.json"), ApplicationsRequest.class);

        when(crmService.getBrokerDetails(TEST_BROKER)).thenReturn(brokerCoreResponse);
        when(brokerCoreResponseToApplicationRequestMapper.toApplicationRequest(brokerCoreResponse)).thenReturn(applicationsRequest);
        when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
                eq(ApplicationDetailsResponse.class))).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        CaseTrackingResponse caseTrackingResponse = caseTrackingService.getApplicationByMortgageReference(TEST_BROKER
                , TEST_MRN, "nwb");
        assertEquals(caseTrackingResponse.getCases().size(), 0);
    }

  @Test
  void testGetApplicationDDocuments_ok() {
    CaseTrackingDocumentResponse applicationDetailsResponse = CaseTrackingDocumentResponse.builder()
        .packagingStatus(PackagingStatus.builder().isBasicPackagingReceived(true).build()).build();

    when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
        eq(CaseTrackingDocumentResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(applicationDetailsResponse));

    CaseTrackingDocumentResponse response = caseTrackingService.getApplicationDocuments(TEST_MRN, "nwb");
    assertTrue(response.getPackagingStatus().getIsBasicPackagingReceived());
  }

  @Test
  void testGetApplicationDDocuments_ok_withPackageNotComplete() {
    CaseTrackingDocumentResponse applicationDetailsResponse = CaseTrackingDocumentResponse.builder()
        .packagingStatus(PackagingStatus.builder().isBasicPackagingReceived(false).build()).build();

    when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
        eq(CaseTrackingDocumentResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(applicationDetailsResponse));

    CaseTrackingDocumentResponse response = caseTrackingService.getApplicationDocuments(TEST_MRN, "nwb");
    assertFalse(response.getPackagingStatus().getIsBasicPackagingReceived());
  }

  @Test
  void testGetApplicationDDocuments_nullResponse_throws_IntegrationException() {

    when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
        eq(CaseTrackingDocumentResponse.class))).thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(null));

    CaseTrackingDocumentResponse response = caseTrackingService.getApplicationDocuments(TEST_MRN, "nwb");
    assertNull(response);

  }

  @Test
  void testGetApplicationDDocuments_HttpClientErrorException_throws_IntegrationException() {

    when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
        eq(CaseTrackingDocumentResponse.class))).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

    CaseTrackingDocumentResponse response = caseTrackingService.getApplicationDocuments(TEST_MRN, "nwb");
    assertNull(response);
  }

  @Test
  void testGetApplicationDDocuments_RestClientException_throws_IntegrationException() {

    when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
        eq(CaseTrackingDocumentResponse.class))).thenThrow(new RestClientException("Rest Client Exception test"));

    CaseTrackingDocumentResponse response = caseTrackingService.getApplicationDocuments(TEST_MRN, "nwb");
    assertNull(response);
  }

  @Test
  void testGetApplicationDDocuments_Exception_Throwable() {

    when(iamJwtChainSecureRestTemplate.exchange(any(), eq(HttpMethod.GET), any(),
        eq(CaseTrackingDocumentResponse.class))).thenThrow(new NullPointerException("Null pointer exception test"));

    CaseTrackingDocumentResponse response = caseTrackingService.getApplicationDocuments(TEST_MRN, "nwb");
    assertNull(response);
  }

    private String getRequestBody(String fileName) throws IOException {
        return new String(Files.readAllBytes(Paths.get("src", "test", "resources", fileName)));
    }

    private UserDetails getUserDetails() {
        return UserDetails.builder().fcaNumber(FCA_NUMBER).fullName(BROKER_FORE_NAME + BROKER_SURNAME)
                .brokerFirstName(BROKER_FORE_NAME).brokerLastName(BROKER_SURNAME).firmPostcode(FIRM_POSTCODE).brokerEmailId(BROKER_EMAIL).build();
    }
}
