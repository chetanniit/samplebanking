package com.natwest.pbbdhb.broker.dashboard.authorisation;

import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerDto;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_BROKER_USERNAME;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_CASE_ID;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AccessPermissionCheckerTest {
    @Mock
    private UserClaimsProvider mockUserClaimsProvider;

    @Mock
    private CaseService mockCaseClient;

    @InjectMocks
    private AccessPermissionChecker accessPermissionChecker;

    @Test
    void isCaseOwnerReturnsTrueWhenUsernamesMatch() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(TEST_BROKER_USERNAME);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCaseByCaseId(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertTrue(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsTrueWhenUsernamesHaveDifferentCases() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername("TestBroker1");
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCaseByCaseId(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn("testbroker1");
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertTrue(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseWhenUsernamesDiffer() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(TEST_BROKER_USERNAME);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCaseByCaseId(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn("other_broker2");
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfLoggedInUserHasNullUsername() {
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(null);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfCaseHasNoBroker() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        caseApplicationDto.setBroker(null);

        when(mockCaseClient.getCaseByCaseId(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfCaseHasBrokerWithNullUsername() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(null);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCaseByCaseId(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }
}
