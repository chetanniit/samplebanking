package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.authorisation.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.exception.DocumentDownloadException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.service.documents.impl.DocumentDownloadServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.security.GeneralSecurityException;
import java.util.Optional;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.BRAND_DEFAULT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DocumentDownloadServiceTest {

    private static final String DOCUMENT_NAME = "EsisDocument";
    private static final String FMA_DOCUMENT_NAME = "MAF-MED0123123-20032023120057667IFDMOE.pdf";

    @InjectMocks
    DocumentDownloadServiceImpl downloadService;

    private String esisEndpoint = "esisEndPoint/%s";

    private String fmaEndpoint = "fmaEndPoint";

    @Mock
    private RestTemplate restTemplate;
    @Mock
    private ResponseEntity<byte[]> response;
    @Mock
    private UserClaimsProvider userClaimsProvider;
    @Mock
    private AccessPermissionChecker accessPermissionChecker;

    @BeforeEach
    public void setUp() throws GeneralSecurityException {
        downloadService = new DocumentDownloadServiceImpl(esisEndpoint, fmaEndpoint, restTemplate, userClaimsProvider, accessPermissionChecker);
    }

    @Test
    void testGetESISDocument() {
        byte[] bytes = new byte[5];
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<byte[]>>any())).thenReturn(response);
        when(response.getBody()).thenReturn(bytes);

        Optional<byte[]> optionalResponse = downloadService.getESISDocument(DOCUMENT_NAME);

        assertEquals(optionalResponse.get(), bytes);
    }

    @Test
    void testGetFMADocument() {
        byte[] bytes = new byte[5];
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<byte[]>>any())).thenReturn(response);
        when(response.getBody()).thenReturn(bytes);
        when(accessPermissionChecker.isCaseOwner(eq(BRAND_DEFAULT), eq("MED0123123"))).thenReturn(true);

        Optional<byte[]> optionalResponse = downloadService.getFMADocument(BRAND_DEFAULT,FMA_DOCUMENT_NAME);

        assertEquals(optionalResponse.get(), bytes);
    }

    @Test
    public void throwsDocumentDownloadExceptionWhenExceptionIsThrown() {
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<byte[]>>any())).thenThrow(new RestClientException("RestClientException"));
        assertThrows(DocumentDownloadException.class, () -> downloadService.getESISDocument(DOCUMENT_NAME));
    }

    @Test
    public void throwsPermissionDeniedExceptionnWhenExceptionIsThrown() {
        when(accessPermissionChecker.isCaseOwner(eq(BRAND_DEFAULT), eq("MED0123123"))).thenReturn(false);

        assertThrows(PermissionDeniedException.class, () -> downloadService.getFMADocument(BRAND_DEFAULT, FMA_DOCUMENT_NAME));
    }
}
