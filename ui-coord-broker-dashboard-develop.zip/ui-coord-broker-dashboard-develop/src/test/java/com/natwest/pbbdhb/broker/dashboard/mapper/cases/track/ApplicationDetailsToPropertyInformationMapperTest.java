package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.AddressInfo;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ApplicationDetailsResponse;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.PropertyInfo;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.detail.response.ValuationHistoryDetail;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.PropertyInformation;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ApplicationDetailsToPropertyInformationMapperTest {

    private static final BigDecimal AMOUNT = new BigDecimal("500");
    private static final String ADDRESS_LINE_1 = "1 Address line";
    private static final String PROPERTY_TYPE = "New";
    private static final String YEAR_BUILD = "2022";
    private static final String TYPE_DESCRIPTION = "Valuation";

    @InjectMocks
    private ApplicationDetailsToPropertyInformationMapperImpl applicationDetailsToPropertyInformationMapper;

    @Mock
    private AddressMapper addressMapper;

    @Test
    public void should_map_application_details_to_property_information() {
        AddressInfo addressInfo = AddressInfo.builder().addressLine1(ADDRESS_LINE_1).build();
        com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.AddressInfo resultAddress =
                com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.AddressInfo.builder()
                        .addressLine1(ADDRESS_LINE_1).build();
        when(addressMapper.toAddress(addressInfo)).thenReturn(resultAddress);
        PropertyInfo propertyInfo = PropertyInfo.builder().address(addressInfo).build();
        ValuationHistoryDetail valuationHistoryDetail = ValuationHistoryDetail.builder()
                .typeDescription(TYPE_DESCRIPTION).build();
        List<ValuationHistoryDetail> details = Lists.newArrayList(valuationHistoryDetail);
        ValuationDetail valuationDetail = ValuationDetail.builder()
                .propertyType(PROPERTY_TYPE)
                .yearBuild(YEAR_BUILD)
                .details(details)
                .amount(AMOUNT).build();
        ApplicationDetailsResponse applicationDetailsResponse = ApplicationDetailsResponse.builder()
                .propertyInformation(propertyInfo)
                .valuationInformation(valuationDetail).build();

        PropertyInformation propertyInformation =
                applicationDetailsToPropertyInformationMapper.toPropertyInformation(applicationDetailsResponse);

        assertEquals(ADDRESS_LINE_1, propertyInformation.getAddressInfo().getAddressLine1());
        assertEquals(PROPERTY_TYPE, propertyInformation.getPropertyType());
        assertEquals(Integer.parseInt(YEAR_BUILD), propertyInformation.getYearOfBuild());
        assertEquals(TYPE_DESCRIPTION, propertyInformation.getValuationType());
        assertEquals(AMOUNT, propertyInformation.getConfirmValuationAmount());
    }

    @Test
    public void should_return_null() {
        ApplicationDetailsResponse applicationDetailsResponse = ApplicationDetailsResponse.builder()
                .build();

        PropertyInformation propertyInformation =
                applicationDetailsToPropertyInformationMapper.toPropertyInformation(applicationDetailsResponse);

        assertNull(propertyInformation.getAddressInfo());
        assertNull(propertyInformation.getPropertyType());
        assertNull(propertyInformation.getYearOfBuild());
        assertNull(propertyInformation.getValuationType());
        assertNull(propertyInformation.getConfirmValuationAmount());
    }
}