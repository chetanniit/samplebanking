package com.natwest.pbbdhb.broker.dashboard.mapper;

import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.model.cases.Broker;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus.IN_PROGRESS;
import static com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus.SUBMISSION_IN_PROGRESS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.FMA_SUBMITTED;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUBMIT_FMA_IN_PROGRESS;
import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.SUBMIT_GMS_MOPS;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class CaseToPresubmittedCaseMapperTest {

  @InjectMocks
  CaseToPreSubmittedCaseMapper caseToPreSubmittedCaseMapper;

  private static final String CASE_ID="caseId";
  private static final Broker BROKER = new Broker();

  @Test
  void should_map_fma_in_progress_not_submitted_to_gms_with_fmaSubmitted_true_to_submission_in_progress() {
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(FMA_SUBMITTED, true);

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(journeyData)
        .applicationStatus(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_fma_in_progress_not_submitted_to_gms_with_fmaSubmitted_false_to_in_progress() {
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(FMA_SUBMITTED, false);

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(journeyData)
        .applicationStatus(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }
  @Test
  void shouldMapCaseResponseToSubmittedCaseResponseWithoutApplicant() {
    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication,
        Collections.EMPTY_LIST);
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
  }
  @Test
  void should_map_fma_in_progress_not_submitted_to_gms_with_fmaSubmitted_null_to_in_progress() {

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(Collections.emptyMap())
        .applicationStatus(FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_submit_gms_mops_with_fmaSubmitted_true_to_submission_in_progress() {
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(FMA_SUBMITTED, true);

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(journeyData)
        .applicationStatus(SUBMIT_GMS_MOPS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_submit_gms_mops_with_fmaSubmitted_false_to_submission_in_progress() {
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(FMA_SUBMITTED, false);

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(journeyData)
        .applicationStatus(SUBMIT_GMS_MOPS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_submit_gms_mops_with_fmaSubmitted_null_to_submission_in_progress() {

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(Collections.emptyMap())
        .applicationStatus(SUBMIT_GMS_MOPS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_submit_fma_in_progress_with_fmaSubmitted_true_to_submission_in_progress() {
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(FMA_SUBMITTED, true);

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(journeyData)
        .applicationStatus(SUBMIT_FMA_IN_PROGRESS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_submit_fma_in_progress_with_fmaSubmitted_false_to_submission_in_progress() {
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(FMA_SUBMITTED, false);

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(journeyData)
        .applicationStatus(SUBMIT_FMA_IN_PROGRESS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

  @Test
  void should_map_submit_fma_in_progress_with_fmaSubmitted_null_to_submission_in_progress() {

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .journeyData(Collections.emptyMap())
        .applicationStatus(SUBMIT_FMA_IN_PROGRESS)
        .build();

    PreSubmittedCase preSubmittedCase = caseToPreSubmittedCaseMapper.toPreSubmittedCase(caseApplication, Collections.emptyList());

    assertEquals(SUBMISSION_IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
  }

}
