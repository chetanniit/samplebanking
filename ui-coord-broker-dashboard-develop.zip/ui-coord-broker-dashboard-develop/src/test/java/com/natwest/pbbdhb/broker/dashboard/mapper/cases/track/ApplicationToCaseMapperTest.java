package com.natwest.pbbdhb.broker.dashboard.mapper.cases.track;

import com.natwest.pbbdhb.broker.dashboard.model.applications.response.Address;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.Application;
import com.natwest.pbbdhb.broker.dashboard.model.applications.response.PropertyInformation;
import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.Case;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.xml.datatype.DatatypeFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
public class ApplicationToCaseMapperTest {

    private static final String POST_CODE = "CH5 3GA";

    @InjectMocks
    private ApplicationToCaseMapperImpl applicationToCaseMapper;

    @Mock
    private ApplicantInformationToUiApplicantInformationMapper applicantInformationToUiApplicantInformationMapper;
    @Mock
    private DatatypeFactory datatypeFactory;

    @Test
    public void should_map_postcode() {
        Address address = Address.builder().postCode(POST_CODE).build();
        PropertyInformation propertyInformation = PropertyInformation.builder().address(address).build();
        Application application = Application.builder().propertyInformation(propertyInformation).build();

        Case aCase = applicationToCaseMapper.toCase(application);

        assertEquals(POST_CODE, aCase.getPostcode());
    }

    @Test
    public void should_return_null_when_application_is_null() {
        Application application = null;

        Case aCase = applicationToCaseMapper.toCase(application);

        assertNull(aCase);
    }

    @Test
    public void should_map_postcode_as_null_when_address_is_null() {
        Address address = null;
        PropertyInformation propertyInformation = PropertyInformation.builder().address(address).build();
        Application application = Application.builder().propertyInformation(propertyInformation).build();

        Case aCase = applicationToCaseMapper.toCase(application);

        assertNull(aCase.getPostcode());
    }

    @Test
    public void should_map_postcode_as_null_when_property_information_is_null() {
        PropertyInformation propertyInformation = null;
        Application application = Application.builder().propertyInformation(propertyInformation).build();

        Case aCase = applicationToCaseMapper.toCase(application);

        assertNull(aCase.getPostcode());
    }
}