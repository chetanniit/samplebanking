package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.ApplicantSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.service.impl.ApplicantServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.buildDefaultApplicant;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public class ApplicantServiceTest {

    private static final String APPLICANT_SEARCH_URL = "https://test/v2/applicants/search";
    private static final String APPLICANT_GET_URL = "https://test/v2/applicants/case/";

    @InjectMocks
    ApplicantServiceImpl applicantService;

    @Mock
    private RestTemplate iamJwtChainSecureRestTemplate;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(applicantService, "applicantsSearchUrl", APPLICANT_SEARCH_URL);
        ReflectionTestUtils.setField(applicantService, "applicantsGetUrl", APPLICANT_GET_URL);
    }

    @Test
    void testGetApplicants() {
        Set<String> caseSet = new HashSet<>(Arrays.asList(TEST_CASE_ID));
        ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();
        applicantSearchResponse.setContent(Arrays.asList(Applicant.builder().caseId(TEST_CASE_ID).build()));

        when(iamJwtChainSecureRestTemplate.postForObject(eq(APPLICANT_SEARCH_URL), any(),
                eq(ApplicantSearchResponse.class), anyMap())).thenReturn(applicantSearchResponse);

        List<Applicant> response = applicantService.getApplicants( caseSet,  "nwb");
        assertEquals(1, response.size());
    }

    @Test
    void testGetEmptyApplicants() {
        Set<String> caseSet = new HashSet<>(Arrays.asList(TEST_CASE_ID));
        ApplicantSearchResponse applicantSearchResponse = new ApplicantSearchResponse();

        when(iamJwtChainSecureRestTemplate.postForObject(eq(APPLICANT_SEARCH_URL), any(),
                eq(ApplicantSearchResponse.class), anyMap())).thenReturn(applicantSearchResponse);

        ApplicantNotFoundException thrown = Assertions
                .assertThrows(ApplicantNotFoundException.class, () -> {
                    applicantService.getApplicants( caseSet,  "nwb");
                }, "Exception - Applicant not found");
        assertEquals("Exception - Applicant not found", thrown.getMessage());
    }

    @Test
    void testGetApplicantsWithException() {
        Set<String> caseSet = new HashSet<>(Arrays.asList(TEST_CASE_ID));

        when(iamJwtChainSecureRestTemplate.postForObject(eq(APPLICANT_SEARCH_URL), any(),
                eq(ApplicantSearchResponse.class), anyMap())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));

        ApplicantServiceException thrown = Assertions
                .assertThrows(ApplicantServiceException.class, () -> {
                    applicantService.getApplicants( caseSet,  "nwb");
                }, "400 BAD_REQUEST");
        Exception ex = ((ApplicantServiceException) thrown).getException();
        assertEquals("400 BAD_REQUEST", ex.getMessage());
    }

    @Test
    void testGetApplicantsWithNotFoundException() {
        Set<String> caseSet = new HashSet<>(Arrays.asList(TEST_CASE_ID));

        when(iamJwtChainSecureRestTemplate.postForObject(eq(APPLICANT_SEARCH_URL), any(),
                eq(ApplicantSearchResponse.class), anyMap())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        ApplicantNotFoundException thrown = Assertions
                .assertThrows(ApplicantNotFoundException.class, () -> {
                    applicantService.getApplicants( caseSet,  "nwb");
                }, "Exception - Applicant not found");

        assertEquals("Exception - Applicant not found", thrown.getMessage());
    }

  @Test
  void testGetApplicantsWithCaseId_ok() {
      Applicant applicant = buildDefaultApplicant();
      List<Applicant> applicantList = new ArrayList<>();
      applicantList.add(applicant);
      ResponseEntity<List<Applicant>> expectedResponseEntity = ResponseEntity.ok(applicantList);
      URI uri = UriComponentsBuilder.fromUriString(APPLICANT_GET_URL).build(TEST_CASE_ID);
      when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
           any(), (ParameterizedTypeReference<List<Applicant>>) any())).thenReturn(expectedResponseEntity);

    List<Applicant> response = applicantService.getApplicants( "nwb", TEST_CASE_ID);
    assertEquals(1, response.size());
    Applicant applicantResponse = response.get(0);
    assertEquals(applicant.getApplicantId(), applicantResponse.getApplicantId());
    assertEquals(applicant.getMainApplicant(), applicantResponse.getMainApplicant());
    assertEquals(applicant.getPersonalDetails().getTitle(), applicantResponse.getPersonalDetails().getTitle());
    assertEquals(applicant.getPersonalDetails().getFirstNames(), applicantResponse.getPersonalDetails().getFirstNames());
    assertEquals(applicant.getPersonalDetails().getLastName(), applicantResponse.getPersonalDetails().getLastName());
    assertEquals(applicant.getPersonalDetails().getDateOfBirth(), applicantResponse.getPersonalDetails().getDateOfBirth());
    assertEquals(applicant.getCaseId(), applicantResponse.getCaseId());
  }

  @Test
  void testGetApplicantsWithCaseId_NotFoundException_throws_IntegrationException() {

    URI uri = UriComponentsBuilder.fromUriString(APPLICANT_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), (ParameterizedTypeReference<List<Applicant>>) any())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

    IntegrationException thrown = Assertions
        .assertThrows(IntegrationException.class, () -> {
          applicantService.getApplicants( TEST_CASE_ID,  "nwb");
        }, "404 NOT_FOUND");

    assertEquals("404 NOT_FOUND", thrown.getMessage());
  }

  @Test
  void testGetApplicantsWithCaseId_RestClientException_throws_IntegrationException() {

    URI uri = UriComponentsBuilder.fromUriString(APPLICANT_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), (ParameterizedTypeReference<List<Applicant>>) any())).thenThrow(new RestClientException("rest exception test"));

    IntegrationException thrown = Assertions
        .assertThrows(IntegrationException.class, () -> {
          applicantService.getApplicants( TEST_CASE_ID,  "nwb");
        }, "rest exception test");

    assertEquals("rest exception test", thrown.getMessage());
  }

  @Test
  void testGetApplicantsWithCaseId_Exception_Throwable() {

    URI uri = UriComponentsBuilder.fromUriString(APPLICANT_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), (ParameterizedTypeReference<List<Applicant>>) any())).thenThrow(new NullPointerException("Null pointer exception test"));

    NullPointerException thrown = Assertions
        .assertThrows(NullPointerException.class, () -> {
          applicantService.getApplicants( TEST_CASE_ID,  "nwb");
        }, "Null pointer exception test");

    assertEquals("Null pointer exception test", thrown.getMessage());
  }

}
