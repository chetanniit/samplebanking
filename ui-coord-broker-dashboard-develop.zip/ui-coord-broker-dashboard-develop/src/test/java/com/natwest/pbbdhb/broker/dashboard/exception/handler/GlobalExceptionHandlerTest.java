package com.natwest.pbbdhb.broker.dashboard.exception.handler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantServiceException;
import com.natwest.pbbdhb.broker.dashboard.exception.UIErrorResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class GlobalExceptionHandlerTest {

    @InjectMocks
    @Spy
    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private ObjectMapper objectMapper;

    @Test
    void badApplicantServiceExceptionHandling() throws JsonProcessingException {
        HttpClientErrorException httpClientErrorException =
                new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
        ApplicantServiceException applicantServiceException = new ApplicantServiceException(httpClientErrorException);
        UIErrorResponse mockedUIErrorResponse = UIErrorResponse.builder().build();
        when(objectMapper.readValue("", UIErrorResponse.class)).thenReturn(mockedUIErrorResponse);

        ResponseEntity<UIErrorResponse> responseResponseEntity =
                globalExceptionHandler.handleCustomException(applicantServiceException);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseResponseEntity.getStatusCode());
        ArgumentCaptor<HttpStatusCodeException> exceptionType = ArgumentCaptor.forClass(HttpStatusCodeException.class);
        verify(globalExceptionHandler).buildErrorResponse(exceptionType.capture());
        assertInstanceOf(HttpClientErrorException.class, exceptionType.getValue());
    }
}