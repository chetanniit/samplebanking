package com.natwest.pbbdhb.broker.dashboard.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationType;
import java.util.Collections;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus.IN_PROGRESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
@ComponentScan("com.natwest.pbbdhb.broker.dashboard.config.broker")
public class BrokerCaseControllerTest extends WireMockIntegrationTest {

  private static final String CASE_ID = "ID20230329140023905042";
  private static final String FILE_NAME = "11110901";
  private static final String FIRST_NAME = "James";
  private static final String POST_CODE = "A12 1AA";

  @Autowired
  private MockMvc mockMvc;

  @Autowired
  private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    super.setUp();
  }

  @AfterEach
  void tearDown() {
    super.tearDown();
  }

  @Test
  void shouldGetCases() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCase();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByFMAInProgress() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByFMAInProgress();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases?type=FMA&status=In+Progress").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByFMASubmissionInProgress() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByFMASubmissionInProgress();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(
                get("/broker/cases?type=FMA&status=Submission+In+Progress").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByFMACompleted() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByFMACompleted();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases?type=FMA&status=Completed").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByAIPInProgress() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByAIPInProgress();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases?type=AIP&status=In+Progress").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByAIPSubmissionInProgress() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByAIPSubmissionInProgress();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(
                get("/broker/cases?type=AIP&status=Submission+In+Progress").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByAIPSubmissionCompleted() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByAIPCompleted();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases?type=AIP&status=Completed").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByESISInProgress() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByESISInProgress();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases?type=ESIS&status=In+Progress").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByESISSubmissionInProgress() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByESISSubmissionInProgress();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(
                get("/broker/cases?type=ESIS&status=Submission+In+Progress").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByESISCompleted() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseFilteredByESISCompleted();
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get("/broker/cases?type=ESIS&status=Completed").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByLastName() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseWithCaseIds(Collections.singletonList("ID20230329140023905042"));
    stubGetApplicantsByLastName("Bond");

    MvcResult result =
        mockMvc.perform(get("/broker/cases?lastName=Bond").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByLastNameAndDob() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseWithCaseIds(Collections.singletonList("ID20230329140023905042"));
    stubGetApplicantsByLastNameAndDob("Bond", "1985-01-05");

    MvcResult result =
        mockMvc.perform(
                get("/broker/cases?lastName=Bond&dateOfBirth=1985-01-05").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }

  @Test
  void shouldGetCasesFilteredByLastNameAndPostcode() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCaseWithCaseIds(Collections.singletonList("ID20230329140023905042"));
    stubGetApplicantsByLastNameAndPostcode("Bond", "A12 1AA");

    MvcResult result =
        mockMvc.perform(get("/broker/cases?lastName=Bond&postcode=A12+1AA").header("brand", "nwb"))
            .andExpect(status().isOk()).andReturn();

    PreSubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        PreSubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getPreSubmittedCases());
    assertEquals(1, response.getPreSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    PreSubmittedCase preSubmittedCase = response.getPreSubmittedCases().get(0);
    assertEquals(ApplicationType.FMA, preSubmittedCase.getType());
    assertEquals(IN_PROGRESS.getLabel(), preSubmittedCase.getApplicationStatus());
    assertEquals(CASE_ID, preSubmittedCase.getCaseId());
    assertEquals(FILE_NAME, preSubmittedCase.getEsis().getFileName());
    assertEquals(FIRST_NAME, preSubmittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(POST_CODE, preSubmittedCase.getApplicants().get(0).getPostcode());
  }
}
