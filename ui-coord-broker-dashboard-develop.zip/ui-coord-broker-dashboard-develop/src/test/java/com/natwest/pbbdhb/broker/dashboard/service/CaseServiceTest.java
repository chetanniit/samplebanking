package com.natwest.pbbdhb.broker.dashboard.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.dashboard.dto.CaseApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.PageApplicationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.PreSubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import com.natwest.pbbdhb.broker.dashboard.exception.ApplicantNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.AssociatedBrokerNotFoundException;
import com.natwest.pbbdhb.broker.dashboard.exception.IntegrationException;
import com.natwest.pbbdhb.broker.dashboard.mapper.CaseToPreSubmittedCaseMapper;
import com.natwest.pbbdhb.broker.dashboard.mapper.CaseToSubmittedCaseMapper;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonAddress;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;
import com.natwest.pbbdhb.broker.dashboard.model.cases.paymentstatus.Fee;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationStatus;
import com.natwest.pbbdhb.broker.dashboard.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.impl.CaseServiceImpl;
import java.net.URI;
import java.time.LocalDate;
import java.time.Month;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.TEST_MORTGAGE_REFERENCE_NUMBER;
import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.buildDefaultCaseApplication;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@Profile("test")
@ExtendWith(SpringExtension.class)
public class CaseServiceTest {

  private static final String CASE_URL = "https://test/v2/cases/search";
  private static final String CASE_GET_URL = "https://test/v2/cases/{caseId}";
  private static final String QUERY_STRING = "?page=0&size=1";
  private static final String CASE_ID = "ID20221201071011831152";
  private static final String TEST_BROKER_USERNAME = "AshHughes07";
  private static final String TEST_BROKER_USERNAME_ASSOCIATE = "AshHughes07_associate";
  private static final String TEST_FCA_NUMBER = "123456";

  @InjectMocks
  CaseServiceImpl caseService;

  @Mock
  private ObjectMapper objectMapper;

  @Mock
  private RestTemplate iamJwtChainSecureRestTemplate;

  @Mock
  private CaseToPreSubmittedCaseMapper caseToPreSubmittedCasesMapper;

  @Mock
  private ApplicantService applicantService;

  @Mock
  private CaseToSubmittedCaseMapper caseToSubmittedCasesMapper;

  @Mock
  private UserClaimsProvider userClaimsProvider;

  @Mock
  private BrokerAccessService brokerAccessService;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(caseService, "caseServiceSearchUrl", CASE_URL);
    ReflectionTestUtils.setField(caseService, "caseServiceGetUrl", CASE_GET_URL);
    objectMapper = new ObjectMapper();
  }

  @Test
  void testGetPreSubmittedCasesNoFilter() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, null, null);
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeFmaStatusSubmissionInProgress() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.FMA.name(),
        ApplicationStatus.SUBMISSION_IN_PROGRESS.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeFmaStatusInProgress() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.FMA.name(), ApplicationStatus.IN_PROGRESS.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeFmaStatusCompleted() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.FMA.name(), ApplicationStatus.COMPLETED.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeAipStatusSubmissionInProgress() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.AIP.name(),
        ApplicationStatus.SUBMISSION_IN_PROGRESS.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeAipStatusInProgress() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.AIP.name(), ApplicationStatus.IN_PROGRESS.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeAipStatusCompleted() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.AIP.name(), ApplicationStatus.COMPLETED.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeEsisStatusSubmissionInProgress() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.ESIS.name(),
        ApplicationStatus.SUBMISSION_IN_PROGRESS.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeEsisStatusInProgress() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.ESIS.name(), ApplicationStatus.IN_PROGRESS.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterTypeEsisStatusCompleted() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, ApplicationType.ESIS.name(), ApplicationStatus.COMPLETED.getLabel());

    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterByLastName() throws IOException {
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder().caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder().firstNames("James").lastName("Bond").build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(
        Arrays.asList(ApplicantDto.builder().firstNames("James").lastName("Bond").build()));

    when(applicantService.getApplicants("Bond", null, null, "nwb")).thenReturn(
        Arrays.asList(applicant));
    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        "Bond", null, null, null, null);
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterByPostcode() throws IOException {
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .addresses(Collections.singletonList(PersonAddress.builder()
            .postcode("EC4Y 8AD")
            .build()))
        .personalDetails(PersonDetails
            .builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(
        ApplicantDto.builder().firstNames("James").lastName("Bond").postcode("EC4Y 8AD").build()));

    when(applicantService.getApplicants(null, "EC4Y 8AD", null, "nwb")).thenReturn(
        Arrays.asList(applicant));
    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, "EC4Y 8AD", null, null, null);
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals("EC4Y 8AD",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getPostcode());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesFilterByDateOfBirth() throws IOException {
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .addresses(Collections.singletonList(PersonAddress.builder()
            .postcode("EC4Y 8AD")
            .build()))
        .personalDetails(PersonDetails
            .builder()
            .firstNames("James")
            .lastName("Bond")
            .dateOfBirth(LocalDate.of(1980, Month.APRIL, 15))
            .build())
        .build();
    PreSubmittedCase preSubmittedCase = new PreSubmittedCase();
    preSubmittedCase.setCaseId("ID20221201071011831152");
    preSubmittedCase.setApplicants(Arrays.asList(
        ApplicantDto.builder().firstNames("James").lastName("Bond")
            .dateOfBirth(LocalDate.of(1980, Month.APRIL, 15)).build()));

    when(applicantService.getApplicants(null, null, "1980-04-15", "nwb")).thenReturn(
        Arrays.asList(applicant));
    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToPreSubmittedCasesMapper.toPreSubmittedCase(any(), any())).thenReturn(
        preSubmittedCase);

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, "1980-04-15", null, null);
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals("1980-04-15",
        response.getPreSubmittedCases().get(0).getApplicants().get(0).getDateOfBirth().toString());
    assertEquals(CASE_ID, response.getPreSubmittedCases().get(0).getCaseId());
  }

  @Test
  void testGetPreSubmittedCasesWithEmptyApplicants() throws IOException {

    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList());

    PreSubmittedCases response = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, null, null);
    assertEquals(1, response.getSize());
    assertEquals(null, response.getPreSubmittedCases());
  }

  @Test
  void testGetEmptyPreSubmittedCases() throws IOException {

    PageApplicationDto pageApplicationDto = objectMapper.readValue(
        getRequestBody("case_search_empty_response.json"), PageApplicationDto.class);

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    PreSubmittedCases preSubmittedCases = caseService.getPreSubmittedCases("brokerUsername", TEST_FCA_NUMBER, "nwb",
        "0", "1", null, null, null, null, null);
    Assertions.assertEquals(preSubmittedCases.getPreSubmittedCases(), Collections.EMPTY_LIST);

  }

  @Test
  void testGetCaseByCaseId_ok() {

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(false);
    ResponseEntity expectedResponseEntity = ResponseEntity.ok(caseApplicationDto);
    URI uri = UriComponentsBuilder.fromUriString(CASE_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), eq(CaseApplicationDto.class))).thenReturn(expectedResponseEntity);

    CaseApplicationDto caseApplicationResponse = caseService.getCaseByCaseId(TEST_CASE_ID, "nwb");
    assertEquals(caseApplicationDto.getMafDocumentUrl(), caseApplicationResponse.getMafDocumentUrl());
    assertEquals(caseApplicationDto.getMortgageReferenceNumber(), caseApplicationResponse.getMortgageReferenceNumber());
    assertNull(caseApplicationResponse.getMortgageTempReferenceNumber());
    List<SalesIllustrationDto> salesIllustrationExpected = caseApplicationDto.getSalesIllustrations();
    List<SalesIllustrationDto> salesIllustrationActual = caseApplicationResponse.getSalesIllustrations();
    SalesIllustrationDto salesIllustrationExpected1 = salesIllustrationExpected.get(0);
    SalesIllustrationDto salesIllustrationExpected2 = salesIllustrationExpected.get(1);
    SalesIllustrationDto salesIllustrationActual1 = salesIllustrationActual.get(0);
    SalesIllustrationDto salesIllustrationActual2 = salesIllustrationActual.get(1);
    assertEquals(salesIllustrationExpected1.getIsAccepted(), salesIllustrationActual1.getIsAccepted());
    assertEquals(salesIllustrationExpected2.getIsAccepted(), salesIllustrationActual2.getIsAccepted());
    List<Fee> feeExpected1 = salesIllustrationExpected1.getProducts().get(0).getFees();
    List<Fee>  feeActual1 = salesIllustrationActual1.getProducts().get(0).getFees();
    List<Fee> feeExpected2 = salesIllustrationExpected2.getProducts().get(0).getFees();
    List<Fee>  feeActual2 = salesIllustrationActual2.getProducts().get(0).getFees();
    assertFeesAreEquals(feeExpected1.get(0), feeActual1.get(0));
    assertFeesAreEquals(feeExpected1.get(1), feeActual1.get(1));
    assertFeesAreEquals(feeExpected2.get(0), feeActual2.get(0));
  }

  @Test
  void testGetCaseByCaseId_ok_with_temp_mortgageRefNumber() {

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(false);
    caseApplicationDto.setMortgageReferenceNumber(null);
    caseApplicationDto.setMortgageTempReferenceNumber(TEST_MORTGAGE_REFERENCE_NUMBER);
    ResponseEntity expectedResponseEntity = ResponseEntity.ok(caseApplicationDto);
    URI uri = UriComponentsBuilder.fromUriString(CASE_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), eq(CaseApplicationDto.class))).thenReturn(expectedResponseEntity);

    CaseApplicationDto caseApplicationResponse = caseService.getCaseByCaseId(TEST_CASE_ID, "nwb");
    assertEquals(caseApplicationDto.getMafDocumentUrl(), caseApplicationResponse.getMafDocumentUrl());
    assertEquals(caseApplicationDto.getMortgageTempReferenceNumber(), caseApplicationResponse.getMortgageTempReferenceNumber());
    assertNull(caseApplicationResponse.getMortgageReferenceNumber());

  }

  @Test
  void testGetCaseByCaseId_no_morgageRefNumbers_throws_IntegrationException() {

    CaseApplicationDto caseApplicationDto = buildDefaultCaseApplication(false);
    caseApplicationDto.setMortgageReferenceNumber(null);
    ResponseEntity expectedResponseEntity = ResponseEntity.ok(caseApplicationDto);
    URI uri = UriComponentsBuilder.fromUriString(CASE_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), eq(CaseApplicationDto.class))).thenReturn(expectedResponseEntity);

    assertThatThrownBy(() -> caseService.getCaseByCaseId(TEST_CASE_ID, "nwb"))
        .isInstanceOf(IntegrationException.class)
        .message().isEqualTo("getCaseByCaseId: Case returned with null mortgageReferenceNumber and mortgageTempReferenceNumber");

  }

  @Test
  void testGetCaseByCaseId_no_case_found_throws_IntegrationException() {
    ResponseEntity expectedResponseEntity = ResponseEntity.ok(null);
    URI uri = UriComponentsBuilder.fromUriString(CASE_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), eq(CaseApplicationDto.class))).thenReturn(expectedResponseEntity);

    assertThatThrownBy(() -> caseService.getCaseByCaseId(TEST_CASE_ID, "nwb"))
        .isInstanceOf(IntegrationException.class)
        .message().isEqualTo("getCaseByCaseId: No case record returned");
  }

  @Test
  void testGetCaseByCaseId_RestClientException_throws_IntegrationException() {
    ResponseEntity expectedResponseEntity = ResponseEntity.ok(null);
    URI uri = UriComponentsBuilder.fromUriString(CASE_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), eq(CaseApplicationDto.class))).thenThrow(new RestClientException("Rest Client Exception test"));


    IntegrationException thrown = Assertions
        .assertThrows(IntegrationException.class, () -> {
          caseService.getCaseByCaseId(TEST_CASE_ID, "nwb");
        }, "Rest Client Exception test");

    assertEquals("Rest Client Exception test", thrown.getMessage());
  }

  @Test
  void testGetCaseByCaseId_Exception_Throwable() {
    ResponseEntity expectedResponseEntity = ResponseEntity.ok(null);
    URI uri = UriComponentsBuilder.fromUriString(CASE_GET_URL).build(TEST_CASE_ID);
    when(iamJwtChainSecureRestTemplate.exchange(eq(uri), any(),
        any(), eq(CaseApplicationDto.class))).thenThrow(new NullPointerException("Null pointer exception test"));

    NullPointerException thrown = Assertions
        .assertThrows(NullPointerException.class, () -> {
          caseService.getCaseByCaseId(TEST_CASE_ID, "nwb");
        }, "Null pointer exception test");

    assertEquals("Null pointer exception test", thrown.getMessage());
  }

  private void assertFeesAreEquals(Fee feeExpected, Fee feeActual) {
    assertEquals(feeExpected.getType(), feeActual.getType());
    assertEquals(feeExpected.getFeeAmount(), feeActual.getFeeAmount());
    assertEquals(feeExpected.getFeeAction(), feeActual.getFeeAction());
    assertEquals(feeExpected.getFeeCode(), feeActual.getFeeCode());
    assertEquals(feeExpected.getFeePaymentType(), feeActual.getFeePaymentType());
    assertEquals(feeExpected.getIsPaymentMade(), feeActual.getIsPaymentMade());
    assertEquals(feeExpected.getOrderId(), feeActual.getOrderId());
    assertEquals(feeExpected.getPaidDate(), feeActual.getPaidDate());
  }

  private String getRequestBody(String fileName) throws IOException {
    return new String(Files.readAllBytes(Paths.get("src", "test", "resources", fileName)));
  }

  @Test
  void testGetSubmittedCasesWithNoFilterAndSameBroker() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    SubmittedCase submittedCase = new SubmittedCase();
    submittedCase.setCaseId("ID20221201071011831152");
    submittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToSubmittedCasesMapper.toSubmittedCase(any(), any())).thenReturn(
        submittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);
    SubmittedCases response = caseService.getSubmittedCases(TEST_BROKER_USERNAME, TEST_FCA_NUMBER, "nwb", "0", "1",
         null, null, null, null);
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getSubmittedCases().get(0).getCaseId());
    assertEquals(60, response.getTotalElements());
  }

  @Test
  void testGetSubmittedCasesWithFilterAndSameBroker() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    SubmittedCase submittedCase = new SubmittedCase();
    submittedCase.setMortgageReferenceNumber("1234");
    submittedCase.setCaseId("ID20221201071011831152");
    submittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToSubmittedCasesMapper.toSubmittedCase(any(), any())).thenReturn(
        submittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));
    when(applicantService.getApplicants("Bond","Test_Post","2002/02/02","nwb")).thenReturn(Arrays.asList(applicant));
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);

    SubmittedCases response = caseService.getSubmittedCases(TEST_BROKER_USERNAME, TEST_FCA_NUMBER, "nwb", "0", "1",
        "12345", "Bond", "Test_Post", "2002/02/02");
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getSubmittedCases().get(0).getCaseId());
    assertEquals("1234", response.getSubmittedCases().get(0).getMortgageReferenceNumber());
    assertEquals(12253, response.getTotalElements());
  }

  @Test
  void testGetSubmittedCasesNoFilterWithAdminAndAssociateBroker() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));
    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);
    Applicant applicant = Applicant.builder()
        .caseId(CASE_ID)
        .applicantId("638853755d4732762f142a29")
        .personalDetails(PersonDetails.builder()
            .firstNames("James")
            .lastName("Bond")
            .build())
        .build();
    SubmittedCase submittedCase = new SubmittedCase();
    submittedCase.setMortgageReferenceNumber("1234");
    submittedCase.setCaseId("ID20221201071011831152");
    submittedCase.setApplicants(Arrays.asList(ApplicantDto.builder()
        .firstNames("James")
        .lastName("Bond")
        .build()));

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));
    when(caseToSubmittedCasesMapper.toSubmittedCase(any(), any())).thenReturn(
        submittedCase);
    when(applicantService.getApplicants(caseSet, "nwb")).thenReturn(Arrays.asList(applicant));
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME_ASSOCIATE)).thenReturn(true);

    SubmittedCases response = caseService.getSubmittedCases(TEST_BROKER_USERNAME_ASSOCIATE, TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, null);
    assertEquals(1, response.getSize());
    assertEquals("James",
        response.getSubmittedCases().get(0).getApplicants().get(0).getFirstNames());
    assertEquals("Bond",
        response.getSubmittedCases().get(0).getApplicants().get(0).getLastName());
    assertEquals(CASE_ID, response.getSubmittedCases().get(0).getCaseId());
    assertEquals("1234", response.getSubmittedCases().get(0).getMortgageReferenceNumber());
    assertEquals(60, response.getTotalElements());
  }

  @Test
  void testSubmittedCasesGivesEmptyResponseWithFilter() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));

    when(applicantService.getApplicants("Bond","Test_Post",
        "2002/02/02","nwb")).thenThrow(new ApplicantNotFoundException("Exception - Applicant not found"));
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);

    SubmittedCases response = caseService.getSubmittedCases(TEST_BROKER_USERNAME, TEST_FCA_NUMBER, "nwb", "0", "1",
        "12345", "Bond", "Test_Post", "2002/02/02");

    assertEquals(0, response.getSize());
    assertEquals(0, response.getSize());
    assertEquals(0, response.getSize());
    assertEquals(0, response.getTotalElements());
  }

  @Test
  void testSubmittedCasesGivesEmptyResponseWithNoFilter() throws IOException {
    Set<String> caseSet = new HashSet<>(Arrays.asList(CASE_ID));

    PageApplicationDto pageApplicationDto = objectMapper
        .readValue(getRequestBody("case_search_response.json"), PageApplicationDto.class);

    when(iamJwtChainSecureRestTemplate.exchange(eq(CASE_URL + QUERY_STRING), eq(HttpMethod.POST),
        any(),
        eq(PageApplicationDto.class))).thenReturn(
        ResponseEntity.status(HttpStatus.OK.value()).body(pageApplicationDto));

    when(applicantService.getApplicants(caseSet, "nwb")).
        thenThrow(new ApplicantNotFoundException("Exception - Applicant not found"));
    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(true);

    SubmittedCases response = caseService.getSubmittedCases(TEST_BROKER_USERNAME, TEST_FCA_NUMBER, "nwb", "0", "1",
        null, null, null, null);
    assertEquals(0, response.getSize());
    assertEquals(0, response.getTotalElements());
  }

  @Test
  void testGetSubmittedCases_whenBrokerDoesNotHaveAcces_ThrowsException() throws IOException {

    when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);
    when(userClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
    when(brokerAccessService.checkRequestedBrokerHasAccess(TEST_BROKER_USERNAME)).thenReturn(false);

    AssociatedBrokerNotFoundException error = Assertions
        .assertThrows(AssociatedBrokerNotFoundException.class, () -> { caseService.getSubmittedCases("UnAssociatedBroker", TEST_FCA_NUMBER, "nwb", "0", "1",
            null, null, null, null);}, "Associated Brokers not found");

  }

}
