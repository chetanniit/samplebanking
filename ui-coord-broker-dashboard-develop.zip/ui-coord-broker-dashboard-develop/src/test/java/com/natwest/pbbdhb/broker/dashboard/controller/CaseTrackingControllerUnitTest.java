package com.natwest.pbbdhb.broker.dashboard.controller;

import com.natwest.pbbdhb.broker.dashboard.controller.impl.CaseTrackingController;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.broker.dashboard.service.CaseService;
import com.natwest.pbbdhb.broker.dashboard.service.CaseTrackingService;
import com.natwest.pbbdhb.broker.dashboard.service.DocumentsUploadService;
import com.natwest.pbbdhb.broker.dashboard.service.PaymentService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CaseTrackingController.class)
public class CaseTrackingControllerUnitTest {
    private static final String MORTGAGE_REF_NUMBER = "MRN12345";
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DocumentsUploadService documentsUploadService;

    @MockBean
    private CaseTrackingService caseTrackingService;

    @MockBean
    private CaseService caseService;

    @MockBean
    private PaymentService paymentService;

    @Test
    public void getDocumentUploadPage_SuccessResponse() throws Exception {

        when(documentsUploadService.getDocumentsUploadURL(eq(MORTGAGE_REF_NUMBER), eq("nwb"))).thenReturn(DocumentsUploadURLResponse.builder().documentUploadURL("/Document").build());

        RequestBuilder request = get("/documents/MRN12345").header("brand", "nwb");

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));

        verify(documentsUploadService, times(1)).getDocumentsUploadURL(eq(MORTGAGE_REF_NUMBER), eq("nwb"));
    }

    @Test
    public void getDocumentUploadPage_PermissionDeniedException() throws Exception {

        when(documentsUploadService.getDocumentsUploadURL(eq(MORTGAGE_REF_NUMBER), eq("nwb"))).thenThrow(new PermissionDeniedException(MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION));

        RequestBuilder request = get("/documents/MRN12345").header("brand", "nwb");

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(containsString(MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION)));

        verify(documentsUploadService, times(1)).getDocumentsUploadURL(eq(MORTGAGE_REF_NUMBER), eq("nwb"));
    }
}
