package com.natwest.pbbdhb.broker.dashboard.service;

import static com.natwest.pbbdhb.broker.dashboard.util.ApplicationConstants.MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.dashboard.authorisation.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.broker.dashboard.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.cases.Broker;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseSearchResponse;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.impl.DocumentsUploadServiceImpl;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
public class DocumentUploadServiceTest {

    private static final String DOCUMENT_URL = "documentUrl?access_token=%s";
    private static final String stubUsername = "hello23";
    private static final String SESSION_TOKEN = "token";
    private static final String CASE_ID="caseId";

    @InjectMocks
    DocumentsUploadServiceImpl documentsUploadService;
    @Mock
    private CaseService caseService;
    @Mock
    private ApplicantService applicantService;
    @Mock
    private BrokerAuthTokenService brokerAuthTokenService;
    @Mock
    private UserClaimsProvider userClaimsProvider;
    @Mock
    private AccessPermissionChecker accessPermissionChecker;

    @Mock
    private BrokerAccessService brokerAccessService;

    private CaseApplication  mockCaseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(Broker.builder().brokerUsername(stubUsername).build())
        .build();

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(documentsUploadService, "documentUploadURL", DOCUMENT_URL);
    }

    @Test
    void testGetDocumentsUploadURL(){
        Applicant applicant = Applicant.builder().applicantId("123").build();
        when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
        when(accessPermissionChecker.isCaseOwner(eq("nwb"),eq(CASE_ID))).thenReturn(true);
        when(userClaimsProvider.getBrokerUsername()).thenReturn(stubUsername);
        when(caseService.getCaseSearchByMortgageRefNumber("MRN","nwb"))
                .thenReturn(CaseSearchResponse.builder().content(Arrays.asList(mockCaseApplication)).build());
        when(brokerAccessService.checkRequestedBrokerHasAccess(any())).thenReturn(true);
        when(brokerAuthTokenService.getSessionAuthToken(CASE_ID, "MRN",
                stubUsername, applicant, "nwb")).thenReturn(SESSION_TOKEN);
        when(applicantService.getApplicants(Collections.singleton(CASE_ID), "nwb")).thenReturn(Arrays.asList(applicant));
        DocumentsUploadURLResponse response = documentsUploadService.getDocumentsUploadURL("MRN","nwb");
        assertEquals("documentUrl?access_token=token", response.getDocumentUploadURL());
    }

    @Test
    void testGetDocumentsUploadURLWithException(){
        Applicant applicant = Applicant.builder().applicantId("123").build();
        when(accessPermissionChecker.isCaseOwner(eq("nwb"),eq(CASE_ID))).thenReturn(true);
        when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
        when(userClaimsProvider.getBrokerUsername()).thenReturn(stubUsername);
        MRNValidateFailureException thrown = Assertions.assertThrows(MRNValidateFailureException.class, () ->
            documentsUploadService.getDocumentsUploadURL("MRN","nwb"));
        assertEquals("getCaseId: Invalid mortgageRefNumber: MRN", thrown.getMessage());
    }

    @Test
    void testGetDocumentsUploadURLWithPermissionDeniedException() {
        Applicant applicant = Applicant.builder().applicantId("123").build();
        when(accessPermissionChecker.isCaseOwner(eq("nwb"), eq(CASE_ID))).thenReturn(false);
        when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
        when(userClaimsProvider.getBrokerUsername()).thenReturn(stubUsername);
        when(caseService.getCaseSearchByMortgageRefNumber("MRN","nwb"))
            .thenReturn(CaseSearchResponse.builder().content(Arrays.asList(mockCaseApplication)).build());
        when(brokerAccessService.checkRequestedBrokerHasAccess(any())).thenReturn(false);
        PermissionDeniedException thrown = Assertions.assertThrows(PermissionDeniedException.class,
            () -> documentsUploadService.getDocumentsUploadURL("MRN", "nwb"));
        assertEquals(MSG_NO_DOCUMENT_UPLOAD_URL_PERMISSION, thrown.getMessage());
    }
}
