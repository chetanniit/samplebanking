package com.natwest.pbbdhb.broker.dashboard.json;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;


@SpringBootTest
@ActiveProfiles("test")
public class StringDeserializerTest {

    @Autowired
    private ObjectMapper objectMapper;


    @Test
    void testDeserialize() throws IOException {
        String json = "{\"brokerFirstName\":\"    Space  Name  \"}";

        UserDetails userDetails = objectMapper.readValue(json, UserDetails.class);

        assertEquals("Space  Name", userDetails.getBrokerFirstName());
        assertNull(userDetails.getBrokerLastName());

    }


}
