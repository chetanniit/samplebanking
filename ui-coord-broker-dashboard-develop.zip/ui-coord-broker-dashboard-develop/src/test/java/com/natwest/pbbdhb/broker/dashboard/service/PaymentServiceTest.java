package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.exception.FeePaymentIntegrationException;
import com.natwest.pbbdhb.broker.dashboard.exception.HttpCustomException;
import com.natwest.pbbdhb.broker.dashboard.model.tiles.PaymentUrlResponse;
import com.natwest.pbbdhb.broker.dashboard.service.impl.PaymentServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public class PaymentServiceTest {
    private String WORLDPAY_URL = "worldpayurl";

    @InjectMocks
    PaymentServiceImpl paymentService;

    @Mock
    private RestTemplate iamJwtChainSecureRestTemplate;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(paymentService, "worldpayUrl", WORLDPAY_URL);
    }

    @Test
    void testGetFeePaymentPage(){
        when(iamJwtChainSecureRestTemplate.postForEntity(eq(WORLDPAY_URL), any(), eq(PaymentUrlResponse.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.OK.value()).body(PaymentUrlResponse.builder().paymentUrl("url").build()));
        PaymentUrlResponse response = paymentService.getFeePaymentPage("MRN", "nwb");
        assertEquals("url", response.getPaymentUrl());
    }

    @Test
    void testGetFeePaymentPageWithException(){
        when(iamJwtChainSecureRestTemplate.postForEntity(eq(WORLDPAY_URL), any(), eq(PaymentUrlResponse.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        FeePaymentIntegrationException thrown = Assertions.assertThrows(FeePaymentIntegrationException.class, () -> {
            paymentService.getFeePaymentPage("MRN", "nwb");
        }, "Exception");

        Exception ex = ((HttpCustomException) thrown).getException();
        assertEquals("404 NOT_FOUND", ex.getMessage());
    }

}
