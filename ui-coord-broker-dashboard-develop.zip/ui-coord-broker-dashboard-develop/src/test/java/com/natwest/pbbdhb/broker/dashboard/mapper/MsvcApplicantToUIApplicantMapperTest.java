package com.natwest.pbbdhb.broker.dashboard.mapper;



import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;

import com.natwest.pbbdhb.broker.dashboard.model.applications.ui.response.UiApplicant;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.natwest.pbbdhb.broker.dashboard.util.TestUtil.buildDefaultApplicant;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class MsvcApplicantToUIApplicantMapperTest {

    @InjectMocks
    private MsvcApplicantToUiApplicantMapperImpl msvcApplicantToUiApplicantMapper;


    @Test
    void should_map_to_UiApplicant() {
        Applicant applicant = buildDefaultApplicant();
        PersonDetails personDetails = applicant.getPersonalDetails();
      UiApplicant uiApplicant = msvcApplicantToUiApplicantMapper.toUiApplicant(applicant);
      assertEquals(applicant.getMainApplicant(), uiApplicant.getIsMainApplicant());
      assertEquals(personDetails.getFirstNames() + " " + personDetails.getLastName(),
          uiApplicant.getName());
      assertEquals(personDetails.getTitle(), uiApplicant.getTitle());
    }

  @Test
  void should_map_to_UiApplicant_with_null_fields() {
    Applicant applicant = buildDefaultApplicant();
    applicant.setPersonalDetails(null);

    UiApplicant uiApplicant = msvcApplicantToUiApplicantMapper.toUiApplicant(applicant);
    assertEquals(applicant.getMainApplicant(), uiApplicant.getIsMainApplicant());
    assertEquals(null, uiApplicant.getName());
    assertEquals(null, uiApplicant.getTitle());

  }

}