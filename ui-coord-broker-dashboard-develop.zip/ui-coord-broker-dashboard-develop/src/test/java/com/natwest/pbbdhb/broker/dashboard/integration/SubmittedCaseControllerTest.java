package com.natwest.pbbdhb.broker.dashboard.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCases;
import java.io.IOException;
import java.time.LocalDate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
@ComponentScan("com.natwest.pbbdhb.broker.dashboard.config.broker")
public class SubmittedCaseControllerTest extends WireMockIntegrationTest{

  private static final String CASE_ID = "ID20230329140023905042";
  private static final String BROKER_USERNAME = "AshHughes07";
  private static final String LAST_NAME = "Bond";
  private static final String POST_CODE = "A12 1AA";
  private static final String SUBMITTED_CASE_URL = "/broker/submitted-cases";
  private static final String BRAND_PARAM = "brand";
  private static final String BRAND_VALUE = "nwb";
  private static final String TEST_BROKER_USERNAME_PARAM = "brokerUsername";

  @Autowired
  private MockMvc mockMvc;

  @Autowired
  private ObjectMapper objectMapper;

  @Mock
  private UserClaimsProvider userClaimsProvider;

  @BeforeEach
  void setUp() throws IOException {
    super.setUp();
  }

  @AfterEach
  void tearDown() {
    super.tearDown();
  }

  @Test
  void shouldGetCasesByMortgageReferenceNumber() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCasesWithCriteria(CRITERIA_MORTGAGE_REFERENCE_NUMBER, true);
    stubGetApplicants(CASE_ID);

    MvcResult result =
        mockMvc.perform(get(SUBMITTED_CASE_URL)
                .queryParam(TEST_BROKER_USERNAME_PARAM,BROKER_USERNAME)
                .queryParam("mortgageReferenceNumber","31664716")
                .header(BRAND_PARAM, BRAND_VALUE))
            .andExpect(status().isOk()).andReturn();

    SubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        SubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getSubmittedCases());
    assertEquals(1, response.getSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    SubmittedCase submittedCase = response.getSubmittedCases().get(0);
    assertEquals(CASE_ID, submittedCase.getCaseId());
  }

  @Test
  void shouldGetCasesByApplicantLastName() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCasesWithCriteria("", true);
    stubGetApplicantsByLastName("Bond");

    MvcResult result =
        mockMvc.perform(get(SUBMITTED_CASE_URL)
                .queryParam(TEST_BROKER_USERNAME_PARAM,BROKER_USERNAME)
                .queryParam("lastName","Bond")
                .header(BRAND_PARAM, BRAND_VALUE))
            .andExpect(status().isOk()).andReturn();

    SubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        SubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getSubmittedCases());
    assertEquals(1, response.getSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    SubmittedCase submittedCase = response.getSubmittedCases().get(0);
    assertEquals(CASE_ID, submittedCase.getCaseId());
    assertEquals(LAST_NAME, submittedCase.getApplicants().get(0).getLastName());

  }

  @Test
  void shouldGetCasesFilteredByLastNameAndDob() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCasesWithCriteria("", true);
    stubGetApplicantsByLastNameAndDob("Bond", "1985-01-05");

    MvcResult result =
        mockMvc.perform(
                     get(SUBMITTED_CASE_URL).queryParam(TEST_BROKER_USERNAME_PARAM,BROKER_USERNAME)
                    .queryParam("lastName","Bond")
                    .queryParam("dateOfBirth","1985-01-05")
                         .header(BRAND_PARAM, BRAND_VALUE))
            .andExpect(status().isOk()).andReturn();

    SubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        SubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getSubmittedCases());
    assertEquals(1, response.getSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    SubmittedCase submittedCase = response.getSubmittedCases().get(0);
    assertEquals(CASE_ID, submittedCase.getCaseId());
    assertEquals(POST_CODE, submittedCase.getApplicants().get(0).getPostcode());
    assertEquals(LocalDate.of(1985, 01, 05), submittedCase.getApplicants().get(0).getDateOfBirth());
  }

  @Test
  void shouldGetCasesFilteredByLastNameAndDobAndMortgageReferenceNumber() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCasesWithCriteria(CRITERIA_MORTGAGE_CASEID, true);
    stubGetApplicantsByLastNameAndDob("Bond", "1985-01-05");

    MvcResult result =
        mockMvc.perform(
                get(SUBMITTED_CASE_URL).queryParam(TEST_BROKER_USERNAME_PARAM,BROKER_USERNAME)
                    .queryParam("lastName","Bond")
                    .queryParam("dateOfBirth","1985-01-05")
                    .queryParam("mortgageReferenceNumber","31664716")
                    .header(BRAND_PARAM, BRAND_VALUE))
            .andExpect(status().isOk()).andReturn();

    SubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        SubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getSubmittedCases());
    assertEquals(1, response.getSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    SubmittedCase submittedCase = response.getSubmittedCases().get(0);
    assertEquals(CASE_ID, submittedCase.getCaseId());
    assertEquals(LAST_NAME, submittedCase.getApplicants().get(0).getLastName());
    assertEquals("31664716", submittedCase.getMortgageReferenceNumber());
    assertEquals(LocalDate.of(1985, 01, 05), submittedCase.getApplicants().get(0).getDateOfBirth());
  }

  @Test
  void shouldGetCasesFilteredByLastNameAndPostcode() throws Exception {
    stubBrokerDetailsForValidBrokerEndpoint("AshHughes07");
    stubGetCasesWithCriteria("", true);
    stubGetApplicantsByLastNameAndPostcode("Bond", "A12 1AA");

    MvcResult result =
        mockMvc.perform(
                get(SUBMITTED_CASE_URL).queryParam(TEST_BROKER_USERNAME_PARAM,BROKER_USERNAME)
                    .queryParam("lastName","Bond")
                    .queryParam("postcode","A12+1AA")
                    .header(BRAND_PARAM, BRAND_VALUE))
            .andExpect(status().isOk()).andReturn();

    SubmittedCases response = objectMapper.readValue(result.getResponse().getContentAsString(),
        SubmittedCases.class);

    assertEquals(0, response.getNumber());
    assertNotNull(response.getSubmittedCases());
    assertEquals(1, response.getSubmittedCases().size());
    assertEquals(1, response.getTotalPages());
    assertEquals(1, response.getTotalElements());
    assertEquals(0, response.getNumber());
    SubmittedCase submittedCase = response.getSubmittedCases().get(0);
    assertEquals(CASE_ID, submittedCase.getCaseId());
    assertEquals(LAST_NAME, submittedCase.getApplicants().get(0).getLastName());
    assertEquals("31664716", submittedCase.getMortgageReferenceNumber());
    assertEquals("A12 1AA", submittedCase.getApplicants().get(0).getPostcode());
    assertEquals(LocalDate.of(1985, 01, 05), submittedCase.getApplicants().get(0).getDateOfBirth());
  }

}
