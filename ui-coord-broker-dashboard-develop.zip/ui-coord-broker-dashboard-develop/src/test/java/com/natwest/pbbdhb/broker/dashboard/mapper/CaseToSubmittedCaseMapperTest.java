package com.natwest.pbbdhb.broker.dashboard.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import com.natwest.pbbdhb.broker.dashboard.dto.SubmittedCase;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.Applicant;
import com.natwest.pbbdhb.broker.dashboard.model.applicant.PersonDetails;
import com.natwest.pbbdhb.broker.dashboard.model.cases.Broker;
import com.natwest.pbbdhb.broker.dashboard.model.cases.CaseApplication;
import java.time.LocalDate;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CaseToSubmittedCaseMapperTest {

  @InjectMocks
  CaseToSubmittedCaseMapper caseToSubmittedCaseMapper;

  private static final String CASE_ID = "caseId";
  private static final String APPLICANT_ID = "applicantId";
  private static final String MORTGAGE_REF_NUMBER = "mortgageRefNumber";
  private static final String TEST_FIRST_NAME= "firstName";
  private static final String TEST_LAST_NAME= "lastName";
  private static final LocalDate TEST_DOB= LocalDate.of(2000,01,01);
  private static final Broker BROKER = new Broker();

  @Test
  void shouldMapCaseResponseToSubmittedCaseResponse() {

    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .mortgageReferenceNumber(MORTGAGE_REF_NUMBER)
        .build();
    PersonDetails personDetails = PersonDetails.builder()
        .firstNames(TEST_FIRST_NAME)
        .lastName(TEST_LAST_NAME)
        .dateOfBirth(TEST_DOB)
        .build();
    Applicant applicant = Applicant.builder()
        .applicantId(APPLICANT_ID)
        .caseId(CASE_ID)
        .personalDetails(personDetails)
        .build();

    SubmittedCase submittedCase = caseToSubmittedCaseMapper.toSubmittedCase(caseApplication,
        Collections.singletonList(applicant));

    assertEquals(CASE_ID, submittedCase.getCaseId());
    assertEquals(TEST_FIRST_NAME, submittedCase.getApplicants().get(0).getFirstNames());
    assertEquals(TEST_LAST_NAME, submittedCase.getApplicants().get(0).getLastName());
    assertEquals(MORTGAGE_REF_NUMBER, submittedCase.getMortgageReferenceNumber());
    assertEquals(TEST_DOB, submittedCase.getApplicants().get(0).getDateOfBirth());
  }
  @Test
  void shouldMapCaseResponseToSubmittedCaseResponseWithoutApplicant() {
    CaseApplication caseApplication = CaseApplication.builder()
        .caseId(CASE_ID)
        .broker(BROKER)
        .mortgageReferenceNumber(MORTGAGE_REF_NUMBER)
        .build();

    SubmittedCase submittedCase = caseToSubmittedCaseMapper.toSubmittedCase(caseApplication,
        Collections.EMPTY_LIST);

    assertEquals(CASE_ID, submittedCase.getCaseId());
    assertEquals(MORTGAGE_REF_NUMBER, submittedCase.getMortgageReferenceNumber());

  }

}
