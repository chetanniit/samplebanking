package com.natwest.pbbdhb.broker.dashboard.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeParseException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DateSerializerTest {

    DateSerializer.Deserialize deserialize;
    DateSerializer.Serialize serialize;
    JsonParser parser;
    DeserializationContext context;
    @Mock
    JsonGenerator gen;
    @Mock
    SerializerProvider serializers;

    @BeforeEach
    void setup() {
        deserialize = new DateSerializer.Deserialize();
        serialize = new DateSerializer.Serialize();
        parser = mock(JsonParser.class);
        context = mock(DeserializationContext.class);
    }

    @Test
    void testDeserialize() throws IOException {
        when(parser.getText()).thenReturn("2021-04-27T13:18+00:00");

        ZonedDateTime result = deserialize.deserialize(parser, context);

        assertEquals(result.getDayOfYear(), 117);
        assertEquals(result.getMonthValue(), 04);
        assertEquals(result.getDayOfMonth(), 27);
    }

    @Test
    void testDeserializeShouldReturnNull() throws IOException {
        when(parser.getText()).thenReturn(null);

        ZonedDateTime result = deserialize.deserialize(parser, context);

        assertNull(result);
    }

    @Test
    void testSerialize() throws IOException {
        ZonedDateTime zonedDateTime = ZonedDateTime.of(2023, 03, 25, 01, 01, 20, 10, ZoneId.of("UTC"));

        serialize.serialize(zonedDateTime, gen, serializers);

        verify(gen).writeString("2023-03-25T01:01+00:00");
    }
}