package com.natwest.pbbdhb.broker.dashboard.service;

import com.natwest.pbbdhb.broker.dashboard.authorisation.UserClaimsProvider;
import com.natwest.pbbdhb.broker.dashboard.model.UserDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.BrokerDetails;
import com.natwest.pbbdhb.broker.dashboard.model.crm.broker.FirmDetails;
import com.natwest.pbbdhb.broker.dashboard.model.user.enums.BrokerType;
import com.natwest.pbbdhb.broker.dashboard.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public class UserServiceTest {

    private static final String stubUsername = "hello23";
    private static final String stubBrokerId = "596840542";
    private static final String FCA_NUMBER = "fcaNumber";
    private static final String FIRM_POSTCODE = "firmPostcode";
    private static final String BROKER_SURNAME = "brokerSurname";
    private static final String BROKER_FORE_NAME = "brokerForeName";
    private static final String BROKER_POSTCODE = "brokerPostcode";
    private static final String BROKER_EMAIL = "brokerEmail";
    private static final String FIRM_NAME = "firmName";
    private static final String BROKER_MIDDLE_NAME = "brokerMiddleName";
    private static final String FIRM_ADDRESS_COUNTRY = "firmAddressCountry";
    private static final String FIRM_ADDRESS_COUNTY = "firmAddressCounty";
    private static final String FIRM_ADDRESS_CITY = "firmAddressCity";
    private static final String FIRM_ADDRESS_LINE_3 = "firmAddressLine3";
    private static final String FIRM_ADDRESS_LINE_2 = "firmAddressLine2";
    private static final String FIRM_ADDRESS_LINE_1 = "firmAddressLine1";
    private static final String BROKER_PHONE_NUMBER = "brokerPhoneNumber";
    private static final String BROKER_MOBILE_NUMBER = "brokerMobileNumber";
    private static final String BROKER_TITLE = "brokerTitle";

    @InjectMocks
    UserServiceImpl userService;

    @Mock
    private UserClaimsProvider userClaimsProvider;

    @Mock
    private CrmService crmService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(userService, "checkForUserPrincipal", true);
    }

    @Test
    void getUserDetails() {
        when(userClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);
        when(userClaimsProvider.getBrokerUsername()).thenReturn(stubUsername);
        when(crmService.getBrokerDetails(any())).thenReturn(getBroker());
        UserDetails userDetails = userService.getDetails();
        assertEquals(stubUsername, userDetails.getUserName());
        assertEquals(BROKER_FORE_NAME + " " + BROKER_SURNAME, userDetails.getFullName());
        assertEquals(FCA_NUMBER, userDetails.getFcaNumber());
        assertEquals(FIRM_POSTCODE, userDetails.getFirmPostcode());
        assertEquals(BROKER_FORE_NAME, userDetails.getBrokerFirstName());
        assertEquals(BROKER_SURNAME, userDetails.getBrokerLastName());
        assertEquals(BROKER_EMAIL, userDetails.getBrokerEmailId());
        assertEquals(BROKER_POSTCODE, userDetails.getBrokerPostcode());
    }

    @Test
    void getCheckForUserPrincipal() {
        assertEquals(true, userService.getCheckForUserPrincipal());
    }

    private BrokerCoreResponse getBroker() {
        BrokerDetails brokerDetails = new BrokerDetails();
        brokerDetails.setBrokerID(stubBrokerId);
        brokerDetails.setTitle(BROKER_TITLE);
        brokerDetails.setUserName(stubUsername);
        brokerDetails.setFirstName(BROKER_FORE_NAME);
        brokerDetails.setLastName(BROKER_SURNAME);
        brokerDetails.setMiddleName(BROKER_MIDDLE_NAME);
        brokerDetails.setBusinessPhone(BROKER_PHONE_NUMBER);
        brokerDetails.setEmailAddress(BROKER_EMAIL);
        brokerDetails.setMobileNumber(BROKER_MOBILE_NUMBER);
        brokerDetails.setBrokerPostcode(BROKER_POSTCODE);

        FirmDetails firmDetails = new FirmDetails();
        firmDetails.setFirmAddressLine1(FIRM_ADDRESS_LINE_1);
        firmDetails.setFirmAddressLine2(FIRM_ADDRESS_LINE_2);
        firmDetails.setFirmAddressLine3(FIRM_ADDRESS_LINE_3);
        firmDetails.setFirmAddressCity(FIRM_ADDRESS_CITY);
        firmDetails.setFirmAddressCounty(FIRM_ADDRESS_COUNTY);
        firmDetails.setFirmAddressCountry(FIRM_ADDRESS_COUNTRY);
        firmDetails.setFirmAddressPostcode(FIRM_POSTCODE);
        firmDetails.setFcaNumber(FCA_NUMBER);
        firmDetails.setFirmName(FIRM_NAME);
        firmDetails.setPrincipleFCANumber(FCA_NUMBER);

        BrokerCoreResponse brokerCoreResponse = new BrokerCoreResponse();
        brokerCoreResponse.setBroker(brokerDetails);
        brokerCoreResponse.setFirmDetails(firmDetails);

        return brokerCoreResponse;
    }
}
