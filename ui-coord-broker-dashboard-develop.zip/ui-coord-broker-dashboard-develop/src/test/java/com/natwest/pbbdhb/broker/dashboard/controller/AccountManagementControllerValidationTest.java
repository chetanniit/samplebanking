package com.natwest.pbbdhb.broker.dashboard.controller;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.dashboard.controller.impl.AccountManagementController;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerPasswordRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.BrokerQuestionsResponse;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.ChangeSecurityQuestionsRequest;
import com.natwest.pbbdhb.broker.dashboard.dto.broker.SecurityQuestion;
import com.natwest.pbbdhb.broker.dashboard.service.AuthService;
import com.natwest.pbbdhb.broker.dashboard.service.UserService;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

@WebMvcTest(AccountManagementController.class)
public class AccountManagementControllerValidationTest {

  public static final String USERNAME = "username";
  public static final String CURRENT_PASSWORD = "oldPass";
  public static final String NEW_PASSWORD = "newPass";
  @MockBean
  private AuthService authService;
  @MockBean
  private UserService userService;

  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private ObjectMapper objectMapper;

  @Test
  public void shouldChangePassword() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .currentPassword(CURRENT_PASSWORD)
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request)
        .andExpect(status().isNoContent());

    verify(authService, times(1)).updateBrokerUserPassword(USERNAME, CURRENT_PASSWORD,
        NEW_PASSWORD);
  }

  @Test
  public void shouldChangePasswordFailedInvalidInput400() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    RequestBuilder request = post("/account-management/password-change")
        .contentType("application/json")
        .content(new ObjectMapper().writeValueAsString(BrokerPasswordRequest.builder()
            .newPassword(NEW_PASSWORD)
            .build()));

    this.mockMvc.perform(request).andExpect(status().isBadRequest());

  }

  @Test
  public void shouldGetSecurityQuestions() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);
    BrokerQuestionsResponse response = BrokerQuestionsResponse.builder()
        .securityQuestions(Collections.singletonList("TEST"))
        .build();
    when(authService.getSecurityQuestions(USERNAME)).thenReturn(response);

    RequestBuilder request = get("/account-management/security-questions");

    this.mockMvc.perform(request)
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON));

    verify(authService, times(1)).getSecurityQuestions(any());
  }

  @Test
  public void shouldChangeSecurityQuestions() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .securityQuestions(Collections.singletonList(SecurityQuestion.builder()
            .question("TEST")
            .answer("TEST")
            .build()))
        .build();
    doNothing().when(authService).changeSecurityQuestions(any(), any());

    this.mockMvc.perform(put("/account-management/security-questions")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(authService, times(1)).changeSecurityQuestions(any(), any());
  }

  @Test
  public void shouldChangeSecurityQuestionsInvalidInputFailed400() throws Exception {
    when(userService.getBrokerUsername()).thenReturn(USERNAME);

    ChangeSecurityQuestionsRequest request = ChangeSecurityQuestionsRequest.builder()
        .build();

    this.mockMvc.perform(put("/account-management/security-questions")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest());

  }
}
