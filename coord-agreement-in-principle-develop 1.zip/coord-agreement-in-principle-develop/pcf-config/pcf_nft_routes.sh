dws pcf operation create route --pcfenv dev-pnf --channel hboapiplatform --space nft --domainname nft-api.natwest.com --hostname coord-agreement-in-principle-v1-mortgages --domain dynamic --path mortgages/v1/coord-agreement-in-principle
dws pcf operation map route --pcfenv dev-pnf --channel hboapiplatform --space nft --appname v1-coord-agreement-in-principle --domainname nft-api.natwest.com --hostname coord-agreement-in-principle-v1-mortgages --domain dynamic --path mortgages/v1/coord-agreement-in-principle

