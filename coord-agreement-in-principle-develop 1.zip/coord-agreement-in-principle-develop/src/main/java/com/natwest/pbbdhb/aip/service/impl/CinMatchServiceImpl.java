package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.Applicant;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.cin.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.model.enums.Client;
import com.natwest.pbbdhb.aip.model.mapper.CustomerSearchMapper;
import com.natwest.pbbdhb.aip.service.CinMatchService;
import com.natwest.pbbdhb.aip.utils.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static org.apache.commons.lang.StringUtils.isBlank;

@Service
@Slf4j
public class CinMatchServiceImpl implements CinMatchService {

    private static final String SINGLE_MATCH_VERIFIED = "SINGLE-MATCH-VERIFIED";

    @Autowired
    private CustomerSearchMapper customerSearchMapper;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${cin.search.endpoint}")
    private String cinSearchURL;


    @Override
    public List<CinResponse> cinSearch(final Application aipRequest, final String brand, final Client client) {

        List<CinResponse> cinResponses = aipRequest.getApplicants().stream()
                .filter(applicant -> isBlank(applicant.getCin()))
                .map(applicant -> applicantCinSearch(applicant, brand, aipRequest.getLenderCaseId(), client))
                .collect(Collectors.toList());

        return cinResponses;
    }

    private CinResponse applicantCinSearch(final Applicant applicant, final String brand, final String lenderCaseId, final Client client) {
        log.info("Case id : {}, cinSearch called", lenderCaseId);
        HttpHeaders headers = AppUtil.applicationHeaders(brand);
        CustomerSearchRequest request = customerSearchMapper.toCustomerSearchRequest(applicant, client.toString(), lenderCaseId);

        try {
            ResponseEntity<CinResponse> responseEntity = restTemplate.postForEntity(
                    cinSearchURL, new HttpEntity(request, headers), CinResponse.class);

            CinResponse cinResponse = responseEntity.getBody();

            if (Objects.nonNull(cinResponse) && cinResponse.getCin().size() == 1
                    && SINGLE_MATCH_VERIFIED.equalsIgnoreCase(cinResponse.getCinMatchIndicator())) {
                applicant.setCin(cinResponse.getCin().get(0));
                cinResponse.setApplicant(applicant);
                log.info("Case id : {}, cinSearch completed with cin found", lenderCaseId);

                return cinResponse;
            }
        } catch (Exception e) {
            log.error("Case id : {}, Exception occurred in CIN search : {}", lenderCaseId, e.getMessage());
        }

        log.info("Case id : {}, cinSearch completed", lenderCaseId);
        return CinResponse.builder().cin(Collections.emptyList()).applicant(applicant).build();
    }

}
