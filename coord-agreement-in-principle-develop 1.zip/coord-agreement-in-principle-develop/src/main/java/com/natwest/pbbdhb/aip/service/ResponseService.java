package com.natwest.pbbdhb.aip.service;

import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponseGenerationRequest;
import jakarta.validation.Valid;

public interface ResponseService {

    AipResponse generateAipResponse(@Valid ScoringResponseGenerationRequest request, String brand);

}
