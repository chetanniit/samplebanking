package com.natwest.pbbdhb.aip.model.enums;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@Schema(description = "OccupyStatus Object")
public enum OccupyStatus {

    LODGING("L", "Lodging"),
    OWNER("O", "Owner"),
    LIVING_WITH_PARENTS("P", "Living With Parents"),
    RENTING("T", "Renting"),
    OTHER("X", "Other"),
    TIED_ACCOMMODATION("Z", "Tied Accommodation"),
    FRIENDS("F", "Friends"),
    TENANT("E", "Tenant");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }

}
