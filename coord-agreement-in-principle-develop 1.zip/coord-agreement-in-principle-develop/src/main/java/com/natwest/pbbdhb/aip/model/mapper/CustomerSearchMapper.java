package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.Address;
import com.natwest.pbbdhb.aip.model.Applicant;
import com.natwest.pbbdhb.aip.model.cin.CustomerSearchRequest;
import org.apache.commons.lang.BooleanUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(config = MappingConfig.class)
public interface CustomerSearchMapper {
    CustomerSearchMapper INSTANCE = Mappers.getMapper(CustomerSearchMapper.class);

    @Mapping(target = "firstName", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "birthDate", source = "applicant.personalDetails.dateOfBirth", dateFormat = "yyyy-MM-dd")
    @Mapping(target = "postCode", source = "applicant.addresses", qualifiedByName = "getPostCode")
    @Mapping(target = "ukAddress", source = "applicant.addresses", qualifiedByName = "getUkAddress")
    @Mapping(target = "sourceId", constant = "AIP")
    @Mapping(target = "channel", source = "client")
    @Mapping(target = "referenceId", source = "lenderCaseId")
    CustomerSearchRequest toCustomerSearchRequest(Applicant applicant, String client, String lenderCaseId);

    @Named("getPostCode")
    static String getPostCode(List<Address> addresses) {

        return addresses.stream().filter(address -> BooleanUtils.isTrue(address.getIsCurrentAddress()))
                .findFirst()
                .map(Address::getPostcode)
                .orElse(null);
    }

    @Named("getUkAddress")
    static Boolean getUkAddress(List<Address> addresses) {

        return addresses.stream()
                .filter(address -> BooleanUtils.isTrue(address.getIsCurrentAddress()))
                .findFirst()
                .map(Address::getUkAddress)
                .orElse(false);
    }
}
