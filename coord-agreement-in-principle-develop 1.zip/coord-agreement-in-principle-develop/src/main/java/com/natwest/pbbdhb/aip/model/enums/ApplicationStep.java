package com.natwest.pbbdhb.aip.model.enums;


public enum ApplicationStep {
    SCORE, EKYC
}
