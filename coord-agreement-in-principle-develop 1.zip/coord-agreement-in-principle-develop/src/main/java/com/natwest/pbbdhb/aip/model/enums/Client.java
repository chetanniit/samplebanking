package com.natwest.pbbdhb.aip.model.enums;


import lombok.AllArgsConstructor;

import java.util.stream.Stream;

@AllArgsConstructor
public enum Client {

    FOCUS,
    CP,
    ME;

    public static Stream<Client> stream() {
        return Stream.of(Client.values());
    }

}
