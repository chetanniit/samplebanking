package com.natwest.pbbdhb.aip.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import org.springframework.http.HttpStatus;

import java.util.List;

public interface StateService {

    HttpStatus captureApplication(String brand, Application application) throws JsonProcessingException;

    HttpStatus updateApplication(String brand, Application aipRequest, CompositeAipResponse aipResponse, ScoringResponse scoringResponse) throws JsonProcessingException;

    HttpStatus captureApplicationState(String brand, Application application, ScoringResponse scoringResponse) throws JsonProcessingException;

    HttpStatus captureApplicationState(String brand, Application application, List<CinResponse> applicantsCinResponse)  throws JsonProcessingException;

    String getDecisionUniqueId(String brand, String lenderCaseId, ApplicationStage applicationStage);
}
