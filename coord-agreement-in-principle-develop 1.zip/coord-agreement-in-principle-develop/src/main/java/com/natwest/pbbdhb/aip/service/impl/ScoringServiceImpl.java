package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.service.ScoringService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;


@Service
@Slf4j
public class ScoringServiceImpl implements ScoringService {
    @Value("${es.scoring.endpoint}")
    private String scoringEndPoint;

    @Autowired
    @Qualifier("restTemplateForTykApi")
    private RestTemplate restTemplate;

    @Autowired
    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Override
    public ScoringResponse scoringCheck(@Valid Application scoreRequest) {
        log.info("Case id : {}-A4, scoreCheck called", scoreRequest.getLenderCaseId());

        restTemplate.getMessageConverters().add(0, mappingJackson2HttpMessageConverter);
        defaultAttributesBeforeSendingToScore(scoreRequest);
        ScoringResponse scoringResponse = restTemplate.postForObject(scoringEndPoint, scoreRequest, ScoringResponse.class);

        log.info("Case id : {}-A5, scoreCheck completed", scoreRequest.getLenderCaseId());
        return scoringResponse;
    }

    private void defaultAttributesBeforeSendingToScore(Application scoreRequest) {

        if (nonNull(scoreRequest.getMortgage())) {

            Integer mortgageTerm = scoreRequest.getMortgage().getMortgageTerm();
            Integer interestOnlyTermYears = scoreRequest.getMortgage().getInterestOnlyTermYears();

            if (nonNull(mortgageTerm) && mortgageTerm.intValue() > 0 && isNull(scoreRequest.getMortgage().getMortgageTermMonths())) {
                scoreRequest.getMortgage().setMortgageTermMonths(0);
            }

            if (nonNull(interestOnlyTermYears) && interestOnlyTermYears.intValue() > 0 && isNull(scoreRequest.getMortgage().getInterestOnlyTermMonths())) {
                scoreRequest.getMortgage().setInterestOnlyTermMonths(0);
            }
        }
    }
}
