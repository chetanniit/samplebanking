package com.natwest.pbbdhb.aip.model.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum DataFeed {

    FOCUS("F", "FOCUS", "FOCUS"),

    ME("M", "Mortgage Engine","ME");

    private String key;

    private String value;

    private String campaignTrackingCode;

    @Override
    public String toString(){
        return key;
    }

}
