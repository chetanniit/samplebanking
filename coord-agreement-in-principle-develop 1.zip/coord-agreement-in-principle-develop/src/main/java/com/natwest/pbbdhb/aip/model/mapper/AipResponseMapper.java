package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(config = MappingConfig.class)
public interface AipResponseMapper {

    AipResponseMapper INSTANCE = Mappers.getMapper(AipResponseMapper.class);

    @Mapping(target = "policyMessages", source = "policies")
    AipResponse toAipResponse(ScoringResponse scoringResponse);

}
