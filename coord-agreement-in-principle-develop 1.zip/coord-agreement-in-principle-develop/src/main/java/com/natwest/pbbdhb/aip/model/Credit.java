
package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

import java.math.BigDecimal;

@Schema(description = "Credit Object")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Credit {

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema()
    private BigDecimal overdraftPostMortgage;

    @Schema(allowableValues = "true, false")
    private Boolean bankrupt;

    @Valid
    @Schema()
    @Length(max = 50, message = "allows max 50 characters")
    private String bankruptDetails;

    @Schema(allowableValues = "true, false")
    private Boolean courtProceedings;

    @Valid
    @Schema()
    @Length(max = 50, message = "allows max 50 characters")
    private String courtProceedingDetails;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema()
    private BigDecimal overdraftPreMortgage;


}
