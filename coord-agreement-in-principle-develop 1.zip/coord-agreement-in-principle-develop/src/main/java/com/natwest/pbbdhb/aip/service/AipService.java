package com.natwest.pbbdhb.aip.service;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.enums.Client;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import jakarta.validation.Valid;

import java.io.IOException;

public interface AipService {

    CompositeAipResponse processApplication(String brand, String clientId, @Valid Application application) throws IOException;

    Client validateClientIsOnBoardedAndGetClient(String clientId, String brand);

}
