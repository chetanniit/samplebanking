package com.natwest.pbbdhb.aip.annotation.validator;

import com.natwest.pbbdhb.aip.annotation.ValidAddress;
import com.natwest.pbbdhb.aip.model.Address;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static org.apache.commons.lang.StringUtils.isNotBlank;

public class AddressValidator implements ConstraintValidator<ValidAddress, Address> {

    @Override
    public boolean isValid(Address address, ConstraintValidatorContext constraintValidatorContext) {
        return isNotBlank(address.getFlat()) || isNotBlank(address.getHouseName()) || isNotBlank(address.getHouseNumber());
    }
}
