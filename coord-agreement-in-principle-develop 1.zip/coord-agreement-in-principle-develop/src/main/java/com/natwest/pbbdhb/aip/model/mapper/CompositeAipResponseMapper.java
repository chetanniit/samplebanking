package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.model.response.Scheme;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.Arrays;
import java.util.List;

import static java.util.Objects.nonNull;

@Mapper(config = MappingConfig.class)
public interface CompositeAipResponseMapper {

    CompositeAipResponseMapper INSTANCE = Mappers.getMapper(CompositeAipResponseMapper.class);

    @Mapping(target = "policies", source = "aipResponse", qualifiedByName = "extractPolicies")
    CompositeAipResponse toCompositeAipResponse(AipResponse aipResponse);

    @Named("extractPolicies")
    static List<Scheme> extractPolicies(AipResponse aipResponse) {
        return nonNull(aipResponse) ? Arrays.asList(Scheme.builder().policyMessages(aipResponse.getPolicyMessages()).build()) : null;
    }

}
