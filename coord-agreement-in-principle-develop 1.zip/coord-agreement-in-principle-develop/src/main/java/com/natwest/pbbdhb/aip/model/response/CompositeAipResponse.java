package com.natwest.pbbdhb.aip.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CompositeAipResponse {

    @Schema(example = "WY1620819268230")
    private String lenderCaseId;

    @Schema(example = "2021051200241")
    private String decisionUniqueId;

    @Schema(example = "REFER")
    private String decision;

    @Schema()
    public List<Scheme> policies;

    @Schema()
    public Packaging packaging;

}
