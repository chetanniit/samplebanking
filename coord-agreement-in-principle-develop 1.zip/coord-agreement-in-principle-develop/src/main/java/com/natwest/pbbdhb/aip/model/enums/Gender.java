package com.natwest.pbbdhb.aip.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Gender {
    MALE("M","MALE"),
    FEMALE("F","FEMALE");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }

}
