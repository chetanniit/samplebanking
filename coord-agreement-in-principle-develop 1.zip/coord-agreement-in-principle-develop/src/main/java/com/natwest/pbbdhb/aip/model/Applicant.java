package com.natwest.pbbdhb.aip.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

import java.util.List;

@Schema(description = "Applicant Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Applicant {

    @Valid
    @Schema(type = "String")
    @Length(max = 16, message = "allows max 16 characters")
    private String cin;

    @Valid
    @Schema()
    private PersonalDetails personalDetails;

    @Schema()
    @Valid
    private List<@Valid Address> addresses;

    @Schema()
    @Valid
    private BankDetails bankDetails;

    @Schema()
    @Valid
    private Credit credit;

    @Schema()
    @Valid
    private CreditCards creditCards;

    @Schema()
    @Valid
    private Employment employment;

    @Schema()
    @Valid
    private Expenditure expenditure;

    @Schema()
    @Valid
    private ExistingMortgage existingMortgage;
}
