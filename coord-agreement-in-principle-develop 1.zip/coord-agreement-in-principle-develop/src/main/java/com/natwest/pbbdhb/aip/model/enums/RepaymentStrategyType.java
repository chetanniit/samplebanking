package com.natwest.pbbdhb.aip.model.enums;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum RepaymentStrategyType {

    MAIN_RESIDENCE("A", "Main residence"),
    NOT_MAIN_RESIDENCE("B", "Not Main Residence"),
    OTHER_MORTGAGE_PROPERTY("C", "Other Mortgaged property"),
    UNENCUMBERED_MAIN_RESIDENCE("D", "Unencumbered Property, main Residence"),
    UNENCUMBERED_OTHER_TERRACED("E", "Unencumbered Property, other property"),
    STOCK_SHARES("F", "Stocks & Shares"),
    UNIT_TRUSTS("G", "Unit Trusts"),
    OEIC("H", "OEIC's"),
    ICVC("I", "ICVC"),
    PENSION("J", "Pension"),
    SAVING("K", "Saving"),
    OTHER_ASSETS("L", "Other Assets"),
    ENDOWMENT("M", "Endowment");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }

}
