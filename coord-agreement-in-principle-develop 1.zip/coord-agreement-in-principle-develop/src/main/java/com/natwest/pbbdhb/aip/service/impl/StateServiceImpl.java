package com.natwest.pbbdhb.aip.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.cin.CinKycVerification;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.cin.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.model.mapper.AipApplicationStateMapper;
import com.natwest.pbbdhb.aip.model.mapper.CinKycVerificationMapper;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.model.state.AipApplication;
import com.natwest.pbbdhb.aip.model.state.AipApplicationState;
import com.natwest.pbbdhb.aip.service.StateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.aip.utils.AppUtil.applicationHeaders;
import static com.natwest.pbbdhb.aip.utils.AppUtil.objectMapperOrganic;

@Service
@Slf4j
public class StateServiceImpl implements StateService {
    private static final String NO_CIN_FOUND = "{No CIN found for any of the applicant}";

    @Value("${create.application.endpoint}")
    private String createApplicationEndPoint;

    @Value("${update.application.endpoint}")
    private String updateApplicationEndPoint;

    @Value("${create.application.state.endpoint}")
    private String createApplicationStateEndPoint;

    @Value("${retrieve.application.endpoint}")
    private String retrieveApplicationEndPoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AipApplicationStateMapper riskAppStateMapper;

    @Autowired
    private CinKycVerificationMapper cinKycVerificationMapper;

    @Autowired
    private ObjectMapper objectMapper;


    @Override
    public HttpStatus captureApplication(String brand, Application aipRequest) throws JsonProcessingException {
        log.info("Case id : {}-A2.1, captureApplication called", aipRequest.getLenderCaseId());
        AipApplication createApplication = riskAppStateMapper.toApplicationRequest(aipRequest, getUntransformedRequest(aipRequest));
        HttpEntity<AipApplication> requestHttpEntity = new HttpEntity<>(createApplication, applicationHeaders(brand));
        return restTemplate.postForObject(createApplicationEndPoint, requestHttpEntity, HttpStatus.class);
    }

    @Override
    public HttpStatus updateApplication(String brand, Application aipRequest, CompositeAipResponse aipResponse, ScoringResponse scoringResponse) throws JsonProcessingException {
        log.info("Case id : {}-A7, updateApplication called", aipRequest.getLenderCaseId());
        aipResponse.setDecisionUniqueId(scoringResponse.getDecisionUniqueId());
        AipApplication aipApplication = AipApplication.builder()
                .decision(aipResponse.getDecision())
                .decisionUniqueId(aipResponse.getDecisionUniqueId())
                .response(objectMapper.writeValueAsString(aipResponse)).build();

        HttpEntity<AipApplication> requestHttpEntity = new HttpEntity<>(aipApplication, applicationHeaders(brand));
        return restTemplate.patchForObject(updateApplicationEndPoint, requestHttpEntity, HttpStatus.class, aipResponse.getLenderCaseId(), ApplicationStage.AIP);
    }

    @Override
    public HttpStatus captureApplicationState(String brand, Application application, ScoringResponse scoreResponse) throws JsonProcessingException {
        log.info("Case id : {}-A6, captureApplicationState called", application.getLenderCaseId());
        AipApplicationState createApplicationState = riskAppStateMapper.toApplicationStateRequest(application, scoreResponse, objectMapper.writeValueAsString(application), objectMapper.writeValueAsString(scoreResponse));
        HttpEntity<AipApplicationState> requestHttpEntity = new HttpEntity<>(createApplicationState, applicationHeaders(brand));
        return restTemplate.postForObject(createApplicationStateEndPoint, requestHttpEntity, HttpStatus.class);
    }

    @Override
    public HttpStatus captureApplicationState(String brand, Application application, List<CinResponse> applicantsCinResponse) throws JsonProcessingException {
        log.info("Case id : {}, captureApplicationState called for cin search", application.getLenderCaseId());

        List<CustomerSearchRequest> cinSearchRequest = application.getApplicants().stream()
                .map(applicant -> cinKycVerificationMapper.toCinSearchRequest(applicant))
                .collect(Collectors.toList());

        List<CinKycVerification> cinKycResponse = (!applicantsCinResponse.isEmpty() && applicantsCinResponse.stream().anyMatch(cinResponse -> !CollectionUtils.isEmpty(cinResponse.getCin()))) ? applicantsCinResponse.stream()
                .map(cinResponse -> cinKycVerificationMapper.toCinKycResponse(cinResponse.getApplicant(), cinResponse.getCin(), cinResponse.getCinMatchIndicator()))
                .collect(Collectors.toList()) : null;

        AipApplicationState createCinState = riskAppStateMapper.toCinApplicationState(application.getLenderCaseId());
        createCinState.setRequest(objectMapper.writeValueAsString(cinSearchRequest));
        createCinState.setResponse(cinKycResponse != null ? objectMapper.writeValueAsString(cinKycResponse) : NO_CIN_FOUND);

        HttpEntity<AipApplicationState> requestHttpEntity = new HttpEntity<>(createCinState, applicationHeaders(brand));

        return restTemplate.postForObject(createApplicationStateEndPoint, requestHttpEntity, HttpStatus.class);
    }

    private String getUntransformedRequest(Application aipRequest) throws JsonProcessingException {
        return objectMapperOrganic.writeValueAsString(aipRequest);
    }

    @Override
    public String getDecisionUniqueId(String brand, String lenderCaseId, ApplicationStage applicationStage) {

        AipApplication riskApplication = restTemplate.exchange(retrieveApplicationEndPoint, HttpMethod.GET,
                new HttpEntity(applicationHeaders(brand)), AipApplication.class, applicationStage, lenderCaseId).getBody();

        return riskApplication != null ? riskApplication.getDecisionUniqueId() : null;
    }
}
