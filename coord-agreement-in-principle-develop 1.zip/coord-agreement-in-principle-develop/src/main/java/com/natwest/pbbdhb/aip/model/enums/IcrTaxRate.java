package com.natwest.pbbdhb.aip.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum IcrTaxRate {

    ICR_HIGH("H", "ICR high tax rate"),
    ICR_LOW("L", "ICR low tax rate");

    private final String key;

    private final String value;

    @Override
    public String toString(){
        return key;
    }

    public String value() {
        return value;
    }
}
