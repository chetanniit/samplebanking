package com.natwest.pbbdhb.aip.utils;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.model.enums.Brand;
import org.springframework.http.HttpHeaders;

public class AppUtil {

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    public static final String BRAND = "brand";
    public static final String BRAND_NWB = "nwb";
    private static final HttpHeaders nwbHttpHeaders;
    private static final HttpHeaders rbsHttpHeaders;
    public static final ObjectMapper objectMapperOrganic;

    static {
        objectMapperOrganic = new ObjectMapper();
        nwbHttpHeaders = new HttpHeaders();
        nwbHttpHeaders.add(CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        nwbHttpHeaders.add(BRAND, BRAND_NWB);

        rbsHttpHeaders = new HttpHeaders();
        rbsHttpHeaders.add(CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        rbsHttpHeaders.add(BRAND, Brand.RBS.value().toLowerCase());
    }

    private static String getBrand(Brand brand) {
        return brand == Brand.NATWEST? BRAND_NWB : Brand.RBS.name().toLowerCase();
    }

    public static HttpHeaders applicationHeaders(Brand brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(AppUtil.CONTENT_TYPE, AppUtil.CONTENT_TYPE_APPLICATION_JSON);
        headers.add(BRAND, getBrand(brand));
        return headers;
    }

    public static HttpHeaders applicationHeaders(String brand) {
        return BRAND_NWB.equals(brand)? nwbHttpHeaders : rbsHttpHeaders;
    }
}
