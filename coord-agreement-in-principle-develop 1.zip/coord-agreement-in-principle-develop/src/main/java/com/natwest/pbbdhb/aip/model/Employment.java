
package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.aip.model.enums.EmploymentStatus;
import com.natwest.pbbdhb.aip.model.enums.EmploymentType;
import com.natwest.pbbdhb.aip.model.enums.OccupationCode;
import com.natwest.pbbdhb.aip.model.enums.PayFrequency;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;


@Schema(description = "Employment Object")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Employment {

    @PositiveOrZero
    @Schema(type = "BigDecimal")
    @Max(value = 99999999, message = "allows max 8 digits")
    private int selfEmployedAnnualDrawings;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal commission;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    @Digits(integer = 8, fraction = 0)
    private BigDecimal discretionaryBonus;

    @Schema(type = "Character", allowableValues = "EMPLOYED,NOT_EMPLOYED,SELF_EMPLOYED")
    private EmploymentStatus employmentStatus;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal grossSalary;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal guaranteedBonus;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal guaranteedOvertime;

    @Valid
    @PositiveOrZero
    @Schema(type = "Integer")
    @Digits(integer = 3, fraction = 0, message = "allows max 3 digits")
    private Integer intendedRetirementAge;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal otherIncomeAmount;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean pensionIncomeAvailable;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema()
    private BigDecimal regularOvertime;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "String", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate startDate;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "LocalDate", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate previousEmployerStartDate;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "LocalDate", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate previousEmployerEndDate;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "LocalDate", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate selfEmployedDateEstablished;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "LocalDate", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate contractStart;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "LocalDate", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate contractEnd;

    @Schema(type = "String", allowableValues = "ACADEMIC_STAFF,AGRICULTURAL_WORKERS_GENERAL,FARM_MANAGEMENT_GENERAL,HM_FORCES_OFFICERS,HM_FORCES_OTHER_RANKS," +
            "HOME_FAMILY_RESPONSIBILITIES,JUNIOR_MANAGEMENT,OFFICE_AND_CLERICAL,PROFESSIONALS,SALES,SEMI_PROFESSIONALS,SEMI_SKILLED,TECHNICIANS,SENIOR_MANAGEMENT,SERVICE_JOBS,SKILLED_MANUAL,SUPERVISORY_FOREMAN,TEACHERS,UNEMPLOYED")
    private OccupationCode occupationCode;

    @Valid
    @Schema(type = "String")
    @Length(max = 9, message = "allows max 9 characters")
    private String niNumber;

    @Schema(type = "String", allowableValues = "PERMANENT,CONTRACT,TEMPORARY,OTHER")
    private EmploymentType employmentType;

    @Valid
    @Schema(type = "String")
    @Length(max = 30, message = "allows max 30 characters")
    private String otherIncomeDescription;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean otherIncome;

    @Schema(type = "String")
    @Length(max = 30, message = "allows max 30 characters")
    private String selfEmployedBusinessType;

    @Schema(type = "String", allowableValues = "MONTHLY,WEEKLY,ANNUALLY")
    private PayFrequency payFrequency;
}
