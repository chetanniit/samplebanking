package com.natwest.pbbdhb.aip.exception;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorResponse {

    private HttpStatus responseStatus;
    private String errorMessage;
    private String statusCode;
    private String message;
    private String success;

    public ErrorResponse(HttpStatus status, String errorMessage){
        this.responseStatus= status;
        this.errorMessage = errorMessage;
    }

}

