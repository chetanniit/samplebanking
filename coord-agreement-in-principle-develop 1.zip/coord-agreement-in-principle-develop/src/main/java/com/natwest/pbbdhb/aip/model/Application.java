
package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStep;
import com.natwest.pbbdhb.aip.model.enums.LoanPurpose;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import java.util.List;


@Schema(description = "Application Object")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Application {

    @Valid
    @Schema
    @Length(max = 50, message = "allows max 50 characters")
    private String lenderCaseId;

    @Valid
    @Schema()
    private AdditionalBorrowing additionalBorrowing;

    @Valid
    @Schema()
    private List<@Valid Applicant> applicants;

    @Schema(
            allowableValues = "RESIDENTIAL_PURCHASE,RESIDENTIAL_MORTGAGE,BUY_TO_LET_PURCHASE,BUY_TO_LET_REMORTGAGE,FIRST_TIME_BUYER,RIGHT_TO_BUY_PURCHASE,RIGHT_TO_BUY_REMORTGAGE,SHARED_EQUITY_PURCHASE,RES_2ND_PROP_AND_PURCHASE,\n" +
                    "RES_2ND_PROP_AND_REMORTG,EXIST_NWMS_CUST_MOVING,NEW_CUST_MOVING_OTHER,RESIDENTIAL_PURCHASE_90_TO_95,EXTRA_BORROWING,HOUSE_PURCHASE,REMORTGAGE,BUY_TO_LET,FIRST_TIME_BUYER_90_TO_95,GUARANTOR,FIRST_TIME_BUYER_NEWBUY,\n" +
                    "RES_PURCHASE_NEWBUY,FIRST_TIME_BUYER_H2B,RES_PURCHASE_H2B_MG,REMORTGAGE_H2B_MG,RESIDENTIAL_ADBO,BUY_TO_LET_ADBO")
    private LoanPurpose loanPurpose;

    @Valid
    @Positive
    @Schema()
    @Max(value = 9,message = "allows max 9 applicants")
    private Integer numberOfApplicants;

    @Schema( type = "Boolean", allowableValues = "true, false")
    private Boolean contactPermission;

    @Valid
    @Schema()
    private Property property;

    @Valid
    @Schema()
    private MortgageMarketReview mortgageMarketReview;

    @Valid
    @Schema()
    private FormInfo formInfo;

    @Valid
    @Schema()
    private Intermediary intermediary;

    @Valid
    @Schema()
    private Mortgage mortgage;

    @Schema(hidden = true, description = "Internal to NatWest")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String serviceRequired = ApplicationStep.SCORE.name();

    @Schema(hidden = true, description = "Internal to NatWest")
    private String decisionUniqueId;

    @Valid
    @Schema()
    @PositiveOrZero
    private Integer numberOfDependentsUnder18;

    @Valid
    @Schema()
    @PositiveOrZero
    private Integer numberOfDependentsOver18;

}
