package com.natwest.pbbdhb.aip.service;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import jakarta.validation.Valid;

public interface ScoringService {

    ScoringResponse scoringCheck(@Valid Application request);

}
