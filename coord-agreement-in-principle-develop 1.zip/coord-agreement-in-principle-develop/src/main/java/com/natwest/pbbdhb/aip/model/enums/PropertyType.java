package com.natwest.pbbdhb.aip.model.enums;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PropertyType {

    BUNGALOW_NEW_BUILD("A", "Bungalow (modernised or refurbished)"),
    BUNGALOW_DETACHED("U", "Bungalow – detached"),
    BUNGALOW_SEMI_DETACHED("M", "Bungalow – semi detached"),
    BUNGALOW_MID_TERRACED("I", "Bungalow – mid terraced"),
    BUNGALOW_END_TERRACED("N", "Bungalow – end terraced"),

    HOUSE_NEW_BUILD("G", "House (modern or refurbished)"),
    HOUSE_DETACHED("Q", "House – detached"),
    HOUSE_SEMI_DETACHED("Y", "House – semi detached"),
    HOUSE_MID_TERRACED("R", "House – mid terraced"),
    HOUSE_END_TERRACED("E", "House – end terraced"),
    HOUSE_NEW_BUY("V", "House – NewBuy"),

    FLAT_NEW_BUILD("J", "Flat (modern or refurbished)"),
    FLAT_PURPOSE_BUILT("W", "Flat – Purpose Built"),
    FLAT_CONVERTED("O", "Flat – Converted"),
    FLAT_NEW_BUY("Z", "Flat – NewBuy");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }

}
