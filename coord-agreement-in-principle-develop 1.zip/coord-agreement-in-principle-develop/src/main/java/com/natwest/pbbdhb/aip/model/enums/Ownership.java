package com.natwest.pbbdhb.aip.model.enums;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public enum Ownership {

    APPLICANT_ONE("1", "Applicant One"),
    APPLICANT_TWO("2", "Applicant Two"),
    JOINT("3", "Joint");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }
}
