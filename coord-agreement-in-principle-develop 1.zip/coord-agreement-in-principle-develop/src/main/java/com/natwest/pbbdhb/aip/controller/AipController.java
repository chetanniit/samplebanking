package com.natwest.pbbdhb.aip.controller;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.service.AipService;
import com.natwest.pbbdhb.aip.utils.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@Tag(name = "Agreement In Principle API", description = "Aip Controller")
@RequestMapping("/")
@Validated
@Slf4j
public class AipController {

    @Autowired
    private AipService aipService;

    @Operation(summary = "Submit aip request",
            description = "Returns Aip Response", tags = {"AipResponse"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "AIP request received"),
            @ApiResponse(responseCode = "400", description = "Bad Request"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "422", description = "Unprocessable Entity"),
            @ApiResponse(responseCode = "500", description = "Internal server error")})
    @PostMapping(path = "/application")
    public ResponseEntity<CompositeAipResponse> aipCheck(@RequestHeader(Constants.CLIENT_ID) String clientId,
                                                         @RequestHeader(Constants.BRAND) @Valid @Pattern(regexp = "(rbs|nwb)", message = "Invalid Brand") String brand,
                                                         @Valid @RequestBody Application application) throws IOException {
        log.info("AipCheck called");
        log.debug("AipCheck called with request : {}", application);

        return ResponseEntity.ok(aipService.processApplication(brand, clientId, application));
    }

}