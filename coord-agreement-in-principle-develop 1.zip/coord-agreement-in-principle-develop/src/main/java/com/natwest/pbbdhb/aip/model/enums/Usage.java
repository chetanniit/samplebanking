package com.natwest.pbbdhb.aip.model.enums;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Usage {

    RESIDENTIAL("1","Residential"),
    CONSENT_TO_LET("2","Consent to Let"),
    BUY_TO_LET("3","Buy To Let");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }
}
