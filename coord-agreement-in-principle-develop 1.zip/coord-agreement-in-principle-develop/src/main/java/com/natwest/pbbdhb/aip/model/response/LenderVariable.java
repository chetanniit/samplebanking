package com.natwest.pbbdhb.aip.model.response;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class LenderVariable {

    private String id;

    private String value;

}
