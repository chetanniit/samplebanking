package com.natwest.pbbdhb.aip.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum OwnershipType {

    HELD_RBSG("1", "Mortgaged - Held with RBSG"),
    HELD_ELSEWHERE("2", "Mortgaged – Held Elsewhere"),
    UNENCUMBERED("3", "Unencumbered");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }
}
