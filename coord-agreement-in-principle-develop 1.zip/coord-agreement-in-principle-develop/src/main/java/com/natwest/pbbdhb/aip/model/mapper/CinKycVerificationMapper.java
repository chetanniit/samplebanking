package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.Address;
import com.natwest.pbbdhb.aip.model.Applicant;
import com.natwest.pbbdhb.aip.model.cin.CinKycVerification;
import com.natwest.pbbdhb.aip.model.cin.CustomerSearchRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper(config = MappingConfig.class)
public interface CinKycVerificationMapper {
    CinKycVerificationMapper INSTANCE = Mappers.getMapper(CinKycVerificationMapper.class);

    @Mapping(target = "firstName", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "cin", source = "cin")
    @Mapping(target = "cinMatchIndicator", source = "cinMatchIndicator")
    CinKycVerification toCinKycResponse(Applicant applicant, List<String> cin, String cinMatchIndicator);


    @Mapping(target = "firstName", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "birthDate", source = "applicant.personalDetails.dateOfBirth")
    @Mapping(target = "postCode", source = "applicant.addresses", qualifiedByName = "getPostCode")
    CustomerSearchRequest toCinSearchRequest(Applicant applicant);

    @Named("getPostCode")
    static String getPostCode(List<Address> addresses) {
        return addresses.stream().filter(Address::getIsCurrentAddress).findFirst().map(Address::getPostcode).orElse(null);
    }


}
