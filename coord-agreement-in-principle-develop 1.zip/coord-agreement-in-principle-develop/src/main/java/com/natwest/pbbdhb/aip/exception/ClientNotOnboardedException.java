package com.natwest.pbbdhb.aip.exception;

public class ClientNotOnboardedException extends RuntimeException {
    public ClientNotOnboardedException(String message) {
        super(message);
    }
}
