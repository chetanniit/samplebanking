
package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.annotation.ValidAddress;
import com.natwest.pbbdhb.aip.model.enums.OccupyStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

@Schema(description = "Address Object")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@ValidAddress
public class Address {

    @Schema(allowableValues = "LODGING,OWNER,LIVING_WITH_PARENTS,RENTING,OTHER,TIED_ACCOMMODATION,FRIENDS,TENANT")
    private OccupyStatus occupyStatus;

    @Valid
    @Length(max = 28, message = "allows max 28 characters")
    @Schema()
    private String town;

    @Valid
    @Length(max = 8, message = "allows max 8 characters")
    @Schema()
    private String postcode;

    @Schema(allowableValues = "true, false")
    private Boolean ukAddress;

    @Valid
    @Length(max = 2, message = "allows max 2 characters")
    @Schema()
    private String occupyMonth;

    @Valid
    @Length(max = 4, message = "allows max 4 characters")
    @Schema()
    private String occupyYear;

    @Schema()
    @Length(max = 10, message = "allows max 10 characters")
    private String flat;

    @Valid
    @Length(max = 22, message = "allows max 22 characters")
    @Schema()
    private String houseName;

    @Valid
    @Length(max = 5, message = "allows max 5 characters")
    @Schema()
    private String houseNumber;

    @Valid
    @Length(max = 32, message = "allows max 32 characters")
    @Schema()
    private String street;

    @Valid
    @Length(max = 32, message = "allows max 32 characters")
    @Schema()
    private String street2;

    @Valid
    @Schema()
    @Length(max = 32, message = "allows max 32 characters")
    private String district;

    @Valid
    @Schema()
    @Length(max = 18, message = "allows max 18 characters")
    private String county;

    @Valid
    @PositiveOrZero
    @Schema()
    @Max(value = 99, message = "numberOfOccupants should not be more than 99")
    private Integer numberOfOccupants;

    @Schema(allowableValues = "true, false")
    private Boolean isCurrentAddress;
}
