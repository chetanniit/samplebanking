package com.natwest.pbbdhb.aip.model.state;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class AipApplicationState {

    private String caseId;

    private String stage;

    private String applicationStep;

    private String request;

    private String response;

    private String httpStatus;

    private String decision;

    private String decisionUniqueId;
}
