package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponseGenerationRequest;
import com.natwest.pbbdhb.aip.service.ResponseService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.aip.utils.AppUtil.applicationHeaders;

@Service
@Slf4j
public class ResponseServiceImpl implements ResponseService {

    @Value("${response.generation.endpoint}")
    private String responseGenerationEndPoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Override
    public AipResponse generateAipResponse(@Valid ScoringResponseGenerationRequest scoringResponse, String brand) {
        String lenderCaseId = scoringResponse.getLenderCaseId();
        log.info("Case id : {}-A8, generateAipResponse called", lenderCaseId);

        HttpEntity<ScoringResponseGenerationRequest> requestHttpEntity = new HttpEntity<>(scoringResponse, applicationHeaders(brand));
        AipResponse aipResponse = restTemplate.postForObject(responseGenerationEndPoint, requestHttpEntity, AipResponse.class);

        log.info("Case id : {}-A9, generateAipResponse completed", lenderCaseId);
        return aipResponse;
    }

}
