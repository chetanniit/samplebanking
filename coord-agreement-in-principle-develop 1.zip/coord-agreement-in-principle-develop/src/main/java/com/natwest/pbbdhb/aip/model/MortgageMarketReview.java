package com.natwest.pbbdhb.aip.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MortgageMarketReview {

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean futureLoansCommitments;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean futureHouseLeisure;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean futurePropertyExpenses;

    @Valid
    @Schema(type = "List", allowableValues = "true, false")
    private List<@Valid FutureIncomeDrop> applicants;

}
