package com.natwest.pbbdhb.aip.service;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.enums.Client;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;

import java.util.List;

public interface CinMatchService {

    List<CinResponse> cinSearch(final Application Request, final String brand, final Client client);
}
