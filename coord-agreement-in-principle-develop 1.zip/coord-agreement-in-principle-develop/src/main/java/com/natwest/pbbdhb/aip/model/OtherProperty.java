
package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.model.enums.Ownership;
import com.natwest.pbbdhb.aip.model.enums.OwnershipType;
import com.natwest.pbbdhb.aip.model.enums.RepaymentType;
import com.natwest.pbbdhb.aip.model.enums.Usage;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class OtherProperty {

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal interestOnlyAmount;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal outstandingMortgageBalance;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal monthlyMortgagePayment;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer remainingMortgageTermMonths;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer remainingMortgageTermYears;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal monthlyRentalIncome;

    @Schema(allowableValues = "true, false", type = "String")
    private Boolean propertyRedemption;

    @Schema(type = "String", allowableValues = "REPAYMENT,INTEREST_ONLY,MIXED,SUB_ACCOUNT_CAPITAL_REPAYMENT,SUB_ACCOUNT_INTEREST_ONLY")
    private RepaymentType mortgageRepaymentType;

    @Schema(type = "BigDecimal", allowableValues = "RESIDENTIAL,CONSENT_TO_LET,BUY_TO_LET")
    private Usage propertyUsage;

    @Schema(type = "String", allowableValues = "APPLICANT_ONE,APPLICANT_TWO,JOINT")
    private Ownership ownership;

    @Schema(type = "String", allowableValues = "HELD_RBSG,HELD_ELSEWHERE,UNENCUMBERED")
    private OwnershipType ownershipType;
}
