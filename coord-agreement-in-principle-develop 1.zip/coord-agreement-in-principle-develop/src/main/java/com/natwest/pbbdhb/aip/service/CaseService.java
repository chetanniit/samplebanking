package com.natwest.pbbdhb.aip.service;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;

public interface CaseService {

    String generateCaseId(String clientId, String preFix,String brand);

    Case createCaseSummary(String clientId, Application application, ScoringResponse scoringResponse,String brand);

    Case trackCase(String clientId, Application application, ScoringResponse scoringResponse,String brand);

    String getNameFromClientId(String clientId, String brand);

}
