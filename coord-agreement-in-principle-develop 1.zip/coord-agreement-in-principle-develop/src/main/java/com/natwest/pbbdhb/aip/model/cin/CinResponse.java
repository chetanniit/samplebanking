package com.natwest.pbbdhb.aip.model.cin;


import com.natwest.pbbdhb.aip.model.Applicant;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CinResponse {

    private Applicant applicant;

    private List<String> cin;

    private String cinMatchIndicator;
}
