package com.natwest.pbbdhb.aip.utils;

import java.util.function.Supplier;

public class Checks {

    private Checks() {
    }

    public static void requireNotNull(Object objectToCheck, Supplier<? extends RuntimeException> supplier) {
        if (objectToCheck == null) {
            throw supplier.get();
        }
    }

}
