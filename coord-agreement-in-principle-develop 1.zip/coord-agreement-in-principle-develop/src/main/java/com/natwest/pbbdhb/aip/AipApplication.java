package com.natwest.pbbdhb.aip;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackageClasses = {AipApplication.class})
@OpenAPIDefinition(info = @Info(title = "Agreement In Principle API", version = "1.0", description = "Agreement In Principle API Specification"))
public class AipApplication {

    public static void main(String[] args) {
        SpringApplication.run(AipApplication.class, args);
    }

}

