package com.natwest.pbbdhb.aip.model;

import com.natwest.pbbdhb.aip.model.enums.Purpose;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Details {

    @Schema(type = "String", allowableValues = "HOME_IMPROVEMENT,HOUSE_PURCHASE,HOLIDAY,BUY_NEW_OR_USED_CAR,DEBT_CONSOLIDATION,OTHER")
    private Purpose purpose;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal amount;

}
