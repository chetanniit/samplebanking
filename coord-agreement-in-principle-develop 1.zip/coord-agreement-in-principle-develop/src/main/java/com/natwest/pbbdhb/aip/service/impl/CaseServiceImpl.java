package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.casemgmt.AipCaseType;
import com.natwest.pbbdhb.aip.model.casemgmt.AipDecision;
import com.natwest.pbbdhb.aip.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.model.casemgmt.CaseStatus;
import com.natwest.pbbdhb.aip.model.casemgmt.CaseSummary;
import com.natwest.pbbdhb.aip.model.casemgmt.CaseType;
import com.natwest.pbbdhb.aip.model.casemgmt.ClientDetails;
import com.natwest.pbbdhb.aip.model.casemgmt.Decision;
import com.natwest.pbbdhb.aip.model.casemgmt.DecisionReason;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.service.CaseService;
import com.natwest.pbbdhb.aip.utils.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static com.natwest.pbbdhb.aip.utils.AppUtil.applicationHeaders;
import static org.apache.commons.lang.StringUtils.isNotBlank;

@Service
@Slf4j
public class CaseServiceImpl implements CaseService {


    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${case.id.generation.endpoint}")
    private String caseIdGenerationEndPoint;

    @Value("${create.case.summary.endpoint}")
    private String createCaseSummaryEndPoint;

    @Value("${create.case.endpoint}")
    private String caseTrackingEndPoint;

    @Value("${fetch.client.details.endpoint}")
    private String fetchClientDetailsPoint;

    @Override
    public String generateCaseId(String clientId, String caseIdPrefix, String brand) {
        log.info("A3- Generating caseId with: prefix {}, clientId: {}", caseIdPrefix, clientId != null ? clientId.concat(caseIdPrefix) : clientId);

        String caseId = restTemplate.exchange(caseIdGenerationEndPoint, HttpMethod.GET,
                new HttpEntity(AppUtil.applicationHeaders(brand)),
                String.class,
                caseIdPrefix,
                clientId).getBody();

        log.info("Case id : {}-A3.1, has been generated successfully", caseId);
        return caseId;
    }

    public Case createCaseSummary(String clientId, Application application, ScoringResponse scoringResponse, String brand) {
        log.info("Case id : {}, createCaseSummary called", application.getLenderCaseId());

        CaseSummary caseSummaryRequest = CaseSummary.builder()
                .caseId(application.getLenderCaseId())
                .creationDate(new Date())
                .source(application.getFormInfo().getDataFeed().name())
                .caseTypeId(AipCaseType.AIP.getId())
                .caseStatusSet(buildApplicationStatus(application.getLenderCaseId(), scoringResponse.getDecision()))
                .build();
        return restTemplate.postForObject(createCaseSummaryEndPoint, new HttpEntity<>(caseSummaryRequest, applicationHeaders(brand)), Case.class);
    }

    public Case trackCase(String clientId, Application application, ScoringResponse scoringResponse, String brand) {
        log.info("Case id : {}-A10, trackCase called", application.getLenderCaseId());

        return restTemplate.exchange(
                caseTrackingEndPoint,
                HttpMethod.PUT, new HttpEntity<>(createCase(clientId, application, scoringResponse), applicationHeaders(brand)),
                Case.class,
                application.getLenderCaseId()).getBody();
    }

    private Case createCase(String clientId, Application application, ScoringResponse scoringResponse) {
        AipDecision aipDecision = isNotBlank(scoringResponse.getDecision()) ?
                AipDecision.valueOf(scoringResponse.getDecision().toUpperCase()) : null;

        Case caseToUpdate = Case.builder()
                .caseId(application.getLenderCaseId())
                .creationDate(new Date())
                .source(application.getFormInfo().getDataFeed().name())
                .clientId(clientId)
                .caseType(CaseType.builder().id(AipCaseType.AIP.getId()).type(AipCaseType.AIP.name()).build())
                .caseStatusSet(aipDecision != null ? new HashSet<>(Collections.singletonList(CaseStatus.builder()
                        .creationDate(new Date())
                        .decisionReason(DecisionReason.builder().id(aipDecision.getId()).decisionReason(aipDecision.name()).build())
                        .decision(Decision.builder().id(aipDecision.getId()).decision(aipDecision.name()).build()).build())) : null)
                .build();
        return caseToUpdate;
    }

    private Set<CaseStatus> buildApplicationStatus(String caseId, String decision) {
        Long decisionId = isNotBlank(decision) ? AipDecision.valueOf(decision.toUpperCase()).getId() : AipDecision.REFER.getId();

        return new HashSet<>(Collections.singletonList(CaseStatus.builder()
                .caseId(caseId)
                .decisionId(decisionId)
                .decisionReasonId(decisionId)
                .creationDate(new Date())
                .build()));
    }

    public String getNameFromClientId(String clientId, String brand) {
        try {
            ClientDetails clientDetails = restTemplate.exchange(fetchClientDetailsPoint, HttpMethod.GET,
                    new HttpEntity<>(applicationHeaders(brand)), ClientDetails.class, clientId).getBody();
            if (clientDetails != null && clientDetails.getName() != null) {
                return clientDetails.getName();
            }
        } catch (RestClientException restClientException) {
            log.error("exception while finding clientDetails : {}", restClientException.getMessage());
        }
        return null;
    }

}
