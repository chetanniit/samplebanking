package com.natwest.pbbdhb.aip.model.casemgmt;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Decision {

    private Long id;

    private String decision;
}
