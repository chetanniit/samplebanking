package com.natwest.pbbdhb.aip.model.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Policy {

    @Schema(example = "Applicant 1 - Address not matched at Bureau.")
    private String message;

    @Schema(example = "R900")
    private String code;

}
