package com.natwest.pbbdhb.aip.service;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;

@FunctionalInterface
public interface UnCheck {

    ScoringResponse unBox(Application application, ScoringResponse scoringResponse);
}
