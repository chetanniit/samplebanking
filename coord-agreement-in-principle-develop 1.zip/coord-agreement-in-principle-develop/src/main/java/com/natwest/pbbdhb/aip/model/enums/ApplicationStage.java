package com.natwest.pbbdhb.aip.model.enums;


public enum ApplicationStage {
    AIP, AIP_TO_FMA, FMA
}
