package com.natwest.pbbdhb.aip.model.casemgmt;

public enum AipDecision {

    ACCEPT("accept", 1),
    REFER("referred", 3),
    DECLINE("declined", 4);

    private String decisionString;
    private long id;

    public long getId() {
        return id;
    }


    AipDecision(String decisionString, long id) {
        this.decisionString = decisionString;
        this.id = id;
    }

    public String getDecisionString() {
        return decisionString;
    }
}
