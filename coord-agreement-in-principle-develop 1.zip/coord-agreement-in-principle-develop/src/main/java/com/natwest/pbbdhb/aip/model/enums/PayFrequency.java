package com.natwest.pbbdhb.aip.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PayFrequency {

    MONTHLY("1", "Monthly"),
    WEEKLY("2", "Weekly"),
    ANNUALLY("3", "Other");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }
}
