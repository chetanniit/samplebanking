package com.natwest.pbbdhb.aip.model.cin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CustomerSearchRequest {

    private String firstName;

    private String lastName;

    private String birthDate;

    private String postCode;

    private String email;

    private String addressLine1;

    private String telephoneNumber;

    private String deathDate;

    private Boolean ukAddress;

    private String sourceId;

    private String channel;

    private String referenceId;
}