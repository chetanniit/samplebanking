package com.natwest.pbbdhb.aip.model.casemgmt;

import lombok.*;

import java.util.Date;
import java.util.Set;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CaseSummary {

    private String caseId;

    private Date creationDate;

    private String source;

    private String clientId;

    private Long caseTypeId;

    private Set<CaseStatus> caseStatusSet;
}
