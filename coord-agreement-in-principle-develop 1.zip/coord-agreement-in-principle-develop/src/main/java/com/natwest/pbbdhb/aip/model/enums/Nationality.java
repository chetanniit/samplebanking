package com.natwest.pbbdhb.aip.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Nationality {

    UNITED_KINGDOM("E", "UK National"),
    NON_EU("N","Non EU"),
    OTHER("O","Other");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }
}
