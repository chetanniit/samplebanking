
package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Schema(description = "CreditCards Object")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CreditCards {

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema()
    private BigDecimal totalBalancePostMortgage;

    @Valid
    @PositiveOrZero
    @Schema()
    @Max(value = 99, message = "allows max 99 cards")
    private Integer numberOfCards;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema()
    private BigDecimal totalBalance;

    @Schema(allowableValues = "true, false")
    private Boolean toBeRepaid;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal refinancedCreditCardBalance;

}
