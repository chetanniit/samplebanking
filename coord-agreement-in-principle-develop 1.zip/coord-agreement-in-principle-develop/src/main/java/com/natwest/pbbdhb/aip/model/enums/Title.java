package com.natwest.pbbdhb.aip.model.enums;

public enum Title {

    None,
    Mr,
    Mrs,
    Miss,
    Ms,
    Dr,
    Reverend,
    Professor,
    Sir,
    Lord,
    Lady,
    Captain,
    Major,
    Colonel,
    General,
    Master,
    Hon,
    Mx,
    Sister,
    Viscount,
    Countess,
    Earl,
    Other
}
