package com.natwest.pbbdhb.aip.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.natwest.pbbdhb.aip.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.exception.ClientNotOnboardedException;
import com.natwest.pbbdhb.aip.exception.ErrorResponse;
import com.natwest.pbbdhb.aip.exception.InvalidCaseIdException;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.ExistingMortgage;
import com.natwest.pbbdhb.aip.model.Expenditure;
import com.natwest.pbbdhb.aip.model.Intermediary;
import com.natwest.pbbdhb.aip.model.Mortgage;
import com.natwest.pbbdhb.aip.model.Property;
import com.natwest.pbbdhb.aip.model.casemgmt.AipDecision;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.model.enums.Client;
import com.natwest.pbbdhb.aip.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.model.enums.ProductType;
import com.natwest.pbbdhb.aip.model.mapper.AipResponseMapper;
import com.natwest.pbbdhb.aip.model.mapper.CompositeAipResponseMapper;
import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.model.response.Policy;
import com.natwest.pbbdhb.aip.model.response.Scheme;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponseGenerationRequest;
import com.natwest.pbbdhb.aip.service.AipService;
import com.natwest.pbbdhb.aip.service.CaseService;
import com.natwest.pbbdhb.aip.service.CinMatchService;
import com.natwest.pbbdhb.aip.service.ResponseService;
import com.natwest.pbbdhb.aip.service.ScoringService;
import com.natwest.pbbdhb.aip.service.StateService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.aip.model.enums.LoanPurpose.BUY_TO_LET;
import static com.natwest.pbbdhb.aip.model.enums.LoanPurpose.BUY_TO_LET_PURCHASE;
import static com.natwest.pbbdhb.aip.model.enums.LoanPurpose.BUY_TO_LET_REMORTGAGE;
import static com.natwest.pbbdhb.aip.utils.Checks.requireNotNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

@Service
@Slf4j
public class AipServiceImpl implements AipService {
    private static final String LOAN_MESSAGE = "LoanMessage";
    private static final Integer maxTermRemaining = 99;

    private final ScoringService scoreService;
    private final CaseService caseService;
    private final StateService stateService;
    private final ResponseService responseService;
    private final ObjectMapper objectMapper;
    private final CinMatchService cinMatchService;
    private final AipResponseMapper aipResponseMapper;
    private final CompositeAipResponseMapper compositeAipResponseMapper;
    private final ModelMapper modelMapper;

    @Value("${cin.search.enable:true}")
    private Boolean enableCinSearch;

    @Autowired
    public AipServiceImpl(ScoringService scoreService,
                          CaseService caseService,
                          StateService stateService,
                          ResponseService responseService,
                          ObjectMapper objectMapper,
                          CinMatchService cinMatchService,
                          AipResponseMapper aipResponseMapper,
                          CompositeAipResponseMapper compositeAipResponseMapper,
                          ModelMapper modelMapper) {
        this.scoreService = scoreService;
        this.caseService = caseService;
        this.stateService = stateService;
        this.responseService = responseService;
        this.objectMapper = objectMapper;
        this.cinMatchService = cinMatchService;
        this.aipResponseMapper = aipResponseMapper;
        this.compositeAipResponseMapper = compositeAipResponseMapper;
        this.modelMapper = modelMapper;

    }

    @Override
    public CompositeAipResponse processApplication(String brand, String clientId, @Valid Application aipRequest) throws IOException {
        log.info("A1 - AIP ProcessApplication started");

        Client client = validateClientIsOnBoardedAndGetClient(clientId, brand);
        applyPrerequisites(brand, clientId, aipRequest);
        removeAttributesBeforeSendingToScore(aipRequest);

        if (isCinSearchEnabled()) {
            List<CinResponse> applicantsCinResponse = cinMatchService.cinSearch(aipRequest, brand, client);
            stateService.captureApplicationState(brand, aipRequest, applicantsCinResponse);
        }

        DataFeed dataFeed = getDataFeed(client.name(), aipRequest.getLenderCaseId());
        aipRequest.getFormInfo().setDataFeed(dataFeed);

        ScoringResponse scoringResponse = scoringCheck(aipRequest);
        scoringResponse.setChannel(client.name());

        stateService.captureApplicationState(brand, aipRequest, scoringResponse);

        if (isNotEmpty(scoringResponse.getErrorCode())) {
            stateService.updateApplication(brand, aipRequest, compositeAipResponseMapper.toCompositeAipResponse(aipResponseMapper.toAipResponse(scoringResponse)), scoringResponse);
            throw new BureauServiceException(scoringResponse.getErrorDescription(), scoringResponse.getErrorCode());
        }

        AipResponse aipResponse = responseService.generateAipResponse(modelMapper.map(scoringResponse, ScoringResponseGenerationRequest.class), brand);

        enrichPolicyMessages(scoringResponse, aipResponse);
        CompositeAipResponse compositeAipResponse = generateCompositeAipResponse(aipRequest, scoringResponse, aipResponse, brand, clientId);
        compositeAipResponse.setPackaging(scoringResponse.getPackaging());

        stateService.updateApplication(brand, aipRequest, compositeAipResponse, scoringResponse);

        caseService.trackCase(clientId, aipRequest, scoringResponse, brand);

        log.info("Case id : {}-A11, AIP ProcessApplication completed", aipRequest.getLenderCaseId());

        return compositeAipResponse;
    }

    private void setChannel(String brand, String clientId, ScoringResponse scoringResponse) {
        Client client = validateClientIsOnBoardedAndGetClient(clientId, brand);
        scoringResponse.setChannel(client.name());
    }

    public static DataFeed getDataFeed(String channel, String lenderCaseId) {
        for (DataFeed df : DataFeed.values()) {
            if (df.getValue().equals(channel)) {
                return df;
            }
        }
        throw new RuntimeException("Channel with name " + channel + " has not been found for lenderCaseId: " + lenderCaseId);
    }

    private CompositeAipResponse generateCompositeAipResponse(Application aipRequest, ScoringResponse scoringResponse, AipResponse aipResponse, String brand, String clientId) throws IOException {
        CompositeAipResponse compositeAipResponse = compositeAipResponseMapper.toCompositeAipResponse(aipResponse);
        Mortgage mortgage = aipRequest.getMortgage();

        if (nonNull(compositeAipResponse)) {
            boolean policiesPresent = !CollectionUtils.isEmpty(compositeAipResponse.getPolicies());

            if (policiesPresent) {
                compositeAipResponse.getPolicies().forEach(policy -> policy.setProductType(ProductType.TWO_YEARS.value()));
            }

            boolean bureauError = CollectionUtils.isEmpty(scoringResponse.getEquifaxResponseDetails());

            if (!bureauError && !AipDecision.DECLINE.name().equals(compositeAipResponse.getDecision())) {
                mortgage.setProductType(ProductType.FIVE_YEARS);

                aipRequest.setDecisionUniqueId(scoringResponse.getDecisionUniqueId());

                ScoringResponse scoringResponse5Yrs = scoringCheck(aipRequest);

                stateService.captureApplicationState(brand, aipRequest, scoringResponse5Yrs);

                setChannel(brand, clientId, scoringResponse);

                AipResponse aipResponse5Yrs = responseService.generateAipResponse(modelMapper.map(scoringResponse5Yrs, ScoringResponseGenerationRequest.class), brand);
                enrichPolicyMessages(scoringResponse5Yrs, aipResponse5Yrs);

                if (nonNull(aipResponse5Yrs.getPolicyMessages())) {
                    Scheme fiveYearScheme = Scheme.builder().productType(ProductType.FIVE_YEARS.value()).policyMessages(aipResponse5Yrs.getPolicyMessages()).build();
                    ArrayList<Scheme> compositePolicies = new ArrayList<>(compositeAipResponse.getPolicies());
                    compositePolicies.add(fiveYearScheme);
                    compositeAipResponse.setPolicies(compositePolicies);
                }
            }
        }
        return compositeAipResponse;
    }

    private void enrichPolicyMessages(ScoringResponse scoringResponse, AipResponse aipResponse) {
        if (isNotEmpty(scoringResponse.getLoanMessage())) {
            Policy loanPolicy = Policy.builder().code(LOAN_MESSAGE).message(scoringResponse.getLoanMessage()).build();
            List<Policy> policyMessages = aipResponse.getPolicyMessages();
            if (nonNull(policyMessages)) policyMessages.add(loanPolicy);
            aipResponse.setPolicyMessages(nonNull(policyMessages) ? policyMessages : Collections.singletonList(loanPolicy));
        }
    }

    private ScoringResponse scoringCheck(Application aipRequest) throws IOException {
        formatPostcode(aipRequest);
        ScoringResponse scoringResponse = ScoringResponse.builder().lenderCaseId(aipRequest.getLenderCaseId()).build();
        try {
            scoringResponse = scoreService.scoringCheck(aipRequest);
        } catch (Exception exception) {
            logException(scoringResponse, exception, aipRequest.getLenderCaseId());
        }
        return scoringResponse;
    }

    private void applyPrerequisites(String brand, String clientId, Application aipRequest) throws JsonProcessingException {
        if (isNotEmpty(aipRequest.getLenderCaseId())) {
            final String decisionUniqueId = stateService.getDecisionUniqueId(brand, aipRequest.getLenderCaseId(), ApplicationStage.AIP);
            aipRequest.setDecisionUniqueId(decisionUniqueId);
            log.info("Case id : {}-A2, fetched decisionUniqueId: {}", aipRequest.getLenderCaseId(), decisionUniqueId);
        }
        final String caseId = caseService.generateCaseId(clientId, aipRequest.getFormInfo().getDataFeed().toString(), brand);

        requireNotNull(caseId, InvalidCaseIdException::new);

        aipRequest.setLenderCaseId(caseId);

        if (nonNull(aipRequest.getMortgage()) && nonNull(aipRequest.getMortgage().getBuyToLet())) {
            aipRequest.getMortgage().setProductType(ProductType.TWO_YEARS);
        }

        stateService.captureApplication(brand, aipRequest);

        Property property = aipRequest.getProperty();
        if (nonNull(property)) {
            Integer termRemaining = property.getTermRemaining();
            property.setTermRemaining(nonNull(termRemaining) && termRemaining > maxTermRemaining ? maxTermRemaining : termRemaining);
        }

        if (aipRequest.getApplicants().stream().anyMatch(applicant -> nonNull(applicant.getExistingMortgage()))) {
            aipRequest.getApplicants().forEach(applicant -> {
                Expenditure expenditure = applicant.getExpenditure();
                if (nonNull(expenditure) && Lists.newArrayList(BUY_TO_LET, BUY_TO_LET_REMORTGAGE, BUY_TO_LET_PURCHASE).contains(aipRequest.getLoanPurpose()))
                    expenditure.setMortgageRent(BigDecimal.ZERO);
            });
        }
    }

    private void removeAttributesBeforeSendingToScore(Application scoreRequest) {
        if (scoreRequest.getApplicants() != null && !scoreRequest.getApplicants().isEmpty()) {
            scoreRequest.getApplicants()
                    .stream()
                    .filter(Objects::nonNull)
                    .forEach(applicant -> {
                        if (applicant.getExistingMortgage() != null) {
                            ExistingMortgage existingMortgage = applicant.getExistingMortgage();

                            if (existingMortgage.getPropertyBeingSold() == null) {
                                existingMortgage.setPropertyBeingSold(existingMortgage.getPropertyBeingRedeemed());
                            }

                            existingMortgage.setPropertyBeingRedeemed(null);
                        }
                    });
        }
    }

    @Override
    public Client validateClientIsOnBoardedAndGetClient(String clientId, String brand) {
        String clientName = caseService.getNameFromClientId(clientId, brand);
        Optional<Client> dataFeedOptional = Client.stream().filter(client -> client.name().equalsIgnoreCase(clientName)).findFirst();
        return dataFeedOptional.orElseThrow(() -> new ClientNotOnboardedException("Client Id is not on-boarded for " + clientId));
    }

    private void formatPostcode(Application aipRequest) {
        Intermediary intermediary = aipRequest.getIntermediary();
        if (nonNull(intermediary)) intermediary.setPostcode(removeAllSpaces(intermediary.getPostcode()));
        aipRequest.getApplicants().stream().filter(Objects::nonNull).forEach(applicant -> applicant.getAddresses()
                .forEach(address -> {
                    String postcode = address.getPostcode();
                    address.setPostcode(removeAllSpaces(postcode));
                }));
    }

    private String removeAllSpaces(String postcode) {
        return isNotEmpty(postcode) ? postcode.replaceAll("\\s+", "") : postcode;
    }

    private void logException(ScoringResponse scoringResponse, Exception exception, String lenderCaseId) throws IOException {
        String message = null;
        int statusCode = 500;
        if (exception instanceof HttpServerErrorException) {
            message = exception.getMessage();
            statusCode = ((HttpServerErrorException) exception).getRawStatusCode();

        } else if (exception instanceof HttpClientErrorException.BadRequest) {
            statusCode = ((HttpClientErrorException.BadRequest) exception).getRawStatusCode();
            String responseBodyAsString = ((HttpClientErrorException.BadRequest) exception).getResponseBodyAsString();
            ErrorResponse errorResponse = StringUtils.isBlank(responseBodyAsString)
                    ? ErrorResponse.builder().statusCode(String.valueOf(HttpStatus.BAD_REQUEST.value())).build()
                    : objectMapper.readValue(responseBodyAsString, ErrorResponse.class);
            message = errorResponse.getMessage();
        }
        scoringResponse.setErrorCode(String.valueOf(statusCode));
        scoringResponse.setErrorDescription(lenderCaseId.concat(" : ").concat(message == null ? exception.getMessage() : message));
        log.error("Case id : {}, Exception is scoring call, error code: {}, message:{}", lenderCaseId, statusCode, message);
    }

    private boolean isCinSearchEnabled() {

        return BooleanUtils.isTrue(enableCinSearch);
    }
}
