package com.natwest.pbbdhb.aip.exception;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApplicationDetailsResponse {

    public String statusCode;

    public String message;

    public String success;
}
