package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.model.state.AipApplication;
import com.natwest.pbbdhb.aip.model.state.AipApplicationState;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.http.HttpStatus;

import static java.util.Objects.isNull;

@Mapper(config = MappingConfig.class)
public interface AipApplicationStateMapper {

    AipApplicationStateMapper INSTANCE = Mappers.getMapper(AipApplicationStateMapper.class);

    @Mapping(target = "caseId", source = "application.lenderCaseId")
    @Mapping(target = "channel", source = "application.formInfo.dataFeed")
    @Mapping(target = "stage", source = "application.formInfo.applicationStage")
    @Mapping(target = "request", source = "request")
    AipApplication toApplicationRequest(Application application, String request);

    @Mapping(target = "stage", constant = "AIP")
    @Mapping(target = "applicationStep", constant = "CIN_MATCH")
    AipApplicationState toCinApplicationState(String caseId);


    @Mapping(target = "caseId", source = "application.lenderCaseId")
    @Mapping(target = "decision", source = "scoringResponse.decision")
    @Mapping(target = "decisionUniqueId", source = "scoringResponse.decisionUniqueId")
    @Mapping(target = "stage", source = "application.formInfo.applicationStage")
    @Mapping(target = "httpStatus", source = "scoringResponse", qualifiedByName = "getHttpStatus")
    @Mapping(target = "applicationStep", constant = "SCORE")
    @Mapping(target = "request", source = "request")
    @Mapping(target = "response", source = "response")
    AipApplicationState toApplicationStateRequest(Application application, ScoringResponse scoringResponse, String request, String response);


    @Named("getHttpStatus")
    static String getHttpStatus(ScoringResponse scoreResponse) {
        return isNull(scoreResponse.getErrorCode()) ? String.valueOf(HttpStatus.OK.value()) : scoreResponse.getErrorCode();
    }

}
