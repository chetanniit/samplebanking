package com.natwest.pbbdhb.aip.model.casemgmt;

public enum AipCaseType {

    AIP(3);

    private final long id;

    AipCaseType(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
