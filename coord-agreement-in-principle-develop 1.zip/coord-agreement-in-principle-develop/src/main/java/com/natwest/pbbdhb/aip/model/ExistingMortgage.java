package com.natwest.pbbdhb.aip.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.aip.model.enums.MortgageOwnership;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ExistingMortgage {

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal amountOutstanding;

    @Schema(type = "String")
    private String lender;

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Schema(type = "LocalDate", example = "\"20210131\"")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate purchaseDate;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal purchasePrice;

    @Schema(type = "String", allowableValues = "JOINT,SINGLE")
    private MortgageOwnership ownership;

    @Valid
    @PositiveOrZero
    @Schema(type = "BigDecimal")
    @Digits(integer = 8, fraction = 0)
    private BigDecimal propertyValue;

    @Schema(type = "Boolean")
    private Boolean propertyBeingRedeemed;

    @Schema(type = "Boolean")
    private Boolean propertyBeingSold;

}
