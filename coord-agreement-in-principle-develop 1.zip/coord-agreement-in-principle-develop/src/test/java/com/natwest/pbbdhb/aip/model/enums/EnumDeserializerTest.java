package com.natwest.pbbdhb.aip.model.enums;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.natwest.pbbdhb.aip.model.Details;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;


public class EnumDeserializerTest {

    @Test
    public void validateDeserializer() throws  Exception {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);

        String jsonRequest = "{\"purpose\":\"HOME_IMPROVEMENT\",\"amount\":null}";
        String jsonResponse = "{\"purpose\":\"1\",\"amount\":null}";

        Details purpose = objectMapper.readValue(jsonRequest, Details.class);
        String valueAsString = objectMapper.writeValueAsString(purpose);

        Assertions.assertEquals(Purpose.HOME_IMPROVEMENT, purpose.getPurpose());
        Assertions.assertEquals(jsonResponse, valueAsString);
    }
    
}

