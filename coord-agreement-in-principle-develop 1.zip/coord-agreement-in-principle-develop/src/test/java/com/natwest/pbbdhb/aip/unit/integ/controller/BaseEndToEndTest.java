package com.natwest.pbbdhb.aip.unit.integ.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class BaseEndToEndTest {

    static final int WIREMOCK_PORT = 9999;
    static final String AIP_REQUEST_JSON = "application.json";
    static final String AIP_REQUEST_5YEARS_JSON = "application5Years.json";
    static final String AIP_BUY_TO_LET_REQUEST_JSON = "applicationBuyToLet.json";
    static final String AIP_BUY_TO_LET_REQUEST_JSON_FOR_2YEARS = "applicationBuyToLetOnlyFor2Years.json";
    static final String CONTENT_TYPE = "content-type";
    static final String APPLICATION_JSON = "application/json";
    static String AIP_SCORE = "application";
    static String JSON = ".json";
    static final String beforeScoringResponse = null;
    static final String ACCEPT = "ACCEPT";
    static final String REFER = "REFER";
    static final String DECLINE = "DECLINE";
    static String withoutCaseId;
    static final String AIP_ENDPOINT = "/application";
    static final String SCORING_ENDPOINT = "/mortgage/scoring/v1";
    static final String CASE_ID_GENERATION_ENDPOINT = "/mortgages/v1/msvc-case-management/generateCaseId";
    static final String CREATE_CASE_SUMMARY_ENDPOINT = "/mortgages/v1/msvc-case-management/casesummary";
    static final String UPDATE_CASE_ENDPOINT = "/mortgages/v1/msvc-case-management/case/";
    static final String CREATE_APPLICATION_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application";
    static final String UPDATE_APPLICATION_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application/";
    static final String CREATE_APPLICATION_STATE_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application/state";
    static final String GENERATE_HBO_AIP_RESPONSE = "/mortgages/v1/msvc-hbo-risk-response-generator/generate/response";
    static final String GET_CLIENT_DETAILS = "/mortgages/v1/msvc-case-management/getClientDetails";

    ObjectMapper mapper = new ObjectMapper();

    protected static final WireMockServer wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(WIREMOCK_PORT));

    @BeforeEach
     void reset() {
        wireMockServer.resetAll();
        wireMockServer.start();
    }

    public File readJson(String fileName) {
        return Paths.get("src", "test", "resources", "__files", fileName).toFile();
    }

    public Path readPath(String fileName) {
        return Paths.get("src", "test", "resources", "__files", fileName);
    }

    public String jsonString(String fileName) throws IOException {
        Scanner scanner = new Scanner(readJson(fileName));
        scanner.useDelimiter("\r\n");
        StringBuilder sb = new StringBuilder();
        while (scanner.hasNext()) {
            sb.append(scanner.next());
        }
        return sb.toString();
    }

    @AfterEach
     void tearDown() {
        wireMockServer.stop();
    }

}
