package com.natwest.pbbdhb.aip.unit.integ.controller;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

@TestConfiguration
public class WireMockConfig {

    @Bean
    @Qualifier("iamJwtChainSecureRestTemplate")
    @Primary
    public RestTemplate iamJwtChainRestTemplate() {
        return new RestTemplateBuilder().build();
    }

}
