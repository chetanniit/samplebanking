package com.natwest.pbbdhb.aip.service.impl;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.exception.ErrorResponse;
import com.natwest.pbbdhb.aip.exception.InvalidCaseIdException;
import com.natwest.pbbdhb.aip.model.Address;
import com.natwest.pbbdhb.aip.model.Applicant;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.BuyToLet;
import com.natwest.pbbdhb.aip.model.ExistingMortgage;
import com.natwest.pbbdhb.aip.model.Expenditure;
import com.natwest.pbbdhb.aip.model.FormInfo;
import com.natwest.pbbdhb.aip.model.Intermediary;
import com.natwest.pbbdhb.aip.model.Mortgage;
import com.natwest.pbbdhb.aip.model.Property;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.model.enums.Brand;
import com.natwest.pbbdhb.aip.model.enums.Client;
import com.natwest.pbbdhb.aip.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.model.enums.IcrTaxRate;
import com.natwest.pbbdhb.aip.model.enums.LoanPurpose;
import com.natwest.pbbdhb.aip.model.enums.ProductType;
import com.natwest.pbbdhb.aip.model.mapper.AipResponseMapper;
import com.natwest.pbbdhb.aip.model.mapper.CompositeAipResponseMapper;
import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.model.response.EquifaxResponseDetails;
import com.natwest.pbbdhb.aip.model.response.Policy;
import com.natwest.pbbdhb.aip.model.response.Scheme;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponseGenerationRequest;
import com.natwest.pbbdhb.aip.service.CaseService;
import com.natwest.pbbdhb.aip.service.CinMatchService;
import com.natwest.pbbdhb.aip.service.ResponseService;
import com.natwest.pbbdhb.aip.service.ScoringService;
import com.natwest.pbbdhb.aip.service.StateService;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class AipServiceImplTest {

    private static final String CLIENT_ID = "clientId";
    private static final String LENDER_CASE_ID = "lenderCaseId";
    private static final String DECISION_UNIQUE_ID = "1";
    private static final String ERROR = "lenderCaseId : 400 BAD_REQUEST";
    private static final String LOAN_MESSAGE = "LoanMessage";
    private static final String BRAND_NWB = "nwb";
    private static final String BUREAU_ERROR = "RBE0010";
    private static final String FOCUS = "FOCUS";

    @Mock
    private ScoringService scoreService;

    @Mock
    private CaseService caseService;

    @Mock
    private StateService stateService;

    @Mock
    private ResponseService responseService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private CinMatchService cinMatchService;

    @Mock
    private AipResponseMapper aipResponseMapper;

    @Mock
    private CompositeAipResponseMapper compositeAipResponseMapper;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AipServiceImpl aipService;

    @Captor
    private ArgumentCaptor<ScoringResponse> scoringResponseArgumentCaptor;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(aipService, "enableCinSearch", true, Boolean.class);
    }

    @Test
    void testProcessApplicationForExistingApplication() throws IOException {
        Application application = getApplication();
        ScoringResponse scoringResponse = new ScoringResponse();
        ScoringResponseGenerationRequest scoringResponseGenerationRequest = new ScoringResponseGenerationRequest();
        AipResponse aipResponse = AipResponse.builder().build();
        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder()
                        .policyMessages(Arrays.asList(Policy.builder().code(LOAN_MESSAGE).message("Maximum lend 500K").build())).build())).build();
        when(stateService.getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(DECISION_UNIQUE_ID);
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, ScoringResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB)).thenReturn(aipResponse);
        when(compositeAipResponseMapper.toCompositeAipResponse(aipResponse)).thenReturn(compositeAipResponse);
        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(LENDER_CASE_ID);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipService.processApplication(BRAND_NWB, CLIENT_ID, application);

        verify(stateService).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService).scoringCheck(application);
        verify(stateService).captureApplicationState(BRAND_NWB, application, scoringResponse);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService).captureApplicationState(any(String.class), eq(application), anyList());
        verify(caseService).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(stateService).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(responseService).generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB);
    }

    @Test
    void loanMessageExistsInAIPResponseIfReturnedInScoringResponse() throws IOException {
        Application application = getApplication();
        ScoringResponse scoringResponse = new ScoringResponse();
        ScoringResponseGenerationRequest scoringResponseGenerationRequest = new ScoringResponseGenerationRequest();
        scoringResponse.setLoanMessage("Maximum lend 500K");
        scoringResponseGenerationRequest.setLoanMessage("Maximum lend 500K");
        AipResponse aipResponse = AipResponse.builder().build();
        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder()
                        .policyMessages(Arrays.asList(Policy.builder().code(LOAN_MESSAGE).message("Maximum lend 500K").build())).build())).build();
        when(stateService.getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(DECISION_UNIQUE_ID);
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, ScoringResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB)).thenReturn(aipResponse);
        when(compositeAipResponseMapper.toCompositeAipResponse(aipResponse)).thenReturn(compositeAipResponse);
        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(LENDER_CASE_ID);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        CompositeAipResponse aipResponseProcessed = aipService.processApplication(BRAND_NWB, CLIENT_ID, application);

        assertEquals(1, aipResponseProcessed.getPolicies().get(0).getPolicyMessages().size());
        assertEquals(LOAN_MESSAGE, aipResponseProcessed.getPolicies().get(0).getPolicyMessages().get(0).getCode());

        verify(stateService).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService).scoringCheck(application);
        verify(stateService).captureApplicationState(BRAND_NWB, application, scoringResponse);
        verify(caseService).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(stateService).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(responseService).generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService).captureApplicationState(any(String.class), eq(application), anyList());
    }

    @Test
    void testProcessApplicationForNewApplication() throws IOException {

        Application application = Application.builder()
                .loanPurpose(LoanPurpose.BUY_TO_LET)
                .formInfo(getFormInfo())
                .mortgage(Mortgage.builder().productType(ProductType.TWO_YEARS).buyToLet(BuyToLet.builder().icrTaxRate(IcrTaxRate.ICR_HIGH).build()).build())
                .property(Property.builder().termRemaining(150).build())
                .applicants(Collections.singletonList(Applicant.builder()
                        .existingMortgage(ExistingMortgage.builder().build()).expenditure(Expenditure.builder().mortgageRent(new BigDecimal(500)).build())
                        .addresses(Collections.singletonList(Address.builder().build())).build())).build();

        ScoringResponse scoringResponse = ScoringResponse.builder().lenderCaseId(LENDER_CASE_ID).equifaxResponseDetails(Lists.newArrayList(new EquifaxResponseDetails())).build();
        ScoringResponseGenerationRequest scoringResponseGenerationRequest = new ScoringResponseGenerationRequest();

        AipResponse aipResponse = AipResponse.builder().build();
        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder()
                        .policyMessages(Arrays.asList(Policy.builder().code(LOAN_MESSAGE).message("Maximum lend 500K").build())).build())).build();
        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(LENDER_CASE_ID);
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, ScoringResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB)).thenReturn(aipResponse);
        when(compositeAipResponseMapper.toCompositeAipResponse(aipResponse)).thenReturn(compositeAipResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipService.processApplication(BRAND_NWB, CLIENT_ID, application);

        assertEquals(LENDER_CASE_ID, application.getLenderCaseId());
        assertEquals(Integer.valueOf(99), application.getProperty().getTermRemaining());
        application.getApplicants().forEach(applicant -> {
            assertEquals(applicant.getExpenditure().getMortgageRent().intValue(), 0);
        });
        verify(caseService).generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB);
        verify(stateService).captureApplication(BRAND_NWB, application);
        verify(stateService, never()).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService, times(2)).scoringCheck(application);
        verify(stateService, times(2)).captureApplicationState(BRAND_NWB, application, scoringResponse);
        verify(stateService).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(caseService).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(responseService, times(2)).generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService).captureApplicationState(any(String.class), eq(application), anyList());
    }


    @Test
    void processBuyToLetApplicationFor2And5YearsTerm() throws IOException {

        Application application = Application.builder()
                .formInfo(getFormInfo())
                .mortgage(Mortgage.builder().productType(ProductType.TWO_YEARS).buyToLet(BuyToLet.builder().icrTaxRate(IcrTaxRate.ICR_HIGH).build()).build())
                .property(Property.builder().termRemaining(150).build())
                .applicants(Collections.singletonList(Applicant.builder()
                        .addresses(Collections.singletonList(Address.builder().build())).build())).build();

        ScoringResponse scoringResponse = ScoringResponse.builder().lenderCaseId(LENDER_CASE_ID).equifaxResponseDetails(Lists.newArrayList(new EquifaxResponseDetails())).build();
        ScoringResponseGenerationRequest scoringResponseGenerationRequest = new ScoringResponseGenerationRequest();

        AipResponse aipResponse = AipResponse.builder().lenderCaseId(LENDER_CASE_ID).policyMessages(Arrays.asList(Policy.builder().code("RBE0010").build())).build();

        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder()
                        .policyMessages(Arrays.asList(Policy.builder().code("RBE0010").message("Maximum lend 500K").build())).build())).build();

        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(LENDER_CASE_ID);
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, ScoringResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB)).thenReturn(aipResponse);
        when(compositeAipResponseMapper.toCompositeAipResponse(aipResponse)).thenReturn(compositeAipResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipService.processApplication(BRAND_NWB, CLIENT_ID, application);

        assertEquals(LENDER_CASE_ID, application.getLenderCaseId());
        assertEquals(1, aipResponse.getPolicyMessages().size());

        verify(caseService).generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB);
        verify(stateService).captureApplication(BRAND_NWB, application);
        verify(stateService, never()).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService, times(2)).scoringCheck(application);
        verify(stateService, times(2)).captureApplicationState(BRAND_NWB, application, scoringResponse);
        verify(stateService).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(caseService).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(responseService, times(2)).generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService).captureApplicationState(any(String.class), eq(application), anyList());
    }

    @Test
    void processBuyToLetApplicationForOnly2YearTermWhenEquifaxError() throws IOException {

        Application application = Application.builder()
                .formInfo(getFormInfo())
                .mortgage(Mortgage.builder().productType(ProductType.TWO_YEARS).buyToLet(BuyToLet.builder().icrTaxRate(IcrTaxRate.ICR_HIGH).build()).build())
                .property(Property.builder().termRemaining(150).build())
                .applicants(Collections.singletonList(Applicant.builder().addresses(Collections.singletonList(Address.builder().build())).build())).build();

        ScoringResponse scoringResponse = ScoringResponse.builder().lenderCaseId(LENDER_CASE_ID)
                .equifaxResponseDetails(Arrays.asList(EquifaxResponseDetails.builder().responseCode(BUREAU_ERROR).build())).build();

        ScoringResponseGenerationRequest scoringResponseGenerationRequest = new ScoringResponseGenerationRequest();

        AipResponse aipResponse = AipResponse.builder().lenderCaseId(LENDER_CASE_ID).policyMessages(Arrays.asList(Policy.builder().code(LOAN_MESSAGE).build())).build();

        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder().policyMessages(Arrays.asList(Policy.builder().build())).build())).build();

        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(LENDER_CASE_ID);
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, ScoringResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB)).thenReturn(aipResponse);
        when(compositeAipResponseMapper.toCompositeAipResponse(aipResponse)).thenReturn(compositeAipResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipService.processApplication(BRAND_NWB, CLIENT_ID, application);

        assertEquals(LENDER_CASE_ID, application.getLenderCaseId());
        assertEquals(1, aipResponse.getPolicyMessages().size());

        verify(caseService).generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB);
        verify(stateService).captureApplication(BRAND_NWB, application);
        verify(stateService, never()).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService, times(2)).scoringCheck(application);
        verify(stateService, times(2)).captureApplicationState(BRAND_NWB, application, scoringResponse);
        verify(stateService).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(caseService).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(responseService, times(2)).generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService).captureApplicationState(any(String.class), eq(application), anyList());
    }

    @Test
    void throwInvalidCaseIdExceptionForNewApplicationWhenCaseIDIsNull() throws IOException {

        Application application = Application.builder().formInfo(getFormInfo()).build();
        ScoringResponse scoringResponse = new ScoringResponse();
        ScoringResponseGenerationRequest scoringResponseGenerationRequest = new ScoringResponseGenerationRequest();

        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder().policyMessages(Arrays.asList(Policy.builder().build())).build())).build();
        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(null);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        assertThrows(InvalidCaseIdException.class, () -> aipService.processApplication(BRAND_NWB, CLIENT_ID, application));

        verify(caseService).generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB);
        verify(stateService, never()).captureApplication(BRAND_NWB, application);
        verify(stateService, never()).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService, never()).scoringCheck(application);
        verify(stateService, never()).captureApplicationState(BRAND_NWB, application, scoringResponse);
        verify(stateService, never()).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(caseService, never()).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(responseService, never()).generateAipResponse(scoringResponseGenerationRequest, BRAND_NWB);
        verify(cinMatchService, never()).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService, never()).captureApplicationState(any(String.class), eq(application), anyList());
    }


    @Test
    void throwBureauServiceExceptionForApplicationWhenErrorInScoreCheck() throws IOException {

        Application application = getApplication();
        ScoringResponse scoringResponse = new ScoringResponse();
        AipResponse aipResponse = AipResponse.builder().build();
        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder()
                .policies(Arrays.asList(Scheme.builder()
                        .policyMessages(Arrays.asList(Policy.builder().code(LOAN_MESSAGE).message("Maximum lend 500K").build())).build())).build();

        when(stateService.getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(DECISION_UNIQUE_ID);
        when(scoreService.scoringCheck(application)).thenThrow(HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null));
        when(caseService.generateCaseId(CLIENT_ID, DataFeed.FOCUS.toString(), BRAND_NWB)).thenReturn(LENDER_CASE_ID);
        ErrorResponse errorResponse = ErrorResponse.builder().message("error").build();
        when(objectMapper.readValue("", ErrorResponse.class)).thenReturn(errorResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        assertThrows(BureauServiceException.class, () -> aipService.processApplication(BRAND_NWB, CLIENT_ID, application));

        verify(stateService).getDecisionUniqueId(BRAND_NWB, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(stateService).captureApplicationState(any(String.class), eq(application), scoringResponseArgumentCaptor.capture());
        assertEquals(String.valueOf(HttpStatus.BAD_REQUEST.value()), scoringResponseArgumentCaptor.getValue().getErrorCode());
        assertEquals(String.valueOf(HttpStatus.BAD_REQUEST.value()), scoringResponseArgumentCaptor.getValue().getErrorCode());

        verify(scoreService).scoringCheck(application);
        verify(stateService, never()).updateApplication(BRAND_NWB, application, compositeAipResponse, scoringResponse);
        verify(caseService, never()).trackCase(CLIENT_ID, application, scoringResponse, BRAND_NWB);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(stateService).captureApplicationState(any(String.class), eq(application), anyList());
    }

    @Test
    void testValidateClientIsOnBoardedAndGetClientMethodWhenResponseFromCaseServiceIsValid() {
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn("CP");
        assertEquals(Client.CP, aipService.validateClientIsOnBoardedAndGetClient(CLIENT_ID, BRAND_NWB));
    }

    private Application getApplication() {
        return Application.builder().lenderCaseId(LENDER_CASE_ID)
                .formInfo(getFormInfo()).intermediary(Intermediary.builder().postcode("S050 5SU").build())
                .mortgage(Mortgage.builder().productType(ProductType.TWO_YEARS).buyToLet(BuyToLet.builder().icrTaxRate(IcrTaxRate.ICR_HIGH).build()).build())
                .property(Property.builder().termRemaining(150).build())
                .applicants(Collections.singletonList(Applicant.builder()
                        .addresses(Collections.singletonList(Address.builder().postcode("GU21 3HX").build())).build())).build();
    }

    private FormInfo getFormInfo() {
        return FormInfo.builder()
                .brand(Brand.RBS)
                .dataFeed(DataFeed.FOCUS).build();
    }

    private CinResponse getCinResponse(String cin, Applicant applicant, boolean vMarker) {
        return CinResponse.builder().cin(Objects.isNull(cin) ? Collections.EMPTY_LIST : Collections.singletonList(cin))
                .applicant(applicant)
                .build();
    }

}
