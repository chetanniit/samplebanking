package com.natwest.pbbdhb.aip.unit.controller;

import com.natwest.pbbdhb.aip.controller.AipController;
import com.natwest.pbbdhb.aip.unit.integ.controller.BaseEndToEndTest;
import com.natwest.pbbdhb.aip.exception.InvalidCaseIdException;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.FormInfo;
import com.natwest.pbbdhb.aip.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.service.CaseService;
import org.junit.Ignore;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@SpringBootTest
@TestInstance(PER_CLASS)
@ExtendWith(SpringExtension.class)
class AipControllerTest extends BaseEndToEndTest {

    @Autowired
    AipController aipController;

    @MockBean
    CaseService caseService;

    @Ignore
    void should_throw_InvalidCaseIdException_when_caseid_is_not_generated() {

        String clientId = "123456789";
        String brand = "nwb";
        when(caseService.generateCaseId(clientId, eq(DataFeed.FOCUS.toString()),brand)).thenReturn(null);

        assertThrows(InvalidCaseIdException.class, () -> {
            aipController.aipCheck(brand, clientId, Application.builder().serviceRequired("AIP")
                    .formInfo(FormInfo.builder().dataFeed(DataFeed.FOCUS).build()).build());
        });
    }

}