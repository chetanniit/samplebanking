package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.FormInfo;
import com.natwest.pbbdhb.aip.model.casemgmt.AipCaseType;
import com.natwest.pbbdhb.aip.model.casemgmt.AipDecision;
import com.natwest.pbbdhb.aip.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.model.casemgmt.CaseStatus;
import com.natwest.pbbdhb.aip.model.casemgmt.CaseSummary;
import com.natwest.pbbdhb.aip.model.casemgmt.ClientDetails;
import com.natwest.pbbdhb.aip.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.aip.utils.AppUtil.applicationHeaders;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class CaseServiceImplTest {

    private static final String CASE_ID_URL = "http://localhost:8080/mortgages/v1/msvc-case-management/generateCaseId";
    private static final String CREATE_CASE_URL = "http://localhost:8080/mortgages/v1/msvc-case-management/case";
    private static final String CREATE_CASE_SUMMARY_URL = "http://localhost:8080/mortgages/v1/msvc-case-management/caseSummary";
    private static final String CLIENT_DETAILS_END_POINT = "http://localhost:8080/mortgages/v1/msvc-case-management/getClientDetails?clientId={clientId}";

    private static final String DECISION = "accept";
    private static final String LENDER_CADE_ID = "OY1620819996381";
    private static final String CLIENT_ID = "clientId";
    private static final String CASE_ID_PREFIX = "_1";

    @InjectMocks
    private CaseServiceImpl caseService;

    @Mock
    private RestTemplate restTemplate;

    @Captor
    private ArgumentCaptor<HttpEntity> caseSummaryArgumentCaptor;

    @Captor
    private ArgumentCaptor<HttpEntity> trackedApplicationCaptor;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(caseService, "caseIdGenerationEndPoint", CASE_ID_URL, String.class);
        ReflectionTestUtils.setField(caseService, "caseTrackingEndPoint", CREATE_CASE_URL, String.class);
        ReflectionTestUtils.setField(caseService, "createCaseSummaryEndPoint", CREATE_CASE_SUMMARY_URL, String.class);
        ReflectionTestUtils.setField(caseService, "fetchClientDetailsPoint", CLIENT_DETAILS_END_POINT, String.class);
    }

    @Test
    void testGenerateCaseId() {

        String brand = "nwb";
        String expectedCaseId = "F1611656326488";
        ResponseEntity<String> responseEntity = new ResponseEntity<>(expectedCaseId, HttpStatus.OK);
        when(restTemplate.exchange(CASE_ID_URL, HttpMethod.GET, new HttpEntity<>(applicationHeaders(brand)), String.class, CASE_ID_PREFIX, CLIENT_ID)).thenReturn(responseEntity);
        String actualCaseId = caseService.generateCaseId(CLIENT_ID, CASE_ID_PREFIX, brand);
        assertEquals(expectedCaseId, actualCaseId);
        verify(restTemplate).exchange(CASE_ID_URL, HttpMethod.GET, new HttpEntity(applicationHeaders(brand)), String.class, CASE_ID_PREFIX, CLIENT_ID);

    }

    @Test
    void trackFocusApplicationWithCaseService() {
        String brand = "nwb";
        when(restTemplate.exchange(eq(CREATE_CASE_URL), eq(HttpMethod.PUT), trackedApplicationCaptor.capture(), eq(Case.class), eq(LENDER_CADE_ID)))
                .thenReturn(new ResponseEntity<>(new Case(), HttpStatus.OK));

        caseService.trackCase(CLIENT_ID, getApplication(DataFeed.FOCUS), ScoringResponse.builder().decision(DECISION).build(), brand);

        verify(restTemplate).exchange(eq(CREATE_CASE_URL), eq(HttpMethod.PUT), trackedApplicationCaptor.capture(), eq(Case.class), eq(LENDER_CADE_ID));
        final HttpEntity httpEntity = trackedApplicationCaptor.getValue();
        Case caseRequest = (Case) httpEntity.getBody();
        assertEquals(LENDER_CADE_ID, caseRequest.getCaseId());
        assertEquals(DataFeed.FOCUS.name().toUpperCase(), caseRequest.getSource());
        assertEquals(Long.valueOf(AipCaseType.AIP.getId()), caseRequest.getCaseType().getId());

        CaseStatus caseStatusSet = caseRequest.getCaseStatusSet().stream().findFirst().get();
        assertEquals(Long.valueOf(AipDecision.ACCEPT.getId()), caseStatusSet.getDecision().getId());
        assertEquals(Long.valueOf(AipDecision.ACCEPT.getId()), caseStatusSet.getDecisionReason().getId());
        assertEquals(LENDER_CADE_ID, caseRequest.getCaseId());
    }

    @Test
    void createCaseSummaryWhenScoringDecisionIsBlank() {

        String brand = "nwb";
        caseService.createCaseSummary(CLIENT_ID, getApplication(DataFeed.FOCUS), ScoringResponse.builder().build(), brand);

        verify(restTemplate).postForObject(eq(CREATE_CASE_SUMMARY_URL), caseSummaryArgumentCaptor.capture(), eq(Case.class));
        CaseSummary caseRequest = (CaseSummary) caseSummaryArgumentCaptor.getValue().getBody();
        assertEquals(LENDER_CADE_ID, caseRequest.getCaseId());
        assertEquals(DataFeed.FOCUS.name().toUpperCase(), caseRequest.getSource());
        assertEquals(Long.valueOf(AipCaseType.AIP.getId()), caseRequest.getCaseTypeId());

        CaseStatus caseStatusSet = caseRequest.getCaseStatusSet().stream().findFirst().get();
        assertEquals(Long.valueOf(AipDecision.REFER.getId()), caseStatusSet.getDecisionId());
        assertEquals(Long.valueOf(AipDecision.REFER.getId()), caseStatusSet.getDecisionReasonId());
        assertEquals(LENDER_CADE_ID, caseStatusSet.getCaseId());
    }

    @Test
    void updateTrackedApplicationWhenAllDetailsAvailable() {

        String brand = "nwb";
        when(restTemplate.exchange(eq(CREATE_CASE_URL), eq(HttpMethod.PUT), trackedApplicationCaptor.capture(), eq(Case.class), eq(LENDER_CADE_ID)))
                .thenReturn(new ResponseEntity<>(new Case(), HttpStatus.OK));

        caseService.trackCase(CLIENT_ID, getApplication(DataFeed.FOCUS), ScoringResponse.builder().decision(DECISION).build(), brand);

        verify(restTemplate).exchange(eq(CREATE_CASE_URL), eq(HttpMethod.PUT), trackedApplicationCaptor.capture(), eq(Case.class), eq(LENDER_CADE_ID));
        Case caseRequest = (Case) trackedApplicationCaptor.getValue().getBody();
        assertEquals(LENDER_CADE_ID, caseRequest.getCaseId());
        assertEquals(DataFeed.FOCUS.name().toUpperCase(), caseRequest.getSource());
        assertEquals(Long.valueOf(AipCaseType.AIP.getId()), caseRequest.getCaseType().getId());
        assertEquals(AipCaseType.AIP.name(), caseRequest.getCaseType().getType());

        CaseStatus caseStatusSet = caseRequest.getCaseStatusSet().stream().findFirst().get();
        assertEquals(Long.valueOf(AipDecision.ACCEPT.getId()), caseStatusSet.getDecision().getId());
        assertEquals(AipDecision.ACCEPT.name(), caseStatusSet.getDecision().getDecision());
        assertEquals(Long.valueOf(AipDecision.ACCEPT.getId()), caseStatusSet.getDecisionReason().getId());
        assertEquals(AipDecision.ACCEPT.name(), caseStatusSet.getDecisionReason().getDecisionReason());
    }

    @Test
    void updateTrackedApplicationWhenScoringDecisionIsBlank() {

        String brand = "nwb";
        when(restTemplate.exchange(eq(CREATE_CASE_URL), eq(HttpMethod.PUT), trackedApplicationCaptor.capture(), eq(Case.class), eq(LENDER_CADE_ID)))
                .thenReturn(new ResponseEntity<>(new Case(), HttpStatus.OK));

        caseService.trackCase(CLIENT_ID, getApplication(DataFeed.FOCUS), ScoringResponse.builder().build(), brand);

        verify(restTemplate).exchange(eq(CREATE_CASE_URL), eq(HttpMethod.PUT), trackedApplicationCaptor.capture(), eq(Case.class), eq(LENDER_CADE_ID));
        Case caseRequest = (Case) trackedApplicationCaptor.getValue().getBody();
        assertEquals(LENDER_CADE_ID, caseRequest.getCaseId());
        assertEquals(DataFeed.FOCUS.name().toUpperCase(), caseRequest.getSource());
        assertEquals(Long.valueOf(AipCaseType.AIP.getId()), caseRequest.getCaseType().getId());
        assertEquals(AipCaseType.AIP.name(), caseRequest.getCaseType().getType());
        assertNull(caseRequest.getCaseStatusSet());
    }

    @MockBean
    private ResponseEntity<ClientDetails> responseEntityClientDetails;

    @Test
    void testGetNameFromClientIdAndExists() {
        String clientId = "client_id";
        ClientDetails clientDetails = mock(ClientDetails.class);
        when(clientDetails.getName()).thenReturn("CP");
        when(responseEntityClientDetails.getBody()).thenReturn(clientDetails);
        when(restTemplate.exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class), eq(ClientDetails.class), eq(clientId)))
                .thenReturn(responseEntityClientDetails);

        assertEquals("CP", caseService.getNameFromClientId(clientId, "nwb"));
        verify(restTemplate).exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class), eq(ClientDetails.class), eq(clientId));
    }


    @Test
    void testGetNameFromClientIdAndNotExists() {
        String clientId = "client_id";
        when(restTemplate.exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class), eq(ClientDetails.class), eq(clientId)))
                .thenThrow(HttpClientErrorException.NotFound.class);

        assertNull(caseService.getNameFromClientId(clientId, "nwb"));
        verify(restTemplate).exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class), eq(ClientDetails.class), eq(clientId));
    }

    private Application getApplication(DataFeed dataFeed) {
        FormInfo formInfo = FormInfo.builder().dataFeed(dataFeed).build();

        return Application.builder().lenderCaseId(LENDER_CADE_ID).formInfo(formInfo).build();
    }
}
