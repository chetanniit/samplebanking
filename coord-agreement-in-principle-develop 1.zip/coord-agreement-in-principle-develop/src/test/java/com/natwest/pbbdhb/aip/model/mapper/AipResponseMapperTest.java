package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.Policy;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import org.junit.Test;

import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

public class AipResponseMapperTest {

    @Test
    public void mapAipResponse() {

        ScoringResponse scoringResponse = ScoringResponse.builder()
                .decision("REFER")
                .decisionUniqueId("2837353923")
                .lenderCaseId("2020103099981")
                .loanMessage(null)
                .policies(Collections.singletonList(Policy.builder().message("R900 App 1 Address not matched at bureau").build()))
                .errorCode("ERROR-100")
                .errorDescription("Applicant 1 is missing first name")
                .podDecision(null)
                .build();

        AipResponse aipResponse = AipResponseMapper.INSTANCE.toAipResponse(scoringResponse);

        assertThat(aipResponse).isNotNull();
        assertThat(aipResponse.getLenderCaseId()).isEqualTo(scoringResponse.getLenderCaseId());
        assertThat(aipResponse.getDecision()).isEqualTo(scoringResponse.getDecision());
        assertThat(aipResponse.getDecisionUniqueId()).isEqualTo(scoringResponse.getDecisionUniqueId());
        assertIterableEquals(aipResponse.getPolicyMessages(), scoringResponse.getPolicies());
    }

}