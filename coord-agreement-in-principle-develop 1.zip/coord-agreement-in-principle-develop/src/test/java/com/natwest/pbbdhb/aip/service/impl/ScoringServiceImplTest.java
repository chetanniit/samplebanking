package com.natwest.pbbdhb.aip.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.Mortgage;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScoringServiceImplTest {

    private static final String URL = "http://localhost:8080/score";

    @InjectMocks
    private ScoringServiceImpl scoringService;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(scoringService, "scoringEndPoint", URL, String.class);
    }

    @Test
    void testScoringService() throws IOException {

        ObjectMapper om = new ObjectMapper();
        Application application = om.readValue(inputJson(), Application.class);
        application.setMortgage(Mortgage.builder().build());
        application.getMortgage().setMortgageTerm(0);
        application.getMortgage().setInterestOnlyTermYears(null);
        when(restTemplate.postForObject(eq(URL), any(Application.class), eq(ScoringResponse.class))).thenReturn(new ScoringResponse());

        scoringService.scoringCheck(application);

        assertNull(application.getMortgage().getMortgageTermMonths());
        assertNull(application.getMortgage().getInterestOnlyTermMonths());
        verify(restTemplate).postForObject(eq(URL), any(Application.class), eq(ScoringResponse.class));
    }

    @Test
    void defaultMortgageTermsMonthsAndInterestOnlyTermMonthsToZeroIfNull() throws IOException {

        ObjectMapper om = new ObjectMapper();
        Application application = om.readValue(inputJson(), Application.class);
        application.setMortgage(Mortgage.builder().build());
        application.getMortgage().setMortgageTerm(30);
        application.getMortgage().setInterestOnlyTermYears(20);
        when(restTemplate.postForObject(eq(URL), any(Application.class), eq(ScoringResponse.class))).thenReturn(new ScoringResponse());
        assertNull(application.getMortgage().getMortgageTermMonths());
        assertNull(application.getMortgage().getInterestOnlyTermMonths());

        scoringService.scoringCheck(application);

        assertEquals(application.getMortgage().getMortgageTermMonths().intValue(), 0);
        assertEquals(application.getMortgage().getInterestOnlyTermMonths().intValue(), 0);
        verify(restTemplate).postForObject(eq(URL), any(Application.class), eq(ScoringResponse.class));
    }

    private String inputJson() throws IOException {
        return new String(Files.readAllBytes(Paths.get("src", "test", "resources/__files", "aip.json")));
    }
}
