package com.natwest.pbbdhb.aip.unit.integ.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.model.*;
import com.natwest.pbbdhb.aip.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.model.casemgmt.ClientDetails;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.enums.*;
import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.Policy;
import com.natwest.pbbdhb.aip.model.state.AipApplication;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
@EnableConfigurationProperties
@ContextConfiguration(classes = { WireMockConfig.class })
public class AipControllerIT extends BaseEndToEndTest {

    private static final String BRAND = "brand";
    static final String CIN_SEARCH_ENDPOINT = "/mortgages/v1/msvc-core-customer-cin-search/customer-cin/search";
    private static final String SINGLE_MATCH_VERIFIED = "SINGLE-MATCH-VERIFIED";
    private static final String CIN = "5634789367";

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper mapper = new ObjectMapper();

    @Nested
    class CreateAipApplication {

        @Nested
        class AipAccepted {

            @Test
            void aip_request_for_residential_is_accepted_on_valid_request_details() throws Exception {

                givenThatCaseIdIsGenerated(CASE_ID_GENERATION_ENDPOINT);

                givenThatAipDecisionIsReceived(AIP_REQUEST_JSON, "applicationACCEPT.json");

                givenThatAipDecisionIsReceived(AIP_REQUEST_5YEARS_JSON, "applicationACCEPT.json");

                givenThatAipResponseIsGenerated(GENERATE_HBO_AIP_RESPONSE, ACCEPT);

                givenThatAipApplicationIsCreated(CREATE_APPLICATION_ENDPOINT);

                givenCinFoundForApplication();

                givenThatAipApplicationStateIsCreated(ACCEPT);

                givenThatAipApplicationIsUpdated(UPDATE_APPLICATION_ENDPOINT);

                givenThatAipApplicationIsTracked(CREATE_CASE_SUMMARY_ENDPOINT);

                givenThatTrackedAipApplicationIsUpdated(UPDATE_CASE_ENDPOINT);

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("client_id","123456789")
                        .header(BRAND, "nwb")
                        .content(mapper.writeValueAsString(aipRequest(withoutCaseId))))
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.decision").value("ACCEPT"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value("F2020303940"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies.length()").value(2))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies[0].productType").value("Two Years"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies[1].productType").value("Five Years"));
            }

            @Test
            void aip_request_for_BuyToLet_is_accepted_on_valid_request_details() throws Exception {

                givenThatCaseIdIsGenerated(CASE_ID_GENERATION_ENDPOINT);

                givenThatAipDecisionIsReceived(AIP_BUY_TO_LET_REQUEST_JSON, "applicationACCEPT.json");

                givenThatAipDecisionIsReceived(AIP_REQUEST_5YEARS_JSON, "applicationACCEPT.json");

                givenThatAipResponseIsGenerated(GENERATE_HBO_AIP_RESPONSE, ACCEPT);

                givenThatAipApplicationIsCreated(CREATE_APPLICATION_ENDPOINT);

                givenCinFoundForApplication();

                givenThatAipApplicationStateIsCreated(ACCEPT);

                givenThatAipApplicationIsUpdated(UPDATE_APPLICATION_ENDPOINT);

                givenThatAipApplicationIsTracked(CREATE_CASE_SUMMARY_ENDPOINT);

                givenThatTrackedAipApplicationIsUpdated(UPDATE_CASE_ENDPOINT);

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("client_id","123456789")
                        .header(BRAND, "nwb")
                        .content(mapper.writeValueAsString(BuyToLetAipRequest(withoutCaseId))))
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.decision").value("ACCEPT"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value("F2020303940"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies.length()").value(2))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies[0].productType").value("Two Years"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies[1].productType").value("Five Years"));
            }

        }

        @Nested
        class AipDeclined {

            @Test
            void aip_request_is_declined_when_credit_score_is_low() throws Exception {

                givenThatCaseIdIsGenerated(CASE_ID_GENERATION_ENDPOINT);

                givenThatAipDecisionIsReceived(AIP_REQUEST_JSON, "applicationDECLINE.json");

                givenThatAipResponseIsGenerated(GENERATE_HBO_AIP_RESPONSE, DECLINE);

                givenThatAipApplicationIsCreated(CREATE_APPLICATION_ENDPOINT);

                givenThatAipApplicationStateIsCreated(DECLINE);

                givenCinFoundForApplication();

                givenThatAipApplicationIsUpdated(UPDATE_APPLICATION_ENDPOINT);

                givenThatAipApplicationIsTracked(CREATE_CASE_SUMMARY_ENDPOINT);

                givenThatTrackedAipApplicationIsUpdated(UPDATE_CASE_ENDPOINT);

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("client_id","123456789")
                        .header(BRAND, "nwb")
                        .content(mapper.writeValueAsString(aipRequest(withoutCaseId))))
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.decision").value("DECLINE"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value("F2020303940"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies").exists());

            }
        }

        @Nested
        class AipReferred {

            @Test
            void aip_request_is_referred_when_more_details_are_needed() throws Exception {

                givenThatCaseIdIsGenerated(CASE_ID_GENERATION_ENDPOINT);

                givenThatAipDecisionIsReceived(AIP_REQUEST_JSON, "applicationREFER.json");

                givenThatAipResponseIsGenerated(GENERATE_HBO_AIP_RESPONSE, REFER);

                givenThatAipApplicationIsCreated(CREATE_APPLICATION_ENDPOINT);

                givenThatAipApplicationStateIsCreated(REFER);

                givenCinFoundForApplication();

                givenThatAipApplicationIsUpdated(UPDATE_APPLICATION_ENDPOINT);

                givenThatAipApplicationIsTracked(CREATE_CASE_SUMMARY_ENDPOINT);

                givenThatTrackedAipApplicationIsUpdated(UPDATE_CASE_ENDPOINT);

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("client_id","123456789")
                        .header("brand","nwb")
                        .content(mapper.writeValueAsString(aipRequest(withoutCaseId))))
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value("F2020303940"))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policies").exists());
            }
        }
    }


    private void givenThatAipDecisionIsReceived(String aipRequest, String jsonResponse) throws IOException {
        wireMockServer.stubFor(post(SCORING_ENDPOINT)
                .withRequestBody(equalToJson(jsonString(aipRequest)))
                .willReturn(aResponse().withStatus(200)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBodyFile(jsonResponse)));
    }

    private void givenThatAipApplicationIsUpdated(String updateApplicationEndpoint) {
        wireMockServer.stubFor(patch(urlPathEqualTo( updateApplicationEndpoint + "F2020303940"))
                .willReturn(aResponse().withStatus(200)));
    }

    private void givenThatAipApplicationStateIsCreated(String decision) {
        wireMockServer.stubFor(post(CREATE_APPLICATION_STATE_ENDPOINT).willReturn(aResponse().withStatus(200)));
    }

    private void givenThatAipApplicationIsCreated(String createApplicationEndpoint) {
        wireMockServer.stubFor(post(createApplicationEndpoint).willReturn(aResponse().withStatus(200)));
    }

    private void givenCinFoundForApplication() throws JsonProcessingException {
        wireMockServer.stubFor(post(CIN_SEARCH_ENDPOINT)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(CinResponse.builder().cin(Lists.newArrayList(CIN)).cinMatchIndicator(SINGLE_MATCH_VERIFIED).build()))));
    }

    private void givenThatCaseIdIsGenerated(String generateCaseIdEndpoint) {
        String params="?caseIdPrefix="+DataFeed.FOCUS.toString()+"&clientId=123456789";
        wireMockServer.stubFor(get(generateCaseIdEndpoint.concat(params))
                .willReturn(aResponse().withStatus(200).withBody("F2020303940")));
    }

    void givenThatClientDetails(String  clientDetailsEndpoint) throws JsonProcessingException {
        wireMockServer.stubFor(get(urlEqualTo(clientDetailsEndpoint + "?clientId=" + "123456789")).withQueryParam("clientId", equalTo("123456789"))
                .willReturn(aResponse().withStatus(200).withHeader("content-type", "application/json")
                        .withBody(mapper.writeValueAsString(ClientDetails.builder().name("FOCUS").organisation("NatWest").build()))));

    }

    private void givenThatCaseIdIsGeneratedWhileAipUpdate(String generateCaseIdEndpoint) {
        String params="?caseIdPrefix="+DataFeed.FOCUS.toString()+"&clientId=123456789";
        wireMockServer.stubFor(get(generateCaseIdEndpoint.concat(params))
                .willReturn(aResponse().withStatus(200).withBody("F3020303950")));
    }

    private void givenThatDecisionUniqueIdIsFetched(String getApplicationEndpoint) throws JsonProcessingException {
        getApplicationEndpoint = getApplicationEndpoint.concat(ApplicationStage.AIP.name()).concat("/F2020303940");

        wireMockServer.stubFor(get(getApplicationEndpoint)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(AipApplication.builder().caseId("2020303940").build()))));
    }

    private void givenThatAipApplicationIsTracked(String createCaseSummaryEndpoint) throws JsonProcessingException {
        wireMockServer.stubFor(post(createCaseSummaryEndpoint)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(Case.builder().caseId("F2020303940").build()))));
    }

    private void givenThatTrackedAipApplicationIsUpdated(String updateCaseEndpoint) throws JsonProcessingException {
        wireMockServer.stubFor(put(updateCaseEndpoint.concat("F2020303940"))
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(Case.builder().caseId("F2020303940").build()))));
    }

    private void givenThatAipResponseIsGenerated(String generateAipResponse, String decision) throws JsonProcessingException {
        wireMockServer.stubFor(post(generateAipResponse).willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                .withBody(mapper.writeValueAsString(aipResponse("F2020303940", decision)))));
    }

    private Application aipRequest(String caseId) {
        return Application.builder().serviceRequired("SCORE").numberOfApplicants(1).lenderCaseId(caseId)
                .formInfo(FormInfo.builder().dataFeed(DataFeed.FOCUS).applicationStage(ApplicationStage.AIP).brand(Brand.RBS).build())
                .intermediary(Intermediary.builder().postcode("S050 5SU").build())
                .applicants(Collections.singletonList(Applicant.builder().personalDetails(PersonalDetails.builder().firstNames("SAMATHA").lastName("LINCOLN").dateOfBirth(LocalDate.parse("1982-04-01")).build()).addresses(Collections.singletonList(Address.builder().postcode("GU21 3HX").houseNumber("3").isCurrentAddress(true).build())).build()))
                .mortgage(Mortgage.builder().build())
                .loanPurpose(LoanPurpose.RESIDENTIAL_PURCHASE)
                .build();
    }

    private Application BuyToLetAipRequest(String caseId) {
        Application application = aipRequest(caseId);
        BuyToLet buyToLet = BuyToLet.builder().icrTaxRate(IcrTaxRate.ICR_HIGH).build();
        application.setMortgage(Mortgage.builder().buyToLet(buyToLet).build());
        application.setLoanPurpose(LoanPurpose.BUY_TO_LET_PURCHASE);

        return application;
    }


    private AipResponse aipResponse(String caseId, String decision) {
        return AipResponse.builder().lenderCaseId(caseId).decision(decision)
                .policyMessages(Collections.singletonList(Policy.builder().message("R435 Level of indebtedness requires UW review").code("R435").build())).build();
    }

}
