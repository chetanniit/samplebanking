package com.natwest.pbbdhb.aip.model.mapper;

import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.FormInfo;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.model.state.AipApplication;
import com.natwest.pbbdhb.aip.model.state.AipApplicationState;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.assertj.core.api.Assertions.assertThat;

public class AipApplicationStateMapperTest {

    @Test
    public void toRiskApplicationRequest() {
        Application application = Application.builder().lenderCaseId("2020103099981").numberOfApplicants(2).serviceRequired("AIP").
                formInfo(FormInfo.builder().dataFeed(DataFeed.FOCUS).applicationStage(ApplicationStage.AIP).build()).build();

        AipApplication riskApplicationRequest = AipApplicationStateMapper.INSTANCE.toApplicationRequest(application,"request");

        assertThat(riskApplicationRequest).isNotNull();
        assertThat(application.getLenderCaseId()).isEqualTo(riskApplicationRequest.getCaseId());
        assertThat(application.getNumberOfApplicants()).isEqualTo(riskApplicationRequest.getNumberOfApplicants());
        assertThat(application.getFormInfo().getApplicationStage().name()).isEqualTo(riskApplicationRequest.getStage());
        assertThat(application.getFormInfo().getDataFeed().name()).isEqualTo(riskApplicationRequest.getChannel());
        assertThat("request").isEqualTo(riskApplicationRequest.getRequest());
    }

    @Test
    void toRiskApplicationStateRequest() {

        ScoringResponse scoringResponse = ScoringResponse.builder()
                .decision("REFER")
                .decisionUniqueId("2837353923")
                .lenderCaseId("2020103099981")
                .build();

        Application application = Application.builder().lenderCaseId("2020103099981").numberOfApplicants(2).serviceRequired("AIP").
                formInfo(FormInfo.builder().dataFeed(DataFeed.FOCUS).applicationStage(ApplicationStage.AIP).build()).build();

        AipApplicationState aipApplicationState = AipApplicationStateMapper.INSTANCE.toApplicationStateRequest(application, scoringResponse,"request","response");

        assertThat(aipApplicationState).isNotNull();
        assertThat(scoringResponse.getLenderCaseId()).isEqualTo(aipApplicationState.getCaseId());
        assertThat(scoringResponse.getDecision()).isEqualTo(aipApplicationState.getDecision());
        assertThat(scoringResponse.getDecisionUniqueId()).isEqualTo(aipApplicationState.getDecisionUniqueId());
        assertThat(application.getFormInfo().getApplicationStage().name()).isEqualTo(aipApplicationState.getStage());
        assertThat("SCORE").isEqualTo(aipApplicationState.getApplicationStep());
        assertThat("request").isEqualTo(aipApplicationState.getRequest());
        assertThat(String.valueOf(HttpStatus.OK.value())).isEqualTo(aipApplicationState.getHttpStatus());
    }

}