package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.Address;
import com.natwest.pbbdhb.aip.model.Applicant;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.cin.CinResponse;
import com.natwest.pbbdhb.aip.model.cin.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.model.enums.Client;
import com.natwest.pbbdhb.aip.model.mapper.CustomerSearchMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.natwest.pbbdhb.aip.utils.AppUtil.BRAND_NWB;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@MockitoSettings(strictness = Strictness.WARN)
@ExtendWith(MockitoExtension.class)
class CinMatchServiceImplTest {

    private static final String CIN = "7823489043";
    private static final String FIRST_NAME = "SIMON";
    private static final String LAST_NAME = "BELL";
    private static final String LENDER_CASE_ID = "2345435";
    private static final String URL = "http://localhost:8081/cin-match";
    private static final String SINGLE_MATCH_VERIFIED = "SINGLE-MATCH-VERIFIED";

    @InjectMocks
    private CinMatchServiceImpl cinMatchServiceImpl;

    @Mock
    private CustomerSearchMapper customerSearchMapper;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(cinMatchServiceImpl, "cinSearchURL", URL, String.class);
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(customerSearchMapper, restTemplate);
    }

    @Test
    void testCinSearchWhenCinExistsAndUkAddressIsTrue() {
        Application application = getApplication();
        application.getApplicants().get(0).setCin(CIN);
        when(customerSearchMapper.toCustomerSearchRequest(application.getApplicants().get(1), Client.FOCUS.toString(), LENDER_CASE_ID)).thenReturn(buildCustomerSearchRequest());
        when(restTemplate.postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))).thenReturn(new ResponseEntity<>(buildCinResponse(), HttpStatus.OK));

        List<CinResponse> actualResponse = cinMatchServiceImpl.cinSearch(application, BRAND_NWB, Client.FOCUS);

        assertAll(
                () -> assertEquals(1, actualResponse.size()),
                () -> assertEquals(CIN, actualResponse.get(0).getCin().get(0)),
                () -> verify(customerSearchMapper).toCustomerSearchRequest(any(Applicant.class), eq(Client.FOCUS.toString()), eq(LENDER_CASE_ID)),
                () -> verify(restTemplate).postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))
        );
    }

    @Test
    void testCinSearch() {
        Application application = getApplication();
        when(customerSearchMapper.toCustomerSearchRequest(application.getApplicants().get(0), Client.FOCUS.toString(), LENDER_CASE_ID)).thenReturn(buildCustomerSearchRequest());
        when(customerSearchMapper.toCustomerSearchRequest(application.getApplicants().get(1), Client.FOCUS.toString(), LENDER_CASE_ID)).thenReturn(buildCustomerSearchRequest());
        when(restTemplate.postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))).thenReturn(new ResponseEntity<>(buildCinResponse(), HttpStatus.OK));

        List<CinResponse> actualResponse = cinMatchServiceImpl.cinSearch(application, BRAND_NWB, Client.FOCUS);

        assertAll(
                () -> assertEquals(2, actualResponse.size()),
                () -> assertEquals(CIN, actualResponse.get(0).getCin().get(0)),
                () -> assertEquals(CIN, actualResponse.get(1).getCin().get(0)),
                () -> assertEquals(CIN, actualResponse.get(1).getApplicant().getCin()),
                () -> verify(customerSearchMapper, times(2)).toCustomerSearchRequest(any(Applicant.class), eq(Client.FOCUS.toString()), eq(LENDER_CASE_ID)),
                () -> verify(restTemplate, times(2)).postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))
        );
    }

    @Test
    void testCinSearchWithException() {
        Application application = getApplication();
        when(customerSearchMapper.toCustomerSearchRequest(application.getApplicants().get(0), Client.FOCUS.toString(), LENDER_CASE_ID)).thenReturn(buildCustomerSearchRequest());
        when(customerSearchMapper.toCustomerSearchRequest(application.getApplicants().get(1), Client.FOCUS.toString(), LENDER_CASE_ID)).thenReturn(buildCustomerSearchRequest());
        when(restTemplate.postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))).thenThrow(new RestClientException("Rest Exception"));

        List<CinResponse> actualResponse = cinMatchServiceImpl.cinSearch(application, BRAND_NWB, Client.FOCUS);

        assertAll(
                () -> assertEquals(2, actualResponse.size()),
                () -> assertTrue(actualResponse.get(0).getCin().isEmpty()),
                () -> assertTrue(actualResponse.get(1).getCin().isEmpty()),
                () -> verify(customerSearchMapper, times(2)).toCustomerSearchRequest(any(Applicant.class), eq(Client.FOCUS.toString()), eq(LENDER_CASE_ID)),
                () -> verify(restTemplate, times(2)).postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))
        );
    }

    @Test
    void testCinSearchWhenUkAddressIsFalse() {
        Application application = getApplication();
        application.setApplicants(Collections.singletonList(getApplicant(false)));
        when(customerSearchMapper.toCustomerSearchRequest(application.getApplicants().get(0), Client.FOCUS.toString(), LENDER_CASE_ID)).thenReturn(buildCustomerSearchRequest());
        when(restTemplate.postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))).thenReturn(new ResponseEntity<>(buildCinResponse(), HttpStatus.OK));

        List<CinResponse> actualResponse = cinMatchServiceImpl.cinSearch(application, BRAND_NWB, Client.FOCUS);

        assertAll(
                () -> assertEquals(CIN, actualResponse.get(0).getCin().get(0)),
                () -> assertEquals(CIN, actualResponse.get(0).getApplicant().getCin()),
                () -> verify(customerSearchMapper).toCustomerSearchRequest(any(Applicant.class), eq(Client.FOCUS.toString()), eq(LENDER_CASE_ID)),
                () -> verify(restTemplate).postForEntity(eq(URL), any(HttpEntity.class), eq(CinResponse.class))
        );
    }

    private CinResponse buildCinResponse() {
        return CinResponse.builder().cin(Collections.singletonList(CIN)).cinMatchIndicator(SINGLE_MATCH_VERIFIED).build();
    }

    private CustomerSearchRequest buildCustomerSearchRequest() {
        return CustomerSearchRequest.builder().firstName(FIRST_NAME).lastName(LAST_NAME).build();
    }

    private Application getApplication() {
        return Application.builder().lenderCaseId(LENDER_CASE_ID).numberOfApplicants(2)
                .applicants(getApplicants())
                .build();
    }

    private List<Applicant> getApplicants() {
       return Arrays.asList(getApplicant(false), getApplicant(true));
    }

    private Applicant getApplicant(boolean ukAddress) {
        List<Address> addresses = Collections.singletonList(Address.builder().ukAddress(ukAddress).isCurrentAddress(true).postcode("CR0 2GE").build());
        return Applicant.builder().addresses(addresses).build();
    }
}
