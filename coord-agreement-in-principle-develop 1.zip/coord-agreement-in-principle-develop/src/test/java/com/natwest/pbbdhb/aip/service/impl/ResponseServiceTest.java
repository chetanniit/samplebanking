package com.natwest.pbbdhb.aip.service.impl;

import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.ScoringResponseGenerationRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ResponseServiceTest {

    private static final String URL = "http://localhost:8080/score";

    @InjectMocks
    private ResponseServiceImpl responseService;

    @Mock
    private RestTemplate restTemplate;


    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(responseService, "responseGenerationEndPoint", URL, String.class);
    }

    @Test
    void testGenerateAipResponse() {
        String brand = "nwb";
        when(restTemplate.postForObject(eq(URL), any(HttpEntity.class), eq(AipResponse.class))).thenReturn(new AipResponse());

        responseService.generateAipResponse(ScoringResponseGenerationRequest.builder().build(), brand);

        verify(restTemplate).postForObject(eq(URL), any(HttpEntity.class), eq(AipResponse.class));
    }
}
