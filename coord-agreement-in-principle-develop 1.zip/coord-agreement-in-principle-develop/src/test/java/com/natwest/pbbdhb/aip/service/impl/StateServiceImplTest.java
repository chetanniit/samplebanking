package com.natwest.pbbdhb.aip.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.model.Application;
import com.natwest.pbbdhb.aip.model.FormInfo;
import com.natwest.pbbdhb.aip.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.model.enums.Brand;
import com.natwest.pbbdhb.aip.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.model.mapper.AipApplicationStateMapper;
import com.natwest.pbbdhb.aip.model.mapper.CompositeAipResponseMapper;
import com.natwest.pbbdhb.aip.model.response.AipResponse;
import com.natwest.pbbdhb.aip.model.response.CompositeAipResponse;
import com.natwest.pbbdhb.aip.model.response.Policy;
import com.natwest.pbbdhb.aip.model.response.Scheme;
import com.natwest.pbbdhb.aip.model.response.ScoringResponse;
import com.natwest.pbbdhb.aip.model.state.AipApplication;
import com.natwest.pbbdhb.aip.model.state.AipApplicationState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class StateServiceImplTest {

    private static final String CREATE_APPICATION_URL = "http://localhost:8081/create/application";
    private static final String UPDATE_APPICATION_URL = "http://localhost:8081/update/application";
    private static final String CREATE_APPICATION_STATE_END_POINT_URL = "http://localhost:8081/create/stateapplication";
    private static final String RETRIEVE_APPICATION_URL = "http://localhost:8081/get/application";
    private static final String LENDER_ID = "lenderId";
    private static final String DECISION_UNIQUE_ID = "decision unique id";
    private static final String DECISION = "decision";
    private static final String RESPOSNE = "response";
    private static final String brand = "nwb";

    @Mock
    private RestTemplate restTemplate;

    @Mock(name = "objectMapper")
    private ObjectMapper objectMapper;

    @Mock(name = "objectMapperOrganic")
    private ObjectMapper objectMapperOrganic;

    @Mock
    private AipApplicationStateMapper riskAppStateMapper;

    @InjectMocks
    private StateServiceImpl stateService;

    @Captor
    private ArgumentCaptor<HttpEntity> aipApplicationArgumentCaptor;

    @Mock
    private CompositeAipResponseMapper compositeAipResponseMapper;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(stateService, "createApplicationEndPoint", CREATE_APPICATION_URL, String.class);
        ReflectionTestUtils.setField(stateService, "createApplicationStateEndPoint", CREATE_APPICATION_STATE_END_POINT_URL, String.class);
        ReflectionTestUtils.setField(stateService, "updateApplicationEndPoint", UPDATE_APPICATION_URL, String.class);
        ReflectionTestUtils.setField(stateService, "retrieveApplicationEndPoint", RETRIEVE_APPICATION_URL, String.class);
    }

    @Test
    void testCaptureApplication() throws JsonProcessingException {
        String brand = "nwb";
        AipApplication aipToFmaApplication = AipApplication.builder().build();
        Application application = buildApplication();
        when(riskAppStateMapper.toApplicationRequest(application, "request")).thenReturn(aipToFmaApplication);

        stateService.captureApplication(brand, application);

        verify(restTemplate).postForObject(eq(CREATE_APPICATION_URL), any(HttpEntity.class), eq(HttpStatus.class));
    }

    @Test
    void updateApplicationOnSuccessfulScoreResponse() throws JsonProcessingException {

        ScoringResponse scoringResponse = ScoringResponse.builder().decision("ACCEPT").decisionUniqueId(DECISION_UNIQUE_ID).build();
        AipResponse aipResponse = AipResponse.builder().decision(DECISION).lenderCaseId(LENDER_ID).build();
        CompositeAipResponse compositeAipResponse = CompositeAipResponse.builder().decision(DECISION).lenderCaseId(LENDER_ID)
                .policies(Arrays.asList(Scheme.builder().policyMessages(Arrays.asList(Policy.builder().build())).build())).build();

        when(objectMapper.writeValueAsString(compositeAipResponse)).thenReturn(RESPOSNE);
        when(compositeAipResponseMapper.toCompositeAipResponse(aipResponse)).thenReturn(compositeAipResponse);

        stateService.updateApplication(brand, buildApplication(), compositeAipResponse, scoringResponse);

        verify(restTemplate).patchForObject(eq(UPDATE_APPICATION_URL), aipApplicationArgumentCaptor.capture(), eq(HttpStatus.class), eq(LENDER_ID), eq(ApplicationStage.AIP));
        AipApplication aipApplication = (AipApplication) aipApplicationArgumentCaptor.getValue().getBody();

        assertEquals(DECISION, aipApplication.getDecision());
        assertEquals(DECISION_UNIQUE_ID, aipApplication.getDecisionUniqueId());
        assertEquals(RESPOSNE, aipApplication.getResponse());
        verify(objectMapper).writeValueAsString(compositeAipResponse);
    }

    @Test
    void testCaptureApplicationState() throws JsonProcessingException {
        String brand = "nwb";
        ScoringResponse scoringResponse = new ScoringResponse();
        AipApplicationState aipApplicationState = AipApplicationState.builder().build();
        when(riskAppStateMapper.toApplicationStateRequest(buildApplication(), scoringResponse, "request", "response")).thenReturn(aipApplicationState);

        stateService.captureApplicationState(brand, buildApplication(), scoringResponse);

        verify(objectMapper).writeValueAsString(any(Application.class));
        verify(objectMapper).writeValueAsString(any(ScoringResponse.class));
        verify(restTemplate).postForObject(eq(CREATE_APPICATION_STATE_END_POINT_URL), any(HttpEntity.class), eq(HttpStatus.class));
    }

    @Test
    void testDecisionUniqueId() {
        String brand = "nwb";
        when(restTemplate.exchange(eq(RETRIEVE_APPICATION_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(AipApplication.class), eq(ApplicationStage.AIP), eq(LENDER_ID)))
                .thenReturn(new ResponseEntity<>(AipApplication.builder().decisionUniqueId(DECISION_UNIQUE_ID).build(), HttpStatus.OK));

        String decision = stateService.getDecisionUniqueId(brand, LENDER_ID, ApplicationStage.AIP);

        assertEquals(decision, DECISION_UNIQUE_ID);
        verify(restTemplate).exchange(eq(RETRIEVE_APPICATION_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(AipApplication.class), eq(ApplicationStage.AIP), eq(LENDER_ID));
    }

    private Application buildApplication() {
        return Application.builder()
                .formInfo(getFormInfo()).build();
    }

    private FormInfo getFormInfo() {
        return FormInfo.builder()
                .brand(Brand.RBS)
                .dataFeed(DataFeed.FOCUS).build();
    }
}
