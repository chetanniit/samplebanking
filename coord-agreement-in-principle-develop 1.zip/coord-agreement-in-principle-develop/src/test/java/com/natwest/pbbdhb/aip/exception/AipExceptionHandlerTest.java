package com.natwest.pbbdhb.aip.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.io.IOException;
import java.lang.reflect.Executable;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AipExceptionHandlerTest {
    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private HttpClientErrorException httpClientErrorException;

    @Mock
    private HttpMessageNotReadableException httpMessageNotReadableException;

    @Mock
    private RuntimeException runtimeException;

    @Mock
    private MethodArgumentNotValidException methodArgumentNotValidException;

    @Mock
    private BureauServiceException bureauServiceException;

    @Mock
    private NoHandlerFoundException noHandlerFoundException;

    @Mock
    private InvalidFormatException invalidFormatException;

    @Mock
    private ErrorResponse errorResponse;

    @Mock
    private Throwable throwable;

    @Mock
    private BindingResult bindingResult;

    @Mock
    private MethodParameter methodParameter;

    @Mock
    private FieldError fieldError;

    @InjectMocks
    private AipExceptionHandler aipExceptionHandler;

    private Fixture fixture;

    @Before
    public void setup() {
        fixture = new Fixture();
    }

    @Test
    public void handleHttpClientErrorException_httpClientErrorException_returnsCorrectResponse() throws IOException {
        fixture.givenObjectMapperReturnsErrorResponse();
        fixture.whenHandleHttpClientErrorExceptionIsCalled();
        fixture.assertHttpClientErrorExceptionResponseValues();
    }

    @Test
    public void handleBadRequest_runtimeException_returnsCorrectResponse() {
        fixture.givenRuntimeExceptionHasMessage();
        fixture.whenHandleBadRequestExceptionRuntimeExceptionIsCalled();
        fixture.assertHandleBadRequestRuntimeExceptionResponse();
    }

    @Test
    public void handleBadRequest_HttpMessageNotReadableException_returnsCorrectResponse() {
        fixture.givenHttpMessageNotReadableExceptionHasCorrectValues();
        fixture.whenHandlebadRequestExceptionIsCalled();
        fixture.assertHandleBadRequestHttpMessageNotReadableExceptionResponse();
    }

    @Test
    public void handleRuntimeException_runtimeException_returnsCorrectResponse() {
        fixture.givenRuntimeExceptionHasMessage();
        fixture.whenHandleRuntimeExceptionIsCalled();
        fixture.assertHandleRuntimeException();
    }

    @Test
    public void handleBureauServiceException_bureauServiceException_returnsCorrectResponse() {
        fixture.givenBureauServiceExceptionHasCorrectValues();
        fixture.whenHandleBureauServiceExceptionIsCalled();
        fixture.assertHandleBureauServiceException();
    }

    @Test
    public void noHandlerFoundException_noHandlerFoundException_returnsCorrectResponse() {
        fixture.givenNoHandlerFoundExceptionCorrectValues();
        fixture.whenNoHandlerFoundException();
        fixture.assertNoHandlerFoundResponse();
    }

    @Test
    public void noHandlerFoundException_invalidFormatException_returnsCorrectResponse() {
        fixture.givenInvalidFormatExceptionCorrectValues();
        fixture.whenNoHandlerFoundInvalidFormatExceptionException();
        fixture.assertNoHandlerFoundInvalidFormatExceptionResponse();
    }



    private class Fixture {
        private static final String RUNTIME_EXCEPTION_MESSAGE = "RuntimeExceptionMessage";
        private static final String THROWABLE_MESSAGE = "ThrowableMessage";
        private static final String BUREAU_SERVICE_EXCEPTION_MESSAGE = "BureauServiceExceptionMessage";

        private ResponseEntity<ErrorResponse> handleHttpClientErrorExceptionResponse;
        private ResponseEntity<ErrorResponse> handleBadRequestExceptionRuntimeExceptionResponse;
        private ResponseEntity<ErrorResponse> handleBadRequestExceptionHttpMessageNotReadableExceptionResponse;
        private ResponseEntity<ErrorResponse> handleRuntimeExceptionResponse;
        private ResponseEntity<ErrorResponse> handleBureauServiceExceptionResponse;
        private ResponseEntity<HttpStatus> noHandlerFoundExceptionResponse;
        private ResponseEntity<HttpStatus> noHandlerFoundInvalidFormatExceptionResponse;
        private ResponseEntity<ErrorResponse> handleMethodArgumentNotValidExceptionResponse;

        private void givenObjectMapperReturnsErrorResponse() throws JsonProcessingException {
            String responseString = "ResponseString";
            when(httpClientErrorException.getResponseBodyAsString()).thenReturn(responseString);
            when(objectMapper.readValue(responseString, ErrorResponse.class)).thenReturn(errorResponse);
        }

        private void givenRuntimeExceptionHasMessage() {
            when(runtimeException.getMessage()).thenReturn(RUNTIME_EXCEPTION_MESSAGE);
        }

        private void givenHttpMessageNotReadableExceptionHasCorrectValues() {
            when(httpMessageNotReadableException.getCause()).thenReturn(throwable);
            when(throwable.getMessage()).thenReturn(THROWABLE_MESSAGE);
        }

        private void givenBureauServiceExceptionHasCorrectValues() {
            when(bureauServiceException.getMessage()).thenReturn(BUREAU_SERVICE_EXCEPTION_MESSAGE);
            when(bureauServiceException.getStatusCode()).thenReturn(HttpStatus.CONFLICT.value() + "");
        }

        private void givenNoHandlerFoundExceptionCorrectValues() {
            when(noHandlerFoundException.getHttpMethod()).thenReturn("GET");
            when(noHandlerFoundException.getRequestURL()).thenReturn("URL");
        }

        private void givenInvalidFormatExceptionCorrectValues() {
            when(invalidFormatException.getValue()).thenReturn("Value");
            when(invalidFormatException.getCause()).thenReturn(throwable);
            when(invalidFormatException.getMessage()).thenReturn("Message");
        }

        private void whenHandleHttpClientErrorExceptionIsCalled() throws IOException {
            handleHttpClientErrorExceptionResponse = aipExceptionHandler.handleHttpClientErrorException(httpClientErrorException);
        }

        private void whenHandlebadRequestExceptionIsCalled() {
            handleBadRequestExceptionHttpMessageNotReadableExceptionResponse = aipExceptionHandler.handleBadRequestException(httpMessageNotReadableException);
        }

        private void whenHandleBadRequestExceptionRuntimeExceptionIsCalled() {
            handleBadRequestExceptionRuntimeExceptionResponse = aipExceptionHandler.handleBadRequestException(runtimeException);
        }

        private void whenHandleMethodArgumentNotValidExceptionIsCalled() {
            handleMethodArgumentNotValidExceptionResponse = aipExceptionHandler.handleMethodArgumentNotValidException(methodArgumentNotValidException);
        }

        private void whenHandleRuntimeExceptionIsCalled() {
            handleRuntimeExceptionResponse = aipExceptionHandler.handleRuntimeException(runtimeException);
        }

        private void whenHandleBureauServiceExceptionIsCalled() {
            handleBureauServiceExceptionResponse = aipExceptionHandler.handleBureauServiceException(bureauServiceException);
        }

        private void whenNoHandlerFoundException() {
            noHandlerFoundExceptionResponse = aipExceptionHandler.noHandlerFoundException(noHandlerFoundException);
        }

        private void whenNoHandlerFoundInvalidFormatExceptionException() {
            noHandlerFoundInvalidFormatExceptionResponse = aipExceptionHandler.noHandlerFoundException(invalidFormatException);
        }

        private void assertHttpClientErrorExceptionResponseValues() {
            assertNotNull(handleHttpClientErrorExceptionResponse);
            assertEquals(HttpStatus.BAD_REQUEST, handleHttpClientErrorExceptionResponse.getStatusCode());
            assertEquals(errorResponse, handleHttpClientErrorExceptionResponse.getBody());
        }

        private void assertHandleBadRequestRuntimeExceptionResponse() {
            assertNotNull(handleBadRequestExceptionRuntimeExceptionResponse);
            assertEquals(HttpStatus.BAD_REQUEST, handleBadRequestExceptionRuntimeExceptionResponse.getStatusCode());
            ErrorResponse body = handleBadRequestExceptionRuntimeExceptionResponse.getBody();
            assertNotNull(body);
            assertEquals(RUNTIME_EXCEPTION_MESSAGE, body.getErrorMessage());
        }

        private void assertHandleBadRequestHttpMessageNotReadableExceptionResponse() {
            assertNotNull(handleBadRequestExceptionHttpMessageNotReadableExceptionResponse);
            assertEquals(HttpStatus.BAD_REQUEST, handleBadRequestExceptionHttpMessageNotReadableExceptionResponse.getStatusCode());
            ErrorResponse body = handleBadRequestExceptionHttpMessageNotReadableExceptionResponse.getBody();
            assertNotNull(body);
            assertEquals(THROWABLE_MESSAGE, body.getErrorMessage());
        }

        private void assertHandleMethodArgumentResponse() {
            assertNotNull(handleMethodArgumentNotValidExceptionResponse);
            assertEquals(HttpStatus.BAD_REQUEST, handleMethodArgumentNotValidExceptionResponse.getStatusCode());
            ErrorResponse body = handleMethodArgumentNotValidExceptionResponse.getBody();
            assertNotNull(body);
            assertEquals("FieldErrorField fieldErrorDefaultMessage,found: fieldErrorRejectedValue ", body.getErrorMessage());
        }

        private void assertHandleRuntimeException() {
            assertNotNull(handleRuntimeExceptionResponse);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, handleRuntimeExceptionResponse.getStatusCode());
            ErrorResponse body = handleRuntimeExceptionResponse.getBody();
            assertNotNull(body);
            assertEquals(RUNTIME_EXCEPTION_MESSAGE, body.getErrorMessage());
        }

        private void assertHandleBureauServiceException() {
            assertNotNull(handleBureauServiceExceptionResponse);
            assertEquals(HttpStatus.CONFLICT, handleBureauServiceExceptionResponse.getStatusCode());
            ErrorResponse body = handleBureauServiceExceptionResponse.getBody();
            assertNotNull(body);
            assertEquals(BUREAU_SERVICE_EXCEPTION_MESSAGE, body.getErrorMessage());
        }

        private void assertNoHandlerFoundResponse() {
            assertNotNull(noHandlerFoundExceptionResponse);
            assertEquals(HttpStatus.NOT_FOUND, noHandlerFoundExceptionResponse.getStatusCode());
        }

        private void assertNoHandlerFoundInvalidFormatExceptionResponse() {
            assertNotNull(noHandlerFoundInvalidFormatExceptionResponse);
            assertEquals(HttpStatus.NOT_FOUND, noHandlerFoundInvalidFormatExceptionResponse.getStatusCode());
        }
    }
}
