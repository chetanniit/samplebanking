package com.natwest.pbbdhb.brokerauth.model.crm.associations.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BrokerAdminDetails {

    @JsonProperty("mbs_brokeradminid")
    private String brokerAdminID;
    @JsonProperty("mbs_username")
    private String userName;
    @JsonProperty("mbs_title")
    private String title;
    @JsonProperty("mbs_firstname")
    private String firstName;
    @JsonProperty("mbs_middlename")
    private String middleName;
    @JsonProperty("mbs_lastname")
    private String lastName;
    @JsonProperty("mbs_brokeradminname")
    private String brokerAdminName;
    @JsonProperty("mbs_emailaddress")
    private String emailAddress;
    @JsonProperty("mbs_fcanumber")
    private String fcaNumber;
    @JsonProperty("mbs_firmname")
    private String firmName;
    @JsonProperty("mbs_principalfcanumber")
    private String principalFCANumber;
}
