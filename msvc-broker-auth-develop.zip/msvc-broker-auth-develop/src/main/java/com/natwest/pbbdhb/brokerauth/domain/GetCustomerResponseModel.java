package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class GetCustomerResponseModel {

  @NonNull
  BrokerTypeModel brokerType;

  @NonNull
  String id;
}
