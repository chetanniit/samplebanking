package com.natwest.pbbdhb.brokerauth.service.signing;

import com.natwest.pbbdhb.brokerauth.domain.JsonWebTokenModel;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import java.security.PrivateKey;
import java.util.UUID;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Service responsible for generating a JWT signed by a private key.
 */
@Service
@Slf4j
public class JwtSigningService {

  // non-standard claims required in our JWT payload
  private final String CLIENT_ID = "client_id";
  private final String BRAND = "brand";
  private final String CHANNEL = "channel";
  private final String DETAILS = "details";

  private final PrivateKey signingKey;

  @Autowired
  public JwtSigningService(
      @Qualifier("jwtSigningKey") PrivateKey signingKey) {
    this.signingKey = signingKey;
  }

  public String createJwt(
      @NonNull JsonWebTokenModel model) {
    return signJwt(
        model.getHeader(),
        createJwtPayload(model.getPayload()));
  }

  private JwtClaims createJwtPayload(
      @NonNull JsonWebTokenModel.PayloadModel payload) {
    log.debug("createJwtPayload: Creating JwtPayload.");
    final JwtClaims claims = new JwtClaims();

    // set expected claims
    claims.setIssuer(payload.getIssuer());
    claims.setSubject(payload.getSubject());
    claims.setAudience(payload.getAudience());
    claims.setIssuedAtToNow();
    claims.setExpirationTimeMinutesInTheFuture(1F);
    claims.setJwtId(UUID.randomUUID().toString());
    claims.setClaim(CLIENT_ID, payload.getClientId());

    // add optional claims
    addCustomClaims(claims, BRAND,
        payload.getBrand() != null ? payload.getBrand().getValue() : null);
    addCustomClaims(claims, CHANNEL, payload.getChannel());
    addCustomClaims(claims, DETAILS, payload.getDetails());

    log.debug("createJwtPayload: JwtPayload, created successfully.");
    return claims;
  }

  private void addCustomClaims(JwtClaims claims, String claimName, Object value) {
    log.debug("addCustomClaims: Adding custom claims.");
    if (value != null) {
      log.debug("addCustomClaims: Custom claims, successfully added.");
      claims.setClaim(claimName, value);
    }
  }

  private String signJwt(
      @NonNull JsonWebTokenModel.HeaderModel header,
      @NonNull JwtClaims payload) {
    log.debug("signJwt: Signing Jwt.");
    try {
      JsonWebSignature jws = new JsonWebSignature();

      // header
      jws.setAlgorithmHeaderValue(header.getAlgorithm());
      jws.setHeader(HeaderParameterNames.TYPE, "JWT");

      // payload
      jws.setPayload(payload.toJson());

      // signature
      jws.setKey(signingKey);

      // create compact serialised JWT
      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.JWT)
          .description(String.format("Creating signed JWT: %s. Payload: %s.", jws, payload))
          .build()
      );
      final String serializedJwt = jws.getCompactSerialization();
      log.trace(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.JWT)
          .description(String.format("Created compact serialised JWT: %s", serializedJwt))
          .build()
      );
      log.debug("signJwt: Jwt, signed successfully.");
      return serializedJwt;
    } catch (JoseException ex) {
      throw new IllegalStateException("Could not build JWS", ex);
    }
  }
}
