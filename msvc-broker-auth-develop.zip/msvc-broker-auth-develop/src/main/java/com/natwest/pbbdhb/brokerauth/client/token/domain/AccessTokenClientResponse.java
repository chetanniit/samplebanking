package com.natwest.pbbdhb.brokerauth.client.token.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.extern.jackson.Jacksonized;

@Builder
@Getter
@Jacksonized
public class AccessTokenClientResponse {

    @NonNull
    @JsonProperty("access_token")
    String accessToken;

    @NonNull
    @JsonProperty("token_type")
    String tokenType;

    // expires-in is an optional field
    // will not be supplied by IAM if token can be automatically extended
    @JsonProperty("expires_in")
    Integer expiresIn;
}
