package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class UserCreateClientRequest {

  @NonNull
  @JsonProperty("personaidentifier")
  String username;

  @NonNull
  @JsonProperty("personaidentifiertype")
  BrokerTypeModel brokerType;

  @NonNull
  @JsonProperty("accountdisable")
  Boolean accountDisabled;

  @NonNull
  @JsonProperty("personaidtype")
  String idType;

  @NonNull
  @JsonProperty("personaidentifierstatus")
  String status;

  @NonNull
  @JsonProperty("schemas")
  List<String> schemas;

}

