package com.natwest.pbbdhb.brokerauth.request.domain;

public enum NonSTPFieldCategory {
  NAME, EMAIL, ADDRESS
}
