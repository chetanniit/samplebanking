package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.mapper;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ActivateUserClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ChangePasswordClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetCustomerClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetCustomerClientResponse.GetCustomerResources;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse.GetUserResources;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpInitialiseClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse.OtpRetrieveResources;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest.Operations;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest.Operations.Values;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SetPasswordClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserCreateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserDeleteClientRequest;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionNotFoundException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;

@Slf4j
public class CustomerIdentityManagementMapper {

  private static final String USER_ID_TYPE = "UUID";
  private static final String USER_STATUS = "NEW";

  private static final String OTP_INITIALISE_TYPE = "ACTCODE";
  private static final String OTP_INITIALISE_STATUS = "New";

  private static final String PATCH_OPERATION = "replace";
  private static final String USERNAME_PREFIX = "CPB-NAPL-";

  private static final List<String> OTP_GENERATE_SCHEMA = Collections.singletonList(
      "urn:pingidentity:scim:api:messages:2.0:PasswordUpdateRequest");
  private static final List<String> PATCH_SCHEMA = Collections.singletonList(
      "urn:ietf:params:scim:api:messages:2.0:PatchOp");
  private static final List<String> OTP_INITIALISE_SCHEMA = Collections.singletonList(
      "urn:generic:schemas:otp:1.0");
  private static final List<String> USER_SCHEMA = Collections.singletonList(
      "urn:generic:schemas:customer:1.0");
  private static final List<String> SET_PASSWORD_SCHEMA = Collections.singletonList(
      "urn:pingidentity:scim:api:messages:2.0:PasswordUpdateRequest");
  private static final List<String> SECURITY_QUESTIONS_SCHEMA = Collections.singletonList(
      "urn:generic:schemas:customerchallenge:1.0");


  // Add private constructor to appease SonarLint
  private CustomerIdentityManagementMapper() {
  }

  public static UserCreateClientRequest toUserCreateClientRequest(UserCreateRequestModel request,
      Brand brand) {
    log.debug("toUserCreateClientRequest: Mapping UserCreateclientRequest for username: {}.",
            request.getUsername());
    return UserCreateClientRequest.builder()
        .username(formatUserName(brand, request.getUsername()))
        .brokerType(request.getBrokerType())
        .accountDisabled(true)
        .idType(USER_ID_TYPE)
        .status(USER_STATUS)
        .schemas(USER_SCHEMA)
        .build();
  }

  public static UserDeleteClientRequest toUserDeleteClientRequest(UserDeleteRequestModel request,
      Brand brand) {
    log.debug("toUserDeleteClientRequest: Mapping UserDeleteRequestModel for username: {}.", request.getUsername());
    return UserDeleteClientRequest.builder()
        .username(formatUserName(brand, request.getUsername()))
        .build();
  }

  public static OtpInitialiseClientRequest toOtpInitialiseClientRequest(@NonNull String username,
      Brand brand) {
    log.debug("toOtpInitialiseClientRequest: Mapping OtpInitialiseClientRequest for username: {}.", username);
    return OtpInitialiseClientRequest.builder()
        .username(formatUserName(brand, username))
        .otpStatus(OTP_INITIALISE_STATUS)
        .otpType(OTP_INITIALISE_TYPE)
        .schemas(OTP_INITIALISE_SCHEMA).build();

  }

  public static OtpValidateClientRequest toOtpValidateClientRequest(OtpValidateRequestModel request,
      Brand brand) {
    log.debug("toOtpValidateClientRequest: Mapping OtpValidateClientRequest for username: {}.", request.getUsername());
    return OtpValidateClientRequest.builder()
        .username(formatUserName(brand, request.getUsername()))
        .encodedOtpCode(base64Encode(request.getOtpCode())).build();
  }

  public static OtpGenerateClientRequest toOtpGenerateClientRequest() {
    log.debug("toOtpGenerateClientRequest: Mapping OtpGenerateClientRequest.");
    return OtpGenerateClientRequest.builder().schemas(OTP_GENERATE_SCHEMA).build();
  }

  public static OtpUpdateClientRequest toOtpUpdateClientRequest(
      OtpUpdateRequestModel request) {
    log.debug("toOtpUpdateClientRequest: Mapping OtpUpdateClientRequest.");
    return OtpUpdateClientRequest.builder()
        .schemas(PATCH_SCHEMA)
        .operations(Collections.singletonList(Operations.builder()
            .op(PATCH_OPERATION)
            .value(Values.builder()
                .otpStatus(request.getOtpStatus())
                .otpType(request.getOtpType())
                .build())
            .build()))
        .build();
  }

  public static GetCustomerResponseModel toGetCustomerResponseModel(
      GetCustomerClientResponse response) {
    log.debug("toGetCustomerResponseModel: Mapping GetCustomerResponseModel.");
    if (response.getResources() == null || response.getResources().size() == 0) {
      log.debug("toGetCustomerResponseModel: Customer not found - UserNotFoundException thrown");
      throw new UserNotFoundException("toGetCustomerResponseModel: Customer not found.");
    }
    if (response.getResources().size() > 1) {
      log.warn("toGetCustomerResponseModel: More than 1 customer returned - InvalidDataResponseException thrown");
      throw new InvalidDataResponseException("toGetCustomerResponseModel: Get customer returned more than 1 customer.");
    }
    GetCustomerResources customer = response.getResources().get(0);
    log.debug("toGetCustomerResponseModel: GetCustomerResponseModel mapped successfully.");
    return GetCustomerResponseModel.builder()
        .brokerType(BrokerTypeModel.fromValue(customer.getBrokerType().getValue()))
        .id(customer.getId())
        .build();
  }

  public static GetUserResponseModel toGetUserResponseModel(GetUserClientResponse response) {
    log.debug("toGetUserResponseModel: Mapping GetUserResponseModel.");
    if (response.getResources() == null || response.getResources().size() == 0) {
      log.debug("toGetUserResponseModel: User not found - UserNotFoundException thrown");
      throw new UserNotFoundException("User not found.");
    }
    if (response.getResources().size() > 1) {
      log.warn("toGetUserResponseModel: More than 1 customer returned - InvalidDataResponseException thrown");
      throw new InvalidDataResponseException("Get user returned more than 1 user.");
    }
    GetUserResources user = response.getResources().get(0);
    log.debug("toGetUserResponseModel: GetUserResponseModel mapped successfully.");
    return GetUserResponseModel.builder()
        .brokerType(BrokerTypeModel.fromValue(user.getBrokerType().getValue()))
        .id(user.getId())
        .parentId(user.getParentId())
        .build();
  }

  public static OtpRetrieveResponseModel toOtpRetrieveResponseModel(
      OtpRetrieveClientResponse response) {
    log.debug("toOtpRetrieveResponseModel: Mapping OtpRetrieveResponseModel.");
    if (response.getResources() == null || response.getResources().size() != 1) {
      log.warn("toOtpRetrieveResponseModel: Retrieve otp didn't return 1 otp code - " +
              "InvalidDataResponseException thrown");
      throw new InvalidDataResponseException("Retrieve otp didn't return 1 otp code.");
    }
    OtpRetrieveResources otp = response.getResources().get(0);
    log.debug("toOtpRetrieveResponseModel: OtpRetrieveResponseModel mapped successfully.");
    return OtpRetrieveResponseModel.builder()
        .otpId(otp.getId())
        .build();
  }

  public static OtpGenerateResponseModel toOtpGenerateResponseModel(
      OtpGenerateClientResponse response) {
    log.debug("toOtpGenerateResponseModel: Mapping OtpGenerateResponseModel.");
    return OtpGenerateResponseModel.builder().activationCode(response.getActivationCode()).build();
  }

  public static SetPasswordClientRequest toSetPasswordClientRequest(
      UserSetPasswordRequestModel request) {
    log.debug("toSetPasswordClientRequest: Mapping SetPasswordClientRequest.");
    return SetPasswordClientRequest.builder()
        .password(request.getPassword())
        .schemas(SET_PASSWORD_SCHEMA)
        .build();
  }

  public static ChangePasswordClientRequest toChangePasswordClientRequest(
      UserChangePasswordRequestModel request) {
    log.debug("toChangePasswordClientRequest: Mapping ChangePasswordClientRequest.");
    return ChangePasswordClientRequest.builder()
        .currentPassword(request.getCurrentPassword())
        .newPassword(request.getNewPassword())
        .schemas(SET_PASSWORD_SCHEMA)
        .build();
  }

  public static ActivateUserClientRequest createActivateUserClientRequest() {
    log.debug("createActivateUserClientRequest: Mapping ActivateUserClientRequest.");
    return ActivateUserClientRequest.builder()
        .schemas(PATCH_SCHEMA)
        .operations(Collections.singletonList(ActivateUserClientRequest.Operations.builder()
            .op(PATCH_OPERATION)
            .value(ActivateUserClientRequest.Operations.Values.builder()
                .accountDisable(false).build())
            .build()))
        .build();
  }

  public static SecurityQuestionsClientRequest toSecurityQuestionsClientRequest(
      SecurityQuestionsRequestModel request) {
    log.debug("toSecurityQuestionsClientRequest: Mapping SecurityQuestionsClientRequest.");
    return SecurityQuestionsClientRequest
        .builder()
        .schemas(SECURITY_QUESTIONS_SCHEMA)
        .parentId(request.getParentId())
        .question(buildQuestion(request.getQuestions()))
        .answer(request.getQuestions().stream().map(CustomerIdentityManagementMapper::buildAnswer)
            .collect(
                Collectors.toList()))
        .build();

  }

  public static SecurityQuestionsFetchResponseModel toSecurityQuestionsResponseModel(
      SecurityQuestionsClientResponse response) {
    log.debug("toSecurityQuestionsResponseModel: Mapping SecurityQuestionsFetchResponseModel.");
    if (response.getResources() == null || response.getResources().size() != 1) {
      log.warn("toSecurityQuestionsResponseModel: Retrieve security questions didn't return 1 question - " +
              "SecurityQuestionNotFoundException thrown");
      throw new SecurityQuestionNotFoundException(
          "Retrieve security questions didn't return 1 question resource.");
    }
    final SecurityQuestionsClientResponse.SecurityQuestionResource securityQuestions = response.getResources()
        .get(0);

    if (securityQuestions.getQuestions() == null || securityQuestions.getQuestions().size() != 1) {
      log.warn("toSecurityQuestionsResponseModel: Retrieve security questions didn't return 1 list of questions " +
              "- SecurityQuestionNotFoundException thrown");
      throw new SecurityQuestionNotFoundException(
          "Retrieve security questions didn't return 1 list of questions.");
    }

    final List<SecurityQuestionsFetchResponseModel.SecurityQuestion> questions = securityQuestions.getQuestions()
        .get(0).entrySet()
        .stream()
        .map(question -> SecurityQuestionsFetchResponseModel.SecurityQuestion.builder()
            .id(question.getKey())
            .question(question.getValue())
            .build())
        .sorted(Comparator.comparing(SecurityQuestionsFetchResponseModel.SecurityQuestion::getId))
        .collect(Collectors.toList());

    log.debug("toSecurityQuestionsResponseModel: SecurityQuestionsFetchResponseModel successful.");
    return SecurityQuestionsFetchResponseModel
        .builder()
        .id(securityQuestions.getId())
        .securityQuestions(questions)
        .build();
  }

  private static List<Map<String, String>> buildQuestion(List<SecurityQuestion> questions) {
    log.debug("buildQuestion: Building security question.");
    HashMap<String, String> questionMap = new HashMap<>();

    for (int i = 0; i < questions.size(); i++) {
      questionMap.put("q" + (i + 1), questions.get(i).getQuestion());
    }
    log.debug("buildQuestion: Security question successfully built.");
    return Collections.singletonList(questionMap);
  }

  private static String buildAnswer(SecurityQuestion securityQuestion) {
    log.debug("buildAnswer: Building security question answer.");
    return securityQuestion.getQuestion() + securityQuestion.getAnswer();
  }

  public static String formatUserName(Brand brand, String username) {
    log.debug("formatUserName: Formatting username: {}.", username);
    return USERNAME_PREFIX + brand.toString() + "@" + username;
  }

  public static String base64Encode(String value) {
    log.debug("base64Encode: Encoding base 64 string.");
    return Base64.encodeBase64String(value.getBytes(StandardCharsets.UTF_8));
  }
}
