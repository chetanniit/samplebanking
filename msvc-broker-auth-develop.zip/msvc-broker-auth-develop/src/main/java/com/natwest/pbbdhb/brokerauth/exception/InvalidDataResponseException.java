package com.natwest.pbbdhb.brokerauth.exception;

import lombok.Getter;

/**
 * An exception to be thrown when the response from the downstream service contains data that our
 * service cannot handle.
 */
@Getter
public class InvalidDataResponseException extends RuntimeException {


  public InvalidDataResponseException(String message, Throwable cause) {
    super(message, cause);
  }

  public InvalidDataResponseException(String message) {
    super(message);
  }
}
