package com.natwest.pbbdhb.brokerauth.validation;

import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.validation.constraint.ContainsAllBrands;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.EnumMap;

/**
 * Validator that checks whether a map holds all possible {@link Brand} enums as keys.
 */
public class AllBrandsValidator implements
        ConstraintValidator<ContainsAllBrands, EnumMap<Brand, ?>> {

  private final static int SUPPORTED_BRANDS_COUNT = Brand.values().length;

  /**
   * Checks that supplied map holds all possible {@link Brand} enum values as keys. Return false if
   * any enum values are missing from the map.
   *
   * @param map     - enum map where {@link Brand} is used as a key
   * @param context - context in which the constraint is evaluated
   * @return false if map does not hold all possible {@link Brand} enums as keys
   */
  @Override
  public boolean isValid(EnumMap<Brand, ?> map, ConstraintValidatorContext context) {
    return map.size() == SUPPORTED_BRANDS_COUNT;
  }
}
