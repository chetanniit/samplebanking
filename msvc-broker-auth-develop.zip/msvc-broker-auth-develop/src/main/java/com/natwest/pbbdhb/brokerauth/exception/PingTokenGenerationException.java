package com.natwest.pbbdhb.brokerauth.exception;

public class PingTokenGenerationException extends RuntimeException {

    public PingTokenGenerationException(String message) {
        super(message);
    }
}
