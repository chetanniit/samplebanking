package com.natwest.pbbdhb.brokerauth.exception;

/**
 * Used to indicate an unexpected exception occurred when processing a security question/answer
 */
public class SecurityQuestionResponseException extends RuntimeException {

  public SecurityQuestionResponseException(String message) {
    super(message);
  }
}