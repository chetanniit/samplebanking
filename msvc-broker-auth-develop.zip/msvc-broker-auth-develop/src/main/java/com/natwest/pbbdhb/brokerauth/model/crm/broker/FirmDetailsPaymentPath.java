
package com.natwest.pbbdhb.brokerauth.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class FirmDetailsPaymentPath {
    @JsonProperty("mbs_name")
    @EqualsAndHashCode.Exclude
    private String name;
    @JsonProperty("mbs_paymentid")
    private String paymentId;
}
