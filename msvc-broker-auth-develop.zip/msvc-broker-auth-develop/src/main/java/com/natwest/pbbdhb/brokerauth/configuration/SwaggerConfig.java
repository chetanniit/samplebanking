package com.natwest.pbbdhb.brokerauth.configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Sets up swagger, defining the swagger properties using {@link OpenAPIDefinition}.
 */
@Configuration
@OpenAPIDefinition(
    info = @Info(
        title = "msvc-broker-auth",
        version = "1.0",
        description = "Provides APIs that supports authentication operations required by Napoli"
    )
)
public class SwaggerConfig {

  /**
   * Set up a {@code OpenAPI} bean.
   *
   * <ul>
   * <li>For UI - {@code http://localhost:server.port/context.root/swagger-ui/index.html}</li>
   * <li>For json - {@code http://localhost:server.port/context.root/v3/api-docs}</li>
   * </ul>
   *
   * @return Bean needed for swagger API and swagger-ui to function.
   */
  @Bean
    public OpenAPI api() {
        return new OpenAPI()
                .components(
                        new Components()
                                .addSecuritySchemes("Authorization", new SecurityScheme()
                                        .type(SecurityScheme.Type.APIKEY)
                                        .in(SecurityScheme.In.HEADER)
                                        .name("iam-claimsetjwt")
                                        .description("JWT is required when calling Gen02 secured endpoints")
                                ))
                .addSecurityItem(new SecurityRequirement().addList("Authorization"));
    }
}