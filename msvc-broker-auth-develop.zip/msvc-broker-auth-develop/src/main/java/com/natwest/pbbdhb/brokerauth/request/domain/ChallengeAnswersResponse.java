package com.natwest.pbbdhb.brokerauth.request.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A controller request domain model describing the payload returned by the challenge answers
 * endpoint.
 */
@Builder
@Value
public class ChallengeAnswersResponse {

  @NonNull
  String otpCode;
  @NonNull
  String brokerType;
}
