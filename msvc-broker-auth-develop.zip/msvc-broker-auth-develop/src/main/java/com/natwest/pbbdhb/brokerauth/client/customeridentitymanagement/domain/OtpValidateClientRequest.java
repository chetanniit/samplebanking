package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class OtpValidateClientRequest {

  @NonNull
  String username;

  @NonNull
  String encodedOtpCode;

}
