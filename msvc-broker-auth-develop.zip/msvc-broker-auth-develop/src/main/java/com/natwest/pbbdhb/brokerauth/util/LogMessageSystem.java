package com.natwest.pbbdhb.brokerauth.util;

public class LogMessageSystem {
  public static String NAPOLI = "Napoli";
}
