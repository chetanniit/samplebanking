package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Builder
@Value
@Jacksonized
public class SecurityQuestionsClientResponse {

  @JsonProperty("Resources")
  List<SecurityQuestionsClientResponse.SecurityQuestionResource> resources;

  @JsonProperty("totalResults")
  int totalResults;

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class SecurityQuestionResource {

    @JsonProperty("id")
    String id;

    @JsonProperty("question")
    List<Map<String, String>> questions;
  }
}
