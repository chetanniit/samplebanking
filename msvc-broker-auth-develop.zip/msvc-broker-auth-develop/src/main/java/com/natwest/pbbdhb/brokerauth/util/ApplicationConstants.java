package com.natwest.pbbdhb.brokerauth.util;

/**
 * The application constants.
 */
public final class ApplicationConstants {

    public static final String JWT_VAL = "JWT";
    public static final String GRANT_TYPE = "grant_type";
    public static final String AUD = "aud";
    public static final String JTI = "jti";
    public static final String ISS = "iss";
    public static final String SUB = "sub";
    public static final String EXPIRY = "exp";
    public static final String NBF = "nbf";
    public static final String TYPE = "typ";
    public static final String KID = "kid";
    public static final String X5T = "x5t";
    public static final String ALGORITHM = "alg";
    public static final String SCOPE = "scope";
    public static final String CLIENT_ID = "client_id";
    public static final String RESOURCE = "resource";
    public static final String TENANT = "tenant";
    public static final String CLIENT_ASSERTION_TYPE = "client_assertion_type";

    private ApplicationConstants() {
    }
}
