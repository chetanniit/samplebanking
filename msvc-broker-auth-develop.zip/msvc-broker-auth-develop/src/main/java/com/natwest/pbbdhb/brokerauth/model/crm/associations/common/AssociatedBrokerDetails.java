package com.natwest.pbbdhb.brokerauth.model.crm.associations.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerDetails;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class AssociatedBrokerDetails extends BrokerDetails {
    @JsonProperty("mbs_fcanumber")
    private String fcaNumber;
    @JsonProperty("mbs_principalfcanumber")
    private String principalFCANumber;
    @JsonProperty("mbs_firmname")
    private String firmName;
    @JsonProperty("mbs_brokeradminname")
    private String brokerAdminName;
}
