package com.natwest.pbbdhb.brokerauth.domain.otp;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data returned by Generating an OTP.
 */
@Builder
@Value
public class OtpGenerateResponseModel {

  /**
   * The activation code to be sent to the user during broker registration. As this is a required
   * field, {@code @NonNull} has been set.
   */
  @NonNull
  String activationCode;
}
