package com.natwest.pbbdhb.brokerauth.configuration;

import com.rbs.dws.security.UserPrincipalProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityContext {

  // Use "simpleUserPrincipalProvider" bean for our UserPrincipalProvider.
  // See: https://confluence-dts-nft.fm.rbsgrp.net/display/SEPD/Tomcat+security+valves
  @Bean
  public UserPrincipalProvider userPrincipalProvider(
      @Autowired @Qualifier("simpleUserPrincipalProvider") UserPrincipalProvider userPrincipalProvider) {
    return userPrincipalProvider;
  }
}
