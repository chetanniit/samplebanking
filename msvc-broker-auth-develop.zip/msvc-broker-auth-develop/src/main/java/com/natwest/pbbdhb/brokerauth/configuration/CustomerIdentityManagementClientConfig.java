package com.natwest.pbbdhb.brokerauth.configuration;

import com.natwest.pbbdhb.brokerauth.domain.Brand;
import java.net.URI;
import java.util.EnumMap;
import jakarta.validation.constraints.NotNull;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

/**
 * A configuration class for the Customer Identity Management client covering stub properties.
 * {@code @ConstructorBinding} has been set so config can be immutable.
 */
@ConfigurationProperties(prefix = "clients.customeridentitymanagement")
@Getter
@Validated
public class CustomerIdentityManagementClientConfig {

  private final CustomerIdentityManagementRestClientConfig rest;
  private final CustomerIdentityManagementStubClientConfig stub;

  @ConstructorBinding
  public CustomerIdentityManagementClientConfig(CustomerIdentityManagementRestClientConfig rest,
      CustomerIdentityManagementStubClientConfig stub) {
    this.rest = rest;
    this.stub = stub;
  }

  @Getter
  @Setter
  public static class CustomerIdentityManagementRestClientConfig {

    @NotNull
    private EnumMap<Brand, EndpointConfig> brands;

    @Default
    private int timeout = 30;

  }


  @Getter
  public static class CustomerIdentityManagementStubClientConfig {

    private final boolean enabled;

    @ConstructorBinding
    public CustomerIdentityManagementStubClientConfig(boolean enabled) {
      this.enabled = enabled;
    }
  }

  @Getter
  @Setter
  public static class EndpointConfig {

    @NotNull
    private URI url;
  }
}
