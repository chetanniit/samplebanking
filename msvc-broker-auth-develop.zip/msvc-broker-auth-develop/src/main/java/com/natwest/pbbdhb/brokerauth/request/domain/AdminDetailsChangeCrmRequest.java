package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdminDetailsChangeCrmRequest {

  @NotNull
  @JsonProperty("mbs_userName")
  private String username;

  @JsonProperty("mbs_title")
  private String title;

  @JsonProperty("mbs_firstName")
  private String firstName;

  @JsonProperty("mbs_middleName")
  private String middleName;

  @JsonProperty("mbs_lastName")
  private String lastName;

  @JsonProperty("mbs_emailAddress")
  private String email;

  @JsonProperty("mbs_mobilePhone")
  private String mobilePhone;

  @JsonProperty("mbs_businessPhone")
  private String businessPhone;

}
