package com.natwest.pbbdhb.brokerauth.client.token;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@ConditionalOnProperty(
    value = "clients.accesstoken.stub.enabled",
    havingValue = "true"
)
@Component
@Primary
@Slf4j
public class AccessTokenStubClient implements AccessTokenClient {

  public AccessTokenStubClient() {
    log.warn("Stub version of Access Token client in-use. Only intended for test environments.");
  }

  @Override
  public AccessTokenResponseModel retrieveToken(AccessTokenRetrieveRequestModel request) {
    log.warn("Returning Access Token stub response. Only intended for test environments.");
    return AccessTokenResponseModel
        .builder()
        .accessToken("stub-token-abcdef-123456")
        .tokenType("Bearer")
        .expiresIn(599)
        .build();
  }
}