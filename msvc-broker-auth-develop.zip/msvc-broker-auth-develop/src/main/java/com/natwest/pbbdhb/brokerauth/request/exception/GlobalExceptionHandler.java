package com.natwest.pbbdhb.brokerauth.request.exception;

import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionLockedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionNotFoundException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionResponseException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionValidateException;
import com.natwest.pbbdhb.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

  /**
   * A sample handler of the {@link RemoteRequestFailedException}.
   *
   * @param ex The exception thrown.
   * @return Description of the error that callers of the controller can understand.
   */
  @ExceptionHandler(RemoteRequestFailedException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ErrorResponse handleRemoteRequestFailedException(RemoteRequestFailedException ex) {
    // log stack trace to help debugging of remote requests
    log.warn("RemoteRequestFailedException was thrown", ex);

    log.error(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );

    return ErrorResponse.invalidServerError();
  }

  /**
   * A handler for {@link MethodArgumentNotValidException}
   *
   * @param ex The MethodArgumentNotValidException that was thrown.
   * @return Description of validation errors that callers of the controller can understand.
   */
  @ExceptionHandler(MethodArgumentNotValidException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleValidationExceptions(MethodArgumentNotValidException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );

    List<ErrorResponseDetail> errors = new ArrayList<>();

    ex.getBindingResult().getAllErrors().forEach((error) -> {
      String errorFieldName = ((FieldError) error).getField();
      String errorMessage = error.getDefaultMessage();

      errors.add(ErrorResponseDetail.builder()
          .title(errorFieldName)
          .description(errorMessage)
          .build());
    });

    return ErrorResponse.invalidRequest(errors);
  }

  /**
   * A handler for {@link LoginFailedException}
   *
   * @param ex The LoginFailedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(LoginFailedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleLoginFailedException(LoginFailedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.invalidCredentials();
  }

  /**
   * A handler for {@link AccountLockedException}
   *
   * @param ex The AccountLockedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(AccountLockedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleAccountLockedException(AccountLockedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.accountLocked();
  }

  /**
   * A handler for {@link AccountLockedException}
   *
   * @param ex The AccountLockedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(PasswordExpiredException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handlePasswordExpiredException(PasswordExpiredException ex) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .exception(ex)
            .build()
    );
    return ErrorResponse.passwordExpired();
  }

  /**
   * A handler for {@link UnauthorisedException}
   *
   * @param ex The UnauthorisedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(UnauthorisedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleUnauthorisedException(UnauthorisedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.unauthorised();
  }

  /**
   * A handler for {@link UserNotFoundException}
   *
   * @param ex The UserNotFoundException that was thrown.
   * @return Description of error that callers of the controller can understand.
   */
  @ExceptionHandler(UserNotFoundException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleUserNotFoundException(UserNotFoundException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.userNotFound();
  }

  /**
   * A handler for {@link UserAlreadyExistsException}
   *
   * @param ex The UserAlreadyExistsException that was thrown.
   * @return Description of conflict error that callers of the controller can understand.
   */
  @ExceptionHandler(UserAlreadyExistsException.class)
  @ResponseStatus(HttpStatus.CONFLICT)
  public ErrorResponse handleUserAlreadyExistsException(UserAlreadyExistsException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.userAlreadyExists();
  }

  /**
   * A handler for {@link InvalidDataResponseException}
   *
   * @param ex The InvalidDataResponseException that was thrown.
   * @return Description of internal server error that callers of the controller can understand.
   */
  @ExceptionHandler(InvalidDataResponseException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ErrorResponse invalidDataResponseException(InvalidDataResponseException ex) {
    log.error(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );

    return ErrorResponse.invalidServerError();
  }

  /**
   * A handler for {@link OtpException}
   *
   * @param ex The OtpException that was thrown.
   * @return Description of otp error that callers of the controller can understand.
   */
  @ExceptionHandler(OtpException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleOtpException(OtpException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );

    switch (ex.getCode()) {
      case INVALID_CREDENTIALS:
        return ErrorResponse.invalidCredentials();
      case OTP_EXPIRED:
        return ErrorResponse.expiredOtp();
      case ACCOUNT_LOCKED:
        return ErrorResponse.accountLocked();
      default:
        return ErrorResponse.otpValidationFailed();
    }
  }

  /**
   * A handler for {@link InvalidDetailsException}
   *
   * @param ex The InvalidDetailsException that was thrown.
   */
  @ExceptionHandler(InvalidDetailsException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleInvalidDetailsException(InvalidDetailsException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build());

    return ErrorResponse.invalidDetails();
  }

  @ExceptionHandler(SecurityQuestionValidateException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleSecurityQuestionValidateException(
      SecurityQuestionValidateException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build());

    return ErrorResponse.securityQuestionValidationFailed();
  }

  @ExceptionHandler(SecurityQuestionLockedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleSecurityQuestionLockedException(SecurityQuestionLockedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build());

    return ErrorResponse.securityQuestionLocked();
  }

  @ExceptionHandler(SecurityQuestionResponseException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ErrorResponse handleSecurityQuestionResponseException(
      SecurityQuestionResponseException ex) {
    log.error(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build());

    return ErrorResponse.invalidServerError();
  }

  @ExceptionHandler(SecurityQuestionNotFoundException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleSecurityQuestionNotFoundException(
      SecurityQuestionNotFoundException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build());

    return ErrorResponse.securityQuestionNotFound();
  }
}
