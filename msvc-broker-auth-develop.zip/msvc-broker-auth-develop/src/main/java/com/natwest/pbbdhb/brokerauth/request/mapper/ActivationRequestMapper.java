package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ActivationRequestMapper {

  private static final String OTP_UPDATE_TYPE = "OTP";
  private static final String ACTIVATION_CODE_UPDATE_TYPE = "ACTCODE";

  private ActivationRequestMapper() {
  }

  public static OtpValidateRequestModel toOtpValidateRequestModel(
      ActivationCodeValidateRequest request) {
    log.debug("toOtpValidateRequestModel: Mapping ActivationCodeValidateRequest to OtpValidateRequestModel");
    return OtpValidateRequestModel.builder()
        .otpCode(request.getCode())
        .username(request.getUsername())
        .build();
  }

  public static OtpValidateRequestModel toOtpValidateRequestModel(UserActivateRequest request) {
    log.debug("toOtpValidateRequestModel: Mapping UserActivateRequest to OtpValidateRequestModel");
    return OtpValidateRequestModel.builder()
        .otpCode(request.getOtpCode())
        .username(request.getUsername())
        .build();
  }

  public static UserSetPasswordRequestModel toUserSetPasswordRequestModel(
      UserActivateRequest request, @NonNull String customerIdentifier) {
    log.debug("toUserSetPasswordRequestModel: Mapping UserActivateRequest to UserSetPasswordRequestModel for " +
                    "CustomerIdentifier: {}", customerIdentifier);
    return UserSetPasswordRequestModel.builder()
        .password(request.getPassword())
        .customerIdentifier(customerIdentifier)
        .build();
  }

  public static SecurityQuestionsRequestModel toSecurityQuestionsRequestModel(
      UserActivateRequest request, @NonNull String customerIdentifier) {
    log.debug("toSecurityQuestionsRequestModel: Mapping UserActivateRequest to SecurityQuestionsRequestModel for " +
            "CustomerIdentifier: {}", customerIdentifier);
    return SecurityQuestionsRequestModel.builder()
        .questions(request.getSecurityQuestions())
        .parentId(customerIdentifier)
        .build();
  }

  public static OtpUpdateRequestModel toOtpUpdateRequestModel(String otpId, String status) {
    log.debug("toOtpUpdateRequestModel: Mapping OtpUpdateRequestModel. otpId: {}, status: {}", otpId, status);
    return OtpUpdateRequestModel.builder()
        .otpId(otpId)
        .otpStatus(status)
        .otpType(OTP_UPDATE_TYPE)
        .build();
  }

  public static OtpUpdateRequestModel toActivationCodeUpdateRequestModel(String otpId, String status) {
    log.debug("toActivationCodeUpdateRequestModel: Mapping OtpUpdateRequestModel. otpId: {}, status: {}", otpId, status);
    return OtpUpdateRequestModel.builder()
        .otpId(otpId)
        .otpStatus(status)
        .otpType(ACTIVATION_CODE_UPDATE_TYPE)
        .build();
  }

}
