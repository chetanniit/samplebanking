package com.natwest.pbbdhb.brokerauth.model.crm.associations.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.common.AssociatedBrokerDetails;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminAssociationsResponse {

    @JsonProperty("mbs_brokers")
    private List<AssociatedBrokerDetails> brokers;
    @JsonProperty("mbs_message1")
    private String message;
}
