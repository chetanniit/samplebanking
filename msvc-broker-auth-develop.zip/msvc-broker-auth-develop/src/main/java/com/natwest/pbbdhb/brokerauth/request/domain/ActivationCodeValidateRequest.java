package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class ActivationCodeValidateRequest {

  @JsonProperty("username")
  @Schema(
      description = "Username from a user's credentials",
      required = true
  )
  @NotNull String username;

  @JsonProperty("code")
  @Schema(
      description = "one time activation code",
      required = true
  )
  @NotNull String code;

}
