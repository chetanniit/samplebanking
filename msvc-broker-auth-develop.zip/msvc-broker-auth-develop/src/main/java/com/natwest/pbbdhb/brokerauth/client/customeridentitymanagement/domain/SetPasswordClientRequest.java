package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class SetPasswordClientRequest {

  @NonNull
  List<String> schemas;

  @NonNull
  @JsonProperty("newPassword")
  String password;

}
