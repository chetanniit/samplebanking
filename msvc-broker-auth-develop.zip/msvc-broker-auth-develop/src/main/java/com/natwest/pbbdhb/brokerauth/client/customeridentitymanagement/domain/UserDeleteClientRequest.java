package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class UserDeleteClientRequest {

  @NonNull
  @JsonProperty("personaidentifier")
  String username;
}

