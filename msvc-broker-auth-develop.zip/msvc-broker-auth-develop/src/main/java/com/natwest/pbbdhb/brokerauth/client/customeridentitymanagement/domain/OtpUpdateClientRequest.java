package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class OtpUpdateClientRequest {

  @NonNull
  List<String> schemas;

  @NonNull
  @JsonProperty("Operations")
  List<Operations> operations;

  @Builder
  @Value
  public static class Operations {

    @NonNull
    String op;

    @NonNull
    Values value;

    @Builder
    @Value
    public static class Values {

      @NonNull
      @JsonProperty("otp_status")
      String otpStatus;

      @NonNull
      @JsonProperty("otp_type")
      String otpType;
    }
  }
}
