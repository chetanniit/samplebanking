package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderResponse;

import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderRequest;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import com.natwest.pbbdhb.brokerauth.service.crm.UsernameReminderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.yaml.snakeyaml.util.UriEncoder;

@Service
@Slf4j
public class UsernameReminderServiceImpl implements UsernameReminderService {

    private final CRMClient crmClient;
    private final String usernameReminderEndpoint;

    public UsernameReminderServiceImpl(CRMClient crmClient,
                                       @Value("${broker.crm.username.reminder.endpoint}") String usernameReminderEndpoint) {
        this.crmClient = crmClient;
        this.usernameReminderEndpoint = usernameReminderEndpoint;
    }

    @Override
    public UsernameReminderResponse getUsernameReminder(UsernameReminderRequest usernameReminderRequest) {
        log.debug("getUsernameReminder: Getting username reminder for {}", usernameReminderRequest);
        try {
            UsernameReminderResponse usernameReminderResponse = (UsernameReminderResponse) crmClient.get(getEncodedURL(usernameReminderRequest), UsernameReminderResponse.class);
            if(usernameReminderResponse.getUsernameIdentified()) {
                log.debug("getUsernameReminder: Username reminder for {}, retrieved successfully", usernameReminderRequest);
                return usernameReminderResponse;
            } else {
                throw new UserNotFoundException(String.format("getUsernameReminder: User not found for details %s", usernameReminderRequest));
            }
        } catch (RestClientException ex) {
            log.warn("getUsernameReminder: Error reading username reminder for {}", usernameReminderRequest, ex);
            throw new RemoteRequestFailedException(
                    String.format("getUsernameReminder: Get Username Reminder request failed for %s", usernameReminderRequest), ex);
        }
    }

    private String getEncodedURL(UsernameReminderRequest usernameReminderRequest) {
        log.debug("getEncodedURL: Getting encoded url.");
        return UriEncoder.encode(String.format(usernameReminderEndpoint, usernameReminderRequest.getEmail(),
                usernameReminderRequest.getLastName(),
                usernameReminderRequest.getDateOfBirth()));
    }
}
