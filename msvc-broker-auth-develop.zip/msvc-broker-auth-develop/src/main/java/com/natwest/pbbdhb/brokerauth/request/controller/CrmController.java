package com.natwest.pbbdhb.brokerauth.request.controller;

import com.natwest.pbbdhb.brokerauth.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorResponse;
import com.natwest.pbbdhb.brokerauth.service.crm.CrmService;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mortgages/v1/msvc-broker-auth/crm")
@Tag(name = "CRM",
    description = "API for CRM")
@Slf4j
@Validated
public class CrmController {

  private final CrmService crmService;

  @Autowired
  public CrmController(CrmService crmService) {
    this.crmService = crmService;
  }

  @Operation(summary = "Get broker details")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerCoreResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/broker/details/{username}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerCoreResponse getBrokerDetails(@PathVariable("username") String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getBrokerDetails: Retrieve broker details for user: %s", username))
        .build()
    );

    log.info("getBrokerDetails: Broker details for user: {}, retrieved successfully", username);
    return crmService.getBrokerDetails(username);
  }

  @Operation(summary = "Get admin details")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = AdminCoreResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/admin/details/{username}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  AdminCoreResponse getAdminDetails(@PathVariable("username") String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getAdminDetails: Retrieve admin details for user: %s", username))
        .build()
    );

    log.info("getAdminDetails: Admin details for user: {}, retrieved successfully", username);
    return crmService.getAdminDetails(username);
  }

  @Operation(summary = "Get broker associations")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerAssociationsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/broker/associations/{username}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerAssociationsResponse getBrokerAssociations(@PathVariable("username") String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getBrokerAssociations: Retrieve broker associations for user: %s", username))
        .build()
    );

    log.info("getBrokerAssociations: Broker associations for user: {}, retrieved successfully", username);
    return crmService.getBrokerAssociations(username);
  }

  @Operation(summary = "Get broker unassociations")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerAssociationsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/broker/unassociations/{username}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerAssociationsResponse getBrokerUnAssociations(@PathVariable("username") String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getBrokerUnAssociations: Retrieve broker unassociations for user: %s", username))
        .build()
    );

    log.info("getBrokerUnAssociations: Broker unAssociations for user: {}, retrieved successfully", username);
    return crmService.getBrokerUnAssociations(username);
  }

  @Operation(summary = "Get admin associations")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = AdminAssociationsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/admin/associations/{username}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  AdminAssociationsResponse getAdminAssociations(@PathVariable("username") String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getAdminAssociations: Retrieve admin associations for user: %s", username))
        .build()
    );

    log.info("getAdminAssociations: Admin associations for user: {}, retrieved successfully", username);
    return crmService.getAdminAssociations(username);
  }

  @Operation(summary = "Associate broker to broker")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerPermissionsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @PostMapping(path = "/broker/association/{username}/broker/{brokerToAssociate}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerPermissionsResponse associateBrokerToBroker(@PathVariable("username") String username,
                                                    @PathVariable("brokerToAssociate") String brokerToAssociate) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("associateBrokerToBroker: Associate broker %s to broker %s",
                username, brokerToAssociate))
        .build()
    );

    log.info("associateBrokerToBroker: Broker username: {} and broker username: {}, associated successfully",
            username, brokerToAssociate);
    return crmService.associateBrokerToBroker(username, brokerToAssociate);
  }

  @Operation(summary = "Unassociate broker to broker")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerPermissionsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @PostMapping(path = "/broker/unassociation/{username}/broker/{brokerToUnAssociate}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerPermissionsResponse unassociateBrokerToBroker(@PathVariable("username") String username,
                                                      @PathVariable("brokerToUnAssociate") String brokerToUnAssociate) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("unassociateBrokerToBroker: Unassociate broker %s to broker %s",
                username, brokerToUnAssociate))
        .build()
    );
    log.info("unassociateBrokerToBroker: Broker username: {} and broker username: {}, unAssociated successfully",
            username, brokerToUnAssociate);
    return crmService.unAssociateBrokerToBroker(username, brokerToUnAssociate);
  }

  @Operation(summary = "Associate broker to admin")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerPermissionsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @PostMapping(path = "/broker/association/{username}/admin/{adminToAssociate}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerPermissionsResponse associateBrokerToAdmin(@PathVariable("username") String username,
                                                   @PathVariable("adminToAssociate") String adminToAssociate) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("associateBrokerToAdmin: Associate broker %s to admin %s", username, adminToAssociate))
        .build()
    );
    log.info("associateBrokerToAdmin: Broker username: {} and admin username: {}, associated successfully",
            username, adminToAssociate);
    return crmService.associateBrokerToAdmin(username, adminToAssociate);
  }

  @Operation(summary = "Unassociate broker to admin")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerPermissionsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @PostMapping(path = "/broker/unassociation/{username}/admin/{adminToAssociate}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerPermissionsResponse unassociateBrokerToAdmin(@PathVariable("username") String username,
                                                     @PathVariable("adminToAssociate") String adminToAssociate) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("unassociateBrokerToAdmin: Unassociate broker %s to admin %s",
                    username, adminToAssociate))
            .build()
    );
    log.info("unassociateBrokerToAdmin: Broker username: {} and admin username: {}, unAssociated successfully",
            username, adminToAssociate);
    return crmService.unAssociateBrokerToAdmin(username, adminToAssociate);
  }

}
