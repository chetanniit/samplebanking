package com.natwest.pbbdhb.brokerauth.request.controller;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.request.controller.helpers.AccessTokenRequestHelper;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeGenerateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UserCreateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UserDeleteRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorResponse;
import com.natwest.pbbdhb.brokerauth.request.mapper.RegistrationRequestMapper;
import com.natwest.pbbdhb.brokerauth.service.registration.RegistrationService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * A Registration controller providing registration operation endpoints for users.
 */
@RestController
@RequestMapping("/mortgages/v1/msvc-broker-auth/users")
@Tag(name = "Users", description = "APIs for user registration and activation")
@Slf4j
public class RegistrationController {

  private final AccessTokenRequestHelper accessTokenRequestHelper;
  private final AccessTokenService accessTokenService;
  private final RegistrationService registrationService;

  @Autowired
  public RegistrationController(
      AccessTokenRequestHelper accessTokenRequestHelper,
      AccessTokenService accessTokenService,
      RegistrationService registrationService) {
    this.accessTokenRequestHelper = accessTokenRequestHelper;
    this.accessTokenService = accessTokenService;
    this.registrationService = registrationService;
  }

  /**
   * Creates a new User and let Spring boot convert the request body in json format to a {@link
   * UserCreateRequestModel} object. The request body will be validated by {@code Valid}.
   *
   * @param createRequest the User to create
   */
  @Operation(responses = {
      @ApiResponse(responseCode = "201", description = "Successfully created user resource"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public void createUser(@RequestBody @Valid UserCreateRequest createRequest) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("createUser: Starting create user operation for username: %s",
                createRequest.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    UserCreateRequestModel userCreateRequestModel = RegistrationRequestMapper.toUserCreateRequestModel(
        createRequest);

    registrationService.createUser(accessToken, userCreateRequestModel);
    log.info("createUser: User with username: {}, successfully created.", createRequest.getUsername());
  }

  /**
   * Deletes an existing User and let Spring boot convert the request body in json format to a {@link
   * UserDeleteRequestModel} object. The request body will be validated by {@code Valid}.
   *
   * @param deleteRequest the User to create
   */
  @Operation(responses = {
          @ApiResponse(responseCode = "204", description = "Successfully deleted user resource"),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                  @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @DeleteMapping
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void deleteUser(@RequestBody @Valid UserDeleteRequest deleteRequest) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("deleteUser: Starting delete user operation for username: %s",
                    deleteRequest.getUsername()))
            .build()
    );

    UserDeleteRequestModel userDeleteRequestModel = RegistrationRequestMapper.toUserDeleteRequestModel(
            deleteRequest);

    final String accessToken = getAccessToken();

    registrationService.deleteUser(accessToken, userDeleteRequestModel);
    log.info("deleteUsed: User with username: {}, successfully deleted.", deleteRequest.getUsername());
  }

  @PostMapping("/activation-code")
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(responses = {
      @ApiResponse(responseCode = "201", description = "Successfully created an activation code", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ActivationCodeResponse.class))}),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
      })
  })
  public ActivationCodeResponse postActivationCode(
      @Valid @RequestBody ActivationCodeGenerateRequest request) {
    final String accessToken = getAccessToken();

    String activationCode = registrationService.createActivationCode(accessToken,
            request.getUsername())
        .getActivationCode();

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("postActivationCode: Posting activation code for user: %s",
                request.getUsername()))
        .build()
    );

    log.info("postActivationCode: Activation code for username: {}, successfully posted.", request.getUsername());
    return RegistrationRequestMapper.toActivationCodeResponse(activationCode);
  }

  @PostMapping("/reactivate")
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(responses = {
          @ApiResponse(responseCode = "201", description = "Successfully created an reactivation code", content = {
                  @Content(mediaType = "application/json", schema = @Schema(implementation = ActivationCodeResponse.class))}),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                  @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
          @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                  @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
          })
  })
  public ActivationCodeResponse reactivateUser(
          @Valid @RequestBody ActivationCodeGenerateRequest request) {
    final String accessToken = getAccessToken();

    String activationCode = registrationService.reactivateUser(accessToken, request).getActivationCode();

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("reactivateUser: Posting reactivation code for user: %s",
                    request.getUsername()))
            .build()
    );

    log.info("reactivateUser: User with username: {}, successfully reactivated.", request.getUsername());
    return RegistrationRequestMapper.toActivationCodeResponse(activationCode);
  }

  private String getAccessToken() {
    log.info("getAccessToken: Getting access token.");
    AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel =
        accessTokenRequestHelper.tokenRetrieveRequestModel();

    log.info("getAccessToken: Access token successfully retrieved.");
    return accessTokenService.token(accessTokenRetrieveRequestModel).getAccessToken();
  }
}
