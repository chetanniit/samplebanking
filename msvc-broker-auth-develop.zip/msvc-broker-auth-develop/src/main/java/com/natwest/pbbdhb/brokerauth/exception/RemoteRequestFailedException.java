package com.natwest.pbbdhb.brokerauth.exception;

import org.springframework.web.client.RestClientException;

/**
 * A sample exception to be thrown when remote request fails, such as a bad rest response.
 */
public class RemoteRequestFailedException extends RuntimeException {

  public RemoteRequestFailedException(String message, RestClientException cause) {
    super(message, cause);
  }

  public RemoteRequestFailedException(String message) {
    super(message);
  }
}