package com.natwest.pbbdhb.brokerauth.exception;

import lombok.Getter;

/**
 * An exception to be thrown when login returns password expired.
 */
@Getter
public class PasswordExpiredException extends RuntimeException {

  private final String username;

  public PasswordExpiredException(String username) {
    super(String.format("Password expired for user: '%s'", username));
    this.username = username;
  }

  public PasswordExpiredException(String username, Throwable cause) {
    super(String.format("Password expired for user: '%s'", username), cause);
    this.username = username;
  }
}
