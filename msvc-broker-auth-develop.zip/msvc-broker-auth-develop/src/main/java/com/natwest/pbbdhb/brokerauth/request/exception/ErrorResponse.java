package com.natwest.pbbdhb.brokerauth.request.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Builder
@JsonInclude(Include.NON_NULL)
@Getter
public class ErrorResponse {

  @JsonProperty("status")
  @Schema(
      description = "HTTP status code of error",
      example = "500"
  )
  int status;

  @JsonProperty("title")
  @Schema(
      description = "Title of error",
      example = "Internal Server Error"
  )
  String title;

  @JsonProperty("code")
  @Schema(
      description = "Enumerated error code",
      example = "INTERNAL_SERVER_ERROR",
      required = true
  )
  @NotNull
  ErrorCode code;

  @JsonProperty("description")
  @Schema(
      description = "Description of error",
      example = "Sorry, something went wrong."
  )
  String description;

  @JsonProperty("errors")
  @Schema(
      description = "List of errors encountered as part of request, typically validation failure errors"
  )
  List<ErrorResponseDetail> errors;

  public static ErrorResponse notFound(
      List<ErrorResponseDetail> details) {
    return ErrorResponse
        .builder()
        .status(HttpStatus.NOT_FOUND.value())
        .title("Not Found")
        .code(ErrorCode.NOT_FOUND)
        .description("The resource requested could not be found.")
        .errors(details)
        .build();
  }

  public static ErrorResponse invalidRequest(
      List<ErrorResponseDetail> details) {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("Invalid Request")
        .code(ErrorCode.INVALID_REQUEST)
        .description("The request has invalid or missing data.")
        .errors(details)
        .build();
  }

  public static ErrorResponse unauthorised() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Unauthorised")
        .code(ErrorCode.UNAUTHORISED)
        .description("You do not have access to this resource.")
        .build();
  }

  public static ErrorResponse invalidCredentials() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Unauthorised")
        .code(ErrorCode.INVALID_CREDENTIALS)
        .description("The credentials entered are invalid.")
        .build();
  }

  public static ErrorResponse invalidServerError() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
        .title("Internal Server Error")
        .code(ErrorCode.INTERNAL_SERVER_ERROR)
        .description("Our backend is non-functional, please try again later.")
        .build();
  }

  public static ErrorResponse expiredOtp() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Expired OTP")
        .code(ErrorCode.OTP_EXPIRED)
        .description("The OTP code has expired")
        .build();
  }

  public static ErrorResponse otpValidationFailed() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Something went wrong during OTP validation")
        .code(ErrorCode.OTP_VALIDATION_FAILED)
        .description("Please try again later")
        .build();
  }

  public static ErrorResponse userNotFound() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("User not found")
        .code(ErrorCode.USER_NOT_FOUND)
        .description("The username can not be found")
        .build();
  }

  public static ErrorResponse userAlreadyExists() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.CONFLICT.value())
        .title("User already exists")
        .code(ErrorCode.USER_ALREADY_EXISTS)
        .description("The username for the user already exists")
        .build();
  }

  public static ErrorResponse invalidDetails() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("Invalid Details")
        .code(ErrorCode.INVALID_DETAILS)
        .description("The input details are invalid")
        .build();
  }

  public static ErrorResponse accountLocked() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Account Locked")
        .code(ErrorCode.ACCOUNT_LOCKED)
        .description("Account is locked, please try again later.")
        .build();
  }

  public static ErrorResponse passwordExpired() {
    return ErrorResponse
            .builder()
            .status(HttpStatus.UNAUTHORIZED.value())
            .title("Password Expired")
            .code(ErrorCode.PASSWORD_EXPIRED)
            .description("Password is expired, please reset your password.")
            .build();
  }

  public static ErrorResponse securityQuestionValidationFailed() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Security Questions Validation Failed")
        .code(ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS)
        .description("One or more of the answers provided are incorrect.")
        .build();
  }

  public static ErrorResponse securityQuestionLocked() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Security Questions Locked")
        .code(ErrorCode.MEMORABLE_QUESTIONS_LOCKED)
        .description("Too many security questions have been answered incorrectly.")
        .build();
  }

  public static ErrorResponse securityQuestionNotFound() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("Security Questions Not Found")
        .code(ErrorCode.QUESTIONS_NOT_RETRIEVED)
        .description("Unable to find security questions for this user.")
        .build();
  }
}