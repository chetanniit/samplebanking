
package com.natwest.pbbdhb.brokerauth.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentPath {
    @JsonProperty("mbs_paymentpathname")
    @EqualsAndHashCode.Exclude
    private String name;
    @JsonProperty("mbs_paymentpathid")
    private String paymentId;
    @JsonProperty("mbs_residentialproductscale")
    public String residentialProductScale;
    @JsonProperty("mbs_btlproductscale")
    public String btlProductScale;
}
