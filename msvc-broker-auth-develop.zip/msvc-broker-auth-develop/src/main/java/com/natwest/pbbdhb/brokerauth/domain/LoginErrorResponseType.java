package com.natwest.pbbdhb.brokerauth.domain;

import lombok.NonNull;

public enum LoginErrorResponseType {
    PASSWORD_EXPIRED(0),
    ACCOUNT_LOCKED(1),
    NO_RECORDS_FOUND(10),
    INVALID_CREDENTIALS(49);


    private final int value;

    LoginErrorResponseType(@NonNull int value) { this.value = value; }

    public int getValue() {
        return value;
    }
}
