package com.natwest.pbbdhb.brokerauth.request.controller;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.request.controller.helpers.AccessTokenRequestHelper;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.LoginRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorResponse;
import com.natwest.pbbdhb.brokerauth.request.mapper.LoginRequestMapper;
import com.natwest.pbbdhb.brokerauth.service.login.LoginService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mortgages/v1/msvc-broker-auth/login")
@Tag(name = "User Login",
    description = "API for user login")
@Slf4j
@Validated
public class LoginController {

  private final AccessTokenRequestHelper accessTokenRequestHelper;
  private final AccessTokenService accessTokenService;
  private final LoginService loginService;

  @Autowired
  public LoginController(
      AccessTokenRequestHelper accessTokenRequestHelper,
      AccessTokenService accessTokenService,
      LoginService loginService) {
    this.accessTokenRequestHelper = accessTokenRequestHelper;
    this.accessTokenService = accessTokenService;
    this.loginService = loginService;
  }

  @Operation(
      operationId = "login",
      summary = "Authenticates a users credentials"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Login was successful"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @PostMapping
  @ResponseStatus(HttpStatus.OK)
  public BrokerType login(@RequestBody @Valid LoginRequest attempt) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("login: Login for user %s", attempt.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    GetUserResponseModel userDetails = loginService.login(
        accessToken,
        LoginRequestMapper.toLoginRequestModel(attempt));

    log.info("login: username: {}, login successful.", attempt.getUsername());
    return BrokerType.valueOf(
        userDetails.getBrokerType().getValue());
  }

  private String getAccessToken() {
    log.info("getAccessToken: Getting access token.");
    AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel =
        accessTokenRequestHelper.tokenRetrieveRequestModel();

    log.info("getAccessToken: Access token retrieved.");
    return accessTokenService.token(accessTokenRetrieveRequestModel).getAccessToken();
  }
}
