package com.natwest.pbbdhb.brokerauth.request.controller.helpers;

import com.google.common.collect.Lists;
import com.rbs.dws.correlation.RequestCorrelationIdContext;
import com.rbs.dws.server.tomcat.config.DESTomcatValvesConfig;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Helper that can provide the contents provided in the correlation id header and the internal
 * correlation id header of the current HTTP request.
 * <p>
 * Typically the correlation Id header is named "x-fapi-interaction-id" and the internal correlation
 * Id header is named "x-rbs-interaction-id".
 * <p>
 * This service retrieves the actual header names being used from the {@link DESTomcatValvesConfig}.
 * The contents of the headers are intercepted by "RequestCorrelationIdValve" valve and stored in a
 * thread local within {@link RequestCorrelationIdContext}.
 */
@Slf4j
@Service
public class CorrelationIdentifierHelper {

    private final List<String> correlationIdHeaders;
    private final List<String> internalCorrelationIdHeaders;

    @Autowired
    public CorrelationIdentifierHelper(DESTomcatValvesConfig valvesConfig) {
        // retrieve the list of configured correlation headers names.
        // we use the output headers since the RequestCorrelationIdValve valve stores the
        // correlation IDs against the output header name.
        this.correlationIdHeaders = Lists.newArrayList(
            valvesConfig
                .requestCorrelationId
                .getOutputHeaderName()
                .split(","));
        this.internalCorrelationIdHeaders = Lists.newArrayList(
            valvesConfig
                .requestInternalCorrelationId
                .getOutputHeaderName()
                .split(","));
    }

    /**
     * Return the value contained in the correlation id header.
     * <p>
     * In the case of multiple correlation headers, the first non-empty value will be returned.
     * <p>
     * This method uses {@link RequestCorrelationIdContext} that holds the values of all correlation
     * headers for the current API request.
     * <p>
     * Will return null if no non-empty values are found.
     *
     * @return contents of correlation id header
     */
    public String requestCorrelationId() {
        log.debug("requestCorrelationId: Requesting correlationId.");
        return correlationIdHeaders
            .stream()
            .map(RequestCorrelationIdContext::get)
            .filter(StringUtils::isNotBlank)
            .findFirst()
            .orElse(null);
    }

    /**
     * Return the value contained in the internal correlation id header.
     * <p>
     * In the case of multiple internal correlation headers, the first non-empty value will be
     * returned.
     * <p>
     * This method uses {@link RequestCorrelationIdContext} that holds the values of all correlation
     * headers for the current API request.
     * <p>
     * Will return null if no non-empty values are found.
     *
     * @return contents of internal correlation id header
     */
    public String requestInternalCorrelationId() {
        log.debug("requestInternalCorrelationId: Requesting internalCorrelationId.");
        return internalCorrelationIdHeaders
            .stream()
            .map(RequestCorrelationIdContext::get)
            .filter(StringUtils::isNotBlank)
            .findFirst()
            .orElse(null);
    }
}
