package com.natwest.pbbdhb.brokerauth.service.login;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LoginService {

  private final CustomerIdentityManagementClient client;

  @Autowired
  public LoginService(CustomerIdentityManagementClient client) {
    this.client = client;
  }

  public GetUserResponseModel login(String accessToken, LoginRequestModel attempt) {
    log.debug("login: Attempting login for UserName: {}", attempt.getUsername());
    client.login(accessToken, attempt);
    log.debug("login: login for UserName: {}, successful", attempt.getUsername());

    return client.getUser(accessToken, attempt.getUsername());
  }
}
