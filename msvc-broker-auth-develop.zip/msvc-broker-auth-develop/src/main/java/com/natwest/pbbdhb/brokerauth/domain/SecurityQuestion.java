package com.natwest.pbbdhb.brokerauth.domain;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class SecurityQuestion {

  @NotBlank
  String question;

  @NotBlank
  String answer;

}
