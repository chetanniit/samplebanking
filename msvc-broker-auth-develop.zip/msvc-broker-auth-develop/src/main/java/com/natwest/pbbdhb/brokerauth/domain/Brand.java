package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Getter;

/**
 * Represents all supported brands.
 */
@Getter
public enum Brand {

  NWB("nwb");

  private final String value;

  Brand(String value) {
    this.value = value;
  }

  public static Brand fromValue(String text) {
    for (Brand brand : Brand.values()) {
      if (brand.value.equalsIgnoreCase(text)) {
        return brand;
      }
    }
    throw new IllegalArgumentException("Unsupported brand: " + text);
  }
}
