package com.natwest.pbbdhb.brokerauth.service.crm;

import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UpdateBrokerDetailsResponse;

public interface BrokerDetailsService {
  BrokerDetailsResponse getBrokerDetails(String brokerUserName);

  UpdateBrokerDetailsResponse updateDetails(BrokerDetailsChangeRequest brokerDetailsChangeRequest);

  BrokerDetailsResponse getAdminDetails(String brokerUserName);
}
