package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class GetUserResponseModel {

  /**
   * The type of user. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  BrokerTypeModel brokerType;

  @NonNull
  String id;

  @NonNull
  String parentId;
}
