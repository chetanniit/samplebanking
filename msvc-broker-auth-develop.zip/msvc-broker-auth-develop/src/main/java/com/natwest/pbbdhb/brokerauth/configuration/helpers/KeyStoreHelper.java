package com.natwest.pbbdhb.brokerauth.configuration.helpers;

import com.natwest.pbbdhb.brokerauth.exception.KeystoreException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import lombok.experimental.UtilityClass;
import org.springframework.util.ResourceUtils;

@UtilityClass
public class KeyStoreHelper {

  public static KeyStore keyStore(String type, String file, char[] password) {
    try {
      KeyStore keyStore = KeyStore.getInstance(type);
      File key = ResourceUtils.getFile(file);
      try (InputStream in = new FileInputStream(key)) {
        keyStore.load(in, password);
      } catch (IOException | CertificateException | NoSuchAlgorithmException e) {
        throw new KeystoreException("Unable to load keystore: " + file, e);
      }
      return keyStore;
    } catch (FileNotFoundException e) {
      throw new KeystoreException("Unable to find keystore file: " + file, e);
    } catch (KeyStoreException e) {
      throw new KeystoreException("Unable to create keystore from: " + file, e);
    }
  }
}
