package com.natwest.pbbdhb.brokerauth.service.crm;

import com.natwest.pbbdhb.brokerauth.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.AdminDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeCrmRequest;

public interface CrmService {
  BrokerCoreResponse getBrokerDetails(String brokerUserName);

  AdminCoreResponse getAdminDetails(String brokerUserName);

  void updateBrokerDetails(BrokerDetailsChangeCrmRequest brokerDetailsChangeCrmRequest);

  void updateAdminDetails(AdminDetailsChangeCrmRequest adminDetailsChangeCrmRequest);

  BrokerAssociationsResponse getBrokerAssociations(String userName);

  BrokerAssociationsResponse getBrokerUnAssociations(String userName);

  AdminAssociationsResponse getAdminAssociations(String userName);

  BrokerPermissionsResponse associateBrokerToBroker(String userName, String userNameToAssociate);

  BrokerPermissionsResponse unAssociateBrokerToBroker(String userName, String userNameToUnAssociate);

  BrokerPermissionsResponse associateBrokerToAdmin(String userName, String adminToAssociate);

  BrokerPermissionsResponse unAssociateBrokerToAdmin(String userName, String adminToUnAssociate);
}
