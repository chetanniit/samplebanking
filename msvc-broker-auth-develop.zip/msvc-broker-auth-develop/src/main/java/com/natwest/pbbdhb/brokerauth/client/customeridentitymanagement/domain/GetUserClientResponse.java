package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.extern.jackson.Jacksonized;

@Builder
@Getter
@Jacksonized
public class GetUserClientResponse {

  @JsonProperty("Resources")
  List<GetUserResources> resources;

  @Builder
  @Getter
  @Jacksonized
  public static class GetUserResources {

    @NonNull
    @JsonProperty("personaidentifiertype")
    BrokerTypeModel brokerType;

    @NonNull
    @JsonProperty("id")
    String id;

    @NonNull
    @JsonProperty("parentidentity")
    String parentId;
  }
}
