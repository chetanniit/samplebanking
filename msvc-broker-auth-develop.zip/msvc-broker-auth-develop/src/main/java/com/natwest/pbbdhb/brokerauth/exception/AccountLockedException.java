package com.natwest.pbbdhb.brokerauth.exception;

import lombok.Getter;

/**
 * An exception to be thrown when login returns account locked.
 */
@Getter
public class AccountLockedException extends RuntimeException {

  private final String username;

  public AccountLockedException(String username) {
    super(String.format("Account locked for user: '%s'", username));
    this.username = username;
  }

  public AccountLockedException(String username, Throwable cause) {
    super(String.format("Account locked for user: '%s'", username), cause);
    this.username = username;
  }
}
