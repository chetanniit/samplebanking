package com.natwest.pbbdhb.brokerauth.service.crm;

import org.springframework.stereotype.Service;

@Service
public interface CRMClient<R, T> {
    T get(String endpoint, Class<T> responseType);
    T post(String endpoint, R body, Class<T> responseType);
}
