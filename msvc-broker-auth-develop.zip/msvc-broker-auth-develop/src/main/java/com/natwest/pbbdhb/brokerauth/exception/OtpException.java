package com.natwest.pbbdhb.brokerauth.exception;

import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;

public class OtpException extends RuntimeException {

  private ErrorCode code;

  public OtpException(ErrorCode code, String message) {
    super(message);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }
}