package com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerPermissionsRequest {
    @JsonProperty("mbs_userName")
    private String userName;
    @JsonProperty("mbs_associateBrokers")
    private List<String> associateBrokers;
    @JsonProperty("mbs_dissociateBrokers")
    private List<String> dissociateBrokers;
    @JsonProperty("mbs_associateBrokerAdmins")
    private List<String> associateBrokerAdmins;
    @JsonProperty("mbs_dissociateBrokerAdmins")
    private List<String> dissociateBrokerAdmins;
}
