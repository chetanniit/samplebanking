package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.PasswordChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.PasswordResetRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.OtpValidateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordResetRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsRequest;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountManagementRequestMapper {

  private AccountManagementRequestMapper() {
  }

  public static PasswordResetRequestModel toPasswordResetRequestModel(
      PasswordResetRequest request) {
    log.debug("toPasswordResetRequestModel: Mapping PasswordResetRequest");
    return PasswordResetRequestModel.builder()
        .username(request.getUsername())
        .otpCode(request.getOtpCode())
        .password(request.getPassword())
        .build();
  }

  public static PasswordChangeRequestModel toPasswordChangeRequestModel(
      PasswordChangeRequest request) {
    log.debug("toPasswordChangeRequestModel: Mapping PasswordChangeRequestModel");
    return PasswordChangeRequestModel.builder()
        .username(request.getUsername())
        .currentPassword(request.getCurrentPassword())
        .newPassword(request.getNewPassword())
        .build();
  }

  public static OtpValidateRequestModel toOtpValidateRequestModel(
      OtpValidateRequest request) {
    log.debug("toOtpValidateRequestModel: Mapping OtpValidateRequest");
    return OtpValidateRequestModel.builder()
        .otpCode(request.getOtpCode())
        .username(request.getUsername())
        .build();
  }

  public static OtpValidateRequestModel toOtpValidateRequestModel(
      PasswordResetRequestModel request) {
    log.debug("toOtpValidateRequestModel: Mapping PasswordResetRequestModel to OtpValidateRequestModel");
    return OtpValidateRequestModel.builder()
        .otpCode(request.getOtpCode())
        .username(request.getUsername())
        .build();
  }

  public static UserSetPasswordRequestModel toUserSetPasswordRequestModel(
      PasswordResetRequestModel request, @NonNull String customerIdentifier) {
    log.debug("toUserSetPasswordRequestModel: Mapping UserSetPasswordRequestModel");
    return UserSetPasswordRequestModel.builder()
        .password(request.getPassword())
        .customerIdentifier(customerIdentifier)
        .build();
  }

  public static UserChangePasswordRequestModel toUserChangePasswordRequestModel(
      PasswordChangeRequestModel request, @NonNull String customerIdentifier) {
    log.debug("toUserChangePasswordRequestModel: Mapping UserChangePasswordRequestModel");
    return UserChangePasswordRequestModel.builder()
        .currentPassword(request.getCurrentPassword())
        .newPassword(request.getNewPassword())
        .customerIdentifier(customerIdentifier)
        .build();
  }

  public static SecurityQuestionsFetchRequestModel toSecurityQuestionsFetchRequestModel(
      RetrieveMemorableQuestionsRequest request) {
    log.debug("toSecurityQuestionsFetchRequestModel: Mapping SecurityQuestionsFetchRequestModel");
    return SecurityQuestionsFetchRequestModel.builder()
        .username(request.getUsername())
        .build();
  }

  public static SecurityQuestionsValidationRequestModel toSecurityQuestionsValidationRequestModel(
      ChallengeAnswersRequest request) {
    log.debug("toSecurityQuestionsValidationRequestModel: Mapping SecurityQuestionsValidationRequestModel");
    return SecurityQuestionsValidationRequestModel.builder()
        .username(request.getUsername())
        .questions(SecurityQuestionMapper.toSecurityQuestionDomainObjectList(
            request.getSecurityQuestions()))
        .build();
  }

  public static SecurityQuestionsChangeRequestModel toSecurityQuestionsChangeRequestModel(
      ChangeMemorableQuestionsRequest request) {
    log.debug("toSecurityQuestionsChangeRequestModel: Mapping SecurityQuestionsChangeRequestModel");
    return SecurityQuestionsChangeRequestModel.builder()
        .username(request.getUsername())
        .questions(
            SecurityQuestionMapper.changeMemorableQuestionSecurityQuestionToSecurityQuestionDomainObjectList(
                request.getQuestions()))
        .build();
  }
}