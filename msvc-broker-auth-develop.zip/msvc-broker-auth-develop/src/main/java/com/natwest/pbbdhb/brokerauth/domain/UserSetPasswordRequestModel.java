package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class UserSetPasswordRequestModel {

  @NonNull
  String customerIdentifier;

  @NonNull
  String password;

}
