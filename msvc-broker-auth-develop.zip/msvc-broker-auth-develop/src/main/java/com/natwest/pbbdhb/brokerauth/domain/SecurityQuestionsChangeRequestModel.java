package com.natwest.pbbdhb.brokerauth.domain;

import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/**
 * A domain definition of the payload supplied to controller when caller wants to change a user's
 * security questions.
 */
@Validated
@Value
@Builder
public class SecurityQuestionsChangeRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's security questions. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  List<SecurityQuestion> questions;
}
