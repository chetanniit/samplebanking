
package com.natwest.pbbdhb.brokerauth.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrokerDetails {

    @JsonProperty("mbs_brokerid")
    private String brokerID;
    @JsonProperty("mbs_username")
    private String userName;
    @JsonProperty("mbs_title")
    private String title;
    @JsonProperty("mbs_brokername")
    private String brokerName;
    @JsonProperty("mbs_firstname")
    private String firstName;
    @JsonProperty("mbs_lastname")
    private String lastName;
    @JsonProperty("mbs_middlename")
    private String middleName;
    @JsonProperty("mbs_emailaddress")
    private String emailAddress;
    @JsonProperty("mbs_mobilenumber")
    private String mobileNumber;
    @JsonProperty("mbs_businessphone")
    private String businessPhone;
    @JsonProperty("mbs_brokerpostcode")
    private String brokerPostcode;
    @JsonProperty("mbs_nationality")
    private String nationality;
    @JsonProperty("mbs_residentialaddressline1")
    private String residentialAddressLine1;
    @JsonProperty("mbs_residentialaddressline2")
    private String residentialAddressLine2;
    @JsonProperty("mbs_residentialaddressline3")
    private String residentialAddressLine3;
    @JsonProperty("mbs_residentialcity")
    private String residentialCity;
    @JsonProperty("mbs_residentialcounty")
    private String residentialCounty;
    @JsonProperty("mbs_residentialcountry")
    private String residentialCountry;
    @JsonProperty("mbs_residentialpostcode")
    private String residentialPostcode;
}
