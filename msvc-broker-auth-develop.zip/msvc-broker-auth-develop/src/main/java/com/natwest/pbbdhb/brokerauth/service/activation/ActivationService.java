package com.natwest.pbbdhb.brokerauth.service.activation;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import com.natwest.pbbdhb.brokerauth.request.mapper.ActivationRequestMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * A Activation service class which provides business logic operations on activation codes.
 */
@Service
@Slf4j
public class ActivationService {

  private static final String USED = "Used";
  private final CustomerIdentityManagementClient customerIdentityManagementClient;

  /**
   * Creates a new instance of the ActivationCodeService
   *
   * @param customerIdentityManagementClient An instance of the CustomerIdentityManagementClient
   */
  public ActivationService(
      CustomerIdentityManagementClient customerIdentityManagementClient) {
    this.customerIdentityManagementClient = customerIdentityManagementClient;
  }

  public void validateActivationCode(String accessToken,
      OtpValidateRequestModel otpValidateRequestModel) {
    log.debug("validateActivationCode: Validating activation code for username: {}", otpValidateRequestModel.getUsername());
    customerIdentityManagementClient.validateOtp(accessToken, otpValidateRequestModel);
    log.debug("validateActivationCode: Activation code for username: {}, successfully validated", otpValidateRequestModel.getUsername());
  }

  /**
   * Handles activating an account for a user, this method: - validates their otp code - makes their
   * account as activated - set's their password and security questions - consumes their otp code
   *
   * @param request     The activation request information
   * @param accessToken The access token for calling iam services
   */
  public void activateUser(UserActivateRequest request, String accessToken) {

    log.debug("activateUser: Activating user: {}", request.getUsername());

    GetUserResponseModel customerIdentifier = customerIdentityManagementClient.getUser(accessToken,
        request.getUsername());

    customerIdentityManagementClient.validateOtp(accessToken,
        ActivationRequestMapper.toOtpValidateRequestModel(request));
    customerIdentityManagementClient.activateAccount(accessToken, customerIdentifier.getId());
    customerIdentityManagementClient.setPassword(accessToken,
        ActivationRequestMapper.toUserSetPasswordRequestModel(request,
            customerIdentifier.getId()));
    customerIdentityManagementClient.createSecurityQuestions(accessToken,
        ActivationRequestMapper.toSecurityQuestionsRequestModel(request,
            customerIdentifier.getParentId()));
    String otpId = customerIdentityManagementClient.retrieveOTP(accessToken, request.getUsername())
        .getOtpId();
    customerIdentityManagementClient.updateOTP(accessToken, ActivationRequestMapper.toActivationCodeUpdateRequestModel(otpId, USED));
    log.debug("activateUser: User: {}, successfully activated", request.getUsername());
  }

}
