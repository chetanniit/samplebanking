
package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UsernameReminderResponse {
    @JsonAlias("mbs_usernameIdentified")
    private Boolean usernameIdentified;
    @JsonAlias("mbs_message")
    private String message;
}
