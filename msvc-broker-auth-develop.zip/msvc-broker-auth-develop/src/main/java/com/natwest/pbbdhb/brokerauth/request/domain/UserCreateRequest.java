package com.natwest.pbbdhb.brokerauth.request.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/**
 * A domain definition of the payload supplied to controller when caller wants to create a user.
 */
@Validated
@Value
@Builder
public class UserCreateRequest {

  @Schema(
      description = "Specifies user's first name",
      required = true
  )
  @NonNull
  String firstname;

  @Schema(
      description = "Specifies user's last name",
      required = true
  )
  @NonNull
  String lastname;


  @Schema(
      description = "Specifies user's email",
      example = "test@email.com",
      required = true
  )
  @NonNull
  String email;

  @Schema(
      description = "Specifies user's username",
      required = true
  )
  @NonNull
  String username;

  @Schema(
      description = "Specifies the user's broker type",
      example = "BROKER",
      required = true
  )
  @NonNull
  BrokerType brokerType;
}
