package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonValue;


/**
 * A domain definition of the type of broker, which is recognised by any caller.
 */
public enum BrokerType {
  ADMIN("ADMIN"),
  BROKER("BROKER");

  private final String value;

  BrokerType(String value) {
    this.value = value;
  }

  public static BrokerType fromValue(String text) {
    for (BrokerType brand : BrokerType.values()) {
      if (brand.value.equalsIgnoreCase(text)) {
        return brand;
      }
    }
    throw new IllegalArgumentException("Unsupported broker type: " + text);
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }
}
