package com.natwest.pbbdhb.brokerauth.request.security;

import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import java.security.GeneralSecurityException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

/**
 * Responsible for retrieving user principal claims contained in our request.
 * <p>
 * Each request will hold claims within a UserPrincipal. This class will retrieve the current
 * request's UserPrincipal and will then extract the specific claims required.
 */
@Slf4j
@Service
@ConditionalOnProperty(name = "features.user-claims-mode", havingValue = "iam", matchIfMissing = true)
public class IamUserClaimsProvider implements UserClaimsProvider {

  private static final String OPERATING_BRAND_CLAIM = "operating_brand";
  private static final String ACCESS_TOKEN_CLAIM = "access_token";

  private final UserPrincipalProvider userPrincipalProvider;

  @Autowired
  public IamUserClaimsProvider(UserPrincipalProvider userPrincipalProvider) {
    this.userPrincipalProvider = userPrincipalProvider;
  }

  public Brand getOperatingBrand() {
    log.debug("getOperatingBrand: Getting operating brand.");
    String operatingBrand = getStringClaim(OPERATING_BRAND_CLAIM);
    log.debug("getOperatingBrand: Operating brand successfully retrieved.");
    return Brand.fromValue(operatingBrand);
  }

  public String getAccessToken() {
    log.debug("getAccessToken: Getting operating brand.");
    return getStringClaim(ACCESS_TOKEN_CLAIM);
  }

  private String getStringClaim(
      final String claimName) {
    log.debug("getStringClaim: Getting string claim.");
    final UserPrincipal userPrincipal = getUserPrincipal();
    final String claimValue = (String) userPrincipal.getProperty(claimName);

    if (StringUtils.isNotBlank(claimValue)) {
      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.JWT)
          .description(String.format("getStringClaim: Retrieved claim: %s=%s", claimName, claimValue))
          .build()
      );
      log.debug("getStringClaim: String claim successfully retrieved.");
      return claimValue;
    }
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.JWT)
        .subtype(LogMessageSubtype.INPUT_VALIDATION)
        .description(String.format("getStringClaim: Could not retrieve claim: %s", claimName))
        .build()
    );
    throw new IllegalStateException("Could not retrieve claim: " + claimName);
  }

  private UserPrincipal getUserPrincipal() {
    log.debug("getUserPrincipal: Getting user principal.");
    try {
      log.debug("getUserPrincipal: User principal successfully retrieved.");
      return Optional
          .ofNullable(userPrincipalProvider.get())
          .orElseThrow(() -> new IllegalStateException("getUserPrincipal: UserPrincipal can not be null"));
    } catch (GeneralSecurityException e) {
      log.warn("getUserPrincipal: Unable to retrieve UserPrincipal.");
      throw new IllegalStateException("getUserPrincipal: Unable to retrieve UserPrincipal", e);
    }
  }
}
