package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.jackson.Jacksonized;

@Builder
@Getter
@Jacksonized
public class OtpValidateClientResponse {

  @JsonProperty("Resources")
  List<OtpResource> resources;


  @JsonProperty("totalResults")
  int totalResults;

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class OtpResource {

    @JsonProperty("returncode")
    OtpValidateReturnCode returnCode;
  }
}
