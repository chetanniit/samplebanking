package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A controller request domain model describing the payload returned by the challenge questions
 * endpoint.
 */
@Builder
@Value
public class RetrieveMemorableQuestionsResponse {

  @NonNull
  List<String> securityQuestions;

  // Lombok doesn't like single member classes, so manually added a constructor
  @JsonCreator
  public RetrieveMemorableQuestionsResponse(
      @JsonProperty("securityQuestions") List<String> securityQuestions) {
    this.securityQuestions = securityQuestions;
  }

}