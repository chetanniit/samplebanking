package com.natwest.pbbdhb.brokerauth.request.domain;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
public class PaymentPath {

  @NotNull
  @EqualsAndHashCode.Exclude
  private String name;

  @NotNull
  private String paymentId;

}
