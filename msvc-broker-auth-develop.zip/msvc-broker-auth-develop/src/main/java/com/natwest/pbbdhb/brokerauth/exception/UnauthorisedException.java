package com.natwest.pbbdhb.brokerauth.exception;


import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;

public class UnauthorisedException extends RuntimeException {

  private ErrorCode code;

  public UnauthorisedException(ErrorCode code, Exception ex) {
    super(ex.getMessage(), ex);
    this.code = code;
  }

  public UnauthorisedException(ErrorCode code, String message) {
    super(message);
    this.code = code;
  }

  public UnauthorisedException(ErrorCode code, String message, Exception ex) {
    super(message, ex);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }

}
