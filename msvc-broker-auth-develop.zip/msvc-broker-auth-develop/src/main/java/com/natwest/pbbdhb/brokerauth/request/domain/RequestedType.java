package com.natwest.pbbdhb.brokerauth.request.domain;

public enum RequestedType {
    STP, NON_STP
}
