package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersRequest;

import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class SecurityQuestionMapper {

    private SecurityQuestionMapper() {
    }

    public static SecurityQuestion toSecurityQuestionDomainObject(
            ChallengeAnswersRequest.SecurityQuestion input) {
        log.debug("toSecurityQuestionDomainObject: Mapping ChallengeAnswersRequest.SecurityQuestion to SecurityQuestion.");
        return SecurityQuestion.builder()
                .question(input.getQuestion())
                .answer(input.getAnswer())
                .build();
    }

    public static SecurityQuestion changeMemorableQuestionSecurityQuestionToSecurityQuestionDomainObject(
        ChangeMemorableQuestionsRequest.SecurityQuestion input) {
        log.debug("changeMemorableQuestionSecurityQuestionToSecurityQuestionDomainObject: Mapping" +
                " ChangeMemorableQuestionsRequest.SecurityQuestion to SecurityQuestion.");
        return SecurityQuestion.builder()
            .question(input.getQuestion())
            .answer(input.getAnswer())
            .build();
    }

    public static List<SecurityQuestion> toSecurityQuestionDomainObjectList(
            List<ChallengeAnswersRequest.SecurityQuestion> input) {
        log.debug("toSecurityQuestionDomainObjectList: Mapping list of ChallengeAnswersRequest.SecurityQuestion to " +
                "list of SecurityQuestions.");
        return input.stream().map(SecurityQuestionMapper::toSecurityQuestionDomainObject)
                .collect(Collectors.toList());
    }

    public static List<SecurityQuestion> changeMemorableQuestionSecurityQuestionToSecurityQuestionDomainObjectList(
        List<ChangeMemorableQuestionsRequest.SecurityQuestion> input) {
        log.debug("changeMemorableQuestionSecurityQuestionToSecurityQuestionDomainObjectList: Mapping list of" +
                " ChangeMemorableQuestionsRequest.SecurityQuestion to list of SecurityQuestions.");
        return input.stream().map(SecurityQuestionMapper::changeMemorableQuestionSecurityQuestionToSecurityQuestionDomainObject)
            .collect(Collectors.toList());
    }

}
