package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionLockedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionResponseException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionValidateException;
import java.util.function.Consumer;
import lombok.NonNull;

/**
 * Enum to map possible values for the return code when validating a security question from CIM
 */
public enum SecurityQuestionValidateReturnCode {

  SUCCESS("0", (username) -> {
  }),
  INVALID_QUESTION_ANSWER("1", (username) -> {
    throw new SecurityQuestionValidateException(
        "Question/Answer is invalid for user: " + username);
  }),
  QUESTIONS_LOCKED("2", (username) -> {
    throw new SecurityQuestionLockedException(
        "Questions are locked for user: " + username);
  }),
  DECODING_FAILURE("3", (username) -> {
    throw new SecurityQuestionResponseException(
        "Decoding failure for user: " + username);
  }),
  UNKNOWN_SERVICE_FAILURE("4", (username) -> {
    throw new SecurityQuestionResponseException(
        "Unknown service failure for user: " + username);
  });

  private final String value;
  private final Consumer<String> assertion;

  SecurityQuestionValidateReturnCode(@NonNull String value, Consumer<String> assertion) {
    this.value = value;
    this.assertion = assertion;
  }

  public void validate(String username) {
    assertion.accept(username);
  }

  /**
   * Create an enum value from a String equivalent
   *
   * @param text The original string value
   * @return OtpValidateReturnCode
   */
  @JsonCreator
  public static SecurityQuestionValidateReturnCode fromValue(String text) {
    for (SecurityQuestionValidateReturnCode code : SecurityQuestionValidateReturnCode.values()) {
      if (code.value.equals(text)) {
        return code;
      }
    }
    return null;
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }
}