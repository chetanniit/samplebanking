package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/**
 * Represents password reset request
 */
@Validated
@Value
@Builder
public class PasswordResetRequest {

  @JsonProperty("username")
  @Schema(
      description = "Username from a user's credentials",
      required = true
  )
  @NotNull String username;

  @JsonProperty("otpCode")
  @Schema(
      description = "The otp code for validation",
      required = true
  )
  @NotNull String otpCode;

  @JsonProperty("password")
  @Schema(
      description = "User's password",
      required = true
  )
  @NotNull String password;
}