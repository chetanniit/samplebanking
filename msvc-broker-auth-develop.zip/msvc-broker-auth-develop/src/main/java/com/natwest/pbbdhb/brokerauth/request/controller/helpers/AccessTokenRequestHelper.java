package com.natwest.pbbdhb.brokerauth.request.controller.helpers;

import com.natwest.pbbdhb.brokerauth.configuration.IamScimConfig;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.JsonWebTokenModel;
import com.natwest.pbbdhb.brokerauth.domain.JsonWebTokenModel.PayloadModel.PayloadModelBuilder;
import com.natwest.pbbdhb.brokerauth.request.security.UserClaimsProvider;
import com.natwest.pbbdhb.brokerauth.service.signing.JwtSigningService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Helper to create access token request model.
 */
@Slf4j
@Service
public class AccessTokenRequestHelper {

  private final IamScimConfig config;
  private final JwtSigningService jwtSigner;
  private final UserClaimsProvider claimsProvider;

  @Autowired
  public AccessTokenRequestHelper(
      IamScimConfig config,
      JwtSigningService jwtSigner,
      UserClaimsProvider claimsProvider) {
    this.config = config;
    this.jwtSigner = jwtSigner;
    this.claimsProvider = claimsProvider;
  }

  /**
   * Create an access token retrieve request model from the supplied controller request.
   * <p>
   * This is more than just a mapper as this helper requires the ability to:
   * <p>
   * - Pull claims from the user principal.
   * <p>
   * - Extract the correlation IDs from the configured correlation headers.
   * <p>
   * - Create a signed JWT suitable for this access token request.
   *
   * @return access token retrieve request model
   */
  public AccessTokenRetrieveRequestModel tokenRetrieveRequestModel() {

    log.debug("Inside AccessTokenRequestHelper: Building AccessTokenRetrieveRequestModel.");

    final JsonWebTokenModel jwtModel = jwtModel(buildPayload().build());

    return AccessTokenRetrieveRequestModel
        .builder()
        .brand(claimsProvider.getOperatingBrand())
        .clientAssertionType(config.getClientAssertionType())
        .clientAssertion(jwtSigner.createJwt(jwtModel))
        .clientId(jwtModel.getPayload().getClientId())
        .grantType(config.getGrantType())
        .scope(config.getScope())
        .build();
  }

  /**
   * Create JWT model for our access token request
   *
   * @param payload - the desired payload for the jwt
   * @return JWT model
   */
  private JsonWebTokenModel jwtModel(JsonWebTokenModel.PayloadModel payload) {

    log.debug("jwtModel: Building JsonWebTokenModel.");
    // build JWT model
    return JsonWebTokenModel
        .builder()
        .header(JsonWebTokenModel.HeaderModel.builder()
            .algorithm(config.getAlgorithm())
            .build())
        .payload(payload)
        .build();
  }

  /**
   * Builds the payload for the jwt model
   *
   * @return access token request jwt payload builder, which can have details added to it if required
   */
  private PayloadModelBuilder buildPayload() {
    log.debug("buildPayload: Building payload.");
    // retrieve the config specific to our brand
    final IamScimConfig.BrandedConfig brandedConfig = config
        .getBrands()
        .get(claimsProvider.getOperatingBrand());

    log.debug("buildPayload: Payload successfully built.");
    return JsonWebTokenModel.PayloadModel.builder()
        .issuer(brandedConfig.getIssuer())
        .subject(brandedConfig.getClientId())
        .audience(brandedConfig.getAudience())
        .clientId(brandedConfig.getClientId())
        .brand(claimsProvider.getOperatingBrand());
  }
}
