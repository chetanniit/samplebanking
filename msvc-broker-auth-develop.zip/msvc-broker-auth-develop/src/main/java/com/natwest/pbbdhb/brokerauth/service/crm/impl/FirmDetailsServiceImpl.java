package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetailsCoreResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.mapper.FirmDetailsMapper;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import com.natwest.pbbdhb.brokerauth.service.crm.FirmDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

@Service
@Slf4j
public class FirmDetailsServiceImpl implements FirmDetailsService {

  private final CRMClient crmClient;
  private final String firmDetailsEndpoint;

  public FirmDetailsServiceImpl(CRMClient crmClient,
                                @Value("${broker.crm.firm.details.endpoint}") String firmDetailsEndpoint) {
    this.crmClient = crmClient;
    this.firmDetailsEndpoint = firmDetailsEndpoint;
  }

  @Override
  public FirmDetailsResponse getFirmDetails(String fcaNumber) {
    log.debug("getFirmDetails: Getting firm details for fcaNumber: {}", fcaNumber);
    try {
      FirmDetailsCoreResponse firmDetailsCoreResponse = (FirmDetailsCoreResponse) crmClient.get(String.format(firmDetailsEndpoint, fcaNumber),
          FirmDetailsCoreResponse.class);
      log.debug("getFirmDetails: Firm details for fcaNumber: {}, successfully retrieved", fcaNumber);
      return FirmDetailsMapper.toFirmDetailsResponse(firmDetailsCoreResponse, fcaNumber);
    } catch (RestClientException ex) {
      log.warn("getFirmDetails: Error getting firm details for fcaNumber {}", fcaNumber, ex);
      throw new RemoteRequestFailedException(
          String.format("getFirmDetails: Request failed for fcaNumber %s", fcaNumber), ex);
    }
  }

}
