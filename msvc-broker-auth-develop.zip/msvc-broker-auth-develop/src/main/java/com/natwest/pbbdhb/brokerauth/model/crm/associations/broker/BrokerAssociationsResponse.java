package com.natwest.pbbdhb.brokerauth.model.crm.associations.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.common.AssociatedBrokerDetails;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrokerAssociationsResponse {

    @JsonProperty("mbs_brokerAdmins")
    private List<BrokerAdminDetails> admins;
    @JsonProperty("mbs_brokers")
    private List<AssociatedBrokerDetails> brokers;
    @JsonProperty("mbs_grantedPermissionBrokers")
    private List<AssociatedBrokerDetails> grantedPermissionBrokers;
    @JsonProperty("mbs_message")
    private String message;

}
