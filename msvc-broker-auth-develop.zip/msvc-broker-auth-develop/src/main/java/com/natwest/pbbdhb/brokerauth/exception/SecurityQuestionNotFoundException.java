package com.natwest.pbbdhb.brokerauth.exception;

/**
 * Used to indicate a user's security questions can not be found.
 */
public class SecurityQuestionNotFoundException extends RuntimeException {

  public SecurityQuestionNotFoundException(String message) {
    super(message);
  }
}