package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.extern.jackson.Jacksonized;

@Builder
@Getter
@Jacksonized
public class OtpRetrieveClientResponse {

  @JsonProperty("Resources")
  List<OtpRetrieveResources> resources;

  @Builder
  @Getter
  @Jacksonized
  public static class OtpRetrieveResources {

    @NonNull
    String id;
  }
}

