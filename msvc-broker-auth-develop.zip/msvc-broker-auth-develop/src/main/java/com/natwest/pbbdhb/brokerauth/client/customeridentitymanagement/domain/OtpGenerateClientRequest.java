package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class OtpGenerateClientRequest {

  @NonNull
  List<String> schemas;
}
