package com.natwest.pbbdhb.brokerauth.request.domain;

import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
public class PrincipalFcaFirm {

  @NotNull
  private String name;

  @NotNull
  private String fcaNumber;

}
