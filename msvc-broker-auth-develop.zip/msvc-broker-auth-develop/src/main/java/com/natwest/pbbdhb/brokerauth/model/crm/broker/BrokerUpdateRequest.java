package com.natwest.pbbdhb.brokerauth.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrokerUpdateRequest {

    @JsonProperty("mbs_requesttype")
    private String requesttype;
    @JsonProperty("mbs_status")
    private String status;
}
