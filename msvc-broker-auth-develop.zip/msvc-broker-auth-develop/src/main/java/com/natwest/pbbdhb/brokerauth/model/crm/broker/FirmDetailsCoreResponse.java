package com.natwest.pbbdhb.brokerauth.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FirmDetailsCoreResponse {
    @JsonProperty("mbs_firmtype")
    private String firmType;
    @JsonProperty("mbs_alternativetradingnames")
    private List<TradingName> alternativeTradingNames;
    @JsonProperty("mbs_paymentpath")
    private List<FirmDetailsPaymentPath> paymentPaths;
    @JsonProperty("mbs_principalfcafirm")
    private List<PrincipalFcaFirm> principalFcaFirms;
}
