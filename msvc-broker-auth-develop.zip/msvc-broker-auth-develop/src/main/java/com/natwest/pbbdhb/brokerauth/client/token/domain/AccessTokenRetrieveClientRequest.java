package com.natwest.pbbdhb.brokerauth.client.token.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class AccessTokenRetrieveClientRequest {

  @NonNull
  @JsonProperty("scope")
  String scope;

  @NonNull
  @JsonProperty("client_assertion")
  String clientAssertion;

  @NonNull
  @JsonProperty("client_assertion_type")
  String clientAssertionType;

  @NonNull
  @JsonProperty("client_id")
  String clientId;

  @NonNull
  @JsonProperty("grant_type")
  String grantType;
}
