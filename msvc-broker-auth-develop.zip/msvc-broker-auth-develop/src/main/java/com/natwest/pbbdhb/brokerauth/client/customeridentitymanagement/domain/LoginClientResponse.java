package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.jackson.Jacksonized;

@Builder
@Getter
@Jacksonized
public class LoginClientResponse {

  @JsonProperty("Resources")
  List<LoginResources> resources;

  @Builder
  @Getter
  @Jacksonized
  public static class LoginResources {

    @JsonProperty("errorcode")
    Integer errorCode;
  }
}

