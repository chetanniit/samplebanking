package com.natwest.pbbdhb.brokerauth.service.crm;

import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;

public interface FirmDetailsService {
  FirmDetailsResponse getFirmDetails(String fcaNumber);
}
