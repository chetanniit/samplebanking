package com.natwest.pbbdhb.brokerauth.configuration;

import java.net.URI;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

/**
 * A configuration class for the Access Token client covering stub properties.
 *
 * {@code @ConstructorBinding} has been set so config can be immutable.
 */
@ConfigurationProperties(prefix = "clients.accesstoken")
@Getter
@Validated
public class AccessTokenClientConfig {

  private final AccessTokenRestClientConfig rest;
  private final AccessTokenStubClientConfig stub;

  @ConstructorBinding
  public AccessTokenClientConfig(AccessTokenRestClientConfig rest,
      AccessTokenStubClientConfig stub) {
    this.rest = rest;
    this.stub = stub;
  }

  @Getter
  public static class AccessTokenRestClientConfig {

    @NotNull
    private final URI url;

    @ConstructorBinding
    public AccessTokenRestClientConfig(URI url) {
      this.url = url;
    }
  }

  @Getter
  public static class AccessTokenStubClientConfig {

    private final boolean enabled;

    @ConstructorBinding
    public AccessTokenStubClientConfig(boolean enabled) {
      this.enabled = enabled;
    }
  }
}
