package com.natwest.pbbdhb.brokerauth.util;

public class LogMessageSubtype {

  public static String INPUT_VALIDATION = "InputValidation";
  public static String INVALID_RESPONSE = "InvalidResponse";
}
