package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

import java.util.List;

@Builder
@Value
public class ChangePasswordClientRequest {

  @NonNull
  List<String> schemas;

  @NonNull
  @JsonProperty("currentPassword")
  String currentPassword;

  @NonNull
  @JsonProperty("newPassword")
  String newPassword;

}
