package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.NonSTPFieldCategory;
import com.natwest.pbbdhb.brokerauth.request.domain.RequestedType;
import com.natwest.pbbdhb.brokerauth.request.domain.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.mapper.BrokerDetailsMapper;
import com.natwest.pbbdhb.brokerauth.service.crm.BrokerDetailsService;
import com.natwest.pbbdhb.brokerauth.service.crm.CrmService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.lang3.builder.DiffResult;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BrokerDetailsServiceImpl implements BrokerDetailsService {

    private final CrmService crmService;

    private static final List<String> NAME_UPDATE_FIELDS = Arrays.asList("title", "firstName", "lastName");
    private static final List<String> ADDRESS_UPDATE_FIELDS = Arrays.asList("addressLine1", "addressLine2", "addressLine3", "city", "county", "postcode");
    private static final List<String> PHONE_UPDATE_FIELDS = Arrays.asList("mobilePhone", "businessPhone");
    private static final String EMAIL_UPDATE_FIELD = "email";
    private static final String FCANUMBER = "fcanumber";
    private static final String RESIDENTIAL_ADDRESS = "residentialAddress";
    private static final String NATIONALITY = "nationality";
    private static final String TRADING_NAME = "tradingName";
    private static final String PAYMENT_PATHS = "paymentPaths";

    private static final List<String> NON_STP_FIELDS = new ArrayList<>();

    public BrokerDetailsServiceImpl(CrmService crmService) {
        this.crmService = crmService;
        NON_STP_FIELDS.addAll(NAME_UPDATE_FIELDS);
        NON_STP_FIELDS.addAll(ADDRESS_UPDATE_FIELDS);
        NON_STP_FIELDS.add(EMAIL_UPDATE_FIELD);
    }

    @Override
    public BrokerDetailsResponse getBrokerDetails(String brokerUsername) {
        log.debug("getBrokerDetails: Getting broker details for username: {}", brokerUsername);
        try {
            BrokerCoreResponse brokerCoreResponse = crmService.getBrokerDetails(brokerUsername);
            log.debug("getBrokerDetails: Broker details for username: {}, successfully retrieved", brokerUsername);
            return BrokerDetailsMapper.toBrokerDetailsResponse(brokerCoreResponse);
        } catch (RestClientException ex) {
            log.warn("getBrokerDetails: Get broker details request failed for username {}", brokerUsername);
            throw new RemoteRequestFailedException(
                String.format("getBrokerDetails: Request failed for broker username %s", brokerUsername), ex);
        }
    }

    @Override
    public BrokerDetailsResponse getAdminDetails(String adminUsername) {
        log.debug("getAdminDetails: Getting admin details for username: {}", adminUsername);
        try {
            AdminCoreResponse adminCoreResponse = crmService.getAdminDetails(adminUsername);
            log.debug("getAdminDetails: Admin details for username: {}, successfully retrieved", adminUsername);
            return BrokerDetailsMapper.toBrokerDetailsResponse(adminCoreResponse);
        } catch (RestClientException ex) {
            log.warn("getAdminDetails: Get admin details request failed for admin username {}",
                    adminUsername);
            throw new RemoteRequestFailedException(
                String.format("getAdminDetails: Request failed for admin username %s", adminUsername), ex);
        }
    }

    public UpdateBrokerDetailsResponse updateDetails(BrokerDetailsChangeRequest brokerDetailsChangeRequest) {
        log.debug("updateDetails: Updating broker details for userName: {}",
                brokerDetailsChangeRequest.getUsername());

        final BrokerType brokerType = brokerDetailsChangeRequest.getBrokerType();
        // Step 1 - Fetch existing broker data
        final BrokerDetailsResponse existingBrokerDetailsResponse;
        try {
            if (BrokerType.ADMIN == brokerType) {
                existingBrokerDetailsResponse = getAdminDetails(brokerDetailsChangeRequest.getUsername());
            } else {
                existingBrokerDetailsResponse = getBrokerDetails(brokerDetailsChangeRequest.getUsername());
            }
        } catch (RemoteRequestFailedException ex) {
            log.warn("updateDetails: Error getting broker details for username {}",
                    brokerDetailsChangeRequest.getUsername(), ex);
            throw new RemoteRequestFailedException(
                String.format("updateDetails: Request failed for username %s", brokerDetailsChangeRequest.getUsername()));
        }

        // Step 2 - Compare and find changed fields
        final BrokerDetails existingBrokerDetails = existingBrokerDetailsResponse.getBrokerDetails();
        final BrokerDetails updatedBrokerDetails = BrokerDetailsMapper.toBrokerDetails(brokerDetailsChangeRequest);
        updatedBrokerDetails.setFcaNumber(existingBrokerDetails.getFcaNumber());
        final DiffResult<BrokerDetails> diffResult = existingBrokerDetails.diff(updatedBrokerDetails);

        final List<String> changedFieldNames = diffResult.getDiffs().stream()
            .map(Diff::getFieldName)
            .collect(Collectors.toList());

        // Step 3 - Build a request with field groups for given type (name, address, phone), gather updated field types for response
        final Set<RequestedType> requestedTypes = new HashSet<>();
        final Set<NonSTPFieldCategory> processingFields = new HashSet<>(existingBrokerDetailsResponse.getProcessingFields());

        BrokerDetails request = BrokerDetails.builder()
            .username(updatedBrokerDetails.getUsername())
            .build();

        changedFieldNames.forEach(fieldName -> {
            if (!processingFields.contains(NonSTPFieldCategory.NAME) && NAME_UPDATE_FIELDS.contains(fieldName)) {
                request.setTitle(StringUtils.defaultIfEmpty(updatedBrokerDetails.getTitle(), ""));
                request.setFirstName(StringUtils.defaultIfEmpty(updatedBrokerDetails.getFirstName(), ""));
                request.setLastName(StringUtils.defaultIfEmpty(updatedBrokerDetails.getLastName(), ""));
                if (BrokerType.ADMIN == brokerType) {
                    request.setMiddleName(StringUtils.defaultIfEmpty(updatedBrokerDetails.getMiddleName(), ""));
                    requestedTypes.add(RequestedType.STP);
                } else {
                    requestedTypes.add(RequestedType.NON_STP);
                    processingFields.add(NonSTPFieldCategory.NAME);
                }
            } else if (!processingFields.contains(NonSTPFieldCategory.ADDRESS) && ADDRESS_UPDATE_FIELDS.contains(fieldName)) {
                request.setAddressLine1(StringUtils.defaultIfEmpty(updatedBrokerDetails.getAddressLine1(), ""));
                request.setAddressLine2(StringUtils.defaultIfEmpty(updatedBrokerDetails.getAddressLine2(), ""));
                request.setAddressLine3(StringUtils.defaultIfEmpty(updatedBrokerDetails.getAddressLine3(), ""));
                request.setCity(StringUtils.defaultIfEmpty(updatedBrokerDetails.getCity(), ""));
                request.setCounty(StringUtils.defaultIfEmpty(updatedBrokerDetails.getCounty(), ""));
                request.setPostcode(StringUtils.defaultIfEmpty(updatedBrokerDetails.getPostcode(), ""));
                if (BrokerType.ADMIN == brokerType) {
                    requestedTypes.add(RequestedType.STP);
                } else {
                    requestedTypes.add(RequestedType.NON_STP);
                    processingFields.add(NonSTPFieldCategory.ADDRESS);
                }
            } else if (PHONE_UPDATE_FIELDS.contains(fieldName)) {
                request.setMobilePhone(StringUtils.defaultIfEmpty(updatedBrokerDetails.getMobilePhone(), ""));
                request.setBusinessPhone(StringUtils.defaultIfEmpty(updatedBrokerDetails.getBusinessPhone(), ""));
                requestedTypes.add(RequestedType.STP);
                if (BrokerType.BROKER == brokerType) {
                    processingFields.add(NonSTPFieldCategory.NAME);
                }
            } else if (!processingFields.contains(NonSTPFieldCategory.EMAIL) && EMAIL_UPDATE_FIELD.equals(fieldName)) {
                request.setEmail(StringUtils.defaultIfEmpty(updatedBrokerDetails.getEmail(), ""));
                if (BrokerType.ADMIN == brokerType) {
                    requestedTypes.add(RequestedType.STP);
                } else {
                    requestedTypes.add(RequestedType.NON_STP);
                    processingFields.add(NonSTPFieldCategory.EMAIL);
                }
            } else if (fieldName.equals(RESIDENTIAL_ADDRESS)) {
                request.setResidentialAddress(updatedBrokerDetails.getResidentialAddress());
                request.setNationality(StringUtils.defaultIfEmpty(updatedBrokerDetails.getNationality(), ""));
                requestedTypes.add(RequestedType.STP);
            } else if (fieldName.equals(NATIONALITY)) {
                request.setNationality(updatedBrokerDetails.getNationality());
                request.setResidentialAddress(updatedBrokerDetails.getResidentialAddress());
                requestedTypes.add(RequestedType.STP);
            } else if (fieldName.equals(FCANUMBER)) {
                request.setFcaNumber(StringUtils.defaultIfEmpty(updatedBrokerDetails.getFcaNumber(), ""));
                requestedTypes.add(RequestedType.STP);
            } else if (fieldName.equals(TRADING_NAME)) {
                request.setTradingName(StringUtils.defaultIfEmpty(updatedBrokerDetails.getTradingName(), ""));
                requestedTypes.add(RequestedType.STP);
            } else if (fieldName.equals(PAYMENT_PATHS)) {
                request.setPaymentPaths(updatedBrokerDetails.getPaymentPaths());
                requestedTypes.add(RequestedType.STP);
            }
        });

        // Step 4 = Make a request to update broker data in CRM
        try {
            if (BrokerType.ADMIN == brokerType) {
                crmService.updateAdminDetails(BrokerDetailsMapper.toAdminDetailsChangeCrmRequest(request));
            } else {
                crmService.updateBrokerDetails(BrokerDetailsMapper.toBrokerDetailsChangeCrmRequest(request));
            }
        } catch (RestClientException ex) {
            log.warn("updateDetails: Error updating broker details for username {}",
                    request.getUsername(), ex);
            throw new RemoteRequestFailedException(
                String.format("updateDetails: Request failed for username %s", request.getUsername()), ex);
        }

        // Step 5 - Build the response
        log.debug("updateDetails: Broker details for userName: {}, successfully updated",
                brokerDetailsChangeRequest.getUsername());
        return UpdateBrokerDetailsResponse.builder()
            .requestedTypes(new ArrayList<>(requestedTypes))
            .processingFields(new ArrayList<>(processingFields))
            .build();
    }

}
