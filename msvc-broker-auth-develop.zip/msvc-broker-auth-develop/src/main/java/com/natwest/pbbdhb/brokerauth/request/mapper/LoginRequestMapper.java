package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.LoginRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoginRequestMapper {

  private LoginRequestMapper() {
  }

  public static LoginRequestModel toLoginRequestModel(LoginRequest attempt) {
    log.debug("toLoginRequestModel: Mapping LoginRequest to LoginRequestModel.");
    return LoginRequestModel.builder()
        .username(attempt.getUsername())
        .password(attempt.getPassword())
        .build();
  }
}
