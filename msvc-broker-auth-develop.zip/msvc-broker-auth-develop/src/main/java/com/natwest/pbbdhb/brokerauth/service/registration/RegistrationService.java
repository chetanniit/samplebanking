package com.natwest.pbbdhb.brokerauth.service.registration;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeGenerateRequest;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.request.mapper.ActivationRequestMapper;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * A Registration service class which provides business logic operations on registering users.
 */
@Slf4j
@Service
public class RegistrationService {

  private final CustomerIdentityManagementClient customerIdentityManagementClient;
  private static final String NEW = "New";


  /**
   * Creates a new instance of the RegistrationService
   *
   * @param customerIdentityManagementClient An instance of the CustomerIdentityManagementClient
   */
  public RegistrationService(CustomerIdentityManagementClient customerIdentityManagementClient) {
    this.customerIdentityManagementClient = customerIdentityManagementClient;
  }

  /**
   * Handles creating users in the customerIdentityManagementClient and initialising an OTP
   *
   * @param accessToken            The access token to be used in requests to the Customer Identity
   *                               Management client.
   * @param userCreateRequestModel The model describing the request to make to the client
   */
  public void createUser(String accessToken, UserCreateRequestModel userCreateRequestModel) {
    log.debug("createUser: Creating user: {}", userCreateRequestModel.getUsername());
    customerIdentityManagementClient.createUser(accessToken, userCreateRequestModel);
    customerIdentityManagementClient.initialiseOtp(accessToken,
        userCreateRequestModel.getUsername());
    log.debug("createUser: User: {}, successfully created", userCreateRequestModel.getUsername());
  }

  public void deleteUser(String accessToken, UserDeleteRequestModel userDeleteRequestModel) {
    log.debug("deleteUser: Deleting user: {}", userDeleteRequestModel.getUsername());
    GetUserResponseModel customerIdentifier = customerIdentityManagementClient.getUser(accessToken,
        userDeleteRequestModel.getUsername());

    try {
      OtpRetrieveResponseModel otpRetrieveResponseModel = customerIdentityManagementClient.retrieveOTP(
          accessToken, userDeleteRequestModel.getUsername());

      customerIdentityManagementClient.deleteOTP(accessToken, otpRetrieveResponseModel.getOtpId());

    } catch (InvalidDataResponseException ex) {
      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.INCOMING)
          .description(
              String.format("Inside RegistrationService: No activation code found for user: %s, proceeding with deletion",
                  userDeleteRequestModel.getUsername()))
          .build());
    }

    try {
      String questionsId = customerIdentityManagementClient.getSecurityQuestions(
              accessToken,
              customerIdentifier.getParentId()).getId();

      customerIdentityManagementClient.deleteSecurityQuestions(accessToken, questionsId);
    } catch (SecurityQuestionNotFoundException ex) {
      log.debug(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.INCOMING)
              .description(
                      String.format("Inside RegistrationService: No questions found for user: %s, proceeding with deletion",
                              userDeleteRequestModel.getUsername()))
              .build());
    }

    customerIdentityManagementClient.deleteUser(accessToken, customerIdentifier.getId(),
        userDeleteRequestModel);
    log.debug("deleteUser: User: {}, successfully deleted", userDeleteRequestModel.getUsername());
  }

  /**
   * Handles creating activation codes for the user to register as broker
   *
   * @param accessToken            The access token to be used in requests to the Customer Identity
   *                               Management client.
   * @param request                The model describing the request to make to the client
   * @return Model containing the activation code.
   */
  public OtpGenerateResponseModel reactivateUser(String accessToken, ActivationCodeGenerateRequest request) {
    log.debug("reactivateUser: Reactivating user: {}", request.getUsername());
    /** Check user exists before sending reactivation code */
    customerIdentityManagementClient.getUser(accessToken, request.getUsername());
    log.debug("reactivateUser: User: {}, successfully reactivated", request.getUsername());
    return createOtp(accessToken, request.getUsername());
  }

  public OtpGenerateResponseModel createOtp(String accessToken, String username) {
    log.debug("createOtp: Creating Otp for user: {}", username);

    // Retrieve OTP
    String otpId = customerIdentityManagementClient.retrieveOTP(accessToken, username).getOtpId();

    // Generate OTP
    OtpGenerateResponseModel otpGenerateDetailsModel = customerIdentityManagementClient.generateOTP(
            accessToken, otpId);

    // Update OTP code to status New
    customerIdentityManagementClient
            .updateOTP(accessToken, ActivationRequestMapper.toOtpUpdateRequestModel(otpId, NEW));

    log.debug("createOtp:  Otp for user: {}, successfully created", username);
    return otpGenerateDetailsModel;
  }

  /**
   * Handles creating activation codes for the user to register as broker
   *
   * @param username The user name of the registering broker
   * @return Model containing the activation code.
   */
  public OtpGenerateResponseModel createActivationCode(String accessToken, String username) {
    log.debug("createActivationCode: Creating Activation code for user: {}", username);

    //retrieve otp
    String otpId = customerIdentityManagementClient.retrieveOTP(accessToken, username).getOtpId();

    //generate activation code
    OtpGenerateResponseModel otpGenerateDetailsModel = customerIdentityManagementClient.generateOTP(
        accessToken, otpId);

    //update activation code to status New
    customerIdentityManagementClient.updateOTP(accessToken,
        ActivationRequestMapper.toActivationCodeUpdateRequestModel(otpId, NEW));

    log.debug("createActivationCode: Activation code for user: {}, successfully created", username);
    return otpGenerateDetailsModel;
  }
}
