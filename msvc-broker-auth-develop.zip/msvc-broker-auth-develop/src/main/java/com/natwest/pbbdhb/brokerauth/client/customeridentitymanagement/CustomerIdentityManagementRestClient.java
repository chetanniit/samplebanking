package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ActivateUserClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ChangePasswordClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetCustomerClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.LoginClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.LoginClientResponse.LoginResources;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpInitialiseClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateReturnCode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionValidateReturnCode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsValidateClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SetPasswordClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserCreateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserDeleteClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.mapper.CustomerIdentityManagementMapper;
import com.natwest.pbbdhb.brokerauth.configuration.CustomerIdentityManagementClientConfig;
import com.natwest.pbbdhb.brokerauth.configuration.CustomerIdentityManagementClientConfig.CustomerIdentityManagementRestClientConfig;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginErrorResponseType;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionResponseException;
import com.natwest.pbbdhb.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import com.natwest.pbbdhb.brokerauth.request.security.UserClaimsProvider;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * A Customer Identity Management rest client, which is not used if the stub configuration property
 * is set to true.
 * <p>
 * The Retryable annotation allows failing methods to re-try if specific exceptions are thrown.
 * Re-tries may work if there's a temporary issue on the remote service.
 * <p>
 * RemoteRequestFailedException - normally thrown by client methods if a non 2xx response is
 * received. InvalidDataResponseException - normally thrown when response data (e.g. customer, OTP)
 * does not match the expectations. This can be due to IAM/IDS synchronisation issues. New records
 * can take time to syncronise across all IDS servers.
 */
@Component
@ConditionalOnProperty(
    value = "clients.customeridentitymanagement.stub.enabled",
    havingValue = "false",
    matchIfMissing = true
)
@Slf4j
@Retryable(
    value = {RemoteRequestFailedException.class, InvalidDataResponseException.class},
    maxAttemptsExpression = "${re-try.max-attempts}",
    backoff = @Backoff(
        delayExpression = "${re-try.back-off.initial-delay-ms}",
        multiplierExpression = "${re-try.back-off.multiplier}",
        maxDelayExpression = "${re-try.back-off.max-delay-ms}"
    )
)
public class CustomerIdentityManagementRestClient implements CustomerIdentityManagementClient {

  private static final String OTP_VALIDATION_RESOURCE = "otpvalidation";
  private static final String OTP_RESOURCE = "otp";
  private static final String LOGIN_RESOURCE = "login";
  private static final String CUSTOMER_RESOURCE = "customer";
  private static final String CUSTOMER_IDENTIFIER_RESOURCE = "customeridentifier";
  private static final String SECURITY_QUESTION_RESOURCE = "customerchallenge";
  private static final String SECURITY_QUESTION_VALIDATION_RESOURCE = "challengevalidation";
  private static final String UNIQUENESS = "uniqueness";
  private static final String BASIC_VALIDATION_HEADER = "Basic";
  private static final String VALIDATION_HEADER = "Validation";

  private final CustomerIdentityManagementRestClientConfig config;
  private final RestTemplate restTemplate;
  private final UserClaimsProvider userClaimsProvider;

  public CustomerIdentityManagementRestClient(CustomerIdentityManagementClientConfig config,
      @Qualifier("customerServiceRestTemplate") RestTemplate restTemplate,
      UserClaimsProvider userClaimsProvider) {
    this.config = config.getRest();
    this.restTemplate = restTemplate;
    this.userClaimsProvider = userClaimsProvider;
  }

  /**
   * A method to support creating users, that will require payloads being sent.
   *
   * @param accessToken            The access token to be used in requests to the Customer Identity
   *                               Management client.
   * @param userCreateRequestModel Model containing all the data needed to create a user.
   */
  @Override
  public void createUser(String accessToken, UserCreateRequestModel userCreateRequestModel) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("createUser: Calling IAM CustomerIdentityManagement to create user: %s",
                userCreateRequestModel))
        .build()
    );
    Brand brand = userClaimsProvider.getOperatingBrand();
    UserCreateClientRequest clientRequest = CustomerIdentityManagementMapper
        .toUserCreateClientRequest(
            userCreateRequestModel, brand);

    URI uri = getUserUri(brand);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.POST,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("createUser: User with username: {}, successfully created", clientRequest.getUsername());
    } catch (HttpClientErrorException.BadRequest ex) {
      if (ex.getResponseBodyAsString().contains(UNIQUENESS)) {
        log.warn("createUser: Error creating user, user already exists - " +
                "UserAlreadyExistsException thrown. Username: {}", clientRequest.getUsername());
        throw new UserAlreadyExistsException(clientRequest.getUsername());
      }
      log.warn("createUser: Error creating user, bad request - " +
              "RemoteRequestFailedException thrown. Request: {}", clientRequest);
      throw new RemoteRequestFailedException(
          String.format("createUser: Create User request failed with bad request %s", clientRequest), ex
      );
    } catch (RestClientException ex) {
      log.warn("createUser: Error creating user, request failed - " +
              "RemoteRequestFailedException thrown. Request: {}", clientRequest);
      throw new RemoteRequestFailedException(
          String.format("createUser: Create User request failed %s", clientRequest), ex
      );
    }

  }

  /**
   * A method to support deleting users, that will require payloads being sent.
   *
   * @param accessToken            The access token to be used in requests to the Customer Identity
   *                               Management client.
   * @param customerIdentifierId   The customer identifier ID used in the URI
   * @param userDeleteRequestModel Model containing all the data needed to delete a user.
   */
  @Override
  public void deleteUser(String accessToken, String customerIdentifierId,
      UserDeleteRequestModel userDeleteRequestModel) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("deleteUser: Calling IAM CustomerIdentityManagement to delete user: %s",
                userDeleteRequestModel))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    UserDeleteClientRequest clientRequest = CustomerIdentityManagementMapper
        .toUserDeleteClientRequest(userDeleteRequestModel, brand);

    URI uri = getDeleteUserUri(brand, customerIdentifierId);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.DELETE,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("deleteUser: User with username: {}, successfully deleted", clientRequest.getUsername());
    } catch (HttpClientErrorException.BadRequest ex) {
      log.warn("deleteUser: Error deleting user, bad request - " +
              "RemoteRequestFailedException thrown. Request: {}", clientRequest);
      throw new RemoteRequestFailedException(
          String.format("deleteUser: Delete User request failed with bad request %s", clientRequest), ex
      );
    } catch (RestClientException ex) {
      log.warn("deleteUser: Error deleting user, request failed - " +
              "RemoteRequestFailedException thrown. Request: {}", clientRequest);
      throw new RemoteRequestFailedException(
          String.format("deleteUser: Delete User request failed %s", clientRequest), ex
      );
    }
  }

  /**
   * A method to support initialising an OTP for a user, that will require payloads being sent.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    The username of the user to initialise the otp for.
   */
  @Override
  public void initialiseOtp(String accessToken, String username) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("initialiseOtp: Calling IAM CustomerIdentityManagement to initialise otp for user: %s",
                username))
        .build()
    );
    Brand brand = userClaimsProvider.getOperatingBrand();
    OtpInitialiseClientRequest clientRequest = CustomerIdentityManagementMapper
        .toOtpInitialiseClientRequest(
            username, brand);
    URI uri = getOtpUri(brand);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.POST,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("initialiseOtp: Otp successfully initialised for user with username: {}", clientRequest.getUsername());

    } catch (RestClientException ex) {
      log.warn("initialiseOtp: Error creating OTP, request failed - " +
              "RemoteRequestFailedException thrown. Request: {}", clientRequest);
      throw new RemoteRequestFailedException(
          String.format("initialiseOtp: Create Otp request failed %s", clientRequest), ex
      );
    }
  }

  /**
   * A method to support validating an OTP for a user, that will require payloads being sent.
   *
   * @param accessToken  The access token to be used in requests to the Customer Identity Management
   *                     client.
   * @param requestModel Model containing all the data needed to validate an OTP.
   */
  @Override
  public void validateOtp(String accessToken, OtpValidateRequestModel requestModel) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String
            .format("validateOtp: Calling IAM CustomerIdentityManagement to validate otp: %s", requestModel))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    OtpValidateClientRequest clientRequest = CustomerIdentityManagementMapper
        .toOtpValidateClientRequest(
            requestModel, brand);
    URI uri = getFilteredResourceUri(OTP_VALIDATION_RESOURCE, brand,
        clientRequest.getUsername());

    HttpHeaders headers = getHeaders(accessToken);
    headers.set(VALIDATION_HEADER,
        String.format("%s %s", BASIC_VALIDATION_HEADER, clientRequest.getEncodedOtpCode()));

    try {
      ResponseEntity<OtpValidateClientResponse> responseEntity = restTemplate
          .exchange(
              uri,
              HttpMethod.GET,
              new HttpEntity<>(headers),
              OtpValidateClientResponse.class);
      log.debug("validateOtp: Otp successfully validated for user with username: {}", clientRequest.getUsername());


      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format(
              "validateOtp: IAM CustomerIdentityManagement responded to validate otp call for user: %s with status code: %s and content: %s",
              clientRequest.getUsername(),
              responseEntity.getStatusCode(),
              Objects.requireNonNull(responseEntity.getBody()).getResources()))
          .build());

      OtpValidateClientResponse body = Objects.requireNonNull(responseEntity.getBody());

      checkTotalResults(body.getTotalResults(), clientRequest.getUsername());

      checkReturnCode(Objects.requireNonNull(body.getResources()).get(0)
          .getReturnCode(), clientRequest.getUsername());

    } catch (RestClientException ex) {
      log.warn("validateOtp: Error validating OTP, request failed - " +
              "RemoteRequestFailedException thrown. Request: {}", clientRequest);
      throw new RemoteRequestFailedException(
          String.format("validateOtp: Validate Otp request failed %s", clientRequest), ex
      );
    }
  }

  /**
   * A method to support retrieving an OTP ID for a user, that will be used in other
   * CustomerIdentityManagement calls. This will require the user's username.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    The user's username to be used to query the endpoint.
   * @return Model containing the ID of the otp.
   */
  @Override
  public OtpRetrieveResponseModel retrieveOTP(String accessToken, String username) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String
            .format("retrieveOTP: Calling IAM CustomerIdentityManagement to retrieve otp for user: %s",
                username))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getFilteredResourceUri(OTP_RESOURCE, brand,
        CustomerIdentityManagementMapper.formatUserName(brand, username));

    try {
      log.debug("retrieveOTP: Otp successfully retrieved for user with username: {}", username);
      return Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.GET,
                  new HttpEntity<>(getHeaders(accessToken)),
                  OtpRetrieveClientResponse.class)
              .getBody())
          .map(CustomerIdentityManagementMapper::toOtpRetrieveResponseModel)
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format("retrieveOTP: Retrieve otp response returned an empty payload for user: %s", username))
          );

    } catch (RestClientException ex) {
      log.warn("retrieveOTP: Error retrieving OTP request, request failed for user - " +
              "RemoteRequestFailedException thrown. Username: {}", username);
      throw new RemoteRequestFailedException(
          String.format("retrieveOTP: Retrieve otp request failed for user: %s", username), ex);
    }
  }

  /**
   * A method to support generating an Activation code for a user, that will require a payload.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param otpId       The otp ID to generate an activation code for.
   * @return Model containing the activation code.
   */
  @Override
  public OtpGenerateResponseModel generateOTP(String accessToken, String otpId) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String
                .format("generateOTP: Calling IAM CustomerIdentityManagement to generate an otp for otp id: %s",
                    otpId))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getGenerateOtpUri(brand, otpId);

    OtpGenerateClientRequest clientRequest = CustomerIdentityManagementMapper
        .toOtpGenerateClientRequest();
    try {
      log.debug("generateOTP: Otp successfully generated, otpId: {}", otpId);
      return Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.PUT,
                  new HttpEntity<>(clientRequest, getHeaders(accessToken)),
                  OtpGenerateClientResponse.class)
              .getBody())
          .map(CustomerIdentityManagementMapper::toOtpGenerateResponseModel)
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format("generateOTP: Generate otp response returned an empty payload for otp id: %s", otpId))
          );

    } catch (RestClientException ex) {
      log.warn("generateOTP: Error generating OTP request - " +
              "RemoteRequestFailedException thrown. otpId: {}", otpId);
      throw new RemoteRequestFailedException(
          String.format("generateOTP: Generate otp request failed for otp id: %s", otpId), ex);
    }
  }

  /**
   * A method to support updating the state of an Activation code for a user, that will require a
   * payload.
   *
   * @param accessToken           The access token to be used in requests to the Customer Identity
   *                              Management client.
   * @param otpUpdateRequestModel Model containing all the data to update the state of an activation
   *                              code.
   */
  @Override
  public void updateOTP(String accessToken, OtpUpdateRequestModel otpUpdateRequestModel) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("updateOTP: Calling IAM CustomerIdentityManagement to update an otp: %s",
                otpUpdateRequestModel))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getUpdateOtpUri(brand, otpUpdateRequestModel.getOtpId());

    OtpUpdateClientRequest clientRequest = CustomerIdentityManagementMapper
        .toOtpUpdateClientRequest(
            otpUpdateRequestModel);
    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.PATCH,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("updateOTP: Otp successfully updated, otpId: {}", otpUpdateRequestModel.getOtpId());

    } catch (RestClientException ex) {
      log.warn("updateOTP: Error updating OTP request - " +
              "RemoteRequestFailedException thrown. otpUpdateRequestModel: {}", otpUpdateRequestModel);
      throw new RemoteRequestFailedException(
          String.format("updateOTP: Update otp request failed %s", otpUpdateRequestModel), ex);
    }
  }

  /**
   * A method to support deleting an Activation code for a user, that will require a payload.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param otpId       String containing the activation code to be deleted
   */
  @Override
  public void deleteOTP(String accessToken, String otpId) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("deleteOTP: Calling IAM CustomerIdentityManagement to delete an otp: %s",
                otpId))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getDeleteOtpUri(brand, otpId);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.DELETE,
              new HttpEntity<>(getHeaders(accessToken)),
              String.class);
      log.debug("deleteOTP: Otp successfully deleted otpId: {}", otpId);

    } catch (HttpClientErrorException.BadRequest ex) {
      log.warn("deleteOTP: Error deleting OTP request - " +
              "RemoteRequestFailedException thrown. otpId: {}", otpId);
      throw new RemoteRequestFailedException(
          String.format("deleteOTP: Delete OTP request failed with bad request for OTP %s", otpId), ex
      );
    } catch (RestClientException ex) {
      log.warn("deleteOTP: Error deleting OTP request - " +
              "RemoteRequestFailedException thrown. otpId: {}", otpId);
      throw new RemoteRequestFailedException(
          String.format("deleteOTP: Delete OTP request failed for OTP %s", otpId), ex
      );
    }
  }

  /**
   * A method to support credential verification for a user.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param attempt     Model containing user credentials for the login verification.
   */
  @Override
  public void login(String accessToken,
      LoginRequestModel attempt) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("login: Calling IAM CustomerIdentityManagement to login for user: %s",
                attempt.getUsername()))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    String username = CustomerIdentityManagementMapper.formatUserName(brand, attempt.getUsername());
    URI uri = getFilteredResourceUri(LOGIN_RESOURCE, brand, username);

    HttpHeaders headers = getHeaders(accessToken);
    headers.set(VALIDATION_HEADER, getValidationHeader(username, attempt.getPassword()));

    try {
      final LoginClientResponse clientResponse = Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.GET,
                  new HttpEntity<>(headers),
                  LoginClientResponse.class)
              .getBody())
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format("login: Login response returned an empty payload for user: %s",
                      attempt.getUsername()))
          );
      log.debug("login: login successful for username: {}", username);
      checkIfLoginResponseIsValid(username, clientResponse);
    } catch (RestClientException ex) {
      log.warn("login: Login request failed for user - " +
              "RemoteRequestFailedException thrown. Username: {}", attempt.getUsername());
      throw new RemoteRequestFailedException(
          String.format("login: Login request failed for user: %s", attempt.getUsername()), ex);
    }
  }

  /**
   * A method to retrieve details for a customer.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    username of the required customer details.
   * @return user details mapped to GetCustomerResponseModel
   */
  @Override
  public GetCustomerResponseModel getCustomer(String accessToken, String username) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("getCustomer: Calling IAM CustomerIdentityManagement to get customer: %s", username))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getFilteredResourceUri(CUSTOMER_RESOURCE, brand,
        CustomerIdentityManagementMapper.formatUserName(brand, username));

    try {
      log.debug("getCustomer: Customer with username: {}, successfully retrieved", username);
      return Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.GET,
                  new HttpEntity<>(getHeaders(accessToken)),
                  GetCustomerClientResponse.class)
              .getBody())
          .map(CustomerIdentityManagementMapper::toGetCustomerResponseModel)
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format("getCustomer: Get customer response returned an empty payload for customer: %s",
                      username))
          );
    } catch (RestClientException ex) {
      log.warn("getCustomer: Error getting user request - " +
              "RemoteRequestFailedException thrown. Username: {}", username);
      throw new RemoteRequestFailedException(
          String.format("getCustomer: Get user request failed for customer: %s", username), ex);
    }
  }

  /**
   * A method to retrieve details for a user.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    username of the required user details.
   * @return user details mapped to GetUserResponseModel
   */
  @Override
  public GetUserResponseModel getUser(String accessToken, String username) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("getUser: Calling IAM CustomerIdentityManagement to get user: %s", username))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getFilteredResourceUri(CUSTOMER_IDENTIFIER_RESOURCE, brand,
        CustomerIdentityManagementMapper.formatUserName(brand, username));

    try {
      log.debug("getUser: User with username: {}, successfully retrieved", username);
      return Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.GET,
                  new HttpEntity<>(getHeaders(accessToken)),
                  GetUserClientResponse.class)
              .getBody())
          .map(CustomerIdentityManagementMapper::toGetUserResponseModel)
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format("getUser: Get user response returned an empty payload for user: %s", username))
          );
    } catch (RestClientException ex) {
      log.warn("getUser: Error getting user request - " +
              "RemoteRequestFailedException thrown. Username: {}", username);
      throw new RemoteRequestFailedException(
          String.format("getUser: Get user request failed for user: %s", username), ex);
    }
  }

  /**
   * A method to mark an account as activated.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param customerId  customerIdentifier id for the user.
   */
  @Override
  public void activateAccount(String accessToken, String customerId) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String
            .format("activateAccount: Calling IAM CustomerIdentityManagement to activate account for customerId: %s",
                customerId))
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getActivateAccountUri(brand, customerId);

    ActivateUserClientRequest clientRequest = CustomerIdentityManagementMapper
        .createActivateUserClientRequest();
    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.PATCH,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("activateAccount: Account successfully activated for customerId: {}", customerId);

    } catch (RestClientException ex) {
      log.warn("activateAccount: Error activating account for customer - " +
              "RemoteRequestFailedException thrown. CustomerId: {}", customerId);
      throw new RemoteRequestFailedException(
          String.format("activateAccount: Activate account request failed for customerId: %s", customerId), ex);
    }
  }

  /**
   * A method to set a user's password.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the password to be set.
   */
  @Override
  public void setPassword(String accessToken, UserSetPasswordRequestModel request) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String.format(
            "setPassword: Calling IAM CustomerIdentityManagement to set password for customerIdentifier: %s",
            request.getCustomerIdentifier()))
        .build()
    );
    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getSetPasswordUri(brand, request.getCustomerIdentifier());
    SetPasswordClientRequest clientRequest = CustomerIdentityManagementMapper
        .toSetPasswordClientRequest(
            request);
    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.PUT,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("setPassword: Password successfully set for customerId: {}", request.getCustomerIdentifier());
    } catch (HttpClientErrorException.BadRequest ex) {
      log.warn("setPassword: Error setting password due to invalid password - " +
              "InvalidDetailsException thrown.");
      throw new InvalidDetailsException("Set password request failed due to invalid password");
    } catch (RestClientException ex) {
      log.warn("setPassword: Error setting password - " +
              "RemoteRequestFailedException thrown. CustomerIdentifier: {}", request.getCustomerIdentifier());
      throw new RemoteRequestFailedException(
          String.format("setPassword: Set password request failed for customerIdentifier: %s",
              request.getCustomerIdentifier()), ex);
    }
  }

  /**
   * A method to change a user's password.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the password to be changed.
   */
  @Override
  public void changePassword(String accessToken, UserChangePasswordRequestModel request) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String.format(
            "changePassword: Calling IAM CustomerIdentityManagement to change password for customerIdentifier: %s",
            request.getCustomerIdentifier()))
        .build()
    );
    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getSetPasswordUri(brand, request.getCustomerIdentifier());
    ChangePasswordClientRequest clientRequest = CustomerIdentityManagementMapper
        .toChangePasswordClientRequest(
            request);
    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.PUT,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("changePassword: Password for customerId: {}, successfully changed", request.getCustomerIdentifier());
    } catch (HttpClientErrorException.BadRequest ex) {
      log.warn("changePassword: Error changing password due to invalid password - " +
              "InvalidDetailsException thrown.");
      throw new InvalidDetailsException("Change password request failed due to invalid password");
    } catch (RestClientException ex) {
      log.warn("changePassword: Error changing password - " +
              "RemoteRequestFailedException thrown. CustomerIdentifier: {}", request.getCustomerIdentifier());
      throw new RemoteRequestFailedException(
          String.format("changePassword: Change password request failed for customerIdentifier: %s",
              request.getCustomerIdentifier()), ex);
    }
  }

  /**
   * A method to get a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param parentId    parent id associated with the security questions.
   */
  @Override
  public SecurityQuestionsFetchResponseModel getSecurityQuestions(String accessToken,
      String parentId) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description("getSecurityQuestions: Calling IAM CustomerIdentityManagement to get security questions")
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getSecurityQuestionsFetchUri(brand, parentId);

    try {
      log.debug("getSecurityQuestions: Security questions successfully retrieved");
      return Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.GET,
                  new HttpEntity<>(getHeaders(accessToken)),
                  SecurityQuestionsClientResponse.class)
              .getBody())
          .map(CustomerIdentityManagementMapper::toSecurityQuestionsResponseModel)
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format(
                      "getSecurityQuestions: Get security questions response returned an empty payload for parent id: %s",
                      parentId))
          );
    } catch (RestClientException ex) {
      log.warn("getSecurityQuestions: Error getting security questions - " +
              "RemoteRequestFailedException thrown.");
      throw new RemoteRequestFailedException(
          String.format("getSecurityQuestions: Get security questions request failed for parent id: %s", parentId), ex);
    }
  }

  /**
   * A method to delete a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param questionsId id of the security questions.
   */
  @Override
  public void deleteSecurityQuestions(String accessToken, String questionsId) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description("deleteSecurityQuestions: Calling IAM CustomerIdentityManagement to delete security questions")
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getSecurityQuestionsDeleteUri(brand, questionsId);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.DELETE,
              new HttpEntity<>(getHeaders(accessToken)),
              Void.class);
      log.debug("deleteSecurityQuestions: Security questions with questionsId: {}, successfully deleted", questionsId);
    } catch (HttpClientErrorException.NotFound ex) {
      log.warn("deleteSecurityQuestions: Error deleting security questions. Questions not found - " +
              "InvalidDetailsException thrown. questionsId: {}", questionsId);
      throw new InvalidDetailsException(
          String.format("deleteSecurityQuestions: Security questions not found for id: %s", questionsId), ex);
    } catch (RestClientException ex) {
      log.warn("deleteSecurityQuestions: Error deleting security questions - " +
              "RemoteRequestFailedException thrown. questionsId: {}", questionsId);
      throw new RemoteRequestFailedException(
          String.format("deleteSecurityQuestions: Delete security questions request failed for questions id: %s",
              questionsId), ex);
    }
  }

  /**
   * A method to create a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the security questions to be set.
   */
  @Override
  public void createSecurityQuestions(String accessToken, SecurityQuestionsRequestModel request) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description("createSecurityQuestions: Calling IAM CustomerIdentityManagement to create security questions")
        .build()
    );
    SecurityQuestionsClientRequest clientRequest = CustomerIdentityManagementMapper
        .toSecurityQuestionsClientRequest(
            request);

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = createSecurityQuestionsUri(brand);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.POST,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("createSecurityQuestions: Security questions successfully created");

      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format(
              "createSecurityQuestions: IAM CustomerIdentityManagement request to create security question call for parentId: %s",
              request.getParentId()))
          .build());
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format(
              "createSecurityQuestions: IAM CustomerIdentityManagement request to create security question call for parentId: %s failed: %s",
              request.getParentId(), ex))
          .build());
      throw new RemoteRequestFailedException("createSecurityQuestions: Create security questions request failed", ex);
    }
  }

  /**
   * A method to set a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the security questions to be set.
   * @param questionsId model containing the questions id retrieved from SecurityQuestionsFetchResponseModel.
   */
  @Override
  public void setSecurityQuestions(String accessToken, SecurityQuestionsRequestModel request, String questionsId) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description("setSecurityQuestions: Calling IAM CustomerIdentityManagement to set security questions")
        .build()
    );
    SecurityQuestionsClientRequest clientRequest = CustomerIdentityManagementMapper
        .toSecurityQuestionsClientRequest(
            request);

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = setSecurityQuestionsUri(brand, questionsId);

    try {
      restTemplate
          .exchange(
              uri,
              HttpMethod.PUT,
              new HttpEntity<>(clientRequest, getHeaders(accessToken)),
              String.class);
      log.debug("setSecurityQuestions: Security questions successfully set, questionsId: {}", questionsId);

      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format(
              "setSecurityQuestions: IAM CustomerIdentityManagement request to change security question call for parentId: %s",
              request.getParentId()))
          .build());
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format(
              "setSecurityQuestions: IAM CustomerIdentityManagement request to change security question call for parentId: %s failed: %s",
              request.getParentId(), ex))
          .build());
      throw new RemoteRequestFailedException("setSecurityQuestions: Set security questions request failed", ex);
    }
  }

  /**
   * A method to validate a user's security question and answer.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing a security question/answer to validate.
   */
  @Override
  public void validateSecurityQuestion(String accessToken,
      SecurityQuestionsSingleValidationRequestModel request) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description("validateSecurityQuestion IAM CustomerIdentityManagement to validate security question")
        .build()
    );

    Brand brand = userClaimsProvider.getOperatingBrand();
    URI uri = getFilteredResourceUri(
        SECURITY_QUESTION_VALIDATION_RESOURCE,
        brand,
        CustomerIdentityManagementMapper.formatUserName(brand, request.getUsername()));

    HttpHeaders headers = getHeaders(accessToken);
    headers.set(VALIDATION_HEADER, getSecurityQuestionValidationHeader(
        request.getQuestion().getQuestion(),
        request.getQuestion().getAnswer()));

    try {
      log.debug("validateSecurityQuestions: Security questions successfully validated for username: {}", request.getUsername());
      SecurityQuestionsValidateClientResponse validateResponse = Optional.ofNullable(restTemplate
              .exchange(
                  uri,
                  HttpMethod.GET,
                  new HttpEntity<>(headers),
                  SecurityQuestionsValidateClientResponse.class)
              .getBody())
          .orElseThrow(() ->
              new RemoteRequestFailedException(String
                  .format(
                      "validateSecurityQuestion: Validate security questions response returned an empty payload for user: %s",
                      request.getUsername()))
          );

      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format(
              "validateSecurityQuestion: IAM CustomerIdentityManagement responded to validate security question call for user: %s with content: %s",
              request.getUsername(),
              validateResponse.getResources()))
          .build());

      // verify the response - will throw an exception if invalid
      checkSecurityQuestionValidateResponse(validateResponse, request.getUsername());

    } catch (RestClientException ex) {
      log.warn("validateSecurityQuestion: Error validating security questions - " +
              "RemoteRequestFailedException thrown. Username: {}", request.getUsername());
      throw new RemoteRequestFailedException(
          String.format("validateSecurityQuestion:nValidate security questions request failed for User: %s",
              request.getUsername()), ex);
    }
  }

  private HttpHeaders getHeaders(String accessToken) {
    log.debug("getHeaders: Getting headers.");
    HttpHeaders headers = new HttpHeaders();
    headers.set("Content-Type", "application/scim+json");
    headers.set("Authorization", "Bearer " + accessToken);
    log.debug("getHeaders: Headers retrieved successfully.");
    return headers;
  }

  private String getValidationHeader(String username, String password) {
    log.debug("getValidationHeader: Getting validation header for username: {}.",
            username);
    final String credentials = username + ':' + password;
    log.debug("getValidationHeader: Validation header for username: {}, successfully retrieved.",
            username);
    return String.format("%s %s",
        BASIC_VALIDATION_HEADER,
        CustomerIdentityManagementMapper.base64Encode(credentials));
  }

  private String getSecurityQuestionValidationHeader(String question, String answer) {
    log.debug("getSecurityQuestionValidationHeader: Getting security question validation header.");
    final String credentials = question + ':' + answer;
    log.debug("getSecurityQuestionValidationHeader: Security question validation header successfully retrieved.");
    return String.format("%s %s",
        BASIC_VALIDATION_HEADER,
        CustomerIdentityManagementMapper.base64Encode(credentials));
  }

  private void checkIfLoginResponseIsValid(String username, LoginClientResponse clientResponse) {
    log.debug("checkIfLoginResponseIsValid: Checking login response is valid for username: {}.",
            username);
    final List<LoginResources> resources = clientResponse.getResources();
    if (resources == null || resources.isEmpty()) {
      log.warn("checkIfLoginResponseIsValid: Login failed for username: {} - LoginFailedException thrown",
              username);
      throw new LoginFailedException(username);
    } else if (resources.size() > 1) {
      log.warn("checkIfLoginResponseIsValid: Login failed for username: {} - UnauthorisedException thrown",
              username);
      throw new UnauthorisedException(ErrorCode.UNAUTHORISED,
          String.format("checkIfLoginResponseIsValid: Login failed for user: %s; expected 1 resource but got '%s'",
              username, resources.size()));
    }
    final Integer errorCode = resources.get(0).getErrorCode();
    if (errorCode != null) {
      if (errorCode == LoginErrorResponseType.NO_RECORDS_FOUND.getValue()
          || errorCode == LoginErrorResponseType.INVALID_CREDENTIALS.getValue()) {
        log.warn("checkIfLoginResponseIsValid: Login failed for username: {} - LoginFailedException thrown",
                username);
        throw new LoginFailedException(username);
      }
      if (errorCode == LoginErrorResponseType.ACCOUNT_LOCKED.getValue()) {
        log.warn("checkIfLoginResponseIsValid: Login failed for username: {} - AccountLockedException thrown",
                username);
        throw new AccountLockedException(username);
      }
      if(errorCode == LoginErrorResponseType.PASSWORD_EXPIRED.getValue()) {
        log.warn("checkIfLoginResponseIsValid: Login failed for username: {} - PasswordExpiredException thrown",
                username);
        throw new PasswordExpiredException(username);
      }
      log.warn("checkIfLoginResponseIsValid: Login failed for username: {} - UnauthorisedException thrown",
              username);
      throw new UnauthorisedException(ErrorCode.UNAUTHORISED,
          String.format("checkIfLoginResponseIsValid: Login failed for user: %s; error code '%s' is present",
              username, errorCode));
    }
    log.debug("checkIfLoginResponseIsValid: Check if login response is valid for username: {}, successful",
            username);
  }

  private void checkReturnCode(OtpValidateReturnCode returnCode, String username) {
    log.debug("checkReturnCode: Checking return code in validation response for username: {}.",
            username);
    if (returnCode == null) {
      log.warn("checkReturnCode: Return code not present in validation response for " +
                      "username: {} - OtpException thrown", username);
      throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
          "checkReturnCode: No returnCode was present in validation response for username: " + username);
    }
    returnCode.validate(username);
    log.debug("checkReturnCode: Check return code in validation response for username: {}, successful",
            username);
  }

  private void checkTotalResults(int totalResults, String username) {
    log.debug("checkTotalResults: Checking total results for username: {}.", username);
    if (totalResults == 0) {
      log.debug("checkTotalResults: 0 results found for username: {} - OtpException thrown",
              username);
      throw new OtpException(ErrorCode.INVALID_CREDENTIALS,
          "No results found for username: " + username);
    }
    if (totalResults > 1) {
      log.warn("checkTotalResults: Multiple results found for username: {} - OtpException thrown",
              username);
      throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
          "checkTotalResults: Multiple results were found for username: " + username);
    }
    log.debug("checkTotalResults: Check total results for username: {}, successful", username);
  }

  private void checkSecurityQuestionValidateResponse(
      SecurityQuestionsValidateClientResponse response,
      String username) {
    log.debug("checkSecurityQuestionValidateResponse: Checking security question validation response for username:" +
            " {}.", username);

    if (response.getTotalResults() == 0) {
      log.debug("checkSecurityQuestionValidateResponse: No results found for username: {} -" +
                      " SecurityQuestionResponseException thrown", username);
      throw new SecurityQuestionResponseException(
          "checkSecurityQuestionValidateResponse: No results found for username: " + username);
    }
    if (response.getTotalResults() > 1) {
      log.warn("checkSecurityQuestionValidateResponse: Multiple results found for username: {} -" +
              " SecurityQuestionResponseException thrown", username);
      throw new SecurityQuestionResponseException(
          "Multiple results were found for username: " + username);
    }
    if (response.getResources() == null || response.getResources().size() != 1) {
      log.warn("checkSecurityQuestionValidateResponse: No resources returned for username: {} -" +
              " SecurityQuestionResponseException thrown", username);
      throw new SecurityQuestionResponseException(
          "checkSecurityQuestionValidateResponse: Validate security questions didn't return 1 resource.");
    }
    final SecurityQuestionValidateReturnCode returnCode = response.getResources().get(0)
        .getReturnCode();

    if (returnCode == null) {
      log.warn("checkSecurityQuestionValidateResponse: No returnCode present in validation response for username:" +
              " {} - SecurityQuestionResponseException thrown", username);
      throw new SecurityQuestionResponseException(
          "checkSecurityQuestionValidateResponse: No returnCode was present in validation response for username: " + username);
    }
    returnCode.validate(username);
    log.debug("checkSecurityQuestionValidateResponse: Check security question validation response for username:" +
            " {}, successful", username);
  }

  private URI getUserUri(Brand brand) {
    log.debug("getUserUri: Getting user uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(CUSTOMER_RESOURCE)
        .build()
        .toUri();
  }

  private URI getDeleteUserUri(Brand brand, String customerId) {
    log.debug("getDeleteUserUri: Getting delete user uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(CUSTOMER_IDENTIFIER_RESOURCE, "{customerId}")
        .build(customerId);
  }

  private URI getOtpUri(Brand brand) {
    log.debug("getOtpUri: Getting OTP uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(OTP_RESOURCE)
        .build()
        .toUri();
  }

  private URI getGenerateOtpUri(Brand brand, String otpId) {
    log.info("getGenerateOtpUri: Getting generate OTP uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(OTP_RESOURCE, "{otpId}", "password")
        .build(otpId);
  }

  private URI getUpdateOtpUri(Brand brand, String otpId) {
    log.debug("getUpdateOtpUri: Getting update OTP uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(OTP_RESOURCE, "{otpId}")
        .build(otpId);
  }

  private URI getDeleteOtpUri(Brand brand, String otpId) {
    log.debug("getDeleteOtpUri: Getting delete OTP uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(OTP_RESOURCE, "{otpId}")
        .build(otpId);
  }

  private URI getActivateAccountUri(Brand brand, String customerId) {
    log.debug("getActivateAccountUri: Getting activate account uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(CUSTOMER_IDENTIFIER_RESOURCE, "{customerId}")
        .build(customerId);
  }

  private URI getSetPasswordUri(Brand brand, String customerId) {
    log.debug("getSetPasswordUri: Getting set password uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(CUSTOMER_IDENTIFIER_RESOURCE, "{customerId}", "password")
        .build(customerId);
  }

  private URI createSecurityQuestionsUri(Brand brand) {
    log.info("createSecurityQuestionsUri: Creating security questions uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(SECURITY_QUESTION_RESOURCE)
        .build()
        .toUri();
  }

  private URI getSecurityQuestionsFetchUri(Brand brand, String parentId) {
    log.debug("getSecurityQuestionsFetchUri: Getting security questions fetch uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(SECURITY_QUESTION_RESOURCE)
        .queryParam("filter", String.format("parentidentity eq \"%s\"", parentId))
        .build()
        .toUri();
  }

  private URI setSecurityQuestionsUri(Brand brand, String questionsId) {
    log.debug("setSecurityQuestionsUri: Setting security questions uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(SECURITY_QUESTION_RESOURCE, "{questionsId}")
        .build(questionsId);
  }

  private URI getSecurityQuestionsDeleteUri(Brand brand, String questionsId) {
    log.debug("getSecurityQuestionsDeleteUri: Getting security questions delete uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(SECURITY_QUESTION_RESOURCE, "{questionsId}")
        .build(questionsId);
  }

  private URI getFilteredResourceUri(String resource, Brand brand, String username) {
    log.debug("getFilteredResourceUri: Getting filtered resource uri.");
    return UriComponentsBuilder
        .fromUri(config.getBrands().get(brand).getUrl())
        .pathSegment(resource)
        .queryParam("filter", String.format("personaidentifier eq \"%s\"", username))
        .build()
        .toUri();
  }
}
