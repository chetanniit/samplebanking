package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement;

import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;

/**
 * An interface describing a client for users.
 */
public interface CustomerIdentityManagementClient {

  /**
   * A method to support creating users, that will require payloads being sent.
   *
   * @param accessToken            The access token to be used in requests to the Customer Identity
   *                               Management client.
   * @param userCreateRequestModel Model containing all the data needed to create a user.
   */
  void createUser(String accessToken, UserCreateRequestModel userCreateRequestModel);

  /**
   * A method to support deleting users, that will require payloads being sent.
   *
   * @param userDeleteRequestModel Model containing all the data needed to delete a user.
   */
  void deleteUser(String accessToken, String customerIdentifierId,
      UserDeleteRequestModel userDeleteRequestModel);

  /**
   * A method to support initialising an OTP for a user, that will require payloads being sent.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    The username of the user to initialise the otp for.
   */
  void initialiseOtp(String accessToken, String username);

  /**
   * A method to support retrieving an OTP ID for a user, that will be used in other
   * CustomerIdentityManagement calls. This will require the user's username.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    The users username te be used to query the endpoint.
   * @return Model containing the ID of the otp.
   */
  OtpRetrieveResponseModel retrieveOTP(String accessToken, String username);

  /**
   * A method to support generating an Activation code for a user, that will require a payload.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param otpId       The otp ID to generate an activation code for.
   * @return Model containing the activation code.
   */
  OtpGenerateResponseModel generateOTP(String accessToken, String otpId);

  /**
   * A method to support updating the state of an Activation code for a user, that will require a
   * payload.
   *
   * @param accessToken           The access token to be used in requests to the Customer Identity
   *                              Management client.
   * @param otpUpdateRequestModel Model containing all the data to update the state of an activation
   *                              code.
   */
  void updateOTP(String accessToken,
      OtpUpdateRequestModel otpUpdateRequestModel);

  /**
   * A method to support validation of an Activation code for a user, that will require a payload.
   *
   * @param accessToken             The access token to be used in requests to the Customer Identity
   *                                Management client.
   * @param otpValidateRequestModel Model containing all the data to vlidate an activation code.
   */
  void validateOtp(String accessToken, OtpValidateRequestModel otpValidateRequestModel);

  /**
   * A method to support deleting an Activation code for a user.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param otpId       String containing the activation code to be deleted
   */
  void deleteOTP(String accessToken, String otpId);


  /**
   * A method to support credential verification for a user.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param attempt     Model containing user credentials for the login verification.
   */
  void login(String accessToken, LoginRequestModel attempt);

  /**
   * A method to retrieve details for a customer.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    username of the required customer details.
   * @return user details mapped to GetCustomerResponseModel
   */
  GetCustomerResponseModel getCustomer(String accessToken, String username);

  /**
   * A method to retrieve details for a user.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param username    username of the required user details.
   * @return user details mapped to GetUserResponseModel
   */
  GetUserResponseModel getUser(String accessToken, String username);

  /**
   * A method to mark an account as activated.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param customerId  customerIdentifier id for the user.
   */
  void activateAccount(String accessToken, String customerId);

  /**
   * A method to set a user's password.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the password to be set.
   */
  void setPassword(String accessToken, UserSetPasswordRequestModel request);

  /**
   * A method to change a user's password.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the password to be changed.
   */
  void changePassword(String accessToken, UserChangePasswordRequestModel request);

  /**
   * A method to create a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the security questions to be set.
   */
  void createSecurityQuestions(String accessToken, SecurityQuestionsRequestModel request);

  /**
   * A method to set a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the security questions to be set.
   * @param questionsId model containing the questions id retrieved from SecurityQuestionsFetchResponseModel.
   */
  void setSecurityQuestions(String accessToken, SecurityQuestionsRequestModel request, String questionsId);

  /**
   * A method to get a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param parentId    parent id for the user.
   * @return security questions details mapped to SecurityQuestionsResponseModel
   */
  SecurityQuestionsFetchResponseModel getSecurityQuestions(String accessToken, String parentId);

  /**
   * A method to delete a user's security questions.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param questionsId id for the questions.
   */
  void deleteSecurityQuestions(String accessToken, String questionsId);

  /**
   * A method to validate a user's security question and answer.
   *
   * @param accessToken The access token to be used in requests to the Customer Identity Management
   *                    client.
   * @param request     model containing the security question/answer to be verified.
   */
  void validateSecurityQuestion(String accessToken,
      SecurityQuestionsSingleValidationRequestModel request);
}
