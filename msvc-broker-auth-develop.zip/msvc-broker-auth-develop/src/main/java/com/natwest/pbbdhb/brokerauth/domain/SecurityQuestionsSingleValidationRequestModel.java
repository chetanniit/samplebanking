package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class SecurityQuestionsSingleValidationRequestModel {

  @NonNull
  String username;

  @NonNull
  SecurityQuestion question;

}
