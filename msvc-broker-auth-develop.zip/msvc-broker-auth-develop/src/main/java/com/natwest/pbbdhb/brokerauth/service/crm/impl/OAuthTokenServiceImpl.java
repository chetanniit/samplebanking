package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerauth.configuration.CRMConfig;
import com.natwest.pbbdhb.brokerauth.exception.PingTokenGenerationException;
import com.natwest.pbbdhb.brokerauth.model.crm.OAuthTokenData;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.SecureDigestAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.DatatypeConverter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Calendar;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import static com.natwest.pbbdhb.brokerauth.util.ApplicationConstants.*;

@Slf4j
@Service
public class OAuthTokenServiceImpl implements OAuthTokenService {

    private final static String SIGNATURE_ALGORITHM = "RS256";
    private final CRMConfig crmConfig;
    private final RestTemplate restTemplate;

    public OAuthTokenServiceImpl(CRMConfig crmConfig,
                                 @Qualifier(value = "proxyRestTemplate") RestTemplate restTemplate) {
        this.crmConfig = crmConfig;
        this.restTemplate = restTemplate;
    }

    public OAuthTokenData generatePingToken() {
        log.debug("generatePingToken: Generating Ping Token...");

        MultiValueMap<String, String> paramsMap = new LinkedMultiValueMap<>();
        paramsMap.add(GRANT_TYPE, crmConfig.getGrant());
        paramsMap.add(SCOPE, crmConfig.getScope());
        paramsMap.add(CLIENT_ID, crmConfig.getConfidentialClientID());
        paramsMap.add(TENANT, crmConfig.getTenant());
        paramsMap.add(RESOURCE, crmConfig.getResource());
        paramsMap.add(CLIENT_ASSERTION_TYPE, crmConfig.getAssertion());

        String signedJwt;
        try {
            signedJwt = generateSignedJwt();
            log.debug("generatePingToken: Generating Ping Token, signedJwt is: {}", signedJwt);
        } catch (NoSuchAlgorithmException | KeyStoreException | CertificateException
                | IOException | UnrecoverableKeyException e) {
            throw new PingTokenGenerationException("generatePingToken: Exception while generating Ping token while" +
                    " fetching access token: " + e.getMessage());
        }
        paramsMap.add("client_assertion", signedJwt);
        log.debug("generatePingToken: Generated JWT Token: {}", signedJwt);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(paramsMap, headers);

        try {
            log.debug(new ObjectMapper().writeValueAsString(entity));
        } catch (JsonProcessingException e) {
            log.warn("generatePingToken: Unable to convert entity to string");
            throw new PingTokenGenerationException("generatePingToken: Exception while converting entity to string");
        }

        ResponseEntity<OAuthTokenData> response =
                restTemplate.exchange(crmConfig.getCrmAccessTokenEndpoint(),
                        HttpMethod.POST, entity,
                        OAuthTokenData.class);
        log.debug("generatePingToken: Access Token generated successfully: " + response.getBody());
        return response.getBody();

    }

    private String generateSignedJwt() throws NoSuchAlgorithmException, KeyStoreException, CertificateException,
            IOException, UnrecoverableKeyException {
        log.info("generatePingToken: Generating Signed Jwt...");

        Calendar expiredTime = Calendar.getInstance();
        expiredTime.add(Calendar.MINUTE, 60);

        Map<String, Object> claims = new ConcurrentHashMap<>();
        claims.put(AUD, crmConfig.getAud());
        claims.put(JTI, UUID.randomUUID().toString());
        claims.put(ISS, crmConfig.getConfidentialClientID());
        claims.put(SUB, crmConfig.getConfidentialClientID());
        claims.put(EXPIRY, (System.currentTimeMillis() + (1000 * 60 * 60 * 60)) / 1000);
        claims.put(NBF, (System.currentTimeMillis() + (1000 * 60)) / 1000);

        //We will sign our JWT with our ApiKey secret
        byte[] pvtKeySecretBytes = DatatypeConverter.parseBase64Binary(crmConfig.getPfxcert());
        InputStream targetStream = new ByteArrayInputStream(pvtKeySecretBytes);
        KeyStore keyStore = KeyStore.getInstance("pkcs12");
        keyStore.load(targetStream, crmConfig.getPwd().toCharArray());
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        keyStore.store(outputStream, crmConfig.getPwd().toCharArray());
        SecureDigestAlgorithm alg = Jwts.SIG.RS256;
        Key k = keyStore.getKey("1",
                crmConfig.getPwd().toCharArray());
        JwtBuilder builder = Jwts.builder();
        builder.header().add(TYPE, JWT_VAL)
                .add(KID, crmConfig.getThumbprint())
                .add(X5T, crmConfig.getXftHeader())
                .add(ALGORITHM, SIGNATURE_ALGORITHM);
        builder.issuedAt(new DateTime().toDate());
        builder.expiration(new DateTime().plusMinutes(60).toDate());
        builder.claims(claims);
        builder.signWith(k, alg);

        log.info("generatePingToken: SignedJwt successfully generated");
        return builder.compact();

    }
}
