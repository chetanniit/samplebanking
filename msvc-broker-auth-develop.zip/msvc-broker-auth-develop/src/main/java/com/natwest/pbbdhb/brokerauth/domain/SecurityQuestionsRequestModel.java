package com.natwest.pbbdhb.brokerauth.domain;

import java.util.List;
import java.util.Map;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class SecurityQuestionsRequestModel {

  String parentId;

  List<SecurityQuestion> questions;

}
