package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to create a user.
 */
@Builder
@Value
public class UserCreateRequestModel {

  /**
   * The user's first name. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String firstname;

  /**
   * The user's last name. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String lastname;

  /**
   * The user's email address. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String email;

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The type of user. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  BrokerTypeModel brokerType;
}
