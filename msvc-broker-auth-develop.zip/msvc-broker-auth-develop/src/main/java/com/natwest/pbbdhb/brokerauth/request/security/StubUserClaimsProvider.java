package com.natwest.pbbdhb.brokerauth.request.security;


import com.natwest.pbbdhb.brokerauth.domain.Brand;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

/**
 * Mock of user claims provider that returns hardcoded values that would be retrieved from the JWT
 * in production.
 */
@Service
@Slf4j
@ConditionalOnProperty(name = "features.user-claims-mode", havingValue = "stub")
public class StubUserClaimsProvider implements UserClaimsProvider {

  private static final String stubAccessToken = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL3BiYm53aXN1YXQuY3JtNC5keW5hbWljcy5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83YzkxN2RiMC03MWYyLTQzOGUtOTU1NC0zODhmZmNhYjg3NjQvIiwiaWF0IjoxNjc5NjYwMzkyLCJuYmYiOjE2Nzk2NjAzOTIsImV4cCI6MTY3OTY2NDI5MiwiYWlvIjoiRTJaZ1lQaHFwSGt5dXNEOHZVdkZncDhGc3ozekFBPT0iLCJhcHBpZCI6IjY3NTcyYTg1LWM0NjUtNDJiNC05MWI5LTQ5YThlNzNlZTNhZCIsImFwcGlkYWNyIjoiMiIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzdjOTE3ZGIwLTcxZjItNDM4ZS05NTU0LTM4OGZmY2FiODc2NC8iLCJvaWQiOiJkOTFlOGIzOS0zZDljLTRiYTQtYWRjOC1iNzhmNGM1MmQ3ZTYiLCJyaCI6IjAuQVJFQXNIMlJmUEp4amtPVlZEaVBfS3VIWkFjQUFBQUFBQUFBd0FBQUFBQUFBQUFSQUFBLiIsInN1YiI6ImQ5MWU4YjM5LTNkOWMtNGJhNC1hZGM4LWI3OGY0YzUyZDdlNiIsInRpZCI6IjdjOTE3ZGIwLTcxZjItNDM4ZS05NTU0LTM4OGZmY2FiODc2NCIsInV0aSI6Ik5ITURHMWIwOFVPU1h4Z2RSQjhVQUEiLCJ2ZXIiOiIxLjAifQ.hkV6fmJfV2jmvuWad5R9fZ894KluBH5N-K6W8cDh1-w-Ko1HCo3fjJhd0Rwo-K1kXoPQ49I0mkJFd8QmtRAh2VMihvN-W8MGxgWHmBy9jYEcGk6dl3_4HDLC3_o2wx-pSaL0MxtK2gjx-oDT_zISpscg2zu3RUZ_KMSoUUduL8UXpRS-MX0YTTa-5V0wKjMR8wsvp5Z4tmnkenwbyLRlN88INDYEgrg67_C4Ls7CGF0DNfLTWdJ5XDIa0uHEO6EFyknTF17mqjiER-JXeh87LNjCg6TztZYKQPjgHsgBVrBwIRA1JRa6buveh48cvxvZNJ4rg2UVDJTDdZmoU75__Q;";

  @Override
  public Brand getOperatingBrand() {
    log.debug("getOperatingBrand: Getting operating brand.");
    return Brand.NWB;
  }

  @Override
  public String getAccessToken() {
    log.debug("getAccessToken: Getting access token.");
    return stubAccessToken;
  }
}
