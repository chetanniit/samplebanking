package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement;

import com.natwest.pbbdhb.brokerauth.configuration.CustomerIdentityManagementClientConfig;
import com.natwest.pbbdhb.brokerauth.configuration.CustomerIdentityManagementClientConfig.CustomerIdentityManagementStubClientConfig;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import java.util.Collections;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * A stubbed Customer Identity Management client, which makes decisions on what data to return based
 * on configuration properties.
 */
@ConditionalOnProperty(
    value = "clients.customeridentitymanagement.stub.enabled",
    havingValue = "true"
)
@Component
@Slf4j
public class CustomerIdentityManagementStubClient implements CustomerIdentityManagementClient {

  private final CustomerIdentityManagementStubClientConfig config;

  public CustomerIdentityManagementStubClient(CustomerIdentityManagementClientConfig config) {
    log.warn(
        "Stub version of Customer Identity Management client in-use. Only intended for test environments.");
    this.config = config.getStub();
  }

  @Override
  public void createUser(String accessToken, UserCreateRequestModel createModel) {
    log.warn("Stub Create User call. Only intended for test environments.");
  }

  @Override
  public void deleteUser(String accessToken, String customerIdentifierId,
      UserDeleteRequestModel userDeleteRequestModel) {
    log.warn("Stub Delete User call. Only intended for test environments.");
  }

  @Override
  public void initialiseOtp(String accessToken, String username) {
    log.warn("Stub Initialise OTP call. Only intended for test environments.");
  }

  @Override
  public OtpRetrieveResponseModel retrieveOTP(String accessToken, String username) {
    log.warn("Stub Retrieve OTP call. Only intended for test environments.");
    return OtpRetrieveResponseModel.builder()
        .otpId("7d2b3b4a-421c-4726-bc49-19645dbe047c")
        .build();
  }

  @Override
  public OtpGenerateResponseModel generateOTP(String accessToken, String otpId) {
    log.warn("Stub Update Password OTP call. Only intended for test environments.");
    return OtpGenerateResponseModel.builder()
        .activationCode("testActivationCode")
        .build();
  }

  @Override
  public void updateOTP(String accessToken, OtpUpdateRequestModel otpUpdateRequestModel) {
    log.warn("Stub Update OTP call. Only intended for test environments.");
  }

  @Override
  public void deleteOTP(String accessToken, String otpId) {
    log.warn("Stub Delete OTP call. Only intended for test environments.");
  }

  @Override
  public void login(String accessToken, LoginRequestModel attempt) {
    log.warn("Stub Initialise login call. Only intended for test environments.");
  }

  @Override
  public GetCustomerResponseModel getCustomer(String accessToken, String username) {
    log.warn("Returning get customer stub response. Only intended for test environments.");
    return GetCustomerResponseModel.builder()
        .id("TestId")
        .brokerType(BrokerTypeModel.BROKER)
        .build();
  }

  @Override
  public GetUserResponseModel getUser(String accessToken, String username) {
    log.warn("Returning get user stub response. Only intended for test environments.");
    return GetUserResponseModel.builder()
        .id("TestId")
        .brokerType(BrokerTypeModel.BROKER)
        .parentId(
            "uid=5be0c229-2a1c-4466-9dac-446be8628080,ou=customer,ou=personaidentity,ou=common,dc=carnus")
        .build();
  }

  @Override
  public void activateAccount(String accessToken, String customerId) {
    log.warn("Stub Activate call. Only intended for test environments.");
  }

  @Override
  public void setPassword(String accessToken, UserSetPasswordRequestModel request) {
    log.warn("Stub set password call. Only intended for test environments.");
  }

  @Override
  public void changePassword(String accessToken, UserChangePasswordRequestModel request) {
    log.warn("Stub change password call. Only intended for test environments.");
  }
  @Override
  public void createSecurityQuestions(String accessToken, SecurityQuestionsRequestModel request) {
    log.warn("Stub set security questions call. Only intended for test environments.");
  }

  @Override
  public void setSecurityQuestions(String accessToken, SecurityQuestionsRequestModel request,
      String questionsId) {
    log.warn("Stub set security questions call. Only intended for test environments.");
  }

  @Override
  public SecurityQuestionsFetchResponseModel getSecurityQuestions(String accessToken,
      String parentId) {
    log.warn("Stub get security questions call. Only intended for test environments.");

    List<SecurityQuestionsFetchResponseModel.SecurityQuestion> questions = Collections.singletonList(
        SecurityQuestionsFetchResponseModel.SecurityQuestion.builder()
            .id("q1")
            .question("test question?")
            .build()
    );
    return SecurityQuestionsFetchResponseModel.builder()
        .id("7d2b3b4a-421c-4726-bc49-19645dbe047c")
        .securityQuestions(questions)
        .build();
  }

  @Override
  public void deleteSecurityQuestions(String accessToken, String questionsId) {
    log.warn("Stub delete security questions call. Only intended for test environments.");
  }

  @Override
  public void validateSecurityQuestion(String accessToken,
      SecurityQuestionsSingleValidationRequestModel request) {
    log.warn("Stub validate security question call. Only intended for test environments.");
  }

  public void validateOtp(String accessToken, OtpValidateRequestModel requestModel) {
    log.warn("Stub validate OTP call. Only intended for test environments.");
  }
}
