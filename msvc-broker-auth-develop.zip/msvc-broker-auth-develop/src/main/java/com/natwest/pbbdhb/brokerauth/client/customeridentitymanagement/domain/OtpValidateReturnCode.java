package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import java.util.function.Consumer;
import lombok.NonNull;

/**
 * Enum to map possible values for the return code when validating an OTP from CIM
 */
public enum OtpValidateReturnCode {

  SUCCESS("0", (username) -> {
  }),
  INVALID_OTP("1", (username) -> {
    throw new OtpException(ErrorCode.INVALID_CREDENTIALS,
        "Otp code is invalid for user: " + username);
  }),
  OTP_ALREADY_USED("2", (username) -> {
    throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
        "Otp code has already been used for user: " + username);
  }),
  OTP_EXPIRED("3", (username) -> {
    throw new OtpException(ErrorCode.OTP_EXPIRED, "Otp code has expired for user: " + username);
  }),
  ACCOUNT_LOCKED("4", (username) -> {
    throw new OtpException(ErrorCode.ACCOUNT_LOCKED, "Account is locked for user: " + username);
  }),
  DECODING_FAILED("5", (username) -> {
    throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
        "Decoding failed for user: " + username);
  }),
  UNKNOWN_SERVICE_ERROR("6", (username) -> {
    throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
        "Unknown service error occurred for user: " + username);
  }),
  NO_RECORDS_FOUND("7", (username) -> {
    throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
        "No records found for user: " + username);
  }),
  MULTIPLE_RECORDS_FOUND("8", (username) -> {
    throw new OtpException(ErrorCode.OTP_VALIDATION_FAILED,
        "Multiple records were found for user: " + username);
  });

  private final String value;
  private final Consumer<String> assertion;

  OtpValidateReturnCode(@NonNull String value, Consumer<String> assertion) {
    this.value = value;
    this.assertion = assertion;
  }

  public void validate(String username) {
    assertion.accept(username);
  }

  /**
   * Create an enum value from a String equivalent
   *
   * @param text The original string value
   * @return OtpValidateReturnCode
   */
  @JsonCreator
  public static OtpValidateReturnCode fromValue(String text) {
    for (OtpValidateReturnCode code : OtpValidateReturnCode.values()) {
      if (code.value.equals(text)) {
        return code;
      }
    }
    return null;
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }
}