package com.natwest.pbbdhb.brokerauth.exception;

import lombok.Getter;

/**
 * An exception to be thrown when the requested username can not be found.
 */
@Getter
public class UserNotFoundException extends RuntimeException {

  public UserNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public UserNotFoundException(String message) {
    super(message);
  }
}
