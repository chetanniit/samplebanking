package com.natwest.pbbdhb.brokerauth.exception;

/**
 * Used to indicate a security answer was found to be incorrect when validating.
 */
public class SecurityQuestionValidateException extends RuntimeException {

  public SecurityQuestionValidateException(String message) {
    super(message);
  }
}