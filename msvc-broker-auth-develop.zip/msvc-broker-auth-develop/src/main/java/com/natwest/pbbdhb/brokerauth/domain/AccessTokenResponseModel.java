package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class AccessTokenResponseModel {

  @NonNull
  String accessToken;

  @NonNull
  String tokenType;

  // expires-in is an optional field for IAM access tokens
  Integer expiresIn;
}
