package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetailsCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath;
import com.natwest.pbbdhb.brokerauth.request.domain.PrincipalFcaFirm;
import lombok.extern.slf4j.Slf4j;

import java.util.stream.Collectors;

@Slf4j
public class FirmDetailsMapper {

  private FirmDetailsMapper() {
  }

  public static FirmDetailsResponse toFirmDetailsResponse(
      FirmDetailsCoreResponse input, String fcaNumber) {
    log.debug("toFirmDetailsResponse: Mapping FirmDetailsCoreResponse and fcaNumber to FirmDetailsResponse.");
    return FirmDetailsResponse.builder()
        .brokerType(input.getFirmType())
        .fcaNumber(fcaNumber)
        .tradingNames(input.getAlternativeTradingNames().stream()
            .map(TradingName::getName)
            .collect(Collectors.toList()))
        .paymentPaths(input.getPaymentPaths().stream()
            .map(paymentPath -> new PaymentPath(paymentPath.getName(), paymentPath.getPaymentId()))
            .collect(Collectors.toList()))
        .principalFcaFirms(input.getPrincipalFcaFirms().stream()
            .map(principalFcaFirm -> PrincipalFcaFirm.builder()
                .name(principalFcaFirm.getName())
                .fcaNumber(principalFcaFirm.getFcaNumber())
                .build())
            .collect(Collectors.toList()))
        .build();
  }

}
