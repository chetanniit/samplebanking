package com.natwest.pbbdhb.brokerauth.request.controller;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.request.controller.helpers.AccessTokenRequestHelper;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorResponse;
import com.natwest.pbbdhb.brokerauth.request.mapper.ActivationRequestMapper;
import com.natwest.pbbdhb.brokerauth.service.activation.ActivationService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * A controller providing operations to be acted on Activation codes endpoints.
 */
@RestController
@RequestMapping("/mortgages/v1/msvc-broker-auth/activation")
@Tag(name = "Activation", description = "An endpoint for creating a new activation code")
@Slf4j
public class ActivationController {

  private final ActivationService activationService;
  private final AccessTokenService accessTokenService;
  private final AccessTokenRequestHelper accessTokenRequestHelper;

  @Autowired
  public ActivationController(
      ActivationService activationService,
      AccessTokenService accessTokenService,
      AccessTokenRequestHelper accessTokenRequestHelper) {
    this.activationService = activationService;
    this.accessTokenService = accessTokenService;
    this.accessTokenRequestHelper = accessTokenRequestHelper;
  }

  @PostMapping("/validate")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @Operation(responses = {
      @ApiResponse(responseCode = "204", description = "Successfully validated activation code"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
      @ApiResponse(responseCode = "401", description = "Unauthorised", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  public void validateActivationCode(
      @Valid @RequestBody ActivationCodeValidateRequest request) {
    final String accessToken = getAccessToken();

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("validateActivationCode: validating activation code %s, for user: %s",
                request.getCode(),
            request.getUsername()))
        .build()
    );
    activationService.validateActivationCode(accessToken,
        ActivationRequestMapper.toOtpValidateRequestModel(request));
    log.info("validateActivationCode: Activation code for username: {}, successfully validated", request.getUsername());
  }

  /**
   * Activates a new User and let Spring boot convert the request body in json format to a {@link
   * UserActivateRequest} object. The request body will be validated by {@code Valid}.
   *
   * @param request the User to activate
   */
  @Operation(responses = {
      @ApiResponse(responseCode = "204", description = "Successfully activated user resource"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @PostMapping()
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void activateUser(@RequestBody @Valid UserActivateRequest request) {

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("activateUser: Starting activate user operation for username: %s",
            request.getUsername()))
        .build()
    );
    log.info("activateUser: Activate user operation for username: {}, successful", request.getUsername());
    activationService.activateUser(request, getAccessToken());
  }


  private String getAccessToken() {
    log.info("getAccessToken: Getting access token.");
    AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel =
        accessTokenRequestHelper.tokenRetrieveRequestModel();

    log.info("getAccessToken: Access token successfully retrieved.");
    return accessTokenService.token(accessTokenRetrieveRequestModel).getAccessToken();
  }
}
