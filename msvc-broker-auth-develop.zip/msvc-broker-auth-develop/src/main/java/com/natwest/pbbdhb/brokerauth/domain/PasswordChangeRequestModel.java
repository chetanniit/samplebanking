package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to change a password.
 */
@Builder
@Value
public class PasswordChangeRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's current password. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String currentPassword;

  /**
   * The user's new password. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String newPassword;

}
