package com.natwest.pbbdhb.brokerauth.service.crm;

import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderRequest;

public interface UsernameReminderService {

    /**
     * A method to retrieve the forgotten username for a user (broker or broker admin).

     * @param usernameReminderRequest the {@link UsernameReminderRequest} request containing the user's email address,
     *                                last name and date of birth.
     * @return {@link UsernameReminderResponse}
     */
    UsernameReminderResponse getUsernameReminder(UsernameReminderRequest usernameReminderRequest);
}
