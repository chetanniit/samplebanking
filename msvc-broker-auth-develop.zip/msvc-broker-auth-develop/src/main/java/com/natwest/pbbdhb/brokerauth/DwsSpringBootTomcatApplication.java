package com.natwest.pbbdhb.brokerauth;

import com.natwest.pbbdhb.brokerauth.configuration.AccessTokenClientConfig;
import com.natwest.pbbdhb.brokerauth.configuration.CustomerIdentityManagementClientConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties({
    AccessTokenClientConfig.class,
    CustomerIdentityManagementClientConfig.class
})
@SpringBootApplication
public class DwsSpringBootTomcatApplication {

  public static void main(String[] args) {
    SpringApplication.run(DwsSpringBootTomcatApplication.class, args);
  }
}
