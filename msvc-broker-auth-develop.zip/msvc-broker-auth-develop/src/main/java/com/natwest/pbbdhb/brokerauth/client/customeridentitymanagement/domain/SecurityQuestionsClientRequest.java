package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class SecurityQuestionsClientRequest {

  @JsonProperty("parentidentity")
  @NonNull
  String parentId;

  @NonNull
  List<String> answer;

  @NonNull
  List<Map<String,String>> question;

  @NonNull
  List<String> schemas;

}
