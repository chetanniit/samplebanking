package com.natwest.pbbdhb.brokerauth.exception;

/**
 * Used to indicate a security question/answer is locked due to multiple failed attempts.
 */
public class SecurityQuestionLockedException extends RuntimeException {

  public SecurityQuestionLockedException(String message) {
    super(message);
  }
}