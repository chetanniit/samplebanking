package com.natwest.pbbdhb.brokerauth.service.crm;

import com.natwest.pbbdhb.brokerauth.model.crm.OAuthTokenData;

public interface OAuthTokenService {

    OAuthTokenData generatePingToken();
}
