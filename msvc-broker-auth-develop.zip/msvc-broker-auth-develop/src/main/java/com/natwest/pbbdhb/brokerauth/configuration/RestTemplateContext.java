package com.natwest.pbbdhb.brokerauth.configuration;

import com.natwest.pbbdhb.brokerauth.request.controller.helpers.CorrelationIdentifierHelper;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import java.io.IOException;
import java.net.URI;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.protocol.HttpClientContext;
import org.apache.hc.core5.http.protocol.HttpContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
@Slf4j
public class RestTemplateContext {

  /**
   * Configure and return a REST template that customises the Access Token REST client requests
   *
   * @param builder           - REST Template Builder
   * @param httpClient        - HTTP Client
   * @param correlationHelper - helper to retrieve correlation IDs
   * @return configured restTemplate that customises REST requests
   */
  @Bean
  // @Scope("prototype") required because dws connection pool config relies on this:
  // see com.rbs.dws.transport.config.HttpContext#httpClient and HystrixCloseableHttpClient
  // hystrixCommandKey defines connections pools which is set per instance
  @Scope("prototype")
  @Autowired
  @Qualifier("accessTokenRestTemplate")
  public RestTemplate accessTokenRestTemplate(
      RestTemplateBuilder builder,
      HttpClient httpClient,
      CorrelationIdentifierHelper correlationHelper) {
    return builder
        .requestFactory(() -> new CustomRequestFactory(httpClient, correlationHelper, null))
        .build();
  }

  /**
   * Configure and return a REST template that customises the Customer Identity Management REST
   * client requests
   *
   * @param builder           - REST Template Builder
   * @param httpClient        - HTTP Client
   * @param correlationHelper - helper to retrieve correlation IDs
   * @param config            - Customer Service Client Config
   * @return configured restTemplate that customises REST requests
   */
  @Bean
  // @Scope("prototype") required because dws connection pool config relies on this:
  // see com.rbs.dws.transport.config.HttpContext#httpClient and HystrixCloseableHttpClient
  // hystrixCommandKey defines connections pools which is set per instance
  @Scope("prototype")
  @Autowired
  @Qualifier("customerServiceRestTemplate")
  public RestTemplate customerServiceRestTemplate(
      RestTemplateBuilder builder,
      HttpClient httpClient,
      CorrelationIdentifierHelper correlationHelper,
      CustomerIdentityManagementClientConfig config) {
    int timeout = config.getRest().getTimeout();
    RequestConfig requestConfig = RequestConfig.custom().setResponseTimeout(timeout, TimeUnit.SECONDS).build();
    return builder
        .requestFactory(() -> new BufferingClientHttpRequestFactory(
                new CustomRequestFactory(httpClient, correlationHelper, requestConfig)))
        .build();
  }

  /**
   * A Custom Request Factory used to customise all REST requests by adding Correlation ID headers
   */
  public static class CustomRequestFactory extends HttpComponentsClientHttpRequestFactory {

    private static final String IAM_CORRELATION_ID_HEADER = "X-Correlation-ID";
    private static final String IAM_REQUEST_ID_HEADER = "X-Request-ID";

    private final CorrelationIdentifierHelper correlationHelper;
    private final RequestConfig requestConfig;

    public CustomRequestFactory(
            HttpClient httpClient,
            CorrelationIdentifierHelper correlationHelper,
            RequestConfig requestConfig) {

      super(httpClient);
      this.correlationHelper = correlationHelper;
      this.requestConfig = requestConfig;
    }

    @Override
    public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {

      final ClientHttpRequest request = super.createRequest(uri, httpMethod);
      HttpContext context = this.createHttpContext(httpMethod, uri);
      if (context == null) {
        context = HttpClientContext.create();
      }
      RequestConfig config = this.requestConfig;
      if (config != null) {
        context.setAttribute("http.request-config", config);
      }
      // insert the correlation headers expected by Ping Federate.
      // to simplify monitoring, we re-use the current HTTP request's correlation header values.
      request
          .getHeaders()
          .set(
              IAM_CORRELATION_ID_HEADER,
              correlationHelper.requestCorrelationId());
      request
          .getHeaders()
          .set(
              IAM_REQUEST_ID_HEADER,
              correlationHelper.requestInternalCorrelationId());
      log.info(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.CONFIG)
          .description(String.format("Access Token request headers: %s", request.getHeaders()))
          .build()
      );

      return request;
    }
  }
}
