package com.natwest.pbbdhb.brokerauth.configuration;

import static com.natwest.pbbdhb.brokerauth.configuration.helpers.KeyStoreHelper.keyStore;

import com.natwest.pbbdhb.brokerauth.exception.KeystoreException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Provides the private key used for signing JWTs.
 */
@Configuration
public class JwtSigningContext {

  @Bean
  @Qualifier("jwtSigningKey")
  public PrivateKey signingKey(@Autowired JwtSigningConfig config) {
    final JwtSigningConfig.SigningCertificate certificate =
        config.getCertificate();

    final char[] password = certificate.getPassword().toCharArray();

    final KeyStore keyStore = keyStore(
        certificate.getType(),
        certificate.getFile(),
        password);

    try {
      final Key key = keyStore.getKey(
          certificate.getAlias(),
          password);

      if (!(key instanceof PrivateKey)) {
        throw new KeystoreException("Key is not an instance of a PrivateKey");
      }

      return (PrivateKey) key;
    } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
      throw new KeystoreException("Unable to extract private key from keystore", e);
    }
  }
}
