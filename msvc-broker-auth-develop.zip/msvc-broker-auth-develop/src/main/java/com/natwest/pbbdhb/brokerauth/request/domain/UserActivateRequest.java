package com.natwest.pbbdhb.brokerauth.request.domain;

import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

import java.util.List;

/**
 * A domain definition of the payload supplied to controller when caller wants to activate a user.
 */
@Validated
@Value
@Builder
public class UserActivateRequest {

  @Schema(
      description = "The otp code for validation",
      required = true
  )
  @NonNull
  String otpCode;

  @Schema(
      description = "Specifies user's username",
      required = true
  )
  @NonNull
  String username;

  @Schema(
      description = "Specifies user's password",
      required = true
  )
  @NonNull
  String password;

  @Schema(
      description = "Specifies user's security questions and answers",
      required = true
  )
  @NonNull
  List<@Valid SecurityQuestion> securityQuestions;
}
