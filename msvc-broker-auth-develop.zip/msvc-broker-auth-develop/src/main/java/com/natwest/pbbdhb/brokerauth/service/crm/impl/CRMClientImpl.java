package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.PingTokenGenerationException;
import com.natwest.pbbdhb.brokerauth.model.crm.OAuthTokenData;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class CRMClientImpl<R, T> implements CRMClient<R, T> {
    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer ";

    private final RestTemplate restTemplate;
    private final OAuthTokenService oauthTokenService;

    public CRMClientImpl(@Qualifier(value = "proxyRestTemplate") RestTemplate restTemplate,
                         OAuthTokenService oauthTokenService) {
        this.restTemplate = restTemplate;
        this.oauthTokenService = oauthTokenService;
    }

    @Override
    public T get(String endpoint, Class<T> responseType) {
        log.debug("get: Get method called.");
        OAuthTokenData tokenData = oauthTokenService.generatePingToken();
        if (tokenData != null && tokenData.getAccessToken() != null) {
            log.debug("get: Token data not null for get method.");
            HttpHeaders headers = getHttpHeaders(tokenData);
            HttpEntity httpEntity = new HttpEntity<>(headers);

            ResponseEntity<T> response =
                    restTemplate.exchange(endpoint, HttpMethod.GET, httpEntity, responseType);
            log.debug("get: End of get method where token data not null.");
            return response.getBody();
        }
        log.warn("get: End of get method - no ping token found - ping token generation exception thrown.");
        throw new PingTokenGenerationException("No Ping token found to call :" + endpoint);
    }

    @Override
    public T post(String endpoint, R body, Class<T> responseType) {
        log.debug("post: Post method called.");
        OAuthTokenData tokenData = oauthTokenService.generatePingToken();
        if (tokenData != null && tokenData.getAccessToken() != null) {
            log.debug("post: Token data not null for post method.");
            HttpHeaders headers = getHttpHeaders(tokenData);
            HttpEntity httpEntity = new HttpEntity<>(body, headers);

            ResponseEntity<T> response =
                    restTemplate.exchange(endpoint, HttpMethod.POST, httpEntity, responseType);
            log.debug("post: End of post method where token data not null.");
            return response.getBody();
        }
        log.warn("post: End of post method - no ping token found - ping token generation exception thrown.");
        throw new PingTokenGenerationException("No Ping token found to call :" + endpoint);
    }

    private HttpHeaders getHttpHeaders(OAuthTokenData tokenData) {
        log.debug("post: Getting http headers.");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(AUTHORIZATION, BEARER + tokenData.getAccessToken());
        log.debug("post: http headers successfully retrieved.");
        return headers;
    }
}
