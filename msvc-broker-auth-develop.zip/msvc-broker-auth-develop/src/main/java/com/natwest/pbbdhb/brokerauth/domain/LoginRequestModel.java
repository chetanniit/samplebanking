package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to validate a user's credentials.
 */
@Builder
@Value
public class LoginRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's password. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String password;
}
