package com.natwest.pbbdhb.brokerauth.configuration;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * Represents the configuration for the JWT signing certificate.
 */
@Configuration
@ConfigurationProperties(prefix = "services.jwt-signing")
@Data
@Validated
public class JwtSigningConfig {

  @NotNull
  private SigningCertificate certificate;

  @Getter
  @Setter
  public static class SigningCertificate {

    @NotBlank
    private String type;

    @NotBlank
    private String file;

    @NotBlank
    private String alias;

    @NotBlank
    private String password;
  }
}
