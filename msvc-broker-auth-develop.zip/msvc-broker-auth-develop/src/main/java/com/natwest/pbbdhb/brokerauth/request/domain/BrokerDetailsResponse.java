package com.natwest.pbbdhb.brokerauth.request.domain;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerDetailsResponse {

  @NotNull
  private BrokerDetails brokerDetails;

  @NotNull
  private List<NonSTPFieldCategory> processingFields;

}
