package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions.BrokerPermissionsRequest;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.AdminDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.service.crm.CrmService;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import java.util.Collections;

@Service
@Slf4j
public class CrmServiceImpl implements CrmService {

    private final CRMClient crmClient;
    private final String brokerDetailsEndpoint;
    private final String adminDetailsEndpoint;
    private final String brokerUpdateDetailsEndpoint;
    private final String adminUpdateDetailsEndpoint;
    private final String brokerAssociationsEndpoint;
    private final String brokerUnAssociationsEndpoint;
    private final String adminAssociationsEndpoint;
    private final String updateAssociationsEndpoint;

    public CrmServiceImpl(CRMClient crmClient,
                          @Value("${broker.crm.details.endpoint}") String brokerDetailsEndpoint,
                          @Value("${broker.crm.admin.details.endpoint}") String adminDetailsEndpoint,
                          @Value("${broker.crm.update.details.endpoint}") String brokerUpdateDetailsEndpoint,
                          @Value("${broker.crm.admin.update.details.endpoint}") String adminUpdateDetailsEndpoint,
                          @Value("${broker.crm.association.endpoint}") String brokerAssociationsEndpoint,
                          @Value("${broker.crm.unassociation.endpoint}") String brokerUnAssociationsEndpoint,
                          @Value("${broker.crm.admin.association.endpoint}") String adminAssociationsEndpoint,
                          @Value("${broker.crm.update.associations.endpoint}") String updateAssociationsEndpoint) {
        this.crmClient = crmClient;
        this.brokerDetailsEndpoint = brokerDetailsEndpoint;
        this.adminDetailsEndpoint = adminDetailsEndpoint;
        this.brokerUpdateDetailsEndpoint = brokerUpdateDetailsEndpoint;
        this.adminUpdateDetailsEndpoint = adminUpdateDetailsEndpoint;
        this.brokerAssociationsEndpoint = brokerAssociationsEndpoint;
        this.brokerUnAssociationsEndpoint = brokerUnAssociationsEndpoint;
        this.adminAssociationsEndpoint = adminAssociationsEndpoint;
        this.updateAssociationsEndpoint = updateAssociationsEndpoint;
    }

    @Override
    public BrokerCoreResponse getBrokerDetails(String userName) {
        log.debug("getBrokerDetails: Getting broker details of userName: {}", userName);
        try {
            BrokerCoreResponse brokerCoreResponse = (BrokerCoreResponse) crmClient.get(String.format(brokerDetailsEndpoint,
                userName), BrokerCoreResponse.class);
            log.debug("getBrokerDetails: Broker details of userName: {}, successfully retrieved", userName);
            return brokerCoreResponse;
        } catch (RestClientException ex) {
            log.warn("getBrokerDetails: Request failed for broker username {}", userName);
            throw new RemoteRequestFailedException(
                String.format("getBrokerDetails: Request failed for broker username %s", userName), ex);
        }
    }

    @Override
    public AdminCoreResponse getAdminDetails(String brokerUserName) {
        log.debug("getAdminDetails: Getting admin details for userName: {}", brokerUserName);
        try {
            AdminCoreResponse adminCoreResponse = (AdminCoreResponse) crmClient.get(String.format(adminDetailsEndpoint,
                brokerUserName), AdminCoreResponse.class);
            log.debug("getAdminDetails: Admin details for userName: {}, successfully retrieved", brokerUserName);
            return adminCoreResponse;
        } catch (RestClientException ex) {
            log.warn("getAdminDetails: Request failed for admin username {}", brokerUserName);
            throw new RemoteRequestFailedException(
                String.format("getAdminDetails: Request failed for admin username %s", brokerUserName), ex);
        }
    }

    @Override
    public void updateBrokerDetails(BrokerDetailsChangeCrmRequest brokerDetailsChangeCrmRequest) {
        log.debug("updateBrokerDetails: Updating broker details for userName: {}", brokerDetailsChangeCrmRequest.getUsername());
        try {
            crmClient.post(brokerUpdateDetailsEndpoint, brokerDetailsChangeCrmRequest, Void.class);
            log.debug("updateBrokerDetails: Broker details for userName: {}, successfully updated", brokerDetailsChangeCrmRequest.getUsername());
        } catch (RestClientException ex) {
            log.warn("updateBrokerDetails: Request failed for broker username {} - {}", brokerDetailsChangeCrmRequest, ex.getMessage());
            throw new RemoteRequestFailedException(
                String.format("updateBrokerDetails: Request failed for broker username %s", brokerDetailsChangeCrmRequest.getUsername()), ex);
        }
    }

    @Override
    public void updateAdminDetails(AdminDetailsChangeCrmRequest adminDetailsChangeCrmRequest) {
        log.debug("updateAdminDetails: Updating admin details for userName: {}", adminDetailsChangeCrmRequest.getUsername());
        try {
            crmClient.post(adminUpdateDetailsEndpoint, adminDetailsChangeCrmRequest, Void.class);
            log.debug("updateAdminDetails: Admin details for userName: {}, successfully updated", adminDetailsChangeCrmRequest.getUsername());
        } catch (RestClientException ex) {
            log.warn("updateAdminDetails:Request failed for admin username {} - {}", adminDetailsChangeCrmRequest.getUsername(), ex.getMessage());
            throw new RemoteRequestFailedException(
                String.format("updateAdminDetails: Request failed for admin username %s", adminDetailsChangeCrmRequest.getUsername()), ex);
        }
    }

    @Override
    public BrokerAssociationsResponse getBrokerAssociations(String userName) {
        log.debug("getBrokerAssociations: Getting broker associations for userName: {}", userName);
        try {
            log.debug("getBrokerAssociations: Broker associations for userName: {}, successfully retrieved", userName);
            return (BrokerAssociationsResponse) crmClient.get(String.format(brokerAssociationsEndpoint,
                userName), BrokerAssociationsResponse.class);
        } catch (RestClientException ex) {
            log.warn("getBrokerAssociations: Request failed for username {}", userName);
            throw new RemoteRequestFailedException(
                String.format("getBrokerAssociations: Request failed for username %s", userName), ex);
        }
    }

    @Override
    public BrokerAssociationsResponse getBrokerUnAssociations(String userName) {
        log.debug("getBrokerUnAssociations: Getting broker unassociations for userName: {}", userName);
        try {
            log.debug("getBrokerUnAssociations: Broker unassociations for userName: {}, successfully retrieved", userName);
            return (BrokerAssociationsResponse) crmClient.get(String.format(brokerUnAssociationsEndpoint,
                userName), BrokerAssociationsResponse.class);
        } catch (RestClientException ex) {
            log.warn("getBrokerUnAssociations: Request failed for username {}", userName);
            throw new RemoteRequestFailedException(
                String.format("getBrokerUnAssociations: Request failed for username %s", userName), ex);
        }

    }

    @Override
    public AdminAssociationsResponse getAdminAssociations(String userName) {
        log.debug("getAdminAssociations: Getting admin associations for userName: {}", userName);
        try {
            log.debug("getAdminAssociations: Admin associations for userName: {}, successfully retrieved", userName);
            return (AdminAssociationsResponse) crmClient.get(String.format(adminAssociationsEndpoint,
                userName), AdminAssociationsResponse.class);
        } catch (RestClientException ex) {
            log.warn("getAdminAssociations: Request failed for username {}", userName);
            throw new RemoteRequestFailedException(
                String.format("getAdminAssociations: Request failed for username %s", userName), ex);
        }
    }

    @Override
    public BrokerPermissionsResponse associateBrokerToBroker(String userName, String userNameToAssociate) {
        log.debug("associateBrokerToBroker: Associating broker to broker. UserName: {}, " +
                        "UserName To Associate: {}", userName, userNameToAssociate);
        try {
            BrokerPermissionsRequest permissionsRequest =
                BrokerPermissionsRequest.builder()
                    .userName(userName)
                    .associateBrokers(Collections.singletonList(userNameToAssociate))
                    .build();
            log.debug("associateBrokerToBroker: End of associate broker to broker.");
            return (BrokerPermissionsResponse) crmClient.post(updateAssociationsEndpoint, permissionsRequest, BrokerPermissionsResponse.class);
        } catch (RestClientException ex) {
            log.warn("associateBrokerToBroker: Request failed where userName is {} and userNameToAssociate is {}", userName, userNameToAssociate);
            throw new RemoteRequestFailedException(
                String.format("associateBrokerToBroker: Request failed where userName is %s and userNameToAssociate is %s", userName, userNameToAssociate), ex);
        }
    }

    @Override
    public BrokerPermissionsResponse unAssociateBrokerToBroker(String userName, String userNameToUnAssociate) {
        log.debug("unAssociateBrokerToBroker: Unassociating broker to broker. UserName: {}, UserName To Unassociate: {}",
                userName, userNameToUnAssociate);
        try {
            BrokerPermissionsRequest permissionsRequest =
                BrokerPermissionsRequest.builder()
                    .userName(userName)
                    .dissociateBrokers(Collections.singletonList(userNameToUnAssociate))
                    .build();
            log.debug("unAssociateBrokerToBroker: End of unassociate broker to broker.");
            return (BrokerPermissionsResponse) crmClient.post(updateAssociationsEndpoint, permissionsRequest, BrokerPermissionsResponse.class);
        } catch (RestClientException ex) {
            log.warn("unAssociateBrokerToBroker: Request failed where userName is {} and userNameToUnAssociate is {}", userName, userNameToUnAssociate);
            throw new RemoteRequestFailedException(
                    String.format("unAssociateBrokerToBroker: Request failed where userName is %s and userNameToUnAssociate is %s", userName, userNameToUnAssociate), ex);
        }
    }

    @Override
    public BrokerPermissionsResponse associateBrokerToAdmin(String userName, String adminToAssociate) {
        log.debug("associateBrokerToAdmin: Associating broker to admin. UserName: {}, adminToAssociate: {}",
                userName, adminToAssociate);
        try {
            BrokerPermissionsRequest permissionsRequest =
                BrokerPermissionsRequest.builder()
                    .userName(userName)
                    .associateBrokerAdmins(Collections.singletonList(adminToAssociate))
                    .build();
            log.debug("associateBrokerToAdmin: End of associate broker to broker of CRM service");
            return (BrokerPermissionsResponse) crmClient.post(updateAssociationsEndpoint, permissionsRequest, BrokerPermissionsResponse.class);
        } catch (RestClientException ex) {
            log.warn("associateBrokerToAdmin: Request failed where userName is {} and adminToAssociate is {}", userName, adminToAssociate);
            throw new RemoteRequestFailedException(
                String.format("associateBrokerToAdmin: Request failed where userName is %s and adminToAssociate is %s", userName, adminToAssociate), ex);
        }
    }

    @Override
    public BrokerPermissionsResponse unAssociateBrokerToAdmin(String userName, String adminToUnAssociate) {
        log.debug("unAssociateBrokerToAdmin: unassociating broker from admin UserName: {}, " +
                        " adminToUnAssociate: {}", userName, adminToUnAssociate);
        try {
            BrokerPermissionsRequest permissionsRequest =
                BrokerPermissionsRequest.builder()
                    .userName(userName)
                    .dissociateBrokerAdmins(Collections.singletonList(adminToUnAssociate))
                    .build();
            log.debug("unAssociateBrokerToAdmin: End of unassociate broker to admin of CRM service");
            return (BrokerPermissionsResponse) crmClient.post(updateAssociationsEndpoint, permissionsRequest, BrokerPermissionsResponse.class);
        } catch (RestClientException ex) {
            log.warn("unAssociateBrokerToAdmin: Request failed where userName is {} and adminToUnAssociate is {}", userName, adminToUnAssociate);
            throw new RemoteRequestFailedException(
                String.format("unAssociateBrokerToAdmin: Request failed where userName is %s and adminToUnAssociate is %s", userName, adminToUnAssociate), ex);
        }}

}
