package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/* A domain definition of the payload supplied to controller when caller wants to change memorable questions. */
@Validated
@Value
@Builder
public class ChangeMemorableQuestionsRequest {

  @JsonProperty("username")
  @Schema(
      description = "Specifies user's username",
      required = true
  )
  @NonNull
  String username;

  @JsonProperty("questions")
  @Schema(
      description = "Specifies user's security questions",
      required = true
  )
  @NonNull
  List<SecurityQuestion> questions;

  @Builder
  @Value
  public static class SecurityQuestion {

    @NotBlank
    String question;
    @NotBlank
    String answer;
  }

}
