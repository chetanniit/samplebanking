package com.natwest.pbbdhb.brokerauth.configuration;

import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.validation.constraint.ContainsAllBrands;
import java.util.EnumMap;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * Represents the configuration required for SCIM IAM token requests.
 */
@Configuration
@ConfigurationProperties(prefix = "services.iam.scim")
@Data
@Validated
public class IamScimConfig {

  @NotBlank
  private String clientAssertionType;

  @NotBlank
  private String scope;

  @NotBlank
  private String grantType;

  @NotBlank
  private String algorithm;
  
  @NotNull
  @ContainsAllBrands
  private EnumMap<Brand, BrandedConfig> brands;

  // holds config that can vary by brand
  @Getter
  @Setter
  public static class BrandedConfig {

    @NotBlank
    private String issuer;

    @NotBlank
    private String clientId;

    @NotBlank
    private String audience;
  }
}
