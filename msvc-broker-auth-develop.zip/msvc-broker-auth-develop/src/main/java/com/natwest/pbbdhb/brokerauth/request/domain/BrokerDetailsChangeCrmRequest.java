package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BrokerDetailsChangeCrmRequest {

  @NotNull
  @JsonProperty("mbs_userName")
  private String username;

  @JsonProperty("mbs_title")
  private String title;

  @JsonProperty("mbs_firstName")
  private String firstName;

  @JsonProperty("mbs_lastName")
  private String lastName;

  @JsonProperty("mbs_emailAddress")
  private String email;

  @JsonProperty("mbs_mobilePhone")
  private String mobilePhone;

  @JsonProperty("mbs_businessPhone")
  private String businessPhone;

  @JsonProperty("mbs_addressLine1")
  private String addressLine1;

  @JsonProperty("mbs_addressLine2")
  private String addressLine2;

  @JsonProperty("mbs_addressLine3")
  private String addressLine3;

  @JsonProperty("mbs_city")
  private String city;

  @JsonProperty("mbs_county")
  private String county;

  @JsonProperty("mbs_postCode")
  private String postcode;

  @JsonIgnore
  private String fcaNumber;

  @JsonProperty("mbs_tradingName")
  private String tradingName;

  @JsonProperty("mbs_paymentPaths")
  private List<String> paymentPaths;

  @JsonProperty("mbs_nationality")
  private String nationality;

  @JsonProperty("mbs_residentialAddressLine1")
  private String residentialAddressLine1;

  @JsonProperty("mbs_residentialAddressLine2")
  private String residentialAddressLine2;

  @JsonProperty("mbs_residentialAddressLine3")
  private String residentialAddressLine3;

  @JsonProperty("mbs_residentialCity")
  private String residentialCity;

  @JsonProperty("mbs_residentialCounty")
  private String residentialCounty;

  @JsonProperty("mbs_residentialCountry")
  private String residentialCountry;

  @JsonProperty("mbs_residentialPostCode")
  private String residentialPostcode;

}
