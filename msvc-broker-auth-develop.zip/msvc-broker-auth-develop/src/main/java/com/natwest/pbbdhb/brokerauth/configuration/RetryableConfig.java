package com.natwest.pbbdhb.brokerauth.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;

/**
 * Configuration required to enable re-try logic
 */
@Configuration
@EnableRetry
public class RetryableConfig {

}
