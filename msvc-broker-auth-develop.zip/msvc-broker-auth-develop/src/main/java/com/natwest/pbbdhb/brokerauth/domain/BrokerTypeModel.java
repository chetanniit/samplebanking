package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Getter;

/**
 * A business domain enum describing all the cases the business logic needs to handle for the type
 * of broker.
 */
@Getter
public enum BrokerTypeModel {
  ADMIN("ADMIN"),
  BROKER("BROKER");

  private final String value;

  BrokerTypeModel(String value) {
    this.value = value;
  }

  public static BrokerTypeModel fromValue(String text) {
    for (BrokerTypeModel brand : BrokerTypeModel.values()) {
      if (brand.value.equalsIgnoreCase(text)) {
        return brand;
      }
    }
    throw new IllegalArgumentException("Unsupported broker type: " + text);
  }
}
