package com.natwest.pbbdhb.brokerauth.client.token;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerauth.client.token.domain.AccessTokenClientResponse;
import com.natwest.pbbdhb.brokerauth.client.token.domain.AccessTokenRetrieveClientRequest;
import com.natwest.pbbdhb.brokerauth.configuration.AccessTokenRestClientConfig;
import com.natwest.pbbdhb.brokerauth.configuration.AccessTokenRestClientConfig.EndpointConfig;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import java.net.URI;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class AccessTokenRestClient implements AccessTokenClient {

  private final AccessTokenRestClientConfig config;
  private final RestTemplate restTemplate;
  private final ObjectMapper mapper;

  @Autowired
  public AccessTokenRestClient(
      AccessTokenRestClientConfig config,
      @Qualifier("accessTokenRestTemplate") RestTemplate restTemplate,
      ObjectMapper mapper) {
    this.config = config;
    this.restTemplate = restTemplate;
    this.mapper = mapper;
  }

  @Override
  public AccessTokenResponseModel retrieveToken(AccessTokenRetrieveRequestModel request) {
    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String.format("retrieveToken: Calling Access Token service to retrieve token for request: %s", request))
        .build()
    );
    try {
      ResponseEntity<AccessTokenClientResponse> responseEntity = restTemplate
          .postForEntity(
              createRetrieveUri(request.getBrand()),
              accessTokenRetrieveRequestEntity(request),
              AccessTokenClientResponse.class);
      log.debug("retrieveToken: Access token successfully retrieved");
      return Optional
          .ofNullable(responseEntity.getBody())
          .map(this::mapToAccessTokenModel)
          .orElseThrow(() ->
              new RemoteRequestFailedException("retrieveToken: Access Token client received an empty payload"));
    } catch (RestClientException ex) {
      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(
              String.format("retrieveToken: Access Token request %s failed with Rest client exception %s", request,
                  ex.getMessage()))
          .build()
      );
      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  private URI createRetrieveUri(Brand brand) {
    log.debug("createRetrieveUri: Creating retrieve uri.");
    return UriComponentsBuilder
        .fromHttpUrl(getEndpointConfigForBrand(brand).getUrl())
        .pathSegment("token.oauth2")
        .build()
        .toUri();
  }

  private EndpointConfig getEndpointConfigForBrand(Brand brand) {
    log.debug("getEndpointConfigForBrand: Getting endpoint config for brand.");
    return config
        .getBrands()
        .get(brand);
  }

  private HttpEntity<MultiValueMap<String, Object>> accessTokenRetrieveRequestEntity(
      AccessTokenRetrieveRequestModel request) {

    // add required headers
    final HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

    // since we are sending data as "x-www-form-urlencoded" we must convert the
    // payload to a multi-value map to allow correct serialisation.
    MultiValueMap<String, Object> payload = new LinkedMultiValueMap<>();
    payload.setAll(
        mapper.convertValue(
            retrieveClientRequestPayload(request),
            new TypeReference<Map<String, Object>>() {
            })
    );

    return new HttpEntity<>(
        payload,
        headers);
  }

  private AccessTokenRetrieveClientRequest retrieveClientRequestPayload(
      AccessTokenRetrieveRequestModel request) {
    log.debug("retrieveClientRequestPayload: Retrieving client request payload.");
    return AccessTokenRetrieveClientRequest
        .builder()
        .clientAssertionType(request.getClientAssertionType())
        .clientAssertion(request.getClientAssertion())
        .clientId(request.getClientId())
        .grantType(request.getGrantType())
        .scope(request.getScope())
        .build();
  }

  private AccessTokenResponseModel mapToAccessTokenModel(AccessTokenClientResponse response) {
    log.debug("mapToAccessTokenModel: Mapping to access token.");
    return AccessTokenResponseModel
        .builder()
        .accessToken(response.getAccessToken())
        .tokenType(response.getTokenType())
        .expiresIn(response.getExpiresIn())
        .build();
  }
}
