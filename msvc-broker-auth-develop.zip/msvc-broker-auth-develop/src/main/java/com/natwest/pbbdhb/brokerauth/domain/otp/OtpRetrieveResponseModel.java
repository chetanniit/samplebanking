package com.natwest.pbbdhb.brokerauth.domain.otp;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data returned by Retrieving an OTP.
 */
@Builder
@Value
public class OtpRetrieveResponseModel {

  /**
   * The OTP ID. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String otpId;
}
