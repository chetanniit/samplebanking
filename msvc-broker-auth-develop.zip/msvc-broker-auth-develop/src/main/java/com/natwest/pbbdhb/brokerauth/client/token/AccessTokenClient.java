package com.natwest.pbbdhb.brokerauth.client.token;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;

public interface AccessTokenClient {

  AccessTokenResponseModel retrieveToken(AccessTokenRetrieveRequestModel request);
  
}
