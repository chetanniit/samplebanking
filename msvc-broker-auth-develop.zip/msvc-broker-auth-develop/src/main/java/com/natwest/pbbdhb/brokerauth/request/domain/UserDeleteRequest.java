package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/* A domain definition of the payload supplied to controller when caller wants to delete a user. */
@Validated
@Value
@Builder
public class UserDeleteRequest {

  @JsonProperty("username")
  @Schema(
      description = "Specifies user's username",
      required = true
  )
  @NonNull
  String username;

  // Lombok doesn't like single member classes, so manually added a constructor
  @JsonCreator
  public UserDeleteRequest(@JsonProperty("username") String username) {
    this.username = username;
  }
}
