package com.natwest.pbbdhb.brokerauth.configuration;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
@Getter
public class ProxyConfig {
    @Value("${proxy.host}")
    private String proxyHost;

    @Value("${proxy.port}")
    private int proxyPort;

    @Value("${msvc.broker.nonProxyHosts}")
    private String msvcBrokerNonProxyHosts;

    public void setProxy() {
        System.setProperty("http.proxyHost", proxyHost);
        System.setProperty("http.proxyPort", String.valueOf(proxyPort));
        System.setProperty("http.nonProxyHosts", msvcBrokerNonProxyHosts);
    }

    @PostConstruct
    public void init() {
        setProxy();
    }
}
