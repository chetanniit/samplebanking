package com.natwest.pbbdhb.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

import java.util.List;

/* A domain definition of the payload supplied to controller when caller wants to send security questions. */
@Validated
@Value
@Builder
public class ChallengeAnswersRequest {
    @JsonProperty("username")
    @Schema(
            description = "Specifies user's username",
            required = true
    )
    @NonNull
    String username;

    @JsonProperty("securityQuestions")
    @Schema(
            description = "Specifies user's security questions",
            required = true
    )
    @NonNull
    List<SecurityQuestion> securityQuestions;


    @Builder
    @Value
    public static class SecurityQuestion {

        @NotBlank
        String question;
        @NotBlank
        String answer;
    }
}
