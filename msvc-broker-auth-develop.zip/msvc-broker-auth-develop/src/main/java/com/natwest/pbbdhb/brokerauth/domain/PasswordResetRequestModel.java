package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to reset a password.
 */
@Builder
@Value
public class PasswordResetRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's otp code to be validated. As this is a required field, {@code @NonNull} has been
   * set.
   */
  @NonNull
  String otpCode;

  /**
   * The user's password. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String password;
}