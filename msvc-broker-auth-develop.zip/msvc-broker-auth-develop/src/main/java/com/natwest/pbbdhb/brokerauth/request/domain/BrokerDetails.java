package com.natwest.pbbdhb.brokerauth.request.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.builder.Diffable;
import org.apache.commons.lang3.builder.ReflectionDiffBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerDetails implements Diffable<BrokerDetails> {

  private BrokerType brokerType;

  private String username;

  private String title;

  private String firstName;

  private String middleName;

  private String lastName;

  private String email;

  private String mobilePhone;

  private String businessPhone;

  private String addressLine1;

  private String addressLine2;

  private String addressLine3;

  private String city;

  private String county;

  private String postcode;

  private String fcaNumber;

  private String tradingName;

  private List<PaymentPath> paymentPaths;

  private String nationality;

  private ResidentialAddress residentialAddress;

  @Override
  public DiffResult<BrokerDetails> diff(BrokerDetails brokerDetails) {
    return new ReflectionDiffBuilder<>(this, brokerDetails, ToStringStyle.SHORT_PREFIX_STYLE)
        .build();
  }
}
