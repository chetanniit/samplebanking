package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/**
 * A domain definition of the payload supplied to controller when caller wants to request a user's security questions.
 */
@Validated
@Value
@Builder
public class SecurityQuestionsFetchRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;
}
