package com.natwest.pbbdhb.brokerauth.request.security;

import com.natwest.pbbdhb.brokerauth.domain.Brand;

/**
 * Provides user claims contained in the request's user principal.
 */
public interface UserClaimsProvider {

  Brand getOperatingBrand();

  String getAccessToken();
}
