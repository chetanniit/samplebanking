package com.natwest.pbbdhb.brokerauth.service.account_management;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.PasswordChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.PasswordResetRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.request.mapper.AccountManagementRequestMapper;
import com.natwest.pbbdhb.brokerauth.request.mapper.ActivationRequestMapper;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Service;

/**
 * A service which provides business logic operations on account management.
 */
@Service
@Slf4j
public class AccountManagementService {

  // OTP states
  private static final String NEW = "New";
  private static final String USED = "Used";

  private final CustomerIdentityManagementClient customerIdentityManagementClient;

  /**
   * Creates a new instance of the AccountManagementService
   *
   * @param customerIdentityManagementClient An instance of the CustomerIdentityManagementClient
   */
  public AccountManagementService(
      CustomerIdentityManagementClient customerIdentityManagementClient) {
    this.customerIdentityManagementClient = customerIdentityManagementClient;
  }

  /**
   * Handles fetching security questions for a user
   *
   * @param accessToken The access token for calling iam services
   * @param request     The security questions request information
   */
  public SecurityQuestionsFetchResponseModel retrieveSecurityQuestions(
      String accessToken,
      SecurityQuestionsFetchRequestModel request) {

    log.debug("retrieveSecurityQuestions: Retrieving security questions for username: {}", request.getUsername());

    GetUserResponseModel customerIdentifier = customerIdentityManagementClient.getUser(
        accessToken,
        request.getUsername());
    log.debug("retrieveSecurityQuestions: Security questions for username: {}, retrieved successfully",
            request.getUsername());
    return customerIdentityManagementClient.getSecurityQuestions(
        accessToken,
        customerIdentifier.getParentId());
  }

  /**
   * Handles fetching security questions for a user
   *
   * @param accessToken The access token for calling iam services
   * @param request     The security questions request information
   */
  public void changeSecurityQuestions(
      String accessToken,
      SecurityQuestionsChangeRequestModel request) {

    log.debug("changeSecurityQuestions: Calling IAM get user for user {}", request.getUsername());

    GetUserResponseModel customerIdentifier = customerIdentityManagementClient.getUser(
        accessToken,
        request.getUsername());
    log.debug("changeSecurityQuestions: Calling IAM get security questions during change of security questions" +
            " for user {}", request.getUsername());

    SecurityQuestionsFetchResponseModel securityQuestions = customerIdentityManagementClient.getSecurityQuestions(
        accessToken,
        customerIdentifier.getParentId());
    log.debug("changeSecurityQuestions: Calling IAM change security questions with randomized payload" +
            " for user {}", request.getUsername());

    SecurityQuestionsRequestModel randomSecurityQuestionsRequestModel = SecurityQuestionsRequestModel.builder()
        .questions(prepareRandomSecurityQuestionsAndAnswers())
        .parentId(customerIdentifier.getParentId())
        .build();
    customerIdentityManagementClient.setSecurityQuestions(
        accessToken,
        randomSecurityQuestionsRequestModel, securityQuestions.getId());

    log.debug("changeSecurityQuestions: Calling IAM change security questions with correct payload for" +
            " user {}", request.getUsername());

    SecurityQuestionsRequestModel securityQuestionsRequestModel = SecurityQuestionsRequestModel.builder()
        .questions(request.getQuestions())
        .parentId(customerIdentifier.getParentId())
        .build();
    customerIdentityManagementClient.setSecurityQuestions(
        accessToken,
        securityQuestionsRequestModel, securityQuestions.getId());
    log.debug("changeSecurityQuestions: Security questions for username: {}, successfully changed", request.getUsername());

  }

  private List<SecurityQuestion> prepareRandomSecurityQuestionsAndAnswers() {
    log.debug("prepareRandomSecurityQuestionsAndAnswers: Preparing random security questions and answers.");
    List<SecurityQuestion> randomSecurityQuestions = new ArrayList<>();
    for (int i = 0; i < 5; i++) {
      randomSecurityQuestions.add(SecurityQuestion.builder()
          .question(RandomStringUtils.random(15, true, false))
          .answer(RandomStringUtils.random(10, true, false))
          .build());
    }
    log.debug("prepareRandomSecurityQuestionsAndAnswers: Random security questions and answers prepared successfully.");
    return randomSecurityQuestions;
  }

  /**
   * Handles validating a user's security answers and returning an OTP code
   *
   * @param accessToken The access token for calling iam services
   * @param request     The security questions validation request information
   */
  public SecurityQuestionsValidationResponseModel validateSecurityAnswers(
      String accessToken,
      SecurityQuestionsValidationRequestModel request) {

    log.debug("validateSecurityAnswers: Validating security answers for username: {}", request.getUsername());
    // check username exists first
    final GetUserResponseModel user = customerIdentityManagementClient.getUser(accessToken,
        request.getUsername());

    // implicit login - we attempt a login to verify if account is unlocked - this could lock the customer's account
    // FIXME - this should be replaced once IAM provide a way to safely verify a user's account status
    // JIRA PRN-1568 raised to cover this work.
    LoginRequestModel loginModel = LoginRequestModel.builder()
        .username(request.getUsername())
        .password(UUID.randomUUID().toString())
        .build();
    try {
      customerIdentityManagementClient.login(accessToken, loginModel);
    } catch (LoginFailedException | PasswordExpiredException ex) {
      // login-failed is expected (if not locked and password not expired)
      // password expired is expected (if password expired, even when wrong password is used!)
      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(
              String.format("validateSecurityAnswers: Account not locked for user: %s", request.getUsername()))
          .build()
      );
    }

    // validate the security questions/answers
    request.getQuestions().forEach((question) -> {
      SecurityQuestionsSingleValidationRequestModel questionsModel = SecurityQuestionsSingleValidationRequestModel.builder()
          .username(request.getUsername())
          .question(SecurityQuestion.builder()
              .question(question.getQuestion())
              .answer(question.getAnswer())
              .build())
          .build();
      customerIdentityManagementClient.validateSecurityQuestion(accessToken, questionsModel);
    });

    // retrieve otp id
    String otpId = customerIdentityManagementClient
        .retrieveOTP(accessToken, request.getUsername()).getOtpId();

    // generate OTP
    OtpGenerateResponseModel otpGenerateDetailsModel = customerIdentityManagementClient
        .generateOTP(accessToken, otpId);

    // update OTP code to status New
    customerIdentityManagementClient
        .updateOTP(accessToken, ActivationRequestMapper.toOtpUpdateRequestModel(otpId, NEW));

    return SecurityQuestionsValidationResponseModel.builder()
        .brokerTypeModel(user.getBrokerType())
        .otpCode(otpGenerateDetailsModel.getActivationCode())
        .build();
  }

  /**
   * Handles verification of an OTP code for a user
   *
   * @param accessToken The access token for calling iam services
   * @param request     The otp validation request information
   */
  public void validateOtp(String accessToken, OtpValidateRequestModel request) {
    log.debug("validateOtp: Validating OTP");
    customerIdentityManagementClient.validateOtp(accessToken, request);
  }

  /**
   * Handles reset of an account password for a user
   *
   * @param accessToken The access token for calling iam services
   * @param request     The password reset request information
   */
  public void passwordReset(String accessToken, PasswordResetRequestModel request) {

    log.debug("passwordReset: Resetting password for username: {}.", request.getUsername());

    customerIdentityManagementClient.validateOtp(
        accessToken,
        AccountManagementRequestMapper.toOtpValidateRequestModel(request));

    GetUserResponseModel customerIdentifier = customerIdentityManagementClient.getUser(
        accessToken,
        request.getUsername());

    customerIdentityManagementClient.setPassword(
        accessToken,
        AccountManagementRequestMapper.toUserSetPasswordRequestModel(
            request,
            customerIdentifier.getId()));

    // set OTP to "used" - prevents OTP being re-used
    String otpId = customerIdentityManagementClient.retrieveOTP(accessToken, request.getUsername())
        .getOtpId();
    customerIdentityManagementClient.updateOTP(
        accessToken,
        ActivationRequestMapper.toOtpUpdateRequestModel(otpId, USED));
    log.debug("passwordReset: Password for username: {} successfully reset.", request.getUsername());
  }

  /**
   * Handles change of an account password for a user
   *
   * @param accessToken The access token for calling iam services
   * @param request     The password change request information
   */
  public void passwordChange(String accessToken, PasswordChangeRequestModel request) {

    log.debug("passwordChange: Changing password for username: {}.", request.getUsername());

    GetUserResponseModel customerIdentifier = customerIdentityManagementClient.getUser(
        accessToken,
        request.getUsername());

    customerIdentityManagementClient.changePassword(
        accessToken,
        AccountManagementRequestMapper.toUserChangePasswordRequestModel(
            request,
            customerIdentifier.getId()));
    log.debug("passwordChange: Password for username: {}, successfully used.", request.getUsername());
  }

  /**
   * Retrieves a broker type
   *
   * @param accessToken The access token for calling iam services
   * @param username    The username of a broker
   */
  public BrokerTypeModel getBrokerType(String accessToken, String username) {
    log.debug("getBrokerType: Getting broker type for username: {}", username);
    GetUserResponseModel responseModel = customerIdentityManagementClient.getUser(accessToken, username);
    log.debug("getBrokerType: Broker type for username: {}, successfully retrieved.", username);
    return responseModel.getBrokerType();
  }
}
