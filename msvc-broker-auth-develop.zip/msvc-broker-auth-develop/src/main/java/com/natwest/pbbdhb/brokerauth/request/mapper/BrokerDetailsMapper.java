package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerUpdateRequest;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.AdminDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.NonSTPFieldCategory;
import com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath;
import com.natwest.pbbdhb.brokerauth.request.domain.ResidentialAddress;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Optional.ofNullable;

@Slf4j
public class BrokerDetailsMapper {

  private final static String NAME_CHANGE = "Name Change";
  private final static String EMAIL_CHANGE = "Email Change";
  private final static String ADDRESS_CHANGE = "Address Change";

  private BrokerDetailsMapper() {
  }

  public static BrokerDetailsResponse toBrokerDetailsResponse(BrokerCoreResponse input) {
    log.debug("toBrokerDetailsResponse: Mapping BrokerCoreResponse to BrokerDetailsResponse...");
    BrokerDetails brokerDetails = BrokerDetails.builder()
        .brokerType(BrokerType.BROKER)
        .username(input.getBroker().getUserName())
        .title(input.getBroker().getTitle())
        .firstName(input.getBroker().getFirstName())
        .lastName(input.getBroker().getLastName())
        .email(input.getBroker().getEmailAddress())
        .mobilePhone(input.getBroker().getMobileNumber())
        .businessPhone(input.getBroker().getBusinessPhone())
        .addressLine1(ofNullable(input.getFirmDetails()).map(FirmDetails::getFirmAddressLine1).orElse(null))
        .addressLine2(ofNullable(input.getFirmDetails()).map(FirmDetails::getFirmAddressLine2).orElse(null))
        .addressLine3(ofNullable(input.getFirmDetails()).map(FirmDetails::getFirmAddressLine3).orElse(null))
        .city(ofNullable(input.getFirmDetails()).map(FirmDetails::getFirmAddressCity).orElse(null))
        .county(ofNullable(input.getFirmDetails()).map(FirmDetails::getFirmAddressCounty).orElse(null))
        .postcode(ofNullable(input.getFirmDetails()).map(FirmDetails::getFirmAddressPostcode).orElse(null))
        .fcaNumber(input.getFirmDetails().getFcaNumber())
        .tradingName(ofNullable(input.getTradingName()).map(TradingName::getName).orElse(null))
        .nationality(input.getBroker().getNationality())
        .residentialAddress(ResidentialAddress.builder()
                .addressLine1(input.getBroker().getResidentialAddressLine1())
                .addressLine2(input.getBroker().getResidentialAddressLine2())
                .addressLine3(input.getBroker().getResidentialAddressLine3())
                .postcode(input.getBroker().getResidentialPostcode())
                .countryOfAddress(input.getBroker().getResidentialCountry())
                .city(input.getBroker().getResidentialCity())
                .county(input.getBroker().getResidentialCounty())
                .build())
        .build();
    if (input.getPaymentPaths() != null) {
      log.debug("toBrokerDetailsResponse: Setting payment paths for broker details...");
      brokerDetails.setPaymentPaths(input.getPaymentPaths().stream()
          .map(paymentPath -> new PaymentPath(paymentPath.getName(),  paymentPath.getPaymentId()))
          .collect(Collectors.toList()));
    }
    log.debug("toBrokerDetailsResponse: BrokerCoreResponse successfully mapped to BrokerDetailsResponse.");
    return BrokerDetailsResponse.builder()
        .brokerDetails(brokerDetails)
        .processingFields(findProcessingFieldCategories(ofNullable(input)
            .map(BrokerCoreResponse::getBrokerUpdateRequest)
            .map(BrokerUpdateRequest::getRequesttype)
            .orElse(StringUtils.EMPTY)))
        .build();
  }

  public static BrokerDetailsResponse toBrokerDetailsResponse(AdminCoreResponse input) {
    log.debug("toBrokerDetailsResponse: Mapping AdminCoreResponse to BrokerDetailsResponse...");
    BrokerDetails brokerDetails = BrokerDetails.builder()
        .brokerType(BrokerType.ADMIN)
        .username(input.getUserName())
        .title(input.getTitle())
        .firstName(input.getFirstName())
        .middleName(input.getMiddleName())
        .lastName(input.getLastName())
        .email(input.getEmailAddress())
        .mobilePhone(input.getMobilePhone())
        .businessPhone(input.getBusinessPhone())
        .fcaNumber(input.getFcaNumber())
        .build();
    log.debug("toBrokerDetailsResponse: AdminCoreResponse successfully mapped to BrokerDetailsResponse.");
    return BrokerDetailsResponse.builder()
        .brokerDetails(brokerDetails)
        .processingFields(Collections.emptyList())
        .build();
  }

  public static BrokerDetails toBrokerDetails(BrokerDetailsChangeRequest brokerDetailsChangeRequest) {
    log.debug("toBrokerDetails: Mapping BrokerDetailsChangeRequest to BrokerDetails...");
    ResidentialAddress residentialAddress = brokerDetailsChangeRequest.getResidentialAddress();
    BrokerDetails.BrokerDetailsBuilder brokerDetailsBuilder = BrokerDetails.builder()
        .brokerType(brokerDetailsChangeRequest.getBrokerType())
        .username(brokerDetailsChangeRequest.getUsername())
        .title(brokerDetailsChangeRequest.getTitle())
        .firstName(brokerDetailsChangeRequest.getFirstName())
        .middleName(brokerDetailsChangeRequest.getMiddleName())
        .lastName(brokerDetailsChangeRequest.getLastName())
        .email(brokerDetailsChangeRequest.getEmail())
        .mobilePhone(brokerDetailsChangeRequest.getMobilePhone())
        .businessPhone(brokerDetailsChangeRequest.getBusinessPhone())
        .addressLine1(brokerDetailsChangeRequest.getAddressLine1())
        .addressLine2(brokerDetailsChangeRequest.getAddressLine2())
        .addressLine3(brokerDetailsChangeRequest.getAddressLine3())
        .city(brokerDetailsChangeRequest.getCity())
        .county(brokerDetailsChangeRequest.getCounty())
        .postcode(brokerDetailsChangeRequest.getPostcode())
        .fcaNumber(brokerDetailsChangeRequest.getFcaNumber())
        .tradingName(brokerDetailsChangeRequest.getTradingName())
        .paymentPaths(brokerDetailsChangeRequest.getPaymentPaths())
        .nationality(brokerDetailsChangeRequest.getNationality());

         if(residentialAddress != null) {
           log.debug("toBrokerDetails: Setting residentialAddress for broker details...");
           brokerDetailsBuilder.residentialAddress(ResidentialAddress.builder()
                   .addressLine1(residentialAddress.getAddressLine1())
                   .addressLine2(residentialAddress.getAddressLine2())
                   .addressLine3(residentialAddress.getAddressLine3())
                   .postcode(residentialAddress.getPostcode())
                   .countryOfAddress(residentialAddress.getCountryOfAddress())
                   .city(residentialAddress.getCity())
                   .county(residentialAddress.getCounty())
                   .build());
         }
         log.debug("toBrokerDetails: BrokerDetailsChangeRequest successfully mapped to BrokerDetails.");
         return brokerDetailsBuilder.build();
  }

  public static BrokerDetailsChangeCrmRequest toBrokerDetailsChangeCrmRequest(BrokerDetails brokerDetails) {
    log.debug("toBrokerDetailsChangeCrmRequest: Mapping BrokerDetails to BrokerDetailsChangeCrmRequest...");
    ResidentialAddress residentialAddress = brokerDetails.getResidentialAddress();
    BrokerDetailsChangeCrmRequest.BrokerDetailsChangeCrmRequestBuilder brokerDetailsChangeCrmRequest = BrokerDetailsChangeCrmRequest.builder()
        .username(brokerDetails.getUsername())
        .title(brokerDetails.getTitle())
        .firstName(brokerDetails.getFirstName())
        .lastName(brokerDetails.getLastName())
        .email(brokerDetails.getEmail())
        .mobilePhone(brokerDetails.getMobilePhone())
        .businessPhone(brokerDetails.getBusinessPhone())
        .addressLine1(brokerDetails.getAddressLine1())
        .addressLine2(brokerDetails.getAddressLine2())
        .addressLine3(brokerDetails.getAddressLine3())
        .city(brokerDetails.getCity())
        .county(brokerDetails.getCounty())
        .postcode(brokerDetails.getPostcode())
        .fcaNumber(brokerDetails.getFcaNumber())
        .tradingName(brokerDetails.getTradingName())
        .nationality(brokerDetails.getNationality())
        .paymentPaths(ofNullable(brokerDetails.getPaymentPaths()).map(paymentPaths -> paymentPaths.stream().map(PaymentPath::getPaymentId).collect(Collectors.toList())).orElse(null));

        if(residentialAddress != null) {
          log.debug("toBrokerDetailsChangeCrmRequest: Setting residentialAddress for brokerDetailsChangeCrmRequest...");
            brokerDetailsChangeCrmRequest.residentialAddressLine1(residentialAddress.getAddressLine1())
                  .residentialAddressLine2(residentialAddress.getAddressLine2())
                  .residentialAddressLine3(residentialAddress.getAddressLine3())
                  .residentialPostcode(residentialAddress.getPostcode())
                  .residentialCity(residentialAddress.getCity())
                  .residentialCountry(residentialAddress.getCountryOfAddress())
                  .residentialCounty(residentialAddress.getCounty());
        }
        log.debug("toBrokerDetailsChangeCrmRequest: BrokerDetails successfully mapped to BrokerDetailsChangeCrmRequest.");
        return brokerDetailsChangeCrmRequest.build();
  }

  public static AdminDetailsChangeCrmRequest toAdminDetailsChangeCrmRequest(BrokerDetails brokerDetails) {
    log.debug("toAdminDetailsChangeCrmRequest: Mapping BrokerDetails to AdminDetailsChangeCrmRequest.");
    return AdminDetailsChangeCrmRequest.builder()
        .username(brokerDetails.getUsername())
        .title(brokerDetails.getTitle())
        .firstName(brokerDetails.getFirstName())
        .middleName(brokerDetails.getMiddleName())
        .lastName(brokerDetails.getLastName())
        .email(brokerDetails.getEmail())
        .mobilePhone(brokerDetails.getMobilePhone())
        .businessPhone(brokerDetails.getBusinessPhone())
        .build();
  }

  private static List<NonSTPFieldCategory> findProcessingFieldCategories(String requestTypeString) {
    log.debug("findProcessingFieldCategories: Checking for processing field categories.");
    List<NonSTPFieldCategory> result = new ArrayList<>();
    if (requestTypeString.contains(NAME_CHANGE)) {
      result.add(NonSTPFieldCategory.NAME);
    }
    if (requestTypeString.contains(EMAIL_CHANGE)) {
      result.add(NonSTPFieldCategory.EMAIL);
    }
    if (requestTypeString.contains(ADDRESS_CHANGE)) {
      result.add(NonSTPFieldCategory.ADDRESS);
    }
    log.debug("findProcessingFieldCategories: Processing field categories successfully found.");
    return result;
  }
}
