package com.natwest.pbbdhb.brokerauth.model.crm.broker;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrokerCoreResponse {
    @JsonProperty("mbs_broker")
    private BrokerDetails broker;
    @JsonProperty("mbs_brokerUpdateRequest")
    private BrokerUpdateRequest brokerUpdateRequest;
    @JsonProperty("mbs_firm")
    private FirmDetails firmDetails;
    @JsonProperty("mbs_tradingName")
    private TradingName tradingName;
    @JsonProperty("mbs_message")
    private String message;
    @JsonProperty("mbs_paymentPaths")
    private List<PaymentPath> paymentPaths;
}
