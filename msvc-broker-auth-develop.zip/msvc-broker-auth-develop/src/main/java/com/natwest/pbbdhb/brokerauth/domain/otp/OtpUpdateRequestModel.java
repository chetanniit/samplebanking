package com.natwest.pbbdhb.brokerauth.domain.otp;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to Update an OTP.
 */
@Builder
@Value
public class OtpUpdateRequestModel {

  /**
   * The OTP ID. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String otpId;

  /**
   * The OTP status to update. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String otpStatus;

  /**
   * The OTP Type to update. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String otpType;
}

