package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UserCreateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UserDeleteRequest;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RegistrationRequestMapper {

  private RegistrationRequestMapper() {
  }

  public static UserCreateRequestModel toUserCreateRequestModel(UserCreateRequest request) {
    log.debug("toUserCreateRequestModel: Mapping UserCreateRequest to UserCreateRequestModel.");
    return UserCreateRequestModel.builder()
        .firstname(request.getFirstname())
        .lastname(request.getLastname())
        .email(request.getEmail())
        .username(request.getUsername())
        .brokerType(BrokerTypeModel.valueOf(request.getBrokerType().toString()))
        .build();
  }

  public static UserDeleteRequestModel toUserDeleteRequestModel(UserDeleteRequest request) {
    log.debug("toUserDeleteRequestModel: Mapping UserDeleteRequest to UserDeleteRequestModel.");
    return UserDeleteRequestModel.builder()
            .username(request.getUsername())
            .build();
  }

  public static ActivationCodeResponse toActivationCodeResponse(@NonNull String activationCode) {
    log.debug("toActivationCodeResponse: Mapping activationCode to ActivationCodeResponse.");
    return ActivationCodeResponse
        .builder()
        .code(activationCode)
        .build();
  }
}
