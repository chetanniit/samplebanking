package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class AccessTokenRetrieveRequestModel {

  @NonNull
  String scope;

  @NonNull
  String clientAssertion;

  @NonNull
  String clientAssertionType;

  @NonNull
  String clientId;

  @NonNull
  String grantType;

  @NonNull
  Brand brand;
}
