package com.natwest.pbbdhb.brokerauth.domain;

import java.util.List;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class SecurityQuestionsFetchResponseModel {

  @NotNull
  String id;

  @NotNull
  List<SecurityQuestion> securityQuestions;

  @Builder
  @Value
  public static class SecurityQuestion {

    @NotBlank
    String id;
    @NotBlank
    String question;
  }
}
