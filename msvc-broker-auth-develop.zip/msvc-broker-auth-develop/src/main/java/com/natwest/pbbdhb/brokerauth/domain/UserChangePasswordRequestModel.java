package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class UserChangePasswordRequestModel {

  @NonNull
  String customerIdentifier;

  @NonNull
  String currentPassword;

  @NonNull
  String newPassword;

}
