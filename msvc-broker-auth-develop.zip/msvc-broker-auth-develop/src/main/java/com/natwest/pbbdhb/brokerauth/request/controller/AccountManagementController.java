package com.natwest.pbbdhb.brokerauth.request.controller;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationResponseModel;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderResponse;
import com.natwest.pbbdhb.brokerauth.request.controller.helpers.AccessTokenRequestHelper;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.OtpValidateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordResetRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorResponse;
import com.natwest.pbbdhb.brokerauth.request.mapper.AccountManagementRequestMapper;
import com.natwest.pbbdhb.brokerauth.service.account_management.AccountManagementService;
import com.natwest.pbbdhb.brokerauth.service.crm.BrokerDetailsService;
import com.natwest.pbbdhb.brokerauth.service.crm.FirmDetailsService;
import com.natwest.pbbdhb.brokerauth.service.crm.UsernameReminderService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.natwest.pbbdhb.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.brokerauth.util.LogMessageType;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/mortgages/v1/msvc-broker-auth/account-management")
@Tag(name = "Account management",
    description = "API for account management")
@Slf4j
@Validated
public class AccountManagementController {

  private final AccessTokenRequestHelper accessTokenRequestHelper;
  private final AccessTokenService accessTokenService;
  private final AccountManagementService accountManagementService;
  private final BrokerDetailsService brokerDetailsService;
  private final FirmDetailsService firmDetailsService;
  private final UsernameReminderService usernameReminderService;
  private final Boolean featureForgotUsernameEnabled;

  @Autowired
  public AccountManagementController(
          AccessTokenRequestHelper accessTokenRequestHelper,
          AccessTokenService accessTokenService,
          AccountManagementService accountManagementService,
          BrokerDetailsService brokerDetailsService,
          FirmDetailsService firmDetailsService, UsernameReminderService usernameReminderService,
          @Value("${feature.forgotten.username.enabled:false}") Boolean featureForgotUsernameEnabled) {
    this.accessTokenRequestHelper = accessTokenRequestHelper;
    this.accessTokenService = accessTokenService;
    this.accountManagementService = accountManagementService;
    this.brokerDetailsService = brokerDetailsService;
    this.firmDetailsService = firmDetailsService;
    this.usernameReminderService = usernameReminderService;
    this.featureForgotUsernameEnabled = featureForgotUsernameEnabled;
  }

  @Operation(
      operationId = "otp-validation",
      summary = "Validate OTP for the user"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "OTP validation for user was successful"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @PostMapping("otp-validation")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void validate(@RequestBody @Valid OtpValidateRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(
            String.format("validate: Validate OTP using otp code: %s, for user: %s", request.getOtpCode(),
                request.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    accountManagementService.validateOtp(
        accessToken,
        AccountManagementRequestMapper.toOtpValidateRequestModel(request));
  }

  @Operation(
      operationId = "challenge-questions",
      summary = "Retrieve memorable questions"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Questions challenged successfully"),
      @ApiResponse(responseCode = "400", description = "Bad request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
  })
  @PostMapping("challenge-questions")
  @ResponseStatus(HttpStatus.OK)
  public RetrieveMemorableQuestionsResponse challengeQuestions(
      @RequestBody @Valid RetrieveMemorableQuestionsRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(
            String.format("RetrieveMemorableQuestionsResponse: Retrieve memorable questions for user: %s", request.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    SecurityQuestionsFetchResponseModel securityQuestions = accountManagementService
        .retrieveSecurityQuestions(accessToken,
            AccountManagementRequestMapper.toSecurityQuestionsFetchRequestModel(request));

    log.info("RetrieveMemorableQuestionsResponse: Memorable questions successfully retrieved for user: {}", request.getUsername());
    return RetrieveMemorableQuestionsResponse.builder()
        .securityQuestions(securityQuestions.getSecurityQuestions().stream()
            .map(SecurityQuestionsFetchResponseModel.SecurityQuestion::getQuestion)
            .collect(Collectors.toList()))
        .build();
  }

  @Operation(
      operationId = "change-questions",
      summary = "Change memorable questions"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Question changed successfully"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
  })
  @PostMapping("change-questions")
  @ResponseStatus(HttpStatus.OK)
  public void changeQuestions(
      @RequestBody @Valid ChangeMemorableQuestionsRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(
            String.format("ChangeMemorableQuestionsRequest: Change memorable questions for user: %s", request.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    accountManagementService
        .changeSecurityQuestions(accessToken,
            AccountManagementRequestMapper.toSecurityQuestionsChangeRequestModel(request));
    log.info("ChangeMemorableQuestionsRequest: Memorable questions successfully changed for user: {}", request.getUsername());
  }

  @Operation(
      operationId = "challenge-answers",
      summary = "Verify Answers and generate OTP"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Login was successful"),
      @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @PostMapping("challenge-answers")
  @ResponseStatus(HttpStatus.OK)
  public ChallengeAnswersResponse challengeAnswers(
      @RequestBody @Valid ChallengeAnswersRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(
            String.format("ChallengeAnswersResponse: Verify Answers and generate OTP for user: %s", request.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    SecurityQuestionsValidationResponseModel securityQuestionsValidationResponseModel = accountManagementService
        .validateSecurityAnswers(accessToken,
            AccountManagementRequestMapper.toSecurityQuestionsValidationRequestModel(request));

    log.info("ChallengeAnswersResponse: Memorable questions successfully verified for user: {}", request.getUsername());
    return ChallengeAnswersResponse.builder()
        .otpCode(securityQuestionsValidationResponseModel.getOtpCode())
        .brokerType(securityQuestionsValidationResponseModel.getBrokerTypeModel().getValue())
        .build();
  }

  @Operation(
      operationId = "password-change",
      summary = "Change password for the account"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "Password change for account was successful"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  @PostMapping("password-change")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void passwordChange(@RequestBody @Valid PasswordChangeRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("passwordChange: Change account password for user: %s",
            request.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    accountManagementService.passwordChange(
        accessToken,
        AccountManagementRequestMapper.toPasswordChangeRequestModel(request));
    log.info("passwordChange: Password successfully changed for user: {}", request.getUsername());
  }

  @Operation(
      operationId = "password-reset",
      summary = "Reset password for the account"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "Password reset for account was successful"),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
      @ApiResponse(responseCode = "401", description = "Unauthorised - OTP validation failed")
  })
  @PostMapping("password-reset")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void passwordReset(@RequestBody @Valid PasswordResetRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("passwordReset: Reset account password using otp code: %s, for" +
                        " user: %s",
            request.getOtpCode(), request.getUsername()))
        .build()
    );

    final String accessToken = getAccessToken();

    accountManagementService.passwordReset(
        accessToken,
        AccountManagementRequestMapper.toPasswordResetRequestModel(request));
    log.info("passwordReset: Password successfully reset for user: {}", request.getUsername());
  }

  @Operation(summary = "Retrieve broker details")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = BrokerDetailsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/broker-details/{username}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  BrokerDetailsResponse getBrokerDetails(@PathVariable("username") String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getBrokerDetails: Retrieve broker details for user: %s",
                username))
        .build()
    );
    log.info("getBrokerDetails: Broker details for: {}, successfully retrieved", username);
    if (BrokerType.ADMIN == getBrokerType(username)) {
      return brokerDetailsService.getAdminDetails(username);
    } else {
      return brokerDetailsService.getBrokerDetails(username);
    }

  }

  @Operation(summary = "Update broker details")
  @ApiResponses(value = {@ApiResponse(responseCode = "204", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = UpdateBrokerDetailsResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @PutMapping(path = "/broker-details")
  @ResponseStatus(HttpStatus.OK)
  UpdateBrokerDetailsResponse updateBrokerDetails(@RequestBody BrokerDetailsChangeRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("updateBrokerDetails: Update broker details for user: %s",
                request.getUsername()))
        .build()
    );

      request.setBrokerType(getBrokerType(request.getUsername()));
      log.info("updateBrokerDetails: Broker details for user: {}, successfully updated", request.getUsername());
      return brokerDetailsService.updateDetails(request);
  }

  @Operation(summary = "Retrieve firm details")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
      "application/json", schema = @Schema(implementation = FirmDetailsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @GetMapping(path = "/firm-details/{fcanumber}", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  FirmDetailsResponse getFirmDetails(@PathVariable("fcanumber") String fcanumber) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("getFirmDetails: Retrieve firm details for fcaNumber: %s",
                fcanumber))
        .build()
    );
    log.info("getFirmDetails: Firm details for fcaNumber: {}, successfully retrieved", fcanumber);
    return firmDetailsService.getFirmDetails(fcanumber);
  }

  @Operation(summary = "Retrieve username reminder")
  @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType =
          "application/json", schema = @Schema(implementation = UsernameReminderResponse.class))),
          @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType =
                  "application/json", schema = @Schema(implementation = ErrorResponse.class))),
          @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType =
                  "application/json", schema = @Schema(implementation = ErrorResponse.class)))})
  @PostMapping(path = "/username-reminder", produces = "application/json")
  @ResponseStatus(HttpStatus.OK)
  UsernameReminderResponse getUsernameReminder(@RequestBody @Valid UsernameReminderRequest usernameReminderRequest) {
    if(!featureForgotUsernameEnabled) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.INCOMING)
              .description(String.format(
                      "getUsernameReminder: Getting username reminder for %s. " +
                              "featureForgotUsernameEnabled=false: returning NOT_FOUND",
                      usernameReminderRequest))
              .build()
      );
      throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("getUsernameReminder: Retrieve username reminder for: %s",
                    usernameReminderRequest))
            .build()
    );

    return usernameReminderService.getUsernameReminder(usernameReminderRequest);

  }

  private String getAccessToken() {
    log.info("getAccessToken: Getting access token.");
    AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel =
        accessTokenRequestHelper.tokenRetrieveRequestModel();

    log.info("getAccessToken: Access token successfully retrieved.");
    return accessTokenService.token(accessTokenRetrieveRequestModel).getAccessToken();
  }

  private BrokerType getBrokerType(String username) {
    log.info("getBrokerType: Getting broker type of username {}.", username);
    final String accessToken = getAccessToken();
    BrokerTypeModel brokerType = accountManagementService.getBrokerType(accessToken, username);
    log.info("getBrokerType: Broker type of username: {}, successfully retrieved", username);
    return BrokerType.fromValue(brokerType.name());
  }
}
