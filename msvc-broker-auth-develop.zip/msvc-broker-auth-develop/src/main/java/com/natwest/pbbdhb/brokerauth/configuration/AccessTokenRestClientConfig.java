package com.natwest.pbbdhb.brokerauth.configuration;

import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.validation.constraint.ContainsAllBrands;
import java.util.EnumMap;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Configuration
@ConfigurationProperties(prefix = "clients.accesstoken.rest")
@Data
@Validated
public class AccessTokenRestClientConfig {

  @NotNull
  @ContainsAllBrands
  private EnumMap<Brand, EndpointConfig> brands;

  @Getter
  @Setter
  public static class EndpointConfig {

    @NotBlank
    private String url;
  }
}
