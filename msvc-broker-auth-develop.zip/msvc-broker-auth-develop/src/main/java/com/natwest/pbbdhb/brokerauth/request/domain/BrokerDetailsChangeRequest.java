package com.natwest.pbbdhb.brokerauth.request.domain;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BrokerDetailsChangeRequest {

  private BrokerType brokerType;

  @NotNull
  private String username;

  private String title;

  private String firstName;

  private String middleName;

  private String lastName;

  private String email;

  private String mobilePhone;

  private String businessPhone;

  private String addressLine1;

  private String addressLine2;

  private String addressLine3;

  private String city;

  private String county;

  private String postcode;

  private String fcaNumber;

  private String tradingName;

  private List<PaymentPath> paymentPaths;

  private String nationality;

  private ResidentialAddress residentialAddress;
}
