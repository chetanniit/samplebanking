package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

import java.util.List;

@Builder
@Value
public class SecurityQuestionsValidationRequestModel {

  @NonNull
  String username;

  @NonNull
  List<SecurityQuestion> questions;

}
