package com.natwest.pbbdhb.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/* A business domain model describing all the data needed to delete a user. */
@Builder
@Value
public class UserDeleteRequestModel {

  /* The user's username. As this is a required field, {@code @NonNull} has been set. */
  @NonNull
  String username;
}
