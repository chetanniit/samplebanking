package com.natwest.pbbdhb.brokerauth.service.token;

import com.natwest.pbbdhb.brokerauth.client.token.AccessTokenClient;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccessTokenService {

  private final AccessTokenClient client;

  @Autowired
  public AccessTokenService(AccessTokenClient client) {
    this.client = client;
  }

  /**
   * Handles creating access tokens in the AccessTokenClient
   *
   * @param request The model describing the request to make to the client
   */
  public AccessTokenResponseModel token(AccessTokenRetrieveRequestModel request) {
    log.debug("token: Retrieving token.");
    return client.retrieveToken(request);
  }
}
