package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class LoginClientContext {

  @Default
  private List<LoginResourcesContext> loginResources = Collections.singletonList(
      LoginResourcesContext.getLoginResourcesBuilder().build());

  public ObjectNode getValidLoginClientResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(loginResources.stream()
            .map(LoginResourcesContext::getLoginResourcesPayload)
            .collect(Collectors.toList())
        );
    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode loginClientResponseReturnsMultipleResources() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(loginResources.stream()
            .map(LoginResourcesContext::getLoginResourcesPayload)
            .collect(Collectors.toList())
        )
        .addAll(loginResources.stream()
            .map(LoginResourcesContext::getLoginResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode loginClientResponseReturnsZeroResources() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode();

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode loginClientResponseReturnsNullResources() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.set("Resources", null);
    return payload;
  }
}
