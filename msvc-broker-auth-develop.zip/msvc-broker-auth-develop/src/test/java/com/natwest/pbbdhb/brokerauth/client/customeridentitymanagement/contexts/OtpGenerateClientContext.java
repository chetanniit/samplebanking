package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientResponse;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class OtpGenerateClientContext {

  @Default
  private String activationCode = "testActivationCode";

  public OtpGenerateClientResponse createOtpGenerateClientResponse() {
    return OtpGenerateClientResponse.builder()
        .activationCode(activationCode)
        .build();
  }

  public ObjectNode getValidOtpGenerateClientResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("generatedPassword", activationCode);
    return payload;
  }
}
