package com.natwest.pbbdhb.brokerauth.request.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.UserContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import com.natwest.pbbdhb.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.brokerauth.service.registration.RegistrationService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * In this test, the full Spring app context is started, but with the service layer mocked.
 */
@ActiveProfiles(profiles = {"int", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class RegistrationControllerTestIT {

  @MockBean
  RegistrationService registrationService;

  @MockBean
  AccessTokenService tokenService;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private MicroserviceIssuer microserviceIssuer;

  @LocalServerPort
  int port;

  @Value("${server.servlet.context-path}")
  private String contextPath;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("mortgages/v1/msvc-broker-auth/users")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header("iam-claimsetjwt", JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Create User Cases")
  class CreateUserCases {

    /**
     * Testing happy path call to controller and verifying service is called.
     */
    @Test
    void shouldCallServiceWithRequestModels() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(UserContext.builder().build().createUserCreateRequest())
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all();

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(registrationService, times(1))
          .createUser(accessTokenResponseModel.getAccessToken(),
              UserContext.builder().build().createUserCreateRequestModel());
    }

    @Test
    void shouldReturnBadRequestIfRequestIsInvalid() {

      givenRequestToController()
          .body(new JSONObject().toString())
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnConflictIfUserAlreadyExists() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      UserContext context = UserContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UserAlreadyExistsException(context.getUsername()))
          .when(registrationService)
          .createUser(any(), any());

      givenRequestToController()
          .body(context.createUserCreateRequest())
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.CONFLICT.value());

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(registrationService, times(1))
          .createUser(accessTokenResponseModel.getAccessToken(),
              UserContext.builder().build().createUserCreateRequestModel());
    }

    @Test
    void shouldReturnServerErrorIfLoginThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      UserContext context = UserContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(registrationService)
          .createUser(any(), any());

      givenRequestToController()
          .body(context.createUserCreateRequest())
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
  }

  @Nested
  @DisplayName("Post Activation Code Cases")
  class PostActivationCodeCases {

    @Test
    void shouldCallServices() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(registrationService.createActivationCode(any(), any())).thenReturn(
          otpContext.createOtpGenerateResponseModel());

      givenRequestToController()
          .body(otpContext.createActivationCodeGenerateRequest())
          .contentType(ContentType.JSON)
          .post("/activation-code")
          .then()
          .log()
          .all();

      Mockito.verify(tokenService, times(1)).token(any());
      Mockito.verify(registrationService).createActivationCode(any(), any());
    }

    @Test
    void shouldReturnActivationCode() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext = OtpContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(registrationService.createActivationCode(any(), any())).thenReturn(
          otpContext.createOtpGenerateResponseModel());

      givenRequestToController()
          .body(otpContext.createActivationCodeGenerateRequest())
          .contentType(ContentType.JSON)
          .post("/activation-code")
          .then()
          .log()
          .all()
          .body("code", equalTo(otpContext.getActivationCode()));
    }

    @Test
    void shouldReturnBadRequestIfRequestIsInvalid() {

      givenRequestToController()
          .body(new JSONObject().toString())
          .contentType(ContentType.JSON)
          .post("/activation-code")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnServerErrorIfActivationCodeThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext = OtpContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(registrationService)
          .createActivationCode(any(), any());

      givenRequestToController()
          .body(otpContext.createActivationCodeGenerateRequest())
          .contentType(ContentType.JSON)
          .post("/activation-code")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
  }

  @Nested
  @DisplayName("Delete User Cases")
  class DeleteUserCases {

    @Test
    void shouldCallServices() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final UserContext context = UserContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(context.createUserDeleteRequest())
          .contentType(ContentType.JSON)
          .delete()
          .then()
          .log()
          .all();

      Mockito.verify(tokenService, times(1)).token(any());
      Mockito.verify(registrationService).deleteUser(any(), any());
    }

    @Test
    void shouldReturnBadRequestIfUserNotFound() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final UserContext context = UserContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);
      doThrow(new UserNotFoundException("User Not Found"))
          .when(registrationService)
          .deleteUser(any(), any());

      givenRequestToController()
          .body(context.createUserDeleteRequest())
          .contentType(ContentType.JSON)
          .delete()
          .then()
          .log()
          .all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));

      Mockito.verify(tokenService, times(1)).token(any());
      Mockito.verify(registrationService).deleteUser(any(), any());
    }
  }

  @Nested
  @DisplayName("Reactivate User Cases")
  class ReactivateUserCases {

    @Test
    void shouldCallServiceWithRequestModels() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
              .createAccessTokenResponseModel();
      final OtpContext otpContext =
              OtpContext.builder()
                      .build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(registrationService.reactivateUser(any(), any())).thenReturn(
              otpContext.createOtpGenerateResponseModel());

      givenRequestToController()
              .body(otpContext.createActivationCodeGenerateRequest())
              .contentType(ContentType.JSON)
              .post("/reactivate")
              .then()
              .log()
              .all();

      Mockito.verify(tokenService, times(1)).token(any());
      Mockito.verify(registrationService).reactivateUser(any(), any());
    }

    @Test
    void shouldReturnActivationCode() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
              .createAccessTokenResponseModel();
      final OtpContext otpContext =
              OtpContext.builder()
                      .build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(registrationService.reactivateUser(any(), any())).thenReturn(
              otpContext.createOtpGenerateResponseModel());

      givenRequestToController()
              .body(otpContext.createActivationCodeGenerateRequest())
              .contentType(ContentType.JSON)
              .post("/reactivate")
              .then()
              .log()
              .all()
              .body("code", equalTo(otpContext.getActivationCode()));
    }

    @Test
    void shouldReturnBadRequestIfRequestIsInvalid() {

      givenRequestToController()
              .body(new JSONObject().toString())
              .contentType(ContentType.JSON)
              .post("/reactivate")
              .then().log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnServerErrorIfActivationCodeThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
              .createAccessTokenResponseModel();
      final OtpContext otpContext = OtpContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
              .when(registrationService)
              .reactivateUser(any(), any());

      givenRequestToController()
              .body(otpContext.createActivationCodeGenerateRequest())
              .contentType(ContentType.JSON)
              .post("/reactivate")
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void shouldThrowUserNotFoundExceptionIfClientThrowsErrorWhenGettingUser() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
              .createAccessTokenResponseModel();
      final OtpContext otpContext = OtpContext.builder().build();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UserNotFoundException("User not found"))
              .when(registrationService)
              .reactivateUser(any(), any());

      givenRequestToController()
              .body(otpContext.createActivationCodeGenerateRequest())
              .contentType(ContentType.JSON)
              .post("/reactivate")
              .then().log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));
    }
  }

}