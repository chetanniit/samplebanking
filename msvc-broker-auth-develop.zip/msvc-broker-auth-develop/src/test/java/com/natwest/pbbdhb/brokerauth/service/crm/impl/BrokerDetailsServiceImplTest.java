package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerUpdateRequest;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.PaymentPath;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.AdminDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.NonSTPFieldCategory;
import com.natwest.pbbdhb.brokerauth.request.domain.RequestedType;
import com.natwest.pbbdhb.brokerauth.request.domain.ResidentialAddress;
import com.natwest.pbbdhb.brokerauth.request.domain.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.service.crm.CrmService;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestClientException;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BrokerDetailsServiceImplTest {

  @InjectMocks
  private BrokerDetailsServiceImpl brokerDetailsService;

  @Mock
  private CrmService crmService;

  @Captor
  private ArgumentCaptor<BrokerDetailsChangeCrmRequest> brokerDetailsChangeRequestArgumentCaptor;

  @Captor
  private ArgumentCaptor<AdminDetailsChangeCrmRequest> adminDetailsChangeRequestArgumentCaptor;

  @Mock
  private OAuthTokenService oauthTokenService;

  private static final String USERNAME = "12345";

  private static final BrokerCoreResponse brokerCoreResponse = BrokerCoreResponse.builder()
      .broker(BrokerDetails.builder()
          .brokerID("brokerId")
          .userName(USERNAME)
          .title("title")
          .brokerName("brokerName")
          .firstName("firstName")
          .lastName("lastName")
          .middleName("middleName")
          .emailAddress("emailAddress")
          .mobileNumber("mobileNumber")
          .businessPhone("businessPhone")
          .brokerPostcode("firmAddressPostcode")
          .nationality("GB")
              .residentialAddressLine1("addressLine1")
              .residentialCity("town")
              .residentialCountry("GB")
              .residentialPostcode("EH11 1PR")
          .build())
      .firmDetails(FirmDetails.builder()
          .firmID("firmID")
          .firmName("firmName")
          .fcaNumber("fcaNumber")
          .principleFCANumber("principleFCANumber")
          .firmAddressLine1("firmAddressLine1")
          .firmAddressLine2("firmAddressLine2")
          .firmAddressLine3("firmAddressLine3")
          .firmAddressPostcode("firmAddressPostcode")
          .firmAddressCity("firmAddressCity")
          .firmAddressCountry("firmAddressCountry")
          .firmAddressCounty("firmAddressCounty")
          .firmAssociateNumber("firmAssociateNumber")
          .statusDate("statusDate")
          .build())
      .brokerUpdateRequest(BrokerUpdateRequest.builder()
          .requesttype("[\"Email Change\"]")
          .status("In progress")
          .build())
      .tradingName(TradingName.builder()
          .name("tradingName")
          .build())
      .paymentPaths(Arrays.asList(
          PaymentPath.builder().paymentId("paymentPathId1").name("paymentPathName1").build(),
          PaymentPath.builder().paymentId("paymentPathId2").name("paymentPathName2").build()
      ))
      .build();

  private static final AdminCoreResponse adminCoreResponse = AdminCoreResponse.builder()
      .brokerAdminID("brokerAdminID")
      .brokerAdminName("brokerAdminName")
      .userName(USERNAME)
      .title("title")
      .firstName("firstName")
      .middleName("middleName")
      .lastName("lastName")
      .firmName("firmName")
      .middleName("middleName")
      .emailAddress("emailAddress")
      .fcaNumber("fcaNumber")
      .principalFCANumber("principalFCANumber")
      .startDate("startDate")
      .mobilePhone("mobilePhone")
      .businessPhone("businessPhone")
      .build();

  @Test
  void shouldGetBrokerDetails() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsResponse response = brokerDetailsService.getBrokerDetails(USERNAME);

    assertNotNull(response);
    assertTrue(response.getProcessingFields().contains(NonSTPFieldCategory.EMAIL));
  }

  @Test
  void shouldGetAdminDetails() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    BrokerDetailsResponse response = brokerDetailsService.getAdminDetails(USERNAME);

    assertNotNull(response);
    assertTrue(response.getProcessingFields().isEmpty());
  }

  @Test
  void shouldUpdateBrokerDetailsNoChanges() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .nationality("GB")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .residentialAddress(ResidentialAddress.builder()
                .addressLine1("addressLine1")
                .city("town")
                .countryOfAddress("GB")
                .postcode("EH11 1PR")
                .build())
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();


    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    assertNotNull(response);
    assertTrue(response.getProcessingFields().contains(NonSTPFieldCategory.EMAIL));
    assertTrue(response.getRequestedTypes().isEmpty());
  }

  @Test
  void shouldUpdateAdminDetailsNoChanges() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();


    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    assertNotNull(response);
    assertTrue(response.getProcessingFields().isEmpty());
    assertTrue(response.getRequestedTypes().contains(RequestedType.STP));
  }

  @Test
  void shouldUpdateBrokerDetailsFirstNameChanged() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("CHANGED")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateBrokerDetails(brokerDetailsChangeRequestArgumentCaptor.capture());

    BrokerDetailsChangeCrmRequest crmRequest = brokerDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertEquals("title", crmRequest.getTitle());
    assertEquals("CHANGED", crmRequest.getFirstName());
    assertEquals("lastName", crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertNull(crmRequest.getMobilePhone());
    assertNull(crmRequest.getBusinessPhone());
    assertNull(crmRequest.getAddressLine1());
    assertNull(crmRequest.getAddressLine2());
    assertNull(crmRequest.getAddressLine3());
    assertNull(crmRequest.getCity());
    assertNull(crmRequest.getCounty());
    assertNull(crmRequest.getPostcode());
    assertNull(crmRequest.getFcaNumber());
    assertNull(crmRequest.getTradingName());
    assertNull(crmRequest.getPaymentPaths());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().containsAll(Arrays.asList(NonSTPFieldCategory.NAME, NonSTPFieldCategory.EMAIL)));
    assertTrue(response.getRequestedTypes().contains(RequestedType.NON_STP));
  }

  @Test
  void shouldUpdateAdminDetailsFirstNameChanged() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("CHANGED")
        .middleName("middleName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobilePhone")
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateAdminDetails(adminDetailsChangeRequestArgumentCaptor.capture());

    AdminDetailsChangeCrmRequest crmRequest = adminDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertEquals("title", crmRequest.getTitle());
    assertEquals("CHANGED", crmRequest.getFirstName());
    assertEquals("middleName", crmRequest.getMiddleName());
    assertEquals("lastName", crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertNull(crmRequest.getMobilePhone());
    assertNull(crmRequest.getBusinessPhone());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().isEmpty());
    assertTrue(response.getRequestedTypes().contains(RequestedType.STP));
  }

  @Test
  void shouldUpdateBrokerDetailsPostcodeChanged() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("CHANGED")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .nationality("GB")
        .residentialAddress(ResidentialAddress.builder()
                .addressLine1("addressLine1")
                .city("town")
                .countryOfAddress("GB")
                .postcode("EH11 1PR")
                .build())
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateBrokerDetails(brokerDetailsChangeRequestArgumentCaptor.capture());

    BrokerDetailsChangeCrmRequest crmRequest = brokerDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertNull(crmRequest.getTitle());
    assertNull(crmRequest.getFirstName());
    assertNull(crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertNull(crmRequest.getMobilePhone());
    assertNull(crmRequest.getBusinessPhone());
    assertEquals("firmAddressLine1", crmRequest.getAddressLine1());
    assertEquals("firmAddressLine2", crmRequest.getAddressLine2());
    assertEquals("firmAddressLine3", crmRequest.getAddressLine3());
    assertEquals("firmAddressCity", crmRequest.getCity());
    assertEquals("firmAddressCounty", crmRequest.getCounty());
    assertEquals("CHANGED", crmRequest.getPostcode());
    assertNull(crmRequest.getFcaNumber());
    assertNull(crmRequest.getTradingName());
    assertNull(crmRequest.getPaymentPaths());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().containsAll(Arrays.asList(NonSTPFieldCategory.ADDRESS, NonSTPFieldCategory.EMAIL)));
    assertTrue(response.getRequestedTypes().contains(RequestedType.NON_STP));
  }

  @Test
  void shouldUpdateBrokerDetailsMobilePhoneChanged() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("CHANGED")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateBrokerDetails(brokerDetailsChangeRequestArgumentCaptor.capture());

    BrokerDetailsChangeCrmRequest crmRequest = brokerDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertNull(crmRequest.getTitle());
    assertNull(crmRequest.getFirstName());
    assertNull(crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertEquals("CHANGED", crmRequest.getMobilePhone());
    assertEquals("businessPhone", crmRequest.getBusinessPhone());
    assertNull(crmRequest.getAddressLine1());
    assertNull(crmRequest.getAddressLine2());
    assertNull(crmRequest.getAddressLine3());
    assertNull(crmRequest.getCity());
    assertNull(crmRequest.getCounty());
    assertNull(crmRequest.getPostcode());
    assertNull(crmRequest.getFcaNumber());
    assertNull(crmRequest.getTradingName());
    assertNull(crmRequest.getPaymentPaths());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().containsAll(Arrays.asList(NonSTPFieldCategory.EMAIL)));
    assertTrue(response.getRequestedTypes().containsAll(Arrays.asList(RequestedType.STP)));
  }

  @Test
  void shouldUpdateAdminDetailsMobilePhoneChanged() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .middleName("middleName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("CHANGED")
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateAdminDetails(adminDetailsChangeRequestArgumentCaptor.capture());

    AdminDetailsChangeCrmRequest crmRequest = adminDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertNull(crmRequest.getTitle());
    assertNull(crmRequest.getFirstName());
    assertNull(crmRequest.getMiddleName());
    assertNull(crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertEquals("CHANGED", crmRequest.getMobilePhone());
    assertEquals("businessPhone", crmRequest.getBusinessPhone());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().isEmpty());
    assertTrue(response.getRequestedTypes().contains(RequestedType.STP));
  }

  @Test
  void shouldUpdateBrokerDetailsMobilePhoneRemoved() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone(null)
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateBrokerDetails(brokerDetailsChangeRequestArgumentCaptor.capture());

    BrokerDetailsChangeCrmRequest crmRequest = brokerDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertNull(crmRequest.getTitle());
    assertNull(crmRequest.getFirstName());
    assertNull(crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertEquals("", crmRequest.getMobilePhone());
    assertEquals("businessPhone", crmRequest.getBusinessPhone());
    assertNull(crmRequest.getAddressLine1());
    assertNull(crmRequest.getAddressLine2());
    assertNull(crmRequest.getAddressLine3());
    assertNull(crmRequest.getCity());
    assertNull(crmRequest.getCounty());
    assertNull(crmRequest.getPostcode());
    assertNull(crmRequest.getFcaNumber());
    assertNull(crmRequest.getTradingName());
    assertNull(crmRequest.getPaymentPaths());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().containsAll(Arrays.asList(NonSTPFieldCategory.EMAIL)));
    assertTrue(response.getRequestedTypes().containsAll(Arrays.asList(RequestedType.STP)));
  }

  @Test
  void shouldUpdateAdminDetailsMobilePhoneRemoved() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .middleName("middleName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone(null)
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateAdminDetails(adminDetailsChangeRequestArgumentCaptor.capture());

    AdminDetailsChangeCrmRequest crmRequest = adminDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertNull(crmRequest.getTitle());
    assertNull(crmRequest.getFirstName());
    assertNull(crmRequest.getMiddleName());
    assertNull(crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertEquals("", crmRequest.getMobilePhone());
    assertEquals("businessPhone", crmRequest.getBusinessPhone());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().isEmpty());
    assertTrue(response.getRequestedTypes().contains(RequestedType.STP));
  }

  @Test
  void shouldUpdateBrokerDetailsFirstNameChangedMobilePhoneRemoved() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("CHANGED")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone(null)
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateBrokerDetails(brokerDetailsChangeRequestArgumentCaptor.capture());

    BrokerDetailsChangeCrmRequest crmRequest = brokerDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertEquals("title", crmRequest.getTitle());
    assertEquals("CHANGED", crmRequest.getFirstName());
    assertEquals("lastName", crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertEquals("", crmRequest.getMobilePhone());
    assertEquals("businessPhone", crmRequest.getBusinessPhone());
    assertNull(crmRequest.getAddressLine1());
    assertNull(crmRequest.getAddressLine2());
    assertNull(crmRequest.getAddressLine3());
    assertNull(crmRequest.getCity());
    assertNull(crmRequest.getCounty());
    assertNull(crmRequest.getPostcode());
    assertNull(crmRequest.getFcaNumber());
    assertNull(crmRequest.getTradingName());
    assertNull(crmRequest.getPaymentPaths());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().containsAll(Arrays.asList(NonSTPFieldCategory.NAME, NonSTPFieldCategory.EMAIL)));
    assertTrue(response.getRequestedTypes().containsAll(Arrays.asList(RequestedType.STP, RequestedType.NON_STP)));
  }

  @Test
  void shouldUpdateAdminDetailsFirstNameChangedMobilePhoneRemoved() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("CHANGED")
        .middleName("middleName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone(null)
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateAdminDetails(adminDetailsChangeRequestArgumentCaptor.capture());

    AdminDetailsChangeCrmRequest crmRequest = adminDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertEquals("title", crmRequest.getTitle());
    assertEquals("CHANGED", crmRequest.getFirstName());
    assertEquals("middleName", crmRequest.getMiddleName());
    assertEquals("lastName", crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertEquals("", crmRequest.getMobilePhone());
    assertEquals("businessPhone", crmRequest.getBusinessPhone());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().isEmpty());
    assertTrue(response.getRequestedTypes().contains(RequestedType.STP));
  }

  @Test
  void shouldUpdateBrokerDetailsSkipEmailWhenProcessing() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("CHANGE")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .nationality("GB")
        .residentialAddress(ResidentialAddress.builder()
                .addressLine1("addressLine1")
                .city("town")
                .countryOfAddress("GB")
                .postcode("EH11 1PR")
                .build())
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    UpdateBrokerDetailsResponse response = brokerDetailsService.updateDetails(request);

    verify(crmService, times(1)).updateBrokerDetails(brokerDetailsChangeRequestArgumentCaptor.capture());

    BrokerDetailsChangeCrmRequest crmRequest = brokerDetailsChangeRequestArgumentCaptor.getValue();
    assertEquals(USERNAME, crmRequest.getUsername());
    assertNull(crmRequest.getTitle());
    assertNull(crmRequest.getFirstName());
    assertNull(crmRequest.getLastName());
    assertNull(crmRequest.getEmail());
    assertNull(crmRequest.getMobilePhone());
    assertNull(crmRequest.getBusinessPhone());
    assertNull(crmRequest.getAddressLine1());
    assertNull(crmRequest.getAddressLine2());
    assertNull(crmRequest.getAddressLine3());
    assertNull(crmRequest.getCity());
    assertNull(crmRequest.getCounty());
    assertNull(crmRequest.getPostcode());
    assertNull(crmRequest.getFcaNumber());
    assertNull(crmRequest.getTradingName());
    assertNull(crmRequest.getPaymentPaths());

    assertNotNull(response);
    assertTrue(response.getProcessingFields().contains(NonSTPFieldCategory.EMAIL));
    assertTrue(response.getRequestedTypes().isEmpty());
  }

  @Test
  void shouldHandleExceptionWhenGetBrokerDetails() {
    doThrow(new RestClientException("CRM client error"))
        .when(crmService).getBrokerDetails(USERNAME);

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> brokerDetailsService.getBrokerDetails(USERNAME));
    assertEquals("getBrokerDetails: Request failed for broker username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenGetAdminDetails() {
    doThrow(new RestClientException("CRM client error"))
        .when(crmService).getAdminDetails(USERNAME);

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> brokerDetailsService.getAdminDetails(USERNAME));
    assertEquals("getAdminDetails: Request failed for admin username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUpdateBrokerDetailsFailedGetBroker() {
    final BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    doThrow(new RestClientException("CRM client error"))
        .when(crmService).getBrokerDetails(USERNAME);

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> brokerDetailsService.updateDetails(request));
    assertEquals("updateDetails: Request failed for username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUpdateBrokerDetailsFailedUpdateBroker() {
    when(crmService.getBrokerDetails(USERNAME)).thenReturn(brokerCoreResponse);

    final BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("firmAddressPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList(
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId1")
                .name("paymentPathName1")
                .build(),
            com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                .paymentId("paymentPathId2")
                .name("paymentPathName2")
                .build()))
        .build();

    doThrow(new RestClientException("CRM client error"))
        .when(crmService).updateBrokerDetails(any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> brokerDetailsService.updateDetails(request));
    assertEquals("updateDetails: Request failed for username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUpdateAdminDetailsFailedGetAdmin() {
    final BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();

    doThrow(new RestClientException("CRM client error"))
        .when(crmService).getAdminDetails(USERNAME);

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> brokerDetailsService.updateDetails(request));
    assertEquals("updateDetails: Request failed for username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUpdateAdminDetailsFailedUpdateAdmin() {
    when(crmService.getAdminDetails(USERNAME)).thenReturn(adminCoreResponse);

    final BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .fcaNumber("fcaNumber")
        .build();

    doThrow(new RestClientException("CRM client error"))
        .when(crmService).updateAdminDetails(any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> brokerDetailsService.updateDetails(request));
    assertEquals("updateDetails: Request failed for username 12345", exception.getMessage());
  }

}
