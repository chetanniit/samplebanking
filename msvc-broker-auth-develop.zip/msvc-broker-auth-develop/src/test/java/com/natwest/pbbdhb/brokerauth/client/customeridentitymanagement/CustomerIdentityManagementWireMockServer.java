package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.http.Body;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.util.UriComponentsBuilder;

public class CustomerIdentityManagementWireMockServer {


  private static final String USER_PATH = "/scim/v2/napoli/v1/customer";
  private static final String DELETE_USER_PATH = "/scim/v2/napoli/v1/customeridentifier";
  private static final String CUSTOMER_PATH = "/scim/v2/napoli/v1/customer";
  private static final String CUSTOMER_IDENTIFIER_PATH = "/scim/v2/napoli/v1/customeridentifier";
  private static final String LOGIN_PATH = "/scim/v2/napoli/v1/login";
  private static final String OTP_PATH = "/scim/v2/napoli/v1/otp";
  private static final String OTP_VALIDATE_PATH = "/scim/v2/napoli/v1/otpvalidation";
  private static final String SECURITY_QUESTIONS_PATH = "/scim/v2/napoli/v1/customerchallenge";
  private static final String SECURITY_QUESTIONS_VALIDATE_PATH = "/scim/v2/napoli/v1/challengevalidation";
  private static final String SET_PASSWORD_PATH = "/scim/v2/napoli/v1/customeridentifier/7d2b3b4a-421c-4726-bc49-19645dbe047c/password";
  private static final String ACTIVATE_USER_PATH = "/scim/v2/napoli/v1/customeridentifier/7d2b3b4a-421c-4726-bc49-19645dbe047c";

  private static String filterByUsernamePath(String path, String username) {
    return UriComponentsBuilder
        .fromPath(path)
        .queryParam("filter", "personaidentifier eq \"CPB-NAPL-NWB@" + username + "\"")
        .build()
        .toUri()
        .toString();
  }

  private static String filterByParentIdPath(String path, String parentId) {
    return UriComponentsBuilder
        .fromPath(path)
        .queryParam("filter", "parentidentity eq \"" + parentId + "\"")
        .build()
        .toUri()
        .toString();
  }

  private static String createUserPath() {
    return UriComponentsBuilder
        .fromPath(USER_PATH)
        .build()
        .toUri()
        .toString();
  }

  private static String deleteUserPath(String customerId) {
    return UriComponentsBuilder
        .fromPath(DELETE_USER_PATH)
        .pathSegment("{customerId}")
        .build(customerId)
        .toString();
  }

  private static String initialiseOtpPath() {
    return UriComponentsBuilder
        .fromPath(OTP_PATH)
        .build()
        .toUri()
        .toString();
  }

  private static String securityQuestionsPath() {
    return UriComponentsBuilder
        .fromPath(SECURITY_QUESTIONS_PATH)
        .build()
        .toUri()
        .toString();
  }

  private static String deleteSecurityQuestionsPath(String questionsId) {
    return UriComponentsBuilder
        .fromPath(SECURITY_QUESTIONS_PATH)
        .pathSegment("{questionsId}")
        .build(questionsId)
        .toString();
  }

  private static String validateOtpPath() {
    return UriComponentsBuilder
        .fromPath(OTP_VALIDATE_PATH)
        .build()
        .toUri()
        .toString();
  }

  private static String deleteOtpPath(String otpId) {
    return UriComponentsBuilder
        .fromPath(OTP_PATH)
        .pathSegment("{otpId}")
        .build(otpId)
        .toString();
  }

  private static String activateUserPath() {
    return UriComponentsBuilder
        .fromPath(ACTIVATE_USER_PATH)
        .build()
        .toUri()
        .toString();
  }

  private static String setPassWordPath() {
    return UriComponentsBuilder
        .fromPath(SET_PASSWORD_PATH)
        .build()
        .toUri()
        .toString();
  }

  private static String generateOtpPath(String otpId) {
    return UriComponentsBuilder
        .fromPath(OTP_PATH)
        .pathSegment("{otpId}", "password")
        .build(otpId)
        .toString();
  }

  private static String updateOtpPath(String otpId) {
    return UriComponentsBuilder
        .fromPath(OTP_PATH)
        .pathSegment("{otpId}")
        .build(otpId)
        .toString();
  }

  static ResponseDefinitionBuilder jsonResponse(HttpStatus status, ObjectNode body) throws IOException {
    return WireMock.status(status.value())
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        .withBody(body.toString());
  }

  static ResponseDefinitionBuilder jsonResponse(HttpStatus status) {
    return WireMock.status(status.value())
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json");
  }

  private static MappingBuilder mappingForCreateUserRequest(ResponseDefinitionBuilder response) {
    return WireMock.post(WireMock.urlPathEqualTo(createUserPath())).willReturn(response);
  }

  private static MappingBuilder mappingForDeleteUserRequest(String customerId,
      ResponseDefinitionBuilder response) {
    return WireMock.delete(WireMock.urlPathEqualTo(deleteUserPath(customerId)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForInitiliseOtpRequest(ResponseDefinitionBuilder response) {
    return WireMock.post(WireMock.urlPathEqualTo(initialiseOtpPath())).willReturn(response);
  }

  private static MappingBuilder mappingForSetPasswordRequest(ResponseDefinitionBuilder response) {
    return WireMock.put(WireMock.urlPathEqualTo(setPassWordPath())).willReturn(response);
  }

  private static MappingBuilder mappingForActivateUserRequest(ResponseDefinitionBuilder response) {
    return WireMock.patch(WireMock.urlPathEqualTo(activateUserPath())).willReturn(response);
  }

  private static MappingBuilder mappingForSetSecurityQuestionsRequest(
      ResponseDefinitionBuilder response) {
    return WireMock.post(WireMock.urlPathEqualTo(securityQuestionsPath())).willReturn(response);
  }

  private static MappingBuilder mappingForGetCustomerRequest(String username,
      ResponseDefinitionBuilder response) {
    return WireMock
        .get(WireMock.urlEqualTo(filterByUsernamePath(CUSTOMER_PATH, username)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForGetSecurityQuestionsRequest(String parentId,
      ResponseDefinitionBuilder response) {
    return WireMock
        .get(WireMock.urlEqualTo(filterByParentIdPath(SECURITY_QUESTIONS_PATH, parentId)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForDeleteSecurityQuestionsRequest(String questionsId,
      ResponseDefinitionBuilder response) {
    return WireMock
        .delete(WireMock.urlEqualTo(deleteSecurityQuestionsPath(questionsId)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForValidateSecurityQuestionsRequest(String username,
      String validationHeader, ResponseDefinitionBuilder response) {
    return WireMock
        .get(WireMock.urlEqualTo(filterByUsernamePath(SECURITY_QUESTIONS_VALIDATE_PATH, username)))
        .withHeader("Validation",
            WireMock.matching("Basic " + Base64.encodeBase64String(
                validationHeader.getBytes(StandardCharsets.UTF_8))))
        .willReturn(response);
  }

  private static MappingBuilder mappingForGetUserRequest(String username,
      ResponseDefinitionBuilder response) {
    return WireMock
        .get(WireMock.urlEqualTo(filterByUsernamePath(CUSTOMER_IDENTIFIER_PATH, username)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForLoginRequest(String username,
      ResponseDefinitionBuilder response) {
    return WireMock
        .get(WireMock.urlEqualTo(filterByUsernamePath(LOGIN_PATH, username)))
        // Base 64 encoded: CPB-NAPL-NWB@TestUsername:TestPassword
        .withHeader("Validation",
            WireMock.matching("Basic Q1BCLU5BUEwtTldCQFRlc3RVc2VybmFtZTpUZXN0UGFzc3dvcmQ="))
        .willReturn(response);
  }

  private static MappingBuilder mappingForRetrieveOtpRequest(String username,
      ResponseDefinitionBuilder response) {
    return WireMock
        .get(WireMock.urlEqualTo(filterByUsernamePath(OTP_PATH, username)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForGenerateOtpRequest(String otpId,
      ResponseDefinitionBuilder response) {
    return WireMock
        .put(WireMock.urlEqualTo(generateOtpPath(otpId)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForUpdateOtpRequest(String otpId,
      ResponseDefinitionBuilder response) {
    return WireMock
        .patch(WireMock.urlEqualTo(updateOtpPath(otpId)))
        .willReturn(response);
  }

  private static MappingBuilder mappingForValidateOtpRequest(ResponseDefinitionBuilder response) {
    return WireMock.get(WireMock.urlPathEqualTo(validateOtpPath())).willReturn(response);
  }

  private static MappingBuilder mappingForDeleteOtpRequest(String otpId,
      ResponseDefinitionBuilder response) {
    return WireMock.delete(WireMock.urlPathEqualTo(deleteOtpPath(otpId))).willReturn(response);
  }

  /**
   * Define a request-response mapping for a create user request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingCreateUserRequest(ResponseDefinitionBuilder response) {
    return mappingForCreateUserRequest(response);
  }

  public static MappingBuilder mappingDeleteUserRequest(String customerId,
      ResponseDefinitionBuilder response) {
    return mappingForDeleteUserRequest(customerId, response);
  }

  /**
   * Define a request-response mapping for a Initialise otp request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingInitiliseOtpRequest(ResponseDefinitionBuilder response) {
    return mappingForInitiliseOtpRequest(response);
  }

  /**
   * Define a request-response mapping for a set password request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingSetPasswordRequest(ResponseDefinitionBuilder response) {
    return mappingForSetPasswordRequest(response);
  }

  /**
   * Define a request-response mapping for a activate user request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingActivateUserRequest(ResponseDefinitionBuilder response) {
    return mappingForActivateUserRequest(response);
  }

  /**
   * Define a request-response mapping for a set security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingSetSecurityQuestionsRequest(
      ResponseDefinitionBuilder response) {
    return mappingForSetSecurityQuestionsRequest(response);
  }

  /**
   * Define a request-response mapping for a get security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingGetSecurityQuestionsRequest(String parentId,
      ResponseDefinitionBuilder response) {
    return mappingForGetSecurityQuestionsRequest(parentId, response);
  }

  /**
   * Define a request-response mapping for a get security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingDeleteSecurityQuestionsRequest(String questionsId,
      ResponseDefinitionBuilder response) {
    return mappingForDeleteSecurityQuestionsRequest(questionsId, response);
  }

  /**
   * Define a request-response mapping for a validate security question request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingValidateSecurityQuestionRequest(String username,
      String validationHeader, ResponseDefinitionBuilder response) {
    return mappingForValidateSecurityQuestionsRequest(username, validationHeader, response);
  }

  /**
   * Define a request-response mapping for a get customer request.
   *
   * @param username The user's username.
   * @param response Payload to be returned.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingGetCustomerRequest(String username, ObjectNode response) throws IOException {
    return mappingForGetCustomerRequest(username, jsonResponse(HttpStatus.OK, response));
  }

  /**
   * Define a request-response mapping for a get user request.
   *
   * @param username The user's username.
   * @param response Payload to be returned.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingGetUserRequest(String username, ObjectNode response) throws IOException {
    return mappingForGetUserRequest(username, jsonResponse(HttpStatus.OK, response));
  }

  /**
   * Define a request-response mapping for a login request.
   *
   * @param username The user's username.
   * @param response Payload to be returned.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingLoginRequest(String username,
      ObjectNode response) throws IOException {
    return mappingForLoginRequest(username, jsonResponse(HttpStatus.OK, response));
  }

  /**
   * Define a request-response mapping for a retrieve otp request.
   *
   * @param username The user's username.
   * @param response Payload to be returned.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingRetrieveOtpRequest(String username,
      ObjectNode response) throws IOException {
    return mappingForRetrieveOtpRequest(username, jsonResponse(HttpStatus.OK, response));
  }

  /**
   * Define a request-response mapping for a generate otp request.
   *
   * @param otpId    The ID of the otp.
   * @param response Payload to be returned.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingGenerateOtpRequest(String otpId,
      ObjectNode response) throws IOException {
    return mappingForGenerateOtpRequest(otpId, jsonResponse(HttpStatus.OK, response));
  }

  /**
   * Define a request-response mapping for an update otp request.
   *
   * @param otpId The ID of the otp.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingUpdateOtpRequest(String otpId) {
    return mappingForUpdateOtpRequest(otpId, jsonResponse(HttpStatus.OK));
  }

  /**
   * Define a request-response mapping for a validate otp request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingValidateOtpRequest(ResponseDefinitionBuilder response) {
    return mappingForValidateOtpRequest(response);
  }

  /**
   * Define a request-response mapping for a delete otp request.
   *
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingDeleteOtpRequest(String otpId,
      ResponseDefinitionBuilder response) {
    return mappingForDeleteOtpRequest(otpId, response);
  }

  /**
   * Define a request-response mapping for non-successful get customer request.
   *
   * @param otpId      The otpId
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingDeleteOtpRequest(String otpId, HttpStatus httpStatus) {
    return mappingForDeleteOtpRequest(otpId, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a request-response mapping for non-successful get customer request.
   *
   * @param username   The user's username.
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingGetCustomerRequest(String username, HttpStatus httpStatus) {
    return mappingForGetCustomerRequest(username, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a request-response mapping for non-successful get user request.
   *
   * @param username   The user's username.
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingGetUserRequest(String username, HttpStatus httpStatus) {
    return mappingForGetUserRequest(username, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a request-response mapping for non-successful login request.
   *
   * @param username   The user's username.
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingLoginRequest(String username, HttpStatus httpStatus) {
    return mappingForLoginRequest(username, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a request-response mapping for non-successful retrieve otp request.
   *
   * @param username   The user's username.
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingRetrieveOtpRequest(String username, HttpStatus httpStatus) {
    return mappingForRetrieveOtpRequest(username, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a request-response mapping for non-successful generate otp request.
   *
   * @param otpId      The ID of the otp.
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingGenerateOtpRequest(String otpId, HttpStatus httpStatus) {
    return mappingForGenerateOtpRequest(otpId, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a request-response mapping for non-successful update otp request.
   *
   * @param otpId      The ID of the otp.
   * @param httpStatus Non-success response status to return.
   * @return Mapping to be passed to {@code WireMock.stubFor()}
   */
  public static MappingBuilder mappingUpdateOtpRequest(String otpId, HttpStatus httpStatus) {
    return mappingForUpdateOtpRequest(otpId, WireMock.status(httpStatus.value()));
  }

  /**
   * Define a verifier request pattern for a create user request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForCreateUserRequest(String body) {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(createUserPath()))
        .withRequestBody(WireMock.equalToJson(body));
  }

  /**
   * Define a verifier request pattern for a delete user request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForDeleteUserRequest(String body, String customerId) {
    return WireMock.deleteRequestedFor(WireMock.urlPathMatching(deleteUserPath(customerId)))
        .withRequestBody(WireMock.equalToJson(body));
  }

  /**
   * Define a verifier request pattern for a Initialise otp request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForInitialiseOtpRequest(String body) {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(initialiseOtpPath()))
        .withRequestBody(WireMock.equalToJson(body));
  }

  /**
   * Define a verifier request pattern for a set password request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForSetPasswordRequest(String body) {
    return WireMock.putRequestedFor(WireMock.urlPathMatching(setPassWordPath()))
        .withRequestBody(WireMock.equalToJson(body));
  }

  /**
   * Define a verifier request pattern for a activate user request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForActivateUserRequest(String body) {
    return WireMock.patchRequestedFor(WireMock.urlPathMatching(activateUserPath()))
        .withRequestBody(WireMock.equalToJson(body));
  }

  /**
   * Define a verifier request pattern for a set security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForSetSecurityQuestionsRequest(String body) {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(securityQuestionsPath()))
        .withRequestBody(WireMock.equalToJson(body));
  }

  /**
   * Define a verifier request pattern for a get security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForGetSecurityQuestionsRequest(String parentId) {
    return WireMock.getRequestedFor(
        WireMock.urlEqualTo(filterByParentIdPath(SECURITY_QUESTIONS_PATH, parentId)));
  }

  /**
   * Define a verifier request pattern for a delete security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForDeleteSecurityQuestionsRequest(String questionsId) {
    return WireMock.deleteRequestedFor(
        WireMock.urlEqualTo(deleteSecurityQuestionsPath(questionsId)));
  }

  /**
   * Define a verifier request pattern for a validate security questions request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForValidateSecurityQuestionsRequest(String username) {
    return WireMock.getRequestedFor(
        WireMock.urlEqualTo(filterByUsernamePath(SECURITY_QUESTIONS_VALIDATE_PATH, username)));
  }

  /**
   * Define a verifier request pattern for a get customer request.
   *
   * @param username The user's username.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForGetCustomerRequest(String username) {
    return WireMock.getRequestedFor(
        WireMock.urlEqualTo(filterByUsernamePath(CUSTOMER_PATH, username)));
  }

  /**
   * Define a verifier request pattern for a get user request.
   *
   * @param username The user's username.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForGetUserRequest(String username) {
    return WireMock.getRequestedFor(
        WireMock.urlEqualTo(filterByUsernamePath(CUSTOMER_IDENTIFIER_PATH, username)));
  }

  /**
   * Define a verifier request pattern for a login request.
   *
   * @param username The user's username.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForLoginRequest(String username) {
    return WireMock.getRequestedFor(
        WireMock.urlEqualTo(filterByUsernamePath(LOGIN_PATH, username)));
  }

  /**
   * Define a verifier request pattern for a retrieve otp request.
   *
   * @param username The user's username.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForRetrieveOtpRequest(String username) {
    return WireMock.getRequestedFor(
        WireMock.urlEqualTo(filterByUsernamePath(OTP_PATH, username)));
  }

  /**
   * Define a verifier request pattern for a generate otp request.
   *
   * @param otpId The ID of the otp.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForGenerateOtpRequest(String otpId) {
    return WireMock.putRequestedFor(
        WireMock.urlEqualTo(generateOtpPath(otpId)));
  }

  /**
   * Define a verifier request pattern for a delete otp request.
   *
   * @param otpId The ID of the otp.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForDeleteOtpRequest(String otpId) {
    return WireMock.deleteRequestedFor(
        WireMock.urlPathEqualTo(deleteOtpPath(otpId)));
  }

  /**
   * Define a verifier request pattern for a update otp request.
   *
   * @param otpId The ID of the otp.
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForUpdateOtpRequest(String otpId) {
    return WireMock.patchRequestedFor(
        WireMock.urlEqualTo(updateOtpPath(otpId)));
  }

  /**
   * Define a verifier request pattern for a validate otp request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForValidateOtpRequest() {
    return WireMock.getRequestedFor(WireMock.urlPathMatching(validateOtpPath()));
  }
}
