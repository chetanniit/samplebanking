package com.natwest.pbbdhb.brokerauth.request.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.natwest.pbbdhb.brokerauth.contexts.LoginContext;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.LoginRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Testing the Login business domain model mapping.
 */
class LoginRequestMapperTest {

  @Nested
  @DisplayName("toLoginRequestModel Cases")
  class ToLoginRequestModelCases {

    /**
     * Testing happy path mapping.
     */
    @Test
    void toLoginRequestModel() {
      LoginRequest requestModel = LoginContext.builder().build().createLoginRequest();

      LoginRequestModel domainModel = LoginRequestMapper.toLoginRequestModel(requestModel);

      assertEquals(domainModel.getUsername(), requestModel.getUsername());
      assertEquals(domainModel.getPassword(), requestModel.getPassword());
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          LoginRequestMapper.toLoginRequestModel(null)
      );
    }
  }
}