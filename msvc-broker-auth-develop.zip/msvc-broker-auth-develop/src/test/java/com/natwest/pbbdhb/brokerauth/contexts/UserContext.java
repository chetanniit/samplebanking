package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserCreateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserDeleteClientRequest;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.UserCreateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UserDeleteRequest;
import java.util.Collections;
import java.util.List;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class UserContext {

  @Default
  private String firstName = "Test";

  @Default
  private String lastName = "Account";

  @Default
  private String email = "test@email.com";

  @Default
  private String username = "TestUsername";

  @Default
  private BrokerTypeModel brokerTypeModel = BrokerTypeModel.BROKER;

  @Default
  private BrokerType brokerType = BrokerType.BROKER;

  @Default
  private Boolean accountDisabled = true;

  @Default
  private String idType = "UUID";

  @Default
  private String status = "NEW";

  @Default
  private List<String> schemas = Collections.singletonList("urn:generic:schemas:customer:1.0");

  @Default
  private Brand brand = Brand.NWB;

  public UserCreateRequestModel createUserCreateRequestModel() {
    return UserCreateRequestModel.builder()
        .firstname(firstName)
        .lastname(lastName)
        .email(email)
        .username(username)
        .brokerType(brokerTypeModel)
        .build();
  }

  public UserCreateClientRequest createUserCreateClientRequest() {
    return UserCreateClientRequest.builder()
        .username("CPB-NAPL-NWB@" + username)
        .brokerType(brokerTypeModel)
        .accountDisabled(accountDisabled)
        .idType(idType)
        .status(status)
        .schemas(schemas)
        .build();
  }

  public UserCreateRequest createUserCreateRequest() {
    return UserCreateRequest.builder()
        .firstname(firstName)
        .lastname(lastName)
        .email(email)
        .username(username)
        .brokerType(brokerType)
        .build();
  }

  public UserDeleteRequestModel createUserDeleteRequestModel() {
    return UserDeleteRequestModel.builder()
        .username(username)
        .build();
  }

  public UserDeleteClientRequest createUserDeleteClientRequest() {
    return UserDeleteClientRequest.builder()
        .username("CPB-NAPL-NWB@" + username)
        .build();
  }

  public UserDeleteRequest createUserDeleteRequest() {
    return UserDeleteRequest.builder()
        .username(username)
        .build();
  }

}
