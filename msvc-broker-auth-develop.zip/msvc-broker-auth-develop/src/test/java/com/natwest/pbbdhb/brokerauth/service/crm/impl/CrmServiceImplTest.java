package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.admin.AdminAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.broker.BrokerAssociationsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions.BrokerPermissionsRequest;
import com.natwest.pbbdhb.brokerauth.model.crm.associations.permissions.BrokerPermissionsResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerUpdateRequest;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.PaymentPath;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.AdminDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestClientException;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CrmServiceImplTest {

  @InjectMocks
  private CrmServiceImpl crmService;

  @Mock
  private CRMClient crmClient;

  @Captor
  private ArgumentCaptor<BrokerPermissionsRequest> brokerPermissionsRequestArgumentCaptor;

  private static final String USERNAME = "12345";
  private static final String BROKER_DETAILS_ENDPOINT = "http://localhost/mbs_ReadBrokerCore(mbs_userName='%s')";
  private static final String ADMIN_DETAILS_ENDPOINT = "http://localhost/mbs_ReadBrokerAdminCore(mbs_userName='%s')";
  private static final String BROKER_UPDATE_DETAILS_ENDPOINT = "http://localhost/mbs_UpdateBrokerCore";
  private static final String ADMIN_UPDATE_DETAILS_ENDPOINT = "http://localhost/mbs_UpdateAdminCore";
  private static final String BROKER_ASSOCIATIONS_ENDPOINT = "http://localhost/mbs_ReadBrokerAssociation(mbs_userName='%s')";
  private static final String BROKER_UNASSOCIATIONS_ENDPOINT = "http://localhost/mbs_ReadBrokerUnassociated(mbs_userName='%s')";
  private static final String ADMIN_ASSOCIATIONS_ENDPOINT = "http://localhost/mbs_ReadBrokerAdminAssociation(mbs_userName='%s')";
  private static final String UPDATE_ASSOCIATIONS_ENDPOINT = "http://localhost/mbs_UpdateBrokerPermission";

  private static final BrokerCoreResponse brokerCoreResponse = BrokerCoreResponse.builder()
      .broker(BrokerDetails.builder()
          .brokerID("brokerId")
          .userName(USERNAME)
          .title("title")
          .brokerName("brokerName")
          .firstName("firstName")
          .lastName("lastName")
          .middleName("middleName")
          .emailAddress("emailAddress")
          .mobileNumber("mobileNumber")
          .businessPhone("businessPhone")
          .brokerPostcode("brokerPostcode")
          .build())
      .firmDetails(FirmDetails.builder()
          .firmID("firmID")
          .firmName("firmName")
          .fcaNumber("fcaNumber")
          .principleFCANumber("principleFCANumber")
          .firmAddressLine1("firmAddressLine1")
          .firmAddressLine2("firmAddressLine2")
          .firmAddressLine3("firmAddressLine3")
          .firmAddressPostcode("firmAddressPostcode")
          .firmAddressCity("firmAddressCity")
          .firmAddressCountry("firmAddressCountry")
          .firmAddressCounty("firmAddressCounty")
          .firmAssociateNumber("firmAssociateNumber")
          .statusDate("statusDate")
          .build())
      .brokerUpdateRequest(BrokerUpdateRequest.builder()
          .requesttype("[\"Email Change\"]")
          .status("In progress")
          .build())
      .tradingName(TradingName.builder()
          .name("tradingName")
          .build())
      .paymentPaths(Arrays.asList(
          PaymentPath.builder().paymentId("paymentPathId1").name("paymentPathName1").build(),
          PaymentPath.builder().paymentId("paymentPathId2").name("paymentPathName2").build()
      ))
      .build();

  private static final AdminCoreResponse adminCoreResponse = AdminCoreResponse.builder()
      .brokerAdminID("brokerAdminID")
      .brokerAdminName("brokerAdminName")
      .userName(USERNAME)
      .title("title")
      .firstName("firstName")
      .middleName("middleName")
      .lastName("lastName")
      .firmName("firmName")
      .middleName("middleName")
      .emailAddress("emailAddress")
      .fcaNumber("fcaNumber")
      .principalFCANumber("principalFCANumber")
      .startDate("startDate")
      .mobilePhone("mobilePhone")
      .businessPhone("businessPhone")
      .build();

  private static final BrokerAssociationsResponse brokerAssociationsResponse = BrokerAssociationsResponse.builder()
      .brokers(Collections.emptyList())
      .admins(Collections.emptyList())
      .grantedPermissionBrokers(Collections.emptyList())
      .message("broker associations ok")
      .build();

  private static final AdminAssociationsResponse adminAssociationsResponse = AdminAssociationsResponse.builder()
        .brokers(Collections.emptyList())
        .message("admin associations ok")
        .build();

  private static final BrokerPermissionsResponse brokerPermissionsResponse = BrokerPermissionsResponse.builder()
        .message("permissions ok")
        .build();

  @BeforeEach
  void setup() throws NoSuchFieldException, IllegalAccessException {
    Field fieldBrokerDetailsEndpoint = crmService.getClass().getDeclaredField("brokerDetailsEndpoint");
    fieldBrokerDetailsEndpoint.setAccessible(true);
    fieldBrokerDetailsEndpoint.set(crmService, BROKER_DETAILS_ENDPOINT);

    Field fieldBrokerUpdateDetailsEndpoint = crmService.getClass().getDeclaredField("brokerUpdateDetailsEndpoint");
    fieldBrokerUpdateDetailsEndpoint.setAccessible(true);
    fieldBrokerUpdateDetailsEndpoint.set(crmService, BROKER_UPDATE_DETAILS_ENDPOINT);

    Field fieldAdminDetailsEndpoint = crmService.getClass().getDeclaredField("adminDetailsEndpoint");
    fieldAdminDetailsEndpoint.setAccessible(true);
    fieldAdminDetailsEndpoint.set(crmService, ADMIN_DETAILS_ENDPOINT);

    Field fieldAdminUpdateDetailsEndpoint = crmService.getClass().getDeclaredField("adminUpdateDetailsEndpoint");
    fieldAdminUpdateDetailsEndpoint.setAccessible(true);
    fieldAdminUpdateDetailsEndpoint.set(crmService, ADMIN_UPDATE_DETAILS_ENDPOINT);

    Field fieldBrokerAssociationsEndpoint = crmService.getClass().getDeclaredField("brokerAssociationsEndpoint");
    fieldBrokerAssociationsEndpoint.setAccessible(true);
    fieldBrokerAssociationsEndpoint.set(crmService, BROKER_ASSOCIATIONS_ENDPOINT);

    Field fieldBrokerUnAssociationsEndpoint = crmService.getClass().getDeclaredField("brokerUnAssociationsEndpoint");
    fieldBrokerUnAssociationsEndpoint.setAccessible(true);
    fieldBrokerUnAssociationsEndpoint.set(crmService, BROKER_UNASSOCIATIONS_ENDPOINT);

    Field fieldAdminAssociationsEndpoint = crmService.getClass().getDeclaredField("adminAssociationsEndpoint");
    fieldAdminAssociationsEndpoint.setAccessible(true);
    fieldAdminAssociationsEndpoint.set(crmService, ADMIN_ASSOCIATIONS_ENDPOINT);

    Field fieldUpdateAssociationsEndpoint = crmService.getClass().getDeclaredField("updateAssociationsEndpoint");
    fieldUpdateAssociationsEndpoint.setAccessible(true);
    fieldUpdateAssociationsEndpoint.set(crmService, UPDATE_ASSOCIATIONS_ENDPOINT);
  }

  @Test
  void shouldGetBrokerDetails() {
    when(crmClient.get(eq(String.format(BROKER_DETAILS_ENDPOINT, USERNAME)), any())).thenReturn(brokerCoreResponse);

    BrokerCoreResponse response = crmService.getBrokerDetails(USERNAME);

    assertNotNull(response);
    assertEquals(USERNAME, response.getBroker().getUserName());
  }

  @Test
  void shouldGetAdminDetails() {
    when(crmClient.get(eq(String.format(ADMIN_DETAILS_ENDPOINT, USERNAME)), any())).thenReturn(adminCoreResponse);

    AdminCoreResponse response = crmService.getAdminDetails(USERNAME);

    assertNotNull(response);
    assertEquals(USERNAME, response.getUserName());
  }

  @Test
  void shouldUpdateBrokerDetails() {
    BrokerDetailsChangeCrmRequest request = BrokerDetailsChangeCrmRequest.builder()
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("brokerPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList("paymentPathId1", "paymentPathId2"))
        .build();

    crmService.updateBrokerDetails(request);

    verify(crmClient, times(1)).post(eq(BROKER_UPDATE_DETAILS_ENDPOINT), eq(request), any());
  }

  @Test
  void shouldUpdateAdminDetails() {
    AdminDetailsChangeCrmRequest request = AdminDetailsChangeCrmRequest.builder()
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .build();

    crmService.updateAdminDetails(request);

    verify(crmClient, times(1)).post(eq(ADMIN_UPDATE_DETAILS_ENDPOINT), eq(request), any());
  }

  @Test
  void shouldGetBrokerAssociations() {
    when(crmClient.get(eq(String.format(BROKER_ASSOCIATIONS_ENDPOINT, USERNAME)), any())).thenReturn(brokerAssociationsResponse);

    BrokerAssociationsResponse response = crmService.getBrokerAssociations(USERNAME);

    assertNotNull(response);
    assertEquals("broker associations ok", response.getMessage());
  }

  @Test
  void shouldGetBrokerUnAssociations() {
    when(crmClient.get(eq(String.format(BROKER_UNASSOCIATIONS_ENDPOINT, USERNAME)), any())).thenReturn(brokerAssociationsResponse);

    BrokerAssociationsResponse response = crmService.getBrokerUnAssociations(USERNAME);

    assertNotNull(response);
    assertEquals("broker associations ok", response.getMessage());
  }

  @Test
  void shouldGetAdminAssociations() {
    when(crmClient.get(eq(String.format(ADMIN_ASSOCIATIONS_ENDPOINT, USERNAME)), any())).thenReturn(adminAssociationsResponse);

    AdminAssociationsResponse response = crmService.getAdminAssociations(USERNAME);

    assertNotNull(response);
    assertEquals("admin associations ok", response.getMessage());
  }

  @Test
  void shouldAssociateBrokerToBroker() {
    when(crmClient.post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), brokerPermissionsRequestArgumentCaptor.capture(), any())).thenReturn(brokerPermissionsResponse);

    BrokerPermissionsResponse response = crmService.associateBrokerToBroker(USERNAME, "newUser");

    assertNotNull(response);
    assertEquals(USERNAME, brokerPermissionsRequestArgumentCaptor.getValue().getUserName());
    assertEquals("newUser", brokerPermissionsRequestArgumentCaptor.getValue().getAssociateBrokers().get(0));
    assertEquals("permissions ok", response.getMessage());
  }

  @Test
  void shouldUnAssociateBrokerToBroker() {
    when(crmClient.post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), brokerPermissionsRequestArgumentCaptor.capture(), any())).thenReturn(brokerPermissionsResponse);

    BrokerPermissionsResponse response = crmService.unAssociateBrokerToBroker(USERNAME, "newUser");

    assertNotNull(response);
    assertEquals(USERNAME, brokerPermissionsRequestArgumentCaptor.getValue().getUserName());
    assertEquals("newUser", brokerPermissionsRequestArgumentCaptor.getValue().getDissociateBrokers().get(0));
    assertEquals("permissions ok", response.getMessage());
  }

  @Test
  void shouldAssociateBrokerToAdmin() {
    when(crmClient.post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), brokerPermissionsRequestArgumentCaptor.capture(), any())).thenReturn(brokerPermissionsResponse);

    BrokerPermissionsResponse response = crmService.associateBrokerToAdmin(USERNAME, "newAdmin");

    assertNotNull(response);
    assertEquals(USERNAME, brokerPermissionsRequestArgumentCaptor.getValue().getUserName());
    assertEquals("newAdmin", brokerPermissionsRequestArgumentCaptor.getValue().getAssociateBrokerAdmins().get(0));
    assertEquals("permissions ok", response.getMessage());
  }

  @Test
  void shouldUnAssociateBrokerToAdmin() {
    when(crmClient.post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), brokerPermissionsRequestArgumentCaptor.capture(), any())).thenReturn(brokerPermissionsResponse);

    BrokerPermissionsResponse response = crmService.unAssociateBrokerToAdmin(USERNAME, "newAdmin");

    assertNotNull(response);
    assertEquals(USERNAME, brokerPermissionsRequestArgumentCaptor.getValue().getUserName());
    assertEquals("newAdmin", brokerPermissionsRequestArgumentCaptor.getValue().getDissociateBrokerAdmins().get(0));
    assertEquals("permissions ok", response.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenGetBrokerDetails() {
    doThrow(new RestClientException("CRM client error"))
        .when(crmClient).get(eq(String.format(BROKER_DETAILS_ENDPOINT, USERNAME)), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.getBrokerDetails(USERNAME));
    assertEquals("getBrokerDetails: Request failed for broker username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenGetAdminDetails() {
    doThrow(new RestClientException("CRM client error"))
        .when(crmClient).get(eq(String.format(ADMIN_DETAILS_ENDPOINT, USERNAME)), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.getAdminDetails(USERNAME));
    assertEquals("getAdminDetails: Request failed for admin username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUpdateBrokerDetails() {
    final BrokerDetailsChangeCrmRequest request = BrokerDetailsChangeCrmRequest.builder()
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .addressLine1("firmAddressLine1")
        .addressLine2("firmAddressLine2")
        .addressLine3("firmAddressLine3")
        .city("firmAddressCity")
        .county("firmAddressCounty")
        .postcode("brokerPostcode")
        .fcaNumber("fcaNumber")
        .tradingName("tradingName")
        .paymentPaths(Arrays.asList("paymentPathId1", "paymentPathId2"))
        .build();

    doThrow(new RestClientException("CRM client error"))
        .when(crmClient).post(eq(BROKER_UPDATE_DETAILS_ENDPOINT), eq(request), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.updateBrokerDetails(request));
    assertEquals("updateBrokerDetails: Request failed for broker username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUpdateAdminDetails() {
    final AdminDetailsChangeCrmRequest request = AdminDetailsChangeCrmRequest.builder()
        .username(USERNAME)
        .title("title")
        .firstName("firstName")
        .lastName("lastName")
        .email("emailAddress")
        .mobilePhone("mobileNumber")
        .businessPhone("businessPhone")
        .build();

    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).post(eq(ADMIN_UPDATE_DETAILS_ENDPOINT), eq(request), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.updateAdminDetails(request));
    assertEquals("updateAdminDetails: Request failed for admin username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenGetBrokerAssociations() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).get(eq(String.format(BROKER_ASSOCIATIONS_ENDPOINT, USERNAME)), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.getBrokerAssociations(USERNAME));
    assertEquals("getBrokerAssociations: Request failed for username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenGetBrokerUnAssociations() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).get(eq(String.format(BROKER_UNASSOCIATIONS_ENDPOINT, USERNAME)), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.getBrokerUnAssociations(USERNAME));
    assertEquals("getBrokerUnAssociations: Request failed for username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenGetAdminAssociations() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).get(eq(String.format(ADMIN_ASSOCIATIONS_ENDPOINT, USERNAME)), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.getAdminAssociations(USERNAME));
    assertEquals("getAdminAssociations: Request failed for username 12345", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenAssociateBrokerToBroker() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), any(), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.associateBrokerToBroker(USERNAME, "newBroker"));
    assertEquals("associateBrokerToBroker: Request failed where userName is 12345 and userNameToAssociate is newBroker", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUnAssociateBrokerToBroker() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), any(), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.unAssociateBrokerToBroker(USERNAME, "newBroker"));
    assertEquals("unAssociateBrokerToBroker: Request failed where userName is 12345 and userNameToUnAssociate is newBroker", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenAssociateBrokerToAdmin() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), any(), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.associateBrokerToAdmin(USERNAME, "newAdmin"));
    assertEquals("associateBrokerToAdmin: Request failed where userName is 12345 and adminToAssociate is newAdmin", exception.getMessage());
  }

  @Test
  void shouldHandleExceptionWhenUnAssociateBrokerToAdmin() {
    doThrow(new RestClientException("CRM client error"))
            .when(crmClient).post(eq(UPDATE_ASSOCIATIONS_ENDPOINT), any(), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> crmService.unAssociateBrokerToAdmin(USERNAME, "newAdmin"));
    assertEquals("unAssociateBrokerToAdmin: Request failed where userName is 12345 and adminToUnAssociate is newAdmin", exception.getMessage());
  }

}
