package com.natwest.pbbdhb.brokerauth.request.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.ActivationContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import com.natwest.pbbdhb.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.brokerauth.service.activation.ActivationService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

@ActiveProfiles(profiles = {"int", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ActivationControllerTestIT {

  @MockBean
  ActivationService activationService;
  @MockBean
  AccessTokenService accessTokenService;

  @LocalServerPort
  int port;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Value("${server.servlet.context-path}")
  String contextPath;

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("mortgages/v1/msvc-broker-auth/activation")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header("iam-claimsetjwt", JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Validate Activation Code")
  class ValidateActivationCode {

    @Test
    void shouldCallServices() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(otpContext.createActivationCodeValidateRequest())
          .post("/validate")
          .then()
          .log()
          .all();

      Mockito.verify(accessTokenService, times(1)).token(any());
      Mockito.verify(activationService).validateActivationCode(any(), any());
    }

    @Test
    void shouldReturnServerErrorIfValidateThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(activationService)
          .validateActivationCode(any(), any());

      givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(otpContext.createActivationCodeValidateRequest())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void shouldReturnBadRequestIfValidateReceivesInvalidRequest() {

      givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(new JSONObject().toString())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnUnauthorisedIfValidateOtpReceivesInvalidUsernameOrOtpCode() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      doThrow(new OtpException(
          ErrorCode.INVALID_CREDENTIALS, "Invalid username or otp"))
          .when(activationService)
          .validateActivationCode(any(), any());

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(otpContext.createActivationCodeValidateRequest())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .extract().asString();

      Assertions.assertTrue(response.contains("INVALID_CREDENTIALS"));
    }

    @Test
    void shouldReturnUnauthorisedIfValidateOtpReceivesExpiredOtpCode() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      doThrow(new OtpException(
          ErrorCode.OTP_EXPIRED, "Expired otp"))
          .when(activationService)
          .validateActivationCode(any(), any());

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(otpContext.createActivationCodeValidateRequest())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .extract().asString();

      Assertions.assertTrue(response.contains("OTP_EXPIRED"));
    }

    @Test
    void shouldReturnUnauthorisedIfTryToValidateALockedAccount() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      doThrow(new OtpException(
          ErrorCode.ACCOUNT_LOCKED, "Account is locked"))
          .when(activationService)
          .validateActivationCode(any(), any());

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(otpContext.createActivationCodeValidateRequest())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .extract().asString();

      Assertions.assertTrue(response.contains("ACCOUNT_LOCKED"));
    }

    @Test
    void shouldReturnUnauthorisedIfValidateOtpReturnsDifferentReturnCode() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();
      final OtpContext otpContext =
          OtpContext.builder()
              .build();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      doThrow(new OtpException(
          ErrorCode.OTP_VALIDATION_FAILED, "Something went wrong"))
          .when(activationService)
          .validateActivationCode(any(), any());

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .body(otpContext.createActivationCodeValidateRequest())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .extract().asString();

      Assertions.assertTrue(response.contains("OTP_VALIDATION_FAILED"));
    }
  }

  @Nested
  @DisplayName("activateUser Cases")
  class ActivateUserCases {

    @Test
    void shouldCallDownstreamServices() {
      ActivationContext context = ActivationContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createUserActivateRequest()))
          .contentType(ContentType.JSON)
          .post()
          .then().log().all();

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(activationService, times(1))
          .activateUser(any(), any());

    }

    @Test
    void shouldReturnServerErrorIfActivationServiceThrowsUserNotFound() {
      ActivationContext context = ActivationContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UserNotFoundException(
          "User Not Found"))
          .when(activationService)
          .activateUser(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createUserActivateRequest()))
          .contentType(ContentType.JSON)
          .post()
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(activationService, times(1))
          .activateUser(any(), any());

    }

    @Test
    void shouldReturnServerErrorIfActivationServiceThrowsRemoteFailure() {
      ActivationContext context = ActivationContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(activationService)
          .activateUser(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createUserActivateRequest()))
          .contentType(ContentType.JSON)
          .post()
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(activationService, times(1))
          .activateUser(any(), any());

    }

    @Test
    void shouldReturnErrorIfPasswordIsInvalid() {
      ActivationContext context = ActivationContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new InvalidDetailsException(
          "Password doesn't meet requirements."))
          .when(activationService)
          .activateUser(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createUserActivateRequest()))
          .contentType(ContentType.JSON)
          .post()
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(activationService, times(1))
          .activateUser(any(), any());

    }

    @Test
    void shouldReturnBadRequestIfSecurityQuestionHasNullAnswer() {
      List<SecurityQuestion> questionWithNullAnswer = Collections.singletonList(
          SecurityQuestion.builder()
              .question("test question?")
              .build());

      UserActivateRequest request = ActivationContext.builder()
          .securityQuestions(questionWithNullAnswer)
          .build()
          .createUserActivateRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnBadRequestIfSecurityQuestionHasBlankAnswer() {
      List<SecurityQuestion> questionWithBlankAnswer = Collections.singletonList(
          SecurityQuestion.builder()
              .question("test question?")
              .answer("            ")
              .build());

      UserActivateRequest request = ActivationContext.builder()
          .securityQuestions(questionWithBlankAnswer)
          .build()
          .createUserActivateRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnBadRequestIfSecurityQuestionHasNoAnswer() {
      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(ActivationContext.MISSING_SECURITY_ANSWER_REQUEST)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }
  }
}
