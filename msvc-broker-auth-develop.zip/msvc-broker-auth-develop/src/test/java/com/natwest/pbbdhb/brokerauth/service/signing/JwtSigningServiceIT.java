package com.natwest.pbbdhb.brokerauth.service.signing;

import static org.assertj.core.api.Assertions.assertThat;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.natwest.pbbdhb.brokerauth.config.JwtPublicKeyConfiguration;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.JsonWebTokenModel;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

/**
 * Tests the JWT signing service that is responsible to creating and signing JWTs.
 */
@ActiveProfiles(profiles = {
    "int"
})
@SpringBootTest
@Import(JwtPublicKeyConfiguration.class)
public class JwtSigningServiceIT {

    private static final String ALGORITHM_ID = AlgorithmIdentifiers.RSA_USING_SHA256;
    private static final String ISSUER = "hbo_issuer";
    private static final String SUBJECT = "hbo_subject";
    private static final String AUDIENCE = "https://iam-authn-sit-nwb.managedtest.com/as/token.oauth2";
    private static final String CLIENT_ID = "hbo-auth-client";
    private static final Brand BRAND = Brand.NWB;
    private static final String CHANNEL = "INTERNET";
    private static final String CIN = "23456789";
    private static final String APPLICANT_ID = "abcdef-12345";
    private static final String CASE_ID = "a1-b2-c3-d4-e5";

    @Autowired
    private JwtSigningService service;

    @Autowired
    @Qualifier("jwtPublicKey")
    public PublicKey publicKey;

    @Autowired
    MicroserviceIssuer microserviceIssuer;

    @Test
    public void shouldCreateJsonWebTokenFromModel() {
        final String jwt = service.createJwt(jwtModel());
        assertThat(jwt).isNotEmpty();
    }

    @Test
    public void shouldVerifySignatureOfJsonWebTokenUsingPublicKey() throws JoseException {
        // create signed JWT as string
        final String jwt = service.createJwt(jwtModel());

        // convert back to a JWS
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(jwt);
        jws.setKey(publicKey);

        // confirms our JWT (signed by our private key) can be verified by the public key
        assertThat(jws.verifySignature()).isTrue();
    }

    @Test
    public void JsonWebTokenShouldContainExpectedHeaders() throws JoseException {
        // create signed JWT as string
        final String jwt = service.createJwt(jwtModel());

        // convert back to a JWS
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(jwt);
        jws.setKey(publicKey);

        // confirm JWT contains the expected headers
        assertThat(jws.getAlgorithmHeaderValue()).isEqualTo(ALGORITHM_ID);
        assertThat(jws.getHeader(HeaderParameterNames.TYPE)).isEqualTo("JWT");
    }

    @Test
    public void JsonWebTokenShouldContainExpectedPayload() throws JoseException {
        // create signed JWT as string
        final String jwt = service.createJwt(jwtModel());

        // convert back to a JWS
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(jwt);
        jws.setKey(publicKey);

        // confirm JWT contains the expected payload
        final String jsonPayload = jws.getPayload();
        assertThat(extract(jsonPayload, "$.sub")).isEqualTo(SUBJECT);
        assertThat(extract(jsonPayload, "$.iss")).isEqualTo(ISSUER);
        assertThat(extract(jsonPayload, "$.aud")).isEqualTo(AUDIENCE);
        assertThat(extract(jsonPayload, "$.iat")).isNotNull();
        assertThat(extract(jsonPayload, "$.exp")).isNotNull();
        assertThat(extract(jsonPayload, "$.jti")).isNotNull();
        assertThat(extract(jsonPayload, "$.client_id")).isEqualTo(CLIENT_ID);
        assertThat(extract(jsonPayload, "$.brand")).isEqualTo(BRAND.getValue());
        assertThat(extract(jsonPayload, "$.channel")).isEqualTo(CHANNEL);
        assertThat(extract(jsonPayload, "$.details")).isNotNull();
        assertThat(extract(jsonPayload, "$.details.cin")).isEqualTo(CIN);
        assertThat(extract(jsonPayload, "$.details.applicant_id")).isEqualTo(APPLICANT_ID);
        assertThat(extract(jsonPayload, "$.details.case_id")).isEqualTo(CASE_ID);
        assertThat(extract(jsonPayload, "$.details.nested-obj.name")).isEqualTo("value");
        assertThat(extract(jsonPayload, "$.details.nested-list.[0]")).isEqualTo("1");
        assertThat(extract(jsonPayload, "$.details.nested-list.[1]")).isEqualTo("2");
        assertThat(extract(jsonPayload, "$.details.nested-list.[2]")).isEqualTo("3");
    }

    @Test
    public void shouldCreateJsonWebTokenFromModelWithoutOptionalClaims() throws JoseException {

        // create JWT model without optional claims
        final JsonWebTokenModel jwtModelWithoutOptionalClaims = JsonWebTokenModel
            .builder()
            .header(JsonWebTokenModel.HeaderModel.builder()
                .algorithm(ALGORITHM_ID)
                .build())
            .payload(JsonWebTokenModel.PayloadModel.builder()
                .issuer(ISSUER)
                .subject(SUBJECT)
                .audience(AUDIENCE)
                .clientId(CLIENT_ID)
                .build())
            .build();

        // create signed JWT as string
        final String jwt = service.createJwt(jwtModelWithoutOptionalClaims);

        // convert back to a JWS
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(jwt);
        jws.setKey(publicKey);

        // verify signature
        assertThat(jws.verifySignature()).isTrue();

        // confirm JWT contains the expected payload
        final String jsonPayload = jws.getPayload();
        assertThat(extract(jsonPayload, "$.sub")).isEqualTo(SUBJECT);
        assertThat(extract(jsonPayload, "$.iss")).isEqualTo(ISSUER);
        assertThat(extract(jsonPayload, "$.aud")).isEqualTo(AUDIENCE);
        assertThat(extract(jsonPayload, "$.iat")).isNotNull();
        assertThat(extract(jsonPayload, "$.exp")).isNotNull();
        assertThat(extract(jsonPayload, "$.jti")).isNotNull();
        assertThat(extract(jsonPayload, "$.client_id")).isEqualTo(CLIENT_ID);
        assertThat(extract(jsonPayload, "$.brand")).isNull();
        assertThat(extract(jsonPayload, "$.channel")).isNull();
        assertThat(extract(jsonPayload, "$.details")).isNull();
    }


    /**
     * A JWT signed by our private key can only be verified using the associated public key.
     * <p>
     * This test proves that any attempt to verify the JWT using a different public key will fail.
     */
    @Test
    public void shouldNotVerifySignatureOfJsonWebTokenUsingIncorrectPublicKey()
        throws JoseException {
        // create signed JWT as string
        final String jwt = service.createJwt(jwtModel());

        // extract public key used to initialise our microservice.
        // we could use any public key for our test. this is just an easy way to retrieve one.
        final PublicKey otherPublicKey = microserviceIssuer
            .getInitialisationCertificate()
            .getPublicKey();

        // convert back to a JWS
        JsonWebSignature jws = new JsonWebSignature();
        jws.setCompactSerialization(jwt);
        jws.setKey(otherPublicKey);

        // confirm our JWT (signed by our private key) can NOT be verified by unrelated public key
        assertThat(jws.verifySignature()).isFalse();
    }

    /**
     * Extract Object from JSON payload using JSON Path
     */
    private Object extract(String payload, String jsonPath) {
        try {
            return JsonPath
                .parse(payload)
                .read(jsonPath, Object.class);
        } catch (PathNotFoundException e) {
            return null;
        }
    }

    /**
     * Helper to create JWT Model
     */
    private JsonWebTokenModel jwtModel() {
        return JsonWebTokenModel
            .builder()
            .header(JsonWebTokenModel.HeaderModel.builder()
                .algorithm(ALGORITHM_ID)
                .build())
            .payload(JsonWebTokenModel.PayloadModel.builder()
                .issuer(ISSUER)
                .subject(SUBJECT)
                .audience(AUDIENCE)
                .clientId(CLIENT_ID)
                .brand(BRAND)
                .channel(CHANNEL)
                .details(createDetails())
                .build())
            .build();
    }

    /**
     * Creates contents of nested details object within JWT
     */
    private Map<String, Object> createDetails() {

        Map<String, Object> details = new HashMap<>();
        details.put("cin", CIN);
        details.put("applicant_id", APPLICANT_ID);
        details.put("case_id", CASE_ID);

        // add a nested object
        Map<String, Object> nestedObject = new HashMap<>();
        nestedObject.put("name", "value");
        details.put("nested-obj", nestedObject);

        // add a nested array
        List<String> nestedList = new ArrayList<>();
        nestedList.add("1");
        nestedList.add("2");
        nestedList.add("3");
        details.put("nested-list", nestedList);

        return details;
    }
}
