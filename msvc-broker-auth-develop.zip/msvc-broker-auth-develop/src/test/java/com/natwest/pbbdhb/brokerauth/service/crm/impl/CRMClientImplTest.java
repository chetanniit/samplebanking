package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.PingTokenGenerationException;
import com.natwest.pbbdhb.brokerauth.model.crm.OAuthTokenData;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.AdminCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CRMClientImplTest {

    @InjectMocks
    private CRMClientImpl client;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private OAuthTokenService oauthTokenService;

    @BeforeEach
    void setup() {
        OAuthTokenData oAuthTokenData = OAuthTokenData.builder().accessToken("jljpr5qVHXc9oRdSgKjCTjnnATzQ").tokenType("Bearer").build();
        when(oauthTokenService.generatePingToken()).thenReturn(oAuthTokenData);
    }

    @Test
    void shouldGetSuccessfulResponseForBrokerDetailsEndpoint() {
        String endpoint = "/broker/details";
        BrokerCoreResponse coreResponse = Mockito.mock(BrokerCoreResponse.class);

        when(restTemplate.exchange(same(endpoint), same(HttpMethod.GET), any(HttpEntity.class),
                same(BrokerCoreResponse.class))).thenReturn(new ResponseEntity(coreResponse, HttpStatus.OK));

        Object response = client.get(endpoint, BrokerCoreResponse.class);

        assertNotNull(response);
        assertTrue(response instanceof BrokerCoreResponse);
    }

    @Test
    void shouldThrowPingTokenGenerationException() {
        String endpoint = "/broker/details";
        when(oauthTokenService.generatePingToken()).thenThrow(new PingTokenGenerationException(
                "Unable to generate ping toke"));

        assertThrows(PingTokenGenerationException.class, () -> {
            client.get(endpoint, BrokerCoreResponse.class);
        });
    }

    @Test
    void shouldThrowPingTokenGenerationExceptionIfTokenDataIsNull() {
        String endpoint = "/broker/details";
        when(oauthTokenService.generatePingToken()).thenReturn(null);

        assertThrows(PingTokenGenerationException.class, () -> {
            client.get(endpoint, BrokerCoreResponse.class);
        });
    }

    @Test
    void shouldThrowPingTokenGenerationExceptionIfAccessTokenIsNull() {
        String endpoint = "/broker/details";
        when(oauthTokenService.generatePingToken()).thenReturn(new OAuthTokenData());

        assertThrows(PingTokenGenerationException.class, () -> {
            client.get(endpoint, BrokerCoreResponse.class);
        });
    }

    @Test
    void shouldGetSuccessfulResponseForAdminDetailsEndpoint() {
        String endpoint = "/admin/details";
        AdminCoreResponse adminCoreResponse = Mockito.mock(AdminCoreResponse.class);

        when(restTemplate.exchange(same(endpoint), same(HttpMethod.GET), any(HttpEntity.class),
                same(AdminCoreResponse.class))).thenReturn(new ResponseEntity(adminCoreResponse, HttpStatus.OK));

        Object response = client.get(endpoint, AdminCoreResponse.class);

        assertNotNull(response);
        assertTrue(response instanceof AdminCoreResponse);
    }

}