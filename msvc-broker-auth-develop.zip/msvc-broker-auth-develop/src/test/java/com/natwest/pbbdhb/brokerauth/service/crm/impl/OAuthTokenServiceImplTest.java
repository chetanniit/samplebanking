package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.configuration.CRMConfig;
import com.natwest.pbbdhb.brokerauth.model.crm.OAuthTokenData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OAuthTokenServiceImplTest {

    @InjectMocks
    private OAuthTokenServiceImpl oAuthTokenService;

    @Mock
    private CRMConfig crmConfig;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    public void setup() {
        when(crmConfig.getConfidentialClientID()).thenReturn("67572a85-c465-42b4-91b9-49a8e73ee3ad");
        when(crmConfig.getPwd()).thenReturn("6h!nEox*GU");
        when(crmConfig.getPfxcert()).thenReturn("MIINiQIBAzCCDU8GCSqGSIb3DQEHAaCCDUAEgg08MIINODCCB+8GCSqGSIb3DQEHBqCCB+AwggfcAgEAMIIH1QYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIzY8/fHUuI7UCAggAgIIHqAyJUx6tVoscR96RtvdjJpBSrMb1MqnR7k518wbOVkPdo1gMihnJ0VaNSjDsLTIg6bsBN8KEUY5QGJFmuEgSvhMiLs5tNzzIf9OUCEUUMnkUBDC3DecOmMGXxK3fsOs2FGDyZqeeL6ORCzWH7AF98zTCBYobkSS0I50uYXTGmHz5uQAC5OHzzXyfNP1zGLjn0hu8j1AviV3jawqOg+lrkxzW712J7bjeBSztiZhlN5rLDc++6F5ldh8mSsWPSqwyzZycjZEWhTCnyz9l28/qD1pZvuwcpw3qLeVlGS8K+H2ln2fJqOi7/4BFFnEltRqayuU0cbJRe3TMcvffYwomSLCoOpffFSz4hAdC5kTVcAXmGXrqKE3Ika4LEUkxLILroZ5xLGusjJ5J3CxNRg2Q3Kdfd0NFdjQEVXwV0YkssfeZtc+678yfvzHLlk/BSFq+EgDr2BIkmpEhLV9auLh2J/cgZyia14LwyhHaou0WAF1VMcno6yUa+A21ELTfMpHgePH0htTRVlF3hB92g1yHeI1HLTq1moxE93Znm6bHy8fwBPa9ezduioqsQ8KB5scwXcutlAcmTIMGsBol3ZKa5eXBg0vrMOCu0BZZw5s/5hgd8jSyTEy0XaTB2i+knZEKMdFN1NIfIJReON9jSJ+Mdh3RIb/Cv4ntT52VER4LbjLbop1Hn2N3jhCuUGbfR9JW8BVTaTZDSEKQESHnKZXONyVdo+hj6Hz49BsSGOB44liw381Xt5IVSrCMpTv5qD81WjpGQLDGWPtktybv6Biu/7L/zr3wGoW5a1Em+slxwsf+7lkqx3HeDds+q3Qhic5ef4Xs132gZEcFqtwXhizQVM4ECwngwkn5LV0bH2e0qBNZodeUPCI5cmsHz/6K9BRflAIHyicWb/F8CGek/hIuzXle7p7FWeojLUu9M4IeOfZGbke603Jl00ia9EuTEIL79RMje0YHXG+3iho8w5Ruy1aazvelRwIdD7HG/owwvmCt7cJPwc8xXaaTCuNMdrldrfYGiipwzNInEYghLRRle+Dj8yBQA1OGGZs/Hcc5mASs18XsudUsU4l5hHyH8MDT2jXPPtHEpWeZGryFbImWLLTDMLmzH3Yx4Z6NWhhM0k+N7NQh025wbmqHL7VejdLtztMBMADisCkUFtfeHvypB4jBh010u4a40D0Nu0dhx7qAhnG/a11qBML5s9D7ZMEkzq7OV5L6byBg9TB8tFumNv7OY3rd72+INbXWZFrkNMkWPYaS3lUFL6jEMm7rJm/f/g+WCs2ZZgryunB4pY8z+FSi0P/Ckccp4aGKDuWjJYfTSB9zd5bCSpN7xErOsNSoqNPWcUunc6kSa02HnemO0xCr58/IjLnePEySxeHcbeUR/SQXYC01EE3TdxdS4ilax9CmUAXEA+kIWfYtC0Bi8iMFCMrXs8adDAg7gIHpD+URSxb8yeuIz4k+NIDMeH1ddhf0hI1Z6Ong/LWOIUKjpdVARhMI/8bRM6LWvQ0IDu/QeoYuVXU2uBQgVEYkVaxdOsMYOHsl7jzcIxhlVXksNL2fxdOCXUXwzCImqMqFadqkYzqLE/N4+JXIm0oSUR+rP3rsmRJZ9akc4cJ+8+IuEfEGzBw3+U4lnlpM6PEesKIY1JAGkirl+lbphrgDWPI9UWrxbJEv06x/2OU0nWol2t4kfn3x+NOROea7zmZwQaoP7LYwGucXfYusuEtyVdMxipn7jqRWVF1sqOKxB6545YQtpWKPM8JliU8b/erh/tQuHi2YiHfUrBf1emo08yznlI95OCVAkL/wOVpnVToq7iscP22H9EtkID0mK3rm3qIjapkKA77ulPcakxkdWIjeR3adsM+9wM8k1OoUXWUMMXw+8pHO7HugucM92sL7UT4wY/Ml/QeDwYpVRHYJrsLyGelLSBwxWzR5VLzPwm+6zxyPPWfGgu/uJw97E9nH9dIc1CXODFubQpfLf0fjfpRz3RCFol+zJzdNDRSCvqK26f+yU72XYMFNmGz555kaSTUEsQWtQW/hU6OtJeZkRBcA2N+7aRhBrVhANvAwl5pRtTqRKCVuCM3mJ5wk3Hw7ORcrsZBTG8Px9x25WbUGhCo68IjB2VcIYPM4rhfMzI5T3G/3xbBhDxLiVzaiN4JgiTplPboEeliZ1NuRIwicSIgAEaBhYVzRtyZEt7hU5IlVN5xw7qpKpNJSONXMe0SDXaWHYiVV5blThTZESXrMQiWGAW7GEUs79IOEPfHLOYjmXOGYmmNO4Di2aJ8EbSBaZeZaqIwpQie9aphAlo0zsQW7UNDpmVm0uW1w1NnRMMMZSbSaOB3FSfmGa3hZ8KwjqpKq3KEEUf+e+zQa5n91YlpzPCGcZD2Gd5GQws5OF5nZ/DD8XnQRlE2lac8097WiB5vKClyMweq6ItT1ydtUwtplfcigIU15CN97WB0Jeipy05RNyLin7OOrXsDy4rfTwksh/TAJAZE1AkXzkxvCUZvjgVJpj2vZzG7717xynoOAvhrYDknuMFtcYsdpz/clAMFxzwIa3lJJR4X9P70UIotHNjARpbDOSwM59wE06YryfSf8l5i0fYqq6LgdsW9QLVCSPvEOQpmOVzQwggVBBgkqhkiG9w0BBwGgggUyBIIFLjCCBSowggUmBgsqhkiG9w0BDAoBAqCCBO4wggTqMBwGCiqGSIb3DQEMAQMwDgQIkzlcKoqkj9sCAggABIIEyIGHqY+dSNVs0JpUrHsCWAONAUF+jScEdiOcZwq+gPVvEQZ2VIzcZU9rIaAuDyuWffE8Tb+IC5cchoLAwLYjjMUFIwEDR32+LriYuLS4dfq1RO14IXD8ROaK8+44oQG3NfdYU9l0vz9x2gCB6KXNzwu//6j+rxcO4AMq2mMhksRgJyaQeDU2OKKZe9nUcmG9efNyKyA1Ig9a+46VrMj3yf0nD5ZeVXt8FTQkte+QReLCdYyHOgGsXe5WZpPkvD6/T+8qK7+4xMy8ySNS01/YyPzWgZc04BA/SUHnKLp5I231XqCfdnjooJSjOVtkyqGGCPqKol56me5r2DONUdXdsl8zUvgYtpCUszc4UeBjJoPlMOGcbo7mMQsoi4yNZGqtDJ6qREEEYx7eoXlLWY0rDWCXNkXzzv3RD13HLUUNYr3OhHf2ADAY43627FaUSabZlDgIY265JobDKLks5+STKKiwGr6IKO5X+Y96MazrMnzMspxeGFVT8HHdEtMdulTBTatdFoas/lSWc3I+0bWAv86GjCqbZkcgvf56qRWHuHIW7R9aWOy78fZhUw6mcgvdrtzA1/DA3tuemY/j6l8VP3UfvVgmyEsa+c6ocSNLyVTHeAgTQULfJR3/P8zvH5az8xFocUOLLcDUIgkn7Ayyj8s6XIyJVefSm2VCKlBY0h/Go/rsVb+4tNVwBfTc0UiVzdxDt+OWLXqWYIhME4s9s+UvN03+fZzFSpjgccj6gMmnfT5y7SjdiLkBaEUs/8DGiPC+6MnaWwsKk3/mAoS0Wdwu4caqr3klqi1GjbRnXjiptjDTjEei6M0UB9zxxnQ77ucgT0Ruveomwvtkm05cb5PX8aW/yU7gCJAPSBAUgAlqrXEuiNihv8uvb02Nx98iu3zKyY1MRVHGMIFvL/GNgUCo1pRcl9otb4wVcEL3Lz6JBN1+7H33W6IZSVofKqenWIoc0bK5ipWcu3OWtpCqo7YuLkQBJu93BgTHtt/rKm2TBQfQYZ4Sz8B3OLXKq9i8Qzvm95+QXQOZ42ptbyWYA9uEfKfFlOqE3vYTZWmULQAAcKiQBYPfN0qABd7eF6OULmvuPBGLMjjyRyH+LJc7ANrWk7T4cOEH4PbqnxxzpZ3vka0FdS6guxrE5iH4/1KnC9tj+/eJuqQRq8MDsK/GKxyivU1FjiZjghiOsLkVg5ZDApKkzR9esMwU0mqzm303zgjjeWkphXFYS4bMWBCHIMkfUPkruKXbxrrD2jQZ+dNXAiyJIy0ze2UX3W+qZVEc3PSb0IH5A8arOXBsI4uvTUoPQpvYoWpgVpiMcQqhaoybE8kJtACogHYaTuGoyi/46NAiXe75Vi4vySLrNztpeeEfmq0/aFvS3L+VSbjV15OlVkeumc2Py6KRF23gjahSDG8YoCthHr5Bl1sdwr7ODZK6oasmfDJgPS1nSEoZ4oXCkM6JWIMqdGAFAO+qMC1crWZOKSb35lasF3IROiiW5ClxgHHHcPg1WwJiXF2KlqYo2dmpvm0MMuxJRbf9nHFqHa3ORRGC/a1s/AM5eLuDHwJEgAMYrkstSBA8GpMO15yT+OfK8zpOnPqfyxLDqpIo5bi6YycR5SONe4bDLDdy4bXpEkv9Pqt6oTElMCMGCSqGSIb3DQEJFTEWBBT8LV94ACCZVEKdn8goTcUWxXSN5DAxMCEwCQYFKw4DAhoFAAQUqfWGR1Pug7RtND3wp/M+VBp7+/EECMA8eaMZb75WAgIIAA==");
        when(crmConfig.getAud()).thenReturn("https://login.microsoftonline.com/7c917db0-71f2-438e-9554-388ffcab8764/oauth2/token");
        when(crmConfig.getCrmAccessTokenEndpoint()).thenReturn("https://login.microsoftonline.com/7c917db0-71f2-438e-9554-388ffcab8764/oauth2/token");
        when(crmConfig.getAssertion()).thenReturn("urn:ietf:params:oauth:client-assertion-type:jwt-bearer");
        when(crmConfig.getResource()).thenReturn("https://pbbnwisuat.crm4.dynamics.com");
        when(crmConfig.getTenant()).thenReturn("7c917db0-71f2-438e-9554-388ffcab8764");
        when(crmConfig.getScope()).thenReturn("https://graph.microsoft.com/.default");
        when(crmConfig.getGrant()).thenReturn("client_credentials");
        when(crmConfig.getThumbprint()).thenReturn("FC2D5F7800209954429D9FC8284DC516C5748DE4");
    }

    @Test
    void shouldGenerateAccessToken() {
        OAuthTokenData oAuthTokenData = OAuthTokenData.builder().accessToken("jljpr5qVHXc9oRdSgKjCTjnnATzQ").tokenType("Bearer").build();
        when(restTemplate.exchange(same(crmConfig.getCrmAccessTokenEndpoint()), same(HttpMethod.POST),
                any(HttpEntity.class),same(OAuthTokenData.class))).thenReturn(new org.springframework.http.ResponseEntity(oAuthTokenData, HttpStatus.OK));
        OAuthTokenData response = oAuthTokenService.generatePingToken();
        assertEquals("jljpr5qVHXc9oRdSgKjCTjnnATzQ", response.getAccessToken());
    }
}