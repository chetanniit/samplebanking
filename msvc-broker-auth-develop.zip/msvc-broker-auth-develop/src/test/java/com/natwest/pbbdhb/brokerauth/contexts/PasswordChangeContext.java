package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.PasswordChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordChangeRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Getter
@ToString
@Builder
@Slf4j
public class PasswordChangeContext {

  @Default
  private String username = "TestUsername";

  @Default
  private String currentPassword = "Password123";

  @Default
  private String newPassword = "Password456";

  @Default
  private String id = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  public PasswordChangeRequestModel createPasswordChangeRequestModel() {
    return PasswordChangeRequestModel.builder()
        .username(username)
        .currentPassword(currentPassword)
        .newPassword(newPassword)
        .build();
  }

  public PasswordChangeRequest createPasswordChangeRequest() {
    return PasswordChangeRequest.builder()
        .username(username)
        .currentPassword(currentPassword)
        .newPassword(newPassword)
        .build();
  }

  public UserChangePasswordRequestModel createUserChangePasswordRequestModel() {
    return UserChangePasswordRequestModel.builder()
        .customerIdentifier(id)
        .currentPassword(currentPassword)
        .newPassword(newPassword)
        .build();
  }
}
