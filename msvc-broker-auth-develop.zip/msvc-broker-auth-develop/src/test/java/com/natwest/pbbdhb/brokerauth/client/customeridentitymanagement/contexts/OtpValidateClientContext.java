package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateClientResponse.OtpResource;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateReturnCode;
import java.util.Collections;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class OtpValidateClientContext {

  @Default
  String username = "testAccount";

  @Default
  private String encodedOtpCode = "UkhGMzQyd3A=";

  @Default
  private OtpValidateReturnCode returnCode = OtpValidateReturnCode.SUCCESS;

  @Default
  private int totalResults = 1;

  public OtpValidateClientRequest createOtpValidateClientRequest() {
    return OtpValidateClientRequest.builder()
        .username("CPB-NAPL-NWB@" + username)
        .encodedOtpCode(encodedOtpCode)
        .build();
  }

  public OtpValidateClientResponse createOtpValidateClientResponse() {
    return OtpValidateClientResponse.builder()
        .totalResults(totalResults)
        .resources(Collections.singletonList(OtpResource.builder().returnCode(returnCode).build()))
        .build();
  }

}
