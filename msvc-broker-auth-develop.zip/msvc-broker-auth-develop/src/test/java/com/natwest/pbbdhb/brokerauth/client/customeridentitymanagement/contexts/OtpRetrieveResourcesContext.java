package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse.OtpRetrieveResources;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class OtpRetrieveResourcesContext {

  @Default
  private String id = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  public static OtpRetrieveResourcesContext.OtpRetrieveResourcesContextBuilder getOtpResourcesBuilder() {
    return OtpRetrieveResourcesContext.builder()
        .id("7d2b3b4a-421c-4726-bc49-19645dbe047c");
  }

  public OtpRetrieveResources getOtpResources() {
    return OtpRetrieveResources.builder()
        .id(id)
        .build();
  }

  public ObjectNode getOtpResourcesPayload() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("id", id);
    return payload;
  }
}