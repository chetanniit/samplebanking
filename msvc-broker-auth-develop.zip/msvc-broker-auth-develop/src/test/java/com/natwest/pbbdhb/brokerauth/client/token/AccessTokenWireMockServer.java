package com.natwest.pbbdhb.brokerauth.client.token;

import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static java.lang.String.format;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.http.Body;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

public class AccessTokenWireMockServer {

  // request parameters
  private static final String CLIENT_ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:at-bearer";
  private static final String CLIENT_ASSERTION = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";

  private static final String SCOPE = "napoli-pdg:all";
  private static final String GRANT_TYPE = "client_credentials";
  private static final String CLIENT = "a3ir203_a2ir101_a5ir210_ubn_f10js_napoliservicemock_client";
  private static final String CORRELATION_HEADER = "X-Correlation-ID";
  private static final String INTERNAL_CORRELATION_HEADER = "X-Request-ID";
  private static final String CORRELATION_ID = "e822be7a-3773-4408-8b74-0c8e9f2fb058";
  private static final String INTERNAL_CORRELATION_ID = "712a5c03-e596-4eb8-afda-3bdfe3cbe974";

  // access token parameters
  private static final String EXPECTED_ACCESS_TOKEN = "stub-token-abcdef-123456";
  private static final Integer EXPECTED_EXPIRES_IN = 599;
  private static final String EXPECTED_TOKEN_TYPE = "Bearer";

  // access token URL path
  private static final String EXPECTED_ACCESS_TOKEN_POST_PATH = "/nwb-token-path/token.oauth2";

  // error parameters
  private static final String ERROR_TYPE = "invalid_client";
  private static final String ERROR_DESCRIPTION = "Invalid client or client credentials.";


  /**
   * URL encode supplied string
   *
   * @param value - string value to be encoded
   * @return - URL encoded string
   */
  private static String encode(String value) {
    try {
      return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
    } catch (UnsupportedEncodingException ex) {
      throw new RuntimeException(ex.getCause());
    }
  }

  /**
   * Define a request-response mapping for an access token request.
   *
   * @param response Payload to be returned.
   * @return Mapping to be passed to {@code WireMock.stubFor()}.
   */
  public static MappingBuilder mappingAccessTokenRequest(ResponseDefinitionBuilder response) {
    return mappingForAccessTokenRequest(response);
  }

  private static MappingBuilder mappingForAccessTokenRequest(ResponseDefinitionBuilder response) {
    return WireMock
        .post(WireMock.urlPathEqualTo(EXPECTED_ACCESS_TOKEN_POST_PATH))
        .withHeader(HttpHeaders.CONTENT_TYPE, containing("application/x-www-form-urlencoded"))
        .willReturn(response);
  }

  static ResponseDefinitionBuilder jsonResponse(HttpStatus status, ObjectNode body) {
    return WireMock.status(status.value())
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        .withBody(body.toString());
  }

  /**
   * Builder of access token response payloads.
   *
   * @return An {@link ObjectNode} for the access token response payloads.
   */
  public static ObjectNode getAccessTokenResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("access_token", EXPECTED_ACCESS_TOKEN);
    payload.put("token_type", EXPECTED_TOKEN_TYPE);
    payload.put("expires_in", EXPECTED_EXPIRES_IN);
    return payload;
  }

  /**
   * Builder of access token error response payloads.
   *
   * @return An {@link ObjectNode} for the error response payloads.
   */
  public static ObjectNode getErrorResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("error_description", ERROR_DESCRIPTION);
    payload.put("error", ERROR_TYPE);
    return payload;
  }

  /**
   * Define a verifier request pattern for an access token request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForAccessTokenRequest() {
    return WireMock
        .postRequestedFor(WireMock.urlPathMatching(EXPECTED_ACCESS_TOKEN_POST_PATH))
        .withHeader(CORRELATION_HEADER, WireMock.equalTo(CORRELATION_ID))
        .withHeader(INTERNAL_CORRELATION_HEADER, WireMock.equalTo(INTERNAL_CORRELATION_ID))
        .withHeader("Content-Type", WireMock.containing("application/x-www-form-urlencoded"))
        .withRequestBody(WireMock.containing(format("scope=%s", encode(SCOPE))))
        .withRequestBody(
            WireMock.containing(format("client_assertion=%s", encode(CLIENT_ASSERTION))))
        .withRequestBody(
            WireMock.containing(
                format("client_assertion_type=%s", encode(CLIENT_ASSERTION_TYPE))))
        .withRequestBody(WireMock.containing(format("client_id=%s", encode(CLIENT))))
        .withRequestBody(WireMock.containing(format("grant_type=%s", encode(GRANT_TYPE))));
  }

}
