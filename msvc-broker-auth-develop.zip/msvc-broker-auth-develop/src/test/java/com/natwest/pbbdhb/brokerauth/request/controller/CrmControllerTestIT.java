package com.natwest.pbbdhb.brokerauth.request.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.brokerauth.service.crm.CrmService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;

@ActiveProfiles(profiles = {"int", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CrmControllerTestIT {

  private final static String BROKER_DETAILS = "/broker/details/12345";
  private final static String ADMIN_DETAILS = "/admin/details/12345";
  private final static String BROKER_ASSOCIATIONS = "/broker/associations/12345";
  private final static String BROKER_UNASSOCIATIONS = "/broker/unassociations/12345";
  private final static String ADMIN_ASSOCIATIONS = "/admin/associations/12345";
  private final static String ASSOCIATION_BROKER_TO_BROKER = "/broker/association/12345/broker/67890";
  private final static String UNASSOCIATION_BROKER_TO_BROKER = "/broker/unassociation/12345/broker/67890";
  private final static String ASSOCIATION_BROKER_TO_ADMIN = "/broker/association/12345/admin/67890";
  private final static String UNASSOCIATION_BROKER_TO_ADMIN = "/broker/unassociation/12345/admin/67890";
  public static final String USERNAME = "12345";
  public static final String ANOTHER_USERNAME = "67890";

  @MockBean
  CrmService crmService;

  @LocalServerPort
  int port;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Value("${server.servlet.context-path}")
  String contextPath;

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("mortgages/v1/msvc-broker-auth/crm")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header("iam-claimsetjwt", JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Get Broker Details Cases")
  class GetBrokerDetailsCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
          .get(BROKER_DETAILS)
          .then().log().all();

      Mockito.verify(crmService, times(1)).getBrokerDetails(eq(USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(crmService)
          .getBrokerDetails(eq(USERNAME));

      givenRequestToController()
          .get(BROKER_DETAILS)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
          .getBrokerDetails(eq(USERNAME));
    }
  }

  @Nested
  @DisplayName("Get Admin Details Cases")
  class GetAdminDetailsCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .get(ADMIN_DETAILS)
              .then().log().all();

      Mockito.verify(crmService, times(1)).getAdminDetails(eq(USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .getAdminDetails(eq(USERNAME));

      givenRequestToController()
              .get(ADMIN_DETAILS)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .getAdminDetails(eq(USERNAME));
    }
  }

  @Nested
  @DisplayName("Get Broker Associations Cases")
  class GetBrokerAssociationsCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .get(BROKER_ASSOCIATIONS)
              .then().log().all();

      Mockito.verify(crmService, times(1)).getBrokerAssociations(eq(USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .getBrokerAssociations(eq(USERNAME));

      givenRequestToController()
              .get(BROKER_ASSOCIATIONS)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .getBrokerAssociations(eq(USERNAME));
    }
  }

  @Nested
  @DisplayName("Get Broker UnAssociations Cases")
  class GetBrokerUnAssociationsCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .get(BROKER_UNASSOCIATIONS)
              .then().log().all();

      Mockito.verify(crmService, times(1)).getBrokerUnAssociations(eq(USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .getBrokerUnAssociations(eq(USERNAME));

      givenRequestToController()
              .get(BROKER_UNASSOCIATIONS)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .getBrokerUnAssociations(eq(USERNAME));
    }
  }

  @Nested
  @DisplayName("Get Admin Associations Cases")
  class GetAdminAssociationsCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .get(ADMIN_ASSOCIATIONS)
              .then().log().all();

      Mockito.verify(crmService, times(1)).getAdminAssociations(eq(USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .getAdminAssociations(eq(USERNAME));

      givenRequestToController()
              .get(ADMIN_ASSOCIATIONS)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .getAdminAssociations(eq(USERNAME));
    }
  }

  @Nested
  @DisplayName("Associate Broker To Broker Cases")
  class AssociateBrokerToBrokerCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .post(ASSOCIATION_BROKER_TO_BROKER)
              .then().log().all();

      Mockito.verify(crmService, times(1)).associateBrokerToBroker(eq(USERNAME), eq(ANOTHER_USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .associateBrokerToBroker(eq(USERNAME), eq(ANOTHER_USERNAME));

      givenRequestToController()
              .post(ASSOCIATION_BROKER_TO_BROKER)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .associateBrokerToBroker(eq(USERNAME), eq(ANOTHER_USERNAME));
    }
  }

  @Nested
  @DisplayName("UnAssociate Broker To Broker Cases")
  class UnAssociateBrokerToBrokerCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .post(UNASSOCIATION_BROKER_TO_BROKER)
              .then().log().all();

      Mockito.verify(crmService, times(1)).unAssociateBrokerToBroker(eq(USERNAME), eq(ANOTHER_USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .unAssociateBrokerToBroker(eq(USERNAME), eq(ANOTHER_USERNAME));

      givenRequestToController()
              .post(UNASSOCIATION_BROKER_TO_BROKER)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .unAssociateBrokerToBroker(eq(USERNAME), eq(ANOTHER_USERNAME));
    }
  }

  @Nested
  @DisplayName("Associate Broker To Admin Cases")
  class AssociateBrokerToAdminCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .post(ASSOCIATION_BROKER_TO_ADMIN)
              .then().log().all();

      Mockito.verify(crmService, times(1)).associateBrokerToAdmin(eq(USERNAME), eq(ANOTHER_USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .associateBrokerToAdmin(eq(USERNAME), eq(ANOTHER_USERNAME));

      givenRequestToController()
              .post(ASSOCIATION_BROKER_TO_ADMIN)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .associateBrokerToAdmin(eq(USERNAME), eq(ANOTHER_USERNAME));
    }
  }

  @Nested
  @DisplayName("UnAssociate Broker To Admin Cases")
  class UnAssociateBrokerToAdminCases {

    @Test
    void shouldCallDownstreamServices() {
      givenRequestToController()
              .post(UNASSOCIATION_BROKER_TO_ADMIN)
              .then().log().all();

      Mockito.verify(crmService, times(1)).unAssociateBrokerToAdmin(eq(USERNAME), eq(ANOTHER_USERNAME));
    }

    @Test
    void shouldReturnServerErrorIfCrmServiceThrowsRemoteFailure() {
      doThrow(new RemoteRequestFailedException(
              "Something went wrong"))
              .when(crmService)
              .unAssociateBrokerToAdmin(eq(USERNAME), eq(ANOTHER_USERNAME));

      givenRequestToController()
              .post(UNASSOCIATION_BROKER_TO_ADMIN)
              .then().log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(crmService, times(1))
              .unAssociateBrokerToAdmin(eq(USERNAME), eq(ANOTHER_USERNAME));
    }
  }

}
