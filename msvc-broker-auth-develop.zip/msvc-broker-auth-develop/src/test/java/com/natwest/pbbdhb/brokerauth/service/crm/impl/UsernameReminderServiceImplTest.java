package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderResponse;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestClientException;
import org.yaml.snakeyaml.util.UriEncoder;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.time.LocalDate;

import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.aUsernameReminderRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsernameReminderServiceImplTest {

  @InjectMocks
  private UsernameReminderServiceImpl usernameReminderService;

  @Mock
  private CRMClient crmClient;

  @Mock
  private OAuthTokenService oauthTokenService;

  private static final String USERNAME_REMINDER_ENDPOINT = "http://localhost/mbs_ReadUsernameReminder(mbs_emailAddress='%s',mbs_lastName='%s',mbs_dateOfBirth='%s')";
  private static final String SUCCESS_MESSAGE = "Broker Admin Record Identified Successfully.";
  private static final String UNSUCCESS_MESSAGE = "Broker / Broker Admin Record not found, contact LiveTalk.";
  private static final UsernameReminderResponse successfulUsernameReminderResponse = UsernameReminderResponse.builder()
      .usernameIdentified(true).message(SUCCESS_MESSAGE).build();
  private static final UsernameReminderResponse unsuccessfulUsernameReminderResponse = UsernameReminderResponse.builder()
          .usernameIdentified(false).message(UNSUCCESS_MESSAGE).build();
  private static final String BROKER_EMAIL_ADDRESS = "test@test.com";
  private static final String BROKER_LAST_NAME = "Test Space";
  private static final LocalDate BROKER_DATE_OF_BIRTH = LocalDate.of(1980,1,1);

  @BeforeEach
  void setup() throws NoSuchFieldException, IllegalAccessException {
    Field fieldUsernameReminderEndpoint = usernameReminderService.getClass().getDeclaredField("usernameReminderEndpoint");
    fieldUsernameReminderEndpoint.setAccessible(true);
    fieldUsernameReminderEndpoint.set(usernameReminderService, USERNAME_REMINDER_ENDPOINT);

  }

  @Test
  void shouldGetUsernameIdentifiedTrueWhenUserIsFound() {
    when(crmClient.get(
                    eq(UriEncoder.encode(String.format(USERNAME_REMINDER_ENDPOINT, BROKER_EMAIL_ADDRESS,
                            BROKER_LAST_NAME, BROKER_DATE_OF_BIRTH))), any()))
            .thenReturn(successfulUsernameReminderResponse);

    UsernameReminderResponse response = usernameReminderService.getUsernameReminder(aUsernameReminderRequest());

    assertNotNull(response);
    assertTrue(response.getUsernameIdentified());
    assertEquals(SUCCESS_MESSAGE, response.getMessage());
  }

  @Test
  void shouldGet404WhenUserIsNotFound() throws UnsupportedEncodingException {
    doThrow(new UserNotFoundException("User not found for details UsernameReminderRequest(email=test@test.com, lastName=Test Space, dateOfBirth=1980-01-01)"))
            .when(crmClient).get(any(), any());

    UserNotFoundException exception = assertThrows(UserNotFoundException.class, () ->
            usernameReminderService.getUsernameReminder(aUsernameReminderRequest()));

    assertEquals("User not found for details UsernameReminderRequest(email=test@test.com, lastName=Test Space, dateOfBirth=1980-01-01)", exception.getMessage());
  }

    @Test
  void shouldHandleExceptionWhenGetUsernameReminder() {
    doThrow(new RestClientException("CRM client error"))
        .when(crmClient).get(any(), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () ->
            usernameReminderService.getUsernameReminder(aUsernameReminderRequest()));
    assertEquals("getUsernameReminder: Get Username Reminder request failed for UsernameReminderRequest(email=test@test.com, lastName=Test Space, dateOfBirth=1980-01-01)", exception.getMessage());
  }

}
