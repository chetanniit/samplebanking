package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ChangePasswordClientRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;

@Getter
@ToString
@Builder
public class ChangePasswordClientContext {

  @Default
  private String customerId = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Default
  private String currentPassword = "Password123";

  @Default
  private String newPassword = "Password456";

  @Default
  private List<String> schemas = Collections.singletonList(
      "urn:pingidentity:scim:api:messages:2.0:PasswordUpdateRequest");

  public ChangePasswordClientRequest createSetPasswordClientRequest() {
    return ChangePasswordClientRequest.builder()
        .currentPassword(currentPassword)
        .newPassword(newPassword)
        .schemas(schemas)
        .build();
  }

}
