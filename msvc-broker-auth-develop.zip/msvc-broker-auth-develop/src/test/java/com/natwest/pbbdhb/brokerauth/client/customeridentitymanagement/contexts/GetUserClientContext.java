package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse.GetUserResources;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class GetUserClientContext {

  @Default
  private List<GetUserResourcesContext> userResources = Collections.singletonList(
      GetUserResourcesContext.getUserResourcesBuilder().build());

  public GetUserClientResponse createGetUserClientResponse() {
    List<GetUserResources> getUserResources = Optional.ofNullable(userResources)
        .orElse(Collections.emptyList())
        .stream()
        .map(GetUserResourcesContext::getUserResources)
        .collect(Collectors.toList());

    return GetUserClientResponse.builder()
        .resources(getUserResources)
        .build();
  }

  public GetUserClientResponse.GetUserClientResponseBuilder createGetUserClientResponseBuilder() {
    List<GetUserResources> getUserResources = Optional.ofNullable(userResources)
        .orElse(Collections.emptyList())
        .stream()
        .map(GetUserResourcesContext::getUserResources)
        .collect(Collectors.toList());

    return GetUserClientResponse.builder()
        .resources(getUserResources);
  }

  public ObjectNode getValidGetUserClientResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(userResources.stream()
            .map(GetUserResourcesContext::getUserResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode getUserClientResponseReturnsMultipleUsers() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(userResources.stream()
            .map(GetUserResourcesContext::getUserResourcesPayload)
            .collect(Collectors.toList())
        )
        .addAll(userResources.stream()
            .map(GetUserResourcesContext::getUserResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode getUserClientResponseReturnsNoUsers() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode();

    payload.set("Resources", resources);
    return payload;
  }
}
