package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetCustomerClientResponse.GetCustomerResources;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class GetCustomerResourcesContext {

  @Default
  private String id = "TestId";

  @Default
  private BrokerTypeModel brokerType = BrokerTypeModel.BROKER;

  public static GetCustomerResourcesContext.GetCustomerResourcesContextBuilder getCustomerResourcesBuilder() {
    return GetCustomerResourcesContext.builder()
        .id("TestId")
        .brokerType(BrokerTypeModel.BROKER);
  }

  public GetCustomerResources getCustomerResources() {
    return GetCustomerResources.builder()
        .id(id)
        .brokerType(brokerType)
        .build();
  }

  public ObjectNode getCustomerResourcesPayload() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("id", id);
    payload.put("personaidentifiertype", brokerType.getValue());
    return payload;
  }
}