package com.natwest.pbbdhb.brokerauth.request.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.UserContext;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UserCreateRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Testing the Registration business domain model mapping.
 */
class RegistrationRequestMapperTest {

  @Nested
  @DisplayName("toUserCreateRequestModel Cases")
  class ToUserCreateRequestModelCases {

    @Test
    void toUserCreateRequestModel() {
      UserCreateRequest requestModel = UserContext.builder().build().createUserCreateRequest();

      UserCreateRequestModel domainModel = RegistrationRequestMapper.toUserCreateRequestModel(
          requestModel);

      assertEquals(domainModel.getFirstname(), requestModel.getFirstname());
      assertEquals(domainModel.getLastname(), requestModel.getLastname());
      assertEquals(domainModel.getEmail(), requestModel.getEmail());
      assertEquals(domainModel.getUsername(), requestModel.getUsername());
      assertEquals(domainModel.getBrokerType().toString(), requestModel.getBrokerType().toString());
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          RegistrationRequestMapper.toUserCreateRequestModel(null)
      );
    }
  }

  @Nested
  @DisplayName("toActivationCodeResponse Cases")
  class ToActivationCodeResponseCases {

    @Test
    void toActivationCodeResponseModel() {

      String code = OtpContext.builder().build().getOtpCode();

      ActivationCodeResponse response = RegistrationRequestMapper.toActivationCodeResponse(code);

      assertEquals(response.getCode(), code);
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          RegistrationRequestMapper.toActivationCodeResponse(null)
      );
    }
  }
}