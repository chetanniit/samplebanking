package com.natwest.pbbdhb.brokerauth.service.crm.impl;

import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetailsCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetailsPaymentPath;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.PrincipalFcaFirm;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;
import com.natwest.pbbdhb.brokerauth.service.crm.CRMClient;
import com.natwest.pbbdhb.brokerauth.service.crm.OAuthTokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestClientException;

import java.lang.reflect.Field;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FirmDetailsServiceImplTest {

  private static final String FCA_NUMBER = "fcaNumber";
  private static final String PRINCIPAL_FIRM_NAME_1 = "principalFirmFcaNumber1";
  private static final String PRINCIPAL_FIRM_FCA_NUMBER_1 = "principalFirmFcaNumber1";
  private static final String PRINCIPAL_FIRM_NAME_2 = "principalFirmFcaNumber2";
  private static final String PRINCIPAL_FIRM_FCA_NUMBER_2 = "principalFirmFcaNumber2";
  private static final String FIRM_TYPE = "firmType";
  private static final String ALTERNATIVE_TRADING_NAME_1 = "alternativeTradingName1";
  private static final String ALTERNATIVE_TRADING_NAME_2 = "alternativeTradingName2";
  private static final String PAYMENT_PATH_ID_1 = "paymentPathId1";
  private static final String PAYMENT_PATH_NAME_1 = "paymentPathName1";
  private static final String PAYMENT_PATH_ID_2 = "paymentPathId2";
  private static final String PAYMENT_PATH_NAME_2 = "paymentPathName2";

  @InjectMocks
  private FirmDetailsServiceImpl firmDetailsService;

  @Mock
  private CRMClient crmClient;

  @Mock
  private OAuthTokenService oauthTokenService;

  private static final String USERNAME = "12345";
  private static final String FIRM_DETAILS_ENDPOINT = "http://localhost/mbs_getfirmdetails(mbs_fcanumber='%s')";
  private static final FirmDetailsCoreResponse firmDetailsCoreResponse = FirmDetailsCoreResponse.builder()
      .firmType(FIRM_TYPE)
      .alternativeTradingNames(Arrays.asList(
          TradingName.builder()
              .name(ALTERNATIVE_TRADING_NAME_1)
              .build(),
          TradingName.builder()
              .name(ALTERNATIVE_TRADING_NAME_2)
              .build()
      ))
      .paymentPaths(Arrays.asList(
          FirmDetailsPaymentPath.builder()
              .name(PAYMENT_PATH_NAME_1)
              .paymentId(PAYMENT_PATH_ID_1)
              .build(),
          FirmDetailsPaymentPath.builder()
              .name(PAYMENT_PATH_NAME_2)
              .paymentId(PAYMENT_PATH_ID_2)
              .build()))
      .principalFcaFirms(Arrays.asList(
          PrincipalFcaFirm.builder()
              .fcaNumber(PRINCIPAL_FIRM_FCA_NUMBER_1)
              .name(PRINCIPAL_FIRM_NAME_1)
              .build(),
          PrincipalFcaFirm.builder()
              .fcaNumber(PRINCIPAL_FIRM_FCA_NUMBER_2)
              .name(PRINCIPAL_FIRM_NAME_2)
              .build()
      ))
      .build();

  @BeforeEach
  void setup() throws NoSuchFieldException, IllegalAccessException {
    Field fieldFirmDetailsEndpoint = firmDetailsService.getClass().getDeclaredField("firmDetailsEndpoint");
    fieldFirmDetailsEndpoint.setAccessible(true);
    fieldFirmDetailsEndpoint.set(firmDetailsService, FIRM_DETAILS_ENDPOINT);

  }

  @Test
  void shouldGetFirmDetails() {
    when(crmClient.get(eq(String.format(FIRM_DETAILS_ENDPOINT, FCA_NUMBER)), any())).thenReturn(firmDetailsCoreResponse);

    FirmDetailsResponse response = firmDetailsService.getFirmDetails(FCA_NUMBER);

    assertNotNull(response);
    assertEquals(FCA_NUMBER, response.getFcaNumber());
  }

  @Test
  void shouldHandleExceptionWhenGetFirmDetails() {
    doThrow(new RestClientException("CRM client error"))
        .when(crmClient).get(any(), any());

    RemoteRequestFailedException exception = assertThrows(RemoteRequestFailedException.class, () -> firmDetailsService.getFirmDetails(FCA_NUMBER));
    assertEquals("getFirmDetails: Request failed for fcaNumber fcaNumber", exception.getMessage());
  }

}
