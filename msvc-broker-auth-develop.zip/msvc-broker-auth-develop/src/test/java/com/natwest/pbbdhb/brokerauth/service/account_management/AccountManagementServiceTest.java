package com.natwest.pbbdhb.brokerauth.service.account_management;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.AccountManagementContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordChangeContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordResetContext;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationResponseModel;
import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionLockedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionNotFoundException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionValidateException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AccountManagementServiceTest {

  @Mock
  CustomerIdentityManagementClient customerIdentityManagementClient;

  @Nested
  @DisplayName("Retrieve Security Questions")
  class RetrieveSecurityQuestionsCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToGetQuestions() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      when(
          customerIdentityManagementClient.getSecurityQuestions(accessToken, context.getParentId()))
          .thenReturn(context.createSecurityQuestionsFetchResponseModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      final SecurityQuestionsFetchResponseModel securityQuestions = service.retrieveSecurityQuestions(
          accessToken, context.createSecurityQuestionsFetchRequestModel());
      assertThat(securityQuestions).isEqualTo(context.createSecurityQuestionsFetchResponseModel());

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).getSecurityQuestions(
          accessToken,
          context.getParentId());
    }

    @Test
    void shouldThrowRemoteRequestFailedExceptionIfClientThrowsWhenGettingUser() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      doThrow(new RemoteRequestFailedException("Request failed"))
          .when(customerIdentityManagementClient).getUser(any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.retrieveSecurityQuestions(accessToken,
              context.createSecurityQuestionsFetchRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
    }

    @Test
    void shouldThrowUserNotFoundExceptionIfClientThrowsWhenGettingUser() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      doThrow(new UserNotFoundException("User not found"))
          .when(customerIdentityManagementClient).getUser(any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.retrieveSecurityQuestions(accessToken,
              context.createSecurityQuestionsFetchRequestModel()))
          .isInstanceOf(UserNotFoundException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
    }

    @Test
    void shouldThrowRemoteRequestFailedExceptionIfClientThrowsWhenGettingQuestions() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new RemoteRequestFailedException("Request failed"))
          .when(customerIdentityManagementClient).getSecurityQuestions(any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.retrieveSecurityQuestions(accessToken,
              context.createSecurityQuestionsFetchRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);
      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).getSecurityQuestions(
          accessToken,
          context.getParentId());
    }

    @Test
    void shouldThrowSecurityQuestionNotFoundExceptionIfClientThrowsWhenGettingQuestions() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new SecurityQuestionNotFoundException("Questions not found"))
          .when(customerIdentityManagementClient).getSecurityQuestions(any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.retrieveSecurityQuestions(accessToken,
              context.createSecurityQuestionsFetchRequestModel()))
          .isInstanceOf(SecurityQuestionNotFoundException.class);
      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).getSecurityQuestions(
          accessToken,
          context.getParentId());
    }
  }

  @Nested
  @DisplayName("Change Security Questions")
  class ChangeSecurityQuestionsCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToChangeQuestions() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      when(
          customerIdentityManagementClient.getSecurityQuestions(accessToken, context.getParentId()))
          .thenReturn(context.createSecurityQuestionsFetchResponseModel());
      lenient().doNothing().when(
              customerIdentityManagementClient)
          .setSecurityQuestions(accessToken, context.createRandomSecurityQuestionsRequestModel(), context.getQuestionId());
      lenient().doNothing().when(
              customerIdentityManagementClient)
          .setSecurityQuestions(accessToken, context.createSecurityQuestionsRequestModel(), context.getQuestionId());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);
      service.changeSecurityQuestions(accessToken,
          context.createSecurityQuestionsChangeRequestModel());

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken, context.getUsername());
      verify(customerIdentityManagementClient, times(1)).getSecurityQuestions(
          any(), any());
      verify(customerIdentityManagementClient, times(2)).setSecurityQuestions(
          any(), any(), any());
    }

    @Test
    void shouldThrowRemoteRequestFailedExceptionIfClientThrowsWhenChangingQuestions() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      when(
          customerIdentityManagementClient.getSecurityQuestions(accessToken, context.getParentId()))
          .thenReturn(context.createSecurityQuestionsFetchResponseModel());
      doThrow(new RemoteRequestFailedException("Request failed"))
          .when(customerIdentityManagementClient).setSecurityQuestions(any(), any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.changeSecurityQuestions(accessToken,
              context.createSecurityQuestionsChangeRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);
      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken, context.getUsername());
      verify(customerIdentityManagementClient, times(1)).getSecurityQuestions(
          any(), any());
      verify(customerIdentityManagementClient, times(1)).setSecurityQuestions(
          any(), any(), any());
    }
  }

  @Nested
  @DisplayName("Validate Security Answers")
  class ValidateSecurityAnswersCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToValidateAnswers() {
      final AccountManagementContext context = AccountManagementContext.builder().build();
      final OtpContext otpContext = OtpContext.builder()
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new LoginFailedException("Invalid credentials"))
          .when(customerIdentityManagementClient).login(any(), any());
      when(customerIdentityManagementClient.retrieveOTP(accessToken, context.getUsername()))
          .thenReturn(otpContext.createOtpRetrieveResponseModel());
      when(customerIdentityManagementClient.generateOTP(accessToken, otpContext.getOtpId()))
          .thenReturn(otpContext.createOtpGenerateResponseModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      final SecurityQuestionsValidationResponseModel result = service.validateSecurityAnswers(
          accessToken,
          context.createSecurityQuestionsValidationRequestModel());

      assertThat(result.getBrokerTypeModel()).isEqualTo(
          context.getBrokerType());
      assertThat(result.getOtpCode()).isEqualTo(
          otpContext.getActivationCode());

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
      verify(customerIdentityManagementClient, times(2)).validateSecurityQuestion(
          accessToken,
          context.createSecuritySingleQuestionsValidationRequestModel());
      verify(customerIdentityManagementClient, times(1)).retrieveOTP(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).generateOTP(
          accessToken,
          otpContext.getOtpId());
      verify(customerIdentityManagementClient, times(1)).updateOTP(
          accessToken,
          otpContext.createOtpUpdateRequestModel());
    }

    @Test
    void shouldCallCustomerIdentityManagementClientToValidateAnswersWhenPasswordIsExpired() {
      final AccountManagementContext context = AccountManagementContext.builder().build();
      final OtpContext otpContext = OtpContext.builder()
              .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
              .thenReturn(context.createGetUserResponseModel());
      doThrow(new PasswordExpiredException("Password expired"))
              .when(customerIdentityManagementClient).login(any(), any());
      when(customerIdentityManagementClient.retrieveOTP(accessToken, context.getUsername()))
              .thenReturn(otpContext.createOtpRetrieveResponseModel());
      when(customerIdentityManagementClient.generateOTP(accessToken, otpContext.getOtpId()))
              .thenReturn(otpContext.createOtpGenerateResponseModel());

      AccountManagementService service = new AccountManagementService(
              customerIdentityManagementClient);

      final SecurityQuestionsValidationResponseModel result = service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel());

      assertThat(result.getBrokerTypeModel()).isEqualTo(
              context.getBrokerType());
      assertThat(result.getOtpCode()).isEqualTo(
              otpContext.getActivationCode());

      verify(customerIdentityManagementClient, times(1)).getUser(
              accessToken,
              context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
              any(),
              any());
      verify(customerIdentityManagementClient, times(2)).validateSecurityQuestion(
              accessToken,
              context.createSecuritySingleQuestionsValidationRequestModel());
      verify(customerIdentityManagementClient, times(1)).retrieveOTP(
              accessToken,
              context.getUsername());
      verify(customerIdentityManagementClient, times(1)).generateOTP(
              accessToken,
              otpContext.getOtpId());
      verify(customerIdentityManagementClient, times(1)).updateOTP(
              accessToken,
              otpContext.createOtpUpdateRequestModel());
    }


    @Test
    void shouldThrowIfUserNotFound() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      doThrow(new UserNotFoundException("User not found"))
          .when(customerIdentityManagementClient).getUser(any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(UserNotFoundException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
    }

    @Test
    void shouldThrowIfAccountIsLocked() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new AccountLockedException("Account locked"))
          .when(customerIdentityManagementClient).login(any(), any());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(AccountLockedException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
    }

    @Test
    void shouldThrowIfAnswersAreNotValid() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new SecurityQuestionValidateException("Invalid answer"))
          .when(customerIdentityManagementClient).validateSecurityQuestion(
              accessToken,
              context.createSecuritySingleQuestionsValidationRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(SecurityQuestionValidateException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
      verify(customerIdentityManagementClient, times(1)).validateSecurityQuestion(
          accessToken,
          context.createSecuritySingleQuestionsValidationRequestModel());
    }

    @Test
    void shouldThrowIfQuestionsAreLocked() {
      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new SecurityQuestionLockedException("Questions locked"))
          .when(customerIdentityManagementClient).validateSecurityQuestion(
              accessToken,
              context.createSecuritySingleQuestionsValidationRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(SecurityQuestionLockedException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
      verify(customerIdentityManagementClient, times(1)).validateSecurityQuestion(
          accessToken,
          context.createSecuritySingleQuestionsValidationRequestModel());
    }

    @Test
    void shouldThrowIfOtpNotFound() {

      final AccountManagementContext context = AccountManagementContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new LoginFailedException("Invalid credentials"))
          .when(customerIdentityManagementClient).login(any(), any());
      doThrow(new InvalidDataResponseException("OTP not found"))
          .when(customerIdentityManagementClient).retrieveOTP(accessToken, context.getUsername());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(InvalidDataResponseException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
      verify(customerIdentityManagementClient, times(2)).validateSecurityQuestion(
          accessToken,
          context.createSecuritySingleQuestionsValidationRequestModel());
      verify(customerIdentityManagementClient, times(1)).retrieveOTP(
          accessToken,
          context.getUsername());
    }

    @Test
    void shouldThrowIfOtpGenerateFails() {
      final AccountManagementContext context = AccountManagementContext.builder().build();
      final OtpContext otpContext = OtpContext.builder()
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new LoginFailedException("Invalid credentials"))
          .when(customerIdentityManagementClient).login(any(), any());
      when(customerIdentityManagementClient.retrieveOTP(accessToken, context.getUsername()))
          .thenReturn(otpContext.createOtpRetrieveResponseModel());
      doThrow(new RemoteRequestFailedException("OTP generation failed"))
          .when(customerIdentityManagementClient).generateOTP(accessToken, otpContext.getOtpId());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
      verify(customerIdentityManagementClient, times(2)).validateSecurityQuestion(
          accessToken,
          context.createSecuritySingleQuestionsValidationRequestModel());
      verify(customerIdentityManagementClient, times(1)).retrieveOTP(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).generateOTP(
          accessToken,
          otpContext.getOtpId());
    }

    @Test
    void shouldThrowIfOtpUpdateFails() {
      final AccountManagementContext context = AccountManagementContext.builder().build();
      final OtpContext otpContext = OtpContext.builder()
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(context.createGetUserResponseModel());
      doThrow(new LoginFailedException("Invalid credentials"))
          .when(customerIdentityManagementClient).login(any(), any());
      when(customerIdentityManagementClient.retrieveOTP(accessToken, context.getUsername()))
          .thenReturn(otpContext.createOtpRetrieveResponseModel());
      when(customerIdentityManagementClient.generateOTP(accessToken, otpContext.getOtpId()))
          .thenReturn(otpContext.createOtpGenerateResponseModel());
      doThrow(new RemoteRequestFailedException("OTP update failed"))
          .when(customerIdentityManagementClient)
          .updateOTP(accessToken, otpContext.createOtpUpdateRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(
          () -> service.validateSecurityAnswers(
              accessToken,
              context.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).login(
          any(),
          any());
      verify(customerIdentityManagementClient, times(2)).validateSecurityQuestion(
          accessToken,
          context.createSecuritySingleQuestionsValidationRequestModel());
      verify(customerIdentityManagementClient, times(1)).retrieveOTP(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient, times(1)).generateOTP(
          accessToken,
          otpContext.getOtpId());
      verify(customerIdentityManagementClient, times(1)).updateOTP(
          accessToken,
          otpContext.createOtpUpdateRequestModel());
    }
  }

  @Nested
  @DisplayName("Validate OTP")
  class ValidateOtpCases {

    @Test
    void shouldCallCustomerIdentityManagementClient() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      service.validateOtp(accessToken, context.createOtpValidateRequestModel());

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfUsernameOrOtpIsInvalid() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.INVALID_CREDENTIALS, "Invalid username or otp"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateOtp(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfOtpIsExpired() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.OTP_EXPIRED, "Expired otp"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateOtp(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfAccountIsLocked() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.ACCOUNT_LOCKED, "Account is locked"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateOtp(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfValidateOtpReturnsDifferentReturnCode() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.OTP_VALIDATION_FAILED, "Something went wrong"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateOtp(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowRemoteFailureIfClientThrowsRemoteFailure() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();
      assertThatThrownBy(() -> service.validateOtp(accessToken, otpValidateRequestModel
      )).isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }
  }

  @Nested
  @DisplayName("Reset Password")
  class ResetPasswordCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToResetPassword() {
      final PasswordResetContext context = PasswordResetContext.builder()
          .build();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();
      final OtpContext otpContext = OtpContext.builder()
          .otpStatus("Used")
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(accountManagementContext.createGetUserResponseModel());
      when(customerIdentityManagementClient.retrieveOTP(accessToken,
          context.getUsername())).thenReturn(otpContext.createOtpRetrieveResponseModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      service.passwordReset(
          accessToken,
          context.createPasswordResetRequestModel()
      );

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).validateOtp(accessToken,
          otpContext.createOtpValidateRequestModel());
      verify(customerIdentityManagementClient).setPassword(accessToken,
          context.createUserSetPasswordRequestModel());
      verify(customerIdentityManagementClient).retrieveOTP(accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).updateOTP(accessToken,
          otpContext.createOtpUpdateRequestModel());
    }

    @Test
    void shouldThrowIfUsernameOrOtpIsInvalid() {
      final PasswordResetContext context = PasswordResetContext.builder()
          .build();
      final OtpContext otpContext = OtpContext.builder()
          .otpStatus("Used")
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      doThrow(new OtpException(ErrorCode.INVALID_CREDENTIALS, "Invalid username or otp"))
          .when(customerIdentityManagementClient)
          .validateOtp(accessToken, otpContext.createOtpValidateRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordReset(
              accessToken,
              context.createPasswordResetRequestModel()))
          .isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          otpContext.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowIfUsernameIsNotFound() {
      final PasswordResetContext context = PasswordResetContext.builder()
          .build();
      final OtpContext otpContext = OtpContext.builder()
          .otpStatus("Used")
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      doThrow(new UserNotFoundException("User not found"))
          .when(customerIdentityManagementClient).getUser(accessToken, context.getUsername());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordReset(
              accessToken,
              context.createPasswordResetRequestModel()))
          .isInstanceOf(UserNotFoundException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).validateOtp(accessToken,
          otpContext.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowIfSetPasswordFails() {
      final PasswordResetContext context = PasswordResetContext.builder()
          .build();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();
      final OtpContext otpContext = OtpContext.builder()
          .otpStatus("Used")
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(accountManagementContext.createGetUserResponseModel());
      doThrow(new InvalidDetailsException("Invalid Password"))
          .when(customerIdentityManagementClient)
          .setPassword(accessToken, context.createUserSetPasswordRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordReset(
              accessToken,
              context.createPasswordResetRequestModel()))
          .isInstanceOf(InvalidDetailsException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).validateOtp(accessToken,
          otpContext.createOtpValidateRequestModel());
      verify(customerIdentityManagementClient).setPassword(accessToken,
          context.createUserSetPasswordRequestModel());
    }

    @Test
    void shouldThrowIfRetrieveOtpFails() {
      final PasswordResetContext context = PasswordResetContext.builder()
          .build();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();
      final OtpContext otpContext = OtpContext.builder()
          .otpStatus("Used")
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(accountManagementContext.createGetUserResponseModel());
      doThrow(new InvalidDataResponseException("Unable to retrieve OTP"))
          .when(customerIdentityManagementClient).retrieveOTP(accessToken, context.getUsername());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordReset(
              accessToken,
              context.createPasswordResetRequestModel()))
          .isInstanceOf(InvalidDataResponseException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).validateOtp(accessToken,
          otpContext.createOtpValidateRequestModel());
      verify(customerIdentityManagementClient).setPassword(accessToken,
          context.createUserSetPasswordRequestModel());
      verify(customerIdentityManagementClient).retrieveOTP(accessToken,
          context.getUsername());
    }

    @Test
    void shouldThrowIfUpdateOtpFails() {
      final PasswordResetContext context = PasswordResetContext.builder()
          .build();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();
      final OtpContext otpContext = OtpContext.builder()
          .otpStatus("Used")
          .otpType("OTP")
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(accountManagementContext.createGetUserResponseModel());
      when(customerIdentityManagementClient.retrieveOTP(accessToken,
          context.getUsername())).thenReturn(otpContext.createOtpRetrieveResponseModel());
      doThrow(new RemoteRequestFailedException("Unable to update OTP"))
          .when(customerIdentityManagementClient)
          .updateOTP(accessToken, otpContext.createUpdateRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordReset(
              accessToken,
              context.createPasswordResetRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).validateOtp(accessToken,
          otpContext.createOtpValidateRequestModel());
      verify(customerIdentityManagementClient).setPassword(accessToken,
          context.createUserSetPasswordRequestModel());
      verify(customerIdentityManagementClient).retrieveOTP(accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).updateOTP(accessToken,
          otpContext.createOtpUpdateRequestModel());
    }
  }

  @Nested
  @DisplayName("Change Password")
  class ChangePasswordCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToChangePassword() {
      final PasswordChangeContext context = PasswordChangeContext.builder()
          .build();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(accountManagementContext.createGetUserResponseModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      service.passwordChange(
          accessToken,
          context.createPasswordChangeRequestModel()
      );

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).changePassword(accessToken,
          context.createUserChangePasswordRequestModel());
    }

    @Test
    void shouldThrowIfUsernameIsNotFound() {
      final PasswordChangeContext context = PasswordChangeContext.builder()
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      doThrow(new UserNotFoundException("User not found"))
          .when(customerIdentityManagementClient).getUser(accessToken, context.getUsername());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordChange(
              accessToken,
              context.createPasswordChangeRequestModel()))
          .isInstanceOf(UserNotFoundException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
    }

    @Test
    void shouldThrowIfSetPasswordFails() {
      final PasswordChangeContext context = PasswordChangeContext.builder()
          .build();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername()))
          .thenReturn(accountManagementContext.createGetUserResponseModel());
      doThrow(new InvalidDetailsException("Invalid Password"))
          .when(customerIdentityManagementClient)
          .changePassword(accessToken, context.createUserChangePasswordRequestModel());

      AccountManagementService service = new AccountManagementService(
          customerIdentityManagementClient);

      assertThatThrownBy(() -> service
          .passwordChange(
              accessToken,
              context.createPasswordChangeRequestModel()))
          .isInstanceOf(InvalidDetailsException.class);

      verify(customerIdentityManagementClient, times(1)).getUser(
          accessToken,
          context.getUsername());
      verify(customerIdentityManagementClient).changePassword(accessToken,
          context.createUserChangePasswordRequestModel());
    }
  }
}
