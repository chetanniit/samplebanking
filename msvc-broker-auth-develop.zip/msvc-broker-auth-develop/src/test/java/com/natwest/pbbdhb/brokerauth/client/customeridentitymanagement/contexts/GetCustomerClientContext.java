package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetCustomerClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetCustomerClientResponse.GetCustomerResources;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class GetCustomerClientContext {

  @Default
  private List<GetCustomerResourcesContext> customerResources = Collections.singletonList(
      GetCustomerResourcesContext.getCustomerResourcesBuilder().build());

  public GetCustomerClientResponse createGetCustomerClientResponse() {
    List<GetCustomerResources> getCustomerResources = Optional.ofNullable(customerResources)
        .orElse(Collections.emptyList())
        .stream()
        .map(GetCustomerResourcesContext::getCustomerResources)
        .collect(Collectors.toList());

    return GetCustomerClientResponse.builder()
        .resources(getCustomerResources)
        .build();
  }

  public GetCustomerClientResponse.GetCustomerClientResponseBuilder createGetCustomerClientResponseBuilder() {
    List<GetCustomerResources> getCustomerResources = Optional.ofNullable(customerResources)
        .orElse(Collections.emptyList())
        .stream()
        .map(GetCustomerResourcesContext::getCustomerResources)
        .collect(Collectors.toList());

    return GetCustomerClientResponse.builder()
        .resources(getCustomerResources);
  }

  public ObjectNode getValidGetCustomerClientResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(customerResources.stream()
            .map(GetCustomerResourcesContext::getCustomerResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode getCustomerClientResponseReturnsMultipleCustomers() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(customerResources.stream()
            .map(GetCustomerResourcesContext::getCustomerResourcesPayload)
            .collect(Collectors.toList())
        )
        .addAll(customerResources.stream()
            .map(GetCustomerResourcesContext::getCustomerResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode getCustomerClientResponseReturnsNoCustomers() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode();

    payload.set("Resources", resources);
    return payload;
  }
}
