package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ActivateUserClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ActivateUserClientRequest.Operations;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.ActivateUserClientRequest.Operations.Values;
import java.util.Collections;
import java.util.List;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class ActivateUserClientContext {

  @Default
  public String customerId = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Default
  private String op = "replace";

  @Default
  private Boolean accountDisable = false;

  @Default
  private List<String> schemas = Collections.singletonList(
      "urn:ietf:params:scim:api:messages:2.0:PatchOp");

  public ActivateUserClientRequest createActivateUserClientRequest() {
    return ActivateUserClientRequest.builder()
        .schemas(schemas)
        .operations(Collections.singletonList(Operations.builder()
                .op(op)
                .value(Values.builder()
                    .accountDisable(accountDisable)
                    .build())
            .build()))
        .build();
  }


}
