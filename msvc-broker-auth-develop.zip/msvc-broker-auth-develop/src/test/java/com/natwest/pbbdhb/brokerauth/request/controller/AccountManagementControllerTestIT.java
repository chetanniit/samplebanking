package com.natwest.pbbdhb.brokerauth.request.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.AccountManagementContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordChangeContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordResetContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionLockedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionNotFoundException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionValidateException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import com.natwest.pbbdhb.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.brokerauth.service.account_management.AccountManagementService;
import com.natwest.pbbdhb.brokerauth.service.crm.BrokerDetailsService;
import com.natwest.pbbdhb.brokerauth.service.crm.FirmDetailsService;
import com.natwest.pbbdhb.brokerauth.service.crm.UsernameReminderService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

import java.time.LocalDate;
import java.util.Collections;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

@ActiveProfiles(profiles = {"int", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AccountManagementControllerTestIT {

  private final static String OTP_VALIDATION = "/otp-validation";
  private final static String PASSWORD_CHANGE = "/password-change";
  private final static String PASSWORD_RESET = "/password-reset";
  private final static String CHALLENGE_QUESTIONS = "/challenge-questions";
  private final static String CHALLENGE_ANSWERS = "/challenge-answers";
  private final static String CHANGE_QUESTIONS = "/change-questions";
  private final static String BROKER_DETAILS = "/broker-details";
  private final static String FIRM_DETAILS = "/firm-details";
  private final static String USERNAME_REMINDER = "/username-reminder";

  @MockBean
  AccountManagementService accountManagementService;
  @MockBean
  BrokerDetailsService brokerDetailsService;
  @MockBean
  FirmDetailsService firmDetailsService;
  @MockBean
  AccessTokenService accessTokenService;
  @MockBean
  UsernameReminderService usernameReminderService;
  @Mock
  AccountManagementController accountManagementController;

  @LocalServerPort
  int port;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Value("${server.servlet.context-path}")
  String contextPath;

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("mortgages/v1/msvc-broker-auth/account-management")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header("iam-claimsetjwt", JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Validate OTP Cases")
  class ValidateOtpCases {

    @Test
    void shouldCallDownstreamServices() {
      OtpContext context = OtpContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createOtpValidateRequest()))
          .contentType(ContentType.JSON)
          .post(OTP_VALIDATION)
          .then().log().all();

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateOtp(any(), any());

    }

    @Test
    void shouldReturnServerErrorIfActivationServiceThrowsRemoteFailure() {
      OtpContext context = OtpContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(accountManagementService)
          .validateOtp(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createOtpValidateRequest()))
          .contentType(ContentType.JSON)
          .post(OTP_VALIDATION)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateOtp(any(), any());

    }

    @Test
    void shouldReturnErrorIfOtpIsInvalid() {
      OtpContext context = OtpContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.INVALID_CREDENTIALS, "Invalid username or otp"))
          .when(accountManagementService).validateOtp(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createOtpValidateRequest()))
          .contentType(ContentType.JSON)
          .post(OTP_VALIDATION)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.INVALID_CREDENTIALS.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateOtp(any(), any());

    }

    @Test
    void shouldReturnErrorIfOtpExpired() {
      OtpContext context = OtpContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.OTP_EXPIRED, "Otp expired"))
          .when(accountManagementService).validateOtp(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createOtpValidateRequest()))
          .contentType(ContentType.JSON)
          .post(OTP_VALIDATION)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.OTP_EXPIRED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateOtp(any(), any());

    }

    @Test
    void shouldReturnErrorIfAccountLocked() {
      OtpContext context = OtpContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.ACCOUNT_LOCKED, "Account locked"))
          .when(accountManagementService).validateOtp(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createOtpValidateRequest()))
          .contentType(ContentType.JSON)
          .post(OTP_VALIDATION)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.ACCOUNT_LOCKED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateOtp(any(), any());

    }

    @Test
    void shouldReturnErrorIfOtherOtpError() {
      OtpContext context = OtpContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.OTP_VALIDATION_FAILED, "Account locked"))
          .when(accountManagementService).validateOtp(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createOtpValidateRequest()))
          .contentType(ContentType.JSON)
          .post(OTP_VALIDATION)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.OTP_VALIDATION_FAILED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateOtp(any(), any());

    }
  }

  @Nested
  @DisplayName("Challenge Questions Cases")
  class ChallengeQuestionsCases {

    @Test
    void shouldCallDownstreamServices() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(accountManagementService.retrieveSecurityQuestions(any(), any())).thenReturn(
          context.createSecurityQuestionsFetchResponseModel());

      SecurityQuestionsFetchRequestModel requestModel = context.createSecurityQuestionsFetchRequestModel();

      RetrieveMemorableQuestionsRequest request = context.createRetrieveMemorableQuestionsRequest();

      givenRequestToController()
          .body(objectMapper.valueToTree(request))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_QUESTIONS)
          .then().log().all()
          .statusCode(HttpStatus.OK.value())
          .body("securityQuestions", equalTo(Collections.singletonList(context.getQuestion())));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .retrieveSecurityQuestions(accessTokenResponseModel.getAccessToken(), requestModel);
    }

    @Test
    void shouldReturn400WhenUserNotFound() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UserNotFoundException("User not found"))
          .when(accountManagementService)
          .retrieveSecurityQuestions(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createSecurityQuestionsFetchRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_QUESTIONS)
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .retrieveSecurityQuestions(any(), any());
    }

    @Test
    void shouldReturn400WhenQuestionsNotFound() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new SecurityQuestionNotFoundException("Questions not found"))
          .when(accountManagementService)
          .retrieveSecurityQuestions(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createSecurityQuestionsFetchRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_QUESTIONS)
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.QUESTIONS_NOT_RETRIEVED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .retrieveSecurityQuestions(any(), any());
    }

  }

  @Nested
  @DisplayName("Change Questions Cases")
  class ChangeQuestionsCases {

    @Test
    void shouldCallDownstreamServices() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      doNothing().when(accountManagementService).changeSecurityQuestions(any(), any());

      SecurityQuestionsChangeRequestModel request = context.createSecurityQuestionsChangeRequestModel();

      givenRequestToController()
          .body(objectMapper.valueToTree(request))
          .contentType(ContentType.JSON)
          .post(CHANGE_QUESTIONS)
          .then().log().all()
          .statusCode(HttpStatus.OK.value());

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .changeSecurityQuestions(accessTokenResponseModel.getAccessToken(), request);
    }

    @Test
    void shouldReturn500WhenRequestFailed() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RestClientException("Request failed"))
          .when(accountManagementService)
          .changeSecurityQuestions(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createSecurityQuestionsChangeRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHANGE_QUESTIONS)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .changeSecurityQuestions(any(), any());
    }
  }

  @Nested
  @DisplayName("Challenge Answers Cases")
  class ChallengeAnswersCases {

    @Test
    void shouldCallDownstreamServices() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(accountManagementService.validateSecurityAnswers(any(), any())).thenReturn(
          context.createSecurityQuestionsValidationResponseModel());

      SecurityQuestionsValidationRequestModel requestModel = context.createSecurityQuestionsValidationRequestModel();

      ChallengeAnswersRequest request = context.createChallengeAnswersRequestModel();

      givenRequestToController()
          .body(objectMapper.valueToTree(request))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.OK.value())
          .body("otpCode", equalTo(context.getOtpCode()))
          .body("brokerType", equalTo(context.getBrokerType().getValue()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateSecurityAnswers(accessTokenResponseModel.getAccessToken(), requestModel);
    }

    @Test
    void shouldReturn401WhenIncorrectMemorableQuestionAnswers() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new SecurityQuestionValidateException("Incorrect memorable question answers"))
          .when(accountManagementService)
          .validateSecurityAnswers(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createChallengeAnswersRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateSecurityAnswers(any(), any());
    }

    @Test
    void shouldReturn401WhenMemorableQuestionsLocked() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new SecurityQuestionLockedException("Memorable questions locked"))
          .when(accountManagementService)
          .validateSecurityAnswers(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createChallengeAnswersRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.MEMORABLE_QUESTIONS_LOCKED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateSecurityAnswers(any(), any());
    }

    @Test
    void shouldReturn401WhenAccountLocked() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new AccountLockedException("Account locked"))
          .when(accountManagementService)
          .validateSecurityAnswers(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createChallengeAnswersRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.ACCOUNT_LOCKED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateSecurityAnswers(any(), any());
    }

    @Test
    void shouldReturn500WhenInternalServerError() {
      AccountManagementContext context = AccountManagementContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException("Iternal Server Error"))
          .when(accountManagementService)
          .validateSecurityAnswers(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createChallengeAnswersRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
          .body("code", equalTo(ErrorCode.INTERNAL_SERVER_ERROR.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .validateSecurityAnswers(any(), any());
    }

  }

  @Nested
  @DisplayName("Reset Password Cases")
  class ResetPasswordCases {

    @Test
    void shouldCallDownstreamServices() {
      PasswordResetContext context = PasswordResetContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordResetRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_RESET)
          .then().log().all();

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordReset(any(), any());

    }

    @Test
    void shouldReturnServerErrorIfServiceThrowsRemoteFailure() {
      PasswordResetContext context = PasswordResetContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(accountManagementService)
          .passwordReset(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordResetRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_RESET)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
          .body("code", equalTo(ErrorCode.INTERNAL_SERVER_ERROR.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordReset(any(), any());

    }

    @Test
    void shouldReturnErrorIfOtpIsInvalid() {
      PasswordResetContext context = PasswordResetContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.INVALID_CREDENTIALS, "Invalid username or otp"))
          .when(accountManagementService)
          .passwordReset(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordResetRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_RESET)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.INVALID_CREDENTIALS.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordReset(any(), any());
    }

    @Test
    void shouldReturnErrorIfOtpExpired() {
      PasswordResetContext context = PasswordResetContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.OTP_EXPIRED, "Otp expired"))
          .when(accountManagementService)
          .passwordReset(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordResetRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_RESET)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.OTP_EXPIRED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordReset(any(), any());
    }

    @Test
    void shouldReturnErrorIfUserNotFound() {
      PasswordResetContext context = PasswordResetContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UserNotFoundException("User not found"))
          .when(accountManagementService)
          .passwordReset(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordResetRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_RESET)
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordReset(any(), any());
    }

    @Test
    void shouldReturnErrorIfPasswordIsInvalid() {
      PasswordResetContext context = PasswordResetContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new InvalidDetailsException(
          "Password doesn't meet requirements."))
          .when(accountManagementService)
          .passwordReset(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordResetRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_RESET)
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.INVALID_DETAILS.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordReset(any(), any());
    }
  }

  @Nested
  @DisplayName("Change Password Cases")
  class ChangePasswordCases {

    @Test
    void shouldCallDownstreamServices() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordChangeRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_CHANGE)
          .then().log().all();

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordChange(any(), any());

    }

    @Test
    void shouldReturnServerErrorIfServiceThrowsRemoteFailure() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(accountManagementService)
          .passwordChange(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordChangeRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_CHANGE)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
          .body("code", equalTo(ErrorCode.INTERNAL_SERVER_ERROR.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordChange(any(), any());

    }

    @Test
    void shouldReturnErrorIfUserNotFound() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UserNotFoundException("User not found"))
          .when(accountManagementService)
          .passwordChange(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordChangeRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_CHANGE)
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordChange(any(), any());
    }

    @Test
    void shouldReturnErrorIfPasswordIsInvalid() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new InvalidDetailsException(
          "Password doesn't meet requirements."))
          .when(accountManagementService)
          .passwordChange(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordChangeRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_CHANGE)
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value())
          .body("code", equalTo(ErrorCode.INVALID_DETAILS.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordChange(any(), any());
    }

    @Test
    void shouldReturnErrorIfAccountLocked() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new OtpException(ErrorCode.ACCOUNT_LOCKED, "Account locked"))
          .when(accountManagementService)
          .passwordChange(any(), any());

      givenRequestToController()
          .body(objectMapper.valueToTree(context.createPasswordChangeRequest()))
          .contentType(ContentType.JSON)
          .post(PASSWORD_CHANGE)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", equalTo(ErrorCode.ACCOUNT_LOCKED.name()));

      Mockito.verify(accessTokenService, times(1)).token(any());

      Mockito.verify(accountManagementService, times(1))
          .passwordChange(any(), any());
    }
  }

  @Nested
  @DisplayName("Retrieve Broker Details Cases")
  class RetrieveBrokerDetailsCases {

    @Test
    void shouldCallDownstreamServices() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(accountManagementService.getBrokerType(any(), any())).thenReturn(BrokerTypeModel.BROKER);

      givenRequestToController()
          .contentType(ContentType.JSON)
          .get(BROKER_DETAILS + "/username")
          .then().log().all();

      Mockito.verify(brokerDetailsService, times(1))
          .getBrokerDetails(eq("username"));

    }

    @Test
    void shouldReturnServerErrorIfCRMServiceThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(accountManagementService.getBrokerType(any(), any())).thenReturn(BrokerTypeModel.BROKER);

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(brokerDetailsService)
          .getBrokerDetails(any());

      givenRequestToController()
          .contentType(ContentType.JSON)
          .get(BROKER_DETAILS + "/username")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(brokerDetailsService, times(1))
          .getBrokerDetails(any());

    }
  }

  @Nested
  @DisplayName("Retrieve Firm Details Cases")
  class RetrieveFirmDetailsCases {

    @Test
    void shouldCallDownstreamServices() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .contentType(ContentType.JSON)
          .get(FIRM_DETAILS + "/12345")
          .then().log().all();

      Mockito.verify(firmDetailsService, times(1))
          .getFirmDetails(eq("12345"));

    }

    @Test
    void shouldReturnServerErrorIfCRMServiceThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(firmDetailsService)
          .getFirmDetails(any());

      givenRequestToController()
          .contentType(ContentType.JSON)
          .get(FIRM_DETAILS + "/username")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(firmDetailsService, times(1))
          .getFirmDetails(any());

    }
  }

  @Nested
  @DisplayName("Update Broker Details Cases")
  class UpdateBrokerDetailsCases {

    @Test
    void shouldCallDownstreamServices() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(accountManagementService.getBrokerType(any(), any())).thenReturn(BrokerTypeModel.BROKER);

      final BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
          .username("username")
          .build();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .put(BROKER_DETAILS)
          .then().log().all();

      Mockito.verify(brokerDetailsService, times(1))
          .updateDetails(any());

    }

    @Test
    void shouldReturnServerErrorIfCRMServiceThrowsRemoteFailure() {
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(accessTokenService.token(any())).thenReturn(accessTokenResponseModel);
      when(accountManagementService.getBrokerType(any(), any())).thenReturn(BrokerTypeModel.BROKER);

      final BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
          .username("username")
          .build();

      doThrow(new RemoteRequestFailedException(
          "Something went wrong"))
          .when(brokerDetailsService)
          .updateDetails(any());

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .put(BROKER_DETAILS)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(brokerDetailsService, times(1))
          .updateDetails(any());

    }
  }

  @Nested
  @DisplayName("Get Username Reminder Cases")
  class GetUsernameReminderCases {

    @Test
    void shouldReturn200IfSuccessful() {
      UsernameReminderRequest req = getUsernameReminderRequest();
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.OK.value());

      Mockito.verify(usernameReminderService, Mockito.times(1))
              .getUsernameReminder(eq(req));
    }

    @Test
    void shouldReturnValidationErrorIfGetUsernameReminderRequestIsInvalidDueToNullLastName() {
      UsernameReminderRequest req = getUsernameReminderRequest();
      req.setLastName(null);
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body("code", equalTo(ErrorCode.INVALID_REQUEST.toString()))
              .body("errors[0].title",  equalTo("lastName"))
              .body("errors[0].description",  equalTo("must not be blank"));;
    }

    @Test
    void shouldReturnValidationErrorIfGetUsernameReminderRequestIsInvalidDueToNullEmail() {
      UsernameReminderRequest req = getUsernameReminderRequest();
      req.setEmail(null);
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body("code", equalTo(ErrorCode.INVALID_REQUEST.toString()))
              .body("errors[0].title",  equalTo("email"))
              .body("errors[0].description",  equalTo("must not be blank"));;
    }

    @Test
    void shouldReturnValidationErrorIfGetUsernameReminderRequestIsInvalidDueToNullDateOfBirth() {
      UsernameReminderRequest req = getUsernameReminderRequest();
      req.setDateOfBirth(null);
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body("code", equalTo(ErrorCode.INVALID_REQUEST.toString()))
              .body("errors[0].title",  equalTo("dateOfBirth"))
              .body("errors[0].description",  equalTo("must not be null"));;
    }

    @Test
    void shouldReturnValidationErrorIfGetUsernameReminderRequestIsInvalidDueToInvalidDateOfBirth() {
      UsernameReminderRequest req = getUsernameReminderRequest();
      JsonNode node = objectMapper.valueToTree(req);
      ((ObjectNode)node).put("dateOfBirth", "01-01-1980");
      givenRequestToController()
              .body(node)
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value());

    }

    @Test
    void shouldReturnInternalServerErrorIfGetUsernameReminderRequestFailed() {
      RemoteRequestFailedException ex = new RemoteRequestFailedException("Generic error");
      doThrow(ex).when(usernameReminderService).getUsernameReminder(any());
      UsernameReminderRequest req = getUsernameReminderRequest();
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
              .body("code", equalTo(ErrorCode.INTERNAL_SERVER_ERROR.toString()));
    }

    @Test
    void shouldReturn404IfFeatureFlagDisabled() {
      ReflectionTestUtils.setField(accountManagementController, "featureForgotUsernameEnabled", false);
      doThrow(new ResponseStatusException(HttpStatus.NOT_FOUND))
              .when(accountManagementController).getUsernameReminder(any());

      verify(usernameReminderService, times(0)).getUsernameReminder(any());
    }

    private UsernameReminderRequest getUsernameReminderRequest() {
      return UsernameReminderRequest.builder()
              .email("test@test.com")
              .dateOfBirth(LocalDate.of(1980,01,01))
              .lastName("Last Name").build();
    }
  }
}
