package com.natwest.pbbdhb.brokerauth.service.token;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.brokerauth.client.token.AccessTokenClient;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AccessTokenServiceTest {

  @Mock
  AccessTokenClient accessTokenClient;

  @Nested
  @DisplayName("Retrieve Token Cases")
  class RetrieveTokenCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallAccessTokenClient() {
      AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel = AccessTokenContext.builder()
          .build().createAccessTokenRetrieveRequestModel();

      AccessTokenService service = new AccessTokenService(accessTokenClient);

      service.token(accessTokenRetrieveRequestModel);

      verify(accessTokenClient).retrieveToken(accessTokenRetrieveRequestModel);
    }

    /**
     * Testing service handles response from client.
     */
    @Test
    void shouldReturnResponseFromAccessTokenClient() {
      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
      AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel = accessTokenContext.createAccessTokenRetrieveRequestModel();
      AccessTokenResponseModel accessTokenResponseModel = accessTokenContext.createAccessTokenResponseModel();

      AccessTokenService service = new AccessTokenService(accessTokenClient);

      when(accessTokenClient.retrieveToken(any())).thenReturn(accessTokenResponseModel);

      AccessTokenResponseModel response = service.token(accessTokenRetrieveRequestModel);

      Assertions.assertEquals(accessTokenResponseModel, response);
    }
  }
}