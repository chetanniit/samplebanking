package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement;

import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.AccountManagementContext;
import com.natwest.pbbdhb.brokerauth.contexts.CustomerContext;
import com.natwest.pbbdhb.brokerauth.contexts.LoginContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.UserContext;
import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"int", "stub-customeridentitymanagement"})
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
class CustomerIdentityManagementStubClientTestIT {

  @Autowired
  CustomerIdentityManagementStubClient client;

  @Test
  void shouldInjectStubClient() {
    assertThat(client.getClass())
        .isEqualTo(CustomerIdentityManagementStubClient.class);
  }

  @Nested
  @DisplayName("Create User Cases")
  class CreateUserCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToCreateUser() {
      UserCreateRequestModel userCreateRequestModel = UserContext.builder().build()
          .createUserCreateRequestModel();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.createUser(accessToken, userCreateRequestModel);
    }
  }

  @Nested
  @DisplayName("Initialise OTP Cases")
  class InitialiseOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToInitialiseOtp() {
      String username = OtpContext.builder().build().getUsername();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.initialiseOtp(accessToken, username);
    }
  }

  @Nested
  @DisplayName("Retrieve Otp Cases")
  class RetrieveOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToRetrieveOtp() {
      final String username = OtpContext.builder().build().getUsername();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.retrieveOTP(accessToken, username);
    }

    /**
     * Testing happy path call to client which returns stub otp details
     */
    @Test
    void shouldReturnOtpDetails() {
      OtpContext context = OtpContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpRetrieveResponseModel result = client.retrieveOTP(accessToken, context.getUsername());

      OtpRetrieveResponseModel expected = context.createOtpRetrieveResponseModel();

      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("Generate Otp Cases")
  class GenerateOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToGenerateOtp() {
      final String otpId = OtpContext.builder().build().getOtpId();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.generateOTP(accessToken, otpId);
    }

    /**
     * Testing happy path call to client which returns stub generated otp
     */
    @Test
    void shouldReturnOtp() {
      OtpContext context = OtpContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpGenerateResponseModel result = client.generateOTP(accessToken, context.getOtpId());

      OtpGenerateResponseModel expected = context.createOtpGenerateResponseModel();

      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("Update Otp Cases")
  class UpdateOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToUpdateOtp() {
      final OtpUpdateRequestModel otpUpdateRequestModel = OtpContext.builder().build()
          .createOtpUpdateRequestModel();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.updateOTP(accessToken, otpUpdateRequestModel);
    }
  }

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToLogin() {
      LoginRequestModel loginRequestModel = LoginContext.builder().build()
          .createLoginRequestModel();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.login(accessToken, loginRequestModel);
    }
  }

  @Nested
  @DisplayName("Get Customer Cases")
  class GetCustomerCases {

    /* Testing happy path call to client */
    @Test
    void shouldCallCustomerIdentityManagementClientToGetCustomer() {
      String username = CustomerContext.builder().build().getUsername();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.getCustomer(accessToken, username);
    }

    /**
     * Testing happy path call to client which returns a stub customer
     */
    @Test
    void shouldReturnCustomer() {
      CustomerContext context = CustomerContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      GetCustomerResponseModel result = client.getCustomer(accessToken, context.getUsername());

      GetCustomerResponseModel expected = context.createGetCustomerResponseModel();

      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("Get User Cases")
  class GetUserCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToGetUser() {
      String username = LoginContext.builder().build().getUsername();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.getUser(accessToken, username);
    }

    /**
     * Testing happy path call to client which returns a stub user
     */
    @Test
    void shouldReturnUser() {
      LoginContext context = LoginContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      GetUserResponseModel result = client.getUser(accessToken, context.getUsername());

      GetUserResponseModel expected = context.createGetUserResponseModel();

      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("Get Security Question Cases")
  class GetSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToGetUser() {

      final AccountManagementContext context = AccountManagementContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      String parentId = context.getParentId();

      final SecurityQuestionsFetchResponseModel result = client.getSecurityQuestions(accessToken,
          parentId);

      final SecurityQuestionsFetchResponseModel expected = context.createSecurityQuestionsFetchResponseModel();
      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("Validate Security Question Cases")
  class ValidateSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToSetUser() {

      final AccountManagementContext context = AccountManagementContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final SecurityQuestionsSingleValidationRequestModel model = context.createSecuritySingleQuestionsValidationRequestModel();

      client.validateSecurityQuestion(accessToken, model);
    }
  }

  @Nested
  @DisplayName("Delete Security Question Cases")
  class DeleteSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToDeleteQuestions() {

      final AccountManagementContext context = AccountManagementContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String questionId = context.getQuestionId();

      client.deleteSecurityQuestions(accessToken, questionId);

    }
  }
}
