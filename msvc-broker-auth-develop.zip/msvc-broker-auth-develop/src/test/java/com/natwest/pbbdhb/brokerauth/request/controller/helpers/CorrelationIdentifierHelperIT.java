package com.natwest.pbbdhb.brokerauth.request.controller.helpers;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.natwest.pbbdhb.brokerauth.request.controller.helpers.CorrelationIdentifierHelperIT.HelloController;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Tests the {@link CorrelationIdentifierHelper} that retrieves the correlation ID and internal
 * correlation ID from HTTP headers.
 * <p>
 * The request correlation id context uses a thread-local to hold the request's correlation
 * headers/values. These are set by the RequestCorrelationIdValve when an HTTP request is made.
 * <p>
 * These tests will confirm we can correctly extract these correlation IDs from HTTP request
 * headers.
 */
@Slf4j
@ActiveProfiles(profiles = {"int"})
@EnableAutoConfiguration
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {
        HelloController.class,
        CorrelationIdentifierHelper.class},
    properties = {
        "des.tomcat.valves.request-correlation-id.header-name = x-fapi-interaction-id,alternative-correlation-header",
        "des.tomcat.valves.requestInternalCorrelationId.header-name = x-rbs-interaction-id,alternative-int-correlation-header"
    })
public class CorrelationIdentifierHelperIT {

    private static final String X_FAPI_INTERACTION_ID_HEADER = "x-fapi-interaction-id";
    private static final String X_RBS_INTERACTION_ID_HEADER = "x-rbs-interaction-id";
    private static final String ALTERNATIVE_INTERACTION_ID_HEADER = "alternative-correlation-header";
    private static final String ALTERNATIVE_INTERNAL_INTERACTION_ID_HEADER = "alternative-int-correlation-header";
    private static final String EXPECTED_CORRELATION_ID_VALUE = UUID.randomUUID().toString();
    private static final String EXPECTED_CORRELATION_INTERNAL_ID_VALUE = UUID.randomUUID()
        .toString();

    // holds the correlation IDs captured by the HTTP calls run during these tests.
    // we use statics as the HTTP requests run in different threads.
    // these captured IDs will be cleared at the start of each test and asserted against after each HTTP call.
    private static String CAPTURED_CORRELATION_HEADER;
    private static String CAPTURED_INTERNAL_CORRELATION_HEADER;

    @SpyBean
    private CorrelationIdentifierHelper helper;

    @Autowired
    private TestRestTemplate restTemplate;

    @BeforeEach
    public void before() {
        CAPTURED_CORRELATION_HEADER = null;
        CAPTURED_INTERNAL_CORRELATION_HEADER = null;
    }

    @Test
    public void shouldCaptureExpectedCorrelationIds() {

        // make the HTTP request
        HttpHeaders headers = new HttpHeaders();
        headers.add(
            X_FAPI_INTERACTION_ID_HEADER,
            EXPECTED_CORRELATION_ID_VALUE);
        headers.add(
            X_RBS_INTERACTION_ID_HEADER,
            EXPECTED_CORRELATION_INTERNAL_ID_VALUE);
        restTemplate.exchange(
            "/hello",
            HttpMethod.GET,
            new HttpEntity<String>(headers),
            String.class);

        // verify the IDs were captured
        verify(helper, times(1))
            .requestCorrelationId();
        assertThat(CAPTURED_CORRELATION_HEADER)
            .isEqualTo(EXPECTED_CORRELATION_ID_VALUE);

        verify(helper, times(1))
            .requestInternalCorrelationId();
        assertThat(CAPTURED_INTERNAL_CORRELATION_HEADER)
            .isEqualTo(EXPECTED_CORRELATION_INTERNAL_ID_VALUE);
    }

    // when we don't specifically supply correlation headers,
    // the DWS libraries should generate their own 32 character ID.
    // this test confirms we can also capture these generated IDs.
    @Test
    public void shouldCaptureGeneratedCorrelationIds() {

        // make the HTTP request with no headers provided
        HttpHeaders headers = new HttpHeaders();
        restTemplate.exchange(
            "/hello",
            HttpMethod.GET,
            new HttpEntity<String>(headers),
            String.class);

        verify(helper, times(1))
            .requestCorrelationId();
        assertThat(CAPTURED_CORRELATION_HEADER)
            .isNotBlank();
        assertThat(CAPTURED_CORRELATION_HEADER.length())
            .isEqualTo(32);

        verify(helper, times(1))
            .requestInternalCorrelationId();
        assertThat(CAPTURED_INTERNAL_CORRELATION_HEADER)
            .isNotBlank();
        assertThat(CAPTURED_INTERNAL_CORRELATION_HEADER.length())
            .isEqualTo(32);
    }

    // The DWS correlation headers configuration supports multiple correlation headers.
    // This test class has been configured with two possible correlation and internal correlation headers.
    // This test confirms we can also extract correlation IDs from these second headers.
    @Test
    public void shouldCaptureExpectedCorrelationIdsUsingAlternativeHeaders() {

        // make the HTTP request
        HttpHeaders headers = new HttpHeaders();
        headers.add(
            ALTERNATIVE_INTERACTION_ID_HEADER,
            EXPECTED_CORRELATION_ID_VALUE);
        headers.add(
            ALTERNATIVE_INTERNAL_INTERACTION_ID_HEADER,
            EXPECTED_CORRELATION_INTERNAL_ID_VALUE);
        restTemplate.exchange(
            "/hello",
            HttpMethod.GET,
            new HttpEntity<String>(headers),
            String.class);

        // verify the IDs were captured
        verify(helper, times(1))
            .requestCorrelationId();
        assertThat(CAPTURED_CORRELATION_HEADER)
            .isEqualTo(EXPECTED_CORRELATION_ID_VALUE);

        verify(helper, times(1))
            .requestInternalCorrelationId();
        assertThat(CAPTURED_INTERNAL_CORRELATION_HEADER)
            .isEqualTo(EXPECTED_CORRELATION_INTERNAL_ID_VALUE);
    }

    /**
     * Provides a test REST controller that we can call as part of these tests.
     * <p>
     * The controller captures the correlation IDs it receives using our helper.
     */
    @RestController
    @Slf4j
    public static class HelloController {

        @Autowired
        CorrelationIdentifierHelper helper;

        @RequestMapping(value = "/hello", method = RequestMethod.GET)
        public void hello() {
            // capture the received correlation headers
            CAPTURED_CORRELATION_HEADER = helper.requestCorrelationId();
            CAPTURED_INTERNAL_CORRELATION_HEADER = helper.requestInternalCorrelationId();
            log.info("Received correlation ID: {}", CAPTURED_CORRELATION_HEADER);
            log.info("Received internal correlation ID: {}", CAPTURED_INTERNAL_CORRELATION_HEADER);
        }
    }
}
