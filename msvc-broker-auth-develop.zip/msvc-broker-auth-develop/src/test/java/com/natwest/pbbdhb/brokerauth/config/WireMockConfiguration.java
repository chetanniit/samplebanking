package com.natwest.pbbdhb.brokerauth.config;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.extension.ResponseDefinitionTransformer;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.ResponseDefinition;
import org.springframework.cloud.contract.wiremock.WireMockConfigurationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import wiremock.com.google.common.net.HttpHeaders;

@Configuration
public class WireMockConfiguration {

  /**
   * Adds a response transformer to close connections, which prevents "connection abort"
   * exceptions.
   */
  @Bean
  WireMockConfigurationCustomizer optionsCustomizer() {
    return options -> options.extensions(NoKeepAliveTransformer.class);
  }

  /**
   * Prevents the "Software caused connection abort" exception seen when using Wiremock.
   * <p>
   * This transformer adds a close connection header to every Wiremock response.
   * <p>
   * See: https://stackoverflow.com/questions/68929051/wiremock-sometimes-it-throws-software-caused-connection-abort-recv-failed
   */
  public static class NoKeepAliveTransformer extends ResponseDefinitionTransformer {

    @Override
    public ResponseDefinition transform(Request request, ResponseDefinition responseDefinition,
        FileSource files, Parameters parameters) {
      return ResponseDefinitionBuilder.like(responseDefinition)
          .withHeader(HttpHeaders.CONNECTION, "close")
          .build();
    }

    @Override
    public String getName() {
      return "keep-alive-disabler";
    }
  }
}
