package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionValidateReturnCode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsValidateClientResponse;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Getter
@ToString
@Builder
public class SecurityQuestionsClientContext {

  private final static String DEFAULT_QUESTION = "test question?";
  private final static String DEFAULT_ANSWER = "test answer";


  @Default
  private String parentId = "uid=5be0c229-2a1c-4466-9dac-446be8628080,ou=customer,ou=personaidentity,ou=common,dc=carnus";

  @Default
  private String questionsId = "1f9c267f-01fe-416f-b74d-f4dec2cc7a3e";

  @Default
  private Map<String, String> questions = Collections.singletonMap("q1", DEFAULT_QUESTION);

  @Default
  private List<String> answers = Collections.singletonList(DEFAULT_QUESTION + DEFAULT_ANSWER);

  @Default
  private String username = "testAccount";

  @Default
  private String question = DEFAULT_QUESTION;

  @Default
  private String answer = DEFAULT_ANSWER;

  @Default
  private List<String> schemas = Collections.singletonList(
      "urn:generic:schemas:customerchallenge:1.0");

  @Default
  private int totalResults = 1;

  @Default
  private SecurityQuestionValidateReturnCode returnCode = SecurityQuestionValidateReturnCode.SUCCESS;

  @Default String validationHeader = DEFAULT_QUESTION + ":" + DEFAULT_ANSWER;

  public SecurityQuestionsClientRequest createSecurityQuestionsClientRequest() {
    return SecurityQuestionsClientRequest.builder()
        .schemas(schemas)
        .parentId(parentId)
        .question(Collections.singletonList(questions))
        .answer(answers)
        .build();
  }

  public SecurityQuestionsClientResponse createSecurityQuestionsClientResponse() {
    List<SecurityQuestionsClientResponse.SecurityQuestionResource> resources = Collections.singletonList(
        SecurityQuestionsClientResponse.SecurityQuestionResource.builder()
            .id(questionsId)
            .questions(Collections.singletonList(questions))
            .build());
    return SecurityQuestionsClientResponse.builder()
        .totalResults(totalResults)
        .resources(resources)
        .build();
  }

  // simulates when response contains no questions
  public SecurityQuestionsClientResponse createMissingSecurityQuestionsClientResponse() {
    List<SecurityQuestionsClientResponse.SecurityQuestionResource> resources = Collections.singletonList(
        SecurityQuestionsClientResponse.SecurityQuestionResource.builder()
            .id(null)
            .questions(null)
            .build());
    return SecurityQuestionsClientResponse.builder()
        .totalResults(0)
        .resources(resources)
        .build();
  }

  // simulates when response is empty - i.e. data not found
  public SecurityQuestionsClientResponse createEmptySecurityQuestionsClientResponse() {
    return SecurityQuestionsClientResponse.builder()
        .totalResults(0)
        .resources(null)
        .build();
  }

  public SecurityQuestionsSingleValidationRequestModel createSecurityQuestionsValidationRequestModel() {
    return SecurityQuestionsSingleValidationRequestModel.builder()
        .username(username)
        .question(SecurityQuestion.builder()
            .question(question)
            .answer(answer)
            .build())
        .build();
  }

  public SecurityQuestionsValidateClientResponse createSecurityQuestionsValidateClientResponse() {
    return SecurityQuestionsValidateClientResponse.builder()
        .totalResults(totalResults)
        .resources(Collections.singletonList(
            SecurityQuestionsValidateClientResponse.SecurityQuestionValidationResource.builder()
                .returnCode(returnCode)
                .build()))
        .build();
  }

  public SecurityQuestionsValidateClientResponse createEmptySecurityQuestionsValidateClientResponse() {
    return SecurityQuestionsValidateClientResponse.builder()
        .totalResults(0)
        .resources(null)
        .build();
  }
}
