package com.natwest.pbbdhb.brokerauth.request.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.natwest.pbbdhb.brokerauth.contexts.ActivationContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Testing the Activation business domain model mapping.
 */
class ActivationRequestMapperTest {

  @Nested
  @DisplayName("toOtpValidateRequestModel Cases")
  class ToOtpValidateRequestModelCases {

    @Test
    void toOtpValidateRequestModelFromActivationCodeValidateRequest() {
      ActivationCodeValidateRequest requestModel = OtpContext.builder().build()
          .createActivationCodeValidateRequest();

      OtpValidateRequestModel domainModel = ActivationRequestMapper.toOtpValidateRequestModel(
          requestModel);

      assertEquals(domainModel.getUsername(), requestModel.getUsername());
      assertEquals(domainModel.getOtpCode(), requestModel.getCode());
    }

    @Test
    void toOtpValidateRequestModelFromUserActivateRequest() {
      UserActivateRequest userActivateRequest = ActivationContext.builder().build()
          .createUserActivateRequest();

      OtpValidateRequestModel domainModel = ActivationRequestMapper.toOtpValidateRequestModel(
          userActivateRequest);

      assertEquals(domainModel.getUsername(), userActivateRequest.getUsername());
      assertEquals(domainModel.getOtpCode(), userActivateRequest.getOtpCode());
    }

    /**
     * Testing error case when trying to map over a null reference for
     * ActivationCodeValidateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForActivationCodeValidateRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toOtpValidateRequestModel((ActivationCodeValidateRequest) null)
      );
    }

    /**
     * Testing error case when trying to map over a null reference for UserActivateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForUserActivateRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toOtpValidateRequestModel((UserActivateRequest) null)
      );
    }
  }

  @Nested
  @DisplayName("toUserSetPasswordRequestModel Cases")
  class ToUserSetPasswordRequestModelCases {

    @Test
    void toUserSetPasswordRequestModel() {
      UserActivateRequest userActivateRequest = ActivationContext.builder().build()
          .createUserActivateRequest();

      UserSetPasswordRequestModel domainModel = ActivationRequestMapper.toUserSetPasswordRequestModel(
          userActivateRequest, "TestId");

      assertEquals(domainModel.getPassword(), userActivateRequest.getPassword());
      assertEquals("TestId", domainModel.getCustomerIdentifier());
    }

    /**
     * Testing error case when trying to map over a null reference for UserActivateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForUserActivateRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toUserSetPasswordRequestModel(null, "Test")
      );
    }

    /**
     * Testing error case when trying to map over a null reference for CustomerIdentifier.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForCustomerIdentifier() {
      UserActivateRequest userActivateRequest = ActivationContext.builder().build()
          .createUserActivateRequest();

      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toUserSetPasswordRequestModel(userActivateRequest, null)
      );
    }
  }

  @Nested
  @DisplayName("toSecurityQuestionsRequestModel Cases")
  class ToSecurityQuestionsRequestModelCases {

    @Test
    void toSecurityQuestionsRequestModel() {
      UserActivateRequest userActivateRequest = ActivationContext.builder().build()
          .createUserActivateRequest();

      SecurityQuestionsRequestModel domainModel = ActivationRequestMapper.toSecurityQuestionsRequestModel(
          userActivateRequest, "TestId");

      assertEquals(domainModel.getQuestions(), userActivateRequest.getSecurityQuestions());
      assertEquals("TestId", domainModel.getParentId());
    }

    /**
     * Testing error case when trying to map over a null reference for UserActivateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForUserActivateRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toSecurityQuestionsRequestModel(null, "Test")
      );
    }

    /**
     * Testing error case when trying to map over a null reference for CustomerIdentifier.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForCustomerIdentifier() {
      UserActivateRequest userActivateRequest = ActivationContext.builder().build()
          .createUserActivateRequest();

      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toSecurityQuestionsRequestModel(userActivateRequest, null)
      );
    }
  }
}