package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.LoginRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class CustomerContext {

  @Default
  private String username = "TestUsername";

  @Default
  private BrokerTypeModel brokerType = BrokerTypeModel.BROKER;

  @Default
  private String id = "TestId";

  public GetCustomerResponseModel createGetCustomerResponseModel() {
    return GetCustomerResponseModel.builder()
          .brokerType(brokerType)
          .id(id)
          .build();
  }
}
