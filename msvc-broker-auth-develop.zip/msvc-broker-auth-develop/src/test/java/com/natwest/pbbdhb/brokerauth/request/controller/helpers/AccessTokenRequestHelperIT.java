package com.natwest.pbbdhb.brokerauth.request.controller.helpers;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.natwest.pbbdhb.brokerauth.config.JwtPublicKeyConfiguration;
import com.natwest.pbbdhb.brokerauth.configuration.IamScimConfig;
import com.natwest.pbbdhb.brokerauth.configuration.IamScimConfig.BrandedConfig;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.request.security.UserClaimsProvider;
import java.security.PublicKey;
import java.util.UUID;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

/**
 * Tests {@link AccessTokenRequestHelper} that creates the request models used for scim
 * requests.
 * <p>
 * The helper pulls together request models from several sources, namely the
 * request correlation headers, user claims, configuration and a JWT signing service.
 */
@ActiveProfiles(profiles = {"int", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Import(JwtPublicKeyConfiguration.class)
@Slf4j
public class AccessTokenRequestHelperIT {

  private static final String JWS_REGEX = "^[a-zA-Z0-9-_]+?.[a-zA-Z0-9-_]+?.([a-zA-Z0-9-_]+)?$";

  // request parameters
  private static final String ACCESS_TOKEN = UUID.randomUUID().toString();
  private static final Brand BRAND = Brand.NWB;

  @Autowired
  private AccessTokenRequestHelper helper;

  @MockBean
  private UserClaimsProvider userClaimsProvider;

  @MockBean
  private CorrelationIdentifierHelper correlationHelper;

  @Autowired
  private IamScimConfig config;

  @Autowired
  @Qualifier("jwtPublicKey")
  public PublicKey publicKey;

  @BeforeEach
  public void beforeEach() {
    when(userClaimsProvider.getOperatingBrand())
        .thenReturn(BRAND);
    when(userClaimsProvider.getAccessToken())
        .thenReturn(ACCESS_TOKEN);
  }

  @Nested
  @DisplayName("create access token cases")
  class GenerateAccessTokenCases {

    @Test
    public void shouldGenerateRequestModel() throws JoseException {

      final BrandedConfig brandedConfig = config.getBrands().get(BRAND);

      final AccessTokenRetrieveRequestModel model = helper.tokenRetrieveRequestModel();
      assertThat(model).isNotNull();
      assertThat(model.getClientAssertionType())
          .isEqualTo(config.getClientAssertionType());
      assertThat(model.getClientId())
          .isEqualTo(brandedConfig.getClientId());
      assertThat(model.getScope())
          .isEqualTo(config.getScope());
      assertThat(model.getGrantType())
          .isEqualTo(config.getGrantType());
      assertThat(model.getBrand())
          .isEqualTo(BRAND);
      assertThat(model.getClientAssertion())
          .matches(Pattern.compile(JWS_REGEX));
      verifyJwtPayload(model.getClientAssertion());
    }
  }

  private void verifyJwtPayload(String jwt) throws JoseException {

    final BrandedConfig brandedConfig = config.getBrands().get(BRAND);

    // convert back to a JWS
    JsonWebSignature jws = new JsonWebSignature();
    jws.setCompactSerialization(jwt);
    jws.setKey(publicKey);

    // verify signature
    assertThat(jws.verifySignature()).isTrue();

    // verify header
    assertThat(jws.getHeader("alg")).isEqualTo(config.getAlgorithm());
    assertThat(jws.getHeader("typ")).isEqualTo("JWT");

    // confirm JWT contains the expected payload
    final String jsonPayload = jws.getPayload();
    assertThat(extract(jsonPayload, "$.sub")).isEqualTo(brandedConfig.getClientId());
    assertThat(extract(jsonPayload, "$.iss")).isEqualTo(brandedConfig.getIssuer());
    assertThat(extract(jsonPayload, "$.aud")).isEqualTo(brandedConfig.getAudience());
    assertThat(extract(jsonPayload, "$.iat")).isNotNull();
    assertThat(extract(jsonPayload, "$.exp")).isNotNull();
    assertThat(extract(jsonPayload, "$.jti")).isNotNull();
    assertThat(extract(jsonPayload, "$.client_id"))
        .isEqualTo(brandedConfig.getClientId());
    assertThat(extract(jsonPayload, "$.brand")).isEqualTo(BRAND.getValue());
    assertThat(extract(jsonPayload, "$.channel")).isNull();
    assertThat(extract(jsonPayload, "$.details")).isNull();
  }

  /**
   * Extract Object from JSON payload using JSON Path
   */
  private Object extract(String payload, String jsonPath) {
    try {
      return JsonPath
          .parse(payload)
          .read(jsonPath, Object.class);
    } catch (PathNotFoundException e) {
      return null;
    }
  }
}
