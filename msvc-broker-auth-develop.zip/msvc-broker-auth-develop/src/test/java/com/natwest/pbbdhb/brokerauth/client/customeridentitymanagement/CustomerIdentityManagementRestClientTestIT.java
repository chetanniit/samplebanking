package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement;

import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.core.Options.DEFAULT_PORT;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.ActivateUserClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.ChangePasswordClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.GetCustomerClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.GetUserClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.LoginClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.OtpGenerateClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.OtpRetrieveClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.OtpValidateClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.SecurityQuestionsClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.SetPasswordClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpValidateReturnCode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionValidateReturnCode;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.AccountManagementContext;
import com.natwest.pbbdhb.brokerauth.contexts.ActivationContext;
import com.natwest.pbbdhb.brokerauth.contexts.CustomerContext;
import com.natwest.pbbdhb.brokerauth.contexts.LoginContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordChangeContext;
import com.natwest.pbbdhb.brokerauth.contexts.UserContext;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.GetCustomerResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionLockedException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionNotFoundException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionResponseException;
import com.natwest.pbbdhb.brokerauth.exception.SecurityQuestionValidateException;
import com.natwest.pbbdhb.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import com.natwest.pbbdhb.brokerauth.request.security.IamUserClaimsProvider;
import com.natwest.pbbdhb.brokerauth.request.security.UserClaimsProvider;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"int"})
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
public class CustomerIdentityManagementRestClientTestIT {

  // the client will re-try (up to a maximum number of attempts) when failures occur
  private static final int EXPECTED_FAILURE_RETRIES = 5;

  @Autowired
  CustomerIdentityManagementRestClient client;

  @MockBean
  @Qualifier("simpleUserPrincipalProvider")
  private UserPrincipalProvider userPrincipalProvider;

  @Mock
  private UserPrincipal userPrincipal;

  UserClaimsProvider userClaimsProvider;

  private static WireMockServer wireMockServer;


  @Autowired
  private ObjectMapper objectMapper;

  @BeforeAll
  public static void startWireMock() {
    wireMockServer = new WireMockServer(options().port(DEFAULT_PORT));
    wireMockServer.start();
  }

  @BeforeEach
  public void setup() throws GeneralSecurityException {
    wireMockServer.resetRequests();
    when(userPrincipalProvider.get()).thenReturn(userPrincipal);
    when(userPrincipal.getProperty("operating_brand")).thenReturn(Brand.NWB.getValue());
    userClaimsProvider = new IamUserClaimsProvider(userPrincipalProvider);
  }

  @AfterAll
  public static void cleanUp() {
    wireMockServer.stop();
  }

  @Nested
  @DisplayName("Create User Cases")
  class CreateUserCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToCreateUser() throws JsonProcessingException {
      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingCreateUserRequest(WireMock.created()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();
      client.createUser(accessToken, context.createUserCreateRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForCreateUserRequest(
              objectMapper.writeValueAsString(context.createUserCreateClientRequest())));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() throws JsonProcessingException {
      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingCreateUserRequest(WireMock.badRequest()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();

      UserCreateRequestModel requestModel = context.createUserCreateRequestModel();

      assertThatThrownBy(
          () -> client.createUser(accessToken, requestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForCreateUserRequest(
              objectMapper.writeValueAsString(context.createUserCreateClientRequest())));
    }

    @Test
    void shouldReturnUserAlreadyExistsExceptionIfResponseIsBadRequestDueToUserAlreadyExists()
            throws IOException {
      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingCreateUserRequest(
              jsonResponse(HttpStatus.BAD_REQUEST, objectMapper.valueToTree(
                  objectMapper.createObjectNode().put("scimType", "uniqueness")))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();

      UserCreateRequestModel userCreateRequestModel = context.createUserCreateRequestModel();
      assertThatThrownBy(
          () -> client.createUser(accessToken, userCreateRequestModel))
          .isInstanceOf(UserAlreadyExistsException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForCreateUserRequest(
              objectMapper.writeValueAsString(context.createUserCreateClientRequest())));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() throws JsonProcessingException {
      WireMock.stubFor(CustomerIdentityManagementWireMockServer.mappingCreateUserRequest(
          WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();

      UserCreateRequestModel requestModel = context.createUserCreateRequestModel();

      assertThatThrownBy(
          () -> client.createUser(accessToken, requestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForCreateUserRequest(
              objectMapper.writeValueAsString(context.createUserCreateClientRequest())));
    }

    @Test
    void shouldNotTimeoutIfWithinSpecifiedTimeoutLimit() throws JsonProcessingException {
      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingCreateUserRequest(
              WireMock.created().withFixedDelay(1500))
      );

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();
      client.createUser(accessToken, context.createUserCreateRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForCreateUserRequest(
              objectMapper.writeValueAsString(context.createUserCreateClientRequest())));
    }

    @Test
    void shouldTimeoutIfOutsideSpecifiedTimeoutLimit() throws JsonProcessingException {
      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingCreateUserRequest(
              WireMock.created().withFixedDelay(2500)));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();

      UserCreateRequestModel userCreateRequestModel = context.createUserCreateRequestModel();
      assertThatThrownBy(
          () -> client.createUser(accessToken, userCreateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForCreateUserRequest(
              objectMapper.writeValueAsString(context.createUserCreateClientRequest())));
    }
  }

  @Nested
  @DisplayName(("Delete User Cases"))
  class DeleteUserCases {

    /* Testing happy path call to client */
    @Test
    void shouldCallCustomerIdentityManagementClientToDeleteUser() throws JsonProcessingException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      ActivateUserClientContext clientContext = ActivateUserClientContext.builder().build();
      UserContext context = UserContext.builder().build();
      UserDeleteRequestModel userDeleteRequestModel = context.createUserDeleteRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteUserRequest(
              clientContext.customerId, WireMock.created()));

      client.deleteUser(accessToken, clientContext.customerId, userDeleteRequestModel);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForDeleteUserRequest(
              objectMapper.writeValueAsString(context.createUserDeleteClientRequest()),
              clientContext.customerId));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() throws JsonProcessingException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();
      ActivateUserClientContext clientContext = ActivateUserClientContext.builder().build();
      UserDeleteRequestModel userDeleteRequestModel = context.createUserDeleteRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteUserRequest(
              clientContext.customerId, WireMock.badRequest()));

      assertThatThrownBy(
          () -> client.deleteUser(accessToken, clientContext.customerId, userDeleteRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForDeleteUserRequest(
              objectMapper.writeValueAsString(context.createUserDeleteClientRequest()),
              clientContext.customerId));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() throws JsonProcessingException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      UserContext context = UserContext.builder().build();
      ActivateUserClientContext clientContext = ActivateUserClientContext.builder().build();
      UserDeleteRequestModel userDeleteRequestModel = context.createUserDeleteRequestModel();

      WireMock.stubFor(CustomerIdentityManagementWireMockServer.mappingDeleteUserRequest(
          clientContext.customerId,
          WireMock.serverError()));

      assertThatThrownBy(
          () -> client.deleteUser(accessToken, clientContext.customerId, userDeleteRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForDeleteUserRequest(
              objectMapper.writeValueAsString(context.createUserDeleteClientRequest()),
              clientContext.customerId));
    }
  }

  @Nested
  @DisplayName("Initialise OTP Cases")
  class InitialiseOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToInitialiseOtp()
        throws JsonProcessingException {

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingInitiliseOtpRequest(WireMock.created()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.initialiseOtp(accessToken, context.getUsername());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForInitialiseOtpRequest(
              objectMapper.writeValueAsString(context.createOtpInitialiseClientRequest())));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() throws JsonProcessingException {
      WireMock.stubFor(CustomerIdentityManagementWireMockServer.mappingInitiliseOtpRequest(
          WireMock.serverError()));

      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = context.getUsername();
      assertThatThrownBy(
          () -> client.initialiseOtp(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForInitialiseOtpRequest(
              objectMapper.writeValueAsString(context.createOtpInitialiseClientRequest())));
    }
  }

  @Nested
  @DisplayName("Retrieve Otp Cases")
  class RetrieveOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToRetrieveOtp() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = OtpContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingRetrieveOtpRequest(
              username,
              OtpRetrieveClientContext.builder().build().getValidOtpRetrieveClientResponse())
      );

      client.retrieveOTP(accessToken, username);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForRetrieveOtpRequest(
              username));
    }

    /**
     * Testing happy path call to client returns the correct result
     */
    @Test
    void shouldReturnOtpRetrieveResponseModel() throws IOException {
      OtpContext context = OtpContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = context.getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingRetrieveOtpRequest(
              username,
              OtpRetrieveClientContext.builder().build().getValidOtpRetrieveClientResponse())
      );

      OtpRetrieveResponseModel result = client.retrieveOTP(accessToken, username);

      OtpRetrieveResponseModel expected = context.createOtpRetrieveResponseModel();

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForRetrieveOtpRequest(
              username));

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing that client throws InvalidDataResponseException when returned more than 1 otp
     */
    @Test
    void shouldReturnInvalidDataResponseExceptionIfClientReturnsMoreThanOneOtp() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = OtpContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingRetrieveOtpRequest(
              username,
              OtpRetrieveClientContext.builder().build()
                  .otpRetrieveClientResponseReturnsMultipleOtps())
      );

      assertThatThrownBy(
          () -> client.retrieveOTP(accessToken, username))
          .isInstanceOf(InvalidDataResponseException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForRetrieveOtpRequest(
              username));
    }

    /**
     * Testing that client throws InvalidDataResponseException when returned no otps
     */
    @Test
    void shouldReturnInvalidDataResponseExceptionIfClientReturnsNoOtps() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = OtpContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingRetrieveOtpRequest(
              username,
              OtpRetrieveClientContext.builder().build().otpRetrieveClientResponseReturnsNoOtps())
      );

      assertThatThrownBy(
          () -> client.retrieveOTP(accessToken, username))
          .isInstanceOf(InvalidDataResponseException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForRetrieveOtpRequest(
              username));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = OtpContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingRetrieveOtpRequest(username,
              HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.retrieveOTP(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForRetrieveOtpRequest(
              username));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = OtpContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingRetrieveOtpRequest(username,
              HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.retrieveOTP(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForRetrieveOtpRequest(
              username));
    }
  }

  @Nested
  @DisplayName("Generate Otp Cases")
  class GenerateOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToGenerateOtp() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = OtpContext.builder().build().getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGenerateOtpRequest(
              otpId,
              OtpGenerateClientContext.builder().build().getValidOtpGenerateClientResponse())
      );

      client.generateOTP(accessToken, otpId);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGenerateOtpRequest(
              otpId));
    }

    /**
     * Testing happy path call to client returns the correct result
     */
    @Test
    void shouldReturnOtpGenerateResponseModel() throws IOException {
      OtpContext context = OtpContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = context.getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGenerateOtpRequest(
              otpId,
              OtpGenerateClientContext.builder().build().getValidOtpGenerateClientResponse())
      );

      OtpGenerateResponseModel result = client.generateOTP(accessToken, otpId);

      OtpGenerateResponseModel expected = context.createOtpGenerateResponseModel();

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGenerateOtpRequest(
              otpId));

      Assertions.assertEquals(expected, result);
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = OtpContext.builder().build().getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGenerateOtpRequest(otpId,
              HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.generateOTP(accessToken, otpId))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGenerateOtpRequest(
              otpId));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = OtpContext.builder().build().getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGenerateOtpRequest(otpId,
              HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.generateOTP(accessToken, otpId))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGenerateOtpRequest(
              otpId));
    }
  }

  @Nested
  @DisplayName("Update Otp Cases")
  class UpdateOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToUpdateOtp() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpUpdateRequestModel otpUpdateRequestModel = OtpContext.builder().build()
          .createOtpUpdateRequestModel();
      final String otpId = otpUpdateRequestModel.getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingUpdateOtpRequest(otpId)
      );

      client.updateOTP(accessToken, otpUpdateRequestModel);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForUpdateOtpRequest(
              otpId));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpUpdateRequestModel otpUpdateRequestModel = OtpContext.builder().build()
          .createOtpUpdateRequestModel();
      final String otpId = otpUpdateRequestModel.getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingUpdateOtpRequest(otpId,
              HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.updateOTP(accessToken, otpUpdateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForUpdateOtpRequest(
              otpId));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpUpdateRequestModel otpUpdateRequestModel = OtpContext.builder().build()
          .createOtpUpdateRequestModel();
      final String otpId = otpUpdateRequestModel.getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingUpdateOtpRequest(otpId,
              HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.updateOTP(accessToken, otpUpdateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForUpdateOtpRequest(
              otpId));
    }
  }

  @Nested
  @DisplayName("Delete Otp Cases")
  class DeleteOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToDeleteOtp() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = OtpContext.builder().build().getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteOtpRequest(
              otpId,
              WireMock.noContent())
      );

      client.deleteOTP(accessToken, otpId);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForDeleteOtpRequest(
              otpId));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = OtpContext.builder().build().getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteOtpRequest(
              otpId,
              HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.deleteOTP(accessToken, otpId))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForDeleteOtpRequest(
              otpId));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String otpId = OtpContext.builder().build().getOtpId();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteOtpRequest(otpId,
              HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.deleteOTP(accessToken, otpId))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForDeleteOtpRequest(
              otpId));
    }
  }

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToLogin() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              LoginClientContext.builder().build().getValidLoginClientResponse())
      );

      Assertions.assertDoesNotThrow(() -> client.login(accessToken, loginRequestModel));

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    /**
     * Testing that client throws LoginFailedException when returned null login resources
     */
    @Test
    void shouldReturnLoginFailedExceptionIfClientReturnsNullResources() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              LoginClientContext.builder().build().loginClientResponseReturnsNullResources())
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(LoginFailedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    /**
     * Testing that client throws UnauthorisedException when returned more than 1 login resource
     */
    @Test
    void shouldReturnUnauthorisedExceptionIfClientReturnsMultipleResources() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              LoginClientContext.builder().build().loginClientResponseReturnsMultipleResources())
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(UnauthorisedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    /**
     * Testing that client throws LoginFailedException when returned zero login resources
     */
    @Test
    void shouldReturnLoginFailedExceptionIfClientReturnsZeroResources() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              LoginClientContext.builder().build().loginClientResponseReturnsZeroResources())
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(LoginFailedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }


    @Test
    void shouldReturnUnauthorisedExceptionIfClientReturnsUnmappedErrorCode() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      ObjectNode payload = new ObjectMapper().createObjectNode();
      ArrayNode resources = new ObjectMapper().createArrayNode();
      ObjectNode error = new ObjectMapper().createObjectNode();
      error.put("errorcode", -1);
      resources.add(error);
      payload.set("Resources", resources);

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              payload)
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(UnauthorisedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    /**
     * Testing that client throws LoginFailedException when the login error code is 10 or 49
     */
    @ParameterizedTest
    @ValueSource(ints = {10, 49})
    void shouldReturnLoginFailedExceptionIfClientReturnsSpecificErrorCode(int errorCode) throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      ObjectNode payload = new ObjectMapper().createObjectNode();
      ArrayNode resources = new ObjectMapper().createArrayNode();
      ObjectNode error = new ObjectMapper().createObjectNode();
      error.put("errorcode", errorCode);
      resources.add(error);
      payload.set("Resources", resources);

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              payload)
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(LoginFailedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    /**
     * Testing that client throws AccountLockedException when the login error code is 1
     */
    @Test
    void shouldReturnAccountLockedExceptionIfClientReturnsSpecificErrorCode() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      ObjectNode payload = new ObjectMapper().createObjectNode();
      ArrayNode resources = new ObjectMapper().createArrayNode();
      ObjectNode error = new ObjectMapper().createObjectNode();
      error.put("errorcode", 1);
      resources.add(error);
      payload.set("Resources", resources);

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(),
              payload)
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(AccountLockedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    /**
     * Testing that client throws PasswordExpiredException when the login error code is 0
     */
    @Test
    void shouldReturnPasswordExpiredExceptionIfClientReturnsSpecificErrorCode() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
              .build().createLoginRequestModel();

      ObjectNode payload = new ObjectMapper().createObjectNode();
      ArrayNode resources = new ObjectMapper().createArrayNode();
      ObjectNode error = new ObjectMapper().createObjectNode();
      error.put("errorcode", 0);
      resources.add(error);
      payload.set("Resources", resources);

      WireMock.stubFor(
              CustomerIdentityManagementWireMockServer.mappingLoginRequest(
                      loginRequestModel.getUsername(),
                      payload)
      );

      assertThatThrownBy(
              () -> client.login(accessToken, loginRequestModel))
              .isInstanceOf(PasswordExpiredException.class);

      WireMock.verify(
              exactly(1),
              CustomerIdentityManagementWireMockServer.patternForLoginRequest(
                      loginRequestModel.getUsername()));
    }


    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(), HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final LoginRequestModel loginRequestModel = LoginContext.builder()
          .build().createLoginRequestModel();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingLoginRequest(
              loginRequestModel.getUsername(), HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.login(accessToken, loginRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForLoginRequest(
              loginRequestModel.getUsername()));
    }
  }

  @Nested
  @DisplayName("Get Customer Cases")
  class GetCustomerCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToGetCustomer() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = CustomerContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetCustomerRequest(
              username,
              GetCustomerClientContext.builder().build().getValidGetCustomerClientResponse())
      );

      client.getCustomer(accessToken, username);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetCustomerRequest(
              username));
    }

    /**
     * Testing happy path call to client returns the correct result
     */
    @Test
    void shouldReturnGetCustomerResponseModel() throws IOException {
      CustomerContext context = CustomerContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = context.getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetCustomerRequest(
              username,
              GetCustomerClientContext.builder().build().getValidGetCustomerClientResponse())
      );

      GetCustomerResponseModel result = client.getCustomer(accessToken, username);

      GetCustomerResponseModel expected = context.createGetCustomerResponseModel();

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetCustomerRequest(
              username));

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing that client throws InvalidDataResponseException when returned more than 1 customer
     */
    @Test
    void shouldReturnInvalidDataResponseExceptionIfClientReturnsMoreThanOneCustomer() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = CustomerContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetCustomerRequest(
              username,
              GetCustomerClientContext.builder().build()
                  .getCustomerClientResponseReturnsMultipleCustomers())
      );

      assertThatThrownBy(
          () -> client.getCustomer(accessToken, username))
          .isInstanceOf(InvalidDataResponseException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetCustomerRequest(
              username));
    }

    /**
     * Testing that client throws InvalidDataResponseException when returned no customers
     */
    @Test
    void shouldReturnUserNotFoundExceptionIfClientReturnsNoCustomers() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = CustomerContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetCustomerRequest(
              username,
              GetCustomerClientContext.builder().build()
                  .getCustomerClientResponseReturnsNoCustomers())
      );

      assertThatThrownBy(
          () -> client.getCustomer(accessToken, username))
          .isInstanceOf(UserNotFoundException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetCustomerRequest(
              username));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = CustomerContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetCustomerRequest(username,
              HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.getCustomer(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetCustomerRequest(
              username));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = CustomerContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetCustomerRequest(username,
              HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.getCustomer(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetCustomerRequest(
              username));
    }
  }

  @Nested
  @DisplayName("Get User Cases")
  class GetUserCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToGetUser() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = LoginContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetUserRequest(
              username,
              GetUserClientContext.builder().build().getValidGetUserClientResponse())
      );

      client.getUser(accessToken, username);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetUserRequest(
              username));
    }

    /**
     * Testing happy path call to client returns the correct result
     */
    @Test
    void shouldReturnGetUserResponseModel() throws IOException {
      LoginContext context = LoginContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = context.getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetUserRequest(
              username,
              GetUserClientContext.builder().build().getValidGetUserClientResponse())
      );

      GetUserResponseModel result = client.getUser(accessToken, username);

      GetUserResponseModel expected = context.createGetUserResponseModel();

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetUserRequest(
              username));

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing that client throws InvalidDataResponseException when returned more than 1 user
     */
    @Test
    void shouldReturnInvalidDataResponseExceptionIfClientReturnsMoreThanOneUser() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = LoginContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetUserRequest(
              username,
              GetUserClientContext.builder().build().getUserClientResponseReturnsMultipleUsers())
      );

      assertThatThrownBy(
          () -> client.getUser(accessToken, username))
          .isInstanceOf(InvalidDataResponseException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetUserRequest(
              username));
    }

    /**
     * Testing that client throws InvalidDataResponseException when returned no users
     */
    @Test
    void shouldReturnUserNotFoundExceptionIfClientReturnsNoUsers() throws IOException {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = LoginContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetUserRequest(
              username,
              GetUserClientContext.builder().build().getUserClientResponseReturnsNoUsers())
      );

      assertThatThrownBy(
          () -> client.getUser(accessToken, username))
          .isInstanceOf(UserNotFoundException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetUserRequest(
              username));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = LoginContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetUserRequest(username,
              HttpStatus.BAD_REQUEST)
      );

      assertThatThrownBy(
          () -> client.getUser(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetUserRequest(
              username));
    }

    @Test
    void shouldReturnRemoteRequestFailedForInternalServerErrorResponse() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final String username = LoginContext.builder().build().getUsername();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetUserRequest(username,
              HttpStatus.INTERNAL_SERVER_ERROR)
      );

      assertThatThrownBy(
          () -> client.getUser(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetUserRequest(
              username));
    }
  }

  @Nested
  @DisplayName("Validate OTP Cases")
  class ValidateOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToValidateOtp() throws IOException {

      OtpValidateClientContext clientContext = OtpValidateClientContext.builder().build();
      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.validateOtp(accessToken, context.createOtpValidateRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @ParameterizedTest
    @ValueSource(strings = {"INVALID_OTP"})
    void shouldReturnOtpExceptionWithInvalidCredentialsForInvalidUsernameOrOtp(
        String returnCode) throws IOException {

      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .returnCode(OtpValidateReturnCode.valueOf(returnCode))
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_CREDENTIALS);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnOtpExceptionWithOtpExpiredForExpiredOtp() throws IOException {

      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .returnCode(OtpValidateReturnCode.OTP_EXPIRED)
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_EXPIRED);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnOtpExceptionWithAccountLockedForALockedAccount() throws IOException {

      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .returnCode(OtpValidateReturnCode.ACCOUNT_LOCKED)
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.ACCOUNT_LOCKED);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnOtpExceptionWithInvalidCredentialsIfValidateOtpReturnsZeroTotalResults() throws IOException {
      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .totalResults(0)
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_CREDENTIALS);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @ParameterizedTest
    @ValueSource(ints = {
        2,
        3,
        10
    })
    void shouldReturnOtpExceptionWithOtpValidationFailedIfValidateOtpReturnsMoreThanOneTotalResults(
        int totalResults) throws IOException {
      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .totalResults(totalResults)
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "OTP_ALREADY_USED",
        "DECODING_FAILED",
        "UNKNOWN_SERVICE_ERROR",
        "MULTIPLE_RECORDS_FOUND",
        "NO_RECORDS_FOUND"
    })
    void shouldReturnOtpExceptionWithOtpValidationFailedIfValidateOtpReturnsDifferentReturnCode(
        String returnCode) throws IOException {

      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .returnCode(OtpValidateReturnCode.valueOf(returnCode))
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnOtpExceptionWithOtpValidationFailedIfValidateOtpReturnsNullReturnCode() throws IOException {

      OtpValidateClientContext clientContext = OtpValidateClientContext.builder()
          .returnCode(null)
          .build();

      OtpContext context = OtpContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(clientContext.createOtpValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(OtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedForErrorResponse() {
      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateOtpRequest(WireMock.serverError())
      );

      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(
          () -> client.validateOtp(accessToken, otpValidateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForValidateOtpRequest()
      );
    }
  }

  @Nested
  @DisplayName("Set Password Cases")
  class SetPasswordCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToSetPassword() throws JsonProcessingException {

      SetPasswordClientContext clientContext = SetPasswordClientContext.builder().build();
      ActivationContext context = ActivationContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetPasswordRequest(WireMock.noContent()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.setPassword(accessToken, context.createUserSetPasswordRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForSetPasswordRequest(
              objectMapper.writeValueAsString(clientContext.createSetPasswordClientRequest())));
    }

    @Test
    void shouldReturnInvalidPasswordExceptionIfResponseIsBadRequest()
        throws JsonProcessingException {

      SetPasswordClientContext clientContext = SetPasswordClientContext.builder().build();
      ActivationContext context = ActivationContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetPasswordRequest(
              CustomerIdentityManagementWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST)));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      UserSetPasswordRequestModel userSetPasswordRequestModel = context
          .createUserSetPasswordRequestModel();
      assertThatThrownBy(() ->
          client.setPassword(accessToken,
              userSetPasswordRequestModel)).isInstanceOf(
          InvalidDetailsException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForSetPasswordRequest(
              objectMapper.writeValueAsString(clientContext.createSetPasswordClientRequest())));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() throws JsonProcessingException {

      SetPasswordClientContext clientContext = SetPasswordClientContext.builder().build();
      ActivationContext context = ActivationContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetPasswordRequest(
              WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      UserSetPasswordRequestModel userSetPasswordRequestModel = context
          .createUserSetPasswordRequestModel();

      assertThatThrownBy(
          () -> client.setPassword(accessToken, userSetPasswordRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForSetPasswordRequest(
              objectMapper.writeValueAsString(clientContext.createSetPasswordClientRequest())));
    }
  }

  @Nested
  @DisplayName("Change Password Cases")
  class ChangePasswordCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToChangePassword() throws JsonProcessingException {

      ChangePasswordClientContext clientContext = ChangePasswordClientContext.builder().build();
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetPasswordRequest(WireMock.noContent()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.changePassword(accessToken, context.createUserChangePasswordRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForSetPasswordRequest(
              objectMapper.writeValueAsString(clientContext.createSetPasswordClientRequest())));
    }

    @Test
    void shouldReturnInvalidPasswordExceptionIfResponseIsBadRequest()
        throws JsonProcessingException {

      ChangePasswordClientContext clientContext = ChangePasswordClientContext.builder().build();
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetPasswordRequest(
              CustomerIdentityManagementWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST)));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      UserChangePasswordRequestModel userChangePasswordRequestModel = context
          .createUserChangePasswordRequestModel();
      assertThatThrownBy(() ->
          client.changePassword(accessToken,
              userChangePasswordRequestModel)).isInstanceOf(
          InvalidDetailsException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForSetPasswordRequest(
              objectMapper.writeValueAsString(clientContext.createSetPasswordClientRequest())));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() throws JsonProcessingException {

      ChangePasswordClientContext clientContext = ChangePasswordClientContext.builder().build();
      PasswordChangeContext context = PasswordChangeContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetPasswordRequest(
              WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      UserChangePasswordRequestModel userChangePasswordRequestModel = context
          .createUserChangePasswordRequestModel();

      assertThatThrownBy(
          () -> client.changePassword(accessToken, userChangePasswordRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForSetPasswordRequest(
              objectMapper.writeValueAsString(clientContext.createSetPasswordClientRequest())));
    }
  }

  @Nested
  @DisplayName("Activate User Cases")
  class ActivateUserCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallCustomerIdentityManagementClientToActivateUser() throws JsonProcessingException {
      ActivateUserClientContext clientContext = ActivateUserClientContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingActivateUserRequest(WireMock.ok()));

      client.activateAccount(accessToken, clientContext.customerId);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForActivateUserRequest(
              objectMapper.writeValueAsString(clientContext.createActivateUserClientRequest())));
    }


    @Test
    void shouldReturnRemoteRequestFailedForErrorResponse() throws JsonProcessingException {
      ActivateUserClientContext clientContext = ActivateUserClientContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingActivateUserRequest(
              WireMock.serverError()));

      assertThatThrownBy(
          () -> client.activateAccount(accessToken, clientContext.customerId))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForActivateUserRequest(
              objectMapper.writeValueAsString(clientContext.createActivateUserClientRequest())));
    }
  }

  @Nested
  @DisplayName("Set Security Question Cases")
  class SetSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToSetSecurityQuestions()
        throws JsonProcessingException {

      SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();
      ActivationContext context = ActivationContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetSecurityQuestionsRequest(
              WireMock.created()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.createSecurityQuestions(accessToken, context.createSecurityQuestionsRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForSetSecurityQuestionsRequest(
              objectMapper.writeValueAsString(
                  clientContext.createSecurityQuestionsClientRequest())));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() throws JsonProcessingException {

      SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();
      ActivationContext context = ActivationContext.builder().build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingSetSecurityQuestionsRequest(
              WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      SecurityQuestionsRequestModel securityQuestionsRequestModel = context
          .createSecurityQuestionsRequestModel();

      assertThatThrownBy(
          () -> client.createSecurityQuestions(accessToken,
              securityQuestionsRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForSetSecurityQuestionsRequest(
              objectMapper.writeValueAsString(
                  clientContext.createSecurityQuestionsClientRequest())));
    }

  }

  @Nested
  @DisplayName("Get Security Question Cases")
  class GetSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToGetSecurityQuestions() throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();
      final AccountManagementContext context = AccountManagementContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetSecurityQuestionsRequest(
              clientContext.getParentId(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createSecurityQuestionsClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      final SecurityQuestionsFetchResponseModel securityQuestions = client.getSecurityQuestions(
          accessToken, clientContext.getParentId());
      assertThat(securityQuestions.getId()).isEqualTo(clientContext.getQuestionsId());
      assertThat(securityQuestions.getSecurityQuestions()).isEqualTo(
          context.getSecurityQuestions());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetSecurityQuestionsRequest(
              clientContext.getParentId()));
    }


    @Test
    void shouldGetSecurityQuestionsIfQuestionsListIsEmpty() throws IOException {

      // constructs a response with an empty list of questions
      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .questions(Collections.emptyMap())
          .build();
      final AccountManagementContext context = AccountManagementContext.builder()
          .securityQuestions(Collections.emptyList())
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetSecurityQuestionsRequest(
              clientContext.getParentId(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createSecurityQuestionsClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      final SecurityQuestionsFetchResponseModel securityQuestions = client.getSecurityQuestions(
          accessToken, clientContext.getParentId());
      assertThat(securityQuestions.getSecurityQuestions()).isEqualTo(
          context.getSecurityQuestions());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetSecurityQuestionsRequest(
              clientContext.getParentId()));
    }

    @Test
    void shouldThrowSecurityQuestionNotFoundExceptionIfQuestionsMissing() throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetSecurityQuestionsRequest(
              clientContext.getParentId(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createMissingSecurityQuestionsClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.getSecurityQuestions(accessToken, clientContext.getParentId()))
          .isInstanceOf(SecurityQuestionNotFoundException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetSecurityQuestionsRequest(
              clientContext.getParentId()));
    }

    @Test
    void shouldThrowSecurityQuestionNotFoundExceptionIfResourcesListIsEmpty() throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetSecurityQuestionsRequest(
              clientContext.getParentId(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createEmptySecurityQuestionsClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.getSecurityQuestions(accessToken, clientContext.getParentId()))
          .isInstanceOf(SecurityQuestionNotFoundException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForGetSecurityQuestionsRequest(
              clientContext.getParentId()));
    }

    @Test
    void shouldReturnRemoteRequestFailedForServerError() {

      SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingGetSecurityQuestionsRequest(
              clientContext.getParentId(),
              WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.getSecurityQuestions(accessToken, clientContext.getParentId()))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForGetSecurityQuestionsRequest(
              clientContext.getParentId()));
    }
  }

  @Nested
  @DisplayName("Validate Security Question Cases")
  class ValidateSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToValidateSecurityQuestion() throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateSecurityQuestionRequest(
              clientContext.getUsername(),
              clientContext.getValidationHeader(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createSecurityQuestionsValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.validateSecurityQuestion(accessToken,
          clientContext.createSecurityQuestionsValidationRequestModel());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateSecurityQuestionsRequest(
              clientContext.getUsername()));
    }

    @ParameterizedTest
    @EnumSource(
        value = SecurityQuestionValidateReturnCode.class,
        names = {"INVALID_QUESTION_ANSWER"})
    void shouldThrowSecurityQuestionValidateExceptionWhenInvalidAnswerResponse(
        SecurityQuestionValidateReturnCode returnCode) throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .returnCode(returnCode)
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateSecurityQuestionRequest(
              clientContext.getUsername(),
              clientContext.getValidationHeader(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createSecurityQuestionsValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.validateSecurityQuestion(accessToken,
              clientContext.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(SecurityQuestionValidateException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateSecurityQuestionsRequest(
              clientContext.getUsername()));
    }

    @ParameterizedTest
    @EnumSource(
        value = SecurityQuestionValidateReturnCode.class,
        names = {"DECODING_FAILURE", "UNKNOWN_SERVICE_FAILURE"})
    void shouldThrowSecurityQuestionResponseExceptionWhenUnexpectedErrorResponse(
        SecurityQuestionValidateReturnCode returnCode) throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .returnCode(returnCode)
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateSecurityQuestionRequest(
              clientContext.getUsername(),
              clientContext.getValidationHeader(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createSecurityQuestionsValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.validateSecurityQuestion(accessToken,
              clientContext.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(SecurityQuestionResponseException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateSecurityQuestionsRequest(
              clientContext.getUsername()));
    }

    @ParameterizedTest
    @EnumSource(
        value = SecurityQuestionValidateReturnCode.class,
        names = {"QUESTIONS_LOCKED"})
    void shouldThrowSSecurityQuestionLockedExceptionWhenQuestionsLocked(
        SecurityQuestionValidateReturnCode returnCode) throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .returnCode(returnCode)
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateSecurityQuestionRequest(
              clientContext.getUsername(),
              clientContext.getValidationHeader(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createSecurityQuestionsValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.validateSecurityQuestion(accessToken,
              clientContext.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(SecurityQuestionLockedException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateSecurityQuestionsRequest(
              clientContext.getUsername()));
    }

    @Test
    void shouldThrowSecurityQuestionValidateExceptionIfResourceListIsEmptyMissing() throws IOException {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateSecurityQuestionRequest(
              clientContext.getUsername(),
              clientContext.getValidationHeader(),
              jsonResponse(HttpStatus.OK,
                  objectMapper.valueToTree(
                      clientContext.createEmptySecurityQuestionsValidateClientResponse()))));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.validateSecurityQuestion(accessToken,
              clientContext.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(SecurityQuestionResponseException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForValidateSecurityQuestionsRequest(
              clientContext.getUsername()));
    }

    @Test
    void shouldThrowRemoteRequestFailedForServerError() {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingValidateSecurityQuestionRequest(
              clientContext.getUsername(),
              clientContext.getValidationHeader(),
              WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.validateSecurityQuestion(accessToken,
              clientContext.createSecurityQuestionsValidationRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForValidateSecurityQuestionsRequest(
              clientContext.getUsername()));
    }
  }

  @Nested
  @DisplayName("Delete Security Question Cases")
  class DeleteSecurityQuestionCases {

    @Test
    void shouldCallCustomerIdentityManagementClientToDeleteSecurityQuestions() {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteSecurityQuestionsRequest(
              clientContext.getQuestionsId(),
              WireMock.noContent()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      client.deleteSecurityQuestions(accessToken, clientContext.getQuestionsId());

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForDeleteSecurityQuestionsRequest(
              clientContext.getQuestionsId()));
    }

    @Test
    void shouldThrowInvalidDetailsForQuestionsNotFound() {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteSecurityQuestionsRequest(
              clientContext.getQuestionsId(),
              WireMock.notFound()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.deleteSecurityQuestions(accessToken, clientContext.getQuestionsId()))
          .isInstanceOf(InvalidDetailsException.class);

      WireMock.verify(
          exactly(1),
          CustomerIdentityManagementWireMockServer.patternForDeleteSecurityQuestionsRequest(
              clientContext.getQuestionsId()));
    }

    @Test
    void shouldThrowRemoteRequestFailedForServerError() {

      final SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      WireMock.stubFor(
          CustomerIdentityManagementWireMockServer.mappingDeleteSecurityQuestionsRequest(
              clientContext.getQuestionsId(),
              WireMock.serverError()));

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      assertThatThrownBy(
          () -> client.deleteSecurityQuestions(accessToken, clientContext.getQuestionsId()))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(
          exactly(EXPECTED_FAILURE_RETRIES),
          CustomerIdentityManagementWireMockServer.patternForDeleteSecurityQuestionsRequest(
              clientContext.getQuestionsId()));
    }
  }

  static ResponseDefinitionBuilder jsonResponse(HttpStatus status, ObjectNode body) {
    return WireMock.status(status.value())
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        .withBody(body.toString());
  }
}
