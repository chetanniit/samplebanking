package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsSingleValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationResponseModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsRequest;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Getter
@ToString
@Builder
@Slf4j
public class AccountManagementContext {

  @Builder.Default
  private String username = "TestUsername";

  @Builder.Default
  private BrokerTypeModel brokerType = BrokerTypeModel.BROKER;

  @Builder.Default
  private List<SecurityQuestionsFetchResponseModel.SecurityQuestion> securityQuestions = Collections.singletonList(
      SecurityQuestionsFetchResponseModel.SecurityQuestion.builder()
          .id("q1")
          .question("test question?")
          .build()
  );

  @Builder.Default
  private String id = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Builder.Default
  private String parentId = "uid=a8f15690-6a66-4cae-9897-67d7db858677,ou=customer,ou=personaidentity,ou=common,dc=carnus";

  @Builder.Default
  private String question = "test question?";

  @Builder.Default
  private String answer = "test answer";

  @Builder.Default
  private String questionId = "1f9c267f-01fe-416f-b74d-f4dec2cc7a3e";

  @Default
  private String otpCode = "RHF342wp";

  public SecurityQuestionsFetchRequestModel createSecurityQuestionsFetchRequestModel() {
    return SecurityQuestionsFetchRequestModel.builder()
        .username(username)
        .build();
  }

  public SecurityQuestionsChangeRequestModel createSecurityQuestionsChangeRequestModel() {
    return SecurityQuestionsChangeRequestModel.builder()
        .username(username)
        .questions(Arrays.asList(
            SecurityQuestion.builder().question(question).answer(answer).build(),
            SecurityQuestion.builder().question(question).answer(answer).build()
        ))
        .build();
  }

  public SecurityQuestionsRequestModel createSecurityQuestionsRequestModel() {
    return SecurityQuestionsRequestModel.builder()
        .parentId(parentId)
        .questions(Arrays.asList(
            SecurityQuestion.builder().question(question).answer(answer).build(),
            SecurityQuestion.builder().question(question).answer(answer).build()
        ))
        .build();
  }

  public SecurityQuestionsRequestModel createRandomSecurityQuestionsRequestModel() {
    return SecurityQuestionsRequestModel.builder()
        .parentId(parentId)
        .questions(Arrays.asList(
            SecurityQuestion.builder()
                .question("Random question 1")
                .answer("Random answer 1")
                .build(),
            SecurityQuestion.builder()
                .question("Random question 2")
                .answer("Random answer 2")
                .build()
        ))
        .build();
  }

  public ChangeMemorableQuestionsRequest createChangeMemorableQuestionsRequest() {
    return ChangeMemorableQuestionsRequest.builder()
        .username(username)
        .questions(Arrays.asList(
            ChangeMemorableQuestionsRequest.SecurityQuestion.builder().question(question)
                .answer(answer).build(),
            ChangeMemorableQuestionsRequest.SecurityQuestion.builder().question(question)
                .answer(answer).build()
        ))
        .build();
  }

  public GetUserResponseModel createGetUserResponseModel() {
    return GetUserResponseModel.builder()
        .brokerType(brokerType)
        .id(id)
        .parentId(parentId)
        .build();
  }

  public SecurityQuestionsFetchResponseModel createSecurityQuestionsFetchResponseModel() {
    return SecurityQuestionsFetchResponseModel.builder()
        .id(id)
        .securityQuestions(securityQuestions)
        .build();
  }

  public SecurityQuestionsSingleValidationRequestModel createSecuritySingleQuestionsValidationRequestModel() {
    return SecurityQuestionsSingleValidationRequestModel.builder()
        .username(username)
        .question(SecurityQuestion.builder().question(question).answer(answer).build())
        .build();
  }

  public SecurityQuestionsValidationRequestModel createSecurityQuestionsValidationRequestModel() {
    return SecurityQuestionsValidationRequestModel.builder()
        .username(username)
        .questions(Arrays.asList(
            SecurityQuestion.builder().question(question).answer(answer).build(),
            SecurityQuestion.builder().question(question).answer(answer).build()
        ))
        .build();
  }

  public SecurityQuestionsValidationResponseModel createSecurityQuestionsValidationResponseModel() {
    return SecurityQuestionsValidationResponseModel.builder()
        .otpCode(otpCode)
        .brokerTypeModel(brokerType)
        .build();
  }

  public ChallengeAnswersRequest createChallengeAnswersRequestModel() {
    return ChallengeAnswersRequest.builder()
        .username(username)
        .securityQuestions(Arrays.asList(
            ChallengeAnswersRequest.SecurityQuestion.builder().question(question).answer(answer)
                .build(),
            ChallengeAnswersRequest.SecurityQuestion.builder().question(question).answer(answer)
                .build()
        ))
        .build();
  }

  public RetrieveMemorableQuestionsRequest createRetrieveMemorableQuestionsRequest() {
    return RetrieveMemorableQuestionsRequest.builder()
        .username(username)
        .build();
  }

}
