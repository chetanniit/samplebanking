package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SetPasswordClientRequest;
import java.util.Collections;
import java.util.List;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class SetPasswordClientContext {

  @Default
  private String customerId = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Default
  private String password = "Password123";

  @Default
  private List<String> schemas = Collections.singletonList(
      "urn:pingidentity:scim:api:messages:2.0:PasswordUpdateRequest");

  public SetPasswordClientRequest createSetPasswordClientRequest() {
    return SetPasswordClientRequest.builder()
        .password(password)
        .schemas(schemas)
        .build();
  }


}
