package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse.OtpRetrieveResources;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class OtpRetrieveClientContext {

  @Default
  private List<OtpRetrieveResourcesContext> otpResources = Collections.singletonList(
      OtpRetrieveResourcesContext.getOtpResourcesBuilder().build());

  public OtpRetrieveClientResponse createOtpRetrieveClientResponse() {
    List<OtpRetrieveResources> getOtpResources = Optional.ofNullable(otpResources)
        .orElse(Collections.emptyList())
        .stream()
        .map(OtpRetrieveResourcesContext::getOtpResources)
        .collect(Collectors.toList());

    return OtpRetrieveClientResponse.builder()
        .resources(getOtpResources)
        .build();
  }

  public OtpRetrieveClientResponse.OtpRetrieveClientResponseBuilder createOtpRetrieveClientResponseBuilder() {
    List<OtpRetrieveResources> getOtpResources = Optional.ofNullable(otpResources)
        .orElse(Collections.emptyList())
        .stream()
        .map(OtpRetrieveResourcesContext::getOtpResources)
        .collect(Collectors.toList());

    return OtpRetrieveClientResponse.builder()
        .resources(getOtpResources);
  }

  public ObjectNode getValidOtpRetrieveClientResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(otpResources.stream()
            .map(OtpRetrieveResourcesContext::getOtpResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }


  public ObjectNode otpRetrieveClientResponseReturnsMultipleOtps() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode()
        .addAll(otpResources.stream()
            .map(OtpRetrieveResourcesContext::getOtpResourcesPayload)
            .collect(Collectors.toList())
        )
        .addAll(otpResources.stream()
            .map(OtpRetrieveResourcesContext::getOtpResourcesPayload)
            .collect(Collectors.toList())
        );

    payload.set("Resources", resources);
    return payload;
  }

  public ObjectNode otpRetrieveClientResponseReturnsNoOtps() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    ArrayNode resources = new ObjectMapper().createArrayNode();

    payload.set("Resources", resources);
    return payload;
  }
}
