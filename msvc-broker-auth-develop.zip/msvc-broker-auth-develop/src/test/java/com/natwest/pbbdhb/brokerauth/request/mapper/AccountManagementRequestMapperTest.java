package com.natwest.pbbdhb.brokerauth.request.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.natwest.pbbdhb.brokerauth.contexts.AccountManagementContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordChangeContext;
import com.natwest.pbbdhb.brokerauth.contexts.PasswordResetContext;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.PasswordChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.PasswordResetRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsChangeRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsValidationRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserChangePasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ChallengeAnswersRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.OtpValidateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordResetRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Testing the Account Management business domain model mapping.
 */
class AccountManagementRequestMapperTest {

  @Nested
  @DisplayName("toPasswordResetRequestModel Cases")
  class ToPasswordResetRequestModelCases {

    @Test
    void toPasswordResetRequestModelFromPasswordResetRequest() {
      PasswordResetRequest requestModel = PasswordResetContext.builder().build()
          .createPasswordResetRequest();

      PasswordResetRequestModel domainModel = AccountManagementRequestMapper.toPasswordResetRequestModel(
          requestModel);

      assertEquals(domainModel.getUsername(), requestModel.getUsername());
      assertEquals(domainModel.getOtpCode(), requestModel.getOtpCode());
      assertEquals(domainModel.getPassword(), requestModel.getPassword());
    }

    /**
     * Testing error case when trying to map over a null reference for PasswordResetRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForPasswordResetRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          AccountManagementRequestMapper.toPasswordResetRequestModel(null)
      );
    }
  }

  @Nested
  @DisplayName("toChangeSecurityQuestionRequestModel Cases")
  class ToChangeSecurityQuestionRequestModelCases {

    @Test
    void toSecurityQuestionsValidationRequestModelFromChallengeAnswerRequest() {
      ChallengeAnswersRequest requestModel = AccountManagementContext.builder().build()
          .createChallengeAnswersRequestModel();

      SecurityQuestionsValidationRequestModel domainModel = AccountManagementRequestMapper.toSecurityQuestionsValidationRequestModel(
          requestModel);

      assertEquals(domainModel.getUsername(), requestModel.getUsername());
      assertEquals(domainModel.getQuestions().size(), requestModel.getSecurityQuestions().size());
      assertEquals(domainModel.getQuestions().get(0).getQuestion(), requestModel.getSecurityQuestions().get(0).getQuestion());
    }

    @Test
    void toSecurityQuestionsValidationRequestModelFromChangeMemorableQuestionsRequest() {
      ChangeMemorableQuestionsRequest requestModel = AccountManagementContext.builder().build()
          .createChangeMemorableQuestionsRequest();

      SecurityQuestionsChangeRequestModel domainModel = AccountManagementRequestMapper.toSecurityQuestionsChangeRequestModel(
          requestModel);

      assertEquals(domainModel.getUsername(), requestModel.getUsername());
      assertEquals(domainModel.getQuestions().size(), requestModel.getQuestions().size());
      assertEquals(domainModel.getQuestions().get(0).getQuestion(), requestModel.getQuestions().get(0).getQuestion());
    }

    /**
     * Testing error case when trying to map over a null reference for ChallengeAnswersRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForChallengeAnswersRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          AccountManagementRequestMapper.toSecurityQuestionsValidationRequestModel(null)
      );
    }

    /**
     * Testing error case when trying to map over a null reference for ChangeMemorableQuestionsRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForChangeMemorableQuestionsRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          AccountManagementRequestMapper.toSecurityQuestionsChangeRequestModel(null)
      );
    }
  }

  @Nested
  @DisplayName("toOtpValidateRequestModel Cases")
  class ToOtpValidateRequestModelCases {

    @Test
    void toOtpValidateRequestModelFromOtpValidateRequest() {
      OtpValidateRequest request = OtpContext.builder().build()
          .createOtpValidateRequest();

      OtpValidateRequestModel domainModel = AccountManagementRequestMapper.toOtpValidateRequestModel(
          request);

      assertEquals(domainModel.getUsername(), request.getUsername());
      assertEquals(domainModel.getOtpCode(), request.getOtpCode());
    }

    /**
     * Testing error case when trying to map over a null reference for OtpValidateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForOtpValidateRequest() {
      Assertions.assertThrows(RuntimeException.class, () ->
          AccountManagementRequestMapper.toOtpValidateRequestModel((OtpValidateRequest) null)
      );
    }

    @Test
    void toOtpValidateRequestModelFromPasswordReset() {
      PasswordResetRequestModel request = PasswordResetContext.builder().build()
          .createPasswordResetRequestModel();

      OtpValidateRequestModel domainModel = AccountManagementRequestMapper.toOtpValidateRequestModel(
          request);

      assertEquals(domainModel.getUsername(), request.getUsername());
      assertEquals(domainModel.getOtpCode(), request.getOtpCode());
    }

    /**
     * Testing error case when trying to map over a null reference for OtpValidateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForOtpValidateRequestFromePasswordReset() {
      Assertions.assertThrows(RuntimeException.class, () ->
          AccountManagementRequestMapper.toOtpValidateRequestModel((PasswordResetRequestModel) null)
      );
    }
  }

  @Nested
  @DisplayName("toUserSetPasswordRequestModel Cases")
  class ToUserSetPasswordRequestModelCases {

    @Test
    void toUserSetPasswordRequestModelFromPasswordResetRequestModel() {
      PasswordResetContext context = PasswordResetContext.builder().build();
      PasswordResetRequestModel request = context.createPasswordResetRequestModel();

      UserSetPasswordRequestModel domainModel = AccountManagementRequestMapper.toUserSetPasswordRequestModel(
          request, context.getId());

      assertEquals(domainModel.getCustomerIdentifier(), context.getId());
      assertEquals(domainModel.getPassword(), request.getPassword());
    }

    /**
     * Testing error case when trying to map over a null reference for OtpValidateRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForPasswordResetRequestModel() {
      PasswordResetContext context = PasswordResetContext.builder().build();
      Assertions.assertThrows(RuntimeException.class, () ->
              AccountManagementRequestMapper.toOtpValidateRequestModel(
                  (PasswordResetRequestModel) null),
          context.getId());
    }
  }

  @Nested
  @DisplayName("toUserChangePasswordRequestModel Cases")
  class ToUserChangePasswordRequestModelCases {

    @Test
    void toUserChangePasswordRequestModelFromPasswordChangeRequestModel() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();
      PasswordChangeRequestModel request = context.createPasswordChangeRequestModel();

      UserChangePasswordRequestModel domainModel = AccountManagementRequestMapper.toUserChangePasswordRequestModel(
          request, context.getId());

      assertEquals(domainModel.getCustomerIdentifier(), context.getId());
      assertEquals(domainModel.getCurrentPassword(), request.getCurrentPassword());
      assertEquals(domainModel.getNewPassword(), request.getNewPassword());
    }

    /**
     * Testing error case when trying to map over a null reference for PasswordChangeRequest.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForPasswordChangeRequestModel() {
      PasswordChangeContext context = PasswordChangeContext.builder().build();
      Assertions.assertThrows(RuntimeException.class, () ->
              AccountManagementRequestMapper.toPasswordChangeRequestModel(
                  (PasswordChangeRequest) null),
          context.getId());
    }
  }
}
