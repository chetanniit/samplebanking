package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetailsCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetailsPaymentPath;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.PrincipalFcaFirm;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Testing the Firm Details model mapping.
 */
class FirmDetailsMapperTest {

  private static final String FCA_NUMBER = "fcaNumber";
  private static final String PRINCIPAL_FIRM_NAME_1 = "principalFirmFcaNumber1";
  private static final String PRINCIPAL_FIRM_FCA_NUMBER_1 = "principalFirmFcaNumber1";
  private static final String PRINCIPAL_FIRM_NAME_2 = "principalFirmFcaNumber2";
  private static final String PRINCIPAL_FIRM_FCA_NUMBER_2 = "principalFirmFcaNumber2";
  private static final String FIRM_TYPE = "firmType";
  private static final String ALTERNATIVE_TRADING_NAME_1 = "alternativeTradingName1";
  private static final String ALTERNATIVE_TRADING_NAME_2 = "alternativeTradingName2";
  private static final String PAYMENT_PATH_ID_1 = "paymentPathId1";
  private static final String PAYMENT_PATH_NAME_1 = "paymentPathName1";
  private static final String PAYMENT_PATH_ID_2 = "paymentPathId2";
  private static final String PAYMENT_PATH_NAME_2 = "paymentPathName2";


  @Nested
  @DisplayName("Firm Details Cases")
  class FirmDetailsCases {

    @Test
    void toFirmDetailsResponse() {
      final FirmDetailsCoreResponse firmDetailsCoreResponse = FirmDetailsCoreResponse.builder()
          .firmType(FIRM_TYPE)
          .alternativeTradingNames(Arrays.asList(
              TradingName.builder()
                  .name(ALTERNATIVE_TRADING_NAME_1)
                  .build(),
              TradingName.builder()
                  .name(ALTERNATIVE_TRADING_NAME_2)
                  .build()
          ))
          .paymentPaths(Arrays.asList(
              FirmDetailsPaymentPath.builder()
                  .name(PAYMENT_PATH_NAME_1)
                  .paymentId(PAYMENT_PATH_ID_1)
                  .build(),
              FirmDetailsPaymentPath.builder()
                  .name(PAYMENT_PATH_NAME_2)
                  .paymentId(PAYMENT_PATH_ID_2)
                  .build()))
          .principalFcaFirms(Arrays.asList(
              PrincipalFcaFirm.builder()
                  .fcaNumber(PRINCIPAL_FIRM_FCA_NUMBER_1)
                  .name(PRINCIPAL_FIRM_NAME_1)
                  .build(),
              PrincipalFcaFirm.builder()
                  .fcaNumber(PRINCIPAL_FIRM_FCA_NUMBER_2)
                  .name(PRINCIPAL_FIRM_NAME_2)
                  .build()
          ))
          .build();

      FirmDetailsResponse firmDetailsResponse = FirmDetailsMapper.toFirmDetailsResponse(firmDetailsCoreResponse, FCA_NUMBER);

      assertEquals(FIRM_TYPE, firmDetailsResponse.getBrokerType());
      assertEquals(FCA_NUMBER, firmDetailsResponse.getFcaNumber());
      assertEquals(ALTERNATIVE_TRADING_NAME_1, firmDetailsResponse.getTradingNames().get(0));
      assertEquals(ALTERNATIVE_TRADING_NAME_2, firmDetailsResponse.getTradingNames().get(1));
      assertEquals(PAYMENT_PATH_ID_1, firmDetailsResponse.getPaymentPaths().get(0).getPaymentId());
      assertEquals(PAYMENT_PATH_NAME_1, firmDetailsResponse.getPaymentPaths().get(0).getName());
      assertEquals(PAYMENT_PATH_ID_2, firmDetailsResponse.getPaymentPaths().get(1).getPaymentId());
      assertEquals(PAYMENT_PATH_NAME_2, firmDetailsResponse.getPaymentPaths().get(1).getName());
      assertEquals(PRINCIPAL_FIRM_NAME_1, firmDetailsResponse.getPrincipalFcaFirms().get(0).getName());
      assertEquals(PRINCIPAL_FIRM_FCA_NUMBER_1, firmDetailsResponse.getPrincipalFcaFirms().get(0).getFcaNumber());
      assertEquals(PRINCIPAL_FIRM_NAME_2, firmDetailsResponse.getPrincipalFcaFirms().get(1).getName());
      assertEquals(PRINCIPAL_FIRM_FCA_NUMBER_2, firmDetailsResponse.getPrincipalFcaFirms().get(1).getFcaNumber());
    }
  }
}
