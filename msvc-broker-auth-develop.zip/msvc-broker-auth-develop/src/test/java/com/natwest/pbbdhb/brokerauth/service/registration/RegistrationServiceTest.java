package com.natwest.pbbdhb.brokerauth.service.registration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.AccountManagementContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.UserContext;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsFetchResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserDeleteRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.exception.*;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeGenerateRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class RegistrationServiceTest {

  @Mock
  CustomerIdentityManagementClient customerIdentityManagementClient;

  @Nested
  @DisplayName("Create User Cases")
  class CreateUserCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallCustomerIdentityManagementClient() {
      UserCreateRequestModel userCreateRequestModel = UserContext.builder().build()
          .createUserCreateRequestModel();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      service.createUser(accessToken, userCreateRequestModel);

      verify(customerIdentityManagementClient).createUser(accessToken, userCreateRequestModel);

      verify(customerIdentityManagementClient).initialiseOtp(accessToken,
          userCreateRequestModel.getUsername());
    }

    @Test
    void shouldReturnErrorIfUserAlreadyExists() {
      UserContext context = UserContext.builder().build();
      UserCreateRequestModel userCreateRequestModel = context.createUserCreateRequestModel();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      doThrow(new UserAlreadyExistsException(context.getUsername()))
          .when(customerIdentityManagementClient).createUser(any(), any());

      assertThatThrownBy(() -> service.createUser(accessToken, userCreateRequestModel))
          .isInstanceOf(UserAlreadyExistsException.class);

      verify(customerIdentityManagementClient).createUser(accessToken, userCreateRequestModel);
    }

    @Test
    void shouldThrowRemoteFailureIfClientThrowsRemoteFailure() {
      UserContext context = UserContext.builder().build();
      UserCreateRequestModel userCreateRequestModel = context.createUserCreateRequestModel();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).createUser(any(), any());

      assertThatThrownBy(() -> service.createUser(accessToken, userCreateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).createUser(accessToken, userCreateRequestModel);
    }
  }

  @Nested
  @DisplayName("Delete User Cases")
  class DeleteUserCases {

    @Test
    void shouldContinueDeletionWhenNoOtpFound() {
      UserDeleteRequestModel userDeleteRequestModel = UserContext.builder().build()
              .createUserDeleteRequestModel();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      SecurityQuestionsFetchResponseModel securityQuestionsFetchResponseModel = accountManagementContext.createSecurityQuestionsFetchResponseModel();

      when(customerIdentityManagementClient.getUser(accessToken, userDeleteRequestModel.getUsername()))
              .thenReturn(accountManagementContext.createGetUserResponseModel());
      doThrow(new InvalidDataResponseException("No OTP found"))
              .when(customerIdentityManagementClient).retrieveOTP(any(), any());
      when(customerIdentityManagementClient.getSecurityQuestions(accessToken, accountManagementContext.getParentId()))
              .thenReturn(securityQuestionsFetchResponseModel);

      service.deleteUser(accessToken, userDeleteRequestModel);

      verify(customerIdentityManagementClient, times(1)).deleteSecurityQuestions(accessToken, securityQuestionsFetchResponseModel.getId());
      verify(customerIdentityManagementClient, times(1))
              .deleteUser(accessToken, accountManagementContext.getId(), userDeleteRequestModel);
    }

    @Test
    void shouldContinueDeletionWhenNoSecurityQuestionsFound() {
      UserDeleteRequestModel userDeleteRequestModel = UserContext.builder().build()
              .createUserDeleteRequestModel();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      final OtpContext otpContext = OtpContext.builder().build();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      OtpRetrieveResponseModel otpRetrieveDetailsModel = otpContext.createOtpRetrieveResponseModel();

      when(customerIdentityManagementClient.getUser(accessToken, userDeleteRequestModel.getUsername()))
              .thenReturn(accountManagementContext.createGetUserResponseModel());
      when(customerIdentityManagementClient.retrieveOTP(accessToken, userDeleteRequestModel.getUsername()))
              .thenReturn(otpRetrieveDetailsModel);

      doThrow(new SecurityQuestionNotFoundException("No questions found"))
              .when(customerIdentityManagementClient).getSecurityQuestions(any(), any());

      service.deleteUser(accessToken, userDeleteRequestModel);

      verify(customerIdentityManagementClient, times(1)).deleteOTP(accessToken, otpRetrieveDetailsModel.getOtpId());
      verify(customerIdentityManagementClient, times(1))
              .deleteUser(accessToken, accountManagementContext.getId(), userDeleteRequestModel);
    }
  }

  @Nested
  @DisplayName("Create Activation Codes Cases")
  class CreateActivationCodes {

    @Test
    void shouldCallCustomerIdentityManagementClient() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().build();
      final String username = otpContext.getUsername();
      final String otpId = otpContext.getOtpId();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      OtpRetrieveResponseModel otpRetrieveDetailsModel = otpContext.createOtpRetrieveResponseModel();
      OtpGenerateResponseModel otpGenerateDetailsModel = otpContext.createOtpGenerateResponseModel();

      when(customerIdentityManagementClient.retrieveOTP(accessToken, username))
          .thenReturn(otpRetrieveDetailsModel);
      when(customerIdentityManagementClient.generateOTP(accessToken, otpId))
          .thenReturn(otpGenerateDetailsModel);

      service.createActivationCode(accessToken, otpContext.getUsername());

      verify(customerIdentityManagementClient, times(1)).retrieveOTP(accessToken,
          username);
      verify(customerIdentityManagementClient, times(1)).generateOTP(accessToken,
          otpId);
      verify(customerIdentityManagementClient, times(1)).updateOTP(accessToken,
          otpContext.createUpdateRequestModel());
    }

    @Test
    void shouldReturnActivationCodeWhenClientResponseIsValid() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().build();
      final String username = otpContext.getUsername();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      OtpRetrieveResponseModel otpRetrieveDetailsModel = otpContext.createOtpRetrieveResponseModel();
      OtpGenerateResponseModel otpGenerateDetailsModel = otpContext.createOtpGenerateResponseModel();

      when(customerIdentityManagementClient.retrieveOTP(accessToken, username))
          .thenReturn(otpRetrieveDetailsModel);
      when(customerIdentityManagementClient.generateOTP(accessToken, otpContext.getOtpId()))
          .thenReturn(otpGenerateDetailsModel);

      String result = service.createActivationCode(accessToken, username)
          .getActivationCode();

      assertThat(result).isEqualTo(otpContext.activationCode);
    }

    @Test
    void shouldThrowRemoteFailureIfClientRetrieveOtpThrowsRemoteFailure() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().build();
      final String username = otpContext.getUsername();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).retrieveOTP(any(), any());

      assertThatThrownBy(() -> service.createActivationCode(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).retrieveOTP(accessToken, username);
    }

    @Test
    void shouldThrowRemoteFailureIfClientGenerateOtpThrowsRemoteFailure() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().build();
      final String username = otpContext.getUsername();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      OtpRetrieveResponseModel otpRetrieveDetailsModel = otpContext.createOtpRetrieveResponseModel();

      when(customerIdentityManagementClient.retrieveOTP(accessToken, username))
          .thenReturn(otpRetrieveDetailsModel);
      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).generateOTP(any(), any());

      assertThatThrownBy(() -> service.createActivationCode(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).retrieveOTP(accessToken, username);
      verify(customerIdentityManagementClient).generateOTP(accessToken, otpContext.getOtpId());
    }

    @Test
    void shouldThrowRemoteFailureIfClientUpdateOtpThrowsRemoteFailure() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().build();
      final String username = otpContext.getUsername();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      OtpRetrieveResponseModel otpRetrieveDetailsModel = otpContext.createOtpRetrieveResponseModel();
      OtpGenerateResponseModel otpGenerateDetailsModel = otpContext.createOtpGenerateResponseModel();

      when(customerIdentityManagementClient.retrieveOTP(accessToken, username))
          .thenReturn(otpRetrieveDetailsModel);
      when(customerIdentityManagementClient.generateOTP(accessToken, otpContext.getOtpId()))
          .thenReturn(otpGenerateDetailsModel);
      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).updateOTP(any(), any());

      assertThatThrownBy(() -> service.createActivationCode(accessToken, username))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).retrieveOTP(accessToken, username);
      verify(customerIdentityManagementClient).generateOTP(accessToken, otpContext.getOtpId());
      verify(customerIdentityManagementClient).updateOTP(accessToken,
          otpContext.createUpdateRequestModel());
    }
  }

  @Nested
  @DisplayName(("Reactivate User Cases"))
  class ReactivateUserCases {

    @Test
    void shouldCallCustomerIdentityManagementClient() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().otpType("OTP").build();
      final String otpId = otpContext.getOtpId();

      ActivationCodeGenerateRequest activationCodeGenerateRequest = otpContext.createActivationCodeGenerateRequest();
      final String username = activationCodeGenerateRequest.getUsername();

      OtpRetrieveResponseModel otpRetrieveDetailsModel = otpContext.createOtpRetrieveResponseModel();
      OtpGenerateResponseModel otpGenerateDetailsModel = otpContext.createOtpGenerateResponseModel();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      when(customerIdentityManagementClient.retrieveOTP(accessToken, username))
              .thenReturn(otpRetrieveDetailsModel);
      when(customerIdentityManagementClient.generateOTP(accessToken, otpId))
              .thenReturn(otpGenerateDetailsModel);

      service.reactivateUser(accessToken, activationCodeGenerateRequest);

      verify(customerIdentityManagementClient).getUser(accessToken, username);
      verify(customerIdentityManagementClient).retrieveOTP(accessToken, username);
      verify(customerIdentityManagementClient).generateOTP(accessToken, otpId);
      verify(customerIdentityManagementClient).updateOTP(accessToken,
              otpContext.createUpdateRequestModel());
    }

    @Test
    void shouldThrowUserNotFoundExceptionIfClientThrowsErrorWhenGettingUser() {
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();
      final OtpContext otpContext = OtpContext.builder().build();

      ActivationCodeGenerateRequest activationCodeGenerateRequest = otpContext.createActivationCodeGenerateRequest();

      RegistrationService service = new RegistrationService(customerIdentityManagementClient);

      doThrow(new UserNotFoundException("User not found"))
              .when(customerIdentityManagementClient).getUser(any(), any());

      assertThatThrownBy(
              () -> service.reactivateUser(
                      accessToken,
                      activationCodeGenerateRequest))
              .isInstanceOf(UserNotFoundException.class);
    }
  }
}