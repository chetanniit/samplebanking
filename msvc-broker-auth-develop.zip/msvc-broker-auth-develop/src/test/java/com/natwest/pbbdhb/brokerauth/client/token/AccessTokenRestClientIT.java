package com.natwest.pbbdhb.brokerauth.client.token;

import static com.github.tomakehurst.wiremock.core.Options.DEFAULT_PORT;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.request.controller.helpers.CorrelationIdentifierHelper;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;


@ActiveProfiles(profiles = {"int"})
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
public class AccessTokenRestClientIT {

  @MockBean
  CorrelationIdentifierHelper helper;

  @Autowired
  AccessTokenRestClient client;

  private static WireMockServer wireMockServer;

  @BeforeAll
  public static void startWireMock() {
    wireMockServer = new WireMockServer(options().port(DEFAULT_PORT));
    wireMockServer.start();
  }

  @BeforeEach
  public void before() {
    wireMockServer.resetRequests();
    when(helper.requestCorrelationId()).thenReturn("e822be7a-3773-4408-8b74-0c8e9f2fb058");
    when(helper.requestInternalCorrelationId()).thenReturn("712a5c03-e596-4eb8-afda-3bdfe3cbe974");
  }

  @AfterAll
  public static void cleanUp() {
    wireMockServer.stop();
  }

  @Nested
  @DisplayName("create access token cases")
  class GenerateAccessTokenTests {

    @Test
    void shouldReturnAccessTokenForValidRequest() {
      WireMock.stubFor(AccessTokenWireMockServer.mappingAccessTokenRequest(
          AccessTokenWireMockServer.jsonResponse(
              HttpStatus.OK,
              AccessTokenWireMockServer.getAccessTokenResponse())));

      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

      AccessTokenRetrieveRequestModel requestModel = accessTokenContext.createAccessTokenRetrieveRequestModel();

      AccessTokenResponseModel expectedToken = accessTokenContext.createAccessTokenResponseModel();

      final AccessTokenResponseModel token = client.retrieveToken(requestModel);
      assertThat(token).isEqualTo(expectedToken);

      // verify the expected request headers and the URL encoded payload
      WireMock.verify(AccessTokenWireMockServer.patternForAccessTokenRequest());
    }

    @Test
    void shouldThrowExceptionForInvalidRequest() {

      WireMock.stubFor(AccessTokenWireMockServer.mappingAccessTokenRequest(
          AccessTokenWireMockServer.jsonResponse(
              HttpStatus.UNAUTHORIZED,
              AccessTokenWireMockServer.getErrorResponse())));

      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

      AccessTokenRetrieveRequestModel requestModel = accessTokenContext.createAccessTokenRetrieveRequestModel();

      assertThatThrownBy(() -> client.retrieveToken(requestModel))
          .isInstanceOf(RemoteRequestFailedException.class)
          .hasMessageContaining("401 Unauthorized")
          .hasMessageContaining(accessTokenContext.getErrorType())
          .hasMessageContaining(accessTokenContext.getErrorDescription());
    }

    @Test
    void shouldThrowExceptionForServerError() {
      WireMock
          .stubFor(AccessTokenWireMockServer.mappingAccessTokenRequest(WireMock.serverError()));

      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

      AccessTokenRetrieveRequestModel requestModel = accessTokenContext.createAccessTokenRetrieveRequestModel();

      assertThatThrownBy(() -> client.retrieveToken(requestModel))
          .isInstanceOf(RemoteRequestFailedException.class)
          .hasMessageContaining("500 Server Error");
    }
  }
}
