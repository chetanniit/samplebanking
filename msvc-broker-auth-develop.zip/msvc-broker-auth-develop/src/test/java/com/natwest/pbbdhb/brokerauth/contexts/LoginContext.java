package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.LoginRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class LoginContext {

  @Default
  private String firstName = "Test";

  @Default
  private String lastName = "Account";

  @Default
  private String username = "TestUsername";

  @Default
  private String password = "TestPassword";

  @Default
  private BrokerTypeModel brokerType = BrokerTypeModel.BROKER;

  @Default
  private String id = "TestId";

  @Default
  private String parentId = "uid=5be0c229-2a1c-4466-9dac-446be8628080,ou=customer,ou=personaidentity,ou=common,dc=carnus";


  public LoginRequestModel createLoginRequestModel() {
    return LoginRequestModel.builder()
        .username(username)
        .password(password)
        .build();
  }

  public GetUserResponseModel createGetUserResponseModel() {
    return GetUserResponseModel.builder()
        .brokerType(brokerType)
        .id(id)
        .parentId(parentId)
        .build();
  }

  public LoginRequest createLoginRequest() {
    return LoginRequest.builder()
        .username(username)
        .password(password)
        .build();
  }
}
