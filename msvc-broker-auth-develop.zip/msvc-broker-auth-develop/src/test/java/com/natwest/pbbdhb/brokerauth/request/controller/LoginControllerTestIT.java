package com.natwest.pbbdhb.brokerauth.request.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.LoginContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import com.natwest.pbbdhb.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.brokerauth.service.login.LoginService;
import com.natwest.pbbdhb.brokerauth.service.token.AccessTokenService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * In this test, the full Spring app context is started, but with the service layer mocked.
 */
@ActiveProfiles(profiles = {"int", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class LoginControllerTestIT {

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  @MockBean
  LoginService loginService;

  @MockBean
  AccessTokenService tokenService;

  @LocalServerPort
  int port;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Value("${server.servlet.context-path}")
  private String contextPath;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("mortgages/v1/msvc-broker-auth/login")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port);
  }

  @Nested
  @DisplayName("login Cases")
  class LoginCases {

    /**
     * Testing happy path call to controller and verifying service is called.
     */
    @Test
    void shouldCallServiceWithRequestModels() {
      LoginContext loginContext = LoginContext.builder().build();
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      givenRequestToController()
          .body(loginContext.createLoginRequest())
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .post("")
          .then().log().all();

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(loginService, times(1))
          .login(accessTokenResponseModel.getAccessToken(),
              loginContext.createLoginRequestModel());
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailsDueToInvalidCredentials() {
      LoginContext loginContext = LoginContext.builder().build();
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new LoginFailedException("Invalid Credentials"))
          .when(loginService)
          .login(any(), any());

      givenRequestToController()
          .body(loginContext.createLoginRequest())
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value());

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(loginService, times(1))
          .login(accessTokenResponseModel.getAccessToken(),
              loginContext.createLoginRequestModel());
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFails() {
      LoginContext loginContext = LoginContext.builder().build();
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new UnauthorisedException(ErrorCode.UNAUTHORISED, "Login Failed"))
          .when(loginService)
          .login(any(), any());

      givenRequestToController()
          .body(loginContext.createLoginRequest())
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value());

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(loginService, times(1))
          .login(accessTokenResponseModel.getAccessToken(),
              loginContext.createLoginRequestModel());
    }

    @Test
    void shouldReturnUnauthorisedIfAccountIsLocked() {
      LoginContext loginContext = LoginContext.builder().build();
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
              .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new AccountLockedException("TestUsername"))
              .when(loginService)
              .login(any(), any());

      givenRequestToController()
              .body(loginContext.createLoginRequest())
              .contentType(ContentType.JSON)
              .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
              .post("")
              .then().log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body("code", is(ErrorCode.ACCOUNT_LOCKED.toString()));

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(loginService, times(1))
              .login(accessTokenResponseModel.getAccessToken(),
                      loginContext.createLoginRequestModel());
    }

    @Test
    void shouldReturnUnauthorisedIfPasswordIsExpired() {
      LoginContext loginContext = LoginContext.builder().build();
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
              .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new PasswordExpiredException("TestUsername"))
              .when(loginService)
              .login(any(), any());

      givenRequestToController()
              .body(loginContext.createLoginRequest())
              .contentType(ContentType.JSON)
              .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
              .post("")
              .then().log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body("code", is(ErrorCode.PASSWORD_EXPIRED.toString()));

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(loginService, times(1))
              .login(accessTokenResponseModel.getAccessToken(),
                      loginContext.createLoginRequestModel());
    }

    @Test
    void shouldReturnServerErrorIfLoginThrowsRemoteFailure() {
      LoginContext loginContext = LoginContext.builder().build();
      AccessTokenResponseModel accessTokenResponseModel = AccessTokenContext.builder().build()
          .createAccessTokenResponseModel();

      when(tokenService.token(any())).thenReturn(accessTokenResponseModel);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(loginService)
          .login(any(), any());

      givenRequestToController()
          .body(loginContext.createLoginRequest())
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

      Mockito.verify(tokenService, times(1)).token(any());

      Mockito.verify(loginService, times(1))
          .login(accessTokenResponseModel.getAccessToken(),
              loginContext.createLoginRequestModel());
    }

    @Test
    void shouldReturnBadRequestIfRequestIsInvalid() {

      givenRequestToController()
          .body(new JSONObject().toString())
          .contentType(ContentType.JSON)
          .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }
  }
}