package com.natwest.pbbdhb.brokerauth.service.login;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.LoginContext;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LoginServiceTest {

  @Mock
  CustomerIdentityManagementClient customerIdentityManagementClient;

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallCimClient() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      service.login(accessToken, loginAttempt);

      verify(customerIdentityManagementClient).login(accessToken, loginAttempt);
      verify(customerIdentityManagementClient).getUser(accessToken, loginAttempt.getUsername());
    }

    /**
     * Testing service handles response from client.
     */
    @Test
    void shouldReturnResponseFromCimClient() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();
      GetUserResponseModel userDetail = loginContext.createGetUserResponseModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      when(customerIdentityManagementClient.getUser(
          accessToken, loginAttempt.getUsername()))
          .thenReturn(userDetail);

      GetUserResponseModel response = service.login(accessToken, loginAttempt);

      Assertions.assertEquals(userDetail, response);
    }

    @Test
    void shouldReturnErrorIfCredentialsAreInvalid() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      doThrow(new LoginFailedException("Invalid Credentials"))
          .when(customerIdentityManagementClient).login(any(), any());

      assertThatThrownBy(() -> service.login(accessToken, loginAttempt))
          .isInstanceOf(LoginFailedException.class);

      verify(customerIdentityManagementClient).login(accessToken, loginAttempt);
    }

    @Test
    void shouldReturnErrorIfAccountLocked() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      doThrow(new AccountLockedException("Account Locked"))
              .when(customerIdentityManagementClient).login(any(), any());

      assertThatThrownBy(() -> service.login(accessToken, loginAttempt))
              .isInstanceOf(AccountLockedException.class);

      verify(customerIdentityManagementClient).login(accessToken, loginAttempt);
    }

    @Test
    void shouldReturnErrorIfPasswordIsExpired() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      doThrow(new PasswordExpiredException("Password expired"))
              .when(customerIdentityManagementClient).login(any(), any());

      assertThatThrownBy(() -> service.login(accessToken, loginAttempt))
              .isInstanceOf(PasswordExpiredException.class);

      verify(customerIdentityManagementClient).login(accessToken, loginAttempt);
    }


    @Test
    void shouldReturnErrorIfLoginResponseIsInvalid() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      doThrow(new UnauthorisedException(ErrorCode.UNAUTHORISED, "Login Failed"))
          .when(customerIdentityManagementClient).login(any(), any());

      assertThatThrownBy(() -> service.login(accessToken, loginAttempt))
          .isInstanceOf(UnauthorisedException.class);

      verify(customerIdentityManagementClient).login(accessToken, loginAttempt);
    }

    @Test
    void shouldThrowRemoteFailureIfClientThrowsRemoteFailure() {
      String accessToken = AccessTokenContext.builder().build().getAccessToken();
      LoginContext loginContext = LoginContext.builder().build();
      LoginRequestModel loginAttempt = loginContext.createLoginRequestModel();

      LoginService service = new LoginService(customerIdentityManagementClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).login(any(), any());

      assertThatThrownBy(() -> service.login(accessToken, loginAttempt))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).login(accessToken, loginAttempt);
    }
  }
}