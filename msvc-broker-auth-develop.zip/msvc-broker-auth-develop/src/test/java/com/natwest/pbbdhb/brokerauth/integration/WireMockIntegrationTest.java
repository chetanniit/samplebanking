package com.natwest.pbbdhb.brokerauth.integration;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.natwest.pbbdhb.brokerauth.config.WireMockConfiguration.NoKeepAliveTransformer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;

public class WireMockIntegrationTest {

  private static final int PORT = 8089;

  private final String ACCESS_TOKEN = "Bearer stub-token-abcdef-123456";

  @Autowired
  private ObjectMapper objectMapper;

  private WireMockServer wireMockServer = new WireMockServer(
      options()
          .port(PORT)
          .extensions(NoKeepAliveTransformer.class));

  @BeforeEach
  void setUp() throws IOException {
    wireMockServer.start();
  }

  @AfterEach
  void tearDown() {
    wireMockServer.stop();
  }

  void stubGetUser() throws IOException {
    wireMockServer.stubFor(get("/scim/v2/napoli/v1/customeridentifier?filter=personaidentifier%20eq%20%22CPB-NAPL-NWB@MurphyS11%22")
        .withHeader("Content-Type", containing("application/scim+json"))
        .withHeader("Authorization", containing(ACCESS_TOKEN))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("iam_get_user_response.json"))));

  }

  void stubGetAdmin() throws IOException {
    wireMockServer.stubFor(get("/scim/v2/napoli/v1/customeridentifier?filter=personaidentifier%20eq%20%22CPB-NAPL-NWB@MurphyS11%22")
        .withHeader("Content-Type", containing("application/scim+json"))
        .withHeader("Authorization", containing(ACCESS_TOKEN))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("iam_get_admin_response.json"))));

  }

  void stubGetSecurityQuestions() throws IOException {

    wireMockServer.stubFor(get("/scim/v2/napoli/v1/customerchallenge?filter=parentidentity%20eq%20%22uid=a5825ddf-eacb-4e48-a7dc-b06c89030049,ou=customer,ou=personaidentity,ou=common,dc=carnus%22")
        .withHeader("Content-Type", containing("application/scim+json"))
        .withHeader("Authorization", containing(ACCESS_TOKEN))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("iam_get_security_questions_response.json"))));
  }

  void stubSetSecurityQuestions() throws IOException {
    wireMockServer.stubFor(put("/scim/v2/napoli/v1/customerchallenge/9b70491b-2add-4139-90a7-1a91e3a4dacb")
        .withHeader("Content-Type", containing("application/scim+json"))
        .withHeader("Authorization", containing(ACCESS_TOKEN))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody(getRequestBody("iam_set_security_questions_response.json"))));
  }

  void stubPostOauth2Token() throws IOException {
    wireMockServer.stubFor(post("/oauth2/token")
        .withHeader("Content-Type", containing("multipart/form-data"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm_oauth_token_data_response.json"))));
  }

  void stubGetBrokerDetails() throws IOException {
    wireMockServer.stubFor(get("/mbs_ReadBrokerCore(mbs_userName='MurphyS11')")
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm_read_broker_response.json"))));
  }

  void stubGetAdminDetails() throws IOException {
    wireMockServer.stubFor(get("/mbs_ReadBrokerAdminCore(mbs_userName='MurphyS11')")
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm_read_admin_response.json"))));
  }

  void stubGetFirmDetails() throws IOException {
    wireMockServer.stubFor(get("/mbs_getfirmdetails(mbs_fcanumber='973235')")
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm_get_firm_details_response.json"))));
  }

  void stubUpdateBrokerDetails() throws IOException {
    wireMockServer.stubFor(post("/mbs_UpdateBrokerCore")
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm_update_broker_response.json"))));
  }

  void stubUpdateAdminDetails() throws IOException {
    wireMockServer.stubFor(post("/mbs_UpdateBrokerAdmin")
        .withHeader("Content-Type", containing("application/json"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(getRequestBody("crm_update_admin_response.json"))));
  }

  void stubGetUsernameReminder() throws IOException {
    wireMockServer.stubFor(get("/mbs_ReadUsernameReminder(mbs_emailAddress='test@test.com',mbs_lastName='Test%20Space',mbs_dateOfBirth='1980-01-01')")
            .withHeader("Content-Type", containing("application/json"))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBody(getRequestBody("crm_read_username_reminder_response.json"))));
  }

  private String getRequestBody(String fileName) throws IOException {
    return new String(Files.readAllBytes(Paths.get("src", "test", "resources", fileName)));
  }
}
