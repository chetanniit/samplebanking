package com.natwest.pbbdhb.brokerauth.utils;

import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

import java.time.LocalDate;
import java.util.Set;

public class TestUtils {

    private static final String BROKER_EMAIL_ADDRESS = "test@test.com";
    private static final String BROKER_LAST_NAME = "Test Space";
    private static final LocalDate BROKER_DATE_OF_BIRTH = LocalDate.of(1980,1,1);
    public static final String MUST_NOT_BE_NULL_ERROR_MESSAGE = "must not be null";
    public static final String MUST_NOT_BE_BLANK_ERROR_MESSAGE = "must not be blank";

    public static <T> Set<ConstraintViolation<T>> getConstraintViolations(T valueToCheck) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        return validator.validate(valueToCheck);
    }

    public static UsernameReminderRequest aUsernameReminderRequest() {
        return UsernameReminderRequest.builder()
                .email(BROKER_EMAIL_ADDRESS).lastName(BROKER_LAST_NAME).dateOfBirth(BROKER_DATE_OF_BIRTH).build();
    }

}
