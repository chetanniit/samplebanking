package com.natwest.pbbdhb.brokerauth.client.token;

import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"int"})
@SpringBootTest(
    properties = {
        "clients.accesstoken.stub.enabled = true"
    }
)
class AccessTokenStubClientIT {

  @Autowired
  AccessTokenClient client;

  @Test
  void shouldInjectStubClient() {
    assertThat(client.getClass())
        .isEqualTo(AccessTokenStubClient.class);
  }

  @Test
  void shouldReturnExpectedStubResponse() {
    AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
    AccessTokenRetrieveRequestModel accessTokenRetrieveRequestModel = accessTokenContext.createAccessTokenRetrieveRequestModel();
    AccessTokenResponseModel expectedToken = accessTokenContext.createAccessTokenResponseModel();

    final AccessTokenResponseModel token = client.retrieveToken(accessTokenRetrieveRequestModel);
    assertThat(token).isEqualTo(expectedToken);
  }
}
