package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class LoginResourcesContext {

  @Default
  private Integer errorCode = null;

  public static LoginResourcesContext.LoginResourcesContextBuilder getLoginResourcesBuilder() {
    return LoginResourcesContext.builder()
        .errorCode(null);
  }

  public ObjectNode getLoginResourcesPayload() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("errorcode", errorCode);
    return payload;
  }
}
