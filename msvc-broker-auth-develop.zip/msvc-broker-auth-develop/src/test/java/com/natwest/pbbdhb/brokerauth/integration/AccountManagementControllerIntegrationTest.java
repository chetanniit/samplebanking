package com.natwest.pbbdhb.brokerauth.integration;

import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.aUsernameReminderRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerauth.request.domain.ResidentialAddress;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ChangeMemorableQuestionsRequest.SecurityQuestion;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.natwest.pbbdhb.brokerauth.request.domain.FirmDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.NonSTPFieldCategory;
import com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath;
import com.natwest.pbbdhb.brokerauth.request.domain.RequestedType;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.RetrieveMemorableQuestionsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UpdateBrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.UsernameReminderRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@ActiveProfiles(profiles = {"it", "int", "stub-userclaims", "stub-accesstoken"})
@AutoConfigureMockMvc
public class AccountManagementControllerIntegrationTest extends WireMockIntegrationTest {

  private static final String SUCCESS_MESSAGE = "Broker Record Identified Successfully.";

  @Autowired
  private MockMvc mockMvc;

  @Autowired
  private ObjectMapper objectMapper;

  private final static String USERNAME = "MurphyS11";

  @BeforeEach
  void setUp() throws IOException {
    super.setUp();
  }

  @AfterEach
  void tearDown() {
    super.tearDown();
  }

  @Test
  public void shouldChallengeQuestions() throws Exception {
    stubGetUser();
    stubGetSecurityQuestions();

    RetrieveMemorableQuestionsRequest request = RetrieveMemorableQuestionsRequest.builder()
        .username(USERNAME)
        .build();

    MvcResult result = mockMvc.perform(post("/mortgages/v1/msvc-broker-auth/account-management/challenge-questions")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk()).andReturn();

    RetrieveMemorableQuestionsResponse response = objectMapper.readValue(result.getResponse().getContentAsString(),
        RetrieveMemorableQuestionsResponse.class);

    assertEquals(2, response.getSecurityQuestions().size());
    assertEquals("what is your name?", response.getSecurityQuestions().get(0));
    assertEquals("where is your hometown?", response.getSecurityQuestions().get(1));
  }

  @Test
  public void shouldChangeQuestions() throws Exception {
    stubGetUser();
    stubGetSecurityQuestions();
    stubSetSecurityQuestions();

    List<SecurityQuestion> securityQuestionList = Arrays.asList(
        SecurityQuestion.builder().question("what is your child name?")
            .answer("Test answer 1").build(),
        SecurityQuestion.builder().question("where is your child hometown?")
            .answer("Test answer 2").build());

    ChangeMemorableQuestionsRequest request = ChangeMemorableQuestionsRequest.builder()
        .username(USERNAME)
        .questions(securityQuestionList)
        .build();

    mockMvc.perform(post("/mortgages/v1/msvc-broker-auth/account-management/change-questions")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk()).andReturn();
  }

  @Test
  public void shouldGetBrokerDetails() throws Exception {
    stubGetUser();
    stubPostOauth2Token();
    stubGetBrokerDetails();

    MvcResult mvcResult = mockMvc.perform(get("/mortgages/v1/msvc-broker-auth/account-management/broker-details/MurphyS11"))
        .andExpect(status().isOk()).andReturn();

    BrokerDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), BrokerDetailsResponse.class);
    assertEquals("HughesA11", response.getBrokerDetails().getUsername());
    assertEquals(NonSTPFieldCategory.ADDRESS, response.getProcessingFields().get(0));
  }

  @Test
  public void shouldGetAdminDetails() throws Exception {
    stubGetAdmin();
    stubPostOauth2Token();
    stubGetAdminDetails();

    MvcResult mvcResult = mockMvc.perform(get("/mortgages/v1/msvc-broker-auth/account-management/broker-details/MurphyS11"))
        .andExpect(status().isOk()).andReturn();

    BrokerDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), BrokerDetailsResponse.class);
    assertEquals("MurphyS11", response.getBrokerDetails().getUsername());
    assertTrue(response.getProcessingFields().isEmpty());
  }

  @Test
  public void shouldGetFirmDetails() throws Exception {
    stubGetUser();
    stubPostOauth2Token();
    stubGetFirmDetails();

    MvcResult mvcResult = mockMvc.perform(get("/mortgages/v1/msvc-broker-auth/account-management/firm-details/973235"))
        .andExpect(status().isOk()).andReturn();

    FirmDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), FirmDetailsResponse.class);
    assertEquals("973235", response.getFcaNumber());
  }

  @Test
  public void shouldUpdateBrokerDetails() throws Exception {
    stubGetUser();
    stubPostOauth2Token();
    stubGetBrokerDetails();
    stubUpdateBrokerDetails();

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.BROKER)
        .username("MurphyS11")
        .title("Mr")
        .firstName("Ashley")
        .lastName("HughesC")
        .email("test@example.com")
        .mobilePhone("07310248113")
        .businessPhone("020 7713 0107")
        .addressLine1("33 Orrell Lane")
        .addressLine2("Orrell Park")
        .addressLine3("test-flat-name-number")
        .city("Liverpool")
        .county(null)
        .postcode("RG21 8EN")
        .fcaNumber("593672")
        .tradingName("Mortgage Advice Bureau")
        .nationality("GB")
        .residentialAddress(ResidentialAddress.builder()
                .addressLine1("addressLine1")
                .city("town")
                .countryOfAddress("GB")
                .postcode("EH11 1PR")
                .build())
        .paymentPaths(Collections.singletonList(PaymentPath.builder()
        .name("Dynamo For Intermediaries")
        .paymentId("529790848")
        .build()
        ))
        .build();

    MvcResult mvcResult = mockMvc.perform(put("/mortgages/v1/msvc-broker-auth/account-management/broker-details")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk()).andReturn();

    UpdateBrokerDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), UpdateBrokerDetailsResponse.class);
    assertTrue(response.getRequestedTypes().isEmpty());
    assertEquals(NonSTPFieldCategory.ADDRESS, response.getProcessingFields().get(0));
  }

  @Test
  public void shouldUpdateAdminDetails() throws Exception {
    stubGetAdmin();
    stubPostOauth2Token();
    stubGetAdminDetails();
    stubUpdateAdminDetails();

    BrokerDetailsChangeRequest request = BrokerDetailsChangeRequest.builder()
        .brokerType(BrokerType.ADMIN)
        .username("MurphyS11")
        .title("Mr")
        .firstName("Ashley")
        .lastName("HughesC")
        .email("test@example.com")
        .mobilePhone("07310248113")
        .businessPhone("020 7713 0107")
        .build();

    MvcResult mvcResult = mockMvc.perform(put("/mortgages/v1/msvc-broker-auth/account-management/broker-details")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk()).andReturn();

    UpdateBrokerDetailsResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), UpdateBrokerDetailsResponse.class);
    assertTrue(response.getRequestedTypes().contains(RequestedType.STP));
    assertTrue(response.getProcessingFields().isEmpty());
  }

  @Test
  public void shouldGetUsernameReminder() throws Exception {
    stubPostOauth2Token();
    stubGetUsernameReminder();

    MvcResult mvcResult = mockMvc.perform(post("/mortgages/v1/msvc-broker-auth/account-management/username-reminder")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(aUsernameReminderRequest())))
        .andExpect(status().isOk()).andReturn();

    UsernameReminderResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), UsernameReminderResponse.class);
    assertTrue(response.getUsernameIdentified());
    assertEquals(SUCCESS_MESSAGE, response.getMessage());
  }

  @Test
  public void shouldGet400BadRequestWhenRequestBodyIsInvalidDueToNullAttribute() throws Exception {
    stubPostOauth2Token();
    stubGetUsernameReminder();

    UsernameReminderRequest request = aUsernameReminderRequest();
    request.setLastName(null);
    request.setDateOfBirth(null);
    request.setEmail(null);

    MvcResult mvcResult = mockMvc.perform(post("/mortgages/v1/msvc-broker-auth/account-management/username-reminder")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isBadRequest()).andReturn();

    ErrorResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ErrorResponse.class);
    assertEquals("Invalid Request", response.getTitle());
    assertEquals("The request has invalid or missing data.", response.getDescription());
    assertTrue(response.getErrors().stream().anyMatch(e ->
            "lastName".equals(e.getTitle()) && MUST_NOT_BE_BLANK_ERROR_MESSAGE.equals(e.getDescription())));
    assertTrue(response.getErrors().stream().anyMatch(e ->
            "email".equals(e.getTitle()) && MUST_NOT_BE_BLANK_ERROR_MESSAGE.equals(e.getDescription())));
    assertTrue(response.getErrors().stream().anyMatch(e ->
            "dateOfBirth".equals(e.getTitle()) && MUST_NOT_BE_NULL_ERROR_MESSAGE.equals(e.getDescription())));
  }

}
