package com.natwest.pbbdhb.brokerauth.request.mapper;

import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerCoreResponse;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.BrokerUpdateRequest;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.FirmDetails;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.PaymentPath;
import com.natwest.pbbdhb.brokerauth.model.crm.broker.TradingName;
import com.natwest.pbbdhb.brokerauth.request.domain.AdminDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeCrmRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsChangeRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.brokerauth.request.domain.BrokerType;
import com.natwest.pbbdhb.brokerauth.request.domain.NonSTPFieldCategory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Testing the Broker Details model mapping.
 */
class BrokerDetailsMapperTest {

  private static final String USERNAME = "username";
  private static final String TITLE = "title";
  private static final String FIRST_NAME = "firstName";
  private static final String MIDDLE_NAME = "middleName";
  private static final String LAST_NAME = "lastName";
  private static final String EMAIL_ADDRESS = "emailAddress";
  private static final String MOBILE_NUMBER = "mobileNumber";
  private static final String BUSINESS_PHONE = "businessPhone";
  private static final String BROKER_POSTCODE = "brokerPostcode";
  private static final String FIRM_ADDRESS_LINE_1 = "firmAddressLine1";
  private static final String FIRM_ADDRESS_LINE_2 = "firmAddressLine2";
  private static final String FIRM_ADDRESS_LINE_3 = "firmAddressLine3";
  private static final String FIRM_ADDRESS_CITY = "firmAddressCity";
  private static final String FIRM_ADDRESS_COUNTY = "firmAddressCounty";
  private static final String FIRM_ADDRESS_COUNTRY = "firmAddressCountry";
  private static final String FCA_NUMBER = "fcaNumber";
  private static final String TRADING_NAME = "tradingName";
  private static final String PAYMENT_PATH_ID_1 = "paymentPathId1";
  private static final String PAYMENT_PATH_NAME_1 = "paymentPathName1";
  private static final String PAYMENT_PATH_ID_2 = "paymentPathId2";
  private static final String PAYMENT_PATH_NAME_2 = "paymentPathName2";
  private static final String IN_PROGRESS = "In progress";

  @Nested
  @DisplayName("Broker Details Cases")
  class BrokerDetailsCases {

    @Test
    void toBrokerDetailsResponse() {
      BrokerCoreResponse brokerCoreResponse = BrokerCoreResponse.builder()
          .broker(BrokerDetails.builder()
              .userName(USERNAME)
              .title(TITLE)
              .firstName(FIRST_NAME)
              .lastName(LAST_NAME)
              .emailAddress(EMAIL_ADDRESS)
              .mobileNumber(MOBILE_NUMBER)
              .businessPhone(BUSINESS_PHONE)
              .brokerPostcode(BROKER_POSTCODE)
              .build())
          .firmDetails(FirmDetails.builder()
              .firmAddressLine1(FIRM_ADDRESS_LINE_1)
              .firmAddressLine2(FIRM_ADDRESS_LINE_2)
              .firmAddressLine3(FIRM_ADDRESS_LINE_3)
              .firmAddressCity(FIRM_ADDRESS_CITY)
              .firmAddressCounty(FIRM_ADDRESS_COUNTY)
              .firmAddressPostcode(BROKER_POSTCODE)
              .firmAddressCountry(FIRM_ADDRESS_COUNTRY)
              .fcaNumber(FCA_NUMBER)
              .build())
          .tradingName(TradingName.builder()
              .name(TRADING_NAME)
              .build())
          .paymentPaths(Arrays.asList(
              PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_1)
                  .name(PAYMENT_PATH_NAME_1)
                  .build(),
              PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_2)
                  .name(PAYMENT_PATH_NAME_2)
                  .build()))
          .brokerUpdateRequest(BrokerUpdateRequest.builder()
              .status(IN_PROGRESS)
              .requesttype("[\"Address Change\",\"Name Change\",\"Email Change\"")
              .build())
          .build();

      final BrokerDetailsResponse brokerDetailsResponse = BrokerDetailsMapper.toBrokerDetailsResponse(brokerCoreResponse);
      final com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails brokerDetails = brokerDetailsResponse.getBrokerDetails();

      assertEquals(BrokerType.BROKER, brokerDetails.getBrokerType());
      assertEquals(USERNAME, brokerDetails.getUsername());
      assertEquals(TITLE, brokerDetails.getTitle());
      assertEquals(FIRST_NAME, brokerDetails.getFirstName());
      assertEquals(LAST_NAME, brokerDetails.getLastName());
      assertEquals(EMAIL_ADDRESS, brokerDetails.getEmail());
      assertEquals(BUSINESS_PHONE, brokerDetails.getBusinessPhone());
      assertEquals(FIRM_ADDRESS_LINE_1, brokerDetails.getAddressLine1());
      assertEquals(FIRM_ADDRESS_LINE_2, brokerDetails.getAddressLine2());
      assertEquals(FIRM_ADDRESS_LINE_3, brokerDetails.getAddressLine3());
      assertEquals(FIRM_ADDRESS_CITY, brokerDetails.getCity());
      assertEquals(FIRM_ADDRESS_COUNTY, brokerDetails.getCounty());
      assertEquals(BROKER_POSTCODE, brokerDetails.getPostcode());
      assertEquals(FCA_NUMBER, brokerDetails.getFcaNumber());
      assertEquals(TRADING_NAME, brokerDetails.getTradingName());
      assertEquals(PAYMENT_PATH_ID_1, brokerDetails.getPaymentPaths().get(0).getPaymentId());
      assertEquals(PAYMENT_PATH_NAME_1, brokerDetails.getPaymentPaths().get(0).getName());
      assertEquals(PAYMENT_PATH_ID_2, brokerDetails.getPaymentPaths().get(1).getPaymentId());
      assertEquals(PAYMENT_PATH_NAME_2, brokerDetails.getPaymentPaths().get(1).getName());

      assertTrue(brokerDetailsResponse.getProcessingFields().containsAll(Arrays.asList(NonSTPFieldCategory.ADDRESS, NonSTPFieldCategory.EMAIL, NonSTPFieldCategory.NAME)));
    }

    @Test
    void toBrokerDetails() {
      BrokerDetailsChangeRequest brokerDetailsChangeRequest = BrokerDetailsChangeRequest.builder()
          .brokerType(BrokerType.BROKER)
          .username(USERNAME)
          .title(TITLE)
          .firstName(FIRST_NAME)
          .middleName(MIDDLE_NAME)
          .lastName(LAST_NAME)
          .email(EMAIL_ADDRESS)
          .mobilePhone(MOBILE_NUMBER)
          .businessPhone(BUSINESS_PHONE)
          .addressLine1(FIRM_ADDRESS_LINE_1)
          .addressLine2(FIRM_ADDRESS_LINE_2)
          .addressLine3(FIRM_ADDRESS_LINE_3)
          .city(FIRM_ADDRESS_CITY)
          .county(FIRM_ADDRESS_COUNTY)
          .postcode(BROKER_POSTCODE)
          .fcaNumber(FCA_NUMBER)
          .tradingName(TRADING_NAME)
          .paymentPaths(Arrays.asList(
              com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_1)
                  .name(PAYMENT_PATH_NAME_1)
                  .build(),
              com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_2)
                  .name(PAYMENT_PATH_NAME_2)
                  .build()))
          .build();

      com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails brokerDetails = BrokerDetailsMapper.toBrokerDetails(brokerDetailsChangeRequest);

      assertEquals(BrokerType.BROKER, brokerDetails.getBrokerType());
      assertEquals(USERNAME, brokerDetails.getUsername());
      assertEquals(TITLE, brokerDetails.getTitle());
      assertEquals(FIRST_NAME, brokerDetails.getFirstName());
      assertEquals(MIDDLE_NAME, brokerDetails.getMiddleName());
      assertEquals(LAST_NAME, brokerDetails.getLastName());
      assertEquals(EMAIL_ADDRESS, brokerDetails.getEmail());
      assertEquals(MOBILE_NUMBER, brokerDetails.getMobilePhone());
      assertEquals(BUSINESS_PHONE, brokerDetails.getBusinessPhone());
      assertEquals(FIRM_ADDRESS_LINE_1, brokerDetails.getAddressLine1());
      assertEquals(FIRM_ADDRESS_LINE_2, brokerDetails.getAddressLine2());
      assertEquals(FIRM_ADDRESS_LINE_3, brokerDetails.getAddressLine3());
      assertEquals(FIRM_ADDRESS_CITY, brokerDetails.getCity());
      assertEquals(FIRM_ADDRESS_COUNTY, brokerDetails.getCounty());
      assertEquals(BROKER_POSTCODE, brokerDetails.getPostcode());
      assertEquals(FCA_NUMBER, brokerDetails.getFcaNumber());
      assertEquals(TRADING_NAME, brokerDetails.getTradingName());
      assertEquals(PAYMENT_PATH_ID_1, brokerDetails.getPaymentPaths().get(0).getPaymentId());
      assertEquals(PAYMENT_PATH_ID_2, brokerDetails.getPaymentPaths().get(1).getPaymentId());
    }

    @Test
    void toBrokerDetailsChangeCrmRequest() {
      com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails brokerDetails = com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails.builder()
          .brokerType(BrokerType.BROKER)
          .username(USERNAME)
          .title(TITLE)
          .firstName(FIRST_NAME)
          .lastName(LAST_NAME)
          .email(EMAIL_ADDRESS)
          .mobilePhone(MOBILE_NUMBER)
          .businessPhone(BUSINESS_PHONE)
          .addressLine1(FIRM_ADDRESS_LINE_1)
          .addressLine2(FIRM_ADDRESS_LINE_2)
          .addressLine3(FIRM_ADDRESS_LINE_3)
          .city(FIRM_ADDRESS_CITY)
          .county(FIRM_ADDRESS_COUNTY)
          .postcode(BROKER_POSTCODE)
          .fcaNumber(FCA_NUMBER)
          .tradingName(TRADING_NAME)
          .paymentPaths(Arrays.asList(
              com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_1)
                  .name(PAYMENT_PATH_NAME_1)
                  .build(),
              com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_2)
                  .name(PAYMENT_PATH_NAME_2)
                  .build()))
          .build();

      BrokerDetailsChangeCrmRequest request = BrokerDetailsMapper.toBrokerDetailsChangeCrmRequest(brokerDetails);

      assertEquals(USERNAME, request.getUsername());
      assertEquals(TITLE, request.getTitle());
      assertEquals(FIRST_NAME, request.getFirstName());
      assertEquals(LAST_NAME, request.getLastName());
      assertEquals(EMAIL_ADDRESS, request.getEmail());
      assertEquals(MOBILE_NUMBER, request.getMobilePhone());
      assertEquals(BUSINESS_PHONE, request.getBusinessPhone());
      assertEquals(FIRM_ADDRESS_LINE_1, request.getAddressLine1());
      assertEquals(FIRM_ADDRESS_LINE_2, request.getAddressLine2());
      assertEquals(FIRM_ADDRESS_LINE_3, request.getAddressLine3());
      assertEquals(FIRM_ADDRESS_CITY, request.getCity());
      assertEquals(FIRM_ADDRESS_COUNTY, request.getCounty());
      assertEquals(BROKER_POSTCODE, request.getPostcode());
      assertEquals(FCA_NUMBER, request.getFcaNumber());
      assertEquals(TRADING_NAME, request.getTradingName());
      assertEquals(PAYMENT_PATH_ID_1, request.getPaymentPaths().get(0));
      assertEquals(PAYMENT_PATH_ID_2, request.getPaymentPaths().get(1));
    }

    @Test
    void toAdminDetailsChangeCrmRequest() {
      com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails brokerDetails = com.natwest.pbbdhb.brokerauth.request.domain.BrokerDetails.builder()
          .brokerType(BrokerType.BROKER)
          .username(USERNAME)
          .title(TITLE)
          .firstName(FIRST_NAME)
          .middleName(MIDDLE_NAME)
          .lastName(LAST_NAME)
          .email(EMAIL_ADDRESS)
          .mobilePhone(MOBILE_NUMBER)
          .businessPhone(BUSINESS_PHONE)
          .addressLine1(FIRM_ADDRESS_LINE_1)
          .addressLine2(FIRM_ADDRESS_LINE_2)
          .addressLine3(FIRM_ADDRESS_LINE_3)
          .city(FIRM_ADDRESS_CITY)
          .county(FIRM_ADDRESS_COUNTY)
          .postcode(BROKER_POSTCODE)
          .fcaNumber(FCA_NUMBER)
          .tradingName(TRADING_NAME)
          .paymentPaths(Arrays.asList(
              com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_1)
                  .name(PAYMENT_PATH_NAME_1)
                  .build(),
              com.natwest.pbbdhb.brokerauth.request.domain.PaymentPath.builder()
                  .paymentId(PAYMENT_PATH_ID_2)
                  .name(PAYMENT_PATH_NAME_2)
                  .build()))
          .build();

      AdminDetailsChangeCrmRequest request = BrokerDetailsMapper.toAdminDetailsChangeCrmRequest(brokerDetails);

      assertEquals(USERNAME, request.getUsername());
      assertEquals(TITLE, request.getTitle());
      assertEquals(FIRST_NAME, request.getFirstName());
      assertEquals(MIDDLE_NAME, request.getMiddleName());
      assertEquals(LAST_NAME, request.getLastName());
      assertEquals(EMAIL_ADDRESS, request.getEmail());
      assertEquals(MOBILE_NUMBER, request.getMobilePhone());
      assertEquals(BUSINESS_PHONE, request.getBusinessPhone());
    }

  }
}