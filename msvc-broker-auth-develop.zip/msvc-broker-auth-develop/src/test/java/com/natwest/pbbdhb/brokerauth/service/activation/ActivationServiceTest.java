package com.natwest.pbbdhb.brokerauth.service.activation;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.CustomerIdentityManagementClient;
import com.natwest.pbbdhb.brokerauth.contexts.AccessTokenContext;
import com.natwest.pbbdhb.brokerauth.contexts.ActivationContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.brokerauth.exception.OtpException;
import com.natwest.pbbdhb.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import com.natwest.pbbdhb.brokerauth.request.exception.ErrorCode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ActivationServiceTest {

  @Mock
  CustomerIdentityManagementClient customerIdentityManagementClient;


  @Nested
  @DisplayName("Validate OTP Cases")
  class ValidateOtpCases {

    @Test
    void shouldCallCustomerIdentityManagementClient() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      service.validateActivationCode(accessToken, context.createOtpValidateRequestModel());

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfUsernameOrOtpIsInvalid() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.INVALID_CREDENTIALS, "Invalid username or otp"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateActivationCode(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfOtpIsExpired() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.OTP_EXPIRED, "Expired otp"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateActivationCode(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfAccountIsLocked() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.ACCOUNT_LOCKED, "Account is locked"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateActivationCode(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowOtpExceptionIfValidateOtpReturnsDifferentReturnCode() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new OtpException(ErrorCode.OTP_VALIDATION_FAILED, "Something went wrong"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();

      assertThatThrownBy(() -> service.validateActivationCode(accessToken,
          otpValidateRequestModel)).isInstanceOf(OtpException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }

    @Test
    void shouldThrowRemoteFailureIfClientThrowsRemoteFailure() {
      OtpContext context = OtpContext.builder().build();

      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).validateOtp(any(), any());

      OtpValidateRequestModel otpValidateRequestModel = context.createOtpValidateRequestModel();
      assertThatThrownBy(() -> service.validateActivationCode(accessToken, otpValidateRequestModel
      )).isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());
    }
  }

  @Nested
  @DisplayName("Activate User Cases")
  class ActivateUserCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallCustomerIdentityManagementClient() {

      ActivationContext context = ActivationContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername())).thenReturn(
          context.createGetUserResponseModel());
      when(customerIdentityManagementClient.retrieveOTP(accessToken,
          context.getUsername())).thenReturn(context.createOtpRetrieveResponseModel());

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      service.activateUser(context.createUserActivateRequest(), accessToken);

      verify(customerIdentityManagementClient).getUser(accessToken,
          context.getUsername());

      verify(customerIdentityManagementClient).validateOtp(accessToken,
          context.createOtpValidateRequestModel());

      verify(customerIdentityManagementClient).activateAccount(accessToken,
          context.getId());

      verify(customerIdentityManagementClient).setPassword(accessToken,
          context.createUserSetPasswordRequestModel());

      verify(customerIdentityManagementClient).createSecurityQuestions(accessToken,
          context.createSecurityQuestionsRequestModel());

      verify(customerIdentityManagementClient).retrieveOTP(accessToken,
          context.getUsername());

      verify(customerIdentityManagementClient).updateOTP(accessToken,
          context.createUpdateRequestModel());
    }

    @Test
    void shouldThrowRemoteFailureIfClientThrowsRemoteFailure() {
      ActivationContext context = ActivationContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(customerIdentityManagementClient).getUser(accessToken, context.getUsername());

      UserActivateRequest activateRequest = context.createUserActivateRequest();
      assertThatThrownBy(
          () -> service.activateUser(activateRequest, accessToken))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(customerIdentityManagementClient).getUser(accessToken,
          context.getUsername());
    }

    @Test
    void shouldReturnErrorIfSetPasswordReturnsError() {
      ActivationContext context = ActivationContext.builder().build();
      final String accessToken = AccessTokenContext.builder().build().getAccessToken();

      when(customerIdentityManagementClient.getUser(accessToken, context.getUsername())).thenReturn(
          context.createGetUserResponseModel());

      ActivationService service = new ActivationService(customerIdentityManagementClient);

      doThrow(new InvalidDetailsException(
          "Password doesn't meet requirements."))
          .when(customerIdentityManagementClient)
          .setPassword(accessToken, context.createUserSetPasswordRequestModel());

      UserActivateRequest activateRequest = context.createUserActivateRequest();
      assertThatThrownBy(
          () -> service.activateUser(activateRequest, accessToken))
          .isInstanceOf(InvalidDetailsException.class);

      verify(customerIdentityManagementClient).setPassword(accessToken,
          context.createUserSetPasswordRequestModel());
    }
  }

}
