package com.natwest.pbbdhb.brokerauth.config;

import static com.natwest.pbbdhb.brokerauth.configuration.helpers.KeyStoreHelper.keyStore;

import com.natwest.pbbdhb.brokerauth.configuration.JwtSigningConfig;
import com.natwest.pbbdhb.brokerauth.exception.KeystoreException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PublicKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

/**
 * Provides the public key that can be used to verify JWTs signed with our private key.
 * <p>
 * Consumers of JWTs issued by this service must be in possession of this public key.
 */
@TestConfiguration
public class JwtPublicKeyConfiguration {

    @Bean
    @Qualifier("jwtPublicKey")
    public PublicKey publicKey(@Autowired JwtSigningConfig config) {
        final JwtSigningConfig.SigningCertificate certificate =
            config.getCertificate();

        final char[] password = certificate.getPassword().toCharArray();

        final KeyStore keyStore = keyStore(
            certificate.getType(),
            certificate.getFile(),
            password);

        try {
            return keyStore
                .getCertificate(certificate.getAlias())
                .getPublicKey();

        } catch (KeyStoreException e) {
            throw new KeystoreException("Unable to extract public key from keystore", e);
        }
    }
}
