package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestionsRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.UserActivateRequest;
import java.util.Collections;
import java.util.List;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class ActivationContext {

  public static final String MISSING_SECURITY_ANSWER_REQUEST =
      "{\"otpCode\":\"RHF342wp\",\"username\":\"TestUsername\",\"password\":\"Password123\",\"securityQuestions\":[{\"question\":\"test question?\"}]}";

  @Default
  public String username = "TestUsername";

  @Default
  private BrokerTypeModel brokerType = BrokerTypeModel.BROKER;

  @Default
  private String status = "NEW";

  @Default
  private Brand brand = Brand.NWB;

  @Default
  private String otpCode = "RHF342wp";

  @Default
  private String password = "Password123";

  @Default
  private String id = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Default
  private String otpId = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Default
  private String parentId = "uid=5be0c229-2a1c-4466-9dac-446be8628080,ou=customer,ou=personaidentity,ou=common,dc=carnus";

  @Default
  private String otpStatus = "Used";

  @Default
  private String otpType = "ACTCODE";

  @Default
  private List<SecurityQuestion> securityQuestions = Collections.singletonList(
      SecurityQuestion.builder()
          .question("test question?")
          .answer("test answer").build());

  public UserActivateRequest createUserActivateRequest() {
    return UserActivateRequest.builder()
        .otpCode(otpCode)
        .password(password)
        .username(username)
        .securityQuestions(securityQuestions)
        .build();
  }

  public GetUserResponseModel createGetUserResponseModel() {
    return GetUserResponseModel.builder()
        .brokerType(brokerType)
        .id(id)
        .parentId(parentId)
        .build();
  }

  public UserSetPasswordRequestModel createUserSetPasswordRequestModel() {
    return UserSetPasswordRequestModel.builder()
        .customerIdentifier(id)
        .password(password)
        .build();
  }

  public SecurityQuestionsRequestModel createSecurityQuestionsRequestModel() {
    return SecurityQuestionsRequestModel.builder()
        .questions(securityQuestions)
        .parentId(parentId)
        .build();
  }

  public OtpRetrieveResponseModel createOtpRetrieveResponseModel() {
    return OtpRetrieveResponseModel.builder()
        .otpId(otpId)
        .build();
  }

  public OtpValidateRequestModel createOtpValidateRequestModel() {
    return OtpValidateRequestModel.builder()
        .username(username)
        .otpCode(otpCode)
        .build();
  }

  public OtpUpdateRequestModel createUpdateRequestModel() {
    return OtpUpdateRequestModel.builder()
        .otpId(otpId)
        .otpStatus(otpStatus)
        .otpType(otpType)
        .build();
  }
}
