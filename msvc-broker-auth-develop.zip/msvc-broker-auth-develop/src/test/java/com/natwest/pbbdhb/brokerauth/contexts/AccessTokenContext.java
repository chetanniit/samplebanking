package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.AccessTokenResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.AccessTokenRetrieveRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class AccessTokenContext {

  @Default
  private Brand brand = Brand.NWB;

  @Default
  private String clientAssertionType = "urn:ietf:params:oauth:client-assertion-type:at-bearer";

  @Default
  private String clientAssertion = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";

  @Default
  private String scope = "napoli-pdg:all";

  @Default
  private String grantType = "client_credentials";

  @Default
  private String clientId = "a3ir203_a2ir101_a5ir210_ubn_f10js_napoliservicemock_client";

  @Default
  private String accessToken = "stub-token-abcdef-123456";

  @Default
  private String tokenType = "Bearer";

  @Default
  private int expiresIn = 599;

  @Default
  private String errorType = "invalid_client";

  @Default
  private String errorDescription = "Invalid client or client credentials.";

  public AccessTokenRetrieveRequestModel createAccessTokenRetrieveRequestModel() {
    return AccessTokenRetrieveRequestModel.builder()
        .brand(brand)
        .clientAssertionType(clientAssertionType)
        .clientAssertion(clientAssertion)
        .clientId(clientId)
        .grantType(grantType)
        .scope(scope)
        .build();
  }

  public AccessTokenResponseModel createAccessTokenResponseModel() {
    return AccessTokenResponseModel.builder()
        .accessToken(accessToken)
        .tokenType(tokenType)
        .expiresIn(expiresIn)
        .build();
  }
}
