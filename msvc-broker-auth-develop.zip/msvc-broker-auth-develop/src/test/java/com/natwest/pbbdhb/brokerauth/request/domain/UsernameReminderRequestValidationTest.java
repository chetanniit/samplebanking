package com.natwest.pbbdhb.brokerauth.request.domain;

import com.natwest.pbbdhb.brokerauth.utils.TestUtils;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

import static com.natwest.pbbdhb.brokerauth.request.domain.AbstractValidationTest.TestValidationError.create;

public class UsernameReminderRequestValidationTest extends AbstractValidationTest<UsernameReminderRequest> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid username reminder request", (Consumer<UsernameReminderRequest>) a -> {
                }, EMPTY_SET),
                Arguments.of("@NotNull annotation - error when last name is null", (Consumer<UsernameReminderRequest>) a -> a.setLastName(null), singleton(create("lastName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("@NotNull annotation - error when email is null", (Consumer<UsernameReminderRequest>) a -> a.setEmail(null), singleton(create("email", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("@NotNull annotation - error when date of birth is null", (Consumer<UsernameReminderRequest>) a -> a.setDateOfBirth(null), singleton(create("dateOfBirth", MUST_NOT_BE_NULL_ERROR_MESSAGE)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testBrokerCaseValidations(String testDescription, Consumer<UsernameReminderRequest> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtils::aUsernameReminderRequest, mutator, expectedErrorMessages);
    }
}
