package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.domain.PasswordResetRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.UserSetPasswordRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.PasswordResetRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Getter
@ToString
@Builder
@Slf4j
public class PasswordResetContext {

  @Default
  private String username = "TestUsername";

  @Default
  private String otpCode = "RHF342wp";

  @Default
  private String password = "Password123";

  @Default
  private String id = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  public PasswordResetRequestModel createPasswordResetRequestModel() {
    return PasswordResetRequestModel.builder()
        .username(username)
        .otpCode(otpCode)
        .password(password)
        .build();
  }

  public PasswordResetRequest createPasswordResetRequest() {
    return PasswordResetRequest.builder()
        .username(username)
        .otpCode(otpCode)
        .password(password)
        .build();
  }

  public UserSetPasswordRequestModel createUserSetPasswordRequestModel() {
    return UserSetPasswordRequestModel.builder()
        .customerIdentifier(id)
        .password(password)
        .build();
  }
}
