package com.natwest.pbbdhb.brokerauth.contexts;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpInitialiseClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest.Operations;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest.Operations.Values;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.OtpValidateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeGenerateRequest;
import com.natwest.pbbdhb.brokerauth.request.domain.ActivationCodeValidateRequest;
import java.util.Collections;
import java.util.List;

import com.natwest.pbbdhb.brokerauth.request.domain.OtpValidateRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Getter
@ToString
@Builder
@Slf4j
public class OtpContext {

  @Default
  private String username = "TestUsername";

  @Default
  private String otpInitialiseType = "ACTCODE";

  @Default
  private String otpUpdateType = "OTP";

  @Default
  private String otpStatus = "New";

  @Default
  public String activationCode = "testActivationCode";

  @Default
  public String op = "replace";

  @Default
  private List<String> otpInitialiseSchema = Collections.singletonList(
      "urn:generic:schemas:otp:1.0");

  @Default
  private List<String> otpGenerateSchema = Collections.singletonList(
      "urn:pingidentity:scim:api:messages:2.0:PasswordUpdateRequest");

  @Default
  private List<String> otpUpdateSchema = Collections.singletonList(
      "urn:ietf:params:scim:api:messages:2.0:PatchOp");

  @Default
  private String otpId = "7d2b3b4a-421c-4726-bc49-19645dbe047c";

  @Default
  private Brand brand = Brand.NWB;

  @Default
  private String otpCode = "RHF342wp";

  @Default
  private String otpType = "ACTCODE";

  @Default
  private String formattedUsername = "CPB-NAPL-NWB@TestUsername";

  public OtpUpdateRequestModel createOtpUpdateRequestModel() {
    return OtpUpdateRequestModel.builder()
        .otpStatus(otpStatus)
        .otpId(otpId)
        .otpType("OTP")
        .build();
  }

  public OtpUpdateRequestModel createActivationCodeUpdateRequestModel() {
    return OtpUpdateRequestModel.builder()
        .otpStatus(otpStatus)
        .otpId(otpId)
        .otpType("ACTCODE")
        .build();
  }

  public OtpInitialiseClientRequest createOtpInitialiseClientRequest() {
    return OtpInitialiseClientRequest.builder()
        .username(formattedUsername)
        .otpStatus(otpStatus)
        .otpType(otpInitialiseType)
        .schemas(otpInitialiseSchema)
        .build();
  }

  public OtpGenerateClientRequest createOtpGenerateClientRequest() {
    return OtpGenerateClientRequest.builder()
        .schemas(otpGenerateSchema)
        .build();
  }

  public OtpUpdateClientRequest createOtpUpdateClientRequest() {
    return OtpUpdateClientRequest.builder()
        .schemas(otpUpdateSchema)
        .operations(Collections.singletonList(Operations.builder()
            .op(op)
            .value(Values.builder()
                .otpStatus(otpStatus)
                .otpType(otpUpdateType)
                .build())
            .build()))
        .build();
  }

  public OtpUpdateClientRequest createActivationCodeUpdateClientRequest() {
    return OtpUpdateClientRequest.builder()
        .schemas(otpUpdateSchema)
        .operations(Collections.singletonList(Operations.builder()
            .op(op)
            .value(Values.builder()
                .otpStatus(otpStatus)
                .otpType(otpInitialiseType)
                .build())
            .build()))
        .build();
  }

  public OtpValidateRequest createOtpValidateRequest() {
    return OtpValidateRequest.builder()
        .username(username)
        .otpCode(otpCode)
        .build();
  }

  public OtpValidateRequestModel createOtpValidateRequestModel() {
    return OtpValidateRequestModel.builder()
        .username(username)
        .otpCode(otpCode)
        .build();
  }

  public OtpUpdateRequestModel createUpdateRequestModel() {
    return OtpUpdateRequestModel.builder()
        .otpId(otpId)
        .otpStatus(otpStatus)
        .otpType(otpType)
        .build();
  }

  public OtpRetrieveResponseModel createOtpRetrieveResponseModel() {
    return OtpRetrieveResponseModel.builder()
        .otpId(otpId)
        .build();
  }


  public OtpGenerateResponseModel createOtpGenerateResponseModel() {
    return OtpGenerateResponseModel.builder()
        .activationCode(activationCode)
        .build();
  }

  public ActivationCodeValidateRequest createActivationCodeValidateRequest() {
    return ActivationCodeValidateRequest.builder()
        .code(otpCode)
        .username(username)
        .build();
  }

  public ActivationCodeGenerateRequest createActivationCodeGenerateRequest() {
    return ActivationCodeGenerateRequest.builder()
        .username(username)
        .build();
  }
}
