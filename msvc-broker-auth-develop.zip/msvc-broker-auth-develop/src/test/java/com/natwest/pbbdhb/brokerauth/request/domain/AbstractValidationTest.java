package com.natwest.pbbdhb.brokerauth.request.domain;

import jakarta.validation.ConstraintViolation;
import lombok.Data;

import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.brokerauth.utils.TestUtils.getConstraintViolations;
import static org.assertj.core.api.Assertions.assertThat;

public abstract class AbstractValidationTest<T> {

    protected void testValidations(String testDescription, Supplier<T> producer, Consumer<T> mutator, Set<TestValidationError> expectedErrors) {
        T objectToValidate = producer.get();
        mutator.accept(objectToValidate);

        Set<ConstraintViolation<T>> violations = getConstraintViolations(objectToValidate);

        assertThat(violations)
                .withFailMessage(String.format("Unexpected number of validation failures for test '%s'. Actual errors:\n%s\n",
                        testDescription, getActualErrors(violations)))
                .hasSize(expectedErrors.size());
        for (TestValidationError expectedError : expectedErrors) {
            assertThat(violations.stream()
                    .filter(v ->
                            expectedError.getField().equals(v.getPropertyPath().toString())
                                    && expectedError.getMessage().equals(v.getMessage())
                    ))
                    .withFailMessage(String.format("Expected error '%s' not found for test '%s'. Actual errors:\n%s\n",
                            expectedError, testDescription, getActualErrors(violations)))
                    .hasSize(1);
        }
    }

    private String getActualErrors(Set<ConstraintViolation<T>> violations) {
        return violations.stream().map(v -> String.format("field: '%s', message: '%s'", v.getPropertyPath(), v.getMessage())).collect(Collectors.joining("\n"));
    }

    @Data
    protected static class TestValidationError {
        private String field;
        private String message;

        public static TestValidationError create(String field, String message) {
            TestValidationError error = new TestValidationError();
            error.setField(field);
            error.setMessage(message);
            return error;
        }
    }
}
