package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse.GetUserResources;
import com.natwest.pbbdhb.brokerauth.domain.BrokerTypeModel;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class GetUserResourcesContext {

  @Default
  private String id = "TestId";

  @Default
  private BrokerTypeModel brokerType = BrokerTypeModel.BROKER;

  @Default
  private String parentId = "uid=5be0c229-2a1c-4466-9dac-446be8628080,ou=customer,ou=personaidentity,ou=common,dc=carnus";

  public static GetUserResourcesContext.GetUserResourcesContextBuilder getUserResourcesBuilder() {
    return GetUserResourcesContext.builder()
        .id("TestId")
        .parentId(
            "uid=5be0c229-2a1c-4466-9dac-446be8628080,ou=customer,ou=personaidentity,ou=common,dc=carnus")
        .brokerType(BrokerTypeModel.BROKER);
  }

  public GetUserResources getUserResources() {
    return GetUserResources.builder()
        .id(id)
        .brokerType(brokerType)
        .parentId(parentId)
        .build();
  }

  public ObjectNode getUserResourcesPayload() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("id", id);
    payload.put("parentidentity", parentId);
    payload.put("personaidentifiertype", brokerType.getValue());
    return payload;
  }
}