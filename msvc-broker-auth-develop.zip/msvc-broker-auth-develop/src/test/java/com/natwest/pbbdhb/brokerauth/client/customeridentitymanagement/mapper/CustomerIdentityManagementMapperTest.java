package com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.mapper;

import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.GetUserClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.GetUserResourcesContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.OtpGenerateClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.OtpRetrieveClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.OtpRetrieveResourcesContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.contexts.SecurityQuestionsClientContext;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.GetUserClientResponse.GetUserResources;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpGenerateClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpInitialiseClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpRetrieveClientResponse.OtpRetrieveResources;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.OtpUpdateClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.SecurityQuestionsClientRequest;
import com.natwest.pbbdhb.brokerauth.client.customeridentitymanagement.domain.UserCreateClientRequest;
import com.natwest.pbbdhb.brokerauth.contexts.ActivationContext;
import com.natwest.pbbdhb.brokerauth.contexts.LoginContext;
import com.natwest.pbbdhb.brokerauth.contexts.OtpContext;
import com.natwest.pbbdhb.brokerauth.contexts.UserContext;
import com.natwest.pbbdhb.brokerauth.domain.Brand;
import com.natwest.pbbdhb.brokerauth.domain.GetUserResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.brokerauth.domain.UserCreateRequestModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpGenerateResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpRetrieveResponseModel;
import com.natwest.pbbdhb.brokerauth.domain.otp.OtpUpdateRequestModel;
import com.natwest.pbbdhb.brokerauth.exception.InvalidDataResponseException;
import com.natwest.pbbdhb.brokerauth.exception.UserNotFoundException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Testing the Customer Identity Management client response mapping.
 */
class CustomerIdentityManagementMapperTest {

  @Nested
  @DisplayName("toUserCreateClientRequest Cases")
  class ToUserCreateClientRequestCases {

    @Test
    void shouldMapToCorrectUserCreateClientRequest() {
      UserContext userContext = UserContext.builder().build();
      UserCreateRequestModel userCreateRequestModel = userContext.createUserCreateRequestModel();

      UserCreateClientRequest result = CustomerIdentityManagementMapper.toUserCreateClientRequest(
          userCreateRequestModel, Brand.NWB);

      UserCreateClientRequest expected = userContext.createUserCreateClientRequest();

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toUserCreateClientRequest(null, Brand.NWB)
      );
    }
  }

  @Nested
  @DisplayName("toOtpInitialiseClientRequest Cases")
  class ToOtpInitialiseClientRequestCases {

    @Test
    void shouldMapToCorrectOtpInitialiseClientRequest() {
      OtpContext otpContext = OtpContext.builder().build();

      OtpInitialiseClientRequest result = CustomerIdentityManagementMapper.toOtpInitialiseClientRequest(
          otpContext.getUsername(), Brand.NWB);

      OtpInitialiseClientRequest expected = otpContext.createOtpInitialiseClientRequest();

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing error case when trying to map over a null reference for username.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNullForUsername() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toOtpInitialiseClientRequest(null, Brand.NWB)
      );
    }

    /**
     * Testing error case when trying to map over a null reference for brand.
     */
    @Test
    void throwsExceptionWhenSuppliedNullForBrand() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toOtpInitialiseClientRequest(
              OtpContext.builder().build().getUsername(), null)
      );
    }
  }

  @Nested
  @DisplayName("toOtpGenerateClientRequest Cases")
  class ToOtpGenerateClientRequestCases {

    @Test
    void shouldMapToCorrectOtpGenerateClientRequest() {
      OtpContext otpContext = OtpContext.builder().build();

      OtpGenerateClientRequest result = CustomerIdentityManagementMapper.toOtpGenerateClientRequest();

      OtpGenerateClientRequest expected = otpContext.createOtpGenerateClientRequest();

      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("toOtpUpdateClientRequest Cases")
  class ToOtpUpdateClientRequestCases {

    @Test
    void shouldMapToCorrectOtpUpdateClientRequest() {
      OtpContext otpContext = OtpContext.builder().build();
      OtpUpdateRequestModel otpUpdateRequestModel = otpContext.createOtpUpdateRequestModel();

      OtpUpdateClientRequest result = CustomerIdentityManagementMapper.toOtpUpdateClientRequest(
          otpUpdateRequestModel);

      OtpUpdateClientRequest expected = otpContext.createOtpUpdateClientRequest();

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toOtpUpdateClientRequest(null)
      );
    }
  }

  @Nested
  @DisplayName("toActivationCodeUpdateClientRequest Cases")
  class ToActivationCodeUpdateClientRequestCases {

    @Test
    void shouldMapToCorrectOtpUpdateClientRequest() {
      OtpContext otpContext = OtpContext.builder().build();
      OtpUpdateRequestModel otpUpdateRequestModel = otpContext.createActivationCodeUpdateRequestModel();

      OtpUpdateClientRequest result = CustomerIdentityManagementMapper.toOtpUpdateClientRequest(
          otpUpdateRequestModel);

      OtpUpdateClientRequest expected = otpContext.createActivationCodeUpdateClientRequest();

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toOtpUpdateClientRequest(null)
      );
    }
  }

  @Nested
  @DisplayName("toGetUserResponseModel Cases")
  class ToGetUserResponseModelCases {

    @Test
    void shouldMapToCorrectGetUserResponseModel() {
      GetUserClientResponse getUserClientResponse = GetUserClientContext.builder().build()
          .createGetUserClientResponse();

      GetUserResponseModel result = CustomerIdentityManagementMapper.toGetUserResponseModel(
          getUserClientResponse);

      GetUserResponseModel expected = LoginContext.builder().build().createGetUserResponseModel();

      Assertions.assertEquals(expected, result);
    }

    @Test
    void shouldThrowExceptionWhenMoreThanOneUserIsReturned() {
      GetUserResources userResource = GetUserResourcesContext.builder().build()
          .getUserResources();

      GetUserClientResponse getUserClientResponse = GetUserClientContext.builder().build()
          .createGetUserClientResponseBuilder()
          .resources(
              Arrays.asList(userResource, userResource))
          .build();

      Assertions.assertThrows(InvalidDataResponseException.class, () ->
          CustomerIdentityManagementMapper.toGetUserResponseModel(getUserClientResponse)
      );
    }

    @Test
    void shouldThrowExceptionWhenUserListReturnedIsEmpty() {
      GetUserClientResponse getUserClientResponse = GetUserClientContext.builder().build()
          .createGetUserClientResponseBuilder()
          .resources(Collections.emptyList())
          .build();

      Assertions.assertThrows(UserNotFoundException.class, () ->
          CustomerIdentityManagementMapper.toGetUserResponseModel(getUserClientResponse)
      );
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toGetUserResponseModel(null)
      );
    }
  }

  @Nested
  @DisplayName("toOtpRetrieveResponseModel Cases")
  class ToOtpRetrieveResponseModelCases {

    @Test
    void shouldMapToCorrectOtpRetrieveResponseModel() {
      OtpRetrieveClientResponse otpRetrieveClientResponse = OtpRetrieveClientContext.builder()
          .build().createOtpRetrieveClientResponse();

      OtpRetrieveResponseModel result = CustomerIdentityManagementMapper.toOtpRetrieveResponseModel(
          otpRetrieveClientResponse);

      OtpRetrieveResponseModel expected = OtpContext.builder().build()
          .createOtpRetrieveResponseModel();

      Assertions.assertEquals(expected, result);
    }

    @Test
    void shouldThrowExceptionWhenMoreThanOneOtpIsReturned() {
      OtpRetrieveResources otpResource = OtpRetrieveResourcesContext.builder().build()
          .getOtpResources();

      OtpRetrieveClientResponse otpRetrieveClientResponse = OtpRetrieveClientContext.builder()
          .build()
          .createOtpRetrieveClientResponseBuilder()
          .resources(
              Arrays.asList(otpResource, otpResource))
          .build();

      Assertions.assertThrows(InvalidDataResponseException.class, () ->
          CustomerIdentityManagementMapper.toOtpRetrieveResponseModel(otpRetrieveClientResponse)
      );
    }

    @Test
    void shouldThrowExceptionWhenOtpListReturnedIsEmpty() {
      OtpRetrieveClientResponse otpRetrieveClientResponse = OtpRetrieveClientContext.builder()
          .build()
          .createOtpRetrieveClientResponseBuilder()
          .resources(Collections.emptyList())
          .build();

      Assertions.assertThrows(InvalidDataResponseException.class, () ->
          CustomerIdentityManagementMapper.toOtpRetrieveResponseModel(otpRetrieveClientResponse)
      );
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toOtpRetrieveResponseModel(null)
      );
    }
  }

  @Nested
  @DisplayName("toOtpGenerateResponseModel Cases")
  class ToOtpGenerateResponseModelCases {

    @Test
    void shouldMapToCorrectOtpGenerateResponseModel() {
      OtpGenerateClientResponse otpGenerateClientResponse = OtpGenerateClientContext.builder()
          .build().createOtpGenerateClientResponse();

      OtpGenerateResponseModel result = CustomerIdentityManagementMapper.toOtpGenerateResponseModel(
          otpGenerateClientResponse);

      OtpGenerateResponseModel expected = OtpContext.builder().build()
          .createOtpGenerateResponseModel();

      Assertions.assertEquals(expected, result);
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          CustomerIdentityManagementMapper.toOtpGenerateResponseModel(null)
      );
    }
  }

  @Nested
  @DisplayName("formatUserName Cases")
  class FormatUserNameCases {

    @Test
    void shouldFormatUsernameCorrectly() {
      UserContext userContext = UserContext.builder().build();
      Brand brand = userContext.getBrand();
      String username = userContext.getUsername();

      String result = CustomerIdentityManagementMapper.formatUserName(brand,
          userContext.getUsername());

      String expected = "CPB-NAPL-" + brand + "@" + username;

      Assertions.assertEquals(expected, result);
    }
  }

  @Nested
  @DisplayName("Create Security Questions Cases")
  class CreateSecurityQuestionCases {

    @Test
    void shouldMapASecurityQuestionCorrectly() {
      ActivationContext activationContext = ActivationContext.builder().build();
      SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .build();

      SecurityQuestionsClientRequest result = CustomerIdentityManagementMapper.toSecurityQuestionsClientRequest(
          activationContext.createSecurityQuestionsRequestModel());

      Assertions.assertEquals(clientContext.createSecurityQuestionsClientRequest(), result);
    }

    @Test
    void shouldMapMultipleSecurityQuestionsCorrectly() {
      ActivationContext activationContext = ActivationContext.builder()
          .securityQuestions(Arrays.asList(
              SecurityQuestion.builder()
                  .question("test question 1?")
                  .answer("test answer 1").build(),
              SecurityQuestion.builder()
                  .question("test question 2?")
                  .answer("test answer 2").build()
          )).build();
      SecurityQuestionsClientContext clientContext = SecurityQuestionsClientContext.builder()
          .questions(new HashMap<String, String>() {{
            put("q1", "test question 1?");
            put("q2", "test question 2?");
          }})
          .answers(Arrays.asList(
              "test question 1?test answer 1",
              "test question 2?test answer 2"
          ))
          .build();

      SecurityQuestionsClientRequest result = CustomerIdentityManagementMapper.toSecurityQuestionsClientRequest(
          activationContext.createSecurityQuestionsRequestModel());

      Assertions.assertEquals(clientContext.createSecurityQuestionsClientRequest(), result);
    }

  }
}
