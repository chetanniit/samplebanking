# coord-application-tracking
**description**: \
Spring boot application supporting external services for mortgage application tracking


## Build the application
```shell script
mvn clean install
```

## Running unit tests
```shell script
mvn clean test
```

## Running all tests
```shell script
mvn clean verify -P integration-test
```

## Running the application with the "local" spring profile
```shell script
mvn spring-boot:run -Djasypt.encryptor.password=****** -Dspring.profiles.active=local,unsecure
```

## Endpoints documented via OpenAPI
```shell script
http://localhost:8080/mortgages/v1/application-tracking/swagger-ui/index.html
```

## REST API contract in JSON format
```shell script
http://localhost:8080/mortgages/v1/application-tracking/v3/api-docs
```

## Actuator endpoints
```shell script
http://localhost:8080/mortgages/v1/application-tracking/actuator/info

http://localhost:8080/mortgages/v1/application-tracking/actuator/env
```
