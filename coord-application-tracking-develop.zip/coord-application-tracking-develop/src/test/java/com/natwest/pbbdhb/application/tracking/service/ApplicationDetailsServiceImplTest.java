/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import static com.natwest.pbbdhb.application.tracking.util.TestConstants.ACTION_REQUIRED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.ACTION_REQUIRED_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.AMBER;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.AMBER_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.CLOSE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.COMPLETION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.COMPLETION_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DECLINE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DECLINE_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GLOBAL_SUB_STATUS;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GLOBAL_SUB_STATUS_CANCELLED_DESCRIPTION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GLOBAL_SUB_STATUS_DECLINED_DESCRIPTION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GREEN;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GREEN_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GREY;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.GREY_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.NO_ACTION_REQUIRED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.NO_ACTION_REQUIRED_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.OFFER;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.OFFER_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.OPEN;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_CANCELLED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_CANCELLED_DESCRIPTION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_STATUS;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.PRODUCT_SWITCH_STATUS_DESCRIPTION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.RED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.RED_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.STAGE_COMPLETION_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.SUB_STATUS_CANCELLED;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.SUB_STATUS_DECLINED;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.REFERENCE_NUMBER;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getApplicationDetailRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.ApplicationDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StageHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.StatusInfo;
import com.natwest.pbbdhb.application.tracking.service.impl.ApplicationDetailsServiceImpl;
import com.natwest.pbbdhb.application.tracking.service.impl.BrokerServiceImpl;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ApplicationDetailsServiceImplTest {

    @InjectMocks private ApplicationDetailsServiceImpl detailsServiceImpl;

    @Mock private GmsStageAndTaskLoader gmsStageAndTaskLoader;

    private static final String NWB_BRAND = "NWB";

    @InjectMocks private BrokerServiceImpl service;

    @Mock private RestTemplate restTemplate;

    public static final String BASE_URL =
            "https://v1-msvc-applications-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/";
    public static final String APPLICATION_INFO_ENDPOINT =
            "applicationInformation/{referenceNumber}";
    public static final String APPLICATION_DETAILS_ENDPOINT =
            "applicationDetails/{referenceNumber}";
    public static final String VALUATION_ENDPOINT = "valuationDetails/{referenceNumber}";

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(gmsStageAndTaskLoader, restTemplate);
    }

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(detailsServiceImpl, "applicationParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(
                detailsServiceImpl, "applicationInfoEndpoint", APPLICATION_INFO_ENDPOINT);
        ReflectionTestUtils.setField(
                detailsServiceImpl, "applicationDetailsEndpoint", APPLICATION_DETAILS_ENDPOINT);
        ReflectionTestUtils.setField(
                detailsServiceImpl, "valuationInfoEndpoint", VALUATION_ENDPOINT);
    }

    @Test
    void populateApplicationRagStatusAmberTest() {

        when(gmsStageAndTaskLoader.getStageDescription("40"))
                .thenReturn(new GMSStageDescription(null, OFFER, OFFER_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(AMBER)).thenReturn(AMBER_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("40", "A29");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);

        assertEquals(
                AMBER, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                AMBER_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(OFFER, applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                OFFER_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());
        assertEquals(
                OPEN,
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).getStatus());

        verify(gmsStageAndTaskLoader).getStageDescription("40");
        verify(gmsStageAndTaskLoader).getStatusDescription(AMBER);
    }

    @Test
    void populateStatusDescriptionForCompletedApplication() {
        when(gmsStageAndTaskLoader.getStageDescription("80"))
                .thenReturn(new GMSStageDescription(null, COMPLETION, COMPLETION_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(GREEN)).thenReturn(GREEN_DESC);

        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject("80", "SCK");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);

        assertEquals(
                GREEN, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREEN_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                COMPLETION, applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                COMPLETION_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());
        assertEquals(
                CLOSE,
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).getStatus());

        verify(gmsStageAndTaskLoader).getStageDescription("80");
        verify(gmsStageAndTaskLoader).getStatusDescription(GREEN);
    }

    @Test
    void populateApplicationRagStatusGreenTest() {

        when(gmsStageAndTaskLoader.getStageDescription("80"))
                .thenReturn(new GMSStageDescription(null, COMPLETION, STAGE_COMPLETION_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(GREEN)).thenReturn(GREEN_DESC);

        ApplicationDetailsInfo applicationDetailsInfo =
                new ApplicationDetailsInfo(
                        null,
                        null,
                        null,
                        null,
                        null,
                        new ApplicationDetails(
                                Collections.singletonList(
                                        new StageHistory(null, "80", null, null, null)),
                                Collections.emptyList(),
                                null,
                                new StatusInfo()),
                        null,
                        new Date());

        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);

        assertEquals(
                GREEN, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREEN_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                COMPLETION, applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                STAGE_COMPLETION_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());

        verify(gmsStageAndTaskLoader).getStageDescription("80");
        verify(gmsStageAndTaskLoader).getStatusDescription(GREEN);
    }

    @Test
    void populateApplicationRagStatusREDTest() {

        when(gmsStageAndTaskLoader.getStageDescription("85"))
                .thenReturn(new GMSStageDescription(null, DECLINE, DECLINE_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(RED)).thenReturn(RED_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("85", "A29");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);

        assertEquals(
                RED, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                RED_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                DECLINE, applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                DECLINE_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());

        verify(gmsStageAndTaskLoader).getStageDescription("85");
        verify(gmsStageAndTaskLoader).getStatusDescription(RED);
    }

    @Test
    void populateApplicationSubStatusNoActionTest() {

        when(gmsStageAndTaskLoader.isAwaitTask("R21")).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask("R21")).thenReturn(true);
        when(gmsStageAndTaskLoader.getStatusDescription(NO_ACTION_REQUIRED))
                .thenReturn(NO_ACTION_REQUIRED_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("25", "R21");
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                NO_ACTION_REQUIRED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                NO_ACTION_REQUIRED_DESC,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask("R21");
        verify(gmsStageAndTaskLoader).isAssessTask("R21");
        verify(gmsStageAndTaskLoader).getStatusDescription(NO_ACTION_REQUIRED);
    }

    @Test
    void populateApplicationSubStatusAttentionTest() {

        when(gmsStageAndTaskLoader.isAwaitTask("A29")).thenReturn(true);
        when(gmsStageAndTaskLoader.getStatusDescription(ACTION_REQUIRED))
                .thenReturn(ACTION_REQUIRED_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("25", "A29");
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                ACTION_REQUIRED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                ACTION_REQUIRED_DESC,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask("A29");
        verify(gmsStageAndTaskLoader).getStatusDescription(ACTION_REQUIRED);
    }

    @Test
    void populateApplicationSubStatusCompletionTest() {

        when(gmsStageAndTaskLoader.isAwaitTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.getStatusDescription(COMPLETION)).thenReturn(COMPLETION_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("80", null);
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                COMPLETION,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                COMPLETION_DESC,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(null);
        verify(gmsStageAndTaskLoader).isAssessTask(null);
        verify(gmsStageAndTaskLoader).getStatusDescription(COMPLETION);
    }

    private ApplicationDetailsInfo getMockApplicationDetailsInfo(String stageNo, String taskCode) {
        return new ApplicationDetailsInfo(
                null,
                null,
                null,
                null,
                null,
                new ApplicationDetails(
                        Collections.singletonList(
                                new StageHistory(null, stageNo, null, null, null)),
                        Collections.singletonList(
                                new CaseHistory(null, taskCode, null, null, null, OPEN)),
                        null,
                        new StatusInfo()),
                null,
                new Date());
    }

    @Test
    void testGetApplicationInfo() {

        when(restTemplate.exchange(any(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{\"productInformation\": [{}]}", HttpStatus.OK));

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        detailsServiceImpl.getApplicationInfo(
                NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(restTemplate).exchange(any(), any(HttpMethod.class), any(), eq(String.class));
    }

    @Test
    void testGetApplicationInfoException() {
        when(restTemplate.exchange(any(), any(HttpMethod.class), any(), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        assertThrows(
                HttpClientErrorException.class,
                () ->
                        detailsServiceImpl.getApplicationInfo(
                                NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest));

        verify(restTemplate).exchange(any(), any(HttpMethod.class), any(), eq(String.class));
    }

    @Test
    void testGetApplicationDetail() {
        when(restTemplate.exchange(any(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{\"applicationDetails\": }", HttpStatus.OK));

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        detailsServiceImpl.getApplicationDetail(
                NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(restTemplate).exchange(any(), any(HttpMethod.class), any(), eq(String.class));
    }

    @Test
    void testGetValuationInformation() {
        when(restTemplate.exchange(any(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{\"valuationInformation\": }", HttpStatus.OK));

        ApplicationDetailRequest applicationDetailRequest = getApplicationDetailRequest();
        detailsServiceImpl.getValuationInformation(
                NWB_BRAND, REFERENCE_NUMBER, applicationDetailRequest);

        verify(restTemplate).exchange(any(), any(HttpMethod.class), any(), eq(String.class));
    }

    private ApplicationDetailsInfo getMockApplicationDetailsObject(
            String stageNo, String taskCode) {
        return new ApplicationDetailsInfo(
                null,
                null,
                null,
                null,
                null,
                new ApplicationDetails(
                        Collections.singletonList(
                                new StageHistory(
                                        null,
                                        stageNo,
                                        null,
                                        ZonedDateTime.now(),
                                        ZonedDateTime.now())),
                        Collections.singletonList(
                                new CaseHistory(
                                        null,
                                        taskCode,
                                        null,
                                        ZonedDateTime.now(),
                                        ZonedDateTime.now(),
                                        CLOSE)),
                        null,
                        new StatusInfo()),
                null,
                new Date());
    }

    @Test
    void populateApplicationSubStatusCancelledTest() {

        when(gmsStageAndTaskLoader.isAwaitTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_CANCELLED))
                .thenReturn(GLOBAL_SUB_STATUS_CANCELLED_DESCRIPTION);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("90", null);
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                SUB_STATUS_CANCELLED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                GLOBAL_SUB_STATUS_CANCELLED_DESCRIPTION,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(null);
        verify(gmsStageAndTaskLoader).isAssessTask(null);
        verify(gmsStageAndTaskLoader)
                .getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_CANCELLED);
    }

    @Test
    void populateApplicationSubStatusDeclinedTest1() {

        when(gmsStageAndTaskLoader.isAwaitTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_DECLINED))
                .thenReturn(GLOBAL_SUB_STATUS_DECLINED_DESCRIPTION);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("84", null);
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                SUB_STATUS_DECLINED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                GLOBAL_SUB_STATUS_DECLINED_DESCRIPTION,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(null);
        verify(gmsStageAndTaskLoader).isAssessTask(null);
        verify(gmsStageAndTaskLoader).getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_DECLINED);
    }

    @Test
    void populateApplicationSubStatusDeclinedTest2() {

        when(gmsStageAndTaskLoader.isAwaitTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_DECLINED))
                .thenReturn(GLOBAL_SUB_STATUS_DECLINED_DESCRIPTION);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("85", null);
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                SUB_STATUS_DECLINED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                GLOBAL_SUB_STATUS_DECLINED_DESCRIPTION,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(null);
        verify(gmsStageAndTaskLoader).isAssessTask(null);
        verify(gmsStageAndTaskLoader).getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_DECLINED);
    }

    @Test
    void populateApplicationSubStatusNoActionTest1() {
        when(gmsStageAndTaskLoader.getStatusDescription(null)).thenReturn(null);
        ApplicationDetailsInfo applicationDetailsInfo =
                new ApplicationDetailsInfo(
                        null,
                        null,
                        null,
                        null,
                        null,
                        new ApplicationDetails(
                                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new StatusInfo()),
                        null,
                        new Date());
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);
        assertNull(applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertNull(
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(null);
    }

    @Test
    void populateApplicationRagStatusGreyTest() {
        when(gmsStageAndTaskLoader.getStageDescription(null)).thenReturn(null);
        when(gmsStageAndTaskLoader.getStatusDescription(GREY)).thenReturn(GREY_DESC);

        ApplicationDetailsInfo applicationDetailsInfo =
                new ApplicationDetailsInfo(
                        null,
                        null,
                        null,
                        null,
                        null,
                        new ApplicationDetails(
                                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new StatusInfo()),
                        null,
                        new Date());
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);

        assertEquals(
                GREY, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREY_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertNull(applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertNull(
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());

        verify(gmsStageAndTaskLoader).getStageDescription(null);
        verify(gmsStageAndTaskLoader).getStatusDescription(GREY);
    }

    @Test
    void populateRagStatusSkipWhenApplicationDetailsNull() {
        ApplicationDetailsInfo applicationDetailsInfo = ApplicationDetailsInfo.builder().build();
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);
        assertNull(applicationDetailsInfo.getApplicationDetails());
        verifyNoInteractions(gmsStageAndTaskLoader);
    }

    @Test
    void populateSubStatusSkipWhenApplicationDetailsNull() {
        ApplicationDetailsInfo applicationDetailsInfo = ApplicationDetailsInfo.builder().build();
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);
        assertNull(applicationDetailsInfo.getApplicationDetails());
        verifyNoInteractions(gmsStageAndTaskLoader);
    }

    @Test
    void populateStatusDescriptionForFundReturnedApplication() {
        when(gmsStageAndTaskLoader.getStageDescription("92"))
                .thenReturn(new GMSStageDescription(null, COMPLETION, COMPLETION_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(GREEN)).thenReturn(GREEN_DESC);

        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject("92", "RET");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, false);

        assertEquals(
                GREEN, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREEN_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                COMPLETION, applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                COMPLETION_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());
        assertEquals(
                CLOSE,
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).getStatus());

        verify(gmsStageAndTaskLoader).getStageDescription("92");
        verify(gmsStageAndTaskLoader).getStatusDescription(GREEN);
    }

    @Test
    void populateApplicationSubStatusNoActionRETTaskTest() {

        when(gmsStageAndTaskLoader.isAwaitTask("RET")).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask("RET")).thenReturn(true);
        when(gmsStageAndTaskLoader.getStatusDescription(NO_ACTION_REQUIRED))
                .thenReturn(NO_ACTION_REQUIRED_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("92", "RET");
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, false);

        assertEquals(
                NO_ACTION_REQUIRED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                NO_ACTION_REQUIRED_DESC,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask("RET");
        verify(gmsStageAndTaskLoader).isAssessTask("RET");
        verify(gmsStageAndTaskLoader).getStatusDescription(NO_ACTION_REQUIRED);
    }

    @Test
    void populateStatusDescriptionForCompletedProductSwitchApplication() {
        when(gmsStageAndTaskLoader.getStageDescription("80"))
                .thenReturn(new GMSStageDescription(null, COMPLETION, COMPLETION_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(GREEN)).thenReturn(GREEN_DESC);

        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject("80", "SCK");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, true);

        assertEquals(
                GREEN, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREEN_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                PRODUCT_SWITCH_STATUS,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                PRODUCT_SWITCH_STATUS_DESCRIPTION,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());
        assertEquals(
                CLOSE,
                applicationDetailsInfo.getApplicationDetails().getCaseHistory().get(0).getStatus());

        verify(gmsStageAndTaskLoader).getStageDescription("80");
        verify(gmsStageAndTaskLoader).getStatusDescription(GREEN);
    }

    @Test
    void populateStatusDescriptionForOfferProductSwitchApplication() {
        when(gmsStageAndTaskLoader.getStageDescription("40"))
                .thenReturn(new GMSStageDescription(null, COMPLETION, COMPLETION_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(AMBER)).thenReturn(AMBER_DESC);
        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject("40", "SCK");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, true);

        assertEquals(
                AMBER, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                AMBER_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                PRODUCT_SWITCH_STATUS,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                PRODUCT_SWITCH_STATUS_DESCRIPTION,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());

        verify(gmsStageAndTaskLoader).getStageDescription("40");
        verify(gmsStageAndTaskLoader).getStatusDescription(AMBER);
    }

    @Test
    void populateStatusDescriptionForDeclinedProductSwitchApplication() {
        when(gmsStageAndTaskLoader.getStageDescription("85"))
                .thenReturn(new GMSStageDescription(null, DECLINE, DECLINE_DESC));
        when(gmsStageAndTaskLoader.getStatusDescription(PRODUCT_SWITCH_CANCELLED))
                .thenReturn(PRODUCT_SWITCH_CANCELLED_DESCRIPTION);
        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject("85", "SCK");
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, true);

        assertEquals(
                RED, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                PRODUCT_SWITCH_CANCELLED_DESCRIPTION,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        assertEquals(
                PRODUCT_SWITCH_STATUS,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatus());
        assertEquals(
                PRODUCT_SWITCH_STATUS_DESCRIPTION,
                applicationDetailsInfo.getApplicationDetails().getStatus().getStatusDescription());

        verify(gmsStageAndTaskLoader).getStageDescription("85");
        verify(gmsStageAndTaskLoader).getStatusDescription(PRODUCT_SWITCH_CANCELLED);
    }

    @Test
    void populateStatusDescriptionForNoStageProductSwitchApplication() {
        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject(null, "SCK");
        when(gmsStageAndTaskLoader.getStatusDescription(GREY)).thenReturn(GREY_DESC);
        applicationDetailsInfo.getApplicationDetails().setStageHistory(new ArrayList<>());
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, true);

        assertEquals(
                GREY, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREY_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(GREY);
        verify(gmsStageAndTaskLoader).getStageDescription(null);
    }

    @Test
    void populateStatusDescriptionForNoStageProductSwitchApplication1() {
        ApplicationDetailsInfo applicationDetailsInfo =
                getMockApplicationDetailsObject("36", "SCK");
        when(gmsStageAndTaskLoader.getStatusDescription(GREY)).thenReturn(GREY_DESC);
        detailsServiceImpl.populateApplicationRagStatus(applicationDetailsInfo, true);

        assertEquals(
                GREY, applicationDetailsInfo.getApplicationDetails().getStatus().getRagStatus());
        assertEquals(
                GREY_DESC,
                applicationDetailsInfo.getApplicationDetails().getStatus().getRagDescription());
        verify(gmsStageAndTaskLoader).getStatusDescription(GREY);
        verify(gmsStageAndTaskLoader).getStageDescription("36");
    }

    @Test
    void populateApplicationSubStatusDeclinedProductSwitch() {
        when(gmsStageAndTaskLoader.isAwaitTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_CANCELLED))
                .thenReturn(GLOBAL_SUB_STATUS_CANCELLED_DESCRIPTION);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("85", null);
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, true);

        assertEquals(
                SUB_STATUS_CANCELLED,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                GLOBAL_SUB_STATUS_CANCELLED_DESCRIPTION,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(null);
        verify(gmsStageAndTaskLoader).isAssessTask(null);
        verify(gmsStageAndTaskLoader)
                .getStatusDescription(GLOBAL_SUB_STATUS + SUB_STATUS_CANCELLED);
    }

    @Test
    void populateApplicationSubStatusCompletionProductSwitchTest() {

        when(gmsStageAndTaskLoader.isAwaitTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.isAssessTask(null)).thenReturn(false);
        when(gmsStageAndTaskLoader.getStatusDescription(COMPLETION)).thenReturn(COMPLETION_DESC);

        ApplicationDetailsInfo applicationDetailsInfo = getMockApplicationDetailsInfo("80", null);
        detailsServiceImpl.populateApplicationSubStatus(applicationDetailsInfo, true);

        assertEquals(
                COMPLETION,
                applicationDetailsInfo.getApplicationDetails().getStatus().getSubStatus());
        assertEquals(
                COMPLETION_DESC,
                applicationDetailsInfo
                        .getApplicationDetails()
                        .getStatus()
                        .getSubStatusDescription());

        verify(gmsStageAndTaskLoader).isAwaitTask(null);
        verify(gmsStageAndTaskLoader).isAssessTask(null);
        verify(gmsStageAndTaskLoader).getStatusDescription(COMPLETION);
    }
}
