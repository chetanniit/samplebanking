/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.mapper;

import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getGmsApplicationResponse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.GmsApplicationResponse;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GmsApplicationResponseMapperTest {

    @InjectMocks private GmsApplicationResponseMapperImpl mapper;

    @Test
    void testToApplicationsResponse() {
        ApplicationsResponse applicationsResponse =
                mapper.toApplicationsResponse(getGmsApplicationResponse());
        assertNotNull(applicationsResponse);
    }

    @Test
    void testToApplicationsResponseWithStageNo9() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.getApplications().get(0).setStageNumber(9);
        ApplicationsResponse applicationsResponse = mapper.toApplicationsResponse(response);
        assertNotNull(applicationsResponse);
    }

    @Test
    void testToApplicationsResponseNull() {
        ApplicationsResponse applicationsResponse = mapper.toApplicationsResponse(null);
        assertNull(applicationsResponse);
    }

    @Test
    void testToApplicationsResponseMortgageInformationNull() {
        ApplicationsResponse applicationsResponse =
                mapper.toApplicationsResponse(getResponseMortgageInformationNull());
        assertNotNull(applicationsResponse);
    }

    private GmsApplicationResponse getResponseMortgageInformationNull() {
        return GmsApplicationResponse.builder()
                .page(null)
                .applications(Collections.singletonList(null))
                .build();
    }
}
