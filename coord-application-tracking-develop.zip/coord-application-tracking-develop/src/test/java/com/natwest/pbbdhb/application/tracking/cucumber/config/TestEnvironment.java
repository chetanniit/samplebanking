/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.config;

public enum TestEnvironment {
    DEV(
            false,
            "https://dev-api.natwest.com/",
            "https://v1-coord-application-tracking-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net",
            "src/test/resources/testInput/dev"),

    SIT(
            true,
            "https://sit-api.natwest.com/",
            "https://v1-coord-application-tracking-sit.edi01-apps.dev-pcf.lb4.rbsgrp.net",
            "src/test/resources/testInput/dev"),

    UAT(
            true,
            "https://beta-uat-api.natwest.com/",
            "https://v1-coord-application-tracking-uat.edi01-apps.dev-pcf.lb4.rbsgrp.net",
            "src/test/resources/testInput/dev"),

    NFT(
            true,
            "https://nft-api.natwest.com/",
            "https://v1-coord-application-tracking-nft.edi01-apps.dev-pcf.lb4.rbsgrp.net",
            "src/test/resources/testInput/nft");

    private Boolean isAuthEnabled;
    private String apigeeUrl;
    private String pcfUrl;
    private String testInputPath;

    TestEnvironment(Boolean isAuthEnabled, String apigeeUrl, String pcfUrl, String testInputPath) {
        this.isAuthEnabled = isAuthEnabled;
        this.apigeeUrl = apigeeUrl;
        this.pcfUrl = pcfUrl;
        this.testInputPath = testInputPath;
    }

    public Boolean isAuthEnabled() {
        return isAuthEnabled;
    }

    public String getApigeeUrl() {
        return apigeeUrl;
    }

    public String getPcfUrl() {
        return pcfUrl;
    }

    public String getTestInputPath() {
        return testInputPath;
    }
}
