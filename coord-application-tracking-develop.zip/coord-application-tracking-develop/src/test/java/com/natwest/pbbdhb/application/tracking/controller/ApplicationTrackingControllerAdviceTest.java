/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.model.exception.ErrorResponse;
import com.natwest.pbbdhb.application.tracking.model.exception.GMSErrorResponse;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import java.util.Arrays;
import javax.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ApplicationTrackingControllerAdviceTest {

    @Mock private ObjectMapper objectMapper;

    @Mock private ErrorMessageConfigReader errorMessageConfigReader;

    private ApplicationTrackingControllerAdvice applicationTrackingControllerAdvice;

    @BeforeEach
    public void setUp() {
        applicationTrackingControllerAdvice =
                new ApplicationTrackingControllerAdvice(objectMapper, errorMessageConfigReader);
    }

    @Test
    void TestHandleMethodArgumentNotValidException() {

        MethodArgumentNotValidException methodArgumentNotValidException =
                mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        when(bindingResult.getFieldErrors())
                .thenReturn(
                        Arrays.asList(
                                new FieldError(
                                        "applicationDetailsRequest",
                                        "emailId",
                                        "please enter valid email id")));
        when(methodArgumentNotValidException.getBindingResult()).thenReturn(bindingResult);

        ResponseEntity<Object> response =
                applicationTrackingControllerAdvice.handleMethodArgumentNotValid(
                        methodArgumentNotValidException,
                        mock(HttpHeaders.class),
                        HttpStatus.BAD_REQUEST,
                        mock(WebRequest.class));

        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void TestHandleGMSStageNotFoundException() {

        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleGMSStageNotFoundException(
                        mock(BrokerValidationException.class), mock(WebRequest.class));

        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorException400() throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        when(exception.getRawStatusCode()).thenReturn(400);
        when(exception.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        when(exception.getResponseBodyAsString()).thenReturn("exception");
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.BAD_REQUEST)
                                .errorCode("RECTNTFND")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, mock(WebRequest.class));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorException500() throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        when(exception.getRawStatusCode()).thenReturn(400);
        when(exception.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        when(exception.getResponseBodyAsString()).thenReturn(null);
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.BAD_REQUEST)
                                .errorCode("RECTNTFND")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, mock(WebRequest.class));
        assertEquals(500, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorException1() throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        when(exception.getRawStatusCode()).thenReturn(404);
        when(exception.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);
        when(exception.getResponseBodyAsString()).thenReturn(null);
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.NOT_FOUND)
                                .errorCode("RECTNTFND")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, mock(WebRequest.class));
        assertEquals(500, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorExceptionFromApplicationDetails() throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        ServletWebRequest servletWebRequest = mock(ServletWebRequest.class);
        when(httpServletRequest.getRequestURI())
                .thenReturn("/mortgages/v1/application-tracking/applicationDetails/10101");
        when(exception.getRawStatusCode()).thenReturn(404);
        when(exception.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);
        when(exception.getResponseBodyAsString()).thenReturn("exception");
        when(servletWebRequest.getRequest()).thenReturn(httpServletRequest);
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.NOT_FOUND)
                                .errorCode("RECTNTFND")
                                .origin("applicationDetails")
                                .errorMessage("Reference number not found")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, servletWebRequest);
        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorExceptionFromApplications() throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        when(exception.getRawStatusCode()).thenReturn(404);
        when(exception.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);
        when(exception.getResponseBodyAsString()).thenReturn("exception");
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.NOT_FOUND)
                                .errorCode("RECTNTFND")
                                .origin("applications")
                                .errorMessage("Application not found")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, mock(ServletWebRequest.class));
        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorExceptionToCoverDefaultSwitchCase()
            throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        when(exception.getRawStatusCode()).thenReturn(404);
        when(exception.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);
        when(exception.getResponseBodyAsString()).thenReturn("exception");
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.NOT_FOUND)
                                .errorCode("RECTNTFND")
                                .origin("dummy")
                                .errorMessage("case tracking data not found")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, mock(ServletWebRequest.class));
        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleAllUncaughtException() {
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleAllUncaughtException(
                        new Exception("Failed"));
        assertEquals(500, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorExceptionNotFound3() throws JsonProcessingException {
        HttpClientErrorException exception = mock(HttpClientErrorException.BadRequest.class);
        when(exception.getRawStatusCode()).thenReturn(404);
        when(exception.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);
        when(exception.getResponseBodyAsString()).thenReturn("exception");
        when(objectMapper.readValue("exception", GMSErrorResponse.class))
                .thenReturn(
                        GMSErrorResponse.builder()
                                .responseStatus(HttpStatus.NOT_FOUND)
                                .errorCode("RECTNTFND")
                                .build());
        ResponseEntity<ErrorResponse> response =
                applicationTrackingControllerAdvice.handleHttpClientErrorException(
                        exception, mock(WebRequest.class));
        assertEquals(500, response.getStatusCodeValue());
    }
}
