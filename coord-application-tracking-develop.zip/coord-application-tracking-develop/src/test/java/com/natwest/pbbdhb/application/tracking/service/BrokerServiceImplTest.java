/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import static com.natwest.pbbdhb.application.tracking.util.TestConstants.ASSESSMENT_VALUATION;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DECLINE;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.DECLINE_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.OFFER_DESC;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getApplicationRequest;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getApplicationRequestForGetApplicationsAPI;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getGmsApplicationResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.application.tracking.mapper.GmsApplicationResponseMapper;
import com.natwest.pbbdhb.application.tracking.mapper.GmsApplicationResponseMapperImpl;
import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.CurrentOpenTasksNumber;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.GmsApplicationResponse;
import com.natwest.pbbdhb.application.tracking.service.impl.BrokerServiceImpl;
import java.util.HashSet;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class BrokerServiceImplTest {

    private static final String NWB_BRAND = "NWB";

    @InjectMocks private BrokerServiceImpl service;

    @Mock private RestTemplate restTemplate;

    @Spy private final GmsApplicationResponseMapper mapper = new GmsApplicationResponseMapperImpl();

    @Mock private GmsStageAndTaskLoader gmsStageLoader;

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate, gmsStageLoader);
    }

    public static final String BASE_URL =
            "https://v1-msvc-applications-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/";
    public static final String BROKER_APPLICATION_ENDPOINT = "applications";
    public static final String BROKER_APPLICATION_SEARCH_ENDPOINT = "brokerApplicationsSearch";

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(service, "msvcApplicationEndpoint", BASE_URL);
        ReflectionTestUtils.setField(
                service, "brokerApplicationsEndpoint", BROKER_APPLICATION_ENDPOINT);
        ReflectionTestUtils.setField(
                service, "brokerApplicationSearchEndpoint", BROKER_APPLICATION_SEARCH_ENDPOINT);
    }

    @Test
    void testGetApplicationsToInvokeBrokerApplicationSearch() {
        GmsApplicationResponse gmsApplicationResponse = getGmsApplicationResponse();

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(gmsApplicationResponse, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequest();
        service.getApplications(NWB_BRAND, applicationRequest);
        verify(mapper).toApplicationsResponse(gmsApplicationResponse);
        verify(restTemplate)
                .exchange(
                        any(), any(HttpMethod.class), any(), ArgumentMatchers.<Class<String>>any());
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsWithStageDescriptionNull() {
        GmsApplicationResponse gmsApplicationResponse = getGmsApplicationResponse();

        when(gmsStageLoader.getStageDescription(anyString())).thenReturn(null);

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(gmsApplicationResponse, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequest();

        service.getApplications(NWB_BRAND, applicationRequest);

        verify(mapper).toApplicationsResponse(gmsApplicationResponse);
        verify(restTemplate)
                .exchange(
                        any(), any(HttpMethod.class), any(), ArgumentMatchers.<Class<String>>any());
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsToInvokeApplications() {
        GmsApplicationResponse gmsApplicationResponse = getGmsApplicationResponse();

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(gmsApplicationResponse, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        service.getApplications(NWB_BRAND, applicationRequest);

        verify(mapper).toApplicationsResponse(gmsApplicationResponse);
        verify(restTemplate)
                .exchange(
                        any(), any(HttpMethod.class), any(), ArgumentMatchers.<Class<String>>any());
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsToInvokeApplicationsWithRedRagStatus() {
        GmsApplicationResponse gmsApplicationResponse = getGmsApplicationResponse();
        gmsApplicationResponse.getApplications().get(0).setStageNumber(90);

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(gmsApplicationResponse, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        service.getApplications(NWB_BRAND, applicationRequest);
        verify(mapper).toApplicationsResponse(gmsApplicationResponse);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsToInvokeApplicationsWithAmberRagStatus() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.getApplications().get(0).setStageNumber(40);

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());
        when(gmsStageLoader.isAwaitTask("AIP")).thenReturn(true);

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        service.getApplications(NWB_BRAND, applicationRequest);

        verify(mapper).toApplicationsResponse(response);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsToInvokeApplicationsWithAmberRagStatusWithAssessTask() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.getApplications().get(0).setStageNumber(40);

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());
        when(gmsStageLoader.isAssessTask("AIP")).thenReturn(true);

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        service.getApplications(NWB_BRAND, applicationRequest);

        verify(mapper).toApplicationsResponse(response);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsToInvokeApplicationsWithStatusAssessmentAndValuation() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.getApplications().get(0).setStageNumber(25);
        response.getApplications().get(0).getOpenTasks().add(new CurrentOpenTasksNumber("AVR"));

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());

        when(gmsStageLoader.getStatusDescription(anyString())).thenReturn(ASSESSMENT_VALUATION);

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        ApplicationsResponse applicationsResponse =
                service.getApplications(NWB_BRAND, applicationRequest);
        assertEquals(
                OFFER_DESC, applicationsResponse.getApplications().get(0).getStatus().getStatus());

        verify(mapper).toApplicationsResponse(response);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsToInvokeApplicationsWithEmptyTasks() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.getApplications().get(0).setStageNumber(40);
        response.getApplications().get(0).setOpenTasks(new HashSet<>());

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        service.getApplications(NWB_BRAND, applicationRequest);

        verify(mapper).toApplicationsResponse(response);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
        verify(gmsStageLoader).getStageDescription(anyString());
    }

    @Test
    void testGetApplicationsWithNoApplications() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.setApplications(null);

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Offer")
                                .status("Your application is under Offer")
                                .build());

        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        service.getApplications(NWB_BRAND, applicationRequest);

        verify(mapper).toApplicationsResponse(response);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
    }

    @Test
    void testGetApplicationsToInvokeApplicationsWithStatusDecline() {
        GmsApplicationResponse response = getGmsApplicationResponse();
        response.getApplications().get(0).setStageNumber(85);

        when(gmsStageLoader.getStageDescription(anyString()))
                .thenReturn(
                        GMSStageDescription.builder()
                                .statusDetail("Your application is Declined")
                                .status(DECLINE)
                                .build());
        when(gmsStageLoader.getStatusDescription(anyString())).thenReturn(DECLINE);
        when(restTemplate.exchange(
                        any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        ApplicationRequest applicationRequest = getApplicationRequestForGetApplicationsAPI();
        ApplicationsResponse applicationsResponse =
                service.getApplications(NWB_BRAND, applicationRequest);
        assertEquals(
                DECLINE, applicationsResponse.getApplications().get(0).getStatus().getStatus());
        assertEquals(
                DECLINE_DESC,
                applicationsResponse.getApplications().get(0).getStatus().getStatusDescription());

        verify(mapper).toApplicationsResponse(response);
        verify(restTemplate)
                .exchange(any(), eq(HttpMethod.GET), any(), eq(GmsApplicationResponse.class));
        verify(gmsStageLoader).getStageDescription(anyString());
        verify(gmsStageLoader).getStageDescription("85");
    }
}
