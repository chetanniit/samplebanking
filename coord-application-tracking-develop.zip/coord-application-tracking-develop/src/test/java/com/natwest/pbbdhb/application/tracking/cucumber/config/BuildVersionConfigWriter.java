/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.config;

import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.CONTENT_TYPE;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.ex.ConfigurationException;

@Slf4j
public class BuildVersionConfigWriter {

    public static String version = null;
    public static String applicationName = null;
    public static String environment = null;

    static {
        log.info("static block in BuildVersionConfigWriter class loading now");
        RestAssured.baseURI = CucumberTestProperties.getTestEnv().getPcfUrl();
        RequestSpecification request =
                RestAssured.given()
                        .log()
                        .all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .accept(ContentType.JSON);

        Response response = request.get(ApiTestConstants.ACTUATOR_INFO);
        try {
            JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
            JsonNode buildInformation = responseJsonNode.get(ApiTestConstants.BUILD);
            version = buildInformation.get(ApiTestConstants.VERSION).asText();
            applicationName = buildInformation.get(ApiTestConstants.NAME).asText();
            getEnvironment();
            updateProperties();
        } catch (IOException e) {
            log.error("error occurred while parsing the response to construct build details", e);
        }
    }

    private static void getEnvironment() {
        environment = CucumberTestProperties.getTestEnv().name();
    }

    public static FileBasedConfiguration updateProperties() {
        FileBasedConfiguration configuration = null;
        Parameters params = new Parameters();
        FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
                new FileBasedConfigurationBuilder<FileBasedConfiguration>(
                                PropertiesConfiguration.class)
                        .configure(
                                params.fileBased()
                                        // .setThrowExceptionOnMissing(true)
                                        .setEncoding("UTF-8")
                                        .setFileName(
                                                ApiTestConstants
                                                        .CUCUMBER_BUILD_CONFIG_PROPERTIES_FILENAME));
        try {
            builder.setAutoSave(true);
            configuration = builder.getConfiguration();
            configuration.setProperty("application name", applicationName);
            configuration.setProperty("version", version);
            configuration.setProperty("environment", environment);
            configuration.setProperty(
                    "testInputPath", CucumberTestProperties.getTestEnv().getTestInputPath());
            configuration.setProperty("baseURI", CucumberTestProperties.getBaseURI());
            configuration.setProperty("Content-Type", CucumberTestProperties.getContentHeader());

            log.info("version:{}", configuration.getString("version"));

        } catch (ConfigurationException e) {
            log.error("cucumber build config file not found", e);
        }
        return configuration;
    }
}
