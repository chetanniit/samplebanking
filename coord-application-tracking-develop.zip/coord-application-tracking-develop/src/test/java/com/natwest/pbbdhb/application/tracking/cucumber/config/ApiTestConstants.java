/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.config;

public interface ApiTestConstants {

    String CUCUMBER_CONFIG_PROPERTIES_FILENAME = "src/test/resources/config/config.properties";

    String GET_APPLICATIONS_INPUT_JSON = "/GetApplications.json";
    String GET_APPLICATION_LIST_INPUT_JSON = "/GetApplicationList.json";
    String GET_APPLICATION_DETAILS_INPUT_JSON = "/GetApplicationDetails.json";

    String CUCUMBER_BUILD_CONFIG_PROPERTIES_FILENAME =
            "src/test/resources/config/buildConfig.properties";
    String ACTUATOR_INFO = "/mortgages/v1/application-tracking/actuator/info";
    String BUILD = "build";
    String VERSION = "version";
    String NAME = "name";
    String LOCALHOST = "localhost";
    String NFT = "NFT";
    String UAT = "UAT";
    String SIT = "SIT";
    String DEV = "DEV";
    String NFT_INDICATOR = "-nft";
    String UAT_INDICATOR = "-uat";
    String SIT_INDICATOR = "-sit";
    String DEV_INDICATOR = "-dev";

    interface Params {
        String CONTENT_TYPE = "Content-Type";
        String BRAND_NWB = "NWB";

        String PATH = "path";
        String RESPONSE_CODE = "responseCode";
        String ERROR_CODE = "errorCode";
        String BRAND = "brand";
        String APPLICANT_DOB = "applicantDob";
        String APPLICANT_FIRST_NAME = "applicantFirstName";
        String APPLICANT_LAST_NAME = "applicantLastName";
        String BROKER_EMAIL_ID = "brokerEmailId";
        String FCA_NUMBER = "fcaNumber";
        String BROKER_FIRST_NAME = "brokerFirstName";
        String BROKER_USER_NAME = "brokerUserName";
        String BROKER_LAST_NAME = "brokerLastName";
        String BROKER_POST_CODE = "brokerPostcode";
        String PAGE_NUMBER = "pageNumber";
        String RESULT_PER_PAGE = "resultPerPage";
        String SORT_BY = "sortBy";
        String PROPERTY_POSTCODE = "propertyPostcode";
        String DATE_RANGE = "dateRange";
        String FIRM_POSTCODE = "firmPostcode";
        String SORT_ORDER = "sortOrder";
        String PAGE = "page";
        String SIZE = "size";
        String TOTAL_ELEMENTS = "totalElements";
        String TOTAL_PAGES = "totalPages";
        String NUMBERS = "number";
        String APPLICATIONS = "applications";
        String APPLICANT_INFORMATION = "applicantInformation";
        String PROPERTY_INFORMATION = "propertyInformation";
        String ADDRESS = "address";
        String FIRST_NAME = "firstName";
        String LAST_NAME = "lastName";
        String DOB = "dob";
        String POSTCODE = "postCode";
        String RESPONSE_STATUS = "responseStatus";
        String BAD_REQUEST = "BAD_REQUEST";
        String FORBIDDEN = "FORBIDDEN";
        String UNAUTHORIZED = "UNAUTHORIZED";
        String ERROR_MESSAGE = "errorMessages";
        String REFERENCE_NUMBER = "referenceNumber";
        String STATUS = "status";
        String RAG_STATUS = "ragStatus";
        String RAG_DESC = "ragDescription";
        String SUB_STATUS = "subStatus";
        String SUB_DESC = "subStatusDescription";
        String LAST_UPDATED_DATE = "lastUpdatedDate";
        String SUBMISSION_DATE = "submissionDate";
        String LINK = "_links";
        String SELF = "self";
        String HREF = "href";
        String STAGE_HISTORY = "stageHistory";
        String CASE_HISTORY = "caseHistory";
        String REQUIRED_ACTION = "requiredActions";
        String APPLICATION_DETAILS = "applicationDetails";
        String DESCRIPTION = "description";
        String STATUS_DESCRIPTION = "statusDescription";
        String ASSESSMENT = "Assessment";
        String VALUATION = "Valuation";
        String PRE_ASSESSMENT = "Pre-Assessment";
        String COMPLETION = "Completion";
        String OFFER = "Offer";
        String TIME_CLOSED = "timeClosed";
        String TIME_OPEN = "timeOpen";
        String RED_DESC = "Your client's application has been declined / cancelled";
        String RED_STATUS_DESC = "Your application is Declined / Cancelled";
        String PRODUCT_INFORMATION = "productInformation";
        String MORTGAGE_TYPE = "mortgageType";
        String FEE_STATUS = "feeStatus";
        String MILESTONE_DECLINE = "Decline/Cancelled";
        String MILESTONE_PRE_ASSESSMENT = "Pre-Assessment";
        String MILESTONE_ASSESSMENT = "Assessment";
        String MILESTONE_COMPLETION = "Completion";
        String PRODUCTS = "products";

        String UNAVAILABLE_FOR_LEGAL_REASON = "UNAVAILABLE FOR LEGAL REASON";
        String NOT_FOUND = "NOT_FOUND";

        String REPAYMENT_AMOUNT = "repaymentAmount";
        String TOTAL_REPAYMENT_AMOUNT = "totalRepaymentAmount";
        String TERM_YEARS = "termYears";
        String TERM_MONTHS = "termMonths";
        String LOAN_AMOUNT = "loanAmount";
        String TOTAL_LOAN_AMOUNT = "totalLoanAmount";

        String UNAVAILABLE_FOR_LEGAL_REASONS = "UNAVAILABLE_FOR_LEGAL_REASONS";
        String COMPLETED_APPLICATION_SUPPRESS_MESSAGE = "Application has been completed";
        String SOFT_DECLINED_APPLICATION_SUPPRESS_MESSAGE =
                "We are sorry but on this occasion we are unable to offer your client a mortgage. If you require further information or wish to appeal this decision please email intermediarydocs@natwest.com including the mortgage reference number";

        String EXPECTED_COMPLETION_DATE = "expectedCompletionDate";
        String COMPLETION_DATE = "completionDate";
        String DECLINED_DATE = "declinedDate";
        String REFUSED_DATE = "refusedDate";
        String IS_SKIP_BRAND = "isSkipBrand";

        String TENURE = "tenure";
        String LEASE_TERM_REMAINING = "leaseTermRemaining";
        String BED_ROOM_COUNT = "bedroomCount";
        String EPC_RATING = "EPCrating";
        String VALUATION_INFORMATION = "valuationInformation";

        String INTEREST_ONLY = "interestOnly";
        String CAPITAL_AND_INTEREST = "capitalAndInterest";
        String REPAYMENT_TYPE = "repaymentType";
        String SOLICITOR_INFORMATION = "solicitorInformation";
        String REQUIRED_ACTIONS = "requiredActions";
        String DESC = "description";
        
        String APPLICANTS = "applicants";
        String SOURCE_INFO = "sourceInfo";

        String RET_DESC =
                "Funds have been returned from your client's solicitor due to your completion being delayed. We are awaiting a new completion date from your client's solicitor.";
        String CATEGORY = "category";
        String OFFER_ISSUE_DATE = "offerIssueDate";
        String COT_ACCEPTED_DATE = "cotAcceptedDate";
        String COT_RECEIVED_DATE = "cotReceivedDate";
        String COT_ASSESSED_DATE = "cotAssessDate";
        String PRODUCT_SWITCH_STATUS = "Product Switch";
        String PRODUCT_SWITCH_STATUS_DESC = "Your application is at Product Switch";
        String PRODUCT_SWITCH_STAGE_40_DESCRIPTION =
                "We are pleased to let you know we have emailed your client('s) with instructions on how to digitally accept their product switch.";
        String PRODUCT_SWITCH_STAGE_67_DESCRIPTION =
                "Your client's product switch has been successful and there is nothing else for you to do. We will write to your client within 3 days of their new rate starting to confirm their new mortgage payment.";
        String PRODUCT_SWITCH_RAG_STATUS = "GREEN";
        String PRODUCT_SWITCH_RAG_DESC = "Product Switch is completed";
        String PRODUCT_SWITCH_CANCEL_DESC = "Your client's product switch has been cancelled.";
        String SOFT_DECLINE_ASSESSMENT_DESC =
                "We are pleased to confirm that we have received the information you sent us. We are currently reviewing your application and will contact you if we need any further information";
        String VALUATION_HISTORY_DESC =
                "We have received the mortgage valuation report. We will contact you if we need any further information.";
        String USER_EMAIL_ID = "userEmailId";
        String USER_FIRM_FCA_NUMBER = "userFirmFCANumber";
        String USER_FIRST_NAME = "userFirstName";
        String USER_LAST_NAME = "userLastName";
        String USER_PRINCIPLE_FCA_NUMBER = "userPrincipalFCANumber";
        String USER_ROLE = "userRole";
        String MIDDLE_NAME = "middleName";
        String IAM_CLAIMSETJWT = "iam-claimsetjwt";
        String FEE_PENDING = "feePending";
    }

    interface Errors {
        String INPUTS_MISSING_FOR_SCENARIO = "inputs missing for scenario";
        String TEST_INPUT_PATH_IS_NULL = "testInputPath is null";
        String INPUTS_MISSING_FOR = "inputs missing for %s";
        String APPLICANT_LAST_UPDATED_DATE_NOT_MATCHED =
                "applicant with lastUpdateDate is not matched";
        String APPLICANT_SUBMISSION_DATE_NOT_MATCHED =
                "applicant with submissionDate is not matched";
        String MISSING_SELF_LINK = "self link is not found";
        String APPLICANT_COUNT_LESS_THAN_2 = "applicant count is less than 2";
        String RAG_NEED_MORE_INFORMATION = "Completion needs more information";
        String STATUS_APPLICATION_ASSESSMENT = "Your application is at Assessment";
        String STATUS_APPLICATION_VALUATION = "Your application is at Valuation";
        String STATUS_APPLICATION_OFFER = "Your application is at Offer";
        String STATUS_APPLICATION_COMPLETION = "Your application is at Completion";
        String TENURE_NOT_MATCHED = "tenure not matched";
        String LEASE_TERM_REMAINING_NOT_MATCHED = "Lease Term Remaining not matched";
        String BED_ROOM_COUNT_NOT_MATCHED = "Bed room count not matched";
        String EPC_RATING_NOT_MATCHED = "EPC rating count not matched";
        String MISSING_SOLICITOR_FIRM_NAME = "missing solicitor firm name";
        String STATUS_INFORMATION_MISSING = "Status Information missing";
        String APPLICATIONS_ARE_NOT_UNIQUE = "applications are not unique";
        String NOT_A_JOINT_APPLICATION = "Not a joint application";
        String MISSING_APPLICANTS = "applicants not found";
        String APPLICANT_INFORMATION_IS_MISSING = "Applicant Information is missing";
        String APPLICANT_LAST_NAME_NOT_MATCHED = "applicant with lastName is not matched";
        String APPLICANT_FIRST_NAME_NOT_MATCHED = "applicant with firstName is not matched";
    }
}
