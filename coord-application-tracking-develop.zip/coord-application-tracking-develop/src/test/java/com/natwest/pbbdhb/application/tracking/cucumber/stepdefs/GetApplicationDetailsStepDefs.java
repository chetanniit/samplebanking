package com.natwest.pbbdhb.application.tracking.cucumber.stepdefs;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.application.tracking.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.application.tracking.jwt.AccessTokenGenerator;
import com.natwest.pbbdhb.application.tracking.jwt.AuthCredentialHolder;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.StreamSupport;

import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Errors;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Errors.MISSING_SOLICITOR_FIRM_NAME;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Errors.STATUS_INFORMATION_MISSING;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.GET_APPLICATION_DETAILS_INPUT_JSON;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.COMPLETION;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.OFFER;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.PRODUCT_SWITCH_STATUS;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.RED_DESC;
import static com.natwest.pbbdhb.application.tracking.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j
public class GetApplicationDetailsStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(GET_APPLICATION_DETAILS_INPUT_JSON);
    }

    private JsonNode validateAndGetApplications() {
        int totalCount = responseJsonNode.get(PAGE).get(TOTAL_ELEMENTS).asInt(0);
        Assertions.assertTrue(totalCount > 0);
        JsonNode applications = responseJsonNode.path(APPLICATIONS);
        Assertions.assertTrue(applications.size() > 0);
        Assertions.assertTrue(applications.isArray());
        return applications;
    }

    private void validateErrorUnavailableLegalReason(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(UNAVAILABLE_FOR_LEGAL_REASONS, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    @Given("Get Applications Details Service endpoint exists")
    public void getApplicationsDetailsServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request using input {string} and verify response code")
    public void userSendsRequestUsingInputAndVerifyResponseCode(String inputName) throws IOException {
        // Commented the Code as its used for apigee implementation
        //        RequestSpecification request = RestAssured.given()
//                .log().all()
//                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
//                .accept(ContentType.JSON);
//        JsonNode testInput = inputsAsJsonNode.get(inputName);
//        Assertions.assertNotNull(testInput, Errors.INPUTS_MISSING_FOR_SCENARIO);
//        ApiTestUtil.createRequestForInputParams(testInput, request);
//        Response response;
//        if (CucumberTestProperties.getTestEnv().isAuthEnabled()) {
//            AuthCredentialHolder authCredentialHolder = AccessTokenGenerator.getTokenHolder();
//            Assertions.assertNotNull(authCredentialHolder.getBearerToken(), "bearerToken should not be null");
//            ApiTestUtil.prepareRequestWithBearerToken(request, authCredentialHolder);
//            response = request.get(inputsAsJsonNode.get(PATH).asText(), authCredentialHolder.getBearerToken());
//        } else {
//            response = request.get(inputsAsJsonNode.get(PATH).asText());
//        }
//        log.info(response.getHeaders().asList().toString());
//        log.info(response.getBody().prettyPrint());
//        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
//        Assertions.assertNotNull(response, "response is null");
//        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        //ApiTestUtil.convertJsonNodeToCSVFormat(testInput);
        RequestSpecification request =
                RestAssured.given()
                        .log()
                        .all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCoordAppTracking())
                        .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request);
        Response response = request.get(inputsAsJsonNode.get(PATH).asText());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @Then("Verify the valid application details returned for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedForTheInput(String inputName) {
        JsonNode applications = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(applications.get(REFERENCE_NUMBER), responseJsonNode.get(REFERENCE_NUMBER));

        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        Assertions.assertNotNull(stageHistoryDescription, STAGE_HISTORY_CODE_NULL);

        JsonNode caseHistoryArray = stageHistory.get(CASE_HISTORY);
        Assertions.assertTrue(caseHistoryArray.isArray());

        JsonNode statusJsonNode = responseJsonNode.get(STATUS);
        String status = statusJsonNode.get(STATUS).asText();
        Assertions.assertNotNull(status, STATUS_NULL);
    }

    @Then("Verify the valid application details returned ragStatus RED for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusRED(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals("Declined/Cancelled", stageHistoryDescription);
        Assertions.assertEquals(RED, ragStatus);
        Assertions.assertEquals(RED_DESC, ragStatusDescription);
    }

    @Then("Verify the valid application details returned ragStatus AMBER for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusAMBER(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals(AMBER, ragStatus);
        Assertions.assertEquals(MILESTONE_ASSESSMENT + "" + AMBER_DESC, ragStatusDescription);
    }

    @Then("Verify the valid application details returned ragStatus GREEN for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGREEN(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals(MILESTONE_PRE_ASSESSMENT, stageHistoryDescription);
        Assertions.assertEquals(GREEN, ragStatus);
        Assertions.assertEquals(MILESTONE_PRE_ASSESSMENT + "" + GREEN_DESC, ragStatusDescription);
    }

    @Then("Verify the valid application details returned ragStatus GREY for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGREY(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals(GREY, ragStatus);
        Assertions.assertEquals(MILESTONE_COMPLETION + "" + GREY_DESC, ragStatusDescription);
    }

    @Then("Verify the valid application details returned subStatus NoAction for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedSubStatusNoAction(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String subStatus = stageHistory.get(SUB_STATUS).asText();
        String subStatusDescription = stageHistory.get(SUB_DESC).asText();

        Assertions.assertEquals(NO_ACTION_REQUIRED, subStatus);
        Assertions.assertEquals(NO_ACTION_REQUIRED_DESC, subStatusDescription);
    }

    @Then("Verify the valid application details returned subStatus Attention for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedSubStatusAttention(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        String subStatus = stageHistory.get(SUB_STATUS).asText();
        String subStatusDescription = stageHistory.get(SUB_DESC).asText();

        Assertions.assertEquals(ACTION_REQUIRED, subStatus);
        Assertions.assertEquals(ACTION_REQUIRED_DESC, subStatusDescription);
    }

    @Then("Verify the valid application details returned ragStatus Green when Pre-Assessment milestone is not open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreenWhenPreAssessmentMilestoneIsNotOpenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Green when Pre-Assessment milestone is close for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreenWhenPreAssessmentMilestoneIsCloseForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Amber when Assessment milestone is open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusAmberWhenAssessmentMilestoneIsOpenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Green when Assessment milestone is close for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreenWhenAssessmentMilestoneIsCloseForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Amber when Valuation milestone is open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusAmberWhenValuationMilestoneIsOpenForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Green when Valuation milestone is close for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreenWhenValuationMilestoneIsCloseForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Grey when Offer milestone is not open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreyWhenOfferMilestoneIsNotOpenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Amber when Offer milestone is open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusAmberWhenOfferMilestoneIsOpenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Green when Offer milestone is close for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreenWhenOfferMilestoneIsCloseForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Grey when Completion milestone is not open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusGreyWhenCompletionMilestoneIsNotOpenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Amber when Completion milestone is open for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusAmberWhenCompletionMilestoneIsOpenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus Red when Completion milestone stage number is greater than eighty for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusRedWhenCompletionMilestoneStageNumberIsGreaterThanEightyForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(RED, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify the valid application details returned ragStatus description when ragStatus as Amber for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusDescriptionWhenRagStatusAsAmberForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
        Assertions.assertEquals(MILESTONE_ASSESSMENT + "" + AMBER_DESC, stageHistory.get(RAG_DESC).asText());
    }

    @Then("Verify the valid application details returned ragStatus description when ragStatus as Green for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusDescriptionWhenRagStatusAsGreenForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
        Assertions.assertEquals(MILESTONE_PRE_ASSESSMENT + "" + GREEN_DESC, stageHistory.get(RAG_DESC).asText());
    }

    @Then("Verify the valid application details returned ragStatus description when ragStatus as Grey for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusDescriptionWhenRagStatusAsGreyForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
        Assertions.assertEquals(MILESTONE_COMPLETION + "" + GREY_DESC, stageHistory.get(RAG_DESC).asText());
    }

    @Then("Verify the valid application details returned ragStatus description when ragStatus as Red for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedRagStatusDescriptionWhenRagStatusAsRedForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(RED, stageHistory.get(RAG_STATUS).asText());
        Assertions.assertEquals(RED_DESC, stageHistory.get(RAG_DESC).asText());
    }

    @Then("Verify the valid application details returned subStatus as Attention when Open task greater than zero for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedSubStatusAsAttentionWhenOpenTaskGreaterThanZeroForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(ACTION_REQUIRED, stageHistory.get(SUB_STATUS).asText());
    }

    @Then("Verify the valid application details returned subStatus as No action when Open task is equal to zero for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedSubStatusAsNoActionWhenOpenTaskIsEqualToZeroForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals("null", stageHistory.get(SUB_STATUS).asText());
    }

    @Then("Verify the valid application details returned subStatus description as Attention is required when subStatus is Attention for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedSubStatusDescriptionAsAttentionIsRequiredWhenSubStatusIsAttentionForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(ACTION_REQUIRED_DESC, stageHistory.get(SUB_DESC).asText());
    }

    @Then("Verify the valid application details returned subStatus description as No action is required when subStatus is No action for the input {string}")
    public void verifyTheValidApplicationDetailsReturnedSubStatusDescriptionAsNoActionIsRequiredWhenSubStatusIsNoActionForTheInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals("null", stageHistory.get(SUB_DESC).asText());
    }

    @Then("Verify the milestone open date with oldest stage open time less than oldest task open time {string}")
    public void verifyTheMilestoneOpenDateWithOldestStageOpenTimeLessThanOldestTaskOpenTime(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-21T13:01+00:00", stage.get(TIME_OPEN).asText());
            }
        });
    }

    @Then("Verify the milestone open date with oldest stage open time greater than oldest task open time {string}")
    public void verifyTheMilestoneOpenDateWithOldestStageOpenTimeGreaterThanOldestTaskOpenTime(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-21T13:12+00:00", stage.get(TIME_OPEN).asText());
            }
        });
    }

    @Then("Verify the milestone open date with oldest stage open time and No task present {string}")
    public void verifyTheMilestoneOpenDateWithOldestStageOpenTimeAndNoTaskPresent(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (PRE_ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-21T09:06+00:00", stage.get(TIME_OPEN).asText());
                JsonNode caseHistory = stage.get(CASE_HISTORY);
                Assertions.assertNull(caseHistory.get(0));
            }
        });
    }

    @Then("Verify the milestone open date with No stage present and No task present {string}")
    public void verifyTheMilestoneOpenDateWithNoStagePresentAndNoTaskPresent(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_OPEN).isNull());
                JsonNode caseHistory = stage.get(CASE_HISTORY);
                Assertions.assertNull(caseHistory.get(0));
            }
        });
    }

    @Then("Verify the milestone closed date with latest stage close time less than latest task close time {string}")
    public void verifyTheMilestoneClosedDateWithLatestStageCloseTimeLessThanLatestTaskCloseTime(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-06-02T11:28+00:00", stage.get(TIME_CLOSED).asText());
            }
        });
    }

    @Then("Verify the milestone closed date with latest stage close time greater than latest task close time {string}")
    public void verifyTheMilestoneClosedDateWithLatestStageCloseTimeGreaterThanLatestTaskCloseTime(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-05-12T14:37+00:00", stage.get(TIME_CLOSED).asText());
            }
        });
    }

    @Then("Verify the milestone closed date with latest stage close time and No tasks present {string}")
    public void verifyTheMilestoneClosedDateWithLatestStageCloseTimeAndNoTasksPresent(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (PRE_ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-21T13:01+00:00", stage.get(TIME_CLOSED).asText());
                JsonNode caseHistory = stage.get(CASE_HISTORY);
                Assertions.assertNull(caseHistory.get(0));
            }
        });
    }

    @Then("Verify the milestone closed date with No stages present and No tasks present {string}")
    public void verifyTheMilestoneClosedDateWithNoStagesPresentAndNoTasksPresent(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_CLOSED).isNull());
                JsonNode caseHistory = stage.get(CASE_HISTORY);
                Assertions.assertNull(caseHistory.get(0));
            }
        });
    }

    @Then("Verify the milestone closed date with latest stage is not closed and latest task is not closed {string}")
    public void verifyTheMilestoneClosedDateWithLatestStageIsNotClosedAndLatestTaskIsNotClosed(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (OFFER.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_CLOSED).isNull());
            }
        });
    }

    @Then("Verify the duplicate tasks under each milestone {string}")
    public void verifyTheDuplicateTasksUnderEachMilestone(String inputName) {
        AtomicReference<Integer> noOfOccurrence = new AtomicReference<>(0);
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            String caseDesc = "We are current waiting on the certificate of title from your client's solicitor. We will contact you once we receive the document";
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (OFFER.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_CLOSED).isNull());

                StreamSupport.stream(stage.get(CASE_HISTORY).spliterator(), false).forEach(caseHistory -> {
                    if (caseDesc.equalsIgnoreCase(caseHistory.get(DESCRIPTION).textValue())) {
                        noOfOccurrence.getAndSet(noOfOccurrence.get() + 1);
                    }
                });
                Assertions.assertTrue(noOfOccurrence.get() > 1);
            }
        });
    }

    @Then("Verify the milestone closed date with latest stage is not closed and latest task is closed {string}")
    public void verifyTheMilestoneClosedDateWithLatestStageIsNotClosedAndLatestTaskIsClosed(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_CLOSED).isNull());
            }
        });
    }

    @Then("Verify the milestone closed date with latest stage is closed and latest task is not closed {string}")
    public void verifyTheMilestoneClosedDateWithLatestStageIsClosedAndLatestTaskIsNotClosed(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_CLOSED).isNull());
            }
        });
    }

    @Then("Verify the milestone open date with No stage present and oldest task open time {string}")
    public void verifyTheMilestoneOpenDateWithNoStagePresentAndOldestTaskOpenTime(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-12T18:56+00:00", stage.get(TIME_OPEN).asText());
            }
        });
    }

    @Then("Verify the milestone closed date with No stages present  and latest task close time {string}")
    public void verifyTheMilestoneClosedDateWithNoStagesPresentAndLatestTaskCloseTime(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-16T12:11+00:00", stage.get(TIME_CLOSED).asText());
            }
        });
    }

    @Then("Verify application Details response for broker having CaseHistory inside stage history Object {string}")
    public void verifyApplicationDetailsResponseForBrokerHavingCaseHistoryInsideStageHistoryObject(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-04-21T13:01+00:00", stage.get(TIME_OPEN).asText());
                JsonNode caseHistory = stage.get(CASE_HISTORY);
                Assertions.assertNotNull(caseHistory);
            }
        });
    }

    @Then("Verify the response for broker having stages mapped to milestone based on mapping sheet {string}")
    public void verifyTheResponseForBrokerHavingStagesMappedToMilestoneBasedOnMappingSheet(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        Assertions.assertNotNull(stageHistoryArray);
        Assertions.assertEquals(PRE_ASSESSMENT, stageHistoryArray.get(0).get(DESCRIPTION).asText());
        Assertions.assertEquals(ASSESSMENT, stageHistoryArray.get(1).get(DESCRIPTION).asText());
        Assertions.assertEquals(VALUATION, stageHistoryArray.get(2).get(DESCRIPTION).asText());
        Assertions.assertEquals(OFFER, stageHistoryArray.get(3).get(DESCRIPTION).asText());
        Assertions.assertEquals(COMPLETION, stageHistoryArray.get(4).get(DESCRIPTION).asText());
    }

    @Then("Verify duplicate stages under the same milestone {string}")
    public void verifyDuplicateStagesUnderTheSameMilestone(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        List<String> totalMilestones = new ArrayList<>();
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage ->
                totalMilestones.add(stage.get(DESCRIPTION).asText())
        );
        Assertions.assertEquals(String.valueOf(totalMilestones.size()), String.valueOf(totalMilestones.stream().distinct().count()));
    }

    @Then("Verify the tasks available for pre-assessment milestone {string}")
    public void verifyTheTasksAvailableForPreAssessmentMilestone(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (PRE_ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertNull(stage.get(CASE_HISTORY).get(0));
            }
        });
    }

    @Then("Verify all the tasks under case history is displayed in opendate desc order {string}")
    public void verifyAllTheTasksUnderCaseHistoryIsDisplayedInOpendateDescOrder(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (OFFER.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-05-12T17:55+00:00", stage.get(CASE_HISTORY).get(0).get(TIME_OPEN).asText());
                Assertions.assertEquals("2021-05-12T17:53+00:00", stage.get(CASE_HISTORY).get(1).get(TIME_OPEN).asText());
                Assertions.assertEquals("2021-05-07T17:33+00:00", stage.get(CASE_HISTORY).get(2).get(TIME_OPEN).asText());
                Assertions.assertEquals("2021-05-07T15:25+00:00", stage.get(CASE_HISTORY).get(3).get(TIME_OPEN).asText());
            }
        });
    }

    @Then("Verify case history with open and close tasks along with their dates and time in Application Details service response for the valid broker details {string}")
    public void verifyCaseHistoryWithOpenAndCloseTasksAlongWithTheirDatesAndTimeInApplicationDetailsServiceResponseForTheValidBrokerDetails(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (OFFER.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("2021-05-12T17:55+00:00", stage.get(CASE_HISTORY).get(0).get(TIME_OPEN).asText());
                Assertions.assertEquals("null", stage.get(CASE_HISTORY).get(0).get(TIME_CLOSED).asText());
                Assertions.assertEquals("2021-05-12T17:53+00:00", stage.get(CASE_HISTORY).get(1).get(TIME_OPEN).asText());
                Assertions.assertEquals("2021-05-12T17:55+00:00", stage.get(CASE_HISTORY).get(1).get(TIME_CLOSED).asText());
                Assertions.assertEquals("2021-05-07T17:33+00:00", stage.get(CASE_HISTORY).get(2).get(TIME_OPEN).asText());
                Assertions.assertEquals("2021-05-12T14:36+00:00", stage.get(CASE_HISTORY).get(2).get(TIME_CLOSED).asText());
                Assertions.assertEquals("2021-05-07T15:25+00:00", stage.get(CASE_HISTORY).get(3).get(TIME_OPEN).asText());
                Assertions.assertEquals("2021-05-07T17:33+00:00", stage.get(CASE_HISTORY).get(3).get(TIME_CLOSED).asText());
            }
        });
    }

    @Then("Verify the valuation milestone is open {string}")
    public void verifyTheValuationMilestoneIsOpen(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertTrue(stage.get(TIME_CLOSED).isNull());
            }
        });
    }

    @Then("Verify the mortgage type as Purchase {string}")
    public void verifyTheMortgageTypeAsPurchase(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Purchase", productInformationDetails.get(MORTGAGE_TYPE).asText());
    }

    @Then("Verify the mortgage type as Remortgage {string}")
    public void verifyTheMortgageTypeAsRemortgage(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Remortgage", productInformationDetails.get(MORTGAGE_TYPE).asText());
    }

    @Then("Verify the mortgage type as Buy To Let {string}")
    public void verifyTheMortgageTypeAsBuyToLet(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Buy to Let", productInformationDetails.get(MORTGAGE_TYPE).asText());
    }

    @Then("Verify the mortgage type as Isolated Product Switch {string}")
    public void verifyTheMortgageTypeAsIsolatedProductSwitch(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        //Assertions.assertEquals("Switch", productInformationDetails.get(MORTGAGE_TYPE).asText());
    }

    @Then("Verify the mortgage type as Existing Customer Further Ad {string}")
    public void verifyTheMortgageTypeAsExistingCustomerFurtherAd(String inputName) {

        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Additional Borrowing", productInformationDetails.get(MORTGAGE_TYPE).asText());
    }

    @Then("Verify the fee status as Added To Loan {string}")
    public void verifyTheFeeStatusAsAddedToLoan(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Added to Loan", productInformationDetails.get(FEE_STATUS).asText());
    }

    @Then("Verify the fee status as To Be Paid On Completion {string}")
    public void verifyTheFeeStatusAsToBePaidOnCompletion(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("Verify the fee status as Free {string}")
    public void verifyTheFeeStatusAsFree(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("Verify the fee status as Paid {string}")
    public void verifyTheFeeStatusAsPaid(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Paid", productInformationDetails.get(FEE_STATUS).asText());
    }

    @Then("Verify the fee status as Paid when feechorig equal to feepaid {string}")
    public void verifyTheFeeStatusAsPaidWhenFeechorigEqualToFeepaid(String inputName) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Paid", productInformationDetails.get(FEE_STATUS).asText());
    }

    @Then("Verify the expected Completion Date field {string}")
    public void verifyTheExpectedCompletionDateField(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        Assertions.assertEquals("2021-06-30", statusDetails.get(EXPECTED_COMPLETION_DATE).asText());
    }

    @Then("Verify the expected Completion Date field value in ISO standard date format {string}")
    public void verifyTheExpectedCompletionDateFieldValueInISOStandardDateFormat(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        Assertions.assertEquals("2021-06-30", statusDetails.get(EXPECTED_COMPLETION_DATE).asText());

    }

    @Then("Verify the Completion Date field {string}")
    public void verifyTheCompletionDateField(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        Assertions.assertEquals("2021-06-30", statusDetails.get(COMPLETION_DATE).asText());

    }

    @Then("Verify the Completion Date field with ISO standard date format {string}")
    public void verifyTheCompletionDateFieldWithISOStandardDateFormat(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        Assertions.assertEquals("2021-06-30", statusDetails.get(COMPLETION_DATE).asText());

    }

    @Then("Verify the Declined Date field {string}")
    public void verifyTheDeclinedDateField(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        //Assertions.assertEquals("2021-06-25", statusDetails.get(DECLINED_DATE).asText());

    }

    @Then("Verify the Declined Date field with ISO standard date format {string}")
    public void verifyTheDeclinedDateFieldWithISOStandardDateFormat(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        //Assertions.assertEquals("2021-06-25", statusDetails.get(DECLINED_DATE).asText());

    }

    @Then("Verify the Refused Date field {string}")
    public void verifyTheRefusedDateField(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        //Assertions.assertEquals("2021-06-21", statusDetails.get(REFUSED_DATE).asText());

    }

    @Then("Verify the Refused Date field with ISO standard date format {string}")
    public void verifyTheRefusedDateFieldWithISOStandardDateFormat(String inputName) {
        JsonNode statusDetails = responseJsonNode.get(STATUS);
        //Assertions.assertEquals("2021-06-21", statusDetails.get(REFUSED_DATE).asText());

    }

    @Then("Verify the Completed Application status for the stage no Eighty where completion date is greater than open date {string}")
    public void verifyTheCompletedApplicationStatusForTheStageNoEightyWhereCompletionDateIsGreaterThanOpenDate(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertTrue(stageHistory.get(TIME_CLOSED).asText().contains("2021-06-24T"));
    }

    @Then("Verify the Completed Application status for the stage no Eighty where completion date is less than open date {string}")
    public void verifyTheCompletedApplicationStatusForTheStageNoEightyWhereCompletionDateIsLessThanOpenDate(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals("null", stageHistory.get(TIME_CLOSED).asText());
    }

    @Then("Verify the Completed Application status for the stage no Eighty where completion date is null {string}")
    public void verifyTheCompletedApplicationStatusForTheStageNoEightyWhereCompletionDateIsNull(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals("null", stageHistory.get(TIME_CLOSED).asText());
    }

    @Then("Verify the Declined Application status for the stage no Eighty four where declined date is null {string}")
    public void verifyTheDeclinedApplicationStatusForTheStageNoEightyFourWhereDeclinedDateIsNull(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertTrue(stageHistory.get(TIME_CLOSED).isNull());
    }

    @Then("Verify the Declined Application status for the stage no Eighty five where declined date is greater than open date {string}")
    public void verifyTheDeclinedApplicationStatusForTheStageNoEightyFiveWhereDeclinedDateIsGreaterThanOpenDate(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("Verify the Declined Application status for the stage no Eighty five where declined date is less than open date {string}")
    public void verifyTheDeclinedApplicationStatusForTheStageNoEightyFiveWhereDeclinedDateIsLessThanOpenDate(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        //Assertions.assertEquals("2021-06-25T06:49+00:00", stageHistory.get(TIME_CLOSED).asText());

    }

    @Then("Verify the Declined Application status for the stage no Eighty five where declined date is null {string}")
    public void verifyTheDeclinedApplicationStatusForTheStageNoEightyFiveWhereDeclinedDateIsNull(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals("null", stageHistory.get(TIME_CLOSED).asText());
    }

    @Then("Verify the Refused Application status for the stage no ninety where refused date is greater than open date {string}")
    public void verifyTheRefusedApplicationStatusForTheStageNoNinetyWhereRefusedDateIsGreaterThanOpenDate(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("Verify the Refused Application status for the stage no ninety where refused date is less than open date {string}")
    public void verifyTheRefusedApplicationStatusForTheStageNoNinetyWhereRefusedDateIsLessThanOpenDate(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        //Assertions.assertEquals("2021-06-21T08:46+00:00", stageHistory.get(TIME_CLOSED).asText());

    }

    @Then("Verify the Refused Application status for the stage no ninety where refused date is null {string}")
    public void verifyTheRefusedApplicationStatusForTheStageNoNinetyWhereRefusedDateIsNull(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals("null", stageHistory.get(TIME_CLOSED).asText());

    }

    @Then("Verify the milestone name for the returned response as DeclineCancelled {string}")
    public void verifyTheMilestoneNameForTheReturnedResponseAsDeclineCancelled(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        Assertions.assertEquals("Declined/Cancelled", stageHistoryArray.get(3).get(DESCRIPTION).asText());
    }

    @Then("Verify the subtext value for the returned response as No Action is required {string}")
    public void verifyTheSubtextValueForTheReturnedResponseAsNoActionIsRequired(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        Assertions.assertEquals("No Action required", stageHistoryArray.get(3).get(SUB_STATUS).asText());
    }

    @Then("Verify the subtext value for the returned response as Action is required {string}")
    public void verifyTheSubtextValueForTheReturnedResponseAsActionIsRequired(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals("Action required", stage.get(SUB_STATUS).asText());
            }
        });
    }

    @Then("Verify the task category for the returned response as Assess {string}")
    public void verifyTheTaskCategoryForTheReturnedResponseAsAssess(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (ASSESSMENT.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryArray = stage.get(CASE_HISTORY);
                boolean isAssessCategoryPresent = StreamSupport.stream(caseHistoryArray.spliterator(), false)
                        .anyMatch(caseHistory -> "Assess".equalsIgnoreCase(caseHistory.get("category").asText()));
                Assertions.assertTrue(isAssessCategoryPresent);
            }
        });
    }

    @Then("Verify the task category for the returned response as Await {string}")
    public void verifyTheTaskCategoryForTheReturnedResponseAsAwait(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals(VALUATION, milestoneDescription.asText());
            }
        });
    }

    @Then("Verify the milestone name for the returned response as Completion {string}")
    public void verifyTheMilestoneNameForTheReturnedResponseAsCompletion(String inputName) {
        JsonNode statusJsonNode = responseJsonNode.get(STATUS).get("status");
        Assertions.assertEquals("Completion", statusJsonNode.asText());
    }

    @Then("Verify the propertyType value as Terraced for the returned response {string}")
    public void verifyThePropertyTypeValueAsTerracedForTheReturnedResponse(String inputName) {
        JsonNode valuationJsonNode = responseJsonNode.get("valuationInformation").get("propertyType");
        Assertions.assertEquals("Terraced", valuationJsonNode.asText());
    }

    @Then("Verify the propertyType value as Detached for the returned response {string}")
    public void verifyThePropertyTypeValueAsDetachedForTheReturnedResponse(String inputName) {
        JsonNode valuationJsonNode = responseJsonNode.get("valuationInformation").get("propertyType");
        Assertions.assertEquals("Terraced", valuationJsonNode.asText());
    }

    @Then("Verify the yearBuild value for the returned response {string}")
    public void verifyTheYearBuildValueForTheReturnedResponse(String inputName) {
        JsonNode valuationJsonNode = responseJsonNode.get("valuationInformation").get("yearBuild");
        Assertions.assertEquals("1884", valuationJsonNode.asText());
    }

    @Then("Verify the milestone name as Assessment for the response returned {string}")
    public void verifyTheMilestoneNameAsAssessmentForTheResponseReturned(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertEquals(ASSESSMENT, stageHistoryArray.get(0).get(DESCRIPTION).asText());
    }

    @Then("Verify the milestone name as Completion for the response returned for ARO task {string}")
    public void verifyTheMilestoneNameAsCompletionForTheResponseReturnedForAROTask(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryNode = stage.get(CASE_HISTORY);
                boolean isAROTaskPresent = StreamSupport.stream(caseHistoryNode.spliterator(), false)
                        .anyMatch(caseHistory -> "We are current waiting on the certificate of title from your client's solicitor. We will contact you once we receive the document".equalsIgnoreCase(caseHistory.get(DESCRIPTION).textValue()));
                Assertions.assertTrue(isAROTaskPresent);
            }
        });
    }

    @Then("Verify the milestone name as Completion for the response returned for CCD task {string}")
    public void verifyTheMilestoneNameAsCompletionForTheResponseReturnedForCCDTask(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                Assertions.assertEquals(COMPLETION, milestoneDescription.asText());
            }
        });
    }

    @Then("Verify the milestone name as Completion for the response returned for SRP task {string}")
    public void verifyTheMilestoneNameAsCompletionForTheResponseReturnedForSRPTask(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryNode = stage.get(CASE_HISTORY);
                boolean isSRPTaskPresent = StreamSupport.stream(caseHistoryNode.spliterator(), false)
                        .anyMatch(caseHistory -> "We have received the certificate of title confirming your client's completion date. If we need further information we will contact your client's solicitors.".equalsIgnoreCase(caseHistory.get(DESCRIPTION).textValue()));
                Assertions.assertTrue(isSRPTaskPresent);
            }
        });
    }

    @Then("Verify the task description for the response returned for T{int} task {string}")
    public void verifyTheTaskDescriptionForTheResponseReturnedForTTask(int taskNumber, String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (COMPLETION.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryNode = stage.get(CASE_HISTORY);
                if (taskNumber == 76) {
                    boolean isT76TaskPresent = StreamSupport.stream(caseHistoryNode.spliterator(), false)
                            .anyMatch(caseHistory -> "Your client's mortgage application has now been closed. Thank you for considering NatWest for your mortgage application. Case Tracking data will be visible for further 14 days.".equalsIgnoreCase(caseHistory.get(DESCRIPTION).textValue()));
                    Assertions.assertTrue(isT76TaskPresent);
                }

                if (taskNumber == 85) {
                    boolean isT85TaskPresent = StreamSupport.stream(caseHistoryNode.spliterator(), false)
                            .anyMatch(caseHistory -> "We are sorry but on this occasion we are unable to offer your client a mortgage. If you require further information or wish to appeal this decision please email intermediarydocs@natwest.com including the mortgage reference number. Case Tracking data will be visible for further 14 days.".equalsIgnoreCase(caseHistory.get(DESCRIPTION).textValue()));
                    Assertions.assertTrue(isT85TaskPresent);
                }
            }
        });
    }

    @Then("Verify the task description for the response returned for not applicable task {string}")
    public void verifyTheTaskDescriptionForTheResponseReturnedForNotApplicableTask(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("Verify the application date before two days of completion {string}")
    public void verifyTheApplicationDateBeforeTwoDaysOfCompletion(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
    }

    @Then("Verify the application date after two days of completion {string}")
    public void verifyTheApplicationDateAfterTwoDaysOfCompletion(String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify invalid Broker EmailId error for the input {string}")
    public void verifyInvalidBrokerEmailIdErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify no application information is returned for the input {string}")
    public void verifyNoApplicationInformationIsReturnedForTheInput(String inputName) {
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
    }

    @Then("Verify error message display of application fourteen days after refused or cancel date {string}")
    public void verifyErrorMessageDisplayOfApplicationFourteenDaysAfterRefusedOrCancelDate(String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify display of application fourteen days after decline date {string}")
    public void verifyDisplayOfApplicationFourteenDaysAfterDeclineDate(String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify display of application fourteen days after refused or cancel date {string}")
    public void verifyDisplayOfApplicationFourteenDaysAfterRefusedOrCancelDate(String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify display of completed application after two days for stage number {int} {string}")
    public void verifyDisplayOfCompletedApplicationAfterTwoDaysForStageNumber(int stage, String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify display of soft decline applications after fourteen days for stage number {int} {string}")
    public void verifyDisplayOfSoftDeclineApplicationsAfterFourteenDaysForStageNumber(int stage, String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify display of hard decline applications after fourteen days for stage number {int} {string}")
    public void verifyDisplayOfHardDeclineApplicationsAfterFourteenDaysForStageNumber(int stage, String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify display of cancel applications after fourteen days for stage number {int} {string}")
    public void verifyDisplayOfCancelApplicationsAfterFourteenDaysForStageNumber(int stage, String inputName) {
        validateErrorUnavailableLegalReason(responseJsonNode, inputName);
    }

    @Then("Verify the user not able to view application for invalid emailid {string}")
    public void verifyTheUserNotAbleToViewApplicationForInvalidEmailid(String inputName) {
        Assertions.assertEquals("FORBIDDEN", responseJsonNode.get("responseStatus").asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    @Then("Verify display of application having product information for the broker exist in GMS {string}")
    public void verifyDisplayOfApplicationHavingProductInformationForTheBrokerExistInGMS(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("281.32", productInformation.get(TOTAL_REPAYMENT_AMOUNT).asText());

    }


    @Then("Verify display of application having product information contains more then one sub product and hiding the existing product from the Product list section under the application details {string}")
    public void verifyDisplayOfApplicationHavingProductInformationContainsMoreThenOneSubProductAndHidingTheExistingProductFromTheProductListSectionUnderTheApplicationDetails(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("281.32", productInformation.get(TOTAL_REPAYMENT_AMOUNT).asText());
    }

    @Then("Verify display of remortgage application where clubbing all same products together by product codes  {string}")
    public void verifyDisplayOfRemortgageApplicationWhereClubbingAllSameProductsTogetherByProductCodes(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("39000", productInformation.get(TOTAL_LOAN_AMOUNT).asText());
    }

    @Then("Verify display of remortgage application where total Loan Amount which is the sum of all the loan amount for new products  {string}")
    public void verifyDisplayOfRemortgageApplicationWhereTotalLoanAmountWhichIsTheSumOfAllTheLoanAmountForNewProducts(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("39000", productInformation.get(TOTAL_LOAN_AMOUNT).asText());
    }

    @Then("Verify display of remortgage application where Repayment amount will be the sum of all the repayment amount for new products {string}")
    public void verifyDisplayOfRemortgageApplicationWhereRepaymentAmountWillBeTheSumOfAllTheRepaymentAmountForNewProducts(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("138.37", productInformation.get(TOTAL_REPAYMENT_AMOUNT).asText());
    }

    @Then("Verify display of AdditionalBorrowing application where clubbing all same products together by product codes  {string}")
    public void verifyDisplayOfAdditionalBorrowingApplicationWhereClubbingAllSameProductsTogetherByProductCodes(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("37000", productInformation.get(TOTAL_LOAN_AMOUNT).asText());
    }

    @Then("Verify display of AdditionalBorrowing application where total Loan Amount which is the sum of all the loan amount for new products  {string}")
    public void verifyDisplayOfAdditionalBorrowingApplicationWhereTotalLoanAmountWhichIsTheSumOfAllTheLoanAmountForNewProducts(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("37000", productInformation.get(TOTAL_LOAN_AMOUNT).asText());
    }

    @Then("Verify display of AdditionalBorrowing application where Repayment amount will be the sum of all the repayment amount for new products {string}")
    public void verifyDisplayOfAdditionalBorrowingApplicationWhereRepaymentAmountWillBeTheSumOfAllTheRepaymentAmountForNewProducts(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("150", productInformation.get(TOTAL_REPAYMENT_AMOUNT).asText());
    }

    @Then("Verify display of BuyToLet application where clubbing all same products together by product codes  {string}")
    public void verifyDisplayOfBuyToLetApplicationWhereClubbingAllSameProductsTogetherByProductCodes(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("67500", productInformation.get(TOTAL_LOAN_AMOUNT).asText());
    }

    @Then("Verify display of BuyToLet application where total Loan Amount which is the sum of all the loan amount for new products  {string}")
    public void verifyDisplayOfBuyToLetApplicationWhereTotalLoanAmountWhichIsTheSumOfAllTheLoanAmountForNewProducts(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("67500", productInformation.get(TOTAL_LOAN_AMOUNT).asText());
    }

    @Then("Verify display of BuyToLet application where Repayment amount will be the sum of all the repayment amount for new products {string}")
    public void verifyDisplayOfBuyToLetApplicationWhereRepaymentAmountWillBeTheSumOfAllTheRepaymentAmountForNewProducts(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("105.6", productInformation.get(TOTAL_REPAYMENT_AMOUNT).asText());
    }

    @Then("Verify the repaymentAmount in product information {string}")
    public void verifyProductInformationRepaymentAmount(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("281.32", productInformation.get(TOTAL_REPAYMENT_AMOUNT).asText());
    }

    @Then("Verify the termYears and termMonths in product information {string}")
    public void verifyTheTermYearsAndTermMonthsInProductInformation(String inputName) {
        JsonNode productInformation = responseJsonNode.get(PRODUCT_INFORMATION);
        JsonNode products = productInformation.get(PRODUCTS);
        Assertions.assertNotNull(productInformation, APPLICATION_DETAILS_NULL);
        Assertions.assertTrue(products.isArray());
        Assertions.assertEquals(1, products.size());
        Assertions.assertEquals("20", products.get(0).get(TERM_YEARS).asText());
        Assertions.assertEquals("0", products.get(0).get(TERM_MONTHS).asText());
    }

    @Then("Verify that refused error message returned for the input {string}")
    public void VerifyRefusedApplicationSuppressed(String inputName) {
        validateUnavailableForLegalReasonRequest(responseJsonNode, inputName);
    }

    @Then("Verify that declined error message returned for the input {string}")
    public void VerifyDeclinedApplicationSuppressed(String inputName) {
        validateUnavailableForLegalReasonRequest(responseJsonNode, inputName);
    }


    private void validateUnavailableForLegalReasonRequest(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(UNAVAILABLE_FOR_LEGAL_REASONS, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    private void verifyErrorMessageForBroker(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(FORBIDDEN, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    private void verifyErrorMessageforCompletedApplications(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(UNAVAILABLE_FOR_LEGAL_REASONS, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());
    }

    @Then("Verify that expected error message returned for the input {string}")
    public void verifyThatExpectedErrorMessageReturnedForTheInput(String inputName) {
        verifyErrorMessageForBroker(responseJsonNode, inputName);
    }

    @Then("Verify that completed error message returned for the input {string}")
    public void verifyThatCompletedErrorMessageReturnedForTheInput(String inputName) {
        verifyErrorMessageforCompletedApplications(responseJsonNode, inputName);
    }

    @Then("Verify invalid broker first name and invalid broker last name error message returned for the input {string}")
    public void verifyInvalidBrokerFirstNameAndInvalidBrokerLastNameErrorMessageReturnedForTheInput(String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        StringBuilder errorMsg = new StringBuilder();
        for (int i = 0; i < responseJsonNode.get(ERROR_MESSAGE).size(); i++) {
            errorMsg.append(responseJsonNode.get(ERROR_MESSAGE).get(i).asText());
        }
        for (String error : errorMessage) {
            Assertions.assertTrue(errorMsg.toString().contains(error));
        }
        Assertions.assertEquals(2, responseJsonNode.get(ERROR_MESSAGE).size());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());

    }


    @Then("Verify mcc valuation information for the given reference number {string}")
    public void VerifyMCCValuationInformationForTheGivenReferenceNumber(String inputName) {
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertNotNull(valuationInformation, VALUATION_INFORMATION_NULL);
        Assertions.assertEquals("Freehold", valuationInformation.get(TENURE).textValue(), ApiTestConstants.Errors.TENURE_NOT_MATCHED);
        Assertions.assertEquals(0, valuationInformation.get(LEASE_TERM_REMAINING).intValue(), ApiTestConstants.Errors.LEASE_TERM_REMAINING_NOT_MATCHED);
        Assertions.assertEquals("2", valuationInformation.get(BED_ROOM_COUNT).textValue(), ApiTestConstants.Errors.BED_ROOM_COUNT_NOT_MATCHED);
        Assertions.assertEquals("C", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);

    }

    @Then("Verify status inside case history object under a milestone {string}")
    public void verifyStatusInsideCaseHistoryObjectUnderAMilestone(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode caseHistoryArray = stage.get(CASE_HISTORY);
            StreamSupport.stream(caseHistoryArray.spliterator(), false).forEach(caseHistory -> {
                if ("null".equals(caseHistory.get(TIME_CLOSED).asText())) {
                    Assertions.assertEquals(OPEN, caseHistory.get(STATUS).asText());
                } else {
                    Assertions.assertEquals(CLOSE, caseHistory.get(STATUS).asText());
                }
            });
        });
    }

    @Then("Verify new field RepaymentType value as Capital and Interest in Application Details Response Object for the input {string}")
    public void verifyNewFieldRepaymentTypeValueAsCapitalAndInterestInApplicationDetailsResponseObjectForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Capital and Interest", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify new field RepaymentType value as Interest Only in Application Details Response Object for the input {string}")
    public void verifyNewFieldRepaymentTypeValueAsInterestOnlyInApplicationDetailsResponseObjectForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Interest Only", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify new field RepaymentType value as Part n Part in Application Details Response Object for the input {string}")
    public void verifyNewFieldRepaymentTypeValueAsPartNPartInApplicationDetailsResponseObjectForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Part n Part", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify RepaymentType value for Single Product for the input {string}")
    public void verifyRepaymentTypeValueForSingleProductForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Capital and Interest", products_Array1.get(REPAYMENT_TYPE).asText());
    }


    @Then("Verify RepaymentType value for multi product having different product code for the input {string}")
    public void verifyRepaymentTypeValueForMultiProductHavingDifferentProductCodeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Part n Part", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify RepaymentType value for multi product having same product code for the input {string}")
    public void verifyRepaymentTypeValueForMultiProductHavingSameProductCodeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Part n Part", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify RepaymentType value for Purchase type for the input {string}")
    public void verifyRepaymentTypeValueForPurchaseTypeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Capital and Interest", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify RepaymentType value for Remortgage type for the input {string}")
    public void verifyRepaymentTypeValueForRemortgageTypeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Part n Part", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify RepaymentType value for Buy To Let type for the input {string}")
    public void verifyRepaymentTypeValueForBuyToLetTypeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Interest Only", products_Array1.get(REPAYMENT_TYPE).asText());
    }


    @Then("Verify RepaymentType value for Product Switch type for the input {string}")
    public void verifyRepaymentTypeValueForProductSwitchTypeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Interest Only", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Verify RepaymentType value for Additional Borrowing type for the input {string}")
    public void verifyRepaymentTypeValueForAdditionalBorrowingTypeForTheInput(String inputName) {
        JsonNode products_Array1 = responseJsonNode.get(PRODUCT_INFORMATION).get(PRODUCTS).get(0);
        Assertions.assertTrue(products_Array1.size() > 0);
        Assert.assertEquals("Capital and Interest", products_Array1.get(REPAYMENT_TYPE).asText());
    }

    @Then("Validate the valuationInformation response where value for Tenure field is Null {string}")
    public void validateTheValuationInformationResponseWhereValueForTenureFieldIsNull(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertNull(valuationInformation.get(TENURE).textValue());
    }

    @Then("Validate the valuationInformation response where value for Tenure field is Freehold {string}")
    public void validateTheValuationInformationResponseWhereValueForTenureFieldIsFreehold(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("Freehold", valuationInformation.get(TENURE).textValue(), ApiTestConstants.Errors.TENURE_NOT_MATCHED);
    }

    @Then("Validate the valuationInformation response where value for Tenure field is Leasehold {string}")
    public void validateTheValuationInformationResponseWhereValueForTenureFieldIsLeasehold(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("Freehold", valuationInformation.get(TENURE).textValue(), ApiTestConstants.Errors.TENURE_NOT_MATCHED);
    }

    @Then("Validate the valuationInformation response where value for Tenure field is Ownership {string}")
    public void validateTheValuationInformationResponseWhereValueForTenureFieldIsOwnership(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertTrue(valuationInformation.get(TENURE).textValue().contains("Ownership"), ApiTestConstants.Errors.TENURE_NOT_MATCHED);
    }

    @Then("Validate the value for BedroomsCount in the valuationInformaton response when bedroom count value is one {string}")
    public void validateTheValueForBedroomsCountInTheValuationInformatonResponseWhenBedroomCountValueIsOne(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("1", valuationInformation.get(BED_ROOM_COUNT).textValue(), ApiTestConstants.Errors.BED_ROOM_COUNT_NOT_MATCHED);

    }

    @Then("Validate the value for BedroomsCount in the valuationInformaton response when bedroom count value is two {string}")
    public void validateTheValueForBedroomsCountInTheValuationInformatonResponseWhenBedroomCountValueIsTwo(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("2", valuationInformation.get(BED_ROOM_COUNT).textValue(), ApiTestConstants.Errors.BED_ROOM_COUNT_NOT_MATCHED);

    }

    @Then("Validate the value for BedroomsCount in the valuationInformaton response when bedroom count value is three {string}")
    public void validateTheValueForBedroomsCountInTheValuationInformatonResponseWhenBedroomCountValueIsThree(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("3", valuationInformation.get(BED_ROOM_COUNT).textValue(), ApiTestConstants.Errors.BED_ROOM_COUNT_NOT_MATCHED);

    }

    @Then("Validate the value for BedroomsCount in the valuationInformaton response when bedroom count value is four {string}")
    public void validateTheValueForBedroomsCountInTheValuationInformatonResponseWhenBedroomCountValueIsFour(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("2", valuationInformation.get(BED_ROOM_COUNT).textValue(), ApiTestConstants.Errors.BED_ROOM_COUNT_NOT_MATCHED);

    }

    @Then("Validate the value for BedroomsCount in the valuationInformaton response when bedroom count value is five {string}")
    public void validateTheValueForBedroomsCountInTheValuationInformatonResponseWhenBedroomCountValueIsFive(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("2", valuationInformation.get(BED_ROOM_COUNT).textValue(), ApiTestConstants.Errors.BED_ROOM_COUNT_NOT_MATCHED);

    }

    @Then("Validate the value for LeaseTermRemaining in the valuationInformaton response when Tenure is leaseHold {string}")
    public void validateTheValueForLeaseTermRemainingInTheValuationInformatonResponseWhenTenureIsLeaseHold(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertNotNull(valuationInformation.get(LEASE_TERM_REMAINING), ApiTestConstants.Errors.LEASE_TERM_REMAINING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is A {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsA(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("A", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is B {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsB(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        //Assertions.assertEquals("B", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is C {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsC(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("C", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is D {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsD(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("D", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is E {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsE(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("F", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is F {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsF(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("F", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is G {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsG(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("Not Captured", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Validate the EPC rating in the valuationInformation response when EPC rating value is Not Captured {string}")
    public void validateTheEPCRatingInTheValuationInformationResponseWhenEPCRatingValueIsNotCaptured(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode valuationInformation = responseJsonNode.get(VALUATION_INFORMATION);
        Assertions.assertEquals("Not Captured", valuationInformation.get(EPC_RATING).textValue(), ApiTestConstants.Errors.EPC_RATING_NOT_MATCHED);
    }

    @Then("Verify the requiredActions details in stageHistory object for a reference number having assessment milestone {string}")
    public void verifyTheRequiredActionsDetailsInStageHistoryObjectForAReferenceNumberHavingAssessmentMilestone(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions details in stageHistory object for a reference number having Valuation milestone {string}")
    public void verifyTheRequiredActionsDetailsInStageHistoryObjectForAReferenceNumberHavingValuationMilestone(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);

        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions details in stageHistory object for a reference number having Offer milestone {string}")
    public void verifyTheRequiredActionsDetailsInStageHistoryObjectForAReferenceNumberHavingOfferMilestone(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);

        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));

    }

    @Then("Verify the requiredActions details in stageHistory object for a reference number having Completion milestone {string}")
    public void verifyTheRequiredActionsDetailsInStageHistoryObjectForAReferenceNumberHavingCompletionMilestone(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        //JsonNode stageHistory = stageHistoryArray.get(3);
//        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
//
//        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
//        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));

    }


    @Then("Verify the requiredActions details in stageHistory object for an inprogress application {string}")
    public void verifyTheRequiredActionsDetailsInStageHistoryObjectForAnInprogressApplication(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions details are displayed in descending order of time in stageHistory object {string}")
    public void verifyTheRequiredActionsDetailsAreDisplayedInDescendingOrderOfTimeInStageHistoryObject(String arg0) {

    }


    @Then("Verify the requiredActions for a reference number having mortgage type as Purchase {string}")
    public void verifyTheRequiredActionsForAReferenceNumberHavingMortgageTypeAsPurchase(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
//        JsonNode stageHistory = stageHistoryArray.get(3);
//        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
//
//        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
//        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions for a reference number having mortgage type as Remortgage {string}")
    public void verifyTheRequiredActionsForAReferenceNumberHavingMortgageTypeAsRemortgage(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions for a reference number having mortgage type as Buy to Let {string}")
    public void verifyTheRequiredActionsForAReferenceNumberHavingMortgageTypeAsBuyToLet(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions for a reference number having mortgage type as Additional Borrowing {string}")
    public void verifyTheRequiredActionsForAReferenceNumberHavingMortgageTypeAsAdditionalBorrowing(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the requiredActions for a reference number having mortgage type as Product Switch {string}")
    public void verifyTheRequiredActionsForAReferenceNumberHavingMortgageTypeAsProductSwitch(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        JsonNode requiredActionObject = stageHistory.get(REQUIRED_ACTIONS);
        Assertions.assertNotNull(requiredActionObject.get(0).get(DESC));
        Assertions.assertNotNull(requiredActionObject.get(0).get(TIME_OPEN));
    }

    @Then("Verify the case history object contains all the closed tasks details {string}")
    public void verifyTheCaseHistoryObjectContainsAllTheClosedTasksDetails(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        JsonNode caseHistory = stageHistory.get(CASE_HISTORY);
        Assertions.assertNotNull(caseHistory.get(0).get("timeClosed"));

    }

    @Then("Validate the COT received date for a broker channel for NWB {string}")
    public void validateTheCOTReceivedDateForABrokerChannelForNWB(String arg0) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
        Assertions.assertNull(statusArray.get("cotReceivedDate").textValue());
        Assertions.assertNull(statusArray.get("cotAssessDate").textValue());
    }

    @Then("Validate the COT assess date for a broker channel for NWB {string}")
    public void validateTheCOTAssessDateForABrokerChannelForNWB(String inputName) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get("cotReceivedDate").asText(), statusArray.get("cotReceivedDate").textValue());
        Assertions.assertNull(statusArray.get("cotAssessDate").textValue());
    }

    @Then("Validate COT assess date and COT received date should not be less than case submission date for NWB Broker {string}")
    public void validateCOTAssessDateAndCOTReceivedDateShouldNotBeLessThanCaseSubmissionDateForNWBBroker(String inputName) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get("cotReceivedDate").asText(), statusArray.get("cotReceivedDate").textValue());
        Assertions.assertEquals(inputs.get("cotAssessDate").asText(), statusArray.get("cotAssessDate").textValue());
        Assertions.assertEquals(inputs.get("submissionDate").asText(), statusArray.get("submissionDate").textValue());
    }

    @Then("Verify error message for entered invalid and blank values in mandatory fields for the input {string}")
    public void verifyErrorMessageForEnteredInvalidAndBlankValuesInMandatoryFieldsForTheInput(String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        StringBuilder errorMsg = new StringBuilder();
        for (int i = 0; i < responseJsonNode.get(ERROR_MESSAGE).size(); i++) {
            errorMsg.append(responseJsonNode.get(ERROR_MESSAGE).get(i).asText());
        }
        for (String error : errorMessage) {
            Assertions.assertTrue(errorMsg.toString().contains(error));
        }
        Assertions.assertEquals(4, responseJsonNode.get(ERROR_MESSAGE).size());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());

    }

    @Then("Verify Applicant first name,last name are converted the names in to capitalization in broker application details for the input {string}")
    public void verifyApplicantFirstNameLastNameAreConvertedTheNamesInToCapitalizationInBrokerApplicationDetailsForTheInput(String arg0) {
        JsonNode applicantInformation = responseJsonNode.get(APPLICANT_INFORMATION).get(0);
        Assertions.assertTrue(applicantInformation.size() > 0);
        Assert.assertEquals("Eycrl", applicantInformation.get(FIRST_NAME).asText());
        Assert.assertEquals("Hmmsn", applicantInformation.get(LAST_NAME).asText());
    }

    @Then("Verify irrespective of names coming from GMS,API will always display the name in presentable format in broker application details for the input {string}")
    public void verifyIrrespectiveOfNamesComingFromGMSAPIWillAlwaysDisplayTheNameInPresentableFormatInBrokerApplicationDetailsForTheInput(String arg0) {
        JsonNode applicantInformation = responseJsonNode.get(APPLICANT_INFORMATION).get(0);
        Assertions.assertTrue(applicantInformation.size() > 0);
        Assert.assertEquals("Eycrl", applicantInformation.get(FIRST_NAME).asText());
        Assert.assertEquals("Hmmsn", applicantInformation.get(LAST_NAME).asText());
    }


    @Then("verify the stage History description and application status for stage ninety two is completion for stage ninety two with {string}")
    public void verifyTheStageHistoryDescriptionAndApplicationStatusForStageNinetyTwoIsCompletionForStageNinetyTwoWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryCompletion = stageHistoryArray.get(3);
        Assert.assertEquals("Completion", stageHistoryCompletion.get(DESCRIPTION).asText());

        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals("Completion", status.get(STATUS).asText());
    }

    @Then("verify the ragstatus of completion stage history of applicationdetails for stage ninety two with {string}")
    public void verifyTheRagstatusOfCompletionStageHistoryOfApplicationdetailsForStageNinetyTwoWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryCompletion = stageHistoryArray.get(3);
        Assert.assertEquals(AMBER, stageHistoryCompletion.get(RAG_STATUS).asText());
    }

    @Then("verify the ragdescription of completion stage history of applicationdetails for stage ninety two with {string}")
    public void verifyTheRagdescriptionOfCompletionStageHistoryOfApplicationdetailsForStageNinetyTwoWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryCompletion = stageHistoryArray.get(3);
        Assert.assertEquals("Completion is in progress", stageHistoryCompletion.get(RAG_DESC).asText());
    }

    @Then("verify the description of completion case history of applicationdetails for RET task code with {string}")
    public void verifyTheDescriptionOfCompletionCaseHistoryOfApplicationdetailsForRETTaskCodeWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode caseHistoryArray = stageHistoryArray.get(3).get(CASE_HISTORY);
        StreamSupport.stream(caseHistoryArray.spliterator(), false).forEach(caseHistory -> {
            if (RET_DESC.equals(caseHistory.get(DESC).asText())) {
                Assert.assertEquals(ASSESS, caseHistory.get(CATEGORY).asText());
            }
        });

    }

    @Then("verify the category of completion case history of applicationdetails for RET task code is access with {string}")
    public void verifyTheCategoryOfCompletionCaseHistoryOfApplicationdetailsForRETTaskCodeIsAccessWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode caseHistoryArray = stageHistoryArray.get(3).get(CASE_HISTORY);

        StreamSupport.stream(caseHistoryArray.spliterator(), false).forEach(caseHistory -> {
            if (RET_DESC.equals(caseHistory.get(DESC).asText())) {
                Assert.assertEquals(ASSESS, caseHistory.get(CATEGORY).asText());
            }
        });
    }

    @Then("verify the status of completion case history of applicationdetails for RET task code with {string}")
    public void verifyTheStatusOfCompletionCaseHistoryOfApplicationdetailsForRETTaskCodeWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode caseHistoryArray = stageHistoryArray.get(3).get(CASE_HISTORY);

        StreamSupport.stream(caseHistoryArray.spliterator(), false).forEach(caseHistory -> {
            if ("null".equals(caseHistory.get(TIME_CLOSED).asText())) {
                Assert.assertEquals(OPEN, caseHistory.get(STATUS).asText());
            } else {
                Assert.assertEquals(CLOSE, caseHistory.get(STATUS).asText());
            }
        });
    }

    @Then("verify the ragstatus and ragDescription for status of applicationdetails for open stage ninety two with {string}")
    public void verifyTheRagstatusAndRagDescriptionForStatusOfApplicationdetailsForOpenStageNinetyTwoWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);

        Assert.assertEquals(AMBER, status.get(RAG_STATUS).asText());
        Assert.assertEquals("Your application is in progress", status.get(RAG_DESC).asText());
    }

    @Then("verify the subStatus and statusDescripion for status of applicationdetails for stage open ninety two with {string}")
    public void verifyTheSubStatusAndStatusDescripionForStatusOfApplicationdetailsForStageOpenNinetyTwoWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);

        Assert.assertEquals(NO_ACTION_REQUIRED, status.get(SUB_STATUS).asText());
        Assert.assertEquals("No action is required", status.get(SUB_DESC).asText());
    }

    @Then("validate the offer issue date field is present in status object with {string}")
    public void validateTheOfferIssueDateFieldIsPresentInStatusObjectWith(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.has(OFFER_ISSUE_DATE));
    }

    @Then("verify the offer issue date in status object for one TTwoOne task created and on open using input {string}")
    public void verifyTheOfferIssueDateInStatusObjectForOneTTwoOneTaskCreatedAndOnOpenUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(OFFER_ISSUE_DATE).isNull());
    }

    @Then("verify the offer issue date in status object for multiple TTwoOne created and one TTwoOne open using input {string}")
    public void verifyTheOfferIssueDateInStatusObjectForMultipleTTwoOneCreatedAndOneTTwoOneOpenUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(OFFER_ISSUE_DATE).isNull());
    }

    @Then("verify the offer issue date in status object for one TTwoOne task created and closed using input {string}")
    public void verifyTheOfferIssueDateInStatusObjectForOneTTwoOneTaskCreatedAndClosedUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(OFFER_ISSUE_DATE).asText(), status.get(OFFER_ISSUE_DATE).asText());
    }

    @Then("verify the offer issue date in status object for multiple TTwoOne created and all closed using input {string}")
    public void verifyTheOfferIssueDateInStatusObjectForMultipleTTwoOneCreatedAndAllClosedUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(OFFER_ISSUE_DATE).asText(), status.get(OFFER_ISSUE_DATE).asText());
    }

    @Then("verify the offer issue date in status object for no TTwoOne created using input {string}")
    public void verifyTheOfferIssueDateInStatusObjectForNoTTwoOneCreatedUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(OFFER_ISSUE_DATE).isNull());
    }


    @Then("verify the cotAcceptedDate is present in status object of response using input {string}")
    public void verifyTheCotAcceptedDateIsPresentInStatusObjectOfResponseUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.has(COT_ACCEPTED_DATE));
    }

    @Then("verify the cotAcceptedDate for application not reached stage fifty and cotReceivedDate is null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationNotReachedStageFiftyAndCotReceivedDateIsNullUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
    }

    @Then("verify the cotAcceptedDate for application reached stage fifty once and cotReceivedDate is null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationReachedStageFiftyOnceAndCotReceivedDateIsNullUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
    }

    @Then("verify the cotAcceptedDate for application reached stage fifty multiple times and cotReceivedDate is null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationReachedStageFiftyMultipleTimesAndCotReceivedDateIsNullUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
    }

    @Then("verify the cotAcceptedDate for application not reached stage fifty and cotReceivedDate is not null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationNotReachedStageFiftyAndCotReceivedDateIsNotNullUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
    }

    @Then("verify the cotAcceptedDate for application reached stage fifty once and cotReceivedDate is not null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationReachedStageFiftyOnceAndCotReceivedDateIsNotNullUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_ACCEPTED_DATE).asText(), status.get(COT_ACCEPTED_DATE).asText());
    }

    @Then("verify the cotAcceptedDate for application reached stage fifty multiple times and cotReceivedDate is not null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationReachedStageFiftyMultipleTimesAndCotReceivedDateIsNotNullUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_ACCEPTED_DATE).asText(), status.get(COT_ACCEPTED_DATE).asText());
    }

    @Then("verify the cotAcceptedDate for application reached stage fifty once and currently in lower stage and cotReceivedDate is not null using input {string}")
    public void verifyTheCotAcceptedDateForApplicationReachedStageFiftyOnceAndCurrentlyInLowerStageAndCotReceivedDateIsNotNullUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
    }

    @Then("verify the cotAcceptedDate for application not reached stage fifty and currently in stage greater than fifty using input {string}")
    public void verifyTheCotAcceptedDateForApplicationNotReachedStageFiftyAndCurrentlyInStageGreaterThanFiftyUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        //Assert.assertEquals("2021-04-19T12:23+00:00",status.get(COT_ACCEPTED_DATE).asText());
    }


    @Then("verify Mortgage Switching Documents for the stage {int} using input {string}")
    public void verifyMortgageSwitchingDocumentsForTheStageUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        Assertions.assertEquals(PRODUCT_SWITCH_STATUS, stageHistoryDescription);
    }

    @Then("verify Milestone Description for the stage {int} using input {string}")
    public void verifyMilestoneDescriptionForTheStageUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (PRODUCT_SWITCH_STAGE_40_DESCRIPTION.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryArray = stage.get(CASE_HISTORY);
                boolean isAssessCategoryPresent = StreamSupport.stream(caseHistoryArray.spliterator(), false)
                        .anyMatch(caseHistory -> "Assess".equalsIgnoreCase(caseHistory.get("category").asText()));
                Assertions.assertTrue(isAssessCategoryPresent);
            }
        });
    }

    @Then("verify Milestone Description and Rag Status for application date is less than rate switch date using input {string}")
    public void verifyMilestoneDescriptionAndRagStatusForApplicationDateIsLessThanRateSwitchDateUsingInput(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("verify Milestone Description and Rag Status for application date is more than rate switch date using input {string}")
    public void verifyMilestoneDescriptionAndRagStatusForApplicationDateIsMoreThanRateSwitchDateUsingInput(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("verify Milestone Description and Rag Status for application date is equal than rate switch date using input {string}")
    public void verifyMilestoneDescriptionAndRagStatusForApplicationDateIsEqualThanRateSwitchDateUsingInput(String inputName) {
        Assertions.assertNotNull(inputName, "test data not found");
    }

    @Then("verify the application details response for progress milestone details for stage number {int} using input {string}")
    public void verifyTheApplicationDetailsResponseForProgressMilestoneDetailsForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
//        JsonNode caseHistoryArray = stageHistoryArray.get(0).get(CASE_HISTORY);
//
//        boolean isDescriptionPresent = StreamSupport.stream(caseHistoryArray.spliterator(), false)
//                .anyMatch(caseHistory -> caseHistory.get(DESC).asText().contains(PRODUCT_SWITCH_STAGE_67_DESCRIPTION));
//        Assertions.assertTrue(isDescriptionPresent);
    }

    @Then("verify the status response for status name and status description for stage number {int} using input {string}")
    public void verifyTheStatusResponseForStatusNameAndStatusDescriptionForStageNumberUsingInput(int arg0, String inputName) {
        JsonNode statusProductSwitch = responseJsonNode.get(STATUS);
        Assert.assertEquals("Product Switch", statusProductSwitch.get(STATUS).asText());
        Assert.assertEquals("Your application is at Product Switch", statusProductSwitch.get(STATUS_DESCRIPTION).asText());
    }

    @Then("verify the application details response for milestone rag description and sub status description for stage number {int} using input {string}")
    public void verifyTheApplicationDetailsResponseForMilestoneRagDescriptionAndSubStatusDescriptionForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
//        Assertions.assertTrue(stageHistoryArray.isArray());
//        JsonNode stageHistory = stageHistoryArray.get(0);
//        Assertions.assertEquals(PRODUCT_SWITCH_RAG_STATUS, stageHistory.get(RAG_STATUS).asText());
//        Assertions.assertEquals(PRODUCT_SWITCH_RAG_DESC, stageHistory.get(RAG_DESC).asText());
    }

    @Then("verify the application details response for no COT is displayed using input {string}")
    public void verifyTheApplicationDetailsResponseForNoCOTIsDisplayedUsingInput(String arg0) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
        Assertions.assertNull(statusArray.get("cotReceivedDate").textValue());
        Assertions.assertNull(statusArray.get("cotAssessDate").textValue());
    }

    @Then("verify the status response for new field expectedEffectiveDate is displayed using input {string}")
    public void verifyTheStatusResponseForNewFieldExpectedEffectiveDateIsDisplayedUsingInput(String inputName) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
//        JsonNode inputs = inputsAsJsonNode.get(inputName);
//        Assertions.assertEquals(inputs.get("expectedEffectiveDate").asText(), statusArray.get("expectedEffectiveDate").textValue());
    }

    @Then("verify the status response for actualEffectiveDate is displayed using input {string}")
    public void verifyTheStatusResponseForActualEffectiveDateIsDisplayedUsingInput(String inputName) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
//        JsonNode inputs = inputsAsJsonNode.get(inputName);
//        Assertions.assertEquals(inputs.get("completionDate").asText(), statusArray.get("completionDate").textValue());
//        Assertions.assertEquals(inputs.get("actualEffectiveDate").asText(), statusArray.get("actualEffectiveDate").textValue());
    }


    @Then("verify the application details response for milestone of declined or cancelled details for stage number {int} using input {string}")
    public void verifyTheApplicationDetailsResponseForMilestoneOfDeclinedOrCancelledDetailsForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals("Assessment", stageHistoryDescription);
//        Assertions.assertEquals(RED, ragStatus);
//        Assertions.assertEquals("Your client's application has been cancelled", ragStatusDescription);

    }

    @Then("verify the application details response for milestone details for stage number {int} using input {string}")
    public void verifyTheApplicationDetailsResponseForMilestoneDetailsForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        JsonNode caseHistoryArray = stageHistoryArray.get(1).get(CASE_HISTORY);

        boolean isDescriptionPresent = StreamSupport.stream(caseHistoryArray.spliterator(), false)
                .anyMatch(caseHistory -> caseHistory.get(DESC).asText().contains(PRODUCT_SWITCH_CANCEL_DESC));
        Assertions.assertTrue(isDescriptionPresent);
    }

    @Then("verify the milestone name as Amber and milestone rag status for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAsAmberAndMilestoneRagStatusForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String subStatusDescription = stageHistory.get(SUB_DESC).asText();

        Assertions.assertEquals("Assessment is in progress", stageHistoryDescription);
        Assertions.assertEquals(AMBER, ragStatus);
        Assertions.assertEquals("Assessment is In-Progress", subStatusDescription);

    }

    @Then("verify the record not found for stage number for stage number {int} using input  {string}")
    public void verifyTheRecordNotFoundForStageNumberForStageNumberUsingInput(int arg0, String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
    }

    @Then("verify the milestone name and milestone rag status as Amber for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAndMilestoneRagStatusAsAmberForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory1 = stageHistoryArray.get(0);
        String stageHistoryDescription1 = stageHistory1.get(DESCRIPTION).asText();
        String ragStatus = stageHistory1.get(RAG_STATUS).asText();
        String subStatusDescription = stageHistory1.get(SUB_DESC).asText();

        Assertions.assertEquals("Assessment", stageHistoryDescription1);
        Assertions.assertEquals(AMBER, ragStatus);
        Assertions.assertEquals("No action is required", subStatusDescription);

        JsonNode stageHistory2 = stageHistoryArray.get(3);
        Assertions.assertEquals("Declined/Cancelled", stageHistory2.get(DESCRIPTION).asText());
        Assertions.assertEquals(RED, stageHistory2.get(RAG_STATUS).asText());

    }

    @Then("verify the milestone name as Assessment and milestone rag status for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAsAssessmentAndMilestoneRagStatusForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (SOFT_DECLINE_ASSESSMENT_DESC.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryArray = stage.get(CASE_HISTORY);
                boolean isAssessCategoryPresent = StreamSupport.stream(caseHistoryArray.spliterator(), false)
                        .anyMatch(caseHistory -> "Assess".equalsIgnoreCase(caseHistory.get("category").asText()));
                Assertions.assertTrue(isAssessCategoryPresent);
            }
        });

        JsonNode stageHistory2 = stageHistoryArray.get(3);
        Assertions.assertEquals("Declined/Cancelled", stageHistory2.get(DESCRIPTION).asText());
        Assertions.assertEquals(RED, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("verify the milestone name Assessment and description for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAssessmentAndDescriptionForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory1 = stageHistoryArray.get(0);
        String stageHistoryDescription1 = stageHistory1.get(DESCRIPTION).asText();
        Assertions.assertEquals("Assessment", stageHistoryDescription1);

        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assert.assertEquals("Your application is at Offer", statusArray.get(STATUS_DESCRIPTION).asText());
        Assert.assertEquals(AMBER, statusArray.get(RAG_STATUS).asText());
        Assert.assertEquals("Your application is in progress", statusArray.get(RAG_DESC).asText());

        JsonNode stageHistory2 = stageHistoryArray.get(3);
        Assertions.assertEquals(COMPLETION, stageHistory2.get(DESCRIPTION).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("verify the milestone name and description for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAndDescriptionForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory1 = stageHistoryArray.get(0);
        String stageHistoryDescription1 = stageHistory1.get(DESCRIPTION).asText();
        Assertions.assertEquals("Assessment", stageHistoryDescription1);

        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assert.assertEquals("Your application is at Offer", statusArray.get(STATUS_DESCRIPTION).asText());
        Assert.assertEquals(AMBER, statusArray.get(RAG_STATUS).asText());
        Assert.assertEquals("Your application is in progress", statusArray.get(RAG_DESC).asText());

        JsonNode stageHistory2 = stageHistoryArray.get(3);
        Assertions.assertEquals(COMPLETION, stageHistory2.get(DESCRIPTION).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("verify the milestone name and stage description for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAndStageDescriptionForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory1 = stageHistoryArray.get(0);
        String stageHistoryDescription1 = stageHistory1.get(DESCRIPTION).asText();
        Assertions.assertEquals("Assessment", stageHistoryDescription1);

        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assert.assertEquals("Your application is at Offer", statusArray.get(STATUS_DESCRIPTION).asText());
        Assert.assertEquals(AMBER, statusArray.get(RAG_STATUS).asText());

        JsonNode stageHistory2 = stageHistoryArray.get(3);
        Assertions.assertEquals(COMPLETION, stageHistory2.get(DESCRIPTION).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("verify the rag status as Amber and milestone name for stage number {int} using input {string}")
    public void verifyTheRagStatusAsAmberAndMilestoneNameForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String subStatusDescription = stageHistory.get(SUB_DESC).asText();

        Assertions.assertEquals("Completion", stageHistoryDescription);
        Assertions.assertEquals(AMBER, ragStatus);
        Assertions.assertEquals("Action is required", subStatusDescription);
    }

    @Then("verify the milestone name as Ready for Fund Release and milestone rag status for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAsReadyForFundReleaseAndMilestoneRagStatusForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        Assertions.assertEquals("Valuation", stageHistoryDescription);
        Assertions.assertEquals(GREEN, ragStatus);

        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assert.assertEquals("No action is required", statusArray.get(SUB_DESC).asText());
    }

    @Then("verify the milestone name as Completed and milestone decription for stage number {int} using input {string}")
    public void verifyTheMilestoneNameAsCompletedAndMilestoneDecriptionForStageNumberUsingInput(int arg0, String arg1) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        StreamSupport.stream(stageHistoryArray.spliterator(), false).forEach(stage -> {
            JsonNode milestoneDescription = stage.get(DESCRIPTION);
            if (VALUATION_HISTORY_DESC.equalsIgnoreCase(milestoneDescription.asText())) {
                JsonNode caseHistoryArray = stage.get(CASE_HISTORY);
                boolean isAssessCategoryPresent = StreamSupport.stream(caseHistoryArray.spliterator(), false)
                        .anyMatch(caseHistory -> "Assess".equalsIgnoreCase(caseHistory.get("category").asText()));
                Assertions.assertTrue(isAssessCategoryPresent);
            }
        });
    }

    @Then("verify overall application will be Green for stage number {int} using input {string}")
    public void verifyOverallApplicationWillBeGreenForStageNumberUsingInput(int arg0, String inputName) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
//        Assertions.assertNotNull(statusArray, STATUS_INFORMATION_MISSING);
//        Assert.assertEquals(GREEN, statusArray.get(RAG_STATUS).asText());
    }

    @Then("verify milestone name and milestone rag status for soft decline progressed back following successful appeal stage number {int} to stage number {int} using input {string}")
    public void verifyMilestoneNameAndMilestoneRagStatusForSoftDeclineProgressedBackFollowingSuccessfulAppealStageNumberToStageNumberUsingInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals("Assessment", stageHistoryDescription);
        Assertions.assertEquals(AMBER, ragStatus);
        Assertions.assertEquals("Assessment is in progress", ragStatusDescription);
    }

    @Then("verify milestone name and milestone rag status for stage number eighty five using input {string}")
    public void verifyMilestoneNameAndMilestoneRagStatusFoStageNumberEightyFiveUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();

        Assertions.assertEquals("Declined/Cancelled", stageHistoryDescription);
        Assertions.assertEquals(RED, ragStatus);
        Assertions.assertEquals("Your client's application has been declined / cancelled", ragStatusDescription);

        JsonNode statusArray = responseJsonNode.get(STATUS);
        Assert.assertEquals("Application is declined", statusArray.get(SUB_DESC).asText());
    }

    @Then("verify milestone name and milestone rag status for stage number twenty two using input {string}")
    public void verifyMilestoneNameAndMilestoneRagStatusForStageNumberTwentyTwoUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();
        Assert.assertEquals("null",ragStatus);
        Assert.assertEquals("null",ragStatusDescription);
    }

    @Then("verify rag description,sub status,sub status description and stage description in the status object for stage number eighty five using input {string}")
    public void verifyRagDescriptionSubStatusSubStatusDescriptionAndStageDescriptionInTheStatusObjectForStageNumberEightyFiveUsingInput(String arg0) {
        JsonNode statusArray = responseJsonNode.get(STATUS);
//        Assert.assertEquals("RED", statusArray.get(RAG_STATUS).asText());
//        Assert.assertEquals("Your client's application has been cancelled", statusArray.get(RAG_DESC).asText());
//        Assert.assertEquals("Cancelled", statusArray.get(SUB_STATUS).asText());
//        Assert.assertEquals("Application is cancelled", statusArray.get(SUB_DESC).asText());
    }

    @Then("verify rag description,sub status and sub status description in the stage history object for stage number eighty five using input {string}")
    public void verifyRagDescriptionSubStatusAndSubStatusDescriptionInTheStageHistoryObjectForStageNumberEightyFiveUsingInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        String ragStatus = stageHistory.get(RAG_STATUS).asText();
//        String ragStatusDescription = stageHistory.get(RAG_DESC).asText();
//
//        Assertions.assertEquals("Product Switch", stageHistoryDescription);
//        Assertions.assertEquals(RED, ragStatus);
//        Assertions.assertEquals("Your client's application has been cancelled", ragStatusDescription);
    }

    //Loan Requirement

    @Then("Verify for Change after offer condition RAG Status Changes to Amber in Assessment while stage moves from thirty four move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromThirtyFourMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status in Valuation while stage moves from thirty four move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusInValuationWhileStageMovesFromThirtyFourMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status Changes to Grey in Offer while stage moves from thirty four move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromThirtyFourMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from thirty four move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromThirtyFourMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status Changes to Amber in Assessment while stage moves from thirty six move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromThirtySixMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status in Valuation while stage moves from thirty six move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusInValuationWhileStageMovesFromThirtySixMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status Changes to Grey in Offer while stage moves from thirty six move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromThirtySixMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from thirty six move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromThirtySixMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status Changes to Amber in Assessment while stage moves from fourty move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromFourtyMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status in Valuation while stage moves from fourty move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusInValuationWhileStageMovesFromFourtyMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status Changes to Grey in Offer while stage moves from fourty move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromFourtyMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from fourty move to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromFourtyMoveToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no change in RAG Status in Assessment while stage moves from {int} to {int} for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangeInRAGStatusInAssessmentWhileStageMovesFromToForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Amber in Valuation while stage moves from {int} to {int} for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToAmberInValuationWhileStageMovesFromToForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Grey in Offer while stage moves from {int} to {int} for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromToForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from {int} to {int} for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromToForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no change in RAG Status in Assessment while stage moves from thirty six to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangeInRAGStatusInAssessmentWhileStageMovesFromThirtySixToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Amber in Valuation while stage moves from thirty six to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToAmberInValuationWhileStageMovesFromThirtySixToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Grey in Offer while stage moves from thirty six to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromThirtySixToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from thirty six to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromThirtySixToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no change in RAG Status in Assessment while stage moves from fouty to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangeInRAGStatusInAssessmentWhileStageMovesFromFoutyToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Amber in Valuation while stage moves from fouty to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToAmberInValuationWhileStageMovesFromFoutyToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Grey in Offer while stage moves from fouty to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromFoutyToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from fouty to thirty for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromFoutyToThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no change in RAG Status in Assessment while stage moves from fifty to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangeInRAGStatusInAssessmentWhileStageMovesFromFiftyToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no change in RAG Status in Valuation while stage moves from fifty to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangeInRAGStatusInValuationWhileStageMovesFromFiftyToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition RAG Status changes to Grey in Offer while stage moves from fifty to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromFiftyToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Change after offer condition no changes in RAG Status i.e Grey in Completion while stage moves from fifty to backward case for the input {string}")
    public void verifyForChangeAfterOfferConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromFiftyToBackwardCaseForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Amber in Assessment while stage moves from {int} to {int} for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromToForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status in Valuation  while stage moves from {int} to either {int} for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusInValuationWhileStageMovesFromToEitherForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Grey in Offer while stage moves from {int} to either {int} for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromToEitherForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status i.e Grey in Completion while stage moves from {int} to {int} for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromToForTheInput(int arg0, int arg1, String arg2) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Amber in Assessment while stage moves from twenty five to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromTwentyFiveToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status in Valuation while stage moves from twenty five to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusInValuationWhileStageMovesFromTwentyFiveToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Grey in Offer while stage moves from twenty five to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromTwentyFiveToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status i.e Grey in Completion while stage moves from twenty five to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromTwentyFiveToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Amber in Assessment while stage moves from thirty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromThirtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status in Valuation while stage moves from thirty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusInValuationWhileStageMovesFromThirtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Grey in Offer while stage moves from thirty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromThirtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status i.e Grey in Completion while stage moves from thirty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromThirtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Amber in Assessment while stage moves from fourty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromFourtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status in Valuation while stage moves from fourty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusInValuationWhileStageMovesFromFourtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Grey in Offer while stage moves from fourty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromFourtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status i.e Grey in Completion while stage moves from fourty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromFourtyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Amber in Assessment while stage moves from fifty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromFiftyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status in Valuation while stage moves from fifty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusInValuationWhileStageMovesFromFiftyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(GREEN, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Grey in Offer while stage moves from fifty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromFiftyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status i.e Grey in Completion while stage moves from fifty to twenty four for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromFiftyToTwentyFourForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify Broker message as We require your new property details for Lost property condition for the input {string}")
    public void verifyBrokerMessageAsWeRequireYourNewPropertyDetailsForLostPropertyConditionForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());

    }

    @Then("Verify for Lost property condition RAG Status Changes to Amber in Assessment while stage moves from twentyfour to either twenty two,twentyfive,thirty for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToAmberInAssessmentWhileStageMovesFromTwentyfourToEitherTwentyTwoTwentyfiveThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status in Valuation while stage moves from twentyfour to either twenty two,twentyfive,thirty for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusInValuationWhileStageMovesFromTwentyfourToEitherTwentyTwoTwentyfiveThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(1);
        Assertions.assertEquals(AMBER, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition RAG Status Changes to Grey in Offer while stage moves from twentyfour to either twenty two,twentyfive,thirty for the input {string}")
    public void verifyForLostPropertyConditionRAGStatusChangesToGreyInOfferWhileStageMovesFromTwentyfourToEitherTwentyTwoTwentyfiveThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(2);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify for Lost property condition no changes in RAG Status i.e Grey in Completion while stage moves from twentyfour to either twenty two,twentyfive,thirty for the input {string}")
    public void verifyForLostPropertyConditionNoChangesInRAGStatusIEGreyInCompletionWhileStageMovesFromTwentyfourToEitherTwentyTwoTwentyfiveThirtyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify Broker message as We have received your  new property details we will contact you if we need any further information for Lost property condition for the input {string}")
    public void verifyBrokerMessageAsWeHaveReceivedYourNewPropertyDetailsWeWillContactYouIfWeNeedAnyFurtherInformationForLostPropertyConditionForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(3);
        Assertions.assertEquals(GREY, stageHistory.get(RAG_STATUS).asText());
    }

    @Then("Verify Case has been at Offer returns to pre offer status for the input {string}")
    public void verifyCaseHasBeenAtOfferReturnsToPreOfferStatusForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray1 = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryArray2 = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray1.isArray());
        JsonNode stageHistory1 = stageHistoryArray1.get(2);
        Assertions.assertTrue(stageHistoryArray2.isArray());
        JsonNode stageHistory2 = stageHistoryArray1.get(3);
        Assertions.assertEquals(GREY, stageHistory1.get(RAG_STATUS).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("Verify Case has been at Offer returns due to lost property for the input {string}")
    public void verifyCaseHasBeenAtOfferReturnsDueToLostPropertyForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray1 = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryArray2 = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray1.isArray());
        JsonNode stageHistory1 = stageHistoryArray1.get(2);
        Assertions.assertTrue(stageHistoryArray2.isArray());
        JsonNode stageHistory2 = stageHistoryArray1.get(3);
        Assertions.assertEquals(GREY, stageHistory1.get(RAG_STATUS).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("New property details have been received and updated and case has returned to pre offer or valuation and then moves forward with new details being updated for the input {string}")
    public void newPropertyDetailsHaveBeenReceivedAndUpdatedAndCaseHasReturnedToPreOfferOrValuationAndThenMovesForwardWithNewDetailsBeingUpdatedForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray1 = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryArray2 = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray1.isArray());
        JsonNode stageHistory1 = stageHistoryArray1.get(2);
        Assertions.assertTrue(stageHistoryArray2.isArray());
        JsonNode stageHistory2 = stageHistoryArray1.get(3);
        Assertions.assertEquals(GREY, stageHistory1.get(RAG_STATUS).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("Verify All of the above combined stages for the input {string}")
    public void verifyAllOfTheAboveCombinedStagesForTheInput(String arg0) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode stageHistoryArray1 = applicationDetails.get(STAGE_HISTORY);
        JsonNode stageHistoryArray2 = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray1.isArray());
        JsonNode stageHistory1 = stageHistoryArray1.get(2);
        Assertions.assertTrue(stageHistoryArray2.isArray());
        JsonNode stageHistory2 = stageHistoryArray1.get(3);
        Assertions.assertEquals(AMBER, stageHistory1.get(RAG_STATUS).asText());
        Assertions.assertEquals(GREY, stageHistory2.get(RAG_STATUS).asText());
    }

    @Then("verify the cot dates for cot received and cot not accessed using input {string}")
    public void verifyTheCotDatesForCotReceivedAndCotNotAccessedUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_RECEIVED_DATE).asText(), status.get(COT_RECEIVED_DATE).asText());
    }

    @Then("verify the cot dates for cot received, cot accessed and cot accepted for completion account using input {string}")
    public void verifyTheCotDatesForCotReceivedCotAccessedAndCotAcceptedForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
//        JsonNode status = responseJsonNode.get(STATUS);
//        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_RECEIVED_DATE).asText(), status.get(COT_RECEIVED_DATE).asText());
//        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_ASSESSED_DATE).asText(), status.get(COT_ASSESSED_DATE).asText());
//        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_ACCEPTED_DATE).asText(), status.get(COT_ACCEPTED_DATE).asText());
    }

    @Then("verify the cot dates for cot accessed and cot accepted and cot not received for completion account using input {string}")
    public void verifyTheCotDatesForCotAccessedAndCotAcceptedAndCotNotReceivedForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
        Assert.assertTrue(status.get(COT_ASSESSED_DATE).isNull());
        Assert.assertTrue(status.get(COT_RECEIVED_DATE).isNull());
    }

    @Then("verify the cot dates for cot received for completion account using input {string}")
    public void verifyTheCotDatesForCotReceivedForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_RECEIVED_DATE).asText(), status.get(COT_RECEIVED_DATE).asText());
    }

    @Then("verify the cot dates for multiple cot received for completion account using input {string}")
    public void verifyTheCotDatesForMultipleCotReceivedForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(COT_RECEIVED_DATE).asText(), status.get(COT_RECEIVED_DATE).asText());
    }

    @Then("verify the cot dates for application moves backward from stage fifty using input {string}")
    public void verifyTheCotDatesForApplicationMovesBackwardFromStageFiftyUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(COT_ACCEPTED_DATE).isNull());
        Assert.assertTrue(status.get(COT_ASSESSED_DATE).isNull());
        Assert.assertTrue(status.get(COT_RECEIVED_DATE).isNull());
    }

    @Then("verify the offer date for no TTwoOne using input {string}")
    public void verifyTheOfferDateForNoTTwoOneUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertTrue(status.get(OFFER_ISSUE_DATE).isNull());
    }

    @Then("verify the offer date for one TTwoOne for completion account using input {string}")
    public void verifyTheOfferDateForOneTTwoOneForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(OFFER_ISSUE_DATE).asText(), status.get(OFFER_ISSUE_DATE).asText());
    }

    @Then("verify the offer date for multiple TTwoOne for completion account using input {string}")
    public void verifyTheOfferDateForMultipleTTwoOneForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
//        JsonNode status = responseJsonNode.get(STATUS);
//        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(OFFER_ISSUE_DATE).asText(), status.get(OFFER_ISSUE_DATE).asText());
    }

    @Then("verify the offer date for cot not received for completion account using input {string}")
    public void verifyTheOfferDateForCotNotReceivedForCompletionAccountUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
//        JsonNode status = responseJsonNode.get(STATUS);
//        Assert.assertEquals(inputsAsJsonNode.get(inputName).get(OFFER_ISSUE_DATE).asText(), status.get(OFFER_ISSUE_DATE).asText());
    }


    @Then("Verify the valid reference number is displayed in the application details for the input {string}")
    public void verifyTheValidReferenceNumberIsDisplayedInTheApplicationDetailsForTheInput(String inputName) {
        JsonNode applications = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(applications.get(REFERENCE_NUMBER), responseJsonNode.get(REFERENCE_NUMBER));
    }

    @Then("Verify invalid User EmailId error for the input {string}")
    public void verifyInvalidUserEmailIdErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Firm FCA Number error for the input {string}")
    public void verifyInvalidUserFirmFCANumberErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user First Name error for the input {string}")
    public void verifyInvalidUserFirstNameErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Last Name error for the input {string}")
    public void verifyInvalidUserLastNameErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Principle FCA Number error for the input {string}")
    public void verifyInvalidUserPrincipleFCANumberErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify invalid user Role error for the input {string}")
    public void verifyInvalidUserRoleErrorForTheInput(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify that expected unauthorized error message returned for the input {string}")
    public void verifyThatExpectedUnauthorizedErrorMessageReturnedForTheInput(String inputName) {
        Assertions.assertEquals(UNAUTHORIZED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }
    @Then("Verify middle name for the input {string}")
    public void verifyMiddleNameForTheInput(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode applicantInformationArray = responseJsonNode.get(APPLICANT_INFORMATION);
        boolean isApplicantMiddleNameFound = StreamSupport.stream(applicantInformationArray.spliterator(), false)
                .anyMatch(
                        applicantInformation -> StringUtils.isNotEmpty(applicantInformation.get(MIDDLE_NAME).textValue()) &&
                                applicantInformation.get(MIDDLE_NAME).textValue().equals(inputs.get(MIDDLE_NAME).textValue()));
        Assertions.assertTrue(isApplicantMiddleNameFound);
    }

    @Then("verify E-cot happy path using input {string}")
    public void verifyECotHappyPathUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(
                inputsAsJsonNode.get(inputName).get(COT_RECEIVED_DATE).asText(),
                status.get(COT_RECEIVED_DATE).asText());
        Assert.assertEquals(
                inputsAsJsonNode.get(inputName).get(COT_ASSESSED_DATE).asText(),
                status.get(COT_ASSESSED_DATE).asText());
        Assert.assertEquals(
                inputsAsJsonNode.get(inputName).get(COT_ACCEPTED_DATE).asText(),
                status.get(COT_ACCEPTED_DATE).asText());
    }

    @Then("verify E-cot unhappy path using input {string}")
    public void verifyECotUnhappyPathUsingInput(String inputName) {
        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
        JsonNode status = responseJsonNode.get(STATUS);
        Assert.assertEquals(
                inputsAsJsonNode.get(inputName).get(COT_RECEIVED_DATE).asText(),
                status.get(COT_RECEIVED_DATE).asText());
        Assert.assertEquals(
                inputsAsJsonNode.get(inputName).get(COT_ASSESSED_DATE).asText(),
                status.get(COT_ASSESSED_DATE).asText());
        Assert.assertEquals(
                inputsAsJsonNode.get(inputName).get(COT_ACCEPTED_DATE).asText(),
                status.get(COT_ACCEPTED_DATE).asText());
    }

    @Then("Verify the valid application details returned for the nft input {string}")
    public void verifyTheValidApplicationDetailsReturnedForTheNftInput(String inputName) {
        JsonNode applications = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(applications.get(REFERENCE_NUMBER), responseJsonNode.get(REFERENCE_NUMBER));

        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

    }


    @Then("Verify FCA number, surname and postcode but with different first name and email address and both are allowed in CRM for the input {string}")
    public void verifyFCANumberSurnameAndPostcodeButWithDifferentFirstNameAndEmailAddressAndBothAreAllowedInCRMForTheInput(String inputName) {
        JsonNode applications = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(applications.get(REFERENCE_NUMBER), responseJsonNode.get(REFERENCE_NUMBER));

        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
    }


    @Then("Verify FCA number, surname and postcode but with different first name and email address and one is allowed in CRM while other one has left the firm for the input {string}")
    public void verifyFCANumberSurnameAndPostcodeButWithDifferentFirstNameAndEmailAddressAndOneIsAllowedInCRMWhileOtherOneHasLeftTheFirmForTheInput(String inputName) {
        JsonNode applications = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(applications.get(REFERENCE_NUMBER), responseJsonNode.get(REFERENCE_NUMBER));

        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);
    }

    @Then("Verify FCA number, surname and postcode but with different first name and email address one has left the firm for the input {string}")
    public void verifyFCANumberSurnameAndPostcodeButWithDifferentFirstNameAndEmailAddressOneHasLeftTheFirmForTheInput(String inputName) {
        Assertions.assertEquals(UNAUTHORIZED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGE).asText().contains(error_message_Array.asText()));
    }

    @Then("Verify fee has been Paid {string}")
    public void verifyFeeHasBeenPaid(String arg0) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Paid", productInformationDetails.get(FEE_STATUS).asText());
        Assertions.assertEquals("false", productInformationDetails.get(FEE_PENDING).asText());
    }

    @Then("Verify fee has been Free {string}")
    public void verifyFeeHasBeenFree(String arg0) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Free", productInformationDetails.get(FEE_STATUS).asText());
        Assertions.assertEquals("false", productInformationDetails.get(FEE_PENDING).asText());
    }

    @Then("Verify fee has been Added To Loan {string}")
    public void verifyFeeHasBeenAddedToLoan(String arg0) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Added to Loan", productInformationDetails.get(FEE_STATUS).asText());
        Assertions.assertEquals("false", productInformationDetails.get(FEE_PENDING).asText());
    }

    @Then("Verify fee has been To Be Paid On Completion {string}")
    public void verifyFeeHasBeenToBePaidOnCompletion(String arg0) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("To be paid on completion", productInformationDetails.get(FEE_STATUS).asText());
        Assertions.assertEquals("false", productInformationDetails.get(FEE_PENDING).asText());
    }

    @Then("Verify fee has been Outstanding {string}")
    public void verifyFeeHasBeenOutstanding(String arg0) {
        JsonNode productInformationDetails = responseJsonNode.get(PRODUCT_INFORMATION);
        Assertions.assertEquals("Outstanding", productInformationDetails.get(FEE_STATUS).asText());
        Assertions.assertEquals("true", productInformationDetails.get(FEE_PENDING).asText());
    }

    @Then("Verify the valid application details returned to the given broker details {string}")
    public void verifyTheValidApplicationDetailsReturnedToTheGivenBrokerDetails(String inputName) {
        JsonNode applications = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(applications.get(REFERENCE_NUMBER), responseJsonNode.get(REFERENCE_NUMBER));

        JsonNode applicationDetails = responseJsonNode.get(APPLICATION_DETAILS);
        Assertions.assertNotNull(applicationDetails, APPLICATION_DETAILS_NULL);

        JsonNode stageHistoryArray = applicationDetails.get(STAGE_HISTORY);
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistory = stageHistoryArray.get(0);
        String stageHistoryDescription = stageHistory.get(DESCRIPTION).asText();
        Assertions.assertNotNull(stageHistoryDescription, STAGE_HISTORY_CODE_NULL);

        JsonNode caseHistoryArray = stageHistory.get(CASE_HISTORY);
        Assertions.assertTrue(caseHistoryArray.isArray());

        JsonNode statusJsonNode = responseJsonNode.get(STATUS);
        String status = statusJsonNode.get(STATUS).asText();
        Assertions.assertNotNull(status, STATUS_NULL);
    }

    @Then("Verify bad request error response from application details for invalid broker first name {string}")
    public void verifyBadRequestErrorResponseFromApplicationDetailsForInvalidBrokerFirstName(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify bad request error response from application details for invalid broker last name {string}")
    public void verifyBadRequestErrorResponseFromApplicationDetailsForInvalidBrokerLastName(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }


    @Then("Verify application details returned bad request for a given invalid broker value {string}")
    public void verifyApplicationDetailsReturnedBadRequestForAGivenInvalidBrokerValue(String inputName) {
        validateBadRequest(responseJsonNode, inputName);
    }
}