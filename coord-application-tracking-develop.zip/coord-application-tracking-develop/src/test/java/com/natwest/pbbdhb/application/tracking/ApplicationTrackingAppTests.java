/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking;

import static com.natwest.pbbdhb.application.tracking.util.TestConstants.B;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.BOOKED_APPOINTMENT;
import static com.natwest.pbbdhb.application.tracking.util.TestConstants.Y;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.GMSTaskDescription;
import com.natwest.pbbdhb.application.tracking.model.MilestoneMappingInformation;
import com.natwest.pbbdhb.application.tracking.model.ValuationStatus;
import com.natwest.pbbdhb.application.tracking.service.GmsStageAndTaskLoader;
import com.natwest.pbbdhb.application.tracking.util.PropertiesReader;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTrackingAppTests {

    @Autowired GmsStageAndTaskLoader loader;

    @Autowired PropertiesReader reader;

    @Test
    void contextLoads() {
        GMSStageDescription description = loader.getStageDescription("20");
        assertEquals("Assessment", description.getStatus());
    }

    @Test
    void awaitTaskLoads() {
        boolean isAwait = loader.isAwaitTask("A29");

        assertTrue(isAwait);
    }

    @Test
    void assessTaskLoads() {
        boolean isAssess = loader.isAssessTask("R16");
        assertTrue(isAssess);
    }

    @Test
    void statusDescriptionLoads() {
        String RedStatus = loader.getStatusDescription("RED");

        assertEquals("Your client's application has been declined / cancelled", RedStatus);
    }

    @Test
    void testValuationStatus() {
        ValuationStatus valuationStatus = loader.getValuationStatus(B);

        assertEquals(Y, valuationStatus.getStatus());
        assertEquals(BOOKED_APPOINTMENT, valuationStatus.getDescription());
    }

    @Test
    void testGetMortgageTypeDescription() {
        String mortgageType = loader.getMortgageTypeDescription("A");
        assertEquals("Additional Borrowing", mortgageType);
    }

    @Test
    void testGetMortgageTypeDescriptionNullCase() {
        String mortgageType = loader.getMortgageTypeDescription(null);
        assertNull(mortgageType);
    }

    @Test
    void testGetMortgageTypeDescriptionNoMapping() {
        String mortgageType = loader.getMortgageTypeDescription("XX");
        assertNull(mortgageType);
    }

    @Test
    void testGetFeeStatusDescription() {
        String feeStatus = loader.getFeeStatusDescription("PP");
        assertEquals("Paid", feeStatus);
    }

    @Test
    void testGetFeeStatusDescriptionNullCase() {
        String feeStatus = loader.getFeeStatusDescription(null);
        assertNull(feeStatus);
    }

    @Test
    void testGetFeeStatusDescriptionNoMapping() {
        String feeStatus = loader.getFeeStatusDescription("XX");
        assertNull(feeStatus);
    }

    @Test
    void testGetTaskDescription() {
        GMSTaskDescription gmsTaskDescription = loader.getTaskDescription("AVR");
        assertEquals(
                "The valuation has been instructed.We will use the details provided to organise the valuation.",
                gmsTaskDescription.getDescription());
    }

    @Test
    void testGetMilestoneMappingInformation() {
        Map<String, MilestoneMappingInformation> milestoneMap =
                loader.getMilestoneMappingInformation();
        assertEquals("Assessment", milestoneMap.get("1").getDescription());
    }

    @Test
    void testIsAllowedTask() {
        boolean isAllowedTask = loader.isAllowedTask("AVR");
        assertTrue(isAllowedTask);
    }

    @Test
    void testIsAllowedStage() {
        boolean isAllowedStage = loader.isAllowedStage("20");
        assertTrue(isAllowedStage);
    }

    @Test
    void testGetProductSwitchMilestoneMappingInformation() {
        Map<String, MilestoneMappingInformation> milestoneMap =
                loader.getProductSwitchMilestoneMappingInformation();

        assertEquals("Product Switch", milestoneMap.get("1").getDescription());
    }

    @Test
    void testGetDummyTaskCode() {
        String taskCode = loader.getDummyTaskCode("40");
        assertEquals("D/40", taskCode);
    }

    @Test
    void testBrokerValidationFlag() {
        assertTrue(reader.getIsBrokerDetailValidateEndpointEnabled());
    }
}
