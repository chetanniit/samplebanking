/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getErrorMap;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getInvalidFirmBrokers;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.ReflectionTestUtils.setField;

import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerDetailValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerDetailValidationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.FirmBroker;
import com.natwest.pbbdhb.application.tracking.model.exception.BrokerValidationException;
import com.natwest.pbbdhb.application.tracking.service.impl.BrokerDetailValidationServiceImpl;
import com.natwest.pbbdhb.application.tracking.util.ErrorMessageConfigReader;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class BrokerDetailValidationServiceImplTest {
    private final String URL = "http://localhost:9001/brokerDetailValidation";
    @InjectMocks private BrokerDetailValidationServiceImpl service;
    @Mock private RestTemplate restTemplate;
    @Mock private ErrorMessageConfigReader errorMessageConfigReader;

    @BeforeEach
    void init() {
        setField(service, "brokerDetailValidationURL", URL, String.class);
    }

    @Test
    void testDetailValidateBroker() {
        BrokerDetailValidationRequest request = BrokerDetailValidationRequest.builder().build();

        Set<FirmBroker> firmBrokerSet = getInvalidFirmBrokers();

        BrokerDetailValidationResponse response =
                BrokerDetailValidationResponse.builder().brokers(firmBrokerSet).build();

        when(restTemplate.exchange(
                        eq(URL),
                        eq(HttpMethod.POST),
                        any(),
                        eq(BrokerDetailValidationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        BrokerDetailValidationResponse actualResponse = service.validateBroker(request);
        assertNotNull(actualResponse);
        assertEquals(2, actualResponse.getBrokers().size());
    }

    @Test
    void testDetailValidateBrokerException() {
        BrokerDetailValidationRequest request = BrokerDetailValidationRequest.builder().build();
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        when(restTemplate.exchange(
                        eq(URL),
                        eq(HttpMethod.POST),
                        any(),
                        eq(BrokerDetailValidationResponse.class)))
                .thenThrow(HttpClientErrorException.NotFound.class);
        BrokerValidationException brokerValidationException =
                assertThrows(
                        BrokerValidationException.class, () -> service.validateBroker(request));
        assertNotNull(brokerValidationException);
    }
}
