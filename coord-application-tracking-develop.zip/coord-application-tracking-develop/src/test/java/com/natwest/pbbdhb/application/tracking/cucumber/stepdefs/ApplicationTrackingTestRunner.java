/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.cucumber.stepdefs;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"classpath:features"},
        glue = {"com.natwest.pbbdhb.application.tracking.cucumber.stepdefs"},
        plugin = {
            "pretty",
            "html:target/cucumber-report/cucumber-reports.html",
            "json:target/cucumber-report/cucumber.json"
        },
        monochrome = true,
        //tags  = "@SmokeTest"
        tags = "@APIConstraintViolationError or @GetApplications or @GetApplicationDetails or @E-cot_ENV04 or @GetBrokerApplicationList"
        //tags  = "@NFT_GetApplications or @NFT_GetApplicationDetails"
        //@E-cot_ENV04 this tag need to run only when db points to ENV 04

        )
public class ApplicationTrackingTestRunner {

    @BeforeClass
    public static void buildConfigSetUp() throws ClassNotFoundException {
        Class.forName(
                "com.natwest.pbbdhb.application.tracking.cucumber.config.BuildVersionConfigWriter");
    }
}
