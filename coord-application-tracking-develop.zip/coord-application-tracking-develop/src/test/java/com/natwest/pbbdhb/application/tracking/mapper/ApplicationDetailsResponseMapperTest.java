/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.mapper;

import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getApplicantInformation;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getApplicationDetails;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getProductInfo;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getSolicitorInformation;
import static com.natwest.pbbdhb.application.tracking.util.TestUtil.getValuationInformation;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.ApplicationDetailsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.CaseHistoryDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.DocumentRequiredFor;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.GranularTrackingDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.GranularTracking;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInformation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.ZonedDateTime;
import java.util.Collections;

@ExtendWith(MockitoExtension.class)
public class ApplicationDetailsResponseMapperTest {

    @InjectMocks private ApplicationDetailsResponseMapperImpl mapper;

    @Test
    void TestToApplicationDetailsResponse() {
        ApplicationDetailsInfo applicationDetailsInfo =
                ApplicationDetailsInfo.builder()
                        .productInformation(getProductInfo())
                        .applicantInformation(getApplicantInformation())
                        .applicationDetails(getApplicationDetails())
                        .valuationInformation(getValuationInformation())
                        .solicitorInformation(getSolicitorInformation())
                        .build();
        ApplicationDetailsResponse applicationDetailsResponse =
                mapper.toApplicationDetailsResponse(applicationDetailsInfo);

        assertNotNull(applicationDetailsResponse);
    }

    @Test
    void TestToApplicationDetailsResponseNegative() {

        ApplicationDetailsResponse applicationDetailsResponse =
                mapper.toApplicationDetailsResponse(null);

        assertNull(applicationDetailsResponse);
    }

    @Test
    void testToGranularTrackingDetail() {
        GranularTracking granularTracking = GranularTracking.builder().category("Payslip")
                .count("3")
                .frequency("Monthly")
                .dueDate("2023-01-01")
                .fromDate("2023-04-04")
                .toDate("2023-02-02")
                .purpose(Collections.singletonList("Payrise"))
                .requestedDate(ZonedDateTime.now())
                .requiredFor(Collections.singletonList(DocumentRequiredFor.builder().applicantName("Jone").build()))
                .reRequestReason(Collections.singletonList("Verification"))
                .state("Open").build();
        GranularTrackingDetail granularTrackingDetail = mapper.toGranularTrackingDetail(granularTracking);
        assertNotNull(granularTrackingDetail);
    }

    @Test
    void testToGranularTrackingDetailNull() {
        GranularTrackingDetail granularTrackingDetail = mapper.toGranularTrackingDetail(null);
        assertNull(granularTrackingDetail);
    }

    @Test
    void testToGranularTrackingDetailEmptyObject() {
        GranularTrackingDetail granularTrackingDetail = mapper.toGranularTrackingDetail(GranularTracking.builder().build());
        assertNotNull(granularTrackingDetail);
    }

    @Test
    void testToProductInformationNull() {
        ProductInformation productInformation = mapper.toProductInformation(null);
        assertNull(productInformation);
    }

    @Test
    void testToProductInformationEmptyObject() {
        ProductInformation productInformation = mapper.toProductInformation(ProductInfo.builder().build());
        assertNotNull(productInformation);
    }

    @Test
    void testToProductInformationFeePendingFalse() {
        ProductInformation productInformation = mapper.toProductInformation(getProductInfo());
        assertNotNull(productInformation);
        assertFalse(productInformation.isFeePending());
    }

    @Test
    void testToProductInformationFeePendingTrue() {
        ProductInfo productInfo = getProductInfo();
        productInfo.setFeeStatus("Outstanding");
        ProductInformation productInformation = mapper.toProductInformation(productInfo);
        assertNotNull(productInformation);
        assertTrue(productInformation.isFeePending());
    }

    @Test
    void testToCaseHistoryDetail() {
        CaseHistoryDetail caseHistoryDetail = mapper.toCaseHistoryDetail(CaseHistory.builder().build(), "Await");
        assertNotNull(caseHistoryDetail);
        assertEquals("Await", caseHistoryDetail.getCategory());
    }

    @Test
    void testToCaseHistoryDetailNull() {
        CaseHistoryDetail caseHistoryDetail = mapper.toCaseHistoryDetail(null, null);
        assertNull(caseHistoryDetail);
    }

    @Test
    void testToCaseHistoryDetailCategoryNull() {
        CaseHistoryDetail caseHistoryDetail = mapper.toCaseHistoryDetail(CaseHistory.builder().build(), null);
        assertNotNull(caseHistoryDetail);
        assertNull(caseHistoryDetail.getCategory());
    }

    @Test
    void testToCaseHistoryDetailCaseHistoryNull() {
        CaseHistoryDetail caseHistoryDetail = mapper.toCaseHistoryDetail(null, "Await");
        assertEquals("Await", caseHistoryDetail.getCategory());
    }
}
