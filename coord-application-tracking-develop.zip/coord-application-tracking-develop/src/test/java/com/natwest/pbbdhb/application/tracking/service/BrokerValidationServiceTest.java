/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.ReflectionTestUtils.setField;

import com.natwest.pbbdhb.application.tracking.model.dto.request.BrokerValidationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.BrokerValidationResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class BrokerValidationServiceTest {

    @InjectMocks private BrokerValidationService service;

    @Mock private RestTemplate restTemplate;

    private final String URL = "http://localhost:9001/brokerValidation";

    @BeforeEach
    void init() {
        setField(service, "brokerValidationURL", URL, String.class);
    }

    @Test
    void testValidateBroker() {
        BrokerValidationRequest request = BrokerValidationRequest.builder().build();
        BrokerValidationResponse response =
                BrokerValidationResponse.builder().allowMortgageBusiness(true).build();
        when(restTemplate.exchange(
                        eq(URL), eq(HttpMethod.POST), any(), eq(BrokerValidationResponse.class)))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        BrokerValidationResponse actualResponse = service.validateBroker(request);

        assertEquals(response.isAllowMortgageBusiness(), actualResponse.isAllowMortgageBusiness());
        assertTrue(actualResponse.isAllowMortgageBusiness());
    }
}
