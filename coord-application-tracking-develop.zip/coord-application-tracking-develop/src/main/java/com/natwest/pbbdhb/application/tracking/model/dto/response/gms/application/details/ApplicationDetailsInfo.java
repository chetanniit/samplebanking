/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_FORMAT_YYYYMMDD;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.ApplicationDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.Applicant;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.PropertyInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.SolicitorInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.SourceInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.valuation.ValuationInformation;
import java.util.Date;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class ApplicationDetailsInfo {

    private ProductInfo productInformation;
    private SolicitorInformation solicitorInformation;
    private List<Applicant> applicantInformation;
    private PropertyInfo propertyInformation;
    private SourceInformation sourceInformation;
    private ApplicationDetails applicationDetails;
    private ValuationInformation valuationInformation;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT_YYYYMMDD)
    private Date expectedCompletionDate;
}
