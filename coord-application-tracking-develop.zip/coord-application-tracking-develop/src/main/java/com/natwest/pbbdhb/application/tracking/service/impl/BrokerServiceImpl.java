/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service.impl;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DEFAULT_PAGE_NUMBER;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DEFAULT_RESULT_PER_PAGE;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DEFAULT_SORT_BY;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DEFAULT_SORT_ORDER;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.INVALID_MANDATORY_APPLICANT_DETAILS;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.validate;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.APPLICATIONS;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.GMS_APPLICATIONS;
import static com.natwest.pbbdhb.application.tracking.util.ErrorConstant.GMS_BROKER_APPLICATIONS_SEARCH;
import static com.natwest.pbbdhb.application.tracking.util.RestAPIUtil.getHeader;
import static com.natwest.pbbdhb.application.tracking.util.RestAPIUtil.populateRequestParams;
import static com.natwest.pbbdhb.application.tracking.util.RestAPIUtil.populateRequestParamsForBrokerApplicationSearch;

import com.natwest.pbbdhb.application.tracking.mapper.GmsApplicationResponseMapper;
import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Application;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListAPIResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Status;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.GmsApplicationResponse;
import com.natwest.pbbdhb.application.tracking.model.exception.InvalidApplicantDetailsException;
import com.natwest.pbbdhb.application.tracking.service.BrokerService;
import com.natwest.pbbdhb.application.tracking.service.GmsStageAndTaskLoader;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class BrokerServiceImpl implements BrokerService {

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired private GmsApplicationResponseMapper mapper;

    @Value("${ms.msvc.applications.endpoint:}")
    private String msvcApplicationEndpoint;

    @Value(("${ms.broker.applications.endpoint:}"))
    private String brokerApplicationsEndpoint;
    
    @Value(("${ms.broker.application.list.endpoint:}"))
    private String brokerApplicationListEndpoint;

    @Value("${ms.broker.applications.search.endpoint:}")
    private String brokerApplicationSearchEndpoint;

    @Autowired private GmsStageAndTaskLoader stageLoader;

    @Override
    public ApplicationsResponse getApplications(
            String brand, ApplicationRequest applicationRequest) {
        populatePaginationValues(applicationRequest);

        if ((Objects.nonNull(applicationRequest)
                && ObjectUtils.anyNotNull(
                        applicationRequest.getApplicantFirstName(),
                        applicationRequest.getApplicantDob(),
                        applicationRequest.getApplicantLastName(),
                        applicationRequest.getPropertyPostcode()))) {
            checkIfApplicantDetailsProvided(applicationRequest);
            return invokeBrokerSearch(brand, applicationRequest);
        }

        return invokeApplications(brand, applicationRequest);
    }
    
    
    @Override
    public ApplicationListResponse getApplicationList(
            String brand, ApplicationListRequest applicationListRequest) {
        populatePaginationValues(applicationListRequest);

        return invokeApplicationList(brand, applicationListRequest);
    }

    private ApplicationsResponse invokeApplications(
            String brand, ApplicationRequest applicationRequest) {
        log.info("call GetApplications service");
        UriComponentsBuilder builder =
                UriComponentsBuilder.fromHttpUrl(
                        msvcApplicationEndpoint + brokerApplicationsEndpoint);
        populateRequestParams(applicationRequest, builder);
        log.debug("getApplications URL {} ", builder.toUriString());
        GmsApplicationResponse response =
                getResponse(builder, brand, APPLICATIONS, GMS_APPLICATIONS);
        ApplicationsResponse applicationsResponse = mapper.toApplicationsResponse(response);
        populateStatus(applicationsResponse);

        return applicationsResponse;
    }
    
    private ApplicationListResponse invokeApplicationList(
            String brand, ApplicationListRequest applicationListRequest) {
        log.info("Calling GetApplicationList service");
        UriComponentsBuilder builder =
                UriComponentsBuilder.fromHttpUrl(
                        msvcApplicationEndpoint + brokerApplicationListEndpoint);
        populateRequestParams(applicationListRequest, builder);
        log.debug("getApplicationList URL {} ", builder.toUriString());
        ApplicationListAPIResponse apiResponse = getApplicationListResponse(builder, brand, APPLICATIONS, GMS_APPLICATIONS);
        return mapper.toApplicationListResponse(apiResponse);
    }

    private void populateStatus(ApplicationsResponse response) {
        if (Objects.isNull(response.getApplications())) {
            return;
        }

        for (Application application : response.getApplications()) {
            Status status = application.getStatus();
            String stageNo = status.getStatus();
            GMSStageDescription stageDescription = stageLoader.getStageDescription(stageNo);
            stageDescription = validate(stageDescription, status.getStatus());
            log.debug("GMSStageDescription : {}", stageDescription);
            status.setStatus(stageDescription.getStatus());
            status.setStatusDescription(stageDescription.getStatusDetail());
        }
    }

    private ApplicationsResponse invokeBrokerSearch(
            String brand, ApplicationRequest applicationRequest) {
        log.info("call brokerApplicationSearch service");
        UriComponentsBuilder builder =
                UriComponentsBuilder.fromHttpUrl(
                        msvcApplicationEndpoint + brokerApplicationSearchEndpoint);
        populateRequestParamsForBrokerApplicationSearch(applicationRequest, builder);
        log.debug("brokerApplicationSearch URL {} ", builder.toUriString());
        ApplicationsResponse applicationsResponse =
                mapper.toApplicationsResponse(
                        getResponse(builder, brand, APPLICATIONS, GMS_BROKER_APPLICATIONS_SEARCH));
        populateStatus(applicationsResponse);

        return applicationsResponse;
    }

    private GmsApplicationResponse getResponse(
            UriComponentsBuilder builder, String brand, String origin, String destination) {
        log.debug("URL {} ", builder.toUriString());
        ResponseEntity<GmsApplicationResponse> response =
                restTemplate.exchange(
                        builder.build().encode().toUri(),
                        HttpMethod.GET,
                        getHeader(brand, origin, destination),
                        GmsApplicationResponse.class);
        log.debug("response : {}", response.getBody());
        return response.getBody();
    }
    
    
    private ApplicationListAPIResponse getApplicationListResponse(
            UriComponentsBuilder builder, String brand, String origin, String destination) {
        log.debug("URL {} ", builder.toUriString());
        ResponseEntity<ApplicationListAPIResponse> response =
                restTemplate.exchange(
                        builder.build().encode().toUri(),
                        HttpMethod.GET,
                        getHeader(brand, origin, destination),
                        ApplicationListAPIResponse.class);
        log.debug("response : {}", response.getBody());
        return response.getBody();
    }
    
    
    
    private void populatePaginationValues(ApplicationRequest applicationRequest) {
        applicationRequest.setResultPerPage(
                Optional.ofNullable(applicationRequest.getResultPerPage())
                        .orElse(DEFAULT_RESULT_PER_PAGE));
        applicationRequest.setPageNumber(
                Optional.ofNullable(applicationRequest.getPageNumber())
                        .orElse(DEFAULT_PAGE_NUMBER));
        applicationRequest.setSortBy(
                Optional.ofNullable(applicationRequest.getSortBy()).orElse(DEFAULT_SORT_BY));
        applicationRequest.setSortOrder(
                Optional.ofNullable(applicationRequest.getSortOrder()).orElse(DEFAULT_SORT_ORDER));
    }
    
    
    private void populatePaginationValues(ApplicationListRequest applicationListRequest) {
        applicationListRequest.setResultPerPage(
                Optional.ofNullable(applicationListRequest.getResultPerPage())
                        .orElse(DEFAULT_RESULT_PER_PAGE));
        applicationListRequest.setPageNumber(
                Optional.ofNullable(applicationListRequest.getPageNumber())
                        .orElse(DEFAULT_PAGE_NUMBER));
        applicationListRequest.setSortBy(
                Optional.ofNullable(applicationListRequest.getSortBy()).orElse(DEFAULT_SORT_BY));
        applicationListRequest.setSortOrder(
                Optional.ofNullable(applicationListRequest.getSortOrder()).orElse(DEFAULT_SORT_ORDER));
    }
    

    private void checkIfApplicantDetailsProvided(ApplicationRequest applicationRequest) {
        if (ObjectUtils.anyNull(
                applicationRequest.getApplicantLastName(),
                applicationRequest.getPropertyPostcode())) {
            throw new InvalidApplicantDetailsException(INVALID_MANDATORY_APPLICANT_DETAILS);
        }
    }
}
