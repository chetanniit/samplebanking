/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.applications;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.DATE_FORMAT;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.UK_TIME_ZONE;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
public class Source implements Serializable{    

    private static final long serialVersionUID = -1543581523738613507L;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT, timezone = UK_TIME_ZONE)
    private Date submissionDate;

    private String applicationType;
    
    private String loanPurpose;
}
