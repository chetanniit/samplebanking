/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.NameCapitaliseSerializer;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class Applicant {
    private String title;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String firstName;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String middleName;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String lastName;

    private String dob;
    private String isMainApplicant;
    private Contact contact;
    private AddressInfo address;
}
