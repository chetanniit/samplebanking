/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response;

import java.sql.Timestamp;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class FirmBroker {
    private String brokerID;

    private String firmName;

    private String firmID;

    private String fcaNumber;

    private String firmPostcode;

    private String brokerPostcode;

    private String brokerSurname;

    private String firmStatus;

    private String brokerStatus;

    private String acceptMortgageBusiness;

    private String principleFcaNumber;

    private String firmAddress1;

    private String firmAddress2;

    private String firmAddress3;

    private String firmAddress4;

    private String firmAddress5;

    private String brokerForeName;

    private String brokerEmail;

    private String brokerTelephoneNumber;

    private Timestamp statusDate;
}
