/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.validator.format;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.INVALID_USER_EMAIL_ID;

import com.natwest.pbbdhb.application.tracking.validator.AdminEmailFormatValidator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = AdminEmailFormatValidator.class)
public @interface AdminEmailConstraint {

    String message() default INVALID_USER_EMAIL_ID;

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
