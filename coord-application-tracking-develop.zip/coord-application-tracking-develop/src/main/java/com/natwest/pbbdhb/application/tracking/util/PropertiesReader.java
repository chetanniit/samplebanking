/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import java.util.List;
import javax.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Data
public class PropertiesReader {

    @Value("${completed.application.suppress.days:14}")
    private int completedApplicationSuppressDays;

    @Value("${declined.application.suppress.days:14}")
    private int declinedApplicationSuppressDays;

    @Value("${refused.application.suppress.days:14}")
    private int refusedApplicationSuppressDays;

    @Value("#{'${application.suppress.stages:80,84,85,90}'.split(',')}")
    private List<String> applicationSuppressStageList;

    @Value("${gms.suppress451Error:N}")
    private String suppress451Error;

    @Value("${gms.systemDate:null}")
    private String systemDate;

    @Value("${broker.detail.validate.endpoint.enable:false}")
    private Boolean isBrokerDetailValidateEndpointEnabled;

    @Value("${add.broker.user.name.to.detail.validate.endpoint:true}")
    private Boolean isAddBrokerUserNameToDetailValidateEndpoint;

    @PostConstruct
    public void print() {
        log.info("properties are loaded with values :{}", this);
    }
}
