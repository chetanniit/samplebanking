/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.mapper;

import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Address;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicantInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Application;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListAPIResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationListResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.ApplicationsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.PropertyInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.applications.Status;
import com.natwest.pbbdhb.application.tracking.model.dto.response.common.Page;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.ApplicantDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.GmsApplicationResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.MortgageInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.PageDetail;
import java.util.List;
import java.util.Set;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(config = MappingConfig.class)
public interface GmsApplicationResponseMapper {

    @Mapping(target = "page", expression = "java(toPage(gmsApplicationResponse.getPage()))")
    @Mapping(
            target = "applications",
            expression = "java(toApplication(gmsApplicationResponse.getApplications()))")
    ApplicationsResponse toApplicationsResponse(GmsApplicationResponse gmsApplicationResponse);
    
    @Mapping(target = "page", expression = "java(toPage(applicationListResponse.getPage()))")
    ApplicationListResponse toApplicationListResponse(ApplicationListAPIResponse applicationListResponse);

    @Mapping(target = "size", expression = "java(pageDetail.getResultPerPage())")
    @Mapping(target = "totalElements", expression = "java(pageDetail.getTotalCount())")
    @Mapping(target = "totalPages", expression = "java(pageDetail.getTotalPages())")
    @Mapping(target = "number", expression = "java(pageDetail.getCurrentPageNumber())")
    Page toPage(PageDetail pageDetail);

    @Mapping(
            target = "applicantInformation",
            expression = "java(toApplicantInformation(mortgageInformation.getApplicantDetail()))")
    @Mapping(
            target = "propertyInformation",
            expression = "java(toPropertyInformation(mortgageInformation))")
    @Mapping(target = "status", expression = "java(toStatus(mortgageInformation))")
    Application toApplication(MortgageInformation mortgageInformation);

    List<Application> toApplication(List<MortgageInformation> mortgageInformation);

    ApplicantInformation toApplicantInformation(ApplicantDetail applicantDetail);

    List<ApplicantInformation> toApplicantInformation(Set<ApplicantDetail> applicantDetail);

    @Mapping(target = "postCode", expression = "java(mortgageInformation.getPropertyPostcode())")
    Address toAddress(MortgageInformation mortgageInformation);

    @Mapping(target = "address", expression = "java(toAddress(mortgageInformation))")
    PropertyInformation toPropertyInformation(MortgageInformation mortgageInformation);

    @Mapping(
            target = "submissionDate",
            expression = "java(mortgageInformation.getSubmissionDate())")
    @Mapping(target = "lastUpdatedDate", expression = "java(mortgageInformation.getUpdatedDate())")
    @Mapping(target = "status", source = "mortgageInformation", qualifiedByName = "getStageNumber")
    Status toStatus(MortgageInformation mortgageInformation);

    @Named("getStageNumber")
    static String getStageNumber(MortgageInformation mortgageInformation) {
        int stageNo = mortgageInformation.getStageNumber();
        // Due to staegNo as Integer, me miss the appending zero in response, hence need to append
        // zero as string
        return stageNo < 10 ? "0" + stageNo : Integer.toString(stageNo);
    }
}
