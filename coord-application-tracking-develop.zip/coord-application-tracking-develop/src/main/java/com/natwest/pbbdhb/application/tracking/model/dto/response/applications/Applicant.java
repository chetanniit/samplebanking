/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.applications;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.natwest.pbbdhb.application.tracking.json.NameCapitaliseSerializer;

import java.io.Serializable;
import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class Applicant implements Serializable{

    private static final long serialVersionUID = -5593110465126694837L;

    private String title;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String firstName;

    @JsonSerialize(using = NameCapitaliseSerializer.class, as = String.class)
    private String lastName;

    private String isMainApplicant;
    
    private String emailAddress;
}
