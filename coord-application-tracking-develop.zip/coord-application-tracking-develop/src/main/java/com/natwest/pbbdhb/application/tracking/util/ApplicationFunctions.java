package com.natwest.pbbdhb.application.tracking.util;

import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import org.apache.commons.collections.CollectionUtils;

import java.util.Objects;
import java.util.function.Predicate;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.OPEN;

public final class ApplicationFunctions {

    private ApplicationFunctions() {
    }

    public static final Predicate<ApplicationDetailsInfo> isAnyNullObjectPresent =
            applicationDetailsInfo -> Objects.isNull(applicationDetailsInfo)
                    || Objects.isNull(applicationDetailsInfo.getApplicationDetails())
                    || CollectionUtils.isEmpty(applicationDetailsInfo.getApplicationDetails().getCaseHistory())
                    || CollectionUtils.isEmpty(applicationDetailsInfo.getApplicationDetails().getGranularTracking());

    public static final Predicate<ApplicationDetailsInfo> isOpenFIPresent =
            applicationDetailsInfo -> applicationDetailsInfo.getApplicationDetails().getGranularTracking()
                    .stream().anyMatch(granularTracking -> OPEN.equalsIgnoreCase(granularTracking.getState()));
}
