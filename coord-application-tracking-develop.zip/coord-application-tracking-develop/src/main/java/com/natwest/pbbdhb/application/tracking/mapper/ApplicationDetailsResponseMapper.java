/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.mapper;

import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.ApplicationDetailsResponse;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.CaseHistoryDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.GranularTrackingDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.StatusDetail;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.ApplicationDetails;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.CaseHistory;
import java.util.List;
import java.util.Objects;

import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.history.GranularTracking;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInformation;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.PRODUCT_FEE_STATUS_OUTSTANDING;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.SPACE;

@Mapper(config = MappingConfig.class)
public interface ApplicationDetailsResponseMapper {

    @Mapping(
            target = "status",
            expression = "java(toStatus(applicationDetailsInfo.getApplicationDetails()))")
    ApplicationDetailsResponse toApplicationDetailsResponse(
            ApplicationDetailsInfo applicationDetailsInfo);

    /**
     * Mapper to map StatusDetail fields from application details object
     *
     * @param applicationDetails - ApplicationDetails
     * @return StatusDetail
     */
    @Mapping(
            target = "submissionDate",
            expression = "java(applicationDetails.getStatus().getSubmissionDate())")
    @Mapping(
            target = "lastUpdatedDate",
            expression = "java(applicationDetails.getStatus().getLastUpdateDate())")
    @Mapping(target = "status", expression = "java(applicationDetails.getStatus().getStatus())")
    @Mapping(
            target = "statusDescription",
            expression = "java(applicationDetails.getStatus().getStatusDescription())")
    @Mapping(
            target = "completionDate",
            expression = "java(applicationDetails.getStatus().getCompletionDate())")
    @Mapping(
            target = "declinedDate",
            expression = "java(applicationDetails.getStatus().getDeclinedDate())")
    @Mapping(
            target = "refusedDate",
            expression = "java(applicationDetails.getStatus().getRefusedDate())")
    @Mapping(
            target = "ragStatus",
            expression = "java(applicationDetails.getStatus().getRagStatus())")
    @Mapping(
            target = "ragDescription",
            expression = "java(applicationDetails.getStatus().getRagDescription())")
    @Mapping(
            target = "subStatus",
            expression = "java(applicationDetails.getStatus().getSubStatus())")
    @Mapping(
            target = "subStatusDescription",
            expression = "java(applicationDetails.getStatus().getSubStatusDescription())")
    StatusDetail toStatus(ApplicationDetails applicationDetails);

    List<CaseHistoryDetail> toCaseHistory(List<CaseHistory> caseHistory);

    @Mapping(target = "timeOpen", source = "openDateTime")
    @Mapping(target = "timeClosed", source = "closedDateTime")
    CaseHistoryDetail toCaseHistory(CaseHistory caseHistory);

    /**
     * To convert CaseHistory to CaseHistoryDetail
     *
     * @param caseHistory - caseHistory
     * @param category    - category
     * @return CaseHistoryDetail
     */
    @Mapping(target = "timeOpen", source = "caseHistory.openDateTime")
    @Mapping(target = "timeClosed", source = "caseHistory.closedDateTime")
    @Mapping(target = "category", source = "category")
    CaseHistoryDetail toCaseHistoryDetail(CaseHistory caseHistory, String category);

    /**
     * Mapper to convert GranularTracking to GranularTrackingDetail
     *
     * @param granularTracking - granularTracking
     * @return GranularTrackingDetail - GranularTrackingDetail
     */
    @Mapping(target = "timePeriod", expression = "java(getTimePeriod(granularTracking))")
    GranularTrackingDetail toGranularTrackingDetail(GranularTracking granularTracking);

    /**
     * To populate time period
     *
     * @param granularTracking - granularTracking
     * @return time period
     */
    default String getTimePeriod(GranularTracking granularTracking) {
        if (Objects.isNull(granularTracking.getCount()) || "0".equalsIgnoreCase(granularTracking.getCount())) {
            return granularTracking.getFrequency();
        } else {
            return granularTracking.getCount() + SPACE + granularTracking.getFrequency();
        }
    }

    @Mapping(target = "feePending", expression = "java(setFeePending(productInfo))")
    ProductInformation toProductInformation(ProductInfo productInfo);

    /**
     * This method is used to populate value for Fee pending field
     *
     * @param productInfo - object
     * @return boolean
     */
    default boolean setFeePending(ProductInfo productInfo) {
        return Objects.nonNull(productInfo) && StringUtils.isNotEmpty(productInfo.getFeeStatus()) && PRODUCT_FEE_STATUS_OUTSTANDING.equalsIgnoreCase(productInfo.getFeeStatus()) ? true : false;
    }
}
