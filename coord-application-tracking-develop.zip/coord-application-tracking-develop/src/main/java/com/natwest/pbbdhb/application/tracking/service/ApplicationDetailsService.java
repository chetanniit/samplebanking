/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationDetailRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.details.ApplicationDetailsInfo;
import java.util.concurrent.CompletableFuture;
import org.springframework.http.ResponseEntity;

public interface ApplicationDetailsService {
    ResponseEntity<String> getApplicationInfo(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest);

    CompletableFuture<ResponseEntity<String>> getApplicationDetail(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest);

    CompletableFuture<ResponseEntity<String>> getValuationInformation(
            String brand,
            String referenceNumber,
            ApplicationDetailRequest applicationDetailRequest);

    void populateApplicationRagStatus(
            ApplicationDetailsInfo detailsInfo, boolean isProductSwitchApp);

    void populateApplicationSubStatus(
            ApplicationDetailsInfo detailsInfo, boolean isProductSwitchApp);
}
