/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.exception;

public class GMSStageNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public GMSStageNotFoundException(String message) {
        super(message);
    }
}
