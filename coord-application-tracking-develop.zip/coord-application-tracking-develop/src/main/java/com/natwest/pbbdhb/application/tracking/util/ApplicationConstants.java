/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;

public class ApplicationConstants {

    public static final String LAST_MODIFIED_DATE = "Last Modified Date";
    public static final String SUBMISSION_DATE = "Submission Date";
    public static final String STATUS = "Status";
    public static final String SORT_BY_ALLOWED_VALUES =
            LAST_MODIFIED_DATE + "," + SUBMISSION_DATE + "," + STATUS;

    public static final String ASC = "Asc";
    public static final String DESC = "Desc";
    public static final String SORT_ORDER_ALLOWED_VALUES = ASC + "," + DESC;

    public static final String LAST_WEEK = "LastWeek";
    public static final String LAST_MONTH = "LastMonth";
    public static final String LAST_THREE_MONTH = "LastThreeMonth";
    public static final String ALL = "All";
    public static final String DATE_RANGE_ALLOWED_VALUES =
            LAST_WEEK + "," + LAST_MONTH + "," + LAST_THREE_MONTH + "," + ALL;
    public static final String RESULT_PER_PAGE_ALLOWED_VALUES = "5,10,15,20,50";

    public static final String SPACE = " ";
    public static final String SPACE_HYPHEN_DELIMITER = " - ";
    public static final String SPACE_COMMA_DELIMITER = " , ";
    public static final String UK_TIME_ZONE = "Europe/London";
    public static final String UTC_TIME_ZONE = "UTC";
    public static final ZoneId LONDON_ZONE = ZoneId.of(UK_TIME_ZONE);

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    public static final String BRAND = "brand";
    public static final String CALLER = "caller";
    public static final String EXTERNAL = "EXTERNAL";
    public static final String DWS_CORRELATION_ID = "dws-correlation-id";
    public static final String DWS_REQUEST_CORRELATION_ID = "dws-request-correlation-id";

    public static final String INVALID_BRAND = "brand name";
    public static final String INVALID_FIRM_NAME = "firm name";
    public static final String INVALID_FIRM_POST_CODE = "firm postcode";
    public static final String INVALID_BROKER_FIRST_NAME = "broker first name";
    public static final String INVALID_BROKER_LAST_NAME = "broker last name";
    public static final String INVALID_BROKER_USER_NAME = "broker user name";
    public static final String INVALID_BROKER_POST_CODE = "broker post code";
    public static final String INVALID_DATE_RANGE = "date range";
    public static final String INVALID_PAGE_NUMBER = "page number";
    public static final String INVALID_APPLICANT_FIRST_NAME = "applicant first name";
    public static final String INVALID_APPLICANT_LAST_NAME = "applicant last name";
    public static final String INVALID_RESULT_PER_PAGE = "resultPerPage number";
    public static final String INVALID_SORT_BY = "sortBy";
    public static final String INVALID_SORT_ORDER = "sortOrder";
    public static final String INVALID_PROPERTY_POST_CODE = "property postcode";
    public static final String INVALID_DOB = "dob";
    public static final String INVALID_FCA_NUMBER = "fca number";
    public static final String INVALID_EMAIL_ID = "email id";
    public static final String INVALID_REFERENCE_NUMBER = "reference number";
    public static final String INVALID_USER_FIRST_NAME = "user first name";
    public static final String INVALID_USER_LAST_NAME = "user last name";
    public static final String INVALID_USER_FCA_NUMBER = "user firm fca number";
    public static final String INVALID_USER_PRINCIPAL_FCA_NUMBER = "user principal fca number";
    public static final String INVALID_USER_EMAIL_ID = "user email id";
    public static final String INVALID_MANDATORY_APPLICANT_DETAILS =
            "Please provide both applicant last name and property postcode to perform search";
    public static final String DEFAULT_DATE_RANGE = "LastWeek";
    public static final String DEFAULT_PAGE_NUMBER = "1";
    public static final String DEFAULT_RESULT_PER_PAGE = "10";
    public static final String DEFAULT_SORT_ORDER = "Desc";
    public static final String DEFAULT_SORT_BY = "Last Modified Date";

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mmxxx";

    public static final String EMAIL_ID = "emailId";
    public static final String FCA_NUMBER = "fcaNumber";
    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String PAGE_NUMBER = "pageNumber";
    public static final String RESULT_PER_PAGE = "resultPerPage";
    public static final String SORT_BY = "sortBy";
    public static final String BROKER_EMAIL_ID = "brokerEmailId";
    public static final String BROKER_FIRST_NAME = "brokerFirstName";
    public static final String BROKER_USER_NAME = "brokerUserName";
    public static final String BROKER_LAST_NAME = "brokerLastName";
    public static final String BROKER_POSTCODE = "brokerPostcode";
    public static final String FIRM_NAME = "firmName";
    public static final String FIRM_POSTCODE = "firmPostcode";
    public static final String PROPERTY_POSTCODE = "propertyPostcode";
    public static final String DATE_RANGE = "dateRange";
    public static final String SORT_ORDER = "sortOrder";

    public static final String APPLICANT_FIRST_NAME = "applicantFirstName";
    public static final String APPLICANT_LAST_NAME = "applicantLastName";
    public static final String APPLICANT_DOB = "applicantDob";
    public static final String POSTCODE = "postcode";

    public static final String USER_FIRST_NAME = "userFirstName";
    public static final String USER_LAST_NAME = "userLastName";
    public static final String USER_FIRM_FCA_NUMBER = "userFirmFCANumber";
    public static final String USER_ROLE = "userRole";
    public static final String USER_PRINCIPAL_FCA_NUMBER = "userPrincipalFCANumber";
    public static final String USER_EMAIL = "userEmailId";

    public static final String FROM_DATE = "fromDate";
    public static final String TO_DATE = "toDate";

    public static final String IS_ACTION_REQUIRED = "actionRequired";

    public static final String VALID_BRANDS = "(RBS|NWB|rbs|nwb)";
    public static final String VALID_DATE_RANGE = "(LastWeek|LastMonth|LastThreeMonth|All)";
    public static final String VALID_SORT_BY = "(Last Modified Date|Submission Date|Status)";
    public static final String VALID_SORT_ORDER = "(Asc|Desc)";
    public static final String DATE_PATTERN = "^\\d{4}-\\d{2}-\\d{2}$";
    public static final String VALIDATE_POST_CODE =
            "^(([A-Z]{1,2}[0-9R][0-9A-Z]?\\s{0,1}[0-9][ABD-HJLNP-UW-Z]{2})|([A-Z]{1,2}[0-9R][0-9A-Z]?)|([0-9][ABD-HJLNP-UW-Z]{2}))$";
    public static final String EMAIL_PATTERN = "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$";

    public static final String ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS = "\\d{1,10}";
    public static final String
            ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MIN_TWO_MAX_OF_FIFTY_CHARACTERS =
            "^([A-Za-z'\"\\s-]){2,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_OF_FIFTY_CHARACTERS =
            "^([A-Za-z'\"\\s-]){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_OF_HUNDRED_CHARACTERS =
            "^([A-Za-z'\"\\s-]){1,100}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_OF_320_CHARACTERS =
            "^([ A-Za-z0-9_@&£$€¥#().,:;\"!+/'ë-]){1,320}$";
    public static final String ALLOW_ALPHABETS_AND_NUMBERS_AND_ATLEAST_TWO_AND_MAX_HUNDRED_CHARACTERS =
            "^[A-Za-z0-9]{2,100}+$";
    public static final String ALLOW_ALPHABETS_AND_NUMBERS_SPECIAL_CHAR_AND_MIN_OF_TWO_AND_MAX_OF_FIFTY_CHAR = "^[A-Za-z0-9 .'-]{2,50}+$";

    public static final String ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS = "^\\d{1,2}$";

    public static final String REFERENCE_NUMBER = "referenceNumber";

    public static final String APPLICATION_DETAILS_REQUEST_PROCESSING_FAIL_ERROR_MESSAGE =
            "Error occurred while processing the request,please try again later.";

    public static final String AMBER = "AMBER";
    public static final String RED = "RED";
    public static final String PRODUCT_SWITCH_CANCELLED = "ProductSwitchCancelled";
    public static final String GREEN = "GREEN";
    public static final String GREY = "GREY";
    public static final String OFFER = "Offer";
    public static final String ACTION_REQUIRED = "Action required";
    public static final String NO_ACTION_REQUIRED = "No Action required";
    public static final String COMPLETION = "Completion";
    public static final String DECLINE = "Decline";

    public static final String NAME_PLACE_HOLDER = "$";

    public static final String JOINT_APPLICANT_PLACE_HOLDER = "${joint-applicant}";

    public static final String APPLICANT_PLACE_HOLDER = "${applicant}";

    public static final String YES = "YES";

    public static final String NO = "NO";

    public static final String ASSESSMENT_VALUATION = "AssessmentAndValuation";
    public static final String AVR = "AVR";
    public static final String SVR = "SVR";
    public static final String MILESTONE_COMPLETION = "Completion";
    public static final String MILESTONE_DECLINE = "Decline";
    public static final String MILESTONE_PRE_ASSESSMENT = "Pre-Assessment";
    public static final String MILESTONE_ASSESSMENT = "Assessment";
    public static final String MILESTONE_Valuation = "Valuation";
    public static final String MILESTONE_OFFER = "Offer";
    public static final String MILESTONE_NAME = "${milestoneName}";
    public static final String YOUR_APPLICATION = "Your application";

    public static final String CSP_VALUE =
            "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self' data: http://www.w3.org/; font-src 'self'; style-src 'self' 'unsafe-inline';base-uri 'self';form-action 'self'";
    public static final String NO_CACHE = "no-cache";

    protected static final List<String> stageList = Arrays.asList("20", "22", "24", "25");

    public static final String N = "N";

    public static final String AWAIT = "Await";
    public static final String ASSESS = "Assess";

    public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";

    public static final String APPLICATION_COMPLETED_STATUS_CODE = "C";
    public static final String APPLICATION_DECLINED_STATUS_CODE = "D";
    public static final String APPLICATION_REFUSED_STATUS_CODE = "R";
    public static final String STAGE_80 = "80";
    public static final String STAGE_84 = "84";
    public static final String STAGE_85 = "85";
    public static final String STAGE_90 = "90";
    public static final String STAGE_00 = "0";
    public static final String STAGE_92 = "92";
    public static final String DEFAULT_TASK_CODE = "DEF";
    public static final String ASSESSMENT = "Assessment";
    public static final String FST = "FST";
    public static final String MISSING_BRAND = "Missing request header 'brand'";

    public static final String INTEREST_ONLY = "Interest Only";
    public static final String CAPITAL_AND_INTEREST = "Capital and Interest";
    public static final String PART_AND_PART = "Part n Part";

    public static final boolean TRUE = true;
    public static final boolean FALSE = false;

    public static final String ORIGIN = "flow_origin";
    public static final String DESTINATION = "destination";

    public static final String MILESTONE_DECLINED_OR_CANCELLED = "Declined/Cancelled";

    public static final String COMPLETED_STAGE_NUMBER = "80";
    public static final String CANCELLED_STAGE_NUMBER = "90";
    public static final String GLOBAL_SUB_STATUS = "SubStatus";
    public static final String SUB_STATUS_CANCELLED = "Cancelled";
    public static final String SUB_STATUS_DECLINED = "Declined";

    public static final String ARO = "ARO";
    public static final String SRP = "SRP";

    public static final String PRODUCT_SWITCH_MORTGAGE_TYPE_CODE = "I";
    public static final String PRODUCT_SWITCH_STATUS = "Product Switch";
    public static final String PRODUCT_SWITCH_STATUS_DESCRIPTION =
            "Your application is at Product Switch";

    public static final String R29 = "R29";
    public static final String DR2 = "DR2";
    public static final String OPEN = "Open";
    public static final String CLOSE = "Close";

    public static final String FNE_TASK_CODE = "FNE";
    public static final String SCM_TASK_CODE = "SCM";
    public static final String AEC_TASK_CODE = "AEC";
    public static final String SRM_TASK_CODE = "SRM";

    public static final String PRODUCT_FEE_STATUS_OUTSTANDING = "Outstanding";
    public static final String NO_REFERRER = "no-referrer";
    public static final String X_XSS_PROTECTION_VALUE = "0";


    private ApplicationConstants() {}
}
