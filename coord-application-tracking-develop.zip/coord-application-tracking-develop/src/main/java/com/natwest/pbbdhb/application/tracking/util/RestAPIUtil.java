/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.util;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.getCurrentDateInUnitedKingdom;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.natwest.pbbdhb.application.tracking.controller.ApplicationTrackingController;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationListRequest;
import com.natwest.pbbdhb.application.tracking.model.dto.request.ApplicationRequest;
import java.io.IOException;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
public class RestAPIUtil {

    private RestAPIUtil() {}

    public static void populateRequestParams(
            ApplicationRequest request, UriComponentsBuilder builder) {
        Optional.ofNullable(request)
                .ifPresent(
                        applicationRequest ->
                                builder.replaceQueryParam(
                                                EMAIL_ID, applicationRequest.getBrokerEmailId())
                                        .replaceQueryParam(
                                                FCA_NUMBER, applicationRequest.getFcaNumber())
                                        .replaceQueryParam(
                                                FIRST_NAME, applicationRequest.getBrokerFirstName())
                                        .replaceQueryParam(
                                                LAST_NAME, applicationRequest.getBrokerLastName())
                                        .replaceQueryParam(
                                                FROM_DATE, applicationRequest.constructFromDate())
                                        .replaceQueryParam(TO_DATE, getCurrentDateInUnitedKingdom())
                                        .replaceQueryParam(
                                                PAGE_NUMBER, applicationRequest.getPageNumber())
                                        .replaceQueryParam(
                                                RESULT_PER_PAGE,
                                                applicationRequest.getResultPerPage())
                                        .replaceQueryParam(
                                                SORT_BY,
                                                applicationRequest.constructSortByParam()));
    }
    
    
    public static void populateRequestParams(
            ApplicationListRequest request, UriComponentsBuilder builder) {
        Optional.ofNullable(request)
                .ifPresent(
                        applicationRequest ->
                                builder.replaceQueryParam(
                                                EMAIL_ID, applicationRequest.getBrokerEmailId())
                                        .replaceQueryParam(
                                                FCA_NUMBER, applicationRequest.getFcaNumber())
                                        .replaceQueryParam(
                                                FIRST_NAME, applicationRequest.getBrokerFirstName())
                                        .replaceQueryParam(
                                                LAST_NAME, applicationRequest.getBrokerLastName())
                                        .replaceQueryParam(
                                                FROM_DATE, applicationRequest.constructFromDate())
                                        .replaceQueryParam(TO_DATE, getCurrentDateInUnitedKingdom())                                        
                                        
                                        .replaceQueryParam(
                                                PAGE_NUMBER, applicationRequest.getPageNumber())
                                        .replaceQueryParam(
                                                RESULT_PER_PAGE,
                                                applicationRequest.getResultPerPage())
                                        .replaceQueryParam(
                                                SORT_BY,
                                                applicationRequest.constructSortByParam()));
        
        Optional.ofNullable(request.getApplicantFirstName())
            .ifPresent(applicantFirstName -> builder.replaceQueryParam(APPLICANT_FIRST_NAME, applicantFirstName));
        
        Optional.ofNullable(request.getApplicantLastName())
            .ifPresent(applicantLastName -> builder.replaceQueryParam(APPLICANT_LAST_NAME, applicantLastName));
        
        Optional.ofNullable(request.getActionRequired())
            .ifPresent(actionRequired -> builder.replaceQueryParam(IS_ACTION_REQUIRED, actionRequired));
    }

    public static void populateRequestParamsForBrokerApplicationSearch(
            ApplicationRequest applicationRequest, UriComponentsBuilder builder) {
        populateRequestParams(applicationRequest, builder);

        Optional.ofNullable(applicationRequest)
                .ifPresent(
                        request -> {
                            Optional.ofNullable(request.getApplicantFirstName())
                                    .ifPresent(
                                            applicantFirstName ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_FIRST_NAME,
                                                            applicantFirstName));

                            Optional.ofNullable(request.getApplicantLastName())
                                    .ifPresent(
                                            applicantLastName ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_LAST_NAME,
                                                            applicantLastName));

                            Optional.ofNullable(request.getApplicantDob())
                                    .ifPresent(
                                            applicantDob ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_DOB, applicantDob));

                            Optional.ofNullable(request.getPropertyPostcode())
                                    .ifPresent(
                                            propertyPostCode ->
                                                    builder.replaceQueryParam(
                                                            POSTCODE, propertyPostCode));
                        });
    }

    public static HttpEntity<?> getHeader(String brand, String origin, String destination) {
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, APPLICATION_JSON);
        header.add(BRAND, brand);
        header.add(CALLER, EXTERNAL);
        header.add(ORIGIN, origin);
        header.add(DESTINATION, destination);
        setCorrelationIdIfPresent(header);
        HttpEntity<?> entity = new HttpEntity<>(header);
        log.info("header set for downstream call: {}", header);
        return entity;
    }

    private static void setCorrelationIdIfPresent(HttpHeaders header) {
        Optional.ofNullable(MDC.get(DWS_REQUEST_CORRELATION_ID))
                .ifPresent(correlationId -> header.add(DWS_CORRELATION_ID, correlationId));
    }

    private static void populateRequestParamsForGetApplications(
            ApplicationRequest applicationRequest, UriComponentsBuilder builder) {
        Optional.ofNullable(applicationRequest)
                .ifPresent(
                        request ->
                                builder.replaceQueryParam(
                                                BROKER_EMAIL_ID, request.getBrokerEmailId())
                                        .replaceQueryParam(
                                                BROKER_USER_NAME, request.getBrokerUserName())
                                        .replaceQueryParam(
                                                BROKER_FIRST_NAME, request.getBrokerFirstName())
                                        .replaceQueryParam(
                                                BROKER_LAST_NAME, request.getBrokerLastName())
                                        .replaceQueryParam(
                                                BROKER_POSTCODE, request.getBrokerPostcode())
                                        .replaceQueryParam(FCA_NUMBER, request.getFcaNumber())
                                        .replaceQueryParam(
                                                FIRM_POSTCODE, request.getFirmPostcode()));

        Optional.ofNullable(applicationRequest)
                .ifPresent(
                        request -> {
                            Optional.ofNullable(request.getApplicantFirstName())
                                    .ifPresent(
                                            applicantFirstName ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_FIRST_NAME,
                                                            applicantFirstName));

                            Optional.ofNullable(request.getApplicantLastName())
                                    .ifPresent(
                                            applicantLastName ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_LAST_NAME,
                                                            applicantLastName));

                            Optional.ofNullable(request.getApplicantDob())
                                    .ifPresent(
                                            applicantDob ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_DOB, applicantDob));

                            Optional.ofNullable(request.getPropertyPostcode())
                                    .ifPresent(
                                            propertyPostCode ->
                                                    builder.replaceQueryParam(
                                                            PROPERTY_POSTCODE, propertyPostCode));

                            Optional.ofNullable(request.getDateRange())
                                    .ifPresent(
                                            dateRange ->
                                                    builder.replaceQueryParam(
                                                            DATE_RANGE, dateRange));

                            Optional.ofNullable(request.getPageNumber())
                                    .ifPresent(
                                            pageNumber ->
                                                    builder.replaceQueryParam(
                                                            PAGE_NUMBER, pageNumber));

                            Optional.ofNullable(request.getResultPerPage())
                                    .ifPresent(
                                            resultPerPage ->
                                                    builder.replaceQueryParam(
                                                            RESULT_PER_PAGE, resultPerPage));

                            Optional.ofNullable(request.getSortBy())
                                    .ifPresent(
                                            sortBy -> builder.replaceQueryParam(SORT_BY, sortBy));

                            Optional.ofNullable(request.getSortOrder())
                                    .ifPresent(
                                            sortOrder ->
                                                    builder.replaceQueryParam(
                                                            SORT_ORDER, sortOrder));
                        });
    }
    
    
    private static void populateRequestParamsForGetApplicationList(
            ApplicationListRequest applicationRequest, UriComponentsBuilder builder) {
        Optional.ofNullable(applicationRequest)
                .ifPresent(
                        request ->
                                builder.replaceQueryParam(
                                                BROKER_EMAIL_ID, request.getBrokerEmailId())
                                        .replaceQueryParam(
                                                BROKER_USER_NAME, request.getBrokerUserName())
                                        .replaceQueryParam(
                                                BROKER_FIRST_NAME, request.getBrokerFirstName())
                                        .replaceQueryParam(
                                                BROKER_LAST_NAME, request.getBrokerLastName())
                                        .replaceQueryParam(
                                                BROKER_POSTCODE, request.getBrokerPostcode())
                                        .replaceQueryParam(FCA_NUMBER, request.getFcaNumber())
                                        .replaceQueryParam(
                                                FIRM_POSTCODE, request.getFirmPostcode()));

        Optional.ofNullable(applicationRequest)
                .ifPresent(
                        request -> {
                            Optional.ofNullable(request.getApplicantFirstName())
                                    .ifPresent(
                                            applicantFirstName ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_FIRST_NAME,
                                                            applicantFirstName));

                            Optional.ofNullable(request.getApplicantLastName())
                                    .ifPresent(
                                            applicantLastName ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_LAST_NAME,
                                                            applicantLastName));

                            Optional.ofNullable(request.getApplicantDob())
                                    .ifPresent(
                                            applicantDob ->
                                                    builder.replaceQueryParam(
                                                            APPLICANT_DOB, applicantDob));

                            Optional.ofNullable(request.getPropertyPostcode())
                                    .ifPresent(
                                            propertyPostCode ->
                                                    builder.replaceQueryParam(
                                                            PROPERTY_POSTCODE, propertyPostCode));

                            Optional.ofNullable(request.getDateRange())
                                    .ifPresent(
                                            dateRange ->
                                                    builder.replaceQueryParam(
                                                            DATE_RANGE, dateRange));

                            Optional.ofNullable(request.getPageNumber())
                                    .ifPresent(
                                            pageNumber ->
                                                    builder.replaceQueryParam(
                                                            PAGE_NUMBER, pageNumber));

                            Optional.ofNullable(request.getResultPerPage())
                                    .ifPresent(
                                            resultPerPage ->
                                                    builder.replaceQueryParam(
                                                            RESULT_PER_PAGE, resultPerPage));

                            Optional.ofNullable(request.getSortBy())
                                    .ifPresent(
                                            sortBy -> builder.replaceQueryParam(SORT_BY, sortBy));

                            Optional.ofNullable(request.getSortOrder())
                                    .ifPresent(
                                            sortOrder ->
                                                    builder.replaceQueryParam(
                                                            SORT_ORDER, sortOrder));
                        });
    }

    public static UriComponentsBuilder populateGetApplicationsURI(
            ApplicationRequest applicationRequest)
            throws InterruptedException, ExecutionException, IOException {
        WebMvcLinkBuilder controllerLinkBuilder =
                linkTo(
                        methodOn(ApplicationTrackingController.class)
                                .getApplications(null, applicationRequest, null));

        UriComponentsBuilder builder = controllerLinkBuilder.toUriComponentsBuilder();
        populateRequestParamsForGetApplications(applicationRequest, builder);
        return builder;
    }
    
    public static UriComponentsBuilder populateGetApplicationListURI(
            ApplicationListRequest applicationRequest)
            throws InterruptedException, ExecutionException, IOException {
        WebMvcLinkBuilder controllerLinkBuilder =
                linkTo(
                        methodOn(ApplicationTrackingController.class)
                                .getApplicationList(null, applicationRequest, null));

        UriComponentsBuilder builder = controllerLinkBuilder.toUriComponentsBuilder();
        populateRequestParamsForGetApplicationList(applicationRequest, builder);
        return builder;
    }
}
