/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information;

import com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail.Products;
import java.util.List;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
@Builder
public class ProductInformation {
    private String totalLoanAmount;
    private String ltv;
    private String totalRepaymentAmount;
    private String feeAmount;
    private String feeIncluded;
    private String depositAmount;
    private String cashback;
    private String mortgageType;
    private String feeStatus;
    private boolean feePending;
    private List<Products> products;
}
