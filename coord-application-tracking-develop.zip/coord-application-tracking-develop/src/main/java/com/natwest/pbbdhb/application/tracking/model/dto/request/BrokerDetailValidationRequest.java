/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrokerDetailValidationRequest {
    private String brokerForeName;
    private String brokerSurname;
    private String brokerEmail;
    private String fcaNumber;
    private String brokerPostcode;
    private String brokerUsername;
}
