/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.service;

import static com.natwest.pbbdhb.application.tracking.util.ApplicationUtil.initMap;

import com.natwest.pbbdhb.application.tracking.model.GMSStageDescription;
import com.natwest.pbbdhb.application.tracking.model.GMSTaskDescription;
import com.natwest.pbbdhb.application.tracking.model.MilestoneMappingInformation;
import com.natwest.pbbdhb.application.tracking.model.ValuationStatus;
import com.opencsv.CSVReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

@Component
public class GmsStageAndTaskLoader {

    @Value("${gms.stage.csv.file}")
    private Resource resource;

    @Value("${gms.task.await.csv.file}")
    private Resource awaitTaskResource;

    @Value("${gms.task.assess.csv.file}")
    private Resource assessTaskResource;

    @Value("${gms.status.description.csv.file}")
    private Resource statusDescriptionResource;

    @Value("${gms.task.description.csv.file}")
    private Resource openTaskDescriptionResource;

    @Value("${gms.milestone.mapping.csv.file}")
    private Resource milestoneMappingResource;

    @Value("${gms.valuation.status.ignore.csv.file}")
    private Resource validationStatusMappingResource;

    @Value("${gms.mortgage.type.mapping.csv.file}")
    private Resource mortgageTypeMappingResource;

    @Value("${gms.fee.status.mapping.csv.file}")
    private Resource feeStatusMappingResource;

    @Value("${gms.product.switch.milestone.mapping.csv.file}")
    private Resource productSwitchMilestoneMappingResource;

    @Value("${gms.dummy.task.csv.file}")
    private Resource dummyTaskMappingResource;

    private final Map<String, GMSStageDescription> map;
    private final Map<String, String> awaitTaskMap;
    private final Map<String, String> assessTaskMap;
    private final Map<String, String> statusDescriptionMap;
    private final Map<String, GMSTaskDescription> taskDescriptionMap;
    private final Map<String, MilestoneMappingInformation> milestoneMap;
    private final Map<String, MilestoneMappingInformation> productSwitchMilestoneMap;
    private final List<String> allowedTasks;
    private final List<String> allowedStages;
    private final Map<String, ValuationStatus> valuationStatusMap;
    private final Map<String, String> mortgageTypeDescriptionMap;
    private final Map<String, String> feeStatusDescriptionMap;
    private final Map<String, String> dummyTaskMap;

    public GmsStageAndTaskLoader() {
        map = new HashMap<>();
        awaitTaskMap = new HashMap<>();
        assessTaskMap = new HashMap<>();
        statusDescriptionMap = new HashMap<>();
        taskDescriptionMap = new HashMap<>();
        milestoneMap = new HashMap<>();
        allowedTasks = new ArrayList<>();
        allowedStages = new ArrayList<>();
        valuationStatusMap = new HashMap<>();
        mortgageTypeDescriptionMap = new HashMap<>();
        feeStatusDescriptionMap = new HashMap<>();
        productSwitchMilestoneMap = new HashMap<>();
        dummyTaskMap = new HashMap<>();
    }

    public GMSStageDescription getStageDescription(String stageNo) {
        return map.get(stageNo);
    }

    public GMSTaskDescription getTaskDescription(String taskCode) {
        return taskDescriptionMap.get(taskCode);
    }

    public Map<String, MilestoneMappingInformation> getMilestoneMappingInformation() {
        return milestoneMap;
    }

    public Map<String, MilestoneMappingInformation> getProductSwitchMilestoneMappingInformation() {
        return productSwitchMilestoneMap;
    }

    /**
     * Method to get dummy task code by stage code
     *
     * @param stageCode - stageCode
     * @return dummy task code
     */
    public String getDummyTaskCode(String stageCode) {
        return dummyTaskMap.get(stageCode);
    }

    public boolean isAwaitTask(String taskCode) {
        return awaitTaskMap.containsKey(taskCode);
    }

    public boolean isAssessTask(String taskCode) {
        return assessTaskMap.containsKey(taskCode);
    }

    public String getStatusDescription(String statusCode) {
        return statusDescriptionMap.get(statusCode);
    }

    public boolean isAllowedTask(String taskCode) {
        return allowedTasks.contains(taskCode);
    }

    public boolean isAllowedStage(String stageNumber) {
        return allowedStages.contains(stageNumber);
    }

    public ValuationStatus getValuationStatus(String code) {
        return valuationStatusMap.get(code);
    }

    public String getMortgageTypeDescription(String code) {
        return mortgageTypeDescriptionMap.get(code);
    }

    public String getFeeStatusDescription(String code) {
        return feeStatusDescriptionMap.get(code);
    }

    @PostConstruct
    void init() throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(resource.getFile()))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                map.put(
                        values[0],
                        GMSStageDescription.builder()
                                .description(values[1])
                                .status(values[2])
                                .statusDetail(values[3])
                                .build());
            }
        }
        initMap(awaitTaskResource.getFile(), awaitTaskMap);
        initMap(assessTaskResource.getFile(), assessTaskMap);
        initMap(statusDescriptionResource.getFile(), statusDescriptionMap);
        initTaskMap(openTaskDescriptionResource.getFile(), taskDescriptionMap);
        initMilestoneMapAndAllowedTasksAndStages(
                milestoneMappingResource.getFile(), milestoneMap, allowedStages, allowedTasks);
        initValuationStatusMap(validationStatusMappingResource.getFile(), valuationStatusMap);
        initMortgageTypeDescriptionMap(
                mortgageTypeMappingResource.getFile(), mortgageTypeDescriptionMap);
        initFeeStatusDescriptionMap(feeStatusMappingResource.getFile(), feeStatusDescriptionMap);
        initProductSwitchMilestoneMap(
                productSwitchMilestoneMappingResource.getFile(), productSwitchMilestoneMap);
        initDummyTaskMap(dummyTaskMappingResource.getFile(), dummyTaskMap);
    }

    private void initDummyTaskMap(File file, Map<String, String> dummyTaskMap) throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                dummyTaskMap.put(values[0], values[1]);
            }
        }
    }

    private void initProductSwitchMilestoneMap(
            File file, Map<String, MilestoneMappingInformation> productSwitchMilestoneMap)
            throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                List<String> stages = Arrays.asList(StringUtils.split(values[3], ","));
                List<String> tasks = Arrays.asList(StringUtils.split(values[4], ","));
                productSwitchMilestoneMap.put(
                        values[0],
                        MilestoneMappingInformation.builder()
                                .description(values[1])
                                .ragStatus(values[2])
                                .stages(stages)
                                .tasks(tasks)
                                .build());
            }
        }
    }

    private void initFeeStatusDescriptionMap(File file, Map<String, String> feeStatusDescriptionMap)
            throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                feeStatusDescriptionMap.put(values[0], values[1]);
            }
        }
    }

    private void initMortgageTypeDescriptionMap(
            File file, Map<String, String> mortgageTypeDescriptionMap) throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                mortgageTypeDescriptionMap.put(values[0], values[2]);
            }
        }
    }

    private void initMilestoneMapAndAllowedTasksAndStages(
            File file,
            Map<String, MilestoneMappingInformation> milestoneMap,
            List<String> allowedStages,
            List<String> allowedTasks)
            throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                List<String> stages = Arrays.asList(StringUtils.split(values[3], ","));
                List<String> tasks = Arrays.asList(StringUtils.split(values[4], ","));
                allowedStages.addAll(stages);
                allowedTasks.addAll(tasks);
                milestoneMap.put(
                        values[0],
                        MilestoneMappingInformation.builder()
                                .description(values[1])
                                .ragStatus(values[2])
                                .stages(stages)
                                .tasks(tasks)
                                .build());
            }
        }
    }

    private void initTaskMap(File file, Map<String, GMSTaskDescription> taskDescriptionMap)
            throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                String code = Objects.nonNull(values[0]) ? values[0].trim() : values[0];
                String description = Objects.nonNull(values[1]) ? values[1].trim() : values[1];
                taskDescriptionMap.put(
                        code, GMSTaskDescription.builder().description(description).build());
            }
        }
    }

    private void initValuationStatusMap(File file, Map<String, ValuationStatus> valuationStatusMap)
            throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                String code = Objects.nonNull(values[0]) ? values[0].trim() : null;
                String description = Objects.nonNull(values[1]) ? values[1].trim() : null;
                String status = Objects.nonNull(values[2]) ? values[2].trim() : null;
                valuationStatusMap.put(
                        code,
                        ValuationStatus.builder().description(description).status(status).build());
            }
        }
    }
}
