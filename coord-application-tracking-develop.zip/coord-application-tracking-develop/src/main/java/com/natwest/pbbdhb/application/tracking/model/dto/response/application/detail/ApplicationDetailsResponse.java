/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.application.tracking.model.dto.response.application.detail;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.Applicant;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.ProductInformation;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.PropertyInfo;
import com.natwest.pbbdhb.application.tracking.model.dto.response.gms.application.information.SolicitorInformation;
import java.util.List;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

@Getter
@Setter
@Builder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder(
        value = {
            "referenceNumber",
            "productInformation",
            "solicitorInformation",
            "applicantInformation",
            "propertyInformation",
            "sourceInformation",
            "valuationInformation",
            "applicationDetails",
            "statusInfo"
        })
public class ApplicationDetailsResponse extends RepresentationModel<ApplicationDetailsResponse> {

    private String referenceNumber;
    private ProductInformation productInformation;
    private SolicitorInformation solicitorInformation;
    private List<Applicant> applicantInformation;
    private PropertyInfo propertyInformation;
    private HistoryDetails applicationDetails;
    private StatusDetail status;
    private ValuationDetail valuationInformation;
}
