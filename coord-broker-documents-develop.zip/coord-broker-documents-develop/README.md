# Work in progress...

# Spring Boot Template for integration microservices

## Brief Overview :
!!! Real MSVC Overview is HERE !!!.

## Build the application
```shell script
mvn clean install
```

## Running unit tests
```shell script
mvn clean test
```

## Running all tests
```shell script
mvn clean verify -P integration-test
```

## Running the application with the "local" spring profile
```shell script
mvn spring-boot:run
```

## Application URL
```shell script
http://localhost:8080/template/v1/msvc-init-template/
```
## Endpoints documented via Swagger
```shell script
http://localhost:8080/template/v1/msvc-init-template/swagger-ui/index.html
```
