package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BasicAddress {

    private String flat;

    private String houseName;

    private String houseNumber;

    private String street;

    private String district;

    private String town;

    private String county;

    private String postcode;

    private String country;
}

