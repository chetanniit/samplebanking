package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MortgageAdvisor {

    private String advisor;

    private String leadAdvisor;

    private String networkAdvisor;

}

