package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class CaseApplication {

    public static final String TRUE_LITERAL = "true";

    private String caseId;

    private String mortgageReferenceNumber;

    private String mortgageTempReferenceNumber;

    private String racfId;

    private Boolean contactPermission;

    private String primaryAdvisorRacfId;

    private String secondaryAdvisorRacfId;

    private String applicationType;

    private String loanPurpose;

    private Boolean scottishApplication;

    private String channel;

    private String branch;

    private String directApplication;

    private String marketingSchemeNumber;

    private String marketingSource;

    private String buyerType;

    private Boolean govtSharedEquityScheme;

    private String schemeType;

    private String schemeName;

    private Boolean mainResidence;

    private Boolean repayMortgageCurrencyNotSterling;

    private String repayMortgageCurrency;

    private BigDecimal currencyExchangeRate;

    private String additionalServicesRequired;

    private Boolean movingToPropertyAtCompletion;

    private String applicationStatus;

    private Mortgage mortgage;

    private DirectDebitDetails directDebit;

    private SolicitorDetails solicitor;

    private EstateAgent estateAgent;

    private ServiceLevel serviceLevel;

    private List<SalesIllustration> salesIllustrations;

    private List<DecisionInPrinciple> decisionInPrinciples;

    private Broker broker;

    private HardscoreDecision hardscoreDecision;

    private Map<String, Object> journeyData;

    private String mortgageApplSeq;

    private String salesIllustrationTempReferenceNumber;

    private IndirectSource indirectSource;

    private String transcriptValuer;

    private String transcriptValuationDate;

    private List<ExceptionPolicy> exceptionPolicies;

    private String version;

}
