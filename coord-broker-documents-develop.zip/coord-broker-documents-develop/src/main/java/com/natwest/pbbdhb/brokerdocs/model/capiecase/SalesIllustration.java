package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SalesIllustration {

    private List<String> documentUrls;

    private List<ProductDetails> products;

    private String mortgageApplSeq;

    private Boolean isAccepted;

    private String selectionDate;
}
