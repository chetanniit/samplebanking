package com.natwest.pbbdhb.brokerdocs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.DocumentsUploadURLResponse;

public interface DocumentsUploadURLService {
    DocumentsUploadURLResponse getDocumentsUploadURL(Broker broker, String mortgageReferenceNumber, String brand, String clientId) throws JsonProcessingException;
}
