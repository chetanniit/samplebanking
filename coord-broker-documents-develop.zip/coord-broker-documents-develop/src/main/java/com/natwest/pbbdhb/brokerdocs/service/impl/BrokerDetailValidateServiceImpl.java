package com.natwest.pbbdhb.brokerdocs.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.BrokerDetailValidateFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.brokervalidation.BrokerDetailValidateRequest;
import com.natwest.pbbdhb.brokerdocs.model.brokervalidation.BrokerDetailValidateResponse;
import com.natwest.pbbdhb.brokerdocs.service.BrokerDetailValidateService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

@Service
public class BrokerDetailValidateServiceImpl implements BrokerDetailValidateService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BrokerDetailValidateServiceImpl.class);
    private static final String NO = "NO";

    @Value("${broker.detail.validate.endpoint}")
    private String brokerDetailValidateEndpoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    ObjectMapper mapper;

    @Override
    public void validateBroker(Broker broker) throws JsonProcessingException {

        LOGGER.debug("DUR 3.1 validating broker: {} ,calling url : {}", mapper.writeValueAsString(broker), brokerDetailValidateEndpoint);
        LOGGER.info("DUR 3.1 validating broker FCA Number: {} ,calling url : {}", broker.getFcaNumber(), brokerDetailValidateEndpoint);
        BrokerDetailValidateRequest brokerDetailValidateRequest = modelMapper.map(broker, BrokerDetailValidateRequest.class);
        BrokerDetailValidateResponse brokerDetailValidateResponse = null;
        try {

            brokerDetailValidateResponse = restTemplate.postForObject(brokerDetailValidateEndpoint, brokerDetailValidateRequest, BrokerDetailValidateResponse.class);
        } catch (Exception e) {
            LOGGER.error(" DUR 3.2 validateBroker : Error in validateBroker. error = {}", e.getMessage());
            if (!(e instanceof HttpClientErrorException.NotFound)) {
                throw new BrokerDetailValidateFailureException("500", "Internal Server Error");
            }
        }

        if (Objects.isNull(brokerDetailValidateResponse) ||
                Objects.isNull(brokerDetailValidateResponse.getBrokers()) ||
                brokerDetailValidateResponse.getBrokers().isEmpty() ||
                (brokerDetailValidateResponse.getBrokers().iterator().next().getAcceptMortgageBusiness().equalsIgnoreCase(NO))) {
            LOGGER.warn("DUR 3.3 BROKER BUSINESS NOT ALLOWED FOR FCA NUMBER: {} (Surname: {})", broker.getFcaNumber(), broker.getBrokerSurname());
            throw new BrokerDetailValidateFailureException("403", "Not a valid broker");
        }
        LOGGER.debug("DUR 3.4 Broker validation is complete for :{}", mapper.writeValueAsString(broker));
        LOGGER.info("DUR 3.4 Broker validation is complete for broker FCA Number: {}", broker.getFcaNumber());
    }

}
