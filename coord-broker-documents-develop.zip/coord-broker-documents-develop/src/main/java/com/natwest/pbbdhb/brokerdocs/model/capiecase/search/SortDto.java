package com.natwest.pbbdhb.brokerdocs.model.capiecase.search;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class SortDto {
    private List<OrderDto> orders;
}
