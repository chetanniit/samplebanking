package com.natwest.pbbdhb.brokerdocs.model.brokerauthtoken;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerAuthTokenResponse {
    String accessToken;
    String tokenType;
    String expiresIn;
}
