package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class Fee {

    private String feeCode;
    private String feeAction;
    private BigDecimal feeAmount;
    private String feePaymentType;
    private String type;

}
