package com.natwest.pbbdhb.brokerdocs;

import com.rbs.pbbdhb.common.error.ErrorHandlingComponents;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackageClasses = {
        BrokerDocsApplication.class,
        ErrorHandlingComponents.class
})
public class BrokerDocsApplication {

    public static void main(String[] args) {
        SpringApplication.run(BrokerDocsApplication.class, args);
    }
}
