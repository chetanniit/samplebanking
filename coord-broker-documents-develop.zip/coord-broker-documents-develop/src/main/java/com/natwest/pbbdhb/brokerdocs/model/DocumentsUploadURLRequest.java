package com.natwest.pbbdhb.brokerdocs.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Validated
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentsUploadURLRequest {

    @Valid
    @Schema
    @NotNull(message = "Broker details cannot be null or empty")
    private Broker broker;
}
