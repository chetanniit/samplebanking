package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RepaymentDetail {

    private String repaymentStrategyType;

    private Long repaymentValue;

    private Long repaymentMortgageAmount;
}

