package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

/**
 * @author lukasz.jozefowicz@natwest.com on 22/06/2022
 */
@Getter
@Setter
public class ExceptionPolicy {
    private String code;
}
