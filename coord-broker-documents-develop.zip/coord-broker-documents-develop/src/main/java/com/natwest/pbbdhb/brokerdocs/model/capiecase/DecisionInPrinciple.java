package com.natwest.pbbdhb.brokerdocs.model.capiecase;


import lombok.*;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DecisionInPrinciple {

    private String dipId;

    private String decisionUniqueId;

    private String decision;

    private String podDecision;

    private List<Policy> policyMessages;

    private String excessIncome;

    private IndicativeCost indicativeCost;

    private String maxLendFigure;

    private String ltv;

    private BigDecimal minRepayment;

    private BigDecimal maxRepayment;

    private String dateTime;

    private Packaging packaging;

    private AdditionalDetails additionalDetails;

    private String lenderCaseId;
}
