package com.natwest.pbbdhb.brokerdocs.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class BrokerDetailValidateFailureException extends RuntimeException {

    private final String statusCode;

    public BrokerDetailValidateFailureException(String statusCode, String message) {
        super(message);
        this.statusCode = statusCode;
    }
}
