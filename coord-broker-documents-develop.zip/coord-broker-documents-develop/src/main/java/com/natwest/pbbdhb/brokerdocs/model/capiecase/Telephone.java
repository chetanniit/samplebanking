package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Telephone {

    private String type;
    private String number;
    private Boolean preferred;
}

