package com.natwest.pbbdhb.brokerdocs.model.capiecase;


import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductDetails {

    private String productCode;

    private String productType;

    private String productTerm;

    private BigDecimal rateOfInterest;

    private Long ltv;

    private String productSelectedDate;
}

