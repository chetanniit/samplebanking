package com.natwest.pbbdhb.brokerdocs.model.capiecase.search;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

import static com.natwest.pbbdhb.brokerdocs.model.capiecase.search.OperatorDto.OperatorType.OR;

@Setter
@Getter
public class OrOperatorDto extends OperatorDto {
    private List<OperatorDto> operators;

    @Override
    public OperatorType getType() {
        return OR;
    }
}
