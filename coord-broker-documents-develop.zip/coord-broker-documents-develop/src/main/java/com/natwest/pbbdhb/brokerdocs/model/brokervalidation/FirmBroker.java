package com.natwest.pbbdhb.brokerdocs.model.brokervalidation;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FirmBroker implements Serializable {

    private String brokerID;

    private String firmName;

    private String firmID;

    private String fcaNumber;

    private String firmPostcode;

    private String brokerPostcode;

    private String brokerSurname;

    private String firmStatus;

    private String brokerStatus;

    private String acceptMortgageBusiness;

    private String principleFcaNumber;

    private String firmAddress1;

    private String firmAddress2;

    private String firmAddress3;

    private String firmAddress4;

    private String firmAddress5;

    private String brokerForeName;

    private String brokerEmail;

    private String brokerTelephoneNumber;

    private Timestamp statusDate;

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FirmBroker)) {
            return false;
        }
        FirmBroker firmBroker = (FirmBroker) obj;
        return Objects.equals(this.brokerID, firmBroker.brokerID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(brokerID);
    }

}
