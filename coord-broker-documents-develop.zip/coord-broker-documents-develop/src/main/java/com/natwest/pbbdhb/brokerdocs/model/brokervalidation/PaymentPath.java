package com.natwest.pbbdhb.brokerdocs.model.brokervalidation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentPath implements Serializable {

    private String paymentPathID;

    private String firmID;

    private String paymentPathName;

    private String paymentRoute;

    private Timestamp lastUpdatedDate;

}
