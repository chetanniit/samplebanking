package com.natwest.pbbdhb.brokerdocs.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.CaseApplication;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.CaseSearchResponse;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.search.CriteriaDto;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.search.QueryDto;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.search.SimpleOperatorDto;
import com.natwest.pbbdhb.brokerdocs.service.CapieService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
@SuppressWarnings("PMD.PreserveStackTrace")
public class CapieServiceImpl implements CapieService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CapieServiceImpl.class);

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private final RestTemplate restTemplate;

    @Autowired
    ObjectMapper mapper;

    @Value("${case.service.search.endpoint}")
    private String caseServiceSearchUrl;

    @Value("${applicant.service.get.endpoint}")
    private String applicantServiceGetUrl;

    @Override
    public String validateMRN(String mortgageRefNumber, String brand, Broker broker) throws JsonProcessingException {
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.add("brand", brand);
        LOGGER.info("DUR 4.1 calling case search on url {} to get case details for mortgage reference number - {} , brand = {}",
                caseServiceSearchUrl, mortgageRefNumber, brand);
        CaseApplication caseApplication;
        CaseSearchResponse response;
        SimpleOperatorDto simpleOperator = SimpleOperatorDto.builder().
                compareType(SimpleOperatorDto.CompareType.EQ).field("mortgageReferenceNumber").
                value(mortgageRefNumber).build();
        QueryDto query = QueryDto.builder().operator(simpleOperator).build();
        CriteriaDto criteria = CriteriaDto.builder().query(query).build();
        HttpEntity<CriteriaDto> httpEntity = new HttpEntity<>(criteria, headers);
        try {
            response = restTemplate.postForObject(caseServiceSearchUrl, httpEntity, CaseSearchResponse.class);
        } catch (Exception e) {
            LOGGER.error("DUR 4.2 Error while fetching case data for mortgageRefNumber={},brand={}, message={}",
                    mortgageRefNumber, brand, e.getMessage());
            throw new MRNValidateFailureException("500", "Error while fetching case data");
        }
        if (response == null || response.getContent() == null || response.getContent().isEmpty() ||
                ObjectUtils.isEmpty(response.getContent().get(0))) {
            LOGGER.error("DUR 4.3 No case record returned for mrn = {} and brand = {}", mortgageRefNumber, brand);
            throw new MRNValidateFailureException("404", "Invalid Mortgage Reference Number");
        }
        caseApplication = response.getContent().get(0);
        if (ObjectUtils.isEmpty(caseApplication.getBroker()) || !isBrokerDetailsMatching(broker, caseApplication.getBroker())) {
            LOGGER.error("DUR 4.4 Broker details in Case service do not match with input Broker details input : {} , case broker data : {}",
                    mapper.writeValueAsString(broker), mapper.writeValueAsString(caseApplication.getBroker()));
            throw new MRNValidateFailureException("403", "Only the broker who created the FMA can upload the document");
        }
        LOGGER.info("DUR 4.5 case search completed for mortgage reference number - {} , brand = {}", mortgageRefNumber, brand);
        return response.getContent().get(0).getCaseId();
    }

    @Override
    public Applicant getMainApplicantData(String caseId, String brand) throws JsonProcessingException {
        LOGGER.info("DUR 5.1  Getting main applicant data for caseId - {} , brand = {}", caseId, brand);
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.add("brand", brand);
        Applicant mainApplicant = null;
        List<Applicant> response;
        try {
            response = restTemplate.exchange(applicantServiceGetUrl, HttpMethod.GET,
                    new HttpEntity<>(headers), new ParameterizedTypeReference<List<Applicant>>() {
                    }, caseId).getBody();
        } catch (Exception e) {
            LOGGER.error("DUR 5.2 Error while fetching applicant data for caseId={},brand={}, message={}",
                    caseId, brand, e.getMessage());
            throw new MRNValidateFailureException("500", "Error while fetching applicant data");
        }
        LOGGER.info("DUR 5.3 Completed applicants fetch for caseId - {} , brand = {}", caseId, brand);
        if (!ObjectUtils.isEmpty(response)) {
            mainApplicant = response.stream().filter(applicant -> applicant.getMainApplicant()).findAny().get();
        }
        return mainApplicant;
    }

    private boolean isBrokerDetailsMatching(Broker inputBroker, com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker caseBroker) {
        Broker mappedBroker = Broker.builder().build();
        List<String> ignoreProps = new ArrayList<String>();
        if (!ObjectUtils.isEmpty(inputBroker.getBrokerForeName()) &&
                !inputBroker.getBrokerForeName().equalsIgnoreCase(caseBroker.getBrokerForeName())) {
            return false;
        }
        if (!ObjectUtils.isEmpty(inputBroker.getBrokerPostcode()) &&
                !inputBroker.getBrokerPostcode().equalsIgnoreCase(caseBroker.getBrokerPostcode())) {
            return false;
        }
        if (!inputBroker.getFcaNumber().equalsIgnoreCase(caseBroker.getFcaNumber())) {
            return false;
        }
        if (!inputBroker.getBrokerEmail().equalsIgnoreCase(caseBroker.getBrokerEmail())) {
            return false;
        }
        if (!inputBroker.getBrokerSurname().equalsIgnoreCase(caseBroker.getBrokerSurname())) {
            return false;
        }
        if (!inputBroker.getBrokerUsername().equalsIgnoreCase(caseBroker.getBrokerUsername())) {
            return false;
        }
        return true;
    }

}
