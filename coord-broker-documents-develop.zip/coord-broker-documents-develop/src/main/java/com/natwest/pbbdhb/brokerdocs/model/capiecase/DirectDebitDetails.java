package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;



@Getter
@Setter
public class DirectDebitDetails {

    @NotNull
    private String accountName;

    @NotNull
    private String accountNumber;

    @NotNull
    private String sortcode;

}

