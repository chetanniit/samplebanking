package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * @author lukasz.jozefowicz@natwest.com on 21/06/2022
 */
@Getter
@Setter
public class AdditionalDetails {
    private Integer shortestTerminMonths;
    private Integer maximumAllowableLoan;
    private BigDecimal loanToValue;
    private Integer excessIncome;
    private String podScoreBand;
}
