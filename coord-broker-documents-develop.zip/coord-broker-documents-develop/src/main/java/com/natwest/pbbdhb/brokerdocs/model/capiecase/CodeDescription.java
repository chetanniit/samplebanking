package com.natwest.pbbdhb.brokerdocs.model.capiecase;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CodeDescription {

    private String code;

    private String longDescription;

    private String shortDescription;
}

