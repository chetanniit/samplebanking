package com.natwest.pbbdhb.brokerdocs.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.utils.EventLogger;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.HandlerMethodValidationException;


import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
public class ErrorHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandler.class);


    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EventLogger eventLogger;

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException ex) {

        List<String> errorMessages = ex.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.toList());

        LOGGER.error("ConstraintViolationException while processing request, Error messages - {}", errorMessages);
        eventLogger.logException(ex,HttpStatus.BAD_REQUEST, ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(errorMessages), HttpStatus.BAD_REQUEST);
    }


    private HttpStatus getStatus(String statusCode) {
        switch (statusCode) {
            case "401":
                return HttpStatus.UNAUTHORIZED;
            case "400":
                return HttpStatus.BAD_REQUEST;
            case "403":
                return HttpStatus.FORBIDDEN;
            case "404":
                return HttpStatus.NOT_FOUND;
            default:
                return HttpStatus.INTERNAL_SERVER_ERROR;
        }

    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        LOGGER.error("MethodArgumentNotValid error during processing: {}", ex.getMessage());
        ErrorResponse errorResponse = new ErrorResponse();
        ex.getBindingResult().getAllErrors();

        for (ObjectError objectError : ex.getBindingResult().getAllErrors()) {
            if (objectError instanceof FieldError) {
                FieldError fieldError = (FieldError) objectError;
                errorResponse.addError(fieldError.getDefaultMessage());
                LOGGER.error("MethodArgumentNotValid error during processing on field {}", fieldError.getField());
            } else {
                errorResponse.addError(objectError.getDefaultMessage());
                LOGGER.error("MethodArgumentNotValid error during processing - non fieldError");
            }
        }
        eventLogger.logException(ex,HttpStatus.BAD_REQUEST, ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({BrokerDetailValidateFailureException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> brokerValidationFailureException(BrokerDetailValidateFailureException ex) {
        LOGGER.error("BrokerDetailValidateFailureException error during processing: code = {}, message ={}"
                , ex.getStatusCode(), ex.getMessage());
        eventLogger.logException(ex, getStatus(ex.getStatusCode()), ex.getMessage());

        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), getStatus(ex.getStatusCode()));

    }

    @ExceptionHandler({MRNValidateFailureException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> MRNValidationFailureException(MRNValidateFailureException ex) {
        LOGGER.error("MRNValidateFailureException error during processing: code = {}, message ={}"
                , ex.getStatusCode(), ex.getMessage());
        eventLogger.logException(ex, getStatus(ex.getStatusCode()), ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), getStatus(ex.getStatusCode()));

    }

    @ExceptionHandler({JsonProcessingException.class, HttpMessageNotReadableException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleJsonProcessingException(Exception ex) {
        LOGGER.error("Input processing error ({}): {}", ex.getClass().getName(), ex.getMessage());
        eventLogger.logException(ex, HttpStatus.BAD_REQUEST, ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);

    }

    @ExceptionHandler({SessionTokenFetchFailureException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleSessionTokenFetchException(SessionTokenFetchFailureException ex) {
        LOGGER.error("SessionTokenFetchFailureException error ({}): {}", ex.getStatusCode(), ex.getMessage());
        eventLogger.logException(ex, HttpStatus.valueOf(ex.getStatusCode()), ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);

    }

    @ExceptionHandler({Exception.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleUnhandledException(Exception ex) {
        String errorMessage = ex.getMessage();
        LOGGER.error("{}: {}", ex.getClass().getSimpleName(), errorMessage);
        eventLogger.logException(ex, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(errorMessage), HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(HandlerMethodValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ResponseEntity<ErrorResponse> handleHandlerMethodValidationException(HandlerMethodValidationException ex) {
        String errorMessage = ex.getMessage();
        LOGGER.error("{}: {}", ex.getClass().getSimpleName(), errorMessage);
        eventLogger.logException(ex, HttpStatus.BAD_REQUEST, ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(errorMessage), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ResponseEntity<ErrorResponse> handleRequestHeaderException(MissingRequestHeaderException ex) {
        String errorMessage = ex.getMessage();
        LOGGER.error("{}: {}", ex.getClass().getSimpleName(), errorMessage);
        eventLogger.logException(ex, HttpStatus.BAD_REQUEST, ex.getMessage());
        return new ResponseEntity<>(new ErrorResponse(errorMessage), HttpStatus.BAD_REQUEST);
    }

}
