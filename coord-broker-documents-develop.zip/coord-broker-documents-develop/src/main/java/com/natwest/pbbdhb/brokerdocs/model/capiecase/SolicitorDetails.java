package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SolicitorDetails {

    private Integer associateSequenceNumber;

    private String alphaKey;

    private CodeDescription solicitorAssociateType;

    private String companyCode;

    private String companyName;

    private String contactName;

    private String branchCode;

    private String branchName;

    private BasicAddress solicitorAddress;

    private CodeDescription solicitorStatus;

    private String solePractitioner;

    private Integer documentExchangeNumber;

    private List<Telephone> solicitorTelephone;

    private String emailAddress;
}

