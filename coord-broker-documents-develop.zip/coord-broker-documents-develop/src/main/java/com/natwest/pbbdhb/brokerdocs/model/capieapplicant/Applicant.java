package com.natwest.pbbdhb.brokerdocs.model.capieapplicant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Applicant {

    String applicantId;
    String caseId;
    Boolean mainApplicant;
    String cin;
}
