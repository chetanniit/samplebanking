package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IndirectSource {

    private Boolean primary;

    private Integer sourceId;

    private String sourceEmail;

    private String sourceName;

    private BrokerFee brokerFee;
}
