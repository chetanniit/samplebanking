package com.natwest.pbbdhb.brokerdocs.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rbs.pbbdhb.common.validation.PostcodeValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode


public class Broker {

    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9.!#$%'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";

    @Schema(example = "123456", minLength = 4, maxLength = 7, description = "Must contain numeric value, fcaNumber allows max 7 characters and min 4 characters", required = true)
    @Pattern(regexp = "[0-9]{4,7}+", message = "fcaNumber is invalid or contains less than 4 characters or more than 7 characters")
    @NotBlank(message = "fcaNumber cannot be null or empty")
    private String fcaNumber;


    @Schema(example = "Abraham", required = true, minLength = 2, maxLength = 50, description = "Broker surname, maximum 50 characters")
    @NotBlank(message = "brokerSurname cannot be null or empty.")
    @Pattern(regexp = "^[A-Za-z0-9 .'-]{2,50}+$", message = "brokerSurname is invalid or contains less than 2 characters or more than 50 characters")
    private String brokerSurname;

    @Schema(example = "LincolnAbraham", description = "Broker username, maximum 100 characters", required = true, minLength = 2, maxLength = 100)
    @Pattern(regexp = "^[A-Za-z0-9]{2,100}+$", message = "brokerUsername is invalid or contains less than 2 characters or more than 100 characters")
    @NotBlank(message = "brokerUsername cannot be null or empty")
    private String brokerUsername;

    @Schema(example = "Lincoln", minLength = 2, maxLength = 50, description = "Broker forename, maximum 50 characters")
    @Pattern(regexp = "^[A-Za-z0-9 .'-]{2,50}+$", message = "brokerForeName is invalid or contains less than 2 characters or more than 50 characters")
    private String brokerForeName;


    @Schema(example = "EC2R 8AH", description = "Broker postcode maximum 8 characters", maxLength = 8)
    @Pattern(regexp = PostcodeValidator.VALID_POSTCODE_REGEX, message = "brokerPostcode is invalid")
    private String brokerPostcode;

    @Schema(example = "brokerEmail@rbs.com", maxLength = 72, description = "Email address for Broker, maximum characters 72", required = true)
    @Pattern(regexp = EMAIL_PATTERN, message = "Please enter valid email Id for Broker")
    @Length(max = 72, message = "brokerEmail exceeds max 72 characters length")
    @NotBlank(message = "brokerEmail cannot be null or empty")
    private String brokerEmail;


}