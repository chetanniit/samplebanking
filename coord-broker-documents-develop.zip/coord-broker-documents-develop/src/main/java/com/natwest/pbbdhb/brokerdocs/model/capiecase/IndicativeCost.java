package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IndicativeCost {
    private MinMaxRepayment capitalAndInterest;
    private MinMaxRepayment interestOnly;
}
