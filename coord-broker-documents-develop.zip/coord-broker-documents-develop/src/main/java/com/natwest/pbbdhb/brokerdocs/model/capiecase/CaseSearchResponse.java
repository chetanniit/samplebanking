package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CaseSearchResponse {
    List<CaseApplication> content;
}
