package com.natwest.pbbdhb.brokerdocs.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@EqualsAndHashCode
@NoArgsConstructor
public class ErrorResponse {
    @JsonProperty("errors")
    private List<String> errors = null;

    public ErrorResponse(String error) {
        this.addError(error);
    }

    public ErrorResponse(List<String> errors) {
        this.addError(errors);
    }

    public ErrorResponse addError(String error) {
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }
        this.errors.add(error);
        return this;
    }

    public ErrorResponse addError(List<String> errors) {
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }
        this.errors.addAll(errors);
        return this;
    }
}
