package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class InterestOnly {

    private List<RepaymentDetail> repaymentDetails;
}

