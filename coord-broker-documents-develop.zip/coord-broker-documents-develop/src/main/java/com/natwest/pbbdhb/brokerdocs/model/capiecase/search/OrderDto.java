package com.natwest.pbbdhb.brokerdocs.model.capiecase.search;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrderDto {
    private String direction;
    private String field;
    private boolean ignoreCase;
    private String nullHandling;
}
