package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class Mortgage {

    private Long propertyValue;

    private Long purchasePrice;

    private List<Deposit> deposits;

    private Long outstandingMortgage;

    private List<AdditionalBorrowing> additionalBorrowing;

    private Long mortgageAmount;

    private Integer mortgageTermYears;

    private Integer mortgageTermMonths;

    private String mortgageType;

    private String mortgageAdvised;

    private MortgageAdvisor mortgageAdvisor;

    private Boolean mortgagePrisoner;

    private Boolean rightToBuy;

    private Boolean mortgageGuarantee;

    private InterestOnly interestOnly;

    private Long interestOnlyAmount;

    private Integer interestOnlyTermMonths;

    private Integer interestOnlyTermYears;

    private List<Fee> fees;
}

