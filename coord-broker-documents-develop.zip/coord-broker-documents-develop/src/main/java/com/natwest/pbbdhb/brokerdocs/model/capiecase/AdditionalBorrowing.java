package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class AdditionalBorrowing {

    private Long amount;

    private String reason;

    private String borrowingDetails;
}

