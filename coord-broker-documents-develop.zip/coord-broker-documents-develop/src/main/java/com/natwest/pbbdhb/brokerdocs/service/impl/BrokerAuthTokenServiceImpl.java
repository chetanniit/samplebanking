package com.natwest.pbbdhb.brokerdocs.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.SessionTokenFetchFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.brokerauthtoken.BrokerAuthTokenRequest;
import com.natwest.pbbdhb.brokerdocs.model.brokerauthtoken.BrokerAuthTokenResponse;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;
import com.natwest.pbbdhb.brokerdocs.service.BrokerAuthTokenService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class BrokerAuthTokenServiceImpl implements BrokerAuthTokenService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BrokerAuthTokenServiceImpl.class);

    @Value("${broker.auth.token.endpoint}")
    private String brokerAuthTokenEndpoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    ObjectMapper mapper;

    @Override
    public String getSessionAuthToken(String caseId, String mortgageReferenceNumber, Broker broker, Applicant mainApplicant, String brand) {


        BrokerAuthTokenRequest request = BrokerAuthTokenRequest.builder()
                .brokerUserName(broker.getBrokerUsername())
                .applicantId(mainApplicant.getApplicantId())
                .caseId(caseId)
                .cin(mainApplicant.getCin()).build();
        LOGGER.info("DUR 6.1 calling broker auth token service at url {} for caseId : {}, mrn : {}, brand : {}", brokerAuthTokenEndpoint, caseId, mortgageReferenceNumber, brand);
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.add("brand", brand);
        HttpEntity<BrokerAuthTokenRequest> httpEntity = new HttpEntity<>(request, headers);
        BrokerAuthTokenResponse response = null;
        try {
            response = restTemplate.postForObject(brokerAuthTokenEndpoint, httpEntity, BrokerAuthTokenResponse.class);
        } catch (Exception e) {
            LOGGER.error("DUR 6.2 Error while fetching session auth token for caseId={}, mrn={}, brand={}, error = {}",
                    caseId, mortgageReferenceNumber, brand, e.getMessage());
            throw new SessionTokenFetchFailureException("500", "Error While fetching session auth token");
        }
        LOGGER.info("DUR 6.3 broker auth token generated successfully for caseId : {}, mrn : {}, brand : {}", caseId, mortgageReferenceNumber, brand);
        return response.getAccessToken();
    }
}
