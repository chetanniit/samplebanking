package com.natwest.pbbdhb.brokerdocs.model.capiecase.search;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public abstract class OperatorDto {
    public enum OperatorType {
        OR, AND, SIMPLE
    }

    public abstract OperatorType getType();

}
