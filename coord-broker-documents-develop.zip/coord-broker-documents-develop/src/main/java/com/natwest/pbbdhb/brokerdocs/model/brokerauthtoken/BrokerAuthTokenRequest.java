package com.natwest.pbbdhb.brokerdocs.model.brokerauthtoken;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerAuthTokenRequest {
    private Map<String, String> tokenClaims;
    private String brokerUserName;
    private String applicantId;
    private String caseId;
    private String cin;
}
