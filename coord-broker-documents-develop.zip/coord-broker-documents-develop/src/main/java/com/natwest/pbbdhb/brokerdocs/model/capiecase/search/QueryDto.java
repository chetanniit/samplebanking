package com.natwest.pbbdhb.brokerdocs.model.capiecase.search;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class QueryDto {
    private OperatorDto operator;
}
