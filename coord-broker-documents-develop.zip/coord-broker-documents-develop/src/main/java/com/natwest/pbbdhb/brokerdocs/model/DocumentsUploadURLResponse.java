package com.natwest.pbbdhb.brokerdocs.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class DocumentsUploadURLResponse {
    String documentUploadURL;
}
