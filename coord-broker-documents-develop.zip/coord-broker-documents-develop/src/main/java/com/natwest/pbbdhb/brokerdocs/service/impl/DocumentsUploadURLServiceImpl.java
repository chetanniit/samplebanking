package com.natwest.pbbdhb.brokerdocs.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;
import com.natwest.pbbdhb.brokerdocs.service.BrokerAuthTokenService;
import com.natwest.pbbdhb.brokerdocs.service.BrokerDetailValidateService;
import com.natwest.pbbdhb.brokerdocs.service.CapieService;
import com.natwest.pbbdhb.brokerdocs.service.DocumentsUploadURLService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Service
public class DocumentsUploadURLServiceImpl implements DocumentsUploadURLService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentsUploadURLServiceImpl.class);

    @Autowired
    BrokerDetailValidateService brokerDetailValidateService;

    @Autowired
    CapieService capieService;

    @Autowired
    BrokerAuthTokenService brokerAuthTokenService;

    @Autowired
    ObjectMapper mapper;


    @Value("${spa.document.upload.url}")
    private String documentUploadURL;

    @Value("${api.metrics.client.id}")
    private String apiMetricsClientId;

    @Override
    public DocumentsUploadURLResponse getDocumentsUploadURL(Broker broker, String mortgageReferenceNumber, String brand, String clientId) throws JsonProcessingException {
        LOGGER.debug("DUR 2.1 : getDocumentsUploadURL called with mrn : {}, brand : {} and brokerdetails : {}"
                , mortgageReferenceNumber, brand, mapper.writeValueAsString(broker));
        LOGGER.info("DUR 2.1 : getDocumentsUploadURL called with mrn : {}, brand : {} and broker FCA NUMBER: {}"
                , mortgageReferenceNumber, brand, broker.getFcaNumber());


        if ((!ObjectUtils.isEmpty(apiMetricsClientId)) && (apiMetricsClientId.equals(clientId))) {
            return createMockResponseForApiMetrics();
        }

        brokerDetailValidateService.validateBroker(broker);

        String caseId = capieService.validateMRN(mortgageReferenceNumber, brand, broker);

        Applicant mainApplicant = capieService.getMainApplicantData(caseId, brand);

        String sessionToken = brokerAuthTokenService.getSessionAuthToken(caseId, mortgageReferenceNumber, broker, mainApplicant, brand);

        LOGGER.debug("DUR 2.2 : getDocumentsUploadURL completed for mrn : {}, brand : {} and brokerdetails : {}"
                , mortgageReferenceNumber, brand, mapper.writeValueAsString(broker));
        LOGGER.debug("DUR 2.2 : getDocumentsUploadURL completed for mrn : {}, brand : {} and broker FCA NUMBER: {}"
                , mortgageReferenceNumber, brand, broker.getFcaNumber());

        return DocumentsUploadURLResponse.builder().documentUploadURL(String.format(documentUploadURL,
                sessionToken)).build();
    }

    private DocumentsUploadURLResponse createMockResponseForApiMetrics() {
        return DocumentsUploadURLResponse.builder().documentUploadURL(String.format(documentUploadURL, "test_session_token")).build();
    }


}
