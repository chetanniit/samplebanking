package com.natwest.pbbdhb.brokerdocs.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TokenDetails {

    private String applicantId;
    private String caseId;
    private String cin;

}
