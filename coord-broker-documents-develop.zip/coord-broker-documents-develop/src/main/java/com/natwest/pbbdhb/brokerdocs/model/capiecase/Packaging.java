package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

/**
 * @author lukasz.jozefowicz@natwest.com on 21/06/2022
 */
@Getter
@Setter
public class Packaging {
    private String app1PaySlipsReq;
    private String app1BankStmntsReq;
    private String app2PaySlipsReq;
    private String app2BankStmntsReq;
    private String app1AccountsReq;
    private String app1TaxCalc;
    private String app1PerAndBusBankStmntsReq;
    private String app2AccountsReq;
    private String app2TaxCalc;
    private String app2PerAndBusBankStmntsReq;
}
