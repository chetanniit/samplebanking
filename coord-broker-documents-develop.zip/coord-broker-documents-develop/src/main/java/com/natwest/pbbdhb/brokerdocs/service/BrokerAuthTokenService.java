package com.natwest.pbbdhb.brokerdocs.service;

import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;

public interface BrokerAuthTokenService {
    String getSessionAuthToken(String caseId, String mortgageReferenceNumber, Broker broker, Applicant mainApplicant, String brand);
}
