package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceLevel {

    private String interview;

    private String levelOfService;
}

