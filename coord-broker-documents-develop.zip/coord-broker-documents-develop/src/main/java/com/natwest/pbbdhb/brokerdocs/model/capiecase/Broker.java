package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;


@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Broker {

    private String fcaNumber;

    private String brokerSurname;

    @JsonProperty("brokerForename")
    private String brokerForeName;

    private String brokerPostcode;

    private String brokerEmail;

    private String brokerUsername;
}