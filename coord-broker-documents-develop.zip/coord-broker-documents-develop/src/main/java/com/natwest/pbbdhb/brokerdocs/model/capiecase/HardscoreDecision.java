package com.natwest.pbbdhb.brokerdocs.model.capiecase;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class HardscoreDecision {

    private String mortgageReferenceNumber;

    private String caseId;

    private String decisionUniqueId;

    private String decision;

    private String podDecision;

    private List<Policy> policyMessages;

    private List<Policy> kycMessages;
}
