package com.natwest.pbbdhb.brokerdocs.model.capiecase.search;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import static com.natwest.pbbdhb.brokerdocs.model.capiecase.search.OperatorDto.OperatorType.SIMPLE;

@Setter
@Getter
@Builder
public class SimpleOperatorDto extends OperatorDto {
    private CompareType compareType;
    private String field;
    private String value;

    public enum CompareType {
        EQ, LIKE
    }

    @Override
    public OperatorType getType() {
        return SIMPLE;
    }
}
