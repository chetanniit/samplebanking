package com.natwest.pbbdhb.brokerdocs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;

public interface CapieService {
    String validateMRN(String mortgageRefNumber, String brand, Broker broker) throws JsonProcessingException;
    Applicant getMainApplicantData(String caseId, String brand) throws JsonProcessingException;

}
