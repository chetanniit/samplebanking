package com.natwest.pbbdhb.brokerdocs.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;

public interface BrokerDetailValidateService {

    void validateBroker(Broker broker) throws JsonProcessingException;

}
