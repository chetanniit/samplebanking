package com.natwest.pbbdhb.brokerdocs.model.brokervalidation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public class BrokerDetailValidateRequest {

    @JsonProperty
    private String fcaNumber;

    @JsonProperty
    private String brokerForeName;

    @JsonProperty
    private String brokerSurname;

    @JsonProperty
    private String brokerEmail;

    @JsonProperty
    private String brokerPostcode;

    @JsonProperty
    private String brokerUsername;

}
