package com.natwest.pbbdhb.brokerdocs.utils;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import static com.natwest.pbbdhb.brokerdocs.utils.Constants.DOC_GEN;
import static com.natwest.pbbdhb.brokerdocs.utils.Constants.EXCEPTION;
import static com.natwest.pbbdhb.brokerdocs.utils.Constants.SUBMISSIONS;
import static com.natwest.pbbdhb.brokerdocs.utils.Constants.SUCCESS;

@Service
@Slf4j
public class EventLogger {


    public void logException(Throwable ex, HttpStatus statusCode) {
        logException(ex, statusCode, null, null);
    }

    public void logException(Throwable ex, HttpStatus statusCode, String message) {
        logException(ex, statusCode, message, null);
    }

    public void logException(Throwable ex, HttpStatus statusCode, String message, String source) {
        log.error(
                LogMessage.builder()
                        .system(DOC_GEN)
                        .type(EXCEPTION)
                        .description(String.format(
                                "exception=%s message=%s responseStatus=%s",
                                ex != null ? ex.getClass().getSimpleName() : "",
                                statusCode != null ? removeSpaces(
                                        String.format("%d-%s", statusCode.value(), message)) : "",
                                statusCode != null ? statusCode.value() : "")
                        )
                        .build());
    }

    public void logDocGenResult(String mortgageReferenceNumber, String brand, String clientId) {
        log.info(
                LogMessage.builder()
                        .system(DOC_GEN)
                        .type(SUCCESS)
                        .description(String.format(
                                "mortgageReferenceNumber=%s brand=%s clientId=%s responseStatus=%s",
                                mortgageReferenceNumber, brand, clientId, HttpStatus.OK.value()))
                        .build());
    }

    public void logDocGenSubmission(String mortgageReferenceNumber, String brand, String clientId) {
        log.info(
                LogMessage.builder()
                        .system(DOC_GEN)
                        .type(SUBMISSIONS)
                        .description(String.format(
                                "mortgageReferenceNumber=%s brand=%s clientId=%s",
                                mortgageReferenceNumber, brand, clientId))
                        .build());
    }


    // application logs are space-delimited key-value pairs
    // we will need to remove additional spaces
    public String removeSpaces(String text) {
        if (text == null) {
            return "";
        }
        return text.replaceAll("\\s+", "-");

    }
}

