package com.natwest.pbbdhb.brokerdocs.utils;

public class Constants {
    public static final String EXCEPTION = "Exception";
    public static final String DOC_GEN = "DocGen";
    public static final String SUBMISSIONS = "submissions";
    public static final String SUCCESS = "success";
}
