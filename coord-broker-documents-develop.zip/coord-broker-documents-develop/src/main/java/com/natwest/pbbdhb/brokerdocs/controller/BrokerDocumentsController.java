package com.natwest.pbbdhb.brokerdocs.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.ErrorResponse;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.brokerdocs.service.DocumentsUploadURLService;
import com.natwest.pbbdhb.brokerdocs.utils.EventLogger;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BrokerDocumentsController {

    private static final Logger LOGGER = LoggerFactory.getLogger(BrokerDocumentsController.class);

    @Autowired
    DocumentsUploadURLService documentsUploadURLService;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    EventLogger eventLogger;

    @Operation(summary = "Get Document Upload UI URL", operationId = "getDocumentsUploadURL", tags = {"Get Document Upload UI URL"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = DocumentsUploadURLResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised", content = {@Content()}),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = {@Content()}),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = {@Content()}),
                    @ApiResponse(responseCode = "422", description = "Unprocessable Entity", content = {@Content()}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content()})
            })
    @PostMapping(path = "/documents/{mortgageReferenceNumber}/get-upload-page", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public DocumentsUploadURLResponse getDocumentsUploadURL(
            @Parameter(description = "Brand", example = "nwb")
            @RequestHeader("brand") @Valid @Pattern(regexp = "(rbs|nwb)",
                    message = "Invalid Brand") String brand,
            @RequestHeader(value = "client_id", required = false) String clientId,
            @Parameter(description = "mortgageReferenceNumber", example = "35273488")
            @Valid @PathVariable("mortgageReferenceNumber") String mortgageReferenceNumber,
            @Valid @RequestBody Broker broker) throws JsonProcessingException {
        eventLogger.logDocGenSubmission(mortgageReferenceNumber, brand, clientId);
        LOGGER.debug("DUR 1.1 : getDocumentsUploadURL: called with mortgageReferenceNumber={} brand={} broker details={}",
                mortgageReferenceNumber, brand, mapper.writeValueAsString(broker));
        LOGGER.info("DUR 1.1 : getDocumentsUploadURL: called with mortgageReferenceNumber={} brand={}",
                mortgageReferenceNumber, brand);
        DocumentsUploadURLResponse documentsUploadURLResponse = documentsUploadURLService.getDocumentsUploadURL(broker, mortgageReferenceNumber, brand, clientId);
        eventLogger.logDocGenResult(mortgageReferenceNumber, brand, clientId);
        LOGGER.debug("DUR 1.2 : getDocumentsUploadURL: completed for mortgageReferenceNumber={} brand={} broker details={}",
                mortgageReferenceNumber, brand, mapper.writeValueAsString(broker));
        LOGGER.info("DUR 1.2 : getDocumentsUploadURL: completed for mortgageReferenceNumber={} brand={}",
                mortgageReferenceNumber, brand);
        return documentsUploadURLResponse;
    }
}
