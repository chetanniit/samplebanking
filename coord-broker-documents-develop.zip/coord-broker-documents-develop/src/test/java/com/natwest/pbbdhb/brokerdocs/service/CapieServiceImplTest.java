package com.natwest.pbbdhb.brokerdocs.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.CaseApplication;
import com.natwest.pbbdhb.brokerdocs.model.capiecase.CaseSearchResponse;
import com.natwest.pbbdhb.brokerdocs.service.impl.CapieServiceImpl;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {CapieServiceImpl.class})
public class CapieServiceImplTest {

    private final static String CASE_ID = "case_id";
    private static final String MRN = "mrn";
    private static final String BRAND = "NATWEST";

    @MockBean
    private ObjectMapper objectMapper;

    @MockBean(name = "iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${case.service.search.endpoint}")
    private String caseServiceSearchUrl;

    @Value("${applicant.service.get.endpoint}")
    private String applicantServiceGetUrl;

    @Autowired
    private CapieService capieService;

    @Test
    public void testValMRN() throws JsonProcessingException {
        Broker inputBroker = Broker.builder().fcaNumber("testFCA").brokerEmail("testEmail").brokerSurname("testsurname").brokerUsername("testUserName").build();

        com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker caseBroker =
                com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker.builder().fcaNumber("testFCA").brokerEmail("testEmail").brokerSurname("testsurname").brokerUsername("testUserName").build();

        CaseApplication caseApplication = CaseApplication.builder().caseId(CASE_ID).mortgageReferenceNumber(MRN).broker(caseBroker).build();
        CaseSearchResponse caseSearchResponse = CaseSearchResponse.builder().content(Collections.singletonList(caseApplication)).build();
        ReflectionTestUtils.setField(capieService, "caseServiceSearchUrl", caseServiceSearchUrl);
        when(restTemplate.postForObject(same(caseServiceSearchUrl), any(), same(CaseSearchResponse.class))).thenReturn(caseSearchResponse);
        String mortgageRefNo = capieService.validateMRN(MRN, BRAND, inputBroker);

        Assert.assertEquals(caseSearchResponse.getContent().get(0).getCaseId(), mortgageRefNo);

    }

    @Test
    public void testValMRN_InvalidMRNException() throws JsonProcessingException {
        Broker inputBroker = Broker.builder().fcaNumber("testFCA").build();

        ReflectionTestUtils.setField(capieService, "caseServiceSearchUrl", caseServiceSearchUrl);

        when(restTemplate.postForObject(same(caseServiceSearchUrl), any(), same(CaseSearchResponse.class))).thenReturn(null);

        MRNValidateFailureException exception = assertThrows(MRNValidateFailureException.class, () -> {
            capieService.validateMRN(MRN, BRAND, inputBroker);
        });

        Assert.assertEquals("Invalid Mortgage Reference Number", exception.getMessage());

    }

    @Test
    public void testValMRN_InvalidBrokerDetails() throws JsonProcessingException {
        Broker inputBroker = Broker.builder().fcaNumber("testFCA").build();
        com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker caseBroker =
                com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker.builder().fcaNumber("testFCA_mismatch").build();

        ReflectionTestUtils.setField(capieService, "caseServiceSearchUrl", caseServiceSearchUrl);

        CaseApplication caseApplication = CaseApplication.builder().caseId(CASE_ID).mortgageReferenceNumber(MRN).broker(caseBroker).build();

        CaseSearchResponse caseSearchResponse = CaseSearchResponse.builder().content(Collections.singletonList(caseApplication)).build();

        when(restTemplate.postForObject(same(caseServiceSearchUrl), any(), same(CaseSearchResponse.class))).thenReturn(caseSearchResponse);

        MRNValidateFailureException exception = assertThrows(MRNValidateFailureException.class, () -> {
            capieService.validateMRN(MRN, BRAND, inputBroker);
        });

        Assert.assertEquals("Only the broker who created the FMA can upload the document", exception.getMessage());

        Assert.assertEquals("403", exception.getStatusCode());

    }

    @Test
    public void testGetMainApplicantData() throws JsonProcessingException {
        Applicant mainApplicant = Applicant.builder().applicantId("1234").mainApplicant(true).build();
        Applicant jointApplicant = Applicant.builder().applicantId("3456").mainApplicant(true).build();
        List<Applicant> response = Arrays.asList(mainApplicant, jointApplicant);
        ReflectionTestUtils.setField(capieService, "applicantServiceGetUrl", applicantServiceGetUrl);

        when(restTemplate.exchange(same(applicantServiceGetUrl), any(), any(), eq(new ParameterizedTypeReference<List<Applicant>>() {
        }), same(CASE_ID))).thenReturn(ResponseEntity.ok(response));
        Applicant responseMainApplicant = capieService.getMainApplicantData(CASE_ID, "nwb");
        Assert.assertEquals(mainApplicant.getApplicantId(), responseMainApplicant.getApplicantId());
    }

    @Test
    public void testGetMainApplicantData_Failure() throws JsonProcessingException {
        Applicant mainApplicant = Applicant.builder().applicantId("1234").mainApplicant(true).build();
        Applicant jointApplicant = Applicant.builder().applicantId("3456").mainApplicant(true).build();
        List<Applicant> response = Arrays.asList(mainApplicant, jointApplicant);
        ReflectionTestUtils.setField(capieService, "applicantServiceGetUrl", applicantServiceGetUrl);

        when(restTemplate.exchange(same(applicantServiceGetUrl), any(), any(), eq(new ParameterizedTypeReference<List<Applicant>>() {
        }), same(CASE_ID))).thenThrow(new RuntimeException());
        MRNValidateFailureException exception = assertThrows(MRNValidateFailureException.class, () -> {
            capieService.getMainApplicantData(CASE_ID, "nwb");
        });
        Assert.assertEquals("Error while fetching applicant data", exception.getMessage());

        Assert.assertEquals("500", exception.getStatusCode());
    }


    @Test
    public void getCaseData_Failure() throws JsonProcessingException {
        Broker inputBroker = Broker.builder().fcaNumber("testFCA").build();
        com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker caseBroker =
                com.natwest.pbbdhb.brokerdocs.model.capiecase.Broker.builder().fcaNumber("testFCA_mismatch").build();

        ReflectionTestUtils.setField(capieService, "caseServiceSearchUrl", caseServiceSearchUrl);

        CaseApplication caseApplication = CaseApplication.builder().caseId(CASE_ID).mortgageReferenceNumber(MRN).broker(caseBroker).build();

        CaseSearchResponse caseSearchResponse = CaseSearchResponse.builder().content(Collections.singletonList(caseApplication)).build();

        when(restTemplate.postForObject(same(caseServiceSearchUrl), any(), same(CaseSearchResponse.class))).thenThrow(new RuntimeException());

        MRNValidateFailureException exception = assertThrows(MRNValidateFailureException.class, () -> {
            capieService.validateMRN(MRN, BRAND, inputBroker);
        });

        Assert.assertEquals("Error while fetching case data", exception.getMessage());

        Assert.assertEquals("500", exception.getStatusCode());
    }

}

