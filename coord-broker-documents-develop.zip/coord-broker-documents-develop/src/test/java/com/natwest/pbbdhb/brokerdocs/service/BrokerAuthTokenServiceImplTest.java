package com.natwest.pbbdhb.brokerdocs.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.SessionTokenFetchFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.brokerauthtoken.BrokerAuthTokenResponse;
import com.natwest.pbbdhb.brokerdocs.model.capieapplicant.Applicant;
import com.natwest.pbbdhb.brokerdocs.service.impl.BrokerAuthTokenServiceImpl;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {BrokerAuthTokenServiceImpl.class})
public class BrokerAuthTokenServiceImplTest {

    private static final String ACCESS_TOKEN = "access_token";
    private static final String CASE_ID = "case_id";
    private static final String MRN = "mrn";
    private static final String BRAND = "NATWEST";


    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper mapper;

    @Value("${broker.auth.token.endpoint}")
    private String brokerAuthTokenEndpoint;

    @InjectMocks
    private BrokerAuthTokenServiceImpl brokerAuthTokenService;

    @Test
    public void testSessionAuthToken() {
        BrokerAuthTokenResponse tokenResponse = BrokerAuthTokenResponse.builder().accessToken(ACCESS_TOKEN).build();
        ReflectionTestUtils.setField(brokerAuthTokenService, "brokerAuthTokenEndpoint", brokerAuthTokenEndpoint);
        ReflectionTestUtils.setField(brokerAuthTokenService, "mapper", new ObjectMapper());
        when(restTemplate.postForObject(same(brokerAuthTokenEndpoint), any(), same(BrokerAuthTokenResponse.class))).thenReturn(tokenResponse);
        String getAccess_token = brokerAuthTokenService.getSessionAuthToken(CASE_ID, MRN, Broker.builder().build(), Applicant.builder().build(), BRAND);
        Assert.assertEquals(ACCESS_TOKEN, getAccess_token);

    }

    @Test
    public void testSessionAuthToken_Exception() {
        SessionTokenFetchFailureException sessionFailure = new SessionTokenFetchFailureException("500", "Error While fetching session auth token");
        SessionTokenFetchFailureException sessionError = Assertions.assertThrows(SessionTokenFetchFailureException.class, () -> {
            ReflectionTestUtils.setField(brokerAuthTokenService, "brokerAuthTokenEndpoint", brokerAuthTokenEndpoint);
            ReflectionTestUtils.setField(brokerAuthTokenService, "mapper", new ObjectMapper());
            when(restTemplate.postForObject(same(brokerAuthTokenEndpoint), any(), same(BrokerAuthTokenResponse.class))).thenThrow(HttpClientErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "Error While fetching session auth token", null, null, null));
            brokerAuthTokenService.getSessionAuthToken(CASE_ID, MRN, Broker.builder().build(), Applicant.builder().build(), BRAND);
        });
        assertEquals(sessionFailure.getStatusCode(), sessionError.getStatusCode());


    }
}
