package com.natwest.pbbdhb.brokerdocs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.brokerdocs.service.impl.DocumentsUploadURLServiceImpl;
import com.natwest.pbbdhb.brokerdocs.utils.EventLogger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {DocumentsUploadURLServiceImpl.class})
public class DocumentsUploadURLServiceImplTest {

    private static final String CASE_ID = "REF2022062713231536";
    private static final String MRN = "1234567654321";
    private static final String BRAND = "nwb";
    private static final String ACCESS_TOKEN = "xyzabc";

    @Value("${broker.detail.validate.endpoint}")
    private String brokerDetailValidateEndpoint;

    @MockBean
    private ObjectMapper objectMapper;

    @MockBean
    private ModelMapper modelMapper;

    @Autowired
    private DocumentsUploadURLService documentsUploadURLService;

    @MockBean
    private BrokerDetailValidateService brokerDetailValidateService;

    @MockBean
    private CapieService capieService;

    @MockBean
    private BrokerAuthTokenService brokerAuthTokenService;

    @MockBean
    private EventLogger eventLogger;

    @MockBean(name = "iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${spa.document.upload.url}")
    private String documentUploadURL;

    private static final String clientId = "clientID";

    @Test
    public void testDocumentUploadURL() throws JsonProcessingException {
        Broker broker = getBrokerDetails();

        brokerDetailValidateService.validateBroker(broker);

        when(capieService.validateMRN(anyString(), anyString(), any())).thenReturn(CASE_ID);

        when(brokerAuthTokenService.getSessionAuthToken(anyString(), anyString(), any(), any(), anyString())).thenReturn(ACCESS_TOKEN);
        DocumentsUploadURLResponse response = documentsUploadURLService.getDocumentsUploadURL(broker, MRN, BRAND, clientId);
        DocumentsUploadURLResponse docURL = DocumentsUploadURLResponse.builder().documentUploadURL(String.format(documentUploadURL, BRAND,
                ACCESS_TOKEN)).build();
        assertEquals(docURL, response);


    }

    private Broker getBrokerDetails() {
        return Broker.builder()
                .brokerEmail("ben@auxiliafs.com")
                .brokerForeName("Ben")
                .brokerSurname("Small")
                .fcaNumber("936469")
                .build();

    }
}
