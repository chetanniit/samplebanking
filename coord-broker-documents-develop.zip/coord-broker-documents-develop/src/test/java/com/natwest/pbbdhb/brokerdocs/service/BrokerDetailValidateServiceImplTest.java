package com.natwest.pbbdhb.brokerdocs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.BrokerDetailValidateFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.brokervalidation.BrokerDetailValidateRequest;
import com.natwest.pbbdhb.brokerdocs.model.brokervalidation.BrokerDetailValidateResponse;
import com.natwest.pbbdhb.brokerdocs.model.brokervalidation.FirmBroker;
import com.natwest.pbbdhb.brokerdocs.model.brokervalidation.PaymentPath;
import com.natwest.pbbdhb.brokerdocs.service.impl.BrokerDetailValidateServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {BrokerDetailValidateServiceImpl.class})
public class BrokerDetailValidateServiceImplTest {

    @Value("${broker.detail.validate.endpoint}")
    private String brokerDetailValidateEndpoint;

    @MockBean
    private ObjectMapper objectMapper;


    @Autowired
    BrokerDetailValidateService brokerDetailValidateService;

    @MockBean
    private ModelMapper modelMapper;

    @MockBean(name = "iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Test
    public void testValidateBroker_Success() throws JsonProcessingException {

        Broker broker = getBrokerDetails();

        BrokerDetailValidateRequest brokerDetailValidateRequest = mock(BrokerDetailValidateRequest.class);
        when(modelMapper.map(any(), eq(BrokerDetailValidateRequest.class))).thenReturn(brokerDetailValidateRequest);

        mockBrokerService();

        brokerDetailValidateService.validateBroker(broker);

        verify(modelMapper).map(any(), same(BrokerDetailValidateRequest.class));

    }

    @Test
    public void testValidateBroker_Failure() throws JsonProcessingException {
        Broker broker = getBrokerDetails();
        BrokerDetailValidateRequest brokerDetailValidateRequest = mock(BrokerDetailValidateRequest.class);
        when(modelMapper.map(any(), eq(BrokerDetailValidateRequest.class))).thenReturn(brokerDetailValidateRequest);

        when(restTemplate.postForObject(brokerDetailValidateEndpoint, brokerDetailValidateRequest, BrokerDetailValidateResponse.class)).thenReturn(null);

        assertThrows(BrokerDetailValidateFailureException.class, () -> brokerDetailValidateService.validateBroker(broker));

        verify(modelMapper).map(any(), eq(BrokerDetailValidateRequest.class));
    }

    @Test
    public void testValidateBroker_Exception() throws JsonProcessingException {
        BrokerDetailValidateFailureException brokerDetailValidateFailureException = new BrokerDetailValidateFailureException("500", "Interval Server Error");
        BrokerDetailValidateFailureException badRequestException = Assertions.assertThrows(BrokerDetailValidateFailureException.class, () -> {
            Broker broker = getBrokerDetails();
            ReflectionTestUtils.setField(brokerDetailValidateService, "brokerDetailValidateEndpoint", brokerDetailValidateEndpoint);
            when(restTemplate.postForObject(same(brokerDetailValidateEndpoint), any(), same(BrokerDetailValidateResponse.class))).thenThrow(HttpClientErrorException.NotFound.create("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", null, null, null));
            brokerDetailValidateService.validateBroker(broker);
        });
        assertEquals(brokerDetailValidateFailureException.getStatusCode(), badRequestException.getStatusCode());

    }

    @Test
    public void testValidateBroker_NotFoundException() throws JsonProcessingException {

        Broker broker = Broker.builder().brokerEmail("ben@auxiliafs.com").brokerSurname("Small").brokerForeName("Ben").fcaNumber("936469").build();
        ReflectionTestUtils.setField(brokerDetailValidateService, "brokerDetailValidateEndpoint", brokerDetailValidateEndpoint);
        when(restTemplate.postForObject(same(brokerDetailValidateEndpoint), any(), same(BrokerDetailValidateResponse.class))).thenThrow(HttpClientErrorException.NotFound.create(HttpStatus.NOT_FOUND, "Broker Data not found", null, null, null));
        BrokerDetailValidateFailureException exception = assertThrows(BrokerDetailValidateFailureException.class, () -> brokerDetailValidateService.validateBroker(broker));

        assertEquals("403", exception.getStatusCode());
        assertEquals("Not a valid broker", exception.getMessage());


    }

    private void mockBrokerService() throws JsonProcessingException {
        Set firmBrokerSet = new HashSet<FirmBroker>();
        Set paymentPathSet = new HashSet<PaymentPath>();
        FirmBroker firmBroker = FirmBroker.builder().brokerID("123").brokerForeName("abc").acceptMortgageBusiness("true").build();
        firmBrokerSet.add(firmBroker);

        PaymentPath paymentPath = PaymentPath.builder().paymentPathID("456").paymentPathName("BBC").build();
        paymentPathSet.add(paymentPath);


        BrokerDetailValidateRequest brokerDetailValidateRequest = mock(BrokerDetailValidateRequest.class);
        when(modelMapper.map(any(), eq(BrokerDetailValidateRequest.class))).thenReturn(brokerDetailValidateRequest);
        BrokerDetailValidateResponse brokerDetailValidateResponse = BrokerDetailValidateResponse.builder()
                .brokers(firmBrokerSet)
                .paymentPaths(paymentPathSet).build();

        when(restTemplate.postForObject(brokerDetailValidateEndpoint, brokerDetailValidateRequest, BrokerDetailValidateResponse.class)).thenReturn(brokerDetailValidateResponse);
    }

    private Broker getBrokerDetails() {
        return Broker.builder()
                .brokerEmail("ben@auxiliafs.com")
                .brokerForeName("Ben")
                .brokerSurname("Small")
                .fcaNumber("936469")
                .build();

    }


}