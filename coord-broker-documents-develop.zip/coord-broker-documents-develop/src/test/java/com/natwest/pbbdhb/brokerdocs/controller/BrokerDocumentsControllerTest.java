package com.natwest.pbbdhb.brokerdocs.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.brokerdocs.exception.MRNValidateFailureException;
import com.natwest.pbbdhb.brokerdocs.model.Broker;
import com.natwest.pbbdhb.brokerdocs.model.DocumentsUploadURLResponse;
import com.natwest.pbbdhb.brokerdocs.service.CapieService;
import com.natwest.pbbdhb.brokerdocs.service.DocumentsUploadURLService;
import com.natwest.pbbdhb.brokerdocs.utils.EventLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(BrokerDocumentsController.class)
public class BrokerDocumentsControllerTest {

    private static final String documentURL = "https://mortgages.natwest.com?brand=nwb&uploadtoken=xyz";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private DocumentsUploadURLService documentsUploadURLService;

    @MockBean
    private Broker broker;

    @MockBean
    private CapieService capieService;

    @MockBean
    private EventLogger eventLogger;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @org.junit.jupiter.api.Test
    public void testDocumentsUploadURLgeneration_Success() throws Exception {
        Broker broker = getBrokerDetails();
        DocumentsUploadURLResponse docUploadResponse = DocumentsUploadURLResponse.builder().documentUploadURL(documentURL).build();
        when(documentsUploadURLService.getDocumentsUploadURL(any(Broker.class), anyString(), anyString(), anyString()))
                .thenReturn(docUploadResponse);

        MvcResult response = mockMvc.perform(post("/documents/123/get-upload-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .header("client_id", "client_id")
                        .content(objectMapper.writeValueAsString(broker)))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        assertEquals("{\"documentUploadURL\":\"https://mortgages.natwest.com?brand=nwb&uploadtoken=xyz\"}", response.getResponse().getContentAsString());


    }

    @org.junit.jupiter.api.Test
    public void testDocumentsUploadURLgeneration_missingBrand() throws Exception {
        Broker broker = getBrokerDetails();
        MvcResult response = mockMvc.perform(post("/documents/123/get-upload-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(broker)))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getResponse().getStatus());

    }

    @org.junit.jupiter.api.Test
    public void testDocumentsUploadURLgeneration_invalidMRN() throws Exception {
        when(capieService.validateMRN(anyString(), anyString(), any())).thenThrow(
                new MRNValidateFailureException("400", "Invalid Mortgage Reference Number"));
        this.mockMvc.perform(post("/documents/123/get-upload-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb"))
                .andExpect(status().isBadRequest());

    }

    @org.junit.jupiter.api.Test
    public void testDocumentsUploadURLgeneration_InvalidBroker() throws Exception {
        Broker broker = Broker.builder().brokerEmail("ben@auxiliafs.com").brokerForeName("Ben").brokerSurname("Small").fcaNumber("0").build();

        MvcResult response = mockMvc.perform(post("/documents/123/get-upload-page")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("brand", "nwb")
                        .content(objectMapper.writeValueAsString(broker)))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getResponse().getStatus());


    }

    private Broker getBrokerDetails() {
        return Broker.builder()
                .brokerEmail("ben@auxiliafs.com")
                .brokerForeName("Ben")
                .brokerSurname("Small")
                .fcaNumber("936469")
                .brokerUsername("userName")
                .build();

    }


}
