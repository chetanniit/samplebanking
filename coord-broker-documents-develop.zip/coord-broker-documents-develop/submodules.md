#pcf-config and consul-properties submodules

The scripts subdirectories inside the pcf-config and consul-properties directories are actually git submodules
(with their own Bitbucket repositories) as shown below:

Directory | Submodule
:---:|:---:
.../pcf-config/scripts | sub-pcf-scripts
.../consul-properties | sub-consul-scripts


In order to ensure the required scripts are available and up to date
* `git clone --recurse-submodules `

and run before using the scripts
* `cd .../msvc-project`
* `git pull`
* `git submodule update --init`
* `git submodule foreach git pull origin master`

For further information consult readme.txt in each scripts directory/submodule.
