dws pcf operation create route --pcfenv dev-pnf --channel hboapiplatform --space nft --domainname nft-api.natwest.com --hostname coord-aip-to-fma-v1-mortgages --domain dynamic --path mortgages/v1/coord-aip-to-fma
dws pcf operation map route --pcfenv dev-pnf --channel hboapiplatform --space nft --appname v1-coord-aip-to-fma --domainname nft-api.natwest.com --hostname coord-aip-to-fma-v1-mortgages --domain dynamic --path mortgages/v1/coord-aip-to-fma

