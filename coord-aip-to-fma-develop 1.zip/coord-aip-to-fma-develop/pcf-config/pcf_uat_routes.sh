dws pcf operation create route --pcfenv dev-pnf --channel hboapiplatform --space uat --domainname uat-api.natwest.com --hostname coord-aip-to-fma-v1-mortgages --domain dynamic --path mortgages/v1/coord-aip-to-fma
dws pcf operation map route --pcfenv dev-pnf --channel hboapiplatform --space uat --appname v1-coord-aip-to-fma --domainname uat-api.natwest.com --hostname coord-aip-to-fma-v1-mortgages --domain dynamic --path mortgages/v1/coord-aip-to-fma

