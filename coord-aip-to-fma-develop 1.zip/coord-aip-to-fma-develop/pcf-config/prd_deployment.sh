#! /bin/bash

function main() {

if [ $# -lt 4 ] || [ $# -gt 4 ]
then
  usage
fi


  approved_request=$1
  pcf_space=$2
  jasypt_password=$3
  version=$4
  shift 4

  # make sure -F isn't used
  for p in "$@"; do
    if [ "$p" == "-F" ]; then
      usage "-F not allowed"
    fi
  done

echo creating app...
./scripts/pcf.sh create-app ${pcf_space} -J ${jasypt_password} -A ${approved_request} "$@" || exit

echo deployment...
./scripts/pcf.sh deploy-app ${pcf_space} -V ${version} -A ${approved_request} "$@" || exit


}

function usage() {
  if [ ! -z "$1" ]; then
    echo $1
  fi

  cat <<- END_USAGE_SUMMARY

usage: $(basename $0) <MCRNumber> <space> <Jasypt_password> <LATEST>


  Examples:

    Deploy the latest version into dev

        $ $0 MCR12345 prd Hboapi01 LATEST

    Deploy version 0.0.5 to prd

      $ $0 prd 0.0.5 -A TCR12345678


END_USAGE_SUMMARY

   exit 1
}
main "$@"