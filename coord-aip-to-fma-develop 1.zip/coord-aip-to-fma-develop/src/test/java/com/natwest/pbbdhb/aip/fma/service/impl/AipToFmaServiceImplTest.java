package com.natwest.pbbdhb.aip.fma.service.impl;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.fma.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.fma.exception.ErrorResponse;
import com.natwest.pbbdhb.aip.fma.exception.InvalidRequestException;
import com.natwest.pbbdhb.aip.fma.model.*;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStep;
import com.natwest.pbbdhb.aip.fma.model.enums.Client;
import com.natwest.pbbdhb.aip.fma.model.enums.LoanPurpose;
import com.natwest.pbbdhb.aip.fma.model.mapper.EkycApplicationMapper;
import com.natwest.pbbdhb.aip.fma.model.mapper.RiskResponseMapper;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponseGenerationRequest;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import com.natwest.pbbdhb.aip.fma.service.CaseService;
import com.natwest.pbbdhb.aip.fma.service.CinMatchService;
import com.natwest.pbbdhb.aip.fma.service.EkycService;
import com.natwest.pbbdhb.aip.fma.service.ResponseService;
import com.natwest.pbbdhb.aip.fma.service.ScoringService;
import com.natwest.pbbdhb.aip.fma.service.StateService;
import com.natwest.pbbdhb.aip.fma.util.LoggerTestUtil;
import org.assertj.core.util.Lists;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.BRAND_NWB;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AipToFmaServiceImplTest {

    private static final String LENDER_CASE_ID = "lenderCaseId";
    private static final String APPLICANT_CIN_2 = "cin2";
    private static final String APPLICANT_CIN_1 = "cin1";
    private static final String CLIENT_ID = "clientId";
    private static final String ACCEPT = "ACCEPT";
    private static final String ERROR = "ERROR";
    private static final String BRAND = "nwb";
    public static final String existingFmaResponse = "{\"lenderCaseId\":\"LW1620387738797\",\"decision\":\"ACCEPT\",\"policyMessages\":[{\"message\":\"Accept\",\"code\":\"LoanMessage\"}]}";
    public static final String existingScoreResponse = "{\"lenderCaseId\":\"F1610482265434\",\"decisionUniqueId\":\"206989699\"}";
    public static final String FOCUS = "FOCUS";
    @Mock
    private ScoringService scoreService;

    @Mock
    private CaseService caseService;

    @Mock
    private StateService stateService;

    @Mock
    private EkycApplicationMapper ekycApplicationMapper;

    @Mock
    private ResponseService responseService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private CinMatchService cinMatchService;

    @Mock
    private EkycService ekycService;

    @Mock
    private RiskResponseMapper riskResponseMapper;

    @Mock
    private ModelMapper modelMapper;

    @Captor
    private ArgumentCaptor<RiskResponse> riskResponseCaptor;

    @InjectMocks
    private AipToFmaServiceImpl aipToFmaService;

    private ListAppender<ILoggingEvent> loggingEventListAppender;
    private final Applicant applicant1 = Applicant.builder().personalDetails(PersonalDetails.builder().build())
            .existingMortgage(ExistingMortgage.builder().build())
            .expenditure(Expenditure.builder().mortgageRent(new BigDecimal(500)).build())
            .addresses(Collections.singletonList(Address.builder().postcode("GU21 3HX").isCurrentAddress(true).ukAddress(true).build())).build();

    private final Applicant applicant2 = Applicant.builder().existingMortgage(ExistingMortgage.builder().build())
            .expenditure(Expenditure.builder().mortgageRent(new BigDecimal(500)).build())
            .addresses(Collections.singletonList(Address.builder().isCurrentAddress(true).postcode("GU21 3HX").ukAddress(true).build())).build();

    @BeforeEach
    void setup() {
        loggingEventListAppender = LoggerTestUtil.getListAppenderForClass(AipToFmaServiceImpl.class);
        ReflectionTestUtils.setField(aipToFmaService, "enableCinSearch", true, Boolean.class);
    }

    @Test
    void processResponseFromPreviousSuccessfulApplicationResponse() throws IOException, BureauServiceException {
        String brand = "nwb";
        Application application = getApplication();
        RiskResponse scoringResponse = getRiskResponse(ACCEPT);
        RiskResponseGenerationRequest scoringResponseGenerationRequest = getRiskResponseGenerationRequest(ACCEPT);
        FmaResponse fmaResponse = FmaResponse.builder().decision("ACCEPT").lenderCaseId("FF8698769887").build();

        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP_TO_FMA)).thenReturn(getAipToFmaApplication());
        when(objectMapper.readValue(existingFmaResponse, FmaResponse.class)).thenReturn(fmaResponse);
        when(modelMapper.map(scoringResponse, RiskResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateFmaResponse(BRAND, scoringResponseGenerationRequest)).thenReturn(fmaResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipToFmaService.processApplication(BRAND, CLIENT_ID, application);

        assertEquals(1, loggingEventListAppender.list.size());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP_TO_FMA);

        verify(scoreService, never()).scoringCheck(application);
        verify(ekycService, never()).kycCheck(any(EkycApplication.class));
        verify(stateService, never()).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(stateService, never()).updateApplication(BRAND, application, fmaResponse, scoringResponse);
        verify(modelMapper, never()).map(scoringResponse, RiskResponseGenerationRequest.class);
        verify(responseService, never()).generateFmaResponse(BRAND, scoringResponseGenerationRequest);
        verify(caseService, never()).trackCase(application, scoringResponse, CLIENT_ID, brand);
        verify(cinMatchService, never()).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
    }

    @Test
    void processResponseFromPreviousSuccessfulStateResponse() throws IOException, BureauServiceException {
        String brand = "nwb";
        Application application = getApplication();
        RiskResponse scoringResponse = getRiskResponse(ACCEPT);
        RiskResponseGenerationRequest scoringResponseGenerationRequest = getRiskResponseGenerationRequest(ACCEPT);
        FmaResponse fmaResponse = FmaResponse.builder().decision("ACCEPT").lenderCaseId("FF8698769887").build();
        FmaResponse fmaErrorResponse = FmaResponse.builder().errorCode("500").build();

        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP_TO_FMA)).thenReturn(getAipToFmaApplication());
        when(objectMapper.readValue(existingFmaResponse, FmaResponse.class)).thenReturn(fmaErrorResponse);
        when(stateService.retrieveApplicationState(BRAND, LENDER_CASE_ID, ApplicationStage.AIP_TO_FMA, ApplicationStep.SCORE)).thenReturn(getAipToFmaApplicationState());
        when(objectMapper.readValue(existingScoreResponse, RiskResponse.class)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, RiskResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateFmaResponse(BRAND, scoringResponseGenerationRequest)).thenReturn(fmaResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipToFmaService.processApplication(BRAND, CLIENT_ID, application);

        assertEquals(1, loggingEventListAppender.list.size());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP_TO_FMA);
        verify(stateService).updateApplication(BRAND, application, fmaResponse, scoringResponse);
        verify(modelMapper).map(scoringResponse, RiskResponseGenerationRequest.class);
        verify(responseService).generateFmaResponse(BRAND, scoringResponseGenerationRequest);
        verify(scoreService, never()).scoringCheck(application);
        verify(ekycService, never()).kycCheck(any(EkycApplication.class));
        verify(stateService, never()).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(caseService, never()).trackCase(application, scoringResponse, CLIENT_ID, brand);
        verify(cinMatchService, never()).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
    }

    @Test
    void processAipToFmaApplication() throws IOException, BureauServiceException {

        String brand = "nwb";
        Application application = getApplication();
        RiskResponse scoringResponse = getRiskResponse(ACCEPT);
        RiskResponseGenerationRequest scoringResponseGenerationRequest = getRiskResponseGenerationRequest(ACCEPT);
        FmaResponse fmaResponse = FmaResponse.builder().build();
        EkycApplication ekycApplication = getEkycApplication();
        RiskResponse ekycResponse = getRiskResponse(ACCEPT);
        CinResponse customerCinResponse = getCustomerCinResponse(applicant1, true, APPLICANT_CIN_1);
        CinResponse customerCinResponse1 = getCustomerCinResponse(applicant2, true, APPLICANT_CIN_2);
        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(getAipToFmaApplication());
        when(cinMatchService.cinSearch(application,
                BRAND_NWB, Client.FOCUS)).thenReturn(Lists.newArrayList(customerCinResponse, customerCinResponse1));
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, RiskResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateFmaResponse(BRAND, scoringResponseGenerationRequest)).thenReturn(fmaResponse);
        when(caseService.trackCase(application, scoringResponse, CLIENT_ID, brand)).thenReturn(Case.builder().build());
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);
        when(ekycApplicationMapper.toEkycApplication(application)).thenReturn(ekycApplication);
        when(ekycService.kycCheck(ekycApplication)).thenReturn(ekycResponse);

        aipToFmaService.processApplication(BRAND, CLIENT_ID, application);

        assertEquals(2, loggingEventListAppender.list.size());
        application.getApplicants().forEach(applicant -> {
            assertEquals(applicant.getExpenditure().getMortgageRent().intValue(), 0);
        });
        verify(riskResponseMapper, times(2)).toApplicantRequest(any(Applicant.class), anyBoolean());
        verify(stateService).captureApplicationState(BRAND, application, scoringResponse);
        verify(stateService).captureApplication(BRAND, application);
        verify(stateService).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(scoreService).scoringCheck(application);
        verify(stateService).updateApplication(BRAND, application, fmaResponse, scoringResponse);
        verify(modelMapper).map(scoringResponse, RiskResponseGenerationRequest.class);
        verify(responseService).generateFmaResponse(BRAND, scoringResponseGenerationRequest);
        verify(caseService).trackCase(application, scoringResponse, CLIENT_ID, brand);
    }

    @Test
    void processAipToFmaApplicationWhenCINExists() throws IOException, BureauServiceException {

        String brand = "nwb";
        Application application = Application.builder()
                .lenderCaseId(LENDER_CASE_ID)
                .formInfo(FormInfo.builder().build())
                .applicants(Collections.singletonList(Applicant.builder().cin(APPLICANT_CIN_1)
                        .addresses(Collections.singletonList(Address.builder().postcode("GU21 3HX").build())).build()))
                .build();
        RiskResponse scoringResponse = getRiskResponse(ACCEPT);
        RiskResponseGenerationRequest scoringResponseGenerationRequest = getRiskResponseGenerationRequest(ACCEPT);
        FmaResponse fmaResponse = FmaResponse.builder().build();
        CinResponse customerCinResponse = getCustomerCinResponse(applicant1, true, APPLICANT_CIN_1);
        CinResponse customerCinResponse1 = getCustomerCinResponse(applicant2, true, APPLICANT_CIN_2);

        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(getAipToFmaApplication());
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(modelMapper.map(scoringResponse, RiskResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateFmaResponse(BRAND, scoringResponseGenerationRequest)).thenReturn(fmaResponse);
        when(caseService.trackCase(application, scoringResponse, CLIENT_ID, brand)).thenReturn(Case.builder().build());
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipToFmaService.processApplication(BRAND, CLIENT_ID, application);

        assertEquals(2, loggingEventListAppender.list.size());
        verify(riskResponseMapper, never()).toApplicantRequest(any(Applicant.class), anyBoolean());
        verify(stateService).captureApplicationState(BRAND, application, scoringResponse);
        verify(stateService).captureApplication(BRAND, application);
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(stateService, never()).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(cinMatchService, never()).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(ekycService, never()).kycCheck(any(EkycApplication.class));
        verify(scoreService).scoringCheck(application);
        verify(stateService).updateApplication(BRAND, application, fmaResponse, scoringResponse);
        verify(modelMapper).map(scoringResponse, RiskResponseGenerationRequest.class);
        verify(responseService).generateFmaResponse(BRAND, scoringResponseGenerationRequest);
        verify(caseService).trackCase(application, scoringResponse, CLIENT_ID, brand);
    }

    @Test
    void testWhenExternalEkycCalledAsKycIsFalse() throws IOException, BureauServiceException {

        String brand = "nwb";
        Application application = getApplication();
        RiskResponse scoringResponse = getRiskResponse(ACCEPT);
        RiskResponseGenerationRequest scoringResponseGenerationRequest = getRiskResponseGenerationRequest(ACCEPT);
        RiskResponse ekycResponse = getRiskResponse(ACCEPT);
        ekycResponse.setApplicants(Lists.newArrayList(com.natwest.pbbdhb.aip.fma.model.response.Applicant.builder().build()));
        FmaResponse fmaResponse = FmaResponse.builder().build();
        EkycApplication ekycApplication = getEkycApplication();
        CinResponse customerCinResponse = getCustomerCinResponse(applicant1, true, APPLICANT_CIN_1);
        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(getAipToFmaApplication());
        when(cinMatchService.cinSearch(application,
                BRAND_NWB, Client.FOCUS)).thenReturn(Lists.newArrayList(customerCinResponse));
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(ekycApplicationMapper.toEkycApplication(application)).thenReturn(ekycApplication);
        when(ekycService.kycCheck(ekycApplication)).thenReturn(ekycResponse);
        when(modelMapper.map(scoringResponse, RiskResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateFmaResponse(BRAND, scoringResponseGenerationRequest)).thenReturn(fmaResponse);
        when(caseService.trackCase(application, scoringResponse, CLIENT_ID, brand)).thenReturn(Case.builder().build());
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        aipToFmaService.processApplication(BRAND, CLIENT_ID, application);

        assertEquals(2, loggingEventListAppender.list.size());
        verify(riskResponseMapper, never()).toApplicantRequest(any(Applicant.class), anyBoolean());
        verify(stateService).captureApplicationState(BRAND, application, scoringResponse);
        verify(stateService).captureEkycApplicationState(BRAND, ekycApplication, ekycResponse);
        verify(stateService).captureApplication(BRAND, application);
        verify(stateService).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(ekycApplicationMapper).toEkycApplication(application);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(scoreService).scoringCheck(application);
        verify(stateService).updateApplication(BRAND, application, fmaResponse, scoringResponse);
        verify(modelMapper).map(scoringResponse, RiskResponseGenerationRequest.class);
        verify(responseService).generateFmaResponse(BRAND, scoringResponseGenerationRequest);
        verify(ekycService).kycCheck(ekycApplication);
        verify(caseService).trackCase(application, scoringResponse, CLIENT_ID, brand);
    }

    @Test
    void testWhenExternalEkycThrowsException() throws IOException {

        String brand = "nwb";
        Application application = getApplication();
        RiskResponse scoringResponse = getRiskResponse(ACCEPT);
        RiskResponseGenerationRequest scoringResponseGenerationRequest = getRiskResponseGenerationRequest(ACCEPT);
        scoringResponse.setApplicants(Lists.newArrayList(com.natwest.pbbdhb.aip.fma.model.response.Applicant.builder().build()));
        FmaResponse fmaResponse = FmaResponse.builder().build();
        EkycApplication ekycApplication = getEkycApplication();
        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(getAipToFmaApplication());
        CinResponse customerCinResponse = getCustomerCinResponse(applicant1, true, APPLICANT_CIN_1);
        CinResponse customerCinResponse1 = getCustomerCinResponse(applicant2, true, APPLICANT_CIN_2);
        when(cinMatchService.cinSearch(application,
                BRAND_NWB, Client.FOCUS)).thenReturn(Lists.newArrayList(customerCinResponse, customerCinResponse1));
        when(scoreService.scoringCheck(application)).thenReturn(scoringResponse);
        when(ekycApplicationMapper.toEkycApplication(application)).thenReturn(ekycApplication);
        when(ekycService.kycCheck(ekycApplication)).thenThrow(HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null));
        when(modelMapper.map(scoringResponse, RiskResponseGenerationRequest.class)).thenReturn(scoringResponseGenerationRequest);
        when(responseService.generateFmaResponse(BRAND, scoringResponseGenerationRequest)).thenReturn(fmaResponse);
        when(caseService.trackCase(application, scoringResponse, CLIENT_ID, brand)).thenReturn(Case.builder().build());
        ErrorResponse errorResponse = ErrorResponse.builder().message("error").build();
        when(objectMapper.readValue("", ErrorResponse.class)).thenReturn(errorResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        assertThrows(BureauServiceException.class, () -> aipToFmaService.processApplication(BRAND, CLIENT_ID, application));

        assertEquals(2, loggingEventListAppender.list.size());
        verify(riskResponseMapper, never()).toApplicantRequest(any(Applicant.class), anyBoolean());
        verify(stateService).captureApplicationState(BRAND, application, scoringResponse);
        verify(stateService).captureEkycApplicationState(any(String.class), eq(ekycApplication), riskResponseCaptor.capture());
        assertEquals(String.valueOf(HttpStatus.BAD_REQUEST.value()), riskResponseCaptor.getValue().getErrorCode());
        verify(stateService).captureApplication(BRAND, application);
        verify(stateService).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(ekycApplicationMapper).toEkycApplication(application);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(scoreService).scoringCheck(application);
        verify(stateService, never()).updateApplication(BRAND, application, fmaResponse, scoringResponse);
        verify(modelMapper, never()).map(scoringResponse, RiskResponseGenerationRequest.class);
        verify(responseService, never()).generateFmaResponse(BRAND, scoringResponseGenerationRequest);
        verify(ekycService).kycCheck(ekycApplication);
        verify(caseService, never()).trackCase(application, scoringResponse, CLIENT_ID, brand);
    }

    @Test
    void testWhenScoringCheckThrowsException() throws IOException {

        String brand = "nwb";
        Application application = getApplication();
        RiskResponse ekycResponse = getRiskResponse(ERROR);
        FmaResponse fmaResponse = FmaResponse.builder().build();
        EkycApplication ekycApplication = getEkycApplication();
        CinResponse customerCinResponse = getCustomerCinResponse(applicant1, true, APPLICANT_CIN_1);
        CinResponse customerCinResponse1 = getCustomerCinResponse(applicant2, true, APPLICANT_CIN_2, APPLICANT_CIN_2);
        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP)).thenReturn(getAipToFmaApplication());
        when(ekycService.kycCheck(ekycApplication)).thenReturn(ekycResponse);
        when(ekycApplicationMapper.toEkycApplication(application)).thenReturn(ekycApplication);
        when(cinMatchService.cinSearch(application,
                BRAND_NWB, Client.FOCUS)).thenReturn(Lists.newArrayList(customerCinResponse, customerCinResponse1));
        when(scoreService.scoringCheck(application)).thenReturn(ekycResponse);
        when(ekycApplicationMapper.toEkycApplication(application)).thenReturn(ekycApplication);
        when(scoreService.scoringCheck(application)).thenThrow(HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null));
        when(responseService.generateFmaResponse(any(String.class), any(RiskResponseGenerationRequest.class))).thenReturn(fmaResponse);
        when(caseService.trackCase(eq(application), any(RiskResponse.class), eq(CLIENT_ID), eq(brand))).thenReturn(Case.builder().build());
        ErrorResponse errorResponse = ErrorResponse.builder().message("error").build();
        when(objectMapper.readValue("", ErrorResponse.class)).thenReturn(errorResponse);
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn(FOCUS);

        assertThrows(BureauServiceException.class, () -> aipToFmaService.processApplication(BRAND, CLIENT_ID, application));

        assertEquals(2, loggingEventListAppender.list.size());
        verify(riskResponseMapper, never()).toApplicantRequest(any(Applicant.class), anyBoolean());
        verify(stateService).captureApplicationState(any(String.class), eq(application), riskResponseCaptor.capture());
        RiskResponse riskResponse = riskResponseCaptor.getValue();
        assertEquals(String.valueOf(HttpStatus.BAD_REQUEST.value()), riskResponse.getErrorCode());
        verify(stateService).captureApplication(BRAND, application);
        verify(stateService).createApplicationState(any(String.class), any(Application.class), anyList());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(ekycApplicationMapper, never()).toEkycApplication(application);
        verify(cinMatchService).cinSearch(any(Application.class), eq(BRAND_NWB), eq(Client.FOCUS));
        verify(scoreService).scoringCheck(application);
        verify(stateService, never()).updateApplication(any(String.class), eq(application), eq(fmaResponse), eq(riskResponse));
        verify(modelMapper, never()).map(riskResponse, RiskResponseGenerationRequest.class);
        verify(responseService, never()).generateFmaResponse(anyString(), any(RiskResponseGenerationRequest.class));
        verify(caseService, never()).trackCase(eq(application), eq(riskResponse), eq(CLIENT_ID), eq(brand));
        verify(ekycService, never()).kycCheck(ekycApplication);
    }

    @Ignore
    void testStageIsFmaThenThrowInvalidRequestException() throws IOException {

        Application application = getApplication();
        AipToFmaApplication aipToFmaApplication = AipToFmaApplication.builder().stage(ApplicationStage.FMA.name()).build();
        when(stateService.retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.FMA)).thenReturn(aipToFmaApplication);

        InvalidRequestException exception = assertThrows(InvalidRequestException.class, () -> aipToFmaService.processApplication(BRAND, CLIENT_ID, application));

        assertEquals(1, loggingEventListAppender.list.size());
        assertEquals("AIP application has already converted to FMA", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getStatusCode());
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(stateService, never()).captureApplication(BRAND, application);
        verify(stateService).retrieveApplication(BRAND, LENDER_CASE_ID, ApplicationStage.AIP);
        verify(scoreService, never()).scoringCheck(application);
        verify(riskResponseMapper, never()).toApplicantRequest(any(Applicant.class), anyBoolean());
    }

    @Test
    void testValidateClientIsOnBoardedAndGetClientMethodWhenResponseFromCaseServiceIsValid() {
        when(caseService.getNameFromClientId(CLIENT_ID, BRAND_NWB)).thenReturn("CP");
        assertEquals(Client.CP, aipToFmaService.validateClientIsOnBoardedAndGetClient(CLIENT_ID, BRAND_NWB));
    }

    private EkycApplication getEkycApplication() {

        return EkycApplication.builder().lenderCaseId(LENDER_CASE_ID)
                .build();
    }

    private CinResponse getCustomerCinResponse(final Applicant applicant, final boolean cinVerified, final String... cin) {

        return CinResponse.builder().applicant(applicant).cin(Lists.newArrayList(cin)).cinVerified(cinVerified).build();
    }

    private Application getApplication() {

        return Application.builder()
                .lenderCaseId(LENDER_CASE_ID)
                .formInfo(FormInfo.builder().applicationStage(ApplicationStage.FMA).build())
                .applicants(Lists.newArrayList(applicant1, applicant2))
                .loanPurpose(LoanPurpose.BUY_TO_LET)
                .intermediary(Intermediary.builder().postcode("S050 5SU").build())
                .build();
    }

    private AipToFmaApplication getAipToFmaApplication() {
        return AipToFmaApplication.builder()
                .stage(ApplicationStage.AIP_TO_FMA.toString())
                .decision(ACCEPT)
                .response(existingFmaResponse)
                .build();
    }

    private AipToFmaApplicationState getAipToFmaApplicationState() {
        return AipToFmaApplicationState.builder()
                .stage(ApplicationStage.AIP_TO_FMA.toString())
                .decision(ACCEPT)
                .response(existingScoreResponse)
                .applicants(Arrays.asList(com.natwest.pbbdhb.aip.fma.model.response.Applicant.builder().build()))
                .build();
    }

    private RiskResponse getRiskResponse(String decision) {
        return RiskResponse.builder()
                .decision(decision)
                .build();
    }

    private RiskResponseGenerationRequest getRiskResponseGenerationRequest(String decision) {
        return RiskResponseGenerationRequest.builder()
                .decision(decision)
                .build();
    }
}
