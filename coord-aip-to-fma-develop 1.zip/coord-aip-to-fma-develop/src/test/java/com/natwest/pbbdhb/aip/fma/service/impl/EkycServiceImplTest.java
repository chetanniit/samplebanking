package com.natwest.pbbdhb.aip.fma.service.impl;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.ekyc.Applicant;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.response.Policy;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.vmarker.KycAssessment;
import com.natwest.pbbdhb.aip.fma.util.LoggerTestUtil;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.BRAND_NWB;

@MockitoSettings(strictness = Strictness.WARN)
@ExtendWith(MockitoExtension.class)
class EkycServiceImplTest {

    private static final String CIN = "2345978945";
    private static final String CIN_1 = "3345978945";
    private static final String LENDER_CASE_ID = "2345435";
    private final String EKYC_URL = "http://msvc-service/ekyc";
    private final String EKYC_VERIFY_URL = "http://msvc-service/ekyc/verify/{cin}";

    @InjectMocks
    private EkycServiceImpl ekycServiceImpl;

    @Mock
    private RestTemplate restTemplate;

    private ListAppender<ILoggingEvent> loggingEventListAppender;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(ekycServiceImpl, "ekycEndPoint", EKYC_URL, String.class);
        ReflectionTestUtils.setField(ekycServiceImpl, "ekycVerificationEndpoint", EKYC_VERIFY_URL, String.class);
        loggingEventListAppender = LoggerTestUtil.getListAppenderForClass(EkycServiceImpl.class);
    }

    @Test
    void testKycCheck() {
        EkycApplication application = EkycApplication.builder().lenderCaseId(LENDER_CASE_ID)
                .decisionUniqueId("DES-232").applicants(
                        Arrays.asList(Applicant.builder().cin(CIN).build(), Applicant.builder().cin(CIN_1).build())).build();

        RiskResponse response = RiskResponse.builder().lenderCaseId("F2020303940").decision("ACCEPT").decisionUniqueId("DES-232")
                .applicants(Arrays.asList(
                        com.natwest.pbbdhb.aip.fma.model.response.Applicant.builder().cin(CIN).build(),
                        com.natwest.pbbdhb.aip.fma.model.response.Applicant.builder().cin(CIN_1).build()))
                .policies(Arrays.asList(
                        Policy.builder().message("Applicant 1 - Address not matched at Bureau.").code("R900").build(),
                        Policy.builder().message("Applicant 2 - Address not matched at Bureau.").code("R901").build()
                )).build();

        when(restTemplate.postForObject(EKYC_URL, application, RiskResponse.class)).thenReturn(response);

        RiskResponse actualResponse = ekycServiceImpl.kycCheck(application);

        assertEquals(response.getLenderCaseId(), actualResponse.getLenderCaseId());
        assertEquals(response.getDecisionUniqueId(), actualResponse.getDecisionUniqueId());
        assertEquals(response.getDecision(), actualResponse.getDecision());
        assertEquals(response.getApplicants().get(0).getCin(), actualResponse.getApplicants().get(0).getCin());
        assertEquals(response.getApplicants().get(1).getCin(), actualResponse.getApplicants().get(1).getCin());
        assertEquals(response.getPolicies().get(0).getMessage(), actualResponse.getPolicies().get(0).getMessage());
        assertEquals(response.getPolicies().get(0).getCode(), actualResponse.getPolicies().get(0).getCode());
        assertEquals(response.getPolicies().get(1).getMessage(), actualResponse.getPolicies().get(1).getMessage());
        assertEquals(response.getPolicies().get(1).getCode(), actualResponse.getPolicies().get(1).getCode());

        verify(restTemplate).postForObject(EKYC_URL, application, RiskResponse.class);
        verify(restTemplate).getMessageConverters();

        assertEquals(2, loggingEventListAppender.list.size());
        ILoggingEvent event = loggingEventListAppender.list.get(1);
        assertEquals(Level.INFO, event.getLevel());
    }

    @Test
    void testKycCheckWithRestClientException() {
        EkycApplication application = EkycApplication.builder().lenderCaseId(LENDER_CASE_ID).applicants(
                        Arrays.asList(Applicant.builder().cin(CIN).build(), Applicant.builder().cin(CIN_1).build())).build();

        when(restTemplate.postForObject(EKYC_URL, application, RiskResponse.class)).thenThrow(new RestClientException("Rest Exception"));

        assertThrows(RestClientException.class, () -> ekycServiceImpl.kycCheck(application));

        verify(restTemplate).postForObject(EKYC_URL, application, RiskResponse.class);
        verify(restTemplate).getMessageConverters();

        assertEquals(1, loggingEventListAppender.list.size());
        ILoggingEvent event = loggingEventListAppender.list.get(0);
        assertEquals(Level.INFO, event.getLevel());
    }

    @Test
    void verifyKycReturnFalseWhenKycVerifiedIsTrueForUkAddress() {
        KycAssessment response = KycAssessment.builder().kycVerified(true).build();
        CinResponse cinResponse = getCinResponse(CIN, true);
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        Boolean result = ekycServiceImpl.verifyKyc(BRAND_NWB, Lists.newArrayList(cinResponse), LENDER_CASE_ID);

        assertAll(
                () -> assertFalse(result),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))
        );
    }

    /*@Test
    void verifyKycReturnFalseWhenKycVerifiedIsTrueForUkAddressAndKycVerifiedNotCalledForNonUkAddress() {
        KycAssessment response = KycAssessment.builder().kycVerified(true).build();
        CinResponse cinResponse = getCinResponse(CIN, true, true);
        CinResponse cinResponse1 = getCinResponse(CIN_1, false, false);
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        Boolean result = ekycServiceImpl.verifyKyc(BRAND_NWB, Lists.newArrayList(cinResponse, cinResponse1), LENDER_CASE_ID);

        assertAll(
                () -> assertFalse(result),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN)),
                () -> verify(restTemplate, never()).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))
        );
    }*/

    @Test
    void verifyKycReturnTrueWhenKycVerifiedIsFalseForOneApplicant() {
        CinResponse cinResponse = getCinResponse(CIN, true);
        CinResponse cinResponse1 = getCinResponse(CIN_1, true);
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))).thenReturn(new ResponseEntity<>(KycAssessment.builder().kycVerified(true).build(), HttpStatus.OK));
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))).thenReturn(new ResponseEntity<>(KycAssessment.builder().kycVerified(false).build(), HttpStatus.OK));

        Boolean result = ekycServiceImpl.verifyKyc(BRAND_NWB, Lists.newArrayList(cinResponse, cinResponse1), LENDER_CASE_ID);

        assertAll(
                () -> assertTrue(result),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN)),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))
        );
    }

    @Test
    void verifyKycReturnFalseWhenKycVerifiedIsFalseAndUkAdressIsFalse() {
        CinResponse cinResponse = getCinResponse(CIN, true);
        CinResponse cinResponse1 = getCinResponse(CIN_1, false);
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))).thenReturn(new ResponseEntity<>(KycAssessment.builder().kycVerified(true).build(), HttpStatus.OK));
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))).thenReturn(new ResponseEntity<>(KycAssessment.builder().kycVerified(false).build(), HttpStatus.OK));

        Boolean result = ekycServiceImpl.verifyKyc(BRAND_NWB, Lists.newArrayList(cinResponse, cinResponse1), LENDER_CASE_ID);

        assertAll(
                () -> assertFalse(result),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN)),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))
        );
    }

    @Test
    void verifyKycReturnTrueWhenCinVerifiedIsFalseAndCallToKycVerifiedDoesNotHappen() {
        CinResponse cinResponse = getCinResponse(null, true);
        CinResponse cinResponse1 = getCinResponse(CIN_1, false);

        Boolean result = ekycServiceImpl.verifyKyc(BRAND_NWB, Lists.newArrayList(cinResponse, cinResponse1), LENDER_CASE_ID);

        assertAll(
                () -> assertTrue(result),
                () -> verify(restTemplate, never()).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN)),
                () -> verify(restTemplate, never()).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN_1))
        );
    }

    @Test
    void testVerifyKycWithException() {
        CinResponse cinResponse = getCinResponse(CIN, true);
        when(restTemplate.exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))).thenThrow(new RestClientException("Rest Exception"));

        Boolean result = ekycServiceImpl.verifyKyc(BRAND_NWB, Lists.newArrayList(cinResponse), LENDER_CASE_ID);

        assertAll(
                () -> assertTrue(result),
                () -> verify(restTemplate).exchange(eq(EKYC_VERIFY_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(KycAssessment.class), eq(CIN))
        );
    }

    private CinResponse getCinResponse(String cin, boolean ukAddress) {
        return CinResponse.builder().cin(Objects.nonNull(cin) ? Collections.singletonList(cin) : Collections.EMPTY_LIST).ukAddress(ukAddress).build();
    }
}
