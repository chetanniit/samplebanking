package com.natwest.pbbdhb.aip.fma.service.impl;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.ClientDetails;
import com.natwest.pbbdhb.aip.fma.model.FormInfo;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.AipToFmaCaseType;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.AipToFmaDecision;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.CaseStatus;
import com.natwest.pbbdhb.aip.fma.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.util.LoggerTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CaseServiceImplTest {

    private static final String URL = "http://localhost:8080/score";
    private static final String DECISION = "accept";
    private static final String LENDER_CADE_ID = "lenderCadeId";
    private static final String CLIENT_ID = "clientId";
    private static final String CLIENT_DETAILS_END_POINT ="http://localhost:8080/mortgages/v1/msvc-case-management/getClientDetails?clientId={clientId}";

    @InjectMocks
    private CaseServiceImpl caseService;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ResponseEntity<ClientDetails> responseEntityClientDetails;

    @Captor
    private ArgumentCaptor<HttpEntity> caseArgumentCaptor;

    private ListAppender<ILoggingEvent> loggingEventListAppender;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(caseService, "createCaseEndPoint", URL, String.class);
        ReflectionTestUtils.setField(caseService, "fetchClientDetailsPoint", CLIENT_DETAILS_END_POINT, String.class);
        loggingEventListAppender = LoggerTestUtil.getListAppenderForClass(CaseServiceImpl.class);
    }

    @Test
    void testCaseServiceTrackApplication() {

        String brand="nwb";
        FormInfo formInfo = FormInfo.builder().dataFeed(DataFeed.FOCUS).build();
        Application application = Application.builder().lenderCaseId(LENDER_CADE_ID).formInfo(formInfo).build();

        caseService.trackCase(application, RiskResponse.builder().decision(DECISION).build(), CLIENT_ID,brand);

        verify(restTemplate).postForObject(eq(URL), caseArgumentCaptor.capture(), eq(Case.class));
        assertEquals(2, loggingEventListAppender.list.size());
        Case caseRequest = (Case)caseArgumentCaptor.getValue().getBody();
        assertEquals(LENDER_CADE_ID, caseRequest.getCaseId());
        assertEquals(CLIENT_ID, caseRequest.getClientId());
        assertEquals(DataFeed.FOCUS.getValue().toUpperCase(), caseRequest.getSource());
        assertEquals(Long.valueOf(AipToFmaCaseType.AIP_To_FMA.getId()), caseRequest.getCaseType().getId());
        assertEquals(AipToFmaCaseType.AIP_To_FMA.name(), caseRequest.getCaseType().getType());

        CaseStatus caseStatusSet = caseRequest.getCaseStatusSet().stream().findFirst().get();
        assertEquals(Long.valueOf(AipToFmaDecision.ACCEPT.getId()), caseStatusSet.getDecisionReason().getId());
        assertEquals(AipToFmaDecision.ACCEPT.name(), caseStatusSet.getDecisionReason().getDecisionReason());
        assertEquals(Long.valueOf(AipToFmaDecision.ACCEPT.getId()), caseStatusSet.getDecision().getId());
        assertEquals(AipToFmaDecision.ACCEPT.name(), caseStatusSet.getDecision().getDecision());
    }

    @Test
    void testGetNameFromClientIdAndExists() {
        String clientId = "client_id";
        ClientDetails clientDetails = mock(ClientDetails.class);
        when(clientDetails.getName()).thenReturn("CP");
        when(responseEntityClientDetails.getBody()).thenReturn(clientDetails);
        when(restTemplate.exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class),eq(ClientDetails.class), eq(clientId)))
                .thenReturn(responseEntityClientDetails);

        assertEquals("CP", caseService.getNameFromClientId(clientId, "nwb"));
        verify(restTemplate).exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class),eq(ClientDetails.class), eq(clientId));
    }

    @Test
    void testGetNameFromClientIdAndNotExists() {
        String clientId = "client_id";
        when(restTemplate.exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class),eq(ClientDetails.class), eq(clientId)))
                .thenThrow(HttpClientErrorException.NotFound.class);

        assertNull(caseService.getNameFromClientId(clientId, "nwb"));
        verify(restTemplate).exchange(eq(CLIENT_DETAILS_END_POINT), eq(HttpMethod.GET), any(HttpEntity.class),eq(ClientDetails.class), eq(clientId));
    }

}
