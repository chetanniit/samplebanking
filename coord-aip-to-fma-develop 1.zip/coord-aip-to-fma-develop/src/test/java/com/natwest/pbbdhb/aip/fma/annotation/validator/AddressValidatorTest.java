package com.natwest.pbbdhb.aip.fma.annotation.validator;

import static org.junit.jupiter.api.Assertions.*;
import com.natwest.pbbdhb.aip.fma.model.Address;
import org.junit.jupiter.api.Test;

class AddressValidatorTest {

    AddressValidator addressValidator=new AddressValidator();

    @Test
    void test_validation_without_flat_houseNo_houseName() {
        Address address=getAddress();
        boolean isValidAddress=addressValidator.isValid(address, null);
        assertFalse(isValidAddress);
    }

    @Test
    void test_validation_with_flatNo() {
        Address address=getAddressWithFlat();
        boolean isValidAddress=addressValidator.isValid(address, null);
        assertTrue(isValidAddress);
    }

    @Test
    void test_validation_with_house_number() {
        Address address=getAddressWithHouseNumber();
        boolean isValidAddress=addressValidator.isValid(address, null);
        assertTrue(isValidAddress);
    }

    @Test
    void test_validation_with_house_name() {
        Address address=getAddressWithHouseName();
        boolean isValidAddress=addressValidator.isValid(address, null);
        assertTrue(isValidAddress);
    }

    private Address getAddressWithHouseName() {
        return Address.builder().houseName("AB").build();
    }

    private Address getAddressWithHouseNumber() {
        return Address.builder().houseNumber("3").build();
    }

    private Address getAddressWithFlat() {
        return Address.builder().flat("A").build();
    }

    private Address getAddress() {
        return Address.builder().build();

    }
}