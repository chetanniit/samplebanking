package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.FormInfo;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AipToFmaApplicationStateMapperTest {

    private static final String LENDER_ID = "lenderID";
    private static final String AIP_TO_FMA = "AIP_TO_FMA";
    private static final String DECISION_UNIQUE_ID = "1";
    private static final String ACCEPT = "accept";
    private static final String SCORE = "SCORE";

    @Test
    void testApplicationRequest() {

        AipToFmaApplication aipToFmaApplication = AipToFmaApplicationStateMapper.INSTANCE.toApplicationRequest(getApplication(), "request");

        assertEquals(LENDER_ID, aipToFmaApplication.getCaseId());
        assertEquals(DataFeed.FOCUS.getValue().toUpperCase(), aipToFmaApplication.getChannel());
        assertEquals(AIP_TO_FMA, aipToFmaApplication.getStage());
        assertEquals(DECISION_UNIQUE_ID, aipToFmaApplication.getDecisionUniqueId());
        assertEquals(Integer.valueOf(2), aipToFmaApplication.getNumberOfApplicants());
    }

    @Test
    void testApplicationStateRequest() {

        AipToFmaApplicationState aipToFmaApplicationState = AipToFmaApplicationStateMapper.INSTANCE.toApplicationStateRequest(getApplication(), getRiskResponse(), "request", "response");

        assertEquals(LENDER_ID, aipToFmaApplicationState.getCaseId());
        assertEquals(ACCEPT, aipToFmaApplicationState.getDecision());
        assertEquals(DECISION_UNIQUE_ID, aipToFmaApplicationState.getDecisionUniqueId());
        assertEquals(AIP_TO_FMA, aipToFmaApplicationState.getStage());
        assertEquals(SCORE, aipToFmaApplicationState.getApplicationStep());
    }

    @Test
    void testEkycApplicationStateRequest() {

        AipToFmaApplicationState aipToFmaApplicationState = AipToFmaApplicationStateMapper.INSTANCE.toEkycApplicationStateRequest(getEkycApplication(), getRiskResponse(), "request", "response");

        assertEquals(LENDER_ID, aipToFmaApplicationState.getCaseId());
        assertEquals(DECISION_UNIQUE_ID, aipToFmaApplicationState.getDecisionUniqueId());
        assertEquals(AIP_TO_FMA, aipToFmaApplicationState.getStage());
        assertEquals("EKYC", aipToFmaApplicationState.getApplicationStep());
    }


    private Application getApplication() {
        return Application.builder()
                .lenderCaseId(LENDER_ID)
                .decisionUniqueId(DECISION_UNIQUE_ID)
                .numberOfApplicants(2)
                .formInfo(FormInfo.builder().dataFeed(DataFeed.FOCUS).build())
                .build();
    }

    private RiskResponse getRiskResponse() {
        return RiskResponse.builder()
                .decision(ACCEPT)
                .decisionUniqueId(DECISION_UNIQUE_ID)
                .build();
    }

    private EkycApplication getEkycApplication() {

        return EkycApplication.builder()
                .lenderCaseId(LENDER_ID)
                .decisionUniqueId(DECISION_UNIQUE_ID)
                .build();
    }
}
