package com.natwest.pbbdhb.aip.fma;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AipToFmaApplicationTest {
    @Test
    public void contextLoads() {
    }


}
