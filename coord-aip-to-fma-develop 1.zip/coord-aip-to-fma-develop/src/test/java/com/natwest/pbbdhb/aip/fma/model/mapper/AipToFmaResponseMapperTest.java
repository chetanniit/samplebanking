package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.Policy;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AipToFmaResponseMapperTest {

    private static final String LENDER_ID = "lenderID";
    private static final String DECISION_UNIQUE_ID = "1";
    private static final String LOAN_MESSAGE = "loan message";
    private static final String POLICY_CODE = "code";
    private static final String POLICY_MESSAGE = "message";

    @Test
    void testEkycApplication() {
        FmaResponse fmaResponse = AipToFmaResponseMapper.INSTANCE.scoringToFmaResponse(getApplication());

        assertEquals(LENDER_ID, fmaResponse.getLenderCaseId());
        assertEquals(POLICY_CODE, fmaResponse.getPolicyMessages().get(0).getCode());
        assertEquals(POLICY_MESSAGE, fmaResponse.getPolicyMessages().get(0).getMessage());
        assertEquals(DECISION_UNIQUE_ID, fmaResponse.getDecisionUniqueId());
    }


    private RiskResponse getApplication() {
        return RiskResponse.builder()
                .lenderCaseId(LENDER_ID)
                .decisionUniqueId(DECISION_UNIQUE_ID)
                .policies(Lists.newArrayList(Policy.builder().code(POLICY_CODE).message(POLICY_MESSAGE).build()))
                .loanMessage(LOAN_MESSAGE)
                .build();
    }
}
