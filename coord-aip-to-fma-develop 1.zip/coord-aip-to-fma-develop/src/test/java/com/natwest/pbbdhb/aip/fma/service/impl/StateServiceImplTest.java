package com.natwest.pbbdhb.aip.fma.service.impl;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.FormInfo;
import com.natwest.pbbdhb.aip.fma.model.PersonalDetails;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.Brand;
import com.natwest.pbbdhb.aip.fma.model.mapper.AipToFmaApplicationStateMapper;
import com.natwest.pbbdhb.aip.fma.model.mapper.CinKycVerificationMapper;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.response.cin.search.CinKycVerification;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import com.natwest.pbbdhb.aip.fma.util.LoggerTestUtil;
import org.assertj.core.util.Lists;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class StateServiceImplTest {

    private static final String CREATE_APPICATION_URL = "http://localhost:8081/create/application";
    private static final String UPDATE_APPICATION_URL = "http://localhost:8081/update/application";
    private static final String CREATE_APPICATION_STATE_END_POINT_URL = "http://localhost:8081/create/stateapplication";
    private static final String GET_APPICATION_URL = "http://localhost:8081/get/application";
    private static final String LENDER_ID = "lenderId";
    private static final String DECISION_UNIQUE_ID = "decision unique id";
    private static final String DECISION = "decision";
    private static final String RESPOSNE = "response";
    private static final String CIN_MATCH = "CIN-MATCH";
    private static final String NO_CIN_FOUND = "{No CIN found for any of the applicant}";
    private static final String SINGLE_MATCH_VERIFIED = "SINGLE-MATCH-VERIFIED";

    @Mock
    private RestTemplate restTemplate;

    @Mock(name = "objectMapper")
    private ObjectMapper objectMapper;

    @Mock(name = "objectMapperOrganic")
    private ObjectMapper objectMapperOrganic;

    @Mock
    private AipToFmaApplicationStateMapper riskAppStateMapper;

    @Mock
    CinKycVerificationMapper cinKycVerificationMapper;

    @InjectMocks
    private StateServiceImpl stateService;

    @Captor
    private ArgumentCaptor<HttpEntity> aipToFmaApplicationArgumentCaptor;

    @Captor
    private ArgumentCaptor<HttpEntity> aipToFmaApplicationStateArgumentCaptor;

    private ListAppender<ILoggingEvent> loggingEventListAppender;

    String brand="nwb";

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(stateService, "createApplicationEndPoint", CREATE_APPICATION_URL, String.class);
        ReflectionTestUtils.setField(stateService, "createApplicationStateEndPoint", CREATE_APPICATION_STATE_END_POINT_URL, String.class);
        ReflectionTestUtils.setField(stateService, "updateApplicationEndPoint", UPDATE_APPICATION_URL, String.class);
        ReflectionTestUtils.setField(stateService, "getApplicationEndPoint", GET_APPICATION_URL, String.class);
        loggingEventListAppender = LoggerTestUtil.getListAppenderForClass(StateServiceImpl.class);
    }

    @Test
    void testCaptureApplication() throws JsonProcessingException {

        AipToFmaApplication aipToFmaApplication = AipToFmaApplication.builder().build();
        Application application = getApplication();
        when(riskAppStateMapper.toApplicationRequest(application, "request")).thenReturn(aipToFmaApplication);

        stateService.captureApplication(brand, application);

        assertEquals(2, loggingEventListAppender.list.size());

        verify(restTemplate).postForObject(eq(CREATE_APPICATION_URL), any(HttpEntity.class), eq(HttpStatus.class));
    }

    @Test
    void testUpdateApplication() throws JsonProcessingException {

        FmaResponse fmaResponse = FmaResponse.builder().lenderCaseId(LENDER_ID).decision(DECISION).build();
        RiskResponse riskResponse = RiskResponse.builder().decisionUniqueId(DECISION_UNIQUE_ID).build();
        when(objectMapper.writeValueAsString(fmaResponse)).thenReturn(RESPOSNE);

        stateService.updateApplication(brand, getApplication(), fmaResponse, riskResponse);

        assertEquals(2, loggingEventListAppender.list.size());
        verify(objectMapper).writeValueAsString(any(FmaResponse.class));
        verify(restTemplate).patchForObject(eq(UPDATE_APPICATION_URL), aipToFmaApplicationArgumentCaptor.capture(), eq(HttpStatus.class), eq(LENDER_ID), eq(ApplicationStage.AIP_TO_FMA));
        AipToFmaApplication aipApplication = (AipToFmaApplication) aipToFmaApplicationArgumentCaptor.getValue().getBody();
        assertNotNull(aipApplication);
        assertEquals(DECISION, aipApplication.getDecision());
        assertEquals(DECISION_UNIQUE_ID, aipApplication.getDecisionUniqueId());
        assertEquals(RESPOSNE, aipApplication.getResponse());
    }

    @Test
    void testCreateApplicationState() throws JsonProcessingException {

        Application application = getApplication();
        CinResponse applicantCinResponse1 = CinResponse.builder().cin(Collections.singletonList("4267913246")).applicant(application.getApplicants().get(0)).vMarker(true).cinMatchIndicator(SINGLE_MATCH_VERIFIED).build();
        List<CinResponse> applicantsCinResponse = Lists.newArrayList(applicantCinResponse1);
        when(riskAppStateMapper.toCinApplicationState(any(String.class))).thenReturn(AipToFmaApplicationState.builder().applicationStep("CIN-MATCH").caseId(LENDER_ID).stage(ApplicationStage.AIP_TO_FMA.name()).build());
        when(cinKycVerificationMapper.toCinSearchRequest(any(Applicant.class))).thenReturn(CustomerSearchRequest.builder().firstName("John").build());
        when(cinKycVerificationMapper.toCinKycResponse(any(Applicant.class),anyList(),anyBoolean(), anyString())).thenReturn(CinKycVerification.builder().vmarker(true).build());
        when(objectMapper.writeValueAsString(any(CustomerSearchRequest.class))).thenReturn("");
        when(objectMapper.writeValueAsString(any(CinKycVerification.class))).thenReturn("");

        stateService.createApplicationState(brand, application, applicantsCinResponse);

        assertEquals(2, loggingEventListAppender.list.size());
        verify(restTemplate).postForObject(eq(CREATE_APPICATION_STATE_END_POINT_URL), aipToFmaApplicationStateArgumentCaptor.capture(), eq(HttpStatus.class));
        AipToFmaApplicationState aipApplication = (AipToFmaApplicationState) aipToFmaApplicationStateArgumentCaptor.getValue().getBody();
        assertNotNull(aipApplication);
        assertEquals(LENDER_ID, aipApplication.getCaseId());
        assertEquals(CIN_MATCH, aipApplication.getApplicationStep());
        assertEquals(ApplicationStage.AIP_TO_FMA.name(), aipApplication.getStage());
    }

    @Ignore
    void testCreateApplicationStateWhenCinMapIsNull() throws JsonProcessingException {

        Application application = getApplication();
        CinResponse applicantCinResponse1 = CinResponse.builder().cin(Collections.singletonList("4267913246")).applicant(application.getApplicants().get(0)).vMarker(true).cinMatchIndicator(SINGLE_MATCH_VERIFIED).build();
        List<CinResponse> applicantsCinResponse = Lists.newArrayList(applicantCinResponse1);
        when(riskAppStateMapper.toCinApplicationState(any(String.class))).thenReturn(AipToFmaApplicationState.builder().applicationStep("CIN-MATCH").caseId(LENDER_ID).stage(ApplicationStage.AIP_TO_FMA.name()).build());
        when(cinKycVerificationMapper.toCinSearchRequest(any(Applicant.class))).thenReturn(CustomerSearchRequest.builder().firstName("John").build());
        when(cinKycVerificationMapper.toCinKycResponse(any(Applicant.class),anyList(),anyBoolean(), anyString())).thenReturn(CinKycVerification.builder().vmarker(true).build());
        when(objectMapper.writeValueAsString(any(CustomerSearchRequest.class))).thenReturn("");
        when(objectMapper.writeValueAsString(any(CinKycVerification.class))).thenReturn("");

        stateService.createApplicationState(brand, application, applicantsCinResponse);

        assertEquals(2, loggingEventListAppender.list.size());
        verify(objectMapper).writeValueAsString(any(CustomerSearchRequest.class));
        verify(objectMapper, never()).writeValueAsString(anyList());
        verify(restTemplate).postForObject(eq(CREATE_APPICATION_STATE_END_POINT_URL), aipToFmaApplicationStateArgumentCaptor.capture(), eq(HttpStatus.class));
        AipToFmaApplicationState aipApplication = (AipToFmaApplicationState) aipToFmaApplicationStateArgumentCaptor.getValue().getBody();
        assertNotNull(aipApplication);
        assertEquals(LENDER_ID, aipApplication.getCaseId());
        assertEquals(CIN_MATCH, aipApplication.getApplicationStep());
        assertEquals(ApplicationStage.AIP_TO_FMA.name(), aipApplication.getStage());
        assertEquals(NO_CIN_FOUND, aipApplication.getResponse());
    }

    @Test
    void testCaptureApplicationState() throws JsonProcessingException {

        Application application = getApplication();
        AipToFmaApplicationState aipToFmaApplicationState = new AipToFmaApplicationState();
        when(riskAppStateMapper.toApplicationStateRequest(application, new RiskResponse(), "request", "response")).thenReturn(aipToFmaApplicationState);

        stateService.captureApplicationState(brand, application, new RiskResponse());

        assertEquals(2, loggingEventListAppender.list.size());
        verify(objectMapper).writeValueAsString(any(Application.class));
        verify(objectMapper).writeValueAsString(any(RiskResponse.class));
        verify(restTemplate).postForObject(eq(CREATE_APPICATION_STATE_END_POINT_URL), any(HttpEntity.class), eq(HttpStatus.class));
    }

    @Test
    void testCaptureEkycApplicationState() throws JsonProcessingException {

        AipToFmaApplicationState aipToFmaApplicationState = new AipToFmaApplicationState();
        EkycApplication ekycApplication = EkycApplication.builder().formInfo(com.natwest.pbbdhb.aip.fma.model.ekyc.FormInfo.builder().brand(Brand.RBS).build()).build();
        when(riskAppStateMapper.toEkycApplicationStateRequest(ekycApplication, new RiskResponse(), "request", "response")).thenReturn(aipToFmaApplicationState);

        stateService.captureEkycApplicationState(brand, ekycApplication, new RiskResponse());

        assertEquals(2, loggingEventListAppender.list.size());
        verify(objectMapper).writeValueAsString(any(EkycApplication.class));
        verify(objectMapper).writeValueAsString(any(RiskResponse.class));
        verify(restTemplate).postForObject(eq(CREATE_APPICATION_STATE_END_POINT_URL), any(HttpEntity.class), eq(HttpStatus.class));
    }

    @Test
    void testRetrieveApplication(){

        when(restTemplate.exchange(eq(GET_APPICATION_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(AipToFmaApplication.class), eq(ApplicationStage.AIP), eq(LENDER_ID)))
                .thenReturn(new ResponseEntity<>(new AipToFmaApplication(), HttpStatus.OK));

        stateService.retrieveApplication(Brand.RBS.name(), LENDER_ID, ApplicationStage.AIP);

        verify(restTemplate).exchange(eq(GET_APPICATION_URL), eq(HttpMethod.GET), any(HttpEntity.class), eq(AipToFmaApplication.class), eq(ApplicationStage.AIP), eq(LENDER_ID));
    }

    private Application getApplication() {

        return Application.builder()
                .lenderCaseId(LENDER_ID)
                .formInfo(FormInfo.builder().brand(Brand.RBS).build())
                .applicants(Collections.singletonList(Applicant.builder().personalDetails(PersonalDetails.builder().firstNames("John").dateOfBirth(LocalDate.now()).build()).build()))
                .build();
    }
}
