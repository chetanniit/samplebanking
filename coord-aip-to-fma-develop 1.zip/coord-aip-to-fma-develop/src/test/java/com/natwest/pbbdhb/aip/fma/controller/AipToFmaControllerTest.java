package com.natwest.pbbdhb.aip.fma.controller;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.natwest.pbbdhb.aip.fma.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.service.AipToFmaService;
import com.natwest.pbbdhb.aip.fma.util.LoggerTestUtil;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class AipToFmaControllerTest{

    @InjectMocks
    private AipToFmaController aipToFmaController;

    @Mock
    private AipToFmaService aipToFmaService;

    private ListAppender<ILoggingEvent> loggingEventListAppender;

    @BeforeEach
    void setup() {
        loggingEventListAppender = LoggerTestUtil.getListAppenderForClass(AipToFmaController.class);
    }

    @Test
    void aipToFmaCheck() throws IOException, BureauServiceException {
        String brand ="nwb";
        Application application = aipToFmaRequest();
        when(aipToFmaService.processApplication("client_id", brand, application)).thenReturn(new FmaResponse());

        ResponseEntity<FmaResponse> response = aipToFmaController.aipToFmaCheck(brand, "client_id", application);

        assertEquals(2, loggingEventListAppender.list.size());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(aipToFmaService).processApplication( "client_id", brand, application);
    }

    private Application aipToFmaRequest() {
        return Application.builder().serviceRequired("AIP").numberOfApplicants(1).lenderCaseId("caseId")
                .applicants(Lists.newArrayList(Applicant.builder().build()))
                .build();
    }
}

