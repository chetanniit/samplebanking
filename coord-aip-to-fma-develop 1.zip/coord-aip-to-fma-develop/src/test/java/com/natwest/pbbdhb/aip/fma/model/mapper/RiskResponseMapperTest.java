package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.PersonalDetails;
import com.natwest.pbbdhb.aip.fma.model.enums.KycResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class RiskResponseMapperTest {

    private static final String CIN = "2345678";
    private static final String FIRST_NAME = "SIMON";
    private static final String LAST_NAME = "BELL";

    @InjectMocks
    private RiskResponseMapperImpl riskResponseMapper;

    @Test
    void testApplicantRequestWhenKycResultIsTrue() {
        Applicant applicant = getApplicant();

        com.natwest.pbbdhb.aip.fma.model.response.Applicant actualRequest = riskResponseMapper.toApplicantRequest(applicant, Boolean.TRUE);

        assertNotNull(actualRequest);
        assertEquals(FIRST_NAME, actualRequest.getFirstNames());
        assertEquals(LAST_NAME, actualRequest.getLastName());
        assertEquals(CIN, actualRequest.getCin());
        assertEquals(KycResult.TRUE.getValue(), actualRequest.getKycResult());
    }


    @Test
    void testApplicantRequestWhenKycResultIsFalse() {
        Applicant applicant = getApplicant();

        com.natwest.pbbdhb.aip.fma.model.response.Applicant actualRequest = riskResponseMapper.toApplicantRequest(applicant, Boolean.FALSE);

        assertNotNull(actualRequest);
        assertEquals(FIRST_NAME, actualRequest.getFirstNames());
        assertEquals(LAST_NAME, actualRequest.getLastName());
        assertEquals(CIN, actualRequest.getCin());
        assertEquals(KycResult.FALSE.getValue(), actualRequest.getKycResult());
    }

    private Applicant getApplicant() {
        return Applicant.builder()
                .personalDetails(getPersonalDetails())
                .cin(CIN)
                .build();
    }

    private PersonalDetails getPersonalDetails() {
        return PersonalDetails.builder()
                .firstNames(FIRST_NAME)
                .lastName(LAST_NAME)
                .build();
    }
}
