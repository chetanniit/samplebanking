package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Address;
import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.PersonalDetails;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.fma.model.enums.Client;
import com.natwest.pbbdhb.aip.fma.model.mapper.CustomerSearchMapperImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CustomerSearchMapperImplTest {

    private static final String LENDER_CASE_ID = "lenderCaseId";

    @InjectMocks
    private CustomerSearchMapperImpl customerSearchMapperImpl;

    @Test
    void testMap() {
        Applicant applicant = getApplicant("SIMON", "BELL", "19800101", "07423657789");

        addAddress(applicant, "G2 9EW", false, "23 Mosaic Apt");
        addAddress(applicant, "G2 6JW", true, "78", "Mever bank");

        CustomerSearchRequest actualRequest = customerSearchMapperImpl.toCustomerSearchRequest(applicant, Client.FOCUS.toString(), LENDER_CASE_ID);

        assertEquals("G2 6JW", actualRequest.getPostCode());
        assertEquals("SIMON", actualRequest.getFirstName());
        assertEquals("BELL", actualRequest.getLastName());
        assertEquals("AIP2FMA", actualRequest.getSourceId());
        assertEquals(Client.FOCUS.toString(), actualRequest.getChannel());
        assertEquals(LENDER_CASE_ID, actualRequest.getReferenceId());
    }

    @Test
    void testMapWithoutCurrentAddress() {
        Applicant applicant = getApplicant("SIMON", "BELL", "19800101", "07423657789");

        addAddress(applicant, "G2 9EW", false, "23 Mosaic Apt");
        addAddress(applicant, "G2 6JW", false, "78", "Mever bank");

        CustomerSearchRequest actualRequest = customerSearchMapperImpl.toCustomerSearchRequest(applicant, Client.FOCUS.toString(), LENDER_CASE_ID);

        assertNull(actualRequest.getPostCode());
        assertEquals("SIMON", actualRequest.getFirstName());
        assertEquals("BELL", actualRequest.getLastName());
        assertEquals("1980-01-01", actualRequest.getBirthDate());
    }

    private void addAddress(Applicant applicant, String postCode, boolean isCurrentAddress, String... address) {
        if(applicant.getAddresses() == null) {
            applicant.setAddresses(new ArrayList<>());
        }

        Address.AddressBuilder builder = Address.builder().isCurrentAddress(isCurrentAddress).postcode(postCode);

        if(address.length == 1) { // Flat Number
            applicant.getAddresses().add(builder.flat(address[0]).build());
            return;
        }

        if(address.length == 2) { // HouseNumber and HouseName
            applicant.getAddresses().add(builder.houseNumber(address[0]).houseName(address[1]).build());
        }
    }

    private Applicant getApplicant(String firstName, String lastName, String dob, String telephone) {
        return Applicant.builder()
                .personalDetails(getPersonalDetails(firstName, lastName, dob, telephone))
                .build();
    }

    private PersonalDetails getPersonalDetails(String firstName, String lastName, String dob, String telephone) {
        return PersonalDetails.builder()
                .firstNames(firstName)
                .lastName(lastName)
                .dateOfBirth(LocalDate.parse(dob, DateTimeFormatter.ofPattern("yyyyMMdd")))
                .mobileNumber(telephone)
                .build();
    }
}
