package com.natwest.pbbdhb.aip.fma.service.impl;


import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponseGenerationRequest;
import com.natwest.pbbdhb.aip.fma.util.LoggerTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ResponseGenerationServiceImplTest {

    private static final String URL = "http://localhost:8080/generate/response";

    @InjectMocks
    private ResponseGenerationServiceImpl responseGenerationService;

    @Mock
    private RestTemplate restTemplate;

    private ListAppender<ILoggingEvent> loggingEventListAppender;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(responseGenerationService, "responseGenerationEndPoint", URL, String.class);
        loggingEventListAppender = LoggerTestUtil.getListAppenderForClass(ResponseGenerationServiceImpl.class);
    }

    @Test
    void testResponseGeneration() {

        when(restTemplate.postForObject(eq(URL), any(HttpEntity.class), eq(FmaResponse.class))).thenReturn(new FmaResponse());

        responseGenerationService.generateFmaResponse("nwb", RiskResponseGenerationRequest.builder().build());

        verify(restTemplate).postForObject(eq(URL), any(HttpEntity.class), eq(FmaResponse.class));
        assertEquals(4, loggingEventListAppender.list.size());
    }

}
