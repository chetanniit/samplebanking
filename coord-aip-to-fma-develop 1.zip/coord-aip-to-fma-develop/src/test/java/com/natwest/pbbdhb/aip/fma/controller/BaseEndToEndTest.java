package com.natwest.pbbdhb.aip.fma.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import com.github.tomakehurst.wiremock.WireMockServer;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Scanner;

public class BaseEndToEndTest {

    static final int WIREMOCK_PORT = 9999;
    static final String AIP_REQUEST_JSON = "aip-to-fma-application.json";
    static final String EKYC_REQUEST_JSON = "aip-to-fma-ekyc-application.json";
    static final String AIP_REQUEST_TRANSFORMED_JSON = "aip-to-fma-transformed-application.json";
    static final String AIP_REQUEST_ORGANIC_JSON = "aip-to-fma-organic-application.json";
    static final String CONTENT_TYPE = "content-type";
    static final String APPLICATION_JSON = "application/json";
    static final String ACCEPT = "ACCEPT";
    static final String REFER = "REFER";
    static final String DECLINE = "DECLINE";
    static final String AIP_ENDPOINT = "/application";
    static final String SCORING_ENDPOINT = "/mortgage/scoring/v1";
    static final String EKYC_ENDPOINT = "/mortgage/eKyc/v1";
    static final String CREATE_CASE_ENDPOINT = "/mortgages/v1/msvc-case-management/case";
    static final String CREATE_APPLICATION_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application";
    static final String UPDATE_APPLICATION_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application/";
    static final String RETRIEVE_CUSTOMER_ENDPOINT = "/mortgages/v1/msvc-customer/core-customer/";
    static final String CREATE_APPLICATION_STATE_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application/state";
    static final String GET_APPLICATION_ENDPOINT = "/mortgages/v1/msvc-hbo-risk-controller-state/application/";
    static final String GENERATE_HBO_AIP_RESPONSE = "/mortgages/v1/msvc-hbo-risk-response-generator/generate/response";
    static final String CIN_SEARCH_ENDPOINT = "/mortgages/v1/msvc-customer-cin-search/customer-cin/search";
    static final String INTERNAL_EKYC_ENDPOINT = "/mortgages/v1/msvc-customer/customer/markers/kyc/";
    static final String GET_CLIENT_DETAILS = "/mortgages/v1/msvc-case-management/getClientDetails";

    ObjectMapper mapper = new ObjectMapper();

    protected static final WireMockServer wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(WIREMOCK_PORT));

    @BeforeAll
    static void setup() {
        wireMockServer.resetAll();
        wireMockServer.start();
    }

    private File readJson(String fileName) {
        return Paths.get("src", "test", "resources", "__files", fileName).toFile();
    }

    public String jsonString(String fileName) throws IOException {
        Scanner scanner = new Scanner(readJson(fileName));
        scanner.useDelimiter("\r\n");
        StringBuilder sb = new StringBuilder();
        while (scanner.hasNext()) {
            sb.append(scanner.next());
        }
        return sb.toString();
    }

    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }

}
