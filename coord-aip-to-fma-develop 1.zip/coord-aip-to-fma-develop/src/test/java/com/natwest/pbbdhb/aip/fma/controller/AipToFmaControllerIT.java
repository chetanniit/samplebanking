package com.natwest.pbbdhb.aip.fma.controller;

import com.natwest.pbbdhb.aip.fma.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.Brand;
import com.natwest.pbbdhb.aip.fma.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.Message;
import com.natwest.pbbdhb.aip.fma.model.response.Policy;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.vmarker.KycAssessment;
import com.natwest.pbbdhb.aip.fma.utils.AppUtil;
import org.assertj.core.util.Lists;
import org.junit.Ignore;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Collections;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@TestInstance(PER_CLASS)
@ActiveProfiles("test")
@AutoConfigureMockMvc
@ContextConfiguration(classes = { WireMockConfig.class })
class AipToFmaControllerIT extends BaseEndToEndTest {

    private static final String CLIENT_ID = "client_id";
    private static final String CIN_1 = "cin1";
    private static final String LENDER_CASE_ID = "F20203039404444";
    private static final String SINGLE_MATCH_VERIFIED = "SINGLE-MATCH-VERIFIED";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MockMvc mockMvc;

    @Nested
    class CreateAipToFmaApplication {


        @Nested
        class AipToFmaAcceptedWhenCustomerExist {

            @Test
            void aiptofma_request_is_accepted_on_valid_request_details() throws Exception {

                givenThatDecisionUniqueIdIsFetched();

                givenThatAipToFmaDecisionIsReceived("applicationACCEPT.json");
                givenKycDecisionIsReceived("ekycApplicationACCEPT.json");

                givenThatAipToFmaResponseIsGenerated(ACCEPT);

                givenThatCinFoundForApplication();

                givenThatInternalKycCheckIsValidApplication(Boolean.TRUE);

                givenThatAipToFmaApplicationIsCreated();

                givenThatAipToFmaApplicationStateIsCreated();

                givenThatAipToFmaApplicationCaseCreated();

                givenThatAipToFmaApplicationIsUpdated();

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(CLIENT_ID, "id")
                        .header(AppUtil.BRAND, AppUtil.BRAND_NWB)
                        .content(mapper.writeValueAsString(aipToFmaRequest())))
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.decision").value(ACCEPT))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value(LENDER_CASE_ID));
            }
        }

        @Nested
        class AipToFmaDeclined {

            @Test
            void aiptofma_request_is_declined_when_credit_score_is_low() throws Exception {

                givenThatAipToFmaDecisionIsReceived("applicationDECLINE.json");

                givenThatDecisionUniqueIdIsFetched();

                givenThatAipToFmaResponseIsGenerated(DECLINE);

                givenThatCinFoundForApplication();

                givenCustomerRetrievedWithCin();

                givenThatInternalKycCheckIsValidApplication(Boolean.FALSE);

                givenThatEnternalKycCheckIsDone();

                givenThatAipToFmaApplicationIsCreated();

                givenThatAipToFmaApplicationStateIsCreated();

                givenThatAipToFmaApplicationCaseCreated();

                givenThatAipToFmaApplicationIsUpdated();

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(CLIENT_ID, "id")
                        .header(AppUtil.BRAND, AppUtil.BRAND_NWB)
                        .content(mapper.writeValueAsString(aipToFmaRequest())))
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.decision").value(DECLINE))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value(LENDER_CASE_ID))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policyMessages").exists());
            }
        }

        @Nested
        class AipToFmaReferred {

            @Test
            void aiptofma_request_is_referred_when_more_details_are_needed() throws Exception {

                givenThatAipToFmaDecisionIsReceived("applicationREFER.json");
                givenKycDecisionIsReceived("ekycApplicationACCEPT.json");

                givenThatDecisionUniqueIdIsFetched();

                givenThatAipToFmaResponseIsGenerated(REFER);

                givenThatCinFoundForApplication();

                givenCustomerRetrievedWithCin();

                givenThatInternalKycCheckIsValidApplication(Boolean.FALSE);

                givenThatEnternalKycCheckIsDone();

                givenThatAipToFmaApplicationIsCreated();

                givenThatAipToFmaApplicationStateIsCreated();

                givenThatAipToFmaApplicationCaseCreated();

                givenThatAipToFmaApplicationIsUpdated();

                givenThatClientDetails(GET_CLIENT_DETAILS);

                mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(CLIENT_ID, "id")
                        .header(AppUtil.BRAND, AppUtil.BRAND_NWB)
                        .content(mapper.writeValueAsString(aipToFmaRequest())))
                        .andExpect(status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value(LENDER_CASE_ID))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.policyMessages").exists());
            }
        }
    }


    @Ignore
    void aiptofma_application_transformed_organic() throws Exception {

        givenThatDecisionUniqueIdIsFetched();

        givenThatAipToFmaDecisionIsReceivedWithOrganicApplication();

        givenThatAipToFmaResponseIsGenerated(ACCEPT);

        givenThatCinFoundForApplication();

        givenCustomerRetrievedWithCin();

        givenThatInternalKycCheckIsValidApplication(Boolean.TRUE);

        givenThatAipToFmaApplicationIsCreated();

        givenThatAipToFmaApplicationStateIsCreated();

        givenThatAipToFmaApplicationCaseCreated();

        givenThatAipToFmaApplicationIsUpdated();

        givenThatClientDetails(GET_CLIENT_DETAILS);

        mockMvc.perform(MockMvcRequestBuilders.post(AIP_ENDPOINT).contentType(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .header(CLIENT_ID, "id")
                .header(AppUtil.BRAND, AppUtil.BRAND_NWB)
                .content(jsonString(AIP_REQUEST_ORGANIC_JSON)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.decision").value(ACCEPT))
                .andExpect(MockMvcResultMatchers.jsonPath("$.lenderCaseId").value(LENDER_CASE_ID));
    }

    void givenThatClientDetails(String  clientDetailsEndpoint) throws JsonProcessingException {
        wireMockServer.stubFor(get(urlEqualTo(clientDetailsEndpoint + "?clientId=" + "id")).withQueryParam("clientId", equalTo("id"))
                .willReturn(aResponse().withStatus(200).withHeader("content-type", "application/json")
                        .withBody(mapper.writeValueAsString(ClientDetails.builder().name("FOCUS").organisation("NatWest").build()))));

    }

    private void givenThatAipToFmaDecisionIsReceivedWithOrganicApplication() throws IOException {
        wireMockServer.stubFor(post(SCORING_ENDPOINT)
                .withRequestBody(equalToJson(jsonString(AIP_REQUEST_TRANSFORMED_JSON)))
                .willReturn(aResponse().withStatus(200)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBodyFile("applicationACCEPT.json")));
    }

    private void givenThatAipToFmaDecisionIsReceived(String jsonResponse) throws IOException {
        wireMockServer.stubFor(post(SCORING_ENDPOINT)
                .withRequestBody(equalToJson(jsonString(AIP_REQUEST_JSON)))
                .willReturn(aResponse().withStatus(200)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBodyFile(jsonResponse)));
    }

    private void givenKycDecisionIsReceived(String jsonResponse) throws IOException {
        wireMockServer.stubFor(post(EKYC_ENDPOINT)
                .withRequestBody(equalToJson(jsonString(EKYC_REQUEST_JSON)))
                .willReturn(aResponse().withStatus(200)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBodyFile(jsonResponse)));
    }

    private void givenThatAipToFmaApplicationIsUpdated() {
        wireMockServer.stubFor(patch(urlPathEqualTo( BaseEndToEndTest.UPDATE_APPLICATION_ENDPOINT + LENDER_CASE_ID + "/" + ApplicationStage.AIP_TO_FMA))
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)));
    }

    private void givenThatAipToFmaApplicationStateIsCreated() {
        wireMockServer.stubFor(post(CREATE_APPLICATION_STATE_ENDPOINT)
                .willReturn(aResponse().withStatus(200)));
    }

    private void givenThatAipToFmaApplicationIsCreated() {
        wireMockServer.stubFor(post(BaseEndToEndTest.CREATE_APPLICATION_ENDPOINT).willReturn(aResponse().withStatus(200)));
    }

    private void givenThatDecisionUniqueIdIsFetched() throws JsonProcessingException {
        String getApplicationEndpoint = GET_APPLICATION_ENDPOINT.concat(ApplicationStage.AIP.name()).concat("/F20203039404444");

        wireMockServer.stubFor(get(getApplicationEndpoint)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(AipToFmaApplication.builder().caseId("202030394044444").build()))));
    }

    private void givenThatCinFoundForApplication() throws JsonProcessingException {
        wireMockServer.stubFor(post(BaseEndToEndTest.CIN_SEARCH_ENDPOINT)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(CinResponse.builder().cin(Lists.newArrayList(CIN_1)).cinMatchIndicator(SINGLE_MATCH_VERIFIED).build()))));
    }

    private void givenCustomerRetrievedWithCin() {
        wireMockServer.stubFor(get(BaseEndToEndTest.RETRIEVE_CUSTOMER_ENDPOINT + CIN_1)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)));
    }

    private void givenThatInternalKycCheckIsValidApplication(boolean value) throws JsonProcessingException {
        wireMockServer.stubFor(get(BaseEndToEndTest.INTERNAL_EKYC_ENDPOINT.concat(CIN_1))
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(KycAssessment.builder().kycVerified(value).build()))));
    }

    private void givenThatEnternalKycCheckIsDone() throws JsonProcessingException {
        wireMockServer.stubFor(post(BaseEndToEndTest.EKYC_ENDPOINT)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(RiskResponse.builder().build()))));
    }

    private void givenThatAipToFmaApplicationCaseCreated() throws JsonProcessingException {
        wireMockServer.stubFor(post(BaseEndToEndTest.CREATE_CASE_ENDPOINT)
                .willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(mapper.writeValueAsString(Case.builder().caseId(LENDER_CASE_ID).build()))));
    }

    private void givenThatAipToFmaResponseIsGenerated(String decision) throws JsonProcessingException {
        wireMockServer.stubFor(post(BaseEndToEndTest.GENERATE_HBO_AIP_RESPONSE).willReturn(aResponse().withStatus(200).withHeader(CONTENT_TYPE, APPLICATION_JSON)
                .withBody(mapper.writeValueAsString(aipToFmaResponse(decision)))));
    }

    private Application aipToFmaRequest() {
        return Application.builder().serviceRequired("AIP").numberOfApplicants(1).lenderCaseId(AipToFmaControllerIT.LENDER_CASE_ID)
                .applicants(Lists.newArrayList(Applicant.builder().addresses(Lists.newArrayList(Address.builder().isCurrentAddress(Boolean.TRUE).houseNumber("3").build())).build()))
                .formInfo(FormInfo.builder().dataFeed(DataFeed.FOCUS)
                        .brand(Brand.RBS)
                        .applicationStage(ApplicationStage.AIP_TO_FMA).build()).build();
    }

    private FmaResponse aipToFmaResponse(String decision) {
        return FmaResponse.builder()
                .lenderCaseId(LENDER_CASE_ID)
                .decision(decision)
                .policyMessages(Collections.singletonList(Policy.builder().build()))
                .kycMessages(Collections.singletonList(Message.builder().build()))
                .build();
    }

}
