package com.natwest.pbbdhb.aip.fma.model.enums;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.natwest.pbbdhb.aip.fma.model.Details;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;


public class EnumDeserializerTest {

    @Test
    public void validateDeserializer() throws  Exception {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);

        String jsonRequest = "{\"purpose\":\"HOME_IMPROVEMENT\",\"amount\":12345678}";
        String jsonResponse = "{\"purpose\":\"1\",\"amount\":12345678}";

        Details purpose = objectMapper.readValue(jsonRequest, Details.class);
        String valueAsString = objectMapper.writeValueAsString(purpose);

        Assertions.assertEquals(Purpose.HOME_IMPROVEMENT, purpose.getPurpose());
        Assertions.assertEquals(jsonResponse, valueAsString);
    }
    
}

