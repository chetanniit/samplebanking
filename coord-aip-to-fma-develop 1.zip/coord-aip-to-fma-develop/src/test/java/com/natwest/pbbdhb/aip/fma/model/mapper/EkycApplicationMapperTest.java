package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.FormInfo;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.Brand;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EkycApplicationMapperTest {

    private static final String LENDER_ID = "lenderID";
    private static final String DECISION_UNIQUE_ID = "1";

    @Test
    void testEkycApplication() {
        EkycApplication ekycApplication = EkycApplicationMapper.INSTANCE.toEkycApplication(getApplication());

        assertEquals(LENDER_ID, ekycApplication.getLenderCaseId());
        assertEquals(Boolean.TRUE, ekycApplication.getContactPermission());
        assertEquals(DECISION_UNIQUE_ID, ekycApplication.getDecisionUniqueId());
        assertEquals(Integer.valueOf(2), ekycApplication.getNumberOfApplicants());
        assertEquals(Brand.NATWEST, ekycApplication.getFormInfo().getBrand());
    }

    private Application getApplication() {
        return Application.builder()
                .lenderCaseId(LENDER_ID)
                .decisionUniqueId(DECISION_UNIQUE_ID)
                .numberOfApplicants(2)
                .contactPermission(Boolean.TRUE)
                .formInfo(FormInfo.builder().brand(Brand.NATWEST).build())
                .build();
    }
}
