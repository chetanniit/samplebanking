package com.natwest.pbbdhb.aip.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class FmaResponse {

    @Schema(example = "F2020303940")
    private String lenderCaseId;

    @Schema(example = "2021051200241")
    private String decisionUniqueId;

    @Schema(example = "REFER")
    private String decision;

    @Schema(example = "400")
    private String errorCode;

    @Schema(example = "Applicant 1 - Address not matched at Bureau")
    private String errorDescription;

    @Schema(example = "C")
    private String podDecision;

    @Schema()
    private List<Policy> policyMessages;

    @Schema()
    private List<Message> kycMessages;

    @Schema()
    private Packaging packaging;

}
