package com.natwest.pbbdhb.aip.fma.service;


import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.enums.Client;

import java.util.List;

public interface CinMatchService {

    List<CinResponse> cinSearch(final Application fmaRequest, final String brand, final Client client);
}
