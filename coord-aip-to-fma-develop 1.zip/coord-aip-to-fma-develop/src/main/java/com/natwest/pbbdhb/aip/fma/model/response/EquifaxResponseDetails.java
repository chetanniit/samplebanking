package com.natwest.pbbdhb.aip.fma.model.response;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class EquifaxResponseDetails {

    public String responseCode;

    public String responseType;

    public String responseMsg;

}
