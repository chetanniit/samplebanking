
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.enums.ProductType;
import com.natwest.pbbdhb.aip.fma.model.enums.RepaymentType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Mortgage {

    @Valid
    @Schema()
    private BuyToLet buyToLet;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer numberOfOccupants;

    @Valid
    @Schema()
    private InterestOnly interestOnly;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal interestOnlyAmount;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer interestOnlyTermMonths;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer interestOnlyTermYears;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal mortgageAmount;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean mortgagePrisoner;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer mortgageTerm;

    @Valid
    @PositiveOrZero
    @Max(value = 99, message = "allows max 2 digits")
    @Schema(type = "Integer")
    private Integer mortgageTermMonths;

    @Schema(type = "String", allowableValues = "REPAYMENT,INTEREST_ONLY,MIXED,SUB_ACCOUNT_CAPITAL_REPAYMENT,SUB_ACCOUNT_INTEREST_ONLY")
    private RepaymentType mortgageType;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal purchasePrice;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean mortgageAdvised;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean debtConsolidation;

    @Schema(type = "String", allowableValues = "true, false")
    private Boolean feesAdded;

    @Schema(type = "Boolean", allowableValues = "true, false")
    private Boolean mortgagePorting;

    @Schema()
    private ProductType productType;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8, fraction = 0, message = "allows max 8 digits. Must be integer value")
    @Schema(type = "BigDecimal")
    private BigDecimal debtConsolidationAmount;

    @Valid
    @Schema()
    private List<@Valid OtherProperty> resOtherProperties;

}
