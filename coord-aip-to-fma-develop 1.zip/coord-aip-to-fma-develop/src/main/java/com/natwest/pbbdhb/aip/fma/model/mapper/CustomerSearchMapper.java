package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Address;
import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CustomerSearchRequest;
import org.apache.commons.lang.BooleanUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper(config = MappingConfig.class)
public interface CustomerSearchMapper {
    CustomerSearchMapper INSTANCE = Mappers.getMapper(CustomerSearchMapper.class);

    @Mapping(target = "firstName", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "birthDate", source = "applicant.personalDetails.dateOfBirth", dateFormat = "yyyy-MM-dd")
    @Mapping(target = "postCode", source = "applicant.addresses", qualifiedByName = "getPostCode")
    @Mapping(target = "ukAddress", source = "applicant.addresses", qualifiedByName = "getUkAddress")
    @Mapping(target = "sourceId", constant = "AIP2FMA")
    @Mapping(target = "channel", source = "client")
    @Mapping(target = "referenceId", source = "lenderCaseId")
    CustomerSearchRequest toCustomerSearchRequest(Applicant applicant, String client, String lenderCaseId);

    @Named("getPostCode")
    static String getPostCode(List<Address> addresses) {

        return addresses.stream().filter(address -> BooleanUtils.isTrue(address.getIsCurrentAddress()))
                .findFirst()
                .map(Address::getPostcode)
                .orElse(null);
    }

    @Named("getUkAddress")
    static Boolean getUkAddress(List<Address> addresses) {

        return addresses.stream()
                .filter(address -> BooleanUtils.isTrue(address.getIsCurrentAddress()))
                .findFirst()
                .map(Address::getUkAddress)
                .orElse(false);
    }

}
