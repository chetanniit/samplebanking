package com.natwest.pbbdhb.aip.fma.controller;

import com.natwest.pbbdhb.aip.fma.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.service.AipToFmaService;
import com.natwest.pbbdhb.aip.fma.utils.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.io.IOException;

@RestController
@Tag(name = "AIP To FMA API", description = "AIP To FMA Controller")
@RequestMapping("/")
@Validated
public class AipToFmaController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AipToFmaController.class);

	@Autowired
	private AipToFmaService aipToFmaService;

	@Operation(summary = "Submit AIP to FMA request",
			description = "Returns FMA Response", tags = {"FmaResponse"})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "AIP To FMA request received"),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "422", description = "Unprocessable Entity"),
			@ApiResponse(responseCode = "500", description = "Internal server error")})
	@PostMapping(path = "/application")
	public ResponseEntity<FmaResponse> aipToFmaCheck(@RequestHeader(Constants.CLIENT_ID) String clientId,
													 @RequestHeader(Constants.BRAND) @Valid @Pattern(regexp="(rbs|nwb)", message="Invalid Brand") String brand,
													 @Valid @RequestBody Application aipToFmaRequest) throws IOException, BureauServiceException {

		LOGGER.info("Case id : {}-AF1, aipToFmaCheck called", aipToFmaRequest.getLenderCaseId());
		FmaResponse response = aipToFmaService.processApplication(brand, clientId, aipToFmaRequest);
		LOGGER.info("Case id : {}-AF25, aipToFmaCheck completed", aipToFmaRequest.getLenderCaseId());
		return ResponseEntity.ok(response);
	}

}
