package com.natwest.pbbdhb.aip.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Message {

    @Schema(example = "Identity NOT validated - please upload ID documents.")
    private String message;

    @Schema(example = "1")
    private String code;

    @Schema(example = "false")
    private boolean applicant1IdRequired;

    @Schema(example = "false")
    private Boolean applicant2IdRequired;
}
