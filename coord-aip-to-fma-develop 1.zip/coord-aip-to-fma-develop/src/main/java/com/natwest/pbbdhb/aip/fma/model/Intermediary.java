
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Intermediary {

    @Valid
    @PositiveOrZero
    @Schema( type = "Integer")
    @Max(value = 999999,message = "allows max 6 digits")
    private Integer club;

    @Valid
    @Schema( type = "String")
    @Length(max = 50,message = "allows max 50 characters")
    private String adviserName;

    @Valid
    @Schema( type = "String")
    @Length(max = 30,message = "allows max 30 characters ")
    private String adviserCompany;

    @Valid
    @Schema( type = "String")
    @Length(max = 8,message = "allows max 8 characters")
    private String postcode;

    @Valid
    @Schema( type = "String")
    @Length(max = 25,message = "allows max 25 characters")
    private String telephone;

    @Valid
    @Schema( type = "String")
    @Length(max = 25,message = "allows max 25 characters")
    private String fax;

    @Valid
    @Schema( type = "String")
    @Length(max = 15,message = "allows max 15 characters")
    private String cmlCode;

    @Valid
    @Schema( type = "String")
    @Length(max = 2,message = "allows max 2 characters")
    private String cmlCodeRefersTo;

}
