
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "InterestOnly Object")
public class InterestOnly {

    @Valid
    @PositiveOrZero
    @Digits(integer = 10,fraction=2, message = "allows max decimal(10,2)")
    @Schema( type = "BigDecimal")
    private BigDecimal repaymentNumberOfOthers;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=2, message = "allows max decimal(10,2)")
    @Schema( type = "BigDecimal")
    public BigDecimal repaymentValueOfOthers;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=2, message = "allows max decimal(10,2)")
    @Schema( type = "BigDecimal")
    public BigDecimal repaymentMortgageAmountOther;

    @Valid
    @Schema()
    public List<@Valid RepaymentDetail> repaymentDetails;


}
