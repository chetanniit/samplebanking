package com.natwest.pbbdhb.aip.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Packaging {

    @Schema(example = "1")
    private String app1PaySlipsReq;

    @Schema(example = "1")
    private String app1BankStmntsReq;

    @Schema(example = "3")
    private String app2PaySlipsReq;

    @Schema(example = "3")
    private String app2BankStmntsReq;

    @Schema(example = "1")
    private String app1AccountsReq;

    @Schema(example = "1")
    private String app1TaxCalc;

    @Schema(example = "1")
    private String app1PerAndBusBankStmntsReq;

    @Schema(example = "1")
    private String app2AccountsReq;

    @Schema(example = "1")
    private String app2TaxCalc;

    @Schema(example = "1")
    private String app2PerAndBusBankStmntsReq;
}
