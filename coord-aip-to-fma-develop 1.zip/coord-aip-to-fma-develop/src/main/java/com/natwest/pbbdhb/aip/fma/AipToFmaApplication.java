package com.natwest.pbbdhb.aip.fma;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackageClasses = {
        AipToFmaApplication.class
})
@OpenAPIDefinition(info = @Info(title = "AIP To FMA Application API", version = "1.0", description = "AIP To FMA Application API Specification"))
public class AipToFmaApplication {

    public static void main(String[] args) {
        SpringApplication.run(AipToFmaApplication.class, args);
    }

}

