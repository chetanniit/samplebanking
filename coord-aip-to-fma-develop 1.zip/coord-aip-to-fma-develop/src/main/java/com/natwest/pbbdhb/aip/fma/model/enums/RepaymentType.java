package com.natwest.pbbdhb.aip.fma.model.enums;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum RepaymentType {

    REPAYMENT("1", "Capital Repayment"),
    INTEREST_ONLY("2", "Interest Only"),
    MIXED("3", "Mixed"),
    SUB_ACCOUNT_CAPITAL_REPAYMENT("C"," sub account capital payment"),
    SUB_ACCOUNT_INTEREST_ONLY("I"," sub account Interest only");

    private String key;
    private String value;
    @Override
    public String toString(){
        return key;
    }
}
