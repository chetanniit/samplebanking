package com.natwest.pbbdhb.aip.fma.model.enums;


public enum ApplicationStage {
    AIP,
    AIP_TO_FMA,
    FMA;

}
