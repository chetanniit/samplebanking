
package com.natwest.pbbdhb.aip.fma.model.ekyc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "Application Object")
public class EkycApplication {

    @Schema()
    private String lenderCaseId;

    @Schema()
    private String serviceRequired;

    @Schema()
    private String decisionUniqueId;

    @Schema()
    private FormInfo formInfo;

    @Schema()
    private Boolean contactPermission;

    @Schema()
    private Integer numberOfApplicants;

    @Schema()
    private List<Applicant> applicants;

}
