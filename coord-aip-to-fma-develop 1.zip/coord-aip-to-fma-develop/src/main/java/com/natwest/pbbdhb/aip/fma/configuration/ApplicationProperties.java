package com.natwest.pbbdhb.aip.fma.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.Getter;
import lombok.ToString;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@Configuration
@EnableAutoConfiguration
@Getter
@ToString
public class ApplicationProperties {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationProperties.class);

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate iamJwtChainRestTemplate;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${iam.jwt.tyk.rest.template}")
    private Boolean invokeIamTykRestEndpoint;

    @Bean
    public RestTemplate restTemplateWithTimeout(RestTemplateBuilder restTemplateBuilder) {
        //This is needed temporarily until cin match service are stable
        RestTemplate withTimeOutTemplate = restTemplateBuilder.setConnectTimeout(Duration.ofMillis(1 * 60000)).setReadTimeout(Duration.ofMillis(1 * 60000)).build();
        return  invokeIamTykRestEndpoint ? iamJwtChainRestTemplate : withTimeOutTemplate;
    }

    @Bean
    @Qualifier("restTemplateForTykApi")
    public RestTemplate restTemplateForTykApi() {
        return invokeIamTykRestEndpoint ? iamJwtChainRestTemplate : restTemplate;
    }

    @Bean
    @Qualifier("objectMapper")
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return objectMapper;
    }

    @Bean
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter(ObjectMapper objectMapper) {
        MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
        objectMapper.configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true);
        mappingJackson2HttpMessageConverter.setObjectMapper(objectMapper);
        return mappingJackson2HttpMessageConverter;
    }

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
        return modelMapper;
    }
}
