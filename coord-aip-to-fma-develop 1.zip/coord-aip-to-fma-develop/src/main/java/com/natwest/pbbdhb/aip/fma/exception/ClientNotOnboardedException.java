package com.natwest.pbbdhb.aip.fma.exception;

public class ClientNotOnboardedException extends RuntimeException {
    public ClientNotOnboardedException(String message) {
        super(message);
    }
}
