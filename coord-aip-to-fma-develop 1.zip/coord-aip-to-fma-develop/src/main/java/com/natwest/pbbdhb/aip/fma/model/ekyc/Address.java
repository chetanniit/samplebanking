
package com.natwest.pbbdhb.aip.fma.model.ekyc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "Address Object")
public class Address {

    private Boolean isCurrentAddress;

    private String flat;

    private String houseName;

    private String houseNumber;

    private String street;

    private String district;

    private String town;

    private String county;

    private String postcode;

    private Boolean ukAddress;

    private String occupyMonth;

    private String occupyYear;

}
