
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.enums.PropertyTenure;
import com.natwest.pbbdhb.aip.fma.model.enums.PropertyType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Positive;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Property {

    @Schema(allowableValues = "BUNGALOW_NEW_BUILD,BUNGALOW_DETACHED,BUNGALOW_SEMI_DETACHED,BUNGALOW_MID_TERRACED,BUNGALOW_END_TERRACED,HOUSE_NEW_BUILD,HOUSE_DETACHED,HOUSE_SEMI_DETACHED,\n" +
            "HOUSE_MID_TERRACED,HOUSE_END_TERRACED,HOUSE_NEW_BUY,FLAT_NEW_BUILD,FLAT_PURPOSE_BUILT,FLAT_CONVERTED,FLAT_NEW_BUY")
    private PropertyType propertyType;

    @Valid
    @Positive
    @Schema()
    @Max(value = 999, message = "allows max 3 digits")
    private Integer termRemaining;

    @Valid
    @Schema()
    @Length(max = 50,message = "allows max 50 characters")
    private String propertyBuilder;

    @Valid
    @Schema()
    @Length(max = 50,message = "allows max 50 characters")
    private String propertyDevelopment;

    @Valid
    @Schema(allowableValues= "FREEHOLD, LEASEHOLD, FUEHOLD")
    private PropertyTenure propertyTenure;
}
