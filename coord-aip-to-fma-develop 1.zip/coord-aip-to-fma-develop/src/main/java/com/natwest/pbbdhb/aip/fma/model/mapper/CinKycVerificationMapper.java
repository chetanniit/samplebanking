package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Address;
import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.fma.model.response.cin.search.CinKycVerification;
import org.apache.logging.log4j.util.Strings;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Objects;

import static org.apache.commons.lang3.StringUtils.SPACE;


@Mapper(config = MappingConfig.class)
public interface CinKycVerificationMapper {
    CinKycVerificationMapper INSTANCE = Mappers.getMapper(CinKycVerificationMapper.class);

    @Mapping(target = "firstName", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "cin", source = "cin")
    @Mapping(target = "vmarker", source = "vMarker")
    @Mapping(target = "cinMatchIndicator", source = "cinMatchIndicator")
    CinKycVerification toCinKycResponse(Applicant applicant, List<String> cin, Boolean vMarker, String cinMatchIndicator);


    @Mapping(target = "firstName", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "birthDate", source = "applicant.personalDetails.dateOfBirth")
    @Mapping(target = "postCode", source = "applicant.addresses", qualifiedByName = "getPostCode")
    CustomerSearchRequest toCinSearchRequest(Applicant applicant);

    @Named("getPostCode")
    static String getPostCode(List<Address> addresses) {
        return addresses.stream().filter(Address::getIsCurrentAddress).findFirst().map(Address::getPostcode).orElse(null);
    }

    @Named("getAddressLine1")
    static String getAddressLine1(List<Address> addresses) {
        Address address = addresses.stream().filter(Address::getIsCurrentAddress).findFirst().orElse(null);
        if(Objects.isNull(address)) {
            return null;
        }
        return Strings.isNotEmpty(address.getFlat())? address.getFlat() : address.getHouseNumber() + SPACE + address.getHouseName();
    }

}
