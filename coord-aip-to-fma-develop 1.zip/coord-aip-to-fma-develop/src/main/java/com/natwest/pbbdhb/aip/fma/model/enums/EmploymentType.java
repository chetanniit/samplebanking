package com.natwest.pbbdhb.aip.fma.model.enums;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum EmploymentType {

    PERMANENT("P", "Permanent"),
    CONTRACT("C", "Contract"),
    TEMPORARY("T", "Temporary"),
    OTHER("O", "Other");

    private String key;
    private String value;

    @Override
    public String toString(){
        return key;
    }

}
