package com.natwest.pbbdhb.aip.fma.model.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum DataFeed {

    FOCUS("F", "FOCUS"),
    ADBO("A", "ADBO"),
    MBL("M","MBL");

    private String key;
    private String value;

    @Override
    public String toString(){
        return key;
    }


}
