package com.natwest.pbbdhb.aip.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "HBO risk controller internal response")
public class CreditRiskResponse {

    private String lenderCaseId;

    private String decision;

    private String loanMessage;

    private String podDecision;

    private List<Policy> policies;

    private List<Applicant> applicants;

}
