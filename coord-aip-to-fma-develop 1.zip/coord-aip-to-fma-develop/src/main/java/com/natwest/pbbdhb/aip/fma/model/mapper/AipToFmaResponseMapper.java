package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(config = MappingConfig.class)
public interface AipToFmaResponseMapper {

    AipToFmaResponseMapper INSTANCE = Mappers.getMapper(AipToFmaResponseMapper.class);

    @Mapping(target = "policyMessages", source = "policies")
    FmaResponse scoringToFmaResponse(RiskResponse scoringResponse);

}
