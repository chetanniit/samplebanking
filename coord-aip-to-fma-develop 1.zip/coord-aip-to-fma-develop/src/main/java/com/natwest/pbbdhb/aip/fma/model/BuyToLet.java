
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.enums.IcrTaxRate;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class BuyToLet {

    @Valid
    @PositiveOrZero
    @Schema( type = "BigDecimal")
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    private BigDecimal lettingAgentCost;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema( type = "BigDecimal")
    private BigDecimal monthlyRentalIncome;

    @PositiveOrZero
    @Schema( type = "Integer")
    private Integer numberOfBuyToLetMortgagesRbs;

    @PositiveOrZero
    @Schema( type = "Integer")
    private Integer numberOfOtherBuyToLetMortgages;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema( type = "BigDecimal")
    private BigDecimal otherBuyToLetGrossRent;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema( type = "BigDecimal")
    private BigDecimal totalBuyToLetMortgagePayments;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema( type = "BigDecimal")
    private BigDecimal totalResidentialMortgagePayment;

    @Schema( type = "Boolean")
    private Boolean useLettingAgent;

    @Valid
    @Schema( type = "OtherProperty")
    private List<@Valid OtherProperty> otherProperties;

    @Schema()
    private IcrTaxRate icrTaxRate;
}
