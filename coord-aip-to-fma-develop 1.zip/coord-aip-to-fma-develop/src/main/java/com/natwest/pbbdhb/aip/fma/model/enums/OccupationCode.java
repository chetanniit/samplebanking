package com.natwest.pbbdhb.aip.fma.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum OccupationCode {
    ACADEMIC_STAFF("AS","Academic Staff"),
    AGRICULTURAL_WORKERS_GENERAL("AG","Agricultural workers general"),
    FARM_MANAGEMENT_GENERAL("FM","farm management general"),
    HM_FORCES_OFFICERS("OF","HM forces officers"),
    HM_FORCES_OTHER_RANKS("OR","HM forces other ranks"),
    HOME_FAMILY_RESPONSIBILITIES("HF","Home family responsibilities"),
    JUNIOR_MANAGEMENT("MJ","Junior Management"),
    OFFICE_AND_CLERICAL("OC","Office and clerical"),
    PROFESSIONALS("PR","Professionals"),
    SALES("SA","SALES"),
    SEMI_PROFESSIONALS("SE","Semi Professionals"),
    SEMI_SKILLED("SS","Semi Skilled"),
    TECHNICIANS("TC","Technicians"),
    SENIOR_MANAGEMENT("MS","Senior Management"),
    SERVICE_JOBS("SR","Service Jobs"),
    SKILLED_MANUAL("SK","Skilled Manual"),
    SUPERVISORY_FOREMAN("SU","Supervisory Foreman"),
    TEACHERS("TH","Teachers"),
    UNEMPLOYED("UN","Unemployed"),
    SELF_EMPLOYED("SE","Self Employed"),
    MANUAL("UM","Manual"),
    STUDENT("ST","Student"),
    RETIRED("RT","Retired");

    private String key;
    private String value;

    @Override
    public String toString(){
        return key;
    }
}
