package com.natwest.pbbdhb.aip.fma.model.enums;


public enum Purpose {

    HOME_IMPROVEMENT(1,"Home improvement"),
    HOUSE_PURCHASE(2,"House purchase"),
    HOLIDAY(4,"Holiday"),
    BUY_NEW_OR_USED_CAR(3,"Buy New or used car"),
    DEBT_CONSOLIDATION(5,"Debt consolidation"),
    OTHER(6,"Other");

    private Integer key;
    private String value;

    Purpose(Integer key, String value){
        this.key = key;
        this.value = value;

    }

   @Override
   public String toString(){
       return key.toString();
   }

}
