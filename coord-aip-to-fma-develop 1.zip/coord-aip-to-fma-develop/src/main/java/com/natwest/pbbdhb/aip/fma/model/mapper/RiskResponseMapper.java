package com.natwest.pbbdhb.aip.fma.model.mapper;


import com.natwest.pbbdhb.aip.fma.model.enums.KycResult;
import com.natwest.pbbdhb.aip.fma.model.response.Applicant;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper(config = MappingConfig.class)
public interface RiskResponseMapper {

    RiskResponseMapper INSTANCE = Mappers.getMapper(RiskResponseMapper.class);

    @Mapping(target = "firstNames", source = "applicant.personalDetails.firstNames")
    @Mapping(target = "lastName", source = "applicant.personalDetails.lastName")
    @Mapping(target = "kycResult", source = "kycResult", qualifiedByName = "getkycResult")
    @Mapping(target = "cin", source = "applicant.cin")
    Applicant toApplicantRequest(com.natwest.pbbdhb.aip.fma.model.Applicant applicant, boolean kycResult);


    @Named("getkycResult")
    static String getkycResult(boolean kycResult) {

        return kycResult ? KycResult.TRUE.getValue() : KycResult.FALSE.getValue();
    }

}
