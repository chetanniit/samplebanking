package com.natwest.pbbdhb.aip.fma.service.impl;

import com.natwest.pbbdhb.aip.fma.model.Address;
import com.natwest.pbbdhb.aip.fma.model.Applicant;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.fma.model.enums.Client;
import com.natwest.pbbdhb.aip.fma.model.mapper.CustomerSearchMapper;
import com.natwest.pbbdhb.aip.fma.service.CinMatchService;
import org.apache.commons.lang.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.applicationHeaders;
import static org.apache.commons.lang.StringUtils.isBlank;


@Service
public class CinMatchServiceImpl implements CinMatchService {

    private static final String SINGLE_MATCH_VERIFIED = "SINGLE-MATCH-VERIFIED";

    @Autowired
    private CustomerSearchMapper customerSearchMapper;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${cin.search.endpoint:}")
    private String cinSearchURL;

    private static final Logger LOGGER = LoggerFactory.getLogger(CinMatchServiceImpl.class);

    @Override
    public List<CinResponse> cinSearch(final Application fmaRequest, final String brand, final Client client) {

        List<CinResponse> cinResponses = fmaRequest.getApplicants().stream()
                .filter(applicant -> isBlank(applicant.getCin()))
                .map(applicant -> applicantCinSearch(applicant, brand, fmaRequest.getLenderCaseId(), client) )
                .collect(Collectors.toList());

        checkUKAddress(cinResponses);

        return cinResponses;
    }


    private CinResponse applicantCinSearch(final Applicant applicant, final String brand, final String lenderCaseId, final Client client) {
        LOGGER.info("Case id : {}-AF5, applicantCinSearch called", lenderCaseId);
        CustomerSearchRequest request = customerSearchMapper.toCustomerSearchRequest(applicant, client.toString(), lenderCaseId);
        HttpHeaders headers = applicationHeaders(brand);

        try {
            ResponseEntity<CinResponse> responseEntity = restTemplate.postForEntity(
                    cinSearchURL, new HttpEntity(request, headers), CinResponse.class);
            CinResponse cinResponse = responseEntity.getBody();

            if(Objects.nonNull(cinResponse) && cinResponse.getCin().size() == 1 && SINGLE_MATCH_VERIFIED.equalsIgnoreCase(cinResponse.getCinMatchIndicator())) {
                applicant.setCin(cinResponse.getCin().get(0));
                cinResponse.setApplicant(applicant);
                LOGGER.info("Case id : {}-AF9, applicantCinSearch completed with cin found, ", lenderCaseId);

                return cinResponse;
            }
        }
        catch (Exception ex) {
            LOGGER.error("Case id : {}, Exception occurred while calling CIN search : {}", lenderCaseId, ex.getMessage());
        }

        LOGGER.info("Case id : {}-AF10, applicantCinSearch completed", lenderCaseId);
        return CinResponse.builder().cin(Collections.emptyList()).applicant(applicant).build();
    }

    private void checkUKAddress(final List<CinResponse> cinResponses) {

        cinResponses.forEach(cinResponse -> {
            Boolean isUkAddress = cinResponse.getApplicant().getAddresses().stream()
                    .filter(address -> BooleanUtils.isTrue(address.getIsCurrentAddress()))
                    .findFirst()
                    .map(Address::getUkAddress)
                    .orElse(false);

            cinResponse.setUkAddress(isUkAddress);
        });
    }

}