package com.natwest.pbbdhb.aip.fma.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStep;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import org.springframework.http.HttpStatus;

import java.util.List;

public interface StateService {

    HttpStatus captureApplication(String brand, Application application) throws JsonProcessingException;

    HttpStatus updateApplication(String brand, Application aipRequest, FmaResponse fmaResponse, RiskResponse scoringResponse) throws JsonProcessingException;

    HttpStatus captureApplicationState(String brand, Application application, RiskResponse riskResponse) throws JsonProcessingException;

    HttpStatus createApplicationState(String brand, Application aipToFmaRequest, List<CinResponse> applicantsCinResponse) throws JsonProcessingException;

    HttpStatus captureEkycApplicationState(String brand, EkycApplication ekycApplication, RiskResponse riskResponse) throws JsonProcessingException;

    AipToFmaApplication retrieveApplication(String brand, String lenderCaseId, ApplicationStage stage);

    AipToFmaApplicationState retrieveApplicationState(String brand, String lenderCaseId, ApplicationStage stage, ApplicationStep step);
}
