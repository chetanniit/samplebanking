package com.natwest.pbbdhb.aip.fma.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum MaritalStatus {

    DIVORCED("D","Divorced"),
    MARRIED("M","Married"),
    SEPARATED("P","Separated"),
    SINGLE("S","Single"),
    ENGAGED("T","Engaged"),
    WIDOWED("W","Widowed"),
    LIVING_WITH_PARTNER("L","Living with Partner");



    private String key;
    private String value;

    @Override
    public String toString(){
        return key;
    }

}
