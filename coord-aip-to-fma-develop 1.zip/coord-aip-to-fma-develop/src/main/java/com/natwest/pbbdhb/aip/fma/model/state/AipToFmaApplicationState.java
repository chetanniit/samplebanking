package com.natwest.pbbdhb.aip.fma.model.state;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.response.Applicant;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class AipToFmaApplicationState {

    private String caseId;

    private String stage;

    private String applicationStep;

    private String request;

    private String response;

    private String decision;

    private String decisionUniqueId;

    private String httpStatus;

    private List<Applicant> applicants;

}
