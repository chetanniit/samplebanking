package com.natwest.pbbdhb.aip.fma.service;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;

public interface CaseService {

    Case trackCase(Application application, RiskResponse scoringResponse, String clientId,String brand);

    String getNameFromClientId(String clientId, String brand);

}
