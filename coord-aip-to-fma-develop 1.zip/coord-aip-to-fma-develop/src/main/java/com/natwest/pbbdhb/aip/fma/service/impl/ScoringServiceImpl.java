package com.natwest.pbbdhb.aip.fma.service.impl;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.ExistingMortgage;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.service.ScoringService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

@Service
public class ScoringServiceImpl implements ScoringService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ScoringServiceImpl.class);

    @Value("${es.scoring.endpoint}")
    private String scoringEndPoint;

    @Autowired
    @Qualifier("restTemplateForTykApi")
    private RestTemplate restTemplate;

    @Autowired
    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Override
    public RiskResponse scoringCheck(@Valid Application application) {
        LOGGER.info("Case id : {}-AF11, scoringCheck called", application.getLenderCaseId());
        LOGGER.debug("Case id : {}, scoringCheck_endPointUrl={}, aipToFmaScoringRequest={}", application.getLenderCaseId(), scoringEndPoint, application);

        restTemplate.getMessageConverters().add(0, mappingJackson2HttpMessageConverter);
        defaultOrRemoveAttributesBeforeSendingToScore(application);
        RiskResponse scoringResponse = restTemplate.postForObject(scoringEndPoint, application, RiskResponse.class);

        LOGGER.debug("scoreCheck_aipResponse={}", scoringResponse);
        LOGGER.info("Case id : {}-AF12, scoringCheck completed", application.getLenderCaseId());

        return scoringResponse;
    }

    private void defaultOrRemoveAttributesBeforeSendingToScore(Application scoreRequest) {
        if (scoreRequest.getApplicants() != null && !scoreRequest.getApplicants().isEmpty()) {
            scoreRequest.getApplicants()
                    .stream()
                    .filter(Objects::nonNull)
                    .forEach(applicant -> {
                        if (applicant.getExistingMortgage() != null) {
                            ExistingMortgage existingMortgage = applicant.getExistingMortgage();

                            if (existingMortgage.getPropertyBeingSold() == null) {
                                existingMortgage.setPropertyBeingSold(existingMortgage.getPropertyBeingRedeemed());
                            }

                            existingMortgage.setPropertyBeingRedeemed(null);
                        }
                    });
        }


        if (nonNull(scoreRequest.getMortgage())) {

            Integer mortgageTerm = scoreRequest.getMortgage().getMortgageTerm();
            Integer interestOnlyTermYears = scoreRequest.getMortgage().getInterestOnlyTermYears();

            if (nonNull(mortgageTerm) && mortgageTerm.intValue() > 0 && isNull(scoreRequest.getMortgage().getMortgageTermMonths())) {
                scoreRequest.getMortgage().setMortgageTermMonths(0);
            }

            if (nonNull(interestOnlyTermYears) && interestOnlyTermYears.intValue() > 0 && isNull(scoreRequest.getMortgage().getInterestOnlyTermMonths())) {
                scoreRequest.getMortgage().setInterestOnlyTermMonths(0);
            }
        }
    }

}
