package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.http.HttpStatus;

import static java.util.Objects.isNull;

@Mapper(config = MappingConfig.class)
public interface AipToFmaApplicationStateMapper {

    AipToFmaApplicationStateMapper INSTANCE = Mappers.getMapper(AipToFmaApplicationStateMapper.class);

    @Mapping(target = "caseId", source = "application.lenderCaseId")
    @Mapping(target = "channel", source = "application.formInfo.dataFeed")
    @Mapping(target = "stage", constant = "AIP_TO_FMA")
    @Mapping(target = "request", source = "request")
    AipToFmaApplication toApplicationRequest(Application application, String request);


    @Mapping(target = "caseId", source = "application.lenderCaseId")
    @Mapping(target = "decision", source = "riskResponse.decision")
    @Mapping(target = "decisionUniqueId", source = "riskResponse.decisionUniqueId")
    @Mapping(target = "applicants", source = "riskResponse.applicants")
    @Mapping(target = "stage", constant = "AIP_TO_FMA")
    @Mapping(target = "applicationStep", constant = "SCORE")
    @Mapping(target = "request", source = "request")
    @Mapping(target = "response", source = "response")
    @Mapping(target = "httpStatus", source = "riskResponse", qualifiedByName = "getHttpStatus")
    AipToFmaApplicationState toApplicationStateRequest(Application application, RiskResponse riskResponse, String request, String response);

    @Mapping(target = "stage", constant = "AIP_TO_FMA")
    @Mapping(target = "applicationStep", constant = "CIN_MATCH")
    AipToFmaApplicationState toCinApplicationState(String caseId);

    @Mapping(target = "caseId", source = "ekycApplication.lenderCaseId")
    @Mapping(target = "decisionUniqueId", source = "ekycApplication.decisionUniqueId")
    @Mapping(target = "applicants", source = "ekycApplication.applicants")
    @Mapping(target = "stage", constant = "AIP_TO_FMA")
    @Mapping(target = "applicationStep", constant = "EKYC")
    @Mapping(target = "request", source = "request")
    @Mapping(target = "response", source = "response")
    @Mapping(target = "httpStatus", source = "riskResponse", qualifiedByName = "getHttpStatus")
    AipToFmaApplicationState toEkycApplicationStateRequest(EkycApplication ekycApplication, RiskResponse riskResponse,String request, String response);

    @Named("getHttpStatus")
    static String getHttpStatus(RiskResponse riskResponse) {
        return isNull(riskResponse.getErrorCode()) ? String.valueOf(HttpStatus.OK.value()) : riskResponse.getErrorCode();
    }
}
