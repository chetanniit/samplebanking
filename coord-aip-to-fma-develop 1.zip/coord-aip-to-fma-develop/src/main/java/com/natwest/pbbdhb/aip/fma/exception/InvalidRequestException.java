package com.natwest.pbbdhb.aip.fma.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvalidRequestException extends RuntimeException {

    private String message;

    private int statusCode;
}
