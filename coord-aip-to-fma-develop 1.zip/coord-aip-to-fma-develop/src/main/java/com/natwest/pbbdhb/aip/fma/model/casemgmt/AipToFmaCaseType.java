package com.natwest.pbbdhb.aip.fma.model.casemgmt;

public enum AipToFmaCaseType {

    AIP_To_FMA(5);

    private final long id;

    AipToFmaCaseType(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
