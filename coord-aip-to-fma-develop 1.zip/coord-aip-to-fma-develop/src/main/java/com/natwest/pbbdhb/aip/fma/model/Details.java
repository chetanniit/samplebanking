package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.enums.Purpose;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Details {

    @Schema(type = "String",allowableValues = "HOME_IMPROVEMENT,HOUSE_PURCHASE,HOLIDAY,BUY_NEW_OR_USED_CAR,DEBT_CONSOLIDATION,OTHER")
    private Purpose purpose;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal amount;

}
