package com.natwest.pbbdhb.aip.fma.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.fma.model.enums.Brand;
import org.springframework.http.HttpHeaders;

import static com.natwest.pbbdhb.aip.fma.model.enums.Brand.NATWEST;

public class AppUtil {

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    public static final String BRAND = "brand";
    public static final String BRAND_NWB = "nwb";
    private static final HttpHeaders nwbHttpHeaders;
    private static final HttpHeaders rbsHttpHeaders;
    public static final ObjectMapper objectMapperOrganic;

    static {
        objectMapperOrganic = new ObjectMapper();
        nwbHttpHeaders = new HttpHeaders();
        nwbHttpHeaders.add(CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        nwbHttpHeaders.add(BRAND, BRAND_NWB);

        rbsHttpHeaders = new HttpHeaders();
        rbsHttpHeaders.add(CONTENT_TYPE, CONTENT_TYPE_APPLICATION_JSON);
        rbsHttpHeaders.add(BRAND, Brand.RBS.value().toLowerCase());
    }

    public static HttpHeaders applicationHeaders(Brand brand) {
        return brand == NATWEST? nwbHttpHeaders : rbsHttpHeaders;
    }

    public static HttpHeaders applicationHeaders(String brand) {
        return BRAND_NWB.equals(brand)? nwbHttpHeaders : rbsHttpHeaders;
    }

}