package com.natwest.pbbdhb.aip.fma.service.impl;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.ClientDetails;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.AipToFmaCaseType;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.AipToFmaDecision;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.CaseStatus;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.CaseType;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Decision;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.DecisionReason;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.service.CaseService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;

import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.applicationHeaders;
import static org.apache.commons.lang.StringUtils.isNotBlank;

@Service
public class CaseServiceImpl implements CaseService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CaseServiceImpl.class);

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${create.case.endpoint}")
    private String createCaseEndPoint;

    @Value("${fetch.client.details.endpoint}")
    private String fetchClientDetailsPoint;

    public Case trackCase(Application application, RiskResponse scoringResponse, String clientId,String brand) {
        LOGGER.info("Case id : {}-AF23, trackApplication called", application.getLenderCaseId());
        LOGGER.debug("Case id : {}, createCase: called with scoringResponse={}, createCase_endPointUrl={}", application.getLenderCaseId(), scoringResponse, createCaseEndPoint);
        return restTemplate.postForObject(createCaseEndPoint,new HttpEntity<>(createCase(application, scoringResponse, clientId),applicationHeaders(brand)), Case.class);
    }

    private Case createCase(Application application, RiskResponse scoringResponse, String clientId) {
        AipToFmaDecision aipToFmaDecision = isNotBlank(scoringResponse.getDecision()) ?
                AipToFmaDecision.valueOf(scoringResponse.getDecision().toUpperCase()) : null;

        return Case.builder()
                .caseId(application.getLenderCaseId())
                .clientId(clientId)
                .source(application.getFormInfo().getDataFeed().name())
                .caseType(CaseType.builder().id(AipToFmaCaseType.AIP_To_FMA.getId()).type(AipToFmaCaseType.AIP_To_FMA.name()).build())
                .caseStatusSet(aipToFmaDecision !=null ? new HashSet<>(Collections.singletonList(CaseStatus.builder()
                        .creationDate(new Date())
                        .decisionReason(DecisionReason.builder().id(aipToFmaDecision.getId()).decisionReason(aipToFmaDecision.name()).build())
                        .decision(Decision.builder().id(aipToFmaDecision.getId()).decision(aipToFmaDecision.name()).build()).build())) : null)
                .creationDate(new Date())
                .build();
    }

    public String getNameFromClientId(String clientId, String brand) {
        try {
            ClientDetails clientDetails = restTemplate.exchange(fetchClientDetailsPoint, HttpMethod.GET,
                    new HttpEntity<>(applicationHeaders(brand)), ClientDetails.class, clientId).getBody();
            if (clientDetails != null && clientDetails.getName() != null) {
                return clientDetails.getName();
            }
        } catch (RestClientException restClientException) {
            LOGGER.error("exception while finding clientDetails : {}", restClientException.getMessage());
        }
        return null;
    }

}
