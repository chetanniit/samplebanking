package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MortgageMarketReview {

    @Schema( type = "String", allowableValues = "true, false")
    private Boolean futureLoansCommitments;

    @Schema( type = "String", allowableValues = "true, false")
    private Boolean futureHouseLeisure;

    @Schema( type = "String", allowableValues = "true, false")
    private Boolean futurePropertyExpenses;

    @Valid
    @Schema( type = "List", allowableValues = "true, false")
    private List<@Valid FutureIncomeDrop> applicants;


}
