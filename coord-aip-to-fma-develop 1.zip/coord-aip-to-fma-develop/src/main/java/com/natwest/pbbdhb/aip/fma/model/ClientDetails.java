package com.natwest.pbbdhb.aip.fma.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ClientDetails {
    private String organisation;
    private String name;
}

