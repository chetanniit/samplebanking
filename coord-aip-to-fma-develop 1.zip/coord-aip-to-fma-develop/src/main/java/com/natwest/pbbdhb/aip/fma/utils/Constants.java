package com.natwest.pbbdhb.aip.fma.utils;

public class Constants {
    public static final String CLIENT_ID = "client_id";
    public static final String BRAND = "brand";
}
