package com.natwest.pbbdhb.aip.fma.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.natwest.pbbdhb.aip.fma.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.fma.exception.ClientNotOnboardedException;
import com.natwest.pbbdhb.aip.fma.exception.ErrorResponse;
import com.natwest.pbbdhb.aip.fma.model.*;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.AipToFmaDecision;
import com.natwest.pbbdhb.aip.fma.model.casemgmt.Case;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStep;
import com.natwest.pbbdhb.aip.fma.model.enums.Client;
import com.natwest.pbbdhb.aip.fma.model.enums.DataFeed;
import com.natwest.pbbdhb.aip.fma.model.mapper.EkycApplicationMapper;
import com.natwest.pbbdhb.aip.fma.model.mapper.RiskResponseMapper;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponseGenerationRequest;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import com.natwest.pbbdhb.aip.fma.service.*;
import org.apache.commons.lang.BooleanUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import jakarta.validation.Valid;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.aip.fma.utils.Checks.errorOutIfTrue;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang.StringUtils.*;
import static com.natwest.pbbdhb.aip.fma.model.enums.LoanPurpose.BUY_TO_LET;
import static com.natwest.pbbdhb.aip.fma.model.enums.LoanPurpose.BUY_TO_LET_PURCHASE;
import static com.natwest.pbbdhb.aip.fma.model.enums.LoanPurpose.BUY_TO_LET_REMORTGAGE;

@Service
public class AipToFmaServiceImpl implements AipToFmaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AipToFmaServiceImpl.class);
    private static final String AIP_SHOULD_BE_ACCEPTED_OR_REFERRED = "Invalid state to convert, AIP application should be either Accepted or Referred";
    private static final Integer maxTermRemaining = 99;

    private final ScoringService scoreService;
    private final CaseService caseService;
    private final StateService stateService;
    private final EkycApplicationMapper ekycApplicationMapper;
    private final ResponseService responseService;
    private final ObjectMapper objectMapper;
    private final CinMatchService cinMatchService;
    private final EkycService ekycService;
    private final RiskResponseMapper riskResponseMapper;
    private final ModelMapper modelMapper;

    @Value("${cin.search.enable:true}")
    private Boolean enableCinSearch;

    @Autowired
    public AipToFmaServiceImpl(ScoringService scoreService,
                               CaseService caseService,
                               StateService stateService,
                               EkycApplicationMapper ekycApplicationMapper,
                               ResponseService responseService,
                               ObjectMapper objectMapper,
                               CinMatchService cinMatchService,
                               EkycService ekycService,
                               RiskResponseMapper riskResponseMapper,
                               ModelMapper modelMapper) {
        this.scoreService = scoreService;
        this.caseService = caseService;
        this.stateService = stateService;
        this.ekycApplicationMapper = ekycApplicationMapper;
        this.responseService = responseService;
        this.objectMapper = objectMapper;
        this.cinMatchService = cinMatchService;
        this.ekycService = ekycService;
        this.riskResponseMapper = riskResponseMapper;
        this.modelMapper = modelMapper;
    }

    @Override
    public FmaResponse processApplication(String brand, String clientId, @Valid Application application) throws IOException, BureauServiceException {
        String lenderCaseId = application.getLenderCaseId();
        LOGGER.info("Case id : {}-AF2, processApplication called", lenderCaseId);
        List<CinResponse> applicantsCinResponse = Lists.newArrayList();
        Client client = validateClientIsOnBoardedAndGetClient(clientId, brand);
        Optional<AipToFmaApplication> previousApplication = fetchApplication(brand, lenderCaseId);

        if(previousApplication.isPresent()) {
            Optional<FmaResponse> previousAppResponse = fetchResponse(brand, application, previousApplication.get(), clientId);
            if(previousAppResponse.isPresent() && isNull(previousAppResponse.get().getErrorCode())) return previousAppResponse.get();
        }

        validateAndApplyPrerequisites(brand, application);

        if(!previousApplication.isPresent()) stateService.captureApplication(brand, application);

        applyPrerequisitesForScoringCheck(application);

        boolean cinNotPresent = application.getApplicants().stream().anyMatch(applicant -> isBlank(applicant.getCin()));

        if(isCinSearchEnabled() && cinNotPresent) {
            applicantsCinResponse = cinMatchService.cinSearch(application, brand, client);
        }

        DataFeed dataFeed = getDataFeed(client.name(),lenderCaseId);
        application.getFormInfo().setDataFeed(dataFeed);

        RiskResponse riskResponse = scoringCheck(application);
        riskResponse.setChannel(client.name());

        stateService.captureApplicationState(brand, application, riskResponse);

        if(cinNotPresent && (!AipToFmaDecision.DECLINE.name().equalsIgnoreCase(riskResponse.getDecision())) && isEmpty(riskResponse.getErrorCode())) {
            callKyc(brand, application, riskResponse);
        }

        if(isCinSearchEnabled() && cinNotPresent) stateService.createApplicationState(brand, application, applicantsCinResponse);

        if(isNotEmpty(riskResponse.getErrorCode())) {
            stateService.updateApplication(brand, application, null, riskResponse);
            throw new BureauServiceException(riskResponse.getErrorDescription(), riskResponse.getErrorCode());
        }

        if(cinNotPresent && CollectionUtils.isEmpty(riskResponse.getApplicants()) && (!AipToFmaDecision.DECLINE.name().equalsIgnoreCase(riskResponse.getDecision()))) {
            addApplicantsToRiskResponse(applicantsCinResponse, riskResponse);
        }

        FmaResponse fmaResponse = responseService.generateFmaResponse(brand, modelMapper.map(riskResponse, RiskResponseGenerationRequest.class));
        fmaResponse.setPackaging(riskResponse.getPackaging());

        stateService.updateApplication(brand, application, fmaResponse, riskResponse);

        if(!previousApplication.isPresent()) {
            Case aCase = caseService.trackCase(application, riskResponse, clientId,brand);
            LOGGER.info("Case id : {}-AF24, processApplication completed, AIP To FMA application {} has been tracked with the case management", lenderCaseId, aCase.getCaseId());
        }

        return fmaResponse;
    }

    @Override
    public Client validateClientIsOnBoardedAndGetClient(String clientId, String brand) {
        String clientName = caseService.getNameFromClientId(clientId, brand);
        Optional<Client> dataFeedOptional = Client.stream().filter(client -> client.name().equalsIgnoreCase(clientName)).findFirst();
        return dataFeedOptional.orElseThrow(() -> new ClientNotOnboardedException("Client Id is not on-boarded for " + clientId));
    }

    private void setChannel(String brand, String clientId, RiskResponse riskResponse) {
        Client client = validateClientIsOnBoardedAndGetClient(clientId, brand);
        riskResponse.setChannel(client.name());
    }

    private static DataFeed getDataFeed(String channel, String lenderCaseId) {
        for (DataFeed df : DataFeed.values()) {
            if (df.getValue().equals(channel)) {
                return df;
            }
        }
        throw new RuntimeException("Channel with name " + channel + " has not been found for lenderCaseId: "+ lenderCaseId);
    }

    private Optional<FmaResponse> fetchResponse(String brand, Application application, AipToFmaApplication previousApplication, String clientId) throws IOException {
        String lenderCaseId = application.getLenderCaseId();
        Optional<FmaResponse> previousAppResponse = nonNull(previousApplication.getResponse())
                ? Optional.ofNullable(objectMapper.readValue(previousApplication.getResponse(), FmaResponse.class)) : Optional.empty();

        if(!previousAppResponse.isPresent() || nonNull(previousAppResponse.get().getErrorCode())){
            Optional<AipToFmaApplicationState> scoreState = fetchApplicationState(brand, lenderCaseId, ApplicationStep.SCORE);
             if(scoreState.isPresent() && nonNull(scoreState.get().getResponse()) && nonNull(scoreState.get().getApplicants())) {
                 RiskResponse riskResponse = objectMapper.readValue(scoreState.get().getResponse(), RiskResponse.class);
                 if(nonNull(riskResponse) && isNull(riskResponse.getErrorCode())) {
                     riskResponse.setApplicants(scoreState.get().getApplicants());
                     riskResponse.setLoanMessage(null);
                     setChannel(brand, clientId, riskResponse);
                     previousAppResponse = Optional.ofNullable(responseService.generateFmaResponse(brand, modelMapper.map(riskResponse, RiskResponseGenerationRequest.class)));
                     if (previousAppResponse.isPresent())
                         stateService.updateApplication(brand, application, previousAppResponse.get(), riskResponse);
                 }
             }
        }
        return previousAppResponse;
    }

    private Optional<AipToFmaApplication> fetchApplication(String brand, String lenderCaseId) {
        AipToFmaApplication fmaApplication = null;
        try {
            fmaApplication = stateService.retrieveApplication(brand, lenderCaseId, ApplicationStage.AIP_TO_FMA);
        } catch (Exception exception){
           LOGGER.error("No FMA application found against {}", lenderCaseId);
        }
        return Optional.ofNullable(fmaApplication);
    }

    private Optional<AipToFmaApplicationState> fetchApplicationState(String brand, String lenderCaseId, ApplicationStep step) {
        AipToFmaApplicationState applicationState = null;
        try {
            applicationState = stateService.retrieveApplicationState(brand, lenderCaseId, ApplicationStage.AIP_TO_FMA, step);
        } catch (Exception exception){
            LOGGER.error("No FMA application found against {}", lenderCaseId);
        }
        return Optional.ofNullable(applicationState);
    }

    private RiskResponse scoringCheck(Application application) throws IOException {
        RiskResponse scoringResponse = RiskResponse.builder().lenderCaseId(application.getLenderCaseId()).build();
        application.setServiceRequired(ApplicationStep.SCORE.name());
        try {
            formatPostcode(application);
            scoringResponse = scoreService.scoringCheck(application);

        } catch (Exception exception){
            logException(scoringResponse, exception, application.getLenderCaseId());
        }
        return scoringResponse;
    }

    private void callKyc(String brand, Application application, RiskResponse riskResponse) throws IOException {

        EkycApplication ekycApplication = ekycApplicationMapper.toEkycApplication(application);
        ekycApplication.setDecisionUniqueId(riskResponse.getDecisionUniqueId());
        RiskResponse kycResponse = kycCheck(brand, ekycApplication);
        riskResponse.setApplicants(kycResponse.getApplicants());
        riskResponse.setErrorCode(kycResponse.getErrorCode());
        riskResponse.setErrorDescription(kycResponse.getErrorDescription());
    }

    private RiskResponse kycCheck(String brand, EkycApplication ekycApplication) throws IOException {
        RiskResponse ekycResponse = RiskResponse.builder().lenderCaseId(ekycApplication.getLenderCaseId()).build();
        ekycApplication.setServiceRequired(ApplicationStep.EKYC.name());
        try {
            ekycResponse = ekycService.kycCheck(ekycApplication);

        } catch (Exception exception){
            logException(ekycResponse, exception, ekycApplication.getLenderCaseId());
        }
        stateService.captureEkycApplicationState(brand, ekycApplication, ekycResponse);

        return ekycResponse;
    }

    private void addApplicantsToRiskResponse(final List<CinResponse> applicantsCinResponse, final RiskResponse riskResponse) {
        List<com.natwest.pbbdhb.aip.fma.model.response.Applicant> applicants = Lists.newArrayList();

        applicantsCinResponse.forEach(cinResponse -> applicants.add(riskResponseMapper.toApplicantRequest(cinResponse.getApplicant(),
                BooleanUtils.isTrue(cinResponse.getVMarker()))));

        riskResponse.setApplicants(applicants);
    }

    private void validateAndApplyPrerequisites(String brand, Application application) {
        String lenderCaseId = application.getLenderCaseId();
        AipToFmaApplication aipToFmaApplication = stateService.retrieveApplication(brand, lenderCaseId, ApplicationStage.AIP);
        errorOutIfTrue(nonNull(aipToFmaApplication) && AipToFmaDecision.DECLINE.name().equalsIgnoreCase(aipToFmaApplication.getDecision()), AIP_SHOULD_BE_ACCEPTED_OR_REFERRED);
        application.setDecisionUniqueId(aipToFmaApplication.getDecisionUniqueId());
        application.setLenderCaseId(lenderCaseId);

        FormInfo formInfo = application.getFormInfo();
        formInfo.setApplicationStage(ApplicationStage.FMA);
        application.setFormInfo(formInfo);
    }

    private void applyPrerequisitesForScoringCheck(Application application) {
        Property property = application.getProperty();
        if(nonNull(property)) {
            Integer termRemaining = property.getTermRemaining();
            property.setTermRemaining(nonNull(termRemaining) && termRemaining > maxTermRemaining ? maxTermRemaining : termRemaining);
        }

        if(application.getApplicants().stream().anyMatch(applicant -> nonNull(applicant.getExistingMortgage()))) {
            application.getApplicants().forEach(applicant -> {
                Expenditure expenditure = applicant.getExpenditure();
                if (nonNull(expenditure) && Lists.newArrayList(BUY_TO_LET, BUY_TO_LET_REMORTGAGE,BUY_TO_LET_PURCHASE).contains(application.getLoanPurpose()))
                    expenditure.setMortgageRent(BigDecimal.ZERO);
            });
        }
    }

    private void formatPostcode(Application aipRequest) {
        Intermediary intermediary = aipRequest.getIntermediary();
        if (intermediary != null) intermediary.setPostcode(removeAllSpaces(intermediary.getPostcode()));
        aipRequest.getApplicants().stream().filter(Objects::nonNull).forEach(applicant -> applicant.getAddresses()
                .forEach(address -> {
                    String postcode = address.getPostcode();
                    address.setPostcode(removeAllSpaces(postcode));
                }));
    }

    private String removeAllSpaces(String postcode) {
        return isNotEmpty(postcode) ? postcode.replaceAll("\\s+", "") : postcode;
    }

    private boolean isCinSearchEnabled() {
        // Return true when null
        return isNull(enableCinSearch) || enableCinSearch;
    }

    private void logException(RiskResponse riskResponse, Exception exception, String lenderCaseId) throws IOException {
        String message;
        int statusCode = 500;
        if (exception instanceof HttpServerErrorException) {
            message = exception.getMessage();
            statusCode = ((HttpServerErrorException) exception).getRawStatusCode();

        } else if (exception instanceof HttpClientErrorException.BadRequest) {
            statusCode = ((HttpClientErrorException.BadRequest) exception).getRawStatusCode();
            String responseBodyAsString = ((HttpClientErrorException.BadRequest) exception).getResponseBodyAsString();
            ErrorResponse errorResponse = isNotEmpty(responseBodyAsString) ? objectMapper.readValue(responseBodyAsString, ErrorResponse.class)
                    : new ErrorResponse(HttpStatus.BAD_REQUEST, exception.getMessage());
            message = errorResponse.getMessage();
        } else {
            message = exception.getMessage();
        }
        riskResponse.setErrorCode(String.valueOf(statusCode));
        riskResponse.setErrorDescription(lenderCaseId.concat(" : ").concat(message == null ? exception.getMessage() : message));
        LOGGER.error("Case id : {}, Scoring call failed with error code: {}, message:{}", lenderCaseId, statusCode, message);
    }
}
