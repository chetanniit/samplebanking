package com.natwest.pbbdhb.aip.fma.model.response.cin.search;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CinKycVerification {

    private String firstName;

    private String lastName;

    private LocalDate birthDate;

    private String postCode;

    private List<String> cin;

    private Boolean vmarker;

    private String cinMatchIndicator;
}
