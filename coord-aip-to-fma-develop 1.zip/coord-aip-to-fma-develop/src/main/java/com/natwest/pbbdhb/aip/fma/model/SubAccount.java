
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.enums.RepaymentType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class SubAccount {

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema(type = "BigDecimal")
    private BigDecimal currentBalance;

    @Valid
    @PositiveOrZero
    @Max(value = 999, message = "allows max 3 digits")
    @Schema(type = "Integer")
    private Integer termRemaining;

    @Schema(allowableValues = "REPAYMENT,INTEREST_ONLY,MIXED,SUB_ACCOUNT_CAPITAL_REPAYMENT,SUB_ACCOUNT_INTEREST_ONLY")
    private RepaymentType repaymentType;


}
