package com.natwest.pbbdhb.aip.fma.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class RiskResponse {

    @Schema(example = "2022033011700")
    private String decisionUniqueId;

    @Schema(example = "REFER")
    private String decision;

    @Schema(example = "CF1648639201527")
    private String lenderCaseId;

    @Schema()
    private String loanMessage;

    @Schema()
    private String podDecision;

    @Schema()
    private List<Policy> policies;

    @Schema()
    private List<Applicant> applicants;

    @Schema()
    private String errorCode;

    @Schema(example = "FOCUS")
    private String channel;

    @Schema()
    private String errorDescription;

    @Schema()
    private List<EquifaxResponseDetails> equifaxResponseDetails;

    @Schema()
    private Packaging packaging;
}
