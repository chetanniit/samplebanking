package com.natwest.pbbdhb.aip.fma.service;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;

import jakarta.validation.Valid;

public interface ScoringService {

    RiskResponse scoringCheck(@Valid Application request);

}
