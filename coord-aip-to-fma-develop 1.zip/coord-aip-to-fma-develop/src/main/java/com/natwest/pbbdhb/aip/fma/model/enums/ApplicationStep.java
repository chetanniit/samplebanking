package com.natwest.pbbdhb.aip.fma.model.enums;


public enum ApplicationStep {
    SCORE,
    EKYC;
}
