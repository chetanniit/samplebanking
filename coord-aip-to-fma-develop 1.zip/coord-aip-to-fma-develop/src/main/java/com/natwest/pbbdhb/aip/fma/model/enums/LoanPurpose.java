package com.natwest.pbbdhb.aip.fma.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum LoanPurpose {

    FIRST_TIME_BUYER_90_TO_95("P", "First Time Buyer 90.01%-95%"),
    RESIDENTIAL_PURCHASE_90_TO_95("R", "Residential Purchase 90.01%-95%"),
    FIRST_TIME_BUYER_H2B("I", "FirstTime Buyer H2B"),
    RES_PURCHASE_H2B_MG("S", "Res Purchase H2B MG"),
    FIRST_TIME_BUYER_NEWBUY("N", "FirstTime Buyer NewBuy"),
    RES_PURCHASE_NEWBUY("V", "Res Purchase NewBuy"),
    RES_2ND_PROP_AND_PURCHASE("D", "Res 2nd prop + purchase"),
    SHARED_EQUITY_PURCHASE("K", "Shared equity purchase"),
    RIGHT_TO_BUY_PURCHASE("C", "Right to buy purchase"),
    RES_PURCHASE_FIRST_TIME("T", "Res purchase 1st time"),
    FIRST_TIME_BUYER("T","First Time Buyer"),
    RESIDENTIAL_PURCHASE("A", "Residential  purchase"),
    RES_2ND_PROP_AND_REMORTG("Q", "Res 2nd prop + remort"),
    RIGHT_TO_BUY_REMORTGAGE("W", "Right to buy remortgage"),
    RESIDENTIAL_MORTGAGE("J", "Residential remortgage"),
    BUY_TO_LET_PURCHASE("Z", "Buy to let purchase"),
    BUY_TO_LET_REMORTGAGE("U", "Buy to let remortgage"),
    REMORTGAGE_H2B_MG("Y", "Remortgage H2B MG"),
    RESIDENTIAL_ADBO("1", "Residential ADBO"),
    BUY_TO_LET_ADBO("2", "Buy to Let ADBO"),

    //Inactive types for FOCUS
    EXIST_NWMS_CUST_MOVING("E", "Exist NWMS Cust Moving"),
    NEW_CUST_MOVING_OTHER("O", "New Cust Moving/Other"),
    EXTRA_BORROWING("X", "Extra Borrowing"),
    HOUSE_PURCHASE("H", "House Purchase"),
    REMORTGAGE("M", "Remortgage"),
    BUY_TO_LET("L", "Buy to Let"),
    GUARANTOR("G", "Guarantor");

    private String key;

    private String value;

    @Override
    public String toString(){
        return key;
    }


}
