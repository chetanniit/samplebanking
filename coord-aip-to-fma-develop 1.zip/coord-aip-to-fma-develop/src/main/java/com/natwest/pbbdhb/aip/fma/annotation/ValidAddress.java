package com.natwest.pbbdhb.aip.fma.annotation;

import com.natwest.pbbdhb.aip.fma.annotation.validator.AddressValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = { AddressValidator.class })
@Documented
public @interface ValidAddress {
    String message() default "Atleast one of the fields must be available (flat, houseName, houseNumber)";
    Class<?>[] groups() default{};
    Class<? extends Payload>[] payload() default{};


}
