package com.natwest.pbbdhb.aip.fma.model.mapper;

import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = MappingConfig.class)
public interface EkycApplicationMapper {

    EkycApplicationMapper INSTANCE = Mappers.getMapper(EkycApplicationMapper.class);

    EkycApplication toEkycApplication(Application application);

}
