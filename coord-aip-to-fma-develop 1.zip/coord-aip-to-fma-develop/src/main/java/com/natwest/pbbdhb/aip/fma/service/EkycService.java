package com.natwest.pbbdhb.aip.fma.service;

import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;

import jakarta.validation.Valid;
import java.util.List;

public interface EkycService {

    RiskResponse kycCheck(@Valid EkycApplication request);

    boolean verifyKyc(final String brand, final List<CinResponse> applicantsCinResponse, final String lenderCaseId);

}
