package com.natwest.pbbdhb.aip.fma.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import static java.lang.String.format;

@ControllerAdvice
@Slf4j
public class AipToFmaExceptionHandler {
    private final ObjectMapper objectMapper;

    @Autowired
    public AipToFmaExceptionHandler(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @ExceptionHandler({HttpClientErrorException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpClientErrorException(HttpClientErrorException ex) throws IOException {
        ErrorResponse errorResponse = objectMapper.readValue(ex.getResponseBodyAsString(), ErrorResponse.class);
        log.error("HttpClientErrorException Bad Request: {}", errorResponse);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    @ExceptionHandler({JsonProcessingException.class, ParseException.class, HttpMessageNotReadableException.class, RestClientException.class, ClientNotOnboardedException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBadRequestException(RuntimeException ex) {

        String errorMessage = ex.getMessage();
        if (ex instanceof HttpMessageNotReadableException) {
            HttpMessageNotReadableException exception = ((HttpMessageNotReadableException) ex);
            String message = exception.getCause().getMessage();
            ErrorResponse errorResponse = ErrorResponse.builder().errorMessage(message).responseStatus(HttpStatus.BAD_REQUEST).build();
            log.error("HttpMessageNotReadableException Bad Request: {}", errorResponse);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
        log.error("JsonProcessing/Parse/RestClientException error during processing: {}", errorMessage);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST, errorMessage));
    }


    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        log.error("Found MethodArgumentNotValid during processing: {} ", ex.getMessage());
        List<FieldError> errors = ex.getBindingResult().getFieldErrors();
        StringBuilder errorMessage = new StringBuilder(StringUtils.EMPTY);
        errors.forEach(error -> errorMessage.append(format("%s %s,found: %s ", error.getField(), error.getDefaultMessage(), error.getRejectedValue())));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST, errorMessage.toString()));
    }

    @ExceptionHandler({RuntimeException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleRuntimeException(RuntimeException ex) {

        String errorMessage = ex.getMessage();
        log.error("Runtime error during processing: {}", errorMessage);

        if (ex instanceof InvalidRequestException) {
            log.error("InvalidRequestException during processing: {}", errorMessage);
            HttpStatus httpStatus = HttpStatus.valueOf(((InvalidRequestException) ex).getStatusCode());
            return ResponseEntity.status(httpStatus).body(new ErrorResponse(httpStatus, errorMessage));
        }

        HttpStatus responseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(responseStatus).body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, errorMessage));
    }

    @ExceptionHandler({NoHandlerFoundException.class})
    @ResponseBody
    public ResponseEntity<HttpStatus> noHandlerFoundException(NoHandlerFoundException ex) {
        log.error("NoHandlerFound error during processing: {} {}", ex.getHttpMethod(), ex.getRequestURL());
        HttpStatus responseStatus = HttpStatus.NOT_FOUND;
        return new ResponseEntity<>(responseStatus);

    }

    @ExceptionHandler({InvalidFormatException.class})
    @ResponseBody
    public ResponseEntity<HttpStatus> noHandlerFoundException(InvalidFormatException ex) {
        log.error("NoHandlerFound error during processing: {}, {}, {}", ex.getValue(), ex.getCause(), ex.getMessage());
        HttpStatus responseStatus = HttpStatus.NOT_FOUND;

        return new ResponseEntity<>(responseStatus);
    }

    @ExceptionHandler({BureauServiceException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBureauServiceException(BureauServiceException ex) {

        String errorMessage = ex.getMessage();
        log.error("BureauServiceException during processing: {}", errorMessage);
        HttpStatus httpStatus = HttpStatus.valueOf(Integer.parseInt(ex.getStatusCode()));

        return ResponseEntity.status(httpStatus).body(new ErrorResponse(httpStatus, errorMessage));
    }

}
