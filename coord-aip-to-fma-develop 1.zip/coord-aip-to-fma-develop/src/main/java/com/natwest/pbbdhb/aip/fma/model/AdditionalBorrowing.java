
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class AdditionalBorrowing {

    @Valid
    @PositiveOrZero
    @Schema( type = "Integer")
    @Max(value = 9999,message = "allows max 4 digits")
    private Integer termYears;

    @Valid
    @PositiveOrZero
    @Schema( type = "Integer")
    @Max(value = 99,message = "allows max 2 digits")
    private Integer termMonths;

    @Schema( type = "String", allowableValues = "true, false")
    private Boolean repaymentVehicle;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=0,message = "allows max 8 digits")
    @Schema( type = "BigDecimal")
    private BigDecimal repaymentCurrentValue;

    @Schema( type = "String", allowableValues = "true, false")
    private Boolean existMortgBf20Sep2015;

    @Valid
    @Schema()
    private List<Details> details;

    @Valid
    @Schema()
    @Size(max = 5, message = "Maximum 5 sub-accounts are allowed")
    private List<SubAccount> subAccounts;

}
