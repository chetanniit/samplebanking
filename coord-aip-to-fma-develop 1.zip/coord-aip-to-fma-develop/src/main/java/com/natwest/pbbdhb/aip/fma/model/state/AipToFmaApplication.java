package com.natwest.pbbdhb.aip.fma.model.state;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class AipToFmaApplication {

    private String stage;

    private String channel;

    private String caseId;

    private String decision;

    private String decisionUniqueId;

    private Integer numberOfApplicants;

    private String request;

    private String response;
}
