package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "Applicant Object")
public class Applicant {

    @Valid
    @Schema( type = "String")
    @Length(max = 16,message = "allows max 16 characters")
    private String cin;

    @Valid
    @Schema()
    private PersonalDetails personalDetails;

    @Schema()
    @Valid
    private List<@Valid Address> addresses;

    @Schema()
    @Valid
    private BankDetails bankDetails;

    @Schema()
    @Valid
    private Credit credit;

    @Schema()
    @Valid
    private CreditCards creditCards;

    @Schema()
    @Valid
    private Employment employment;

    @Schema()
    @Valid
    private Expenditure expenditure;

    @Schema()
    @Valid
    private ExistingMortgage existingMortgage;
}
