package com.natwest.pbbdhb.aip.fma.model.enums;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public enum Ownership {

    /*SINGLE("S"),
    JOINT("J");
    String key;

    @Override
    public String toString(){
        return key;

    }*/


    APPLICANT_ONE("1", "Applicant One"),
    APPLICANT_TWO("2", "Applicant Two"),
    JOINT("3", "Joint");

    private String key;
    private String value;

    @Override
    public String toString(){
        return key;
    }
}
