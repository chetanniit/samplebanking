package com.natwest.pbbdhb.aip.fma.model.response;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Applicant {

    private String firstNames;

    private String lastName;

    private String kycResult;

    private String cin;

}
