package com.natwest.pbbdhb.aip.fma.service.impl;

import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponseGenerationRequest;
import com.natwest.pbbdhb.aip.fma.service.ResponseService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.applicationHeaders;

@Service
public class ResponseGenerationServiceImpl implements ResponseService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResponseGenerationServiceImpl.class);

    @Value("${response.generation.endpoint}")
    private String responseGenerationEndPoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Override
    public FmaResponse generateFmaResponse(String brand, @Valid RiskResponseGenerationRequest scoringResponse) {
        String lenderCaseId = scoringResponse.getLenderCaseId();
        LOGGER.info("Case id : {}-AF20, generateFmaResponse called", lenderCaseId);
        LOGGER.debug("Case id : {}, scoringCheck_endPointUrl={}, aipScoringRequest={}", lenderCaseId, responseGenerationEndPoint, scoringResponse);

        HttpEntity<RiskResponseGenerationRequest> requestHttpEntity = new HttpEntity<>(scoringResponse, applicationHeaders(brand));
        FmaResponse aipResponse = restTemplate.postForObject(responseGenerationEndPoint, requestHttpEntity, FmaResponse.class);

        LOGGER.debug("Case id : {}, scoreCheck_aipResponse={}", lenderCaseId, aipResponse);
        LOGGER.info("Case id : {}-AF21, generateFmaResponse completed", lenderCaseId);

        return aipResponse;
    }

}
