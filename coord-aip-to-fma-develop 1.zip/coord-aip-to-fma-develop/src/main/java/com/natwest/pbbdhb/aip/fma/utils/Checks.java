package com.natwest.pbbdhb.aip.fma.utils;

import com.natwest.pbbdhb.aip.fma.exception.InvalidRequestException;
import lombok.SneakyThrows;
import org.springframework.http.HttpStatus;

public class Checks {

    private Checks() {
    }

    @SneakyThrows
    public static void errorOutIfTrue(Boolean bool, String message) {
        if (bool) throw new InvalidRequestException(message,HttpStatus.BAD_REQUEST.value());
    }

}
