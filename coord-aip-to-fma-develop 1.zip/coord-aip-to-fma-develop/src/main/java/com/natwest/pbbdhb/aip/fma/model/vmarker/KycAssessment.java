package com.natwest.pbbdhb.aip.fma.model.vmarker;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import lombok.experimental.Accessors;

@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Accessors(chain = true)
public class KycAssessment {

    private Boolean kycVerified;
}
