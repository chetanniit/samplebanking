package com.natwest.pbbdhb.aip.fma.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.cin.search.CustomerSearchRequest;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStep;
import com.natwest.pbbdhb.aip.fma.model.mapper.AipToFmaApplicationStateMapper;
import com.natwest.pbbdhb.aip.fma.model.mapper.AipToFmaResponseMapper;
import com.natwest.pbbdhb.aip.fma.model.mapper.CinKycVerificationMapper;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.response.cin.search.CinKycVerification;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplication;
import com.natwest.pbbdhb.aip.fma.model.state.AipToFmaApplicationState;
import com.natwest.pbbdhb.aip.fma.service.StateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.applicationHeaders;
import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.objectMapperOrganic;

@Service
public class StateServiceImpl implements StateService {

    private static final Logger LOGGER = LoggerFactory.getLogger(StateServiceImpl.class);
    private static final String NO_CIN_FOUND = "{No CIN found for any of the applicant}";

    @Value("${create.application.endpoint}")
    private String createApplicationEndPoint;

    @Value("${create.application.state.endpoint}")
    private String createApplicationStateEndPoint;

    @Value("${update.application.endpoint}")
    private String updateApplicationEndPoint;

    @Value("${retrieve.application.endpoint}")
    private String getApplicationEndPoint;

    @Value("${retrieve.application.state.endpoint}")
    private String getApplicationStateEndPoint;

    @Autowired
    private CinKycVerificationMapper cinKycVerificationMapper;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AipToFmaApplicationStateMapper riskAppStateMapper;

    @Autowired
    private AipToFmaResponseMapper scoreToFmaMapper;

    @Autowired
    private ObjectMapper objectMapper;


    @Override
    public HttpStatus captureApplication(String brand, Application application) throws JsonProcessingException {
        LOGGER.info("Case id : {}-AF4, captureApplication called", application.getLenderCaseId());
        AipToFmaApplication createApplication = riskAppStateMapper.toApplicationRequest(application, objectMapperOrganic.writeValueAsString(application));
        LOGGER.debug("Case id : {}, riskCreateApplication_endPointUrl={}", application.getLenderCaseId(), createApplicationEndPoint);
        HttpEntity<AipToFmaApplication> requestHttpEntity = new HttpEntity<>(createApplication, applicationHeaders(brand));
        return restTemplate.postForObject(createApplicationEndPoint, requestHttpEntity, HttpStatus.class);
    }

    @Override
    public HttpStatus updateApplication(String brand, Application application, FmaResponse fmaResponse, RiskResponse scoringResponse) throws JsonProcessingException {
        LOGGER.info("Case id : {}-AF22, updateApplication called", application.getLenderCaseId());
        if(fmaResponse == null) fmaResponse = scoreToFmaMapper.scoringToFmaResponse(scoringResponse);
        fmaResponse.setDecisionUniqueId(scoringResponse.getDecisionUniqueId());

        AipToFmaApplication applicationToUpdate = AipToFmaApplication.builder()
                .decision(fmaResponse.getDecision())
                .decisionUniqueId(fmaResponse.getDecisionUniqueId())
                .response(objectMapper.writeValueAsString(fmaResponse)).build();

        LOGGER.debug("Case id : {}, riskUpdateApplication_endPointUrl={}, riskUpdateApplicationRequest={}", application.getLenderCaseId(), updateApplicationEndPoint, applicationToUpdate.toString());
        HttpEntity<AipToFmaApplication> requestHttpEntity = new HttpEntity<>(applicationToUpdate, applicationHeaders(brand));

        return restTemplate.patchForObject(updateApplicationEndPoint, requestHttpEntity, HttpStatus.class, application.getLenderCaseId(), ApplicationStage.AIP_TO_FMA);
    }

    @Override
    public HttpStatus captureApplicationState(String brand, Application application, RiskResponse scoreResponse) throws JsonProcessingException {
        LOGGER.info("Case id : {}-AF13, captureApplicationState called", application.getLenderCaseId());
        AipToFmaApplicationState createApplicationState = riskAppStateMapper.toApplicationStateRequest(application, scoreResponse, objectMapper.writeValueAsString(application), objectMapper.writeValueAsString(scoreResponse));
        LOGGER.debug("Case id : {}, applicationState_endPointUrl={}, createApplicationStateRequest={}", application.getLenderCaseId(), createApplicationStateEndPoint, createApplicationState);

        HttpEntity<AipToFmaApplicationState> requestHttpEntity = new HttpEntity<>(createApplicationState, applicationHeaders(brand));
        return restTemplate.postForObject(createApplicationStateEndPoint, requestHttpEntity, HttpStatus.class);
    }

    @Override
    public HttpStatus createApplicationState(String brand, Application aipToFmaRequest, List<CinResponse> applicantsCinResponse) throws JsonProcessingException {
        LOGGER.info("Case id : {}-AF19, captureApplicationState for cin-search called", aipToFmaRequest.getLenderCaseId());
        List<CustomerSearchRequest> cinSearchRequest = aipToFmaRequest.getApplicants().stream()
                .filter(Objects::nonNull)
                .map(applicant -> cinKycVerificationMapper.toCinSearchRequest(applicant))
                .collect(Collectors.toList());

        List<CinKycVerification> cinKycResponse = (!applicantsCinResponse.isEmpty() && applicantsCinResponse.stream().anyMatch(cinResponse ->  !CollectionUtils.isEmpty(cinResponse.getCin()))) ? applicantsCinResponse.stream()
                .map(cinResponse -> cinKycVerificationMapper.toCinKycResponse(cinResponse.getApplicant(), cinResponse.getCin(), cinResponse.getVMarker(), cinResponse.getCinMatchIndicator()))
                .collect(Collectors.toList()) : null;

        AipToFmaApplicationState createCinState = riskAppStateMapper.toCinApplicationState(aipToFmaRequest.getLenderCaseId());
        createCinState.setRequest(!cinSearchRequest.isEmpty() ? objectMapper.writeValueAsString(cinSearchRequest) : null);
        createCinState.setResponse(cinKycResponse !=null ? objectMapper.writeValueAsString(cinKycResponse) : NO_CIN_FOUND);
        LOGGER.debug("Case id : {}, AIP-To-FMA CIN match createState_endPointUrl={}, createApplicationStateRequest={}", aipToFmaRequest.getLenderCaseId(), createApplicationStateEndPoint, createCinState);

        HttpEntity<AipToFmaApplicationState> requestHttpEntity = new HttpEntity<>(createCinState, applicationHeaders(brand));
        return restTemplate.postForObject(createApplicationStateEndPoint, requestHttpEntity, HttpStatus.class);
    }

    @Override
    public HttpStatus captureEkycApplicationState(String brand, EkycApplication ekycApplication, RiskResponse ekycResponse) throws JsonProcessingException {
        LOGGER.info("Case id : {}-AF18, captureEkycApplicationState called", ekycApplication.getLenderCaseId());
        AipToFmaApplicationState createApplicationState = riskAppStateMapper.toEkycApplicationStateRequest(ekycApplication, ekycResponse, objectMapper.writeValueAsString(ekycApplication), objectMapper.writeValueAsString(ekycResponse));
        LOGGER.debug("Case id : {}, applicationState_endPointUrl={}, createApplicationStateRequest={}", ekycApplication.getLenderCaseId(), createApplicationStateEndPoint, createApplicationState);

        HttpEntity<AipToFmaApplicationState> requestHttpEntity = new HttpEntity<>(createApplicationState, applicationHeaders(brand));
        return restTemplate.postForObject(createApplicationStateEndPoint, requestHttpEntity, HttpStatus.class);
    }

    @Override
    public AipToFmaApplication retrieveApplication(String brand, String lenderCaseId, ApplicationStage stage) {
        LOGGER.info("Case id : {}-AF3, retrieveApplication called for stage: {}", lenderCaseId, stage.name());

        return restTemplate.exchange(getApplicationEndPoint, HttpMethod.GET,
                new HttpEntity(applicationHeaders(brand)), AipToFmaApplication.class, stage, lenderCaseId).getBody();
    }

    @Override
    public AipToFmaApplicationState retrieveApplicationState(String brand, String lenderCaseId, ApplicationStage stage, ApplicationStep step) {
        LOGGER.info("Case id : {}-AF3.1, retrieveApplication state called for stage: {}, step: {}", lenderCaseId, stage.name(), step.name());

        return restTemplate.exchange(getApplicationStateEndPoint, HttpMethod.GET,
                new HttpEntity(applicationHeaders(brand)), AipToFmaApplicationState.class, stage, step, lenderCaseId).getBody();
    }

}
