package com.natwest.pbbdhb.aip.fma.model.casemgmt;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.Date;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Case {

    private String caseId;

    private String clientId;

    private String source;

    private CaseType caseType;

    private Set<CaseStatus> caseStatusSet;

    private Date creationDate;

}
