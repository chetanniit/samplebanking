package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "BankDetails Object")
public class BankDetails {

    @Valid
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @Schema(type = "LocalDate",example = "\"20210131\"")
    private LocalDate dateOpened;

    @Valid
    @Schema()
    @Length(max = 30,message = "allows max 30 characters")
    private String bankName;

    @Valid
    @Schema()
    @Length(max = 8,message = "allows max 8 characters")
    private String sortCode;

    @Valid
    @Schema()
    @Length(max = 10,message = "allows max 10 characters")
    private String accountNumber;

    @Schema( allowableValues = "true, false")
    private Boolean chequeCard;
}
