package com.natwest.pbbdhb.aip.fma.model.casemgmt;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CaseType {

    private Long id;

    private String type;

}
