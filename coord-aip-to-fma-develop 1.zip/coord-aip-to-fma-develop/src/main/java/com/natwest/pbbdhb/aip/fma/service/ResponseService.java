package com.natwest.pbbdhb.aip.fma.service;

import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponseGenerationRequest;
import jakarta.validation.Valid;

public interface ResponseService {

    FmaResponse generateFmaResponse(String brand, @Valid RiskResponseGenerationRequest request);

}
