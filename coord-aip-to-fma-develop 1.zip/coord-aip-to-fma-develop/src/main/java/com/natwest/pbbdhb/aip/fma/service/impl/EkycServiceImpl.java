package com.natwest.pbbdhb.aip.fma.service.impl;

import com.natwest.pbbdhb.aip.fma.model.cin.search.CinResponse;
import com.natwest.pbbdhb.aip.fma.model.ekyc.EkycApplication;
import com.natwest.pbbdhb.aip.fma.model.response.RiskResponse;
import com.natwest.pbbdhb.aip.fma.model.vmarker.KycAssessment;
import com.natwest.pbbdhb.aip.fma.service.EkycService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Objects;

import static com.natwest.pbbdhb.aip.fma.utils.AppUtil.applicationHeaders;
import static java.util.Objects.nonNull;

@Service
public class EkycServiceImpl implements EkycService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EkycServiceImpl.class);

    @Value("${es.ekyc.endpoint}")
    private String ekycEndPoint;

    @Value("${verify.ekyc.endpoint}")
    private String ekycVerificationEndpoint;

    @Autowired
    @Qualifier("restTemplateForTykApi")
    private RestTemplate restTemplate;

    @Autowired
    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Override
    public RiskResponse kycCheck(@Valid EkycApplication application) {
        String lenderCaseId = application.getLenderCaseId();
        LOGGER.info("Case id : {}-AF16, kycCheck called", lenderCaseId);

        removeCinsForApplicants(application);
        restTemplate.getMessageConverters().add(0, mappingJackson2HttpMessageConverter);
        RiskResponse  ekycResponse = restTemplate.postForObject(ekycEndPoint, application, RiskResponse.class);
        LOGGER.info("Case id : {}-AF17, kycCheck completed", lenderCaseId);

        return ekycResponse;
    }

    @Override
    public boolean verifyKyc(final String brand, final List<CinResponse> applicantsCinResponse, final String lenderCaseId) {
        LOGGER.info("Case id : {}, verifyKyc called", lenderCaseId);

        //Check CIN is verified for all the applicants with UK address
        boolean ukApplicantsCinNotVerified = applicantsCinResponse.stream()
                .filter(CinResponse::isUkAddress)
                .anyMatch(cinResponse -> CollectionUtils.isEmpty(cinResponse.getCin()));

        //Verify KYC when all applicants CIN is verified
        return (!applicantsCinResponse.isEmpty() && !ukApplicantsCinNotVerified)
                ? !applicantsCinResponse.stream()
                .allMatch(cinResponse -> verifyKycForApplicant(brand, cinResponse, lenderCaseId))
                : Boolean.TRUE;
    }

    private boolean verifyKycForApplicant(final String brand, final CinResponse cinResponse, final String lenderCaseId) {

        boolean customerVerified = false;

        if(!cinResponse.getCin().isEmpty()) {
            customerVerified = isCustomerVerified(cinResponse, brand, lenderCaseId);
        }

        //For non-uk applicants - V-marker should happen and always return true to avoid external EKYC call
        return customerVerified || !cinResponse.isUkAddress();
    }

    private boolean isCustomerVerified(final CinResponse cinResponse, final String brand, final String lenderCaseId) {
        String cin = cinResponse.getCin().get(0);
        LOGGER.info("Case id : {}, isCustomerVerified called for cin : {}", lenderCaseId, cin);
        HttpHeaders headers = applicationHeaders(brand);
        KycAssessment response;

        try {
            ResponseEntity<KycAssessment> responseEntity = restTemplate.exchange(ekycVerificationEndpoint, HttpMethod.GET, new HttpEntity<>(headers), KycAssessment.class, cin);
            response =  responseEntity.getBody();
        }
        catch (Exception ex) {
            LOGGER.error("Case id : {}, Exception occurred while calling V-Marker API : {}", lenderCaseId, ex.getMessage());
            response = KycAssessment.builder().kycVerified(false).build();
        }

        cinResponse.setVMarker(nonNull(response) ? response.getKycVerified() : false);
        LOGGER.info("Case id : {}, isCustomerVerified completed", lenderCaseId);

        return cinResponse.getVMarker();
    }

    private void removeCinsForApplicants(EkycApplication eKycppAlication) {
        eKycppAlication.getApplicants().stream()
                .forEach(applicant -> {
                    if(Objects.nonNull(applicant.getCin()))applicant.setCin(null);
                });
    }

}