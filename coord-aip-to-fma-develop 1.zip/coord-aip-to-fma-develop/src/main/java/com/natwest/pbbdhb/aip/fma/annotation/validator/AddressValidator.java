package com.natwest.pbbdhb.aip.fma.annotation.validator;

import com.natwest.pbbdhb.aip.fma.annotation.ValidAddress;
import com.natwest.pbbdhb.aip.fma.model.Address;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import static org.apache.commons.lang.StringUtils.isNotBlank;

public class AddressValidator implements ConstraintValidator<ValidAddress, Address> {

    @Override
    public boolean isValid(Address address, ConstraintValidatorContext constraintValidatorContext) {
        return isNotBlank(address.getFlat())||isNotBlank(address.getHouseName())||isNotBlank(address.getHouseNumber());
    }
}
