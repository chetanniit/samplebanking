
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.aip.fma.model.enums.Gender;
import com.natwest.pbbdhb.aip.fma.model.enums.MaritalStatus;
import com.natwest.pbbdhb.aip.fma.model.enums.Nationality;
import com.natwest.pbbdhb.aip.fma.model.enums.Title;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "PersonalDetails Object")
public class PersonalDetails {

    @Valid
    @Schema()
    @Length(min = 2, max = 30,message = "allows minimum 2 and maximum 50 characters")
    private String lastName;

    @Valid
    @Schema()
    @Length(min = 1, max = 15, message = "allows minimum 1 and maximum 15 characters")
    private String firstNames;

    @Valid
    @Schema(type = "String",example = "\"20210131\"")
    @JsonFormat(pattern = "yyyyMMdd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate dateOfBirth;

    @Valid
    @Schema()
    @Length(max = 1,message = "allows max 1 character")
    private String secondInitial;

    @Valid
    @Schema()
    private Title title;

    @Schema(allowableValues = "UNITED_KINGDOM,NON_EU,OTHER")
    private Nationality nationality;

    @Schema( allowableValues = "true, false")
    private Boolean rightToReside;

    @Schema(allowableValues = "MALE,FEMALE")
    private Gender gender;

    @Schema(allowableValues = "MARRIED,DIVORCED,SEPARATED,SINGLE,ENGAGED,WIDOWED,LIVING_WITH_PARTNER")
    private MaritalStatus maritalStatus;

    @Valid
    @Schema()
    @Length(max = 25,message = "allows max 25 digits")
    private String privateTelephoneNumber;

    @Valid
    @Schema()
    @Length(max = 25,message = "allows max 25 digits")
    private String workTelephoneNumber;

    @Valid
    @Schema()
    @Length(max = 25,message = "allows max 25 digits")
    private String mobileNumber;

    @Valid
    @Schema()
    private String numberOfDependants;

}
