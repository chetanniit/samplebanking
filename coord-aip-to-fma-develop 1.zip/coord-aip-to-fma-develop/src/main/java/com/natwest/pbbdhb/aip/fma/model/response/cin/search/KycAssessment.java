package com.natwest.pbbdhb.aip.fma.model.response.cin.search;

import lombok.*;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Accessors(chain = true)
public class KycAssessment {

    private LocalDateTime assessmentDateTime;

    private Boolean kycVerified;
}
