package com.natwest.pbbdhb.aip.fma.model.ekyc;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Schema(description = "Applicant Object")
public class Applicant {

    private String cin;

    private PersonalDetails personalDetails;

    private List<Address> addresses;

}
