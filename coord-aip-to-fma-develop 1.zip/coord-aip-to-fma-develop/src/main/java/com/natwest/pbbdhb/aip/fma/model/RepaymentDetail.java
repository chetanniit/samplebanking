
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.aip.fma.model.enums.RepaymentStrategyType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class RepaymentDetail {

    @Schema(allowableValues = "MAIN_RESIDENCE,NOT_MAIN_RESIDENCE,OTHER_MORTGAGE_PROPERTY,UNENCUMBERED_MAIN_RESIDENCE,\n" +
            "UNENCUMBERED_OTHER_TERRACED,STOCK_SHARES,UNIT_TRUSTS,OEIC,ICVC,PENSION,SAVING,OTHER_ASSETS,ENDOWMENT")
    private RepaymentStrategyType repaymentStrategyType;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=2, message = "allows max decimal(10,2)")
    @Schema(type = "BigDecimal")
    private BigDecimal repaymentValue;

    @Valid
    @PositiveOrZero
    @Digits(integer = 8,fraction=2, message = "allows max decimal(10,2)")
    @Schema(type = "BigDecimal")
    private BigDecimal repaymentMortgageAmount;

}
