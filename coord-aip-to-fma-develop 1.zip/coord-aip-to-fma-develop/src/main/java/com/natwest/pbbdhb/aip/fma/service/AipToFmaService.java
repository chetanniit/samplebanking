package com.natwest.pbbdhb.aip.fma.service;

import com.natwest.pbbdhb.aip.fma.exception.BureauServiceException;
import com.natwest.pbbdhb.aip.fma.model.Application;
import com.natwest.pbbdhb.aip.fma.model.enums.Client;
import com.natwest.pbbdhb.aip.fma.model.response.FmaResponse;

import jakarta.validation.Valid;
import java.io.IOException;

public interface AipToFmaService {

    FmaResponse processApplication(String brand, String clientId, @Valid Application application) throws IOException, BureauServiceException;

    Client validateClientIsOnBoardedAndGetClient(String clientId, String brand);

}
