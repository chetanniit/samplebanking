
package com.natwest.pbbdhb.aip.fma.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.aip.fma.model.enums.ApplicationStage;
import com.natwest.pbbdhb.aip.fma.model.enums.Brand;
import com.natwest.pbbdhb.aip.fma.model.enums.DataFeed;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class FormInfo {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private ApplicationStage applicationStage = ApplicationStage.FMA;

    @Schema( type = "String",allowableValues = "MBL,FOCUS,ADBO")
    private DataFeed dataFeed;

    @Schema( type = "String",allowableValues = "RBS,NATWEST")
    private Brand brand;

    @Schema( type = "String")
    @Length(max = 7,message = "allows max 7 characters")
    @Valid
    private String formType;

}
