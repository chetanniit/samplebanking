package com.natwest.pbbdhb.aip.fma.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum KycResult {

    TRUE("V"),
    FALSE("N");

    private final String value;

    public String getValue ( ) {
        return this.value;
    }

    @Override
    public String toString(){
        return value;
    }

}
