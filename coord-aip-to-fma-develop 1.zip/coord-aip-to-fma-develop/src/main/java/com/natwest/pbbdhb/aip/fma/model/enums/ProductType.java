package com.natwest.pbbdhb.aip.fma.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ProductType {

    TWO_YEARS("T", "Two Years"),
    FIVE_YEARS("F", "Five Years");

    private final String key;

    private final String value;

    @Override
    public String toString(){
        return key;
    }

    public String value() {
        return value;
    }
}
