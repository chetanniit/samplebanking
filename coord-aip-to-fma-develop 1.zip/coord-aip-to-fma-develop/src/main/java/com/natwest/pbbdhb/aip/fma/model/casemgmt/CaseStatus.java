package com.natwest.pbbdhb.aip.fma.model.casemgmt;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CaseStatus {

    private String caseId;

    private Long decisionId;

    private Long decisionReasonId;

    private Date creationDate;

    private Decision decision;

    private DecisionReason decisionReason;

}
