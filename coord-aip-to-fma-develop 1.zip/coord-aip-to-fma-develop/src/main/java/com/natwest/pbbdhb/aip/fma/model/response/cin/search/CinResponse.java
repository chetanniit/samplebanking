package com.natwest.pbbdhb.aip.fma.model.response.cin.search;

import com.natwest.pbbdhb.aip.fma.model.Applicant;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CinResponse {

    private Applicant applicant;

    private List<String> cin;

    private Boolean vMarker;

    private String cinMatchIndicator;
}
