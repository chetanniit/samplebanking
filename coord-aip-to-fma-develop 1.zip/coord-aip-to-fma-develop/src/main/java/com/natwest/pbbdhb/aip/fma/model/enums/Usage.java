package com.natwest.pbbdhb.aip.fma.model.enums;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Usage {

    /*HELD_RBSG("1", "Mortgaged - Held with RBSG"),
    HELD_ELSEWHERE("2", "Mortgaged – Held Elsewhere"),
    UNENCUMBERED("3", "Unencumbered");*/

    RESIDENTIAL("1","Residential"),
    CONSENT_TO_LET("2","Consent to Let"),
    BUY_TO_LET("3","Buy To Let");
    private String key;
    private String value;

    @Override
    public String toString(){
        return key;
    }
}
