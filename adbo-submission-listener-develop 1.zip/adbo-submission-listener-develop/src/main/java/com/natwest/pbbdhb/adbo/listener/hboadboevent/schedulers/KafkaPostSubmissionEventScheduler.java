package com.natwest.pbbdhb.adbo.listener.hboadboevent.schedulers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums.RetryStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.GetApplicationsResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ADBOSubmissionResult;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ApplicationStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ApplicationType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.service.KafkaProducerService;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.service.StateApplicationService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.DefaultLockingTaskExecutor;
import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.LockingTaskExecutor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;

import java.time.Duration;
import java.time.Instant;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@ConditionalOnProperty(prefix = "application.config.kafka.publisher.scheduler", name = "enabled", havingValue = "true")
@Component
@Slf4j
public class KafkaPostSubmissionEventScheduler {
    private static final int PT5M = 5;
    private static final int PT10M = 10;
    private static final String BRANDS_DELIMITER = ",";
    private static final String LOCK_NAME = "%s_EXT_PUBLISH";

    @Value("${application.config.brand.names}")
    private String brands;

    @Autowired
    @Qualifier("multiBrandLockProvider")
    private LockProvider multiBrandLockProvider;

    @Autowired
    private StateApplicationService stateService;

    @Autowired
    private KafkaProducerService kafkaProducerService;


    private final ObjectMapper objectMapper = new ObjectMapper();

    private final Runnable task;

    public KafkaPostSubmissionEventScheduler() {
        this.task = initTask();
    }

    @Scheduled(fixedRateString = "${application.config.kafka.publisher.scheduler.poller-interval}",
            initialDelayString = "${application.config.kafka.publisher.scheduler.poller-initial-delay}")
    public void publish() {
        if (StringUtils.isBlank(brands)) {
            log.info("Publish(Kafka/MOPS): No brands configured, exiting from scheduler");
            return;
        }

        Arrays.stream(brands.split(BRANDS_DELIMITER)).forEach(brand -> {
            try {

                log.info("Publish(Kafka/MOPS): Set brand to Thread Local ContextHolder");
                BrandContextHolder.setCurrentBrand(brand);
                LockingTaskExecutor executor = new DefaultLockingTaskExecutor(multiBrandLockProvider);
                executor.executeWithLock(task, new LockConfiguration(Instant.now(),
                        String.format(LOCK_NAME, ApplicationType.ADDITIONAL_BORROWING),
                        Duration.ofMinutes(PT10M), Duration.ofMinutes(PT5M)));
            } finally {
                log.info("Publish(Kafka/MOPS): Clearing brand from Thread Local ContextHolder");
                BrandContextHolder.clear();
            }
        });
    }

    private Runnable initTask() {
        return () -> {
            final String brand = BrandContextHolder.getCurrentBrand();

            Arrays.asList(RetryStatus.NULL, RetryStatus.SUCCESSFUL, RetryStatus.FAILED, RetryStatus.MANUAL)
                    .forEach(rs -> {
                        try {
                            log.info(
                                    "Publish(Kafka/MOPS): Retrieving applications with RetryStatus={}, isKafkaSent={}, "
                                            + "isApplicationSentToMops={} and brand={}",
                                    rs, Boolean.FALSE, null, brand);
                            GetApplicationsResponse applicationsResponse =
                                    stateService.retrieveApplications(rs, null, Boolean.FALSE, null,
                                            null, brand);
                            if (!CollectionUtils.isEmpty(applicationsResponse.getData())) {
                                final Map<String, Object> headers =
                                        Stream.of(new AbstractMap.SimpleEntry<>(WorkflowExecutionConstants.BRAND_HEADER,
                                                        brand))
                                                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                                applicationsResponse.getData().stream()
                                        .map(app -> stateService.retrieveApplication(brand, app.getFlowId()))
                                        .filter(app -> Objects.nonNull(app) && Objects.nonNull(app.getResponse()))
                                        .map(applicationResponse -> {
                                            try {
                                                log.info("Retrieve application={}", applicationResponse.getFlowId());
                                                return objectMapper.readValue(applicationResponse.getResponse(),
                                                        ADBOSubmissionResult.class);
                                            } catch (JsonProcessingException e) {
                                                log.error(
                                                        "{} Publish(Kafka/MOPS): Scheduler failed for RetryStatus={} "
                                                                + "and brand={} with error=",
                                                        ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, rs,
                                                        brand, e);
                                                return null;
                                            }
                                        }).filter(app -> Objects.nonNull(app) && Objects.nonNull(app.getCaseId()))
                                        .forEach(adboSubmissionResult -> {

                                            if (rs == RetryStatus.MANUAL) {
                                                adboSubmissionResult.setStatus(
                                                        ApplicationStatus.MANUAL_KEY_IN_SUCCESSFUL);
                                            }
                                            adboSubmissionResult.setBrand(brand);
                                            kafkaProducerService.send(adboSubmissionResult.getCaseId(),
                                                    adboSubmissionResult);
                                        });
                            }
                        } catch (HttpClientErrorException.NotFound e) {
                            log.warn(
                                    "Publish(Kafka/MOPS): "
                                            + "No records found by scheduler for RetryStatus={} and brand={}",
                                    rs, brand);
                        } catch (RuntimeException ex) {
                            log.error(
                                    "{} Publish(Kafka/MOPS):"
                                            + " Scheduler failed for RetryStatus={} and brand={} with error=",
                                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, rs,
                                    brand, ex);
                        }
                    });
        };
    }
}


