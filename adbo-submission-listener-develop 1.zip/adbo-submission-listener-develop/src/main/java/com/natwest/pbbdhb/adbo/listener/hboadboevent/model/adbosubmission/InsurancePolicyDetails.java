package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePolicyDetails {
    private String policyType;
    private String insCompanyCode;
    private String insCompanyName;
    private String policyReference;
    private LocalDate policyStartDate;
    private String premiumCollFrequency;
    private BigDecimal sumInsured;
    private BigDecimal premiumAmount;
    private PaymentProtectionDetails paymentProtectionDetails;
}
