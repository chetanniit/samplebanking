package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ADBOSubmitRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer.CoreCustomerContact;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer.CoreCustomerDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer.UpdateCoreCustomerRequest;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.PersonalDetails;
import com.natwest.pbbdhb.openapi.Telephone;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils.getApplicant;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class UpdateCoreCustomerRequestMapper
        implements WorkflowMapper<WorkflowContext, UpdateCoreCustomerRequest> {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    @SuppressWarnings("checkstyle:visibilitymodifier")
    int updateCoreCustomerRoutingIndex = ADBOSubmitRoutingSlip.UPDATE_CORE_CUSTOMER.getIndex();

    @Override
    public UpdateCoreCustomerRequest map(WorkflowContext source) {
        return mapToUpdateCustomerRequest(getApplicant(source, updateCoreCustomerRoutingIndex));
    }

    @Mapping(target = "cin", source = "cin")
    @Mapping(target = "customerContactDetails", source = "applicant", qualifiedByName = "mapCoreCustomerContact")
    @Mapping(target = "customerDetails", source = "applicant", qualifiedByName = "mapCoreCustomerDetails")
    abstract UpdateCoreCustomerRequest mapToUpdateCustomerRequest(Applicant applicant);

    @Named("mapCoreCustomerDetails")
    @Mapping(target = "primaryNationalityRegistration", expression = "java(com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.Country.valueOf(applicant.getPersonalDetails().getNationality()))")
    abstract CoreCustomerDetails mapCoreCustomerContact(Applicant applicant);

    @Named("mapCoreCustomerContact")
    @Mapping(target = "residencePhoneNumber", ignore = true)
    @Mapping(target = "mobileNumber",
            expression = "java(getContact(applicant.getPersonalDetails().getTelephones(),com.natwest.pbbdhb.openapi"
                    + ".Telephone.TypeEnum.MOBILE))")
    @Mapping(target = "businessPhoneNumber", ignore = true)
    @Mapping(target = "email", source = "personalDetails.email")
    @Mapping(target = "preferredTelephoneType", ignore = true)
    @Mapping(target = "requestContentType",
            expression = "java(com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ContactPreferenceRequestType"
                    + ".PERSONALCUSTOMERPREFERENCES)")
    @Mapping(target = "allowedMediums", ignore = true)
    @Mapping(target = "disallowedMediums", ignore = true)
    abstract CoreCustomerContact mapCoreCustomerDetails(Applicant applicant);

    String getContact(Set<Telephone> telephones, Telephone.TypeEnum type) {
        return telephones.stream().filter(val -> val.getType() == type).findFirst()
                .map(telephone -> telephone.getNumber()).orElse(null);
    }


}
