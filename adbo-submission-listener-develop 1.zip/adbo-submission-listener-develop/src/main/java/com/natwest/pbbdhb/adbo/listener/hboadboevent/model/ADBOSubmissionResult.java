package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.LoanPurpose;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.Error;
import com.natwest.pbbdhb.openapi.HardscoreDecision;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ADBOSubmissionResult {
    private String mortgageRefNo;
    private String mortgageApplSeq;
    private String caseId;
    private String uiId;
    private String tempRefNo;
    private String brand;
    private ApplicationStatus status;
    private String userId;
    private String channel;
    private Application.ApplicationTypeEnum applicationType;
    private LoanPurpose loanPurpose;
    private Application application;
    private String submitDateTime;
    private HardscoreDecision hardscoreDecision;
    private List<Error> errors;
}
