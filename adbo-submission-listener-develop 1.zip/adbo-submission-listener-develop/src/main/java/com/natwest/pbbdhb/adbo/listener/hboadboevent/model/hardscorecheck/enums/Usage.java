package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum Usage {
    RESIDENTIAL,
    CONSENT_TO_LET,
    BUY_TO_LET
}
