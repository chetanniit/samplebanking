package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.Gender;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.MaritalStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.Title;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PersonalDetails {
    private Title title;
    private String otherTitle;
    private String firstNames;
    private String middleNames;
    private String lastName;
    private Gender gender;
    private LocalDate dateOfBirth;
    private MaritalStatus maritalStatus;
    private String nationality;
    private Boolean rightToReside;
    private String countryOfResidenceIsoCode;
    private List<Telephone> telephones;
    private String email;
}
