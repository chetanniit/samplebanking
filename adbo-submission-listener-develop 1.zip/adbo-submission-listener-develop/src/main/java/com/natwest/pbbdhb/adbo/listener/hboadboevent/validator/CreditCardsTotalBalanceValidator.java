package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CreditCardsTotalBalanceConstraint;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.CreditCard;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class CreditCardsTotalBalanceValidator
        implements ConstraintValidator<CreditCardsTotalBalanceConstraint, Applicant> {
    @Override
    public boolean isValid(Applicant applicant, ConstraintValidatorContext constraintValidatorContext) {

        final int maxAmount = 99999999;

        return isNull(applicant) || isNull(applicant.getCreditCards()) || BigDecimal.valueOf(maxAmount).compareTo(
                applicant.getCreditCards().stream().filter(val -> nonNull(val.getTotalBalance()))
                        .map(CreditCard::getTotalBalance).reduce(BigDecimal.ZERO, BigDecimal::add)) >= 0;
    }
}
