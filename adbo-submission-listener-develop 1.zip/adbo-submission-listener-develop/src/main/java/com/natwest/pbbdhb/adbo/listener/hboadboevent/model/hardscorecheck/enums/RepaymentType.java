package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum RepaymentType {
    REPAYMENT, INTEREST_ONLY, MIXED
}
