package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.enums.YesOrNo;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ADBOSubmitRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.IncomeConversionFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.IncomeType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.Dependant;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerBankAccount;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerCoreDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerEmployed;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerExpenditure;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerFailedToMakePaymentsDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerIncome;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerIncomeDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerIncomeWithUnderwritingPercent;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerOccupancyDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerPreviousOccupancyDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerRecipientDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerSelfEmployed;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update.UpdateCustomerSupplementaryDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import com.natwest.pbbdhb.openapi.Address;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.BankDetails;
import com.natwest.pbbdhb.openapi.CreditCard;
import com.natwest.pbbdhb.openapi.Employment;
import com.natwest.pbbdhb.openapi.FinancialCommitment;
import com.natwest.pbbdhb.openapi.Income;
import com.natwest.pbbdhb.openapi.Loan;
import com.natwest.pbbdhb.openapi.OtherIncome;
import com.natwest.pbbdhb.openapi.PersonalDetails;
import com.natwest.pbbdhb.openapi.SelfEmployed;
import com.natwest.pbbdhb.openapi.UnstructuredAddress;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.ValueMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.google.common.collect.Lists.newArrayList;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_FORMAT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils.getApplicant;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.NumberUtils.roundDown;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.ADOPTION_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.ATTENDANCE_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.CHILD_BENEFIT;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.CHILD_WORKING_TAX_CREDIT;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.CONSTANT_ATTENDANCE_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.EMPLOYMENT_AND_SUPPORT_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.FOSTER_CARERS_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.GUARDIANS_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.MAINTENANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.PENSION_CREDIT;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.REDUCED_EARNINGS_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.RENTAL_INCOME;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.WIDOWED_PARENT_ALLOWANCE;
import static com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum.WORKING_FAMILIES_TAX_CREDIT;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.Optional.ofNullable;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class UpdateGMSCustomerRequestMapper
        implements WorkflowMapper<WorkflowContext, UpdateCustomerRequest>, SharedCustomerMapper {

    protected static final String DEPENDANT_RELATIONSHIP = "00C";
    protected static final String CHILD = "Child";
    protected static final String ADULT = "Adult";
    protected static final int OVER18_AGE = 18;
    protected static final String CURRENT_EMPLOYMENT = "C";
    protected static final String UNKNOWN = "Unknown";

    @SuppressWarnings("checkstyle:visibilitymodifier")
    int updateGmsCustomerRoutingIndex = ADBOSubmitRoutingSlip.UPDATE_GMS_CUSTOMER.getIndex();

    @Value("${adbo.address-line.max-length:30}")
    @SuppressWarnings("checkstyle:visibilitymodifier")
    int addressLineMaxLength;

    @Value("${adbo.customer-type:P}")
    @Setter
    @Getter
    private String customerType;

    @Value("${adbo.income-frequency:A}")
    private String incomeFrequency;

    @Value("${adbo.net-income-frequency:M}")
    private String netIncomeFrequency;

    @Value("${adbo.expenditure-frequency:M}")
    private String expenditureFrequency;

    @Value("${adbo.other-self-employed-income-type:OTS}")
    private String otherSelfEmployedIncomeType;

    @Value("${adbo.basic-self-employed-income-type:BAS}")
    private String basicSelfEmployedIncomeType;

    @Value("${adbo.un-employed.employer-name:Not Working}")
    private String unEmployedEmployerName;

    @Value("${adbo.un-employed.address1:Not Working}")
    private String unEmployedAddress1;

    @Value("${adbo.un-employed.address2:Not Working}")
    private String unEmployedAddress2;

    @Value("${adbo.un-employed.employer-name:Retired}")
    private String retiredEmployerName;

    @Value("${adbo.un-employed.address1:Retired}")
    private String retiredAddress1;

    @Value("${adbo.un-employed.address2:Retired}")
    private String retiredAddress2;

    @Value("${adbo.un-employed.address2:UK}")
    private String unEmployedAddressCountry;

    @Value("${adbo.un-employed.start-date.prior-months:6}")
    private int unEmployedStartDatePriorMonths;

    @Value("${adbo.un-employed.income-details.amount:1}")
    private BigDecimal unEmployedIncomeAmount;

    @Value("${adbo.un-employed.income-details.frequency:A}")
    private String unEmployedIncomeFrequency;

    @Value("${adbo.un-employed.income-details.net-amount:1}")
    private BigDecimal unEmployedIncomeNetAmount;

    @Value("${adbo.un-employed.income-details.frequency:M}")
    private String unEmployedIncomeNetFrequency;

    @Autowired
    private PropertiesConfig config;

    public UpdateCustomerRequest map(WorkflowContext source) {
        Application application = (Application) source.getOriginalPayload();
        return mapToGMSUpdateCustomerRequest(getApplicant(source, updateGmsCustomerRoutingIndex),
                config.getXoUserid(), source);
    }

    @Mappings({@Mapping(target = "userId", source = "userId"),
            @Mapping(target = "externalRefId", source = "applicant.cin"),
            @Mapping(target = "coreDetails", source = "applicant.personalDetails"),
            @Mapping(target = "supplementaryDetails", source = "applicant"),
            @Mapping(target = "previousOccupancyDetails", source = "applicant.addresses",
                    qualifiedByName = "toGMSPreviousOccupancy"),
            @Mapping(target = "currentOccupancyDetails", source = "applicant.currentUnstructuredAddress",
                    qualifiedByName = "toGMSCurrentOccupancy"),
            @Mapping(target = "creditDeclarations.bankruptcyDetails.answer",
                    source = "applicant.creditHistory.bankrupt", qualifiedByName = "toGMSYesOrNo"),
            @Mapping(target = "creditDeclarations.bankruptcyDetails.note",
                    source = "applicant.creditHistory.bankruptDetails"),
            @Mapping(target = "creditDeclarations.ccjDetails.answer",
                    source = "applicant.creditHistory.courtProceedings", qualifiedByName = "toGMSYesOrNo"),
            @Mapping(target = "creditDeclarations.ccjDetails.note",
                    source = "applicant.creditHistory.courtProceedingDetails"),
            @Mapping(target = "creditDeclarations.failedToMakePaymentsDetails", source = "applicant",
                    qualifiedByName = "mapFailedToMakePaymentDetails"),
            @Mapping(target = "employmentDetails.employed",
                    expression = "java(" + "isNotEmployed(applicant) ? "
                            + "toGMSNotEmployedEmploymentDetails(applicant) : toGMSEmploymentDetails(" + "applicant, "
                            +
                            "com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils.getNetMonthlyIncome"
                            + "(applicant, " + "workflowContext)))"),
            @Mapping(target = "employmentDetails.selfEmployed",
                    expression = "java(toGMSSelfEmploymentDetails(" + "applicant, "
                            +
                            "com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils.getNetMonthlyIncome"
                            + "(applicant, " + "workflowContext)))"),

            @Mapping(target = "otherIncomeDetails.income", source = "applicant", qualifiedByName = "toGMSOtherIncomes"),
            @Mapping(target = "expenditureDetails.expenditure", source = "applicant",
                    qualifiedByName = "toGMSExpenditures"),
            @Mapping(target = "bankAccountDetails.bankAccount", source = "applicant.mainBankDetails",
                    qualifiedByName = "toGMSBankDetails"),
            @Mapping(target = "dependants.dependant", expression = "java(toGMSDependants(workflowContext))")})
    abstract UpdateCustomerRequest mapToGMSUpdateCustomerRequest(Applicant applicant, String userId,
                                                                 @Context WorkflowContext workflowContext);

    //TODO - mailIndicator is not available in adbo payload
    @Mapping(target = "customerType", expression = "java(getCustomerType())")
    @Mapping(target = "title", source = "personalDetails.title")
    @Mapping(target = "surname", source = "personalDetails.lastName")
    @Mapping(target = "foreNames", source = "personalDetails", qualifiedByName = "mapToForeNames")
    @Mapping(target = "nationality", source = "personalDetails", qualifiedByName = "mapToNationality")
    @Mapping(target = "gender", source = "personalDetails.gender")
    @Mapping(target = "dateOfBirth", source = "personalDetails.dateOfBirth", dateFormat = STANDARD_DATE_FORMAT)
    @Mapping(target = "maritalStatus", source = "personalDetails.maritalStatus")
    @Mapping(target = "homeTelephone", source = "personalDetails.telephones", qualifiedByName = "telephoneListToHome")
    @Mapping(target = "workTelephone", source = "personalDetails.telephones", qualifiedByName = "telephoneListToWork")
    @Mapping(target = "mobilePhoneNumber", source = "personalDetails.telephones",
            qualifiedByName = "telephoneListToMobile")
    @Mapping(target = "emailAddress", source = "personalDetails.email")
    abstract UpdateCustomerCoreDetails mapToUpdateCustomerCoreDetails(PersonalDetails personalDetails);


    @Mapping(target = "faxNumber", source = "personalDetails.telephones", qualifiedByName = "telephoneListToFax")
    @Mapping(target = "countryOfResidence", source = "personalDetails", qualifiedByName = "mapToCountryOfResidence")
    @Mapping(target = "numberOfDependants", expression = "java(toGMSNumberOfDependants(workflowContext))")
    @Mapping(target = "kycChannel", source = "kycChannel")
    abstract UpdateCustomerSupplementaryDetails mapToUpdateCustomerSupplementaryDetails(Applicant source, @Context
            WorkflowContext workflowContext);

    @Named("toGMSPreviousOccupancy")
    UpdateCustomerPreviousOccupancyDetails toGMSPreviousOccupancy(Set<Address> addresses) {
        UpdateCustomerPreviousOccupancyDetails updateCustomerPreviousOccupancyDetails =
                UpdateCustomerPreviousOccupancyDetails.builder().occupancy(nonNull(addresses)
                        ? toPreviousAddresses(addresses).stream().map(this::mapToGMSCustomerPreviousOccupancyDetails)
                                .collect(Collectors.toList()) : null).build();
        //Set previous addresses in descending order
        if (CollectionUtils.isNotEmpty(updateCustomerPreviousOccupancyDetails.getOccupancy())) {
            Collections.sort(updateCustomerPreviousOccupancyDetails.getOccupancy(),
                    (o1, o2) -> o2.getAddressEntryDate().compareTo(o1.getAddressEntryDate()));
        }
        return updateCustomerPreviousOccupancyDetails;
    }

    @Mapping(target = "clientAddress", source = "gmsAddress", qualifiedByName = "clientGmsAddress")
    @Mapping(target = "yearsAtAddress", source = "gmsAddress", qualifiedByName = "yearsAtGmsAddress")
    @Mapping(target = "monthsAtAddress", source = "gmsAddress", qualifiedByName = "monthsAtGmsAddress")
    @Mapping(target = "addressEntryDate", source = "gmsAddress.startDate", qualifiedByName = "startDate")
    @Mapping(target = "occupancyType", source = "gmsAddress.occupyStatus")
    @Mapping(target = "currentValue", source = "gmsAddress", qualifiedByName = "toGMSCurrentPropertyValue")
    @Named("toGMSCurrentOccupancy")
    abstract UpdateCustomerOccupancyDetails toGMSCurrentOccupancy(UnstructuredAddress gmsAddress, @Context
            WorkflowContext workflowContext);


    @Mapping(target = "clientAddress", source = "address", qualifiedByName = "clientAddress")
    @Mapping(target = "yearsAtAddress", source = "address", qualifiedByName = "yearsAtAddress")
    @Mapping(target = "monthsAtAddress", source = "address", qualifiedByName = "monthsAtAddress")
    @Mapping(target = "addressEntryDate", source = "address.startDate", qualifiedByName = "startDate")
    @Mapping(target = "occupancyType", source = "address.occupyStatus")
    @Mapping(target = "currentValue", expression = "java(BigDecimal.ONE)")
    abstract UpdateCustomerOccupancyDetails mapToGMSCustomerPreviousOccupancyDetails(Address address);

    @Named("mapFailedToMakePaymentDetails")
    UpdateCustomerFailedToMakePaymentsDetails mapFailedToMakePaymentDetails(Applicant source,
                                                                            @Context WorkflowContext workflowContext) {
        return Optional.ofNullable(workflowContext.getOriginalHeaders()).map(headers -> headers.get(BRAND_HEADER))
                .filter(String.class::isInstance).map(String.class::cast).filter("RBS"::equalsIgnoreCase).map(brand ->
                        //Defaults FailedToMakePaymentsDetails -> Answer and PropertyRepossessed to N for RBS brand
                        UpdateCustomerFailedToMakePaymentsDetails.builder().answer(YesOrNo.N.name())
                                .propertyRepossessed(YesOrNo.N.name()).build()).orElse(null);
    }

    boolean isNotEmployed(Applicant applicant) {
        return CollectionUtils.isEmpty(applicant.getEmployments()) || applicant.getEmployments().stream()
                .filter(e -> Employment.EmploymentStatusEnum.NOT_EMPLOYED == e.getEmploymentStatus()).findAny()
                .isPresent() || applicant.getWorkStatus() == Applicant.WorkStatusEnum.NOT_WORKING;
    }

    List<UpdateCustomerEmployed> toGMSNotEmployedEmploymentDetails(Applicant applicant) {
        List<Employment> employments = Optional.ofNullable(applicant.getEmployments())
                .orElse(Arrays.asList(
                        Employment.builder().employmentStatus(Employment.EmploymentStatusEnum.NOT_EMPLOYED)
                                .employmentType(
                                        Employment.EmploymentTypeEnum.OTHER)
                                .occupationCode(Employment.OccupationCodeEnum.UNEMPLOYED).build()));

        if (employments.isEmpty()) {
            employments.add(Employment.builder().employmentType(
                            Employment.EmploymentTypeEnum.OTHER).employmentStatus(Employment.
                            EmploymentStatusEnum.NOT_EMPLOYED)
                    .occupationCode(Employment.OccupationCodeEnum.UNEMPLOYED).build());
        }

        return employments.stream()
                .filter(e -> e.getEmploymentStatus().equals(Employment.EmploymentStatusEnum.NOT_EMPLOYED))
                .map(employment -> {
                    UpdateCustomerEmployed notEmployed = mapToGMSNotEmployed(employment);
                    List<UpdateCustomerIncome> incomes = mapOtherIncomesToEmployedIncomes(applicant.getOtherIncomes());
                    if (CollectionUtils.isNotEmpty(incomes)) {
                        notEmployed.getIncomeDetails().getIncome().addAll(incomes);
                    }
                    return notEmployed;
                }).collect(Collectors.toList());


    }

    UpdateCustomerEmployed mapToGMSNotEmployed(Employment employment) {
        return UpdateCustomerEmployed.builder().employerName(
                        Employment.OccupationCodeEnum.UNEMPLOYED.equals(employment.getOccupationCode())
                                ? unEmployedEmployerName : retiredEmployerName)
                .startDate(LocalDate.now().minusMonths(unEmployedStartDatePriorMonths))
                .occupation(mapToOccupationType(employment.getOccupationCode()))
                .employerStatus(mapToEmployerStatus(Employment.IndustryTypeEnum.OTHER))
                .currentOrPrevious(CURRENT_EMPLOYMENT)
                .employmentType(mapToEmploymentType(Employment.EmploymentStatusEnum.NOT_EMPLOYED))
                .employmentStatus(mapToEmploymentStatus(employment.getEmploymentType())).employerAddress(
                        ContactAddress.builder().address1(
                                        Employment.OccupationCodeEnum.UNEMPLOYED.equals(employment.getOccupationCode())
                                                ? unEmployedAddress1 : retiredAddress1).address2(
                                        Employment.OccupationCodeEnum.UNEMPLOYED.equals(employment.getOccupationCode())
                                                ? unEmployedAddress2 : retiredAddress2).
                                                    addressCountry(unEmployedAddressCountry)
                                .build()).incomeDetails(UpdateCustomerIncomeDetails.builder().income(Stream
                                .of(UpdateCustomerIncome.builder().incomeType(
                                                Employment.OccupationCodeEnum.RETIRED == employment.getOccupationCode()
                                                        ? IncomeType.PEE.name() : IncomeType.BAE.name()).
                                                            amount(unEmployedIncomeAmount)
                                        .frequency(unEmployedIncomeFrequency).netAmount(unEmployedIncomeNetAmount)
                                        .netFrequency(unEmployedIncomeNetFrequency).build()).
                                collect(Collectors.toList()))
                        .build()).build();
    }

    List<UpdateCustomerIncome> mapOtherIncomesToEmployedIncomes(List<OtherIncome> otherIncomes) {
        return CollectionUtils.isEmpty(otherIncomes) ? null
                : otherIncomes.stream().filter(i -> !isOtherIncome(i)).map(i -> mapOtherIncomeToEmployedIncome(i))
                        .collect(Collectors.toList());
    }

    @Named("toGMSNumberOfDependants")
    Integer toGMSNumberOfDependants(WorkflowContext workflowContext) {
        if (ADBOWorkflowUtils.getCount(workflowContext, ADBOSubmitRoutingSlip.UPDATE_GMS_CUSTOMER.getIndex()) == 1) {
            return mapToGMSNumberOfDependants(workflowContext);
        }
        return 0;
    }

    @Named("toGMSCurrentPropertyValue")
    BigDecimal toGMSCurrentPropertyValue(UnstructuredAddress unstructuredAddress,
                                         @Context WorkflowContext workflowContext) {
        return mapToPropertyValue(
                ADBOWorkflowUtils.getOriginalPayload(workflowContext).getExistingMortgage().getMortgageProperty());
    }

    List<UpdateCustomerEmployed> toGMSEmploymentDetails(Applicant applicant, BigDecimal netMonthlyIncome) {
        return nonNull(applicant.getEmployments()) ? toEmployed(applicant.getEmployments()).stream().map(employment -> {
            UpdateCustomerEmployed employed = mapToGMSEmployed(employment, netMonthlyIncome);
            if (Boolean.TRUE.equals(employment.getPrimary())) {
                List<UpdateCustomerIncome> incomes = mapOtherIncomesToEmployedIncomes(applicant.getOtherIncomes());
                if (CollectionUtils.isNotEmpty(incomes)) {
                    if (isNull(employed.getIncomeDetails())) {
                        employed.setIncomeDetails(
                                UpdateCustomerIncomeDetails.builder().income(new ArrayList<>()).build());
                    }
                    employed.getIncomeDetails().getIncome().addAll(incomes);
                }
            }
            return employed;
        }).collect(Collectors.toList()) : null;
    }


    @Mapping(target = "incomeType", source = "source.type", qualifiedByName = "employedOtherIncomeType")
    @Mapping(target = "frequency", source = "source.frequency")
    @Mapping(target = "amount", source = "source", qualifiedByName = "toGMSOtherIncomeAmount")
    abstract UpdateCustomerIncome mapOtherIncomeToEmployedIncome(OtherIncome source);

    @Mapping(target = "incomeType", source = "source.type", qualifiedByName = "selfEmployedOtherIncomeType")
    @Mapping(target = "frequency", source = "source.frequency")
    @Mapping(target = "amount", source = "source", qualifiedByName = "toGMSOtherIncomeAmount")
    abstract UpdateCustomerIncome mapOtherIncomeToSelfEmployedIncome(OtherIncome source);

    @Mapping(target = "startDate", source = "employment.startDate", dateFormat = STANDARD_DATE_FORMAT)
    @Mapping(target = "contractEndDate", source = "employment", qualifiedByName = "toGMSContractEndDate")
    @Mapping(target = "occupation", source = "employment.occupationCode")
    @Mapping(target = "employerStatus", source = "employment.industryType")
    @Mapping(target = "employmentStatus", source = "employment.employmentType")
    @Mapping(target = "currentOrPrevious", source = "employment", qualifiedByName = "toGMSCurrentOrPrevious")
    @Mapping(target = "faxNumber", source = "employment.telephones", qualifiedByName = "telephoneListToFax")
    @Mapping(target = "telephoneNumber", source = "employment.telephones", qualifiedByName = "telephoneListToBusiness")
    @Mapping(target = "employmentType", source = "employment.employmentStatus")
    @Mapping(target = "employerAddress", source = "employment", qualifiedByName = "toGMSEmploymentAddress")
    @Mapping(target = "employerName", source = "employment.employerName")
    @Mapping(target = "incomeDetails.income", expression = "java(toGMSEmployedIncomes(employment, netMonthlyIncome))")
    @Mapping(target = "yearsOfService", source = "employment", qualifiedByName = "yearsAtEmployment")
    @Mapping(target = "monthsOfService", source = "employment", qualifiedByName = "monthsAtEmployment")
    abstract UpdateCustomerEmployed mapToGMSEmployed(Employment employment, @Context BigDecimal netMonthlyIncome);

    @Named("toGMSContractEndDate")
    LocalDate cpToGMSContractEndDate(Employment source) {
        if (source.getEmploymentType().equals(Employment.EmploymentTypeEnum.CONTRACT)) {
            return toLocalDate(source.getEndDate());
        }
        return null;
    }

    List<UpdateCustomerSelfEmployed> toGMSSelfEmploymentDetails(Applicant applicant, BigDecimal netMonthlyIncome) {
        AtomicBoolean isPrimarySelfEmployed = new AtomicBoolean(false);
        List<UpdateCustomerSelfEmployed> updateCustomerSelfEmployed = nonNull(applicant.getEmployments())
                ? toSelfEmployed(applicant.getEmployments()).stream().map(employment -> {
                    UpdateCustomerSelfEmployed selfEmployed = mapToGMSSelfEmployed(employment, netMonthlyIncome);
                    if (Boolean.TRUE.equals(employment.getPrimary())) {
                        isPrimarySelfEmployed.set(true);
                        setSelfEmployedBasicIncomeType(selfEmployed);
                        List<UpdateCustomerIncome> incomes =
                                mapOtherIncomesToSelfEmployedIncomes(applicant.getOtherIncomes());
                        if (CollectionUtils.isNotEmpty(incomes)) {
                            if (isNull(selfEmployed.getIncomeDetails())) {
                                selfEmployed.setIncomeDetails(
                                        UpdateCustomerIncomeDetails.builder().income(new ArrayList<>()).build());
                            }
                            selfEmployed.getIncomeDetails().getIncome().addAll(incomes);
                        }
                    }
                    return selfEmployed;
                }).collect(Collectors.toList()) : null;
        if (Boolean.FALSE.equals(isPrimarySelfEmployed.get())) {
            ofNullable(updateCustomerSelfEmployed).map(List::stream).flatMap(selfEmployedStream -> selfEmployedStream
                            .filter(selfEmployed -> "C".equalsIgnoreCase(selfEmployed.getCurrentOrPrevious())).
                                findFirst())
                    .ifPresent(this::setSelfEmployedBasicIncomeType);
        }
        return updateCustomerSelfEmployed;
    }

    private void setSelfEmployedBasicIncomeType(UpdateCustomerSelfEmployed selfEmployed) {
        ofNullable(selfEmployed.getIncomeDetails()).map(UpdateCustomerIncomeDetails::getIncome).map(List::stream)
                .flatMap(Stream::findFirst)
                .ifPresent(updateCustomerIncome -> updateCustomerIncome.setIncomeType(basicSelfEmployedIncomeType));
    }

    List<UpdateCustomerIncome> mapOtherIncomesToSelfEmployedIncomes(List<OtherIncome> otherIncomes) {
        return CollectionUtils.isEmpty(otherIncomes) ? null
                : otherIncomes.stream().filter(i -> !isOtherIncome(i)).map(i -> mapOtherIncomeToSelfEmployedIncome(i))
                        .collect(Collectors.toList());
    }

    @Mapping(target = "faxNumber", source = "employment.telephones", qualifiedByName = "telephoneListToFax")
    @Mapping(target = "telephoneNumber", source = "employment.telephones", qualifiedByName = "telephoneListToBusiness")
    @Mapping(target = "employmentStatus", source = "employment.selfEmployed.businessType")
    @Mapping(target = "profitYear1", expression = "java(employment.getSelfEmployed().getBusinessType()"
            + ".equals(com.natwest.pbbdhb.openapi"
            + ".SelfEmployed.BusinessTypeEnum" + ".LIMITED_COMPANY)"
            + "? null : employment"
            + ".getSelfEmployed().getLatestTradingYear())")
    @Mapping(target = "profitYear2", expression = "java(employment.getSelfEmployed().getBusinessType()"
            + ".equals(com.natwest.pbbdhb.openapi"
            + ".SelfEmployed.BusinessTypeEnum" + ".LIMITED_COMPANY)"
            + "? null : employment"
            + ".getSelfEmployed().getPreviousTradingYear())")
    @Mapping(target = "profitAmount1", expression = "java(employment.getSelfEmployed().getBusinessType()"
            + ".equals(com.natwest.pbbdhb.openapi"
            + ".SelfEmployed.BusinessTypeEnum" + ".LIMITED_COMPANY)"
            + "? null : employment"
            + ".getSelfEmployed().getNetProfitLatest())")
    @Mapping(target = "profitAmount2", expression = "java(employment.getSelfEmployed().getBusinessType()"
            + ".equals(com.natwest.pbbdhb.openapi"
            + ".SelfEmployed.BusinessTypeEnum" + ".LIMITED_COMPANY)"
            + "? null : employment"
            + ".getSelfEmployed().getNetProfitPrevious())")
    @Mapping(target = "yearsEstablished", source = "employment.selfEmployed.selfEmployedDateEstablished",
            dateFormat = STANDARD_DATE_FORMAT, qualifiedByName = "numberOfYears")
    @Mapping(target = "monthsEstablished", source = "employment.selfEmployed.selfEmployedDateEstablished",
            dateFormat = STANDARD_DATE_FORMAT, qualifiedByName = "numberOfMonths")
    @Mapping(target = "employmentType", source = "employment.employmentStatus")
    @Mapping(target = "occupation", source = "employment.occupationCode")
    @Mapping(target = "employerStatus", source = "employment.industryType")
    @Mapping(target = "percentageShares", expression = "java(employment.getSelfEmployed().getEmployeeShare() != null "
            + "? employment.getSelfEmployed().getEmployeeShare().intValue"
            + "() : null)")
    @Mapping(target = "dividendYear1", source = "employment.selfEmployed.latestTradingYear")
    @Mapping(target = "dividendYear2", source = "employment.selfEmployed.previousTradingYear")
    @Mapping(target = "dividendAmount1", source = "employment.selfEmployed.dividendsLatest")
    @Mapping(target = "dividendAmount2", source = "employment.selfEmployed.dividendsPrevious")
    @Mapping(target = "companyAddress", source = "employment", qualifiedByName = "toGMSEmploymentAddress")
    @Mapping(target = "companyName", source = "employment.employerName")
    @Mapping(target = "currentOrPrevious", source = "employment", qualifiedByName = "toGMSCurrentOrPrevious")
    @Mapping(target = "incomeDetails.income",
            expression = "java(cpToGMSSelfEmployedIncomes(employment, " + "netMonthlyIncome))")
    abstract UpdateCustomerSelfEmployed mapToGMSSelfEmployed(Employment employment,
                                                             @Context BigDecimal netMonthlyIncome);

    List<UpdateCustomerIncome> toGMSEmployedIncomes(Employment employment, BigDecimal netMonthlyIncome) {
        List<UpdateCustomerIncome> incomes = null;
        if (!isNull(employment.getIncomes())) {
            incomes = employment.getIncomes().stream().map(i -> mapToEmployedIncome(i)).collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(incomes)) {
                incomes.stream().forEach(i -> {
                    i.setNetAmount(BigDecimal.ZERO);
                    i.setNetFrequency("M");
                });
                mapToGMSNetAmount(incomes.stream().findFirst().get(), employment, netMonthlyIncome);
            }
        }
        return incomes;
    }

    @Mapping(target = "incomeType", source = "source.type", qualifiedByName = "employedIncomeType")
    @Mapping(target = "frequency", constant = "A")
    @Mapping(target = "amount", source = "source", qualifiedByName = "toGMSIncomeAmount")
    abstract UpdateCustomerIncome mapToEmployedIncome(Income source);

    List<UpdateCustomerIncome> cpToGMSSelfEmployedIncomes(Employment employment, BigDecimal netMonthlyIncome) {
        BigDecimal annualIncomeAmount = getSelfEmployedNonPrimaryIncome(employment.getSelfEmployed());
        List<UpdateCustomerIncome> incomes = newArrayList(
                UpdateCustomerIncome.builder().incomeType(otherSelfEmployedIncomeType)
                        .amount(roundDown(annualIncomeAmount)).frequency(incomeFrequency).build());
        if (!CollectionUtils.isEmpty(incomes)) {
            incomes.stream().forEach(i -> {
                if (isNull(i.getAmount())) {
                    i.setAmount(BigDecimal.ZERO);
                }

                i.setNetAmount(BigDecimal.ZERO);
                i.setNetFrequency("M");
            });
            mapToGMSNetAmount(incomes.stream().findFirst().get(), employment, netMonthlyIncome);
        }
        return incomes;
    }

    void mapToGMSNetAmount(UpdateCustomerIncome income, Employment source, BigDecimal netMonthlyIncome) {
        if (Boolean.TRUE.equals(source.getPrimary()) && nonNull(netMonthlyIncome)
                && netMonthlyIncome.compareTo(BigDecimal.ZERO) == 1) {
            income.setNetAmount(netMonthlyIncome);
            income.setNetFrequency(netIncomeFrequency);
        }
    }

    @Named("toGMSOtherIncomes")
    List<UpdateCustomerIncomeWithUnderwritingPercent> toGMSOtherIncomes(Applicant applicant) {
        if (Employment.EmploymentStatusEnum.EMPLOYED.equals(primaryEmploymentStatus(applicant.getEmployments()))) {
            return nonNull(applicant.getOtherIncomes())
                    ? applicant.getOtherIncomes().stream().filter(i -> isOtherIncome(i))
                            .map(i -> mapToEmployedOtherIncome(i)).collect(Collectors.toList()) : null;
        } else {
            return nonNull(applicant.getOtherIncomes())
                    ? applicant.getOtherIncomes().stream().filter(i -> isOtherIncome(i))
                            .map(i -> mapToSelfEmployedOtherIncome(i)).collect(Collectors.toList()) : null;
        }
    }

    @Mapping(target = "incomeType", source = "source.type", qualifiedByName = "employedOtherIncomeType")
    @Mapping(target = "frequency", source = "source.frequency")
    @Mapping(target = "amount", source = "source", qualifiedByName = "toGMSOtherIncomeAmount")
    abstract UpdateCustomerIncomeWithUnderwritingPercent mapToEmployedOtherIncome(OtherIncome source);

    @Mapping(target = "incomeType", source = "source.type", qualifiedByName = "selfEmployedOtherIncomeType")
    @Mapping(target = "frequency", source = "source.frequency")
    @Mapping(target = "amount", source = "source", qualifiedByName = "toGMSOtherIncomeAmount")
    abstract UpdateCustomerIncomeWithUnderwritingPercent mapToSelfEmployedOtherIncome(OtherIncome source);

    @Named("toGMSBankDetails")
    List<UpdateCustomerBankAccount> toGMSBankDetails(BankDetails source) {
        return Arrays.asList(mapToGMSBankDetails(source));
    }

    @Mapping(target = "yearsWithBank", source = "source.dateOpened", dateFormat = STANDARD_DATE_FORMAT,
            qualifiedByName = "numberOfYears")
    @Mapping(target = "monthsWithBank", source = "source.dateOpened", dateFormat = STANDARD_DATE_FORMAT,
            qualifiedByName = "numberOfMonths")
    @Mapping(target = "chequeGuaranteeCard", source = "source.debitCard", qualifiedByName = "toGMSYesOrNo")
    @Mapping(target = "bankAccountNumber", source = "source.accountNumber")
    @Mapping(target = "bankAccountName", source = "source.accountName")
    @Mapping(target = "bankSortCode", source = "source.sortCode")
    abstract UpdateCustomerBankAccount mapToGMSBankDetails(BankDetails source);

    @Named("toGMSDependants")
    List<Dependant> toGMSDependants(WorkflowContext workflowContext) {
        List<Dependant> dependants = new ArrayList<>();
        if (ADBOWorkflowUtils.getCount(workflowContext, ADBOSubmitRoutingSlip.UPDATE_GMS_CUSTOMER.getIndex()) == 1) {
            Application application = ADBOWorkflowUtils.getOriginalPayload(workflowContext);
            if (application.getNumberOfDependantsUnder18() > 0) {
                dependants.addAll(getDependants(application.getNumberOfDependantsUnder18(), true));
            }
            if (application.getNumberOfDependantsOver18() > 0) {
                dependants.addAll(getDependants(application.getNumberOfDependantsOver18(), false));
            }
        }
        return dependants;
    }

    @Mapping(target = "relationship", constant = DEPENDANT_RELATIONSHIP)
    @Mapping(target = "name", expression = "java(under18Dependant ? CHILD : ADULT)")
    @Mapping(target = "age", expression = "java(under18Dependant ? null : OVER18_AGE)")
    abstract Dependant mapToGMSDependant(Boolean under18Dependant);

    private List<Dependant> getDependants(Integer noOfDependants, Boolean under18Dependant) {
        List dependantsList = new ArrayList<Dependant>();
        for (int i = 0; i < noOfDependants; i++) {
            dependantsList.add(mapToGMSDependant(under18Dependant));
        }
        return dependantsList;
    }

    @Named(value = "toGMSIncomeAmount")
    BigDecimal toGMSIncomeAmount(Income source) {
        return getIncomeAmount(source.getFrequency().name(), source.getAmount());
    }


    @ValueMapping(source = "OWNER_MORTGAGED", target = "O")
    @ValueMapping(source = "OWNER_NO_MORTGAGE", target = "O")
    @ValueMapping(source = "TENANT", target = "O")
    @ValueMapping(source = "LIVING_WITH_FAMILY", target = "O")
    @ValueMapping(source = "LIVING_WITH_FRIENDS", target = "O")
    @ValueMapping(source = "LIVING_WITH_PARTNER", target = "O")
    abstract String mapToOccupancyType(Address.OccupyStatusEnum source);

    @ValueMapping(source = "OWNER_MORTGAGED", target = "E")
    @ValueMapping(source = "OWNER_NO_MORTGAGE", target = "U")
    @ValueMapping(source = "TENANT", target = "T")
    @ValueMapping(source = "LIVING_WITH_FAMILY", target = "L")
    @ValueMapping(source = "LIVING_WITH_FRIENDS", target = "F")
    @ValueMapping(source = "LIVING_WITH_PARTNER", target = "P")
    abstract String mapToOccupancyType(UnstructuredAddress.OccupyStatusEnum source);

    @ValueMapping(source = "BASIC_EARNINGS", target = "BAE")
    @ValueMapping(source = "BONUS_GUARANTEED", target = "BON")
    @ValueMapping(source = "OVERTIME_GUARANTEED", target = "GOT")
    @ValueMapping(source = "COMMISSION_GUARANTEED", target = "COE")
    @ValueMapping(source = "SHIFT_ALLOWANCE_GUARANTEED", target = "GSA")
    @ValueMapping(source = "BONUS_DISCRETIONARY", target = "ROB")
    @ValueMapping(source = "OVERTIME_REGULAR", target = "ROB")
    @ValueMapping(source = "COMMISSION_REGULAR", target = "COE")
    @ValueMapping(source = "SHIFT_ALLOWANCE_REGULAR", target = "GSA")
    @ValueMapping(source = "PROFIT_SHARE", target = "OTE")
    @ValueMapping(source = "DIVIDEND", target = "OTE")
    @ValueMapping(source = "CAR_ALLOWANCE", target = "OTE")
    @ValueMapping(source = "MORTGAGE_SUBSIDY", target = "OTE")
    @Named("employedIncomeType")
    abstract String mapToEmployedIncomeType(Income.TypeEnum source);


    @ValueMapping(source = "WORKING_FAMILIES_TAX_CREDIT", target = "WFT")
    @ValueMapping(source = "CHILD_BENEFIT", target = "WFT")
    @ValueMapping(source = "UNIVERSAL_CREDIT", target = "OTE")
    @ValueMapping(source = "CARERS_ALLOWANCE", target = "DAE")
    @ValueMapping(source = "DISABLEMENT_LIVING_ALLOWANCE", target = "DAE")
    @ValueMapping(source = "PERSONAL_INDEPENDENT_INCOME", target = "DAE")
    @ValueMapping(source = "DIVIDEND", target = "RIE")
    @ValueMapping(source = "INVESTMENT_INCOME", target = "RIE")
    @ValueMapping(source = "MAINTENANCE", target = "WFT")
    @ValueMapping(source = "PENSION_PRIVATE_OR_EMPLOYERS", target = "PEE")
    @ValueMapping(source = "PENSION_STATE", target = "PEE")
    @ValueMapping(source = "TRUST", target = "RIE")
    @ValueMapping(source = "RENTAL_INCOME", target = "RIO")
    @ValueMapping(source = "ADOPTION_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "ATTENDANCE_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "CHILD_WORKING_TAX_CREDIT", target = "WFT")
    @ValueMapping(source = "CONSTANT_ATTENDANCE_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "EMPLOYMENT_AND_SUPPORT_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "FOSTER_CARERS_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "GUARDIANS_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "INCOME_SUPPORT", target = "OTE")
    @ValueMapping(source = "INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT", target = "IIB")
    @ValueMapping(source = "PENSION_CREDIT", target = "WFT")
    @ValueMapping(source = "REDUCED_EARNINGS_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "WIDOWED_PARENT_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "WAR_WIDOW_PENSION", target = "PEE")
    @ValueMapping(source = "OTHER_TAXABLE", target = "OTE")
    @ValueMapping(source = "OTHER_NON_TAXABLE", target = "OTE")
    @Named("employedOtherIncomeType")
    abstract String mapToEmployedOtherIncomeType(OtherIncome.TypeEnum source);

    @ValueMapping(source = "WORKING_FAMILIES_TAX_CREDIT", target = "WFT")
    @ValueMapping(source = "CHILD_BENEFIT", target = "WFT")
    @ValueMapping(source = "UNIVERSAL_CREDIT", target = "OTS")
    @ValueMapping(source = "CARERS_ALLOWANCE", target = "DAS")
    @ValueMapping(source = "DISABLEMENT_LIVING_ALLOWANCE", target = "DAS")
    @ValueMapping(source = "PERSONAL_INDEPENDENT_INCOME", target = "DAS")
    @ValueMapping(source = "DIVIDEND", target = "RIS")
    @ValueMapping(source = "INVESTMENT_INCOME", target = "RIS")
    @ValueMapping(source = "MAINTENANCE", target = "WFT")
    @ValueMapping(source = "PENSION_PRIVATE_OR_EMPLOYERS", target = "PES")
    @ValueMapping(source = "PENSION_STATE", target = "PES")
    @ValueMapping(source = "TRUST", target = "RIS")
    @ValueMapping(source = "RENTAL_INCOME", target = "RIO")
    @ValueMapping(source = "ADOPTION_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "ATTENDANCE_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "CHILD_WORKING_TAX_CREDIT", target = "WFT")
    @ValueMapping(source = "CONSTANT_ATTENDANCE_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "EMPLOYMENT_AND_SUPPORT_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "FOSTER_CARERS_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "GUARDIANS_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "INCOME_SUPPORT", target = "OTS")
    @ValueMapping(source = "INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT", target = "IIB")
    @ValueMapping(source = "PENSION_CREDIT", target = "WFT")
    @ValueMapping(source = "REDUCED_EARNINGS_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "WIDOWED_PARENT_ALLOWANCE", target = "ATA")
    @ValueMapping(source = "WAR_WIDOW_PENSION", target = "PES")
    @ValueMapping(source = "OTHER_TAXABLE", target = "OTS")
    @ValueMapping(source = "OTHER_NON_TAXABLE", target = "OTS")
    @Named("selfEmployedOtherIncomeType")
    abstract String mapToSelfEmployedOtherIncomeType(OtherIncome.TypeEnum source);

    @ValueMapping(source = "HIRE_PURCHASE", target = "LR")
    @ValueMapping(source = "SECURED_LOAN", target = "LR")
    @ValueMapping(source = "UNSECURED_LOAN", target = "LR")
    @ValueMapping(source = "STUDENT_LOAN", target = "LR")
    abstract String mapToExpenditureType(Loan.TypeEnum source);

    @ValueMapping(source = "CREDIT_CARD", target = "C")
    @ValueMapping(source = "STORE_CARD", target = "C")
    abstract String mapToExpenditureType(CreditCard.TypeEnum source);

    @ValueMapping(source = "CHILD_SUPPORT", target = "CS")
    @ValueMapping(source = "RENT", target = "MR")
    @ValueMapping(source = "RENT_SHORTFALL", target = "MR")
    @ValueMapping(source = "PENSION_CONTRIBUTION", target = "CS")
    @ValueMapping(source = "RENT_WHILE_HOUSE_IMPROVEMENTS", target = "MR")
    @ValueMapping(source = "MORTGAGE_PAYMENTS", target = "MR")
    @ValueMapping(source = "RUNNING_COSTS", target = "MR")
    @ValueMapping(source = "SCHOOL_FEES", target = "CS")
    @ValueMapping(source = "CHILD_CARE_COSTS", target = "CS")
    @ValueMapping(source = "ADULT_CARE_COSTS", target = "CS")
    @ValueMapping(source = "GROUND_RENT", target = "MR")
    @ValueMapping(source = "SERVICE_CHARGE", target = "CS")
    @ValueMapping(source = "ESTATE_CHARGE", target = "CS")
    @ValueMapping(source = "HELP_TO_BUY_LOAN", target = "LR")
    @ValueMapping(source = "OTHER_COMMITTED_EXPENDITURE", target = "CS")
    abstract String mapToExpenditureType(FinancialCommitment.TypeEnum source);

    @ValueMapping(source = "SELF_EMPLOYED", target = "S")
    @ValueMapping(source = "NOT_EMPLOYED", target = "U")
    @ValueMapping(source = "EMPLOYED", target = "E")
    abstract String mapToEmploymentType(Employment.EmploymentStatusEnum source);

    @ValueMapping(source = "PERMANENT", target = "P")
    @ValueMapping(source = "CONTRACT", target = "C")
    @ValueMapping(source = "TEMPORARY", target = "T")
    @ValueMapping(source = "OTHER", target = "R")
    abstract String mapToEmploymentStatus(Employment.EmploymentTypeEnum source);

    @ValueMapping(source = "ANNUALLY", target = "A")
    @ValueMapping(source = "BIANNUALLY", target = "A")
    @ValueMapping(source = "QUARTERLY", target = "A")
    @ValueMapping(source = "MONTHLY", target = "M")
    @ValueMapping(source = "WEEKLY", target = "W")
    @ValueMapping(source = "FORTNIGHTLY", target = "A")
    @ValueMapping(source = "FOUR_WEEKLY", target = "A")
    abstract String mapToIncomeFrequency(Income.FrequencyEnum source);

    @ValueMapping(source = "ANNUALLY", target = "A")
    @ValueMapping(source = "BIANNUALLY", target = "A")
    @ValueMapping(source = "QUARTERLY", target = "A")
    @ValueMapping(source = "MONTHLY", target = "A")
    @ValueMapping(source = "WEEKLY", target = "A")
    @ValueMapping(source = "FORTNIGHTLY", target = "A")
    @ValueMapping(source = "FOUR_WEEKLY", target = "A")
    abstract String mapToOtherIncomeFrequency(OtherIncome.FrequencyEnum source);

    //TODO - Need to revisit
    @ValueMapping(source = "AGRICULTURE_HUNTING_FORESTRY", target = "A")
    @ValueMapping(source = "FISHING", target = "B")
    @ValueMapping(source = "MINING_AND_QUARRYING", target = "C")
    @ValueMapping(source = "MANUFACTURING", target = "D")
    @ValueMapping(source = "ELECTRICITY_GAS_WATER_SUPPLY", target = "E")
    @ValueMapping(source = "CONSTRUCTION", target = "F")
    @ValueMapping(source = "WHOLESALE_RETAIL_AND_REPAIR", target = "G")
    @ValueMapping(source = "HOTELS_AND_RESTAURANTS", target = "H")
    @ValueMapping(source = "TRANSPORT_STORAGE_COMM", target = "I")
    @ValueMapping(source = "FINANCIAL_INTERMEDIATION", target = "J")
    @ValueMapping(source = "PROPERTY_AND_BUSINESS", target = "K")
    @ValueMapping(source = "PUBLIC_ADMIN_AND_DEFENCE", target = "L")
    @ValueMapping(source = "EDUCATION", target = "M")
    @ValueMapping(source = "HEALTH_AND_SOCIAL_WORK", target = "N")
    @ValueMapping(source = "OFFICE_WORK_AND_ADMINISTRATION", target = "P")
    @ValueMapping(source = "OTHER", target = "O")
    abstract String mapToEmployerStatus(Employment.IndustryTypeEnum source);

    @ValueMapping(source = "LIMITED_COMPANY", target = "D")
    @ValueMapping(source = "PARTNERSHIP", target = "P")
    @ValueMapping(source = "SOLE_TRADER", target = "S")
    abstract String mapToSelfEmployedType(SelfEmployed.BusinessTypeEnum source);

    @ValueMapping(target = "CA", source = "ARTS")
    @ValueMapping(target = "CB", source = "BUSINESS_AND_ADMINISTRATION")
    @ValueMapping(target = "CC", source = "SCIENCES")
    @ValueMapping(target = "CD", source = "SOCIAL_STUDIES")
    @ValueMapping(target = "CE", source = "ENGINEERING")
    @ValueMapping(target = "CF", source = "MATHS_SCIENCES_AND_INFORMATICS")
    @ValueMapping(target = "CG", source = "ARCHITECT_BUILDING_AND_PLANNING")
    @ValueMapping(target = "CH", source = "HUMANITIES")
    @ValueMapping(target = "CJ", source = "AGRICULTURE")
    @ValueMapping(target = "CK", source = "LANGUAGES_AND_RELATED_SUBJECTS")
    @ValueMapping(target = "CL", source = "LAW")
    @ValueMapping(target = "CM", source = "MEDICAL_AND_RELATED")
    @ValueMapping(target = "CN", source = "NURSING")
    @ValueMapping(target = "AS", source = "ACADEMIC_STAFF")
    @ValueMapping(target = "AG", source = "AGRICULTURAL_WORKERS_GENERAL")
    @ValueMapping(target = "FM", source = "FARM_MANAGEMENT_GENERAL")
    @ValueMapping(target = "OF", source = "HM_FORCES_OFFICERS")
    @ValueMapping(target = "OR", source = "HM_FORCES_OTHER_RANKS")
    @ValueMapping(target = "HF", source = "HOME_FAMILY_RESPONSIBILITIES")
    @ValueMapping(target = "MJ", source = "JUNIOR_MANAGEMENT")
    @ValueMapping(target = "OC", source = "OFFICE_AND_CLERICAL")
    @ValueMapping(target = "PR", source = "PROFESSIONALS")
    @ValueMapping(target = "SA", source = "SALES")
    @ValueMapping(target = "PM", source = "SEMI_PROFESSIONALS")
    @ValueMapping(target = "SS", source = "SEMI_SKILLED")
    @ValueMapping(target = "TH", source = "TECHNICIANS")
    @ValueMapping(target = "MS", source = "SENIOR_MANAGEMENT")
    @ValueMapping(target = "SR", source = "SERVICE_JOBS")
    @ValueMapping(target = "SK", source = "SKILLED_MANUAL")
    @ValueMapping(target = "SU", source = "SUPERVISORY_FOREMAN")
    @ValueMapping(target = "TC", source = "TEACHERS")
    @ValueMapping(target = "UN", source = "UNEMPLOYED")
    @ValueMapping(target = "SE", source = "SELF_EMPLOYED")
    @ValueMapping(target = "ST", source = "STUDENT")
    @ValueMapping(target = "RT", source = "RETIRED")
    @ValueMapping(target = "UM", source = "MANUAL")
    abstract String mapToOccupationType(Employment.OccupationCodeEnum source);

    @ValueMapping(target = "DGA", source = "DIGITAL_ADVISOR")
    abstract String mapToKycChannelType(Applicant.KycChannelEnum source);

    @Named(value = "toGMSCurrentOrPrevious")
    String toGMSCurrentOrPrevious(Employment employment) {
        if (StringUtils.isNotBlank(employment.getEndDate())) {
            if (employment.getEmploymentType().getValue().equals(Employment.EmploymentTypeEnum.CONTRACT.getValue())) {
                return toLocalDate(employment.getEndDate()).isAfter(LocalDate.now()) ? "C" : "P";
            } else {
                return "P";
            }
        } else {
            return "C";
        }

    }

    @Named(value = "toGMSNumberOfDependants")
    BigDecimal mapToIncomeAmount(Income source) {
        return getIncomeAmount(source.getFrequency().name(), source.getAmount());
    }

    @Named(value = "toGMSOtherIncomeAmount")
    BigDecimal mapToOtherIncomeAmount(OtherIncome source) {
        return getIncomeAmount(source.getFrequency().name(), source.getAmount());
    }

    private BigDecimal getIncomeAmount(String frequency, BigDecimal amount) {
        return amount.multiply(BigDecimal
                .valueOf(IncomeConversionFrequency.getIncomeConversionFrequency(frequency).getConversionFactor()));
    }

    Employment.EmploymentStatusEnum primaryEmploymentStatus(List<Employment> employments) {
        return CollectionUtils.isNotEmpty(employments)
                ? employments.stream().filter(e -> e.getPrimary()).findFirst().map(e -> e.getEmploymentStatus())
                        .orElse(null) : null;
    }

    @Named("toGMSExpenditures")
    List<UpdateCustomerExpenditure> toGMSExpenditures(Applicant source, @Context WorkflowContext workflowContext) {
        //Expenditures - based on creditCards, loans and financialCommitments of an Applicant
        List<UpdateCustomerExpenditure> expenditures = new ArrayList<>();

        Predicate<CreditCard> isValidPartialRefinanced = (CreditCard c) -> nonNull(c.getPartialRefinanced())
                && c.getPartialRefinanced()
                        .compareTo(BigDecimal.ZERO) > 0
                && c.getPartialRefinanced()
                        .compareTo(c.getTotalBalance()) <= 0;

        Predicate<CreditCard> isDebtConsolidated =
                (CreditCard c) -> ofNullable(c.getDebtConsolidation()).orElse(Boolean.FALSE);

        if (nonNull(source.getCreditCards())) {
            expenditures.addAll(source.getCreditCards().stream()
                .filter(c -> !(!isDebtConsolidated.test(c) && c.getToBeRepaid()) && nonNull(c.getTotalBalance())
                        && c.getTotalBalance().compareTo(BigDecimal.ZERO) > 0)
                .map(c -> UpdateCustomerExpenditure.builder().expenditureType(mapToExpenditureType(c.getType()))
                        .amount(BigDecimal.valueOf(0L)).recipientDetails(
                                UpdateCustomerRecipientDetails.builder().recipient(c.getProvider()).amountOwed(
                                                isValidPartialRefinanced.test(c) && isDebtConsolidated.test(c) && c
                                                        .getToBeRepaid() ? c.getPartialRefinanced()
                                                        : c.getTotalBalance())
                                        .amountConsolidated(isDebtConsolidated.test(c)
                                                ? (isValidPartialRefinanced.test(c) ? c.getPartialRefinanced()
                                                : c.getTotalBalance()) : null).build())
                        .frequency(expenditureFrequency).build()).collect(Collectors.toList()));
        }
        if (nonNull(source.getLoans())) {
            expenditures.addAll(source.getLoans().stream()
                .filter(l -> !(!ofNullable(l.getDebtConsolidation()).orElse(Boolean.FALSE) && l.getToBeRepaid()))
                .map(l -> UpdateCustomerExpenditure.builder().expenditureType(mapToExpenditureType(l.getType()))
                        .amount(l.getMonthlyPayment()).frequency(expenditureFrequency).recipientDetails(
                                UpdateCustomerRecipientDetails.builder().recipient(l.getProvider())
                                        .amountOwed(l.getAmountOutstanding()).amountConsolidated(
                                                ofNullable(l.getDebtConsolidation()).orElse(Boolean.FALSE) && l
                                                        .getToBeRepaid() ? l.getAmountOutstanding() : null).
                                        build()).build())
                .collect(Collectors.toList()));
        }
        if (nonNull(source.getFinancialCommitments())) {
            expenditures.addAll(source.getFinancialCommitments().stream()
                .filter(e -> nonNull(e.getPaymentsContinuing())
                        && e.getPaymentsContinuing().compareTo(BigDecimal.ZERO) > 0)
                .map(e -> UpdateCustomerExpenditure.builder().expenditureType(mapToExpenditureType(e.getType()))
                        .amount(e.getMonthlyPayments()).frequency(expenditureFrequency).build())
                .collect(Collectors.toList()));
        }
        return expenditures;
    }

    boolean isOtherIncome(OtherIncome otherIncome) {
        return Stream.of(ATTENDANCE_ALLOWANCE, ADOPTION_ALLOWANCE, CONSTANT_ATTENDANCE_ALLOWANCE,
                        EMPLOYMENT_AND_SUPPORT_ALLOWANCE, REDUCED_EARNINGS_ALLOWANCE, WIDOWED_PARENT_ALLOWANCE,
                        FOSTER_CARERS_ALLOWANCE, GUARDIANS_ALLOWANCE,
                        WORKING_FAMILIES_TAX_CREDIT, MAINTENANCE, CHILD_BENEFIT, CHILD_WORKING_TAX_CREDIT,
                        PENSION_CREDIT, RENTAL_INCOME, INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT)
                .collect(Collectors.toList()).contains(otherIncome.getType());
    }

}
