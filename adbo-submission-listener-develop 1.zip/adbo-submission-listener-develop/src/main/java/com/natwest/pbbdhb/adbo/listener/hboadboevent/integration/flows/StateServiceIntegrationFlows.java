package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.flows;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionSpel;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.WorkflowExecutionFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.state.CreateApplicationRequestMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.state.CreateApplicationStateRequestMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.state.UpdateApplicationRequestMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums.WorkflowExecutionMessage;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.CreateApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.CreateApplicationStateResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.GetApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.UpdateApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.SerializableUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.WorkflowUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.Alert;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.LoggerUtils;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.extern.slf4j.Slf4j;
import org.aopalliance.aop.Advice;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.handler.advice.ExpressionEvaluatingRequestHandlerAdvice;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.http.outbound.HttpRequestExecutingMessageHandler;
import org.springframework.integration.json.ObjectToJsonTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.messaging.support.ErrorMessage;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.LOGGING_RESPONSE_INPUT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.LoggerUtils.getAlertMessage;

@Configuration
@Component
@Slf4j
public class StateServiceIntegrationFlows {

    @Autowired
    private WorkflowRoutingSlip workflowRoutingSlip;

    @Value("${application.config.state-service.base-url}")
    private String stateApiBaseUrl;

    @Autowired
    @Qualifier("workflowStateServiceRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("workflowExecutionCreateStateErrorHandlerAdvice")
    private Advice createStateErrorHandlerAdvice;

    @Autowired
    @Qualifier("workflowExecutionUpdateApplicationErrorHandlerAdvice")
    private Advice updateApplicationErrorHandlerAdvice;

    @Autowired
    @Qualifier("workflowExecutionCreateOrRetrieveApplicationErrorHandlerAdvice")
    private Advice createOrRetrieveApplicationErrorHandlerAdvice;

    @Autowired
    @Qualifier("workflowExecutionStateLogHttpResponseTimeAdvice")
    private Advice responseTimeAdvice;

    @Autowired(required = false)
    @Qualifier("parameterizedTypeReferenceMap")
    private Map<String, ParameterizedTypeReference<?>> parameterizedTypeReferenceMap;

    @Autowired
    private ObjectMapper objectMapper;

    @Bean
    public IntegrationFlow retrieveApplication() {
        return f -> f.log(LoggingHandler.Level.INFO, log.getName(), m -> StringUtils
                .prependIfMissing("Retrieving application from State Database",
                        LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                .handle(httpRequestExecutingMessageHandler(stateApiBaseUrl + "/applications/{flowId}", HttpMethod.GET,
                        GetApplicationResponse.class),
                        m -> m.advice(createOrRetrieveApplicationErrorHandlerAdvice)
                                .advice(responseTimeAdvice)).wireTap(WorkflowExecutionConstants.LOGGING_RESPONSE_INPUT)
                .enrichHeaders(spec -> spec.headerFunction(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                        m -> m.getHeaders()
                                .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)
                                .setRoutingSlip(SerializableUtils
                                        .deSerialize(((GetApplicationResponse) m.getPayload()).getWorkflowContext(),
                                                WorkflowContext.class).getRoutingSlip()).setResponseMap(
                                        getApplicationStateResponses(
                                                ((GetApplicationResponse) m.getPayload()).getStates())), true))
                .enrichHeaders(spec -> spec.headerFunction(ROUTING_SLIP_INDEX_HEADER, m -> new AtomicInteger(
                                m.getHeaders().get(WORKFLOW_CONTEXT_HEADER, WorkflowContext.class).findFailedRouteIndex()),
                        true)).enrichHeaders(spec -> spec.headerFunction(WORKFLOW_CONTEXT_HEADER,
                        m -> m.getHeaders().get(WORKFLOW_CONTEXT_HEADER, WorkflowContext.class).resetFailedRoute(),
                        true)).channel(WorkflowExecutionConstants.EXECUTE_WORKFLOW_ROUTE_STRATEGY_INPUT);
    }

    @Bean
    public IntegrationFlow createApplication(@Autowired CreateApplicationRequestMapper mapper) {
        return f -> f.log(LoggingHandler.Level.INFO, log.getName(), m -> StringUtils
                .prependIfMissing("Creating application in State Database",
                        LoggerUtils.getLogMsgPrefix(m.getHeaders()))).transform(Message.class, m -> mapper.map(m))
                .transform(Transformers.toJson())
                .handle(httpRequestExecutingMessageHandler(stateApiBaseUrl + "/applications", HttpMethod.POST,
                        CreateApplicationResponse.class),
                        m -> m.advice(createOrRetrieveApplicationErrorHandlerAdvice)
                                .advice(responseTimeAdvice)).wireTap(WorkflowExecutionConstants.LOGGING_RESPONSE_INPUT)
                .enrichHeaders(hspec -> hspec.headerFunction(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                        m -> m.getHeaders()
                                .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)
                                .populateFlowId(((CreateApplicationResponse) m.getPayload()).getFlowId()), true))
                .channel(WorkflowExecutionConstants.EXECUTE_WORKFLOW_ROUTE_STRATEGY_INPUT);
    }

    @Bean
    public IntegrationFlow updateApplication(@Autowired UpdateApplicationRequestMapper mapper) {
        return f -> f.log(LoggingHandler.Level.INFO, log.getName(), m -> StringUtils.prependIfMissing(
                String.format("Updating application in State Database for tempRefNo: '%s'",
                        m.getHeaders().get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)
                                .getFlowId()), LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                .transform(Message.class, m -> mapper.map(m)).transform(Transformers.toJson())
                .handle(httpRequestExecutingMessageHandler(stateApiBaseUrl + "/applications/{flowId}", HttpMethod.PATCH,
                        UpdateApplicationResponse.class),
                        m -> m.advice(updateApplicationErrorHandlerAdvice)
                                .advice(responseTimeAdvice))
                .channel(LOGGING_RESPONSE_INPUT);
    }

    @Bean
    public IntegrationFlow createApplicationState(@Autowired CreateApplicationStateRequestMapper mapper) {
        return f -> f.log(LoggingHandler.Level.INFO, log.getName(), m -> StringUtils.prependIfMissing(
                String.format("Creating application state for route '%s' in State Database for tempRefNo: " + "'%s'",
                        m.getHeaders().get(WORKFLOW_CONTEXT_HEADER, WorkflowContext.class).getRouteByIndex(
                                m.getHeaders().get(ROUTING_SLIP_INDEX_HEADER, AtomicInteger.class).get())
                                .getRequestChannel(),
                        m.getHeaders().get(WORKFLOW_CONTEXT_HEADER, WorkflowContext.class).getFlowId()),
                LoggerUtils.getLogMsgPrefix(m.getHeaders()))).transform(Message.class, m -> mapper.map(m))
                .transform(Transformers.toJson())
                .handle(httpRequestExecutingMessageHandler(stateApiBaseUrl + "/applications/{flowId}/states",
                        HttpMethod.POST, CreateApplicationStateResponse.class),
                        m -> m.advice(createStateErrorHandlerAdvice)
                                .advice(responseTimeAdvice))
                .channel(LOGGING_RESPONSE_INPUT);
    }

    @Bean
    public IntegrationFlow handleCreateOrRetrieveApplicationError(
            @Autowired @Qualifier("workflowExecutionOutputMapper") WorkflowMapper<WorkflowContext, Object> mapper) {
        return f -> f.transform(ErrorMessage.class, m -> {
            ExpressionEvaluatingRequestHandlerAdvice.MessageHandlingExpressionEvaluatingAdviceException ex =
                    (ExpressionEvaluatingRequestHandlerAdvice.MessageHandlingExpressionEvaluatingAdviceException) m
                            .getPayload();
            String tempRefNo = ex.getFailedMessage().getHeaders()
                    .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class).getFlowId();
            StringBuilder errorBuilder =
                    StringUtils.isBlank(tempRefNo) ? new StringBuilder("Creating application in State Database") :
                            new StringBuilder("Retrieving application from State Database for tempRefNo: '")
                                    .append(tempRefNo).append("'");
            String error = StringUtils.prependIfMissing(
                    String.format(errorBuilder.append(" failed with error: %s").toString(),
                            WorkflowUtils.getSpecificCause(m, MessageHandlingException.class).getCause().getMessage()),
                    LoggerUtils.getLogMsgPrefix(ex.getFailedMessage().getHeaders()));
            return MessageBuilder.withPayload(error).copyHeaders(ex.getFailedMessage().getHeaders()).build();
        }).<String>log(LoggingHandler.Level.ERROR, log.getName(),
                m ->  getAlertMessage(m.getHeaders(), Alert.STATE_API_CALL_FAILED, m.getPayload()).build()
        ).transform(Message.class, m -> mapper
                .map(m.getHeaders().get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)))
                .route(WorkflowExecutionSpel.DEFAULT_REPLY_CHANNEL);
    }

    @Bean
    public IntegrationFlow handleCreateStateError() {
        return f -> f.transform(ErrorMessage.class, m -> m.getPayload().getCause().getMessage())
                .<String>log(LoggingHandler.Level.ERROR, log.getName(),
                m ->  getAlertMessage(m.getHeaders(), Alert.STATE_API_CALL_FAILED, m.getPayload()).build()).nullChannel();
    }

    @Bean
    public IntegrationFlow handleUpdateApplicationError() {
        return f -> f.transform(ErrorMessage.class, m -> m.getPayload().getCause().getMessage())
                .<String>log(LoggingHandler.Level.ERROR, log.getName(),
                        m ->  getAlertMessage(m.getHeaders(), Alert.STATE_API_CALL_FAILED, m.getPayload()).build()).nullChannel();
    }

    private HttpRequestExecutingMessageHandler httpRequestExecutingMessageHandler(final String url,
                                                                                  final HttpMethod method,
                                                                                  final Class<?> expectedResponseType) {
        HttpRequestExecutingMessageHandler messageHandler =
                Http.outboundGateway(url, restTemplate).httpMethod(method).mappedRequestHeaders("*")
                        .mappedResponseHeaders(WorkflowExecutionConstants.EXPECTED_HTTP_RESPONSE_HEADERS)
                        .expectedResponseType(expectedResponseType).getObject();
        messageHandler.setUriVariableExpressions(Collections.singletonMap(WorkflowExecutionConstants.FLOW_ID_PARAM,
                new SpelExpressionParser().parseExpression(WorkflowExecutionSpel.GET_FLOW_ID_HEADER)));
        return messageHandler;
    }

    private Map<String, Map<Integer, Object>> getApplicationStateResponses(
            List<CreateApplicationStateResponse> states) {
        final Set<WorkflowRoutingSlip.Route> routes =
                workflowRoutingSlip.getRoutingSlip().entrySet().stream().map(entry -> entry.getValue())
                        .collect(Collectors.toSet());
        final Set<String> routesNameSet = routes.stream().map(r -> r.getRequestChannel()).collect(Collectors.toSet());
        final List<CreateApplicationStateResponse> filteredStates =
                states.stream().filter(s -> !HttpStatus.resolve(Integer.parseInt(s.getResponseStatus())).isError())
                        .filter(s -> routesNameSet.contains(s.getApplicationSubType())).collect(Collectors.toList());

        final Set<String> keySet =
                filteredStates.stream().map(s -> s.getApplicationSubType()).collect(Collectors.toSet());

        return routes.stream().filter(s -> keySet.contains(s.getRequestChannel())).collect(Collectors
                .toMap(WorkflowRoutingSlip.Route::getRequestChannel, route -> filteredStates.stream()
                        .filter(fs -> fs.getApplicationSubType().equals(route.getRequestChannel()))
                        .sorted(Comparator.comparing(CreateApplicationStateResponse::getReceiveTimestamp))
                        .map(stateResponse -> {
                            BaseResponse response =
                                    BaseResponse.builder().receiveTimestamp(stateResponse.getReceiveTimestamp())
                                            .build();
                            try {
                                response.setResponse(parseJson(stateResponse.getResponse(),
                                        Class.forName(route.getHttpExpectedResponseType())));
                            } catch (ClassNotFoundException ex) {
                                log.error("{} Could not load response type class while unmarshalling application state "
                                          + "response, type: {}, error: {}",
                                        ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG,
                                        route.getHttpExpectedResponseType(), ex.getMessage());
                                throw new WorkflowExecutionFailureException(
                                        WorkflowExecutionMessage.HTTP_REQUEST_EXECUTING_MESSAGE_HANDLER.getMessage(),
                                        ex.getCause());
                            }
                            return response;
                        }).collect(Collectors.collectingAndThen(Collectors.toList(),
                                l -> IntStream.range(0, l.size()).mapToObj(index -> index)
                                        .collect(Collectors.toMap(index -> index, index -> l.get(index)))))));
    }

    private <T> T parseJson(String json, Class<T> type) {
        try {
            return objectMapper.readValue(json, type);
        } catch (JsonProcessingException exception) {
            log.error("{} Parsing json for type={} failed with error", ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG,
                    type, exception);
        }
        return null;
    }

    private <T> T parseJson(String json, TypeReference<T> typeRef) {
        try {
            return objectMapper.readValue(json, typeRef);
        } catch (JsonProcessingException exception) {
            log.error("{} Parsing json for type={} failed with error", ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG,
                    typeRef, exception);
        }
        return null;
    }
}
