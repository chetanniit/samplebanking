package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum OccupationCode {
    ACADEMIC_STAFF("AS", "Academic Staff"),
    AGRICULTURAL_WORKERS_GENERAL("AG", "Agricultural workers general"),
    FARM_MANAGEMENT_GENERAL("FM", "farm management general"),
    HM_FORCES_OFFICERS("OF", "HM forces officers"),
    HM_FORCES_OTHER_RANKS("OR", "HM forces other ranks"),
    HOME_FAMILY_RESPONSIBILITIES("HF", "Home family responsibilities"),
    JUNIOR_MANAGEMENT("MJ", "Junior Management"),
    MANUAL("UM", "Manual"),
    OFFICE_AND_CLERICAL("OC", "Office and clerical"),
    PROFESSIONALS("PR", "Professionals"),
    RETIRED("RT", "Retired"),
    SALES("SA", "SALES"),
    SELF_EMPLOYED("SE", "Self Employed"),
    SEMI_PROFESSIONALS("PM", "Semi Professionals"),
    SEMI_SKILLED("SS", "Semi Skilled"),
    SENIOR_MANAGEMENT("MS", "Senior Management"),
    SERVICE_JOBS("SR", "Service Jobs"),
    SKILLED_MANUAL("SK", "Skilled Manual"),
    STUDENT("ST", "Student"),
    SUPERVISORY_FOREMAN("SU", "Supervisory Foreman"),
    TEACHERS("TC", "Teachers"),
    TECHNICIANS("TH", "Technicians"),
    UNEMPLOYED("UN", "Unemployed");

    private String key;

    private String value;


    public static String mapToGMSValue(final String fmaValue) {
        return valueOf(fmaValue).key;
    }


    @Override
    public String toString() {
        return name();
    }
}
