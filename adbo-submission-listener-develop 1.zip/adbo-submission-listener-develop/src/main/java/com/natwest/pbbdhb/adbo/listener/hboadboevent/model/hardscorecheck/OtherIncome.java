package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.IncomeFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.OtherIncomeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OtherIncome {
    private OtherIncomeType type;
    private IncomeFrequency frequency;
    private BigInteger amount;
}
