package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.StartDateConstraint;
import com.natwest.pbbdhb.openapi.Employment;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;

public class StartDateValidator implements ConstraintValidator<StartDateConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || isNull(employment.getEmploymentStatus()) || !employment.getEmploymentStatus()
                .equals(Employment.EmploymentStatusEnum.EMPLOYED) || StringUtils.isNotBlank(employment.getStartDate());
    }
}
