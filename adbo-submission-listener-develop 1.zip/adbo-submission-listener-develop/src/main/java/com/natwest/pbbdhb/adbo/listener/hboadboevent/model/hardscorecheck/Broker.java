package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Broker {
    private String fcaNumber;
    private String firmName;
    private String firmPostcode;
    private String brokerSurname;
    private String brokerForename;
    private String brokerPostcode;
    private String brokerAddress;
    private String brokerEmail;
    private String paymentPathName;

}

