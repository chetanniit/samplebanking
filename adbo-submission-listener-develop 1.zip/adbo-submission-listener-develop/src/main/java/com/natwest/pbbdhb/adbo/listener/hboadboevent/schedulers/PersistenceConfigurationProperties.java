package com.natwest.pbbdhb.adbo.listener.hboadboevent.schedulers;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotNull;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "brand")
@Validated
@Setter
@Getter
public class PersistenceConfigurationProperties {

    // brand.datasource.xxx properties
    @NotNull
    private Map<String, Map<String, String>> dataSource;

    // brand.hikari properties
    private Map<String, String> hikari;
}
