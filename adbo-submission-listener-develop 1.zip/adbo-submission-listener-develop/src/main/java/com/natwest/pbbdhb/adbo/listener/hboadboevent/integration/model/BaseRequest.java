package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BaseRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    private Object request;
    private LocalDateTime sendTimestamp;
}
