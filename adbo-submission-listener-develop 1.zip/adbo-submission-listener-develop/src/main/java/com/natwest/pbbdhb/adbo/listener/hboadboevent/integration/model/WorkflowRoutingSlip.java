package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Configuration
@ConfigurationProperties(prefix = "workflow.execution")
@Validated
@Data
@Slf4j
public class WorkflowRoutingSlip {
    private final Map<Integer, Route> routingSlip = new HashMap<>();

    @Data
    public static class Route implements Cloneable, Serializable {
        private static final long serialVersionUID = 1L;
        @NotBlank
        private String requestChannel;
        private String conditionExpression;
        private String loopExpression;
        private String loopConditionExpression;
        private AtomicInteger count = new AtomicInteger();
        private String httpRequestMapperType;
        @NotBlank
        private String httpUrl;
        private Map<String, String> httpUriParameters = new HashMap<>();
        @NotBlank
        private String httpMethod;
        @NotBlank
        private String httpExpectedResponseType;
        private Map<Integer, HttpStatus> httpStatus = new HashMap<>();
        private String failSafeExpression;
        private Map<Integer, Boolean> failSafeResult = new HashMap<>();
        private Map<Integer, Object> errorResponse = new HashMap<>();
        private String retryOnFailureExpression;
        private String retryPolicyExpression;
        private int retryPolicyMaxAttempts;
        private long retryPolicyInitialInterval;
        private long retryPolicyMaxInterval;
        private double retryPolicyMultiplier;
        private String delayExpression;
        private boolean deprecated;

        @Override
        public Object clone() {
            Route route = new Route();
            route.setRequestChannel(this.requestChannel);
            route.setConditionExpression(this.conditionExpression);
            route.setLoopExpression(this.loopExpression);
            route.setLoopConditionExpression(this.loopConditionExpression);
            route.setCount(new AtomicInteger());
            route.setHttpRequestMapperType(this.httpRequestMapperType);
            route.setHttpUrl(this.httpUrl);
            route.setHttpUriParameters(this.httpUriParameters);
            route.setHttpMethod(this.httpMethod);
            route.setHttpExpectedResponseType(this.httpExpectedResponseType);
            route.setHttpStatus(new HashMap<>());
            route.setFailSafeExpression(this.failSafeExpression);
            route.setFailSafeResult(new HashMap<>());
            route.setErrorResponse(new HashMap<>());
            route.setRetryOnFailureExpression(this.retryOnFailureExpression);
            route.setRetryPolicyExpression(this.retryPolicyExpression);
            route.setRetryPolicyMaxAttempts(this.retryPolicyMaxAttempts);
            route.setRetryPolicyInitialInterval(this.retryPolicyInitialInterval);
            route.setRetryPolicyMaxInterval(this.retryPolicyMaxInterval);
            route.setRetryPolicyMultiplier(this.retryPolicyMultiplier);
            route.setDelayExpression(this.delayExpression);
            log.debug("Cloned the route={}", route.getRequestChannel());
            return route;
        }
    }
}
