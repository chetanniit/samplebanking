package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import lombok.Data;

@Data
public class GetCustomerAccountant implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private GetCustomerBaseAddress accountantAddress;
    private String telephoneNumber;
    private String faxNumber;
    private String qualification;
    private String emailAddress;
}
