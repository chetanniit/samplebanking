package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicantDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    private String firstNames;
    private String lastName;
    private String dateOfBirth;
    private String postCode;
    private BigDecimal netMonthlyIncome;
    private BigDecimal netAnnualIncome;
    private BureauData bureauData;
}
