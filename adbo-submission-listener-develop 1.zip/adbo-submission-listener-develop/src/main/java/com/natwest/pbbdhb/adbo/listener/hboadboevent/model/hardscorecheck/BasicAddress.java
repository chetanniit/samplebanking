package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BasicAddress {
    private String flat;
    private String houseName;
    private String houseNumber;
    private String street;
    private String district;
    private String town;
    private String county;
    private String postcode;
}
