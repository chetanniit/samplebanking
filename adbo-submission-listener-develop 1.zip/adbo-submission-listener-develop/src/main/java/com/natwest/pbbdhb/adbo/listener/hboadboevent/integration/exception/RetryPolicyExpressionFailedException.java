package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RetryPolicyExpressionFailedException extends RuntimeException {
    private String message;

    public RetryPolicyExpressionFailedException(String pMessage) {
        super(pMessage, new Throwable(pMessage));
        this.message = pMessage;
    }
}
