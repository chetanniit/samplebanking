package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.BusinessType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SelfEmployed {

    private BusinessType businessType;
    private LocalDate selfEmployedDateEstablished;
    private BigDecimal drawingsLatest;
    private BigDecimal drawingsPrevious;
    private BigDecimal dividendsLatest;
    private BigDecimal dividendsPrevious;
    private BigDecimal netProfitLatest;
    private BigDecimal netProfitPrevious;

}
