package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum BuyerType {
    FIRST_TIME_BUYER, NEW_CUSTOMER, EXISTING_CUSTOMER
}
