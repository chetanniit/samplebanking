package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerCreditBureauDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    private String seriousDefaultDetected;
    private String cmlDataDetected;
    private String electoralRoll;
    private Integer ccJsUnder3YearsNo;
    private BigDecimal ccJsUnder3YearsVal;
    private Integer ccJsOver3YearsNo;
    private BigDecimal ccJsOver3YearsVal;
    private Integer numberOfSearches;
    private LocalDate recentSearchDate;
    private String kycIdentityConfirmed;
    private String kycIdentityElecConfirmed;
    private String kycAddressConfirmed;
    private String kycAddressElecConfirmed;

    // named to match the GMS XML class so that MapStruct will generate the mapping
    public String getCMLDataDetected() {
        return cmlDataDetected;
    }

    public void setCMLDataDetected(final String inCmlDataDetected) {
        this.cmlDataDetected = inCmlDataDetected;
    }

    public Integer getCCJsUnder3YearsNo() {
        return ccJsUnder3YearsNo;
    }

    public void setCCJsUnder3YearsNo(final Integer inCcJsUnder3YearsNo) {
        this.ccJsUnder3YearsNo = inCcJsUnder3YearsNo;
    }

    public BigDecimal getCCJsUnder3YearsVal() {
        return ccJsUnder3YearsVal;
    }

    public void setCCJsUnder3YearsVal(final BigDecimal inCcJsUnder3YearsVal) {
        this.ccJsUnder3YearsVal = inCcJsUnder3YearsVal;
    }

    public Integer getCCJsOver3YearsNo() {
        return ccJsOver3YearsNo;
    }

    public void setCCJsOver3YearsNo(final Integer inCcJsOver3YearsNo) {
        this.ccJsOver3YearsNo = inCcJsOver3YearsNo;
    }

    public BigDecimal getCCJsOver3YearsVal() {
        return ccJsOver3YearsVal;
    }

    public void setCCJsOver3YearsVal(final BigDecimal inCcJsOver3YearsVal) {
        this.ccJsOver3YearsVal = inCcJsOver3YearsVal;
    }

    public String getKYCIdentityConfirmed() {
        return kycIdentityConfirmed;
    }

    public void setKYCIdentityConfirmed(final String inKycIdentityConfirmed) {
        this.kycIdentityConfirmed = inKycIdentityConfirmed;
    }

    public String getKYCIdentityElecConfirmed() {
        return kycIdentityElecConfirmed;
    }

    public void setKYCIdentityElecConfirmed(final String inKycIdentityElecConfirmed) {
        this.kycIdentityElecConfirmed = inKycIdentityElecConfirmed;
    }

    public String getKYCAddressConfirmed() {
        return kycAddressConfirmed;
    }

    public void setKYCAddressConfirmed(final String inKycAddressConfirmed) {
        this.kycAddressConfirmed = inKycAddressConfirmed;
    }

    public String getKYCAddressElecConfirmed() {
        return kycAddressElecConfirmed;
    }

    public void setKYCAddressElecConfirmed(final String inKycAddressElecConfirmed) {
        this.kycAddressElecConfirmed = inKycAddressElecConfirmed;
    }
}
