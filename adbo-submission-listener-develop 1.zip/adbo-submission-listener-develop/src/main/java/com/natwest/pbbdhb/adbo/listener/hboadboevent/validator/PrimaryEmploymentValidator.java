package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.PrimaryEmploymentConstraint;
import com.natwest.pbbdhb.openapi.Employment;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_FORMAT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_PATTERN;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.toLocalDate;

public class PrimaryEmploymentValidator implements ConstraintValidator<PrimaryEmploymentConstraint, List<Employment>> {

    @Override
    public boolean isValid(List<Employment> employments, ConstraintValidatorContext constraintValidatorContext) {
        return CollectionUtils.isEmpty(employments) || checkCurrentPrimary(employments);
    }

    private boolean checkCurrentPrimary(List<Employment> employments) {
        Set<Employment> currentEmployments = employments.stream()
                .filter(e -> Objects.nonNull(e.getEmploymentStatus()) && Objects.nonNull(e.getEmploymentType())
                             && Objects.nonNull(e.getOccupationCode()) && !e.getEmploymentStatus()
                        .equals(Employment.EmploymentStatusEnum.NOT_EMPLOYED) && (
                                     (StringUtils.isBlank(e.getEndDate()) && !e.getEmploymentType()
                                             .equals(Employment.EmploymentTypeEnum.CONTRACT)) || StringUtils
                                             .isBlank(e.getEndDate()) || !Pattern
                                             .matches(STANDARD_DATE_PATTERN, e.getEndDate()) || (
                                             e.getEmploymentType().equals(Employment.EmploymentTypeEnum.CONTRACT)
                                             && Objects.nonNull(e.getEndDate()) && toLocalDate(e.getEndDate(),
                                                     DateTimeFormatter.ofPattern(STANDARD_DATE_FORMAT))
                                                     .isAfter(LocalDate.now())))).collect(Collectors.toSet());
        return CollectionUtils.isEmpty(currentEmployments)
                || currentEmployments.stream().map(Employment::getPrimary).filter(Objects::nonNull)
                       .filter(primary -> primary).count() == 1;
    }

}
