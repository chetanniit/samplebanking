package com.natwest.pbbdhb.adbo.listener.hboadboevent.configuration;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.openapi.Application;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

import java.util.Optional;

@Slf4j
@Configuration
public class KafkaConsumerConfiguration {

    @Bean("kafkaTemplate")
    public KafkaTemplate<String, Object> kafkaTemplate(ProducerFactory<String, Object> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }

    @Bean("kafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory, CommonErrorHandler commonErrorHandler) {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.setCommonErrorHandler(commonErrorHandler);
        return factory;
    }

    @Bean
    public CommonErrorHandler kafkaErrorHandler() {
        DefaultErrorHandler result = new DefaultErrorHandler((rec, ex) -> {
            String caseId =
                    Optional.ofNullable(rec).map(ConsumerRecord::value).filter(Application.class::isInstance)
                            .map(Application.class::cast).map(Application::getCaseId).orElse(null);
            log.error("{} Receiving failed at listener for caseId [{}] with Error-{}",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, caseId, ex.getMessage());
        }, new FixedBackOff(0L, 0L));
        result.setLogLevel(KafkaException.Level.WARN);
        return result;
    }

}
