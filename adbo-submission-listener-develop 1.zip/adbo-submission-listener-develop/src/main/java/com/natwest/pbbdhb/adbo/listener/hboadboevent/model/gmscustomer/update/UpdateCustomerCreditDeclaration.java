package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerCreditDeclaration {
    private UpdateCustomerBankruptcyDetails bankruptcyDetails;
    private UpdateCustomerFailedToMakePaymentsDetails failedToMakePaymentsDetails;
    private UpdateCustomerCCJDetails ccjDetails;
    private UpdateCustomerCreditArrangementsDetails creditArrangementsDetails;
    private UpdateCustomerRefusedLoanDetails refusedLoanDetails;
    private UpdateCustomerDefaultedOnCreditAccountsDetails defaultedOnCreditAccountsDetails;
    private UpdateCustomerCreditBureauDetails creditBureauDetails;
}
