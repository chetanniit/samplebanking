package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerLandlord {
    private String name;
    private UpdateCustomerLandlordAddress landlordAddress;
    private String telephoneNumber;
    private String faxNumber;
    private BigDecimal monthlyPayment;
}
