package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class GetCustomerIncomeWithUnderwritingPercent implements Serializable {
    private static final long serialVersionUID = 1L;

    private String incomeType;
    private BigDecimal amount;
    private String frequency;
    private BigDecimal netAmount;
    private String netFrequency;
}
