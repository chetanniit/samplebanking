package com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ProofOfIdNotesTransformer extends AbstractNotesTransformer {
    private static final String VELOCITY_MODEL_ADBO_REQUEST = "adboRequest";
    private static final String GET_ROUTE = "getRoute";

    @Value("${application.config.velocity.template-path.proof-of-id-notes}")
    private String templatePath;

    @Override
    protected String getTemplatePath() {
        return templatePath;
    }

    @Override
    protected void preTransform(VelocityContext velocityContext, WorkflowContext wc) {
        super.preTransform(velocityContext, wc);
        velocityContext.put(VELOCITY_MODEL_ADBO_REQUEST, wc.getOriginalPayload());
        velocityContext.put(GET_ROUTE, ADBOUtils.getRoute);
    }
}
