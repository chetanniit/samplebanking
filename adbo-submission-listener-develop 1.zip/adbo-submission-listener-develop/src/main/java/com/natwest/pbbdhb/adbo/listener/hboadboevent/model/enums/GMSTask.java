package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum GMSTask {
    AUTOMATED_WORKFLOW("FAU"),
    AWAIT_FEES("CPZ"),
    CASE_OWNER_UPDATE("CAU"),
    GET_MTG_OPS_CASE_OWNER("T79"),
    KYC_CHECKS("AKY"),
    MANUAL_VAL_INSTRUCTION("AVO"),
    OUTSTANDING_DATA("CPD"),
    PRE_SCREEN_HUNTER_TASK("PRS"),
    R71("R71"),
    DAS("DAS");


    private final String code;

    @Override
    public String toString() {
        return code;
    }

    public String getCode() {
        return this.code;
    }

}
