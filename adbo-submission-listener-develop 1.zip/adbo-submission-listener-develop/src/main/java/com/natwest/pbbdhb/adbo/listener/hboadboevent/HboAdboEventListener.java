package com.natwest.pbbdhb.adbo.listener.hboadboevent;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.exception.HboADBOEventRetryException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.WorkflowExecutionFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.gateway.WorkflowExecutionGateway;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ADBOSubmissionResult;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ApplicationStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.CustomHeader;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.Alert;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.LoanPurpose;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.service.KafkaProducerService;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.model.CreateStateHboKafkaEventRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.service.StateApplicationService;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.Error;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.listener.ListenerExecutionFailedException;
import org.springframework.kafka.retrytopic.RetryTopicHeaders;
import org.springframework.kafka.retrytopic.SameIntervalTopicReuseStrategy;
import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.converter.KafkaMessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.AbstractMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.LoggerUtils.getAlertMessage;

@Slf4j
@Component
@RequiredArgsConstructor
public class HboAdboEventListener {
    private final WorkflowExecutionGateway messagingGateway;
    private final KafkaProducerService kafkaProducerService;
    private final StateApplicationService stateService;
    private final ObjectMapper objectMapper;
    @Autowired
    private PropertiesConfig config;
    @Autowired
    private Validator validator;

    @RetryableTopic(
            attempts = "${application.config.kafka.max-attempts}",
            kafkaTemplate = "kafkaTemplate",
            backoff = @Backoff(delayExpression = "${application.config.kafka.retry.backoff-delays}"),
            topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
            sameIntervalTopicReuseStrategy = SameIntervalTopicReuseStrategy.MULTIPLE_TOPICS,
            include = HboADBOEventRetryException.class,
            autoCreateTopics = "${application.config.kafka.retry.auto-create-topics}",
            retryTopicSuffix = ".retry",
            dltTopicSuffix = ".error"
    )
    @KafkaListener(
            topics = "${application.config.kafka.topics.in}",
            groupId = "${application.config.kafka.group-id}"
    )
    public void receive(@Payload Application message, @Headers KafkaMessageHeaders headers) throws
            HboADBOEventRetryException {
        log.info("Received message with caseReference: [{}] at [{}]", message.getCaseId(),
                LocalDateTime.ofInstant(Instant.ofEpochMilli(headers.get(KafkaHeaders.RECEIVED_TIMESTAMP, Long.class)),
                        TimeZone.getDefault().toZoneId()));
        final Map<String, Object> messageHeaders = buildMessageHeaders(message, headers);
        List<Error> validationErrors = getValidationErrors(message, message.getCaseId());
        if (!CollectionUtils.isEmpty(validationErrors)) {
            String brand = getBrand(message, headers);
            log.error(getAlertMessage(message,headers, Alert.DATA_VALIDATION_FAILED, validationErrors.toString()).build());
            kafkaProducerService.send(message.getCaseId(), ADBOSubmissionResult.builder().caseId(message.getCaseId())
                    .uiId(message.getUiId())
                    .loanPurpose(LoanPurpose.ADDITIONAL_BORROWING)
                    .applicationType(Application.ApplicationTypeEnum.RESIDENTIAL)
                    .userId(config.getXoUserid())
                    .brand(brand)
                    .channel(
                            Optional.ofNullable(message.getChannel()).map(Application.ChannelEnum::getValue).orElse(""))
                    .application(message)
                    .status(ApplicationStatus.CONTRACT_VALIDATION_ERROR).errors(validationErrors).build());
            return;
        }

        try {
            final ADBOSubmissionResult
                    result = (ADBOSubmissionResult) messagingGateway.process(message, messageHeaders);
            log.info("[{}] :: Processing status: {} with error: {}", message.getCaseId(),
                    result.getStatus(), result.getErrors());

            switch (result.getStatus()) {
                case HARDSCORE_DECLINED:
                case SUCCESSFUL:
                case RETRY_SUCCESSFUL:
                    kafkaProducerService.send(message.getCaseId(), result);
                    break;
                case FAILED:
                case RETRY_FAILED:
                    kafkaProducerService.send(message.getCaseId(), result);
                    triggerRetry(result, message.getCaseId());
                    break;
                case ACCEPTED:
                case PENDING:
                    triggerRetry(result, message.getCaseId());
                    break;
                default:
                    break;
            }
        } catch (WorkflowExecutionFailureException wex) {
            log.error(getAlertMessage(message, headers, Alert.WORKFLOW_EXECUTION_FAILED, wex.getMessage()).build());
            throw new ListenerExecutionFailedException(wex.getMessage(), wex);
        }
    }

    private String getBrand(Application message, KafkaMessageHeaders headers) {
        return Objects.nonNull(headers.get(CustomHeader.BRAND.getKafkaHeader()))
                ? headers.get(CustomHeader.BRAND.getKafkaHeader(), String.class)
                : StringUtils.isNotBlank(message.getBrand()) ? message.getBrand() : "nwb";
    }

    private List<Error> getValidationErrors(Application message, String id) {
        Set<ConstraintViolation<Application>> validations = validator.validate(message);
        if (!CollectionUtils.isEmpty(validations)) {
            List<Error> errors = validations.stream()
                    .map(cv -> Error.builder().message(cv.getPropertyPath().toString() + " " + cv.getMessage()).build())
                    .collect(Collectors.toList());
            log.error("{} [{}] :: The payload validation failed for caseId [{}] with validation errors={}",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, id, errors);
            return errors;
        }
        return Collections.emptyList();
    }

    @DltHandler
    public void handleDlt(@Payload Application message, @Headers KafkaMessageHeaders headers) {
        final String topic = new String((byte[]) headers.get(KafkaHeaders.ORIGINAL_TOPIC), StandardCharsets.UTF_8);
        log.info("Received message with case id [{}] in DLQ handler from DLQ topic [{}]",
                Optional.ofNullable(message).map(val -> val.getCaseId()).orElse(null), topic);
        log.error(getAlertMessage(message, headers, Alert.EVENT_RECEIVED_IN_DLT, Alert.EVENT_RECEIVED_IN_DLT.getSubtype()).build());
        try {
            final CreateStateHboKafkaEventRequest createStateHboKafkaEventRequest =
                    CreateStateHboKafkaEventRequest.builder()
                            .messageKey(headers.get(KafkaHeaders.RECEIVED_KEY, String.class))
                            .originalReceivedTimestamp(LocalDateTime.ofInstant(
                                    Instant.ofEpochMilli(headers.get(KafkaHeaders.RECEIVED_TIMESTAMP, Long.class)),
                                    TimeZone.getDefault().toZoneId()))
                            .topicName(topic)
                            .message(objectMapper.writeValueAsString(message))
                            .recoverable(Boolean.TRUE)
                            .build();
            stateService.createEvent(createStateHboKafkaEventRequest,
                    Objects.nonNull(headers.get(CustomHeader.BRAND.getKafkaHeader()))
                            ? headers.get(CustomHeader.BRAND.getKafkaHeader(), String.class) : "nwb");
        } catch (JsonProcessingException ex) {
            log.error(
                    "{} Error serializing hbo.adbo.pre.submission.event to JSON in DLT handler for message={}, "
                            + "error={}",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, message, ex.getMessage());
        }
    }

    private Map<String, Object> buildMessageHeaders(final Application message, final KafkaMessageHeaders headers) {
        String brand = getBrand(message, headers);
        String clientId = brand.equals("nwb") ? config.getClientIdNwb() : config.getClientIdRbs();
        Map<String, Object> messageHeaders =
                Stream.of(new AbstractMap.SimpleImmutableEntry<>(CustomHeader.BRAND.getMessageHeader(), brand),
                        new AbstractMap.SimpleImmutableEntry<>(CustomHeader.CASE_REFERENCE.getMessageHeader(),
                                message.getCaseId()),
                        new AbstractMap.SimpleImmutableEntry<>(CustomHeader.CHANNEL.getMessageHeader(),
                                Objects.nonNull(message.getChannel()) ? message.getChannel().name() :
                                        Application.ChannelEnum.INTERNET.name()),
                        new AbstractMap.SimpleImmutableEntry<>(CustomHeader.CLIENT_ID.getMessageHeader(),
                                clientId),
                        new AbstractMap.SimpleImmutableEntry<>(CustomHeader.USER_ID.getMessageHeader(),
                                config.getXoUserid()))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        final byte[] tempRefNo = headers.get(CustomHeader.TEMP_REF_NO.getKafkaHeader(), byte[].class);
        if (Objects.nonNull(tempRefNo)) {
            messageHeaders.put(CustomHeader.TEMP_REF_NO.getMessageHeader(),
                    new String(tempRefNo, StandardCharsets.UTF_8));
        }

        final byte[] retryAttempt = headers.get(RetryTopicHeaders.DEFAULT_HEADER_ATTEMPTS, byte[].class);
        if (Objects.nonNull(retryAttempt)) {
            messageHeaders.put(CustomHeader.RETRY_ATTEMPT.getMessageHeader(), new BigInteger(retryAttempt).intValue());
        }

        final byte[] retryTimestamp = headers.get(RetryTopicHeaders.DEFAULT_HEADER_BACKOFF_TIMESTAMP, byte[].class);
        if (Objects.nonNull(retryTimestamp)) {
            messageHeaders.put(CustomHeader.RETRY_TIMESTAMP.getMessageHeader(),
                    LocalDateTime.ofInstant(Instant.ofEpochMilli(new BigInteger(retryTimestamp).longValue()),
                            TimeZone.getDefault().toZoneId()));
        }

        return messageHeaders;
    }

    /**
     * DO NOT CHANGE THE BELOW MESSAGE FORMAT.
     * Value of 'tempRefNo' is extracted and added as a header to Kafka event for retry
     * attempts in ProducerInterceptor
     *
     * @param result an ADBOSubmissionResult object
     * @param id     a String id
     */
    private void triggerRetry(final ADBOSubmissionResult result, final String id) throws HboADBOEventRetryException {
        String error = String.format("[%s] :: Processing failed, will be sent to Retry Topic (if available)", id);
        final Throwable throwable = new Throwable(error);

        if (StringUtils.isNotBlank(result.getTempRefNo())) {
            error = new StringBuilder(error)
                    .append(" :: ")
                    .append("<tempRefNo>")
                    .append(result.getTempRefNo())
                    .append("</tempRefNo>")
                    .toString();
        }

        throw new HboADBOEventRetryException(error, throwable);
    }
}
