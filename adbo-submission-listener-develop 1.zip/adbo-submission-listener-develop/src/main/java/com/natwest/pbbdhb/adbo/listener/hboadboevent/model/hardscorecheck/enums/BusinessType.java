package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum BusinessType {
    SOLE_TRADER, PARTNERSHIP, LIMITED_COMPANY
}
