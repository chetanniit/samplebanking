package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum RepaymentStrategyType {

    MAIN_RESIDENCE("A", "Main residence"),
    NOT_MAIN_RESIDENCE("B", "Not Main Residence"),
    OTHER_MORTGAGE_PROPERTY("C", "Other Mortgaged property"),
    UNENCUMBERED_MAIN_RESIDENCE("D", "Unencumbered Property, main Residence"),

    /**
     * Deprecated since 07/03/2023. Use {@link RepaymentStrategyType#UNENCUMBERED_OTHER_PROPERTY}.
     */
    @Deprecated
    UNENCUMBERED_OTHER_TERRACED("E", "Unencumbered Property, other property"),

    UNENCUMBERED_OTHER_PROPERTY("E", "Unencumbered Property, other property"),
    STOCK_SHARES("F", "Stocks & Shares"),
    UNIT_TRUSTS("G", "Unit Trusts"),
    OEIC("H", "OEIC's"),
    ICVC("I", "ICVC"),
    PENSION("J", "Pension"),
    SAVING("K", "Saving"),
    OTHER_ASSETS("L", "Other Assets"),
    ENDOWMENT("M", "Endowment"),
    SALE_OF_PROPERTY("SP", "Sale of Property");

    private final String key;
    private final String value;

    @Override
    public String toString() {
        return name();
    }

}
