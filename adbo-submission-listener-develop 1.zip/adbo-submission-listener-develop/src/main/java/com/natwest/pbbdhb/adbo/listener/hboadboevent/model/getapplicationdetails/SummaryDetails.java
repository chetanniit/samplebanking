package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SummaryDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    private BigDecimal borrowingLimit;
    private BigDecimal generalInsurance;
    private BigDecimal typicalAPR;
    private BigDecimal totalAmountPayable;
    private BigDecimal totalChargeForCredit;
    private BigDecimal costPerAmountBorrowed;
    private BigDecimal retentionAmount;
    private BigDecimal releasedAmount;
    private BigDecimal maximumLoan;
    private BigDecimal ppp;
    private BigDecimal cashback;
    private BigDecimal debtConsolidation;
    private BigDecimal actualLTV;
    private String loyaltyBonusIndicator;
    private BigDecimal loyaltyBonus;
}
