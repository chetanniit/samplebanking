package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

public enum Status {

    //Found Failed Route and not a retry attempt
    //No routes executed yet (responseMap in workflowContext is empty)
    ACCEPTED,

    //Found Failed Route and a retry attempt
    PENDING,

    //No failed route and not a retry attempt
    //No failed route and a retry attempt
    SUCCESSFUL,

    //Found Failed Route after Hard score & No retry attempts left (all retry attempts failed)
    FAILED,

    //Incoming Data Validation Failed - product|Hard score failed
    DECLINED,

    //Found Failed Route including Hard score & No retry attempts left (all retry attempts failed)
    FAILED_BEFORE_SCORING,

    //Manual Keyed In cases -hard score done but failed in other route (after retry)
    MANUAL_KEY_IN
}
