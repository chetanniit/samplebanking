package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.CountryIsoToGmsCode;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CountryIsoToGmsCodeConstraint;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class CountryIsoToGmsCodeValidator implements ConstraintValidator<CountryIsoToGmsCodeConstraint, String> {
    @Override
    public boolean isValid(String countryIsoCode, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(countryIsoCode) || countryIsoCode.length() < 2
                || nonNull(CountryIsoToGmsCode.getCountryIsoToGmsCode(countryIsoCode));
    }

}
