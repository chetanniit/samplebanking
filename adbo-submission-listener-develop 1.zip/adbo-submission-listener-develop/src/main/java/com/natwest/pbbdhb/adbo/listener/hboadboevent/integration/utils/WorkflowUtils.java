package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.WorkflowExecutionFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpError;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpErrorResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums.WorkflowExecutionMessage;

import java.util.Collections;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.Alert;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.LoggerUtils;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.support.ErrorMessage;

public interface WorkflowUtils {

    static Message<?> getFailedMessage(ErrorMessage errorMessage) {
        Throwable cause = errorMessage.getPayload();
        while (cause != null && !MessagingException.class.isAssignableFrom(cause.getClass())) {
            cause = cause.getCause();
        }
        MessagingException ex = (MessagingException) cause;
        while (ex.getFailedMessage() instanceof ErrorMessage && MessagingException.class
                .isAssignableFrom(ex.getFailedMessage().getPayload().getClass())) {
            ex = (MessagingException) ex.getFailedMessage().getPayload();
        }
        return ex.getFailedMessage();
    }

    static <T> T getSpecificCause(ErrorMessage errorMessage, Class<T> exceptionClass) {
        Throwable cause = errorMessage.getPayload();
        while (cause != null && !exceptionClass.isInstance(cause)) {
            cause = cause.getCause();
        }
        return (T) cause;
    }

    static HttpErrorResponse buildHttpErrorResponse(HttpStatus status, Throwable throwable) {
        return HttpErrorResponse.builder().errors(Collections.singletonList(
                HttpError.builder().status(Integer.toString(status.value())).code(status.getReasonPhrase())
                        .message(throwable.getMessage()).build())).build();
    }

    static WorkflowExecutionFailureException toThrowable(Message failedMessage, Throwable throwable) {
        WorkflowContext workflowContext = failedMessage.getHeaders()
                .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class);
        String error = org.apache.commons.lang3.StringUtils
                .prependIfMissing(String.format("%s:: %s", Alert.WORKFLOW_EXECUTION_FAILED.code, WorkflowExecutionMessage.WORKFLOW_EXECUTION_ERROR_MESSAGE.getMessage()),
                        LoggerUtils.getLogMsgPrefix(failedMessage.getHeaders()));
        return new WorkflowExecutionFailureException(error, throwable, workflowContext);
    }
}
