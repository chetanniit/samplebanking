package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.LatestGreaterThanPreviousTradingYearConstraint;
import com.natwest.pbbdhb.openapi.SelfEmployed;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_YEAR_PATTERN;
import static java.util.Objects.isNull;

public class LatestGreaterThanPreviousTradingYearValidator
        implements ConstraintValidator<LatestGreaterThanPreviousTradingYearConstraint, SelfEmployed> {

    @Override
    public boolean isValid(SelfEmployed selfEmployed, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(selfEmployed) || StringUtils.isEmpty(selfEmployed.getLatestTradingYear()) || StringUtils
                .isEmpty(selfEmployed.getPreviousTradingYear()) || !Pattern
                .matches(STANDARD_YEAR_PATTERN, selfEmployed.getLatestTradingYear()) || !Pattern
                .matches(STANDARD_YEAR_PATTERN, selfEmployed.getPreviousTradingYear())
                || Integer.valueOf(selfEmployed.getLatestTradingYear())
                        .compareTo(Integer.valueOf(selfEmployed.getPreviousTradingYear())) > 0;
    }
}
