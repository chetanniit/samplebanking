package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.autoprocess.AutoProcessRequest;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class AutoProcessRequestMapper
        implements WorkflowMapper<WorkflowContext, AutoProcessRequest>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    public AutoProcessRequest map(WorkflowContext source) {
        return mapToAutoProcessRequest(source);
    }

    @Mappings({
            @Mapping(target = "userId", expression = "java(config.getXoUserid())"),
            @Mapping(target = "mortgageNumber", source = "source", qualifiedByName = "getMortgageNumber"),
            @Mapping(target = "applSeq", source = "source", qualifiedByName = "getApplicationSequenceNumber")})
    abstract AutoProcessRequest mapToAutoProcessRequest(WorkflowContext source);
}
