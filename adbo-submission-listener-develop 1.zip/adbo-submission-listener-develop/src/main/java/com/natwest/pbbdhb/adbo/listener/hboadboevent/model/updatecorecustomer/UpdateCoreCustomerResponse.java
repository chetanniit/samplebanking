package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateCoreCustomerResponse {

    private Boolean customerContactUpdated;

    private Boolean customerDetailsUpdated;

    private String responseStatus;

    private String errorMessage;

}
