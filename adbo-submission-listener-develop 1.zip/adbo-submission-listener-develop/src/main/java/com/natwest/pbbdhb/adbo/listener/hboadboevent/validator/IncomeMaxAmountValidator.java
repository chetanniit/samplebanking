package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.IncomeConversionFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.IncomeMaxAmountConstraint;
import com.natwest.pbbdhb.openapi.Income;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.MAXIMUM_INCOME_AMOUNT;
import static java.util.Objects.isNull;

public class IncomeMaxAmountValidator implements ConstraintValidator<IncomeMaxAmountConstraint, Income> {
    @Override
    public boolean isValid(Income income, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(income) || isNull(income.getFrequency()) || isNull(income.getAmount())
               || income.getAmount().compareTo(MAXIMUM_INCOME_AMOUNT) > 0 || amountValidForFrequency(income);

    }

    private boolean amountValidForFrequency(Income income) {
        switch (income.getFrequency()) {
            case BIANNUALLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(income.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.BIANNUALLY.getConversionFactor()))) >= 0;
            case QUARTERLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(income.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.QUARTERLY.getConversionFactor()))) >= 0;
            case FORTNIGHTLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(income.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.FORTNIGHTLY.getConversionFactor())))
                       >= 0;
            case FOUR_WEEKLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(income.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.FOUR_WEEKLY.getConversionFactor())))
                       >= 0;
            default:
                return true;
        }

    }
}
