package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.math.BigInteger;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SubAccountAccountSelection implements Serializable {
    private static final long serialVersionUID = 1L;
    private String subAccountNumber;
    private BigInteger accountIndex;
    private String productDescription;
    private String productCode;
    private int termYears;
    private int termMonths;
    private String loanPurposeCode;
    private String loanPurposeDescription;
    private String calculationType;
    private String regulatedAuthority;
    private String ported;
    private Calculation loanAmountCalculation;
    private Calculation borrowingLimitCalculation;
}
