package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.notes.TaskNote;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers.ProofOfIdNotesTransformer;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import lombok.Getter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

@Getter
@Mapper(componentModel = "spring")
public abstract class AddProofOfIdNotesRequestMapper extends AddNotesRequestMapper {
    @Autowired
    private ProofOfIdNotesTransformer proofOfIdNotesTransformer;

    @Mapping(target = "taskSequenceNumber", source = "source", qualifiedByName = "getTaskSeqNumberForProofOfIdNotes")
    @Mapping(target = "note", source = "source", qualifiedByName = "getProofOfIdNotes")
    abstract TaskNote mapToTaskNotes(WorkflowContext source);

    @Named(value = "getTaskSeqNumberForProofOfIdNotes")
    String getTaskSeqNumberForProofOfIdNotes(WorkflowContext context) {
        return ADBOWorkflowUtils.getTaskSeqNumberForGeneralNotes(context);
    }

    @Named(value = "getProofOfIdNotes")
    String getProofOfIdNotes(WorkflowContext context) {
        return proofOfIdNotesTransformer.transform(context);
    }
}
