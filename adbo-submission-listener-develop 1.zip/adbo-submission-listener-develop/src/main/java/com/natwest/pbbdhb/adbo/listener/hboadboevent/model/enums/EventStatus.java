package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

public enum EventStatus {
    SUCCESSFUL,
    RETRY_SUCCESSFUL,
    RETRY_FAILED,
    MANUAL_KEY_IN
}
