package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateApplicationResponse {
    private String flowId;
    private String refId;
    private String additionalRefId;
    private String applicationType;
    private String refType;
    private String request;
    private String channel;
    private String response;
    private String responseStatus;
    private List<CreateApplicationStateResponse> states;
    private Integer retryCount;
    private String retryStatus;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime retryTimestamp;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime kafkaTimestamp;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime mopsTimestamp;
}
