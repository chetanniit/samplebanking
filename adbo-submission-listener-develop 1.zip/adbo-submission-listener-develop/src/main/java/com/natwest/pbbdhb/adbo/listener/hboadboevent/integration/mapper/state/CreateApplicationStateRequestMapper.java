package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.state;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.CreateApplicationStateRequest;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
@Slf4j
public abstract class CreateApplicationStateRequestMapper
        implements WorkflowMapper<Message<?>, CreateApplicationStateRequest> {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public CreateApplicationStateRequest map(final Message<?> message) {
        final WorkflowContext context =
                message.getHeaders().get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class);
        final Integer index =
                message.getHeaders().get(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER, AtomicInteger.class)
                        .get();
        final WorkflowRoutingSlip.Route route = context.getRouteByIndex(index);
        CreateApplicationStateRequest req = Objects.isNull(context) || Objects.isNull(route) ? null
                : toCreateApplicationStateRequest(context, route);
        return req;
    }

    @Mappings({
            @Mapping(target = "applicationSubType", source = "route.requestChannel"),
            @Mapping(target = "request", expression = "java(getRequest(context, route))"),
            @Mapping(target = "response", expression = "java(getResponse(context, route))"),
            @Mapping(target = "responseStatus", expression = "java(getResponseStatus(route))"),
            @Mapping(target = "sendTimestamp", expression = "java(getSendTimestamp(context, route))"),
            @Mapping(target = "receiveTimestamp", expression = "java(getReceiveTimestamp(context, route))")
    })
    public abstract CreateApplicationStateRequest toCreateApplicationStateRequest(WorkflowContext context,
                                                                                  WorkflowRoutingSlip.Route route);

    @Named("getRequest")
    protected String getRequest(final WorkflowContext context, final WorkflowRoutingSlip.Route route) {
        return context.getRequestMap().get(route.getRequestChannel()).entrySet().stream()
                .filter(entryMap -> entryMap.getKey() == route.getCount().get())
                .map(entry -> entry.getValue())
                .map(BaseRequest.class::cast)
                .map(r -> r.getRequest())
                .map(Object::toString)
                .findFirst().orElse(null);
    }

    @Named("getSendTimestamp")
    protected LocalDateTime getSendTimestamp(final WorkflowContext context, final WorkflowRoutingSlip.Route route) {
        return context.getRequestMap().get(route.getRequestChannel()).entrySet().stream()
                .filter(entryMap -> entryMap.getKey() == route.getCount().get())
                .map(entry -> entry.getValue())
                .map(BaseRequest.class::cast)
                .map(r -> r.getSendTimestamp())
                .findFirst().orElse(null);
    }

    @Named("getResponseStatus")
    protected String getResponseStatus(final WorkflowRoutingSlip.Route route) {
        HttpStatus status = route.getHttpStatus().get(route.getCount().get());
        if (Objects.nonNull(status)) {
            return new Integer(status.value()).toString();
        }
        return null;
    }

    @Named("getResponse")
    protected String getResponse(final WorkflowContext context, final WorkflowRoutingSlip.Route route) {
        HttpStatus status = route.getHttpStatus().get(route.getCount().get());
        Map<Integer, ?> responseMap = (Objects.nonNull(status) && status.isError())
                ? route.getErrorResponse() : context.getResponseMap().get(route.getRequestChannel());

        Object response = Optional.ofNullable(responseMap)
                .filter(Objects::nonNull)
                .get()
                .entrySet()
                .stream()
                .filter(mapEntry -> mapEntry.getKey() == route.getCount().get())
                .map(entry -> entry.getValue())
                .findFirst()
                .map(BaseResponse.class::cast)
                .map(r -> r.getResponse())
                .orElse(null);
        if (Objects.nonNull(response)) {
            try {
                return objectMapper.writeValueAsString(response);
            } catch (Exception ex) {
                log.error("{} Exception converting Route response to json. error={}",
                        ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, ex.getMessage());
            }
        }
        return null;
    }

    @Named("getReceiveTimestamp")
    protected LocalDateTime getReceiveTimestamp(final WorkflowContext context, final WorkflowRoutingSlip.Route route) {
        HttpStatus status = route.getHttpStatus().get(route.getCount().get());
        Map<Integer, ?> responseMap = (Objects.nonNull(status) && status.isError())
                ? route.getErrorResponse() : context.getResponseMap().get(route.getRequestChannel());

        return Optional.ofNullable(responseMap)
                .filter(Objects::nonNull)
                .get()
                .entrySet()
                .stream()
                .filter(entryMap -> entryMap.getKey() == route.getCount().get())
                .map(entry -> entry.getValue())
                .map(BaseResponse.class::cast)
                .map(r -> r.getReceiveTimestamp())
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(null);
    }
}
