package com.natwest.pbbdhb.adbo.listener.hboadboevent.service;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.gateway.WorkflowExecutionGateway;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ADBOSubmissionResult;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ApplicationStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.model.PatchApplicationRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.service.StateApplicationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;

@Import(WorkflowExecutionGateway.class)
@Service
@Slf4j
@RequiredArgsConstructor
public class KafkaProducerService {
    @Value("${application.config.kafka.topics.out}")
    private String topic;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final StateApplicationService stateService;

    public void send(final String caseId, final ADBOSubmissionResult message) {
        CompletableFuture<SendResult<String, Object>> future =
                kafkaTemplate.send(topic, message.getTempRefNo(), message);

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                log.info("[{}] :: Sending message to topic: {} failed with error: {}", caseId, topic, ex.getMessage());
            } else {
                log.info("[{}] :: Sending message to topic: {} successful", caseId, topic);
                if (!message.getStatus().equals(ApplicationStatus.CONTRACT_VALIDATION_ERROR)) {
                    final PatchApplicationRequest request =
                            PatchApplicationRequest.builder().flowId(message.getTempRefNo()).kafkaTimestamp(
                                    LocalDateTime.ofInstant(
                                            Instant.ofEpochMilli(result.getRecordMetadata().timestamp()),
                                            TimeZone.getDefault().toZoneId())).build();
                    stateService.patchKafkaTimestamp(request, message.getBrand());
                }
            }
        });
    }
}
