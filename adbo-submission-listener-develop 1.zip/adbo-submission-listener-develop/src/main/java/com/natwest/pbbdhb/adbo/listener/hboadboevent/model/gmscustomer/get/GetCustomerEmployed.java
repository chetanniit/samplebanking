package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerEmployed implements Serializable {
    private static final long serialVersionUID = 1L;

    private String currentOrPrevious;
    private String employerName;
    private GetCustomerAddress employerAddress;
    private String natureOfBusiness;
    private String presentPosition;
    private String employmentType;
    private String employerStatus;
    private Integer yearsOfService;
    private Integer monthsOfService;
    private String employeeReferenceNo;
    private String contactName;
    private String position;
    private String telephoneNumber;
    private String deliveryPreference;
    private String faxNumber;
    private String emailAddress;
    private String employmentStatus;
    private LocalDate contractEndDate;
    private String occupation;
    private LocalDate startDate;
    private GetCustomerIncomeDetails incomeDetails;
}
