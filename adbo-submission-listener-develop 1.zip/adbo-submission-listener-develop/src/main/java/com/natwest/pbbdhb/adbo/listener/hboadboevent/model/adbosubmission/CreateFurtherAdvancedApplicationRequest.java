package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateFurtherAdvancedApplicationRequest {
    private String society;
    private String lookupData;
    private String lookupSet;
    private String userId;
    private String mortgage;
    private String linkedKFIApplSeq;
    private ApplicationGeneralDetails applicationGeneralDetails;
    private ServiceLevel serviceLevel;
    private LoanDetails loanDetails;
    private AssessableIncome assessableIncome;
    private SolicitorDetails solicitorDetails;
    private FeeDetails feeDetails;
    private PropertyDetails propertyDetails;
    private InsuranceDetails insuranceDetails;
    private TransactItems transactItems;
}
