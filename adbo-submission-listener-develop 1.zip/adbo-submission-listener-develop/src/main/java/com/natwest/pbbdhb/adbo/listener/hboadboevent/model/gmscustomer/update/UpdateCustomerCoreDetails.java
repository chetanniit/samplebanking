package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerCoreDetails {
    private String customerType;
    private String title;
    private String surname;
    private String foreNames;
    private String nationality;
    private String gender;
    private LocalDate dateOfBirth;
    private String niNumber;
    private String mailIndicator;
    private String maritalStatus;
    private String homeTelephone;
    private String workTelephone;
    private String emailAddress;
    private String mobilePhoneNumber;
    private String firstTimeLandlord;
}
