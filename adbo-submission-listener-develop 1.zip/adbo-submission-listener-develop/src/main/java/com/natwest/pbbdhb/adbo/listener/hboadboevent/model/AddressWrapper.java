package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper.BaseMapper;
import com.natwest.pbbdhb.openapi.EmploymentAddress;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AddressWrapper {

    private String flat;
    private String houseName;
    private String houseNumber;
    private String street;
    private String district;
    private String town;
    private String county;
    private String postcode;
    private String countryIsoCode;

    public AddressWrapper(EmploymentAddress address) {
        this.flat = address.getFlat();
        this.houseName = address.getHouseName();
        this.houseNumber = address.getHouseNumber();
        this.street = address.getStreet();
        this.district = address.getDistrict();
        this.town = address.getTown();
        this.county = address.getCounty();
        this.postcode = address.getPostcode();
        this.countryIsoCode = address.getCountryIsoCode();
    }

    public boolean isUkAddress() {
        return BaseMapper.isUkAddress(countryIsoCode);
    }

}
