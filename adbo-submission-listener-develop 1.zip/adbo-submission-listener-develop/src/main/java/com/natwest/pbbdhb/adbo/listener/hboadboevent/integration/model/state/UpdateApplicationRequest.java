package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateApplicationRequest {
    private String refId;
    private String refType;
    private String additionalRefId;
    private String response;
    private String responseStatus;
    private Integer retryCount;
    private String retryStatus;
    private LocalDateTime retryTimestamp;
    private byte[] workflowContext;
}
