package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Fee {
    private String feeCode;
    private String isHLC;
    private BigDecimal chargedAmount;
    private String feeAction;
    private String capitaliseHLCFee;
    private BigDecimal costAmount;
    private String policyNumber;

}
