package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationAdditionalBorrowing {
    private Integer termYears;
    private Integer termMonths;
    private Boolean repaymentVehicle;
    private BigDecimal repaymentCurrentValue;
    private Boolean mortgageBefore20thSept2015;
    private BigDecimal propertyValue;
    private Boolean hpiUsed;
    private List<Details> details;
    private List<SubAccount> subAccounts;

}
