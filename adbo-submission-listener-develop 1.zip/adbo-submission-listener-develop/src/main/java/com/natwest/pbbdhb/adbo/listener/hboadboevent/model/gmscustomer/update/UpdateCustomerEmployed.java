package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerEmployed {
    private String currentOrPrevious;
    private String employerName;
    private ContactAddress employerAddress;
    private String natureOfBusiness;
    private String presentPosition;
    private String employmentType;
    private String employerStatus;
    private Integer yearsOfService;
    private Integer monthsOfService;
    private String employeeReferenceNo;
    private String contactName;
    private String position;
    private String telephoneNumber;
    private String deliveryPreference;
    private String faxNumber;
    private String emailAddress;
    private String employmentStatus;
    private LocalDate contractEndDate;
    private String occupation;
    private LocalDate startDate;
    private UpdateCustomerIncomeDetails incomeDetails;
}
