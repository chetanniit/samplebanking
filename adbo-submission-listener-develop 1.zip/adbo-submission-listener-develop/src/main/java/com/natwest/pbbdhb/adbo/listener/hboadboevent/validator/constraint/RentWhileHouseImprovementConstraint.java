package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.RentWhileHouseImprovementValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;


@Documented
@Constraint(validatedBy = RentWhileHouseImprovementValidator.class)
@Target({PARAMETER, METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RentWhileHouseImprovementConstraint {
    String message() default
            " required applicants[].financialCommitments[] of type RENT_WHILE_HOUSE_IMPROVEMENTS when application"
            + ".borrowingDetails.additionalBorrowings[].reason is HOME_IMPROVEMENT "
            + "and application.borrowingDetails.additionalBorrowings[].livingElseWhereMoreThan6Months is true ";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
