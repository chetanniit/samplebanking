package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.SelfEmploymentConstraint;
import com.natwest.pbbdhb.openapi.Employment;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.openapi.Employment.EmploymentStatusEnum.SELF_EMPLOYED;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class SelfEmploymentValidator implements ConstraintValidator<SelfEmploymentConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || !SELF_EMPLOYED.equals(employment.getEmploymentStatus()) || nonNull(
                employment.getSelfEmployed());
    }
}
