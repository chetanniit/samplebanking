package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.IncomeConversionFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.OtherIncomeMaxAmountConstraint;
import com.natwest.pbbdhb.openapi.OtherIncome;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.MAXIMUM_INCOME_AMOUNT;
import static java.util.Objects.isNull;

public class OtherIncomeMaxAmountValidator implements ConstraintValidator<OtherIncomeMaxAmountConstraint, OtherIncome> {
    @Override
    public boolean isValid(OtherIncome otherIncome, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(otherIncome) || isNull(otherIncome.getFrequency()) || isNull(otherIncome.getAmount())
               || otherIncome.getAmount().compareTo(MAXIMUM_INCOME_AMOUNT) > 0 || amountValidForFrequency(otherIncome);

    }

    private boolean amountValidForFrequency(OtherIncome otherIncome) {
        switch (otherIncome.getFrequency()) {
            case BIANNUALLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(otherIncome.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.BIANNUALLY.getConversionFactor()))) >= 0;
            case QUARTERLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(otherIncome.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.QUARTERLY.getConversionFactor()))) >= 0;
            case FORTNIGHTLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(otherIncome.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.FORTNIGHTLY.getConversionFactor())))
                       >= 0;
            case FOUR_WEEKLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(otherIncome.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.FOUR_WEEKLY.getConversionFactor())))
                       >= 0;
            case MONTHLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(otherIncome.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.MONTHLY.getConversionFactor()))) >= 0;
            case WEEKLY:
                return MAXIMUM_INCOME_AMOUNT.compareTo(otherIncome.getAmount()
                        .multiply(BigDecimal.valueOf(IncomeConversionFrequency.WEEKLY.getConversionFactor()))) >= 0;
            default:
                return true;
        }

    }
}
