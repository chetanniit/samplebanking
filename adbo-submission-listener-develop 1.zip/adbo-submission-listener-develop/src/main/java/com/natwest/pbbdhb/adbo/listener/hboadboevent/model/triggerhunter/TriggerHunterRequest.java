package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.triggerhunter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TriggerHunterRequest {
    @NotBlank
    private String userId;
    @NotBlank
    private String mortgage;
    @NotBlank
    private String applSeq;
}
