package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum IcrTaxRate {
    ICR_HIGH,
    ICR_LOW
}
