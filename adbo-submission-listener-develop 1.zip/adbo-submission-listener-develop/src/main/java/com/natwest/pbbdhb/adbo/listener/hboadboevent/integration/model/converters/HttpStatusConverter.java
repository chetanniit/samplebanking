package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.converters;

import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@ConfigurationPropertiesBinding
public class HttpStatusConverter implements Converter<String, HttpStatus> {

    @Override
    public HttpStatus convert(String source) {
        if (source == null) {
            return null;
        }
        return HttpStatus.resolve(Integer.parseInt(source));
    }
}
