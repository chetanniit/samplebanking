package com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils.getHardScoreApplicationResponse;

@Component
public class TransactNotesTransformer extends AbstractNotesTransformer {
    private static final String VELOCITY_MODEL_HARD_SCORE_RESPONSE = "hardScoreResponse";

    @Value("${application.config.velocity.template-path.transact-notes}")
    private String templatePath;
    @Autowired
    private PropertiesConfig config;


    @Override
    protected String getTemplatePath() {
        return templatePath;
    }

    @Override
    protected void preTransform(VelocityContext velocityContext, WorkflowContext wc) {
        super.preTransform(velocityContext, wc);
        velocityContext
                .put(VELOCITY_MODEL_HARD_SCORE_RESPONSE,
                        Optional.ofNullable(getHardScoreApplicationResponse(wc)).get().orElse(null));
    }
}
