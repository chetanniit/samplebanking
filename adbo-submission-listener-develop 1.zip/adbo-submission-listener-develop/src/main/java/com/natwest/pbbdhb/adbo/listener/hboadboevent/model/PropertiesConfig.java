package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.math.BigInteger;

@Configuration
@ConfigurationProperties(prefix = "application.config")
@Data
public class PropertiesConfig {
    private String society;
    private String group;
    private String lookupData;
    private String lookupSet;
    private String advanceType;
    private String calculationType;
    private String xoUserid;
    private String newContract;
    private BigInteger solicitorId;
    private BigInteger solicitorIdRbs;
    private String payloadType;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String refIdExpression;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String refType;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String additionalRefIdExpression;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String statusExpression;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String channelExpression;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String applicationType;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String clientIdNwb;
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected String clientIdRbs;
    private boolean useHardcodedDecisionDate;
    private String hardcodedDecisionDate;

}
