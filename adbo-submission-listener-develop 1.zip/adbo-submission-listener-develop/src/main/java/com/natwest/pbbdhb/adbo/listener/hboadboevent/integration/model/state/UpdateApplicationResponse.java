package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateApplicationResponse {
    private String flowId;
}
