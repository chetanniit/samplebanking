package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.MortgageNewResidentialConstraint;
import com.natwest.pbbdhb.openapi.AdditionalBorrowing;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class MortgageNewResidentialValidator
        implements ConstraintValidator<MortgageNewResidentialConstraint, AdditionalBorrowing> {

    @Override
    public boolean isValid(AdditionalBorrowing additionalBorrowing,
                           ConstraintValidatorContext constraintValidatorContext) {
        return isNull(additionalBorrowing) || isNull(additionalBorrowing.getReason()) || !additionalBorrowing
                .getReason().equals(AdditionalBorrowing.ReasonEnum.HOUSE_PURCHASE) || nonNull(
                additionalBorrowing.getMortgageNewResidential());
    }
}
