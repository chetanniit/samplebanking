package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GetCustomerData implements Serializable {
    private static final long serialVersionUID = 1L;

    @Schema(description = "GMS id")
    private Long clientId;

    @Schema(description = "CIN")
    private String clientAlternateId;

    private GetCustomerCoreDetails coreDetails;

    private GetCustomerSupplementaryDetails supplementaryDetails;

    private GetCustomerCorrespondenceAddress correspondenceAddress;

    private GetCustomerOccupancyDetails currentOccupancyDetails;

    private GetCustomerPreviousOccupancyDetails previousOccupancyDetails;

    private GetCustomerCreditDeclaration creditDeclarations;

    private GetCustomerEmploymentDetails employmentDetails;

    private GetCustomerOtherIncome otherIncomeDetails;

    private GetCustomerExpenditureDetails expenditureDetails;

    private GetCustomerBankAccountDetails bankAccountDetails;

    private GetCustomerPropertyOwnershipDetails propertyOwnershipDetails;

    private GetCustomerAccountDetails accountDetails;
}
