package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.WorkStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Applicant {

    private String cin;
    private PersonalDetails personalDetails;
    private List<Address> addresses;
    private WorkStatus workStatus;
    private Integer intendedRetirementAge;
    private Employment employment;
    private List<OtherIncome> otherIncomes;
    private List<ExistingMortgage> existingMortgages;
    private List<CreditCard> creditCards;
    private List<Loan> loans;
    private List<FinancialCommitment> financialCommitments;
    private BankDetails mainBankDetails;
    private CreditHistory creditHistory;
    private FutureAffordability futureAffordability;

}
