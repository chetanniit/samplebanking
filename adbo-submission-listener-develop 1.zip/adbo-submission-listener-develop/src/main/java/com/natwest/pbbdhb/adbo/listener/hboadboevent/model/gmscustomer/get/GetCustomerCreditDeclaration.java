package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import lombok.Data;

@Data
public class GetCustomerCreditDeclaration implements Serializable {
    private static final long serialVersionUID = 1L;

    private GetCustomerBankruptcyDetails bankruptcyDetails;
    private GetCustomerFailedToMakePaymentsDetails failedToMakePaymentsDetails;
    private GetCustomerCCJDetails ccjDetails;
    private GetCustomerCreditArrangementsDetails creditArrangementsDetails;
    private GetCustomerRefusedLoanDetails refusedLoanDetails;
    private GetCustomerDefaultedOnCreditAccountsDetails defaultedOnCreditAccountsDetails;
    private GetCustomerCreditBureauDetails creditBureauDetails;


    // named to match the GMS XML class so that MapStruct will generate the mapping
    public GetCustomerCCJDetails getCCJDetails() {
        return ccjDetails;
    }

    public void setCCJDetails(final GetCustomerCCJDetails inCcjDetails) {
        this.ccjDetails = inCcjDetails;
    }
}
