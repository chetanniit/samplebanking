package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContactAddress implements Serializable {
    private static final long serialVersionUID = 1L;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String address5;
    private String addressPC;
    private String addressCountry;
}
