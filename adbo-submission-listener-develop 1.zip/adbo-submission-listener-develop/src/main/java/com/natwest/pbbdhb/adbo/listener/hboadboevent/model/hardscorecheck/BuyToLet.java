package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.IcrTaxRate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BuyToLet {

    private BigDecimal lettingAgentCost;
    private BigDecimal monthlyRentalIncome;
    private Boolean useLettingAgent;
    private IcrTaxRate icrTaxRate;

}
