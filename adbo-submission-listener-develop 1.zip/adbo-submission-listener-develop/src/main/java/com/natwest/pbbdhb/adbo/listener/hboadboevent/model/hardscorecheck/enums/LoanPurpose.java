package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PUBLIC)
public enum LoanPurpose {
    HOUSE_PURCHASE, REMORTGAGE, ADDITIONAL_BORROWING
}
