package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Alert {
    WORKFLOW_EXECUTION_FAILED("10001",  "WorkflowExecutionFailureException"),
    STATE_API_CALL_FAILED("10002",  "HttpCallFailureException"),
    DATA_VALIDATION_FAILED("10003", "ConstraintViolationException"),
    EVENT_RECEIVED_IN_DLT("10004", "ListenerExecutionFailedException");

    public final String code;
    public final String subtype;
}
