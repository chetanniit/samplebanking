package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.CreditCardType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreditCard {
    private CreditCardType type;
    private String provider;
    private BigDecimal totalBalance;
    private Boolean toBeRepaid;
    private Boolean debtConsolidation;
    private Integer partialRefinanced;

}
