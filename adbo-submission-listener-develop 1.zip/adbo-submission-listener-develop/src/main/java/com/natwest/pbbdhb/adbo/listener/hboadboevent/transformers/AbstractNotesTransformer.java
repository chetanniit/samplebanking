package com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.io.StringWriter;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG;

@Slf4j
public abstract class AbstractNotesTransformer {

    public static final String VELOCITY_MODEL_CARRIAGE_RETURN_CHARACTER_VALUE = "\r";
    private static final String VELOCITY_MODEL_CONTEXT = "context";
    private static final String VELOCITY_MODEL_CARRIAGE_RETURN_CHARACTER = "cr";
    @Autowired
    private VelocityEngine velocityEngine;

    private VelocityContext context;
    private Template template;

    @PostConstruct
    public void init() {
        log.info("Initializing Velocity Engine");
        velocityEngine.init();
        this.context = new VelocityContext();
        log.info("Creating Velocity Template for {}", getTemplatePath());
        this.template = velocityEngine.getTemplate(getTemplatePath());
    }

    protected abstract String getTemplatePath();

    protected void preTransform(VelocityContext velocityContext, WorkflowContext workflowContext) {
        velocityContext.put(VELOCITY_MODEL_CONTEXT, workflowContext);
        velocityContext.put(VELOCITY_MODEL_CARRIAGE_RETURN_CHARACTER, VELOCITY_MODEL_CARRIAGE_RETURN_CHARACTER_VALUE);
    }

    public String transform(WorkflowContext source) {
        log.debug("Started transforming Notes into GMS Notes, flow id={}", source.getFlowId());
        try {
            preTransform(context, source);
            StringWriter writer = new StringWriter();
            template.merge(context, writer);
            log.debug("Transformed Notes into GMS Notes with velocity template, result={}", writer);
            return writer.toString();
        } catch (RuntimeException ex) {
            log.error("{} Failed to transform Notes into GMS Notes : ", PREFIX_EXCEPTION_MSG_LOG, ex);
            throw ex;
        }
    }
}
