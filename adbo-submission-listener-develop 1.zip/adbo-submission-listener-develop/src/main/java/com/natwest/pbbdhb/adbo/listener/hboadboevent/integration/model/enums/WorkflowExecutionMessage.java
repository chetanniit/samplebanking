package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums;

public enum WorkflowExecutionMessage {
    WORKFLOW_EXECUTION_ERROR_MESSAGE("Workflow Execution Error: error occurred during workflow execution"),
    HTTP_REQUEST_EXECUTING_MESSAGE_HANDLER(
            "Workflow Execution Error: error creating object HttpRequestExecutingMessageHandler, could not resolve "
                    + "'expectedResponseType'"),
    APPLICATION_NOT_FOUND_MESSAGE(
            "Application and its details are not found for mrn=%s in state database OR skipped event processing");

    @SuppressWarnings("checkstyle:visibilitymodifier")
    public final String message;

    WorkflowExecutionMessage(String pMessage) {
        this.message = pMessage;
    }

    public String getMessage() {
        return this.message;
    }
}
