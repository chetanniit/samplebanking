package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ErrorResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<String> errors = null;
}
