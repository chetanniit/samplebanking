package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.MortgagePaymentsValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;


@Documented
@Constraint(validatedBy = MortgagePaymentsValidator.class)
@Target({PARAMETER, METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
public @interface MortgagePaymentsConstraint {
    String message() default
            "Required applicants[].financialCommitments[] of type MORTGAGE_PAYMENTS when application"
                    + ".borrowingDetails.additionalBorrowings[].reason is HOUSE_PURCHASE "
                    + "and application.borrowingDetails.additionalBorrowings[].mortgageNewResidential is true ";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
