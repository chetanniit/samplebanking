package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.AdditionalBorrowingReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdditionalBorrowing {
    private BigDecimal amount;
    private AdditionalBorrowingReason reason;
}
