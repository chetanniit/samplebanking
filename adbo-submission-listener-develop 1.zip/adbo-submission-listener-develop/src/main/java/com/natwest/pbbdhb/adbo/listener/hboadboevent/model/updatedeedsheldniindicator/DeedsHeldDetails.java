package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatedeedsheldniindicator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DeedsHeldDetails {
    private String deedsHeld;
}
