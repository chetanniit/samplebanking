package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ProductValidateRequest {
    private String productCode;
    private String productSearchDate;
    private String productTerm;
    private BigDecimal mortgageAmount;
    private BigDecimal ltv;
    private String applicationType;
    private String customerType;
    private String mortgageType;
    private String productType;
    private String repaymentType;
    private List<GMSProductFee> fees;
    private BigDecimal propertyValue;
    private Boolean isCashbackProduct;
    private Boolean freeLegal;
}
