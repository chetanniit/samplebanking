package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerBankAccount {
    private BigInteger bankSortCode;
    private String bankAccountName;
    private Long bankAccountNumber;
    private Integer yearsWithBank;
    private Integer monthsWithBank;
    private String chequeGuaranteeCard;
}
