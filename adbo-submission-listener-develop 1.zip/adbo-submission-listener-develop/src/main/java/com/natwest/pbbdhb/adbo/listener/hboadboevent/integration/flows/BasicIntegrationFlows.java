package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.flows;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionSpel;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.LoggerUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.json.ObjectToJsonTransformer;
import org.springframework.integration.routingslip.RoutingSlipRouteStrategy;
import org.springframework.integration.transformer.support.RoutingSlipHeaderValueMessageProcessor;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;


@Configuration
@Component
@Slf4j
public class BasicIntegrationFlows {

    @Autowired
    private WorkflowRoutingSlip workflowRoutingSlip;

    @Bean
    public DirectChannel workflowExecutionError() {
        return new DirectChannel();
    }

    @Bean
    public IntegrationFlow workflowInitialize() {
        return f -> f
                .log(LoggingHandler.Level.INFO, log.getName(),
                        m -> StringUtils.prependIfMissing("Initializing workflow execution",
                                LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                .enrichHeaders(spec -> spec.headerFunction(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                                m -> WorkflowContext.builder()
                                        .originalPayload(m.getPayload())
                                        .originalHeaders(m.getHeaders())
                                        .routingSlip(workflowRoutingSlip.getRoutingSlip().entrySet().stream().collect(
                                                Collectors
                                                        .toMap(Map.Entry::getKey,
                                                                e -> (WorkflowRoutingSlip.Route) e.getValue().clone())))
                                        .flowId(m.getHeaders().get(WorkflowExecutionConstants.FLOW_ID_HEADER,
                                                String.class))
                                        .currentAttempt(Optional.ofNullable(m.getHeaders()
                                                .get(WorkflowExecutionConstants.RETRY_COUNT_HEADER, Integer.class))
                                                .orElse(1))
                                        .requestMap(new HashMap<>())
                                        .responseMap(new HashMap<>()).build(), true)
                        .headerFunction(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER, h -> new AtomicInteger()))
                .route(WorkflowExecutionSpel.IS_FLOW_ID_EXIST_IN_MESSAGE_HEADER, r -> r
                        .channelMapping(true, WorkflowExecutionConstants.RETRIEVE_APPLICATION_STATE_INPUT)
                        .channelMapping(false, WorkflowExecutionConstants.CREATE_APPLICATION_INPUT));
    }

    @Bean
    public IntegrationFlow executeWorkflowRouteStrategy(
            @Autowired @Qualifier("WorkflowExecutionRouteStrategy") RoutingSlipRouteStrategy routeStrategy) {
        return f -> f.enrichHeaders(hspec -> hspec.header(IntegrationMessageHeaderAccessor.ROUTING_SLIP,
                new RoutingSlipHeaderValueMessageProcessor(routeStrategy)));
    }

    @Bean
    public IntegrationFlow resolveFailSafe() {
        return f -> f
                .log(LoggingHandler.Level.ERROR, log.getName(),
                        m -> StringUtils.prependIfMissing(
                                String.format("Execution of route '%s' failed",
                                        m.getHeaders().get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                                                        WorkflowContext.class)
                                                .getRouteByIndex(m.getHeaders().get(
                                                        WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER,
                                                        AtomicInteger.class).get())
                                                .getRequestChannel()),
                                LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                .routeToRecipients(rs -> rs
                        .applySequence(true)
                        .recipient(WorkflowExecutionConstants.CREATE_APPLICATION_STATE_INPUT)
                        .recipientFlow(rf -> rf.route(WorkflowExecutionSpel.IS_ROUTE_FAIL_SAFE, r -> r
                                .subFlowMapping(true, sf -> sf
                                        .log(LoggingHandler.Level.INFO, log.getName(),
                                                m -> StringUtils.prependIfMissing(
                                                        String.format("Route '%s' is fail safe",
                                                                m.getHeaders().get(
                                                                                WorkflowExecutionConstants.
                                                                                        WORKFLOW_CONTEXT_HEADER,
                                                                                WorkflowContext.class)
                                                                        .getRouteByIndex(m.getHeaders().get(
                                                                                WorkflowExecutionConstants.
                                                                                        ROUTING_SLIP_INDEX_HEADER,
                                                                                AtomicInteger.class).get())
                                                                        .getRequestChannel()),
                                                        LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                                        .channel(WorkflowExecutionConstants.EXECUTE_WORKFLOW_ROUTE_STRATEGY_INPUT))
                                .subFlowMapping(false, sf -> sf
                                        .log(LoggingHandler.Level.INFO, log.getName(),
                                                m -> StringUtils.prependIfMissing(
                                                        String.format("Route '%s' is NOT fail safe",
                                                                m.getHeaders().get(
                                                                                WorkflowExecutionConstants.
                                                                                        WORKFLOW_CONTEXT_HEADER,
                                                                                WorkflowContext.class)
                                                                        .getRouteByIndex(m.getHeaders().get(
                                                                                WorkflowExecutionConstants.
                                                                                        ROUTING_SLIP_INDEX_HEADER,
                                                                                AtomicInteger.class).get())
                                                                        .getRequestChannel()),
                                                        LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                                        .channel(WorkflowExecutionConstants.WORKFLOW_EXECUTION_OUTPUT_INPUT)))));
    }

    @Bean
    public IntegrationFlow workflowExecutionOutput(@Autowired @Qualifier("workflowExecutionOutputMapper")
                                                           WorkflowMapper<WorkflowContext, Object> mapper) {
        return f -> f
                .log(LoggingHandler.Level.INFO, log.getName(), m ->
                        StringUtils.prependIfMissing(
                                String.format("Workflow execution %s",
                                        Objects.isNull(m.getHeaders().get(
                                                WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                                                WorkflowContext.class).findFailedRoute())
                                                ? "successful" : "failed"),
                                LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                .transform(Message.class, m -> mapper.map(m.getHeaders().get(
                        WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)))
                .routeToRecipients(rspec -> rspec
                        .applySequence(true)
                        .recipient(WorkflowExecutionConstants.UPDATE_APPLICATION_INPUT)
                        .recipientFlow(rf -> rf.route(WorkflowExecutionSpel.DEFAULT_REPLY_CHANNEL)));
    }

    @Bean
    public IntegrationFlow loggingHttpResponse() {
        return f -> f.log(LoggingHandler.Level.DEBUG, WorkflowExecutionConstants.REST_TEMPLATE_LOGGING_CATEGORY,
                m -> new ObjectToJsonTransformer().transform(m).getPayload())
                .nullChannel();
    }

}
