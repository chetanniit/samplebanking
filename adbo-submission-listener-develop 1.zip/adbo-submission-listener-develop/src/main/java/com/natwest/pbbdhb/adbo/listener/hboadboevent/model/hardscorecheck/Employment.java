package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.IndustryType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.OccupationCode;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.EmploymentStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.EmploymentType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.PaymentFrequency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Employment {
    private Boolean primary;
    private EmploymentStatus employmentStatus;
    private EmploymentType employmentType;
    private OccupationCode occupationCode;
    private IndustryType industryType;
    private LocalDate startDate;
    private LocalDate endDate;
    private List<Income> incomes;
    private PaymentFrequency paymentFrequency;
    private SelfEmployed selfEmployed;
}
