package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@Getter
public enum IncomeConversionFrequency {

    ANNUALLY(1, "ANNUALLY"),
    BIANNUALLY(2, "BIANNUALLY"),
    QUARTERLY(4, "QUARTERLY"),
    FORTNIGHTLY(26, "FORTNIGHTLY"),
    FOUR_WEEKLY(13, "FOUR_WEEKLY"),
    MONTHLY(12, "MONTHLY"),
    WEEKLY(52, "WEEKLY");

    private int conversionFactor;
    private String value;

    private static final Map<String, IncomeConversionFrequency> BY_VALUE_MAP = new HashMap<>();

    static {
        for (IncomeConversionFrequency icf : values()) {
            BY_VALUE_MAP.put(icf.getValue(), icf);
        }
    }

    public static IncomeConversionFrequency getIncomeConversionFrequency(String value) {
        return BY_VALUE_MAP.get(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
