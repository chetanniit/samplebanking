package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerCreditBureauDetails {
    private String seriousDefaultDetected;
    private String cmlDataDetected;
    private String electoralRoll;
    private Integer ccJsUnder3YearsNo;
    private BigDecimal ccJsUnder3YearsVal;
    private Integer ccJsOver3YearsNo;
    private BigDecimal ccJsOver3YearsVal;
    private Integer numberOfSearches;
    private LocalDate recentSearchDate;
    private String kycIdentityConfirmed;
    private String kycIdentityElecConfirmed;
    private String kycAddressConfirmed;
    private String kycAddressElecConfirmed;
}
