package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ProductValidateResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private String productCode;
    private Boolean validProduct;
    private List<GMSProductFee> fees;
}
