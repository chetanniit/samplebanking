package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerMortgageDetails {
    private String accountNo;
    private BigDecimal monthlyRepayment;
    private BigDecimal currentBalance;
    private String toBeRedeemed;
    private LocalDate mortgageStartDate;
}
