package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.ADBOTotalAmountConstraint;
import com.natwest.pbbdhb.openapi.BorrowingDetails;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Optional;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class ADBOTotalAmountValidator implements ConstraintValidator<ADBOTotalAmountConstraint, BorrowingDetails> {

    @Override
    public boolean isValid(final BorrowingDetails borrowingDetails,
                           final ConstraintValidatorContext constraintValidatorContext) {

        final int minAmount = 10000;
        final int maxAmount = 500000;

        if (isNull(borrowingDetails)) {
            return true;
        }
        BigDecimal sum = Optional.ofNullable(borrowingDetails.getAdditionalBorrowings()).orElse(new ArrayList<>())
                .stream()
                .map(ab -> nonNull(ab.getAmount()) ? ab.getAmount() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return sum.compareTo(BigDecimal.valueOf(minAmount)) >= 0 && sum.compareTo(BigDecimal.valueOf(maxAmount)) <= 0;
    }
}
