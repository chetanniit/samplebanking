package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.PropertyType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BasicProperty {
    private BasicAddress address;
    private PropertyType type;
    private String numberBedrooms;
}
