package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonTypesOtherName {
    private String type;
    private String title;
    private String initials;
    private String foreNames;
    private String middleNames;
    private String surname;
    private String fullName;
    private LocalDate effectiveFrom;
    private LocalDate effectiveTo;
}
