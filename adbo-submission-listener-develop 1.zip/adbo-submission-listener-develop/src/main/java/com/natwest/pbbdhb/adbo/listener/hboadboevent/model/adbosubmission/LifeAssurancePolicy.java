package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LifeAssurancePolicy {
    private String policyType;
    private String insCompanyCode;
    private String insCompanyName;
    private String policyReference;
    private LocalDate policyStartDate;
    private String assignment;
    private LocalDate maturityDate;
    private String lifeAssured1;
    private String lifeAssured2;
    private String lifeAssured3;
    private String lifeAssured4;
    private BigDecimal minimumGuaranteedDeathBenefit;
    private BigDecimal premiumAmount;
}
