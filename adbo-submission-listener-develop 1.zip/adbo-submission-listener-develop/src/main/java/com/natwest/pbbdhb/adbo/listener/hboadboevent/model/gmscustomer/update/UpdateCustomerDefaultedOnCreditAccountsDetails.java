package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerDefaultedOnCreditAccountsDetails {
    private String answer;
    private Integer noOfCreditAccounts;
    private Integer noOfCreditDefaults;
    private Integer noOfMonthsArrears6Months;
    private Integer noOfMonthsArrears12Months;
    private Integer noOfMonthsArrears24Months;
    private BigDecimal totValCreditAccounts;
    private BigDecimal totMonthlyPaymentCreditAccounts;
    private String ivAs;
    private String ivAsCleared;
    private LocalDate latestIVAStartDate;
    private String hasDebtReliefOrders;
    private String debtReliefOrdersCleared;
    private LocalDate debtReliefOrdersStartDate;
    private String note;

    public String getIVAs() {
        return ivAs;
    }

    public void setIVAs(final String pIvAs) {
        this.ivAs = pIvAs;
    }

    public String getIVAsCleared() {
        return ivAsCleared;
    }

    public void setIVAsCleared(final String pIvAsCleared) {
        this.ivAsCleared = pIvAsCleared;
    }
}
