package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmploymentAddressConstraint;
import com.natwest.pbbdhb.openapi.EmploymentAddress;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isNotBlank;

public class EmploymentAddressValidator implements ConstraintValidator<EmploymentAddressConstraint, EmploymentAddress> {

    @Override
    public boolean isValid(final EmploymentAddress address,
                           final ConstraintValidatorContext constraintValidatorContext) {
        return isNull(address) || isNotBlank(address.getFlat()) || isNotBlank(address.getHouseNumber()) || isNotBlank(
                address.getHouseName());

    }
}
