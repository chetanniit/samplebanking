package com.natwest.pbbdhb.adbo.listener.hboadboevent.utils;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.openapi.Address;
import com.natwest.pbbdhb.openapi.Employment;
import com.natwest.pbbdhb.openapi.Route;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;

import static com.natwest.pbbdhb.openapi.Route.INTERNET_BANKING;
import static com.natwest.pbbdhb.openapi.Route.MOBILE_BANKING;
import static java.util.Objects.isNull;
import static java.util.Optional.ofNullable;

@Slf4j
public final class ADBOUtils {
    public static final String STANDARD_DATE_FORMAT = "uuuu-MM-dd";
    public static final String STANDARD_DATE_PATTERN = "^\\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$";
    public static final String STANDARD_UK_POSTCODE_FORMAT =
            "^(([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|"
                    + "([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?)))) [0-9][A-Za-z]{2}$";
    public static final String STANDARD_YEAR_PATTERN = "^\\d{4}$";
    public static final String COUNTRY_GB_PATTERN = "^GB$";
    public static final BigDecimal MAXIMUM_INCOME_AMOUNT = BigDecimal.valueOf(99999999);
    public static final String STR_EBA = "EBA";
    public static final String STR_MBA = "MBA";

    public static final List<Address.OccupyStatusEnum> OWNER_OCCUPY_STATUSES =
            Arrays.asList(Address.OccupyStatusEnum.OWNER_NO_MORTGAGE, Address.OccupyStatusEnum.OWNER_MORTGAGED);

    @SuppressWarnings("checkstyle:visibilitymodifier")
    public static BiFunction<Route, Route, String> getRoute =
            (applicationRoute, applicantRoute) -> {
                String route = ofNullable(applicantRoute).map(val -> val.name()).orElse(applicationRoute.name());
                return INTERNET_BANKING.name().equals(route) ? STR_EBA
                        : (MOBILE_BANKING.name().equals(route) ? STR_MBA : "");
            };

    private ADBOUtils() {
    }

    public static boolean isUkAddress(String countryIsoCode) {
        return isNull(countryIsoCode) || "GB".equalsIgnoreCase(countryIsoCode);
    }

    public static LocalDate toLocalDate(String date, DateTimeFormatter formatter) {
        return Optional.ofNullable(date).map(d -> {
            try {
                return LocalDate.parse(d, formatter);
            } catch (DateTimeParseException ex) {
                log.error("{} Can't parse date {} using format {}", ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, date,
                        formatter, ex);
                throw ex;
            }
        }).orElse(null);
    }

    public static boolean isPreviousEmployment(Employment employment) {
        return !isNull(employment)
                && !isNull(employment.getEndDate())
                && LocalDate.now().isAfter(toLocalDate(employment.getEndDate(), DateTimeFormatter.ISO_LOCAL_DATE));
    }

}
