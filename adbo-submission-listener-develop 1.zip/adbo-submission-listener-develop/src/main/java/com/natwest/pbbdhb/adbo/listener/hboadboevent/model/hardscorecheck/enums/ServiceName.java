package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PUBLIC)
public enum ServiceName {
    EKYC, EKYC_VMARKER, NONE

}
