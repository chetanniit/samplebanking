package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PaymentFrequency {
    ANNUALLY, BIANNUALLY, FORTNIGHTLY, FOUR_WEEKLY, MONTHLY, QUARTERLY, WEEKLY;
}
