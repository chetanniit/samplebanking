package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Address extends BaseAddress {
    private String addressCountry;
}
