package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerFailedToMakePaymentsDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    private String answer;
    private LocalDate dateArrearsRepaid;
    private BigDecimal currentOutstandingArrears;
    private Integer noOfMonthsInArrears;
    private LocalDate dateHighestArrears;
    private String worseningArrears;
    private Integer highestMonthsArrears6Months;
    private BigDecimal highestValueArrears6Months;
    private Integer highestMonthsArrears12Months;
    private BigDecimal highestValueArrears12Months;
    private Integer highestMonthsArrears24Months;
    private BigDecimal highestValueArrears24Months;
    private String arrearsOver24Months;
    private String propertyRepossessed;
    private LocalDate propertyRepossessionDate;
    private String note;
    private LocalDate loanArrearsRepaidDate;
    private BigDecimal currentLoanArrearsOutstanding;
    private Integer numberOfMonthsInLoanArrears;
    private LocalDate highestLoanArrearsDate;
    private String haveLoanArrearsWorsenedInLastSixMonths;
    private BigDecimal highestLoanArrearsInPreviousTwoYears;
    private Integer highestLoanArrearsMonthsInPreviousTwoYears;
}
