package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum OwnershipType {
    HELD_RBSG,
    HELD_ELSEWHERE,
    UNENCUMBERED
}
