package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.responseerrorhandler;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.HttpCallFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpError;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpErrorResponse;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.DefaultResponseErrorHandler;

@Component("workflowExecutionHttpCallResponseErrorHandler")
@Slf4j
public class HttpCallResponseErrorHandler extends DefaultResponseErrorHandler {

    private ObjectMapper objectMapper =
            new Jackson2ObjectMapperBuilder().serializationInclusion(JsonInclude.Include.NON_EMPTY)
                    .featuresToEnable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES).build();

    @Override
    @SuppressWarnings("PMD.AvoidThrowingRawExceptionTypes")
    public void handleError(final ClientHttpResponse response) throws IOException {
        final String errorResponseBody =
                this.getErrorMessage(this.getResponseBody(response), this.getCharset(response));
        log.debug("Http call failed with status={} and response={}", response.getStatusCode(), errorResponseBody);

        HttpErrorResponse httpErrorResponse;
        try {
            httpErrorResponse = objectMapper.readValue(errorResponseBody, HttpErrorResponse.class);
        } catch (Exception ex) {
            httpErrorResponse = HttpErrorResponse.builder().errors(Collections.singletonList(
                    HttpError.builder().status(Integer.toString(response.getStatusCode().value()))
                            .code(response.getStatusText()).message(errorResponseBody).build()))
                    .build();
        }

        throw new HttpCallFailureException(new Throwable(
                String.format("Http call failed with %s, %s", response.getStatusText(), response.getRawStatusCode())),
                HttpStatus.valueOf(response.getStatusCode().value()), httpErrorResponse);
    }

    private String getErrorMessage(@Nullable byte[] responseBody, @Nullable Charset charset) {
        if (ObjectUtils.isEmpty(responseBody)) {
            return "[no body]";
        } else {
            charset = charset == null ? StandardCharsets.UTF_8 : charset;
            return new String(responseBody, charset);
        }
    }

}
