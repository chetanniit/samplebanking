package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HardScoreApplicationResponse  {
    private static final long serialVersionUID = 1L;
    private String caseId;

    private String decisionUniqueId;

    private String decision;

    private String podDecision;

    private List<Policy> policyMessages;

    private List<Message> kycMessages;

    private AdditionalDetails additionalDetails;

    private String errorCode;

    private String errorDescription;

    private Packaging packaging;
}
