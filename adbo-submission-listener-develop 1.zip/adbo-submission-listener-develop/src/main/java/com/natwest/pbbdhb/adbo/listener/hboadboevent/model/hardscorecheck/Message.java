package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class Message implements Serializable {
    private String message;

    private String code;

    private Boolean applicant1IdRequired;

    private Boolean applicant2IdRequired;
}
