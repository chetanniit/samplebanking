package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EndDateConstraint;
import com.natwest.pbbdhb.openapi.Employment;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_FORMAT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_PATTERN;
import static java.util.Objects.isNull;

public class EndDateValidator implements ConstraintValidator<EndDateConstraint, Employment> {

    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(STANDARD_DATE_FORMAT);
        return isNull(employment) || isNull(employment.getStartDate()) || isNull(employment.getEndDate()) || StringUtils
                .isBlank(employment.getEndDate()) || StringUtils.isBlank(employment.getStartDate()) || !Pattern
                .matches(STANDARD_DATE_PATTERN, employment.getStartDate()) || !Pattern
                .matches(STANDARD_DATE_PATTERN, employment.getEndDate()) || ADBOUtils
                       .toLocalDate(employment.getEndDate(), formatter)
                       .isAfter(ADBOUtils.toLocalDate(employment.getStartDate(), formatter));
    }

}
