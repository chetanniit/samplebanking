package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankDetails {
    private LocalDate dateOpened;
    private String bankName;
    private Boolean debitCard;
    private String sortCode;
    private String accountNumber;
}
