package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationGeneralDetails {

    private String externalReference;
    private String externalCaseReference;
    private String advanceType;
    private String scottishApplication;
    private String directApplication;
    private String newContractRequired;
    private String group;
    private String branch;
    private String operator;
    private String channel;
    private String marketingSource;
    private LocalDate completionDate;
    private String marketingSchemeNumber;
    private IndirectSourceDetails indirectSourceDetails;
}
