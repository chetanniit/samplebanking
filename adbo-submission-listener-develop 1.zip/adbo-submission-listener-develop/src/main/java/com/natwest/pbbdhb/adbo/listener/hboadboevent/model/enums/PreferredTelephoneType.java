package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PreferredTelephoneType {

    NO_PREFERENCE("0", "No Preference"),
    HOME("1", "Home"),
    BUSINESS("2", "Business"),
    MOBILE("3", "Mobile");

    private String key;

    private String value;

    @Override
    public String toString() {
        return key;
    }
}
