package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.notes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotesApplicant {
    private String cin;
    private List<String> multiCins;
}
