package com.natwest.pbbdhb.adbo.listener.hboadboevent.state.service;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums.RetryStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.CreateApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.GetApplicationsResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.model.CreateStateHboKafkaEventRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.state.model.PatchApplicationRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Objects;

@Slf4j
@Service
public class StateApplicationService {

    @Value("${application.config.state-service.base-url}")
    private String stateApiBaseUrl;

    @Value("${application.config.state-service.retrieve-applications-url}")
    private String stateApiRetrieveUrl;

    @Autowired
    @Qualifier("resolvedRestTemplate")
    private RestTemplate restTemplate;

    public void createEvent(final CreateStateHboKafkaEventRequest request, final String brand) {
        try {
            URI uri = UriComponentsBuilder.fromHttpUrl(stateApiBaseUrl + "/events").build().toUri();
            RequestEntity requestEntity
                    = new RequestEntity<>(request, enrichHttpHeadersWithBrand(brand), HttpMethod.POST, uri);
            log.info("POST state details API: Call to create event with URL={}, Request={}", uri, requestEntity);

            final ResponseEntity<Void> response = restTemplate.exchange(requestEntity, Void.class);
            log.info("POST state details API: Call to create event returned Http Status={}",
                    response.getStatusCode().value());
        } catch (Exception ex) {
            log.error("{} POST state details API: Call to create event failed with error",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, ex);
        }
    }

    public void patchKafkaTimestamp(final PatchApplicationRequest request, final String brand) {
        try {
            URI uri =
                    UriComponentsBuilder.fromHttpUrl(stateApiBaseUrl + "/applications/{id}").build(request.getFlowId());
            RequestEntity requestEntity
                    = new RequestEntity<>(request, enrichHttpHeadersWithBrand(brand), HttpMethod.PATCH, uri);
            log.info("PATCH state details API: Call to patch kafka timestamp with URL={}, Request={}", uri,
                    requestEntity);

            final ResponseEntity<Void> response = restTemplate.exchange(requestEntity, Void.class);
            log.info("PATCH state details API: Call to patch kafka timestamp returned Http Status={}",
                    response.getStatusCode().value());
        } catch (Exception ex) {
            log.error("{} PATCH state details API: Call to patch kafka timestamp failed with error=",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, ex);
        }
    }


    public GetApplicationsResponse retrieveApplications(RetryStatus status, Integer maxRetryAttempts,
                                                        Boolean isKafkaEventSent, Boolean isApplicationSentToMops,
                                                        String responseStatus, String brand) {
        UriComponentsBuilder uriComponentsBuilder =
                UriComponentsBuilder.fromHttpUrl(stateApiRetrieveUrl);
        if (Objects.nonNull(maxRetryAttempts)) {
            uriComponentsBuilder
                    .queryParam(WorkflowExecutionConstants.RETRY_MAX_ATTEMPTS_QUERY_PARAM, maxRetryAttempts);
        }
        if (Objects.nonNull(isKafkaEventSent)) {
            uriComponentsBuilder
                    .queryParam(WorkflowExecutionConstants.IS_KAFKA_EVENT_SENT_QUERY_PARAM, isKafkaEventSent);
        }
        if (Objects.nonNull(isApplicationSentToMops)) {
            uriComponentsBuilder
                    .queryParam(WorkflowExecutionConstants.IS_MOPS_EMAIL_SENT_QUERY_PARAM, isApplicationSentToMops);
        }
        if (StringUtils.isNotBlank(responseStatus)) {
            uriComponentsBuilder
                    .queryParam(WorkflowExecutionConstants.RESPONSE_STATUS_QUERY_PARAM, responseStatus);
        }

        final URI retrieveApplicationsUrl = uriComponentsBuilder.build(status.name());

        HttpHeaders headers = new HttpHeaders();
        headers.add(WorkflowExecutionConstants.BRAND_HEADER, brand);
        final HttpEntity<?> requestHttpEntity = new HttpEntity<>(headers);
        log.info("GMS State Integration API: called to Retrieve Applications by Retry Status with URL={} and Brand={}",
                retrieveApplicationsUrl, brand);
        final ResponseEntity<GetApplicationsResponse> response = restTemplate
                .exchange(retrieveApplicationsUrl, HttpMethod.GET, requestHttpEntity, GetApplicationsResponse.class);
        log.info(
                "GMS State Integration API: Retrieve Applications by Retry Status returned Http Status={}",
                response.getStatusCode().value());

        return response.getBody();
    }

    public CreateApplicationResponse retrieveApplication(String brand, String flowId) {
        UriComponentsBuilder uriComponentsBuilder =
                UriComponentsBuilder.fromHttpUrl(stateApiRetrieveUrl);

        URI uri = UriComponentsBuilder.fromHttpUrl(stateApiBaseUrl + "/applications/{id}").build(flowId);

        HttpHeaders headers = new HttpHeaders();
        headers.add(WorkflowExecutionConstants.BRAND_HEADER, brand);
        final HttpEntity<?> requestHttpEntity = new HttpEntity<>(headers);
        log.info("GMS State Integration API: called to Retrieve Application Brand={} id={}",
                brand, flowId);
        final ResponseEntity<CreateApplicationResponse> response = restTemplate
                .exchange(uri, HttpMethod.GET, requestHttpEntity, CreateApplicationResponse.class);
        log.info(
                "GMS State Integration API: Retrieve Application by id={} returned Http Status={}", flowId,
                response.getStatusCode().value());

        return response.getBody();
    }


    private HttpHeaders enrichHttpHeadersWithBrand(String brand) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("brand", brand);
        return httpHeaders;
    }
}
