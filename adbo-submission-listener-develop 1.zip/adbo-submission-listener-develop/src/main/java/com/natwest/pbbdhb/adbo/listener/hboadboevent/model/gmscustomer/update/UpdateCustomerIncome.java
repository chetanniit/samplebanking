package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerIncome {
    private String incomeType;
    private BigDecimal amount;
    private String frequency;
    private BigDecimal netAmount;
    private String netFrequency;
}
