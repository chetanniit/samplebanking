package com.natwest.pbbdhb.adbo.listener.hboadboevent.configuration;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.schedulers.MultiBrandJdbcTemplateLockProvider;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.schedulers.PersistenceConfigurationProperties;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.LockProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

@Configuration
@Slf4j
public class SchedulerConfiguration {

    @Autowired
    private PersistenceConfigurationProperties persistenceConfigurationProperties;


    @Bean
    @DependsOn("multiBrandDataSources")
    public LockProvider multiBrandLockProvider(
            @Autowired @Qualifier("multiBrandDataSources") Map<String, DataSource> multiBrandDataSources) {
        return new MultiBrandJdbcTemplateLockProvider(multiBrandDataSources);
    }

    @ConditionalOnProperty(name = "application.config.brand.names")
    @Bean
    public Map<String, DataSource> multiBrandDataSources(@Value("${application.config.brand.names}") String brands) {
        log.info("Creating multiBrandDataSource for brands....{}", Arrays.asList(brands.split(",")));
        final Map<String, DataSource> targetDataSources = new HashMap<>();
        for (String brand : brands.split(",")) {
            targetDataSources.put(brand, createDataSource(brand));
        }
        return targetDataSources;
    }

    private HikariDataSource createDataSource(String brand) {
        log.info("Creating HikariDataSource for {}", brand);

        final Properties properties = new Properties();

        // default to a friendly pool name
        properties.setProperty("poolName", "Hikari-" + brand);

        // get global (brand.hikari) properties
        if (Objects.nonNull(persistenceConfigurationProperties.getHikari())) {
            persistenceConfigurationProperties.getHikari().forEach(properties::setProperty);
        }

        // override with/add brand specific (brand.datasource.xxx) properties
        if (Objects.nonNull(persistenceConfigurationProperties.getDataSource()) && (Objects
                .nonNull(persistenceConfigurationProperties.getDataSource().get(brand)))) {
            persistenceConfigurationProperties.getDataSource().get(brand).forEach(properties::setProperty);
        }

        final HikariConfig config = new HikariConfig(properties);

        return new HikariDataSource(config);
    }
}
