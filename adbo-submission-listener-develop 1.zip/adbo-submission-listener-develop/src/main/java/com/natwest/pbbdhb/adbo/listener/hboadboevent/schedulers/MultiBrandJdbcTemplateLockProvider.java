package com.natwest.pbbdhb.adbo.listener.hboadboevent.schedulers;

import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.lang.NonNull;

import javax.sql.DataSource;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class MultiBrandJdbcTemplateLockProvider implements LockProvider {
    private static final String SHED_LOCK_TABLE_NAME = "TBL_SHED_LOCK";
    private final ConcurrentHashMap<String, LockProvider> providers = new ConcurrentHashMap<>();

    private Map<String, DataSource> multiBrandDataSources;

    public MultiBrandJdbcTemplateLockProvider(Map<String, DataSource> pMultiBrandDataSources) {
        log.info("Initialize MultiBrandJdbcTemplateLockProvider for brands={}", pMultiBrandDataSources.keySet());
        this.multiBrandDataSources = pMultiBrandDataSources;
    }

    @Override
    public @NonNull
    Optional<SimpleLock> lock(@NonNull LockConfiguration lockConfiguration) {
        String brand = BrandContextHolder.getCurrentBrand();
        log.info("Trying to acquire lock using brand specific LockProvider with brand={}", brand);
        return providers.computeIfAbsent(brand, this::createLockProvider).lock(lockConfiguration);
    }

    private LockProvider createLockProvider(String brand) {
        log.info("Build brand specific JdbcTemplateLockProvider for brand={}", brand);
        return new JdbcTemplateLockProvider(
                JdbcTemplateLockProvider.Configuration.builder().withTableName(SHED_LOCK_TABLE_NAME)
                        .withJdbcTemplate(new JdbcTemplate(multiBrandDataSources.get(brand))).usingDbTime().build());
    }
}
