package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateFurtherAdvanceApplicationResponse {
    private String mortgageNumber;
    private String applSeq;
    private List<String> documents;
    private List<String> documentUrls;
}
