package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Objects;

public class HttpCallTimestampCaptor {
    private static final ThreadLocal<HttpCallTimestamp> CONTEXT_HOLDER = new ThreadLocal();

    public static void setSendTimestamp(LocalDateTime timestamp) {
        if (Objects.isNull(CONTEXT_HOLDER.get())) {
            CONTEXT_HOLDER.set(new HttpCallTimestamp());
        }
        CONTEXT_HOLDER.get().setSendTimestamp(timestamp);
    }

    public static LocalDateTime getSendTimestamp() {
        return CONTEXT_HOLDER.get().getSendTimestamp();
    }

    public static void setReceiveTimestamp(LocalDateTime timestamp) {
        if (Objects.isNull(CONTEXT_HOLDER.get())) {
            CONTEXT_HOLDER.set(new HttpCallTimestamp());
        }
        CONTEXT_HOLDER.get().setReceiveTimestamp(timestamp);
    }

    public static LocalDateTime getReceiveTimestamp() {
        return CONTEXT_HOLDER.get().getReceiveTimestamp();
    }

    public static void clear() {
        CONTEXT_HOLDER.remove();
    }
}

@Data
class HttpCallTimestamp {
    private LocalDateTime sendTimestamp;
    private LocalDateTime receiveTimestamp;
}
