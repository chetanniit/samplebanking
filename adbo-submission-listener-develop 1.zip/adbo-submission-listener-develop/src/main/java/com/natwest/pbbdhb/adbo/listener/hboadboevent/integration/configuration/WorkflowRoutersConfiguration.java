package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.configuration;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.RetryPolicyExpressionFailedException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.HttpCallFailureException;

import java.util.LinkedHashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.Router;
import org.springframework.integration.router.ErrorMessageExceptionTypeRouter;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.web.client.ResourceAccessException;

@Configuration
@Slf4j
public class WorkflowRoutersConfiguration {

    @Bean("workflowExecutionExceptionTypeRouter")
    @Router(inputChannel = WorkflowExecutionConstants.WORKFLOW_EXECUTION_ERROR_INPUT)
    public ErrorMessageExceptionTypeRouter errorMessageExceptionTypeRouter() {
        ErrorMessageExceptionTypeRouter router = new ErrorMessageExceptionTypeRouter();

        Map<String, String> mappings = new LinkedHashMap<>();
        mappings.put(MessageHandlingException.class.getName(),
                WorkflowExecutionConstants.MESSAGE_HANDLING_EXCEPTION_INPUT);
        mappings.put(ResourceAccessException.class.getName(),
                WorkflowExecutionConstants.RESOURCE_ACCESS_EXCEPTION_INPUT);
        mappings.put(HttpCallFailureException.class.getName(),
                WorkflowExecutionConstants.HTTP_CALL_FAILURE_EXCEPTION_INPUT);
        mappings.put(RetryPolicyExpressionFailedException.class.getName(),
                WorkflowExecutionConstants.TRANSFORM_RETRY_POLICY_EXPRESSION_FAILURE_INPUT);

        router.setChannelMappings(mappings);
        router.setDefaultOutputChannelName(
                WorkflowExecutionConstants.ERROR_MESSAGE_EXCEPTION_TYPE_ROUTER_DEFAULT_OUTPUT_INPUT);
        return router;
    }
}
