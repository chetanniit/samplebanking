package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerCCJDetails {

    private String answer;
    private Integer noOfCCJ;
    private LocalDate dateOfLastCCJ;
    private BigDecimal amountPayableForLastCCJ;
    private LocalDate dateLastCCJRepaid;
    private Integer ccJsSatisfied;
    private String note;

    public Integer getCCJsSatisfied() {
        return ccJsSatisfied;
    }

    public void setCCJsSatisfied(final Integer pCcJsSatisfied) {
        this.ccJsSatisfied = pCcJsSatisfied;
    }
}
