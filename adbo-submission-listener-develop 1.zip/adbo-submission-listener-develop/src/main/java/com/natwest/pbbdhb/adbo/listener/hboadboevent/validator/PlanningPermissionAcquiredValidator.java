package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.PlanningPermissionAcquiredConstraint;
import com.natwest.pbbdhb.openapi.AdditionalBorrowing;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class PlanningPermissionAcquiredValidator
        implements ConstraintValidator<PlanningPermissionAcquiredConstraint, AdditionalBorrowing> {

    @Override
    public boolean isValid(AdditionalBorrowing additionalBorrowing,
                           ConstraintValidatorContext constraintValidatorContext) {
        return isNull(additionalBorrowing) || isNull(additionalBorrowing.getReason()) || !additionalBorrowing
                .getReason().equals(AdditionalBorrowing.ReasonEnum.HOME_IMPROVEMENT)
                || isNull(additionalBorrowing.getPlanningPermissionRequired())
                || !additionalBorrowing.getPlanningPermissionRequired()
                || nonNull(additionalBorrowing.getPlanningPermissionAcquired());
    }
}
