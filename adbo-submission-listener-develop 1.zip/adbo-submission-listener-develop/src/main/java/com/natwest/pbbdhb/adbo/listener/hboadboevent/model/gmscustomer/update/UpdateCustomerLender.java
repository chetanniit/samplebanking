package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerLender {
    private String name;
    private UpdateCustomerLenderAddress lenderAddress;
    private String telephoneNumber;
    private String faxNumber;
    private UpdateCustomerMortgageDetails mortgageDetails;
}
