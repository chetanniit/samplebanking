package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum MortgageOwnership {
    JOINT, SINGLE
}
