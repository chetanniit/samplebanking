package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.notes.NotesRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring")
public abstract class AddNotesRequestMapper implements WorkflowMapper<WorkflowContext, NotesRequest>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    public NotesRequest map(WorkflowContext source) {
        return mapToNotesRequest(source);
    }

    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target = "applicationNumber", source = "source", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "applicationSequenceNumber", source = "source", qualifiedByName = "getApplicationSequenceNumber")
    @Mapping(target = "society", expression = "java(config.getSociety())")
    @Mapping(target = "taskNote", source = "source")
    abstract NotesRequest mapToNotesRequest(WorkflowContext source);
}
