package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.CountryIsoToGmsCode;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.CustomerAddress;
import com.natwest.pbbdhb.openapi.Address;
import com.natwest.pbbdhb.openapi.PersonalDetails;
import com.natwest.pbbdhb.openapi.UnstructuredAddress;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.ValueMapping;

import static java.util.Optional.ofNullable;

@Mapper(componentModel = "spring")
public interface SharedCustomerMapper extends BaseMapper {

    static final int  SECOND_FORE_NAMES_MAX_LENGTH = 30;

    @ValueMapping(source = "MR", target = "MR")
    @ValueMapping(source = "MRS", target = "MRS")
    @ValueMapping(source = "MISS", target = "MSS")
    @ValueMapping(source = "MS", target = "MS")
    @ValueMapping(source = "DR", target = "DR")
    @ValueMapping(source = "REVEREND", target = "REV")
    @ValueMapping(source = "PROFESSOR", target = "PRF")
    @ValueMapping(source = "SIR", target = "SIR")
    @ValueMapping(source = "LORD", target = "LRD")
    @ValueMapping(source = "LADY", target = "LDY")
    @ValueMapping(source = "CAPTAIN", target = "CAP")
    @ValueMapping(source = "MAJOR", target = "MAJ")
    @ValueMapping(source = "COLONEL", target = "COL")
    @ValueMapping(source = "MASTER", target = "MST")
    @ValueMapping(source = "HON", target = "HON")
    @ValueMapping(source = "MX", target = "MX")
    @ValueMapping(source = "SISTER", target = "SIS")
    @ValueMapping(source = "VISCOUNT", target = "VIS")
    @ValueMapping(source = "COUNTESS", target = "COU")
    @ValueMapping(source = "EARL", target = "EAR")
    @ValueMapping(source = "OTHER", target = "OTH")
    @ValueMapping(source = "NONE", target = "OTH")
    String mapToTitle(PersonalDetails.TitleEnum source);

    ///TODO - D, M, S and W exist in GMS
    @ValueMapping(source = "DIVORCED", target = "D")
    @ValueMapping(source = "MARRIED", target = "M")
    @ValueMapping(source = "SEPARATED", target = "D")
    @ValueMapping(source = "SINGLE", target = "S")
    @ValueMapping(source = "ENGAGED", target = "M")
    @ValueMapping(source = "WIDOWED", target = "W")
    @ValueMapping(source = "LIVING_WITH_PARTNER", target = "M")
    @ValueMapping(source = "CIVIL_PARTNERSHIP", target = "M")
    @ValueMapping(source = "SURVIVING_CIVIL_PARTNER", target = "W")
    String mapToMaritalStatus(PersonalDetails.MaritalStatusEnum source);

    @Named("mapToNationality")
    default String mapToNationality(PersonalDetails personalDetails) {
        return getGmsCode(personalDetails.getNationality(), CountryIsoToGmsCode::getNationalityCode);
    }

    @Named("mapToCountryOfResidence")
    default String mapToGMSCountryOfResidence(PersonalDetails personalDetails) {
        return getGmsCode(personalDetails.getCountryOfResidenceIsoCode(), CountryIsoToGmsCode::getResidenceCode);
    }

    @Named("mapToForeNames")
    default String mapToForeNames(PersonalDetails personalDetails) {
        String firstName = personalDetails.getFirstNames().trim();
        int index = firstName.indexOf(' ');
        if (index > 0) {
            return ofNullable(String.format("%s %s", firstName.substring(0, index),
                    StringUtils.substring(String.format("%s %s", firstName.substring(index + 1), ofNullable(
                    personalDetails.getMiddleNames()).orElse(StringUtils.EMPTY)).trim(), 0, SECOND_FORE_NAMES_MAX_LENGTH))).get();
        }else{
            return ofNullable(String.format("%s %s", firstName,
                    StringUtils.substring((ofNullable(
                            personalDetails.getMiddleNames()).orElse(StringUtils.EMPTY)).trim(), 0, SECOND_FORE_NAMES_MAX_LENGTH))).get();
            }
        }
        


    @Mapping(target = "foreignAddressIndicator", source = "source.countryIsoCode",
            qualifiedByName = "toGMSForeignAddressIndicator")
    @Mapping(target = "addressCountry", source = "source", qualifiedByName = "countryCode")
    @Mapping(target = "addressPC", source = "source", qualifiedByName = "applicantPostcode")
    @Mapping(target = "address1", source = "source", qualifiedByName = "applicantAddressLine1")
    @Mapping(target = "address2", source = "source", qualifiedByName = "applicantAddressLine2")
    @Mapping(target = "address3", source = "source", qualifiedByName = "applicantAddressLine3")
    @Mapping(target = "address4", source = "source", qualifiedByName = "applicantAddressLine4")
    @Mapping(target = "address5", source = "source", qualifiedByName = "applicantAddressLine5")
    @Named("clientAddress")
    CustomerAddress mapToAddress(Address source);

    @Mapping(target = "foreignAddressIndicator", source = "source.countryCode",
            qualifiedByName = "toGMSForeignAddressIndicator")
    @Mapping(target = "addressCountry", source = "countryCode")
    @Mapping(target = "addressPC", source = "postcode")
    @Mapping(target = "address1", source = "address1")
    @Mapping(target = "address2", source = "address2")
    @Mapping(target = "address3", source = "address3")
    @Mapping(target = "address4", source = "address4")
    @Mapping(target = "address5", source = "address5")
    @Named("clientGmsAddress")
    CustomerAddress mapToAddress(UnstructuredAddress source);

    @ValueMapping(source = "MALE", target = "M")
    @ValueMapping(source = "FEMALE", target = "F")
    @ValueMapping(source = MappingConstants.NULL, target = "M")
    String mapToGMSGenderType(PersonalDetails.GenderEnum source);

}
