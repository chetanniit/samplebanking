package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.RentWhileHouseImprovementConstraint;
import com.natwest.pbbdhb.openapi.AdditionalBorrowing;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.FinancialCommitment;
import org.springframework.util.CollectionUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class RentWhileHouseImprovementValidator
        implements ConstraintValidator<RentWhileHouseImprovementConstraint, Application> {
    @Override
    public boolean isValid(Application application, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(application) || CollectionUtils.isEmpty(application.getApplicants()) || isNull(
                application.getBorrowingDetails()) || CollectionUtils
                       .isEmpty(application.getBorrowingDetails().getAdditionalBorrowings()) || !application
                .getBorrowingDetails().getAdditionalBorrowings().stream().anyMatch(
                        ab -> ab.getReason().equals(AdditionalBorrowing.ReasonEnum.HOME_IMPROVEMENT) && nonNull(
                                ab.getLivingElseWhereMoreThan6Months()) && ab.getLivingElseWhereMoreThan6Months())
               || application.getApplicants().stream().anyMatch(
                a -> !CollectionUtils.isEmpty(a.getFinancialCommitments()) && a.getFinancialCommitments().stream()
                        .anyMatch(
                                fc -> fc.getType().equals(FinancialCommitment.TypeEnum.RENT_WHILE_HOUSE_IMPROVEMENTS)));
    }
}
