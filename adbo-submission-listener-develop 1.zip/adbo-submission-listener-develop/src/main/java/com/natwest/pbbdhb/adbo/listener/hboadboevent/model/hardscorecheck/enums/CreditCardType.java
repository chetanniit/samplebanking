package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum CreditCardType {
    CREDIT_CARD, STORE_CARD
}
