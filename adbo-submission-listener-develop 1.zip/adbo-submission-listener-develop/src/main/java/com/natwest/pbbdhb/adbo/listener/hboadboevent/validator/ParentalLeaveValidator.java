package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.ParentalLeaveConstraint;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.Employment;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class ParentalLeaveValidator implements ConstraintValidator<ParentalLeaveConstraint, Applicant> {
    @Override
    public boolean isValid(Applicant applicant, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(applicant) || isNull(applicant.getWorkStatus()) || applicant.getWorkStatus()
                .equals(Applicant.WorkStatusEnum.NOT_WORKING) || !isCurrentEmploymentWithValidStatusAndType(applicant)
                || nonNull(applicant.getParentalLeave());
    }

    private boolean isCurrentEmploymentWithValidStatusAndType(Applicant applicant) {
        if (isNull(applicant.getEmployments())) {
            return false;
        }
        List<Employment> currentEmployments = applicant.getEmployments().stream()
                .filter(e -> StringUtils.isBlank(e.getEndDate()) && nonNull(e.getEmploymentType()) && e
                        .getEmploymentType().equals(Employment.EmploymentTypeEnum.PERMANENT) && nonNull(
                        e.getEmploymentStatus()) && e.getEmploymentStatus()
                        .equals(Employment.EmploymentStatusEnum.EMPLOYED)).collect(Collectors.toList());
        return !CollectionUtils.isEmpty(currentEmployments) && currentEmployments.size() == 1;

    }

}
