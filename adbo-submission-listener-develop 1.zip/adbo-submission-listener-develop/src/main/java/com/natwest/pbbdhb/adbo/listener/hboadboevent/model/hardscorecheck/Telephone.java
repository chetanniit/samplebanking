package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.TelephoneType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Telephone {
    private TelephoneType type;
    private String number;
    private Boolean preferred;
}
