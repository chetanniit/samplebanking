package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SummarySelection implements Serializable {
    private static final long serialVersionUID = 1L;
    private SummaryBorrowing borrowing;
    private SummaryDetails summaryDetails;
    private EffectOfABaseRateChange effectOfABaseRateChange;
    private ForeignCurrencyIncrease foreignCurrencyIncrease;
    private SummaryRepayments repayments;
    private RepaymentsAPRIncludingReserveFunds repaymentsAPRIncludingReserveFunds;
}
