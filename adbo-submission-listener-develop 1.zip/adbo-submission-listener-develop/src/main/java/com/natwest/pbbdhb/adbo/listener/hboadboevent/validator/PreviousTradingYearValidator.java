package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.PreviousTradingYearConstraint;
import com.natwest.pbbdhb.openapi.SelfEmployed;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class PreviousTradingYearValidator implements ConstraintValidator<PreviousTradingYearConstraint, SelfEmployed> {
    @Override
    public boolean isValid(SelfEmployed selfEmployed, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(selfEmployed) || !(hasLimitedCompanyPreviousEarnings(selfEmployed)
                                         || hasSoleTraderOrPartnershipPreviousEarnings(selfEmployed)) || StringUtils
                       .isNotBlank(selfEmployed.getPreviousTradingYear());
    }

    public boolean hasLimitedCompanyPreviousEarnings(SelfEmployed selfEmployed) {
        return selfEmployed.getBusinessType().equals(SelfEmployed.BusinessTypeEnum.LIMITED_COMPANY) && (
                nonNull(selfEmployed.getDrawingsPrevious()) || nonNull(selfEmployed.getDividendsPrevious()));
    }

    public boolean hasSoleTraderOrPartnershipPreviousEarnings(SelfEmployed selfEmployed) {
        return !selfEmployed.getBusinessType().equals(SelfEmployed.BusinessTypeEnum.LIMITED_COMPANY) && nonNull(
                selfEmployed.getNetProfitPrevious());
    }
}
