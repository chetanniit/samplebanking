package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum LoanType {
    HIRE_PURCHASE, SECURED_LOAN, UNSECURED_LOAN, STUDENT_LOAN, PERSONAL_CONTRACT_PURCHASE
}
