package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.LoanType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Loan {
    private LoanType type;
    private String provider;
    private BigDecimal monthlyPayment;
    private BigDecimal amountOutstanding;
    private Boolean toBeRepaid;
    private Boolean debtConsolidation;
}
