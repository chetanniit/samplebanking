package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Packaging implements Serializable {
    private String app1AccountsReq;
    private String app1BankStmntsReq;
    private String app1PaySlipsReq;
    private String app1PerAndBusBankStmntsReq;
    private String app1TaxCalc;
    private String app2AccountsReq;
    private String app2BankStmntsReq;
    private String app2PaySlipsReq;
    private String app2PerAndBusBankStmntsReq;
    private String app2TaxCalc;
}
