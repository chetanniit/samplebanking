package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.AdditionalBorrowingDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.ApplicationGeneralDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.AssociatedAccount;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.AssociatedAccounts;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.Contact;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.CreateFurtherAdvancedApplicationRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.FeeDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.PropertyDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.SellingAgent;
import com.natwest.pbbdhb.openapi.AdditionalBorrowing;
import com.natwest.pbbdhb.openapi.Address;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.BorrowingDetails;
import com.natwest.pbbdhb.openapi.Fee;
import com.natwest.pbbdhb.openapi.PersonalDetails;
import com.natwest.pbbdhb.openapi.ProductDetails;
import com.natwest.pbbdhb.openapi.ServiceLevel;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.Builder;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.ValueMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.BRAND_HEADER;
import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class FurtherAdvanceApplicationRequestMapper
        implements WorkflowMapper<WorkflowContext, CreateFurtherAdvancedApplicationRequest>, SharedCustomerMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;
    @Value("${adbo.regulated-authority:FSA}")
    private String regulatedAuthority;
    @Value("${adbo.regulated-authority-overriden-by:SUMMIT}")
    private String regulatedAuthorityOverridenBy;

    public CreateFurtherAdvancedApplicationRequest map(WorkflowContext source) {
        Application application = (Application) source.getOriginalPayload();

        return mapToGMSFurtherAdvanceRequest(application, source);
    }

    @Mappings({@Mapping(target = "society", expression = "java(config.getSociety())"),
            @Mapping(target = "lookupData", expression = "java(config.getLookupData())"),
            @Mapping(target = "lookupSet", expression = "java(config.getLookupSet())"),
            @Mapping(target = "userId", expression = "java(config.getXoUserid())"),
            @Mapping(target = "mortgage", source = "existingMortgage.mortgageReferenceNumber"),
            @Mapping(target = "applicationGeneralDetails", source = "application",
                    qualifiedByName = "toApplicationGeneralDetails"),
            @Mapping(target = "loanDetails.associatedAccounts", source = "borrowingDetails",
                    qualifiedByName = "toAssociatedAccounts"),
            @Mapping(target = "loanDetails.loanAmount", source = "borrowingDetails", qualifiedByName = "toLoanAmount"),
            @Mapping(target = "loanDetails.additionalBorrowingDetails", source = "borrowingDetails",
                    qualifiedByName = "toAdditionalBorrowingDetails"),
            @Mapping(target = "loanDetails.allApplicantsToBenefit", ignore = true),
            @Mapping(target = "loanDetails.paymentMethod", ignore = true),
            @Mapping(target = "loanDetails.borrowingLimit", ignore = true),
            @Mapping(target = "loanDetails.paymentDueDate", ignore = true),
            @Mapping(target = "loanDetails.repaymentVehicle", ignore = true),
            @Mapping(target = "serviceLevel.interview", source = "serviceLevel.interview"),
            @Mapping(target = "serviceLevel.levelOfService", source = "serviceLevel.levelOfService"),
            @Mapping(target = "solicitorDetails.applicantSolicitor.applicantSolicitorId", source = ".",
                    qualifiedByName = "checksolicitorId"),
            @Mapping(target = "feeDetails", source = "borrowingDetails.products", qualifiedByName = "toFeeDetails"),
            @Mapping(target = "propertyDetails", source = "application", qualifiedByName = "toPropertyDetails")
    })
    abstract CreateFurtherAdvancedApplicationRequest mapToGMSFurtherAdvanceRequest(Application application, @Context
            WorkflowContext workflowContext);


    @Mapping(target = "externalReference", ignore = true)
    @Mapping(target = "externalCaseReference", ignore = true)
    @Mapping(target = "advanceType", expression = "java(config.getAdvanceType())")
    @Mapping(target = "scottishApplication", source = "application.scottishApplication",
            qualifiedByName = "toGMSYesOrNo")
    @Mapping(target = "directApplication", source = "application.channel", qualifiedByName = "toGMSDirectApplication")
    @Mapping(target = "newContractRequired", expression = "java(config.getNewContract())")
    @Mapping(target = "group", expression = "java(config.getGroup())")
    @Mapping(target = "branch", source = "branch")
    @Mapping(target = "operator", expression = "java(config.getXoUserid())")
    @Mapping(target = "channel", source = "application.channel")
    @Mapping(target = "marketingSource", source = "application.marketingSource")
    @Mapping(target = "marketingSchemeNumber", ignore = true)
    @Mapping(target = "completionDate", ignore = true)
    @Mapping(target = "indirectSourceDetails", ignore = true)
    @Named("toApplicationGeneralDetails")
    abstract ApplicationGeneralDetails mapToApplicationGeneralDetails(Application application);

    @Named("checksolicitorId")
    BigInteger checksolicitorId(Application source, @Context WorkflowContext workflowContext) {

        String brand = (String) Optional.ofNullable(workflowContext.getOriginalHeaders())
                .map(headers -> headers.get(BRAND_HEADER)).get();
        BigInteger solicitorId = brand.equals("rbs") ? config.getSolicitorIdRbs() : config.getSolicitorId();

        return solicitorId;
    }


    @ValueMapping(source = "INTERNET", target = "DR")
    abstract String mapToGMSChannel(Application.ChannelEnum channel);

    @Named(value = "toGMSDirectApplication")
    String toGMSDirectApplication(Application.ChannelEnum channel) {
        //TODO - add channel check when supporting more channels - Day 1 requirement is to support DIRECT channel only
        return "Y";
    }

    @Named("toLoanAmount")
    BigDecimal toLoanAmount(BorrowingDetails borrowingDetails) {
        return borrowingDetails.getAdditionalBorrowings().stream()
                .map(aB -> aB.getAmount()).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Named("toAdditionalBorrowingDetails")
    AdditionalBorrowingDetails toAdditionalBorrowingDetails(BorrowingDetails source) {
        return AdditionalBorrowingDetails.builder().additionalBorrowing(
                source.getAdditionalBorrowings().stream().map(ab -> toAdditionalBorrowing(ab))
                        .collect(Collectors.toList())).build();
    }

    @Mapping(target = "purpose", source = "reason")
    @Mapping(target = "amount", source = "amount")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.
            AdditionalBorrowing toAdditionalBorrowing(
                AdditionalBorrowing additionalBorrowing);

    @Named("toAssociatedAccounts")
    AssociatedAccounts toAssociatedAccounts(BorrowingDetails source) {
        List<AssociatedAccount> associatedAccounts = new ArrayList<>();
        associatedAccounts.addAll(source.getAdditionalBorrowings().stream()
                .map(ab -> AssociatedAccount.builder()
                        .calculationType(mapToGMSCalculationType(source.getRepaymentType()))
                        .loanAmount(ab.getAmount())
                        .productCode(source.getProducts().stream().findFirst().get().getProductCode())
                        .termMonths(source.getTermMonths())
                        .termYears(source.getTermYears())
                        .loanPurpose(mapToGMSBorrowingReason(ab.getReason()))
                        .regulatedAuthority(regulatedAuthority)
                        .regulatedAuthorityOverridenBy(regulatedAuthorityOverridenBy).build())
                .collect(Collectors.toList()));
        return AssociatedAccounts.builder().associatedAccount(associatedAccounts).build();
    }

    @Named("toFeeDetails")
    FeeDetails toFeeDetails(Set<ProductDetails> source) {
        ProductDetails productDetails = source.stream().findFirst().get();
        Set<Fee> fees = new HashSet<>();
        if (CollectionUtils.isNotEmpty(productDetails.getFees())) {
            fees = Optional.ofNullable(
                    productDetails.getFees().stream().filter(f -> f.getAction().equals(Fee.ActionEnum.NO_ACTION))
                            .collect(Collectors.toSet())).orElse(null);
        }
        if (isNotEmpty(fees)) {
            FeeDetails feeDetails =
                    FeeDetails.builder().fee(fees.stream().map(this::mapToGMSFee).collect(Collectors.toList())).build();
            return feeDetails;
        }
        return null;
    }

    @Mapping(target = "otherOccupants", ignore = true)
    @Mapping(target = "estimatedValue", source = "existingMortgage.mortgageProperty",
            qualifiedByName = "toEstimatedValue")
    @Mapping(target = "viewingArrangements.contact", source = "application", qualifiedByName = "toViewingContact")
    @Mapping(target = "viewingArrangements.sellingAgent", source = "application", qualifiedByName = "toSellingAgent")
    @Named("toPropertyDetails")
    abstract PropertyDetails toPropertyDetails(Application application);

    @Named("toEstimatedValue")
    BigDecimal toEstimatedValue(com.natwest.pbbdhb.openapi.PropertyDetails source) {
        return Optional.ofNullable(source.getEstimatedValueByCustomer()).orElse(source.getEstimatedValueByHPI());
    }

    //To GMS Viewing Contact
    @Named(value = "toViewingContact")
    Contact toViewingContact(Application application) {
        Applicant viewingContact = application.getApplicants().get(0);
        Address viewingContactAddress = BaseMapper.toCurrentAddress(viewingContact.getAddresses());
        return Contact.builder().name(getViewingOrSellingContactName(application)).contactAddress(
                        ContactAddress.builder().address1(mapToGMSApplicantAddressLine1(viewingContactAddress))
                                .address2(mapToGMSApplicantAddressLine2(viewingContactAddress))
                                .address3(mapToGMSApplicantAddressLine3(viewingContactAddress))
                                .address4(mapToGMSApplicantAddressLine4(viewingContactAddress))
                                .address5(mapToGMSApplicantAddressLine5(viewingContactAddress))
                                .addressPC(mapToPostcode(viewingContactAddress))
                                .addressCountry(toCountryCode(viewingContactAddress)).build())
                .telephoneNumber(getViewingOrSellingContactNumber(application)).build();
    }

    @Named(value = "toSellingAgent")
    SellingAgent toSellingAgent(Application application) {
        PersonalDetails personalDetails = application.getApplicants().get(0).getPersonalDetails();
        Address applicantAddress = BaseMapper.toCurrentAddress(application.getApplicants().get(0).getAddresses());
        return SellingAgent.builder().name(getViewingOrSellingContactName(application))
                .telephoneNumber(getViewingOrSellingContactNumber(application)).sellingAgentAddress(
                        ContactAddress.builder().address1(mapToGMSApplicantAddressLine1(applicantAddress))
                                .address2(mapToGMSApplicantAddressLine2(applicantAddress))
                                .address3(mapToGMSApplicantAddressLine3(applicantAddress))
                                .address4(mapToGMSApplicantAddressLine4(applicantAddress))
                                .address5(mapToGMSApplicantAddressLine5(applicantAddress))
                                .addressPC(mapToPostcode(applicantAddress))
                                .addressCountry(toCountryCode(applicantAddress)).build()).build();
    }

    private String getViewingOrSellingContactName(Application application) {
        if (Objects.nonNull(application.getExistingMortgage().getMortgageProperty().getValuationContact())) {
            return application.getExistingMortgage().getMortgageProperty().getValuationContact().getName();
        }
        PersonalDetails personalDetails = application.getApplicants().get(0).getPersonalDetails();
        return new StringBuilder(
                personalDetails.getTitle().equals(PersonalDetails.TitleEnum.OTHER)
                        ? personalDetails.getOtherTitle() : mapToTitle(personalDetails.getTitle())).append(" ")
                .append(personalDetails.getFirstNames().trim().charAt(0)).append(" ")
                .append(personalDetails.getLastName()).toString();
    }

    private String getViewingOrSellingContactNumber(Application application) {
        if (Objects.nonNull(application.getExistingMortgage().getMortgageProperty().getValuationContact())) {
            return application.getExistingMortgage().getMortgageProperty().getValuationContact().getTelephoneNumber();
        }
        return toPersonalNumber(application.getApplicants().get(0).getPersonalDetails().getTelephones());
    }

    //Map To GMS Fee
    @Mapping(target = "feeCode", source = "code")
    @Mapping(target = "isHLC", ignore = true)
    @Mapping(target = "chargedAmount", ignore = true)
    @Mapping(target = "feeAction", source = "action")
    @Mapping(target = "capitaliseHLCFee", ignore = true)
    @Mapping(target = "costAmount", ignore = true)
    @Mapping(target = "policyNumber", ignore = true)
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.Fee mapToGMSFee(Fee fee);

    //Map To GMS Calculation types
    @ValueMapping(source = "CAPITAL_AND_INTEREST", target = "C")
    abstract String mapToGMSCalculationType(BorrowingDetails.RepaymentTypeEnum repaymentTypeEnum);

    //Map To GMS Fee Action
    @ValueMapping(source = "NO_ACTION", target = "N")
    @ValueMapping(source = "DEDUCT_FROM_ADVANCE", target = "D")
    @ValueMapping(source = "ADD_CAPITALISE_TO_LOAN", target = "C")
    abstract String mapToGMSFeeAction(Fee.ActionEnum actionEnum);

    @ValueMapping(source = "TELEPHONE", target = "T")
    @ValueMapping(source = "FACE_TO_FACE", target = "F")
    @ValueMapping(source = "NONE", target = "N")
    abstract String mapToGMSInterviewType(ServiceLevel.InterviewEnum source);

    @ValueMapping(source = "ADVISED", target = "AI")
    @ValueMapping(source = "ADVICE_REJECTED", target = "AR")
    @ValueMapping(source = "NON_ADVISED", target = "EX")
    @ValueMapping(source = "EXECUTION_ONLY", target = "EO")
    abstract String mapToGMSLevelOfService(ServiceLevel.LevelOfServiceEnum source);

    @ValueMapping(source = "HOME_IMPROVEMENT", target = "HI")
    @ValueMapping(source = "HOUSE_PURCHASE", target = "HP")
    @ValueMapping(source = "BUY_TO_LET", target = "HP")
    @ValueMapping(source = "BUY_OUT", target = "BY")
    @ValueMapping(source = "WEDDING", target = "WE")
    @ValueMapping(source = "EDUCATION", target = "OT")
    @ValueMapping(source = "REDEEM_SECOND_CHARGE", target = "PC")
    @ValueMapping(source = "HOLIDAY", target = "HO")
    @ValueMapping(source = "GIFT", target = "OT")
    @ValueMapping(source = "MEDICAL", target = "OT")
    @ValueMapping(source = "BUY_NEW_CAR", target = "CN")
    @ValueMapping(source = "DEBT_CONSOLIDATION", target = "RF")
    abstract String mapToGMSBorrowingReason(AdditionalBorrowing.ReasonEnum reason);
}
