package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.toolkit;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateToolkitNotesRequest {
    private String userId;
    private String decisionUniqueId;
    private String gmsRefNo;
    private String source;
}
