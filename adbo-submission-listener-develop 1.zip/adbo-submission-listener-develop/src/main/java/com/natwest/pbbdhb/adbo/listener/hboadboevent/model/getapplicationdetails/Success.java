package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Success implements Serializable {
    private static final long serialVersionUID = 1L;
    @JsonProperty("case")
    private Case caseObj;
    private ApplicationGeneralDetails applicationGeneralDetails;
    private SummarySelection mortgageSummary;
    private RepaymentSelection repaymentProfile;
    private AccountSelection accounts;
    private InsuranceSelection insurances;
    private PPPSelection pppInsurances;
    private StageHistory stageHistory;
    private CaseHistory caseHistory;
    private AdditionalProductSwitchDetails additionalProductSwitchDetails;
    private FeeDetails feeDetails;
    private IndirectSourceDetails indirectSourceDetails;
}
