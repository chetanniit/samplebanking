package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.AddressPostcodeConstraint;
import com.natwest.pbbdhb.openapi.Address;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_UK_POSTCODE_FORMAT;
import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isNotBlank;

public class AddressPostcodeValidator implements ConstraintValidator<AddressPostcodeConstraint, Address> {

    @Override
    public boolean isValid(final Address address, final ConstraintValidatorContext constraintValidatorContext) {
        return isNull(address) || !ADBOUtils.isUkAddress(address.getCountryIsoCode())
                || (isNotBlank(address.getPostcode()) && Pattern
                        .matches(STANDARD_UK_POSTCODE_FORMAT, address.getPostcode()));
    }
}
