package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.ApplicationType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.BuyerType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.LoanPurpose;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.SchemeType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.ServiceName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class HardScoreApplication {
    @SuppressWarnings("checkstyle:visibilitymodifier")
    public Mortgage mortgage;
    private String caseId;
    private Boolean contactPermission;
    private ApplicationType applicationType;
    private LoanPurpose loanPurpose;
    private BuyerType buyerType;
    private Boolean govtSharedEquityScheme;
    private SchemeType schemeType;
    private String schemeName;
    private Boolean mainResidence;
    private List<Applicant> applicants;
    private Broker broker;
    private PurchaseProperty property;
    private ServiceName additionalServicesRequired;
    private Integer numberOfDependantsOver18;
    private Integer numberOfDependantsUnder18;
    private ApplicationAdditionalBorrowing additionalBorrowing;
    private String mortgageReferenceNumber;
}
