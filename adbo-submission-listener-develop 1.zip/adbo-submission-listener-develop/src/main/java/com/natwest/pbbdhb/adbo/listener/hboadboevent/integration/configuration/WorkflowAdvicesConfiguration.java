package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.configuration;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpCallTimestampCaptor;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import lombok.extern.slf4j.Slf4j;
import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInterceptor;
import org.aspectj.lang.annotation.Around;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.handler.advice.ExpressionEvaluatingRequestHandlerAdvice;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.CREATE_OR_RETRIEVE_APPLICATION_ERROR_INPUT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.CREATE_STATE_ERROR_INPUT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.UPDATE_APPLICATION_ERROR_INPUT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.WORKFLOW_EXECUTION_ERROR_INPUT;

@Configuration
@Slf4j
public class WorkflowAdvicesConfiguration {

    @Around("execution(* org.springframework.integration.handler.AbstractReplyProducingMessageHandler"
            + ".handleRequestMessage(..))")
    @Bean("workflowExecutionLogHttpResponseTimeAdvice")
    public Advice workflowExecutionLogHttpResponseTimeAdvice() {
        return (MethodInterceptor) invocation -> {
            HttpCallTimestampCaptor.clear();
            final Instant start = Instant.now();
            HttpCallTimestampCaptor.setSendTimestamp(LocalDateTime.ofInstant(start, ZoneOffset.UTC));
            Object result = invocation.proceed();
            final Instant end = Instant.now();
            HttpCallTimestampCaptor.setReceiveTimestamp(LocalDateTime.ofInstant(end, ZoneOffset.UTC));
            log.info("Total response time taken={}ms", Duration.between(start, end).toMillis());
            return result;
        };
    }

    @Around("execution(* org.springframework.integration.handler.AbstractReplyProducingMessageHandler"
            + ".handleRequestMessage(..))")
    @Bean("workflowExecutionStateLogHttpResponseTimeAdvice")
    public Advice workflowExecutionStateLogHttpResponseTimeAdvice() {
        return (MethodInterceptor) invocation -> {
            final Instant start = Instant.now();
            Object result = invocation.proceed();
            final Instant end = Instant.now();
            log.info("Total response time taken={}ms", Duration.between(start, end).toMillis());
            return result;
        };
    }

    @Bean("workflowExecutionErrorHandlerAdvice")
    public Advice workflowExecutionErrorHandlerAdvice() {
        ExpressionEvaluatingRequestHandlerAdvice advice = new ExpressionEvaluatingRequestHandlerAdvice();
        advice.setFailureChannelName(WORKFLOW_EXECUTION_ERROR_INPUT);
        advice.setTrapException(true);
        return advice;
    }

    @Bean("workflowExecutionUpdateApplicationErrorHandlerAdvice")
    public Advice workflowExecutionUpdateApplicationErrorHandlerAdvice() {
        ExpressionEvaluatingRequestHandlerAdvice advice = new ExpressionEvaluatingRequestHandlerAdvice();
        advice.setFailureChannelName(UPDATE_APPLICATION_ERROR_INPUT);
        advice.setTrapException(true);
        return advice;
    }

    @Bean("workflowExecutionCreateStateErrorHandlerAdvice")
    public Advice workflowExecutionCreateStateErrorHandlerAdvice() {
        ExpressionEvaluatingRequestHandlerAdvice advice = new ExpressionEvaluatingRequestHandlerAdvice();
        advice.setFailureChannelName(CREATE_STATE_ERROR_INPUT);
        advice.setTrapException(true);
        return advice;
    }

    @Bean("workflowExecutionCreateOrRetrieveApplicationErrorHandlerAdvice")
    public Advice workflowExecutionCreateOrRetrieveApplicationErrorHandlerAdvice() {
        ExpressionEvaluatingRequestHandlerAdvice advice = new ExpressionEvaluatingRequestHandlerAdvice();
        advice.setFailureChannelName(CREATE_OR_RETRIEVE_APPLICATION_ERROR_INPUT);
        advice.setTrapException(true);
        return advice;
    }
}
