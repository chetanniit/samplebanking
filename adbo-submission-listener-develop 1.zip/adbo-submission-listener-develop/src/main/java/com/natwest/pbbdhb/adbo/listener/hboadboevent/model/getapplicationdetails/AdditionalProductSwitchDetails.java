package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AdditionalProductSwitchDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    private LocalDate createDate;
    private BigDecimal regularPaymentAmount;
    private LocalDate anticipatedCompletionDate;
    private String linkedKFIApplSeq;
    private String levelOfService;
}
