package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Insurance implements Serializable {
    private static final long serialVersionUID = 1L;
    private String standard;
    private String policyClass;
    private String insuranceProductCode;
    private String insuranceProductDescription;
    private String insuranceCompanyCode;
    private String insuranceCompanyDescription;
    private String debitFrequency;
    private BigDecimal sumInsured;
    private BigDecimal premium;
}
