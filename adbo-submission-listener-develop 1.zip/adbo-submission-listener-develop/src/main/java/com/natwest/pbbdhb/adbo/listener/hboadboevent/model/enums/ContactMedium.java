package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ContactMedium {

    EMAIL("Email", "Email"),
    MAIL("Mail", "Mail"),
    SMS("SMS", "SMS"),
    PHONE("Phone", "Phone"),
    INTERACTIVE_VOICE_RESPONSE("InteractiveVoiceResponse", "Interactive Voice Response");

    private String key;

    private String value;

    @Override
    public String toString() {
        return key;
    }
}
