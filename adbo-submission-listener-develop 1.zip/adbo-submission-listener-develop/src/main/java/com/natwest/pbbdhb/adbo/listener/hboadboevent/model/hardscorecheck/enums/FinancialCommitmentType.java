package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum FinancialCommitmentType {
    CHILD_SUPPORT, RENT, SCHOOL_FEES, CHILD_CARE_COSTS, ADULT_CARE_COSTS, GROUND_RENT, SERVICE_CHARGE, ESTATE_CHARGE,
    HELP_TO_BUY_LOAN, OTHER_COMMITTED_EXPENDITURE
}
