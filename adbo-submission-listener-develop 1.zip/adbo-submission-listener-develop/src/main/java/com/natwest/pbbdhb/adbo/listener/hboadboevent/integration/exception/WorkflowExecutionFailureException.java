package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class WorkflowExecutionFailureException extends RuntimeException {
    private String message;
    private WorkflowContext workflowContext;

    public WorkflowExecutionFailureException(String pMessage, Throwable cause) {
        super(pMessage, cause);
        this.message = pMessage;
    }

    public WorkflowExecutionFailureException(String pMessage, Throwable cause, WorkflowContext pWorkflowContext) {
        this(pMessage, cause);
        this.workflowContext = pWorkflowContext;
    }
}
