package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditHistory {
    private Boolean bankrupt;
    private String bankruptDetails;
    private Boolean courtProceedings;
    private String courtProceedingDetails;
}
