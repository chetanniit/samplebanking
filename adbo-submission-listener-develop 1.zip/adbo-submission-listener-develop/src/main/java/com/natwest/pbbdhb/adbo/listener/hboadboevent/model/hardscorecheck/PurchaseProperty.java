package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.PropertyType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.Tenure;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PurchaseProperty {
    private String numberBedrooms;
    private String floor;
    private String numberOfFlats;
    private Tenure propertyTenure;
    private String remainingLeasehold;
    private LocalDate whenBuilt;
    private LocalDate refurbishedDate;
    private Boolean nhbcCertificate;
    private Boolean declarationKnowYourProperty;
    private Boolean consentToShareDetailsWithSurveyProvider;
    private Integer termRemaining;
    private String propertyBuilder;
    private String propertyDevelopment;
    private BasicAddress address;
    private PropertyType type;
}
