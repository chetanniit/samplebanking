package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.math.BigInteger;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplicantSolicitor {
    @PositiveOrZero
    @Digits(integer = 9, fraction = 0)
    private BigInteger applicantSolicitorId;

    @Size(max = 45)
    private String name;

    @Size(max = 30)
    private String contactName;

    @PositiveOrZero
    @Digits(integer = 10, fraction = 2)
    private BigDecimal conveyancyFee;

    @Valid
    private BaseAddress applicantSolicitorAddress;

}
