package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.GMSTask;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.TaskAction;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.managetask.ManageTaskRequest;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;

@Slf4j
@Mapper(componentModel = "spring")
public abstract class CreateADBOSwicherRequestMapper extends CreateManageTaskRequestMapper
        implements WorkflowMapper<WorkflowContext, ManageTaskRequest> {

    public ManageTaskRequest map(WorkflowContext source) {
        return mapToManageTaskRequest(source, GMSTask.DAS, TaskAction.OPEN, null);
    }

}
