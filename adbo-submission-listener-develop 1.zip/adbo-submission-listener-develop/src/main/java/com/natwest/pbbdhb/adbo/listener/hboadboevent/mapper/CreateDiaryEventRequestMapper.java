package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.dairyevent.DiaryEventRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers.DiaryEventNotesTransformer;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring")
public abstract class CreateDiaryEventRequestMapper implements WorkflowMapper<WorkflowContext, DiaryEventRequest>, BaseMapper{

    @Autowired
    private DiaryEventNotesTransformer diaryEventNotesTransformer;


    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;


    public DiaryEventRequest map(WorkflowContext source) {
        return mapToDiaryEventRequest(source);
    }

    @Mapping(target = "accountNumber", source = "source", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "note", source = "source", qualifiedByName = "getDiaryEventNotes")
    @Mapping(target=  "diaryEvent", constant="PRICOH")
    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target=  "function", constant="SUM07304")
    @Mapping(target=  "param1", constant="PC")
    @Mapping(target=  "param2", constant="1")
    @Mapping(target = "society", expression = "java(new java.math.BigInteger(config.getSociety()))")
    abstract DiaryEventRequest mapToDiaryEventRequest(WorkflowContext source);

    @Named("getDiaryEventNotes")
    String getDiaryEventNotes(WorkflowContext context) {
        return diaryEventNotesTransformer.transform(context);
    }
}
