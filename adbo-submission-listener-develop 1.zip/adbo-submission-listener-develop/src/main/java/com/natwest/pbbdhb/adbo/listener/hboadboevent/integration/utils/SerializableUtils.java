package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Objects;

@Slf4j
public class SerializableUtils {

    @SuppressWarnings("PMD.ReturnEmptyCollectionRatherThanNull")
    public static byte[] serialize(final Object object) {
        if (Objects.nonNull(object)) {
            log.info("Started to serialize the object: " + object.getClass().getName());
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = null;
            try {
                oos = new ObjectOutputStream(bos);
                oos.writeObject(object);
                oos.flush();
                byte[] stream = bos.toByteArray();
                log.info("Finished serializing object: " + object.getClass().getName());
                return stream;
            } catch (IOException ex) {
                log.error("Error occurred while serializing WorkflowContext", ex);
            } finally {
                try {
                    if (Objects.nonNull(oos)) {
                        oos.close();
                    }
                    bos.close();
                } catch (IOException ex) {
                    log.error("Error occurred while closing ByteArrayOutputStream during serialization", ex);
                }
            }
        }
        return null;
    }

    public static <T> T deSerialize(final byte[] input, final Class<T> expectedType) {
        if (Objects.nonNull(input)) {
            log.info("Started to de-serialize the byte stream");
            ByteArrayInputStream bis = new ByteArrayInputStream(input);
            ObjectInputStream ois = null;
            try {
                ois = new ObjectInputStream(bis);
                Object object = ois.readObject();
                log.info("Finished de-serializing the byte stream to object: " + object.getClass().getName());
                return (T) object;
            } catch (Exception ex) {
                log.error("Error occurred while de-serialization", ex);
            } finally {
                try {
                    if (Objects.nonNull(ois)) {
                        ois.close();
                    }
                    bis.close();
                } catch (IOException ex) {
                    log.error("Error occurred while closing ObjectInput/ByteArrayInputStream during deserialization",
                            ex);
                }
            }
        }
        return null;
    }
}

