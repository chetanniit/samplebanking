package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import lombok.Data;

@Data
public class GetCustomerProductDescription implements Serializable {
    private static final long serialVersionUID = 1L;

    private GetCustomerCodeDescription accountType;
    private GetCustomerCodeDescription interestControl;
    private GetCustomerCodeDescription redemptionControl;
    private GetCustomerCodeDescription regulationCode;
}
