package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatedeedsheldniindicator.DeedsHeldDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatedeedsheldniindicator.NIIndicatorDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatedeedsheldniindicator.UpdateDeedsHeldNIIndicatorRequest;
import com.natwest.pbbdhb.openapi.Application;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import static java.util.Objects.nonNull;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class UpdateDeedsHeldAndNIIndicatorRequestMapper
        implements WorkflowMapper<WorkflowContext, UpdateDeedsHeldNIIndicatorRequest>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    @Override
    public UpdateDeedsHeldNIIndicatorRequest map(WorkflowContext workflowContext) {
        return mapToUpdateDeedsHeldNIIndicatorRequest(workflowContext,
                (Application) workflowContext.getOriginalPayload());
    }


    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target = "mortgage", source = "workflowContext", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "applSeq", source = "workflowContext", qualifiedByName = "getApplicationSequenceNumber")
    @Mapping(target = "applicationGeneralDetails", source = "source", qualifiedByName = "mapNIIndicatorDetails")
    @Mapping(target = "propertyDetails", source = "source", qualifiedByName = "mapDeedsHeldDetails")
    abstract UpdateDeedsHeldNIIndicatorRequest mapToUpdateDeedsHeldNIIndicatorRequest(WorkflowContext workflowContext,
            Application source);

    @Named("mapNIIndicatorDetails")
    NIIndicatorDetails mapNIIndicatorDetails(
            Application source) {
        Boolean northernIrelandApplication = source.getNorthernIrelandApplication();
        return nonNull(northernIrelandApplication) ? NIIndicatorDetails.builder()
                .northernIrelandApplication(toGMSYesOrNo(northernIrelandApplication)).build() : null;
    }

    @Named("mapDeedsHeldDetails")
    DeedsHeldDetails mapDeedsHeldDetails(
            Application source) {
        return DeedsHeldDetails.builder().deedsHeld("N").build();
    }
}
