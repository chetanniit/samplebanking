package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpError;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpErrorResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ADBOSubmissionResult;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ADBOSubmitRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.LoanPurpose;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.Error;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;

import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.BRAND_HEADER;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class ADBOSubmissionResultMapper
        implements WorkflowMapper<WorkflowContext, ADBOSubmissionResult>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    @Value("${application.config.kafka.max-attempts}")
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected int maxAttempts;

    public ADBOSubmissionResult map(final WorkflowContext source) {
        Application application = ADBOWorkflowUtils.getOriginalPayload(source);
        return ADBOSubmissionResult.builder()
                .brand(Optional.ofNullable(source.getOriginalHeaders()).map(headers -> headers.get(BRAND_HEADER))
                        .filter(String.class::isInstance).map(String.class::cast).orElse(null))
                .uiId(application.getUiId()).channel(application.getChannel().name())
                .applicationType(application.getApplicationType()).loanPurpose(LoanPurpose.ADDITIONAL_BORROWING)
                .caseId(application.getCaseId()).mortgageRefNo(ADBOWorkflowUtils.getMortgageNumber(source))
                .mortgageApplSeq(ADBOWorkflowUtils.getAppSeq(source)).caseId(application.getCaseId())
                .status(ADBOWorkflowUtils.chekWorkflowStatus(source, maxAttempts)).tempRefNo(source.getFlowId())
                .submitDateTime(Optional.ofNullable(ADBOWorkflowUtils.getBaseResponsesTimestamp(source,
                                ADBOSubmitRoutingSlip.SUBMIT_FURTHER_ADVANCE.getRequestChannel()))
                        .map(sd -> sd.format(DateTimeFormatter.ISO_DATE_TIME)).orElse(null)).application(application)
                .errors(mapToErrors(source)).hardscoreDecision(ADBOWorkflowUtils.getHardScoreDecision(source))
                .userId(config.getXoUserid()).build();

    }

    public List<Error> mapToErrors(final WorkflowContext source) {
        List<HttpError> httpErrors = getErrorResponse(source);
        if (!CollectionUtils.isEmpty(httpErrors)) {
            return httpErrors.stream().map(he -> Error.builder().message(he.getMessage()).build()
                            .code(source.findFailedRoute().getRequestChannel() + "Failed"))
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    protected List<HttpError> getErrorResponse(WorkflowContext context) {
        return context.getRoutingSlip().values().stream().flatMap(route -> route.getErrorResponse().entrySet().stream()
                        .filter(errorResponse -> !Boolean.TRUE.equals(route.getFailSafeResult()
                                .get(errorResponse.getKey())))
                        .map(Map.Entry::getValue))
                .map(var -> ((HttpErrorResponse) ((BaseResponse) var).getResponse()).getErrors())
                .filter(Objects::nonNull).flatMap(List::stream).collect(Collectors.toList());
    }
}
