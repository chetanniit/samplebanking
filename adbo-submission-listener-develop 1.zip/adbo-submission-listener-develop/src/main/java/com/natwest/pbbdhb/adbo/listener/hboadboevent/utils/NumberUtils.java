package com.natwest.pbbdhb.adbo.listener.hboadboevent.utils;

import lombok.experimental.UtilityClass;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static java.util.Optional.ofNullable;

@UtilityClass
public class NumberUtils {

    public static BigDecimal roundDown(BigDecimal value) {
        return ofNullable(value).map(it -> it.setScale(0, RoundingMode.FLOOR)).orElse(value);
    }

}
