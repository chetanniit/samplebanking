package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.strategy;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.context.expression.BeanExpressionContextAccessor;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.integration.routingslip.RoutingSlipRouteStrategy;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.WORKFLOW_EXECUTION_OUTPUT_INPUT;

@Service("WorkflowExecutionRouteStrategy")
@Slf4j
public class WorkflowRouteStrategy implements RoutingSlipRouteStrategy, BeanFactoryAware {

    private BeanFactory beanFactory;

    @Override
    @SuppressWarnings("checkstyle:innerassignment")
    public Object getNextPath(Message<?> m, Object o) {
        final WorkflowContext wc = m.getHeaders().get(WORKFLOW_CONTEXT_HEADER, WorkflowContext.class);

        AtomicInteger routeIndex =
                m.getHeaders().get(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER, AtomicInteger.class);
        int nextRouteIndex = routeIndex.get();

        if (!wc.getRoutingSlip().containsKey(nextRouteIndex)) {
            log.info("No route found for index={} in routing slip, incremented the routing index by 1",
                    routeIndex.get());
            routeIndex.incrementAndGet();
        }

        StandardEvaluationContext context = new StandardEvaluationContext(m);
        context.setBeanResolver(new BeanFactoryResolver(beanFactory));
        context.addPropertyAccessor(new BeanExpressionContextAccessor());
        nextRouteIndex = resolveNextRoute(wc, routeIndex, context);

        if (!CollectionUtils.isEmpty(wc.getRoutingSlip()) && nextRouteIndex <= wc.getRoutingSlip().size()) {
            final WorkflowRoutingSlip.Route nextRoute = wc.getRoutingSlip().get(nextRouteIndex);
            log.info("Resolved nextRoute={} for routingIndex={}", nextRoute.getRequestChannel(), routeIndex.get());

            long delayInMillis = 0;
            if (StringUtils.isNotBlank(nextRoute.getDelayExpression())
                    && (delayInMillis = new SpelExpressionParser().parseExpression(nextRoute.getDelayExpression())
                    .getValue(context, Long.class)) > 0) {
                log.info("Resolved nextRoute={} for delay expression={}", nextRoute.getRequestChannel(),
                        nextRoute.getDelayExpression());
                try {
                    Thread.sleep(delayInMillis);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }

            return nextRoute.getRequestChannel();
        } else {
            log.info("Resolving next route reached end of routes, current routingIndex={}", routeIndex.get());
            log.info("Returning to response building channel={}", WORKFLOW_EXECUTION_OUTPUT_INPUT);
            return WORKFLOW_EXECUTION_OUTPUT_INPUT;
        }
    }

    @SuppressWarnings("checkstyle:innerassignment")
    private int resolveNextRoute(WorkflowContext wc, AtomicInteger routeIndex, EvaluationContext context) {
        log.info("Resolving next route for routingIndex={}", routeIndex.get());
        WorkflowRoutingSlip.Route route = wc.getRoutingSlip().get(routeIndex.get());

        if (Objects.nonNull(route)) {
            Collection items = null;
            SpelExpressionParser parser = new SpelExpressionParser();
            if (StringUtils.isNotBlank(route.getLoopExpression())) {
                items = parser.parseExpression(route.getLoopExpression()).getValue(context, Collection.class);
            }

            if (route.isDeprecated()
                    || (StringUtils.isBlank(route.getLoopExpression()) && route.getCount().get() > 0)
                    || (StringUtils.isNotBlank(route.getConditionExpression())
                    && !parser.parseExpression(route.getConditionExpression()).getValue(context, Boolean.class))
                    || (StringUtils.isNotBlank(route.getLoopExpression())
                    && (CollectionUtils.isEmpty(items) || items.size() <= route.getCount().get()))) {
                log.info(
                        "Route with index={} does not qualify for execution(deprecated or condition not met or "
                                + "already completed), moving to evaluate the next route in the slip",
                        routeIndex.get());
                routeIndex.incrementAndGet();
                return resolveNextRoute(wc, routeIndex, context);
            }

            log.info("Incrementing the route count by 1 for routingIndex={}", routeIndex.get());
            route.getCount().incrementAndGet();

            if (!CollectionUtils.isEmpty(items) && StringUtils.isNotBlank(route.getLoopConditionExpression()) && !parser
                    .parseExpression(route.getLoopConditionExpression()).getValue(context, Boolean.class)) {
                log.info(
                        "Route with routingIndex={} and count={} does not qualify for execution, moving to evaluate "
                                + "the "
                                + "next route in the slip",
                        routeIndex.get(), route.getCount().get());
                return resolveNextRoute(wc, routeIndex, context);
            }
        }

        return routeIndex.get();
    }

    @Override
    public void setBeanFactory(BeanFactory pBeanFactory) throws BeansException {
        this.beanFactory = pBeanFactory;
    }
}
