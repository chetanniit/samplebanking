package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.OccupationCode;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.ApplicationAdditionalBorrowing;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Details;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.HardScoreApplication;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.OtherIncome;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.PurchaseProperty;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.ApplicationType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.BuyerType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.EmploymentType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.FinancialCommitmentType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.IncomeFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.IncomeType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.LoanPurpose;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.OccupyStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.OtherIncomeType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.PaymentFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.Purpose;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.ServiceName;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.SubAccountRepaymentType;
import com.natwest.pbbdhb.openapi.Address;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.BankDetails;
import com.natwest.pbbdhb.openapi.BorrowingDetails;
import com.natwest.pbbdhb.openapi.CreditCard;
import com.natwest.pbbdhb.openapi.Employment;
import com.natwest.pbbdhb.openapi.FinancialCommitment;
import com.natwest.pbbdhb.openapi.Income;
import com.natwest.pbbdhb.openapi.PersonalDetails;
import com.natwest.pbbdhb.openapi.PropertyDetails;
import com.natwest.pbbdhb.openapi.SubAccount;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.ValueMapping;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_FORMAT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.NumberUtils.roundDown;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR)
public abstract class HardScoreCheckRequestMapper
        implements WorkflowMapper<WorkflowContext, HardScoreApplication>, BaseMapper {

    protected static final ApplicationType APPLICATION_TYPE = ApplicationType.ADDITIONAL_BORROWING;
    protected static final LoanPurpose LOAN_PURPOSE = LoanPurpose.ADDITIONAL_BORROWING;
    protected static final BuyerType BUYER_TYPE = BuyerType.EXISTING_CUSTOMER;
    protected static final ServiceName SERVICE_NAME = ServiceName.NONE;
    protected static final BigDecimal REPAYMENT_CURRENT_VALUE = BigDecimal.valueOf(100000);
    protected static final PaymentFrequency PAYMENT_FREQUENCY = PaymentFrequency.MONTHLY;
    protected static final int MONTHS_IN_YEAR = 12;
    protected static final int FLAT_MAX_LENGTH = 10;
    protected static final int BANK_NAME_MAX_LENGTH = 30;
    protected static final int MIDDLE_NAMES_MAX_LENGTH = 25;

    public HardScoreApplication map(WorkflowContext source) {
        Application application = (Application) source.getOriginalPayload();
        return mapToHardScoreApplicationRequest(application);
    }

    @Mapping(target = "mortgageReferenceNumber", source = "existingMortgage.mortgageReferenceNumber")
    @Mapping(target = "caseId", source = "dipId")
    @Mapping(target = "contactPermission", expression = "java(Boolean.TRUE)")
    @Mapping(target = "applicationType", expression = "java(APPLICATION_TYPE)")
    @Mapping(target = "loanPurpose", expression = "java(LOAN_PURPOSE)")
    @Mapping(target = "buyerType", expression = "java(BUYER_TYPE)")
    @Mapping(target = "govtSharedEquityScheme", expression = "java(Boolean.FALSE)")
    @Mapping(target = "applicants", source = "applicants")
    @Mapping(target = "additionalBorrowing", source = "source", qualifiedByName = "mapToAdditionalBorrowings")
    @Mapping(target = "property", source = "existingMortgage.mortgageProperty",
            qualifiedByName = "mapToPurchaseProperty")
    @Mapping(target = "additionalServicesRequired", expression = "java(SERVICE_NAME)")
    @Mapping(target = "numberOfDependantsOver18", source = "numberOfDependantsOver18")
    @Mapping(target = "numberOfDependantsUnder18", source = "numberOfDependantsUnder18")
    @Mapping(target = "broker", ignore = true)
    @Mapping(target = "mortgage", ignore = true)
    @Mapping(target = "mainResidence", ignore = true)
    @Mapping(target = "schemeType", ignore = true)
    @Mapping(target = "schemeName", ignore = true)
    abstract HardScoreApplication mapToHardScoreApplicationRequest(Application source);


    @Named("mapToAdditionalBorrowings")
    @Mapping(target = "termYears", source = "borrowingDetails.termYears")
    @Mapping(target = "termMonths", source = "borrowingDetails.termMonths")
    @Mapping(target = "propertyValue", source = "existingMortgage.mortgageProperty",
            qualifiedByName = "mapToPropertyValue")
    @Mapping(target = "hpiUsed", source = "existingMortgage.mortgageProperty", qualifiedByName = "mapToHPIUsed")
    @Mapping(target = "details", source = "borrowingDetails", qualifiedByName = "mapToAdditionalBorrowingDetails")
    @Mapping(target = "subAccounts", source = "existingMortgage.mortgageSubAccounts",
            qualifiedByName = "mapToSubAccounts")
    @Mapping(target = "repaymentVehicle", ignore = true)
    @Mapping(target = "repaymentCurrentValue", ignore = true)
    @Mapping(target = "mortgageBefore20thSept2015", ignore = true)
    abstract ApplicationAdditionalBorrowing mapToAdditionalBorrowings(Application source);

    @Named("mapToPurchaseProperty")
    @Mapping(target = "type", source = "propertyType")
    @Mapping(target = "propertyTenure", source = "propertyTenure")
    @Mapping(target = "whenBuilt", source = "whenBuilt", dateFormat = STANDARD_DATE_FORMAT)
    @Mapping(target = "refurbishedDate", ignore = true)
    @Mapping(target = "numberBedrooms", ignore = true)
    @Mapping(target = "floor", ignore = true)
    @Mapping(target = "numberOfFlats", ignore = true)
    @Mapping(target = "remainingLeasehold", ignore = true)
    @Mapping(target = "nhbcCertificate", ignore = true)
    @Mapping(target = "declarationKnowYourProperty", ignore = true)
    @Mapping(target = "consentToShareDetailsWithSurveyProvider", ignore = true)
    @Mapping(target = "termRemaining", ignore = true)
    @Mapping(target = "propertyBuilder", ignore = true)
    @Mapping(target = "propertyDevelopment", ignore = true)
    @Mapping(target = "address", ignore = true)
    abstract PurchaseProperty mapToPurchaseProperty(PropertyDetails source);

    @Named("mapToCurrentBalance")
    BigDecimal mapToPropertyValue(BigDecimal source) {
        return source.setScale(0, BigDecimal.ROUND_DOWN);
    }

    @Named("mapToHPIUsed")
    boolean mapToHPIUsed(PropertyDetails source) {
        return !(Objects.nonNull(source.getEstimatedValueByCustomer())
                && source.getEstimatedValueByCustomer().compareTo(BigDecimal.ZERO) > 0);
    }

    @Named("mapToAdditionalBorrowingDetails")
    List<Details> mapToAdditionalBorrowingDetails(BorrowingDetails source) {
        return source.getAdditionalBorrowings().stream().map(ab -> mapToAdditionalBorrowingDetail(ab))
                .collect(Collectors.toList());
    }

    @Mapping(target = "purpose", source = "reason")
    @Mapping(target = "amount", source = "amount")
    abstract Details mapToAdditionalBorrowingDetail(com.natwest.pbbdhb.openapi.AdditionalBorrowing source);

    @Named("mapToSubAccounts")
    List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.SubAccount> mapToSubAccounts(
            List<SubAccount> source) {
        return source.stream().map(sa -> mapToSubAccount(sa)).collect(Collectors.toList());
    }

    @Mapping(target = "currentBalance", source = "remainingAmount", qualifiedByName = "mapToCurrentBalance")
    @Mapping(target = "termRemaining", source = "source", qualifiedByName = "mapToTermRemaining")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.SubAccount mapToSubAccount(
            SubAccount source);

    @Named("mapToTermRemaining")
    int mapToTermRemaining(SubAccount source) {
        return BigInteger.valueOf(source.getRemainingTermYears()).multiply(BigInteger.valueOf(MONTHS_IN_YEAR))
                .add(BigInteger.valueOf(source.getRemainingTermMonths())).intValue();
    }

    @ValueMapping(source = "HOME_IMPROVEMENT", target = "HOME_IMPROVEMENT")
    @ValueMapping(source = "HOUSE_PURCHASE", target = "HOUSE_PURCHASE")
    @ValueMapping(source = "HOLIDAY", target = "HOLIDAY")
    @ValueMapping(source = "BUY_NEW_CAR", target = "BUY_NEW_OR_USED_CAR")
    @ValueMapping(source = "DEBT_CONSOLIDATION", target = "DEBT_CONSOLIDATION")
    @ValueMapping(source = "BUY_TO_LET", target = "HOUSE_PURCHASE")
    @ValueMapping(source = "BUY_OUT", target = "BUY_OUT")
    @ValueMapping(source = "WEDDING", target = "WEDDING")
    @ValueMapping(source = "GIFT", target = "GIFT")
    @ValueMapping(source = "REDEEM_SECOND_CHARGE", target = "OTHER")
    @ValueMapping(source = "MEDICAL", target = "OTHER")
    @ValueMapping(source = "EDUCATION", target = "OTHER")
    abstract Purpose mapToPurpose(com.natwest.pbbdhb.openapi.AdditionalBorrowing.ReasonEnum source);

    @ValueMapping(source = "CAPITAL_AND_INTEREST", target = "REPAYMENT")
    abstract SubAccountRepaymentType mapToRepaymentType(SubAccount.RepaymentTypeEnum repaymentTypeEnum);

    @Mapping(target = "employment", source = "source.employments", qualifiedByName = "mapToEmployment")
    @Mapping(target = "mainBankDetails", source = "source.mainBankDetails", qualifiedByName = "mapToBankDetails")
    @Mapping(target = "otherIncomes", source = "source", qualifiedByName = "mapToOtherIncomes")
    @Mapping(target = "creditCards", source = "creditCards", qualifiedByName = "mapToCreditCards")
    @Mapping(target = "addresses", source = "addresses", qualifiedByName = "mapToAddresses")
    @Mapping(target = "financialCommitments", source = "financialCommitments",
            qualifiedByName = "mapToFinancialCommitments")
    @Mapping(target = "intendedRetirementAge", source = "retirementAge")
    @Mapping(target = "futureAffordability.commitmentsDueDuringMortgage", expression = "java(Boolean.FALSE)")
    @Mapping(target = "futureAffordability.otherCommitments", expression = "java(Boolean.FALSE)")
    @Mapping(target = "futureAffordability.propertyExpensesAffectingMortgagePayment",
            expression = "java(Boolean.FALSE)")
    @Mapping(target = "futureAffordability.personalChangesAmountAffectingTheMortgagePayment",
            source = "futureAffordability.personalChangesAmountAffectingTheMortgagePayment")
    @Mapping(target = "existingMortgages", ignore = true)
    @Mapping(target = "personalDetails", source = "source.personalDetails", qualifiedByName = "mapToMiddleNames")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Applicant mapToHardScoreApplicant(
            Applicant source);

    @Mapping(target = "applicant.employment", source = "employments")
    @Named("mapToEmployment")
    com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Employment toHardScoreEmployment(
            List<Employment> employments) {
        return toActiveEmployment(CollectionUtils.isNotEmpty(employments) ? employments.stream()
                .filter(emp -> emp.getPrimary() && ((StringUtils.isBlank(emp.getEndDate()) && !emp.getEmploymentType()
                        .equals(Employment.EmploymentTypeEnum.CONTRACT)) || (emp.getEmploymentType()
                        .equals(Employment.EmploymentTypeEnum.CONTRACT)
                        && Objects.nonNull(emp.getEndDate())
                        && toLocalDate(emp.getEndDate())
                        .isAfter(LocalDate.now()))))
                .findAny().orElse(null) : null);
    }

    @Named("mapToBankDetails")
    @Mapping(target = "bankName", source = "bankName", qualifiedByName = "mapToBankName")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.BankDetails mapToBankDetails(
        BankDetails source);

    @Named("mapToBankName")
    String mapToBankName(String source) {
        return StringUtils.isNotBlank(source)
            ? StringUtils.substring(source, 0, BANK_NAME_MAX_LENGTH) : source;
    }

    @Named("mapToMiddleNames")
    @Mapping(target = "middleNames", source = "middleNames", qualifiedByName = "mapToMiddleNames")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.PersonalDetails mapToMiddleNames(
        PersonalDetails source);

    @Named("mapToMiddleNames")
    String mapToMiddleNames(String source) {
        return StringUtils.isNotBlank(source)
            ? StringUtils.substring(source, 0, MIDDLE_NAMES_MAX_LENGTH) : source;
    }

    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.CreditCard mapToCreditCard(
            CreditCard source);

    @Named("mapToCreditCards")
    List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.CreditCard> mapToCreditCards(
            List<CreditCard> creditCards) {
        List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.CreditCard> hardScoreCreditCards =
                new ArrayList<>();
        if (CollectionUtils.isNotEmpty(creditCards)) {
            hardScoreCreditCards
                    .addAll(creditCards.stream().filter(c -> c.getTotalBalance().compareTo(BigDecimal.ZERO) > 0)
                            .map(this::mapToCreditCard).collect(Collectors.toList()));
        }
        return hardScoreCreditCards;
    }

    @Named("mapToFinancialCommitments")
    List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.FinancialCommitment>
    mapToFinancialCommitments(
            List<FinancialCommitment> source) {
        List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.FinancialCommitment>
                financialCommitments = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(source)) {
            financialCommitments
                    .addAll(source.stream().map(this::mapToFinancialCommitment).collect(Collectors.toList()));
        }
        return financialCommitments;
    }

    @Mapping(target = "type", source = "type")
    @Mapping(target = "monthlyPayments", source = "monthlyPayments")
    @Mapping(target = "paymentsContinuing", source = "paymentsContinuing")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.FinancialCommitment
    mapToFinancialCommitment(
            FinancialCommitment source);

    @Named("mapToAddress")
    @Mapping(target = "isCurrentAddress", source = "source", qualifiedByName = "mapToIsCurrentAddress")
    @Mapping(target = "ukAddress", source = "source", qualifiedByName = "mapToIsUkAddress")
    @Mapping(target = "flat", source = "flat", qualifiedByName = "mapToFlat")
    @Mapping(target = "startMonth", source = "startDate", qualifiedByName = "mapToStartMonth")
    @Mapping(target = "startYear", source = "startDate", qualifiedByName = "mapToStartYear")
    @Mapping(target = "endMonth", source = "endDate", qualifiedByName = "mapToEndMonth")
    @Mapping(target = "endYear", source = "endDate", qualifiedByName = "mapToEndYear")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Address mapToAddress(Address source);

    @Named("mapToIsCurrentAddress")
    boolean mapToIsCurrentAddress(Address source) {
        return StringUtils.isBlank(source.getEndDate());
    }

    @Named("mapToIsUkAddress")
    boolean mapToIsUkAddress(Address source) {
        return "GB".equals(source.getCountryIsoCode());
    }

    @Named("mapToStartMonth")
    Integer mapToStartMonth(String source) {
        return toLocalDate(source).getMonthValue();
    }

    @Named("mapToStartYear")
    Integer mapToStartYear(String source) {
        return toLocalDate(source).getYear();
    }

    @Named("mapToFlat")
    String mapToFlat(String source) {
        return StringUtils.isNotBlank(source)
                ? source.length() > FLAT_MAX_LENGTH ? source.substring(0, FLAT_MAX_LENGTH) : source : source;
    }

    @Named("mapToEndMonth")
    Integer mapToEndMonth(String source) {
        return Optional.ofNullable(source).filter(StringUtils::isNotBlank).map(s -> toLocalDate(s).getMonthValue())
                .orElse(null);
    }

    @Named("mapToEndYear")
    Integer mapToEndYear(String source) {
        return Optional.ofNullable(source).filter(StringUtils::isNotBlank).map(s -> toLocalDate(s).getYear())
                .orElse(null);
    }

    @Named("mapToAddresses")
    List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Address> mapToAddresses(
            Set<Address> source) {
        List<com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Address> addresses = new ArrayList<>();
        List<Address> sortedAddresses = new ArrayList<>(source);
        //Sort addresses in descending order
        Collections.sort(sortedAddresses, (o1, o2) -> o2.getStartDate().compareTo(o1.getStartDate()));
        addresses.addAll(sortedAddresses.stream().map(this::mapToAddress).collect(Collectors.toList()));
        return addresses;
    }

    @Named("mapToOtherIncomes")
    List<OtherIncome> mapToOtherIncomes(Applicant applicant) {
        List<OtherIncome> hardscoreOtherIncomes = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(applicant.getOtherIncomes())) {
            hardscoreOtherIncomes.addAll(applicant.getOtherIncomes().stream().map(oi -> mapToOtherIncome(oi))
                    .collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(applicant.getEmployments())) {
            List<Employment> nonPrimaryEmployments = applicant.getEmployments().stream()
                    .filter(emp -> !emp.getPrimary() && (StringUtils.isEmpty(emp.getEndDate()) || (
                            (emp.getEmploymentType().getValue()
                                    .equals(Employment.EmploymentTypeEnum.CONTRACT.getValue())) && toLocalDate(
                                    emp.getEndDate()).isAfter(LocalDate.now())))).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(nonPrimaryEmployments)) {
                BigDecimal totalFromNonPrimary =
                        nonPrimaryEmployments.stream().filter(e -> CollectionUtils.isNotEmpty(e.getIncomes()))
                                .flatMap(e -> e.getIncomes().stream()).map(i -> toAnnualIncomeAmount(i))
                                .reduce(BigDecimal.ZERO, BigDecimal::add).add(nonPrimaryEmployments.stream()
                                        .filter(e -> e.getEmploymentStatus()
                                                .equals(Employment.EmploymentStatusEnum.SELF_EMPLOYED))
                                        .map(e -> getSelfEmployedNonPrimaryIncome(e.getSelfEmployed())).
                                        map(v -> roundDown(v))
                                        .reduce(BigDecimal.ZERO, BigDecimal::add));
                if (totalFromNonPrimary.compareTo(BigDecimal.ZERO) > 0) {
                    hardscoreOtherIncomes.add(OtherIncome.builder().type(OtherIncomeType.OTHER_TAXABLE)
                            .amount(totalFromNonPrimary.toBigInteger()).frequency(IncomeFrequency.ANNUALLY).build());
                }
            }
        }
        return hardscoreOtherIncomes;
    }

    @Named("mapToOtherIncome")
    abstract OtherIncome mapToOtherIncome(com.natwest.pbbdhb.openapi.OtherIncome source);

    @Mapping(source = "dateOfBirth", target = "dateOfBirth", dateFormat = STANDARD_DATE_FORMAT)
    @Mapping(source = "countryOfResidenceIsoCode", target = "countryOfResidenceIsoCode",
            defaultExpression = "java(source.getNationality())")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.PersonalDetails
    toHardscorePersonalDetails(
            PersonalDetails source);

    @Mapping(source = "startDate", target = "startDate", dateFormat = STANDARD_DATE_FORMAT)
    @Mapping(source = "endDate", target = "endDate", dateFormat = STANDARD_DATE_FORMAT)
    @Mapping(target = "paymentFrequency", expression = "java(PAYMENT_FREQUENCY)")
    abstract com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Employment toActiveEmployment(
            Employment source);

    //TODO - Missing enums in hard score - LIVING_WITH_FAMILY, LIVING_WITH_FRIENDS, LIVING_WITH_PARTNER and
    // EXISTING_CUSTOMER_FURTHER_ADVANCED
    @ValueMapping(source = "LIVING_WITH_FAMILY", target = "LIVING_WITH_RELATIVES")
    @ValueMapping(source = "LIVING_WITH_FRIENDS", target = "LIVING_WITH_RELATIVES")
    @ValueMapping(source = "LIVING_WITH_PARTNER", target = "LIVING_WITH_RELATIVES")
    @ValueMapping(source = "OWNER_MORTGAGED", target = "OWNER_MORTGAGED")
    @ValueMapping(source = "OWNER_NO_MORTGAGE", target = "OWNER_NO_MORTGAGE")
    @ValueMapping(source = "TENANT", target = "TENANT")
    abstract OccupyStatus mapToOccupyStatus(Address.OccupyStatusEnum source);

    //TODO - Missing enums in hard score - PROBATION
    @ValueMapping(source = "PERMANENT", target = "PERMANENT")
    @ValueMapping(source = "CONTRACT", target = "CONTRACT")
    @ValueMapping(source = "TEMPORARY", target = "TEMPORARY")
    @ValueMapping(source = "PROBATION", target = "OTHER")
    @ValueMapping(source = "OTHER", target = "OTHER")
    abstract EmploymentType mapToEmploymentType(Employment.EmploymentTypeEnum source);

    //TODO - Missing enums in hard score - RENT_SHORTFALL, PENSION_CONTRIBUTION, RENT_WHILE_HOUSE_IMPROVEMENTS,
    // MORTGAGE_PAYMENTS and RUNNING_COSTS
    @ValueMapping(source = "CHILD_SUPPORT", target = "CHILD_SUPPORT")
    @ValueMapping(source = "RENT", target = "RENT")
    @ValueMapping(source = "RENT_SHORTFALL", target = "RENT")
    @ValueMapping(source = "PENSION_CONTRIBUTION", target = "OTHER_COMMITTED_EXPENDITURE")
    @ValueMapping(source = "RENT_WHILE_HOUSE_IMPROVEMENTS", target = "OTHER_COMMITTED_EXPENDITURE")
    @ValueMapping(source = "MORTGAGE_PAYMENTS", target = "OTHER_COMMITTED_EXPENDITURE")
    @ValueMapping(source = "RUNNING_COSTS", target = "OTHER_COMMITTED_EXPENDITURE")
    @ValueMapping(source = "SCHOOL_FEES", target = "SCHOOL_FEES")
    @ValueMapping(source = "CHILD_CARE_COSTS", target = "CHILD_CARE_COSTS")
    @ValueMapping(source = "ADULT_CARE_COSTS", target = "ADULT_CARE_COSTS")
    @ValueMapping(source = "GROUND_RENT", target = "GROUND_RENT")
    @ValueMapping(source = "SERVICE_CHARGE", target = "SERVICE_CHARGE")
    @ValueMapping(source = "ESTATE_CHARGE", target = "ESTATE_CHARGE")
    @ValueMapping(source = "HELP_TO_BUY_LOAN", target = "HELP_TO_BUY_LOAN")
    @ValueMapping(source = "OTHER_COMMITTED_EXPENDITURE", target = "OTHER_COMMITTED_EXPENDITURE")
    abstract FinancialCommitmentType mapToFinancialCommitmentType(FinancialCommitment.TypeEnum source);

    //TODO - Missing enums in hard score - ARTS, BUSINESS_AND_ADMINISTRATION, SCIENCES, SOCIAL_STUDIES, ENGINEERING,
    // MATHS_SCIENCES_AND_INFORMATICS, ARCHITECT_BUILDING_AND_PLANNING, HUMANITIES, AGRICULTURE,
    // LANGUAGES_AND_RELATED_SUBJECTS,
    // LAW, MEDICAL_AND_RELATED and NURSING
    @ValueMapping(source = "ARTS", target = "PROFESSIONALS")
    @ValueMapping(source = "BUSINESS_AND_ADMINISTRATION", target = "PROFESSIONALS")
    @ValueMapping(source = "SCIENCES", target = "PROFESSIONALS")
    @ValueMapping(source = "SOCIAL_STUDIES", target = "PROFESSIONALS")
    @ValueMapping(source = "ENGINEERING", target = "PROFESSIONALS")
    @ValueMapping(source = "MATHS_SCIENCES_AND_INFORMATICS", target = "PROFESSIONALS")
    @ValueMapping(source = "ARCHITECT_BUILDING_AND_PLANNING", target = "PROFESSIONALS")
    @ValueMapping(source = "HUMANITIES", target = "PROFESSIONALS")
    @ValueMapping(source = "AGRICULTURE", target = "PROFESSIONALS")
    @ValueMapping(source = "LANGUAGES_AND_RELATED_SUBJECTS", target = "PROFESSIONALS")
    @ValueMapping(source = "LAW", target = "PROFESSIONALS")
    @ValueMapping(source = "MEDICAL_AND_RELATED", target = "PROFESSIONALS")
    @ValueMapping(source = "NURSING", target = "PROFESSIONALS")
    @ValueMapping(source = "ACADEMIC_STAFF", target = "ACADEMIC_STAFF")
    @ValueMapping(source = "AGRICULTURAL_WORKERS_GENERAL", target = "AGRICULTURAL_WORKERS_GENERAL")
    @ValueMapping(source = "FARM_MANAGEMENT_GENERAL", target = "FARM_MANAGEMENT_GENERAL")
    @ValueMapping(source = "HM_FORCES_OFFICERS", target = "HM_FORCES_OFFICERS")
    @ValueMapping(source = "HM_FORCES_OTHER_RANKS", target = "HM_FORCES_OTHER_RANKS")
    @ValueMapping(source = "HOME_FAMILY_RESPONSIBILITIES", target = "HOME_FAMILY_RESPONSIBILITIES")
    @ValueMapping(source = "JUNIOR_MANAGEMENT", target = "JUNIOR_MANAGEMENT")
    @ValueMapping(source = "OFFICE_AND_CLERICAL", target = "OFFICE_AND_CLERICAL")
    @ValueMapping(source = "PROFESSIONALS", target = "PROFESSIONALS")
    @ValueMapping(source = "SALES", target = "SALES")
    @ValueMapping(source = "SEMI_PROFESSIONALS", target = "SEMI_PROFESSIONALS")
    @ValueMapping(source = "SEMI_SKILLED", target = "SEMI_SKILLED")
    @ValueMapping(source = "TECHNICIANS", target = "TECHNICIANS")
    @ValueMapping(source = "SENIOR_MANAGEMENT", target = "SENIOR_MANAGEMENT")
    @ValueMapping(source = "SERVICE_JOBS", target = "SERVICE_JOBS")
    @ValueMapping(source = "SKILLED_MANUAL", target = "SKILLED_MANUAL")
    @ValueMapping(source = "SUPERVISORY_FOREMAN", target = "SUPERVISORY_FOREMAN")
    @ValueMapping(source = "TEACHERS", target = "TEACHERS")
    @ValueMapping(source = "UNEMPLOYED", target = "UNEMPLOYED")
    @ValueMapping(source = "SELF_EMPLOYED", target = "SELF_EMPLOYED")
    @ValueMapping(source = "STUDENT", target = "STUDENT")
    @ValueMapping(source = "RETIRED", target = "RETIRED")
    @ValueMapping(source = "MANUAL", target = "MANUAL")
    abstract OccupationCode mapToOccupationCode(Employment.OccupationCodeEnum source);

    @ValueMapping(source = "BASIC_EARNINGS", target = "BASIC_EARNINGS")
    @ValueMapping(source = "BONUS_GUARANTEED", target = "BONUS_GUARANTEED_PAID_ANNUALLY")
    @ValueMapping(source = "OVERTIME_GUARANTEED", target = "OVERTIME_GUARANTEED")
    @ValueMapping(source = "COMMISSION_GUARANTEED", target = "COMMISSION_GUARANTEED")
    @ValueMapping(source = "SHIFT_ALLOWANCE_GUARANTEED", target = "SHIFT_ALLOWANCE_GUARANTEED")
    @ValueMapping(source = "BONUS_DISCRETIONARY", target = "BONUS_DISCRETIONARY_PAID_ANNUALLY")
    @ValueMapping(source = "OVERTIME_REGULAR", target = "OVERTIME_REGULAR")
    @ValueMapping(source = "COMMISSION_REGULAR", target = "COMMISSION_REGULAR")
    @ValueMapping(source = "SHIFT_ALLOWANCE_REGULAR", target = "SHIFT_ALLOWANCE_REGULAR")
    @ValueMapping(source = "PROFIT_SHARE", target = "PROFIT_SHARE")
    @ValueMapping(source = "DIVIDEND", target = "DIVIDEND")
    @ValueMapping(source = "CAR_ALLOWANCE", target = "CAR_ALLOWANCE")
    @ValueMapping(source = "MORTGAGE_SUBSIDY", target = "MORTGAGE_SUBSIDY")
    abstract IncomeType mapToIncomeType(Income.TypeEnum source);

    //TODO - Missing enums in hard score for these -
    // ADOPTION_ALLOWANCE,
    //                ATTENDANCE_ALLOWANCE,
    //                CHILD_WORKING_TAX_CREDIT,
    //                CONSTANT_ATTENDANCE_ALLOWANCE,
    //                EMPLOYMENT_AND_SUPPORT_ALLOWANCE,
    //                FOSTER_CARERS_ALLOWANCE,
    //                GUARDIANS_ALLOWANCE,
    //                INCOME_SUPPORT,
    //                INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT,
    //                PENSION_CREDIT,
    //                REDUCED_EARNINGS_ALLOWANCE,
    //                WIDOWED_PARENT_ALLOWANCE,
    //                WAR_WIDOW_PENSION
    @ValueMapping(source = "WORKING_FAMILIES_TAX_CREDIT", target = "WORKING_FAMILIES_TAX_CREDIT")
    @ValueMapping(source = "CHILD_BENEFIT", target = "CHILD_BENEFIT")
    @ValueMapping(source = "UNIVERSAL_CREDIT", target = "UNIVERSAL_CREDIT")
    @ValueMapping(source = "CARERS_ALLOWANCE", target = "CARERS_ALLOWANCE")
    @ValueMapping(source = "DISABLEMENT_LIVING_ALLOWANCE", target = "DISABLEMENT_LIVING_ALLOWANCE")
    @ValueMapping(source = "PERSONAL_INDEPENDENT_INCOME", target = "PERSONAL_INDEPENDENT_INCOME")
    @ValueMapping(source = "DIVIDEND", target = "DIVIDEND")
    @ValueMapping(source = "INVESTMENT_INCOME", target = "INVESTMENT_INCOME")
    @ValueMapping(source = "MAINTENANCE", target = "MAINTENANCE")
    @ValueMapping(source = "PENSION_PRIVATE_OR_EMPLOYERS", target = "PENSION_PRIVATE_OR_EMPLOYERS")
    @ValueMapping(source = "PENSION_STATE", target = "PENSION_STATE")
    @ValueMapping(source = "RENTAL_INCOME", target = "RENTAL_INCOME")
    @ValueMapping(source = "TRUST", target = "TRUST")
    @ValueMapping(source = "ADOPTION_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "ATTENDANCE_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "CHILD_WORKING_TAX_CREDIT", target = "OTHER_TAXABLE")
    @ValueMapping(source = "CONSTANT_ATTENDANCE_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "EMPLOYMENT_AND_SUPPORT_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "FOSTER_CARERS_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "GUARDIANS_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "INCOME_SUPPORT", target = "OTHER_TAXABLE")
    @ValueMapping(source = "INDUSTRIAL_INJURIES_DISABLEMENT_BENEFIT", target = "OTHER_TAXABLE")
    @ValueMapping(source = "PENSION_CREDIT", target = "OTHER_TAXABLE")
    @ValueMapping(source = "REDUCED_EARNINGS_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "WIDOWED_PARENT_ALLOWANCE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "WAR_WIDOW_PENSION", target = "OTHER_TAXABLE")
    @ValueMapping(source = "OTHER_TAXABLE", target = "OTHER_TAXABLE")
    @ValueMapping(source = "OTHER_NON_TAXABLE", target = "OTHER_NON_TAXABLE")
    abstract OtherIncomeType mapToOtherIncomeType(com.natwest.pbbdhb.openapi.OtherIncome.TypeEnum source);

}
