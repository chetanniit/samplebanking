package com.natwest.pbbdhb.adbo.listener.hboadboevent.state.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PatchApplicationRequest {
    @JsonIgnore
    private String flowId;
    private Integer retryCount;
    private String retryStatus;
    private LocalDateTime kafkaTimestamp;
    private LocalDateTime mopsTimestamp;
}
