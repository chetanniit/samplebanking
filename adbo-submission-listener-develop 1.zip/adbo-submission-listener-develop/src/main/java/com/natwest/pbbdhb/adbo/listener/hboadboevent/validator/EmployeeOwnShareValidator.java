package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmployeeOwnShareConstraint;
import com.natwest.pbbdhb.openapi.Employment;
import com.natwest.pbbdhb.openapi.SelfEmployed;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.isPreviousEmployment;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class EmployeeOwnShareValidator implements ConstraintValidator<EmployeeOwnShareConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || isPreviousEmployment(employment) || isNull(employment.getEmploymentStatus())
               || !Employment.EmploymentStatusEnum.SELF_EMPLOYED.equals(employment.getEmploymentStatus()) || isNull(
                employment.getSelfEmployed()) || isNull(employment.getSelfEmployed().getBusinessType())
               || SelfEmployed.BusinessTypeEnum.SOLE_TRADER.equals(employment.getSelfEmployed().getBusinessType())
               || nonNull(employment.getSelfEmployed().getOwnShare());
    }
}
