package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.MortgageAdvisedType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.ProductTerm;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.RepaymentType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Mortgage {
    private BuyToLet buyToLet;
    private BigDecimal propertyValue;
    private BigDecimal purchasePrice;
    private BigDecimal outstandingMortgage;
    private List<AdditionalBorrowing> additionalBorrowings;
    private BigDecimal mortgageAmount;
    private Integer mortgageTermYears;
    private Integer mortgageTermMonths;
    private RepaymentType mortgageType;
    private MortgageAdvisedType mortgageAdvised;
    private Boolean mortgagePrisoner;
    private Boolean rightToBuy;
    private Boolean mortgageGuarantee;
    private InterestOnly interestOnly;
    private List<OtherProperty> otherProperties;
    private ProductTerm productTerm;
}
