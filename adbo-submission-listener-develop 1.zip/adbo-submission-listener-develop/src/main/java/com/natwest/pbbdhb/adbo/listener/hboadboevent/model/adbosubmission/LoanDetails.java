package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoanDetails {
    private BigDecimal borrowingLimit;
    private BigDecimal loanAmount;
    private String paymentMethod;
    private String paymentDueDate;
    private String repaymentVehicle;
    private String allApplicantsToBenefit;
    private AdditionalBorrowingDetails additionalBorrowingDetails;
    private AssociatedAccounts associatedAccounts;
}
