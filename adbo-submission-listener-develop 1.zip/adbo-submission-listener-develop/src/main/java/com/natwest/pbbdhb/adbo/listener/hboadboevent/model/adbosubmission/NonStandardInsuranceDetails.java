package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import java.util.List;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NonStandardInsuranceDetails {
    @NotNull
    private List<InsurancePolicyDetails> nonStandardInsurance;
}
