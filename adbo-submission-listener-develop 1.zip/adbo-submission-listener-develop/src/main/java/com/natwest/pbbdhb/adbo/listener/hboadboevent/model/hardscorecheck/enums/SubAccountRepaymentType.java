package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.Getter;

@Getter
public enum SubAccountRepaymentType {

    REPAYMENT, INTEREST_ONLY

}
