package com.natwest.pbbdhb.adbo.listener.hboadboevent.schedulers;

public class BrandContextHolder {
    private static final ThreadLocal<String> CONTEXT_HOLDER = new ThreadLocal<>();

    public static String getCurrentBrand() {
        return CONTEXT_HOLDER.get();
    }

    public static void setCurrentBrand(String brand) {
        CONTEXT_HOLDER.set(brand);
    }

    public static void clear() {
        CONTEXT_HOLDER.remove();
    }
}
