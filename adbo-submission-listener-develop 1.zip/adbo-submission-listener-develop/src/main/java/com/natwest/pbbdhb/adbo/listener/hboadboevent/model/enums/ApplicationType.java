package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ApplicationType {
    ADDITIONAL_BORROWING("ADDITIONAL_BORROWING");

    @JsonValue
    private final String typeName;

    @Override
    public String toString() {
        return typeName;
    }
}
