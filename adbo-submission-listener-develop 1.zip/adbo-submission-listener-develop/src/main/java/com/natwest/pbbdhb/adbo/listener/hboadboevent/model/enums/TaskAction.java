package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum TaskAction {

    OPEN("O"),
    CLOSE("C");

    private final String action;

    @Override
    public String toString() {
        return action;
    }

    public String getAction() {
        return this.action;
    }

}
