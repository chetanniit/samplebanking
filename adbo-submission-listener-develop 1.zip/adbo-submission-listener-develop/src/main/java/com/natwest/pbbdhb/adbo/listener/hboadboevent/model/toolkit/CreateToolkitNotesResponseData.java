package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.toolkit;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Class for create toolkit notes response data.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateToolkitNotesResponseData implements Serializable {
    private static final long serialVersionUID = 1L;

    private String message;
}
