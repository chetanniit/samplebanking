package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

import org.springframework.kafka.retrytopic.RetryTopicHeaders;

public enum CustomHeader {
    USER_ID("userId", "userId"),
    CHANNEL("channel", "channel"),
    CLIENT_ID("client_id", "client_id"),
    BRAND("brand", "brand"),
    CASE_REFERENCE("kafka_case-id", "caseReferenceId"),
    TEMP_REF_NO("kafka_temp-ref-no", "flowId"),
    RETRY_ATTEMPT(RetryTopicHeaders.DEFAULT_HEADER_ATTEMPTS, "retryCount"),
    RETRY_TIMESTAMP(RetryTopicHeaders.DEFAULT_HEADER_BACKOFF_TIMESTAMP, "retryTimestamp");

    private final String kafkaHeader;
    private final String messageHeader;

    CustomHeader(String pKafkaHeader, String pMessageHeader) {
        this.kafkaHeader = pKafkaHeader;
        this.messageHeader = pMessageHeader;
    }

    public String getKafkaHeader() {
        return this.kafkaHeader;
    }

    public String getMessageHeader() {
        return this.messageHeader;
    }

}
