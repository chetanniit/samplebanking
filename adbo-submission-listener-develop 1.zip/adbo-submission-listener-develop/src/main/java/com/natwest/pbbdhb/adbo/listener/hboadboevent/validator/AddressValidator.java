package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.AddressConstraint;
import com.natwest.pbbdhb.openapi.Address;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isNotBlank;

public class AddressValidator implements ConstraintValidator<AddressConstraint, Address> {

    @Override
    public boolean isValid(final Address address, final ConstraintValidatorContext constraintValidatorContext) {
        return isNull(address) || isNotBlank(address.getFlat()) || isNotBlank(address.getHouseNumber()) || isNotBlank(
                address.getHouseName());
    }
}
