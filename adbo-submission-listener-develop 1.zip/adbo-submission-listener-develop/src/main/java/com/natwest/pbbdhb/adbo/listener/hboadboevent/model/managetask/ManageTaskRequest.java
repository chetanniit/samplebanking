package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.managetask;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ManageTaskRequest {
    private String userId;
    private String mortgage;
    private String applSeq;
    private String taskCode;
    private String taskSuccessIndicator;
    private String action;
    private String note;
}
