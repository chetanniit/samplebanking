package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer excessIncome;

    private Integer shortestTerminMonths;

    private Integer maximumAllowableLoan;

    private BigDecimal loanToValue;

    private String podScoreBand;

    private String landlordCode;

    private List<ApplicantDetails> applicants;
}
