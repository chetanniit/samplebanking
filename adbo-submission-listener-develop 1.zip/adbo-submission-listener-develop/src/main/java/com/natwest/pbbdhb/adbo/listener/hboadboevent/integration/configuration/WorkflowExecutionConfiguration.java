package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.configuration;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.rbs.dws.transport.rest.CorrelationIdClientHttpRequestFactory;
import com.rbs.dws.transport.rest.IamJwtChainSecureClientHttpRequestFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

@Configuration
@ComponentScan
@EnableIntegration
@IntegrationComponentScan
@Slf4j
public class WorkflowExecutionConfiguration {

    @Value("${iam.jwt.secure.rest.template}")
    private Boolean isIamJwtSecureRestTemplate;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    @Qualifier("workflowExecutionHttpCallResponseErrorHandler")
    private ResponseErrorHandler httpCallResponseErrorHandler;

    @Autowired
    @Qualifier("workflowStateServiceResponseErrorHandler")
    private ResponseErrorHandler workflowStateServiceResponseErrorHandler;

    @Value("${application.config.state-service.connect-timeout}")
    private int stateApiConnectTimeout;

    @Value("${application.config.state-service.read-timeout}")
    private int stateApiReadTimeout;

    @Bean("workflowExecutionRestTemplate")
    public RestTemplate workflowExecutionRestTemplate(
            @Autowired @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
            @Autowired RestTemplate restTemplate) {
        RestTemplate resolvedRestTemplate = isIamJwtSecureRestTemplate ? iamJwtChainSecureRestTemplate : restTemplate;
        resolvedRestTemplate.setErrorHandler(httpCallResponseErrorHandler);
        return resolvedRestTemplate;
    }

    @Bean("workflowStateServiceRestTemplate")
    public RestTemplate stateServiceRestTemplate(
            @Autowired @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate iamJwtChainSecureRestTemplate,
            @Autowired RestTemplate restTemplate) {
        if (isIamJwtSecureRestTemplate) {
            iamJwtChainSecureRestTemplate.setErrorHandler(workflowStateServiceResponseErrorHandler);
            IamJwtChainSecureClientHttpRequestFactory requestFactory
                    = (IamJwtChainSecureClientHttpRequestFactory) iamJwtChainSecureRestTemplate.getRequestFactory();
            requestFactory.setConnectTimeout(stateApiConnectTimeout);
            requestFactory.setConnectionRequestTimeout(stateApiReadTimeout);
            return iamJwtChainSecureRestTemplate;
        }

        restTemplate.setErrorHandler(workflowStateServiceResponseErrorHandler);
        CorrelationIdClientHttpRequestFactory requestFactory
                = (CorrelationIdClientHttpRequestFactory) restTemplate.getRequestFactory();
        requestFactory.setConnectTimeout(stateApiConnectTimeout);
        requestFactory.setConnectionRequestTimeout(stateApiReadTimeout);
        return restTemplate;
    }

    @Bean("workflowExecutionOutputMapper")
    public WorkflowMapper workflowExecutionOutputMapper(
            @Value("${application.config.output-mapper}") Class mapperClass) {
        return (WorkflowMapper) applicationContext.getBean(mapperClass);
    }
}
