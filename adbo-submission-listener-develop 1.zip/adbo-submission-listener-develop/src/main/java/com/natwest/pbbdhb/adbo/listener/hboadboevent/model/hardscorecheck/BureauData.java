package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BureauData {
    private Integer overdraftBalance;
    private Integer mailOrderBalance;
    private Integer budgetAccountBalance;
}
