package com.natwest.pbbdhb.adbo.listener.hboadboevent.utils;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.CustomHeader;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.Alert;
import com.natwest.pbbdhb.msvcutils.logging.Incident;
import com.natwest.pbbdhb.openapi.Application;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.kafka.support.converter.KafkaMessageHeaders;
import org.springframework.messaging.MessageHeaders;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants.BRAND;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants.CASE_ID;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants.CHANNEL;

@Slf4j
public class LoggerUtils {

    public static final String SERVICE_ID = "adbo-submission-listener";
    public static final String LOG_MSG_PREFIX = "[" + BRAND + "=%s, " + CHANNEL + "=%s, " + CASE_ID + "=%s] - ";


    public static String getLogMsgPrefix(Map<String, Object> headers) {
        String brand = (String) headers.get(CustomHeader.BRAND.getMessageHeader());
        String client = (String) headers.get(CustomHeader.CHANNEL.getMessageHeader());
        String refId = (String) headers.get(CustomHeader.CASE_REFERENCE.getMessageHeader());
        return String.format(LOG_MSG_PREFIX, brand, client, refId);
    }

    public static String getLogMsgPrefix(MessageHeaders headers) {
        String brand = headers.get(CustomHeader.BRAND, String.class);
        String channel = headers.get(CustomHeader.CHANNEL, String.class);
        String caseId = headers.get(CustomHeader.CASE_REFERENCE, String.class);
        return String.format(LOG_MSG_PREFIX, brand, channel, caseId);
    }

    public static Incident.Builder getAlertMessage(MessageHeaders headers, Alert alert, String errorMessage) {
        return buildAlertMessage(alert, headers.get(CustomHeader.BRAND, String.class),
                headers.get(CustomHeader.CHANNEL, String.class), headers.get(CustomHeader.CASE_REFERENCE, String.class),
                errorMessage);
    }

    public static Incident.Builder getAlertMessage(Application message, KafkaMessageHeaders headers, Alert alert,
                                                   String errorMessage) {
        return buildAlertMessage(alert, Objects.nonNull(headers.get(CustomHeader.BRAND.getKafkaHeader())) ?
                        headers.get(CustomHeader.BRAND.getKafkaHeader(), String.class) :
                        org.apache.commons.lang.StringUtils.isNotBlank(message.getBrand()) ? message.getBrand() : "nwb",
                Optional.ofNullable(message.getChannel()).map(Application.ChannelEnum::getValue)
                        .orElse(StringUtils.EMPTY), message.getCaseId(), errorMessage);
    }


    public static Incident.Builder buildAlertMessage(Alert alert, String brand, String channel, String caseId,
                                                     String errorMessage) {
        return new Incident.Builder().system(SERVICE_ID).type(alert.name()).subtype(alert.subtype)
                .addDescriptionEntry(BRAND, brand).addDescriptionEntry(CHANNEL, channel)
                .addDescriptionEntry(CASE_ID, caseId).errorCode(alert.getCode())
                .addDescriptionEntry(Incident.ERROR_MESSAGE_FIELD, errorMessage);
    }

}
