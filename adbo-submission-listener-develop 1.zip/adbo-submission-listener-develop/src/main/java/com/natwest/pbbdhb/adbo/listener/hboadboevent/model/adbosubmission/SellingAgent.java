package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SellingAgent {
    private String name;
    private ContactAddress sellingAgentAddress;
    private String telephoneNumber;
}
