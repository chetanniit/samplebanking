package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class UpdateCustomerData implements Serializable {
    private static final long serialVersionUID = 1L;
    private long clientId;
    private String clientAlternateId;
    private UpdateCustomerMessageResponse messages;
}
