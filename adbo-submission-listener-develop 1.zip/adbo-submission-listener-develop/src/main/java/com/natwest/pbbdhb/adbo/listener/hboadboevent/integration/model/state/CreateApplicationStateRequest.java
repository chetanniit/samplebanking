package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateApplicationStateRequest {
    private String applicationSubType;
    private String request;
    private String response;
    private String responseStatus;
    private LocalDateTime sendTimestamp;
    private LocalDateTime receiveTimestamp;
}
