package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmploymentIndustryTypeConstraint;
import com.natwest.pbbdhb.openapi.Employment;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class EmploymentIndustryTypeValidator
        implements ConstraintValidator<EmploymentIndustryTypeConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || isNull(employment.getEmploymentStatus()) || employment.getEmploymentStatus()
                .equals(Employment.EmploymentStatusEnum.NOT_EMPLOYED) || nonNull(employment.getIndustryType());
    }
}
