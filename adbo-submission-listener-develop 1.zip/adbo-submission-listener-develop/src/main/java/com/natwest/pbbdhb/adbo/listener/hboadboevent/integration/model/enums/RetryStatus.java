package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums;

public enum RetryStatus {
    PENDING, SUCCESSFUL, FAILED, NULL, MANUAL
}
