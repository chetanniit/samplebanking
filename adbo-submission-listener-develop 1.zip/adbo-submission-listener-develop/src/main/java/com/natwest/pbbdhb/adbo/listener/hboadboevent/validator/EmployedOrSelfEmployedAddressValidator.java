package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmployedOrSelfEmployedAddressConstraint;
import com.natwest.pbbdhb.openapi.Employment;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDate;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class EmployedOrSelfEmployedAddressValidator
        implements ConstraintValidator<EmployedOrSelfEmployedAddressConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || isNull(employment.getEmploymentStatus()) || employment.getEmploymentStatus()
                .equals(Employment.EmploymentStatusEnum.NOT_EMPLOYED)
                || (StringUtils.isNotBlank(employment.getEndDate())
                && (employment.getEmploymentType() != Employment.EmploymentTypeEnum.CONTRACT
                || LocalDate.now().isAfter(LocalDate.parse(employment.getEndDate()))))
                || nonNull(employment.getAddress())
                || nonNull(employment.getUnstructuredAddress());
    }
}
