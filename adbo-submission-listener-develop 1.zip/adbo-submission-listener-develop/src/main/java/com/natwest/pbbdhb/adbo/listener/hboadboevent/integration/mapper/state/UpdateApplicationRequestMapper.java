package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.state;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.UpdateApplicationRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.SerializableUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.SpelUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ApplicationStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
@Slf4j
public abstract class UpdateApplicationRequestMapper implements WorkflowMapper<Message<?>, UpdateApplicationRequest> {

    @Autowired
    private PropertiesConfig config;

    @Value("${application.config.kafka.max-attempts}")
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected int maxAttempts;

    @Override
    public UpdateApplicationRequest map(final Message<?> message) {
        UpdateApplicationRequest updateApplicationRequest =
                Objects.isNull(message) ? null : toUpdateApplicationRequest(message);
        return updateApplicationRequest;
    }

    @Mappings({@Mapping(target = "refId", source = "message", qualifiedByName = "getRefId"),
            @Mapping(target = "additionalRefId", source = "message", qualifiedByName = "getAdditionalRefId"),
            @Mapping(target = "response",
                    expression = "java((String) new org.springframework.integration.json.ObjectToJsonTransformer()"
                            + ".transform(message).getPayload())"),
//            @Mapping(target = "responseStatus", source = "message", qualifiedByName = "getStatus"),
            @Mapping(target = "retryCount", source = "message", qualifiedByName = "getRetryCount"),
            @Mapping(target = "retryStatus", source = "message", qualifiedByName = "getRetryStatus"),
            @Mapping(target = "retryTimestamp", source = "message", qualifiedByName = "getRetryTimestamp"),
            @Mapping(target = "workflowContext", source = "message", qualifiedByName = "getWorkflowContext")
    })
    public abstract UpdateApplicationRequest toUpdateApplicationRequest(Message<?> message);

    @Named("getRefId")
    protected String getRefId(final Message<?> message) {
        return SpelUtils.evaluate(message, config.getRefIdExpression(), String.class);
    }

    @Named("getAdditionalRefId")
    protected String getAdditionalRefId(final Message<?> message) {
        return SpelUtils.evaluate(message, config.getAdditionalRefIdExpression(), String.class);
    }

    @Named("getRetryCount")
    protected Integer getRetryCount(final Message<?> message) {
        return Optional
                .of(message.getHeaders().get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class))
                .map(WorkflowContext::getCurrentAttempt).map(attempts -> Math.decrementExact(attempts))
                .filter(count -> count > 0).orElse(null);
    }

    protected ApplicationStatus getStatus(final Message<?> message) {
        return SpelUtils.evaluate(message, config.getStatusExpression(), ApplicationStatus.class);
    }

    @Named("getRetryStatus")
    protected String getRetryStatus(final Message<?> message) {
        Integer retryCount = getRetryCount(message);
//        if (Objects.nonNull(retryCount)) {
//            return retryCount < Math.decrementExact(maxAttempts) ? getRetryStatus(message, retryCount) : "COMPLETED";
//        }
        return getRetryStatus(message, retryCount);
    }

    @Named("getWorkflowContext")
    protected byte[] getWorkflowContext(final Message<?> message) {
        return SerializableUtils
                .serialize(message.getHeaders()
                        .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class));
    }

    @Named("getRetryTimestamp")
    protected LocalDateTime getRetryTimestamp(final Message<?> message) {
        return message.getHeaders().get(WorkflowExecutionConstants.RETRY_TIMESTAMP_HEADER, LocalDateTime.class);
    }

    protected String getRetryStatus(final Message<?> message, Integer retryCount) {
        switch (getStatus(message)) {
            case RETRY_SUCCESSFUL:
                return "SUCCESSFUL";
            case RETRY_FAILED:
                return "FAILED";
            case HARDSCORE_DECLINED:
                if (Objects.nonNull(retryCount)) {
                    return "RETRY_FAILED";
                }
            case PENDING:
                return "PENDING";
            default:
                return null;
        }
    }
}
