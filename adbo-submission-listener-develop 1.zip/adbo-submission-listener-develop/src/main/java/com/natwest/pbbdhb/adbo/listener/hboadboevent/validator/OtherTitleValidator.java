package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.OtherTitleConstraint;
import com.natwest.pbbdhb.openapi.PersonalDetails;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isNotBlank;

public class OtherTitleValidator implements ConstraintValidator<OtherTitleConstraint, PersonalDetails> {
    @Override
    public boolean isValid(PersonalDetails personalDetails, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(personalDetails) || PersonalDetails.TitleEnum.OTHER != personalDetails.getTitle() || isNotBlank(
                personalDetails.getOtherTitle());
    }
}
