package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import lombok.Data;

@Data
public class GetCustomerBankAccount implements Serializable {
    private static final long serialVersionUID = 1L;

    private String bankSortCode;
    private String bankAccountName;
    private Long bankAccountNumber;
    private Integer yearsWithBank;
    private Integer monthsWithBank;
    private String chequeGuaranteeCard;
}
