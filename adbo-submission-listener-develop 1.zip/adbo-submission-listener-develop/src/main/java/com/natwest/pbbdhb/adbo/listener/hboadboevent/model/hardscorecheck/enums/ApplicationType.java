package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum ApplicationType {
    RESIDENTIAL,
    BUY_TO_LET,
    ADDITIONAL_BORROWING
}
