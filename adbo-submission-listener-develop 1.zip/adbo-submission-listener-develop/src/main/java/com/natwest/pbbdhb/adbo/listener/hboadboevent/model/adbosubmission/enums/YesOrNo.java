package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.enums;

public enum YesOrNo {
    Y, N
}
