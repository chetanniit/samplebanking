package com.natwest.pbbdhb.adbo.listener;

import com.ulisesbocchio.jasyptspringboot.environment.StandardEncryptableEnvironment;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackageClasses = ADBOSubmissionListener.class,
        exclude = DataSourceAutoConfiguration.class)
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT10S")
public class ADBOSubmissionListener {

    public static void main(String[] args) {
//        new SpringApplicationBuilder().environment(new StandardEncryptableEnvironment())
//                .sources(ADBOSubmissionListener.class).run(args);

        SpringApplication.run(ADBOSubmissionListener.class, args);


    }
}
