package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateApplicationRequest {
    private String channel;
    private String refId;
    private String refType;
    private String additionalRefId;
    private String applicationType;
    private String request;
}
