package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CreditHistoryCourtProceedingDetailsConstraint;
import com.natwest.pbbdhb.openapi.CreditHistory;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;

public class CreditHistoryCourtProceedingDetailsValidator
        implements ConstraintValidator<CreditHistoryCourtProceedingDetailsConstraint, CreditHistory> {
    @Override
    public boolean isValid(CreditHistory creditHistory, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(creditHistory) || isNull(creditHistory.getCourtProceedings()) || !creditHistory
                .getCourtProceedings() || StringUtils.isNotBlank(creditHistory.getCourtProceedingDetails());
    }
}
