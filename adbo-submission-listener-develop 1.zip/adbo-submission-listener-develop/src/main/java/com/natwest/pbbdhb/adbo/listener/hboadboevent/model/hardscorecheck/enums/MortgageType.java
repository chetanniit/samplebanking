package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum MortgageType {
    RESIDENTIAL, BUY_TO_LET
}
