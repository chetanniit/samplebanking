package com.natwest.pbbdhb.adbo.listener.hboadboevent.exception;

import lombok.Data;

@Data
public class HboADBOEventRetryException extends Exception {
    private final String message;
    private final Throwable throwable;

    public HboADBOEventRetryException(String inMessage, Throwable inThrowable) {
        super(inMessage, inThrowable);
        this.message = inMessage;
        this.throwable = inThrowable;
    }
}
