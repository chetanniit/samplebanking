package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.autoprocess;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class AutoProcessRequest {
    private String userId;
    private String mortgageNumber;
    private String applSeq;
}
