package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerFailedToMakePaymentsDetails {
    private String answer;
    private LocalDate dateArrearsRepaid;
    private BigDecimal currentOutstandingArrears;
    private Integer noOfMonthsInArrears;
    private LocalDate dateHighestArrears;
    private String worseningArrears;
    private Integer highestMonthsArrears6Months;
    private BigDecimal highestValueArrears6Months;
    private Integer highestMonthsArrears12Months;
    private BigDecimal highestValueArrears12Months;
    private Integer highestMonthsArrears24Months;
    private BigDecimal highestValueArrears24Months;
    private String arrearsOver24Months;
    private String propertyRepossessed;
    private LocalDate propertyRepossessionDate;
    private String note;
    private LocalDate loanArrearsRepaidDate;
    private BigDecimal currentLoanArrearsOutstanding;
    private Integer numberOfMonthsInLoanArrears;
    private LocalDate highestLoanArrearsDate;
    private String haveLoanArrearsWorsenedInLastSixMonths;
    private BigDecimal highestLoanArrearsInPreviousTwoYears;
    private Integer highestLoanArrearsMonthsInPreviousTwoYears;
}
