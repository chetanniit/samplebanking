package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class UpdateCustomerAddress {
    private String foreignAddressIndicator;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String address5;
    private String addressPC;
    private String addressCountry;
}
