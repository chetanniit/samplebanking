package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetCustomerOccupancyDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    private String occupancyType;
    private GetCustomerAddress clientAddress;
    private Integer yearsAtAddress;
    private Integer monthsAtAddress;
    private LocalDate addressEntryDate;
    private BigDecimal originalPurchasePrice;
    private LocalDate purchaseDate;
    private BigDecimal currentValue;
    private GetCustomerLenderDetails lenderDetails;
    private GetCustomerLandlordDetails landlordDetails;
}
