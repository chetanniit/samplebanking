package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum CinMatchType {
    SINGLE_MATCH_VERIFIED("SINGLE-MATCH-VERIFIED"), MULTI_MATCH("MULTI-MATCH"), NO_MATCH("NO-MATCH");
    private final String description;

    public String getDescription() {
        return description;
    }
}
