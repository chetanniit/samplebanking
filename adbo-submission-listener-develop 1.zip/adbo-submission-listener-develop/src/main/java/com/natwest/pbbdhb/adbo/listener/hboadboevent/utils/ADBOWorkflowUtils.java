package com.natwest.pbbdhb.adbo.listener.hboadboevent.utils;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ApplicationStatus;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.CreateFurtherAdvanceApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ADBOSubmitRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails.Event;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails.GetMortgageApplicationDetailsResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails.Stage;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.ApplicantDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.HardScoreApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.mortgagedetails.MortgageDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.mortgagedetails.MortgageDetailsResponse;
import com.natwest.pbbdhb.openapi.AdditionalDetails;
import com.natwest.pbbdhb.openapi.Applicant;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.Fee;
import com.natwest.pbbdhb.openapi.HardscoreDecision;
import com.natwest.pbbdhb.openapi.Message;
import com.natwest.pbbdhb.openapi.Packaging;
import com.natwest.pbbdhb.openapi.Policy;
import com.natwest.pbbdhb.openapi.ProductDetails;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_FORMAT;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public interface ADBOWorkflowUtils {

    String HARD_SCORE_DECLINE = "DECLINE";
    String STAGE_20 = "20";
    String ABM = "ABM";
    String SPACE_REGEX = "\\s+";
    DateTimeFormatter NON_ISO_DATE_FORMAT = DateTimeFormatter.ofPattern(STANDARD_DATE_FORMAT);

    static Application getOriginalPayload(WorkflowContext context) {
        return (Application) context.getOriginalPayload();
    }

    static <T> Map<Integer, T> getResponses(WorkflowContext wc, String requestChannel, Class<T> responseType) {
        return getBaseResponses(wc, requestChannel).entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,
                v -> (isNull(v.getValue()) || isNull(v.getValue().getResponse())) ? null
                        : (T) v.getValue().getResponse()));
    }

    static Map<Integer, BaseResponse> getBaseResponses(WorkflowContext wc, String requestChannel) {
        return Optional.ofNullable(wc.getResponseMap().get(requestChannel)).orElse(Collections.emptyMap()).entrySet()
                .stream().collect(Collectors
                        .toMap(Map.Entry::getKey, v -> isNull(v.getValue()) ? null : (BaseResponse) v.getValue()));
    }

    static Applicant getApplicant(WorkflowContext context, Integer routingIndex) {
        int counter = getCount(context, routingIndex);
        return Optional.of(getApplicants(context))
                .filter(applicants -> IntStream.range(0, applicants.size()).anyMatch(index -> index == (counter - 1)))
                .map(applicants -> applicants.get(counter - 1)).orElse(null);
    }

    static List<Applicant> getApplicants(WorkflowContext context) {
        return getOriginalPayload(context).getApplicants();
    }

    static int getCount(WorkflowContext context, Integer routingIndex) {
        return Optional.ofNullable(context.getRoutingSlip().get(routingIndex)).map(WorkflowRoutingSlip.Route::getCount)
                .map(AtomicInteger::get).orElse(0);
    }

    static BigDecimal getNetMonthlyIncome(Applicant applicant, WorkflowContext context) {
        List<ApplicantDetails> applicants =
                getHardScoreApplicationResponse(context).get().getAdditionalDetails().getApplicants();

        return applicants.stream().filter(b -> isSameApplicant().apply(applicant, b)).map(b -> b.getNetMonthlyIncome())
                .findFirst().orElse(null);
    }

    static BiFunction<Applicant, ApplicantDetails, Boolean> isSameApplicant() {
        return (a, b) -> LocalDate.parse(b.getDateOfBirth()).format(NON_ISO_DATE_FORMAT)
                .equals(a.getPersonalDetails().getDateOfBirth()) && StringUtils
                .equals(b.getFirstNames(), a.getPersonalDetails().getFirstNames()) && StringUtils
                .equals(b.getLastName(), a.getPersonalDetails().getLastName()) && StringUtils
                .equals(replaceAllSpaces(b.getPostCode()), replaceAllSpaces(a.getAddresses().stream()
                        .filter(address -> StringUtils.isBlank(address.getEndDate())).findFirst().get()
                        .getPostcode()));
    }

    static String replaceAllSpaces(String text) {
        return Optional.ofNullable(text).map(str -> str.replaceAll(SPACE_REGEX, StringUtils.EMPTY))
                .orElse(StringUtils.EMPTY);
    }

    static Optional<HardScoreApplicationResponse> getHardScoreApplicationResponse(WorkflowContext context) {
        return getResponses(context, ADBOSubmitRoutingSlip.HARD_SCORE_CHECK.getRequestChannel(),
                HardScoreApplicationResponse.class).values().stream().findFirst();
    }

    static boolean isHardScoreAccepted(WorkflowContext context) {
        return getHardScoreApplicationResponse(context).map(HardScoreApplicationResponse::getDecision)
                .map(d -> d.equalsIgnoreCase("ACCEPT") || d.equalsIgnoreCase("REFER")).orElse(false);
    }

    static Long getGmsId(WorkflowContext context, Integer routingIndex) {
        return Optional.ofNullable(getRequestClientId(context, routingIndex)).orElse(null);
    }

    static Long getRequestClientId(WorkflowContext context, Integer routingIndex) {
        return Optional.ofNullable(getApplicant(context, routingIndex)).map(Applicant::getClientId)
                .filter(Objects::nonNull).map(id -> Long.valueOf(id)).orElse(null);
    }

    static boolean isFurtherAdvancedSubmissionValid(WorkflowContext context) {
        return nonNull(getFurtherAdvancedSubmissionResponse(context));
    }

    static CreateFurtherAdvanceApplicationResponse getFurtherAdvancedSubmissionResponse(WorkflowContext context) {
        return getResponses(context, ADBOSubmitRoutingSlip.SUBMIT_FURTHER_ADVANCE.getRequestChannel(),
                CreateFurtherAdvanceApplicationResponse.class).values().stream().findFirst().filter(Objects::nonNull)
                .orElse(null);
    }

    static String getMortgageNumber(WorkflowContext context) {
        return getOriginalPayload(context).getExistingMortgage().getMortgageReferenceNumber();
    }

    static String getAppSeq(WorkflowContext context) {
        CreateFurtherAdvanceApplicationResponse createFurtherAdvanceApplicationResponse =
                getFurtherAdvancedSubmissionResponse(context);
        if (nonNull(createFurtherAdvanceApplicationResponse)) {
            return createFurtherAdvanceApplicationResponse.getApplSeq();
        }
        return null;
    }

    static HardscoreDecision getHardScoreDecision(WorkflowContext context) {
        return getHardScoreApplicationResponse(context)
                .map(r -> HardscoreDecision.builder().decision(r.getDecision()).podDecision(r.getPodDecision())
                        .decisionUniqueId(r.getDecisionUniqueId()).kycMessages(nonNull(r.getKycMessages())
                                ? r.getKycMessages().stream()
                                        .map(k -> Message.builder().code(k.getCode()).message(k.getMessage())
                                                .applicant1IdRequired(k.getApplicant1IdRequired())
                                                .applicant2IdRequired(k.getApplicant2IdRequired()).build())
                                        .collect(Collectors.toList()) : null).policyMessages(
                                nonNull(r.getPolicyMessages()) ? r.getPolicyMessages().stream()
                                        .map(p -> Policy.builder().code(p.getCode()).message(p.getMessage()).build())
                                        .collect(Collectors.toList()) : null).additionalDetails(
                                Optional.ofNullable(r.getAdditionalDetails())
                                        .map(additionalDetails -> AdditionalDetails.builder()
                                                .excessIncome(additionalDetails.getExcessIncome())
                                                .loanToValue(additionalDetails.getLoanToValue())
                                                .maximumAllowableLoan(additionalDetails.getMaximumAllowableLoan())
                                                .podScoreBand(additionalDetails.getPodScoreBand())
                                                .shortestTerminMonths(additionalDetails.getShortestTerminMonths())
                                                .build()).orElse(null)).packaging(Optional.ofNullable(r.getPackaging())
                                .map(packaging -> Packaging.builder().app1AccountsReq(packaging.getApp1AccountsReq())
                                        .app1BankStmntsReq(packaging.getApp1BankStmntsReq())
                                        .app1PaySlipsReq(packaging.getApp1PaySlipsReq())
                                        .app1PerAndBusBankStmntsReq(packaging.getApp1PerAndBusBankStmntsReq())
                                        .app1TaxCalc(packaging.getApp1TaxCalc())
                                        .app2AccountsReq(packaging.getApp2AccountsReq())
                                        .app2BankStmntsReq(packaging.getApp2BankStmntsReq())
                                        .app2PaySlipsReq(packaging.getApp2PaySlipsReq())
                                        .app2PerAndBusBankStmntsReq(packaging.getApp2PerAndBusBankStmntsReq())
                                        .app2TaxCalc(packaging.getApp2TaxCalc()).build()).orElse(null)).build())
                .orElse(null);
    }

    static boolean isInValidStage(GetMortgageApplicationDetailsResponse getMortgageApplicationDetailsResponse) {
        if (isNull(getMortgageApplicationDetailsResponse)) {
            return true;
        }
        List<Stage> stages = getMortgageApplicationDetailsResponse.getSuccess().getStageHistory().getStage();
        List<Event> events = getMortgageApplicationDetailsResponse.getSuccess().getCaseHistory().getEvent();
        return CollectionUtils.isEmpty(stages) || CollectionUtils.isEmpty(events) || stages.stream()
                .noneMatch(s -> s.getCode().equals(STAGE_20)) || events.stream()
                .noneMatch(e -> e.getCode().equals(ABM));
    }

    static boolean isValidStage(WorkflowContext workflowContext) {
        GetMortgageApplicationDetailsResponse getMortgageApplicationDetailsResponse = getResponses(workflowContext,
                ADBOSubmitRoutingSlip.GET_MORTGAGE_APPLICATION_DETAILS.getRequestChannel(),
                GetMortgageApplicationDetailsResponse.class).values().stream().findFirst().orElse(null);
        if (isNull(getMortgageApplicationDetailsResponse)) {
            return false;
        }
        return !isInValidStage(getMortgageApplicationDetailsResponse);
    }

    static boolean isAdboSwitcherRequired(WorkflowContext workflowContext){
        return isValidStage(workflowContext) && Optional.ofNullable(getOriginalPayload(workflowContext)
                .getAdditionalBorrowingWithSwitch()).orElse(false);
    }

    static LocalDateTime getBaseResponsesTimestamp(WorkflowContext context, String requestChannel) {
        return getBaseResponses(context, requestChannel).values().stream().filter(a -> Objects.nonNull(a))
                .map(BaseResponse::getReceiveTimestamp).findFirst().orElse(null);
    }

    static String getChannel(WorkflowContext context) {
        return getOriginalPayload(context).getChannel().getValue();
    }

    static ApplicationStatus chekWorkflowStatus(WorkflowContext source, int maxAttempts) {
        WorkflowRoutingSlip.Route failedRouteEntry = source.findFailedRoute();
        if (Objects.isNull(failedRouteEntry)) {
            if (!org.springframework.util.CollectionUtils.isEmpty(source.getResponseMap())) {
                if (!ADBOWorkflowUtils.isHardScoreAccepted(source)) {
                    return ApplicationStatus.HARDSCORE_DECLINED;
                } else if (source.getCurrentAttempt() > 1) {
                    return ApplicationStatus.RETRY_SUCCESSFUL;
                }
                return ApplicationStatus.SUCCESSFUL;
            } else {
                return ApplicationStatus.ACCEPTED;
            }
        } else if (source.getCurrentAttempt() == 1) {
            return ApplicationStatus.ACCEPTED;
        } else if (source.getCurrentAttempt() > 1 && source.getCurrentAttempt() < maxAttempts) {
            return ApplicationStatus.PENDING;
        }
        return ApplicationStatus.RETRY_FAILED;
    }

    static String getTaskSeqNumberForNotes(WorkflowContext wc, String requestChannel) {
        return getResponses(wc, requestChannel, MortgageDetailsResponse.class).values().stream().findFirst()
                .map(MortgageDetailsResponse::getData).map(MortgageDetails::getTaskSeqNumber).orElse(null);
    }

    static String getTaskSeqNumberForGeneralNotes(WorkflowContext wc) {
        return getTaskSeqNumberForNotes(wc,
                ADBOSubmitRoutingSlip.GET_MORTGAGE_DETAILS_FOR_GENERAL_NOTES.getRequestChannel());
    }

    static boolean isCreateAwaitFeesTask(WorkflowContext wc) {
        return Optional.ofNullable(getProduct(wc).getFees()).orElse(Collections.emptySet())
                .stream()
                .anyMatch(f -> f.getAction().equals(Fee.ActionEnum.NO_ACTION)
                        && f.getAmount().compareTo(BigDecimal.ZERO) > 0);
    }

    static ProductDetails getProduct(WorkflowContext wc) {
        return getOriginalPayload(wc).getBorrowingDetails().getProducts().stream().findFirst().get();
    }

    static boolean isClosePreScreeningHunterTask(WorkflowContext context) {
        Optional<HttpStatus> status =
                getResponses(context, ADBOSubmitRoutingSlip.TRIGGER_HUNTER_CHECKS.getRequestChannel(),
                        HttpStatus.class).values().stream().findFirst();
        return status.isPresent() && status.get().equals(HttpStatus.OK);
    }
}
