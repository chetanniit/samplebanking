package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants;

@SuppressWarnings("checkstyle:interfaceistype")
public interface WorkflowExecutionSpel {
    String IS_ROUTE_FAIL_SAFE =
            "headers['" + WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER + "'].isRouteFailSafe(#root.headers['"
                    + WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER + "'].get())";
    String DEFAULT_REPLY_CHANNEL = "headers['replyChannel']";
    String WORKFLOW_CONTEXT_HEADER = "headers['" + WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER + "']";
    String GET_FLOW_ID_HEADER = WORKFLOW_CONTEXT_HEADER + ".flowId";
    String IS_FLOW_ID_EXIST_IN_MESSAGE_HEADER = "T(org.apache.commons.lang.StringUtils).isNotBlank("
            + GET_FLOW_ID_HEADER + ")";
}
