package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper;

public interface WorkflowMapper<S, T> {
    T map(S source);
}
