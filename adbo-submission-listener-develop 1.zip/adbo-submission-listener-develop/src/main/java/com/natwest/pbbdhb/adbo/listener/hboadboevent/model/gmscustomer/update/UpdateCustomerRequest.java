package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerRequest {
    private String externalRefId;
    private String userId;
    private UpdateCustomerCoreDetails coreDetails;
    private UpdateCustomerSupplementaryDetails supplementaryDetails;
    private UpdateCustomerCorrespondenceAddress correspondenceAddress;
    private UpdateCustomerOccupancyDetails currentOccupancyDetails;
    private UpdateCustomerOccupancyDetails movedOccupancyDetails;
    private UpdateCustomerPreviousOccupancyDetails previousOccupancyDetails;
    private UpdateCustomerCreditDeclaration creditDeclarations;
    private UpdateCustomerEmploymentDetails employmentDetails;
    private UpdateCustomerOtherIncome otherIncomeDetails;
    private UpdateCustomerExpenditureDetails expenditureDetails;
    private UpdateCustomerBankAccountDetails bankAccountDetails;
    private UpdateCustomerPropertyOwnershipDetails propertyOwnershipDetails;
    private CommonTypesOtherNames otherNames;
    private Dependants dependants;
}
