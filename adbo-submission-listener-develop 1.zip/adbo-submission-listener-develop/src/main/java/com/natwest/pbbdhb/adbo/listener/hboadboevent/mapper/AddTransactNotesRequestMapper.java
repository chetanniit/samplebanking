package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.notes.TaskNote;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers.TransactNotesTransformer;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import lombok.Getter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

@Getter
@Mapper(componentModel = "spring")
public abstract class AddTransactNotesRequestMapper extends AddNotesRequestMapper {
    @Autowired
    private TransactNotesTransformer transactNotesTransformer;

    @Mapping(target = "taskSequenceNumber", source = "source", qualifiedByName = "getTaskSeqNumberForTransactNotes")
    @Mapping(target = "note", source = "source", qualifiedByName = "getTransactNotes")
    abstract TaskNote mapToTaskNotes(WorkflowContext source);

    @Named(value = "getTaskSeqNumberForTransactNotes")
    String getTaskSeqNumberForTransactNotes(WorkflowContext context) {
        return ADBOWorkflowUtils.getTaskSeqNumberForGeneralNotes(context);
    }

    @Named(value = "getTransactNotes")
    String getTransactNotes(WorkflowContext context) {
        return transactNotesTransformer.transform(context);
    }
}
