package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerSelfEmployed {

    private String currentOrPrevious;
    private String companyName;
    private ContactAddress companyAddress;
    private String natureOfBusiness;
    private String employmentType;
    private String employerStatus;
    private Integer yearsEstablished;
    private Integer monthsEstablished;
    private String telephoneNumber;
    private String deliveryPreference;
    private String faxNumber;
    private String emailAddress;
    private String employmentStatus;
    private String occupation;
    private String profitYear1;
    private String profitYear2;
    private String profitYear3;
    private BigDecimal profitAmount1;
    private BigDecimal profitAmount2;
    private BigDecimal profitAmount3;
    private UpdateCustomerIncomeDetails incomeDetails;
    private UpdateCustomerAccountantDetails accountantDetails;
    private Integer yearsOfAccounts;
    private Integer percentageShares;
    private String dividendYear1;
    private String dividendYear2;
    private BigDecimal dividendAmount1;
    private BigDecimal dividendAmount2;

}
