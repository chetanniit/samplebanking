package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.SelfEmployedDateEstablishedConstraint;
import com.natwest.pbbdhb.openapi.SelfEmployed;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_FORMAT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_PATTERN;
import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isBlank;

public class SelfEmployedDateEstablishedValidator
        implements ConstraintValidator<SelfEmployedDateEstablishedConstraint, SelfEmployed> {

    @Override
    public boolean isValid(SelfEmployed selfEmployed, ConstraintValidatorContext constraintValidatorContext) {
        // SelfEmployed dateEstablished cannot be older than 99 years and 11 months (= 1199 months)
        final int dateEstablishedMaxAgeMonths = 1199;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(STANDARD_DATE_FORMAT);
        return isNull(selfEmployed) || isNull(selfEmployed.getSelfEmployedDateEstablished())
                || isBlank(selfEmployed.getSelfEmployedDateEstablished())
                || !Pattern.matches(STANDARD_DATE_PATTERN, selfEmployed.getSelfEmployedDateEstablished())
                || (ADBOUtils.toLocalDate(selfEmployed.getSelfEmployedDateEstablished(), formatter)
                        .isBefore(LocalDate.now())
                && ADBOUtils.toLocalDate(selfEmployed.getSelfEmployedDateEstablished(), formatter)
                                .isAfter(LocalDate.now().minusMonths(dateEstablishedMaxAgeMonths)));
    }
}
