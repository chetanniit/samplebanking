package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CreditHistoryBankruptcyDateConstraint;
import com.natwest.pbbdhb.openapi.CreditHistory;
import org.apache.commons.lang.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;

public class CreditHistoryBankruptcyDateValidator
        implements ConstraintValidator<CreditHistoryBankruptcyDateConstraint, CreditHistory> {
    @Override
    public boolean isValid(CreditHistory creditHistory, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(creditHistory) || isNull(creditHistory.getBankrupt()) || !creditHistory.getBankrupt()
               || StringUtils.isNotBlank(creditHistory.getBankruptcyDate());
    }
}
