package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerCCJDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    private String answer;
    private Integer noOfCCJ;
    private LocalDate dateOfLastCCJ;
    private BigDecimal amountPayableForLastCCJ;
    private LocalDate dateLastCCJRepaid;
    private Integer ccJsSatisfied;
    private String note;


    // named to match the GMS XML class so that MapStruct will generate the mapping
    public Integer getCCJsSatisfied() {
        return ccJsSatisfied;
    }

    public void setCCJsSatisfied(final Integer inCcJsSatisfied) {
        this.ccJsSatisfied = inCcJsSatisfied;
    }
}
