package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CurrentAddressConstraint;
import com.natwest.pbbdhb.openapi.Address;
import org.apache.commons.lang3.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Objects;
import java.util.Set;

import static java.util.Objects.isNull;

public class CurrentAddressValidator implements ConstraintValidator<CurrentAddressConstraint, Set<Address>> {

    @Override
    public boolean isValid(Set<Address> addresses, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(addresses) || addresses.isEmpty()
                || addresses.stream().map(adr -> StringUtils.isBlank(adr.getEndDate())).filter(Objects::nonNull)
                        .filter(isCurrentAddress -> isCurrentAddress).count() == 1;
    }
}
