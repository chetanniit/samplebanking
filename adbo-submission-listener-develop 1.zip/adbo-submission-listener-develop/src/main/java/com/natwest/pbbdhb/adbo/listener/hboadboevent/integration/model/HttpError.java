package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class HttpError implements Serializable {
    private static final long serialVersionUID = 1L;
    private String status;
    private String code;
    private String message;
}
