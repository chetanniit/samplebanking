package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmploymentAddressPostcodeConstraint;
import com.natwest.pbbdhb.openapi.EmploymentAddress;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_UK_POSTCODE_FORMAT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.isUkAddress;
import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isBlank;

public class EmploymentAddressPostcodeValidator
        implements ConstraintValidator<EmploymentAddressPostcodeConstraint, EmploymentAddress> {

    @Override
    public boolean isValid(final EmploymentAddress address,
                           final ConstraintValidatorContext constraintValidatorContext) {
        return isNull(address) || !isUkAddress(address.getCountryIsoCode())
               || !isBlank(address.getPostcode()) && Pattern
                .matches(STANDARD_UK_POSTCODE_FORMAT, address.getPostcode());
    }
}
