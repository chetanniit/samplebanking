package com.natwest.pbbdhb.adbo.listener.hboadboevent.transformers;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DiaryEventNotesTransformer extends AbstractNotesTransformer {
    private static final String VELOCITY_MODEL_ADBO_REQUEST = "adboRequest";

    @Value("${application.config.velocity.template-path.diary-notes}")
    private String templatePath;

    @Override
    protected String getTemplatePath() {return templatePath;
    }

    @Override
    protected void preTransform(VelocityContext velocityContext, WorkflowContext wc) {
        super.preTransform(velocityContext, wc);
        velocityContext.put(VELOCITY_MODEL_ADBO_REQUEST, wc.getOriginalPayload());
    }

}
