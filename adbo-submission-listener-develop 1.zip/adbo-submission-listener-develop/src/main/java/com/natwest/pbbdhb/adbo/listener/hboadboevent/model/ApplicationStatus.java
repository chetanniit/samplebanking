package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

public enum ApplicationStatus {

    /**
     * Incoming Data Validation Failed.
     *
     */
    CONTRACT_VALIDATION_ERROR,

    /**
     * Incoming Data Validation Failed.
     * Hardscore validation failed
     */
    HARDSCORE_DECLINED,

    /**
     * Found failed route and it is not retry attempt.
     * No routes executed yet (responseMap in workflowContext is empty)
     */
    ACCEPTED,

    /**
     * Found failed route and it is retry attempt.
     */
    PENDING,

    /**
     * No failed route after retry i.e. retry successful.
     */
    RETRY_SUCCESSFUL,

    /**
     * Found failed route and no retry attempts left (all retry attempts failed).
     */
    RETRY_FAILED,

    /**
     * Deserialization failed.
     */
    FAILED,

    /**
     * Not Found any failed route and response Map is not empty.
     */
    SUCCESSFUL,

    /**
     * For Manual Keyed In Cases.
     */
    MANUAL_KEY_IN_SUCCESSFUL;


}
