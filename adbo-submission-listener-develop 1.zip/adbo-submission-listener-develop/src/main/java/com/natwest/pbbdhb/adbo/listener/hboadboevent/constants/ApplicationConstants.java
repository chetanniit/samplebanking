package com.natwest.pbbdhb.adbo.listener.hboadboevent.constants;

@SuppressWarnings("checkstyle:interfaceistype")
   public interface ApplicationConstants {
    String BRAND = "brand";
    String CASE_ID = "case";
    String CHANNEL = "channel";
    String CLIENT_ID = "client_id";
    String PREFIX_EXCEPTION_MSG_LOG = "adbo-submission-listener:adbo:Exception in processing request for mortgage process:";

}
