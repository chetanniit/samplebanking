package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.notes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaskNote {
    private String taskSequenceNumber;
    private String note;
}
