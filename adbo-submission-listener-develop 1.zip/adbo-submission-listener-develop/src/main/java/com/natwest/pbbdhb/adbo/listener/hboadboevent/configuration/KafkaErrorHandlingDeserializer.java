package com.natwest.pbbdhb.adbo.listener.hboadboevent.configuration;

import com.natwest.pbbdhb.openapi.Application;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;

public class KafkaErrorHandlingDeserializer extends ErrorHandlingDeserializer<Application> {
}
