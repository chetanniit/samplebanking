package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class GetCustomerBaseAddress implements Serializable {
    private static final long serialVersionUID = 1L;

    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String address5;
    private String addressPC;
}
