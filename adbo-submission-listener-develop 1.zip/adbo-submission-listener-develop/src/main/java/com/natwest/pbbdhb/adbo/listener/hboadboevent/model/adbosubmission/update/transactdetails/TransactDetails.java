package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.update.transactdetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactDetails {
    private String aipReferenceNumber;
    private String decision;
    private LocalDate decisionDate;
    private String resultFromTransact;
    private String referrals;
    private String additionalInfo;
}
