package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum IncomeFrequency {
    ANNUALLY, BIANNUALLY, FORTNIGHTLY, FOUR_WEEKLY, MONTHLY, QUARTERLY, WEEKLY
}
