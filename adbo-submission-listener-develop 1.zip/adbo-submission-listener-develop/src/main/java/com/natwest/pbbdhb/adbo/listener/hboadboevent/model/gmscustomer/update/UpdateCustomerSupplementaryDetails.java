package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerSupplementaryDetails {

    private String countryOfResidence;
    private Integer noOfMonthsResidentInUK;
    private String maidenName;
    private LocalDate dateMaidenNameChanged;
    private String movingIntoPropertyAtCompletion;
    private String holdsInvestmentAccount;
    private String interestOrShareInPropertyOtherThanCurrentDwelling;
    private String existingCustomerWithMortgage;
    private String existingSocietyMember;
    private String existingAccountNumber;
    private String deliveryPreference;
    private String faxNumber;
    private Integer numberOfDependants;
    private LocalDate retirementDate;
    private String kycChannel;

}
