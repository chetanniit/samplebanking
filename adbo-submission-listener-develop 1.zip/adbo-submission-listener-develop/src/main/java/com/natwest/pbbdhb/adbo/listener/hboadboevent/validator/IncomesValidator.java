package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.IncomesConstraint;
import com.natwest.pbbdhb.openapi.Employment;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.isPreviousEmployment;
import static com.natwest.pbbdhb.openapi.Employment.EmploymentStatusEnum.EMPLOYED;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class IncomesValidator implements ConstraintValidator<IncomesConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || !EMPLOYED.equals(employment.getEmploymentStatus())
                || isPreviousEmployment(employment) || (
                nonNull(employment.getIncomes()) && !employment.getIncomes().isEmpty());
    }
}
