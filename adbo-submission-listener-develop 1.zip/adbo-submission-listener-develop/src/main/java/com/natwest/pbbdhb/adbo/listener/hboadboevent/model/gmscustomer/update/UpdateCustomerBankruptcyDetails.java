package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerBankruptcyDetails {
    private String answer;
    private LocalDate bankruptcyDate;
    private LocalDate bankruptcyDischargeDate;
    private Integer noYrsBankruptcyDischarged;
    private BigDecimal bankruptcyAmount;
    private String note;
}
