package com.natwest.pbbdhb.adbo.listener.hboadboevent.interceptor;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.CustomHeader;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.header.Header;
import org.springframework.kafka.retrytopic.RetryTopicHeaders;
import org.springframework.kafka.support.KafkaHeaders;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class RetryHeaderEnrichInterceptor<K, V> implements ProducerInterceptor<K, V> {
    private static final Pattern TEMP_REF_MATCHER = Pattern.compile("(?<=<tempRefNo>)(.*)(?=</tempRefNo>)");

    @Override
    public ProducerRecord<K, V> onSend(ProducerRecord<K, V> record) {
        Header retryAttemptsHeader = record.headers().lastHeader(RetryTopicHeaders.DEFAULT_HEADER_ATTEMPTS);
        if (Objects.nonNull(retryAttemptsHeader)
                && 0 < new BigInteger(retryAttemptsHeader.value()).intValue()) {
            Header tempRefHeader = record.headers().lastHeader(CustomHeader.TEMP_REF_NO.getKafkaHeader());
            if (Objects.isNull(tempRefHeader)) {
                Header exHeader = record.headers().lastHeader(KafkaHeaders.EXCEPTION_MESSAGE);
                Matcher m1 = TEMP_REF_MATCHER.matcher(new String(exHeader.value(), StandardCharsets.UTF_8));
                if (m1.find()) {
                    record.headers().add(CustomHeader.TEMP_REF_NO.getKafkaHeader(),
                            m1.group().getBytes(StandardCharsets.UTF_8));
                    log.info("Added custom header '[{}={}]' for retry attempt",
                            CustomHeader.TEMP_REF_NO.getKafkaHeader(), m1.group());
                }
            }
        }
        return record;
    }

    @Override
    public void onAcknowledgement(RecordMetadata recordMetadata, Exception e) {
    }

    @Override
    public void close() {
    }

    @Override
    public void configure(Map<String, ?> map) {
    }
}
