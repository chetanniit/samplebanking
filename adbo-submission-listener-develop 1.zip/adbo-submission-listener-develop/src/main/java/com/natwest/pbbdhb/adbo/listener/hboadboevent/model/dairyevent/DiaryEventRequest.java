package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.dairyevent;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DiaryEventRequest {

    private String accountNumber;
    private String note;
    private String diaryEvent;
    private String userId;
    private String function;
    private BigInteger society;
    private String param1;
    private String param2;

}
