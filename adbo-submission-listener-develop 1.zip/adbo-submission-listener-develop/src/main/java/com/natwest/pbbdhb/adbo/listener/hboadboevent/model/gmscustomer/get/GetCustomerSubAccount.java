package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerSubAccount implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer subAccountNumber;
    private String globalAccountType;
    private GetCustomerCodeDescription usageCode;
    private String isAccountOwner;
    private Integer holderPosition;
    private GetCustomerCodeDescription processStatus;
    private LocalDate inceptionDate;
    private LocalDate closureDate;
    private GetCustomerProductDescription productDescription;
    private GetCustomerOtherAccountHolders otherAccountHolders;
}
