package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmploymentTypeContractEndDateConstraint;
import com.natwest.pbbdhb.openapi.Employment;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class EmploymentTypeContractEndDateValidator
        implements ConstraintValidator<EmploymentTypeContractEndDateConstraint, Employment> {
    @Override
    public boolean isValid(Employment employment, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(employment) || isNull(employment.getEmploymentType()) || isNull(employment.getEmploymentStatus())
                || employment.getEmploymentStatus().equals(Employment.EmploymentStatusEnum.NOT_EMPLOYED) || !employment
                .getEmploymentType().getValue().equals(Employment.EmploymentTypeEnum.CONTRACT.getValue()) || nonNull(
                employment.getEndDate());
    }
}
