package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.GMSTask;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.TaskAction;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.managetask.ManageTaskRequest;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public abstract class CreateManualValInstructionTaskRequestMapper extends CreateManageTaskRequestMapper
        implements WorkflowMapper<WorkflowContext, ManageTaskRequest> {

    public ManageTaskRequest map(WorkflowContext source) {
        return mapToManageTaskRequest(source, GMSTask.MANUAL_VAL_INSTRUCTION, TaskAction.OPEN, null);
    }

}
