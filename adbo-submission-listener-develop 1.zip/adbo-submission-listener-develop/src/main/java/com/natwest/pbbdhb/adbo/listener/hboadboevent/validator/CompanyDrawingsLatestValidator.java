package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CompanyDrawingsLatestConstraint;
import com.natwest.pbbdhb.openapi.Employment;
import com.natwest.pbbdhb.openapi.SelfEmployed;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.isPreviousEmployment;
import static com.natwest.pbbdhb.openapi.SelfEmployed.BusinessTypeEnum.LIMITED_COMPANY;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class CompanyDrawingsLatestValidator
        implements ConstraintValidator<CompanyDrawingsLatestConstraint, Employment> {

    @Override
    @SuppressWarnings("checkstyle:innerassignment")
    public boolean isValid(final Employment employment,
                           final ConstraintValidatorContext constraintValidatorContext) {

        SelfEmployed selfEmployed = null;

        return isNull(employment) || isPreviousEmployment(employment)
                || (isNull(selfEmployed = employment.getSelfEmployed())
                || !LIMITED_COMPANY.equals(selfEmployed.getBusinessType()) || nonNull(
                        selfEmployed.getDrawingsLatest()));
    }
}
