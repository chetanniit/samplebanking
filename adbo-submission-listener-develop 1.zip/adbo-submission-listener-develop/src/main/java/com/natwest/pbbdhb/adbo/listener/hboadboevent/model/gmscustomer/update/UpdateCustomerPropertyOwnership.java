package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;


import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerPropertyOwnership {
    private ContactAddress propertyOwnershipAddress;
    private String propertyType;
    private Integer proportionOwned;
}
