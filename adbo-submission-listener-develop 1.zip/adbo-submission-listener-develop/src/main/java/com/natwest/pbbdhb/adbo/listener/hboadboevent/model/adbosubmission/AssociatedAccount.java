package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssociatedAccount {
    private String productCode;
    private BigDecimal loanAmount;
    private Integer termYears;
    private Integer termMonths;
    private String loanPurpose;
    private String calculationType;
    private String regulatedAuthority;
    private String regulatedAuthorityOverridenBy;
}
