package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ContactPreferenceRequestType {

    PERSONALCUSTOMERPREFERENCES("PersonalCustomerPreferences", "Personal Customer Preferences"),
    CUSTOMERADDRESS("CustomerAddress", "Customer Address");

    private String key;

    private String value;

    @Override
    public String toString() {
        return key;
    }
}
