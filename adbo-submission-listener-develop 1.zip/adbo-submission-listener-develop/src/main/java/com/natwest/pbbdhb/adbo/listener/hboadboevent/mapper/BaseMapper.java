package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.AddressWrapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.ContactAddress;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.CountryIsoToGmsCode;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import com.natwest.pbbdhb.openapi.Address;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.Employment;
import com.natwest.pbbdhb.openapi.Income;
import com.natwest.pbbdhb.openapi.PropertyDetails;
import com.natwest.pbbdhb.openapi.SelfEmployed;
import com.natwest.pbbdhb.openapi.Telephone;
import com.natwest.pbbdhb.openapi.UnstructuredAddress;
import com.natwest.pbbdhb.openapi.UnstructuredEmploymentAddress;
import org.apache.commons.lang.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.SPACE;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.trim;

@Mapper(componentModel = "spring")
public interface BaseMapper {

    int ADDRESS_LINE_MAX_LENGTH = 40;

    static Address toCurrentAddress(Set<Address> addresses) {
        return addresses.stream().filter(address -> isBlank(address.getEndDate())).findFirst().orElse(null);
    }

    static boolean isUkAddress(String countryCode) {
        return "GB".equals(countryCode);
    }

    default Set<Address> toPreviousAddresses(Set<Address> addresses) {
        return addresses.stream().filter(address -> isNotBlank(address.getEndDate())).collect(Collectors.toSet());
    }

    @Named("countryCode")
    default String toCountryCode(Address address) {
        return isUkAddress(address.getCountryIsoCode()) ? CountryIsoToGmsCode.GB.getCountryCode()
                : getGmsCode(address.getCountryIsoCode(), CountryIsoToGmsCode::getCountryCode);
    }

    @Named("applicantAddressLine1")
    default String mapToGMSApplicantAddressLine1(Address address) {
        return getAddressLine1(trim(address.getHouseNumber()), trim(address.getFlat()), trim(address.getHouseName()),
                trim(address.getStreet()));
    }

    @Named("applicantAddressLine2")
    default String mapToGMSApplicantAddressLine2(Address address) {
        return getAddressLine2(trim(address.getHouseNumber()), trim(address.getFlat()), trim(address.getHouseName()),
                trim(address.getStreet()), trim(address.getDistrict()), trim(address.getTown()));
    }

    @Named("applicantAddressLine3")
    default String mapToGMSApplicantAddressLine3(Address address) {
        if (isUkAddress(address.getCountryIsoCode())) {
            return getAddressLine3(trim(address.getHouseNumber()), trim(address.getFlat()),
                    trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                    trim(address.getCounty()));
        }
        return getNonUkAddressLine3(trim(address.getHouseNumber()), trim(address.getFlat()),
                trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                trim(address.getCounty()), trim(address.getPostcode()));
    }

    @Named("applicantAddressLine4")
    default String mapToGMSApplicantAddressLine4(Address address) {
        if (isUkAddress(address.getCountryIsoCode())) {
            return getAddressLine4(trim(address.getHouseNumber()), trim(address.getFlat()),
                    trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                    trim(address.getCounty()));
        }
        return getNonUkAddressLine4(trim(address.getHouseNumber()), trim(address.getFlat()),
                trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                trim(address.getCounty()), trim(address.getPostcode()));
    }

    @Named("applicantAddressLine5")
    default String mapToGMSApplicantAddressLine5(Address address) {
        if (isUkAddress(address.getCountryIsoCode())) {
            return getAddressLine5(trim(address.getHouseNumber()), trim(address.getFlat()),
                    trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getCounty()));
        }
        return getNonUkAddressLine5(trim(address.getHouseNumber()), trim(address.getFlat()),
                trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getCounty()),
                trim(address.getPostcode()));
    }


    @Named("applicantPostcode")
    default String mapToPostcode(Address address) {
        if (isUkAddress(address.getCountryIsoCode())) {
            return address.getPostcode();
        }
        return null;
    }

    default LocalDate toLocalDate(String date) {
        return ADBOUtils.toLocalDate(date, DateTimeFormatter.ISO_LOCAL_DATE);
    }

    @Named("startDate")
    default LocalDate toStartDateAtAddress(String startDate) {
        return toLocalDate(startDate);
    }

    default Period toPeriodAtEmployment(Employment employment) {
        LocalDate startDate =
                Optional.ofNullable(employment.getStartDate()).filter(StringUtils::isNotBlank).map(s -> toLocalDate(s))
                        .orElse(null);
        LocalDate endDate =
                Optional.ofNullable(employment.getEndDate()).filter(StringUtils::isNotBlank).map(s -> toLocalDate(s))
                        .orElse(null);
        return Period
                .between(isNull(startDate) ? LocalDate.now() : startDate, isNull(endDate) ? LocalDate.now() : endDate);
    }

    default Period toPeriod(LocalDate startDate) {
        return Period.between(startDate, LocalDate.now());
    }

    @Named("yearsAtAddress")
    default Integer toYearsAtAddress(Address address) {
        return Optional.ofNullable(address).map(a -> toPeriodAtAddress(a).getYears()).orElse(null);
    }

    @Named("monthsAtAddress")
    default Integer toMonthsAtAddress(Address address) {
        return Optional.ofNullable(address).map(a -> toPeriodAtAddress(a).getMonths()).orElse(null);
    }

    @Named("yearsAtGmsAddress")
    default Integer toYearsAtGmsAddress(UnstructuredAddress address) {
        return Optional.ofNullable(address).map(a -> toPeriodAtGmsAddress(a).getYears()).orElse(null);
    }

    @Named("monthsAtGmsAddress")
    default Integer toMonthsAtGmsAddress(UnstructuredAddress address) {
        return Optional.ofNullable(address).map(a -> toPeriodAtGmsAddress(a).getMonths()).orElse(null);
    }

    default Period toPeriodAtAddress(Address address) {
        LocalDate endDate = isNotBlank(address.getEndDate()) ? toLocalDate(address.getEndDate()) : LocalDate.now();
        return Period.between(toLocalDate(address.getStartDate()), endDate.plusDays(1));
    }

    default Period toPeriodAtGmsAddress(UnstructuredAddress address) {
        LocalDate endDate = LocalDate.now();
        return Period.between(toLocalDate(address.getStartDate()), endDate.plusDays(1));
    }

    default List<Employment> toEmployed(List<Employment> source) {
        return source.stream().filter(e -> e.getEmploymentStatus().equals(Employment.EmploymentStatusEnum.EMPLOYED))
                .collect(Collectors.toList());
    }

    default List<Employment> toSelfEmployed(List<Employment> source) {
        return source.stream()
                .filter(e -> e.getEmploymentStatus().equals(Employment.EmploymentStatusEnum.SELF_EMPLOYED))
                .collect(Collectors.toList());
    }


    /**
     * Map a set of telephone numbers to a single value based on the types specified.
     * The numbers in the set are sorted using the preferred flag and the order specifed by the types parameter and the
     * number at the top is returned.
     * Preferred numbers sort ahead on non-preferred numbers.
     * Numbers with the same preferred value sort according to the order of the specified types.
     * The ordering of numbers of the same type and same preferred value is indeterminate.
     *
     * @param telephones set of telephone numbers
     * @param types      desired number types in priority order
     * @return the single mapped number
     */
    default String toContactNumber(final Set<Telephone> telephones, final Telephone.TypeEnum... types) {

        List<Telephone.TypeEnum> typesList = Arrays.asList(types);

        return ofNullable(telephones).map(Collection::stream)
                .flatMap(ts -> ts.filter(t -> typesList.contains(t.getType())).sorted((lhs, rhs) -> {
                    if (lhs.getPreferred() == rhs.getPreferred()) {
                        final Telephone.TypeEnum lhsType = lhs.getType();
                        final Telephone.TypeEnum rhsType = rhs.getType();
                        if (typesList.indexOf(lhsType) < typesList.indexOf(rhsType)) {
                            return -1;
                        } else if (typesList.indexOf(lhsType) > typesList.indexOf(rhsType)) {
                            return 1;
                        } else {
                            return 0;
                        }
                    } else if (lhs.getPreferred()) {
                        return -1;
                    } else {
                        return 1;
                    }
                }).map(t -> t.getNumber()).findFirst()).orElse(StringUtils.EMPTY);
    }

    /**
     * Return the fax number from the specified set of telephone numbers.
     *
     * @param telephones the set of telephone numbers
     * @return the fax number
     */
    @Named(value = "telephoneListToFax")
    default String toFaxNumber(Set<Telephone> telephones) {
        return toContactNumber(telephones, Telephone.TypeEnum.FAX);
    }

    /**
     * Return the home number from the specified set of telephone numbers.
     *
     * @param telephones the set of telephone numbers
     * @return the home number
     */
    @Named(value = "telephoneListToHome")
    default String toHomeNumber(Set<Telephone> telephones) {
        return toContactNumber(telephones, Telephone.TypeEnum.HOME);
    }

    /**
     * Return the work number from the specified set of telephone numbers.
     *
     * @param telephones the set of telephone numbers
     * @return the work number
     */
    @Named(value = "telephoneListToWork")
    default String toWorkNumber(Set<Telephone> telephones) {
        return toContactNumber(telephones, Telephone.TypeEnum.WORK);
    }

    /**
     * Return the mobile number from the specified set of telephone numbers.
     *
     * @param telephones the set of telephone numbers
     * @return the mobile number
     */
    @Named(value = "telephoneListToMobile")
    default String toMobileNumber(Set<Telephone> telephones) {
        return toContactNumber(telephones, Telephone.TypeEnum.MOBILE);
    }

    /**
     * Return the "best" personal number from the specified set of telephone numbers.
     * MOBILE is favoured over HOME, which is favoured over WORK.
     *
     * @param telephones the set of telephone numbers
     * @return the fax number
     */
    @Named(value = "telephoneListToPersonal")
    default String toPersonalNumber(Set<Telephone> telephones) {
        return toContactNumber(telephones, Telephone.TypeEnum.MOBILE, Telephone.TypeEnum.HOME, Telephone.TypeEnum.WORK);
    }

    /**
     * Return the "best" business number from the specified set of telephone numbers.
     * WORK is favoured over MOBILE, which is favoured over HOME.
     *
     * @param telephones the set of telephone numbers
     * @return the fax number
     */
    @Named(value = "telephoneListToBusiness")
    default String toBusinessNumber(Set<Telephone> telephones) {
        return toContactNumber(telephones, Telephone.TypeEnum.WORK, Telephone.TypeEnum.MOBILE, Telephone.TypeEnum.HOME);
    }

    @Named(value = "toGMSYesOrNo")
    default String toGMSYesOrNo(Boolean source) {
        return Objects.nonNull(source) && source ? "Y" : "N";
    }

    //To GMS Foreign Address Indicator
    @Named(value = "toGMSForeignAddressIndicator")
    default String toGMSForeignAddress(String source) {
        return "GB".equals(source) || "UK".equals(source) ? "N" : "Y";
    }


    @Named("numberOfYears")
    default Integer toYears(LocalDate dateEstablished) {
        return toPeriod(dateEstablished).getYears();
    }

    @Named("numberOfMonths")
    default Integer toMonths(LocalDate dateEstablished) {
        return toPeriod(dateEstablished).getMonths();
    }

    @Named("yearsAtEmployment")
    default Integer toYearsAtEmployment(Employment employment) {
        return Optional.ofNullable(employment).map(e -> toPeriodAtEmployment(e).getYears()).orElse(null);
    }

    @Named("monthsAtEmployment")
    default Integer toMonthsAtEmployment(Employment employment) {
        return Optional.ofNullable(employment).map(e -> toPeriodAtEmployment(e).getMonths()).orElse(null);
    }


    //To Year String
    @Named(value = "toYear")
    default Integer mapToYear(String date) {
        int yearLen = 4;
        return StringUtils.isNotBlank(date) ? Integer.valueOf(date.substring(0, yearLen)) : null;
    }

    default String getAddressLine1(String houseNo, String flat, String houseName, String street) {
        String addressLine1;
        if (isNotBlank(houseNo)) {
            addressLine1 = new StringBuilder().append(houseNo).append(SPACE).append(street).toString();
        } else if (isNotBlank(flat)) {
            // Housename NOT Blank = Falt + " " + HouseName
            // Housename Blank = Falt + " " + Street
            addressLine1 =
                    new StringBuilder().append(flat).append(SPACE).append(isNotBlank(houseName) ? houseName : street)
                            .toString();
        } else {
            // Housename NOT Blank = HouseName
            addressLine1 = houseName;
        }
        return addressLine1.length() > ADDRESS_LINE_MAX_LENGTH ? addressLine1.substring(0, ADDRESS_LINE_MAX_LENGTH)
                : addressLine1;
    }

    default String getAddressLine2(String houseNo, String flat, String houseName, String street, String district,
                                   String town) {
        String addressLine2;
        if (isNotBlank(houseNo)) {
            // Flat NOT Blank and Housename Blank = Flat
            // Flat Blank and Housename NOT Blank = Housename
            // Flat and Housename are NOT Blank = Flat + " " + Housename
            // Flat and Housename are Blank = District or Town
            addressLine2 = isBlank(flat) && isBlank(houseName) ? isNotBlank(district) ? district : town
                    : new StringBuilder(Optional.ofNullable(flat).orElse(EMPTY))
                            .append(isNotBlank(flat) && isNotBlank(houseName) ? SPACE : EMPTY)
                            .append(Optional.ofNullable(houseName).orElse(EMPTY)).toString();
        } else if (isNotBlank(flat)) {
            // Housename NOT Blank = Street
            // Housename Blank = District or Town
            addressLine2 = isNotBlank(houseName) ? street : isNotBlank(district) ? district : town;
        } else {
            // Housename NOT Blank = Street
            addressLine2 = street;
        }
        return addressLine2.length() > ADDRESS_LINE_MAX_LENGTH ? addressLine2.substring(0, ADDRESS_LINE_MAX_LENGTH)
                : addressLine2;
    }

    default String getAddressLine3(String houseNo, String flat, String houseName, String district, String town,
                                   String county) {
        if (isNotBlank(houseName) || (isNotBlank(houseNo) && isNotBlank(flat))) {
            return isNotBlank(district) ? district : town;
        }
        return isNotBlank(district) ? town : county;
    }

    default String getNonUkAddressLine3(String houseNo, String flat, String houseName, String district, String town,
                                        String county, String postcode) {
        if (isNotBlank(houseName) || (isNotBlank(houseNo) && isNotBlank(flat))) {
            return isNotBlank(district) ? district : town;
        }
        return isNotBlank(district) ? town : (isNotBlank(county) ? county : postcode);
    }

    default String getAddressLine4(String houseNo, String flat, String houseName, String district, String town,
                                   String county) {
        if (isNotBlank(houseName) || (isNotBlank(houseNo) && isNotBlank(flat))) {
            return isNotBlank(district) ? town : county;
        }
        return isNotBlank(district) ? county : null;
    }

    default String getNonUkAddressLine4(String houseNo, String flat, String houseName, String district, String town,
                                        String county, String postcode) {
        if (isNotBlank(houseName) || (isNotBlank(houseNo) && isNotBlank(flat))) {
            return isNotBlank(district) ? town : (isNotBlank(county) ? county : postcode);
        }
        return isNotBlank(district) ? (isNotBlank(county) ? county : postcode) : (isNotBlank(county) ? postcode : null);
    }

    default String getAddressLine5(String houseNo, String flat, String houseName, String district, String county) {
        if (isNotBlank(houseName) || (isNotBlank(houseNo) && isNotBlank(flat))) {
            return isNotBlank(district) ? county : null;
        }
        return null;
    }

    default String getNonUkAddressLine5(String houseNo, String flat, String houseName, String district, String county,
                                        String postcode) {
        if (isNotBlank(houseName) || (isNotBlank(houseNo) && isNotBlank(flat))) {
            if (isNotBlank(district)) {
                if (isNotBlank(county)) {
                    return county + (isNotBlank(postcode) ? SPACE + postcode : EMPTY);
                }
                return postcode;
            } else {
                return (isNotBlank(county) ? postcode : null);
            }
        }
        return isNotBlank(district) && isNotBlank(county) ? postcode : null;
    }

    default BigDecimal getSelfEmployedNonPrimaryIncome(SelfEmployed selfEmployed) {
        switch (selfEmployed.getBusinessType()) {
            case LIMITED_COMPANY:
                return getCompanyAverageIncome(selfEmployed);
            default:
                return getSoleTraderOrPartnershipAverageIncome(selfEmployed);
        }
    }

    default BigDecimal getCompanyAverageIncome(SelfEmployed selfEmployed) {
        BigDecimal drawings = (nonNull(selfEmployed.getDrawingsPrevious())
                && selfEmployed.getDrawingsPrevious().compareTo(BigDecimal.ZERO) > 0)
                ? (selfEmployed.getDrawingsLatest().compareTo(selfEmployed.getDrawingsPrevious()) > 0
                ? selfEmployed.getDrawingsLatest().add(selfEmployed.getDrawingsPrevious())
                                .divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN)
                : selfEmployed.getDrawingsLatest())
                : nonNull(selfEmployed.getDrawingsLatest())
                        ? selfEmployed.getDrawingsLatest().divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN)
                        : BigDecimal.ZERO;
        BigDecimal dividends = (nonNull(selfEmployed.getDividendsLatest())
                && selfEmployed.getDividendsLatest().compareTo(BigDecimal.ZERO) > 0)
                ? ((nonNull(selfEmployed.getDividendsPrevious())
                        && selfEmployed.getDividendsPrevious().compareTo(BigDecimal.ZERO) > 0)
                        && selfEmployed.getDividendsLatest().compareTo(selfEmployed.getDividendsPrevious()) > 0
                ? selfEmployed.getDividendsLatest().add(selfEmployed.getDividendsPrevious())
                                .divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN)
                : (isNull(selfEmployed.getDividendsPrevious()) || selfEmployed.getDividendsPrevious()
                                .equals(BigDecimal.ZERO) ? selfEmployed.getDividendsLatest()
                                .divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN)
                : selfEmployed.getDividendsLatest())) : BigDecimal.ZERO;
        return drawings.add(dividends);
    }

    default BigDecimal getSoleTraderOrPartnershipAverageIncome(SelfEmployed selfEmployed) {
        return (nonNull(selfEmployed.getNetProfitPrevious())
                && selfEmployed.getNetProfitPrevious().compareTo(BigDecimal.ZERO) > 0)
                ? selfEmployed.getNetProfitLatest().compareTo(selfEmployed.getNetProfitPrevious()) > 0
                ? selfEmployed.getNetProfitLatest().add(selfEmployed.getNetProfitPrevious())
                                .divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN)
                : selfEmployed.getNetProfitLatest()
                : nonNull(selfEmployed.getNetProfitLatest())
                        ? selfEmployed.getNetProfitLatest().divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN)
                        : BigDecimal.ZERO;
    }

    default BigDecimal toAnnualIncomeAmount(Income income) {

        final int biannuallyFreq = 2;
        final int quarterlyFreq = 4;
        final int weeklyFreq = 52;
        final int monthlyFreq = 12;
        final int fortnightlyFreq = 26;
        final int fourWeeklyFreq = 13;

        switch (income.getFrequency()) {
            case BIANNUALLY:
                return income.getAmount().multiply(BigDecimal.valueOf(biannuallyFreq));
            case QUARTERLY:
                return income.getAmount().multiply(BigDecimal.valueOf(quarterlyFreq));
            case WEEKLY:
                return income.getAmount().multiply(BigDecimal.valueOf(weeklyFreq));
            case MONTHLY:
                return income.getAmount().multiply(BigDecimal.valueOf(monthlyFreq));
            case FORTNIGHTLY:
                return income.getAmount().multiply(BigDecimal.valueOf(fortnightlyFreq));
            case FOUR_WEEKLY:
                return income.getAmount().multiply(BigDecimal.valueOf(fourWeeklyFreq));
            default:
                return income.getAmount();
        }
    }

    default String getGmsCode(String countryIsoCode, Function<CountryIsoToGmsCode, String> function) {
        return Optional.ofNullable(countryIsoCode).map(CountryIsoToGmsCode::getCountryIsoToGmsCode).map(function)
                .orElse(null);

    }

    //To GMS NUmber Of Dependants
    default Integer mapToGMSNumberOfDependants(WorkflowContext workflowContext) {
        Application application = ADBOWorkflowUtils.getOriginalPayload(workflowContext);
        Integer numberOfDependants =
                application.getNumberOfDependantsOver18() + application.getNumberOfDependantsUnder18();
        return numberOfDependants.compareTo(0) > 0 ? numberOfDependants : 0;
    }

    @Named(value = "toGMSEmploymentAddress")
    default ContactAddress toGMSEmploymentAddress(Employment employment) {
        return nonNull(employment.getAddress()) ? toGMSContactAddress(new AddressWrapper(employment.getAddress()))
                : toGMSContactAddress(employment.getUnstructuredAddress());
    }

    @Mapping(target = "addressCountry", source = "countryCode")
    @Mapping(target = "addressPC", source = "postcode")
    @Mapping(target = "address1", source = "address1")
    @Mapping(target = "address2", source = "address2")
    @Mapping(target = "address3", source = "address3")
    @Mapping(target = "address4", source = "address4")
    @Mapping(target = "address5", source = "address5")
    ContactAddress toGMSContactAddress(UnstructuredEmploymentAddress gmsEmploymentAddress);

    default ContactAddress toGMSContactAddress(AddressWrapper address) {
        String addressCountry = ofNullable(getGmsCode(address.getCountryIsoCode(), CountryIsoToGmsCode::getCountryCode))
                .orElseGet(() -> address.isUkAddress() ? CountryIsoToGmsCode.GB.getCountryCode() : null);
        ContactAddress.ContactAddressBuilder contactAddressBuilder = ContactAddress.builder().address1(
                        getAddressLine1(trim(address.getHouseNumber()), trim(address.getFlat()),
                                trim(address.getHouseName()),
                                trim(address.getStreet()))).address2(
                        getAddressLine2(trim(address.getHouseNumber()), trim(address.getFlat()),
                                trim(address.getHouseName()),
                                trim(address.getStreet()), trim(address.getDistrict()), trim(address.getTown())))
                .addressCountry(addressCountry);
        if (address.isUkAddress()) {
            //Build UK address
            return contactAddressBuilder.address3(
                            getAddressLine3(trim(address.getHouseNumber()), trim(address.getFlat()),
                                    trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                                    trim(address.getCounty()))).address4(
                            getAddressLine4(trim(address.getHouseNumber()), trim(address.getFlat()),
                                    trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                                    trim(address.getCounty()))).address5(
                            getAddressLine5(trim(address.getHouseNumber()), trim(address.getFlat()),
                                    trim(address.getHouseName()), trim(address.getDistrict()),
                                    trim(address.getCounty())))
                    .addressPC(address.getPostcode()).build();
        }
        //Build NON UK address
        return contactAddressBuilder.address3(
                getNonUkAddressLine3(trim(address.getHouseNumber()), trim(address.getFlat()),
                        trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                        trim(address.getCounty()), trim(address.getPostcode()))).address4(
                getNonUkAddressLine4(trim(address.getHouseNumber()), trim(address.getFlat()),
                        trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getTown()),
                        trim(address.getCounty()), trim(address.getPostcode()))).address5(
                getNonUkAddressLine5(trim(address.getHouseNumber()), trim(address.getFlat()),
                        trim(address.getHouseName()), trim(address.getDistrict()), trim(address.getCounty()),
                        trim(address.getPostcode()))).build();
    }

    @Named(value = "getMortgageNumber")
    default String getMortgageNumber(WorkflowContext context) {
        return ADBOWorkflowUtils.getMortgageNumber(context);
    }

    @Named(value = "getApplicationSequenceNumber")
    default String getApplicationSequenceNumber(WorkflowContext context) {
        return ADBOWorkflowUtils.getAppSeq(context);
    }

    @Named("mapToPropertyValue")
    default BigDecimal mapToPropertyValue(PropertyDetails source) {
        BigDecimal propertyValue =
                Optional.ofNullable(source.getEstimatedValueByCustomer()).orElse(source.getEstimatedValueByHPI());
        return propertyValue.setScale(0, BigDecimal.ROUND_DOWN);
    }

}
