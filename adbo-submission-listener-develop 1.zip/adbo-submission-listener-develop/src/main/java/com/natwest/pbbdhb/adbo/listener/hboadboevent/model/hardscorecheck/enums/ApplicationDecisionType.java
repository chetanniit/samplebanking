package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ApplicationDecisionType {

    DECLINE("1", "decline");

    private final String key;

    private final String value;

    public String value() {
        return value;
    }
}
