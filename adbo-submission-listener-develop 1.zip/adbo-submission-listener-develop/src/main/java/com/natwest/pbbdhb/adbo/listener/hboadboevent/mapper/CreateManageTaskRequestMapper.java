package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.GMSTask;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.TaskAction;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.managetask.ManageTaskRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring")
public abstract class CreateManageTaskRequestMapper implements BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    @Mapping(target = "mortgage", source = "source", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "applSeq", source = "source", qualifiedByName = "getApplicationSequenceNumber")
    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target = "taskCode", expression = "java(task.getCode())")
    @Mapping(target = "note", source = "note")
    @Mapping(target = "action", expression = "java(action.getAction())")
    @Mapping(target = "taskSuccessIndicator", source = "action", qualifiedByName = "getTaskSuccessIndicator")
    protected abstract ManageTaskRequest mapToManageTaskRequest(WorkflowContext source, GMSTask task,
                                                                TaskAction action, String note);
    @Named("getTaskSuccessIndicator")
    String getTaskSuccessIndicator(TaskAction action) {
        return TaskAction.CLOSE == action ? "Y" : null;
    }
}
