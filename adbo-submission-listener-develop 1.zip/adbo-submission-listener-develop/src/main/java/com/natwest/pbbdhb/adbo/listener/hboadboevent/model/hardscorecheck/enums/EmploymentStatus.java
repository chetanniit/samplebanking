package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum EmploymentStatus {
    EMPLOYED, NOT_EMPLOYED, SELF_EMPLOYED
}
