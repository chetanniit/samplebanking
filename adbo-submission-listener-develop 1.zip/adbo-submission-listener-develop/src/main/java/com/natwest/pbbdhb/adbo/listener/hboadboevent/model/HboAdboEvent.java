package com.natwest.pbbdhb.adbo.listener.hboadboevent.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ApplicationType;
import com.natwest.pbbdhb.openapi.Application;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class HboAdboEvent {
    @NotBlank
    private String mortgageRefNo;
    @NotBlank
    private String mortgageApplSeq;
    @NotBlank
    private String caseId;
    @NotBlank
    private String tempRefNo;
    @NotBlank
    private String brand;
    @NotBlank
    private String status;
    @NotBlank
    private String userId;
    @NotBlank
    private String channel;
    @NotNull
    private ApplicationType applicationType;
    @NotNull
    private Application application;
    @NotBlank
    private LocalDateTime submitDateTime;
}
