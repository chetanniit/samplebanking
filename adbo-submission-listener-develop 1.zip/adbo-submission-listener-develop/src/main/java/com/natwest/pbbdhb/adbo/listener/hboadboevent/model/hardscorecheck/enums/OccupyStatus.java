package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum OccupyStatus {
    OWNER_MORTGAGED, OWNER_NO_MORTGAGE, LIVING_WITH_RELATIVES, OTHER, TENANT
}
