package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class MonthlySubAccountRepayment implements Serializable {
    private static final long serialVersionUID = 1L;
    private String repaymentSequenceNumber;
    private LocalDate effectiveDate;
    private int numberOfRepayments;
    private BigDecimal totalMonthlySubAccountRepayment;
    private BigDecimal repaymentInterestRate;
    private BigDecimal differenceFromStandardRate;
    private String tierInterestCalculationType;
    private BigDecimal borrowingAmountRepayment;
    private BigDecimal xPercentStandardVariableRateIncreaseRepayment;
    private BigDecimal tierCappedRepayment;
    private BigDecimal tierFlooredRepayent;
    private BigDecimal tierCappedRate;
    private LocalDate tierEndDate;
}
