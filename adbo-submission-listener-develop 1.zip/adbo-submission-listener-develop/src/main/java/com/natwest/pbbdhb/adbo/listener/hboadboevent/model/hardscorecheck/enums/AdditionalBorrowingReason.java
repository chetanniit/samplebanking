package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum AdditionalBorrowingReason {
    HOME_IMPROVEMENT, HOUSE_PURCHASE, HOLIDAY, BUY_NEW_OR_USED_CAR, DEBT_CONSOLIDATION, OTHER
}
