package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum IndustryType {
    AGRICULTURE_HUNTING_FORESTRY("A"),
    CONSTRUCTION("F"),
    EDUCATION("M"),
    ELECTRICITY_GAS_WATER_SUPPLY("E"),
    FINANCIAL_INTERMEDIATION("J"),
    FISHING("B"),
    HEALTH_AND_SOCIAL_WORK("N"),
    HOTELS_AND_RESTAURANTS("H"),
    MANUFACTURING("D"),
    MINING_AND_QUARRYING("C"),
    OFFICE_WORK_AND_ADMINISTRATION("P"),
    OTHER("O"),
    PROPERTY_AND_BUSINESS("K"),
    PUBLIC_ADMIN_AND_DEFENCE("L"),
    TRANSPORT_STORAGE_COMM("I"),
    WHOLESALE_RETAIL_AND_REPAIR("G");

    private String gmsValue;


    public static String mapToGMSValue(final String fmaValue) {
        return valueOf(fmaValue).gmsValue;
    }


    @Override
    public String toString() {
        return name();
    }
}
