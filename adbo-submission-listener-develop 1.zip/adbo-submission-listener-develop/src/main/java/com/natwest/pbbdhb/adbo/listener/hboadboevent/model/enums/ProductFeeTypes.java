package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ProductFeeTypes {
    PRODUCT, VALUATION, CHAPS;
}
