package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.configuration;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.HttpCallFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.RetryPolicyExpressionFailedException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.WorkflowExecutionFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.BaseResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpCallTimestampCaptor;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpErrorResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.WorkflowUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.ParseException;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.http.HttpStatus;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.messaging.support.ErrorMessage;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Configuration
@Component
@Slf4j
public class WorkflowTransformersConfiguration {

    @Transformer(inputChannel = WorkflowExecutionConstants.ERROR_MESSAGE_EXCEPTION_TYPE_ROUTER_DEFAULT_OUTPUT_INPUT)
    public Message<?> handleRuntimeException(ErrorMessage errorMessage) {
        throw WorkflowUtils.toThrowable(WorkflowUtils.getFailedMessage(errorMessage), errorMessage.getPayload());
    }

    @Transformer(inputChannel = WorkflowExecutionConstants.HTTP_CALL_FAILURE_EXCEPTION_INPUT,
            outputChannel = WorkflowExecutionConstants.RESOLVE_FAIL_SAFE_INPUT)
    public Message<?> handleHttpCallFailureException(ErrorMessage errorMessage) {
        HttpCallFailureException ex = WorkflowUtils.getSpecificCause(errorMessage, HttpCallFailureException.class);
        log.error("Downstream call returned error={}", ex.getMessage());
        return toMessage(WorkflowUtils.getFailedMessage(errorMessage), ex.getStatus(), ex.getErrorResponse());
    }

    @Transformer(inputChannel = WorkflowExecutionConstants.RESOURCE_ACCESS_EXCEPTION_INPUT,
            outputChannel = WorkflowExecutionConstants.RESOLVE_FAIL_SAFE_INPUT)
    public Message<?> handleResourceAccessException(ErrorMessage errorMessage) {
        ResourceAccessException ex = WorkflowUtils.getSpecificCause(errorMessage, ResourceAccessException.class);
        log.error("Downstream call returned error={}", ex.getMessage());
        return toMessage(WorkflowUtils.getFailedMessage(errorMessage), HttpStatus.INTERNAL_SERVER_ERROR,
                WorkflowUtils.buildHttpErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, ex));
    }

    @Transformer(inputChannel = WorkflowExecutionConstants.MESSAGE_HANDLING_EXCEPTION_INPUT)
    public WorkflowExecutionFailureException handleMessageHandlingException(ErrorMessage errorMessage) {
        MessageHandlingException ex = WorkflowUtils.getSpecificCause(errorMessage, MessageHandlingException.class);
        throw WorkflowUtils.toThrowable(ex.getFailedMessage(), ex);
    }

    @Transformer(inputChannel = WorkflowExecutionConstants.TRANSFORM_RETRY_POLICY_EXPRESSION_FAILURE_INPUT,
            outputChannel = WorkflowExecutionConstants.RESOLVE_FAIL_SAFE_INPUT)
    public Message<?> handleRetryPolicyExpressionFailedException(ErrorMessage errorMessage) {
        RetryPolicyExpressionFailedException ex =
                WorkflowUtils.getSpecificCause(errorMessage, RetryPolicyExpressionFailedException.class);
        log.error("Retry policy expression failed, error", ex);
        return toMessage(WorkflowUtils.getFailedMessage(errorMessage), HttpStatus.INTERNAL_SERVER_ERROR,
                WorkflowUtils.buildHttpErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, ex));
    }

    public Message<?> toMessage(Message failedMessage, HttpStatus status, HttpErrorResponse errorResponse) {
        WorkflowContext workflowContext = failedMessage.getHeaders()
                .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class);
        AtomicInteger routingSlipIndex = failedMessage.getHeaders()
                .get(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER, AtomicInteger.class);
        WorkflowRoutingSlip.Route currentRoute = workflowContext.getRoutingSlip().get(routingSlipIndex.get());

        ((BaseRequest) workflowContext.getRequestMap().get(currentRoute.getRequestChannel())
                .get(currentRoute.getCount().get()))
                .setSendTimestamp(HttpCallTimestampCaptor.getSendTimestamp());

        currentRoute.getHttpStatus().put(currentRoute.getCount().get(), status);
        BaseResponse baseResponse = BaseResponse.builder()
                .response(errorResponse)
                .receiveTimestamp(Optional.ofNullable(HttpCallTimestampCaptor.getReceiveTimestamp()).orElse(
                        LocalDateTime.ofInstant(Instant.now(), ZoneOffset.UTC)))
                .build();
        currentRoute.getErrorResponse().put(currentRoute.getCount().get(), baseResponse);
        log.error("Route with index={} and count={} failed with errorResponse={}", routingSlipIndex.get(),
                currentRoute.getCount().get(), errorResponse);

        boolean isFailSafe = evaluateFailSafe(currentRoute, new StandardEvaluationContext(failedMessage));
        log.info("Route with index={} and count={} is set with failSafe={}", routingSlipIndex.get(),
                currentRoute.getCount().get(), isFailSafe);
        currentRoute.getFailSafeResult().put(currentRoute.getCount().get(), isFailSafe);

        Message message = MessageBuilder.withPayload(failedMessage.getPayload()).copyHeaders(failedMessage.getHeaders())
                .setHeader(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, workflowContext).build();
        log.error("Failed message is transformed into main for flowId={}",
                Optional.ofNullable(workflowContext).map(WorkflowContext::getFlowId).orElse(null));

        return message;
    }

    private boolean evaluateFailSafe(final WorkflowRoutingSlip.Route route, EvaluationContext context) {
        if (StringUtils.isNotBlank(route.getFailSafeExpression())) {
            try {
                SpelExpressionParser parser = new SpelExpressionParser();
                Boolean result = parser.parseExpression(route.getFailSafeExpression()).getValue(context, Boolean.class);
                if (Objects.nonNull(result)) {
                    log.info("FailSafeExpression={} for Route={} and count={} evaluate to {}",
                            route.getFailSafeExpression(), route.getFailSafeExpression(), route.getRequestChannel(),
                            route.getCount().get(), result);
                    return result;
                } else {
                    log.info("FailSafeExpression={} for Route={} with index={} and count={} evaluate to null",
                            route.getFailSafeExpression(), route.getRequestChannel(), route.getCount().get());
                }
            } catch (ParseException ex) {
                log.error(
                        "Error occurred while evaluating failSafeExpression={} for Route={} and count={} failed with "
                                + "error={}",
                        route.getFailSafeExpression(), route.getRequestChannel(), route.getCount().get(),
                        ex.getMessage());
            }
        }
        return false;
    }
}
