package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum Ownership {
    APPLICANT_ONE,
    APPLICANT_TWO,
    JOINT
}
