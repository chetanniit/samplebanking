package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum MortgageAdvisedType {
    ADVICE, REJECTED_ADVICE_EXECUTION_ONLY
}


