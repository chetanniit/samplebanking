package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum ProductTerm {
    TWO_YEAR("TWO_YEAR"),
    FIVE_YEAR("FIVE_YEAR");

    private String value;

    ProductTerm(String pValue) {
        this.value = pValue;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
