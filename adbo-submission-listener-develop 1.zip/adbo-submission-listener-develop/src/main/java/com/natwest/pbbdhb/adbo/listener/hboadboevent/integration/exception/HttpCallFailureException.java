package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.HttpErrorResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.http.HttpStatus;

@Data
@EqualsAndHashCode(callSuper = false)
public class HttpCallFailureException extends RuntimeException {
    private HttpStatus status;
    private HttpErrorResponse errorResponse;

    public HttpCallFailureException(Throwable cause) {
        super(cause);
    }

    public HttpCallFailureException(Throwable cause, HttpStatus pStatus, HttpErrorResponse pErrorResponse) {
        this(cause);
        this.status = pStatus;
        this.errorResponse = pErrorResponse;
    }
}
