package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.toolkit.CreateToolkitNotesRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.FIELD)
public abstract class CreateToolkitNotesRequestMapper
        implements WorkflowMapper<WorkflowContext, CreateToolkitNotesRequest>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    @Override
    public CreateToolkitNotesRequest map(WorkflowContext workflowContext) {
        return mapToCreateToolkitNotesRequest(workflowContext);
    }

    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target = "decisionUniqueId", source = "source", qualifiedByName = "getDecisionUniqueId")
    @Mapping(target = "gmsRefNo", source = "source", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "source", constant = "ADBO")
    abstract CreateToolkitNotesRequest mapToCreateToolkitNotesRequest(WorkflowContext source);

    @Named("getDecisionUniqueId")
    String getDecisionUniqueId(WorkflowContext workflowContext) {
        return ADBOWorkflowUtils.getHardScoreDecision(workflowContext).getDecisionUniqueId();
    }

}
