package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck.GMSProductFee;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck.ProductValidateRequest;
import com.natwest.pbbdhb.openapi.Application;
import com.natwest.pbbdhb.openapi.ProductDetails;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;

@Mapper(componentModel = "spring")
public interface ProductCheckRequestMapper extends WorkflowMapper<WorkflowContext, ProductValidateRequest>, BaseMapper {
    String APPLICATION_TYPE = "RESIDENTIAL";
    String CUSTOMER_TYPE = "EXISTING_CUSTOMER";
    String MORTGAGE_TYPE = "ADBO";

    @Override
    default ProductValidateRequest map(WorkflowContext source) {
        Application application =
                (Application) source.getOriginalPayload();
        return mapToProductValidateRequest(
                application.getBorrowingDetails().getProducts().stream().findFirst().get(),
                application);
    }

    default ProductValidateRequest mapToProductValidateRequest(ProductDetails product, Application application) {
        return ProductValidateRequest.builder()
                .productCode(product.getProductCode())
                .productSearchDate(toLocalDate(product.getProductSelectionDate())
                        .format(DateTimeFormatter.ofPattern("dd-MM-yyyy")))
                .mortgageType(MORTGAGE_TYPE)
                .productType(product.getProductType().getValue())
                .repaymentType(application.getBorrowingDetails().getRepaymentType().getValue())
                .customerType(CUSTOMER_TYPE)
                .applicationType(APPLICATION_TYPE)
                .productTerm(product.getProductTerm().getValue())
                .ltv(nonNull(product.getLtv()) ? BigDecimal.valueOf(product.getLtv()) : null)
                .fees(CollectionUtils.isNotEmpty(product.getFees())
                        ? product.getFees()
                        .stream()
                        .map(f -> GMSProductFee.builder().code(f.getCode()).build())
                        .collect(Collectors.toList())
                        : null)
                .mortgageAmount(application.getBorrowingDetails().getAdditionalBorrowings().stream()
                        .map(aB -> aB.getAmount())
                        .reduce(BigDecimal.ZERO, BigDecimal::add))
                .propertyValue(Optional.ofNullable(
                                application.getExistingMortgage().getMortgageProperty().getEstimatedValueByCustomer()).
                        orElse(application.getExistingMortgage().getMortgageProperty().getEstimatedValueByHPI()))
                .build();
    }
}
