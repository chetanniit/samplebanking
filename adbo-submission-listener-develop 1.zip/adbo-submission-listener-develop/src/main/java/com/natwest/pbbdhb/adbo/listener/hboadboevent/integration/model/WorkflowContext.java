package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkflowContext implements Serializable {
    private static final long serialVersionUID = 1L;
    private transient Object originalPayload;
    private transient Map<String, Object> originalHeaders;
    private Map<Integer, WorkflowRoutingSlip.Route> routingSlip;
    private transient Map<String, Map<Integer, Object>> requestMap;
    private transient Map<String, Map<Integer, Object>> responseMap;
    private transient String flowId;
    private transient Integer currentAttempt;

    public WorkflowRoutingSlip.Route getRouteByIndex(Integer index) {
        return this.getRoutingSlip().get(index);
    }

    public WorkflowContext populateRequestMap(String key, Integer index, Object request) {
        if (Objects.isNull(this.getRequestMap())) {
            this.requestMap = new HashMap<>();
        }
        if (!this.getRequestMap().containsKey(key)) {
            this.getRequestMap().put(key, new HashMap<>());
        }
        this.getRequestMap().get(key)
                .put(this.getRouteByIndex(index).getCount().get(), BaseRequest.builder().request(request).build());
        return this;
    }

    public WorkflowContext populateResponseStatus(Integer index, HttpStatus status) {
        WorkflowRoutingSlip.Route route = this.getRouteByIndex(index);
        route.getHttpStatus().put(route.getCount().get(), status);
        return this;
    }

    public Integer findFailedRouteIndex() {
        return Optional.ofNullable(findFailedRouteEntry()).filter(Objects::nonNull).map(Map.Entry::getKey).orElse(null);
    }

    public WorkflowContext populateResponseMap(String key, Integer index, Object response) {
        if (Objects.isNull(this.getResponseMap())) {
            this.responseMap = new HashMap<>();
        }
        if (!this.getResponseMap().containsKey(key)) {
            this.getResponseMap().put(key, new HashMap<>());
        }

        BaseResponse baseResponse = BaseResponse.builder()
                .response(response)
                .receiveTimestamp(HttpCallTimestampCaptor.getReceiveTimestamp())
                .build();
        this.getResponseMap().get(key).put(this.getRouteByIndex(index).getCount().get(), baseResponse);
        return this;
    }


    private Map.Entry<Integer, WorkflowRoutingSlip.Route> findFailedRouteEntry() {
        return Optional.ofNullable(this.getRoutingSlip()).get().entrySet().stream()
                .filter(routeEntry -> !routeEntry.getValue().getErrorResponse().isEmpty())
                .filter(routeEntry -> !isRouteFailSafe(routeEntry.getKey()))
                .findFirst()
                .orElse(null);
    }

    public WorkflowRoutingSlip.Route findFailedRoute() {
        return Optional.ofNullable(findFailedRouteEntry()).filter(Objects::nonNull).map(Map.Entry::getValue)
                .orElse(null);
    }


    public boolean isRouteFailSafe(Integer index) {
        WorkflowRoutingSlip.Route route = this.getRouteByIndex(index);
        return Optional.ofNullable(route.getFailSafeResult().get(Integer.valueOf(route.getCount().get())))
                .orElse(Boolean.FALSE);
    }

    public WorkflowContext populateOriginalPayload(Object pOriginalPayload) {
        this.setOriginalPayload(pOriginalPayload);
        return this;
    }

    public WorkflowContext setResponseMap(Map<String, Map<Integer, Object>> pResponseMap) {
        this.responseMap = pResponseMap;
        this.getRoutingSlip().entrySet().stream()
                .forEach(entry -> {
                    if (this.getResponseMap().containsKey(entry.getValue().getRequestChannel())) {
                        entry.getValue().setCount(new AtomicInteger(
                                this.getResponseMap().get(entry.getValue().getRequestChannel()).size()));
                    }
                });
        return this;
    }

    public WorkflowContext populateRequestTimestamp(String key, Integer index) {
        ((BaseRequest) this.getRequestMap().get(key).get(this.getRouteByIndex(index).getCount().get()))
                .setSendTimestamp(HttpCallTimestampCaptor.getSendTimestamp());
        return this;
    }

    public WorkflowContext setRoutingSlip(Map<Integer, WorkflowRoutingSlip.Route> pRoutingSlip) {
        this.routingSlip = pRoutingSlip;
        return this;
    }

    public WorkflowContext populateFlowId(String pFlowId) {
        this.setFlowId(pFlowId);
        return this;
    }

    public WorkflowContext resetFailedRoute() {
        WorkflowRoutingSlip.Route failedRoute = this.findFailedRoute();
        if (Objects.nonNull(failedRoute)) {
            final Integer count = failedRoute.getCount().get();
            failedRoute.getFailSafeResult().remove(count);
            failedRoute.getHttpStatus().remove(count);
            failedRoute.getErrorResponse().remove(count);
            failedRoute.getCount().decrementAndGet();
        }
        return this;
    }
}
