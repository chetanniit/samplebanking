package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.update.transactdetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateApplicationTransactDetailsRequest {
    private String userId;
    private String mortgage;
    private String applSeq;
    private TransactDetails transactDetails;
}
