package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CountrySelectionConstraint;
import com.natwest.pbbdhb.openapi.Application;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;

public class CountrySelectionValidator implements ConstraintValidator<CountrySelectionConstraint, Application> {


    @Override
    public boolean isValid(Application application, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(application) || isNull(application.getScottishApplication()) || isNull(
                application.getNorthernIrelandApplication()) || !(application.getScottishApplication() && application
                .getNorthernIrelandApplication());
    }


}
