package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerExpenditure {
    private String expenditureType;
    private BigDecimal amount;
    private String frequency;
    private UpdateCustomerRecipientDetails recipientDetails;
}
