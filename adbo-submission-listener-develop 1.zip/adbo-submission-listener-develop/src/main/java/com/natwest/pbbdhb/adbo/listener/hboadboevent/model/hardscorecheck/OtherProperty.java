package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.Ownership;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.OwnershipType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.RepaymentType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.Usage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OtherProperty {

    private BigDecimal interestOnlyAmount;
    private BigDecimal monthlyMortgagePayment;
    private BigDecimal outstandingMortgageBalance;
    private Integer remainingMortgageTermMonths;
    private Integer remainingMortgageTermYears;
    private BigDecimal monthlyRentalIncome;
    private Boolean propertyRedemption;
    private RepaymentType mortgageRepaymentType;
    private Usage propertyUsage;
    private Ownership ownership;
    private OwnershipType ownershipType;

}
