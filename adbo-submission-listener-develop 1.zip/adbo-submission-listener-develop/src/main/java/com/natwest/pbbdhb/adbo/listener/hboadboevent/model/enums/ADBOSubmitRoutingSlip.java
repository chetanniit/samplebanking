package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
@AllArgsConstructor
public enum ADBOSubmitRoutingSlip {
    HARD_SCORE_CHECK(1, "hardScoreCheck"),
    UPDATE_CORE_CUSTOMER(2, "updateCoreCustomer"),
    UPDATE_GMS_CUSTOMER(3, "updateGMSCustomer"),
    SUBMIT_FURTHER_ADVANCE(4, "submitFurtherAdvance"),
    AUTO_PROCESS(5, "autoProcess"),
    GET_MORTGAGE_APPLICATION_DETAILS(6, "getMortgageApplicationDetails"),
    TRIGGER_HUNTER_CHECKS(7, "triggerHunterChecks"),
    OPEN_PRE_SCREEN_TASK(8, "openPreScreeningTask"),
    CLOSE_PRE_SCREEN_TASK(9, "closePreScreeningTask"),
    UPDATE_DEEDS_HELD_AND_NI_IND(10, "updateDeedsHeldAndNIIndicator"),
    UPDATE_TRANSACT_DETAILS(11, "updateTransactDetails"),
    GET_MORTGAGE_DETAILS_FOR_GENERAL_NOTES(12, "getMortgageDetailsForGeneralNotes"),
    ADD_TRANSACT_NOTES(13, "addTransactNotes"),
    CREATE_AUTOMATED_WORKFLOW_TASK(14, "createAutomatedWorkflowTask"),
    CREATE_GET_MTG_OPS_CASE_OWNER_TASK(15, "createGetMtgOpsCaseOwnerTask"),
    CREATE_CASE_OWNER_UPDATE_TASK(16, "createCaseOwnerUpdateTask"),
    CREATE_R71_TASK(17, "createR71Task"),
    CREATE_MANUAL_VAL_INSTRUCTION_TASK(18, "createManualValInstructionTask"),
    CLOSE_GET_MTG_OPS_CASE_OWNER_TASK(19, "closeGetMtgOpsCaseOwnerTask"),
    CLOSE_CASE_OWNER_UPDATE_TASK(20, "closeCaseOwnerUpdateTask"),
    CREATE_AWAIT_FEES_TASK(21, "createAwaitFeesTask"),
    ADD_TOOLKIT_NOTES(22, "addToolkitNotes"),
    ADD_PROOF_OF_ID_NOTES(23, "addProofOfIdNotes"),
    CREATE_KYC_CHECKS_TASK(24, "createKycChecksTask"),
    CLOSE_KYC_CHECKS_TASK(25, "closeKycChecksTask"),
    CREATESWITCHER_TASK(26, "createSwitcherTask"),
    CREATEDIARYEVENT_TASK(27, "createDiaryEventTask");

    private static final Map<String, ADBOSubmitRoutingSlip> BY_REQUEST_CHANNEL =
            Stream.of(ADBOSubmitRoutingSlip.values())
                    .collect(Collectors.toMap(ADBOSubmitRoutingSlip::getRequestChannel, Function.identity()));

    private final int index;
    private final String requestChannel;

    public static ADBOSubmitRoutingSlip valueOfRequestChannel(String requestChannel) {
        return BY_REQUEST_CHANNEL.get(requestChannel);
    }

}
