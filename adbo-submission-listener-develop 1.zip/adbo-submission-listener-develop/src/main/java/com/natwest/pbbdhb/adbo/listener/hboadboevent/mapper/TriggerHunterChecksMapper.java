package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.triggerhunter.TriggerHunterRequest;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class TriggerHunterChecksMapper
        implements WorkflowMapper<WorkflowContext, TriggerHunterRequest>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    @Override
    public TriggerHunterRequest map(WorkflowContext workflowContext) {
        return mapToHunterRequest(workflowContext);
    }

    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target = "mortgage", source = "workflowContext", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "applSeq", source = "workflowContext", qualifiedByName = "getApplicationSequenceNumber")
    abstract TriggerHunterRequest mapToHunterRequest(WorkflowContext workflowContext);
}
