package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum WorkStatus {
    WORKING, NOT_WORKING
}
