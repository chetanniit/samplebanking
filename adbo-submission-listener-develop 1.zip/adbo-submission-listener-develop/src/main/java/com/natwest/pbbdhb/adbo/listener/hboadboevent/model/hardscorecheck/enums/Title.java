package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum Title {
    NONE, MR, MRS, MISS, MS, DR, REVEREND, PROFESSOR, SIR, LORD, LADY, CAPTAIN, MAJOR, COLONEL, GENERAL, MASTER, HON,
    MX, SISTER, VISCOUNT, COUNTESS, EARL, OTHER
}
