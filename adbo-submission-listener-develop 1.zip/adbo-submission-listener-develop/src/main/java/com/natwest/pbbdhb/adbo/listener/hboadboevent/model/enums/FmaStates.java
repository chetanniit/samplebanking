package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.HardScoreApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck.ProductValidateResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer.UpdateCoreCustomerResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum FmaStates {
    VALIDATE_PRODUCT("validateProduct", ProductValidateResponse.class),
    HARD_SCORE_CHECK("hardScoreCheck", HardScoreApplicationResponse.class),
    UPDATE_CORE_CUSTOMER("updateCoreCustomer",UpdateCoreCustomerResponse .class);

    private final String applicationSubType;
    private final Class responseType;

    public static FmaStates getByApplicationSubType(String applicationSubType) {
        return Arrays.stream(FmaStates.values()).filter(fs -> applicationSubType.equals(fs.applicationSubType))
                .findFirst().orElse(null);
    }

}
