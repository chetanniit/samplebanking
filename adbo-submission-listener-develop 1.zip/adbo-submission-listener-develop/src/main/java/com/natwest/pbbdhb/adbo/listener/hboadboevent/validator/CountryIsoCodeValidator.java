package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.CountryIsoCodeConstraint;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Locale;

import static java.util.Arrays.binarySearch;
import static java.util.Objects.isNull;

public class CountryIsoCodeValidator implements ConstraintValidator<CountryIsoCodeConstraint, String> {
    @Override
    public boolean isValid(String countryIsoCode, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(countryIsoCode) || countryIsoCode.length() < 2 || isValidCountryCode(countryIsoCode);
    }

    private boolean isValidCountryCode(String countryCode) {
        return binarySearch(Locale.getISOCountries(), countryCode) >= 0;
    }

}
