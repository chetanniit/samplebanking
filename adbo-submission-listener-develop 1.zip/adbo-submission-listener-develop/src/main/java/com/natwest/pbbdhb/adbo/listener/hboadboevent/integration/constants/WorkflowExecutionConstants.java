package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants;

@SuppressWarnings("checkstyle:interfaceistype")
public interface WorkflowExecutionConstants {
    String EXPECTED_HTTP_RESPONSE_HEADERS = "X-*, HTTP_RESPONSE_HEADERS";
    String WORKFLOW_CONTEXT_HEADER = "workflowContext";
    String ROUTING_SLIP_INDEX_HEADER = "routingSlipIndex";
    String HTTP_STATUS_CODE_HEADER = "http_statusCode";
    String BRAND_HEADER = "brand";
    String USER_ID_HEADER = "userId";
    String CASE_REF_HEADER = "caseReferenceId";
    String FLOW_ID_HEADER = "flowId";
    String FLOW_ID_PARAM = "flowId";
    String RETRY_COUNT_HEADER = "retryCount";
    String RETRY_TIMESTAMP_HEADER = "retryTimestamp";

    String WORKFLOW_INITIALIZE_INPUT = "workflowInitialize.input";
    String HTTP_CALL_FAILURE_EXCEPTION_INPUT = "httpCallFailureException.input";
    String RESOURCE_ACCESS_EXCEPTION_INPUT = "resourceAccessException.input";
    String MESSAGE_HANDLING_EXCEPTION_INPUT = "messageHandlingException.input";
    String ERROR_MESSAGE_EXCEPTION_TYPE_ROUTER_DEFAULT_OUTPUT_INPUT =
            "errorMessageExceptionTypeRouterDefaultOutput.input";
    String RESOLVE_FAIL_SAFE_INPUT = "resolveFailSafe.input";
    String EXECUTE_WORKFLOW_ROUTE_STRATEGY_INPUT = "executeWorkflowRouteStrategy.input";
    String WORKFLOW_EXECUTION_OUTPUT_INPUT = "workflowExecutionOutput.input";
    String TRANSFORM_RETRY_POLICY_EXPRESSION_FAILURE_INPUT = "handleRetryPolicyExpressionFailure.input";
    String WORKFLOW_EXECUTION_ERROR_INPUT = "workflowExecutionError";
    String RETRIEVE_APPLICATION_STATE_INPUT = "retrieveApplication.input";
    String CREATE_APPLICATION_INPUT = "createApplication.input";
    String UPDATE_APPLICATION_INPUT = "updateApplication.input";
    String CREATE_APPLICATION_STATE_INPUT = "createApplicationState.input";
    String CREATE_STATE_ERROR_INPUT = "handleCreateStateError.input";
    String UPDATE_APPLICATION_ERROR_INPUT = "handleUpdateApplicationError.input";
    String CREATE_OR_RETRIEVE_APPLICATION_ERROR_INPUT = "handleCreateOrRetrieveApplicationError.input";
    String LOGGING_RESPONSE_INPUT = "loggingHttpResponse.input";

    String REST_TEMPLATE_LOGGING_CATEGORY = "org.springframework.web.client.RestTemplate";

    String RETRY_MAX_ATTEMPTS_QUERY_PARAM = "maxRetryCount";
    String IS_KAFKA_EVENT_SENT_QUERY_PARAM = "isKafkaEventSent";
    String IS_MOPS_EMAIL_SENT_QUERY_PARAM = "isMopsEmailSent";
    String RESPONSE_STATUS_QUERY_PARAM = "responseStatus";

}
