package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.IntendedRetirementAgeConstraint;
import com.natwest.pbbdhb.openapi.Applicant;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.STANDARD_DATE_PATTERN;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOUtils.toLocalDate;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang.StringUtils.isBlank;

public class IntendedRetirementAgeValidator implements ConstraintValidator<IntendedRetirementAgeConstraint, Applicant> {
    @Override
    public boolean isValid(Applicant applicant, ConstraintValidatorContext constraintValidatorContext) {

        final int minAge = 18;
        final int maxAge = 99;

        return isNull(applicant) || isNull(applicant.getWorkStatus()) || applicant.getWorkStatus()
                .equals(Applicant.WorkStatusEnum.NOT_WORKING) || isNull(applicant.getPersonalDetails()) || isBlank(
                applicant.getPersonalDetails().getDateOfBirth()) || !Pattern
                .matches(STANDARD_DATE_PATTERN, applicant.getPersonalDetails().getDateOfBirth()) || (
                       nonNull(applicant.getRetirementAge()) && (applicant.getRetirementAge() < minAge
                                                                         || applicant.getRetirementAge() > maxAge
                                                                         || applicant.getRetirementAge()
                                                                            >= Period.between(
                               toLocalDate(applicant.getPersonalDetails().getDateOfBirth(),
                                       DateTimeFormatter.ISO_LOCAL_DATE), LocalDate.now()).getYears()));
    }

}
