package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.Country;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CoreCustomerDetails {

    @Schema(name = "primaryNationalityRegistration",description = "primary nationality registration", example = "GB")
    private Country primaryNationalityRegistration;
}
