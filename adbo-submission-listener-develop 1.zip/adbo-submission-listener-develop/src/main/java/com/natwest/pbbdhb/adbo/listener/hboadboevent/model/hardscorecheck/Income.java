package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.IncomeFrequency;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.IncomeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Income {
    private IncomeType type;
    private IncomeFrequency frequency;
    private BigDecimal amount;

}
