package com.natwest.pbbdhb.adbo.listener.hboadboevent.mapper;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.update.transactdetails.TransactDetails;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission.update.transactdetails.UpdateApplicationTransactDetailsRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ADBOSubmitRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.HardScoreApplicationResponse;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.Message;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.ADBOWorkflowUtils;
import lombok.Getter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static java.util.Objects.nonNull;

@Getter
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR)
public abstract class UpdateTransactDetailsRequestMapper
        implements WorkflowMapper<WorkflowContext, UpdateApplicationTransactDetailsRequest>, BaseMapper {

    @Autowired
    @SuppressWarnings("checkstyle:visibilitymodifier")
    protected PropertiesConfig config;

    public UpdateApplicationTransactDetailsRequest map(WorkflowContext workflowContext) {
        return mapToTransactDetailsRequest(workflowContext);
    }

    @Mapping(target = "userId", expression = "java(config.getXoUserid())")
    @Mapping(target = "mortgage", source = "workflowContext", qualifiedByName = "getMortgageNumber")
    @Mapping(target = "applSeq", source = "workflowContext", qualifiedByName = "getApplicationSequenceNumber")
    @Mapping(target = "transactDetails", source = "workflowContext", qualifiedByName = "mapToTransactDetails")
    abstract UpdateApplicationTransactDetailsRequest mapToTransactDetailsRequest(WorkflowContext workflowContext);

    @Named("mapToTransactDetails")
    public TransactDetails mapToTransactDetails(WorkflowContext source) {
        return mapToTransactDetails(
                Optional.ofNullable(ADBOWorkflowUtils.getHardScoreApplicationResponse(source)).get().orElse(null),
                ADBOWorkflowUtils
                        .getBaseResponsesTimestamp(source, ADBOSubmitRoutingSlip.HARD_SCORE_CHECK.getRequestChannel()));
    }

    @Mapping(target = "aipReferenceNumber", source = "hardscoreResponse.decisionUniqueId")
    @Mapping(target = "decision", constant = "REFER")
    @Mapping(target = "decisionDate", source = "hardscoreResponseTimestamp", qualifiedByName = "mapDecisionDate")
    @Mapping(target = "resultFromTransact", source = "hardscoreResponse.decision")
    @Mapping(target = "referrals", source = "hardscoreResponse", qualifiedByName = "mapReferrals")
    @Mapping(target = "additionalInfo", ignore = true)
    abstract TransactDetails mapToTransactDetails(HardScoreApplicationResponse hardscoreResponse,
                                                  LocalDateTime hardscoreResponseTimestamp);

    @Named("mapReferrals")
    public String mapReferrals(HardScoreApplicationResponse hardscoreResponse) {
        StringBuilder referrals = new StringBuilder("[" + hardscoreResponse.getPodDecision() + "]");
        if (nonNull(hardscoreResponse.getKycMessages())) {
            for (Message kycMessage : hardscoreResponse.getKycMessages()) {
                referrals.append(kycMessage.getMessage());
            }
        }
        return referrals.toString();
    }

    @Named("mapDecisionDate")
    public LocalDate mapDecisionDate(LocalDateTime responseDateTime) {
        return config.isUseHardcodedDecisionDate()
                ? toLocalDate(config.getHardcodedDecisionDate())
                : responseDateTime.toLocalDate();
    }
}
