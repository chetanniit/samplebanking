package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerDefaultedOnCreditAccountsDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    private String answer;
    private Integer noOfCreditAccounts;
    private Integer noOfCreditDefaults;
    private Integer noOfMonthsArrears6Months;
    private Integer noOfMonthsArrears12Months;
    private Integer noOfMonthsArrears24Months;
    private BigDecimal totValCreditAccounts;
    private BigDecimal totMonthlyPaymentCreditAccounts;
    private String ivAs;
    private String ivAsCleared;
    private LocalDate latestIVAStartDate;
    private String hasDebtReliefOrders;
    private String debtReliefOrdersCleared;
    private LocalDate debtReliefOrdersStartDate;
    private String note;

    // named to match the GMS XML class so that MapStruct will generate the mapping
    public String getIVAs() {
        return ivAs;
    }

    public void setIVAs(final String inIvAs) {
        this.ivAs = inIvAs;
    }

    public String getIVAsCleared() {
        return ivAsCleared;
    }

    public void setIVAsCleared(final String inIvAsCleared) {
        this.ivAsCleared = inIvAsCleared;
    }
}
