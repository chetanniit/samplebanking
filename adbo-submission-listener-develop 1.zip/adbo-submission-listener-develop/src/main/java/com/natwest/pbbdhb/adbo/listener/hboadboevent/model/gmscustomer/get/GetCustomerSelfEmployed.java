package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class GetCustomerSelfEmployed implements Serializable {
    private static final long serialVersionUID = 1L;

    private String currentOrPrevious;
    private String companyName;
    private GetCustomerAddress companyAddress;
    private String natureOfBusiness;
    private Integer yearsEstablished;
    private Integer monthsEstablished;
    private String telephoneNumber;
    private String deliveryPreference;
    private String faxNumber;
    private String emailAddress;
    private String profitYear1;
    private String profitYear2;
    private String profitYear3;
    private BigDecimal profitAmount1;
    private BigDecimal profitAmount2;
    private BigDecimal profitAmount3;
    private GetCustomerIncomeDetails incomeDetails;
    private GetCustomerAccountantDetails accountantDetails;
    private Integer yearsOfAccounts;
    private String employmentStatus;
}
