package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Errors implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<java.lang.Error> error;
}
