package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.expression.ParseException;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

@Slf4j
public class SpelUtils {

    public static <T> T evaluate(final Object rootObject, final String expression, final Class<T> expectedType) {
        try {
            return new SpelExpressionParser().parseExpression(expression)
                    .getValue(new StandardEvaluationContext(rootObject), expectedType);
        } catch (ParseException ex) {
            log.error("{} Error evaluating expression={}", ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, expression,
                    ex);
            return expectedType.isInstance(Boolean.class) ? (T) Boolean.FALSE : null;
        }
    }
}
