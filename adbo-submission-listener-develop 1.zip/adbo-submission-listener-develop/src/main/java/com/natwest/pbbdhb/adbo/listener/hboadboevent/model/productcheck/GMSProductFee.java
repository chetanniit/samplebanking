package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.productcheck;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class GMSProductFee implements Serializable {
    private static final long serialVersionUID = 1L;
    private String code;
    private String type;
    private Double amount;
}
