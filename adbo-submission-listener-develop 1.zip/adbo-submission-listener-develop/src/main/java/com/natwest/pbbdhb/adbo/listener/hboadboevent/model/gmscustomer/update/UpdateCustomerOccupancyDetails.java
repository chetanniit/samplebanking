package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.CustomerAddress;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCustomerOccupancyDetails {
    private String occupancyType;
    private CustomerAddress clientAddress;
    private Integer yearsAtAddress;
    private Integer monthsAtAddress;
    private LocalDate addressEntryDate;
    private BigDecimal originalPurchasePrice;
    private LocalDate purchaseDate;
    private BigDecimal currentValue;
    private UpdateCustomerLenderDetails lenderDetails;
    private UpdateCustomerLandlordDetails landlordDetails;
}
