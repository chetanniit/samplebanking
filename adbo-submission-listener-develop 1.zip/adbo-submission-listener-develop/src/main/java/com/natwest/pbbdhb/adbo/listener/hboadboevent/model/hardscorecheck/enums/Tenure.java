package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum Tenure {
    FREEHOLD, LEASEHOLD, FEUHOLD
}
