package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import java.time.LocalDate;
import lombok.Data;

@Data
public class GetCustomerSupplementaryDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    private String countryOfResidence;
    private Integer noOfMonthsResidentInUK;
    private String maidenName;
    private LocalDate dateMaidenNameChanged;
    private String movingIntoPropertyAtCompletion;
    private String holdsInvestmentAccount;
    private String interestOrShareInPropertyOtherThanCurrentDwelling;
    private String existingCustomerWithMortgage;
    private String existingSocietyMember;
    private String existingAccountNumber;
    private String deliveryPreference;
    private String faxNumber;
    private Integer numberOfDependants;
    private LocalDate retirementDate;
}
