package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ContactMedium;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.ContactPreferenceRequestType;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums.PreferredTelephoneType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CoreCustomerContact {

    @Length(max = 20, message = "Allows max 20 characters")
    @Schema(example = "+123455555", description = "Allows max 20 characters")
    private String residencePhoneNumber;

    @Length(max = 20, message = "Allows max 20 characters")
    @Schema(example = "+123456666", description = "Allows max 20 characters")
    private String mobileNumber;

    @Length(max = 20, message = "Allows max 20 characters")
    @Schema(example = "+123456789", description = "Allows max 20 characters")
    private String businessPhoneNumber;

    @Length(max = 50, message = "Allows max 50 characters")
    @Schema(example = "test@test.com", description = "Validated against RFC 822 standards. Allows max 50 characters")
    private String email;

    @Schema(example = "MOBILE")
    private PreferredTelephoneType preferredTelephoneType;

    @Schema(example = "PERSONALCUSTOMERPREFERENCES")
    private ContactPreferenceRequestType requestContentType;

    @Schema
    private List<ContactMedium> allowedMediums;

    @Schema
    private List<ContactMedium> disallowedMediums;

}
