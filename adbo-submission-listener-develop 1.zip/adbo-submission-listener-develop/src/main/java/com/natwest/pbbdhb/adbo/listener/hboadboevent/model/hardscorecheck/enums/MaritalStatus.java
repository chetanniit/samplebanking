package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums;

public enum MaritalStatus {
    DIVORCED, MARRIED, SEPARATED, SINGLE, ENGAGED, WIDOWED, LIVING_WITH_PARTNER, CIVIL_PARTNERSHIP,
    SURVIVING_CIVIL_PARTNER
}
