package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.state;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.state.CreateApplicationRequest;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.SpelUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.PropertiesConfig;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.SpelEvaluationException;
import org.springframework.messaging.Message;

import java.util.Objects;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
@Slf4j
public abstract class CreateApplicationRequestMapper implements WorkflowMapper<Message<?>, CreateApplicationRequest> {

    @Autowired
    private PropertiesConfig config;

    @Override
    public CreateApplicationRequest map(final Message<?> message) {
        return Objects.isNull(message) ? null : toCreateApplicationRequest(message);
    }

    @Mappings({@Mapping(target = "applicationType", expression = "java(getApplicationType())"),
            @Mapping(target = "channel", source = "message", qualifiedByName = "getChannel"),
            @Mapping(target = "refId", source = "message", qualifiedByName = "getRefId"),
            @Mapping(target = "refType", expression = "java(getRefType())"),
            @Mapping(target = "additionalRefId", source = "message", qualifiedByName = "getAdditionalRefId"),
            @Mapping(target = "request",
                    expression = "java((String) new org.springframework.integration.json.ObjectToJsonTransformer()"
                            + ".transform(message).getPayload())")})
    public abstract CreateApplicationRequest toCreateApplicationRequest(Message<?> message);

    @Named("getApplicationType")
    protected String getApplicationType() {
        return config.getApplicationType();
    }

    @Named("getChannel")
    protected String getChannel(final Message<?> message) {
        return SpelUtils.evaluate(message, config.getChannelExpression(), String.class);
    }

    @Named("getRefId")
    protected String getRefId(final Message<?> message) {
        try {
            return SpelUtils.evaluate(message, config.getRefIdExpression(), String.class);
        } catch (SpelEvaluationException ex) {
            log.error("{} Ref Id expression failed with error: {}", ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG,
                    ex.getMessage());
        }
        return null;
    }

    @Named("getRefType")
    protected String getRefType() {
        return config.getRefType();
    }

    @Named("getAdditionalRefId")
    protected String getAdditionalRefId(final Message<?> message) {
        try {
            return SpelUtils.evaluate(message, config.getAdditionalRefIdExpression(), String.class);
        } catch (SpelEvaluationException ex) {
            log.error("{} Additional Ref Id expression evaluation failed with error: {}",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, ex.getMessage());
        }
        return null;
    }
}
