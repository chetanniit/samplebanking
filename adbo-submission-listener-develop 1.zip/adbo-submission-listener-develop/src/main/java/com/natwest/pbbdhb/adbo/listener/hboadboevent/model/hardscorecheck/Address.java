package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck.enums.OccupyStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Address {
    private Boolean isCurrentAddress;
    private Boolean ukAddress;
    private String countryIsoCode;
    private OccupyStatus occupyStatus;
    private Integer startMonth;
    private Integer startYear;
    private Integer endMonth;
    private Integer endYear;
    private String flat;
    private String houseName;
    private String houseNumber;
    private String street;
    private String district;
    private String town;
    private String county;
    private String postcode;
}
