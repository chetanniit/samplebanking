package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.hardscorecheck;

public interface Response {

    String getErrorCode();
}
