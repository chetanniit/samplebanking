package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.get;

import java.io.Serializable;
import lombok.Data;

@Data
public class GetCustomerCorrespondenceAddress implements Serializable {
    private static final long serialVersionUID = 1L;

    private GetCustomerAddress clientAddress;
    private String sameAsCurrent;
}
