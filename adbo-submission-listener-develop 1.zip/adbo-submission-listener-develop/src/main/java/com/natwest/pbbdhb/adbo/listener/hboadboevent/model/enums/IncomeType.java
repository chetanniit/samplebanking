package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

/**
 * Valid incometypes from "Validation A income type code".
 */
public enum IncomeType {
    INV, ATA, IIB, BAE, HOA, GSA, BAS, WFT, CAE, CAS, PEE, PES, RIE, RIS, DAE, DAS, RIO, RIB, BON, GOT, ROB, COE, DVE,
    DVS, OTE, OTS
}
