package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
public class BaseResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    private Object response;
    private LocalDateTime receiveTimestamp;
}
