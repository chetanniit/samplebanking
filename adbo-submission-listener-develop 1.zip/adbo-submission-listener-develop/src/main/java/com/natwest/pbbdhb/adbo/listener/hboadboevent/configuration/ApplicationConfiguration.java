package com.natwest.pbbdhb.adbo.listener.hboadboevent.configuration;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.util.Properties;

@Configuration
public class ApplicationConfiguration {

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate iamJwtChainSecureRestTemplate;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${iam.jwt.secure.rest.template}")
    private Boolean isIamJwtSecureRestTemplate;

    @Bean
    @Qualifier("resolvedRestTemplate")
    public RestTemplate resolvedRestTemplate() {
        return isIamJwtSecureRestTemplate ? iamJwtChainSecureRestTemplate : restTemplate;
    }

    @Bean
    public VelocityEngine velocityEngine() {
        Properties properties = new Properties();
        properties.setProperty("resource.default_encoding", "UTF-8");
        properties.setProperty("resource.loaders", "class");
        properties.setProperty("resource.loader.class.class",
                "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        VelocityEngine velocityEngine = new VelocityEngine(properties);
        return velocityEngine;
    }
}
