package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.getapplicationdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Error implements Serializable {
    private static final long serialVersionUID = 1L;
    private String timestamp;
    private String message;
    private String code;
    private String diagnostic;

}
