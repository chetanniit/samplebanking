package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.gmscustomer.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Dependant {
    private String name;
    private LocalDate dateOfBirth;
    private Integer age;
    private String relationship;
}
