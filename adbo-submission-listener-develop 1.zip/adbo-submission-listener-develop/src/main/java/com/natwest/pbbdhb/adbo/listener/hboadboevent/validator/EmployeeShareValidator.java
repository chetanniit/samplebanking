package com.natwest.pbbdhb.adbo.listener.hboadboevent.validator;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.validator.constraint.EmployeeShareConstraint;
import com.natwest.pbbdhb.openapi.SelfEmployed;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class EmployeeShareValidator implements ConstraintValidator<EmployeeShareConstraint, SelfEmployed> {
    @Override
    public boolean isValid(SelfEmployed selfEmployed, ConstraintValidatorContext constraintValidatorContext) {
        return isNull(selfEmployed) || !Boolean.TRUE.equals(selfEmployed.getOwnShare()) || nonNull(
                selfEmployed.getEmployeeShare());
    }
}
