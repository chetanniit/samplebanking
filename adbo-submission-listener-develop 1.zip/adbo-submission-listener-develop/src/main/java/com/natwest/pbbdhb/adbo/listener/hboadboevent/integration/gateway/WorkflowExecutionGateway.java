package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.gateway;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.WorkflowExecutionFailureException;

import java.util.Map;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.WORKFLOW_EXECUTION_ERROR_INPUT;
import static com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants.WORKFLOW_INITIALIZE_INPUT;

@MessagingGateway(defaultRequestChannel = WORKFLOW_INITIALIZE_INPUT, errorChannel = WORKFLOW_EXECUTION_ERROR_INPUT)
public interface WorkflowExecutionGateway {
    Object process(@Payload Object payload, @Headers Map<String, Object> headers) throws
            WorkflowExecutionFailureException;
}
