package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.adbosubmission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SolicitorDetails {
    @Valid
    private ApplicantSolicitor applicantSolicitor;
}
