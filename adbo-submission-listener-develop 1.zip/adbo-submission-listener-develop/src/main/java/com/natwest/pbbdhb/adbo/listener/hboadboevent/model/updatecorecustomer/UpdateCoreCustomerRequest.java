package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.updatecorecustomer;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCoreCustomerRequest {

    @Valid
    @Pattern(regexp = "\\d{10}", message = "customer identification number must be 10 digits and have numbers only")
    @Schema( description = "Allows max 10 digits")
    private String cin;

    @Schema(name = "customerDetails", description = "customers details", example = "{\n" +
            "  \"primaryNationalityRegistration\": \"GB\",\n" +
            "}")
    private CoreCustomerDetails customerDetails;

    @Schema(name = "customerContactDetails", description = "customers contact details and preferences", example = "{\n" +
            "  \"residencePhoneNumber\": \"+123455555\",\n" +
            "  \"mobileNumber\": \"+123456666\",\n" +
            "  \"businessPhoneNumber\": \"+123456789\",\n" +
            "  \"email\": \"test@test.com\",\n" +
            "  \"preferredTelephoneType\": \"MOBILE\",\n" +
            "  \"requestContentType\": \"PERSONALCUSTOMERPREFERENCES\",\n" +
            "  \"allowedMediums\": [\n" +
            "    \"Email\"\n" +
            "  ],\n" +
            "  \"disallowedMediums\": [\n" +
            "    \"Email\"\n" +
            "  ]\n" +
            "}")
    private CoreCustomerContact customerContactDetails;


}
