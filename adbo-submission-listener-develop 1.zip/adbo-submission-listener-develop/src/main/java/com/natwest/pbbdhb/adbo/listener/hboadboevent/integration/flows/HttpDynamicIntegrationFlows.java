package com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.flows;

import com.natwest.pbbdhb.adbo.listener.hboadboevent.constants.ApplicationConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.constants.WorkflowExecutionConstants;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.RetryPolicyExpressionFailedException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.exception.WorkflowExecutionFailureException;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.mapper.WorkflowMapper;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowContext;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.WorkflowRoutingSlip;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.model.enums.WorkflowExecutionMessage;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.integration.utils.SpelUtils;
import com.natwest.pbbdhb.adbo.listener.hboadboevent.utils.LoggerUtils;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aopalliance.aop.Advice;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.handler.advice.AbstractRequestHandlerAdvice;
import org.springframework.integration.handler.advice.ErrorMessageSendingRecoverer;
import org.springframework.integration.handler.advice.RequestHandlerRetryAdvice;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.http.dsl.HttpMessageHandlerSpec;
import org.springframework.integration.http.outbound.HttpRequestExecutingMessageHandler;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

@Configuration
@Component
@Slf4j
public class HttpDynamicIntegrationFlows {

    @Autowired
    @Qualifier("workflowExecutionError")
    private MessageChannel workflowExecutionErrorChannel;
    @Autowired
    @Qualifier("workflowExecutionRestTemplate")
    private RestTemplate restTemplate;
    @Autowired(required = false)
    @Qualifier("parameterizedTypeReferenceMap")
    private Map<String, ParameterizedTypeReference<?>> parameterizedTypeReferenceMap;
    @Autowired
    private ApplicationContext applicationContext;
    @Autowired
    private IntegrationFlowContext integrationFlowContext;
    @Autowired
    private WorkflowRoutingSlip workflowRoutingSlip;
    @Autowired
    @Qualifier("workflowExecutionLogHttpResponseTimeAdvice")
    private Advice responseTimeAdvice;
    @Autowired
    @Qualifier("workflowExecutionErrorHandlerAdvice")
    private Advice workflowExecutionErrorHandlerAdvice;

    @SuppressWarnings("unchecked")
    @PostConstruct
    public void init() {
        workflowRoutingSlip.getRoutingSlip().values().forEach(route -> {
            registerChannel(route);
            WorkflowMapper mapper = resolveRequestMapper(route);

            log.info("Initializing the integration flow for route={}", route.getRequestChannel());
            IntegrationFlow flow = IntegrationFlow.from(route.getRequestChannel())
                    .transform(Message.class, m -> Objects.isNull(mapper) ? m
                            : mapper.map(m.getHeaders()
                            .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)))
                    .transform(Transformers.toJson())
                    .enrichHeaders(hspec -> hspec.headerFunction(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                            m -> m.getHeaders()
                                    .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)
                                    .populateRequestMap(route.getRequestChannel(),
                                            m.getHeaders().get(
                                                            WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER,
                                                            AtomicInteger.class)
                                                    .get(), Objects.isNull(mapper) ? "{}" : m.getPayload()),
                            true))
                    .log(LoggingHandler.Level.INFO, log.getName(), m ->
                            org.apache.commons.lang3.StringUtils.prependIfMissing(String.format("Executing route '%s"
                                            + "'", route.getRequestChannel()),
                                    LoggerUtils.getLogMsgPrefix(m.getHeaders())))
                    .handle(httpRequestExecutingMessageHandler(route),
                            m -> m.advice(getAdvices(route).toArray(new Advice[0])))
                    .wireTap(WorkflowExecutionConstants.LOGGING_RESPONSE_INPUT)
                    .enrichHeaders(hspec -> hspec.headerFunction(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER,
                            m -> m.getHeaders()
                                    .get(WorkflowExecutionConstants.WORKFLOW_CONTEXT_HEADER, WorkflowContext.class)
                                    .populateRequestTimestamp(
                                            route.getRequestChannel(),
                                            m.getHeaders().get(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER,
                                                    AtomicInteger.class).get())
                                    .populateResponseStatus(
                                            m.getHeaders().get(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER,
                                                    AtomicInteger.class).get(),
                                            m.getHeaders().get(WorkflowExecutionConstants.HTTP_STATUS_CODE_HEADER,
                                                    HttpStatus.class))
                                    .populateResponseMap(route.getRequestChannel(),
                                            m.getHeaders().get(WorkflowExecutionConstants.ROUTING_SLIP_INDEX_HEADER,
                                                    AtomicInteger.class).get(),
                                            m.getPayload()), true))
                    .routeToRecipients(r -> r.applySequence(true)
                            .recipient(WorkflowExecutionConstants.CREATE_APPLICATION_STATE_INPUT)
                            .recipient(WorkflowExecutionConstants.EXECUTE_WORKFLOW_ROUTE_STRATEGY_INPUT))
                    .get();

            integrationFlowContext.registration(flow).id(route.getRequestChannel().concat("Flow")).register();
        });

        log.info("Registered the following integration flows={}", integrationFlowContext.getRegistry().values().stream()
                .map(e -> e.getIntegrationFlow().getInputChannel()).collect(Collectors.toList()));
    }

    @SneakyThrows
    private WorkflowMapper resolveRequestMapper(final WorkflowRoutingSlip.Route route) {
        return (WorkflowMapper) (StringUtils.isBlank(route.getHttpRequestMapperType()) ? null
                : applicationContext.getBean(Class.forName(route.getHttpRequestMapperType())));
    }

    private void registerChannel(final WorkflowRoutingSlip.Route route) {
        DirectChannel channel = new DirectChannel();
        channel.setBeanName(route.getRequestChannel());
        channel.setBeanFactory(applicationContext);
        ((ConfigurableApplicationContext) applicationContext).getBeanFactory()
                .registerSingleton(route.getRequestChannel(), channel);
        log.info("Registered the following Message Channels={}", Arrays.asList(channel.getFullChannelName()));
    }

    private HttpRequestExecutingMessageHandler httpRequestExecutingMessageHandler(
            final WorkflowRoutingSlip.Route route) {
        HttpMessageHandlerSpec messageHandlerSpec = Http.outboundGateway(route.getHttpUrl(), restTemplate)
                .httpMethod(HttpMethod.valueOf(route.getHttpMethod())).mappedRequestHeaders("*")
                .mappedResponseHeaders(WorkflowExecutionConstants.EXPECTED_HTTP_RESPONSE_HEADERS);

        try {
            messageHandlerSpec.expectedResponseType(Class.forName(route.getHttpExpectedResponseType()));
        } catch (ClassNotFoundException ex) {
            log.error("{} Error loading class={}: message={} and stackTrace={}",
                    ApplicationConstants.PREFIX_EXCEPTION_MSG_LOG, route.getHttpExpectedResponseType(),
                    ex.getMessage(), ex.getStackTrace());

            if (!CollectionUtils.isEmpty(parameterizedTypeReferenceMap) && parameterizedTypeReferenceMap
                    .containsKey(route.getHttpExpectedResponseType())) {
                messageHandlerSpec
                        .expectedResponseType(parameterizedTypeReferenceMap.get(route.getHttpExpectedResponseType()));
            } else {
                log.error(
                        "Could not retrieve instance of ParameterizedTypeReference from parameterizedTypeReferenceMap"
                                + " using={}. "
                                + "Make sure bean 'parameterizedTypeReferenceMap' is defined",
                        route.getHttpExpectedResponseType());
                throw new WorkflowExecutionFailureException(
                        WorkflowExecutionMessage.HTTP_REQUEST_EXECUTING_MESSAGE_HANDLER.getMessage(),
                        ex.getCause());
            }
        }

        // Setting the uriVariableExpressions post object creation.
        // Passing uriVariableExpressions in the above builder is not persisting after the object is created.
        Map<String, Expression> uriVariableExpressions = route.getHttpUriParameters().entrySet().stream()
                .map(e -> new AbstractMap.SimpleEntry<>(e.getKey(),
                        new SpelExpressionParser().parseExpression(e.getValue())))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        HttpRequestExecutingMessageHandler messageHandler = messageHandlerSpec.getObject();
        messageHandler.setUriVariableExpressions(uriVariableExpressions);

        return messageHandler;
    }

    private Advice requestHandlerRetryAdvice(final WorkflowRoutingSlip.Route route) {
        RequestHandlerRetryAdvice advice = new RequestHandlerRetryAdvice();

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(route.getRetryPolicyMaxAttempts());

        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(route.getRetryPolicyInitialInterval());
        backOffPolicy.setMaxInterval(route.getRetryPolicyMaxInterval());
        backOffPolicy.setMultiplier(route.getRetryPolicyMultiplier());

        RetryTemplate retryTemplate = new RetryTemplate();
        retryTemplate.setRetryPolicy(retryPolicy);
        retryTemplate.setBackOffPolicy(backOffPolicy);

        RecoveryCallback<Object> recoveryCallback = new ErrorMessageSendingRecoverer(workflowExecutionErrorChannel);

        advice.setRetryTemplate(retryTemplate);
        advice.setRecoveryCallback(recoveryCallback);

        return advice;
    }

    private List<Advice> getAdvices(final WorkflowRoutingSlip.Route route) {
        // Order of adding below advices into a List is very important from retry perspective. Do not change the
        // order unless necessary.
        List<Advice> advices = new ArrayList<>();
        advices.add(workflowExecutionErrorHandlerAdvice); // Order=2 or 4
        if (StringUtils.isNotBlank(route.getRetryPolicyExpression())) {
            advices.add(requestHandlerRetryAdvice(route)); // Order=3
            advices.add(new AbstractRequestHandlerAdvice() {
                @Override
                protected Object doInvoke(ExecutionCallback callback, Object target,
                                          Message<?> message) {
                    return evaluateRetryCondition(callback.execute(), route);
                }
            }); // Order=2
        }
        advices.add(responseTimeAdvice); // Order=1
        return advices;
    }

    private Object evaluateRetryCondition(Object result, final WorkflowRoutingSlip.Route route) {
        final Boolean evaluationResult = SpelUtils.evaluate(result, route.getRetryPolicyExpression(), Boolean.class);
        log.info("Retry policy expression of route '{}' evaluates to '{}'", route.getRequestChannel(),
                evaluationResult);
        if (evaluationResult) {
            throw new RetryPolicyExpressionFailedException(
                    String.format("Retry policy expression of route %s evaluates to 'false'",
                            route.getRequestChannel()));
        }
        return result;
    }

}
