package com.natwest.pbbdhb.adbo.listener.hboadboevent.model.enums;

/**
 * Valid incometypes from "SID_Customer Update.pdf".
 */
public enum IncomeFrequency {
    A,
    M,
    W
}

