# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.10.0
- PBBDHB-74007: Upgrade to Java 17

## 0.9.3
- PBBDHB-77728: [FMA/ADBO/CASE] - a new property/field to indicate running cost by family member

## 0.9.1
- PBBDHB-76682: ADBO Submit: ApplicantID to be passed 

## 0.9.0
- PBBDHB-72820: Make Field whenBuilt optional in ADBO Submit API

## 0.8.2
-PBBDHB-74130 ADBO-Diary event-Pricing by cohort

## 0.8.1
- PBBDHB-70854 Add Boolean Field: additionalBorrowingWithSwitch and if its TRUE- Open DAS task

## 0.8.0
- PBBDHB-72076: Disable Hunter related calls from Orchestration

## 0.7.1
- PBBDHB-68744: Add new endpoint to update core customer nationality

## 0.6.2 
- PBBDHB-70053: Add new kafka bootstrap servers for NFT/PROD

## 0.5.3
- PBBDHB-69901: [adbo-submission-listener]: Integrating the Splunk with Incident management

## 0.5.2
- PBBDHB-69056: remove middleNames max/min restriction and truncate to downstream calls
- PBBDHB-68517: ADBO- Two records getting generated in submission state db for the same case

## 0.5.1
- PBBDHB-69187: Need to stop sensitive data logging by ADBO submission listener component

## 0.5.0
- PBBDHB-67172: Add SelfEmployed dateEstablished validation
- PBBDHB-67918: Set up code quality checks
- PBBDHB-68747: Truncate Bank Account Name to 30 characters while sending to Hardscore

## 0.4.10
- PBBDHB-68418: ADBO - Contract Validation Error - MAF Document / MOPS email is NOT generating for Contract Validation Event

## 0.4.3
- PBBDHB-66265: ADBO - GMS having incorrect length of residence for the previous addresses
- PBBDHB-64355: ADBO - Default solicitorId for RBS Brand
- PBBDHB-65435: ADBO - Need to call update/Patch core customer to update email and mobile number within ADBO orchestration
- PBBDHB-63575: ADBO - DAY 2: Implement validations in ADBO
- PBBDHB-67088: ADBO - Update DWS and remove Consul

## 0.4.2
- PBBDHB-62990: ADBO - Add validator in credit cards block
- PBBDHB-65956: ADBO - Add Route field in Applicant level
- PBBDHB-65766: ADBO - API development to support GMS Sopra service to trigger Hunter 

## 0.2.0
- PBBDHB-65412: ADBO - CreditCard.TotalBalance minimum must be zero

## 0.1.2
- PBBDHB-64497: ADBO - Add 1 second Delay After FAU Task in ADBO-GMS orchestration
- PBBDHB-64161: ADBO - Changed mapping for CHILD_WORKING_TAX_CREDIT to GMS code WFT (Working Families Tax Credit)
- PBBDHB-64629: ADBO - Change GMS mapping for ADBO reason and hard score reason

## 0.1.1
- PBBDHB-64161: ADBO - Other Income Mapping to GMS
- PBBDHB-64477: ADBO - Submission Listener 'Retired'/'Unemployed' mapping to GMS
- PBBDHB-64436: ADBO - In case of previous address , hard score is triggered with previous address

## 0.1.0
- PBBDHB-63787: ADBO - Move the ADBO Post Submission Listener Orchestration calls to ADBO Submission Listener orchestration
- PBBDHB-63789: ADBO - Implement ADBO Submission Listener - Retry Mechanism for Moved Post submission orchestration calls
- PBBDHB-63801: ADBO - Make the ADBO Post Submission Listener Obsolete

## 0.0.16
- PBBDHB-63664: ADBO - error message need to be modified to correct the block name displayed in the error when unstructuredAddress is not provided along with address block also passed null

## 0.0.14
- PBBDHB-63709: ADBO - HPI used should be derived from the estimatedValueByCustomer while passing to Hardscore

## 0.0.13
- PBBDHB-63469: ADBO - a few of these error messages are missing the name of the field in the message.

## 0.0.12
- PBBDHB-63393: ADBO - for few of the occupationCode enums 'updateGMSCustomer' service call is failing as part of ADBO submission.

## 0.0.11
- PBBDHB-63179: ADBO - contract changes v1.8

## 0.0.10
- PBBDHB-62988: ADBO - No validation in ADBO submission listener for retirement age less than current age

## 0.0.9
- PBBDHB-62620: Contract changes

## 0.0.2, 0.0.3, 0.0.4, 0.0.5, 0.0.6, 0.0.7, 0.0.8
- PBBDHB-61526: Implement 1.5v Contract Changes in adbo-submission-listener and custom validators

## 0.0.1
- PBBDHB-56793: [ADBO]: Build L2 ADBO Submission Listener
