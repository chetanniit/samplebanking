# Project: ui-coord-broker-auth

## How to run

Compile the project with:

```
mvn compile
```

Ensure you have the latest pcf scripts:

```
git submodule update --init
```

To run the app locally, you can use the `local` profile:

```
mvn spring-boot:run -Dspring-boot.run.jvmArguments="-Dproxy.username=<username> -Dproxy.password=<password>"
```

Use your normal natwest username and password above - the UI Coordinator is configured to use a proxy with user authentication when running locally.

To run the app locally via Intellij, you can add a run configuration with 'SPRING_PROFILES_ACTIVE=local'
as an environment variable, 'and com.natwest.pbbdhb.ui.coord.brokerauth.BrokerAuthenticationApplication.java' as the main
class.

## How to test

To run unit tests, you can either run the tests in IntelliJ, or run the following command (the command might not run
integration tests):

```

mvn test

```

To run all tests, including integration tests, and verify that project gets packaged up then you can run :

```

mvn verify -DskipITs=false

```

## Setting up your IDE

### Setting up plugins in IntelliJ

The code in the libraries included by the dws starter uses Lombok, so you need to install the IntelliJ Lombok plugin in
order to compile your project.

### Setting up code autoformatting in IntelliJ

It is recommended that all developers use a consistent code formatter.

1. File > Settings > Editor > Code Style, then Settings > Import Scheme > IntelliJ IDEA code style XML.
2. Select `intellij-style.xml` from the root of the project
3. Install the Save Actions plugin and restart IntelliJ
4. File > Settings > Other Settings > Save Actions
5. Enable `Activate save actions on save`, `Optimize imports`, `Reformat file`

### Setting up SonarLint

It is recommended to use SonarLint, instructions to set this up can be found in these links:

- https://confluence.dts.fm.rbsgrp.net/pages/viewpage.action?spaceKey=PBJ&title=Sonar+Local+Setup
- https://confluence.dts.fm.rbsgrp.net/pages/viewpage.action?spaceKey=PAIS&title=Integrate+the+SonarLint+with+SonarQube+in+local

## How to deploy

Deploying this service can be done through team city (https://teamcity-4.dts.fm.rbsgrp.net/project.html?projectId=AgileMarkets_DigitalHomeBuying_JavaArchetype_UiCoordBrokerAuth&tab=projectOverview&branch_AgileMarkets_DigitalHomeBuying_JavaArchetype_UiCoordBrokerAuth=__all_branches__)
using the PCF Deploy option. After choosing a branch, you can specify an env to deploy to in the build's run parameters.

Alternatively the service can be deployed manually using these
instructions: https://natwest.atlassian.net/wiki/spaces/PBBDHB/pages/1204957482/Deploying+a+microservice

## About this service

This is an L1 service designed to support _CRM_ and the ui broker authentication for intermediary services (_ui-spa-broker-auth_), by calling _msvc-broker-auth_ to create/activate/login users with _iam_. 
This service has endpoints to support each part of the broker auth process:

- __BrokerRegistrationController__ - endpoints for the initial registration of brokers and admins with _CRM_, (e.g. check username available, get firm details, register user)
- __RegistrationController__ - endpoints to be called by _CRM_ for creating/deleting/reactivating users in _iam_
- __ActivationController__ - endpoints with activation actions for users (e.g. activate user, validate action code)
- __LoginController__ - endpoints for logging in users

## Swagger Documentation

When running locally Swagger documentation will be generated from the code and available at:

- http://localhost:8080/mortgages/v1/ui-broker-auth/swagger-ui/index.html#/ (interactive UI)
- http://localhost:8080/mortgages/v1/ui-broker-auth/v3/api-docs (as json)
- http://localhost:8080/mortgages/v1/ui-broker-auth/v3/api-docs.yaml (as yaml)

You can also find the deployed service's documentation (along with its current status and build) through the hbo service
dashboard: https://dev-spa.mortgages.natwest.com/dashboard

## Microservice Structure

- client - clients to external apis, dbs, etc. Also includes client layer domain models and mappers
- configuration - all property and configuration classes
- domain - service layer domain objects. The request and client layer packages contain their own domain packages, and
  are responsible for converting to and from the top level domain models
- exception - global exception handler and custom exception classes
- request - controllers and request layer domain models and mappers
- service - all services
- validation - custom validation classes

More information on this structure can be found
here: https://natwest.atlassian.net/wiki/spaces/PBBDHB/pages/950252075/ADR+004+-+Separation+of+Request+and+Service+layers+packages
