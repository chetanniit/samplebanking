package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import jakarta.validation.ConstraintViolation;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidUsernameReminderRequest;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.getConstraintViolations;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class UsernameReminderRequestValidationTest {

    private static final String UNEXPECTED_ADDITIONAL_VIOLATION = "unexpected additional constraint violation";

    @Test
    public void validUsernameReminderRequestHasNoErrors() {
        UsernameReminderRequest usernameReminderRequest = createValidUsernameReminderRequest();

        Set<ConstraintViolation<UsernameReminderRequest>> violations = getConstraintViolations(usernameReminderRequest);

        assertEquals(0, violations.size());
    }


    @Test
    public void nullAndBlankMandatoryFieldsCausesValidationError() {
        UsernameReminderRequest usernameReminderRequest = createValidUsernameReminderRequest();
        usernameReminderRequest.setDateOfBirth(null);
        usernameReminderRequest.setEmail("");
        usernameReminderRequest.setLastName("");
        Set<ConstraintViolation<UsernameReminderRequest>> violations = getConstraintViolations(usernameReminderRequest);

        assertEquals(3, violations.size());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("email") && MUST_NOT_BE_BLANK_ERROR_MESSAGE.equals(v.getMessage())));
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("lastName") && MUST_NOT_BE_BLANK_ERROR_MESSAGE.equals(v.getMessage())));
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("dateOfBirth") && MUST_NOT_BE_NULL_ERROR_MESSAGE.equals(v.getMessage())));

    }

}
