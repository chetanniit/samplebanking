package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.BrokerInfoContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.AddressInfoModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

public class BrokerInfoClientMapperTest {

    @Nested
    @DisplayName("Broker Cases")
    class BrokerCases {

        @Test
        void shouldMapBrokerInfoBrokerDomainModel() {
            BrokerInfoContext context = BrokerInfoContext.builder().build();

            BrokerInfoBrokerDomainModel actual = BrokerInfoClientMapper.toDomain(context.createBrokerInfoDto());

            BrokerInfoBrokerDomainModel expected = context.createBrokerInfoDomainModel();

            Assertions.assertEquals(expected, actual);
        }


        @Test
        void shouldReturnNullForMissingDetails() {
            BrokerInfoBrokerDomainModel actual = BrokerInfoClientMapper.toDomain(BrokerInfoResponseDto.builder()
                    .broker(BrokerInfoDto.builder().build())
                    .firm(FirmDto.builder().build())
                    .tradingName(TradingNameDto.builder().build())
                    .build());

            BrokerInfoBrokerDomainModel expected = BrokerInfoBrokerDomainModel.builder().firmAddress(AddressInfoModel.builder().build()).build();

            Assertions.assertEquals(expected, actual);
        }
    }

    @Nested
    @DisplayName("Admin Cases")
    class AdminCases {

        @Test
        void shouldMapBrokerInfoBrokerDomainModel() {
            BrokerInfoContext context = BrokerInfoContext.builder().build();

            BrokerInfoBrokerDomainModel actual = BrokerInfoClientMapper.toDomain(context.createAdminInfoDto());

            BrokerInfoBrokerDomainModel expected = context.createAdminInfoBrokerDomainModel();

            Assertions.assertEquals(expected, actual);
        }


        @Test
        void shouldReturnNullForMissingDetails() {
            BrokerInfoBrokerDomainModel actual = BrokerInfoClientMapper.toDomain(AdminInfoDto.builder().build());

            BrokerInfoBrokerDomainModel expected = BrokerInfoBrokerDomainModel.builder().build();

            Assertions.assertEquals(expected, actual);
        }
    }
}
