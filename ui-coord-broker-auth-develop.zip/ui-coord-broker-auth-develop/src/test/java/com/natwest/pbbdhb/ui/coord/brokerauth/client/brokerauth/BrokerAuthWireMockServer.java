package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth;

import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.google.common.collect.Lists;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.util.UriComponentsBuilder;
import wiremock.com.fasterxml.jackson.databind.ObjectMapper;
import wiremock.com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.List;

public class BrokerAuthWireMockServer {

  private static final String EXPECTED_PATH = "/mortgages/v1/msvc-broker-auth";
  private static final String EXPECTED_ACTIVATION_CODE = "123456";
  private static final List<String> EXPECTED_QUESTIONS = Lists.newArrayList(
      "Question 1?",
      "Question 2?",
      "Question 3?",
      "Question 4?",
      "Question 5?"
  );
  private static final String EXPECTED_OTP_CODE = "abc123";
  private static final String EXPECTED_BROKER_TYPE = UserRegistrationType.BROKER.value();
  private static final String USERNAME = "TestUsername";
  private static final String USERNAME_REMINDER_FOUND_RESPONSE_MESSAGE = "Broker Admin Record Identified Successfully.";
  private static final String USERNAME_REMINDER_NOT_FOUND_RESPONSE_MESSAGE = "Broker / Broker Admin Record not found, contact LiveTalk.";

  private static String activationPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("activation")
        .build()
        .getPath();
  }

  private static String registrationRetrievePath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("users")
        .build()
        .getPath();
  }

  private static String deleteUserPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("users")
        .build()
        .getPath();
  }

  private static String generateActivationCodePath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("users", "activation-code")
        .build()
        .getPath();
  }

  private static String validateActivationCodePath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("activation", "validate")
        .build()
        .toUriString();
  }

  private static String loginPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("login")
        .build()
        .toUriString();
  }

  private static String reactivateUserPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("users", "reactivate")
        .build()
        .toUriString();
  }

  private static String retrieveQuestionsPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("account-management", "challenge-questions")
        .build()
        .toUriString();
  }

  private static String validateAnswersPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("account-management", "challenge-answers")
        .build()
        .toUriString();
  }

  private static String resetPasswordPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("account-management", "password-reset")
        .build()
        .toUriString();
  }

  private static String validateOtpPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("account-management", "otp-validation")
        .build()
        .toUriString();
  }

  private static String getUsernameReminderPath() {
    return UriComponentsBuilder
            .fromPath(EXPECTED_PATH)
            .pathSegment("account-management", "username-reminder")
            .build()
            .toUriString();
  }

  private static String getBrokerDetailsPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("account-management")
        .pathSegment("broker-details", "{username}")
        .build(USERNAME)
        .toString();
  }

  public static MappingBuilder mappingActivationRequest() {
    return WireMock.post(WireMock.urlPathEqualTo(activationPath()));
  }

  public static MappingBuilder mappingRetrieveRequest() {
    return WireMock.post(WireMock.urlPathEqualTo(registrationRetrievePath()));
  }

  public static MappingBuilder mappingDeleteRequest() {
    return WireMock.delete(WireMock.urlPathEqualTo(deleteUserPath()));
  }

  public static MappingBuilder mappingGenerateActivationCodeRequest() {
    return WireMock.post(WireMock.urlPathEqualTo(generateActivationCodePath()));
  }

  public static MappingBuilder mappingValidateActivationCodeRequest() {
    return WireMock.post(WireMock.urlEqualTo(validateActivationCodePath()));
  }

  public static MappingBuilder mappingLoginRequest() {
    return WireMock.post(WireMock.urlEqualTo(loginPath()));
  }

  public static MappingBuilder mappingReactivateUserRequest() {
    return WireMock.post(WireMock.urlEqualTo(reactivateUserPath()));
  }

  public static MappingBuilder mappingRetrieveQuestionsRequest() {
    return WireMock.post(WireMock.urlEqualTo(retrieveQuestionsPath()));
  }

  public static MappingBuilder mappingValidateAnswersRequest() {
    return WireMock.post(WireMock.urlEqualTo(validateAnswersPath()));
  }

  public static MappingBuilder mappingResetPasswordRequest() {
    return WireMock.post(WireMock.urlEqualTo(resetPasswordPath()));
  }

  public static MappingBuilder mappingValidateOtpRequest() {
    return WireMock.post(WireMock.urlEqualTo(validateOtpPath()));
  }

  public static MappingBuilder mappingGetBrokerDetailsRequest() {
    return WireMock.get(WireMock.urlEqualTo(getBrokerDetailsPath()));
  }

  public static MappingBuilder mappingGetUsernameReminderRequest() {
    return WireMock.post(WireMock.urlEqualTo(getUsernameReminderPath()));
  }

  /**
   * Define a verifier request pattern for an activate user request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForActivateUserRequest() {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(activationPath()));
  }

  /**
   * Define a verifier request pattern for a registration retrieve request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForRetrieveRequest() {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(registrationRetrievePath()));
  }

  public static RequestPatternBuilder patternForDeleteRequest() {
    return WireMock.deleteRequestedFor(WireMock.urlPathMatching(deleteUserPath()));
  }

  public static RequestPatternBuilder patternForGenerateActivationCodeRequest() {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(generateActivationCodePath()));
  }

  public static ResponseDefinitionBuilder jsonResponse(HttpStatus status) {
    return WireMock.status(status.value());
  }

  /**
   * Define a verifier request pattern for a validate an activation code request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForValidateActivationCodeRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(validateActivationCodePath()));
  }

  /**
   * Define a verifier request pattern for a login request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForLoginRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(loginPath()));
  }

  public static RequestPatternBuilder patternForReactivateUserRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(reactivateUserPath()));
  }

  public static RequestPatternBuilder patternForRetrieveQuestionsRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(retrieveQuestionsPath()));
  }

  public static RequestPatternBuilder patternForValidateAnswersRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(validateAnswersPath()));
  }

  /**
   * Define a verifier request pattern for a reset password request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForResetPasswordRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(resetPasswordPath()));
  }

  /**
   * Define a verifier request pattern for a validate OTP request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForValidateOtpRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(validateOtpPath()));
  }

  public static RequestPatternBuilder patternForUsernameReminderRequest() {
    return WireMock.postRequestedFor(WireMock.urlEqualTo(getUsernameReminderPath()));
  }

  public static RequestPatternBuilder patternForGetBrokerDetails() {
    return WireMock.getRequestedFor(WireMock.urlEqualTo(getBrokerDetailsPath()));
  }

  public static ResponseDefinitionBuilder jsonResponse(ResponseDefinitionBuilder status) {
    return status
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json");
  }

  public static ObjectNode getActivationCodeResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("code", EXPECTED_ACTIVATION_CODE);
    return payload;
  }

  public static ObjectNode getReactivateUserResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("code", EXPECTED_OTP_CODE);
    return payload;
  }

  public static ObjectNode getRetrieveQuestionsResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.putPOJO("securityQuestions", EXPECTED_QUESTIONS);
    return payload;
  }

  public static ObjectNode getValidateAnswersResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("otpCode", EXPECTED_OTP_CODE);
    payload.put("brokerType", EXPECTED_BROKER_TYPE);
    return payload;
  }

  public static ObjectNode getUsernameReminderResponseUserFound() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("usernameFound", true);
    payload.put("message", USERNAME_REMINDER_FOUND_RESPONSE_MESSAGE);
    return payload;
  }

  public static ObjectNode getUsernameReminderResponseUserNotFound() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("usernameFound", false);
    payload.put("message", USERNAME_REMINDER_NOT_FOUND_RESPONSE_MESSAGE);
    return payload;
  }

  public static ObjectNode errorResponseBody(ErrorCode code) {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("code", code.toString());
    return payload;
  }

  static ResponseDefinitionBuilder jsonResponse(HttpStatus status,
      ObjectNode body) {
    return WireMock.status(status.value())
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        .withJsonBody(body);
  }




}
