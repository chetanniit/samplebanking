package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.responses;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import java.util.Collections;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles(profiles = { "integration", "rest-responses" })
class CrmResponsesTest {

  @Autowired
  private CrmResponses crmResponses;

  @Test
  void ThrowsExceptionWhenJsonIsNull() {
    CrmDataException exception = assertThrows(
        CrmDataException.class,
        () -> crmResponses.isSuccessful("test-key-1", null)
    );

    assertEquals(
        "Json supplied to response check cannot be null",
        exception.getMessage()
    );
  }

  @Test
  void ThrowsExceptionWhenEndpointIsNull() {
    CrmDataException exception = assertThrows(
        CrmDataException.class,
        () -> crmResponses.isSuccessful(null,
            new JSONObject(Collections.singletonMap("mbs_message", "test success 1")))
    );

    assertEquals(
        "No response checker configured for endpoint: null",
        exception.getMessage()
    );
  }

  @Test
  void ThrowsExceptionWhenEndpointNotFound() {
    CrmDataException exception = assertThrows(
        CrmDataException.class,
        () -> crmResponses.isSuccessful("not-a-test-key",
            new JSONObject(Collections.singletonMap("mbs_message", "test success 1")))
    );

    assertEquals(
        "No response checker configured for endpoint: not-a-test-key",
        exception.getMessage()
    );
  }

  @Test
  void isSuccessfulReturnsCorrectResponseWhenResponseContainsTarget() {
    assertTrue(crmResponses.isSuccessful(
        "test-key-1",
        new JSONObject(Collections.singletonMap("mbs_message", "test success 1"))
    ));

    assertFalse(crmResponses.isSuccessful(
        "test-key-1",
        new JSONObject(Collections.singletonMap("mbs_message", "test failure 1"))
    ));

  }

  @Test
  void isSuccessfulReturnsCorrectResponseWhenNonDefaultTargetIsSpecified() {
    assertFalse(crmResponses.isSuccessful(
        "test-key-2",
        new JSONObject(Collections.singletonMap("test different target", "test failure 2"))
    ));
  }

  @Test
  void IsSuccessfulThrowsExceptionWhenNoTargetFound() {
    CrmDataException exception = assertThrows(
        CrmDataException.class,
        () -> crmResponses.isSuccessful("test-key-2",
            new JSONObject(Collections.singletonMap("not a target", "test fail 2"))
        )
    );

    assertEquals(
        "No response fields found.  Expected one of [success: \"mbs_message\", failure: \"test different target\"]",
        exception.getMessage()
    );
  }

  @Test
  void IsSuccessfulThrowsExceptionWhenNoMatchingMessage() {
    CrmDataException exception = assertThrows(
        CrmDataException.class,
        () -> crmResponses.isSuccessful("test-key-1",
            new JSONObject(Collections.singletonMap("mbs_message", "wrong success message"))
        )
    );

    assertEquals(
        "CRM returned an unexpected result.  Expected one of [success: \"test success 1\", failure: \"test failure 1\"]",
        exception.getMessage()
    );
  }

  @Test
  void isSuccessfulThrowsExceptionWhenResponseIsEmpty() {
    CrmDataException exception = assertThrows(
        CrmDataException.class,
        () -> crmResponses.isSuccessful("test-key-2", new JSONObject())
    );

    assertEquals(
        "No response fields found.  Expected one of [success: \"mbs_message\", failure: \"test different target\"]",
        exception.getMessage()
    );
  }
}