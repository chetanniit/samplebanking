package com.natwest.pbbdhb.ui.coord.brokerauth.util;

import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.APPOINTED_REPRESENTATIVE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.DIRECTLY_AUTHORISED;
import static java.lang.Boolean.TRUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.*;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.Address;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.Agreements;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.PaymentPath;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.PrincipalFcaFirm;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.ResidentialAddress;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UserDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.Title;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import lombok.SneakyThrows;
import org.springframework.core.io.Resource;

public final class TestUtil {

  public static final Random random = new Random();

  public static final String MUST_NOT_BE_NULL_ERROR_MESSAGE = "must not be null";
  public static final String MUST_NOT_BE_BLANK_ERROR_MESSAGE = "must not be blank";
  public static final String SIZE_ERROR_MESSAGE = "size must be between 0 and %d";
  public static final String MUST_NOT_BE_EMPTY_ERROR_MESSAGE = "must not be empty";

  public static final String ENUM_BROKER_TYPE_ERROR_MESSAGE = "must be any of: AR, DA";

  public static final String BRAND_RBS = "rbs";

  private static final String MOBILE_PHONE_NUMBER = "123 456 7890";
  private static final String OTHER_PHONE_NUMBER = "123 456 7891";

  private static final ObjectMapper objectMapper = JsonMapper.builder()
      .findAndAddModules()  // load extensions for LocalDate, etc.
      .build();

  private static final ObjectMapper objectMapperIgnoreUnknownProperties = new ObjectMapper().configure(
      DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

  /**
   * @return a username containing 8 random digits
   */
  public static String newRandomUserName() {
    final int randomInteger = random.nextInt(100000000);
    final String randomPart = String.format("%08d", randomInteger);
    return "testUser-" + randomPart;
  }

  public static BrokerRegistration createValidBrokerRegistration() {
    BrokerRegistration brokerRegistration = new BrokerRegistration();
    brokerRegistration.setBrokerDetails(createValidUserDetails());
    brokerRegistration.setAgreements(createValidAgreements());
    brokerRegistration.setAddress(createValidAddress());
    brokerRegistration.setFirmDetails(createValidFirmDetails());
    brokerRegistration.setUsername("test-username");
    brokerRegistration.setPaymentPaths(Arrays.asList("test-payment-path-1", "test-payment-path-2"));
    return brokerRegistration;
  }

  public static AdminRegistration createValidAdminRegistration() {
    AdminRegistration adminRegistration = new AdminRegistration();
    adminRegistration.setAdminDetails(createValidAdminDetails());
    adminRegistration.setAgreements(createValidAgreements());
    adminRegistration.setFirmDetails(createValidAdminFirmDetails());
    adminRegistration.setUsername("test-username");

    return adminRegistration;
  }

  @SneakyThrows
  public static AdminRegistrationDto createValidAdminRegistrationDto() {
    AdminRegistrationDto adminRegistrationDto = new AdminRegistrationDto();
    adminRegistrationDto.setFirstName("James");
    adminRegistrationDto.setLastName("Bond");
    adminRegistrationDto.setFcaNumber("007007");
    adminRegistrationDto.setUsername("jbond007");
    adminRegistrationDto.setFirmName("Universal Exports");
    return adminRegistrationDto;
  }

  public static UserDetails createValidUserDetails() {
    UserDetails userDetails = new UserDetails();
    userDetails.setTitle(Title.CAPTAIN);
    userDetails.setFirstNames("James Tiberius");
    userDetails.setLastName("Kirk");
    userDetails.setDateOfBirth(LocalDate.of(2233, 3, 22));
    userDetails.setEmailAddress("captain@enterprise.org");
    userDetails.setMobilePhoneNumber(MOBILE_PHONE_NUMBER);
    userDetails.setOtherPhoneNumber(OTHER_PHONE_NUMBER);
    userDetails.setNationality("GB");
    userDetails.setResidentialAddress(createValidResidentialAddress());
    return userDetails;
  }

  public static AdminDetails createValidAdminDetails() {
    AdminDetails userDetails = new AdminDetails();
    userDetails.setTitle(Title.CAPTAIN);
    userDetails.setFirstName("James");
    userDetails.setMiddleName("Tiberius");
    userDetails.setLastName("Kirk");
    userDetails.setDateOfBirth(LocalDate.of(2233, 3, 22));
    userDetails.setEmailAddress("captain@enterprise.org");
    userDetails.setMobilePhoneNumber(MOBILE_PHONE_NUMBER);
    userDetails.setOtherPhoneNumber(OTHER_PHONE_NUMBER);

    return userDetails;
  }

  public static AdminRegistrationResponseDto createAdminRegistrationResponseDto(String errorMessage) {
    AdminRegistrationResponseDto adminRegistrationResponseDto = new AdminRegistrationResponseDto();
    adminRegistrationResponseDto.setMessage(errorMessage);
    return adminRegistrationResponseDto;
  }

  public static String createValidBrokerRegistrationJson(BrokerRegistration brokerRegistration)
      throws JsonProcessingException {
    return objectMapper.writeValueAsString(brokerRegistration);
  }

  public static String createValidBrokerRegistrationJson() throws JsonProcessingException {
    BrokerRegistration brokerRegistration = createValidBrokerRegistration();
    return createValidBrokerRegistrationJson(brokerRegistration);
  }

  public static String createAdminRegistrationJson(AdminRegistration adminRegistration)
      throws JsonProcessingException {
    return objectMapper.writeValueAsString(adminRegistration);
  }

  public static Agreements createValidAgreements() {
    Agreements agreements = new Agreements();
    agreements.setPrivacyPolicy(TRUE);
    agreements.setTermsOfBusiness(TRUE);
    agreements.setBusinessDeclaration(TRUE);
    return agreements;
  }

  public static Address createValidAddress() {
    Address address = new Address();
    address.setAddressLine1("test-address-line-1");
    address.setAddressLine2("test-address-line-2");
    address.setAddressLine3("test-address-line-3");
    address.setTown("test-town");
    address.setCounty("test-county");
    address.setPostcode("test-postcode");
    return address;
  }

  public static ResidentialAddress createValidResidentialAddress() {
    ResidentialAddress address = new ResidentialAddress();
    address.setAddressLine1("test-address-line-1");
    address.setTown("test-town");
    address.setCountryOfAddress("test-county");
    address.setPostcode("test-postcode");
    return address;
  }

  public static FirmDetails createValidFirmDetails() {
    FirmDetails firmDetails = new FirmDetails();
    firmDetails.setBrokerType(APPOINTED_REPRESENTATIVE.value());
    firmDetails.setFirmName("test-firm-name");
    firmDetails.setFcaNumber("726136");
    firmDetails.setPrincipalFcaNumber("726136");
    firmDetails.setPreviousFirmName("test-previous-firm-name");
    firmDetails.setPreviousFcaNumber("726136");
    return firmDetails;
  }

  public static FirmDetails createValidAdminFirmDetails() {
    FirmDetails firmDetails = new FirmDetails();
    firmDetails.setBrokerType(DIRECTLY_AUTHORISED.value());
    firmDetails.setFirmName("test-firm-name");
    firmDetails.setFcaNumber("726136");
    firmDetails.setPreviousFirmName("test-previous-firm-name");
    firmDetails.setPreviousFcaNumber("726136");
    return firmDetails;
  }

  public static <T> Set<ConstraintViolation<T>> getConstraintViolations(T valueToCheck) {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    Validator validator = factory.getValidator();
    return validator.validate(valueToCheck);
  }

  public static FirmDetailsResponse createValidFirmDetailsResponse() {
    FirmDetailsResponse firmDetailsResponse = new FirmDetailsResponse();
    firmDetailsResponse.setBrokerType(APPOINTED_REPRESENTATIVE.value());
    firmDetailsResponse.setFcaNumber("test-fca-number");
    firmDetailsResponse.setTradingNames(
        Arrays.asList("test-trading-name-1", "test-trading-name-2"));
    firmDetailsResponse.setPaymentPaths(Collections.singletonList(createValidPaymentPath()));
    firmDetailsResponse.setPrincipalFcaFirms(
        Collections.singletonList(createValidPrincipalFcaFirm()));
    return firmDetailsResponse;
  }

  private static PaymentPath createValidPaymentPath() {
    PaymentPath paymentPath = new PaymentPath();
    paymentPath.setPaymentId("test-payment-id");
    paymentPath.setName("test-payment-name");
    return paymentPath;
  }

  private static PrincipalFcaFirm createValidPrincipalFcaFirm() {
    PrincipalFcaFirm principalFcaFirm = new PrincipalFcaFirm();
    principalFcaFirm.setFcaNumber("test-principal-fca-number");
    principalFcaFirm.setName("test-principal-firm-name");
    return principalFcaFirm;
  }

  public static FirmDetailsResponseDto createValidFirmDetailsResponseDto() {
    FirmDetailsResponseDto firmDetailsResponseDto = new FirmDetailsResponseDto();
    firmDetailsResponseDto.setBrokerType(APPOINTED_REPRESENTATIVE.value());
    firmDetailsResponseDto.setIsAllowed(TRUE);
    firmDetailsResponseDto.setIsExist(TRUE);
    firmDetailsResponseDto.setTradingNames(
        Arrays.asList(createValidAlternativeTradingNamesDto("test-trading-name-1"),
            createValidAlternativeTradingNamesDto("test-trading-name-2")));
    firmDetailsResponseDto.setPaymentPaths(Collections.singletonList(createValidPaymentPathDto()));
    firmDetailsResponseDto.setPrincipalFcaFirms(
        Collections.singletonList(createValidPrincipalFcaFirmDto()));
    return firmDetailsResponseDto;
  }

  private static AlternativeTradingNamesDto createValidAlternativeTradingNamesDto(String name) {
    AlternativeTradingNamesDto alternativeTradingNamesDto = new AlternativeTradingNamesDto();
    alternativeTradingNamesDto.setName(name);
    return alternativeTradingNamesDto;
  }

  private static PaymentPathDto createValidPaymentPathDto() {
    PaymentPathDto paymentPathDto = new PaymentPathDto();
    paymentPathDto.setPaymentId("test-payment-id");
    paymentPathDto.setName("test-payment-name");
    return paymentPathDto;
  }

  private static PrincipalFcaFirmDto createValidPrincipalFcaFirmDto() {
    PrincipalFcaFirmDto principalFcaFirmDto = new PrincipalFcaFirmDto();
    principalFcaFirmDto.setFcaNumber("test-principal-fca-number");
    principalFcaFirmDto.setName("test-principal-firm-name");
    return principalFcaFirmDto;
  }

  @SneakyThrows
  public static BrokerRegistrationDto createValidBrokerRegistrationDto() {
    BrokerRegistrationDto brokerRegistrationDto = new BrokerRegistrationDto();
    brokerRegistrationDto.setBrokerDetails(
        objectMapper.writeValueAsString(createValidBrokerDetailsDto()));
    brokerRegistrationDto.setAddress(
        objectMapper.writeValueAsString(createValidBrokerAddressDto()));
    brokerRegistrationDto.setFirmDetails(
        objectMapper.writeValueAsString(createValidFirmDetailsDto()));
    brokerRegistrationDto.setUsername("test-username");
    brokerRegistrationDto.setPaymentPaths("test-payment-path-1,test-payment-path-2");
    brokerRegistrationDto.setTradingNames("test-firm-name");
    brokerRegistrationDto.setResidentialAddress(
            objectMapper.writeValueAsString(createValidBrokerResidentialAddressDto())
    );
    return brokerRegistrationDto;
  }

  private static BrokerRegistrationDto.BrokerDetailsDto createValidBrokerDetailsDto() {
    BrokerRegistrationDto.BrokerDetailsDto brokerDetailsDto = new BrokerRegistrationDto.BrokerDetailsDto();
    brokerDetailsDto.setTitle(Title.CAPTAIN.getText());
    brokerDetailsDto.setFirstNames("James Tiberius");
    brokerDetailsDto.setLastName("Kirk");
    brokerDetailsDto.setDateOfBirth(LocalDate.of(2233, 3, 22));
    brokerDetailsDto.setEmailAddress("captain@enterprise.org");
    brokerDetailsDto.setPrimaryPhoneNumber(MOBILE_PHONE_NUMBER);
    brokerDetailsDto.setSecondaryPhoneNumber(OTHER_PHONE_NUMBER);
    brokerDetailsDto.setNationality("GB");
    return brokerDetailsDto;
  }

  private static BrokerRegistrationDto.AddressDto createValidBrokerAddressDto() {
    BrokerRegistrationDto.AddressDto brokerAddressDto = new BrokerRegistrationDto.AddressDto();
    brokerAddressDto.setAddressLine1("test-address-line-1");
    brokerAddressDto.setAddressLine2("test-address-line-2");
    brokerAddressDto.setAddressLine3("test-address-line-3");
    brokerAddressDto.setTown("test-town");
    brokerAddressDto.setCounty("test-county");
    brokerAddressDto.setPostcode("test-postcode");
    return brokerAddressDto;
  }

  private static BrokerRegistrationDto.ResidentialAddressDto createValidBrokerResidentialAddressDto() {
    BrokerRegistrationDto.ResidentialAddressDto brokerAddressDto = new BrokerRegistrationDto.ResidentialAddressDto();
    brokerAddressDto.setAddressLine1("test-address-line-1");
    brokerAddressDto.setTown("test-town");
    brokerAddressDto.setCountry("test-county");
    brokerAddressDto.setPostcode("test-postcode");
    return brokerAddressDto;
  }

  private static BrokerRegistrationDto.FirmDetailsDto createValidFirmDetailsDto() {
    BrokerRegistrationDto.FirmDetailsDto firmDetailsDto = new BrokerRegistrationDto.FirmDetailsDto();
    firmDetailsDto.setBrokerType(APPOINTED_REPRESENTATIVE.value());
    firmDetailsDto.setFirmName("test-firm-name");
    firmDetailsDto.setFcaNumber("726136");
    firmDetailsDto.setPrincipalFcaNumber("726136");
    firmDetailsDto.setPreviousFirmName("test-previous-firm-name");
    firmDetailsDto.setPreviousFcaNumber("726136");
    return firmDetailsDto;
  }

  public static BrokerRegistrationResponseDto createBrokerRegistrationResponseDto(boolean isSuccess,
      String errorMessage) {
    BrokerRegistrationResponseDto brokerRegistrationResponseDto = new BrokerRegistrationResponseDto();
    brokerRegistrationResponseDto.setMessage(errorMessage);
    brokerRegistrationResponseDto.setSuccess(isSuccess);
    return brokerRegistrationResponseDto;
  }

  public static <T> T readObjectFromResource(Resource resource, Class<T> objectType)
      throws IOException {
    return objectMapperIgnoreUnknownProperties.readValue(resource.getInputStream(), objectType);
  }

  public static FirmDetailsResponseDto readFirmDetailsFromResource(Resource resource)
      throws IOException {
    return readObjectFromResource(resource, FirmDetailsResponseDto.class);
  }

  public static BrokerRegistrationResponseDto readRegisterBrokerFromResource(Resource resource)
      throws IOException {
    return readObjectFromResource(resource, BrokerRegistrationResponseDto.class);
  }

  public static String readResource(Resource resource) throws IOException {
    return new BufferedReader(
        new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8)).lines()
        .collect(Collectors.joining());
  }

  public static FirmDetailsResponse readFirmDetailsResponseFromResource(Resource resource)
      throws IOException {
    return readObjectFromResource(resource, FirmDetailsResponse.class);
  }

  public static UsernameReminderRequest createValidUsernameReminderRequest() {
    return UsernameReminderRequest.builder()
            .dateOfBirth(LocalDate.of(1980, 1, 1))
            .email("test@email.com")
            .lastName("Last Name")
            .build();
  }

  private TestUtil() {
  }
}
