package com.natwest.pbbdhb.ui.coord.brokerauth.service.activation;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ActivationCodeException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.event.BrokerEventService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ActivationServiceTest {

  @Mock
  BrokerAuthClient brokerAuthClient;

  @Mock
  BrokerEventService brokerEventService;

  @Nested
  @DisplayName("Activate Cases")
  class ActivateCases {

    @Test
    void shouldCallBrokerAuthClientToActivateUserAndSendMetric() {
      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      ActivateUserRequestModel model = activationContext.createActivateUserRequestModel();

      activationService.activateUser(model);

      verify(brokerAuthClient).activate(model);
      verify(brokerEventService).createBrokerActivationEvent(model.getUsername());

    }

    @Test
    void shouldReturnErrorIfPasswordInvalid() {
      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(new InvalidDetailsException("Password was invalid"))
          .when(brokerAuthClient).activate(activationContext.createActivateUserRequestModel());

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();

      assertThatThrownBy(
          () -> activationService.activateUser(activateUserRequestModel))
          .isInstanceOf(InvalidDetailsException.class);

      verify(brokerAuthClient).activate(activationContext.createActivateUserRequestModel());
      verifyNoInteractions(brokerEventService);

    }

    @Test
    void shouldReturnErrorIfActivationCodeIsExpired() {
      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.OTP_EXPIRED,
              "Activation code is expired")).when(
              brokerAuthClient)
          .activate(any());

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();
      assertThatThrownBy(
          () -> activationService.activateUser(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).activate(activateUserRequestModel);
      verifyNoInteractions(brokerEventService);


    }

    @Test
    void shouldReturnErrorIfAccountIsLocked() {
      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.ACCOUNT_LOCKED,
              "user account is locked")).when(
              brokerAuthClient)
          .activate(any());

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();
      assertThatThrownBy(
          () -> activationService.activateUser(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).activate(activateUserRequestModel);
      verifyNoInteractions(brokerEventService);


    }

    @Test
    void shouldReturnErrorIfUsernameOrActivationCodeIsInvalid() {
      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.INVALID_CREDENTIALS,
              "Username or Activation code is invalid")).when(
              brokerAuthClient)
          .activate(any());

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();
      assertThatThrownBy(
          () -> activationService.activateUser(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).activate(activateUserRequestModel);
      verifyNoInteractions(brokerEventService);


    }

    @Test
    void shouldReturnErrorIfActivationCodeValidationIsFailed() {
      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.OTP_VALIDATION_FAILED,
              "Activation code validation is failed")).when(
              brokerAuthClient)
          .activate(any());

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();
      assertThatThrownBy(
          () -> activationService.activateUser(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).activate(activateUserRequestModel);
      verifyNoInteractions(brokerEventService);


    }

    @Test
    void shouldReturnErrorIfActivationBrokerEventReturnsException() {

      //Note: This scenario is included for completeness as BrokerEventService is mocked, but is not expected to happen as real BrokerEventService createBrokerActivationEvent is suppressing all exceptions.

      ActivationContext activationContext = ActivationContext.builder().build();

      ActivationService activationService = new ActivationService(brokerAuthClient, brokerEventService);

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();

      doThrow(
          new RuntimeException("some issue")).when(
              brokerEventService)
          .createBrokerActivationEvent(any());

      assertThatThrownBy(
          () -> activationService.activateUser(activateUserRequestModel))
          .isInstanceOf(RuntimeException.class);

      verify(brokerAuthClient).activate(activateUserRequestModel);
      verify(brokerEventService).createBrokerActivationEvent(activateUserRequestModel.getUsername());

    }
  }

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    @Test
    void shouldCallBrokerAuthClient() {
      ActivationCodeValidateRequestModel model = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationService service = new ActivationService(brokerAuthClient, brokerEventService);

      service.validateActivationCode(model);

      verify(brokerAuthClient).validateActivationCode(model);
      verifyNoInteractions(brokerEventService);

    }

    @Test
    void shouldReturnErrorIfUsernameOrActivationCodeIsInvalid() {
      ActivationCodeValidateRequestModel model = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationService service = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.INVALID_CREDENTIALS,
              "Username or Activation code is invalid")).when(
              brokerAuthClient)
          .validateActivationCode(any());

      assertThatThrownBy(() -> service.validateActivationCode(model))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).validateActivationCode(model);
      verifyNoInteractions(brokerEventService);

    }

    @Test
    void shouldReturnErrorIfActivationCodeIsExpired() {
      ActivationCodeValidateRequestModel model = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationService service = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.OTP_EXPIRED,
              "Activation code is expired")).when(
              brokerAuthClient)
          .validateActivationCode(any());

      assertThatThrownBy(() -> service.validateActivationCode(model))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).validateActivationCode(model);
      verifyNoInteractions(brokerEventService);
    }

    @Test
    void shouldReturnErrorIfActivationCodeValidationIsFailed() {
      ActivationCodeValidateRequestModel model = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationService service = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.OTP_VALIDATION_FAILED,
              "Activation code validation is failed")).when(
              brokerAuthClient)
          .validateActivationCode(any());

      assertThatThrownBy(() -> service.validateActivationCode(model))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).validateActivationCode(model);
      verifyNoInteractions(brokerEventService);
    }

    @Test
    void shouldReturnErrorIfAccountIsLocked() {
      ActivationCodeValidateRequestModel model = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationService service = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(
          new ActivationCodeException(ErrorCode.ACCOUNT_LOCKED,
              "user account is locked")).when(
              brokerAuthClient)
          .validateActivationCode(any());

      assertThatThrownBy(() -> service.validateActivationCode(model))
          .isInstanceOf(ActivationCodeException.class);

      verify(brokerAuthClient).validateActivationCode(model);
      verifyNoInteractions(brokerEventService);
    }

    @Test
    void shouldReturnErrorIfDownstreamServiceReturnsError() {
      ActivationCodeValidateRequestModel model = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationService service = new ActivationService(brokerAuthClient, brokerEventService);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(brokerAuthClient).validateActivationCode(any());

      assertThatThrownBy(() -> service.validateActivationCode(model))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(brokerAuthClient).validateActivationCode(model);
      verifyNoInteractions(brokerEventService);
    }



  }
}
