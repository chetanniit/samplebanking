package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccountManagementContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.RegistrationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles(profiles = {"integration", "stub-brokerauth"})
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
class BrokerAuthClientStubTestIT {

  @Autowired
  BrokerAuthClient client;

  @Test
  void shouldInjectStubClient() {
    assertThat(client.getClass())
        .isEqualTo(BrokerAuthClientStub.class);
  }

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToLogin() {
      UserRegistrationType result = client.login(
          LoginRequestModel.builder()
              .username("TestUsername")
              .password("TestPassword")
              .build()
      );

      assertThat(result).isEqualTo(UserRegistrationType.BROKER);
    }
  }

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToValidateActivationCode() {
      client.validateActivationCode(
          ActivationContext.builder().build().createActivationCodeValidateRequestModel());
    }
  }

  @Nested
  @DisplayName("Generate Activation Code Cases")
  class GenerateActivationCodeCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToGenerateActivationCode() {
      client.generateActivationCode(
          RegistrationContext.builder().build().createCreateUserRequestModel().getUsername());
    }
  }

  @Nested
  @DisplayName("Reset Password Cases")
  class ResetPasswordCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToResetPassword() {
      client.resetPassword(
          AccountManagementContext.builder().build().createResetPasswordRequestModel());
    }
  }

  @Nested
  @DisplayName("Validate OTP Cases")
  class ValidateOtpCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToValidateOtp() {
      client.validateOtp(
          AccountManagementContext.builder().build().createValidateOtpRequestModel());
    }
  }

  @Nested
  @DisplayName("Get Username Reminder Cases")
  class GetUsernameReminderCase {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToGetUsernameReminder() {
      client.getUsernameReminder(
              ActivationContext.builder().build().createUsernameReminderRequest());
    }
  }
}
