package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.config;

import okhttp3.OkHttpClient;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

@TestConfiguration
public class TestConfig {

    @Bean
    public OkHttpClient proxyHttpClient() {
        return new OkHttpClient.Builder().build();
    }
}
