package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.*;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.RegistrationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class BrokerAuthClientMapperTest {

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    @Test
    void toClientModel() {
      LoginRequestModel domainModel = LoginRequestModel.builder()
          .username("TestUsername")
          .password("TestPassword")
          .build();

      LoginClientRequest clientModel = BrokerAuthClientMapper.toClientModel(domainModel);

      assertEquals(clientModel.getUsername(), domainModel.getUsername());
      assertEquals(clientModel.getPassword(), domainModel.getPassword());
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          BrokerAuthClientMapper.toClientModel((ActivateUserRequestModel) null)
      );
    }
  }

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    @Test
    void toClientModel() {
      ActivationCodeValidateRequestModel domainModel = ActivationContext.builder().build()
          .createActivationCodeValidateRequestModel();

      ActivationCodeValidateClientRequest clientModel = BrokerAuthClientMapper.toClientModel(
          domainModel);

      assertEquals(clientModel.getUsername(), domainModel.getUsername());
      assertEquals(clientModel.getCode(), domainModel.getCode());
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          BrokerAuthClientMapper.toClientModel((ActivationCodeValidateRequestModel) null)
      );
    }
  }

  @Nested
  @DisplayName("Activate Cases")
  class ActivateCases {

    @Test
    void toActivateClientModel() {
      ActivationContext context = ActivationContext.builder().build();
      ActivateUserRequestModel requestModel = context.createActivateUserRequestModel();

      ActivateUserClientRequest clientRequest = BrokerAuthClientMapper.toClientModel(requestModel);

      assertEquals(requestModel.getUsername(), clientRequest.getUsername());
      assertEquals(requestModel.getPassword(), clientRequest.getPassword());
      assertEquals(requestModel.getOtpCode(), clientRequest.getOtpCode());
      assertEquals(requestModel.getSecurityQuestions().get(0).getQuestion(),
          clientRequest.getSecurityQuestions().get(0).getQuestion());
      assertEquals(requestModel.getSecurityQuestions().get(0).getAnswer(),
          clientRequest.getSecurityQuestions().get(0).getAnswer());
    }
  }

  @Nested
  @DisplayName("Registration Cases")
  class RegistrationCases {

    @Test
    void toClientModel() {
      RegistrationContext context = RegistrationContext.builder().build();

      CreateUserClientRequest actual = BrokerAuthClientMapper
          .toClientModel(context.createCreateUserRequestModel());

      CreateUserClientRequest expected = context.createCreateUserClientRequest();

      Assertions.assertEquals(expected, actual);
    }
  }

  @Nested
  @DisplayName("Deletion Cases")
  class DeleteUserCases {

    @Test
    void toClientModel() {
      RegistrationContext context = RegistrationContext.builder().build();

      DeleteUserClientRequest actual = BrokerAuthClientMapper
              .toClientModel(context.createDeleteUserRequestModel());

      DeleteUserClientRequest expected = context.createDeleteUserClientRequest();

      Assertions.assertEquals(expected, actual);
    }
  }

  @Nested
  @DisplayName("Generate Activation Code")
  class GenerateActivationCodeCases {

    @Test
    void toGenerateActivationCodeClientModel() {
      RegistrationContext context = RegistrationContext.builder().build();

      String username = context.createCreateUserRequestModel().getUsername();
      ActivationCodeGenerateClientRequest actual = BrokerAuthClientMapper
          .toActivationCodeGenerationClientModel(username);

      ActivationCodeGenerateClientRequest expected = ActivationCodeGenerateClientRequest.builder()
          .username(username)
          .build();

      Assertions.assertEquals(expected, actual);

    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          BrokerAuthClientMapper.toActivationCodeGenerationClientModel(null)
      );
    }
  }
}