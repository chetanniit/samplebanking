package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.google.common.collect.Sets;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BUSINESS_DECLARATION_NOT_CONFIRMED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PRIVACY_POLICY_NOT_ACCEPTED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG;

import static java.lang.Boolean.FALSE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class AgreementsValidationTest extends AbstractValidationTest<Agreements> {

    private static Stream<Arguments> provideArgs() {
        return Stream.of(
                Arguments.of("Valid Agreements", (Consumer<Agreements>) a -> {
                }, EMPTY_SET),
                Arguments.of("Privacy Policy is null", (Consumer<Agreements>) a -> a.setPrivacyPolicy(null), singleton(
                    TestValidationError
                        .create("privacyPolicy", TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Privacy Policy is not accepted", (Consumer<Agreements>) a -> a.setPrivacyPolicy(FALSE), singleton(
                    TestValidationError
                        .create("privacyPolicy", PRIVACY_POLICY_NOT_ACCEPTED_MSG))),
                Arguments.of("All agreements are not accepted", (Consumer<Agreements>) a -> {
                    a.setPrivacyPolicy(FALSE);
                    a.setTermsOfBusiness(FALSE);
                    a.setBusinessDeclaration(FALSE);
                }, Sets.newHashSet(TestValidationError
                    .create("privacyPolicy", PRIVACY_POLICY_NOT_ACCEPTED_MSG), TestValidationError
                    .create("termsOfBusiness", TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG), TestValidationError
                    .create("businessDeclaration", BUSINESS_DECLARATION_NOT_CONFIRMED_MSG)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("provideArgs")
    public void testAgreementsValidations(String testDescription, Consumer<Agreements> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtil::createValidAgreements, mutator, expectedErrorMessages);
    }
}
