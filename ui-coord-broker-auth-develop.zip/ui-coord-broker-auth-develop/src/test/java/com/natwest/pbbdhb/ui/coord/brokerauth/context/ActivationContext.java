package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivateUserRequest;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class ActivationContext {

  public static final String MISSING_SECURITY_ANSWER_REQUEST = "{\"otpCode\":\"12345\",\"username\":\"TestUsername\",\"password\":\"Password123\",\"securityQuestions\":[{\"question\":\"test question?\"}]}";

  @Default
  public String username = "TestUsername";

  @Default
  private String code = "12345";

  @Default
  private String password = "Password123";

  @Default
  private String lastName = "Last Name";

  @Default
  private String email = "test@email.com";

  @Default
  private LocalDate dateOfBirth = LocalDate.of(1980, 1, 1);

  @Default
  private List<SecurityQuestion> securityQuestions = Collections.singletonList(
      SecurityQuestion.builder()
          .question("test question?")
          .answer("test answer").build());

  public ActivationCodeValidateRequestModel createActivationCodeValidateRequestModel() {
    return ActivationCodeValidateRequestModel.builder()
        .username(username)
        .code(code)
        .build();
  }

  public ActivationCodeValidateRequest createActivationCodeValidateRequest() {
    return ActivationCodeValidateRequest.builder()
        .username(username)
        .code(code)
        .build();
  }

  public ActivateUserRequest createUserActivateRequest() {
    return ActivateUserRequest.builder()
        .otpCode(code)
        .password(password)
        .username(username)
        .securityQuestions(securityQuestions)
        .build();
  }

  public ActivateUserRequestModel createActivateUserRequestModel() {
    return ActivateUserRequestModel.builder()
        .otpCode(code)
        .username(username)
        .password(password)
        .securityQuestions(securityQuestions)
        .build();
  }

  public UsernameReminderRequest createUsernameReminderRequest() {
    return UsernameReminderRequest.builder()
            .email(email)
            .lastName(lastName)
            .dateOfBirth(dateOfBirth)
            .build();
  }
}
