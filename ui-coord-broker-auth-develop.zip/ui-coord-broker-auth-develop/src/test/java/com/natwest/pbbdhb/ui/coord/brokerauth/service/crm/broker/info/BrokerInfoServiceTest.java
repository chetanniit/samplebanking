package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.BrokerInfoClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.BrokerInfoContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BrokerInfoServiceTest {

  @Mock
  BrokerInfoClient brokerClient;

  @Nested
  @DisplayName("Broker Info Cases")
  class BrokerInfoCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallBrokerClient() {
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      String username = brokerInfoContext.getUsername();
      BrokerInfoBrokerDomainModel expectedBroker = brokerInfoContext.createBrokerInfoDomainModel();

      BrokerTypeInfoService service = new BrokerTypeInfoService(brokerClient);

      when(brokerClient.getBrokerInfo(username)).thenReturn(expectedBroker);

      service.getBrokerInfo(username);

      verify(brokerClient).getBrokerInfo(username);
    }

    /**
     * Testing service handles response from client.
     */
    @Test
    void shouldReturnResponseFromBrokerClient() {
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      String username = brokerInfoContext.getUsername();
      BrokerInfoBrokerDomainModel expectedBroker = brokerInfoContext.createBrokerInfoDomainModel();

      BrokerTypeInfoService service = new BrokerTypeInfoService(brokerClient);

      when(brokerClient.getBrokerInfo(username)).thenReturn(expectedBroker);

      assertThat(service.getBrokerInfo(username))
          .isEqualTo(expectedBroker);
    }
  }
}