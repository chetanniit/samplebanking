package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ResetPasswordRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.RetrieveChallengeQuestionsRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ValidateOtpRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDate;
import java.util.List;

@Getter
@ToString
@Builder
public class AccountManagementContext {

  @Default
  public String username = "TestUsername";

  @Default
  public String otp = "abc123";

  @Default
  private String password = "Password123";

  @Default
  private String lastName = "Last Name";

  @Default
  private String email = "test@email.com";

  @Default
  private LocalDate dateOfBirth = LocalDate.of(1980, 1, 1);

  @Default
  public UserRegistrationType userType = UserRegistrationType.BROKER;

  public RetrieveChallengeQuestionsRequest createRetrieveQuestionsRequestModel() {
    return RetrieveChallengeQuestionsRequest
        .builder()
        .username(username)
        .build();
  }

  public ValidateSecurityAnswersRequestModel createValidateSecurityAnswersRequestModel() {
    return ValidateSecurityAnswersRequestModel.builder()
        .username(username)
        .securityQuestions(securityAnswers())
        .build();
  }

  public ValidateSecurityAnswersResponseModel createValidateSecurityAnswersResponseModel() {
    return ValidateSecurityAnswersResponseModel.builder()
        .otp(otp)
        .userType(userType)
        .build();
  }

  public List<String> securityQuestions() {
    return Lists.newArrayList(
        "Question 1?",
        "Question 2?",
        "Question 3?",
        "Question 4?",
        "Question 5?"
    );
  }

  public List<SecurityQuestion> securityAnswers() {
    return Lists.newArrayList(
        SecurityQuestion.builder().question("Question 1?").answer("Answer 1").build(),
        SecurityQuestion.builder().question("Question 2?").answer("Answer 2").build()
    );
  }

  public ResetPasswordRequestModel createResetPasswordRequestModel() {
    return ResetPasswordRequestModel.builder()
            .username(username)
            .otpCode(otp)
            .password(password)
            .build();
  }

  public ResetPasswordRequest createResetPasswordRequest() {
    return ResetPasswordRequest.builder()
            .username(username)
            .otpCode(otp)
            .password(password)
            .build();
  }

  public ValidateOtpRequestModel createValidateOtpRequestModel() {
    return ValidateOtpRequestModel.builder()
            .username(username)
            .otpCode(otp)
            .build();
  }

  public ValidateOtpRequest createValidateOtpRequest() {
    return ValidateOtpRequest.builder()
            .username(username)
            .otpCode(otp)
            .build();
  }

  public UsernameReminderRequest createUsernameReminderRequest() {
    return UsernameReminderRequest.builder()
            .lastName(lastName)
            .email(email)
            .dateOfBirth(dateOfBirth)
            .build();
  }
}
