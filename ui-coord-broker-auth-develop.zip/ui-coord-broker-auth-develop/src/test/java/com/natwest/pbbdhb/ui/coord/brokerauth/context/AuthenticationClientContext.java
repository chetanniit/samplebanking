package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain.BrokerPortalAccessTokenClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.AddressInfoModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class AuthenticationClientContext {

    @Default
    private String username = "TestUsername";

    @Default
    private String fcaNumber = "TestFcaNumber";

    @Default
    private AddressInfoModel address = AddressInfoModel.builder()
            .postcode("TestFirmPostcode")
            .line1("Test Address")
            .city("Newcastle")
            .build();

    @Default
    private String accessToken = "XXX.YYY.ZZZ";

    @Default
    private String tokenType = "Bearer";

    @Default
    private int expiresIn = 599;

    public BrokerPortalAccessTokenClientRequest createBrokerAccessTokenClientRequest() {
        return  BrokerPortalAccessTokenClientRequest
                .builder()
                .brokerRole(UserRegistrationType.BROKER)
                .userName(username)
                .fcaNumber(fcaNumber)
                .build();
    }

    public BrokerPortalAccessTokenClientRequest createAdminAccessTokenClientRequest() {
        return BrokerPortalAccessTokenClientRequest
                .builder()
                .brokerRole(UserRegistrationType.ADMIN)
                .userName(username)
                .build();
    }
}
