package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import static com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelperTest.TEST_CLIENT_ID;
import static com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelperTest.TEST_RESOURCE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelperTest.TEST_TENANT_ID;
import static com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelperTest.TEST_URL;
import static java.time.LocalDateTime.now;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.annotation.DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD;

import com.natwest.pbbdhb.ui.coord.brokerauth.exception.AccessTokenNotRefreshedException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

@ActiveProfiles(profiles = { "integration" })
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
    "clients.crm.token.client-id=" + TEST_CLIENT_ID,
    "clients.crm.token.tenant-id=" + TEST_TENANT_ID,
    "clients.crm.token.resource=" + TEST_RESOURCE,
    "clients.crm.token.url="+ TEST_URL
})
@DirtiesContext(classMode = BEFORE_EACH_TEST_METHOD)
class SecurityTokenHelperTest {

    static final String TEST_URL = "http://test-authority.com/";
    static final String TEST_GRANT_TYPE = "client_credentials";
    static final String TEST_CLIENT_ID = "test-client-id";
    static final String TEST_TENANT_ID = "test-tenant-id";
    static final String TEST_RESOURCE = "test-resource";

    private static final String TEST_TOKEN = "test-token";
    private static final String EXPECTED_METHOD_NAME_POST = "POST";

    @MockBean(name = "proxyHttpClient")
    private OkHttpClient mockOkHttpClient;

    @MockBean
    private Call mockCall;

    @Autowired
    private SecurityTokenHelper securityTokenHelper;

    private final Request expectedTokenRequest = new Request.Builder()
            .url(TEST_URL)
            .post(new FormBody.Builder()
                    .add("grant_type", TEST_GRANT_TYPE)
                    .add("client_id", TEST_CLIENT_ID)
                    .add("resource", TEST_RESOURCE)
                    .build())
            .build();

    @Test
    void testGetAccessTokenReturnsNewTokenWhenNoTokenExists() throws IOException {
        Response tokenResponse = createTokenResponse(
                now(ZoneOffset.UTC).plusMinutes(2).toEpochSecond(ZoneOffset.UTC));

        when(this.mockOkHttpClient.newCall(argThat(this::matchRequest))).thenReturn(this.mockCall);
        when(this.mockCall.execute()).thenReturn(tokenResponse);

        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(TEST_TOKEN);
    }

    @Test
    void testGetAccessTokenReturnsSameTokenWhenNotExpiredOneExists() throws IOException {
        Response tokenResponse = createTokenResponse(
                now(ZoneOffset.UTC).plusMinutes(2).toEpochSecond(ZoneOffset.UTC));

        when(this.mockOkHttpClient.newCall(argThat(this::matchRequest))).thenReturn(this.mockCall);
        when(this.mockCall.execute()).thenReturn(tokenResponse);

        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(TEST_TOKEN);

        // Make another call for token - token is not expired
        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(TEST_TOKEN);

        verify(this.mockOkHttpClient).newCall(any(Request.class));
        verifyNoMoreInteractions(this.mockOkHttpClient);
        verify(this.mockCall).execute();
        verifyNoMoreInteractions(this.mockCall);
    }

    @Test
    void testGetAccessTokenReturnsNewTokenWhenExistingOneExpired() throws IOException {
        Response tokenResponse = createTokenResponse(
                now(ZoneOffset.UTC).minusMinutes(2).toEpochSecond(ZoneOffset.UTC));

        when(this.mockOkHttpClient.newCall(argThat(this::matchRequest))).thenReturn(this.mockCall);
        when(this.mockCall.execute()).thenReturn(tokenResponse);

        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(TEST_TOKEN);

        // Make another call for token - token is expired
        String newToken = "new-test-token";
        Response newTokenResponse = createTokenResponse(
                now(ZoneOffset.UTC).plusMinutes(2).toEpochSecond(ZoneOffset.UTC), newToken);

        when(this.mockCall.execute()).thenReturn(newTokenResponse);

        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(newToken);

        verify(this.mockOkHttpClient, times(2)).newCall(any(Request.class));
        verifyNoMoreInteractions(this.mockOkHttpClient);
        verify(this.mockCall, times(2)).execute();
        verifyNoMoreInteractions(this.mockCall);
    }

    @Test
    void testGetAccessTokenReturnsNewTokenWhenExistingOneWillExpireInLessThanAMinute() throws IOException {
        Response tokenResponse = createTokenResponse(
                now(ZoneOffset.UTC).plusSeconds(30).toEpochSecond(ZoneOffset.UTC));

        when(this.mockOkHttpClient.newCall(argThat(this::matchRequest))).thenReturn(this.mockCall);
        when(this.mockCall.execute()).thenReturn(tokenResponse);

        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(TEST_TOKEN);

        // Make another call for token - token is going to expire in less than 1 minute
        String newToken = "new-test-token";
        Response newTokenResponse = createTokenResponse(
                now(ZoneOffset.UTC).plusMinutes(2).toEpochSecond(ZoneOffset.UTC), newToken);

        when(this.mockCall.execute()).thenReturn(newTokenResponse);

        assertThat(this.securityTokenHelper.getAccessToken()).isEqualTo(newToken);

        verify(this.mockOkHttpClient, times(2)).newCall(any(Request.class));
        verifyNoMoreInteractions(this.mockOkHttpClient);
        verify(this.mockCall, times(2)).execute();
        verifyNoMoreInteractions(this.mockCall);
    }

    @Test
    void testGetAccessTokenThrowsExceptionAfterCatchingIOExceptionFromRestCall() throws IOException {
        when(this.mockOkHttpClient.newCall(any())).thenReturn(this.mockCall);
        when(this.mockCall.execute()).thenThrow(new IOException("expected"));

        assertThat(catchThrowable(() -> securityTokenHelper.getAccessToken()))
                .isInstanceOf(AccessTokenNotRefreshedException.class)
                .hasMessage("Problem getting access token: expected");
    }

    private Response createTokenResponse(long expirationMillis) {
        return createTokenResponse(expirationMillis, TEST_TOKEN);
    }

    private Response createTokenResponse(long expirationMillis, String token) {
        Map<String, String> tokenResponseMap = new HashMap<>();
        tokenResponseMap.put("expires_on", Long.toString(expirationMillis));
        tokenResponseMap.put("access_token", token);

        return new Response.Builder()
                .request(this.expectedTokenRequest)
                .protocol(Protocol.HTTP_2)
                .code(HttpURLConnection.HTTP_OK)
                .message("")
                .body(ResponseBody.create(
                        MediaType.get("application/json; charset=utf-8"),
                        JSONObject.toJSONString(tokenResponseMap)
                )).build();
    }

    private boolean matchRequest(Request request) {
        Buffer buffer = new Buffer();
        final String body;
        try {
            Objects.requireNonNull(request.body()).writeTo(buffer);
            body = buffer.readUtf8();
        } catch (IOException e) {
            fail("Error reading request body. Error message: " + e.getMessage());
            return false;
        }
        return TEST_URL.equals(request.url().uri().toString())
                && EXPECTED_METHOD_NAME_POST.equals(request.method())
                && body.contains(String.format("grant_type=%s", TEST_GRANT_TYPE))
                && body.contains(String.format("client_id=%s", TEST_CLIENT_ID))
                && body.contains(String.format("tenant=%s", TEST_TENANT_ID))
                && body.contains(String.format("resource=%s", TEST_RESOURCE))
                && body.contains("client-assertion-type")
                && body.contains("client-assertion");
    }
}