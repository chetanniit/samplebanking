package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info;


import static com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.BrokerEventRestClientTest.FAKE_BROKER_EVENT_ENDPOINT_URL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.event.BrokerEventRestClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventRequestDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelper;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import java.io.IOException;
import java.net.HttpURLConnection;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(properties = {
    "broker-event.createBrokerEventEndpoint=" + FAKE_BROKER_EVENT_ENDPOINT_URL
})
@ActiveProfiles(profiles = {"integration"})
class BrokerEventRestClientTest {

  public static final String FAKE_BROKER_EVENT_ENDPOINT_URL = "https://testBrokerEventEndpoint";
  private static final String BAD_REQUEST_MESSAGE = "Bad Request";
  private static final String IO_ERROR_MESSAGE = "IO Error";

  private static final String TEST_USER_NAME = "jlpicard";

  private static final String TEST_ACCESS_TOKEN = "test-access-token";

  private static final String EMPTY_JSON_BODY = "{}";

  private static final String FAKE_REQUEST_URL = "https://fake-url.com";

  private final Request fakeRequest = new Request.Builder()
      .url(FAKE_REQUEST_URL)
      .build();

  @Value("classpath:test-files/broker-event/create-broker-event-200-success.json")
  private Resource brokerEventSuccess;

  @Value("classpath:test-files/broker-event/create-broker-event-200-failure.json")
  private Resource brokerEventFailure;

  @MockBean(name = "proxyHttpClient")
  private OkHttpClient mockProxyHttpClient;

  @MockBean
  private Call mockServiceCall;

  @MockBean
  private SecurityTokenHelper mockSecurityTokenHelper;

  @Autowired
  private BrokerEventRestClient testee;

  @BeforeEach
  void stubAccessToken() {
    when(this.mockSecurityTokenHelper.getAccessToken()).thenReturn(TEST_ACCESS_TOKEN);
  }

  @AfterEach
  void verifyCalls() throws IOException {
    verify(this.mockProxyHttpClient).newCall(any(Request.class));
    verifyNoMoreInteractions(this.mockProxyHttpClient);
    verify(this.mockServiceCall).execute();
    verifyNoMoreInteractions(this.mockServiceCall);
  }

  @Test
  void testCreateBrokerEventSuccessResponse() throws IOException {

    Response crmResponse = createResponse(HttpURLConnection.HTTP_OK, "",
        TestUtil.readResource(brokerEventSuccess));
    doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
    doReturn(crmResponse).when(this.mockServiceCall).execute();

    BrokerEventResponseDto expectedResponse = new BrokerEventResponseDto();
    expectedResponse.setMessage("Broker Event Request accepted successfully");
    expectedResponse.setSuccess(true);

    BrokerEventRequestDto requestDto = BrokerEventRequestDto.builder().username(TEST_USER_NAME)
        .eventType("4").build();
    BrokerEventResponseDto actualResponse = testee.createBrokerEvent(requestDto);
    assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);

  }

  @Test
  void testCreateBrokerEventNoMatchResponse() throws IOException {

    Response crmResponse = createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(brokerEventFailure));
    doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
    doReturn(crmResponse).when(this.mockServiceCall).execute();

    BrokerEventResponseDto expectedResponse = new BrokerEventResponseDto();
    expectedResponse.setMessage("No Broker or Multiple Broker Records found with the given UserName(" + TEST_USER_NAME + ")");
    expectedResponse.setSuccess(false);

    BrokerEventRequestDto requestDto = BrokerEventRequestDto.builder().username(TEST_USER_NAME)
        .eventType("4").build();
    BrokerEventResponseDto actualResponse = testee.createBrokerEvent(requestDto);
    assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);

  }

  @Test
  void testCreateBrokerEventEmptyBody() throws IOException {
    Response crmResponse = createResponse(HttpURLConnection.HTTP_OK, "", EMPTY_JSON_BODY);
    doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
    doReturn(crmResponse).when(this.mockServiceCall).execute();

    BrokerEventRequestDto requestDto = BrokerEventRequestDto.builder().username(TEST_USER_NAME).eventType("4").build();

    BrokerEventResponseDto expectedResponse = new BrokerEventResponseDto();
    expectedResponse.setSuccess(false);

    assertThat(testee.createBrokerEvent(requestDto)).isEqualTo(expectedResponse);
  }

  @Test
  void testCreateBrokerEventBadResponse() throws IOException {

    Response crmResponse = createResponse(HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE, EMPTY_JSON_BODY);
    doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
    doReturn(crmResponse).when(this.mockServiceCall).execute();

    BrokerEventRequestDto requestDto = BrokerEventRequestDto.builder().username(TEST_USER_NAME)
        .eventType("4").build();

    assertThat(catchThrowable(() -> testee.createBrokerEvent(
        requestDto)))
        .isInstanceOf(CrmEndpointException.class)
        .hasMessage(String.format("Endpoint %s returned %d (%s)", FAKE_BROKER_EVENT_ENDPOINT_URL,
            HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE));

  }


  @Test
  void testCreateBrokerEventIOError() throws IOException {
    doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
    doThrow(new IOException(IO_ERROR_MESSAGE)).when(this.mockServiceCall).execute();

    BrokerEventRequestDto requestDto = BrokerEventRequestDto.builder().username(TEST_USER_NAME).eventType("4").build();

    assertThat(catchThrowable(
        () -> testee.createBrokerEvent(
            requestDto)))
        .isInstanceOf(CrmEndpointException.class)
        .hasMessage(String.format("Endpoint %s request failed %s", FAKE_BROKER_EVENT_ENDPOINT_URL,
            IO_ERROR_MESSAGE));

  }


  private Response createResponse(int responseCode, String message, String jsonResponse) {
    Response.Builder responseBuilder = new Response.Builder()
        .request(fakeRequest)
        .protocol(Protocol.HTTP_2)
        .code(responseCode)
        .message(message);

    if (jsonResponse != null) {
      responseBuilder.body(
          ResponseBody.create(MediaType.get("application/json; charset=utf-8"), jsonResponse));
    }

    return responseBuilder.build();
  }

}


