package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PARAM_FCA_NUMBER;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PARAM_USERNAME;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PATH_FIRM_DETAILS;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PATH_REGISTER_BROKER;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PATH_USERNAME_VERIFICATION;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.readFirmDetailsResponseFromResource;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.readResource;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.natwest.pbbdhb.ui.coord.brokerauth.BrokerAuthenticationApplication;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.config.TestConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import io.restassured.RestAssured;
import java.io.IOException;
import java.util.Collections;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {
        BrokerAuthenticationApplication.class, TestConfig.class
    }
)
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
public class BrokerRegistrationControllerTest {

  private static final String TEST_USERNAME_AVAILABLE = "username_good";
  private static final String TEST_USERNAME_NOT_AVAILABLE = "username_bad";
  private static final String TEST_FCA_NUMBER_EXIST = "1234567";
  private static final String TEST_FCA_NUMBER_NOT_EXIST = "7654321";

  @Value("classpath:test-files/firms/firm-details-response.json")
  private Resource firmDetailsResponse;

  @Value("classpath:test-files/registration/register-broker-valid-request.json")
  private Resource registerBrokerRequestValid;

  @Value("classpath:test-files/registration/register-broker-invalid-request-username-not-available.json")
  private Resource registerBrokerRequestInvalidUsername;

  @LocalServerPort
  private int port;

  @BeforeEach
  public void setUp() {
    RestAssured.port = this.port;
  }

  @AfterEach
  public void cleanUp() {
    RestAssured.port = RestAssured.UNDEFINED_PORT;
  }


  @Test
  public void isUsernameAvailableReturnsOkWhenUsernameNotTaken() {
    with()
        .queryParam(PARAM_USERNAME, TEST_USERNAME_AVAILABLE)
        .get(PATH_USERNAME_VERIFICATION)
        .then()
        .statusCode(HttpStatus.OK.value());
  }

  @Test
  public void isUsernameAvailableReturnsConflictWhenUsernameTaken() {
    with()
        .queryParam(PARAM_USERNAME, TEST_USERNAME_NOT_AVAILABLE)
        .get(PATH_USERNAME_VERIFICATION)
        .then()
        .statusCode(HttpStatus.CONFLICT.value());
  }

  @Test
  public void getFirmDetailsReturnsOkWithFirmDetailsWhenReceivedFromCrm() throws IOException {
    FirmDetailsResponse expectedResponse = readFirmDetailsResponseFromResource(firmDetailsResponse);

    FirmDetailsResponse response = with()
        .queryParam(PARAM_FCA_NUMBER, TEST_FCA_NUMBER_EXIST)
        .get(PATH_FIRM_DETAILS)
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(FirmDetailsResponse.class);

    assertThat(response).usingRecursiveComparison().ignoringCollectionOrder()
        .isEqualTo(expectedResponse);
  }

  @Test
  public void getFirmDetailsReturnsNotFoundWhenFirmNotFoundInCrm() {
    with()
        .queryParam(PARAM_FCA_NUMBER, TEST_FCA_NUMBER_NOT_EXIST)
        .get(PATH_FIRM_DETAILS)
        .then()
        .statusCode(HttpStatus.NOT_FOUND.value());
  }

  @Test
  public void registerBrokerReturnsAcceptedWhenRegistrationAcceptedByCrm() throws IOException {
    String request = readResource(registerBrokerRequestValid);

    with()
        .body(request)
        .contentType(APPLICATION_JSON_VALUE)
        .post(PATH_REGISTER_BROKER)
        .then()
        .statusCode(HttpStatus.ACCEPTED.value());
  }

  @Test
  public void registerBrokerReturnsBadRequestWhenUsernameIsTakenAndRegistrationIsRejectedByCrm()
      throws IOException {
    String request = readResource(registerBrokerRequestInvalidUsername);

    ErrorResponse errorResponse = with()
        .body(request)
        .contentType(APPLICATION_JSON_VALUE)
        .post(PATH_REGISTER_BROKER)
        .then()
        .statusCode(HttpStatus.BAD_REQUEST.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(ErrorResponse.class);

    assertThat(errorResponse).usingRecursiveComparison().ignoringCollectionOrder()
        .isEqualTo(ErrorResponse.invalidDetails(new ValidationErrorResponse(
            Collections.singleton(new Violation("username", "This username is already in use, please choose another")))));
  }

}
