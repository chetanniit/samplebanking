package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Collections;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;


import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.APPOINTED_REPRESENTATIVE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.DIRECTLY_AUTHORISED;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.USERNAME_INVALID_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_EMPTY_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;

import static java.lang.Boolean.FALSE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

public class BrokerRegistrationValidationTest extends AbstractValidationTest<BrokerRegistration> {

    private static Stream<Arguments> provideArgs() {
        return Stream.of(
                Arguments.of("Valid broker registration", (Consumer<BrokerRegistration>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid broker registration for Directly authorised and null principal FCA number", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(DIRECTLY_AUTHORISED.value());
                    a.getFirmDetails().setPrincipalFcaNumber(null);
                }, EMPTY_SET),
                Arguments.of("Valid broker registration with previous firm name and fca number not provided", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setPreviousFirmName(null);
                    a.getFirmDetails().setPreviousFcaNumber(null);
                }, EMPTY_SET),
                Arguments.of("Broker details is null", (Consumer<BrokerRegistration>) a -> a.setBrokerDetails(null), singleton(
                    TestValidationError
                        .create("brokerDetails", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Agreements is null", (Consumer<BrokerRegistration>) a -> a.setAgreements(null), singleton(
                    TestValidationError.create("agreements", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Address is null", (Consumer<BrokerRegistration>) a -> a.setAddress(null), singleton(
                    TestValidationError.create("address", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Username is null", (Consumer<BrokerRegistration>) a -> a.setUsername(null), singleton(
                    TestValidationError.create("username", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Payment paths is null", (Consumer<BrokerRegistration>) a -> a.setPaymentPaths(null), singleton(
                    TestValidationError
                        .create("paymentPaths", MUST_NOT_BE_EMPTY_ERROR_MESSAGE))),
                Arguments.of("Payment paths is empty", (Consumer<BrokerRegistration>) a -> a.setPaymentPaths(Collections.emptyList()), singleton(
                    TestValidationError
                        .create("paymentPaths", MUST_NOT_BE_EMPTY_ERROR_MESSAGE))),
                Arguments.of("Firm details is null", (Consumer<BrokerRegistration>) a -> a.setFirmDetails(null), singleton(
                    TestValidationError
                        .create("firmDetails", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Principal FCA number is null for Appointed representative", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(APPOINTED_REPRESENTATIVE.value());
                    a.getFirmDetails().setPrincipalFcaNumber(null);
                }, singleton(TestValidationError
                    .create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Principal FCA number is blank for Appointed representative", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(APPOINTED_REPRESENTATIVE.value());
                    a.getFirmDetails().setPrincipalFcaNumber("");
                }, singleton(TestValidationError
                    .create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Principal FCA number is blank for Directly authorised", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(DIRECTLY_AUTHORISED.value());
                    a.getFirmDetails().setPrincipalFcaNumber("");
                }, singleton(TestValidationError
                    .create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Principal FCA number is provided for Directly authorised", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(DIRECTLY_AUTHORISED.value());
                    a.getFirmDetails().setPrincipalFcaNumber("test-fca-number");
                }, singleton(TestValidationError
                    .create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Previous firm name provided but previous FCA number not", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setPreviousFirmName("test-firm-name");
                    a.getFirmDetails().setPreviousFcaNumber(null);
                }, singleton(TestValidationError
                    .create("firmDetails", PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Previous FCA number provided but previous firm name not", (Consumer<BrokerRegistration>) a -> {
                    a.getFirmDetails().setPreviousFcaNumber("test-fca-number");
                    a.getFirmDetails().setPreviousFirmName(null);
                }, singleton(TestValidationError
                    .create("firmDetails", PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("@Valid annotation - error when agreements invalid", (Consumer<BrokerRegistration>) a -> a.getAgreements().setTermsOfBusiness(FALSE), singleton(
                    TestValidationError
                        .create("agreements.termsOfBusiness", TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG))),
                Arguments.of("@Valid annotation - error when address details invalid", (Consumer<BrokerRegistration>) a -> a.getAddress().setPostcode(null), singleton(
                    TestValidationError
                        .create("address.postcode", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("@Valid annotation - error when firm details invalid", (Consumer<BrokerRegistration>) a -> a.getFirmDetails().setFirmName(null), singleton(
                    TestValidationError
                        .create("firmDetails.firmName", MUST_NOT_BE_BLANK_ERROR_MESSAGE)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("provideArgs")
    public void testBrokerRegistrationValidations(String testDescription, Consumer<BrokerRegistration> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtil::createValidBrokerRegistration, mutator, expectedErrorMessages);
    }

}
