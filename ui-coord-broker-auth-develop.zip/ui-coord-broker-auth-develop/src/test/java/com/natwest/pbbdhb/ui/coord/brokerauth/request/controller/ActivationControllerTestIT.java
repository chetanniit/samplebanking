package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ActivationCodeException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.activation.ActivationService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * In this test, the full Spring app context is started, but with the service layer mocked.
 */
@ActiveProfiles(profiles = {"integration", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ActivationControllerTestIT {

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  @MockBean
  ActivationService activationService;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @LocalServerPort
  int port;

  @Value("${server.servlet.context-path}")
  String contextPath;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder
        .fromPath(contextPath)
        .pathSegment("activation")
        .build()
        .getPath();
    return RestAssured
        .given().log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Activate Cases")
  class ActivateCases {

    @Test
    void shouldCallServiceWithRequestModels() {
      ActivationContext activationContext = ActivationContext.builder().build();

      givenRequestToController()
          .body(objectMapper.valueToTree(activationContext.createActivateUserRequestModel()))
          .contentType(ContentType.JSON)
          .post("")
          .then()
          .log().all();

      Mockito.verify(activationService, Mockito.times(1))
          .activateUser(activationContext.createActivateUserRequestModel());
    }

    @Test
    void shouldReturnErrorIfPasswordIsInvalid() {
      doThrow(new InvalidDetailsException("Password was Invalid"))
          .when(activationService).activateUser(any());

      ActivationContext activationContext = ActivationContext.builder().build();

      givenRequestToController()
          .body(objectMapper.valueToTree(activationContext.createActivateUserRequestModel()))
          .contentType(ContentType.JSON)
          .post("")
          .then()
          .log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnBadRequestIfSecurityQuestionHasNullAnswer() {
      List<SecurityQuestion> questionWithoutAnswer = Collections.singletonList(
          SecurityQuestion.builder()
              .question("test question?")
              .build());

      ActivateUserRequest request = ActivationContext.builder()
          .securityQuestions(questionWithoutAnswer)
          .build()
          .createUserActivateRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnBadRequestIfSecurityQuestionHasBlankAnswer() {
      List<SecurityQuestion> questionWithoutAnswer = Collections.singletonList(
          SecurityQuestion.builder()
              .question("test question?")
              .answer("            ")
              .build());

      ActivateUserRequest request = ActivationContext.builder()
          .securityQuestions(questionWithoutAnswer)
          .build()
          .createUserActivateRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnBadRequestIfSecurityQuestionHasNoAnswer() {
      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(ActivationContext.MISSING_SECURITY_ANSWER_REQUEST)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnErrorIfActivationCodeIsExpired() {
      doThrow(new ActivationCodeException(ErrorCode.OTP_EXPIRED,
          "Activation Code is expired"))
          .when(activationService)
          .activateUser(any());

      ActivationContext activationContext = ActivationContext.builder().build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(activationContext.createActivateUserRequestModel()))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("OTP_EXPIRED"));
    }

    @Test
    void shouldReturnErrorIfUsernameOrActivationCodeIsInvalid() {
      doThrow(new ActivationCodeException(ErrorCode.INVALID_CREDENTIALS,
          "Invalid Username or Activation Code"))
          .when(activationService)
          .activateUser(any());

      ActivationContext activationContext = ActivationContext.builder().build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(activationContext.createActivateUserRequestModel()))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("INVALID_CREDENTIALS"));
    }

    @Test
    void shouldReturnErrorIfAccountIsLocked() {
      doThrow(new ActivationCodeException(ErrorCode.ACCOUNT_LOCKED,
          "Activation Code is expired"))
          .when(activationService)
          .activateUser(any());

      ActivationContext activationContext = ActivationContext.builder().build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(activationContext.createActivateUserRequestModel()))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("ACCOUNT_LOCKED"));
    }

    @Test
    void shouldReturnErrorIfActivationCodeValidationIsFailed() {
      doThrow(new ActivationCodeException(ErrorCode.OTP_VALIDATION_FAILED,
          "Activation Code validation is failed"))
          .when(activationService)
          .activateUser(any());

      ActivationContext activationContext = ActivationContext.builder().build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(activationContext.createActivateUserRequestModel()))
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("OTP_VALIDATION_FAILED"));
    }
  }

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    @Test
    void shouldCallService() {
      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then()
          .log()
          .all();

      Mockito.verify(activationService).validateActivationCode(any());
    }

    @Test
    void shouldReturnErrorIfServiceReturnsError() {
      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(activationService)
          .validateActivationCode(any());

      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void shouldReturnErrorIfInvalidRequestBody() {

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(new JSONObject().toString())
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnErrorIfUsernameOrActivationCodeIsInvalid() {
      doThrow(new ActivationCodeException(ErrorCode.INVALID_CREDENTIALS,
          "Invalid Username or Activation Code"))
          .when(activationService)
          .validateActivationCode(any());

      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("INVALID_CREDENTIALS"));
    }

    @Test
    void shouldReturnErrorIfActivationCodeIsExpired() {
      doThrow(new ActivationCodeException(ErrorCode.OTP_EXPIRED,
          "Activation Code is expired"))
          .when(activationService)
          .validateActivationCode(any());

      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("OTP_EXPIRED"));
    }

    @Test
    void shouldReturnErrorIfActivationCodeIsFailed() {
      doThrow(new ActivationCodeException(ErrorCode.OTP_VALIDATION_FAILED,
          "Activation Code validation is failed"))
          .when(activationService)
          .validateActivationCode(any());

      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("OTP_VALIDATION_FAILED"));
    }

    @Test
    void shouldReturnErrorIfAccountIsLocked() {
      doThrow(new ActivationCodeException(ErrorCode.ACCOUNT_LOCKED,
          "Account is locked"))
          .when(activationService)
          .validateActivationCode(any());

      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("ACCOUNT_LOCKED"));
    }
  }
}