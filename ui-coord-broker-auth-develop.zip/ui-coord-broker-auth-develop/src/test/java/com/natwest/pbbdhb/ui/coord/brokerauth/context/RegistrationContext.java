package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivationCodeClientResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.CreateUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.DeleteUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.ReactivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.CreateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.DeleteUserRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class RegistrationContext {

  @Default
  private String firstname = "Alice";

  @Default
  private String lastname = "Smith";

  @Default
  private String email = "asmith@aol.com";

  @Default
  private String username = "asmith";

  @Default
  private String code = "123456";

  @Default
  private String reactivationCode = "abc123";

  @Default
  private UserRegistrationType brokerType = UserRegistrationType.BROKER;

  public CreateUserRequest createCreateUserRequest() {
    return CreateUserRequest.builder()
        .firstName(firstname)
        .lastName(lastname)
        .email(email)
        .username(username)
        .userType(brokerType)
        .build();
  }

  public CreateUserRequestModel createCreateUserRequestModel() {
    return CreateUserRequestModel.builder()
        .firstname(firstname)
        .lastname(lastname)
        .email(email)
        .username(username)
        .brokerType(brokerType)
        .build();
  }

  public CreateUserClientRequest createCreateUserClientRequest() {
    return CreateUserClientRequest.builder()
        .firstname(firstname)
        .lastname(lastname)
        .email(email)
        .username(username)
        .brokerType(brokerType)
        .build();
  }

  public ActivationCodeClientResponse createActivationCodeClientResponse() {
    return ActivationCodeClientResponse.builder()
        .code(code)
        .build();
  }

  public DeleteUserRequest createDeleteUserRequest() {
    return DeleteUserRequest.builder()
            .username(username)
            .build();
  }

  public DeleteUserRequestModel createDeleteUserRequestModel() {
    return DeleteUserRequestModel.builder()
            .username(username)
            .build();
  }

  public DeleteUserClientRequest createDeleteUserClientRequest() {
    return DeleteUserClientRequest.builder()
            .username(username)
            .build();
  }

  public ReactivateUserRequest createReactivateUserRequestModel() {
    return ReactivateUserRequest.builder()
        .username(username)
        .firstName(firstname)
        .lastName(lastname)
        .email(email)
        .build();
  }
}
