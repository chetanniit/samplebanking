package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.RegistrationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.CreateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.DeleteUserRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class RegistrationRequestMapperTest {

  @Nested
  @DisplayName("Create User Registration Cases")
  class CreateUserRegistrationCases {

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          RegistrationRequestMapper.toDomainModel((CreateUserRequest) null)
      );
    }

    @Test
    void shouldMapToDomainModel() {

      RegistrationContext registrationContext = RegistrationContext.builder().build();

      CreateUserRequest request = registrationContext.createCreateUserRequest();

      CreateUserRequestModel requestModel = RegistrationRequestMapper.toDomainModel(
          request);

      Assertions.assertEquals(requestModel.getUsername(), request.getUsername());
      Assertions.assertEquals(requestModel.getFirstname(), request.getFirstName());
      Assertions.assertEquals(requestModel.getLastname(), request.getLastName());
      Assertions.assertEquals(requestModel.getEmail(), request.getEmail());
      Assertions.assertEquals(requestModel.getBrokerType(), request.getUserType());
    }
  }

  @Nested
  @DisplayName("Delete User Registration Cases")
  class DeleteUserRegistrationCases {

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          RegistrationRequestMapper.toDomainModel((DeleteUserRequest) null)
      );
    }

    @Test
    void shouldMapToDomainModel() {

      RegistrationContext registrationContext = RegistrationContext.builder().build();

      DeleteUserRequest request = registrationContext.createDeleteUserRequest();

      DeleteUserRequestModel requestModel = RegistrationRequestMapper.toDomainModel(
          request);

      Assertions.assertEquals(requestModel.getUsername(), request.getUsername());
    }
  }
}