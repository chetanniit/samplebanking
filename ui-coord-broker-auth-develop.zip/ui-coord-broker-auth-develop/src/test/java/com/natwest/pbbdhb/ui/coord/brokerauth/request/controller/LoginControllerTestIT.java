package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccessTokenContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.BrokerInfoContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.LoginContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper.LoginRequestMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info.AdminTypeInfoService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info.BrokerTypeInfoService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.login.LoginService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.token.TokenService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * In this test, the full Spring app context is started, but with the service layer mocked.
 */
@ActiveProfiles(profiles = {"integration", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class LoginControllerTestIT {

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  @MockBean
  LoginService loginService;

  @MockBean
  TokenService tokenService;

  @MockBean
  BrokerTypeInfoService brokerService;

  @MockBean
  AdminTypeInfoService adminService;

  @LocalServerPort
  int port;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Value("${server.servlet.context-path}")
  private String contextPath;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("login")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    /**
     * Testing happy path call to controller for broker and verifying service is called.
     */
    @Test
    void shouldCallBrokerServicesWithRequestModels() {

      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.BROKER);

      when(brokerService.getBrokerInfo("TestUsername"))
          .thenReturn(brokerInfoContext.createBrokerInfoDomainModel());

      when(tokenService.retrieveAccessToken(
          accessTokenContext.createBrokerAccessTokenRequestModel()))
          .thenReturn(accessTokenContext.createBrokerPortalAccessTokenResponseModel());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .body(request)
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all();

      Mockito.verify(loginService, times(1)).login(any());
      Mockito.verify(brokerService, times(1))
          .getBrokerInfo("TestUsername");
      Mockito.verify(adminService, times(0))
          .getBrokerInfo("TestUsername");
      Mockito.verify(tokenService, times(1))
          .retrieveAccessToken(any());
    }

    /**
     * Testing happy path call to controller for broker admin and verifying service is called.
     */
    @Test
    void shouldCallAdminServicesWithRequestModels() {
      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.ADMIN);

      when(adminService.getBrokerInfo("TestUsername"))
          .thenReturn(brokerInfoContext.createBrokerInfoDomainModel());

      when(
          tokenService.retrieveAccessToken(accessTokenContext.createAdminAccessTokenRequestModel()))
          .thenReturn(accessTokenContext.createBrokerPortalAccessTokenResponseModel());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .body(request)
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all();

      Mockito.verify(loginService, times(1)).login(any());
      Mockito.verify(brokerService, times(0))
          .getBrokerInfo("TestUsername");
      Mockito.verify(adminService, times(1))
          .getBrokerInfo("TestUsername");
      Mockito.verify(tokenService, times(1))
          .retrieveAccessToken(any());
    }

    /**
     * Testing happy path call to controller for broker and verify response.
     */
    @Test
    void shouldReturnTokenWithValidLoginForBroker() {
      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.BROKER);

      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      when(brokerService.getBrokerInfo("TestUsername"))
          .thenReturn(brokerInfoContext.createBrokerInfoDomainModel());

      when(tokenService.retrieveAccessToken(any()))
          .thenReturn(
              accessTokenContext.createBrokerPortalAccessTokenResponseModel()
          );

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .body(request)
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.OK.value())
          .body("accessToken", is("XXX.YYY.ZZZ"))
          .body("tokenType", is("Bearer"))
          .body("expiresIn", is(599));

      Mockito.verify(loginService, times(1)).login(any());
      Mockito.verify(brokerService, times(1))
          .getBrokerInfo("TestUsername");
      Mockito.verify(adminService, times(0))
          .getBrokerInfo("TestUsername");
      Mockito.verify(tokenService, times(1))
          .retrieveAccessToken(
              LoginRequestMapper.toDomainModel("TestUsername", UserRegistrationType.BROKER, "TestFcaNumber"));
    }

    @Test
    void shouldReturnTokenWithValidLoginForBrokerUsingUsernameCasingFromCRM() {
      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.BROKER);

      AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      when(brokerService.getBrokerInfo("tESTuserNAMe"))
          .thenReturn(brokerInfoContext.createBrokerInfoDomainModel());

      when(tokenService.retrieveAccessToken(any()))
          .thenReturn(
              accessTokenContext.createBrokerPortalAccessTokenResponseModel()
          );

      LoginRequest request = LoginContext.builder().username("tESTuserNAMe").build().createLoginRequest();

      givenRequestToController()
          .body(request)
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.OK.value())
          .body("accessToken", is("XXX.YYY.ZZZ"))
          .body("tokenType", is("Bearer"))
          .body("expiresIn", is(599));

      Mockito.verify(loginService, times(1)).login(any());
      Mockito.verify(brokerService, times(1))
          .getBrokerInfo("tESTuserNAMe");
      Mockito.verify(adminService, times(0))
          .getBrokerInfo("tESTuserNAMe");
      Mockito.verify(tokenService, times(1))
          .retrieveAccessToken(
              LoginRequestMapper.toDomainModel("TestUsername", UserRegistrationType.BROKER, "TestFcaNumber"));
    }

    /**
     * Testing happy path call to controller for broker admin and verify response.
     */
    @Test
    void shouldReturnTokenWithValidLoginForAdmin() {
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.ADMIN);

      when(adminService.getBrokerInfo("TestUsername"))
          .thenReturn(brokerInfoContext.createBrokerInfoDomainModel());

      when(tokenService.retrieveAccessToken(any()))
          .thenReturn(
              BrokerPortalAccessTokenResponseModel.builder()
                  .accessToken("XXX.YYY.ZZZ")
                  .tokenType("Bearer")
                  .expiresIn(599)
                  .build()
          );

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .body(request)
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.OK.value())
          .body("accessToken", is("XXX.YYY.ZZZ"))
          .body("tokenType", is("Bearer"))
          .body("expiresIn", is(599));

      Mockito.verify(loginService, times(1)).login(any());
      Mockito.verify(brokerService, times(0))
          .getBrokerInfo("TestUsername");
      Mockito.verify(adminService, times(1))
          .getBrokerInfo("TestUsername");
      Mockito.verify(tokenService, times(1))
          .retrieveAccessToken(
              LoginRequestMapper.toDomainModel("TestUsername", UserRegistrationType.ADMIN, "TestFcaNumber"));
    }

    @Test
    void shouldReturnTokenWithValidLoginForAdminUsingUsernameCasingFromCRM() {
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();

      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.ADMIN);

      when(adminService.getBrokerInfo("tESTuserNAMe"))
          .thenReturn(brokerInfoContext.createBrokerInfoDomainModel());

      when(tokenService.retrieveAccessToken(any()))
          .thenReturn(
              BrokerPortalAccessTokenResponseModel.builder()
                  .accessToken("XXX.YYY.ZZZ")
                  .tokenType("Bearer")
                  .expiresIn(599)
                  .build()
          );

      LoginRequest request = LoginContext.builder().username("tESTuserNAMe").build().createLoginRequest();

      givenRequestToController()
          .body(request)
          .contentType(ContentType.JSON)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.OK.value())
          .body("accessToken", is("XXX.YYY.ZZZ"))
          .body("tokenType", is("Bearer"))
          .body("expiresIn", is(599));

      Mockito.verify(loginService, times(1)).login(any());
      Mockito.verify(brokerService, times(0))
          .getBrokerInfo("tESTuserNAMe");
      Mockito.verify(adminService, times(1))
          .getBrokerInfo("tESTuserNAMe");
      Mockito.verify(tokenService, times(1))
          .retrieveAccessToken(
              LoginRequestMapper.toDomainModel("TestUsername", UserRegistrationType.ADMIN, "TestFcaNumber"));
    }

    @Test
    void shouldReturnErrorIfServiceReturnsError() {
      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(loginService)
          .login(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void shouldReturnErrorIfInvalidRequestBody() {

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(new JSONObject().toString())
          .then().log().all()
          .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailedDueToInvalidCredentials() {
      doThrow(new LoginFailedException("Failed to login"))
          .when(loginService)
          .login(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value());
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailedDueToAccountLocked() {
      doThrow(new AccountLockedException("Failed to login"))
              .when(loginService)
              .login(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
              .contentType(ContentType.JSON)
              .body(request)
              .then().log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body("code", is(ErrorCode.ACCOUNT_LOCKED.toString()));
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailedDueToExpiredPassword() {
      doThrow(new PasswordExpiredException("Failed to login"))
              .when(loginService)
              .login(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
              .contentType(ContentType.JSON)
              .body(request)
              .then().log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body("code", is(ErrorCode.PASSWORD_EXPIRED.toString()));
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailed() {
      doThrow(new UnauthorisedException(ErrorCode.UNAUTHORISED, "Failed to login"))
          .when(loginService)
          .login(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value());
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailedDueToCRMDataExceptionForbroker() {
      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.BROKER);
      doThrow(new CrmDataException("Failed to login"))
          .when(brokerService)
          .getBrokerInfo(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", is(ErrorCode.UNAUTHORISED.toString()));
    }

    @Test
    void shouldReturnUnauthorisedIfLoginFailedDueToCRMDataExceptionForAdmin() {
      when(loginService.login(any()))
          .thenReturn(UserRegistrationType.ADMIN);
      doThrow(new CrmDataException("Failed to login"))
          .when(adminService)
          .getBrokerInfo(any());

      LoginRequest request = LoginContext.builder().build().createLoginRequest();

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", is(ErrorCode.UNAUTHORISED.toString()));
    }
  }
}