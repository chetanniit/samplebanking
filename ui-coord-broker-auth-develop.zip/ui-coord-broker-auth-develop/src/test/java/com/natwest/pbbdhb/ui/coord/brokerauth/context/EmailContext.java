package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailAccountRecoveryModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailActivationCodeRequestModel;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class EmailContext {

  @Default
  private String templateName = "test template name";

  @Default
  private String firstname = "testFirstname";

  @Default
  public String surname = "testSurname";

  @Default
  public String toRecipients = "test@recipient.com";
  @Default
  private String registrationUrl = "testRegistrationUrl";

  @Default
  public String activationCode = "testActivationCode";

  @Default
  public String accountRecoveryUrl = "testAccountRecoveryUrl";

  @Default
  public String oneTimePasscode = "testOneTimePasscode";

  @Default
  public String supportNumber = "0123456789";

  public EmailActivationCodeRequestModel createEmailRequestModel() {
    return EmailActivationCodeRequestModel.builder()
        .templateName(templateName)
        .firstname(firstname)
        .surname(surname)
        .toRecipients(toRecipients)
        .registrationUrl(registrationUrl)
        .activationCode(activationCode)
        .build();
  }

  public EmailAccountRecoveryModel createEmailAccountRecoveryModel() {
    return EmailAccountRecoveryModel.builder()
        .templateName(templateName)
        .firstname(firstname)
        .surname(surname)
        .toRecipients(toRecipients)
        .accountRecoveryUrl(accountRecoveryUrl)
        .oneTimePasscode(oneTimePasscode)
        .supportNumber(supportNumber)
        .build();
  }
}
