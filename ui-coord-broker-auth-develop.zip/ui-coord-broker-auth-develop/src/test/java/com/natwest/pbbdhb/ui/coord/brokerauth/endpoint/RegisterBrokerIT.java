package com.natwest.pbbdhb.ui.coord.brokerauth.endpoint;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidBrokerRegistration;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidBrokerRegistrationJson;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.newRandomUserName;
import static io.restassured.RestAssured.with;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("local")
@Disabled
public class RegisterBrokerIT {

    //Tests disabled for teamcity integration build. Run these locally.

    @LocalServerPort
    private int port;

    private final String contextPath = "/mortgages/v1/ui-broker-auth";
    private final String endpoint = contextPath + ApplicationConstants.PATH_REGISTER_BROKER;

    @BeforeEach
    public void setUp() {
        RestAssured.port = this.port;
    }

    @Test
    public void postResponseStatusIsAccepted() throws Exception {
        String okUsername = newRandomUserName();
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setUsername(okUsername);
        String body = createValidBrokerRegistrationJson(brokerRegistration);

        int statusCode = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint)
                .getStatusCode();

        assertEquals(HttpStatus.ACCEPTED.value(), statusCode);
    }

    @Test
    public void postWithPlainTextBodyResponseStatusIsUnsupportedMediaType() {
        String body = "plain text";
        int statusCode = with()
                .contentType(ContentType.TEXT)
                .body(body)
                .post(endpoint)
                .getStatusCode();

        assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value(), statusCode);
    }

    @Test
    public void postWithInvalidJsonResponseStatusIsBadRequest() {
        String body = "{invalid json}";
        int statusCode = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint)
                .getStatusCode();

        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
    }

    @Test
    public void invalidateAgreementsAndConfirmExceptionIsReturned() throws JsonProcessingException {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();

        String body = createValidBrokerRegistrationJson(brokerRegistration);
        body = body.replace("\"termsOfBusiness\":true,", "");
        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("termsOfBusiness") && response.getBody().asString().contains("must not be null"));

        body = createValidBrokerRegistrationJson(brokerRegistration);
        body = body.replace(",\"businessDeclaration\":true", "");
        response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("businessDeclaration") && response.getBody().asString().contains("must not be null"));
    }

    @Test
    public void invalidateFirstNamesAndConfirmExceptionIsReturned() throws JsonProcessingException {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        String body = createValidBrokerRegistrationJson(brokerRegistration);
        body = body.replace("\"firstNames\":\"James Tiberius\",", "");

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("brokerDetails.firstNames") && response.getBody().asString().contains("must not be blank"));
    }

    @Test
    public void usernameTooShortExceptionIsReturned() throws JsonProcessingException {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setUsername("short");
        String body = createValidBrokerRegistrationJson(brokerRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("username") && response.getBody().asString().contains("Username must be at least 6 characters"));
    }

    @Test
    public void usernameMustStartWithLetterOrNumberExceptionIsReturned() throws JsonProcessingException {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setUsername("_invalid");
        String body = createValidBrokerRegistrationJson(brokerRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("username") && response.getBody().asString().contains("Username must start with a letter or a number"));
    }

    @Test
    public void usernameMustContainNoSpecialCharacterExceptionIsReturned() throws JsonProcessingException {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setUsername("inval!id");
        String body = createValidBrokerRegistrationJson(brokerRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("username") && response.getBody().asString().contains("Username must contain no special characters other than '. - _'"));
    }
}
