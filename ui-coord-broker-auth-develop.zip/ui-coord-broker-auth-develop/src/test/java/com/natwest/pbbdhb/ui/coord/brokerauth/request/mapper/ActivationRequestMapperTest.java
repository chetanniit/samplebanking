package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivationCodeValidateRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class ActivationRequestMapperTest {

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    @Test
    void toDomainModel() {
      ActivationCodeValidateRequest requestModel = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      ActivationCodeValidateRequestModel clientModel = ActivationRequestMapper.toDomainModel(
          requestModel);

      assertEquals(clientModel.getUsername(), requestModel.getUsername());
      assertEquals(clientModel.getCode(), requestModel.getCode());
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toDomainModel((ActivationCodeValidateRequest) null)
      );
    }
  }

  @Nested
  @DisplayName("Activate Cases")
  class ActivateCases {

    @Test
    void shouldMapToDomainModel() {

      ActivationContext activationContext = ActivationContext.builder().build();

      ActivateUserRequest request = activationContext.createUserActivateRequest();

      ActivateUserRequestModel requestModel = ActivationRequestMapper.toDomainModel(
          request);

      assertEquals(requestModel.getUsername(), request.getUsername());
      assertEquals(requestModel.getPassword(), request.getPassword());
      assertEquals(requestModel.getOtpCode(), request.getOtpCode());
      assertEquals(requestModel.getSecurityQuestions(), request.getSecurityQuestions());
    }

    /**
     * Testing error case when trying to map over a null reference.
     */
    @SuppressWarnings("ConstantConditions")
    @Test
    void throwsExceptionWhenSuppliedNull() {
      Assertions.assertThrows(RuntimeException.class, () ->
          ActivationRequestMapper.toDomainModel((ActivateUserRequest) null)
      );
    }
  }
}