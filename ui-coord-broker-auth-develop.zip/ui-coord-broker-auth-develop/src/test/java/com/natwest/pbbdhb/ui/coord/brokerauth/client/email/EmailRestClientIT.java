package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

import static org.mockito.Mockito.when;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.EmailContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.Brand;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.security.UserClaimsProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"integration"})
@AutoConfigureWireMock(port = 0)
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
@DirtiesContext
public class EmailRestClientIT {

  @Autowired
  EmailRestClient restClient;

  @MockBean
  UserClaimsProvider userClaimsProvider;

  @BeforeEach
  public void setup() {
    when(userClaimsProvider.getOperatingBrand()).thenReturn(Brand.NWB);
  }

  @Nested
  @DisplayName("Email cases")
  class EmailCases {

    @Test
    void shouldSendEmail() {
      EmailContext emailContext = EmailContext.builder().build();

      WireMock.stubFor(EmailWireMockServer.mappingEmailRequest()
          .willReturn(EmailWireMockServer.jsonResponse(HttpStatus.OK)));

      restClient.send(emailContext.createEmailRequestModel());

      WireMock.verify(WireMock.exactly(1),
          EmailWireMockServer.patternForEmailRequest());
    }
  }
}
