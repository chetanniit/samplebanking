package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.event;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.event.BrokerEventClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BrokerEventServiceTest {

  BrokerEventService testee;
  BrokerEventClient brokerEventRestClient = mock(BrokerEventClient.class);

  private static final String TEST_USER = "TEST-USER";

  @BeforeEach
  void setUp() {
    testee = new BrokerEventService(brokerEventRestClient);
  }


  @Test
  void createBrokerActivationEventWhenClientCallReturnsSuccess() {

    BrokerEventResponseDto clientResponse = new BrokerEventResponseDto();
    clientResponse.setSuccess(true);
    when(brokerEventRestClient.createBrokerEvent(any())).thenReturn(clientResponse);

    assertTrue(testee.createBrokerActivationEvent(TEST_USER));

  }

  @Test
  void createBrokerActivationEventWhenClientCallReturnsFailure() {

    BrokerEventResponseDto clientResponse = new BrokerEventResponseDto();
    clientResponse.setSuccess(false);
    when(brokerEventRestClient.createBrokerEvent(any())).thenReturn(clientResponse);

    assertFalse(testee.createBrokerActivationEvent(TEST_USER));

  }

  @Test
  void createBrokerActivationEventReturnsFalseAndDoesNotThrowExceptionWhenClientThrowsCRMException() {

    BrokerEventResponseDto clientResponse = new BrokerEventResponseDto();
    clientResponse.setSuccess(false);
    when(brokerEventRestClient.createBrokerEvent(any())).thenThrow(new CrmEndpointException("crm call failed"));

    assertFalse(testee.createBrokerActivationEvent(TEST_USER));

  }

  @Test
  void createBrokerActivationEventReturnsFalseAndDoesNotThrowExceptionWhenClientThrowsException() {

    BrokerEventResponseDto clientResponse = new BrokerEventResponseDto();
    clientResponse.setSuccess(false);

    when(brokerEventRestClient.createBrokerEvent(any())).thenThrow(new RuntimeException("some random exception"));

    assertFalse(testee.createBrokerActivationEvent(TEST_USER));

  }

}