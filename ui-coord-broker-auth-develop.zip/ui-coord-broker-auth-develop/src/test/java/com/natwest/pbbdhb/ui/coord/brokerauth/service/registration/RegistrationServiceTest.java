package com.natwest.pbbdhb.ui.coord.brokerauth.service.registration;


import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.RegistrationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class    RegistrationServiceTest {

  @Mock
  BrokerAuthClient brokerAuthClient;

  @Test
  void shouldCallRegistrationClient() {
    CreateUserRequestModel createUserRequestModel = RegistrationContext.builder().build()
        .createCreateUserRequestModel();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    service.createUser(createUserRequestModel);

    verify(brokerAuthClient, times(1)).createUser(createUserRequestModel);
    verify(brokerAuthClient, times(1)).generateActivationCode(createUserRequestModel.getUsername());
  }

  @Test
  void shouldReturnActivationCode() {
    RegistrationContext context = RegistrationContext.builder().build();
    CreateUserRequestModel createUserRequestModel = context.createCreateUserRequestModel();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    when(brokerAuthClient.generateActivationCode(context.getUsername()))
        .thenReturn(context.createActivationCodeClientResponse().getCode());

    String result = service.createUser(createUserRequestModel);

    assertThat(result).isEqualTo(context.getCode());

    verify(brokerAuthClient, times(1)).createUser(createUserRequestModel);
    verify(brokerAuthClient, times(1)).generateActivationCode(
        createUserRequestModel.getUsername());
  }

  @Test
  void shouldReturnErrorIfUserAlreadyExists() {
    RegistrationContext context = RegistrationContext.builder().build();
    CreateUserRequestModel userCreateRequestModel = context.createCreateUserRequestModel();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    doThrow(new UserAlreadyExistsException(context.getUsername()))
        .when(brokerAuthClient).createUser(any());

    assertThatThrownBy(() -> service.createUser(userCreateRequestModel))
        .isInstanceOf(UserAlreadyExistsException.class);

    verify(brokerAuthClient, times(1)).createUser(userCreateRequestModel);
    verify(brokerAuthClient, times(0)).generateActivationCode(
        userCreateRequestModel.getUsername());
  }

  @Test
  void shouldReturnErrorIfDownstreamServiceReturnsErrorForCreateUser() {
    RegistrationContext context = RegistrationContext.builder().build();
    CreateUserRequestModel userCreateRequestModel = context.createCreateUserRequestModel();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    doThrow(new RemoteRequestFailedException("Something went wrong"))
        .when(brokerAuthClient).createUser(any());

    assertThatThrownBy(() -> service.createUser(userCreateRequestModel))
        .isInstanceOf(RemoteRequestFailedException.class);

    verify(brokerAuthClient, times(1)).createUser(userCreateRequestModel);
    verify(brokerAuthClient, times(0)).generateActivationCode(
        userCreateRequestModel.getUsername());
  }

  @Test
  void shouldReturnErrorIfDownstreamServiceReturnsErrorForGenerateActivationCode() {
    RegistrationContext context = RegistrationContext.builder().build();
    CreateUserRequestModel userCreateRequestModel = context.createCreateUserRequestModel();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    doThrow(new RemoteRequestFailedException("Something went wrong"))
        .when(brokerAuthClient).generateActivationCode(any());

    assertThatThrownBy(() -> service.createUser(userCreateRequestModel))
        .isInstanceOf(RemoteRequestFailedException.class);

    verify(brokerAuthClient, times(1)).createUser(userCreateRequestModel);
    verify(brokerAuthClient, times(1)).generateActivationCode(
        userCreateRequestModel.getUsername());
  }

  @Test
  void shouldCallDeleteRegistrationClient() {
    DeleteUserRequestModel deleteUserRequestModel = RegistrationContext.builder().build()
            .createDeleteUserRequestModel();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    service.deleteUser(deleteUserRequestModel);

    verify(brokerAuthClient, times(1)).deleteUser(deleteUserRequestModel);
  }

  @Test
  void shouldCallReactivateUserClientMethod() {
    RegistrationContext context = RegistrationContext.builder().build();

    RegistrationService service = new RegistrationService(brokerAuthClient);

    service.reactivateUser(context.getUsername());

    verify(brokerAuthClient, times(1)).reactivateUser(context.getUsername());
  }
}
