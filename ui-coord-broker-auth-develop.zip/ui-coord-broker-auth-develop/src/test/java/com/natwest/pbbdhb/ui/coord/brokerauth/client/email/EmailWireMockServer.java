package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.web.util.UriComponentsBuilder;

public class EmailWireMockServer {

  private static final String EXPECTED_PATH = "/mortgages/v1/msvc-int-email";

  private static String emailpath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_PATH)
        .pathSegment("email")
        .build()
        .getPath();
  }

  public static MappingBuilder mappingEmailRequest() {
    return WireMock.post(WireMock.urlPathEqualTo(emailpath()));
  }

  /**
   * Define a verifier request pattern for a retrieve request.
   *
   * @return Mapping to be passed to {@code WireMock.verify()}.
   */
  public static RequestPatternBuilder patternForEmailRequest() {
    return WireMock.postRequestedFor(WireMock.urlPathMatching(emailpath()));
  }

  public static ResponseDefinitionBuilder jsonResponse(HttpStatus status) {
    return WireMock.status(status.value());
  }
}
