package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.ui.coord.brokerauth.model.AbstractValidationTest.TestValidationError.create;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.ENUM_BROKER_TYPE_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;

import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class FirmDetailsValidationTest extends AbstractValidationTest<FirmDetails> {

    private static Stream<Arguments> provideArgs() {
        return Stream.of(
                Arguments.of("Valid firm details", (Consumer<FirmDetails>) d -> {
                }, EMPTY_SET),
                Arguments.of("Broker type is invalid", (Consumer<FirmDetails>) d -> d.setBrokerType("invalid"), singleton(create("brokerType", ENUM_BROKER_TYPE_ERROR_MESSAGE))),
                Arguments.of("Firm name is null", (Consumer<FirmDetails>) d -> d.setFirmName(null), singleton(create("firmName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Firm name is empty", (Consumer<FirmDetails>) d -> d.setFirmName(""), singleton(create("firmName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("FCA number is null", (Consumer<FirmDetails>) d -> d.setFcaNumber(null), singleton(create("fcaNumber", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("FCA number is empty", (Consumer<FirmDetails>) d -> d.setFcaNumber(""), singleton(create("fcaNumber", MUST_NOT_BE_BLANK_ERROR_MESSAGE)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("provideArgs")
    public void testFirmDetailsValidations(String testDescription, Consumer<FirmDetails> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtil::createValidFirmDetails, mutator, expectedErrorMessages);
    }

}
