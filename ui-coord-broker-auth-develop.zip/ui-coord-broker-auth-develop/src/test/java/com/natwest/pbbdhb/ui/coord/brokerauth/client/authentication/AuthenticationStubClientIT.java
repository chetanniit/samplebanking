package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication;


import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccessTokenContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;


@ActiveProfiles(profiles = {"integration"})
@SpringBootTest(
    properties = {
        "clients.authentication.stub.enabled = true"
    }
)
class AuthenticationStubClientIT {

  @Autowired
  AuthenticationClient client;

  @Test
  void shouldInjectStubClient() {
    assertThat(client.getClass())
        .isEqualTo(AuthenticationStubClient.class);
  }

  @Test
  void shouldReturnExpectedStubResponse() {

    final AccessTokenContext context = AccessTokenContext.builder().accessToken("stub-token-abcdef-123456").build();

    BrokerPortalAccessTokenRequestModel requestModel = context.createBrokerAccessTokenRequestModel();

    BrokerPortalAccessTokenResponseModel responseModel = context.createBrokerPortalAccessTokenResponseModel();

    final BrokerPortalAccessTokenResponseModel token = client.retrieve(requestModel);

    Assertions.assertThat(token).isEqualTo(responseModel);
  }
}
