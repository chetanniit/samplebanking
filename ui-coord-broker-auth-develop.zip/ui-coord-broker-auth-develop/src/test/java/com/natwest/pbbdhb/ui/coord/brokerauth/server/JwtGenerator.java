package com.natwest.pbbdhb.ui.coord.brokerauth.server;

import com.rbs.dws.security.iam.MicroserviceIssuer;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;

public class JwtGenerator {

  static final String NWB_APIGEE_DEV_ISSUER = "nwb.apigee.dev";
  static final String NWB_OPERATING_BRAND = "nwb";

  /**
   * Helper for generating a JWT.
   *
   * @param microserviceIssuer Information regarding the microservice issuer, so the audience of
   *                           outer jwt can be known.
   * @return JWT string payload.
   */
  public static String createJwt(MicroserviceIssuer microserviceIssuer) {
    JwtClaims claims = new JwtClaims();
    String microserviceName = microserviceIssuer.get();
    claims.setAudience(microserviceName);
    claims.setIssuer(NWB_APIGEE_DEV_ISSUER);
    claims.setSubject(microserviceName);

    claims.setExpirationTimeMinutesInTheFuture(60F);

    claims.setClaim("operating_brand", NWB_OPERATING_BRAND);

    return createJwtWithRandomKey(claims);
  }

  private static String createJwtWithRandomKey(JwtClaims claims) {
    try {
      final KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("EC");
      keyPairGenerator.initialize(256, SecureRandom.getInstanceStrong());

      KeyPair keyPair = keyPairGenerator.genKeyPair();

      JsonWebSignature jws = new JsonWebSignature();
      jws.setPayload(claims.toJson());
      jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
      jws.setKey(keyPair.getPrivate());
      jws.setHeader(HeaderParameterNames.TYPE, "JWT");

      return jws.getCompactSerialization();
    } catch (NoSuchAlgorithmException ex) {
      throw new IllegalStateException("Could not find EC algorithm", ex);
    } catch (JoseException ex) {
      throw new IllegalStateException("Could not build JWS", ex);
    }
  }

}
