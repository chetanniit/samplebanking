package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccountManagementContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.BrokerInfoContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.MemorableQuestionAnswersValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.QuestionsNotRetrievedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ResetPasswordException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ValidateOtpException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ResetPasswordRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.server.JwtGenerator;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.account.AccountManagementService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info.BrokerTypeInfoService;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * In this test, the full Spring app context is started, but with the service layer mocked.
 */
@ActiveProfiles(profiles = {"integration", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AccountManagementControllerTestIT {

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  private static final String CHALLENGE_QUESTIONS = "/challenge-questions";
  private static final String CHALLENGE_ANSWERS = "/challenge-answers";
  private static final String CODE = "code";
  private static final String PASSWORD_RESET = "password-reset";
  private static final String OTP_VALIDATION = "otp-validation";
  private static final String USERNAME_REMINDER = "username-reminder";

  @Mock
  AccountManagementController accountManagementController;

  @MockBean
  AccountManagementService accountManagementService;

  @MockBean
  BrokerTypeInfoService brokerService;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @LocalServerPort
  int port;

  @Value("${server.servlet.context-path}")
  String contextPath;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder
        .fromPath(contextPath)
        .pathSegment("account-management")
        .build()
        .getPath();
    return RestAssured
        .given().log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(port)
        .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Retrieve Questions Cases")
  class RetrieveQuestionsCases {

    @Test
    void shouldCallServiceWithRequestModels() {
      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
              .build();

      givenRequestToController()
              .body(objectMapper.valueToTree(
                      accountManagementContext.createRetrieveQuestionsRequestModel()))
              .contentType(ContentType.JSON)
              .post(CHALLENGE_QUESTIONS)
              .then()
              .log().all();

      verify(accountManagementService, Mockito.times(1))
              .retrieveSecurityQuestions(
                      accountManagementContext.createRetrieveQuestionsRequestModel().getUsername());
    }

    @Test
    void shouldReturnErrorIfServiceFailedToRetrieveQuestions() {
      doThrow(new QuestionsNotRetrievedException("Questions not retrieved exception"))
              .when(accountManagementService).retrieveSecurityQuestions(any());

      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
              .build();

      givenRequestToController()
              .body(objectMapper.valueToTree(
                      accountManagementContext.createRetrieveQuestionsRequestModel()))
              .contentType(ContentType.JSON)
              .post(CHALLENGE_QUESTIONS)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value());
    }
  }

  @Nested
  @DisplayName("Validate Answers Cases")
  class ValidateAnswersCases {

    @Test
    void shouldCallServiceWithRequestModels() {
      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      givenRequestToController()
          .body(objectMapper.valueToTree(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then()
          .log().all();

      verify(accountManagementService, Mockito.times(1))
          .validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel());
    }

    @Test
    void shouldReturn401DueToCrmDataException() {
      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      when(accountManagementService.validateSecurityAnswers(any()))
          .thenReturn(accountManagementContext.createValidateSecurityAnswersResponseModel());

      doThrow(new CrmDataException("Failed to login"))
          .when(brokerService)
          .getBrokerInfo(any());

      givenRequestToController()
          .body(objectMapper.valueToTree(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
          .contentType(ContentType.JSON)
          .post(CHALLENGE_ANSWERS)
          .then()
          .log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value())
          .body("code", is(ErrorCode.UNAUTHORISED.toString()));
    }

    @Test
    void shouldReturnErrorIfAnswersAreIncorrect() {
      doThrow(new MemorableQuestionAnswersValidationException(
          ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS,
          "Incorrect answers message", new Throwable()))
          .when(accountManagementService).validateSecurityAnswers(any());

      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("INCORRECT_MEMORABLE_QUESTION_ANSWERS"));
    }

    @Test
    void shouldReturnErrorIfQuestionsAreLocked() {
      doThrow(new MemorableQuestionAnswersValidationException(
          ErrorCode.MEMORABLE_QUESTIONS_LOCKED,
          "Questions locked message", new Throwable()))
          .when(accountManagementService).validateSecurityAnswers(any());

      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("MEMORABLE_QUESTIONS_LOCKED"));
    }

    @Test
    void shouldReturnErrorIfAccountIsLocked() {
      doThrow(new MemorableQuestionAnswersValidationException(
          ErrorCode.ACCOUNT_LOCKED,
          "Account locked message", new Throwable()))
          .when(accountManagementService).validateSecurityAnswers(any());

      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.UNAUTHORIZED.value()).extract().asString();

      Assertions.assertTrue(response.contains("ACCOUNT_LOCKED"));
    }

    @Test
    void shouldReturnErrorForGenericRequestException() {
      doThrow(new RemoteRequestFailedException("Generic request exception")).when(
          accountManagementService).validateSecurityAnswers(any());

      AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

      String response = givenRequestToController()
          .contentType(ContentType.JSON)
          .body(objectMapper.valueToTree(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
          .post(CHALLENGE_ANSWERS)
          .then().log().all()
          .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value()).extract().asString();

      Assertions.assertTrue(response.contains("INTERNAL_SERVER_ERROR"));
    }
  }

  @Nested
  @DisplayName("Password Reset Cases")
  class PasswordResetCases {
    @Test
    void shouldReturn204IfSuccessful() {
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      ResetPasswordRequest req = accountManagementContext.createResetPasswordRequest();
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.NO_CONTENT.value());
      ResetPasswordRequestModel expectedServiceModel = ResetPasswordRequestModel.builder()
              .otpCode(req.getOtpCode())
              .password(req.getPassword())
              .username(req.getUsername())
              .build();
      verify(accountManagementService, Mockito.times(1))
              .resetPassword(eq(expectedServiceModel));
    }

    @Test
    void shouldReturnErrorIfUserNotFound() {
      ResetPasswordException ex = new ResetPasswordException(400, ErrorCode.USER_NOT_FOUND, "User not found for user: 'sampleUser'");
      doThrow(ex).when(accountManagementService).resetPassword(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body(CODE, equalTo(ErrorCode.USER_NOT_FOUND.toString()));
    }

    @Test
    void shouldReturnErrorIfPasswordNotValid() {
      ResetPasswordException ex = new ResetPasswordException(400, ErrorCode.INVALID_DETAILS, "Password not valid");
      doThrow(ex).when(accountManagementService).resetPassword(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body(CODE, equalTo(ErrorCode.INVALID_DETAILS.toString()));
    }

    @Test
    void shouldReturnErrorIfAccountLocked() {
      ResetPasswordException ex = new ResetPasswordException(401, ErrorCode.ACCOUNT_LOCKED, "Account locked for user: 'sampleUser'");
      doThrow(ex).when(accountManagementService).resetPassword(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.ACCOUNT_LOCKED.toString()));
    }

    @Test
    void shouldReturnErrorIfInvalidOtp() {
      ResetPasswordException ex = new ResetPasswordException(401, ErrorCode.INVALID_CREDENTIALS, "Invalid OTP code for code '1234' and username 'sampleUser'");
      doThrow(ex).when(accountManagementService).resetPassword(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.INVALID_CREDENTIALS.toString()));
    }

    @Test
    void shouldReturnErrorIfOtpExpired() {
      ResetPasswordException ex = new ResetPasswordException(401, ErrorCode.OTP_EXPIRED, "Expired OTP code for code '1234' and username 'sampleUser'");
      doThrow(ex).when(accountManagementService).resetPassword(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.OTP_EXPIRED.toString()));
    }

    @Test
    void shouldReturnErrorIfGenericOtpFailure() {
      ResetPasswordException ex = new ResetPasswordException(401, ErrorCode.OTP_VALIDATION_FAILED, "Generic OTP failure for code '1234' and username 'sampleUser'");
      doThrow(ex).when(accountManagementService).resetPassword(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(PASSWORD_RESET)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.OTP_VALIDATION_FAILED.toString()));
    }
  }

  @Nested
  @DisplayName("Validate OTP Cases")
  class ValidateOtpCases {
    @Test
    void shouldReturn204IfSuccessful() {
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      ResetPasswordRequest req = accountManagementContext.createResetPasswordRequest();
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(OTP_VALIDATION)
              .then()
              .log().all()
              .statusCode(HttpStatus.NO_CONTENT.value());
      ValidateOtpRequestModel expectedServiceModel = ValidateOtpRequestModel.builder()
              .otpCode(req.getOtpCode())
              .username(req.getUsername())
              .build();
      verify(accountManagementService, Mockito.times(1))
              .validateOtp(eq(expectedServiceModel));
    }
    @Test
    void shouldReturnErrorIfAccountLocked() {
      ValidateOtpException ex = new ValidateOtpException(ErrorCode.ACCOUNT_LOCKED, "Account locked for user: 'username'");
      doThrow(ex).when(accountManagementService).validateOtp(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(OTP_VALIDATION)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.ACCOUNT_LOCKED.toString()));
    }
    @Test
    void shouldReturnErrorIfInvalidCredentials() {
      ValidateOtpException ex = new ValidateOtpException(ErrorCode.INVALID_CREDENTIALS, "Login failed due to invalid credentials for user: 'username'");
      doThrow(ex).when(accountManagementService).validateOtp(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(OTP_VALIDATION)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.INVALID_CREDENTIALS.toString()));
    }
    @Test
    void shouldReturnErrorIfOtpExpired() {
      ValidateOtpException ex = new ValidateOtpException(ErrorCode.OTP_EXPIRED, "Expired OTP code for code '1234' and username 'username'");
      doThrow(ex).when(accountManagementService).validateOtp(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(OTP_VALIDATION)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.OTP_EXPIRED.toString()));
    }
    @Test
    void shouldReturnErrorIfOtpValidationFailed() {
      ValidateOtpException ex = new ValidateOtpException(ErrorCode.OTP_VALIDATION_FAILED, "Generic OTP failure for code '1234' and username 'username'");
      doThrow(ex).when(accountManagementService).validateOtp(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createResetPasswordRequest()))
              .contentType(ContentType.JSON)
              .post(OTP_VALIDATION)
              .then()
              .log().all()
              .statusCode(HttpStatus.UNAUTHORIZED.value())
              .body(CODE, equalTo(ErrorCode.OTP_VALIDATION_FAILED.toString()));
    }
  }

  @Nested
  @DisplayName("Get Username Reminder Cases")
  class GetUsernameReminderCases {

    @Test
    void shouldReturn204IfSuccessful() {
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      UsernameReminderRequest req = accountManagementContext.createUsernameReminderRequest();
      givenRequestToController()
              .body(objectMapper.valueToTree(req))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.NO_CONTENT.value());

      verify(accountManagementService, Mockito.times(1))
              .getUsernameReminder(eq(req));
    }

    @Test
    void shouldReturnValidationErrorIfGetUsernameReminderRequestIsInvalid() {
      InvalidDetailsException ex = new InvalidDetailsException("Generic validation failed error");
      doThrow(ex).when(accountManagementService).getUsernameReminder(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createUsernameReminderRequest()))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.BAD_REQUEST.value())
              .body(CODE, equalTo(ErrorCode.INVALID_DETAILS.toString()));
    }

    @Test
    void shouldReturnInternalServerErrorIfGetUsernameReminderRequestFailed() {
      RemoteRequestFailedException ex = new RemoteRequestFailedException("Generic error");
      doThrow(ex).when(accountManagementService).getUsernameReminder(any());
      AccountManagementContext accountManagementContext = AccountManagementContext.builder().build();
      givenRequestToController()
              .body(objectMapper.valueToTree(accountManagementContext.createUsernameReminderRequest()))
              .contentType(ContentType.JSON)
              .post(USERNAME_REMINDER)
              .then()
              .log().all()
              .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
              .body(CODE, equalTo(ErrorCode.INTERNAL_SERVER_ERROR.toString()));
    }

    @Test
    void shouldReturn404IfFeatureFlagDisabled() {
      ReflectionTestUtils.setField(accountManagementController, "featureForgotUsernameEnabled", false);
      doThrow(new ResponseStatusException(HttpStatus.NOT_FOUND))
              .when(accountManagementController).getUsernameReminder(any());

      verify(accountManagementService, times(0)).getUsernameReminder(any());

    }
  }
}
