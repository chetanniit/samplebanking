package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailActivationCodeTemplateConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailReactivateAccountTemplateConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.EmailContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.RegistrationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.email.EmailService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.registration.RegistrationService;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

@ActiveProfiles(profiles = {"integration"})
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class RegistrationControllerTestIT {

  @MockBean
  RegistrationService registrationService;

  @MockBean
  EmailService emailService;

  @MockBean
  EmailActivationCodeTemplateConfig emailActivationCodeConfig;

  @MockBean
  EmailReactivateAccountTemplateConfig emailReactivateConfig;

  @LocalServerPort
  int port;

  @Value("${server.servlet.context-path}")
  String contextPath;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder.fromPath(contextPath)
        .pathSegment("registration")
        .build()
        .getPath();
    return RestAssured.given()
        .log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port);
  }

  @Test
  void shouldCallServiceWithRequestModels() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();
    EmailContext emailContext = EmailContext.builder()
        .activationCode("123456")
        .firstname(registrationContext.getFirstname())
        .surname(registrationContext.getLastname())
        .toRecipients(registrationContext.getEmail())
        .build();

    when(emailActivationCodeConfig.getName()).thenReturn(emailContext.getTemplateName());
    when(emailActivationCodeConfig.getRegistrationUrl()).thenReturn(
        emailContext.getRegistrationUrl());
    when(registrationService.createUser(registrationContext.createCreateUserRequestModel()))
        .thenReturn(registrationContext.createActivationCodeClientResponse().getCode());

    givenRequestToController()
        .body(registrationContext.createCreateUserRequest())
        .contentType(ContentType.JSON)
        .post("user")
        .then().log().all();

    verify(registrationService, times(1))
        .createUser(registrationContext.createCreateUserRequestModel());

    verify(emailService, Mockito.times(1))
        .send(emailContext.createEmailRequestModel());
  }

  @Test
  void shouldReturnErrorIfInvalidRequestBody() {

    givenRequestToController()
        .body(new JSONObject().toString())
        .contentType(ContentType.JSON)
        .post("user")
        .then().log().all()
        .statusCode(HttpStatus.BAD_REQUEST.value());
  }

  @Test
  void shouldReturnErrorIfUserAlreadyExists() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new UserAlreadyExistsException(registrationContext.getUsername()))
        .when(registrationService)
        .createUser(any());

    givenRequestToController()
        .body(registrationContext.createCreateUserRequest())
        .contentType(ContentType.JSON)
        .post("user")
        .then().log().all()
        .statusCode(HttpStatus.CONFLICT.value());

    verify(registrationService, times(1))
        .createUser(registrationContext.createCreateUserRequestModel());
  }

  @Test
  void shouldReturnErrorIfServiceReturnsError() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new RemoteRequestFailedException("Something went wrong"))
        .when(registrationService)
        .createUser(any());

    givenRequestToController()
        .body(registrationContext.createCreateUserRequest())
        .contentType(ContentType.JSON)
        .post("user")
        .then().log().all()
        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

    verify(registrationService, times(1))
        .createUser(registrationContext.createCreateUserRequestModel());
  }

  @Test
  void shouldCallServiceWithDeleteRequestModels() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    givenRequestToController()
            .body(registrationContext.createDeleteUserRequest())
            .contentType(ContentType.JSON)
            .delete("user")
            .then().log().all();

    verify(registrationService, times(1))
            .deleteUser(registrationContext.createDeleteUserRequestModel());
  }

  @Test
  void shouldReturnErrorIfDeleteUserNotFound() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new UserNotFoundException("Exception message"))
        .when(registrationService)
        .deleteUser(any());

    givenRequestToController()
        .body(registrationContext.createDeleteUserRequest())
        .contentType(ContentType.JSON)
        .delete("user")
        .then().log().all()
        .statusCode(HttpStatus.BAD_REQUEST.value())
        .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));

    verify(registrationService, times(1))
        .deleteUser(registrationContext.createDeleteUserRequestModel());
  }

  @Test
  void shouldReturnErrorIfDeleteServiceReturnsError() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new RemoteRequestFailedException("Something went wrong"))
            .when(registrationService)
            .deleteUser(any());

    givenRequestToController()
            .body(registrationContext.createDeleteUserRequest())
            .contentType(ContentType.JSON)
            .delete("user")
            .then().log().all()
            .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

    verify(registrationService, times(1))
            .deleteUser(registrationContext.createDeleteUserRequestModel());
  }

  @Test
  void shouldCallServiceWithReactivateUserModels() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();
    EmailContext emailContext = EmailContext.builder()
        .oneTimePasscode("abc123")
        .firstname(registrationContext.getFirstname())
        .surname(registrationContext.getLastname())
        .toRecipients(registrationContext.getEmail())
        .build();

    when(emailReactivateConfig.getName()).thenReturn(emailContext.getTemplateName());
    when(emailReactivateConfig.getAccountRecoveryUrl()).thenReturn(
        emailContext.getAccountRecoveryUrl());
    when(emailReactivateConfig.getSupportNumber()).thenReturn(emailContext.getSupportNumber());
    when(registrationService.reactivateUser(registrationContext.getUsername()))
        .thenReturn(registrationContext.getReactivationCode());

    givenRequestToController()
        .body(registrationContext.createReactivateUserRequestModel())
        .contentType(ContentType.JSON)
        .put("reactivate")
        .then().log().all();

    verify(registrationService, times(1))
        .reactivateUser(registrationContext.getUsername());

    verify(emailService, Mockito.times(1))
        .send(emailContext.createEmailAccountRecoveryModel());
  }

  @Test
  void shouldReturnErrorIfReactivateUserNotFound() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new UserNotFoundException("Exception message"))
        .when(registrationService)
        .reactivateUser(any());

    givenRequestToController()
        .body(registrationContext.createReactivateUserRequestModel())
        .contentType(ContentType.JSON)
        .put("reactivate")
        .then().log().all()
        .statusCode(HttpStatus.BAD_REQUEST.value())
        .body("code", equalTo(ErrorCode.USER_NOT_FOUND.name()));
  }

  @Test
  void shouldReturnErrorIfServiceReturnsReactivationError() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new RemoteRequestFailedException("Exception message"))
        .when(registrationService)
        .reactivateUser(any());

    givenRequestToController()
        .body(registrationContext.createReactivateUserRequestModel())
        .contentType(ContentType.JSON)
        .put("reactivate")
        .then().log().all()
        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
  }

  @Test
  void shouldReturnErrorIfActivationCodeUsernameIncorrect() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new RemoteRequestFailedException("Exception message"))
        .when(registrationService)
        .reactivateUser(any());

    givenRequestToController()
        .body(registrationContext.createReactivateUserRequestModel())
        .contentType(ContentType.JSON)
        .put("reactivate")
        .then().log().all()
        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
  }
  @Test
  void shouldReturnErrorIfActivationCodeInternalServerError() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new RemoteRequestFailedException("Exception message"))
        .when(registrationService)
        .reactivateUser(any());

    givenRequestToController()
        .body(registrationContext.createReactivateUserRequestModel())
        .contentType(ContentType.JSON)
        .put("reactivate")
        .then().log().all()
        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
  }
  @Test
  void shouldReturnErrorIfActivationCodeGetBrokerDetailsError() {
    RegistrationContext registrationContext = RegistrationContext.builder().build();

    doThrow(new RemoteRequestFailedException("Exception message"))
        .when(registrationService)
        .reactivateUser(any());

    givenRequestToController()
        .body(registrationContext.createReactivateUserRequestModel())
        .contentType(ContentType.JSON)
        .put("reactivate")
        .then().log().all()
        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
  }
}
