package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.FirmDetailsResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameAvailableResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.net.HttpURLConnection;

import static com.natwest.pbbdhb.ui.coord.brokerauth.service.BrokerRegistrationConnectionHelperTest.FAKE_DETAILS_ENDPOINT_URL;
import static com.natwest.pbbdhb.ui.coord.brokerauth.service.BrokerRegistrationConnectionHelperTest.FAKE_REGISTER_BROKER_ENDPOINT_URL;
import static com.natwest.pbbdhb.ui.coord.brokerauth.service.BrokerRegistrationConnectionHelperTest.FAKE_USERNAME_ENDPOINT_URL;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidBrokerRegistrationDto;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        BrokerRegistrationConnectionHelper.class,
        ObjectMapper.class
})
@TestPropertySource(properties = {
        "broker-registration.registerBrokerEndpoint=" + FAKE_REGISTER_BROKER_ENDPOINT_URL,
        "broker-registration.usernameEndpoint=" + FAKE_USERNAME_ENDPOINT_URL,
        "broker-registration.firmDetailsEndpoint=" + FAKE_DETAILS_ENDPOINT_URL
})
class BrokerRegistrationConnectionHelperTest {
    public static final String FAKE_REGISTER_BROKER_ENDPOINT_URL = "https://testRegisterBrokerEndpoint";
    public static final String FAKE_USERNAME_ENDPOINT_URL = "https://testUsernameEndpoint";
    public static final String FAKE_DETAILS_ENDPOINT_URL = "https://testFirmDetailsEndpoint";

    private static final String FAKE_REQUEST_URL = "https://fake-url.com";
    private static final String BAD_REQUEST_MESSAGE = "Bad Request";
    private static final String IO_ERROR_MESSAGE = "IO Error";

    private static final String TEST_ACCESS_TOKEN = "test-access-token";
    private static final String TEST_BRAND = "test-brand";
    private static final String TEST_FCA_NUMBER = "test-fca-number";

    private static final String TEST_USER_NAME = "jlpicard";

    private static final String EMPTY_JSON_BODY = "{}";

    @Value("classpath:test-files/registration/register-broker-success.json")
    private Resource registerBrokerSuccess;

    @Value("classpath:test-files/registration/register-broker-failure.json")
    private Resource registerBrokerFailure;

    @Value("classpath:test-files/firms/ar-multiple-multiple.json")
    private Resource arMultipleFirmsMultiplePrincipals;

    @Value("classpath:test-files/firms/ar-single-multiple.json")
    private Resource arSingleFirmMultiplePrincipals;

    @Value("classpath:test-files/username/username-available.json")
    private Resource usernameAvailable;


    private final Request fakeRequest = new Request.Builder()
            .url(FAKE_REQUEST_URL)
            .build();

    @MockBean(name = "proxyHttpClient")
    private OkHttpClient mockProxyHttpClient;

    @MockBean
    private Call mockServiceCall;

    @MockBean
    private SecurityTokenHelper mockSecurityTokenHelper;

    @Autowired
    private BrokerRegistrationConnectionHelper brokerRegistrationConnectionHelper;

    @BeforeEach
    void stubAccessToken() {
        when(this.mockSecurityTokenHelper.getAccessToken()).thenReturn(TEST_ACCESS_TOKEN);
    }

    @AfterEach
    void verifyCalls() throws IOException {
        verify(this.mockProxyHttpClient).newCall(any(Request.class));
        verifyNoMoreInteractions(this.mockProxyHttpClient);
        verify(this.mockServiceCall).execute();
        verifyNoMoreInteractions(this.mockServiceCall);
    }

    @Test
    void testRegisterBrokerNotOK() throws IOException {
        Response errorResponse = createResponse(HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE, EMPTY_JSON_BODY);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(errorResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerRegistrationConnectionHelper.registerBroker(createValidBrokerRegistrationDto())))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s returned %d (%s)", FAKE_REGISTER_BROKER_ENDPOINT_URL, HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE));
    }

    @Test
    void testRegisterBrokerIOError() throws IOException {
        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doThrow(new IOException(IO_ERROR_MESSAGE)).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerRegistrationConnectionHelper.registerBroker(createValidBrokerRegistrationDto())))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s request failed %s", FAKE_REGISTER_BROKER_ENDPOINT_URL, IO_ERROR_MESSAGE));
    }

    @Test
    void testRegisterBrokerNoBody() throws IOException {
        Response noBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", null);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(noBodyResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerRegistrationConnectionHelper.registerBroker(createValidBrokerRegistrationDto())))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s failed", FAKE_REGISTER_BROKER_ENDPOINT_URL));
    }

    @Test
    void testRegisterBrokerEmptyBody() throws IOException {
        Response emptyBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", EMPTY_JSON_BODY);
        BrokerRegistrationResponseDto emptyDto = new BrokerRegistrationResponseDto();

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(emptyBodyResponse).when(this.mockServiceCall).execute();

        assertThat(brokerRegistrationConnectionHelper.registerBroker(createValidBrokerRegistrationDto())).isEqualTo(emptyDto);
    }

    @Test
    void testRegisterBrokerSuccessResponse() throws IOException {
        Response completeResponse = createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(registerBrokerSuccess));
        BrokerRegistrationResponseDto brokerRegistrationResponseDto = TestUtil.readRegisterBrokerFromResource(registerBrokerSuccess);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(brokerRegistrationConnectionHelper.registerBroker(createValidBrokerRegistrationDto())).isEqualTo(brokerRegistrationResponseDto);
    }

    @Test
    void testRegisterBrokerFailureResponse() throws IOException {
        Response completeResponse = createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(registerBrokerFailure));
        BrokerRegistrationResponseDto brokerRegistrationResponseDto = TestUtil.readRegisterBrokerFromResource(registerBrokerFailure);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(brokerRegistrationConnectionHelper.registerBroker(createValidBrokerRegistrationDto())).isEqualTo(brokerRegistrationResponseDto);
    }

    @Test
    void testGetFirmDetailsNotOK() throws IOException {
        Response errorResponse = createResponse(HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE, EMPTY_JSON_BODY);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(errorResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerRegistrationConnectionHelper.getFirmDetails(TEST_BRAND, TEST_FCA_NUMBER)))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s returned %d (%s)", FAKE_DETAILS_ENDPOINT_URL, HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE));
    }

    @Test
    void testGetFirmDetailsIOError() throws IOException {
        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doThrow(new IOException(IO_ERROR_MESSAGE)).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerRegistrationConnectionHelper.getFirmDetails(TEST_BRAND, TEST_FCA_NUMBER)))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s request failed %s", FAKE_DETAILS_ENDPOINT_URL, IO_ERROR_MESSAGE));
    }

    @Test
    void testGetFirmDetailsNoBody() throws IOException {
        Response noBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", null);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(noBodyResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerRegistrationConnectionHelper.getFirmDetails(TEST_BRAND, TEST_FCA_NUMBER)))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s failed", FAKE_DETAILS_ENDPOINT_URL));
    }

    @Test
    void testGetFirmDetailsEmptyBody() throws IOException {
        Response emptyBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", EMPTY_JSON_BODY);
        FirmDetailsResponseDto emptyDto = new FirmDetailsResponseDto();

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(emptyBodyResponse).when(this.mockServiceCall).execute();

        assertThat(brokerRegistrationConnectionHelper.getFirmDetails(TEST_BRAND, TEST_FCA_NUMBER)).isEqualTo(emptyDto);
    }

    @Test
    void testGetFirmDetailsArMultipleMultipleBody() throws IOException {
        Response completeResponse = createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(arMultipleFirmsMultiplePrincipals));
        FirmDetailsResponseDto firmDetailsResponseDto = TestUtil.readFirmDetailsFromResource(arMultipleFirmsMultiplePrincipals);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(brokerRegistrationConnectionHelper.getFirmDetails(TEST_BRAND, TEST_FCA_NUMBER)).isEqualTo(firmDetailsResponseDto);
    }

    @Test
    void testUserNameAvailableBadResponse() throws IOException {
        Response response = createResponse(HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE, EMPTY_JSON_BODY);

        UsernameAvailableResponse.UsernameAvailableResponseBuilder expectedResponseBuilder = UsernameAvailableResponse.builder();
        expectedResponseBuilder.isAvailable(false);
        expectedResponseBuilder.error(String.format("Error in call %s", HttpURLConnection.HTTP_BAD_REQUEST));
        expectedResponseBuilder.isError(true);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(response).when(this.mockServiceCall).execute();

        UsernameAvailableResponse expectedResponse = expectedResponseBuilder.build();
        UsernameAvailableResponse actualResponse = brokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USER_NAME);

        assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    }

    @Test
    void testUserNameAvailableIOError() throws IOException {
        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doThrow(new IOException(IO_ERROR_MESSAGE)).when(this.mockServiceCall).execute();

        UsernameAvailableResponse.UsernameAvailableResponseBuilder expectedResponseBuilder = UsernameAvailableResponse.builder();
        expectedResponseBuilder.isAvailable(false);
        expectedResponseBuilder.error(String.format("Error getting username availability %s", IO_ERROR_MESSAGE));
        expectedResponseBuilder.isError(true);

        UsernameAvailableResponse expectedResponse = expectedResponseBuilder.build();
        UsernameAvailableResponse actualResponse = brokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USER_NAME);

        assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    }

    @Test
    void testUserNameAvailableIsTrue() throws IOException {
        String responseBody = TestUtil.readResource(usernameAvailable);
        Response response = createResponse(HttpURLConnection.HTTP_OK, "", responseBody);

        UsernameAvailableResponse.UsernameAvailableResponseBuilder expectedResponseBuilder = UsernameAvailableResponse.builder();
        expectedResponseBuilder.isAvailable(true);
        expectedResponseBuilder.error(null);
        expectedResponseBuilder.isError(false);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(response).when(this.mockServiceCall).execute();

        UsernameAvailableResponse expectedResponse = expectedResponseBuilder.build();
        UsernameAvailableResponse actualResponse = brokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USER_NAME);

        assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    }

    @Test
    void testUserNameAvailableNoBody() throws IOException {
        Response response = createResponse(HttpURLConnection.HTTP_OK, "", null);

        UsernameAvailableResponse.UsernameAvailableResponseBuilder expectedResponseBuilder = UsernameAvailableResponse.builder();
        expectedResponseBuilder.isAvailable(false);
        expectedResponseBuilder.error(null);
        expectedResponseBuilder.isError(false);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(response).when(this.mockServiceCall).execute();

        UsernameAvailableResponse expectedResponse = expectedResponseBuilder.build();
        UsernameAvailableResponse actualResponse = brokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USER_NAME);

        assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    }

    @Test
    void testUserNameAvailableEmptyBody() throws IOException {
        Response response = createResponse(HttpURLConnection.HTTP_OK, "", EMPTY_JSON_BODY);

        UsernameAvailableResponse.UsernameAvailableResponseBuilder expectedResponseBuilder = UsernameAvailableResponse.builder();
        expectedResponseBuilder.isAvailable(false);
        expectedResponseBuilder.error("Error getting username availability java.lang.NullPointerException");
        expectedResponseBuilder.isError(true);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(response).when(this.mockServiceCall).execute();

        UsernameAvailableResponse expectedResponse = expectedResponseBuilder.build();
        UsernameAvailableResponse actualResponse = brokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USER_NAME);

        assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    }

    private Response createResponse(int responseCode, String message, String jsonResponse) {
        Response.Builder responseBuilder = new Response.Builder()
                .request(fakeRequest)
                .protocol(Protocol.HTTP_2)
                .code(responseCode) // status code
                .message(message);

        if (jsonResponse != null) {
            responseBuilder.body(ResponseBody.create(MediaType.get("application/json; charset=utf-8"), jsonResponse));
        }

        return responseBuilder.build();
    }
}


