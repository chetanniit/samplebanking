package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication;

import static com.github.tomakehurst.wiremock.client.WireMock.containing;

import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.util.UriComponentsBuilder;
import wiremock.com.fasterxml.jackson.databind.ObjectMapper;
import wiremock.com.fasterxml.jackson.databind.node.ObjectNode;

public class AuthenticationWireMockServer {

  // access token parameters
  private static final String EXPECTED_ACCESS_TOKEN = "XXX.YYY.ZZZ";
  private static final Integer EXPECTED_EXPIRES_IN = 599;
  private static final String EXPECTED_TOKEN_TYPE = "Bearer";
  private static final String EXPECTED_ACCESS_TOKEN_PATH = "/mortgages/v1/msvc-auth/broker-portal/token";

  // error parameters
  private static final String ERROR_TYPE = "invalid_client";
  private static final String ERROR_DESCRIPTION = "Invalid client or client credentials.";

  public static String accessTokenPath() {
    return UriComponentsBuilder
        .fromPath(EXPECTED_ACCESS_TOKEN_PATH)
        .build()
        .getPath();
  }

  public static MappingBuilder mappingAccessTokenRequest(
      ObjectNode response, HttpStatus status) {
    return mappingForAccessTokenRequest(jsonResponse(status, response));
  }

  private static MappingBuilder mappingForAccessTokenRequest(ResponseDefinitionBuilder response) {
    return WireMock
        .post(WireMock.urlPathEqualTo(EXPECTED_ACCESS_TOKEN_PATH))
        .withHeader(HttpHeaders.CONTENT_TYPE, containing("application/json"))
        .willReturn(response);
  }

  static ResponseDefinitionBuilder jsonResponse(HttpStatus status,
      ObjectNode body) {
    return WireMock.status(status.value())
        .withHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        .withJsonBody(body);
  }

  public static ObjectNode getAccessTokenResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("accessToken", EXPECTED_ACCESS_TOKEN);
    payload.put("tokenType", EXPECTED_TOKEN_TYPE);
    payload.put("expiresIn", EXPECTED_EXPIRES_IN);
    return payload;
  }

  public static ObjectNode getErrorResponse() {
    ObjectNode payload = new ObjectMapper().createObjectNode();
    payload.put("error_description", ERROR_DESCRIPTION);
    payload.put("error", ERROR_TYPE);
    return payload;
  }

}
