package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccessTokenContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.BrokerInfoContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.*;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginResponse;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LoginRequestMapperTest {

  @Test
  void toLoginDomainModel() {
    LoginRequest requestModel = LoginRequest.builder()
        .username("TestUsername")
        .password("TestPassword")
        .build();

    LoginRequestModel domainModel = LoginRequestMapper.toDomainModel(requestModel);

    assertEquals(domainModel.getUsername(), requestModel.getUsername());
    assertEquals(domainModel.getPassword(), requestModel.getPassword());
  }

  @Test
  void toBrokerDomainModel() {
    BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder().build();
    AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

    BrokerInfoBrokerDomainModel brokerInfo = brokerInfoContext.createBrokerInfoDomainModel();
    String username = brokerInfoContext.getUsername();
    UserRegistrationType brokerType = UserRegistrationType.BROKER;
    String fcaNumber = brokerInfoContext.getFcaNumber();

    BrokerPortalAccessTokenRequestModel domainModel = LoginRequestMapper.toDomainModel(
        username,
        brokerType,
            fcaNumber
    );

    assertEquals(domainModel, accessTokenContext.createBrokerAccessTokenRequestModel());
  }

  @Test
  void toResponseModel() {
    AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

    BrokerPortalAccessTokenResponseModel domainModel = accessTokenContext.createBrokerPortalAccessTokenResponseModel();

    LoginResponse requestModel = LoginRequestMapper.toResponseModel(domainModel, UserRegistrationType.BROKER);

    assertEquals(requestModel.getTokenType(), domainModel.getTokenType());
    assertEquals(requestModel.getAccessToken(), domainModel.getAccessToken());
    assertEquals(requestModel.getExpiresIn(), domainModel.getExpiresIn());
  }

  @Test
  void shouldAllowNullFieldsForAccessTokenRequestModel() {
    BrokerPortalAccessTokenRequestModel expected = BrokerPortalAccessTokenRequestModel.builder()
            .brokerRole(UserRegistrationType.BROKER)
            .userName("TestUsername")
            .fcaNumber("TestFcaNumber")
            .build();

    BrokerPortalAccessTokenRequestModel actual = LoginRequestMapper.toDomainModel("TestUsername", UserRegistrationType.BROKER, "TestFcaNumber");

    assertEquals(expected, actual);
  }
}