package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.ui.coord.brokerauth.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.APPOINTED_REPRESENTATIVE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.DIRECTLY_AUTHORISED;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.*;
import static java.lang.Boolean.FALSE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

public class AdminRegistrationValidationTest extends AbstractValidationTest<AdminRegistration> {

    private static Stream<Arguments> provideArgs() {
        return Stream.of(

                Arguments.of("Valid admin registration", (Consumer<AdminRegistration>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid broker registration for Directly authorised and null principal FCA number", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(DIRECTLY_AUTHORISED.value());
                    a.getFirmDetails().setPrincipalFcaNumber(null);
                }, EMPTY_SET),
                Arguments.of("Valid broker registration with previous firm name and fca number not provided", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setPreviousFirmName(null);
                    a.getFirmDetails().setPreviousFcaNumber(null);
                }, EMPTY_SET),
                Arguments.of("Admin details is null", (Consumer<AdminRegistration>) a -> a.setAdminDetails(null), singleton(create("adminDetails", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Agreements is null", (Consumer<AdminRegistration>) a -> a.setAgreements(null), singleton(create("agreements", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Username is null", (Consumer<AdminRegistration>) a -> a.setUsername(null), singleton(create("username", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Firm details is null", (Consumer<AdminRegistration>) a -> a.setFirmDetails(null), singleton(create("firmDetails", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Principal FCA number is null for Appointed representative", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(APPOINTED_REPRESENTATIVE.value());
                    a.getFirmDetails().setPrincipalFcaNumber(null);
                }, singleton(create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Principal FCA number is blank for Appointed representative", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(APPOINTED_REPRESENTATIVE.value());
                    a.getFirmDetails().setPrincipalFcaNumber("");
                }, singleton(create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Principal FCA number is blank for Directly authorised", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(DIRECTLY_AUTHORISED.value());
                    a.getFirmDetails().setPrincipalFcaNumber("");
                }, singleton(create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Principal FCA number is provided for Directly authorised", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setBrokerType(DIRECTLY_AUTHORISED.value());
                    a.getFirmDetails().setPrincipalFcaNumber("test-fca-number");
                }, singleton(create("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Previous firm name provided but previous FCA number not", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setPreviousFirmName("test-firm-name");
                    a.getFirmDetails().setPreviousFcaNumber(null);
                }, singleton(create("firmDetails", PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("Previous FCA number provided but previous firm name not", (Consumer<AdminRegistration>) a -> {
                    a.getFirmDetails().setPreviousFcaNumber("test-fca-number");
                    a.getFirmDetails().setPreviousFirmName(null);
                }, singleton(create("firmDetails", PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG))),
                Arguments.of("@Valid annotation - error when agreements invalid", (Consumer<AdminRegistration>) a -> a.getAgreements().setTermsOfBusiness(FALSE), singleton(create("agreements.termsOfBusiness", TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG))),
                Arguments.of("@Valid annotation - error when firm details invalid", (Consumer<AdminRegistration>) a -> a.getFirmDetails().setFirmName(null), singleton(create("firmDetails.firmName", MUST_NOT_BE_BLANK_ERROR_MESSAGE)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("provideArgs")
    public void testBrokerRegistrationValidations(String testDescription, Consumer<AdminRegistration> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtil::createValidAdminRegistration, mutator, expectedErrorMessages);
    }

}
