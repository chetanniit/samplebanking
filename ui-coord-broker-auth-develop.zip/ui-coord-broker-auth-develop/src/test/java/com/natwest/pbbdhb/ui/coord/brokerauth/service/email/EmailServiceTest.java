package com.natwest.pbbdhb.ui.coord.brokerauth.service.email;


import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.EmailClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.EmailContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailActivationCodeRequestModel;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmailServiceTest {

  @Mock
  EmailClient emailClient;

  @Test
  void shouldCallEmailClient() {

     EmailActivationCodeRequestModel email = EmailContext.builder().build()
        .createEmailRequestModel();
    EmailService emailService = new EmailService(emailClient);
    emailService.send(email);

    Mockito.verify(emailClient).send(email);
  }
}
