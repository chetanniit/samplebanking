package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginRequest;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public class LoginContext {

  @Default
  private String username = "TestUsername";

  @Default
  private String password = "Password123";

  public LoginRequest createLoginRequest() {
    return LoginRequest.builder()
        .username(username)
        .password(password)
        .build();
  }

  public LoginRequestModel createLoginRequestModel() {
    return LoginRequestModel.builder()
        .username(username)
        .password(password)
        .build();
  }
}
