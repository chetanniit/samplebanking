package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.*;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerFirmNotValidException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerRegistrationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerRegistrationValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UsernameAvailableException;
import com.natwest.pbbdhb.ui.coord.brokerauth.mapper.BrokerRegistrationMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.mapper.FirmDetailsResponseMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameAvailableResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BRAND_DEFAULT;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.*;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidFirmDetailsResponse;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidFirmDetailsResponseDto;
import static java.lang.Boolean.FALSE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BrokerRegistrationServiceImplTest {

    private static final String TEST_USERNAME = "test-username";
    private static final String TEST_FCA_NUMBER = "test-fca-number";
    private static final String EXPECTED_BROKER_FIRM_NOT_VALID_EXCEPTION_MSG = "FCA Number 'test-fca-number' does not exist or is not allowed to do business";

    @Mock
    private BrokerRegistrationConnectionHelper mockBrokerRegistrationConnectionHelper;

    @Mock
    private BrokerRegistrationMapper mockBrokerRegistrationMapper;

    @Mock
    private FirmDetailsResponseMapper mockFirmDetailsResponseMapper;

    @InjectMocks
    private BrokerRegistrationServiceImpl brokerRegistrationService;

    @Test
    void registerBrokerNoExceptionIsThrownWhenSuccessfulResponseReceived() {
        BrokerRegistration request = createValidBrokerRegistration();
        BrokerRegistrationDto dto = createValidBrokerRegistrationDto();
        BrokerRegistrationResponseDto response = createBrokerRegistrationResponseDto(true, null);

        when(this.mockBrokerRegistrationMapper.toBrokerRegistrationDto(request)).thenReturn(dto);
        when(this.mockBrokerRegistrationConnectionHelper.registerBroker(dto)).thenReturn(response);

        this.brokerRegistrationService.registerBroker(request);
    }

    @Test
    void registerBrokerBrokerRegistrationValidationExceptionIsThrownWhenUsernameIsLessThan6Characters() {
        BrokerRegistration request = createValidBrokerRegistration();
        request.setUsername("short");

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username must be at least 6 characters"));
    }

    @Test
    void registerBrokerBrokerRegistrationValidationExceptionIsThrownWhenUsernameStartsWithSpecialCharacter() {
        BrokerRegistration request = createValidBrokerRegistration();
        request.setUsername("_invalid");

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username must start with a letter or a number"));
    }

    @Test
    void registerBrokerBrokerRegistrationValidationExceptionIsThrownWhenUsernameContainsSpecialCharacter() {
        BrokerRegistration request = createValidBrokerRegistration();
        request.setUsername("inval!id");

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username must contain no special characters other than '. - _'"));
    }

    @Test
    void registerBrokerBrokerRegistrationValidationExceptionIsThrownWhenErrorResponseReceivedWithUsernameInUseMessage() {
        BrokerRegistration request = createValidBrokerRegistration();
        BrokerRegistrationDto dto = createValidBrokerRegistrationDto();
        BrokerRegistrationResponseDto response = createBrokerRegistrationResponseDto(false, "Username already exist");

        when(this.mockBrokerRegistrationMapper.toBrokerRegistrationDto(request)).thenReturn(dto);
        when(this.mockBrokerRegistrationConnectionHelper.registerBroker(dto)).thenReturn(response);

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "This username is already in use, please choose another"));
    }

    @Test
    void registerBrokerBrokerRegistrationValidationExceptionIsThrownWhenErrorResponseReceivedWithUsernameOtherErrorMessage() {
        BrokerRegistration request = createValidBrokerRegistration();
        BrokerRegistrationDto dto = createValidBrokerRegistrationDto();
        BrokerRegistrationResponseDto response = createBrokerRegistrationResponseDto(false, "Username error");

        when(this.mockBrokerRegistrationMapper.toBrokerRegistrationDto(request)).thenReturn(dto);
        when(this.mockBrokerRegistrationConnectionHelper.registerBroker(dto)).thenReturn(response);

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username error"));
    }

    @Test
    void registerBrokerBrokerRegistrationExceptionIsThrownWhenErrorResponseReceivedWithUsernameNotInMessage() {
        BrokerRegistration request = createValidBrokerRegistration();
        BrokerRegistrationDto dto = createValidBrokerRegistrationDto();
        BrokerRegistrationResponseDto response = createBrokerRegistrationResponseDto(false, "expected");

        when(this.mockBrokerRegistrationMapper.toBrokerRegistrationDto(request)).thenReturn(dto);
        when(this.mockBrokerRegistrationConnectionHelper.registerBroker(dto)).thenReturn(response);

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationException.class)
                .hasMessage("Error while submitting broker registration: expected");
    }

    @Test
    void registerBrokerBrokerRegistrationValidationExceptionIsThrownWhenBrokerIsUnder18YearsOld() {
        BrokerRegistration request = createValidBrokerRegistration();
        request.getBrokerDetails().setDateOfBirth(LocalDate.now().minusYears(17));

        assertThat(catchThrowable(() -> brokerRegistrationService.registerBroker(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("brokerDetails.dateOfBirth", "You must be over 18 years of age"));
    }

    @Test
    void registerAdminBrokerRegistrationValidationExceptionIsThrownWhenUsernameIsLessThan6Characters() {
        AdminRegistration request = createValidAdminRegistration();
        request.setUsername("short");

        assertThat(catchThrowable(() -> brokerRegistrationService.registerAdmin(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username must be at least 6 characters"));
    }

    @Test
    void registerAdminBrokerRegistrationValidationExceptionIsThrownWhenUsernameStartsWithSpecialCharacter() {
        AdminRegistration request = createValidAdminRegistration();
        request.setUsername("_invalid");

        assertThat(catchThrowable(() -> brokerRegistrationService.registerAdmin(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username must start with a letter or a number"));
    }

    @Test
    void registerAdminBrokerRegistrationValidationExceptionIsThrownWhenUsernameContainsSpecialCharacter() {
        AdminRegistration request = createValidAdminRegistration();
        request.setUsername("inval!id");

        assertThat(catchThrowable(() -> brokerRegistrationService.registerAdmin(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "Username must contain no special characters other than '. - _'"));
    }

    @Test
    void registerAdminBrokerRegistrationValidationExceptionIsThrownWhenAdminIsUnder16YearsOld() {
        AdminRegistration request = createValidAdminRegistration();
        request.getAdminDetails().setDateOfBirth(LocalDate.now().minusYears(15));

        assertThat(catchThrowable(() -> brokerRegistrationService.registerAdmin(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("adminDetails.dateOfBirth", "You must be over 16 years of age"));
    }

    @Test
    void registerAdminBrokerRegistrationValidationExceptionIsThrownWhenErrorResponseReceivedWithUsernameInUseMessage() {
        AdminRegistration request = createValidAdminRegistration();
        AdminRegistrationDto dto = createValidAdminRegistrationDto();
        AdminRegistrationResponseDto response = createAdminRegistrationResponseDto("Requested Username is already taken");

        when(this.mockBrokerRegistrationMapper.toAdminRegistrationDto(request)).thenReturn(dto);
        when(this.mockBrokerRegistrationConnectionHelper.registerAdmin(dto)).thenReturn(response);

        assertThat(catchThrowable(() -> brokerRegistrationService.registerAdmin(request)))
                .isInstanceOf(BrokerRegistrationValidationException.class)
                .isEqualTo(new BrokerRegistrationValidationException("username", "This username is already in use, please choose another"));
    }

    @Test
    void isUsernameAvailableReturnsTrueWhenReceivedFromHelper() {
        UsernameAvailableResponse usernameAvailableResponse = UsernameAvailableResponse.builder().isAvailable(true).build();

        when(this.mockBrokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USERNAME))
                .thenReturn(usernameAvailableResponse);

        assertTrue(brokerRegistrationService.isUsernameAvailable(TEST_USERNAME));
    }

    @Test
    void isUsernameAvailableReturnsFalseWhenReceivedFromHelper() {
        UsernameAvailableResponse usernameAvailableResponse = UsernameAvailableResponse.builder().isAvailable(false).build();

        when(this.mockBrokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USERNAME))
                .thenReturn(usernameAvailableResponse);

        assertFalse(brokerRegistrationService.isUsernameAvailable(TEST_USERNAME));
    }

    @Test
    void isUsernameAvailableThrowsExceptionWhenReceivedErrorFromHelper() {
        String expectedMessage = "expectedMessage";
        UsernameAvailableResponse usernameAvailableResponse = UsernameAvailableResponse.builder()
                .isAvailable(false)
                .isError(true)
                .error(expectedMessage)
                .build();

        when(this.mockBrokerRegistrationConnectionHelper.isUsernameAvailable(TEST_USERNAME))
                .thenReturn(usernameAvailableResponse);

        assertThat(catchThrowable(() -> brokerRegistrationService.isUsernameAvailable(TEST_USERNAME)))
                .isInstanceOf(UsernameAvailableException.class)
                .hasMessage(expectedMessage);
    }

    @Test
    void getFirmDetailsReturnsValidResponseFromHelper() {
        FirmDetailsResponse expectedResponse = createValidFirmDetailsResponse();
        FirmDetailsResponseDto expectedResponseDto = createValidFirmDetailsResponseDto();

        when(this.mockBrokerRegistrationConnectionHelper.getFirmDetails(
            BRAND_DEFAULT, TEST_FCA_NUMBER)).thenReturn(expectedResponseDto);
        when(this.mockFirmDetailsResponseMapper.toFirmDetails(TEST_FCA_NUMBER, expectedResponseDto)).thenReturn(expectedResponse);

        assertThat(this.brokerRegistrationService.getFirmDetails(BRAND_DEFAULT, TEST_FCA_NUMBER)).isEqualTo(expectedResponse);
    }

    @Test
    void getFirmDetailsThrowsExceptionWhenFirmDoesNotExist() {
        FirmDetailsResponseDto expectedResponseDto = createValidFirmDetailsResponseDto();
        expectedResponseDto.setIsExist(FALSE);

        when(this.mockBrokerRegistrationConnectionHelper.getFirmDetails(
            BRAND_DEFAULT, TEST_FCA_NUMBER)).thenReturn(expectedResponseDto);

        assertThat(catchThrowable(() -> this.brokerRegistrationService.getFirmDetails(
            BRAND_DEFAULT, TEST_FCA_NUMBER)))
                .isInstanceOf(BrokerFirmNotValidException.class)
                .hasMessage(EXPECTED_BROKER_FIRM_NOT_VALID_EXCEPTION_MSG);

        verifyNoInteractions(this.mockFirmDetailsResponseMapper);
    }

    @Test
    void getFirmDetailsThrowsExceptionWhenFirmNotAllowedToDoBusiness() {
        FirmDetailsResponseDto expectedResponseDto = createValidFirmDetailsResponseDto();
        expectedResponseDto.setIsAllowed(FALSE);

        when(this.mockBrokerRegistrationConnectionHelper.getFirmDetails(
            BRAND_DEFAULT, TEST_FCA_NUMBER)).thenReturn(expectedResponseDto);

        assertThat(catchThrowable(() -> this.brokerRegistrationService.getFirmDetails(
            BRAND_DEFAULT, TEST_FCA_NUMBER)))
                .isInstanceOf(BrokerFirmNotValidException.class)
                .hasMessage(EXPECTED_BROKER_FIRM_NOT_VALID_EXCEPTION_MSG);

        verifyNoInteractions(this.mockFirmDetailsResponseMapper);
    }
}