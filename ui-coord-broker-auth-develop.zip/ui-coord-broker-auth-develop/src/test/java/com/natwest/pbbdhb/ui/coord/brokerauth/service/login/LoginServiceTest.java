package com.natwest.pbbdhb.ui.coord.brokerauth.service.login;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.LoginContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LoginServiceTest {

  @Mock
  BrokerAuthClient brokerAuthClient;

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallLoginClient() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      service.login(loginAttempt);

      verify(brokerAuthClient).login(loginAttempt);
    }

    /**
     * Testing service handles response from client.
     */
    @Test
    void shouldReturnResponseFromLoginClient() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      when(brokerAuthClient.login(any())).thenReturn(UserRegistrationType.BROKER);

      assertThat(service.login(loginAttempt))
          .isEqualTo(UserRegistrationType.BROKER);
    }

    @Test
    void shouldReturnErrorIfLoginFailsDueToInvalidCredentials() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      doThrow(new LoginFailedException("Login failed")).when(brokerAuthClient).login(any());

      assertThatThrownBy(() -> service.login(loginAttempt)).isInstanceOf(
          LoginFailedException.class);

      verify(brokerAuthClient).login(loginAttempt);
    }

    @Test
    void shouldReturnErrorIfLoginFailsDueToAccountLocked() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      doThrow(new AccountLockedException("Account Locked")).when(brokerAuthClient).login(any());

      assertThatThrownBy(() -> service.login(loginAttempt)).isInstanceOf(
              AccountLockedException.class);

      verify(brokerAuthClient).login(loginAttempt);
    }

    @Test
    void shouldReturnErrorIfLoginFailsDueToExpiredPassword() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      doThrow(new PasswordExpiredException("Password Expired")).when(brokerAuthClient).login(any());

      assertThatThrownBy(() -> service.login(loginAttempt)).isInstanceOf(
              PasswordExpiredException.class);

      verify(brokerAuthClient).login(loginAttempt);
    }

    @Test
    void shouldReturnErrorIfLoginFails() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      doThrow(new UnauthorisedException(ErrorCode.UNAUTHORISED, "Login failed"))
          .when(brokerAuthClient).login(any());

      assertThatThrownBy(() -> service.login(loginAttempt)).isInstanceOf(
          UnauthorisedException.class);

      verify(brokerAuthClient).login(loginAttempt);
    }

    @Test
    void shouldReturnErrorIfDownstreamServiceReturnsError() {
      LoginRequestModel loginAttempt = LoginContext.builder().build().createLoginRequestModel();

      LoginService service = new LoginService(brokerAuthClient);

      doThrow(new RemoteRequestFailedException("Something went wrong"))
          .when(brokerAuthClient).login(any());

      assertThatThrownBy(() -> service.login(loginAttempt))
          .isInstanceOf(RemoteRequestFailedException.class);

      verify(brokerAuthClient).login(loginAttempt);
    }
  }
}