package com.natwest.pbbdhb.ui.coord.brokerauth.service.account;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccountManagementContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.MemorableQuestionAnswersValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.QuestionsNotRetrievedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountManagementServiceTest {

  @Mock
  BrokerAuthClient brokerAuthClient;

  @InjectMocks
  AccountManagementService accountManagementService;

  AccountManagementContext accountManagementContext = AccountManagementContext.builder()
          .build();

  @Nested
  @DisplayName("Retrieve Security Questions Cases")
  class RetrieveSecurityQuestionsCases {

    @Test
    void shouldCallBrokerAuthClientToRetrieveQuestions() {
      when(brokerAuthClient.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername())).thenReturn(
              accountManagementContext.securityQuestions());
      accountManagementService.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername());

      verify(brokerAuthClient).retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername());
    }

    @Test
    void shouldPassThroughQuestionsNotRetrievedException() {
      when(brokerAuthClient.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername())).thenThrow(
              new QuestionsNotRetrievedException("Test exception message"));

      assertThatThrownBy(() -> accountManagementService.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername()))
              .isInstanceOf(QuestionsNotRetrievedException.class).hasMessage("Test exception message");
    }

    @Test
    void shouldHandleRemoteRequestFailedException() {
      when(brokerAuthClient.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername())).thenThrow(
              new RemoteRequestFailedException("Test request failed exception"));

      assertThatThrownBy(() -> accountManagementService.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername()))
              .isInstanceOf(QuestionsNotRetrievedException.class).hasMessage(
              "Error retrieving questions for user: " + accountManagementContext.getUsername());
    }

    @Test
    void shouldThrowExceptionIfQuestionsAreNull() {
      when(brokerAuthClient.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername())).thenReturn(
              null);

      assertThatThrownBy(() -> accountManagementService.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername()))
              .isInstanceOf(QuestionsNotRetrievedException.class).hasMessage(
              "No questions retrieved for user: " + accountManagementContext.getUsername());
    }

    @Test
    void shouldThrowExceptionIfThereAreFewerThanTwoQuestions() {
      when(brokerAuthClient.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername())).thenReturn(
              accountManagementContext.securityQuestions().subList(0, 1)
      );

      assertThatThrownBy(() -> accountManagementService.retrieveSecurityQuestions(
              accountManagementContext.createRetrieveQuestionsRequestModel().getUsername()))
              .isInstanceOf(QuestionsNotRetrievedException.class).hasMessage(
              "Fewer than two questions retrieved for user: " + accountManagementContext.getUsername());
    }
  }

  @Nested
  @DisplayName("Validate Security Answers Cases")
  class ValidateSecurityAnswersCases {

    @Test
    void shouldCallBrokerAuthClientToValidateAnswers() {
      when(brokerAuthClient.validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel())).thenReturn(
              accountManagementContext.createValidateSecurityAnswersResponseModel());
      accountManagementService.validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel());

      verify(brokerAuthClient).validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel());
    }

    @Test
    void shouldPassThroughMemorableQuestionAnswersValidationException() {
      when(brokerAuthClient.validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel())).thenThrow(
              new MemorableQuestionAnswersValidationException(ErrorCode.MEMORABLE_QUESTIONS_LOCKED,
                      "Test exception message", new Throwable())
      );

      assertThatThrownBy(() -> accountManagementService.validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
              .isInstanceOf(MemorableQuestionAnswersValidationException.class)
              .hasMessage("Test exception message")
              .hasFieldOrPropertyWithValue("code", ErrorCode.MEMORABLE_QUESTIONS_LOCKED);
    }

    @Test
    void shouldPassThroughRemoteRequestFailedException() {
      when(brokerAuthClient.validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel()
      )).thenThrow(new RemoteRequestFailedException("Test request failed exception"));

      assertThatThrownBy(() -> accountManagementService.validateSecurityAnswers(
              accountManagementContext.createValidateSecurityAnswersRequestModel()))
              .isInstanceOf(RemoteRequestFailedException.class)
              .hasMessage("Test request failed exception");
    }
  }

  @Nested
  @DisplayName("Reset Password Cases")
  class ResetPasswordCases {
    @Test
    void shouldCallBrokerAuthClientToResetPassword() {
      ResetPasswordRequestModel req = accountManagementContext.createResetPasswordRequestModel();
      accountManagementService.resetPassword(req);
      verify(brokerAuthClient).resetPassword(req);
    }
  }

  @Nested
  @DisplayName("Validate Otp Cases")
  class ValidateOtpCases {
    @Test
    void shouldCallBrokerAuthClientToValidateOtp() {
      ValidateOtpRequestModel req = accountManagementContext.createValidateOtpRequestModel();
      accountManagementService.validateOtp(req);
      verify(brokerAuthClient).validateOtp(req);
    }
  }


  @Nested
  @DisplayName("Get Username Reminder Cases")
  class GetUsernameReminderCases {

    @Test
    void shouldCallBrokerAuthClientToGetUsernameReminder() {
      UsernameReminderRequest req = accountManagementContext.createUsernameReminderRequest();
      accountManagementService.getUsernameReminder(req);
      verify(brokerAuthClient).getUsernameReminder(req);
    }

    @Test
    void shouldPassThroughUsernameReminderValidationException() {
      doThrow(new InvalidDetailsException("Test validation exception message"))
              .when(brokerAuthClient).getUsernameReminder(
              accountManagementContext.createUsernameReminderRequest());

      assertThatThrownBy(() -> accountManagementService.getUsernameReminder(
              accountManagementContext.createUsernameReminderRequest()))
              .isInstanceOf(InvalidDetailsException.class)
              .hasMessage("Test validation exception message");
    }

    @Test
    void shouldPassThroughRemoteRequestFailedException() {
      doThrow(new RemoteRequestFailedException("Test request failed exception"))
              .when(brokerAuthClient).getUsernameReminder(
              accountManagementContext.createUsernameReminderRequest());

      assertThatThrownBy(() -> accountManagementService.getUsernameReminder(
              accountManagementContext.createUsernameReminderRequest()))
              .isInstanceOf(RemoteRequestFailedException.class)
              .hasMessage("Test request failed exception");


    }
  }
}
