package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication;

import static com.github.tomakehurst.wiremock.client.WireMock.exactly;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccessTokenContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"integration"})
@AutoConfigureWireMock(port = 0)
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
public class AuthenticationRestClientIT {

  @Autowired
  AuthenticationRestClient client;

  @Nested
  @DisplayName("retrieve access-token cases")
  class RetrieveAccessTokenCases {

    @Test
    void shouldReturnAccessTokenForValidRequest() {

      final AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

      WireMock.stubFor(AuthenticationWireMockServer.mappingAccessTokenRequest(
          AuthenticationWireMockServer.getAccessTokenResponse(),
          HttpStatus.OK));

      BrokerPortalAccessTokenResponseModel responseModel = accessTokenContext.createBrokerPortalAccessTokenResponseModel();

      BrokerPortalAccessTokenResponseModel token = client.retrieve(
              accessTokenContext.createBrokerAccessTokenRequestModel());
      Assertions.assertThat(token).isEqualTo(responseModel);
    }

    @Test
    void shouldThrowExceptionForInvalidRequest() {

      final AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();

      WireMock.stubFor(AuthenticationWireMockServer.mappingAccessTokenRequest(
          AuthenticationWireMockServer.getErrorResponse(),
          HttpStatus.UNAUTHORIZED));

      BrokerPortalAccessTokenRequestModel requestModel = accessTokenContext.createBrokerAccessTokenRequestModel();
      Assertions.assertThatThrownBy(() -> client.retrieve(requestModel))
          .isInstanceOf(RemoteRequestFailedException.class);
    }

    @Test
    void shouldThrowExceptionForServerError() {
      final AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
      WireMock.stubFor(
          WireMock.post(WireMock.urlPathEqualTo(AuthenticationWireMockServer.accessTokenPath())
          ).willReturn(WireMock.serverError()));

      BrokerPortalAccessTokenRequestModel requestModel = accessTokenContext.createBrokerAccessTokenRequestModel();

      Assertions.assertThatThrownBy(() -> client.retrieve(requestModel))
          .isInstanceOf(RemoteRequestFailedException.class)
          .hasMessageContaining("500 Server Error");
    }
  }

  @Nested
  @DisplayName("revoke access-token cases")
  class RevokeAccessTokenCases {

    @Test
    void shouldReturnNoContent() {
      WireMock
          .stubFor(WireMock
              .delete(WireMock.urlPathEqualTo(AuthenticationWireMockServer.accessTokenPath()))
              .willReturn(WireMock.noContent()));

      client.revoke();

      WireMock.verify(
          exactly(1),
          WireMock.deleteRequestedFor(WireMock.urlPathMatching(
              AuthenticationWireMockServer.accessTokenPath())));

    }

  }


}
