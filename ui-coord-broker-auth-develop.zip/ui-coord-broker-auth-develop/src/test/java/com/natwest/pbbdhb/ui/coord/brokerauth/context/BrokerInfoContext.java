package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.AddressInfoModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.PaymentPathDetailsModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.*;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;

@Getter
@ToString
@Builder
public class BrokerInfoContext {

    @Default
    public String username = "TestUsername";

    @Default
    private String brokerId = "TestBrokerId";

    @Default
    private String firstname = "TestFirstname";

    @Default
    private String middleName = "TestMiddleName";

    @Default
    private String lastname = "TestLastname";

    @Default
    private String title = "Mr";

    @Default
    private String emailAddress = "test@email.com";

    @Default
    private String mobilePhone = "0797777777";

    @Default
    private String businessPhone = "07912312345";

    @Default
    private String postcode = "NE2 1AA";

    @Default
    private String firmName = "TestFirmName";

    @Default
    private String tradingName = "TestTradingName";

    @Default
    private String fcaNumber = "TestFcaNumber";

    @Default
    private String principalFcaNumber = "TestPrincipalFcaNumber";

    @Default
    private AddressInfoModel address = AddressInfoModel.builder()
            .postcode("TestFirmPostcode")
            .line1("Test Address")
            .city("Newcastle")
            .build();

    @Default
    private String firmPostCode = "TestFirmPostcode";

    @Default
    private String firmLine1 = "Test Address";

    @Default
    private String firmCity = "Newcastle";

    @Default
    private List<PaymentPathDetailsModel> paymentPaths = Collections.singletonList(PaymentPathDetailsModel.builder()
            .paymentPathId("1")
            .paymentPathName("TestPaymentPath")
            .build());

    @Default
    private List<PaymentPathDto> paymentPathDtos = Collections.singletonList(PaymentPathDto.builder()
            .paymentPathId("1")
            .paymentPathname("TestPaymentPath")
            .build());

    public BrokerInfoBrokerDomainModel createBrokerInfoDomainModel() {
        return BrokerInfoBrokerDomainModel.builder()
                .brokerId(brokerId)
                .username(username)
                .title(title)
                .brokerFirstName(firstname)
                .brokerLastName(lastname)
                .emailAddress(emailAddress)
                .businessPhone(businessPhone)
                .mobileNumber(mobilePhone)
                .brokerPostcode(postcode)
                .fcaNumber(fcaNumber)
                .principalFcaNumber(principalFcaNumber)
                .firmName(firmName)
                .paymentPaths(paymentPaths)
                .firmAddress(address)
                .tradingName(tradingName)
                .build();
    }

    public BrokerInfoResponseDto createBrokerInfoDto() {
        return BrokerInfoResponseDto.builder()
                .broker(BrokerInfoDto.builder()
                        .brokerId(brokerId)
                        .username(username)
                        .title(title)
                        .firstName(firstname)
                        .lastName(lastname)
                        .emailAddress(emailAddress)
                        .businessPhone(businessPhone)
                        .mobileNumber(mobilePhone)
                        .brokerPostcode(postcode)
                        .build()
                )
                .firm(FirmDto.builder()
                        .firmName(firmName)
                        .fcaNumber(fcaNumber)
                        .principleFcaNumber(principalFcaNumber)
                        .firmAddressLine1(firmLine1)
                        .firmAddressCity(firmCity)
                        .firmAddressPostcode(firmPostCode)
                        .build())
                .paymentPaths(paymentPathDtos)
                .tradingName(TradingNameDto.builder()
                        .name(tradingName)
                        .build())
                .build();
    }

    public AdminInfoDto createAdminInfoDto() {
        return AdminInfoDto.builder()
                .brokerAdminId(brokerId)
                .username(username)
                .title(title)
                .firstName(firstname)
                .middleName(middleName)
                .lastName(lastname)
                .emailAddress(emailAddress)
                .businessPhone(businessPhone)
                .mobileNumber(mobilePhone)
                .firmName(firmName)
                .fcaNumber(fcaNumber)
                .principleFcaNumber(principalFcaNumber)
                .build();
    }

    public BrokerInfoBrokerDomainModel createAdminInfoBrokerDomainModel() {
        return BrokerInfoBrokerDomainModel.builder()
                .brokerId(brokerId)
                .username(username)
                .title(title)
                .brokerFirstName(firstname)
                .brokerLastName(lastname)
                .emailAddress(emailAddress)
                .businessPhone(businessPhone)
                .mobileNumber(mobilePhone)
                .fcaNumber(fcaNumber)
                .principalFcaNumber(principalFcaNumber)
                .firmName(firmName)
                .build();
    }
}
