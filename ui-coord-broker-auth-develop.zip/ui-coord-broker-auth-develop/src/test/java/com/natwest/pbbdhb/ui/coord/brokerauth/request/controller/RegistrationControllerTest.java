package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailActivationCodeTemplateConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeGenerateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailActivationCodeRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.account.AccountManagementService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.email.EmailService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.registration.RegistrationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RegistrationControllerTest {

  @Mock
  private RegistrationService registrationService;

  @Mock
  private AccountManagementService accountManagementService;

  @Mock
  private EmailActivationCodeTemplateConfig activationCodeTemplate;

  @Mock
  private EmailService emailService;

  @Captor
  private ArgumentCaptor<EmailActivationCodeRequestModel> emailActivationCodeRequestModelArgumentCaptor;

  @InjectMocks
  private RegistrationController registrationController;

  @Test
  void testActivationCode() {
    when(registrationService.activationCode(any())).thenReturn("ACTIVATION_CODE");
    when(accountManagementService.getBrokerDetails(eq("username"))).thenReturn(BrokerDetailsResponse.builder()
        .brokerDetails(BrokerDetails.builder()
            .email("example@email.test")
            .firstName("John")
            .lastName("Doe")
            .build())
        .build());
    when(activationCodeTemplate.getName()).thenReturn("Activation Code Template Name");
    when(activationCodeTemplate.getRegistrationUrl()).thenReturn("http://registration-url/");

    final ActivationCodeGenerateRequestModel request = ActivationCodeGenerateRequestModel.builder()
        .username("username")
        .build();

    registrationController.activationCode(request);

    verify(emailService, times(1)).send(emailActivationCodeRequestModelArgumentCaptor.capture());
    EmailActivationCodeRequestModel value = emailActivationCodeRequestModelArgumentCaptor.getValue();

    assertEquals("Activation Code Template Name", value.getTemplateName());
    assertEquals("example@email.test", value.getToRecipients());
    assertEquals("John", value.getFirstname());
    assertEquals("Doe", value.getSurname());
    assertEquals("http://registration-url/", value.getRegistrationUrl());
    assertEquals("ACTIVATION_CODE", value.getActivationCode());
  }
}