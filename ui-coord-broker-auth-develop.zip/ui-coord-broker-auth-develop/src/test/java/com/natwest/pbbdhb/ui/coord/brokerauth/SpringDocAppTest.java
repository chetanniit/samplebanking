package com.natwest.pbbdhb.ui.coord.brokerauth;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.springframework.http.HttpEntity.EMPTY;
import static org.springframework.http.HttpMethod.GET;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("integration")
public class SpringDocAppTest {
    @Autowired
    TestRestTemplate template;

    @Test
    public void shouldDisplaySwaggerUiPage() {
        // Just assert that we have a page with the title "Swagger UI". The details are filled in by javascript
        // afterwards, it seems.
        ResponseEntity<String> response =
                template.exchange(template.getRootUri() + "/swagger-ui/index.html", GET, EMPTY, String.class);
        assertThat(HttpStatus.OK, equalTo(response.getStatusCode()));
        assertThat(response.getHeaders().getContentType(), equalTo(MediaType.TEXT_HTML));
        assertThat(response.getBody(), containsString("Swagger UI"));
    }
}

