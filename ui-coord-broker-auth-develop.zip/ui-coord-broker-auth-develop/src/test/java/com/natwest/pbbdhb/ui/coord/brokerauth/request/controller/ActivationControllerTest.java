package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.ui.coord.brokerauth.BrokerAuthenticationApplication;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthWireMockServer;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.config.TestConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.server.JwtGenerator;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * In this test, the full Spring app context is started,with wiremock
 */
@ActiveProfiles(profiles = {"integration", "secured"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {
        BrokerAuthenticationApplication.class, TestConfig.class
    })
@AutoConfigureWireMock(port = 0)
class ActivationControllerTest {

  private static final String CLAIMSETJWT = "iam-claimsetjwt";

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Value("${server.servlet.context-path}")
  String contextPath;

  @LocalServerPort
  private int port;

  RequestSpecification givenRequestToController() {
    String basePath = UriComponentsBuilder
        .fromPath(contextPath)
        .pathSegment("activation")
        .build()
        .getPath();
    return RestAssured
        .given().log().all()
        .accept(ContentType.JSON)
        .basePath(basePath)
        .port(this.port)
        .header(CLAIMSETJWT, JwtGenerator.createJwt(microserviceIssuer));
  }

  @Nested
  @DisplayName("Validate User")
  class ValidateUserCases {

    @Test
    void shouldCallMetricService() {
      ActivateUserRequest request = ActivationContext.builder().build()
          .createUserActivateRequest();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.noContent())));

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("")
          .then()
          .log()
          .all();

      WireMock.verify(1, postRequestedFor(urlEqualTo("/mortgages/v1/msvc-broker-auth/activation")));
      WireMock.verify(1, postRequestedFor(urlEqualTo("/mbs_CreateBrokerEvent")));


    }

  }

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    @Test
    void shouldNotCallMetricService() {
      ActivationCodeValidateRequest request = ActivationContext.builder().build()
          .createActivationCodeValidateRequest();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.noContent())));

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.noContent())));

      givenRequestToController()
          .contentType(ContentType.JSON)
          .body(request)
          .post("/validate")
          .then()
          .log()
          .all();

      WireMock.verify(1, postRequestedFor(urlEqualTo("/mortgages/v1/msvc-broker-auth/activation/validate")));
      WireMock.verify(0, postRequestedFor(urlEqualTo("/mbs_CreateBrokerEvent")));


    }

  }
}