package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import jakarta.validation.ConstraintViolation;
import org.junit.jupiter.api.Test;

import java.util.Set;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.getConstraintViolations;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class UserDetailsValidationTest {

    private static final String UNEXPECTED_ADDITIONAL_VIOLATION = "unexpected additional constraint violation";

    @Test
    public void validBrokerDetailsHasNoErrors() {
        UserDetails userDetails = createValidUserDetails();

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertEquals(0, violations.size(), "Unexpected constraint violation");
    }

    @Test
    public void validBrokerDetailsWithOnlyMobilePhoneNumberHasNoErrors() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setOtherPhoneNumber(null);

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertEquals(0, violations.size(), "Unexpected constraint violation");
    }

    @Test
    public void validBrokerDetailsWithOnlyOtherPhoneNumberHasNoErrors() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setMobilePhoneNumber(null);

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertEquals(0, violations.size(), "Unexpected constraint violation");
    }

    @Test
    public void nullBothPhoneNumbersCausesValidationError() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setMobilePhoneNumber(null);
        userDetails.setOtherPhoneNumber(null);
        String violationMissed = "phone numbers @AtLeastOneNotNullValidator violation not reported";

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertTrue(violations.size() > 0, violationMissed);
        assertTrue(violations.size() < 2, UNEXPECTED_ADDITIONAL_VIOLATION);
    }

    @Test
    public void nullTitleCausesValidationError() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setTitle(null);
        String violationMissed = "title @NotNull violation not reported";

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertTrue(violations.size() > 0, violationMissed);
        assertTrue(violations.size() < 2, UNEXPECTED_ADDITIONAL_VIOLATION);
    }
    
    @Test
    public void blankLastNameCausesValidationError() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setLastName(" ");
        String violationMissed = "lastName @NotBlank violation not reported";

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertTrue(violations.size() > 0, violationMissed);
        assertTrue(violations.size() < 2, UNEXPECTED_ADDITIONAL_VIOLATION);
    }

    @Test
    public void nullDateOfBirthCausesValidationError() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setDateOfBirth(null);
        String violationMissed = "dateOfBirth @NotBlank violation not reported";

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertTrue(violations.size() > 0, violationMissed);
        assertTrue(violations.size() < 2, UNEXPECTED_ADDITIONAL_VIOLATION);
    }

    @Test
    public void nullEmailAddressCausesValidationError() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setEmailAddress(null);
        String violationMissed = "emailAddress @NotBlank violation not reported";

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertTrue(violations.size() > 0, violationMissed);
        assertTrue(violations.size() < 2, UNEXPECTED_ADDITIONAL_VIOLATION);
    }

    @Test
    public void wrongFormatEmailAddressCausesValidationError() {
        UserDetails userDetails = createValidUserDetails();
        userDetails.setEmailAddress("someone_at_somewhere");
        String violationMissed = "emailAddress @Email format violation not reported";

        Set<ConstraintViolation<UserDetails>> violations = getConstraintViolations(userDetails);

        assertTrue(violations.size() > 0, violationMissed);
        assertTrue(violations.size() < 2, UNEXPECTED_ADDITIONAL_VIOLATION);
    }
}
