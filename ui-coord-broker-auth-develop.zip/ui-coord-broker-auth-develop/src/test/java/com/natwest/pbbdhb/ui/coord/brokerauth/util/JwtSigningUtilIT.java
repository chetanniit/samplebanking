package com.natwest.pbbdhb.ui.coord.brokerauth.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.CertificateModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.JsonWebTokenModel;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import java.security.PublicKey;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Tests the JWT signing service that is responsible to creating and signing JWTs.
 */
@ActiveProfiles(profiles = {
    "integration"
})
@SpringBootTest
public class JwtSigningUtilIT {

  private static final String ALGORITHM_ID = AlgorithmIdentifiers.RSA_USING_SHA256;
  private static final String KEY_ID = "hbo_key_id";
  private static final String X5T = "hbo_x5t";
  private static final String ISSUER = "hbo_issuer";
  private static final String SUBJECT = "hbo_subject";
  private static final String AUDIENCE = "https://iam-authn-sit-nwb.managedtest.com/as/token.oauth2";

  @Qualifier("crmJwtSigningCertificate")
  @Autowired
  private CertificateModel certificate;

  @Autowired
  MicroserviceIssuer microserviceIssuer;

  @Test
  public void shouldCreateJsonWebTokenFromModel() {
    final String jwt = JwtSigningUtil.createJwt(jwtModel(), certificate.getPrivateKey());
    assertThat(jwt).isNotEmpty();
  }

  @Test
  public void shouldVerifySignatureOfJsonWebTokenUsingPublicKey() throws JoseException {
    // create signed JWT as string
    final String jwt = JwtSigningUtil.createJwt(jwtModel(), certificate.getPrivateKey());

    // convert back to a JWS
    JsonWebSignature jws = new JsonWebSignature();
    jws.setCompactSerialization(jwt);
    jws.setKey(certificate.getPublicKey());

    // confirms our JWT (signed by our private key) can be verified by the public key
    assertThat(jws.verifySignature()).isTrue();
  }

  @Test
  public void JsonWebTokenShouldContainExpectedHeaders() throws JoseException {
    // create signed JWT as string
    final String jwt = JwtSigningUtil.createJwt(jwtModel(), certificate.getPrivateKey());

    // convert back to a JWS
    JsonWebSignature jws = new JsonWebSignature();
    jws.setCompactSerialization(jwt);
    jws.setKey(certificate.getPublicKey());

    // confirm JWT contains the expected headers
    assertThat(jws.getAlgorithmHeaderValue()).isEqualTo(ALGORITHM_ID);
    assertThat(jws.getKeyIdHeaderValue()).isEqualTo(KEY_ID);
    assertThat(jws.getHeader(HeaderParameterNames.TYPE)).isEqualTo("JWT");
    assertThat(jws.getHeader(HeaderParameterNames.X509_CERTIFICATE_THUMBPRINT)).isEqualTo(X5T);
  }

  @Test
  public void JsonWebTokenShouldContainExpectedPayload() throws JoseException {
    // create signed JWT as string
    final String jwt = JwtSigningUtil.createJwt(jwtModel(), certificate.getPrivateKey());

    // convert back to a JWS
    JsonWebSignature jws = new JsonWebSignature();
    jws.setCompactSerialization(jwt);
    jws.setKey(certificate.getPublicKey());

    // confirm JWT contains the expected payload
    final String jsonPayload = jws.getPayload();
    assertThat(extract(jsonPayload, "$.sub")).isEqualTo(SUBJECT);
    assertThat(extract(jsonPayload, "$.iss")).isEqualTo(ISSUER);
    assertThat(extract(jsonPayload, "$.aud")).isEqualTo(AUDIENCE);
    assertThat(extract(jsonPayload, "$.iat")).isNotNull();
    assertThat(extract(jsonPayload, "$.exp")).isNotNull();
    assertThat(extract(jsonPayload, "$.jti")).isNotNull();
  }

  /**
   * A JWT signed by our private key can only be verified using the associated public key.
   * <p>
   * This test proves that any attempt to verify the JWT using an different public key will fail.
   */
  @Test
  public void shouldNotVerifySignatureOfJsonWebTokenUsingIncorrectPublicKey()
      throws JoseException {
    // create signed JWT as string
    final String jwt = JwtSigningUtil.createJwt(jwtModel(), certificate.getPrivateKey());

    // extract public key used to initialise our micro-service.
    // we could use any public key for our test. this is just an easy way to retrieve one.
    final PublicKey otherPublicKey = microserviceIssuer
        .getInitialisationCertificate()
        .getPublicKey();

    // convert back to a JWS
    JsonWebSignature jws = new JsonWebSignature();
    jws.setCompactSerialization(jwt);
    jws.setKey(otherPublicKey);

    // confirm our JWT (signed by our private key) can NOT be verified by unrelated public key
    assertThat(jws.verifySignature()).isFalse();
  }

  /**
   * Extract Object from JSON payload using JSON Path
   */
  private Object extract(String payload, String jsonPath) {
    try {
      return JsonPath
          .parse(payload)
          .read(jsonPath, Object.class);
    } catch (PathNotFoundException e) {
      return null;
    }
  }

  /**
   * Helper to create JWT Model
   */
  private JsonWebTokenModel jwtModel() {
    return JsonWebTokenModel
        .builder()
        .header(JsonWebTokenModel.HeaderModel.builder()
            .algorithm(ALGORITHM_ID)
            .kid(KEY_ID)
            .x5t(X5T)
            .build())
        .payload(JsonWebTokenModel.PayloadModel.builder()
            .issuer(ISSUER)
            .subject(SUBJECT)
            .audience(AUDIENCE)
            .build())
        .build();
  }
}
