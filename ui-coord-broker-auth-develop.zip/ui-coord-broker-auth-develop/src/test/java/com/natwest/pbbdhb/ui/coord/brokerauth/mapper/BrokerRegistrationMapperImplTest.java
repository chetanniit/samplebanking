package com.natwest.pbbdhb.ui.coord.brokerauth.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        BrokerRegistrationMapperImpl.class
})
class BrokerRegistrationMapperImplTest {

    @Autowired
    private BrokerRegistrationMapperImpl brokerRegistrationMapper;

    @Test
    void toBrokerRegistrationDtoMapsCorrectly() {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        BrokerRegistrationDto expectedResult = createValidBrokerRegistrationDto();

        BrokerRegistrationDto result = this.brokerRegistrationMapper.toBrokerRegistrationDto(brokerRegistration);

        assertThat(result).usingRecursiveComparison().isEqualTo(expectedResult);
    }

    @Test
    void toBrokerRegistrationDtoMapsCorrectlyWhenBrokerDetailsNull() {
        final String okUsername = newRandomUserName();
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setUsername(okUsername);
        brokerRegistration.setBrokerDetails(null);
        BrokerRegistrationDto expectedResult = createValidBrokerRegistrationDto();
        expectedResult.setUsername(okUsername);
        expectedResult.setBrokerDetails(null);
        expectedResult.setResidentialAddress(null);

        BrokerRegistrationDto result = this.brokerRegistrationMapper.toBrokerRegistrationDto(brokerRegistration);

        assertThat(result).usingRecursiveComparison().isEqualTo(expectedResult);
    }

    @Test
    void toBrokerRegistrationDtoMapsCorrectlyWhenAddressNull() {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setAddress(null);
        BrokerRegistrationDto expectedResult = createValidBrokerRegistrationDto();
        expectedResult.setAddress(null);

        BrokerRegistrationDto result = this.brokerRegistrationMapper.toBrokerRegistrationDto(brokerRegistration);

        assertThat(result).usingRecursiveComparison().isEqualTo(expectedResult);
    }

    @Test
    void toBrokerRegistrationDtoMapsCorrectlyWhenFirmDetailsNull() {
        BrokerRegistration brokerRegistration = createValidBrokerRegistration();
        brokerRegistration.setFirmDetails(null);
        BrokerRegistrationDto expectedResult = createValidBrokerRegistrationDto();
        expectedResult.setFirmDetails(null);
        expectedResult.setTradingNames(null);

        BrokerRegistrationDto result = this.brokerRegistrationMapper.toBrokerRegistrationDto(brokerRegistration);

        assertThat(result).usingRecursiveComparison().isEqualTo(expectedResult);
    }

    @Test
    void toBrokerRegistrationDtoReturnsNullWhenBrokerRegistrationNull() {
        assertThat(this.brokerRegistrationMapper.toBrokerRegistrationDto(null)).isNull();
    }
}