package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth;


import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccountManagementContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.ActivationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.LoginContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.RegistrationContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.Brand;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ActivationCodeException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.MemorableQuestionAnswersValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.QuestionsNotRetrievedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ResetPasswordException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ValidateOtpException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.security.UserClaimsProvider;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"integration"})
@AutoConfigureWireMock(port = 0)
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
public class BrokerAuthRestClientIT {

  @Autowired
  BrokerAuthRestClient restClient;

  @MockBean
  UserClaimsProvider userClaimsProvider;

  @Autowired
  private ObjectMapper objectMapper;

  @BeforeEach
  public void setup() {
    when(userClaimsProvider.getOperatingBrand()).thenReturn(Brand.NWB);
  }

  @Nested
  @DisplayName("Activate User Cases")
  class ActivateUserCases {

    @Test
    void shouldActivateUser() throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.noContent())));

      restClient.activate(activationContext.createActivateUserRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(
                      activationContext.createActivateUserRequestModel()))));
    }

    @Test
    void shouldReturnInvalidDetailsIfResponseIsBadRequest() throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())));

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();
      assertThatThrownBy(
          () -> restClient.activate(activateUserRequestModel))
          .isInstanceOf(InvalidDetailsException.class);

      WireMock.verify(exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(
                      activationContext.createActivateUserRequestModel()))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithOtpValidationFailedErrorCode()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_VALIDATION_FAILED))));

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();

      assertThatThrownBy(() -> restClient.activate(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(activateUserRequestModel))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithActivationCodeIsExpired()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_EXPIRED))));

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();

      assertThatThrownBy(() -> restClient.activate(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_EXPIRED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(activateUserRequestModel))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithAccountIsLocked()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.ACCOUNT_LOCKED))));

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();

      assertThatThrownBy(() -> restClient.activate(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.ACCOUNT_LOCKED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(activateUserRequestModel))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithInvalidCredentialsErrorCode()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_CREDENTIALS))));

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();

      assertThatThrownBy(() -> restClient.activate(activateUserRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_CREDENTIALS);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(activateUserRequestModel))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsInternalServerError()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingActivationRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      ActivateUserRequestModel activateUserRequestModel = activationContext.createActivateUserRequestModel();
      assertThatThrownBy(
          () -> restClient.activate(activateUserRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForActivateUserRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(
                      activationContext.createActivateUserRequestModel()))));
    }
  }

  @Nested
  @DisplayName("Register User cases")
  class RegisterUserCases {

    @Test
    void shouldCreateUser() throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.created())));

      restClient.createUser(context.createCreateUserRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(context.createCreateUserRequestModel()))));
    }

    @Test
    void shouldReturnUserAlreadyExistsExceptionIfResponseIsConflict()
        throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.status(409))));

      CreateUserRequestModel createUserRequestModel = context.createCreateUserRequestModel();
      assertThatThrownBy(
          () -> restClient.createUser(createUserRequestModel))
          .isInstanceOf(UserAlreadyExistsException.class);

      WireMock.verify(exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(context.createCreateUserRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())));

      CreateUserRequestModel createUserRequestModel = context.createCreateUserRequestModel();
      assertThatThrownBy(
          () -> restClient.createUser(createUserRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(context.createCreateUserRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsInternalServerError()
        throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      CreateUserRequestModel createUserRequestModel = context.createCreateUserRequestModel();
      assertThatThrownBy(
          () -> restClient.createUser(createUserRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(context.createCreateUserRequestModel()))));
    }
  }

  @Nested
  @DisplayName("Delete User Code Cases")
  class DeleteUserCodeCases {

    @Test
    void shouldDeleteUser() throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingDeleteRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.noContent())));

      restClient.deleteUser(context.createDeleteUserRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForDeleteRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(context.createDeleteUserRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingDeleteRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())));

      DeleteUserRequestModel deleteUserRequestModel = context.createDeleteUserRequestModel();
      assertThatThrownBy(
              () -> restClient.deleteUser(deleteUserRequestModel))
              .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(exactly(1),
              BrokerAuthWireMockServer.patternForDeleteRequest()
                      .withRequestBody(equalToJson(
                              objectMapper.writeValueAsString(context.createDeleteUserRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsInternalServerError()
            throws JsonProcessingException {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingDeleteRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      DeleteUserRequestModel deleteUserRequestModel = context.createDeleteUserRequestModel();
      assertThatThrownBy(
              () -> restClient.deleteUser(deleteUserRequestModel))
              .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(exactly(1),
              BrokerAuthWireMockServer.patternForDeleteRequest()
                      .withRequestBody(equalToJson(
                              objectMapper.writeValueAsString(context.createDeleteUserRequestModel()))));
    }
  }

  @Nested
  @DisplayName("Validate Activation Code Cases")
  class ValidateActivationCodeCases {

    @Test
    void shouldValidateUser() throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.noContent())));

      restClient.validateActivationCode(
          activationContext.createActivationCodeValidateRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())));

      ActivationCodeValidateRequestModel activationCodeValidateRequestModel =
          activationContext.createActivationCodeValidateRequestModel();
      assertThatThrownBy(
          () -> restClient.validateActivationCode(
              activationCodeValidateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsInternalServerError()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      ActivationCodeValidateRequestModel activationCodeValidateRequestModel = activationContext.createActivationCodeValidateRequestModel();
      assertThatThrownBy(
          () -> restClient.validateActivationCode(
              activationCodeValidateRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithAccountLockedErrorCode()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.ACCOUNT_LOCKED))));

      ActivationCodeValidateRequestModel activationCodeValidateRequestModel = activationContext.createActivationCodeValidateRequestModel();
      assertThatThrownBy(
          () -> restClient.validateActivationCode(activationCodeValidateRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.ACCOUNT_LOCKED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithOtpExpiredErrorCode()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_EXPIRED))));

      ActivationCodeValidateRequestModel activationCodeValidateRequestModel = activationContext.createActivationCodeValidateRequestModel();
      assertThatThrownBy(
          () -> restClient.validateActivationCode(activationCodeValidateRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_EXPIRED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithInvalidCredentialsErrorCode()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_CREDENTIALS))));

      ActivationCodeValidateRequestModel activationCodeValidateRequestModel = activationContext.createActivationCodeValidateRequestModel();
      assertThatThrownBy(
          () -> restClient.validateActivationCode(activationCodeValidateRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_CREDENTIALS);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }

    @Test
    void shouldReturnActivationCodeExceptionIfResponseIsUnauthorisedWithOtpValidationFailedErrorCode()
        throws JsonProcessingException {
      ActivationContext activationContext = ActivationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_VALIDATION_FAILED))));

      ActivationCodeValidateRequestModel activationCodeValidateRequestModel = activationContext.createActivationCodeValidateRequestModel();
      assertThatThrownBy(
          () -> restClient.validateActivationCode(activationCodeValidateRequestModel))
          .isInstanceOf(ActivationCodeException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateActivationCodeRequest()
              .withRequestBody(equalToJson(objectMapper.writeValueAsString(
                  activationContext.createActivationCodeValidateRequestModel()))));
    }
  }

  @Nested
  @DisplayName("Login Cases")
  class LoginCases {

    @Test
    void shouldLogin() throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(
          BrokerAuthWireMockServer.mappingLoginRequest()
              .willReturn(WireMock.ok()
                  .withHeader(HttpHeaders.CONTENT_TYPE, "application/json")
                  .withBody(objectMapper.writeValueAsString(UserRegistrationType.BROKER))));

      restClient.login(loginContext.createLoginRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForLoginRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }

    @Test
    void shouldReturnLoginFailedIfResponseIsUnauthorisedWithInvalidCredentials()
        throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingLoginRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(
              WireMock.unauthorized().withBody("INVALID_CREDENTIALS"))));

      LoginRequestModel loginRequestModel = loginContext.createLoginRequestModel();
      assertThatThrownBy(
          () -> restClient.login(loginRequestModel))
          .isInstanceOf(LoginFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForLoginRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }

    @Test
    void shouldReturnAccountLockedIfResponseIsUnauthorisedWithAccountLocked()
        throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingLoginRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(
              WireMock.unauthorized().withBody("ACCOUNT_LOCKED"))));

      LoginRequestModel loginRequestModel = loginContext.createLoginRequestModel();
      assertThatThrownBy(
          () -> restClient.login(loginRequestModel))
          .isInstanceOf(AccountLockedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForLoginRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }

    @Test
    void shouldReturnPasswordExpiredIfResponseIsUnauthorisedWithPasswordExpired()
            throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingLoginRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(
                      WireMock.unauthorized().withBody("PASSWORD_EXPIRED"))));

      LoginRequestModel loginRequestModel = loginContext.createLoginRequestModel();
      assertThatThrownBy(
              () -> restClient.login(loginRequestModel))
              .isInstanceOf(PasswordExpiredException.class);

      WireMock.verify(WireMock.exactly(1),
              BrokerAuthWireMockServer.patternForLoginRequest()
                      .withRequestBody(equalToJson(
                              objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }

    @Test
    void shouldReturnUnauthorisedIfResponseIsUnauthorised() throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingLoginRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.unauthorized())));

      LoginRequestModel loginRequestModel = loginContext.createLoginRequestModel();
      assertThatThrownBy(
          () -> restClient.login(loginRequestModel))
          .isInstanceOf(UnauthorisedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForLoginRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingLoginRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())));

      LoginRequestModel loginRequestModel = loginContext.createLoginRequestModel();
      assertThatThrownBy(
          () -> restClient.login(loginRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForLoginRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsInternalServerError()
        throws JsonProcessingException {
      LoginContext loginContext = LoginContext.builder().build();

      WireMock.stubFor(
          BrokerAuthWireMockServer.mappingLoginRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      LoginRequestModel loginRequestModel = loginContext.createLoginRequestModel();
      assertThatThrownBy(
          () -> restClient.login(loginRequestModel))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForLoginRequest()
              .withRequestBody(equalToJson(
                  objectMapper.writeValueAsString(loginContext.createLoginRequestModel()))));
    }
  }

  @Nested
  @DisplayName("Generate Activation Code cases")
  class GenerateActivationCodeCases {

    @Test
    void shouldCallBrokerAuthClient() {
      RegistrationContext context = RegistrationContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingGenerateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.CREATED,
              BrokerAuthWireMockServer.getActivationCodeResponse())));

      restClient.generateActivationCode(context.getUsername());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForGenerateActivationCodeRequest());
    }

    @Test
    void shouldReturnActivationCodeClientResponse() {
      RegistrationContext context = RegistrationContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingGenerateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.CREATED,
              BrokerAuthWireMockServer.getActivationCodeResponse())));

      String result = restClient.generateActivationCode(
          context.getUsername());

      String expected = context.createActivationCodeClientResponse().getCode();

      Assertions.assertEquals(expected, result);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForGenerateActivationCodeRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsBadRequest() {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingGenerateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())));

      String username = context.getUsername();
      assertThatThrownBy(
          () -> restClient.generateActivationCode(username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForGenerateActivationCodeRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedIfResponseIsInternalServerError() {
      RegistrationContext context = RegistrationContext.builder().build();

      WireMock.stubFor(BrokerAuthWireMockServer.mappingGenerateActivationCodeRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      String username = context.getUsername();
      assertThatThrownBy(
          () -> restClient.generateActivationCode(username))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForGenerateActivationCodeRequest());
    }
  }

  @Nested
  @DisplayName("Retrieve Questions Cases")
  class RetrieveQuestionsCases {

    @Test
    void shouldCallBrokerAuthClient() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveQuestionsRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK,
              BrokerAuthWireMockServer.getRetrieveQuestionsResponse())));

      restClient.retrieveSecurityQuestions(context.getUsername());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveQuestionsRequest());
    }

    @Test
    void shouldReturnSecurityQuestionsResponse() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveQuestionsRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK,
              BrokerAuthWireMockServer.getRetrieveQuestionsResponse())));

      List<String> result = restClient.retrieveSecurityQuestions(context.getUsername());

      List<String> expected = context.securityQuestions();

      Assertions.assertEquals(expected, result);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveQuestionsRequest());
    }

    @Test
    void shouldReturnQuestionsNotRetrievedExceptionIfResponseIsBadRequest() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveQuestionsRequest().willReturn(
          BrokerAuthWireMockServer.jsonResponse(WireMock.badRequest())
      ));

      assertThatThrownBy(
          () -> restClient.retrieveSecurityQuestions(context.getUsername())

      ).isInstanceOf(QuestionsNotRetrievedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveQuestionsRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedExceptionIfResponseIsInternalServerError() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingRetrieveQuestionsRequest().willReturn(
          BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())
      ));

      assertThatThrownBy(
          () -> restClient.retrieveSecurityQuestions(context.getUsername())

      ).isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForRetrieveQuestionsRequest());
    }
  }

  @Nested
  @DisplayName("Validate Answers Cases")
  class ValidateAnswersCases {

    @Test
    void shouldCallBrokerAuthClient() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateAnswersRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK,
              BrokerAuthWireMockServer.getValidateAnswersResponse())));

      restClient.validateSecurityAnswers(context.createValidateSecurityAnswersRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateAnswersRequest());
    }

    @Test
    void shouldReturnValidateAnswersResponse() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateAnswersRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK,
              BrokerAuthWireMockServer.getValidateAnswersResponse())));

      ValidateSecurityAnswersResponseModel result = restClient.validateSecurityAnswers(
          context.createValidateSecurityAnswersRequestModel());

      ValidateSecurityAnswersResponseModel expected = context.createValidateSecurityAnswersResponseModel();

      Assertions.assertEquals(expected, result);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateAnswersRequest());
    }

    @Test
    void shouldReturnMemorableQuestionAnswersValidationExceptionIfAnswersAreIncorrect() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateAnswersRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(
                  ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS))));

      assertThatThrownBy(
          () -> restClient.validateSecurityAnswers(
              context.createValidateSecurityAnswersRequestModel())
      ).isInstanceOf(MemorableQuestionAnswersValidationException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateAnswersRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedExceptionIfResponseIsInternalServerError() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateAnswersRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      assertThatThrownBy(
          () -> restClient.validateSecurityAnswers(
              context.createValidateSecurityAnswersRequestModel())
      ).isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateAnswersRequest());
    }
  }

  @Nested
  @DisplayName("Reactivate User Cases")
  class ReactivateUserCases {

    @Test
    void shouldCallBrokerAuthClient() {
      RegistrationContext context = RegistrationContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingReactivateUserRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.CREATED,
              BrokerAuthWireMockServer.getReactivateUserResponse())));

      restClient.reactivateUser(context.getUsername());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForReactivateUserRequest());
    }

    @Test
    void shouldReturnReactivateUserResponse() {
      RegistrationContext context = RegistrationContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingReactivateUserRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.CREATED,
              BrokerAuthWireMockServer.getReactivateUserResponse())));

      String result = restClient.reactivateUser(context.getUsername());

      String expected = context.getReactivationCode();

      Assertions.assertEquals(expected, result);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForReactivateUserRequest());
    }

    @Test
    void shouldReturnUserNotFoundExceptionIfUserNotFound() {
      RegistrationContext context = RegistrationContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingReactivateUserRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.USER_NOT_FOUND))));

      assertThatThrownBy(
          () -> restClient.reactivateUser(context.getUsername()))
          .isInstanceOf(UserNotFoundException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForReactivateUserRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedExceptionIfResponseIsInternalServerError() {
      RegistrationContext context = RegistrationContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingReactivateUserRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      assertThatThrownBy(
          () -> restClient.reactivateUser(context.getUsername()))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForReactivateUserRequest());
    }
  }

  @Nested
  @DisplayName("Reset Password cases")
  class ResetPasswordCases {

    @Test
    void shouldCallBrokerAuthClient() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK)));

      restClient.resetPassword(context.createResetPasswordRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfUserNotFound() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.USER_NOT_FOUND))));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(ResetPasswordException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.USER_NOT_FOUND);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfInvalidDetails() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_DETAILS))));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(ResetPasswordException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_DETAILS);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfAccountLocked() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.ACCOUNT_LOCKED))));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(ResetPasswordException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.ACCOUNT_LOCKED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfInvalidCredentials() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_CREDENTIALS))));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(ResetPasswordException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_CREDENTIALS);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfOtpExpired() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_EXPIRED))));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(ResetPasswordException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_EXPIRED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfOtpValidationFailed() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_VALIDATION_FAILED))));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(ResetPasswordException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }

    @Test
    void shouldReturnResetPasswordExceptionIfInternalServerError() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingResetPasswordRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      assertThatThrownBy(
          () -> restClient.resetPassword(context.createResetPasswordRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForResetPasswordRequest());
    }
  }

  @Nested
  @DisplayName("Validate OTP cases")
  class ValidateOtpCases {

    @Test
    void shouldCallBrokerAuthClient() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateOtpRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK)));

      restClient.validateOtp(context.createValidateOtpRequestModel());

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnValidateOtpExceptionIfAccountLocked() throws JsonProcessingException {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateOtpRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.ACCOUNT_LOCKED))));


      assertThatThrownBy(
          () -> restClient.validateOtp(context.createValidateOtpRequestModel()))
          .isInstanceOf(ValidateOtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.ACCOUNT_LOCKED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnValidateOtpExceptionIfInvalidCredentials() throws JsonProcessingException {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateOtpRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_CREDENTIALS))));


      assertThatThrownBy(
          () -> restClient.validateOtp(context.createValidateOtpRequestModel()))
          .isInstanceOf(ValidateOtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_CREDENTIALS);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnValidateOtpExceptionIfOtpExpired() throws JsonProcessingException {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateOtpRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_EXPIRED))));


      assertThatThrownBy(
          () -> restClient.validateOtp(context.createValidateOtpRequestModel()))
          .isInstanceOf(ValidateOtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_EXPIRED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnValidateOtpExceptionIfOtpValidationFailed() throws JsonProcessingException {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateOtpRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.UNAUTHORIZED,
              BrokerAuthWireMockServer.errorResponseBody(ErrorCode.OTP_VALIDATION_FAILED))));


      assertThatThrownBy(
          () -> restClient.validateOtp(context.createValidateOtpRequestModel()))
          .isInstanceOf(ValidateOtpException.class)
          .hasFieldOrPropertyWithValue("code", ErrorCode.OTP_VALIDATION_FAILED);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateOtpRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedExceptionIfResponseIsInternalServerError() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingValidateOtpRequest()
          .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      assertThatThrownBy(
          () -> restClient.validateOtp(context.createValidateOtpRequestModel()))
          .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
          BrokerAuthWireMockServer.patternForValidateOtpRequest());
    }

    @Nested
    @DisplayName("Broker Details Cases")
    class BrokerDetailsCases {

      @Test
      void shouldCallBrokerAuthClient() {
        AccountManagementContext context = AccountManagementContext.builder().build();
        WireMock.stubFor(BrokerAuthWireMockServer.mappingGetBrokerDetailsRequest()
            .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK)));

        restClient.getBrokerDetails(context.getUsername());

        WireMock.verify(WireMock.exactly(1),
            BrokerAuthWireMockServer.patternForGetBrokerDetails());
      }

      @Test
      void shouldReturnBrokerDetailsExceptionIfBadRequest() {
        AccountManagementContext context = AccountManagementContext.builder().build();
        WireMock.stubFor(BrokerAuthWireMockServer.mappingGetBrokerDetailsRequest()
            .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST,
                BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_REQUEST))));


        assertThatThrownBy(
            () -> restClient.getBrokerDetails(context.getUsername()))
            .isInstanceOf(BrokerDetailsException.class)
            .hasFieldOrPropertyWithValue("code", ErrorCode.INVALID_REQUEST);

        WireMock.verify(WireMock.exactly(1),
            BrokerAuthWireMockServer.patternForGetBrokerDetails());
      }

      @Test
      void shouldReturnInternalServerError() {
        AccountManagementContext context = AccountManagementContext.builder().build();
        WireMock.stubFor(BrokerAuthWireMockServer.mappingGetBrokerDetailsRequest()
            .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.INTERNAL_SERVER_ERROR,
                BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INTERNAL_SERVER_ERROR))));


        assertThatThrownBy(
            () -> restClient.getBrokerDetails(context.getUsername()))
            .isInstanceOf(RemoteRequestFailedException.class);
        WireMock.verify(WireMock.exactly(1),
            BrokerAuthWireMockServer.patternForGetBrokerDetails());

      }
    }
  }

  @Nested
  @DisplayName("Get Username Reminder cases")
  class GetUsernameReminderCases {

    @Test
    void shouldCallBrokerAuthClientAndGetUsernameFound() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingGetUsernameReminderRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK,
              BrokerAuthWireMockServer.getUsernameReminderResponseUserFound())));

      restClient.getUsernameReminder(context.createUsernameReminderRequest());

      WireMock.verify(WireMock.exactly(1),
              BrokerAuthWireMockServer.patternForUsernameReminderRequest());
    }

    @Test
    void shouldCallBrokerAuthClientAndGetUsernameNotFound() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingGetUsernameReminderRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.OK,
                      BrokerAuthWireMockServer.getUsernameReminderResponseUserNotFound())));

      restClient.getUsernameReminder(context.createUsernameReminderRequest());

      WireMock.verify(WireMock.exactly(1),
              BrokerAuthWireMockServer.patternForUsernameReminderRequest());
    }

    @Test
    void shouldReturnInvalidRequestIfResponseIsBadRequest() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingGetUsernameReminderRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(HttpStatus.BAD_REQUEST,
                      BrokerAuthWireMockServer.errorResponseBody(ErrorCode.INVALID_REQUEST))));

      assertThatThrownBy(
              () -> restClient.getUsernameReminder(context.createUsernameReminderRequest()))
              .isInstanceOf(InvalidDetailsException.class);

      WireMock.verify(WireMock.exactly(1),
              BrokerAuthWireMockServer.patternForUsernameReminderRequest());
    }

    @Test
    void shouldReturnRemoteRequestFailedExceptionIfResponseIsInternalServerError() {
      AccountManagementContext context = AccountManagementContext.builder().build();
      WireMock.stubFor(BrokerAuthWireMockServer.mappingGetUsernameReminderRequest()
              .willReturn(BrokerAuthWireMockServer.jsonResponse(WireMock.serverError())));

      assertThatThrownBy(
              () -> restClient.getUsernameReminder(context.createUsernameReminderRequest()))
              .isInstanceOf(RemoteRequestFailedException.class);

      WireMock.verify(WireMock.exactly(1),
              BrokerAuthWireMockServer.patternForUsernameReminderRequest());
    }
  }
}
