package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.mapper;


import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain.BrokerPortalAccessTokenClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.AccessTokenContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.AuthenticationClientContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AuthenticationClientMapperTest {

    @Test
    public void shouldMapAccessTokenClientRequestForBroker() {
        AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
        AuthenticationClientContext authenticationClientContext = AuthenticationClientContext.builder().build();

        BrokerPortalAccessTokenClientRequest request = AuthenticationClientMapper.toBrokerPortalAccessTokenClientRequest(accessTokenContext.createBrokerAccessTokenRequestModel());

        assertThat(request).isEqualTo(authenticationClientContext.createBrokerAccessTokenClientRequest());
    }

    @Test
    public void shouldReturnNullForMissingDetailsForBroker() {
        BrokerPortalAccessTokenClientRequest request = AuthenticationClientMapper.toBrokerPortalAccessTokenClientRequest(
                BrokerPortalAccessTokenRequestModel.builder()
                        .brokerRole(UserRegistrationType.BROKER).build());

        assertThat(request).isEqualTo(BrokerPortalAccessTokenClientRequest.builder().brokerRole(UserRegistrationType.BROKER).build());
    }

    @Test
    public void shouldMapAccessTokenClientRequestForAdmin() {
        AccessTokenContext accessTokenContext = AccessTokenContext.builder().build();
        AuthenticationClientContext authenticationClientContext = AuthenticationClientContext.builder().build();

        BrokerPortalAccessTokenClientRequest request = AuthenticationClientMapper.toBrokerPortalAccessTokenClientRequest(accessTokenContext.createAdminAccessTokenRequestModel());

        assertThat(request).isEqualTo(authenticationClientContext.createAdminAccessTokenClientRequest());
    }

    @Test
    public void shouldReturnNullForMissingDetailsForAdmin() {
        BrokerPortalAccessTokenClientRequest request = AuthenticationClientMapper.toBrokerPortalAccessTokenClientRequest(
                BrokerPortalAccessTokenRequestModel.builder()
                        .brokerRole(UserRegistrationType.ADMIN).build());

        assertThat(request).isEqualTo(BrokerPortalAccessTokenClientRequest.builder().brokerRole(UserRegistrationType.ADMIN).build());
    }

}
