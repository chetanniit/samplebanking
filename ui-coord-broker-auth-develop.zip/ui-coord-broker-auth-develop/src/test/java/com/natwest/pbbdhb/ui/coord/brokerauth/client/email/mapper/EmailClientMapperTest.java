package com.natwest.pbbdhb.ui.coord.brokerauth.client.email.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.domain.EmailClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.EmailContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailActivationCodeRequestModel;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class EmailClientMapperTest {

  @Nested
  @DisplayName("Email Cases")
  class EmailCases {

    @Test
    void toEmailClientModel() {
      EmailContext context = EmailContext.builder().build();
      EmailActivationCodeRequestModel requestModel = context.createEmailRequestModel();

      EmailClientRequest clientRequest = EmailClientMapper.toClientModel(requestModel);

      assertEquals(requestModel.getTemplateName(), clientRequest.getTemplateName());

      Map<String, Object> params = clientRequest.getParameters();

      assertFalse(params.containsKey("templateName"));
      assertEquals(requestModel.getFirstname(), params.get("firstname"));
      assertEquals(requestModel.getSurname(), params.get("surname"));
      assertEquals(requestModel.getToRecipients(), params.get("toRecipients"));
      assertEquals(requestModel.getRegistrationUrl(), params.get("registrationUrl"));
      assertEquals(requestModel.getActivationCode(), params.get("activationCode"));
   }
  }
}