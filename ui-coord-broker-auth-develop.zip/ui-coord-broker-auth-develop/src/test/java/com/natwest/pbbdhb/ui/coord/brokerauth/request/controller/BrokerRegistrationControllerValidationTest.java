package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BRAND_INVALID_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BUSINESS_DECLARATION_NOT_CONFIRMED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.FCA_NUMBER_INVALID_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PARAM_FCA_NUMBER;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PARAM_USERNAME;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PATH_FIRM_DETAILS;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PATH_USERNAME_VERIFICATION;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PRIVACY_POLICY_NOT_ACCEPTED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.USERNAME_INVALID_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.BRAND_RBS;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.ENUM_BROKER_TYPE_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_EMPTY_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.SIZE_ERROR_MESSAGE;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidFirmDetailsResponse;
import static java.lang.Boolean.FALSE;
import static java.util.Collections.emptyList;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.CONFLICT;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.OK;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Sets;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerFirmNotValidException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerRegistrationValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.BrokerRegistrationService;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import java.util.Arrays;
import java.util.Collections;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.util.UriComponentsBuilder;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("integration")
class BrokerRegistrationControllerValidationTest {

  public static final String STRING_251 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
  public static final String STRING_101 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
  public static final String STRING_21 = "aaaaaaaaaaaaaaaaaaaaa";
  @Autowired
  private TestRestTemplate restTemplate;

  @MockBean
  private BrokerRegistrationService mockBrokerRegistrationService;

  private BrokerRegistration brokerRegistration;

  @BeforeEach
  private void resetBrokerRegistration() {
    brokerRegistration = TestUtil.createValidBrokerRegistration();
  }

  @Test
  public void registerBrokerReturnsAcceptedWhenRequestIsValid() {
    ResponseEntity<Void> response =
        restTemplate.postForEntity(
            restTemplate.getRootUri() + "/registerBroker", brokerRegistration, Void.class);
    assertEquals(ACCEPTED, response.getStatusCode());
    assertNull(response.getBody());
    verify(mockBrokerRegistrationService).registerBroker(brokerRegistration);
  }

  @Test
  public void registerBrokerReturnsBadRequestWhenBrokerRegistrationValidationExceptionIsThrown() {
    String expectedErrorField = "expectedField";
    String expectedErrorMessage = "expectedMessage";
    doThrow(new BrokerRegistrationValidationException(expectedErrorField, expectedErrorMessage))
        .when(mockBrokerRegistrationService).registerBroker(brokerRegistration);

    ResponseEntity<ErrorResponse> response =
        restTemplate.postForEntity(
            restTemplate.getRootUri() + "/registerBroker", brokerRegistration,
            ErrorResponse.class);

    assertEquals(BAD_REQUEST, response.getStatusCode());
    assertEquals(ErrorResponse.invalidDetails(new ValidationErrorResponse(
            Collections.singleton(new Violation(expectedErrorField, expectedErrorMessage)))),
        response.getBody());
    assertEquals(MediaType.APPLICATION_JSON, response.getHeaders().getContentType());
  }

  @ParameterizedTest(name = "{index} {0}")
  @MethodSource("registerBrokerArgs")
  public void invalidateEachValidatedFieldAndConfirmExceptionIsReturned(String testDescription,
      Consumer<BrokerRegistration> mutator,
      ErrorResponse expected) {
    mutator.accept(brokerRegistration);
    ResponseEntity<ErrorResponse> response =
        restTemplate.postForEntity(
            restTemplate.getRootUri() + "/registerBroker", brokerRegistration,
                ErrorResponse.class);
    assertEquals(expected.getCode(), response.getBody().getCode());
    assertEquals(expected.getStatus(), response.getBody().getStatus());
    assertEquals(expected.getDescription(), response.getBody().getDescription());
    assertTrue(expected.getErrors().containsAll(response.getBody().getErrors()));
    HttpHeaders headers = response.getHeaders();
    assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
    assertNotNull(headers.getFirst("x-fapi-interaction-id"));
  }

  @Test
  public void invalidateEnumAndConfirmExceptionIsReturned() throws JsonProcessingException {
    String brString = TestUtil.createValidBrokerRegistrationJson();
    brString = brString.replace("CAPTAIN", "WING_COMMANDER");
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<String> request =
        new HttpEntity<>(brString, httpHeaders);
    ResponseEntity<ErrorResponse> response =
        restTemplate.postForEntity(
            restTemplate.getRootUri() + "/registerBroker", request, ErrorResponse.class);

    String startOfExpectedMessage = "JSON parse error: Cannot deserialize value of type " +
        "`com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.Title` from String " +
        "\"WING_COMMANDER\": not one of the values accepted for Enum class: [MASTER, " +
        "SISTER, MR, COLONEL, HON, GENERAL, LADY, REVEREND, DR, VISCOUNT, OTHER, LORD, " +
        "COUNTESS, MAJOR, MISS, CAPTAIN, MS, MX, MRS, EARL, SIR, PROFESSOR]";
    ErrorResponse body = response.getBody();
    assertNotNull(body);
    assertTrue(
        body.getErrors().stream().anyMatch(e -> e.getDescription().startsWith(startOfExpectedMessage)));
    HttpHeaders headers = response.getHeaders();
    assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
    assertNotNull(headers.getFirst("x-fapi-interaction-id"));
  }

  private static Stream<Arguments> registerBrokerArgs() {
    return Stream.of(
        Arguments.of("null brokerDetails.title",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setTitle(null),
            ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.title", "must not be null"))))),
        Arguments.of("null brokerDetails.lastName",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setLastName(null),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.lastName", "must not be blank"))))),
        Arguments.of("blank brokerDetails.lastName",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setLastName(""),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.lastName", "must not be blank"))))),
        Arguments.of("null brokerDetails.dateOfBirth",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setDateOfBirth(null),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.dateOfBirth", "must not be null"))))),
        Arguments.of("null brokerDetails.emailAddress",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setEmailAddress(null),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.emailAddress", "must not be blank"))))),
        Arguments.of("blank brokerDetails.emailAddress",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setEmailAddress(""),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.emailAddress", "must not be blank"))))),
        Arguments.of("invalid brokerDetails.emailAddress",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setEmailAddress("invalid"),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.emailAddress",
                    "must be a well-formed email address"))))),
        Arguments.of("invalid brokerDetails.emailAddress",
            (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setEmailAddress("invalid"),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails.emailAddress",
                    "must be a well-formed email address"))))),
        Arguments.of("invalid brokerDetails.emailAddress & null dateOfBirth",
            (Consumer<BrokerRegistration>) b -> {
              b.getBrokerDetails().setEmailAddress("invalid");
              b.getBrokerDetails().setDateOfBirth(null);
            },
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                Arrays.asList(new Violation("brokerDetails.dateOfBirth", "must not be null"),
                    new Violation("brokerDetails.emailAddress",
                        "must be a well-formed email address")))))),

        Arguments.of("null brokerDetails.nationality",
                (Consumer<BrokerRegistration>) b -> b.getBrokerDetails().setNationality(null),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                        new Violation("brokerDetails.nationality", "must not be blank"))))),

        Arguments.of("invalid username", (Consumer<BrokerRegistration>) b -> b.setUsername(null),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("username", MUST_NOT_BE_NULL_ERROR_MESSAGE))))),

        Arguments.of("invalid paymentPaths",
            (Consumer<BrokerRegistration>) b -> b.setPaymentPaths(emptyList()),
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("paymentPaths", MUST_NOT_BE_EMPTY_ERROR_MESSAGE))))),

        Arguments.of("invalid all agreements", (Consumer<BrokerRegistration>) b -> {
              b.getAgreements().setPrivacyPolicy(FALSE);
              b.getAgreements().setTermsOfBusiness(FALSE);
              b.getAgreements().setBusinessDeclaration(FALSE);
            },
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                new Violation("agreements.privacyPolicy", PRIVACY_POLICY_NOT_ACCEPTED_MSG),
                new Violation("agreements.termsOfBusiness", TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG),
                new Violation("agreements.businessDeclaration",
                    BUSINESS_DECLARATION_NOT_CONFIRMED_MSG))))),

        Arguments.of("invalid address - null town and postcode",
            (Consumer<BrokerRegistration>) b -> {
              b.getAddress().setTown(null);
              b.getAddress().setPostcode(null);
            },
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                new Violation("address.town", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                new Violation("address.postcode", MUST_NOT_BE_BLANK_ERROR_MESSAGE))))),

            Arguments.of("invalid residential address - null town and postcode",
                    (Consumer<BrokerRegistration>) b -> {
                      b.getBrokerDetails().getResidentialAddress().setAddressLine1(null);
                      b.getBrokerDetails().getResidentialAddress().setTown(null);
                      b.getBrokerDetails().getResidentialAddress().setPostcode(null);
                    },
                    ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                            new Violation("brokerDetails.residentialAddress.addressLine1", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                            new Violation("brokerDetails.residentialAddress.town", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                            new Violation("brokerDetails.residentialAddress.postcode", MUST_NOT_BE_BLANK_ERROR_MESSAGE))))),

            Arguments.of("invalid residential address - max length exceeded",
                    (Consumer<BrokerRegistration>) b -> {
                      b.getBrokerDetails().getResidentialAddress().setAddressLine1(STRING_251);
                      b.getBrokerDetails().getResidentialAddress().setAddressLine2(STRING_251);
                      b.getBrokerDetails().getResidentialAddress().setAddressLine3(STRING_251);
                      b.getBrokerDetails().getResidentialAddress().setTown(STRING_101);
                      b.getBrokerDetails().getResidentialAddress().setCountryOfAddress(STRING_101);
                      b.getBrokerDetails().getResidentialAddress().setCounty(STRING_101);
                      b.getBrokerDetails().getResidentialAddress().setPostcode(STRING_21);
                    },
                    ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                            new Violation("brokerDetails.residentialAddress.addressLine1", String.format(SIZE_ERROR_MESSAGE, 250)),
                            new Violation("brokerDetails.residentialAddress.addressLine2", String.format(SIZE_ERROR_MESSAGE, 250)),
                            new Violation("brokerDetails.residentialAddress.addressLine3", String.format(SIZE_ERROR_MESSAGE, 250)),
                            new Violation("brokerDetails.residentialAddress.town", String.format(SIZE_ERROR_MESSAGE, 100)),
                            new Violation("brokerDetails.residentialAddress.county", String.format(SIZE_ERROR_MESSAGE, 100)),
                            new Violation("brokerDetails.residentialAddress.countryOfAddress", String.format(SIZE_ERROR_MESSAGE, 100)),
                            new Violation("brokerDetails.residentialAddress.postcode", String.format(SIZE_ERROR_MESSAGE, 20)))))),

            Arguments.of("invalid nationality - max length exceeded",
                    (Consumer<BrokerRegistration>) b -> {
                      b.getBrokerDetails().setNationality(STRING_251);
                    },
                    ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                            new Violation("brokerDetails.nationality", String.format(SIZE_ERROR_MESSAGE, 250)))))),


            Arguments.of(
            "invalid firmDetails - brokerType, firmName, fcaNumber, principalFcaNumber, previousFirmName and previousFirmFcaNumber",
            (Consumer<BrokerRegistration>) b -> {
              b.getFirmDetails().setBrokerType("invalid");
              b.getFirmDetails().setFirmName(null);
              b.getFirmDetails().setFcaNumber(null);
              b.getFirmDetails().setPreviousFcaNumber(null);
            },
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Sets.newHashSet(
                new Violation("firmDetails.fcaNumber", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                new Violation("firmDetails.brokerType", ENUM_BROKER_TYPE_ERROR_MESSAGE),
                new Violation("firmDetails.firmName", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                new Violation("firmDetails", PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG),
                new Violation("firmDetails",
                    PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG))))),

        Arguments.of("null both phone numbers", (Consumer<BrokerRegistration>) b -> {
              b.getBrokerDetails().setMobilePhoneNumber(null);
              b.getBrokerDetails().setOtherPhoneNumber(null);
            },
                ErrorResponse.invalidDetails(new ValidationErrorResponse(Collections.singleton(
                new Violation("brokerDetails",
                    "at least one of the fields 'mobilePhoneNumber, otherPhoneNumber' must not be null")))))
    );
  }

  @Test
  public void isUsernameAvailableReturnsOkWhenUsernameIsAvailable() {
    String validUsername = randomAlphabetic(20);
    when(this.mockBrokerRegistrationService.isUsernameAvailable(validUsername)).thenReturn(true);

    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_USERNAME_VERIFICATION);
    uriBuilder.queryParam(PARAM_USERNAME, validUsername);
    ResponseEntity<Void> response = restTemplate.getForEntity(uriBuilder.build().toUri(),
        Void.class);

    assertEquals(OK, response.getStatusCode());
  }

  @Test
  public void isUsernameAvailableReturnsConflictWhenUsernameIsNotAvailable() {
    String validUsername = randomAlphabetic(6);
    when(this.mockBrokerRegistrationService.isUsernameAvailable(validUsername)).thenReturn(false);

    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_USERNAME_VERIFICATION);
    uriBuilder.queryParam(PARAM_USERNAME, validUsername);
    ResponseEntity<Void> response = restTemplate.getForEntity(uriBuilder.build().toUri(),
        Void.class);

    assertEquals(CONFLICT, response.getStatusCode());
  }

  @ParameterizedTest(name = "{index} {0}")
  @MethodSource("isUsernameAvailableArgs")
  public void isUsernameAvailableWithValidationErrorsReturnsBadRequestError(String testDescription,
      String usernameToTest, ErrorResponse expected) {
    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_USERNAME_VERIFICATION);
    uriBuilder.queryParam(PARAM_USERNAME, usernameToTest);
    ResponseEntity<ErrorResponse> response = restTemplate.getForEntity(
        uriBuilder.build().toUri(), ErrorResponse.class);

    assertEquals(BAD_REQUEST, response.getStatusCode());
    assertEquals(expected, response.getBody());
    assertEquals(MediaType.APPLICATION_JSON, response.getHeaders().getContentType());
    verifyNoInteractions(this.mockBrokerRegistrationService);
  }

  private static Stream<Arguments> isUsernameAvailableArgs() {
    return Stream.of(
        Arguments.of("Username too short", randomAlphabetic(5), ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("isUsernameAvailable.username", USERNAME_INVALID_MSG))))),
        Arguments.of("Username too long", randomAlphabetic(21), ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("isUsernameAvailable.username", USERNAME_INVALID_MSG))))),
        Arguments.of("Username contains whitespace", "Bob Jones", ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("isUsernameAvailable.username", USERNAME_INVALID_MSG))))),
        Arguments.of("Username contains @", "abc@def", ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("isUsernameAvailable.username", USERNAME_INVALID_MSG)))))
    );
  }


  @Test
  public void getFirmDetailsReturnsOkWhenFcaNumberIsValid() {
    String validFcaNumber = randomNumeric(6);
    FirmDetailsResponse expectedResponse = createValidFirmDetailsResponse();
    when(this.mockBrokerRegistrationService.getFirmDetails(BRAND_DEFAULT,
        validFcaNumber)).thenReturn(expectedResponse);

    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_FIRM_DETAILS);
    uriBuilder.queryParam(PARAM_FCA_NUMBER, validFcaNumber);
    ResponseEntity<FirmDetailsResponse> response = restTemplate.getForEntity(
        uriBuilder.build().toUri(), FirmDetailsResponse.class);

    assertEquals(OK, response.getStatusCode());
    assertEquals(expectedResponse, response.getBody());
  }

  @Test
  public void getFirmDetailsReturnsNotFoundWhenFcaNumberIsNotValid() {
    String validFcaNumber = randomNumeric(7);
    when(this.mockBrokerRegistrationService.getFirmDetails(BRAND_RBS, validFcaNumber)).thenThrow(
        new BrokerFirmNotValidException("expected"));

    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_FIRM_DETAILS);
    uriBuilder.queryParam(PARAM_FCA_NUMBER, validFcaNumber);
    final HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_RBS);
    ResponseEntity<Object> response = restTemplate.exchange(uriBuilder.build().toUri(), GET,
        new HttpEntity<>(headers), Object.class);

    assertEquals(NOT_FOUND, response.getStatusCode());
  }


  @Test
  public void getFirmDetailsReturnsBadRequestWhenBrandHeaderInvalid() {
    String validFcaNumber = randomNumeric(7);

    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_FIRM_DETAILS);
    uriBuilder.queryParam(PARAM_FCA_NUMBER, validFcaNumber);
    final HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, "invalid");
    ResponseEntity<ErrorResponse> response = restTemplate.exchange(
        uriBuilder.build().toUri(), GET, new HttpEntity<>(headers), ErrorResponse.class);

    assertEquals(BAD_REQUEST, response.getStatusCode());
    assertEquals(ErrorResponse.invalidDetails(new ValidationErrorResponse(
            Collections.singleton(new Violation("getFirmDetails.brand", BRAND_INVALID_MSG)))),
        response.getBody());
    verifyNoInteractions(this.mockBrokerRegistrationService);
  }

  @ParameterizedTest(name = "{index} {0}")
  @MethodSource("getFirmDetailsArgs")
  public void getFirmDetailsWithValidationErrorsReturnsBadRequestError(String testDescription,
      String fcaNumberToTest, ErrorResponse expected) {
    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(restTemplate.getRootUri());
    uriBuilder.path(PATH_FIRM_DETAILS);
    uriBuilder.queryParam(PARAM_FCA_NUMBER, fcaNumberToTest);
    ResponseEntity<ErrorResponse> response = restTemplate.getForEntity(
        uriBuilder.build().toUri(), ErrorResponse.class);

    assertEquals(BAD_REQUEST, response.getStatusCode());
    assertEquals(expected, response.getBody());
    assertEquals(MediaType.APPLICATION_JSON, response.getHeaders().getContentType());
    verifyNoInteractions(this.mockBrokerRegistrationService);
  }

  private static Stream<Arguments> getFirmDetailsArgs() {
    return Stream.of(
        Arguments.of("Fca number too short", randomNumeric(5), ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("getFirmDetails.fcanumber", FCA_NUMBER_INVALID_MSG))))),
        Arguments.of("Fca number too long", randomNumeric(8), ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("getFirmDetails.fcanumber", FCA_NUMBER_INVALID_MSG))))),
        Arguments.of("Fca number invalid characters", "12345a", ErrorResponse.invalidDetails(new ValidationErrorResponse(
            singleton(new Violation("getFirmDetails.fcanumber", FCA_NUMBER_INVALID_MSG)))))
    );
  }
}