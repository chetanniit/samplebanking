package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.BrokerInfoClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.context.BrokerInfoContext;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AdminInfoServiceTest {

  @Mock
  BrokerInfoClient brokerClient;

  @Nested
  @DisplayName("Admin Broker Info Cases")
  class AdminInfoCases {

    /**
     * Testing service passes request through to client.
     */
    @Test
    void shouldCallBrokerClient() {
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder()
          .address(null)
          .paymentPaths(null)
          .postcode(null)
          .build();
      String username = brokerInfoContext.getUsername();
      BrokerInfoBrokerDomainModel expectedAdmin = brokerInfoContext.createBrokerInfoDomainModel();

      AdminTypeInfoService service = new AdminTypeInfoService(brokerClient);

      when(brokerClient.getAdminInfo(username)).thenReturn(expectedAdmin);

      service.getBrokerInfo(username);

      verify(brokerClient).getAdminInfo(username);
    }

    /**
     * Testing service handles response from client.
     */
    @Test
    void shouldReturnResponseFromBrokerClient() {
      BrokerInfoContext brokerInfoContext = BrokerInfoContext.builder()
          .address(null)
          .paymentPaths(null)
          .postcode(null)
          .build();
      String username = brokerInfoContext.getUsername();
      BrokerInfoBrokerDomainModel expectedBroker = brokerInfoContext.createBrokerInfoDomainModel();

      AdminTypeInfoService service = new AdminTypeInfoService(brokerClient);

      when(brokerClient.getAdminInfo(username)).thenReturn(expectedBroker);

      assertThat(service.getBrokerInfo(username))
          .isEqualTo(expectedBroker);
    }
  }
}