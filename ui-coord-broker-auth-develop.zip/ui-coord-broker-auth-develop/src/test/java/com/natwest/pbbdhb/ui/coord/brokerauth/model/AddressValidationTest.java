package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;

import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class AddressValidationTest extends AbstractValidationTest<Address> {

    private static Stream<Arguments> provideArgs() {
        return Stream.of(
                Arguments.of("Valid Address", (Consumer<Address>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid Address when non required fields empty", (Consumer<Address>) a -> {
                    a.setAddressLine2(null);
                    a.setAddressLine3(null);
                    a.setCounty(null);
                }, EMPTY_SET),
                Arguments.of("Address line 1 is null", (Consumer<Address>) a -> a.setAddressLine1(null), singleton(
                    TestValidationError.create("addressLine1", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Address line 1 is blank", (Consumer<Address>) a -> a.setAddressLine1(""), singleton(
                    TestValidationError.create("addressLine1", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Town is null", (Consumer<Address>) a -> a.setTown(null), singleton(
                    TestValidationError.create("town", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Town is blank", (Consumer<Address>) a -> a.setTown(""), singleton(
                    TestValidationError.create("town", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Postcode is null", (Consumer<Address>) a -> a.setPostcode(null), singleton(
                    TestValidationError.create("postcode", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Postcode is blank", (Consumer<Address>) a -> a.setPostcode(""), singleton(
                    TestValidationError.create("postcode", MUST_NOT_BE_BLANK_ERROR_MESSAGE)))
                );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("provideArgs")
    public void testAddressValidations(String testDescription, Consumer<Address> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtil::createValidAddress, mutator, expectedErrorMessages);
    }
}
