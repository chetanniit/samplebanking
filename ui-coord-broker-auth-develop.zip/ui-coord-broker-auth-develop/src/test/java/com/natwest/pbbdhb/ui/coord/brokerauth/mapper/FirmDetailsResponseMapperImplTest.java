package com.natwest.pbbdhb.ui.coord.brokerauth.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.AlternativeTradingNamesDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.FirmDetailsResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.PaymentPath;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.PrincipalFcaFirm;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        FirmDetailsResponseMapperImpl.class
})
public class FirmDetailsResponseMapperImplTest {
    @Autowired
    private FirmDetailsResponseMapper firmDetailsResponseMapper;

    @Value("classpath:test-files/firms/ar-multiple-multiple.json")
    private Resource arMultipleFirmsMultiplePrincipals;

    @Value("classpath:test-files/firms/da-multiple.json")
    private Resource daMultipleFirmsNoPrincipals;

    @Value("classpath:test-files/firms/not-do-business.json")
    private Resource notDoBusiness;

    @Value("classpath:test-files/firms/not-exist.json")
    private Resource notExist;

    private static final String TEST_FCA_NUMBER = "test-fca-number";

    @Test
    public void toMultipleFirmsMultiplePrincipalsMapsCorrectly() throws IOException {
        FirmDetailsResponseDto responseDto = TestUtil.readFirmDetailsFromResource(arMultipleFirmsMultiplePrincipals);
        FirmDetailsResponse response = firmDetailsResponseMapper.toFirmDetails(TEST_FCA_NUMBER, responseDto);

        validateResponse(responseDto, response);
    }

    @Test
    public void toMultipleFirmsNoPrincipalsMapsCorrectly() throws IOException {
        FirmDetailsResponseDto responseDto = TestUtil.readFirmDetailsFromResource(daMultipleFirmsNoPrincipals);
        FirmDetailsResponse response = firmDetailsResponseMapper.toFirmDetails(TEST_FCA_NUMBER, responseDto);

        validateResponse(responseDto, response);
    }

    @Test
    public void toDoNotDoBusinessMapsCorrectly() throws IOException {
        FirmDetailsResponseDto responseDto = TestUtil.readFirmDetailsFromResource(notDoBusiness);
        FirmDetailsResponse response = firmDetailsResponseMapper.toFirmDetails(TEST_FCA_NUMBER, responseDto);

        validateResponse(responseDto, response);
    }

    @Test
    public void toNotExistMapsCorrectly() throws IOException {
        FirmDetailsResponseDto responseDto = TestUtil.readFirmDetailsFromResource(notExist);
        FirmDetailsResponse response = firmDetailsResponseMapper.toFirmDetails(TEST_FCA_NUMBER, responseDto);

        validateResponse(responseDto, response);
    }

    private void validateResponse(FirmDetailsResponseDto responseDto, FirmDetailsResponse response) {
        Assertions.assertEquals(responseDto.getBrokerType(), response.getBrokerType());
        Assertions.assertEquals(TEST_FCA_NUMBER, response.getFcaNumber());
        Assertions.assertEquals(responseDto.getPrincipalFcaFirms().size(), response.getPrincipalFcaFirms().size());
        Assertions.assertEquals(responseDto.getPaymentPaths().size(), response.getPaymentPaths().size());
        Assertions.assertEquals(responseDto.getTradingNames().size(), response.getTradingNames().size());

        // Test All Trading Names have been correctly mapped from objects to list of strings.
        Assertions.assertTrue(responseDto.getTradingNames().stream().map(
            AlternativeTradingNamesDto::getName).allMatch(s -> response.getTradingNames().contains(s)));

        List<PaymentPath> mappedPaymentPaths = (List<PaymentPath>) responseDto.getPaymentPaths().stream().map(dto -> {
            PaymentPath p = new PaymentPath();
            p.setPaymentId(dto.getPaymentId());
            p.setName(dto.getName());

            return p;
        }).collect(Collectors.toList());

        assertThat(response.getPaymentPaths()).usingRecursiveComparison().isEqualTo(mappedPaymentPaths);

        List<PrincipalFcaFirm> mappedPrincipleFcaFirms = (List<PrincipalFcaFirm>) responseDto.getPrincipalFcaFirms().stream().map(dto -> {
            PrincipalFcaFirm p = new PrincipalFcaFirm();
            p.setFcaNumber(dto.getFcaNumber());
            p.setName(dto.getName());

            return p;
        }).collect(Collectors.toList());

        assertThat(response.getPrincipalFcaFirms()).usingRecursiveComparison().isEqualTo(mappedPrincipleFcaFirms);
    }
}
