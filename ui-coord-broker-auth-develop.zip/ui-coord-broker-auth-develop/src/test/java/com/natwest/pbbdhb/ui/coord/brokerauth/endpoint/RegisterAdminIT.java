package com.natwest.pbbdhb.ui.coord.brokerauth.endpoint;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createAdminRegistrationJson;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.createValidAdminRegistration;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.newRandomUserName;
import static io.restassured.RestAssured.with;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Slf4j
@ActiveProfiles("local")
@Disabled
public class RegisterAdminIT {

    //Tests disabled for teamcity integration build. Run these locally.

    @LocalServerPort
    private int port;

    private final String contextPath = "/mortgages/v1/ui-broker-auth";
    private final String endpoint = contextPath + ApplicationConstants.PATH_REGISTER_ADMIN;

    @BeforeEach
    public void setUp() {
        RestAssured.port = this.port;
    }

    @Test
    public void postResponseStatusIsAccepted() throws Exception {
        AdminRegistration adminRegistration = createValidAdminRegistration();
        adminRegistration.setUsername(newRandomUserName());
        String body = createAdminRegistrationJson(adminRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        int statusCode = response.getStatusCode();

        log.info(response.body().asPrettyString());

        assertEquals(HttpStatus.ACCEPTED.value(), statusCode);
    }

    @Test
    public void postWithPlainTextBodyResponseStatusIsUnsupportedMediaType() {
        String body = "plain text";
        int statusCode = with()
                .contentType(ContentType.TEXT)
                .body(body)
                .post(endpoint)
                .getStatusCode();

        assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value(), statusCode);
    }

    @Test
    public void postWithInvalidJsonResponseStatusIsBadRequest() {
        String body = "{invalid json}";
        int statusCode = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint)
                .getStatusCode();

        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
    }

    @Test
    public void invalidateAgreementsAndConfirmExceptionIsReturned() throws JsonProcessingException {
        AdminRegistration adminRegistration = createValidAdminRegistration();

        String body = createAdminRegistrationJson(adminRegistration);
        body = body.replace("\"privacyPolicy\":true,", "");

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("privacyPolicy") && response.getBody().asString().contains("must not be null"));
    }

    @Test
    public void invalidateFirstNamesAndConfirmExceptionIsReturned() throws JsonProcessingException {
        AdminRegistration adminRegistration = createValidAdminRegistration();
        String body = createAdminRegistrationJson(adminRegistration);

        body = body.replace("\"firstName\":\"James\",", "");

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("adminDetails.firstName") && response.getBody().asString().contains("must not be blank"));
    }

    @Test
    public void usernameTooShortExceptionIsReturned() throws JsonProcessingException {
        AdminRegistration adminRegistration = createValidAdminRegistration();
        adminRegistration.setUsername("short");
        String body = createAdminRegistrationJson(adminRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("username") && response.getBody().asString().contains("Username must be at least 6 characters"));
    }

    @Test
    public void usernameMustStartWithLetterOrNumberExceptionIsReturned() throws JsonProcessingException {
        AdminRegistration adminRegistration = createValidAdminRegistration();
        adminRegistration.setUsername("_invalid");
        String body = createAdminRegistrationJson(adminRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("username") && response.getBody().asString().contains("Username must start with a letter or a number"));
    }

    @Test
    public void usernameMustContainNoSpecialCharacterExceptionIsReturned() throws JsonProcessingException {
        AdminRegistration adminRegistration = createValidAdminRegistration();
        adminRegistration.setUsername("inval!id");
        String body = createAdminRegistrationJson(adminRegistration);

        Response response = with()
                .contentType(ContentType.JSON)
                .body(body)
                .post(endpoint);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
        assertTrue(response.getBody().asString().contains("username") && response.getBody().asString().contains("Username must contain no special characters other than '. - _'"));
    }
}
