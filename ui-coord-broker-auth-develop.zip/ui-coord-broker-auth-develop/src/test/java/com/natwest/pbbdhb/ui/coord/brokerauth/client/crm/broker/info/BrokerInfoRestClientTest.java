package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info;

import static com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.BrokerInfoRestClientTest.FAKE_READ_ADMIN_ENDPOINT_URL;
import static com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.BrokerInfoRestClientTest.FAKE_READ_BROKER_ENDPOINT_URL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.AdminInfoDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelper;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil;
import java.io.IOException;
import java.net.HttpURLConnection;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(properties = {
        "broker-info.readBrokerEndpoint=" + FAKE_READ_BROKER_ENDPOINT_URL,
        "broker-info.readAdminEndpoint=" + FAKE_READ_ADMIN_ENDPOINT_URL
})
@ActiveProfiles(profiles = { "integration" })
class BrokerInfoRestClientTest {
    public static final String FAKE_READ_BROKER_ENDPOINT_URL = "https://testReadBrokerEndpoint/(mbs_username='{username}')";
    public static final String FAKE_READ_ADMIN_ENDPOINT_URL = "https://testReadAdminEndpoint/(mbs_username='{username}')";

    private static final String FAKE_REQUEST_URL = "https://fake-url.com";
    private static final String BAD_REQUEST_MESSAGE = "Bad Request";
    private static final String IO_ERROR_MESSAGE = "IO Error";

    private static final String TEST_ACCESS_TOKEN = "test-access-token";

    private static final String TEST_USER_NAME = "jlpicard";

    private static final String EMPTY_JSON_BODY = "{}";

    @Value("classpath:test-files/broker-info/read-broker-success.json")
    private Resource readBrokerSuccess;

    @Value("classpath:test-files/broker-info/read-admin-success.json")
    private Resource readAdminSuccess;

    @Value("classpath:test-files/broker-info/read-broker-failure.json")
    private Resource readBrokerFailure;

    @Value("classpath:test-files/broker-info/read-broker-missing-trading-name.json")
    private Resource readBrokerMissingTradingName;

    @Value("classpath:test-files/broker-info/read-admin-failure.json")
    private Resource readAdminFailure;

    private final Request fakeRequest = new Request.Builder()
            .url(FAKE_REQUEST_URL)
            .build();

    @MockBean(name = "proxyHttpClient")
    private OkHttpClient mockProxyHttpClient;

    @MockBean
    private Call mockServiceCall;

    @MockBean
    private SecurityTokenHelper mockSecurityTokenHelper;

    @Autowired
    private BrokerInfoRestClient brokerInfoRestClient;

    @BeforeEach
    void stubAccessToken() {
        when(this.mockSecurityTokenHelper.getAccessToken()).thenReturn(TEST_ACCESS_TOKEN);
    }

    @AfterEach
    void verifyCalls() throws IOException {
        verify(this.mockProxyHttpClient).newCall(any(Request.class));
        verifyNoMoreInteractions(this.mockProxyHttpClient);
        verify(this.mockServiceCall).execute();
        verifyNoMoreInteractions(this.mockServiceCall);
    }

    @Test
    void testReadBrokerNotOK() throws IOException {
        Response errorResponse = createResponse(HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE, EMPTY_JSON_BODY);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(errorResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s returned %d (%s)", FAKE_READ_BROKER_ENDPOINT_URL, HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE));
    }


    @Test
    void testReadAdminNotOK() throws IOException {
        Response errorResponse = createResponse(HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE, EMPTY_JSON_BODY);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(errorResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getAdminInfo(TEST_USER_NAME)))
            .isInstanceOf(CrmEndpointException.class)
            .hasMessage(String.format("Endpoint %s returned %d (%s)", FAKE_READ_ADMIN_ENDPOINT_URL, HttpURLConnection.HTTP_BAD_REQUEST, BAD_REQUEST_MESSAGE));
    }

    @Test
    void testReadBrokerIOError() throws IOException {
        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doThrow(new IOException(IO_ERROR_MESSAGE)).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s request failed %s", FAKE_READ_BROKER_ENDPOINT_URL, IO_ERROR_MESSAGE));
    }

    @Test
    void testReadAdminIOError() throws IOException {
        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doThrow(new IOException(IO_ERROR_MESSAGE)).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getAdminInfo(TEST_USER_NAME)))
            .isInstanceOf(CrmEndpointException.class)
            .hasMessage(String.format("Endpoint %s request failed %s", FAKE_READ_ADMIN_ENDPOINT_URL, IO_ERROR_MESSAGE));
    }

    @Test
    void testReadBrokerNoBody() throws IOException {
        Response noBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", null);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(noBodyResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)))
                .isInstanceOf(CrmEndpointException.class)
                .hasMessage(String.format("Endpoint %s returned an invalid response null", FAKE_READ_BROKER_ENDPOINT_URL));
    }

    @Test
    void testReadAdminNoBody() throws IOException {
        Response noBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", null);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(noBodyResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getAdminInfo(TEST_USER_NAME)))
            .isInstanceOf(CrmEndpointException.class)
            .hasMessage(String.format("Endpoint %s returned an invalid response null", FAKE_READ_ADMIN_ENDPOINT_URL));
    }

    @Test
    void testReadBrokerEmptyBody() throws IOException {
        Response emptyBodyResponse = createResponse(HttpURLConnection.HTTP_OK, "", EMPTY_JSON_BODY);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(emptyBodyResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)))
            .isInstanceOf(CrmDataException.class)
            .hasMessage("No response fields found.  Expected one of [success: \"mbs_message\", failure: \"mbs_message\"]");
    }

    @Test
    void testReadBrokerMissingTradingName() throws IOException {
        Response missingTradingNameResponse =
            createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(readBrokerMissingTradingName));
        BrokerInfoResponseDto brokerReadResponseDto =
            TestUtil.readObjectFromResource(readBrokerMissingTradingName, BrokerInfoResponseDto.class);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(missingTradingNameResponse).when(this.mockServiceCall).execute();

        assertThat(brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)).isEqualTo(brokerReadResponseDto);
    }

    @Test
    void testReadBrokerSuccessResponse() throws IOException {
        Response completeResponse =
            createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(readBrokerSuccess));
        BrokerInfoResponseDto brokerReadResponseDto =
            TestUtil.readObjectFromResource(readBrokerSuccess, BrokerInfoResponseDto.class);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)).isEqualTo(brokerReadResponseDto);
    }

    @Test
    void testReadAdminSuccessResponse() throws IOException {
        Response completeResponse =
            createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(readAdminSuccess));
        AdminInfoDto adminInfoDto =
            TestUtil.readObjectFromResource(readAdminSuccess, AdminInfoDto.class);

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(brokerInfoRestClient.getAdminInfo(TEST_USER_NAME)).isEqualTo(adminInfoDto);
    }

    @Test
    void testReadBrokerFailureResponse() throws IOException {
        Response completeResponse =
            createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(readBrokerFailure));

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getBrokerInfo(TEST_USER_NAME)))
            .isInstanceOf(CrmDataException.class)
            .hasMessage(String.format("CRM failed to find the requested data for %s", TEST_USER_NAME));
    }

    @Test
    void testReadAdminFailureResponse() throws IOException {
        Response completeResponse =
            createResponse(HttpURLConnection.HTTP_OK, "", TestUtil.readResource(readAdminFailure));

        doReturn(mockServiceCall).when(this.mockProxyHttpClient).newCall(any());
        doReturn(completeResponse).when(this.mockServiceCall).execute();

        assertThat(catchThrowable(() -> brokerInfoRestClient.getAdminInfo(TEST_USER_NAME)))
            .isInstanceOf(CrmDataException.class)
            .hasMessage(String.format("CRM failed to find the requested data for %s", TEST_USER_NAME));
    }

    private Response createResponse(int responseCode, String message, String jsonResponse) {
        Response.Builder responseBuilder = new Response.Builder()
                .request(fakeRequest)
                .protocol(Protocol.HTTP_2)
                .code(responseCode) // status code
                .message(message);

        if (jsonResponse != null) {
            responseBuilder.body(ResponseBody.create(MediaType.get("application/json; charset=utf-8"), jsonResponse));
        }

        return responseBuilder.build();
    }
}


