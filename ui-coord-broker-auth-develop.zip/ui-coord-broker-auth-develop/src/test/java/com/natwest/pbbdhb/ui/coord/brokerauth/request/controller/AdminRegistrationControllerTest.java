package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;


import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PATH_REGISTER_ADMIN;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.TestUtil.readResource;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.natwest.pbbdhb.ui.coord.brokerauth.BrokerAuthenticationApplication;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.config.TestConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorResponse;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.io.IOException;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {
        BrokerAuthenticationApplication.class, TestConfig.class
    }
)

@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
public class AdminRegistrationControllerTest {

  @Value("classpath:test-files/registration/register-admin-valid-request.json")
  private Resource registerAdminRequestValid;

  @Value("classpath:test-files/registration/register-admin-valid-request-spaces.json")
  private Resource registerAdminRequestValidWithSpaces;

  @Value("classpath:test-files/registration/register-admin-invalid-request-username-not-available.json")
  private Resource registerAdminRequestInvalidUsername;

  @LocalServerPort
  private int port;

  @BeforeEach
  public void setUp() {
    RestAssured.port = this.port;
  }

  @AfterEach
  public void cleanUp() {
    RestAssured.port = RestAssured.UNDEFINED_PORT;
  }

  @Test
  public void adminBrokerReturnsAcceptedWhenRegistrationAcceptedByCrm() throws IOException {
    String request = readResource(registerAdminRequestValid);

    Response response = with()
        .body(request)
        .contentType(APPLICATION_JSON_VALUE)
        .post(PATH_REGISTER_ADMIN);

    log.info(response.body().asPrettyString());

    response
        .then()
        .statusCode(HttpStatus.ACCEPTED.value());
  }

  @Test
  public void adminBrokerReturnsAcceptedWhenRegistrationAcceptedByCrmAndSringAreCorrectlyTrimmed() throws IOException {
    String request = readResource(registerAdminRequestValidWithSpaces);

    Response response = with()
            .body(request)
            .contentType(APPLICATION_JSON_VALUE)
            .post(PATH_REGISTER_ADMIN);

    log.info(response.body().asPrettyString());

    response
            .then()
            .statusCode(HttpStatus.ACCEPTED.value());
  }

  @Test
  public void adminBrokerReturnsBadRequestWhenUsernameIsTakenAndRegistrationIsRejectedByCrm()
      throws IOException {
    String request = readResource(registerAdminRequestInvalidUsername);

    Response response = with()
        .body(request)
        .contentType(APPLICATION_JSON_VALUE)
        .post(PATH_REGISTER_ADMIN);

    log.info(response.body().asPrettyString());

    ErrorResponse errorResponse = response
        .then()
        .statusCode(HttpStatus.BAD_REQUEST.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(ErrorResponse.class);

    assertThat(errorResponse).usingRecursiveComparison().ignoringCollectionOrder()
        .isEqualTo(ErrorResponse.invalidDetails(new ValidationErrorResponse(
            Collections.singleton(new Violation("username", "This username is already in use, please choose another")))));
  }

}
