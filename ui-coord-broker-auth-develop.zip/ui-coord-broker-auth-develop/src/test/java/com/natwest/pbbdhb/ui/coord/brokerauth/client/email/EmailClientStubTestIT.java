package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.ui.coord.brokerauth.context.EmailContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"integration", "stub-email"})
@SpringBootTest(
    webEnvironment = WebEnvironment.NONE
)
public class EmailClientStubTestIT {

  @Autowired
  EmailClient client;

  @Test
  void shouldInjectStubClient() {
    assertThat(client.getClass())
        .isEqualTo(EmailClientStub.class);
  }

  @Nested
  @DisplayName("Email Cases")
  class EmailCases {

    /**
     * Testing happy path call to client
     */
    @Test
    void shouldCallClientToSendEmail() {
      client.send(
          EmailContext.builder().build().createEmailRequestModel()
      );
    }
  }
}
