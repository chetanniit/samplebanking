package com.natwest.pbbdhb.ui.coord.brokerauth.context;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.*;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import lombok.Builder.Default;
import java.util.Collections;
import java.util.List;

@Getter
@ToString
@Builder
public class AccessTokenContext {

    @Default
    private String username = "TestUsername";

    @Default
    private String accessToken = "XXX.YYY.ZZZ";

    @Default
    private String tokenType = "Bearer";

    @Default
    private String fcaNumber = "TestFcaNumber";

    @Default
    private int expiresIn = 599;

    public BrokerPortalAccessTokenRequestModel createBrokerAccessTokenRequestModel() {
        return  BrokerPortalAccessTokenRequestModel
                .builder()
                .userName(username)
                .brokerRole(UserRegistrationType.BROKER)
                .fcaNumber(fcaNumber)
                .build();
    }

    public BrokerPortalAccessTokenRequestModel createAdminAccessTokenRequestModel() {
        return BrokerPortalAccessTokenRequestModel
                .builder()
                .brokerRole(UserRegistrationType.ADMIN)
                .userName(username)
                .build();
    }

    public BrokerPortalAccessTokenResponseModel createBrokerPortalAccessTokenResponseModel() {
        return BrokerPortalAccessTokenResponseModel.builder()
                .accessToken(accessToken)
                .tokenType(tokenType)
                .expiresIn(expiresIn)
                .build();
    }
}
