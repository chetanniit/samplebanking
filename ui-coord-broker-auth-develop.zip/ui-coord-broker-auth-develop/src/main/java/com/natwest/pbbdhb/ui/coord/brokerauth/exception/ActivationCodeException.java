package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;

public class ActivationCodeException extends RuntimeException {

  private final ErrorCode code;

  public ActivationCodeException(ErrorCode code, String message) {
    super(message);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }
}