package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * Represents the header and payload claims required by a JWT (Json Web Token).
 */
@Builder
@Value
public class JsonWebTokenModel {

  @NonNull
  HeaderModel header;
  @NonNull
  PayloadModel payload;

  /**
   * Claims for the JWT header
   */
  @Builder
  @Value
  public static class HeaderModel {

    @NonNull
    String algorithm;
    @NonNull
    String kid;
    @NonNull
    String x5t;
  }

  /**
   * Claims for the JWT payload
   */
  @Builder
  @Value
  public static class PayloadModel {

    @NonNull
    String issuer;
    @NonNull
    String subject;
    @NonNull
    String audience;
  }
}
