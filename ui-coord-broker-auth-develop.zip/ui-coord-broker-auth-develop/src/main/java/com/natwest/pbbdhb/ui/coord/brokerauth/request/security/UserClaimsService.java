package com.natwest.pbbdhb.ui.coord.brokerauth.request.security;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.Brand;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import java.security.GeneralSecurityException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Responsible for retrieving user principal claims contained in our request.
 * <p>
 * Each request will hold claims within a UserPrincipal. This class will retrieve the current
 * request's UserPrincipal and will then extract the specific claims required.
 */
@Slf4j
@Service
public class UserClaimsService implements UserClaimsProvider {

  private static final String OPERATING_BRAND_CLAIM = "operating_brand";
  private static final String ACCESS_TOKEN_CLAIM = "access_token";

  private final UserPrincipalProvider userPrincipalProvider;

  @Autowired
  public UserClaimsService(UserPrincipalProvider userPrincipalProvider) {
    this.userPrincipalProvider = userPrincipalProvider;
  }

  public Brand getOperatingBrand() {
    String operatingBrand = getStringClaim(OPERATING_BRAND_CLAIM);
    return Brand.fromValue(operatingBrand);
  }

  public String getAccessToken() {
    return getStringClaim(ACCESS_TOKEN_CLAIM);
  }

  private String getStringClaim(
      final String claimName) {
    final UserPrincipal userPrincipal = getUserPrincipal();
    final String claimValue = (String) userPrincipal.getProperty(claimName);

    if (StringUtils.isNotBlank(claimValue)) {
      log.debug(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.JWT)
          .description(String.format("Retrieved claim: %s=%s",  claimName, claimValue))
          .build()
      );
      return claimValue;
    }
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.JWT)
        .description(String.format("Could not retrieve claim: %s",  claimName))
        .build()
    );
    throw new IllegalStateException("Could not retrieve claim: " + claimName);
  }

  private UserPrincipal getUserPrincipal() {
    try {
      return Optional
          .ofNullable(userPrincipalProvider.get())
          .orElseThrow(() -> new IllegalStateException("UserPrincipal can not be null"));
    } catch (GeneralSecurityException e) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.JWT)
              .description(" Unable to Retrieve UserPrincipal.")
              .build()
      );
      throw new IllegalStateException("Unable to retrieve UserPrincipal", e);
    }
  }
}
