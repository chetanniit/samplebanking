package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.domain.EmailClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.mapper.EmailClientMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailRestClientConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.Brand;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.EmailSendFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.security.UserClaimsProvider;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Component
@Slf4j
public class EmailRestClient implements EmailClient {

  private final EmailRestClientConfig config;
  private final RestTemplate restTemplate;
  private final UserClaimsProvider userClaimsProvider;

  @Autowired
  public EmailRestClient(
      EmailRestClientConfig config,
      @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
      UserClaimsProvider userClaimsProvider) {
    this.config = config;
    this.restTemplate = restTemplate;
    this.userClaimsProvider = userClaimsProvider;
  }

  @Override
  public <T extends EmailTemplate> void send(T emailRequestModel) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String.format("Send Email request for %s",  emailRequestModel.getToRecipients()))
        .build()
    );

    try {
      Brand brand = userClaimsProvider.getOperatingBrand();

      HttpEntity<EmailClientRequest> httpRequest = new HttpEntity<>(
          EmailClientMapper.toClientModel(emailRequestModel), getHeaders(brand.getValue()));

      restTemplate
          .postForEntity(
              sendEmailUri(),
              httpRequest,
              Void.class);

      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(String.format("End of Send Email request for %s",  emailRequestModel.getToRecipients()))
              .build()
      );

    } catch (HttpClientErrorException.Unauthorized ex) {
      log.error(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(String.format("Email request with template %s for %s failed with " +
                              "EmailSendFailedException %s", emailRequestModel.getTemplateName(),
                      emailRequestModel.getToRecipients(), ex.getMessage()))
              .build()
      );
      throw new EmailSendFailedException(emailRequestModel.getToRecipients());
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(String.format("Email request with template %s for %s failed with Rest client exception %s",
              emailRequestModel.getTemplateName(), emailRequestModel.getToRecipients(), ex.getMessage()))
          .build()
      );

      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  private URI sendEmailUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment("email")
        .build()
        .toUri();
  }

  private HttpHeaders getHeaders(String brand) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("brand", brand);

    return headers;
  }
}
