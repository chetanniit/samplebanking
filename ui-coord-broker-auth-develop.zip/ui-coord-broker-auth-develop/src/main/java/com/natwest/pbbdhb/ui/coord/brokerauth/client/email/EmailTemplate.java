package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

import com.fasterxml.jackson.annotation.JsonIgnore;

public interface EmailTemplate {
  @JsonIgnore
  String getTemplateName();
  String getToRecipients();
}
