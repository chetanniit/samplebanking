package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper.LoginRequestMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info.BrokerInfoFactory;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info.BrokerTypeInfo;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.login.LoginService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.token.TokenService;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("login")
@Tag(name = "User Login",
    description = "API for user login")
@Slf4j
@Validated
public class LoginController {

  private final LoginService loginService;
  private final TokenService tokenService;
  private final BrokerInfoFactory brokerInfoFactory;


  @Autowired
  public LoginController(
          LoginService loginService,
          TokenService tokenService,
          BrokerInfoFactory brokerInfoFactory) {
    this.loginService = loginService;
    this.tokenService = tokenService;
    this.brokerInfoFactory = brokerInfoFactory;
  }

  @Operation(
      operationId = "login",
      summary = "Authenticates a user's credentials"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Login was successful"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "401", description = "Unauthorized")
  })
  @PostMapping
  @ResponseStatus(HttpStatus.OK)
  public LoginResponse login(@RequestBody @Valid LoginRequest attempt) {
    String username = attempt.getUsername();
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Login request for user: %s",  username))
        .build()
    );

    UserRegistrationType brokerType = loginService.login(
        LoginRequestMapper.toDomainModel(attempt));

    BrokerTypeInfo brokerInfo = brokerInfoFactory.getBrokerTypeService(brokerType);
    BrokerInfoBrokerDomainModel brokerInfoModel = brokerInfo.getBrokerInfo(username);

    BrokerPortalAccessTokenResponseModel token = tokenService.retrieveAccessToken(
        LoginRequestMapper.toDomainModel(brokerInfoModel.getUsername(), brokerType, brokerInfoModel.getFcaNumber())
    );

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Login Request for user: %s",  username))
            .build()
    );

    return LoginRequestMapper.toResponseModel(token, brokerType);
  }
}
