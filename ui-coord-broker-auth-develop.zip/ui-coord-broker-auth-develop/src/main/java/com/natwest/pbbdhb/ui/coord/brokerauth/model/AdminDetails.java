package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.Title;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidateAtLeastOneNotNull;
import jakarta.validation.constraints.Email;
import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@ValidateAtLeastOneNotNull(fields = "mobilePhoneNumber,otherPhoneNumber")
public class AdminDetails {
    @NotNull
    private Title title;

    @NotBlank
    private String firstName;

    private String middleName;

    @NotBlank
    private String lastName;

    @NotNull
    private LocalDate dateOfBirth;

    private String mobilePhoneNumber;

    private String otherPhoneNumber;

    @NotBlank
    @Email
    private String emailAddress;
}
