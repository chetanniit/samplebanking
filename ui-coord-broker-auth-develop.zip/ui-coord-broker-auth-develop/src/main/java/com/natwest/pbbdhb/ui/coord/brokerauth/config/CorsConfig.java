package com.natwest.pbbdhb.ui.coord.brokerauth.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@Slf4j
public class CorsConfig implements WebMvcConfigurer {

  @Value("${management.endpoints.web.cors.allowed-origins:#{null}}")
  private String[] allowedOrigins;
  @Value("${management.endpoints.web.cors.allowed-methods:#{null}}")
  private String[] allowedMethods;

  @Override
  public void addCorsMappings(CorsRegistry registry) {
    if (allowedOrigins == null || allowedMethods == null) {
      return;
    }

    registry.addMapping("/**").allowedOrigins(allowedOrigins).allowedMethods(allowedMethods);
  }
}
