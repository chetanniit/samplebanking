package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class RetrieveChallengeQuestionsResponse {

  @NotNull
  List<String> securityQuestions;
}
