package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ResidentialAddress {

    @NotBlank
    @Size(max = 250)
    private String addressLine1;

    @Size(max = 250)
    private String addressLine2;

    @Size(max = 250)
    private String addressLine3;

    @NotBlank
    @Size(max = 100)
    private String town;

    @Size(max = 100)
    private String county;

    @NotBlank
    @Size(max = 20)
    private String postcode;

    @NotBlank
    @Size(max = 100)
    private String countryOfAddress;

}
