package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class ValidateOtpClientRequest {

  @JsonProperty("username")
  @NonNull
  String username;

  @JsonProperty("otpCode")
  @NonNull
  String otpCode;

}
