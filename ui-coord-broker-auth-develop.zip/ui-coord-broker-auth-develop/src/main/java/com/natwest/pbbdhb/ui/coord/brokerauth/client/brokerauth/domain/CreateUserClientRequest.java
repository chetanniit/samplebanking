package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class CreateUserClientRequest {

  @JsonProperty("firstname")
  @NonNull
  String firstname;

  @JsonProperty("lastname")
  @NonNull
  String lastname;

  @JsonProperty("email")
  @NonNull
  String email;

  @JsonProperty("username")
  @NonNull
  String username;

  @JsonProperty("brokerType")
  @NonNull
  UserRegistrationType brokerType;
}
