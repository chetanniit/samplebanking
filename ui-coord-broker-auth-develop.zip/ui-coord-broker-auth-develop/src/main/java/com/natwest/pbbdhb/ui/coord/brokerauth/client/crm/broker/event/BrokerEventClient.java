package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.event;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventRequestDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventResponseDto;


public interface BrokerEventClient {

  BrokerEventResponseDto createBrokerEvent(BrokerEventRequestDto requestDto);

}


