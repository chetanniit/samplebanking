package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication;


import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;

public interface AuthenticationClient {

  BrokerPortalAccessTokenResponseModel retrieve(BrokerPortalAccessTokenRequestModel requestModel);

  void revoke();
}
