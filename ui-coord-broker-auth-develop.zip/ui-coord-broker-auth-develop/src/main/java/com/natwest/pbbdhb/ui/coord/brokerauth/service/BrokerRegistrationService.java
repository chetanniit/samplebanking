package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;

public interface BrokerRegistrationService {

    /**
     * Submits broker registration details.
     *
     * @param brokerRegistration the broker details for registration
     */
    void registerBroker(BrokerRegistration brokerRegistration);

    /**
     * Submits broker registration details.
     *
     * @param adminRegistration the admin details for registration
     */
    void registerAdmin(AdminRegistration adminRegistration);

    /**
     * Performs verification of username availability.
     *
     * @param username the username to verify
     * @return a boolean indicating whether the user name is already in use or not
     */
    boolean isUsernameAvailable(String username);

    /**
     * Gets the details of the firm for a given FCA number
     *
     * @param brand the bank brand this request applies to
     * @param fcaNumber the number to retrieve the details for
     * @return an object containing the details og the firm.
     */
    FirmDetailsResponse getFirmDetails(String brand, String fcaNumber);
}
