package com.natwest.pbbdhb.ui.coord.brokerauth.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.AlternativeTradingNamesDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.FirmDetailsResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface FirmDetailsResponseMapper {

    FirmDetailsResponse toFirmDetails(String fcaNumber, FirmDetailsResponseDto dto);

    List<String> map(List<AlternativeTradingNamesDto> tradingNamesDtos);

    default String map(AlternativeTradingNamesDto tradingNamesDto) {
        if (tradingNamesDto == null) {
            return null;
        }
        return tradingNamesDto.getName();
    }
}
