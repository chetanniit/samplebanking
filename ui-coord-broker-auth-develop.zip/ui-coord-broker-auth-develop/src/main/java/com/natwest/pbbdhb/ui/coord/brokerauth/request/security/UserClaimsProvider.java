package com.natwest.pbbdhb.ui.coord.brokerauth.request.security;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.Brand;

/**
 * Provides user claims contained in the request's user principal.
 */
public interface UserClaimsProvider {

  Brand getOperatingBrand();

  String getAccessToken();
}
