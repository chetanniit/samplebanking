package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class RetrieveSecurityQuestionsRequest {

  @JsonProperty("username")
  @NotNull String username;
}
