package com.natwest.pbbdhb.ui.coord.brokerauth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDate;

@Data
public class AdminRegistrationDto {
    @JsonProperty("mbs_title")
    private String title;
    @JsonProperty("mbs_userName")
    private String username;
    @JsonProperty("mbs_firstName")
    private String firstName;
    @JsonProperty("mbs_middleName")
    private String middleName;
    @JsonProperty("mbs_lastName")
    private String lastName;
    @JsonProperty("mbs_dateOfBirth")
    private LocalDate dateOfBirth;
    @JsonProperty("mbs_businessPhone")
    private String businessPhone;
    @JsonProperty("mbs_mobilePhone")
    private String mobilePhone;
    @JsonProperty("mbs_emailAddress")
    private String emailAddress;
    @JsonProperty("mbs_firmName")
    private String firmName;
    @JsonProperty("mbs_fcaNumber")
    private String fcaNumber;
    @JsonProperty("mbs_principalFCANumber")
    private String principalFcaNumber;
}

