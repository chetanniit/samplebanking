package com.natwest.pbbdhb.ui.coord.brokerauth.util;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.JsonWebTokenModel;
import java.security.PrivateKey;
import java.util.UUID;
import lombok.NonNull;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;

/**
 * Utility responsible for generating a JWT signed by a private key.
 */
@UtilityClass
@Slf4j
public class JwtSigningUtil {

  /**
   * Create a signed JWT.
   *
   * @param model - jwt model holding JWT header and payload
   * @param privateKey - private key for signing JWT
   * @return signed JWT
   */
  public static String createJwt(
      @NonNull JsonWebTokenModel model,
      @NonNull PrivateKey privateKey) {
    return signJwt(
        model.getHeader(),
        createJwtPayload(model.getPayload()),
        privateKey);
  }

  private static JwtClaims createJwtPayload(
      @NonNull JsonWebTokenModel.PayloadModel payload) {
    final JwtClaims claims = new JwtClaims();

    // set expected claims
    claims.setIssuer(payload.getIssuer());
    claims.setSubject(payload.getSubject());
    claims.setAudience(payload.getAudience());
    claims.setIssuedAtToNow();
    claims.setNotBeforeMinutesInThePast(1F);
    claims.setExpirationTimeMinutesInTheFuture(1F);
    claims.setJwtId(UUID.randomUUID().toString());

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Expected JWT Claims successfully set.")
            .build()
    );

    return claims;
  }

  private static String signJwt(
      @NonNull JsonWebTokenModel.HeaderModel header,
      @NonNull JwtClaims payload,
      @NonNull PrivateKey signingKey) {
    try {
      JsonWebSignature jws = new JsonWebSignature();

      // header
      jws.setAlgorithmHeaderValue(header.getAlgorithm());
      jws.setHeader(HeaderParameterNames.TYPE, "JWT");
      jws.setKeyIdHeaderValue(header.getKid());
      jws.setHeader(HeaderParameterNames.X509_CERTIFICATE_THUMBPRINT, header.getX5t());

      // payload
      jws.setPayload(payload.toJson());

      // signature
      jws.setKey(signingKey);

      // create compact serialised JWT
      log.debug("Creating signed JWT: {}. Payload: {}.", jws, payload);
      final String serializedJwt = jws.getCompactSerialization();
      log.trace("Created compact serialised JWT: {}", serializedJwt);

      return serializedJwt;
    } catch (JoseException ex) {
      log.error(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.INCOMING)
              .description(String.format("Could not build JWS due to IllegalStateException: %s", ex.getMessage()))
              .build()
      );
      throw new IllegalStateException("Could not build JWS", ex);
    }
  }
}
