package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

/**
 * This is a stubbed implementation of a BrokerAuth Client.
 * <p>
 * This returns static responses and should only be used in test environments. Intended for use when
 * downstream services are not required or not available.
 */
@ConditionalOnProperty(
    value = "clients.email.stub.enabled",
    havingValue = "true")
@Service
@Primary
@Slf4j
public class EmailClientStub implements EmailClient {

  public EmailClientStub() {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Email Stub client in-use. Only intended for test environments")
        .build()
    );
  }

  @Override
  public <T extends EmailTemplate> void send(T emailRequestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Email Stub send call. Only intended for test environments.")
        .build()
    );
  }
}
