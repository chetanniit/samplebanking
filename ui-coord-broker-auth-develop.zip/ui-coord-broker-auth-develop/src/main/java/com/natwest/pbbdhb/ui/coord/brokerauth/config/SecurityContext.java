package com.natwest.pbbdhb.ui.coord.brokerauth.config;

import com.rbs.dws.security.UserPrincipalProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityContext {

  // Use "simpleUserPrincipalProvider" bean for our UserPrincipalProvider.
  // See: http://dp.apps.prod-pcf2.lb1.rbsgrp.net/pages/documents/libraries-dws-tomcat-valves
  @Bean
  public UserPrincipalProvider userPrincipalProvider(
      @Autowired @Qualifier("simpleUserPrincipalProvider") UserPrincipalProvider userPrincipalProvider) {
    return userPrincipalProvider;
  }
}
