package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerRegistrationValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.NonNull;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Exception handler for rest controllers.
 */
@RestControllerAdvice
@Slf4j
public class ControllerAdvice extends ResponseEntityExceptionHandler {

  @ExceptionHandler(ConstraintViolationException.class)
  public ResponseEntity<Object> handleConstraintViolation(
      ConstraintViolationException ex, WebRequest request) {
    log.error(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return new ResponseEntity<>(ErrorResponse.invalidDetails(
        new ValidationErrorResponse(
            normaliseException(ex, ConstraintViolationException::getConstraintViolations,
                constraintViolation -> (constraintViolation.getPropertyPath().toString()),
                ConstraintViolation::getMessage))), new HttpHeaders(), HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(BrokerRegistrationValidationException.class)
  public ResponseEntity<Object> handleBrokerRegistrationValidationException(
      BrokerRegistrationValidationException ex, WebRequest request) {
    log.error(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return new ResponseEntity<>(ErrorResponse.invalidDetails(
        new ValidationErrorResponse(normaliseException(ex, Collections::singleton,
            BrokerRegistrationValidationException::getField,
            BrokerRegistrationValidationException::getMessage))), new HttpHeaders(),
        HttpStatus.BAD_REQUEST);
  }

  @Override
  @NonNull
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      @NonNull MethodArgumentNotValidException ex,
      @NonNull HttpHeaders headers,
      @NonNull HttpStatusCode status,
      @NonNull WebRequest request) {
    log.error(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .exception(ex)
            .build()
    );
    return new ResponseEntity<>(ErrorResponse.invalidDetails(
        new ValidationErrorResponse(
            normaliseException(ex,
                MethodArgumentNotValidException::getFieldErrors,
                FieldError::getField,
                FieldError::getDefaultMessage))), headers, status);
  }

  @Override
  @NonNull
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      @NonNull HttpMessageNotReadableException ex,
      @NonNull HttpHeaders headers,
      @NonNull HttpStatusCode status,
      @NonNull WebRequest request) {
    log.error(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .exception(ex)
            .build()
    );
    return new ResponseEntity<>(ErrorResponse.invalidDetails(
        new ValidationErrorResponse(
            normaliseException(ex,
                Collections::singleton,
                e -> "",
                HttpMessageNotReadableException::getMessage))), headers, status);
  }

  private <E, X> Set<Violation> normaliseException(E e,
      Function<E, Collection<X>> collectorFunction,
      Function<X, String> propertyFunction,
      Function<X, String> messageFunction) {
    return collectorFunction.apply(e).
        stream().map(x -> new Violation(propertyFunction.apply(x), messageFunction.apply(x))).
        collect(Collectors.toSet());
  }
}
