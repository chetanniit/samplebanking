package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.event;


import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.event.BrokerEventClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventRequestDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class BrokerEventService implements BrokerEvent {

  private static final String BROKER_ACTIVATION_EVENT = "4";

  private final BrokerEventClient brokerEventClient;


  @Override
  public boolean createBrokerActivationEvent(String userName) {

    try {

      BrokerEventResponseDto responseDto = createActivationEvent(userName, BROKER_ACTIVATION_EVENT);

      if (!responseDto.isSuccess()) {
        log.warn(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .subtype(LogMessageSubtype.INVALID_RESPONSE)
            .description("Broker Activation metric not accepted in CRM: " + userName)
                .build());
      }
      log.debug(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description("Broker Activation metric accepted in CRM: " + userName).build());
      return responseDto.isSuccess();

    } catch (Exception e) {
      //Deliberately suppressing all exceptions - this is a metric being sent to CRM for analytics and does not impact client journey.
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description("Broker Activation metric not sent to CRM due to endpoint error: " + userName + " " +
                  e.getMessage())
              .build()
      );

    }

    return false;

  }

  private BrokerEventResponseDto createActivationEvent(String userName, String eventType) {
    BrokerEventRequestDto requestDto = BrokerEventRequestDto.builder().username(userName)
        .eventType(eventType).build();

    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(String.format("Creating Activation event of type: %s for user '%s'", eventType, userName))
            .build()
    );

    return brokerEventClient.createBrokerEvent(requestDto);

  }


}
