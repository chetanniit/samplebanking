package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;


@ConditionalOnProperty(
    value = "clients.authentication.stub.enabled",
    havingValue = "true"
)
@Service
@Primary
@Slf4j
public class AuthenticationStubClient implements AuthenticationClient {

  public AuthenticationStubClient() {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description(
            "Stub version of Authentication Client is in-use. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public BrokerPortalAccessTokenResponseModel retrieve(
      BrokerPortalAccessTokenRequestModel requestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Retrieving Access Token stub version. Only intended for test environments.")
        .build()
    );
    return BrokerPortalAccessTokenResponseModel
        .builder()
        .accessToken("stub-token-abcdef-123456")
        .tokenType("Bearer")
        .expiresIn(599)
        .build();
  }

  @Override
  public void revoke() {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Revoking Access Token stub version. Only intended for test environments.")
        .build());
  }
}
