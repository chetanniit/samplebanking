package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class BrokerRegistrationException extends RuntimeException {

    public BrokerRegistrationException(String message) {
        super(message);
    }
}
