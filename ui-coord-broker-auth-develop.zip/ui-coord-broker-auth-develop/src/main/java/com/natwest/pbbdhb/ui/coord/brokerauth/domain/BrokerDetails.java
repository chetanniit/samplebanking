package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrokerDetails {

  private String username;

  private String title;

  private String firstName;

  private String lastName;

  private String email;

  private String mobilePhone;

  private String businessPhone;

  private String addressLine1;

  private String addressLine2;

  private String addressLine3;

  private String city;

  private String county;

  private String postcode;

  private String fcaNumber;

  private String tradingName;

}
