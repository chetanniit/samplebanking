package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.responses;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.json.simple.JSONObject;

@Data
public class CrmResponseTarget {

  @NotBlank
  String target = "mbs_message";

  @NotBlank
  String message;


  public boolean check(JSONObject json) {
    return json.containsKey(target) && message.equalsIgnoreCase((String) json.get(target));
  }

  public boolean exists(JSONObject json) {
    return json.containsKey(target);
  }
}
