package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import lombok.Getter;

/**
 * An exception to be thrown when there is a failed login attempt.
 */
@Getter
public class LoginFailedException extends RuntimeException {

  private final String username;

  public LoginFailedException(String username) {
    super(String.format("Login failed due to invalid credentials for user: '%s'", username));
    this.username = username;
  }

  public LoginFailedException(String username, Throwable cause) {
    super(String.format("Login failed for user: '%s'", username), cause);
    this.username = username;
  }
}
