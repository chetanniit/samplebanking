package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Builder
@Value
@Jacksonized
public class ValidateSecurityAnswersResponse {

  @JsonProperty("otpCode")
  @NonNull
  String otpCode;

  @JsonProperty("brokerType")
  @NonNull
  UserRegistrationType brokerType;
}
