package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.mapper;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.AddressInfoModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.AdminInfoDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.FirmDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.PaymentPathDetailsModel;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.TradingNameDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

import java.util.stream.Collectors;
@Slf4j
public class BrokerInfoClientMapper {
  public static BrokerInfoBrokerDomainModel toDomain(BrokerInfoResponseDto broker) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping BrokerInfoResponseDto to BrokerInfoBrokerDomainModel")
            .build()
    );
    return BrokerInfoBrokerDomainModel.builder()
        .brokerId(broker.getBroker().getBrokerId())
        .username(broker.getBroker().getUsername())
        .title(broker.getBroker().getTitle())
        .brokerFirstName(broker.getBroker().getFirstName())
        .brokerLastName(broker.getBroker().getLastName())
        .emailAddress(broker.getBroker().getEmailAddress())
        .businessPhone(broker.getBroker().getBusinessPhone())
        .mobileNumber(broker.getBroker().getMobileNumber())
        .brokerPostcode(broker.getBroker().getBrokerPostcode())
        .fcaNumber(broker.getFirm().getFcaNumber())
        .principalFcaNumber(broker.getFirm().getPrincipleFcaNumber())
        .firmName(broker.getFirm().getFirmName())
        .firmAddress(buildFirmAddress(broker.getFirm()))
        .tradingName(buildTradingName(broker.getTradingName()))
        .paymentPaths(broker.getPaymentPaths() == null ? null : broker
            .getPaymentPaths()
            .stream()
            .map(paymentPath -> PaymentPathDetailsModel.builder()
                    .paymentPathId(paymentPath.getPaymentPathId())
                    .paymentPathName(paymentPath.getPaymentPathname())
                    .paymentPathScaleBtl(paymentPath.getBtlProductScale())
                    .paymentPathScaleResidential(paymentPath.getResidentialProductScale())
                .build())
            .collect(Collectors.toList()))
        .build();
  }

  public static BrokerInfoBrokerDomainModel toDomain(AdminInfoDto admin) {

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping AdminInfoDto to BrokerInfoBrokerDomainModel")
            .build()
    );
    return BrokerInfoBrokerDomainModel.builder()
        .brokerId(admin.getBrokerAdminId())
        .username(admin.getUsername())
        .title(admin.getTitle())
        .brokerFirstName(admin.getFirstName())
        .brokerLastName(admin.getLastName())
        .emailAddress(admin.getEmailAddress())
        .businessPhone(admin.getBusinessPhone())
        .mobileNumber(admin.getMobileNumber())
        .fcaNumber(admin.getFcaNumber())
        .principalFcaNumber(admin.getPrincipleFcaNumber())
        .firmName(admin.getFirmName())
        .build();
  }

  private static AddressInfoModel buildFirmAddress(FirmDto firm) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Building Firm address from FirmDto to AddressInfoModel")
            .build()
    );
    return AddressInfoModel.builder()
        .city(firm.firmAddressCity)
        .postcode(firm.firmAddressPostcode)
        .line1(firm.getFirmAddressLine1())
        .line2(firm.getFirmAddressLine2())
        .line3(firm.getFirmAddressLine3())
        .country(firm.firmAddressCountry)
        .county(firm.firmAddressCounty)
        .build();
  }

  private static String buildTradingName(TradingNameDto tradingName) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Building Trading Name from TradingNameDto")
            .build()
    );
    return tradingName != null ? tradingName.getName() : null;
  }
}