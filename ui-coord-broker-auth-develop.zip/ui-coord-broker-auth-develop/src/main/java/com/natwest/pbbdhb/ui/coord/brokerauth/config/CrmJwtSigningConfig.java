package com.natwest.pbbdhb.ui.coord.brokerauth.config;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Configuration
@ConfigurationProperties(prefix = "clients.crm.jwt-signing")
@Data
@Validated
public class CrmJwtSigningConfig {

  @NotBlank
  private String password;

  @NotBlank
  private String certificate;

  @NotBlank
  private String type;

}
