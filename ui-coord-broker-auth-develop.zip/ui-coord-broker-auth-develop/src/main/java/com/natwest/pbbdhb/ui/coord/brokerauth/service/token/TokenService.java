package com.natwest.pbbdhb.ui.coord.brokerauth.service.token;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.AuthenticationClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class TokenService {

  private final AuthenticationClient authClient;

  @Autowired
  public TokenService(
      AuthenticationClient authClient) {
    this.authClient = authClient;
  }

  public BrokerPortalAccessTokenResponseModel retrieveAccessToken(
      BrokerPortalAccessTokenRequestModel request) {
    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Retrieving login access token for user: %s",
                    request.getUserName()))
            .build()
    );
    return authClient.retrieve(request);
  }
}
