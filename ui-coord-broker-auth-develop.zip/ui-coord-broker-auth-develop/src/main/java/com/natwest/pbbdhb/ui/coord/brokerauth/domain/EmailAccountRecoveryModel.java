package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.EmailTemplate;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class EmailAccountRecoveryModel implements EmailTemplate {

  @NotBlank
  String templateName;

  @NotBlank
  String toRecipients;

  @NotBlank
  String firstname;

  @NotBlank
  String surname;

  @NotBlank
  String accountRecoveryUrl;

  @NotBlank
  String oneTimePasscode;

  @NotBlank
  String supportNumber;
}
