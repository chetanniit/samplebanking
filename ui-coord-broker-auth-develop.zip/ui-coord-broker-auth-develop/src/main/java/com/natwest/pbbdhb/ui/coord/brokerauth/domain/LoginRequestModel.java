package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

/**
 * Represents a user's credentials
 */
@Data
@Builder
public class LoginRequestModel {

  @NotNull
  private String username;

  @NotNull
  private String password;
}