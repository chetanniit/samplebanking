package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class UsernameAvailableException extends RuntimeException {

    public UsernameAvailableException(String message) {
        super(message);
    }
}
