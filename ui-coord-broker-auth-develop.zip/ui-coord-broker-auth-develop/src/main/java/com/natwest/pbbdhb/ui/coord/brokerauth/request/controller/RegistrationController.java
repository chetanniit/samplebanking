package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailActivationCodeTemplateConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailReactivateAccountTemplateConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeGenerateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailAccountRecoveryModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailActivationCodeRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.ReactivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.CreateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.DeleteUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper.RegistrationRequestMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.account.AccountManagementService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.email.EmailService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.registration.RegistrationService;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/registration")
@Tag(name = "User Registration and Management",
    description = "API for user registration and management operations")
@Slf4j
@Validated
public class RegistrationController {

  private final RegistrationService registrationService;
  private final AccountManagementService accountManagementService;
  private final EmailService emailService;
  private final EmailActivationCodeTemplateConfig activationCodeTemplate;
  private final EmailReactivateAccountTemplateConfig reactivateAccountConfig;

  public RegistrationController(
      RegistrationService registrationService,
      AccountManagementService accountManagementService,
      EmailService emailService,
      EmailActivationCodeTemplateConfig activationCodeTemplate,
      EmailReactivateAccountTemplateConfig reactivateAccountConfig) {
    this.registrationService = registrationService;
    this.accountManagementService = accountManagementService;
    this.emailService = emailService;
    this.activationCodeTemplate = activationCodeTemplate;
    this.reactivateAccountConfig = reactivateAccountConfig;
  }

  @Operation(
      operationId = "createUser",
      summary = "Creates a user within IAM"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "201", description = "User creation was successful"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "409", description = "User already exists"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")
  })
  @PostMapping("/user")
  @ResponseStatus(HttpStatus.CREATED)
  public void createUser(@RequestBody @Valid CreateUserRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Create user request for user: %s", request.getUsername()))
        .build()
    );

    String activationCode = registrationService.createUser(
        RegistrationRequestMapper.toDomainModel(request));

    emailService.send(
        EmailActivationCodeRequestModel.builder()
            .templateName(activationCodeTemplate.getName())
            .toRecipients(request.getEmail())
            .firstname(request.getFirstName())
            .surname(request.getLastName())
            .registrationUrl(activationCodeTemplate.getRegistrationUrl())
            .activationCode(activationCode)
            .build()
    );
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Create user request for user: %s", request.getUsername()))
            .build()
    );
  }

  @Operation(
      operationId = "deleteUser",
      summary = "Deletes a user within IAM"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "User deletion was successful"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")
  })
  @DeleteMapping("user")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void deleteUser(@RequestBody @Valid DeleteUserRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Delete user request for user: %s", request.getUsername()))
        .build()
    );

    registrationService.deleteUser(RegistrationRequestMapper.toDomainModel(request));

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Delete User request for user: %s", request.getUsername()))
            .build()
    );
  }

  @Operation(
      operationId = "reactivateUser",
      summary = "Invokes user activation process again"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "User reactivation was successful"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")
  })
  @PutMapping("reactivate")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void reactivateUser(@RequestBody @Valid ReactivateUserRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Reactivate user request for user: %s", request.getUsername()))
        .build()
    );

    String oneTimePasscode = registrationService.reactivateUser(request.getUsername());

    emailService.send(
        EmailAccountRecoveryModel.builder()
            .templateName(reactivateAccountConfig.getName())
            .toRecipients(request.getEmail())
            .firstname(request.getFirstName())
            .surname(request.getLastName())
            .accountRecoveryUrl(reactivateAccountConfig.getAccountRecoveryUrl())
            .oneTimePasscode(oneTimePasscode)
            .supportNumber(reactivateAccountConfig.getSupportNumber())
            .build()
    );
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Reactivate user request for user: %s", request.getUsername()))
            .build()
    );
  }

  @Operation(
      operationId = "activationCode",
      summary = "Invokes user activation code again"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "User reactivation was successful"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")
  })
  @PostMapping("activation-code")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void activationCode(@RequestBody @Valid ActivationCodeGenerateRequestModel request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Activation code request for user: %s",
                request.getUsername()))
        .build()
    );

    String activationCode = registrationService.activationCode(request);

    BrokerDetailsResponse brokerDetailsResponse = accountManagementService.getBrokerDetails(request.getUsername());
    BrokerDetails brokerDetails = brokerDetailsResponse.getBrokerDetails();

    emailService.send(
        EmailActivationCodeRequestModel.builder()
            .templateName(activationCodeTemplate.getName())
            .toRecipients(brokerDetails.getEmail())
            .firstname(brokerDetails.getFirstName())
            .surname(brokerDetails.getLastName())
            .registrationUrl(activationCodeTemplate.getRegistrationUrl())
            .activationCode(activationCode)
            .build());

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Activation code request for user: %s", request.getUsername()))
            .build()
    );
  }
}
