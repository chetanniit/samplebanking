package com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentPathDto {

  @JsonProperty("mbs_paymentpathid")
  public String paymentPathId;

  @JsonProperty("mbs_paymentpathname")
  public String paymentPathname;

  @JsonProperty("mbs_residentialproductscale")
  public String residentialProductScale;

  @JsonProperty("mbs_btlproductscale")
  public String btlProductScale;
}
