package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidateEnum;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class FirmDetails {

    @ValidateEnum(enumClass = BrokerType.class)
    private String brokerType;

    @NotBlank
    private String firmName;

    @NotBlank
    private String fcaNumber;

    private String principalFcaNumber;

    private String previousFirmName;

    private String previousFcaNumber;
}
