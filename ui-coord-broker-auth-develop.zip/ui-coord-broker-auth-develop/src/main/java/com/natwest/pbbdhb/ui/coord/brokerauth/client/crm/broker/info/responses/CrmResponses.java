package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.responses;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import java.util.HashMap;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Component
@ConfigurationProperties(prefix = "clients.brokerinfo.rest")
@Data
@Validated
public class CrmResponses {

  @NotNull
  private HashMap<String, CrmMessage> responses;

  public boolean isSuccessful(String endpointKey, JSONObject json) {
    if(json == null) {
      log.error(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INPUT_VALIDATION)
              .description("Json supplied to response check cannot be null.")
              .build()
      );
      throw new CrmDataException("Json supplied to response check cannot be null");
    }

    CrmMessage responseChecker = responses.get(endpointKey);
    if(responseChecker == null) {
      log.error(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description("No response checker configured for endpoint: " + endpointKey)
              .build()
      );
      throw new CrmDataException("No response checker configured for endpoint: " + endpointKey);
    }
    return responseChecker.check(json);
  }
}

