
package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UsernameReminderResponse {
    private Boolean usernameIdentified;
    private String message;
}
