package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class ActivationCodeGenerateClientRequest {

  @JsonProperty("username")
  @NonNull
  String username;

}
