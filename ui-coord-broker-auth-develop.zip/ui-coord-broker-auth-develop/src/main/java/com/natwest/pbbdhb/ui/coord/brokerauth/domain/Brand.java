package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents all supported brands.
 */
@Slf4j
@Getter
public enum Brand {

  NWB("nwb");

  private final String value;

  Brand(String value) {
    this.value = value;
  }

  public static Brand fromValue(String text) {
    for (Brand brand : Brand.values()) {
      if (brand.value.equalsIgnoreCase(text)) {
        return brand;
      }
    }
    log.warn(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(String.format("Unsupported brand '%s'", text))
            .build()
    );
    throw new IllegalArgumentException("Unsupported brand: " + text);
  }
}
