package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class DeleteUserRequestModel {

  @NonNull
  String username;
}
