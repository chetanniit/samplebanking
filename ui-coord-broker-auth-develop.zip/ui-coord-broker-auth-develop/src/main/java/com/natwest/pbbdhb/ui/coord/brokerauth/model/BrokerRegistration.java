package com.natwest.pbbdhb.ui.coord.brokerauth.model;


import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidatePreviousFirmDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidatePrincipalFcaNumber;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import jakarta.validation.constraints.NotNull;
import java.util.List;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG;


@Data
public class BrokerRegistration {

    @NotNull
    @Valid
    private UserDetails brokerDetails;

    @NotNull
    @Valid
    private Agreements agreements;

    @NotNull
    @Valid
    private Address address;

    @NotNull
    @ValidatePrincipalFcaNumber(message = PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG)
    @ValidatePreviousFirmDetails(message = PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG)
    @Valid
    private FirmDetails firmDetails;

    @NotNull
    private String username;

    @NotEmpty
    private List<String> paymentPaths;
}
