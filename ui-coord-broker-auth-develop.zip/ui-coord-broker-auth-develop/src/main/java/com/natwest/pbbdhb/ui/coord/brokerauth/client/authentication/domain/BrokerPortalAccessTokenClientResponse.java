package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain;


import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.CheckForNull;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.extern.jackson.Jacksonized;

@Getter
@Builder
@Jacksonized
public class BrokerPortalAccessTokenClientResponse {

  @NonNull
  @JsonProperty("accessToken")
  String accessToken;

  @NonNull
  @JsonProperty("tokenType")
  String tokenType;

  @CheckForNull
  @JsonProperty("expiresIn")
  Integer expiresIn;
}