package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;


import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper.ActivationRequestMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.activation.ActivationService;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("activation")
@Tag(name = "Activate User",
    description = "API for user activation")
@Slf4j
@Validated
public class ActivationController {

  private final ActivationService activationService;

  public ActivationController(
      ActivationService activationService) {
    this.activationService = activationService;
  }

  @Operation(
      operationId = "activation",
      summary = "Activates user"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "User was Activated successful"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "401", description = "Unauthorized"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PostMapping
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void activateUser(@RequestBody @Valid ActivateUserRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Activation request for user: %s", request.getUsername()))
        .build()
    );

    activationService.activateUser(ActivationRequestMapper.toDomainModel(request));

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of method Activation Request for user: %s", request.getUsername()))
            .build()
    );
  }

  @PostMapping("/validate")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @Operation(responses = {
      @ApiResponse(responseCode = "204", description = "Successfully validated activation code"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "401", description = "Unauthorised", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
      @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
          @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
  })
  public void validateActivationCode(
      @Valid @RequestBody ActivationCodeValidateRequest request) {

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format(
            "Validate activation code request for code: %s, for user: %s", request.getCode(), request.getUsername()))
        .build()
    );
    activationService.validateActivationCode(ActivationRequestMapper.toDomainModel(request));

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "End of request for Validation of activation code for code: %s, for user: %s", request.getCode(),
                    request.getUsername()))
            .build()
    );
  }
}
