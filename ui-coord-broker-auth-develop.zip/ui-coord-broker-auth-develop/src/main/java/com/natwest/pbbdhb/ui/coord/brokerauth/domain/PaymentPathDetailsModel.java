package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.Value;

import javax.annotation.CheckForNull;

@Builder
@Value
public class PaymentPathDetailsModel {

    @CheckForNull
    String paymentPathId;

    @CheckForNull
    String paymentPathName;

    @CheckForNull
    String paymentPathScaleBtl;

    @CheckForNull
    String paymentPathScaleResidential;

}
