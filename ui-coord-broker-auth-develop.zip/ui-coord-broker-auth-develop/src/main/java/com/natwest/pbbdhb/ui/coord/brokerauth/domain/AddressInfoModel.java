package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import javax.annotation.CheckForNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddressInfoModel {

  @CheckForNull
  private String postcode;

  @CheckForNull
  private String line1;

  @CheckForNull
  private String line2;

  @CheckForNull
  private String line3;

  @CheckForNull
  private String city;

  @CheckForNull
  private String county;

  @CheckForNull
  private String country;
}
