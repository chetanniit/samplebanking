package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UsernameAvailableResponse {
    private final boolean isAvailable;
    private final boolean isError;
    private final String error;
}
