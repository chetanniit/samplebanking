package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import java.util.List;

public interface BrokerInfo {

  BrokerInfoBrokerDomainModel getBrokerInfo(String username);

  BrokerInfoBrokerDomainModel getAdminInfo(String username);
}
