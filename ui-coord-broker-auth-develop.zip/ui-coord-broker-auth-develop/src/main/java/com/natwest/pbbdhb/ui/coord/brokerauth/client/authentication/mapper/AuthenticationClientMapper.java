package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.mapper;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain.BrokerPortalAccessTokenClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain.BrokerPortalAccessTokenClientResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.*;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AuthenticationClientMapper {


    public static BrokerPortalAccessTokenClientRequest toBrokerPortalAccessTokenClientRequest(
            BrokerPortalAccessTokenRequestModel requestModel) {
        log.info(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.INCOMING)
                .description("Mapping Access Token Client Request to Broker Portal")
                .build()
        );
        return BrokerPortalAccessTokenClientRequest.builder()
                .brokerRole(requestModel.getBrokerRole())
                .userName(requestModel.getUserName())
                .fcaNumber(requestModel.getFcaNumber())
                .build();
    }

    public static BrokerPortalAccessTokenResponseModel toBrokerPortalAccessTokenResponseModel(
            BrokerPortalAccessTokenClientResponse clientResponse) {
        log.info(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .description("Mapping Access Token Response Model to Broker Portal")
                .build()
        );
        return BrokerPortalAccessTokenResponseModel.builder()
                .accessToken(clientResponse.getAccessToken())
                .tokenType(clientResponse.getTokenType())
                .expiresIn(clientResponse.getExpiresIn())
                .build();
    }

}
