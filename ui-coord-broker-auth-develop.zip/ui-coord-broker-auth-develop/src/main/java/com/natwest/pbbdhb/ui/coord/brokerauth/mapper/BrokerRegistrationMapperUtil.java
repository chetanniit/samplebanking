package com.natwest.pbbdhb.ui.coord.brokerauth.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class BrokerRegistrationMapperUtil {

    private static final ObjectMapper objectMapper = JsonMapper.builder()
            .findAndAddModules()  // load extensions for LocalDate, etc.
            .build();

    public static <T> String toJson(T object) {
        try {
            log.info(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .description("Mapping object to JSON")
                    .build()
            );
            return object != null ? objectMapper.writeValueAsString(object) : null;
        } catch (JsonProcessingException e) {
            log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .description(String.format("Error writing object to JSON. Error message: %s",e.getMessage()))
                    .build());
            throw new RuntimeException("Error writing object to JSON. Error message: " + e.getMessage());
        }
    }

    private BrokerRegistrationMapperUtil(){
    }
}
