package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class QuestionsNotRetrievedException extends RuntimeException {
  public QuestionsNotRetrievedException(String message) {
    super(message);
  }

  public QuestionsNotRetrievedException(String message, Throwable cause) {
    super(message, cause);
  }
}
