package com.natwest.pbbdhb.ui.coord.brokerauth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDate;

@Data
public class BrokerRegistrationDto {

    @JsonProperty("mbs_brokerdetails")
    private String brokerDetails;
    @JsonProperty("mbs_address")
    private String address;
    @JsonProperty("mbs_firmdetails")
    private String firmDetails;
    @JsonProperty("mbs_username")
    private String username;
    @JsonProperty("mbs_paymentpaths")
    private String paymentPaths;
    @JsonProperty("mbs_tradingnames")
    private String tradingNames;
    @JsonProperty("mbs_residentialaddress")
    private String residentialAddress;

    @Data
    public static class BrokerDetailsDto {
        private String title;
        private String firstNames;
        private String lastName;
        private LocalDate dateOfBirth;
        private String nationality;
        private String primaryPhoneNumber;
        private String secondaryPhoneNumber;
        private String emailAddress;
    }

    @Data
    public static class AddressDto {
        private String addressLine1;
        private String addressLine2;
        private String addressLine3;
        private String town;
        private String county;
        private String postcode;
    }

    @Data
    public static class ResidentialAddressDto {
        private String addressLine1;
        private String addressLine2;
        private String addressLine3;
        private String town;
        private String county;
        private String postcode;
        private String country;
    }

    @Data
    public static class FirmDetailsDto {
        private String brokerType;
        private String firmName;
        private String fcaNumber;
        private String principalFcaNumber;
        private String previousFirmName;
        private String previousFcaNumber;
    }
}

