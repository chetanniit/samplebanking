package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.responses.CrmResponses;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.AdminInfoDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelper;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Component
public class BrokerInfoRestClient {

    private static final String READ_BROKER_CORE = "mbs_ReadBrokerCore";
    private static final String READ_BROKER_ADMIN_CORE = "mbs_ReadBrokerAdminCore";

    private final OkHttpClient httpClient;
    private final SecurityTokenHelper securityTokenHelper;
    private final CrmResponses crmResponses;
    private final String readBrokerEndpoint;
    private final String readAdminEndpoint;

    private final ObjectMapper objectMapper;

    public BrokerInfoRestClient(
        @Qualifier("proxyHttpClient") OkHttpClient httpClient,
        SecurityTokenHelper securityTokenHelper,
        CrmResponses crmResponses,
        ObjectMapper objectMapper,
        @Value("${broker-info.readBrokerEndpoint}") String readBrokerEndpoint,
        @Value("${broker-info.readAdminEndpoint}") String readAdminEndpoint) {

        this.httpClient = httpClient;
        this.securityTokenHelper = securityTokenHelper;
        this.crmResponses = crmResponses;
        this.objectMapper = objectMapper;
        this.readBrokerEndpoint = readBrokerEndpoint;
        this.readAdminEndpoint = readAdminEndpoint;
    }

    public BrokerInfoResponseDto getBrokerInfo(String username) {
        logRequestAttempt("Fetching Broker Info from CRM for : " + username);
        return crm_readInfo(username, readBrokerEndpoint, READ_BROKER_CORE, BrokerInfoResponseDto.class);
    }

    public AdminInfoDto getAdminInfo(String username) {
        logRequestAttempt("Fetching Admin Info from CRM for : " + username);
        return crm_readInfo(username, readAdminEndpoint, READ_BROKER_ADMIN_CORE, AdminInfoDto.class);
    }

    private <T> T crm_readInfo(String username, String endpoint, String endpointKey, Class<T> clazz) {

        try {
            Map<String, String> usernameMap = Collections.singletonMap("username", username);
            String callUrl = UriComponentsBuilder.fromHttpUrl(endpoint).buildAndExpand(usernameMap).toUriString();
            Response response = get(callUrl);

            int status = response.code();
            if (status != HttpURLConnection.HTTP_OK) {
                log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .subtype(LogMessageSubtype.ERROR_RESPONSE)
                    .description(String.format("Error in CRM Read Info call. Endpoint %s returned %d (%s)", endpoint,
                            status, response.message()))
                    .build()
                );
                throw new CrmEndpointException(
                    String.format("Endpoint %s returned %d (%s)",
                        endpoint, status, response.message()));
            }

            JSONObject jsonObject = (JSONObject) JSONValue.parse(Objects.requireNonNull(response.body()).string());

            log.info(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .description(String.format("Received CRM Info response: '%s' for user: %s", jsonObject.toString(),
                        username))
                .build());

            if(!crmResponses.isSuccessful(endpointKey, jsonObject)) {
                log.warn(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.OUTGOING)
                        .subtype(LogMessageSubtype.ERROR_RESPONSE)
                        .description(String.format("CRM failed to find the requested data for ", username))
                        .build()
                );
                throw new CrmDataException("CRM failed to find the requested data for " + username);
            }

            return objectMapper.convertValue(jsonObject, clazz);

        } catch (NullPointerException npe) {
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description("No broker/admin details returned, NullPointerException : " + npe)
                .build()
            );
            throw new CrmEndpointException(
                String.format("Endpoint %s returned an invalid response %s",
                    endpoint, npe.getMessage()));
        } catch (CrmDataException cde) {
            log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INPUT_VALIDATION)
                .description("CrmDataException: " + cde.getMessage())
                .build()
            );
            throw cde;
        } catch (IOException e) {
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description("Error getting broker/admin details : " + e)
                .build()
            );
            throw new CrmEndpointException(
                String.format("Endpoint %s request failed %s",
                    endpoint, e.getMessage()));
        }
    }

    private Response get(String url) throws IOException {
        logRequestAttempt("Making request to " + url);

        Request request = new Request.Builder()
            .url(url)
            .get()
            .addHeader("Authorization", "Bearer " + this.securityTokenHelper.getAccessToken())
            .build();

        return httpClient.newCall(request).execute();
    }

    private void logRequestAttempt(String message) {
        log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(message)
            .build());
    }
}
