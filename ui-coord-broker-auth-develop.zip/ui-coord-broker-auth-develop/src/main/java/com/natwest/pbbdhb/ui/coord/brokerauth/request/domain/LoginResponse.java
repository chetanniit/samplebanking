package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import javax.annotation.CheckForNull;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class LoginResponse {

    @NonNull
    String accessToken;

    @NonNull
    String tokenType;

    // expires-in is an optional field for IAM access tokens
    @CheckForNull
    Integer expiresIn;

    @NonNull
    UserRegistrationType brokerType;
}
