package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import java.util.List;

import jakarta.validation.Valid;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class ValidateSecurityAnswersRequestModel {

  @NonNull
  String username;

  @NonNull
  List<@Valid SecurityQuestion> securityQuestions;
}
