package com.natwest.pbbdhb.ui.coord.brokerauth.validator;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidatePrincipalFcaNumber;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.util.StringUtils;

import static com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.BrokerType.APPOINTED_REPRESENTATIVE;

public class PrincipalFcaNumberValidator implements ConstraintValidator<ValidatePrincipalFcaNumber, FirmDetails> {

    @Override
    public boolean isValid(FirmDetails value, ConstraintValidatorContext context) {
        if (value == null || value.getBrokerType() == null) {
            return true;
        }
        if (APPOINTED_REPRESENTATIVE.value().equals(value.getBrokerType())) {
            return StringUtils.hasText(value.getPrincipalFcaNumber());
        } else {
            return value.getPrincipalFcaNumber() == null;
        }
    }
}
