package com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation;

import com.natwest.pbbdhb.ui.coord.brokerauth.validator.AtLeastOneNotNullValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = AtLeastOneNotNullValidator.class)
public @interface ValidateAtLeastOneNotNull {

    String message() default "at least one of the fields '${errorMessageFields}' must not be null";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String fields();
}
