package com.natwest.pbbdhb.ui.coord.brokerauth.model.enums;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum BrokerType implements ValuedEnum {
    APPOINTED_REPRESENTATIVE("AR"),
    DIRECTLY_AUTHORISED("DA");

    private final String value;

    @Override
    public String value() {
        return this.value;
    }
}