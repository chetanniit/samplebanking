package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

/**
 * Represents a user's credentials
 */
@Validated
@Value
@Builder
public class LoginRequest {

  @JsonProperty("username")
  @Schema(
      description = "Username from a user's credentials",
      required = true
  )
  @NotNull String username;

 @JsonProperty("password")
  @Schema(
      description = "Password from a user's credentials",
      required = true
  )
  @NotNull String password;
}