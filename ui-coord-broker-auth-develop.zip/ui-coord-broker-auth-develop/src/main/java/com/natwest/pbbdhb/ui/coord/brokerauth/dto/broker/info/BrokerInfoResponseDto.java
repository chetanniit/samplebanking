package com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrokerInfoResponseDto {

    @JsonProperty("mbs_message")
    public String message;

    @JsonProperty("mbs_paymentPaths")
    public List<PaymentPathDto> paymentPaths;

    @JsonProperty("mbs_broker")
    public BrokerInfoDto broker;

    @JsonProperty("mbs_brokerUpdateRequest")
    public BrokerUpdateRequestDto brokerUpdateRequest;

    @JsonProperty("mbs_firm")
    public FirmDto firm;

    @JsonProperty("mbs_tradingName")
    public TradingNameDto tradingName;
}
