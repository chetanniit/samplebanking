package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.event;

public interface BrokerEvent {

  /**
   * Create a Broker Event for Broker Activation
   *
   * @param userName the broker or admin user that has been activated
   * @return a boolean indicating if the event was successfully created in crm
   */
  boolean createBrokerActivationEvent(String userName);

}
