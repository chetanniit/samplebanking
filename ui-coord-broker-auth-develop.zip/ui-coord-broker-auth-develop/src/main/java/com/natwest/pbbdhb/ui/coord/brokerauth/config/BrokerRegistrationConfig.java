package com.natwest.pbbdhb.ui.coord.brokerauth.config;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ProxyConfigurationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class BrokerRegistrationConfig {

  @Bean
  public OkHttpClient proxyHttpClient(@Value("${proxy.host}") String proxyHost,
      @Value("${http.connection.timeout:#{10}}") int connectionTimeout,
      @Value("${proxy.port:#{0}}") int proxyPort,
      @Value("${proxy.authentication.required:#{false}}") boolean proxyAuthRequired,
      @Value("${proxy.username:#{null}}") String username,
      @Value("${proxy.password:#{null}}") String password)
      throws NoSuchAlgorithmException, KeyManagementException {

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.CONFIG)
        .description(String.format("Proxy configuration = (host: %s, port: %s, username: %s)", proxyHost, proxyPort,
                username))
        .build()
    );

    OkHttpClient.Builder builder = new OkHttpClient.Builder();
    addSslConfig(builder);

    // userproxy.rbsgrp.net requires authentication - appproxy.rbsgrp.net does not
    if (proxyAuthRequired) {
      if (Objects.isNull(username) || Objects.isNull(password)) {
          log.error(LogMessage.builder()
                  .system(LogMessageSystem.NAPOLI)
                  .type(LogMessageType.CONFIG)
                  .description("Username and password have to be provided when authentication required ")
                  .build()
          );
        throw new ProxyConfigurationException(
            "Username and password have to be provided when authentication required");
      }
      Authenticator proxyAuthenticator = (route, response) -> {
        String credential = Credentials.basic(username, password);
          log.info(LogMessage.builder()
                  .system(LogMessageSystem.NAPOLI)
                  .type(LogMessageType.CONFIG)
                  .description(String.format("Proxy-Authorization underway with provided credentials for user: %s",
                                  username))
                  .build()
          );
        return response.request().newBuilder()
            .header("Proxy-Authorization", credential)
            .build();
      };
      builder.proxyAuthenticator(proxyAuthenticator);
    }

    HttpLoggingInterceptor logger = new HttpLoggingInterceptor();
    HttpLoggingInterceptor.Level logLevel = HttpLoggingInterceptor.Level.BODY; // Level.BODY is higher than Level.HEADERS
    logger.setLevel(logLevel);
    builder.addInterceptor(logger);
    builder.connectTimeout(connectionTimeout, TimeUnit.SECONDS);
    return builder.proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)))
        .build();
  }

  private void addSslConfig(OkHttpClient.Builder builder)
      throws NoSuchAlgorithmException, KeyManagementException {
    // TODO Temporarily switch off the TLS server certificate checking until we can figure out what we need to add to the trust store
    X509TrustManager[] trustAllCerts = new X509TrustManager[]{
        new X509TrustManager() {
          @Override
          public void checkClientTrusted(java.security.cert.X509Certificate[] chain,
              String authType) {
          }

          @Override
          public void checkServerTrusted(java.security.cert.X509Certificate[] chain,
              String authType) {
          }

          @Override
          public java.security.cert.X509Certificate[] getAcceptedIssuers() {
            return new java.security.cert.X509Certificate[]{};
          }
        }
    };

    SSLContext sslContext = SSLContext.getInstance("TLS");
    sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
    SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

    builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0]);
    builder.hostnameVerifier((hostname, session) -> true);
  }
}
