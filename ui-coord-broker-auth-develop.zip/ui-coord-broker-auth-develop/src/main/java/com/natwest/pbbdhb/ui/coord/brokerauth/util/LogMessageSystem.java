package com.natwest.pbbdhb.ui.coord.brokerauth.util;

public class LogMessageSystem {
  public static String NAPOLI = "Napoli";
}
