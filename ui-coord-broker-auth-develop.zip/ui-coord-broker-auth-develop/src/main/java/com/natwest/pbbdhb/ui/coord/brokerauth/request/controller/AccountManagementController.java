package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.EmailForgottenPasswordTemplateConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.EmailAccountRecoveryModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ResetPasswordRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.RetrieveChallengeQuestionsRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.RetrieveChallengeQuestionsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.SubmitChallengeAnswersRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ValidateOtpRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper.AccountManagementRequestMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.account.AccountManagementService;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info.BrokerInfoFactory;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.email.EmailService;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/account-management")
@Tag(name = "Account Management",
    description = "API for account management")
@Slf4j
@Validated
@Configuration
public class AccountManagementController {

  private final BrokerInfoFactory brokerInfoFactory;
  private final AccountManagementService accountManagementService;
  private final EmailService emailService;
  private final EmailForgottenPasswordTemplateConfig forgottenPasswordTemplateConfig;
  private final Boolean featureForgotUsernameEnabled;

  public AccountManagementController(BrokerInfoFactory brokerInfoFactory,
                                     AccountManagementService accountManagementService, EmailService emailService,
                                     EmailForgottenPasswordTemplateConfig forgottenPasswordTemplateConfig,
                                     @Value("${feature.forgotten.username.enabled:false}") Boolean featureForgotUsernameEnabled) {
    this.brokerInfoFactory = brokerInfoFactory;
    this.accountManagementService = accountManagementService;
    this.emailService = emailService;
    this.forgottenPasswordTemplateConfig = forgottenPasswordTemplateConfig;
    this.featureForgotUsernameEnabled = featureForgotUsernameEnabled;
  }

  @PostMapping("/challenge-questions")
  @ResponseStatus(HttpStatus.OK)
  public RetrieveChallengeQuestionsResponse retrieveChallengeQuestions(
      @Valid @RequestBody RetrieveChallengeQuestionsRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                "Retrieving challenge questions request  for user: %s", request.getUsername()))
            .build()
    );

    List<String> securityQuestions = accountManagementService.retrieveSecurityQuestions(
        request.getUsername());

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Retrieving challenge questions request  for user: %s",
                    request.getUsername()))
            .build()
    );

    return AccountManagementRequestMapper.toResponseModel(securityQuestions);
  }
  @Operation(
      operationId = "challenge-answers",
      summary = "validate challenger answers for the account",
      tags = "Account Management"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "No Content - challenge answers validation was successful"),
      @ApiResponse(responseCode = "400", description = "Bad request - challenge answers validation failed"),
      @ApiResponse(responseCode = "401", description = "Unauthorised - challenge answers validation failed")
  })
  @PostMapping("/challenge-answers")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void submitChallengeAnswers(@Valid @RequestBody SubmitChallengeAnswersRequest request) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Validating challenge answers for user: %s", request.getUsername()))
        .build()
    );

    ValidateSecurityAnswersRequestModel requestModel = AccountManagementRequestMapper.toDomainModel(
        request);
    ValidateSecurityAnswersResponseModel responseModel = accountManagementService.validateSecurityAnswers(
        requestModel
    );

    BrokerInfoBrokerDomainModel brokerDetails = brokerInfoFactory.getBrokerTypeService(
            responseModel.getUserType())
        .getBrokerInfo(request.getUsername());

    emailService.send(
        EmailAccountRecoveryModel.builder()
            .templateName(forgottenPasswordTemplateConfig.getName())
            .toRecipients(brokerDetails.getEmailAddress())
            .firstname(brokerDetails.getBrokerFirstName())
            .surname(brokerDetails.getBrokerLastName())
            .accountRecoveryUrl(forgottenPasswordTemplateConfig.getAccountRecoveryUrl())
            .oneTimePasscode(responseModel.getOtp())
            .supportNumber(forgottenPasswordTemplateConfig.getSupportNumber()).build()
    );
    //log saying email has been sent to the user -- CHECK THIS ONE -- OUTGOING / INCOMING - ASK
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(String.format(
                    "Recovery email for brokerUsername: %s with email: %s sent successfully", request.getUsername(),
                    brokerDetails.getEmailAddress()))
            .build()
    );

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "End of Validation of challenge answers request for user: %s", request.getUsername()))
            .build()
    );
  }

  @Operation(
          operationId = "password-reset",
          summary = "Reset password for the account"
  )
  @ApiResponses(value = {
          @ApiResponse(responseCode = "204", description = "No Content - OTP validation was successful"),
          @ApiResponse(responseCode = "400", description = "Bad request - OTP validation failed"),
          @ApiResponse(responseCode = "401", description = "Unauthorised - OTP validation failed")
  })
  @PostMapping("password-reset")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void reset(@RequestBody @Valid ResetPasswordRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Reset password request for otp code: %s, for user: %s", request.getOtpCode(),
                    request.getUsername()))
            .build()
    );
    accountManagementService.resetPassword(AccountManagementRequestMapper.toDomainModel(request));
    //log for successful password reset?
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Password reset request for otp code: %s, for user: %s",
                    request.getOtpCode(), request.getUsername()))
            .build()
    );
  }

  @Operation(
          operationId = "otp-validation",
          summary = "Validate OTP for the user"
  )
  @ApiResponses(value = {
          @ApiResponse(responseCode = "204", description = "No Content - OTP validation was successful"),
          @ApiResponse(responseCode = "400", description = "Bad request - OTP validation failed"),
          @ApiResponse(responseCode = "401", description = "Unauthorised - OTP validation failed")
  })
  @PostMapping("otp-validation")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void validate(@RequestBody @Valid ValidateOtpRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Validating OTP request  for otp code: %s, for user: %s", request.getOtpCode(),
                    request.getUsername()))
            .build()
    );
    accountManagementService.validateOtp(AccountManagementRequestMapper.toDomainModel(request));
    //Log for OTP successfully validated
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "End of Validation of OTP request for otp code: %s, for user: %s", request.getOtpCode(),
                    request.getUsername()))
            .build()
    );
  }

  @Operation(
          operationId = "username-reminder",
          summary = "Get username reminder for the account"
  )
  @ApiResponses(value = {
          @ApiResponse(responseCode = "204", description = "No Content - username reminder was successful"),
          @ApiResponse(responseCode = "400", description = "Bad request - username reminder failed"),
          @ApiResponse(responseCode = "401", description = "Unauthorised - username reminder failed")
  })
  @PostMapping("username-reminder")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void getUsernameReminder(@RequestBody @Valid UsernameReminderRequest request) {
    if(!featureForgotUsernameEnabled) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.INCOMING)
              .description(String.format("Getting username reminder for %s. featureForgotUsernameEnabled=false: " +
                      "returning NOT_FOUND", request))
              .build()
      );
      throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Getting username reminder for %s", request))
            .build()
    );
    accountManagementService.getUsernameReminder(request);
    //log for username reminder successfully generated
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "End of Username reminder request for %s ", request))
            .build()
    );
  }
}
