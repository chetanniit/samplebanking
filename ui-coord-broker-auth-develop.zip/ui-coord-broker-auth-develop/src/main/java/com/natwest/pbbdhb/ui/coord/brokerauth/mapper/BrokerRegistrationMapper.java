package com.natwest.pbbdhb.ui.coord.brokerauth.mapper;

import com.natwest.pbbdhb.ui.coord.brokerauth.dto.AdminRegistrationDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto.AddressDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto.ResidentialAddressDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto.BrokerDetailsDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto.FirmDetailsDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.Address;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.ResidentialAddress;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UserDetails;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", imports = {StringUtils.class})
public interface BrokerRegistrationMapper {

    @Mapping(target = "brokerDetails", expression = "java(BrokerRegistrationMapperUtil.toJson(map(brokerRegistration.getBrokerDetails())))")
    @Mapping(target = "address", expression = "java(BrokerRegistrationMapperUtil.toJson(map(brokerRegistration.getAddress())))")
    @Mapping(target = "firmDetails", expression = "java(BrokerRegistrationMapperUtil.toJson(map(brokerRegistration.getFirmDetails())))")
    @Mapping(target = "residentialAddress", expression = "java(BrokerRegistrationMapperUtil.toJson(map(brokerRegistration.getBrokerDetails())) == null ? null : BrokerRegistrationMapperUtil.toJson(map(brokerRegistration.getBrokerDetails().getResidentialAddress())))")
    @Mapping(target = "paymentPaths", expression = "java(StringUtils.join(brokerRegistration.getPaymentPaths(), \",\"))")
    @Mapping(target = "tradingNames", source = "firmDetails.firmName")
    BrokerRegistrationDto toBrokerRegistrationDto(BrokerRegistration brokerRegistration);

    @Mapping(target = "title", source = "adminDetails.title.text")
    @Mapping(target = "firstName", source = "adminDetails.firstName")
    @Mapping(target = "middleName", source = "adminDetails.middleName")
    @Mapping(target = "lastName", source = "adminDetails.lastName")
    @Mapping(target = "dateOfBirth", source = "adminDetails.dateOfBirth")
    @Mapping(target = "mobilePhone", source = "adminDetails.mobilePhoneNumber")
    @Mapping(target = "businessPhone", source = "adminDetails.otherPhoneNumber")
    @Mapping(target = "emailAddress", source = "adminDetails.emailAddress")
    @Mapping(target = "firmName", source = "firmDetails.firmName")
    @Mapping(target = "fcaNumber", source = "firmDetails.fcaNumber")
    @Mapping(target = "principalFcaNumber", source = "firmDetails.principalFcaNumber")
    AdminRegistrationDto toAdminRegistrationDto(AdminRegistration adminRegistration);

    @Mapping(target = "title", source = "title.text")
    @Mapping(target = "primaryPhoneNumber", source = "mobilePhoneNumber")
    @Mapping(target = "secondaryPhoneNumber", source = "otherPhoneNumber")
    BrokerDetailsDto map(UserDetails userDetails);

    AddressDto map(Address address);

    FirmDetailsDto map(FirmDetails firmDetails);

    @Mapping(target = "country", source = "countryOfAddress")
    ResidentialAddressDto map(ResidentialAddress residentialAddress);

}
