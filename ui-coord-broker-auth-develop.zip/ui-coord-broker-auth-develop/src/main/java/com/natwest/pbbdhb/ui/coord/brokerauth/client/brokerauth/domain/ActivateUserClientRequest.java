package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class ActivateUserClientRequest {

  @JsonProperty("otpCode")
  @NonNull
  String otpCode;

  @JsonProperty("username")
  @NonNull
  String username;

  @JsonProperty("password")
  @NonNull
  String password;

  @JsonProperty("securityQuestions")
  @NonNull
  List<SecurityQuestionClientRequest> securityQuestions;
}
