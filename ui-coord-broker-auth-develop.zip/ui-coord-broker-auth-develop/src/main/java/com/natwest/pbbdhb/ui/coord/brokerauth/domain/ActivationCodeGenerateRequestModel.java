package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class ActivationCodeGenerateRequestModel {

  @JsonProperty("username")
  @Schema(
      description = "Username from a user's credentials",
      required = true
  )
  @NotNull String username;

  // Lombok doesn't like single member classes, so we manually added a constructor
  @JsonCreator
  public ActivationCodeGenerateRequestModel(@JsonProperty("username") String username) {
    this.username = username;
  }

}