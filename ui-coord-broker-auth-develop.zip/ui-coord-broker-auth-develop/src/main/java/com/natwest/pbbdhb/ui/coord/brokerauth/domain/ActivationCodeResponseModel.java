package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

/**
 * A controller request domain model describing the payload returned by the post activation code
 * endpoint.
 */
@Builder
@Value
public class ActivationCodeResponseModel {

  /**
   * The activation code to be sent to the user during broker registration.
   */
  @Schema(
      description = "The activation code used to activate a users account",
      example = "dFasdf3",
      required = true
  )
  String code;
}
