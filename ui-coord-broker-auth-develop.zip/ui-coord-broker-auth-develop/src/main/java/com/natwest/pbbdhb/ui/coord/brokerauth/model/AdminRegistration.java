package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.*;

import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidatePreviousFirmDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidatePrincipalFcaNumber;
import jakarta.validation.Valid;
import lombok.Data;
import jakarta.validation.constraints.NotNull;


@Data
public class AdminRegistration {

    @NotNull
    @Valid
    private AdminDetails adminDetails;

    @NotNull
    @Valid
    private Agreements agreements;

    @NotNull
    @ValidatePrincipalFcaNumber(message = PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG)
    @ValidatePreviousFirmDetails(message = PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG)
    @Valid
    private FirmDetails firmDetails;

    @NotNull
    private String username;
}
