package com.natwest.pbbdhb.ui.coord.brokerauth.util;

public class LogMessageSubtype {

  public static String INPUT_VALIDATION = "InputValidation";
  public static String INVALID_RESPONSE = "InvalidResponse";
  public static String ERROR_RESPONSE = "ErrorResponse";
}
