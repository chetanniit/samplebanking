package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import java.security.PrivateKey;
import java.security.PublicKey;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class CertificateModel {

  @NonNull
  PublicKey publicKey;

  @NonNull
  PrivateKey privateKey;

  @NonNull
  String certificateThumbPrint;

}
