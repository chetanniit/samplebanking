package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to validate OTP for user.
 */
@Builder
@Value
public class ValidateOtpRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's otp code to be validated. As this is a required field, {@code @NonNull} has
   * been set.
   */
  @NonNull
  String otpCode;

}
