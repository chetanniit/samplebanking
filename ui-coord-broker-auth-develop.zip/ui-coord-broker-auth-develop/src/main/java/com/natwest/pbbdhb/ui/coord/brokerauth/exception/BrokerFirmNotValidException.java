package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@ResponseStatus(NOT_FOUND)
public class BrokerFirmNotValidException extends RuntimeException {

    public BrokerFirmNotValidException(String message) {
        super(message);
    }
}
