package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class BrokerInfoBrokerDomainModel {
  private String brokerId;

  private String username;

  private String title;

  private String brokerFirstName;

  private String brokerLastName;

  private String emailAddress;

  private String businessPhone;

  private String mobileNumber;

  private String brokerPostcode;

  private String fcaNumber;

  private String principalFcaNumber;

  private String tradingName;

  private String firmName;

  private AddressInfoModel firmAddress;

  private List<PaymentPathDetailsModel> paymentPaths;

}
