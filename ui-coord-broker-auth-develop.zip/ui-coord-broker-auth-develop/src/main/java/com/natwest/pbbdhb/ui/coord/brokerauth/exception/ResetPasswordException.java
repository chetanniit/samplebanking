package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;

public class ResetPasswordException extends RuntimeException {

  private final ErrorCode code;
  private final int httpStatus;

  public ResetPasswordException(int httpStatus, ErrorCode code, String message) {
    super(message);
    this.httpStatus = httpStatus;
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }

  public int getHttpStatus() { return httpStatus; }
}