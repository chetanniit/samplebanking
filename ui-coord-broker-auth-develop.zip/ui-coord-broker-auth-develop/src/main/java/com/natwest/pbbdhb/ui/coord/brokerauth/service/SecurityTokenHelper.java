package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.CrmTokenAuthConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.CertificateModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.JsonWebTokenModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.AccessTokenNotRefreshedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.JwtSigningUtil;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SecurityTokenHelper {

    private static final String GRANT_TYPE = "client_credentials";
    private static final String CLIENT_ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";

    private final OkHttpClient httpClient;
    private final String proxyHost;
    private final int proxyPort;
    private final boolean proxyAuthRequired;
    private final String proxyUsername;
    private final CrmTokenAuthConfig tokenConfig;
    private final CertificateModel certificate;
    private String accessToken;
    private LocalDateTime accessTokenExpires;

    @Autowired
    public SecurityTokenHelper(@Qualifier("proxyHttpClient") OkHttpClient httpClient,
                               @Value("${proxy.host:#{null}}") String proxyHost,
                               @Value("${proxy.port:#{999}}") int proxyPort,
                               @Value("${proxy.authentication.required:#{false}}") boolean proxyAuthRequired,
                               @Value("${proxy.username:#{null}}") String proxyUsername,
                               CrmTokenAuthConfig tokenConfig,
                               CertificateModel certificate) {
        this.proxyHost = proxyHost;
        this.proxyPort = proxyPort;
        this.proxyAuthRequired = proxyAuthRequired;
        this.proxyUsername = proxyUsername;
        this.httpClient = httpClient;
        this.tokenConfig = tokenConfig;
        this.certificate = certificate;
    }

    public String getAccessToken() {
        if (shouldRefreshAccessToken()) {
            refreshAccessToken();
        }
        log.debug(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .description("Access token retrieved successfully.")
                .build());
        return accessToken;
    }

    private void refreshAccessToken() {
        try {
            log.debug(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .description(String.format(
                    "Proxy configuration = (host: %s, port: %s, auth required: %s, username: %s)",
                    proxyHost, proxyPort, proxyAuthRequired, proxyUsername))
                .build()
            );

            // create signed JWT
            JsonWebTokenModel jwtModel = JsonWebTokenModel
                .builder()
                .header(JsonWebTokenModel.HeaderModel.builder()
                    .algorithm(tokenConfig.getAlgorithm())
                    .kid(certificate.getCertificateThumbPrint())
                    .x5t(tokenConfig.getX5t())
                    .build())
                .payload(JsonWebTokenModel.PayloadModel.builder()
                    .issuer(tokenConfig.getClientId())
                    .audience(tokenConfig.getAudience())
                    .subject(tokenConfig.getClientId())
                    .build())
                .build();
            String jwt = JwtSigningUtil.createJwt(jwtModel, certificate.getPrivateKey());

            // create access token request
            final Request request = new Request.Builder()
                .url(tokenConfig.getUrl())
                .post(new FormBody.Builder()
                    .add("grant_type", GRANT_TYPE)
                    .add("client_id", tokenConfig.getClientId())
                    .add("tenant", tokenConfig.getTenantId())
                    .add("resource", tokenConfig.getResource())
                    .add("client_assertion_type", CLIENT_ASSERTION_TYPE)
                    .add("client_assertion", jwt)
                    .build())
                .build();


            Response tokenResponse = httpClient.newCall(request).execute();
            ResponseBody body = tokenResponse.body();
            if (body != null) {
                JSONObject jsonObject = (JSONObject) JSONValue.parse(body.string());
                accessToken = jsonObject.get("access_token").toString();

                String expiresOn = jsonObject.get("expires_on").toString();
                accessTokenExpires = LocalDateTime.ofEpochSecond(Long.parseUnsignedLong(expiresOn), 0, ZoneOffset.UTC);
            }
        } catch (IOException ex) {
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(String.format("Problem getting access token, AccessTokenNotRefreshedException: %s",
                        ex.getMessage()))
                .build(),
                ex
            );
            throw new AccessTokenNotRefreshedException("Problem getting access token: " + ex.getMessage());
        }
    }

    private boolean shouldRefreshAccessToken() {
        return null == accessTokenExpires || null == accessToken || accessTokenExpires.isBefore(LocalDateTime.now(ZoneOffset.UTC).plusMinutes(1));
    }
}
