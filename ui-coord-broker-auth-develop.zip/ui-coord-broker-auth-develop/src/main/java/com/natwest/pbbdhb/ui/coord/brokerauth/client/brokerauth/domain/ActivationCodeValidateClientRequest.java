package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Builder
@Value
public class ActivationCodeValidateClientRequest {

  @NonNull
  String username;

  @NonNull
  String code;

}
