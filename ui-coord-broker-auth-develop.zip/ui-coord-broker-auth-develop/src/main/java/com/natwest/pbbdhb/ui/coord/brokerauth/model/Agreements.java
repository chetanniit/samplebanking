package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import jakarta.validation.constraints.AssertTrue;
import lombok.Data;

import jakarta.validation.constraints.NotNull;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.BUSINESS_DECLARATION_NOT_CONFIRMED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.PRIVACY_POLICY_NOT_ACCEPTED_MSG;
import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG;

@Data
public class Agreements {

    @NotNull
    @AssertTrue(message = PRIVACY_POLICY_NOT_ACCEPTED_MSG)
    private Boolean privacyPolicy;

    @AssertTrue(message = TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG)
    private Boolean termsOfBusiness;

    @AssertTrue(message = BUSINESS_DECLARATION_NOT_CONFIRMED_MSG)
    private Boolean businessDeclaration;
}
