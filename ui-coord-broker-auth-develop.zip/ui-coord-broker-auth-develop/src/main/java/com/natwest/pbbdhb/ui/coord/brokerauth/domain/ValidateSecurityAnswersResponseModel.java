package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class ValidateSecurityAnswersResponseModel {

  @NonNull
  String otp;

  @NonNull
  UserRegistrationType userType;
}
