package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class EmailSendFailedException extends RuntimeException {

  public EmailSendFailedException(String message) {
    super(message);
  }
}