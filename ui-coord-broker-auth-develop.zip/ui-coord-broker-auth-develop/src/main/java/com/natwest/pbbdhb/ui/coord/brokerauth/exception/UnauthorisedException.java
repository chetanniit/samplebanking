package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;

public class UnauthorisedException extends RuntimeException {

  private final ErrorCode code;

  public UnauthorisedException(ErrorCode code, Exception ex) {
    super(ex.getMessage(), ex);
    this.code = code;
  }

  public UnauthorisedException(ErrorCode code, String message) {
    super(message);
    this.code = code;
  }

  public UnauthorisedException(ErrorCode code, String message, Exception ex) {
    super(message, ex);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }

}
