package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.mapper.BrokerInfoClientMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.AdminInfoDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class BrokerInfoClient implements BrokerInfo {

  private final BrokerInfoRestClient restClient;

  public BrokerInfoClient(BrokerInfoRestClient restClient) {
    this.restClient = restClient;
  }

  @Override
  public BrokerInfoBrokerDomainModel getBrokerInfo(String username) {
    BrokerInfoResponseDto dto = restClient.getBrokerInfo(username);
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description("Retrieving Broker Info.")
            .build());
    return BrokerInfoClientMapper.toDomain(dto);
  }

  @Override
  public BrokerInfoBrokerDomainModel getAdminInfo(String username) {
    AdminInfoDto dto = restClient.getAdminInfo(username);
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description("Retrieving Admin Info.")
            .build());
    return BrokerInfoClientMapper.toDomain(dto);
  }
}
