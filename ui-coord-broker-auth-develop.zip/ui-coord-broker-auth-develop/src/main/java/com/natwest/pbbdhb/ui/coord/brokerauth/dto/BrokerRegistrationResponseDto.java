package com.natwest.pbbdhb.ui.coord.brokerauth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerRegistrationResponseDto {

    @JsonProperty("mbs_returnsuccessful")
    private boolean success;
    @JsonProperty("mbs_message")
    private String message;
}
