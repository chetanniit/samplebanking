package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class AccessTokenNotRefreshedException extends RuntimeException {

    public AccessTokenNotRefreshedException(String message) {
        super(message);
    }
}
