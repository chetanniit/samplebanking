package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.event;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventRequestDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@ConditionalOnProperty(
    value = "clients.crmbroker.event.stub.enabled",
    havingValue = "true")
@Component
@Primary
@Slf4j
public class BrokerEventStubClient implements BrokerEventClient {

  @Override
  public BrokerEventResponseDto createBrokerEvent(BrokerEventRequestDto requestDto) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub broker event call. Only intended for test environments. Will always respond true")
        .build()
    );
    return BrokerEventResponseDto.builder().message("").success(true).build();
  }


}
