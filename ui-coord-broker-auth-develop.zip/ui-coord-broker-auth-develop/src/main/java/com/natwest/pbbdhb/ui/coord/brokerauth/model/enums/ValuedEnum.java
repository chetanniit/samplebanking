package com.natwest.pbbdhb.ui.coord.brokerauth.model.enums;

public interface ValuedEnum {
    String value();
}
