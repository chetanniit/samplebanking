package com.natwest.pbbdhb.ui.coord.brokerauth;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The main Spring Boot class for this application.
 */
@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(
        title = "UI Coord Broker Authentication Service",
        version = "v1",
        description = "UI Coord Broker Authentication API"
    )
)
public class BrokerAuthenticationApplication {

  public static void main(String[] args) {
      SpringApplication.run(BrokerAuthenticationApplication.class, args);
  }
}
