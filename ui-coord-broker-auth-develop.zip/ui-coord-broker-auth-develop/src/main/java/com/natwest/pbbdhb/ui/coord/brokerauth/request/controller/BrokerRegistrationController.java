package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import static org.springframework.http.HttpStatus.CONFLICT;
import static org.springframework.http.HttpStatus.OK;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.BrokerRegistrationService;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@Tag(name = "Broker Registration", description = "broker registration API")
@Slf4j
@Validated
@RequiredArgsConstructor
public class BrokerRegistrationController {

  private final BrokerRegistrationService brokerRegistrationService;

  @Operation(
      operationId = "registerBroker",
      summary = "Submit broker registration request",
      tags = "Broker Registration"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "202", description = "Successful submission of broker registration request"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "415", description = "Unsupported media type")
  })
  @PostMapping(ApplicationConstants.PATH_REGISTER_BROKER)
  public ResponseEntity<Void> registerBroker(
      @RequestBody @Valid BrokerRegistration brokerRegistration) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Request to register broker: %s",
                brokerRegistration))
        .build()
    );

    this.brokerRegistrationService.registerBroker(brokerRegistration);

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Request to register broker: %s",
                    brokerRegistration))
            .build()
    );

    return ResponseEntity.accepted().build();
  }

  @Operation(
      operationId = "registerAdmin",
      summary = "Submit admin registration request",
      tags = "Admin Registration"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "202", description = "Successful submission of admin registration request"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "415", description = "Unsupported media type")
  })
  @PostMapping(ApplicationConstants.PATH_REGISTER_ADMIN)
  public ResponseEntity<Void> registerAdmin(
      @RequestBody @Valid AdminRegistration adminRegistration) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Request to register admin: %s",
                adminRegistration))
        .build()
    );

    this.brokerRegistrationService.registerAdmin(adminRegistration);

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Request to register admin: %s", adminRegistration))
            .build()
    );

    return ResponseEntity.accepted().build();
  }

  @Operation(
      operationId = "isUsernameAvailable",
      summary = "Verifies availability of username",
      tags = "Broker Registration"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Username is available"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "409", description = "Username is not available - already exists")
  })
  @GetMapping(path = ApplicationConstants.PATH_USERNAME_VERIFICATION)
  public ResponseEntity<Void> isUsernameAvailable(
      @RequestParam @Parameter(name = ApplicationConstants.PARAM_USERNAME, description = "The username to verify", required = true)
      @Pattern(regexp = ApplicationConstants.USERNAME_REGEX, message = ApplicationConstants.USERNAME_INVALID_MSG) String username) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Request to verify availability of username=%s", username))
        .build()
    );

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Request to verify availability of username=%s", username))
            .build()
    );

    return ResponseEntity
        .status(this.brokerRegistrationService.isUsernameAvailable(username) ? OK : CONFLICT)
        .build();
  }

  @Operation(
      operationId = "firmDetails",
      summary = "Get firm details for given FCA number request",
      tags = "Broker Registration"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successfully retrieved firm details", content = @Content(mediaType = "application/json", schema = @Schema(implementation = FirmDetailsResponse.class))),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "404", description = "Firm details not found")
  })
  @GetMapping(path = ApplicationConstants.PATH_FIRM_DETAILS, produces = MediaType.APPLICATION_JSON_VALUE)
  public FirmDetailsResponse getFirmDetails(
      @Parameter(name = ApplicationConstants.BRAND_HEADER, description = ApplicationConstants.BRAND_DESCRIPTION)
      @RequestHeader(value = ApplicationConstants.BRAND_HEADER, required = false, defaultValue = ApplicationConstants.BRAND_DEFAULT)
      @Pattern(regexp = ApplicationConstants.BRAND_VALID_REGEX, message = ApplicationConstants.BRAND_INVALID_MSG) final String brand,
      @RequestParam @Parameter(name = ApplicationConstants.PARAM_FCA_NUMBER, description = "The firms FCA number", required = true)
      @Pattern(regexp = ApplicationConstants.FCA_NUMBER_REGEX, message = ApplicationConstants.FCA_NUMBER_INVALID_MSG) String fcanumber) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Request to get firm details for fcanumber=%s", fcanumber))
        .build()
    );

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("End of Request to get firm details for fcanumber=%s", fcanumber))
            .build()
    );

    return this.brokerRegistrationService.getFirmDetails(brand, fcanumber);
  }
}
