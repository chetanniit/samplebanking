package com.natwest.pbbdhb.ui.coord.brokerauth.client.email.domain;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;
import javax.annotation.CheckForNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class EmailClientRequest {

  @JsonProperty("notificationType")
  @CheckForNull
  String templateName;

  @JsonProperty("parameters")
  @CheckForNull
  Map<String, Object> parameters;
}
