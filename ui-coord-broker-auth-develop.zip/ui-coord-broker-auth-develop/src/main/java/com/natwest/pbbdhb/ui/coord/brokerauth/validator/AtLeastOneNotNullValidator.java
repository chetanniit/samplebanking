package com.natwest.pbbdhb.ui.coord.brokerauth.validator;

import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidateAtLeastOneNotNull;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

import static org.apache.tomcat.util.IntrospectionUtils.getProperty;

public class AtLeastOneNotNullValidator implements ConstraintValidator<ValidateAtLeastOneNotNull, Object> {

    private String[] fields;

    @Override
    public void initialize(ValidateAtLeastOneNotNull annotation) {
        this.fields = annotation.fields().split(",");
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        if (objectToValidate == null) {
            return true;
        }
        for (String field : this.fields) {
            if (getProperty(objectToValidate, field) != null) {
                return true;
            }
        }
        context.unwrap(HibernateConstraintValidatorContext.class).addExpressionVariable("errorMessageFields", String.join(", ", this.fields));
        return false;
    }
}
