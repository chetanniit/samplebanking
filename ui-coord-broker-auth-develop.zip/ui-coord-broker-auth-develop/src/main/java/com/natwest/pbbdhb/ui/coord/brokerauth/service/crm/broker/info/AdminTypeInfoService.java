package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.BrokerInfo;
import java.util.List;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class AdminTypeInfoService implements BrokerTypeInfo {

  private final BrokerInfo brokerClient;

  @Override
  public BrokerInfoBrokerDomainModel getBrokerInfo(String username) {

    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Admin Broker Information Retrieved Successfully for brokerUsername: %s",
                    username))
            .build()
    );
    return brokerClient.getAdminInfo(username);
  }
}