package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import javax.annotation.CheckForNull;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrokerPortalAccessTokenClientRequest {

  @JsonProperty("brokerRole")
  @NonNull
  UserRegistrationType brokerRole;

  @JsonProperty("userName")
  @CheckForNull
  String userName;

  @JsonProperty("fcaNumber")
  String fcaNumber;
}
