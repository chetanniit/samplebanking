package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to validate an Activation Code.
 */
@Builder
@Value
public class ActivationCodeValidateRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's activation code to be validated. As this is a required field, {@code @NonNull} has
   * been set.
   */
  @NonNull
  String code;
}