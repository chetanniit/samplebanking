package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

  public static final String INTERNAL_SERVER_ERROR_DESCRIPTION = "Our backend is non-functional, please try again later.";
  public static final String INTERNAL_SERVER_ERROR_TITLE = "Internal Server Error";
  public static final String LOGIN_URI = "/login";

  @Value("${server.servlet.context-path}")
  String contextPath;

  /**
   * Handles validation exceptions (e.g. field 'x' can not be null), populating errors property with
   * specific validation details.
   *
   * @param ex Exception containing validation failure details
   * @return An ErrorResponse describing the validation issues
   */
  @ExceptionHandler(RemoteRequestFailedException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ErrorResponse handleRemoteRequestFailedException(RemoteRequestFailedException ex) {
    log.error(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(ex.getClass().getSimpleName())
            .description("RemoteRequestFailedException was thrown")
            .build(),
        ex
    );
    return ErrorResponse.internalServerError(INTERNAL_SERVER_ERROR_TITLE,
        INTERNAL_SERVER_ERROR_DESCRIPTION);
  }

  /**
   * A handler for {@link CrmDataException}
   *
   * @param ex The CrmDataException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(CrmDataException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleCrmDataExceptionForLoginController(CrmDataException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.unauthorised();
  }

  /**
   * A handler for {@link ActivationCodeException}
   *
   * @param ex The ActivationCodeException that was thrown.
   * @return Description of Activation Code error that callers of the controller can understand.
   */
  @ExceptionHandler(ActivationCodeException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleActivationCodeException(ActivationCodeException ex) {
    String message = LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(ex.getClass().getSimpleName())
        .description(String.format(
            "ActivationCodeException was thrown for reason %s",
            ex.getMessage()))
        .build();
    switch (ex.getCode()) {
      case INVALID_CREDENTIALS:
        log.info(message, ex);
        return ErrorResponse.invalidCredentials();
      case OTP_EXPIRED:
        log.info(message, ex);
        return ErrorResponse.expiredOtp();
      case ACCOUNT_LOCKED:
        log.info(message, ex);
        return ErrorResponse.accountLocked();
      default:
        log.error(message, ex);
        return ErrorResponse.otpValidationFailed();
    }

  }

  /**
   * A handler for {@link LoginFailedException}
   *
   * @param ex The LoginFailedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(LoginFailedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleLoginFailedException(LoginFailedException ex) {
    log.info("LoginFailedException was thrown for reason {}", ex.getMessage(), ex);
    return ErrorResponse.invalidCredentials();
  }


  /**
   * A handler for {@link UnauthorisedException}
   *
   * @param ex The UnauthorisedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(UnauthorisedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleUnauthorisedException(UnauthorisedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.unauthorised();
  }

  /**
   * A handler for {@link UserAlreadyExistsException}
   *
   * @param ex The UserAlreadyExistsException that was thrown.
   * @return Description of conflict error that callers of the controller can understand.
   */
  @ExceptionHandler(UserAlreadyExistsException.class)
  @ResponseStatus(HttpStatus.CONFLICT)
  public ErrorResponse handleUserAlreadyExistsException(UserAlreadyExistsException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.userAlreadyExists();
  }

  /**
   * A handler for {@link InvalidDetailsException}
   *
   * @param ex The InvalidDetailsException that was thrown.
   * @return Description of conflict error that callers of the controller can understand.
   */
  @ExceptionHandler(InvalidDetailsException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleInvalidDetailsException(InvalidDetailsException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.invalidDetails();
  }

  /**
   * A handler for {@link AccountLockedException}
   *
   * @param ex The AccountLockedException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(AccountLockedException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleAccountLockedException(AccountLockedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.accountLocked();
  }

  /**
   * A handler for {@link PasswordExpiredException}
   *
   * @param ex The PasswordExpiredException that was thrown.
   * @return Description of unauthorised error that callers of the controller can understand.
   */
  @ExceptionHandler(PasswordExpiredException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handlePasswordExpiredException(PasswordExpiredException ex) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .exception(ex)
            .build()
    );
    return ErrorResponse.passwordExpired();
  }

  /**
   * A handler for {@link QuestionsNotRetrievedException}
   *
   * @param ex The QuestionsNotRetrievedException that was throw.
   * @return Description of bad request error that the callers of the controller can understand.
   */
  @ExceptionHandler(QuestionsNotRetrievedException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleQuestionsNotRetrievedException(QuestionsNotRetrievedException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .exception(ex)
        .build()
    );
    return ErrorResponse.questionsNotRetrieved();
  }

  /**
   * A handler for {@link MemorableQuestionAnswersValidationException}
   *
   * @param ex The MemorableQuestionAnswersValidationException that was thrown.
   * @return Description of unauthorised error that the callers of the controller can understand.
   */
  @ExceptionHandler(MemorableQuestionAnswersValidationException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleMemorableQuestionAnswersValidationException(
      MemorableQuestionAnswersValidationException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(ex.getClass().getSimpleName())
        .description(String.format(
            "MemorableQuestionAnswersValidationException was thrown for reason %s",
            ex.getMessage()))
        .build()
    );
    switch (ex.getCode()) {
      case INCORRECT_MEMORABLE_QUESTION_ANSWERS:
        return ErrorResponse.incorrectMemorableQuestionAnswers();
      case MEMORABLE_QUESTIONS_LOCKED:
        return ErrorResponse.memorableQuestionsLocked();
      case ACCOUNT_LOCKED:
        return ErrorResponse.accountLocked();
      default:
        return ErrorResponse.internalServerError(INTERNAL_SERVER_ERROR_TITLE,
            INTERNAL_SERVER_ERROR_DESCRIPTION);
    }
  }

  /**
   * A handler for {@link UserNotFoundException}
   *
   * @param ex The UserNotFoundException that was thrown.
   * @return Description of bad request error that the callers of the controller can understand.
   */
  @ExceptionHandler(UserNotFoundException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ErrorResponse handleUserNotFoundException(UserNotFoundException ex) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(ex.getClass().getSimpleName())
        .description(String.format(
            "UserNotFoundException was thrown for reason %s",
            ex.getMessage()))
        .build()
    );
    return ErrorResponse.userNotFound();
  }

  /**
   * A handler for {@link ResetPasswordException}
   *
   * @param ex The ResetPasswordException that was thrown.
   * @return Description of Reset Password error that callers of the controller can understand.
   */
  @ExceptionHandler(ResetPasswordException.class)
  public ResponseEntity<ErrorResponse> handleResetPasswordException(ResetPasswordException ex) {
    final String message = LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(ex.getClass().getSimpleName())
        .description(String.format(
            "ResetPasswordException was thrown for reason: %s",
            ex.getMessage()))
        .build();
    log.info(message, ex);
    switch (ex.getCode()) {
      case USER_NOT_FOUND:
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.userNotFound());
      case INVALID_DETAILS:
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.invalidDetails());
      case ACCOUNT_LOCKED:
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.accountLocked());
      case INVALID_CREDENTIALS:
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.invalidCredentials());
      case OTP_EXPIRED:
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.expiredOtp());
      case OTP_VALIDATION_FAILED:
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.otpValidationFailed());
      default:
        log.error(message, ex);
        return ResponseEntity.status(ex.getHttpStatus()).body(ErrorResponse.otpValidationFailed());
    }
  }

  /**
   * A handler for {@link ValidateOtpException}
   *
   * @param ex The ValidateOtpException that was thrown.
   * @return Description of Validate OTP error that callers of the controller can understand.
   */
  @ExceptionHandler(ValidateOtpException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleValidateOtpException(ValidateOtpException ex) {
    String message = LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(ex.getClass().getSimpleName())
        .description(String.format(
            "ValidateOtpException was thrown for reason: %s",
            ex.getMessage()))
        .build();
    log.info(message, ex);
    switch (ex.getCode()) {
      case ACCOUNT_LOCKED:
        return ErrorResponse.accountLocked();
      case INVALID_CREDENTIALS:
        return ErrorResponse.invalidCredentials();
      case OTP_EXPIRED:
        return ErrorResponse.expiredOtp();
      default:
        log.error(message, ex);
        return ErrorResponse.otpValidationFailed();
    }

  }

  /**
   * A handler for {@link BrokerDetailsException}
   *
   * @param ex The BrokerDetailsException that was thrown.
   * @return Description of Broker Details error that callers of the controller can understand.
   */
  @ExceptionHandler(BrokerDetailsException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ErrorResponse handleBrokerDetailsException(BrokerDetailsException ex) {
    String message = LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(ex.getClass().getSimpleName())
        .description(String.format(
            "BrokerDetailsException was thrown for reason: %s",
            ex.getMessage()))
        .build();

    log.error(message, ex);
    return ErrorResponse.invalidDetails();
  }
}
