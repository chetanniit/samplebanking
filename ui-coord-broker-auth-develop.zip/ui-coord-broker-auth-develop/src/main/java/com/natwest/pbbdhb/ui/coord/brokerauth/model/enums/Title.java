package com.natwest.pbbdhb.ui.coord.brokerauth.model.enums;

/*
Based on com.rbs.pbbdhb.application.applicant.service.model.enums.Title in ui-coord-adviced-sales
*/

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Title {
//    NONE(""),
    MR("Mr"),
    MRS("Mrs"),
    MISS("Miss"),
    MS("Ms"),
    DR("Dr"),
    REVEREND("Reverend"),
    PROFESSOR("Professor"),
    SIR("Sir"),
    LORD("Lord"),
    LADY("Lady"),
    CAPTAIN("Captain"),
    MAJOR("Major"),
    COLONEL("Colonel"),
    GENERAL("General"),
    MASTER("Master"),
    HON("Hon"),
    MX("Mx"),
    SISTER("Sister"),
    VISCOUNT("Viscount"),
    COUNTESS("Countess"),
    EARL("Earl"),
    OTHER("Other");

    private final String text;
}
