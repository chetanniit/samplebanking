package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
@Jacksonized
public class RetrieveChallengeQuestionsRequest {

  @JsonProperty("username")
  @Schema(description = "Specifies user's username", required = true)
  @NonNull
  String username;
}
