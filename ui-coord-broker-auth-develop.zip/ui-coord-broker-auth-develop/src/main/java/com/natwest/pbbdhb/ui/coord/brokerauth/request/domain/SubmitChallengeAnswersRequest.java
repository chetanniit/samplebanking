package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.SecurityQuestion;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import jakarta.validation.Valid;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class SubmitChallengeAnswersRequest {

  @JsonProperty("username")
  @Schema(description = "Specifies user's username", required = true)
  @NonNull
  String username;

  @JsonProperty("securityQuestions")
  @Schema(description = "Specifies user's security questions and answers", required = true)
  @NonNull
  List<@Valid SecurityQuestion> securityQuestions;
}
