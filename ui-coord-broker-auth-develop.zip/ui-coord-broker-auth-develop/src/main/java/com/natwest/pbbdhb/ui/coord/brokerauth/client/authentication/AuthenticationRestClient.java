package com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain.BrokerPortalAccessTokenClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.domain.BrokerPortalAccessTokenClientResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.authentication.mapper.AuthenticationClientMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.AuthenticationRestClientConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import java.net.URI;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


@Service
@Slf4j
public class AuthenticationRestClient implements AuthenticationClient {

  private final RestTemplate restTemplate;
  private final AuthenticationRestClientConfig clientConfig;

  @Autowired
  public AuthenticationRestClient(
      @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
      AuthenticationRestClientConfig clientConfig) {
    this.restTemplate = restTemplate;
    this.clientConfig = clientConfig;
  }

  @Override
  public BrokerPortalAccessTokenResponseModel retrieve(
      BrokerPortalAccessTokenRequestModel requestModel) {
    return AuthenticationClientMapper.toBrokerPortalAccessTokenResponseModel(makeClientRequest(
            AuthenticationClientMapper.toBrokerPortalAccessTokenClientRequest(requestModel)
    ));
  }

  @Override
  public void revoke() {
    try {
      log.info(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description("Making remote request to revoke access-token.")
          .build()
      );
      restTemplate.delete(getUri());
      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description("End of remote request to revoke access-token.")
              .build()
      );
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description("Access Token revoke request failed")
          .build(),
          ex
      );

      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    }
  }

  private BrokerPortalAccessTokenClientResponse makeClientRequest(
      BrokerPortalAccessTokenClientRequest clientRequest) {
    try {
      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description("Making remote request to retrieve Access Token.")
              .build()
      );
      ResponseEntity<BrokerPortalAccessTokenClientResponse> responseEntity = restTemplate
          .postForEntity(
              getUri(),
              new HttpEntity<>(clientRequest),
              BrokerPortalAccessTokenClientResponse.class
          );

      return Optional
          .ofNullable(responseEntity.getBody())
          .orElseThrow(() -> {
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INPUT_VALIDATION)
                .description(String.format(
                    "Retrieving Access Token for request : %s returned an empty " +
                            "payload", clientRequest))
                .build()
            );

            return new RemoteRequestFailedException(
                "Access Token response returned an empty payload");
          });
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(String.format("Access Token request failed: %s",
              clientRequest))
          .build(),
          ex
      );

      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    }
  }

  private URI getUri() {
    return UriComponentsBuilder
        .fromHttpUrl(clientConfig.getUrl())
        .pathSegment("broker-portal", "token")
        .build()
        .toUri();
  }
}
