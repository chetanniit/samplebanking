package com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.controller.ValidationErrorResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.controller.Violation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Validated
@Value
@Builder
@JsonInclude(Include.NON_NULL)
public class ErrorResponse {

  @JsonProperty("status")
  @Schema(
      description = "HTTP status code of error",
      example = "500"
  )
  int status;

  @JsonProperty("title")
  @Schema(
      description = "Title of error",
      example = "Internal Server Error"
  )
  String title;

  @JsonProperty("code")
  @Schema(
      description = "Enumerated error code",
      example = "INTERNAL_SERVER_ERROR",
      required = true
  )
  @NotNull
  ErrorCode code;

  @JsonProperty("description")
  @Schema(
      description = "Description of error",
      example = "Sorry, something went wrong."
  )
  String description;

  @JsonProperty("errors")
  @Schema(
      description = "List of errors encountered as part of request, typically validation failure errors"
  )
  List<ErrorResponseDetail> errors;

  public static ErrorResponse internalServerError(String title, String description) {
    return ErrorResponse
        .builder()
        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
        .title(title)
        .code(ErrorCode.INTERNAL_SERVER_ERROR)
        .description(description)
        .build();
  }

  public static ErrorResponse invalidCredentials() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Invalid Credentials")
        .code(ErrorCode.INVALID_CREDENTIALS)
        .description("The credentials entered are invalid")
        .build();
  }

  public static ErrorResponse unauthorised() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Unauthorised")
        .code(ErrorCode.UNAUTHORISED)
        .description("You do not have access to this resource")
        .build();
  }

  public static ErrorResponse userAlreadyExists() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.CONFLICT.value())
        .title("User already exists")
        .code(ErrorCode.USER_ALREADY_EXISTS)
        .description("The username for the user already exists")
        .build();
  }

  public static ErrorResponse invalidDetails() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("Invalid Details")
        .code(ErrorCode.INVALID_DETAILS)
        .description("The input details are invalid")
        .build();
  }

  public static ErrorResponse invalidDetails(ValidationErrorResponse errors) {
    return ErrorResponse
            .builder()
            .status(HttpStatus.BAD_REQUEST.value())
            .title("Invalid Details")
            .code(ErrorCode.INVALID_DETAILS)
            .errors(errors != null && errors.getViolations() != null ?
                errors.getViolations().stream().map(v ->
                        ErrorResponseDetail.builder()
                                .title(v.getFieldName())
                                .description(v.getMessage())
                                .build())
                        .collect(Collectors.toList()) :
                new ArrayList<>())
            .build();
  }

  public static ErrorResponse accountLocked() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Account Locked")
        .code(ErrorCode.ACCOUNT_LOCKED)
        .description("Account is locked, please try again later.")
        .build();
  }

  public static ErrorResponse passwordExpired() {
    return ErrorResponse
            .builder()
            .status(HttpStatus.UNAUTHORIZED.value())
            .title("Password Expired")
            .code(ErrorCode.PASSWORD_EXPIRED)
            .description("Password is expired, please reset your password.")
            .build();
  }

  public static ErrorResponse expiredOtp() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Expired OTP")
        .code(ErrorCode.OTP_EXPIRED)
        .description("The OTP code has expired")
        .build();
  }

  public static ErrorResponse otpValidationFailed() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Something went wrong whilst validating otp")
        .code(ErrorCode.OTP_VALIDATION_FAILED)
        .description("Please try again later")
        .build();
  }

  public static ErrorResponse questionsNotRetrieved() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("Memorable questions not retrieved")
        .code(ErrorCode.QUESTIONS_NOT_RETRIEVED)
        .description("Failed to retrieve memorable questions")
        .build();
  }

  public static ErrorResponse incorrectMemorableQuestionAnswers() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Incorrect answers")
        .code(ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS)
        .description("Incorrect answers to memorable questions")
        .build();
  }

  public static ErrorResponse memorableQuestionsLocked() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.UNAUTHORIZED.value())
        .title("Questions locked")
        .code(ErrorCode.MEMORABLE_QUESTIONS_LOCKED)
        .description("Memorable questions are locked")
        .build();
  }

  public static ErrorResponse userNotFound() {
    return ErrorResponse
        .builder()
        .status(HttpStatus.BAD_REQUEST.value())
        .title("User not found")
        .code(ErrorCode.USER_NOT_FOUND)
        .description("User IAM entry not found")
        .build();
  }
}
