package com.natwest.pbbdhb.ui.coord.brokerauth.service.email;

import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.EmailClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.EmailTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EmailService {

  private final EmailClient client;

  public EmailService(
      EmailClient client) {
    this.client = client;
  }

  public <T extends EmailTemplate> void send(T emailRequestModel) {
    client.send(emailRequestModel);
  }
}
