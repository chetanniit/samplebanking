package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

/**
 * A business domain model describing all the data needed to reset password for account.
 */
@Builder
@Value
public class ResetPasswordRequestModel {

  /**
   * The user's username. As this is a required field, {@code @NonNull} has been set.
   */
  @NonNull
  String username;

  /**
   * The user's otp code to be validated. As this is a required field, {@code @NonNull} has
   * been set.
   */
  @NonNull
  String otpCode;

  /**
   * The user's new password to be set. As this is a required field, {@code @NonNull} has
   * been set.
   */
  @NonNull
  String password;
}