package com.natwest.pbbdhb.ui.coord.brokerauth.util;

public class LogMessageType {

  public static String INCOMING = "Incoming";
  public static String OUTGOING = "Outgoing";
  public static String JWT = "JWT";
  public static String CONFIG = "Config";
}

