package com.natwest.pbbdhb.ui.coord.brokerauth.service.login;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LoginService {

  private final BrokerAuthClient brokerAuthClient;

  @Autowired
  public LoginService(BrokerAuthClient brokerAuthClient) {
    this.brokerAuthClient = brokerAuthClient;
  }

  public UserRegistrationType login(LoginRequestModel attempt) {
    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Login attempt for user: %s",  attempt.getUsername()))
            .build()
    );
    return brokerAuthClient.login(attempt);
  }
}
