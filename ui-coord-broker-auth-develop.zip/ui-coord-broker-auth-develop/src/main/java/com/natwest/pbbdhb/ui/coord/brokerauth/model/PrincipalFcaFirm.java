package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import lombok.Data;

import jakarta.validation.constraints.NotNull;

@Data
public class PrincipalFcaFirm {
    @NotNull
    private String name;

    @NotNull
    private String fcaNumber;
}
