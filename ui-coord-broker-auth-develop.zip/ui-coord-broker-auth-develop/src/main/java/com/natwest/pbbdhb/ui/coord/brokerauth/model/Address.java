package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;

@Data
public class Address {

    @NotBlank
    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    @NotBlank
    private String town;

    private String county;

    @NotBlank
    private String postcode;

}
