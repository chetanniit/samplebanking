package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
@Jacksonized
public class DeleteUserRequest {
  @JsonProperty("username")
  @Schema(
      description = "Specifies the username of the user",
      example = "asmith",
      required = true
  )
  @NotNull
  String username;
}