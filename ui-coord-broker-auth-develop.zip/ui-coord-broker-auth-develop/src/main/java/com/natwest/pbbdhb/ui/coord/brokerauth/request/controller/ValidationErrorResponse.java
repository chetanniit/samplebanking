package com.natwest.pbbdhb.ui.coord.brokerauth.request.controller;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ValidationErrorResponse {

  private Set<Violation> violations;

}
