package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class SecurityQuestionClientRequest {

  String question;
  String answer;

}
