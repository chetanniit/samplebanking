package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;


import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.CreateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.DeleteUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
@Slf4j
@Component
public class RegistrationRequestMapper {

  public static CreateUserRequestModel toDomainModel(CreateUserRequest userRequest) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping CreateUserRequest to CreateUserRequestModel")
            .build()
    );

    return CreateUserRequestModel.builder()
        .firstname(userRequest.getFirstName())
        .lastname(userRequest.getLastName())
        .username(userRequest.getUsername())
        .email(userRequest.getEmail())
        .brokerType(userRequest.getUserType())
        .build();
  }

  public static DeleteUserRequestModel toDomainModel(DeleteUserRequest userRequest) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping DeleteUserRequest to DeleteUserRequestModel")
            .build()
    );

    return DeleteUserRequestModel.builder()
            .username(userRequest.getUsername())
            .build();
  }
}
