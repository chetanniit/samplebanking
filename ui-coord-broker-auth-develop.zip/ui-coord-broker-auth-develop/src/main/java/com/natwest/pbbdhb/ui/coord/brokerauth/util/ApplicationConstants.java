package com.natwest.pbbdhb.ui.coord.brokerauth.util;

/**
 * The application constants.
 */
public final class ApplicationConstants {

  public static final String BRAND_HEADER = "brand";

  public static final String PATH_REGISTER_BROKER = "/registerBroker";

  public static final String PATH_REGISTER_ADMIN = "/registerAdmin";

  public static final String PATH_USERNAME_VERIFICATION = "/isUsernameAvailable";
  public static final String PARAM_USERNAME = "username";

  public static final String BRAND_DEFAULT = "nwb";
  public static final String BRAND_DESCRIPTION = "The brand name";
  public static final String BRAND_INVALID_MSG = "The brand name is invalid";
  public static final String BRAND_VALID_REGEX = "(RBS|NWB|rbs|nwb)";

  public static final String PRIVACY_POLICY_NOT_ACCEPTED_MSG = "Privacy Policy must be accepted";
  public static final String TERMS_OF_BUSINESS_NOT_ACCEPTED_MSG = "Terms of Business must be accepted";
  public static final String BUSINESS_DECLARATION_NOT_CONFIRMED_MSG = "Business Declaration must be confirmed";

  public static final String PRINCIPAL_FCA_NUMBER_NOT_PROVIDED_MSG = "'principalFcaNumber' needs to be provided only for broker of type 'Appointed representative'";
  public static final String PREVIOUS_FIRM_NAME_AND_PREVIOUS_FCA_NUMBER_NOT_PROVIDED_MSG = "Both or none of 'previousFirmName' and 'previousFcaNumber' need to provided";

  public static final String USERNAME_REGEX = "^[a-zA-Z0-9][a-zA-Z0-9._-]{5,19}$";
  public static final String USERNAME_INVALID_MSG = "Must be between 6 and 20 characters and contain no special characters other than \".-_\"";
  public static final String USERNAME_NO_SPECIAL_CHARACTERS_REGEX = "^[a-zA-Z0-9._-]+$";
  public static final String USERNAME_NO_SPECIAL_CHARACTERS_MSG = "Username must contain no special characters other than '. - _'";
  public static final String USERNAME_STARTS_WITH_LETTER_OR_NUMBER = "^[a-zA-Z0-9].*$";
  public static final String USERNAME_STARTS_WITH_LETTER_OR_NUMBER_MSG = "Username must start with a letter or a number";
  public static final String USERNAME_MUST_BE_AT_LEAST_6_CHARACTERS_MSG = "Username must be at least 6 characters";
  public static final String USERNAME_IN_USE_MSG = "This username is already in use, please choose another";

  public static final String PATH_FIRM_DETAILS = "/firmDetails";
  public static final String PARAM_FCA_NUMBER = "fcanumber";
  public static final String FCA_NUMBER_REGEX = "^[\\d]{6,7}$";
  public static final String FCA_NUMBER_INVALID_MSG = "Must be 6 or 7 numeric characters";


  private ApplicationConstants() {
  }
}
