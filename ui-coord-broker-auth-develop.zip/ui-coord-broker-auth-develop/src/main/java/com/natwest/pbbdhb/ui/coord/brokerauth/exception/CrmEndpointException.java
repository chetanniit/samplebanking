package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class CrmEndpointException extends RuntimeException {
    public CrmEndpointException(String message) { super(message); }
}
