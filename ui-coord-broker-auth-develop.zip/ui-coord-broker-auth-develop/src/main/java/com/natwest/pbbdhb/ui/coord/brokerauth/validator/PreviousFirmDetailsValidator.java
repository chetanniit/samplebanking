package com.natwest.pbbdhb.ui.coord.brokerauth.validator;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidatePreviousFirmDetails;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;


public class PreviousFirmDetailsValidator implements ConstraintValidator<ValidatePreviousFirmDetails, FirmDetails> {

    @Override
    public boolean isValid(FirmDetails value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        return (value.getPreviousFirmName() == null && value.getPreviousFcaNumber() == null)
                || (value.getPreviousFirmName() != null && value.getPreviousFcaNumber() != null);
    }
}
