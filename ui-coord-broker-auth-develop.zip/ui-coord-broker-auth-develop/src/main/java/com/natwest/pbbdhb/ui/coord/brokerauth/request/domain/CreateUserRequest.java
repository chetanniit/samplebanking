package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
@Jacksonized
public class CreateUserRequest {

  @JsonProperty("firstName")
  @Schema(
      description = "Specifies the first name of the user",
      example = "Alice",
      required = true
  )
  @NonNull
  String firstName;

  @JsonProperty("lastName")
  @Schema(
      description = "Specifies the last name of the user",
      example = "Smith",
      required = true
  )
  @NonNull
  String lastName;

  @JsonProperty("email")
  @Schema(
      description = "Specifies the email address of the user",
      example = "asmith@aol.com",
      required = true
  )
  @NonNull
  String email;

  @JsonProperty("username")
  @Schema(
      description = "Specifies the username of the user",
      example = "asmith",
      required = true
  )
  @NonNull
  String username;

  @JsonProperty("userType")
  @Schema(
      description = "Specifies the type of user",
      example = "BROKER",
      required = true
  )
  @NonNull
  UserRegistrationType userType;
}
