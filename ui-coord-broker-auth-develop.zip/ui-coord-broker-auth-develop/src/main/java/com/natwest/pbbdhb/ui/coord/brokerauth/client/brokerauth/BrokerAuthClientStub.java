package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetails;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import java.util.List;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

/**
 * This is a stubbed implementation of a BrokerAuth Client.
 * <p>
 * This returns static responses and should only be used in test environments. Intended for use when
 * downstream services are not required or not available.
 */
@ConditionalOnProperty(
    value = "clients.brokerauth.stub.enabled",
    havingValue = "true")
@Service
@Primary
@Slf4j
public class BrokerAuthClientStub implements BrokerAuthClient {

  public BrokerAuthClientStub() {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub Account Status client in-use. Only intended for test environments")
        .build()
    );
  }

  @Override
  public UserRegistrationType login(LoginRequestModel attempt) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub login call. Only intended for test environments.")
        .build()
    );

    return UserRegistrationType.BROKER;
  }

  @Override
  public void activate(ActivateUserRequestModel requestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub activate call. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public String generateActivationCode(
      String username) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub generate activation code call. Only intended for test environments.")
        .build()
    );
    return UUID.randomUUID().toString();
  }

  @Override
  public void validateActivationCode(ActivationCodeValidateRequestModel requestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub validate activation code call. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public void createUser(CreateUserRequestModel createUserRequestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub create user call. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public void deleteUser(DeleteUserRequestModel deleteUserRequestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub delete user call. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public String reactivateUser(String username) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub reactivate user call. Only intended for test environments.")
        .build()
    );
    return UUID.randomUUID().toString();
  }

  @Override
  public List<String> retrieveSecurityQuestions(String username) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub retrieve security questions call. Only intended for test environments.")
        .build()
    );
    return Lists.newArrayList(
        "Question 1?",
        "Question 2?",
        "Question 3?",
        "Question 4?",
        "Question 5?"
    );
  }

  @Override
  public ValidateSecurityAnswersResponseModel validateSecurityAnswers(
      ValidateSecurityAnswersRequestModel answersModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub validate security answers call. Only intended for test environments.")
        .build()
    );
    return ValidateSecurityAnswersResponseModel.builder().otp(UUID.randomUUID().toString())
        .userType(UserRegistrationType.BROKER).build();
  }

  public void resetPassword(ResetPasswordRequestModel resetPasswordRequestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub reset password call. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public void validateOtp(ValidateOtpRequestModel validateOtpRequestModel) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub validate OTP call. Only intended for test environments.")
        .build()
    );
  }

  @Override
  public BrokerDetailsResponse getBrokerDetails(String username) {
    log.warn(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .description("Stub get Broker details call. Only intended for test environments.")
        .build()
    );
    return BrokerDetailsResponse.builder().brokerDetails(
        BrokerDetails.builder()
        .firstName("TESTNAME")
        .lastName("TESTLASTNAME")
        .email("test@test.eu")
        .username("TestUsername")
        .build())
      .build();
  }

  @Override
  public void getUsernameReminder(UsernameReminderRequest usernameReminderRequest) {
    log.warn(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .description("Stub get username reminder call. Only intended for test environments.")
            .build()
    );
  }
}
