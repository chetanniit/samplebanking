package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import lombok.Data;

@Data
public class BrokerRegistrationValidationException extends RuntimeException {

    private final String field;
    private final String message;
}
