package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class InvalidDetailsException extends RuntimeException {

  public InvalidDetailsException(String message) {
    super(message);
  }

  public InvalidDetailsException(String message, Throwable cause) {
    super(message, cause);
  }
}
