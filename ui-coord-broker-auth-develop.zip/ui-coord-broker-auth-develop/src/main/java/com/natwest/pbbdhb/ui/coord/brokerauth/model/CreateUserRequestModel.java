package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class CreateUserRequestModel {

  @NonNull
  String firstname;

  @NonNull
  String lastname;

  @NonNull
  String email;

  @NonNull
  String username;

  @NonNull
  UserRegistrationType brokerType;
}
