package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;

public class MemorableQuestionAnswersValidationException extends RuntimeException {

  private final ErrorCode code;

  public MemorableQuestionAnswersValidationException(ErrorCode code, String message, Throwable cause) {
    super(message, cause);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }
}
