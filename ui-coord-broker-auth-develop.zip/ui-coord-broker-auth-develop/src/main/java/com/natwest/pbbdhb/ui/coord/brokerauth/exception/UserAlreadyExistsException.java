package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

import lombok.Getter;

/**
 * An exception to be thrown when there is an attempt to create a user but that username already
 * exists.
 */
@Getter
public class UserAlreadyExistsException extends RuntimeException {

  private final String username;

  public UserAlreadyExistsException(String username) {
    super(String.format("Username already exists: '%s'", username));
    this.username = username;
  }

  public UserAlreadyExistsException(String username, Throwable cause) {
    super(String.format("Username already exists: '%s'", username), cause);
    this.username = username;
  }
}
