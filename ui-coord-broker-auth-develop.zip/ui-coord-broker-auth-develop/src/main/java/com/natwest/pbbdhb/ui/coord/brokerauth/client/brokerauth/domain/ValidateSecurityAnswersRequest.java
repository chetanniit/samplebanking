package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ValidateSecurityAnswersRequest {

  @JsonProperty("username")
  @NotNull String username;

  @JsonProperty("securityQuestions")
  @NotNull List<SecurityQuestionClientRequest> securityQuestions;
}
