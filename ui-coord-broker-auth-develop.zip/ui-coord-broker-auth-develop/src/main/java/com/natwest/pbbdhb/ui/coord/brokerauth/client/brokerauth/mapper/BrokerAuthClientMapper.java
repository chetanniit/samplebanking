package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.mapper;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivateUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivationCodeGenerateClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivationCodeValidateClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.CreateUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.DeleteUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.LoginClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ResetPasswordClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.SecurityQuestionClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ValidateOtpClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ValidateSecurityAnswersRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ValidateSecurityAnswersResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.SecurityQuestion;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;
@Slf4j
public class BrokerAuthClientMapper {

  private BrokerAuthClientMapper() {
    // Added to resolve sonarlint issue
  }

  public static LoginClientRequest toClientModel(LoginRequestModel attempt) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping LoginRequestModel to LoginClientRequest")
            .build()
    );
    return LoginClientRequest.builder()
        .username(attempt.getUsername())
        .password(attempt.getPassword())
        .build();
  }

  public static ActivateUserClientRequest toClientModel(
      ActivateUserRequestModel activateUserRequestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ActivateUserRequestModel to ActivateUserClientRequest")
            .build()
    );
    return ActivateUserClientRequest.builder()
        .otpCode(activateUserRequestModel.getOtpCode())
        .username(activateUserRequestModel.getUsername())
        .password(activateUserRequestModel.getPassword())
        .securityQuestions(mapSecurityQuestions(activateUserRequestModel.getSecurityQuestions()))
        .build();
  }

  public static ActivationCodeGenerateClientRequest toActivationCodeGenerationClientModel(
      String username) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping username to ActivationCodeGenerateClientRequest")
            .build()
    );
    return ActivationCodeGenerateClientRequest.builder()
        .username(username)
        .build();
  }

  public static ValidateSecurityAnswersRequest toClientModel(
      ValidateSecurityAnswersRequestModel requestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ValidateSecurityAnswersRequestModel to ValidateSecurityAnswersRequest")
            .build()
    );
    return ValidateSecurityAnswersRequest.builder().username(requestModel.getUsername())
        .securityQuestions(mapSecurityQuestions(requestModel.getSecurityQuestions())).build();
  }

  public static ValidateSecurityAnswersResponseModel toResponseModel(
      ValidateSecurityAnswersResponse response) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ValidateSecurityAnswersResponse to ValidateSecurityAnswersResponseModel")
            .build()
    );
    return ValidateSecurityAnswersResponseModel.builder().otp(response.getOtpCode())
        .userType(response.getBrokerType()).build();
  }

  public static List<SecurityQuestionClientRequest> mapSecurityQuestions(
      List<SecurityQuestion> securityQuestions) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping Security Questions.")
            .build()
    );
    return securityQuestions.stream()
        .map(securityQuestion -> SecurityQuestionClientRequest.builder()
            .question(securityQuestion.getQuestion())
            .answer(securityQuestion.getAnswer())
            .build()).collect(Collectors.toList());
  }

  public static ActivationCodeValidateClientRequest toClientModel(
      ActivationCodeValidateRequestModel activationCodeValidateRequestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ActivationCodeValidateRequestModel to ActivationCodeValidateClientRequest")
            .build()
    );
    return ActivationCodeValidateClientRequest.builder()
        .username(activationCodeValidateRequestModel.getUsername())
        .code(activationCodeValidateRequestModel.getCode())
        .build();
  }

  public static CreateUserClientRequest toClientModel(CreateUserRequestModel requestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping CreateUserRequestModel to CreateUserClientRequest")
            .build()
    );
    return CreateUserClientRequest.builder()
        .email(requestModel.getEmail())
        .firstname(requestModel.getFirstname())
        .lastname(requestModel.getLastname())
        .username(requestModel.getUsername())
        .brokerType(requestModel.getBrokerType())
        .build();
  }

  public static DeleteUserClientRequest toClientModel(DeleteUserRequestModel requestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping DeleteUserRequestModel to DeleteUserClientRequest")
            .build()
    );
    return DeleteUserClientRequest.builder()
        .username(requestModel.getUsername())
        .build();
  }

  public static ResetPasswordClientRequest toClientModel(ResetPasswordRequestModel requestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ResetPasswordRequestModel to ResetPasswordClientRequest")
            .build()
    );
    return ResetPasswordClientRequest.builder()
        .username(requestModel.getUsername())
        .otpCode(requestModel.getOtpCode())
        .password(requestModel.getPassword())
        .build();
  }

  public static ValidateOtpClientRequest toClientModel(ValidateOtpRequestModel requestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ValidateOtpRequestModel to ValidateOtpClientRequest")
            .build()
    );
    return ValidateOtpClientRequest.builder()
        .username(requestModel.getUsername())
        .otpCode(requestModel.getOtpCode())
        .build();
  }
}
