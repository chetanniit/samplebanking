package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info.responses;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmDataException;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Data
@Validated
public class CrmMessage {

  @NotNull
  CrmResponseTarget successMessage;

  @NotNull
  CrmResponseTarget failMessage;

  public boolean check(JSONObject json) {
    if (!(successMessage.exists(json) || failMessage.exists(json))) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(String.format("No response fields found. Expected one of [success: \"%s\", failure: \"%s\"]",
                      successMessage.getTarget(), failMessage.getTarget()))
              .build()
      );
      throw new CrmDataException(String.format(
          "No response fields found.  Expected one of [success: \"%s\", failure: \"%s\"]",
          successMessage.getTarget(),
          failMessage.getTarget()));
    }

    return successMessage.check(json) || failMessageCheck(json);
  }

  private boolean failMessageCheck(JSONObject json) {
    if (!failMessage.check(json)) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(String.format("No response fields found. Expected one of [success: \"%s\", failure: \"%s\"]",
                      successMessage.getTarget(), failMessage.getTarget()))
              .build()
      );
      throw new CrmDataException(String.format(
          "CRM returned an unexpected result.  Expected one of [success: \"%s\", failure: \"%s\"]",
          successMessage.getMessage(),
          failMessage.getMessage()));
    }

    return false;
  }
}