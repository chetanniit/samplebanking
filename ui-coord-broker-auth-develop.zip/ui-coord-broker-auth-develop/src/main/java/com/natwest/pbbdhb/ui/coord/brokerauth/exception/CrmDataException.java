package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class CrmDataException extends RuntimeException {
    public CrmDataException(String message) { super(message); }
}
