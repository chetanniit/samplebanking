package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameAvailableResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.AdminRegistrationDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.AdminRegistrationResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.FirmDetailsResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

@Slf4j
@Component
public class BrokerRegistrationConnectionHelper {

    private final OkHttpClient httpClient;
    private final SecurityTokenHelper securityTokenHelper;
    private final String registerBrokerEndpoint;
    private final String usernameEndpoint;
    private final String firmDetailsEndpoint;
    private final String registerBrokerAdminEndpoint;

    private final ObjectMapper objectMapper;

    public BrokerRegistrationConnectionHelper(@Qualifier("proxyHttpClient") OkHttpClient httpClient,
                                              SecurityTokenHelper securityTokenHelper,
                                              ObjectMapper objectMapper,
                                              @Value("${broker-registration.registerBrokerEndpoint}") String registerBrokerEndpoint,
                                              @Value("${broker-registration.usernameEndpoint}") String usernameEndpoint,
                                              @Value("${broker-registration.firmDetailsEndpoint}") String firmDetailsEndpoint,
                                              @Value("${broker-registration.registerBrokerAdminEndpoint}") String registerBrokerAdminEndpoint) {
        this.httpClient = httpClient;
        this.securityTokenHelper = securityTokenHelper;
        this.objectMapper = objectMapper;
        this.registerBrokerEndpoint = registerBrokerEndpoint;
        this.usernameEndpoint = usernameEndpoint;
        this.firmDetailsEndpoint = firmDetailsEndpoint;
        this.registerBrokerAdminEndpoint = registerBrokerAdminEndpoint;
    }

    private Response get(String url) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Authorization", "Bearer " + this.securityTokenHelper.getAccessToken())
                .build();
        return httpClient.newCall(request).execute();
    }

    private Response post(String url, RequestBody body) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", "Bearer " + this.securityTokenHelper.getAccessToken())
                .build();
        return httpClient.newCall(request).execute();
    }

    public BrokerRegistrationResponseDto registerBroker(BrokerRegistrationDto brokerRegistrationDto) {
        log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(String.format("Calling CRM service to register " +
                    "broker: %s", brokerRegistrationDto))
            .build()
        );

        try {
            RequestBody request = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), this.objectMapper.writeValueAsString(brokerRegistrationDto));
            Response response = post(registerBrokerEndpoint, request);
            int status = response.code();

            if (status != HttpURLConnection.HTTP_OK) {
                String error = "Error in call " + response.code();
                log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .subtype(LogMessageSubtype.ERROR_RESPONSE)
                    .description(error)
                    .build()
                );

                throw new CrmEndpointException(String.format("Endpoint %s returned %d (%s)", registerBrokerEndpoint, status, response.message()));
            } else {
                ResponseBody body = response.body();
                if (body != null) {
                    JSONObject jsonObject = (JSONObject) JSONValue.parse(body.string());
                    return objectMapper.convertValue(jsonObject, BrokerRegistrationResponseDto.class);
                }
            }
        } catch (IOException e) {
            String error = "Error registering broker " + e;
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(error)
                .build()
            );

            throw new CrmEndpointException(String.format("Endpoint %s request failed %s", registerBrokerEndpoint, e.getMessage()));
        }

        log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(String.format("Endpoint %s failed for broker " +
                                "registration.",
                        registerBrokerEndpoint))
                .build()
        );

        throw new CrmEndpointException(String.format("Endpoint %s failed", registerBrokerEndpoint));
    }

    public AdminRegistrationResponseDto registerAdmin(AdminRegistrationDto adminRegistrationDto) {
        log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(String.format("Calling CRM service to register " +
                    "admin: %s", adminRegistrationDto))
            .build()
        );

        try {
            RequestBody request = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), this.objectMapper.writeValueAsString(adminRegistrationDto));
            Response response = post(registerBrokerAdminEndpoint, request);
            int status = response.code();

            if (status != HttpURLConnection.HTTP_OK) {
                String error = "Error in call " + response.code();
                log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .subtype(LogMessageSubtype.ERROR_RESPONSE)
                    .description(error)
                    .build()
                );

                throw new CrmEndpointException(String.format("Endpoint %s returned %d (%s)", registerBrokerAdminEndpoint, status, response.message()));
            } else {
                ResponseBody body = response.body();
                if (body != null) {
                    JSONObject jsonObject = (JSONObject) JSONValue.parse(body.string());
                    return objectMapper.convertValue(jsonObject, AdminRegistrationResponseDto.class);
                }
            }
        } catch (IOException e) {
            String error = "Error registering admin " + e;
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(error)
                .build()
            );

            throw new CrmEndpointException(String.format("Endpoint %s request failed %s", registerBrokerAdminEndpoint, e.getMessage()));
        }
        log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(String.format("Endpoint %s failed for admin " +
                                "registration.",
                        registerBrokerEndpoint))
                .build()
        );
        throw new CrmEndpointException(String.format("Endpoint %s failed", registerBrokerAdminEndpoint));
    }

    public UsernameAvailableResponse isUsernameAvailable(String username) {
        UsernameAvailableResponse.UsernameAvailableResponseBuilder responseBuilder = UsernameAvailableResponse.builder();
        responseBuilder.isAvailable(false); // the default
        try {
            String callUrl = usernameEndpoint + URLEncoder.encode('\'' + username + '\'', StandardCharsets.UTF_8.toString());
            Response response = get(callUrl);
            int status = response.code();

            if (status != HttpURLConnection.HTTP_OK) {
                String error = "Error in call " + response.code();
                log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .subtype(LogMessageSubtype.ERROR_RESPONSE)
                    .description(error)
                    .build()
                );
                responseBuilder.error(error).isError(true);
            } else {
                ResponseBody body = response.body();
                if (body != null) {
                    JSONObject jsonObject = (JSONObject) JSONValue.parse(body.string());
                    boolean isAvailable = Boolean.parseBoolean(Objects.requireNonNull(jsonObject.get("mbs_brokerportalidavailable")).toString());
                    log.debug(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.OUTGOING)
                        .description(String.format(
                            "CRM service responds... username: %s; " +
                                    "isAvailable: %s", username, isAvailable))
                        .build()
                    );
                    responseBuilder.isAvailable(isAvailable);
                }
            }
        } catch (Exception e) {
            String error = "Error getting username availability " +
                    ((e.getMessage() == null) ? e : e.getMessage());

            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(error)
                .build()
            );
            responseBuilder.error(error)
                    .isError(true);
        }
        return responseBuilder.build();
    }

    public FirmDetailsResponseDto getFirmDetails(@SuppressWarnings("unused") String brand, String fcaNumber) {
        try {
            String callUrl = firmDetailsEndpoint + URLEncoder.encode('\'' + fcaNumber + '\'', StandardCharsets.UTF_8.toString());
            Response response = get(callUrl);
            int status = response.code();

            if (status != HttpURLConnection.HTTP_OK) {
                String error = "Error in call " + response.code();
                log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.OUTGOING)
                    .subtype(LogMessageSubtype.ERROR_RESPONSE)
                    .description(error)
                    .build()
                );

                throw new CrmEndpointException(String.format("Endpoint %s returned %d (%s)", firmDetailsEndpoint, status, response.message()));
            } else {
                ResponseBody body = response.body();
                if (body != null) {
                    JSONObject jsonObject = (JSONObject) JSONValue.parse(body.string());
                    return objectMapper.convertValue(jsonObject, FirmDetailsResponseDto.class);
                }
            }
        } catch (IOException e) {
            String error = "Error getting firm details " + e;
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(error)
                .build()
            );

            throw new CrmEndpointException(String.format("Endpoint %s request failed %s", firmDetailsEndpoint, e.getMessage()));
        }
        log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(String.format("Endpoint %s failed for " +
                        "retrieving firm details.", registerBrokerEndpoint))
                .build()
        );
        throw new CrmEndpointException(String.format("Endpoint %s failed", firmDetailsEndpoint));
    }
}
