package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class ReactivateUserRequest {
  @JsonProperty("firstName")
  @Schema(
      description = "Specifies the first name of the user",
      example = "Alice",
      required = true
  )
  @NotNull
  String firstName;

  @JsonProperty("lastName")
  @Schema(
      description = "Specifies the last name of the user",
      example = "Smith",
      required = true
  )
  @NotNull
  String lastName;

  @JsonProperty("email")
  @Schema(
      description = "Specifies the email address of the user",
      example = "asmith@aol.com",
      required = true
  )
  @NotNull
  String email;

  @JsonProperty("username")
  @Schema(
      description = "Specifies the username of the user",
      example = "asmith",
      required = true
  )
  @NotNull
  String username;
}
