package com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.NonNull;

public enum ErrorCode {
  INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR"),
  INVALID_CREDENTIALS("INVALID_CREDENTIALS"),
  OTP_EXPIRED("OTP_EXPIRED"),
  OTP_VALIDATION_FAILED("OTP_VALIDATION_FAILED"),
  UNAUTHORISED("UNAUTHORISED"),
  INVALID_DETAILS("INVALID_DETAILS"),
  ACCOUNT_LOCKED("ACCOUNT_LOCKED"),
  PASSWORD_EXPIRED("PASSWORD_EXPIRED"),
  USER_ALREADY_EXISTS("USER_ALREADY_EXISTS"),
  USER_NOT_FOUND("USER_NOT_FOUND"),
  INVALID_REQUEST("INVALID_REQUEST"),
  INCORRECT_MEMORABLE_QUESTION_ANSWERS("INCORRECT_MEMORABLE_QUESTION_ANSWERS"),
  MEMORABLE_QUESTIONS_LOCKED("MEMORABLE_QUESTIONS_LOCKED"),
  QUESTIONS_NOT_RETRIEVED("QUESTIONS_NOT_RETRIEVED");

  private final String value;

  ErrorCode(@NonNull String value) {
    this.value = value;
  }

  @JsonCreator
  public static ErrorCode fromValue(String text) {
    for (ErrorCode code : ErrorCode.values()) {
      if (code.value.equals(text)) {
        return code;
      }
    }
    return null;
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }
}
