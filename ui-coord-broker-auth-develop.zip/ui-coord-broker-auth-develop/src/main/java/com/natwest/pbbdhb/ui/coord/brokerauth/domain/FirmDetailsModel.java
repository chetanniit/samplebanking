package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.Value;

import javax.annotation.CheckForNull;

@Builder
@Value
public class FirmDetailsModel {

    @CheckForNull
    String firmName;

    @CheckForNull
    String fcaNumber;

    @CheckForNull
    String principalFCANumber;

    @CheckForNull
    AddressInfoModel address;

    @CheckForNull
    String tradingName;
}
