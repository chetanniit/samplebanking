package com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TradingNameDto {

  @JsonProperty("mbs_name")
  public String name;

  @JsonProperty("mbs_type")
  public String type;

  @JsonProperty("mbs_effectivedate")
  public String effectivedate;
}
