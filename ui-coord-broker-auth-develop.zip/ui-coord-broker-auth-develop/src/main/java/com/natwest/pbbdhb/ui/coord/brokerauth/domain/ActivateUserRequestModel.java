package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class ActivateUserRequestModel {

  @NonNull
  String otpCode;

  @NonNull
  String username;

  @NonNull
  String password;

  @NonNull
  List<SecurityQuestion> securityQuestions;
  
}
