package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerPortalAccessTokenResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.LoginResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoginRequestMapper {

  public static LoginRequestModel toDomainModel(LoginRequest attempt) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping LoginRequest to LoginRequestModel")
            .build()
    );
    return LoginRequestModel.builder()
        .username(attempt.getUsername())
        .password(attempt.getPassword())
        .build();
  }

  public static BrokerPortalAccessTokenRequestModel toDomainModel(
      String username,
      UserRegistrationType brokerType,
      String fcaNumber) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping Username, UserRegistrationType and FcaNumber to BrokerPortalAccessTokenRequestModel")
            .build()
    );
    return BrokerPortalAccessTokenRequestModel
        .builder()
        .brokerRole(brokerType)
        .userName(username)
            .fcaNumber(fcaNumber)
        .build();
  }

  public static LoginResponse toResponseModel(BrokerPortalAccessTokenResponseModel result, UserRegistrationType brokerType) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping BrokerPortalAccessTokenResponseModel and UserRegistrationType to LoginResponse")
            .build()
    );
    return LoginResponse.builder()
        .accessToken(result.getAccessToken())
        .tokenType(result.getTokenType())
        .expiresIn(result.getExpiresIn())
        .brokerType(brokerType)
        .build();
  }
}
