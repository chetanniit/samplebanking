package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.event;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventRequestDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerEventResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.CrmEndpointException;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.SecurityTokenHelper;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import java.io.IOException;
import java.net.HttpURLConnection;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class BrokerEventRestClient implements BrokerEventClient {

    private final OkHttpClient httpClient;
    private final SecurityTokenHelper securityTokenHelper;
    private final String createBrokerEndpoint;
    private final ObjectMapper objectMapper;

    public BrokerEventRestClient(
        @Qualifier("proxyHttpClient") OkHttpClient httpClient,
        SecurityTokenHelper securityTokenHelper,
        ObjectMapper objectMapper,
        @Value("${broker-event.createBrokerEventEndpoint}") String createBrokerEventEndpoint) {
        this.httpClient = httpClient;
        this.securityTokenHelper = securityTokenHelper;
        this.objectMapper = objectMapper;
        this.createBrokerEndpoint = createBrokerEventEndpoint;

    }

    public BrokerEventResponseDto createBrokerEvent(BrokerEventRequestDto requestDto) {
        log.info(LogMessage.builder().system(LogMessageSystem.NAPOLI).type(LogMessageType.OUTGOING)
            .description(
                String.format("Calling CRM service to create broker event: %s for user: %s", requestDto,
                        requestDto.getUsername()))
            .build());

        try {
            RequestBody request = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                this.objectMapper.writeValueAsString(requestDto));

            Response response = post(createBrokerEndpoint, request);

            int status = response.code();

            if (status != HttpURLConnection.HTTP_OK) {
                logError(LogMessageSubtype.ERROR_RESPONSE, "Error in create broker event call "
                        + response.code());
                throw new CrmEndpointException(
                    String.format("Endpoint %s returned %d (%s)", createBrokerEndpoint, response.code(),
                        response.message()));

            }

            ResponseBody body = response.body();
            JSONObject jsonObject = new JSONObject();
            if (body != null) {
                jsonObject = (JSONObject) JSONValue.parse(body.string());
            }
            BrokerEventResponseDto responseDto = objectMapper.convertValue(jsonObject, BrokerEventResponseDto.class);

            if (body == null || !checkForSuccess(responseDto.getMessage())) {
                logWarn(LogMessageSubtype.INVALID_RESPONSE,
                    String.format("CRM failed to create broker event type %s for user %s:  %s",
                            requestDto.getEventType(), requestDto.getUsername(), responseDto.getMessage()));
            }

            responseDto.setSuccess(checkForSuccess(responseDto.getMessage()));

            return responseDto;


        } catch (IOException e) {
            String error = "Error creating broker event" + e;
            logError(LogMessageSubtype.INVALID_RESPONSE, error);
            throw new CrmEndpointException(String.format("Endpoint %s request failed %s", createBrokerEndpoint, e.getMessage()));
        }
    }

    private Response post(String url, RequestBody body) throws IOException {
        Request request = new Request.Builder()
            .url(url)
            .post(body)
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer " + this.securityTokenHelper.getAccessToken())
            .build();
        return httpClient.newCall(request).execute();
    }

    private void logError(String logMessageSubtype, String description) {
        log.error(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .subtype(logMessageSubtype)
            .description(description).build());
    }

    private void logWarn(String logMessageSubtype, String description) {
        log.warn(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .subtype(logMessageSubtype)
            .description(description).build());
    }

    private boolean checkForSuccess(String message) {
        String successMessage = "Broker Event Request accepted successfully";
        return successMessage.equalsIgnoreCase(message);
    }


}


