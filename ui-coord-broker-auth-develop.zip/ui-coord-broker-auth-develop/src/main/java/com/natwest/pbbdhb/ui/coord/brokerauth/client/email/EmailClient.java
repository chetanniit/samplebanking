package com.natwest.pbbdhb.ui.coord.brokerauth.client.email;

public interface EmailClient {

  <T extends EmailTemplate> void send(T emailRequestModel);
}
