package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;

import java.util.List;

public interface BrokerAuthClient {

  UserRegistrationType login(LoginRequestModel attempt);

  void activate(ActivateUserRequestModel requestModel);

  String generateActivationCode(
      String username);

  void validateActivationCode(ActivationCodeValidateRequestModel requestModel);

  void createUser(CreateUserRequestModel createUserRequestModel);

  void deleteUser(DeleteUserRequestModel deleteUserRequestModel);

  String reactivateUser(String username);

  List<String> retrieveSecurityQuestions(String username);

  ValidateSecurityAnswersResponseModel validateSecurityAnswers(ValidateSecurityAnswersRequestModel answersModel);

  void resetPassword(ResetPasswordRequestModel resetPasswordRequestModel);

  void validateOtp(ValidateOtpRequestModel validateOtpRequestModel);

  BrokerDetailsResponse getBrokerDetails(String username);

  void getUsernameReminder(UsernameReminderRequest usernameReminderRequest);
}
