package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import lombok.Data;

import java.util.List;

@Data
public class FirmDetailsResponse {
    private String brokerType;
    private String fcaNumber;
    private List<String> tradingNames;
    private List<PaymentPath> paymentPaths;
    private List<PrincipalFcaFirm> principalFcaFirms;
}
