package com.natwest.pbbdhb.ui.coord.brokerauth.service;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.AdminRegistrationResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.BrokerRegistrationResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.dto.FirmDetailsResponseDto;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerFirmNotValidException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerRegistrationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerRegistrationValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UsernameAvailableException;
import com.natwest.pbbdhb.ui.coord.brokerauth.mapper.BrokerRegistrationMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.mapper.FirmDetailsResponseMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.AdminRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.BrokerRegistration;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.FirmDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameAvailableResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.Locale;

import static com.natwest.pbbdhb.ui.coord.brokerauth.util.ApplicationConstants.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class BrokerRegistrationServiceImpl implements BrokerRegistrationService {

    private final BrokerRegistrationConnectionHelper helper;
    private final BrokerRegistrationMapper brokerRegistrationMapper;
    private final FirmDetailsResponseMapper firmDetailsResponseMapper;

    @Override
    public void registerBroker(BrokerRegistration brokerRegistration) {
        if (brokerRegistration.getUsername().length() < 6) {
            log.debug("Broker Registration failed, Username must be at least 6 characters long.");
            throw new BrokerRegistrationValidationException("username", USERNAME_MUST_BE_AT_LEAST_6_CHARACTERS_MSG);
        }

        if (!brokerRegistration.getUsername().matches(USERNAME_STARTS_WITH_LETTER_OR_NUMBER)) {
            log.debug("Broker Registration failed, Username must start with a letter or a number.");
            throw new BrokerRegistrationValidationException("username", USERNAME_STARTS_WITH_LETTER_OR_NUMBER_MSG);
        }

        if (!brokerRegistration.getUsername().matches(USERNAME_NO_SPECIAL_CHARACTERS_REGEX)) {
            log.debug("Broker Registration failed, Username must contain no special characters other than '. - _'");
            throw new BrokerRegistrationValidationException("username", USERNAME_NO_SPECIAL_CHARACTERS_MSG);
        }

        if (brokerRegistration.getAgreements().getTermsOfBusiness() == null) {
            log.debug("Broker Registration failed, Terms of Business must not be null.");
            throw new BrokerRegistrationValidationException("termsOfBusiness", "must not be null");
        }
        if (brokerRegistration.getAgreements().getBusinessDeclaration() == null) {
            log.debug("Broker Registration failed, Business Declarations must not be null.");
            throw new BrokerRegistrationValidationException("businessDeclaration", "must not be null");
        }
        String firstNames = brokerRegistration.getBrokerDetails().getFirstNames();
        if (firstNames == null || firstNames.trim().length() == 0) {
            log.debug("Broker Registration failed, Broker's first name must not be null.");
            throw new BrokerRegistrationValidationException("brokerDetails.firstNames", "must not be blank");
        }
        if (brokerRegistration.getFirmDetails().getBrokerType() == null) {
            log.debug("Broker Registration failed, Broker Type must not be null.");
            throw new BrokerRegistrationValidationException("firmDetails.brokerType", "must not be null");
        }

        if (brokerRegistration.getBrokerDetails().getDateOfBirth() != null) {
            int brokerAge = Period.between(brokerRegistration.getBrokerDetails().getDateOfBirth(), LocalDate.now())
                    .getYears();
            if (brokerAge > 0 && brokerAge < 18) {
                log.debug("Broker Registration failed, Broker must be over 18 years of age.");
                throw new BrokerRegistrationValidationException("brokerDetails.dateOfBirth", "You must be over " +
                        "18 years of age");
            }
        }

        BrokerRegistrationResponseDto brokerRegistrationResponseDto = this.helper.registerBroker(this
                .brokerRegistrationMapper.toBrokerRegistrationDto(brokerRegistration));
        if (brokerRegistrationResponseDto.isSuccess()) {
            //log to notify of broker registration successful
            log.debug(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.INCOMING)
                    .description(String.format("Broker with username: %s registered successfully.",
                            brokerRegistration.getUsername()))
                    .build()
            );
            return;
        }
        if (brokerRegistrationResponseDto.getMessage() != null
                && brokerRegistrationResponseDto.getMessage().toLowerCase(Locale.ROOT).contains("username")) {
            String message = brokerRegistrationResponseDto.getMessage();
            if ("Username already exist". equals(message)) {
                log.debug(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.INCOMING)
                        .description(String.format("Username: %s already in use.", brokerRegistration.getUsername()))
                        .build()
                );
                throw new BrokerRegistrationValidationException("username", USERNAME_IN_USE_MSG);
            } else {
                log.debug(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.INCOMING)
                        .description(String.format("Exception in registration of broker with Username: %s due to" +
                                        " BrokerRegistrationValidationException: %s",
                                brokerRegistration.getUsername(), message))
                        .build()
                );
                throw new BrokerRegistrationValidationException("username", message);
            }
        } else {
            log.error(LogMessage.builder()
                    .system(LogMessageSystem.NAPOLI)
                    .type(LogMessageType.INCOMING)
                    .description(String.format("Error registering broker with username: %s  due to " +
                                    "BrokerRegistrationException: %s",
                            brokerRegistration.getUsername(), brokerRegistrationResponseDto.getMessage()))
                    .build()
            );
            throw new BrokerRegistrationException("Error while submitting broker registration: " +
                    brokerRegistrationResponseDto.getMessage());
        }
    }

    @Override
    public void registerAdmin(AdminRegistration adminRegistration) {
        if (adminRegistration.getUsername().length() < 6) {
            log.debug("Admin Broker Registration failed, Username must be at least 6 characters long.");
            throw new BrokerRegistrationValidationException("username", USERNAME_MUST_BE_AT_LEAST_6_CHARACTERS_MSG);
        }

        if (!adminRegistration.getUsername().matches(USERNAME_STARTS_WITH_LETTER_OR_NUMBER)) {
            log.debug("Admin Broker Registration failed, Username must start with a letter or a number.");
            throw new BrokerRegistrationValidationException("username", USERNAME_STARTS_WITH_LETTER_OR_NUMBER_MSG);
        }

        if (!adminRegistration.getUsername().matches(USERNAME_NO_SPECIAL_CHARACTERS_REGEX)) {
            log.debug("Admin Broker Registration failed, Username must contain no special characters other than" +
                    " '. - _'");
            throw new BrokerRegistrationValidationException("username", USERNAME_NO_SPECIAL_CHARACTERS_MSG);
        }

        if (adminRegistration.getAdminDetails().getFirstName() == null) {
            log.debug("Admin Broker Registration failed, Broker's first name must not be null.");
            throw new BrokerRegistrationValidationException("adminDetails.firstName", "must not be blank");
        }

        if (adminRegistration.getAdminDetails().getDateOfBirth() != null) {
            int adminAge = Period.between(adminRegistration.getAdminDetails().getDateOfBirth(), LocalDate.now())
                    .getYears();
            if (adminAge > 0 && adminAge < 16) {
                log.debug("Admin Broker Registration failed, Admin Broker must be over 16 years of age.");
                throw new BrokerRegistrationValidationException("adminDetails.dateOfBirth", "You must be over 16 " +
                        "years of age");
            }
        }

        AdminRegistrationResponseDto adminRegistrationResponseDto = this.helper.registerAdmin(this
                .brokerRegistrationMapper.toAdminRegistrationDto(adminRegistration));
        if (adminRegistrationResponseDto.getMessage() == null) {
            log.debug("Error while submitting admin registration: message cannot be null.");
            throw new BrokerRegistrationException("Error while submitting admin registration: message cannot be null");
        }


        if (adminRegistrationResponseDto.getMessage().toLowerCase(Locale.ROOT).contains("username")) {
            String message = adminRegistrationResponseDto.getMessage();
            if ("Requested Username is already taken". equals(message)) {
                log.debug(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.INCOMING)
                        .description(String.format("Username: %s already in use.", adminRegistration.getUsername()))
                        .build()
                );
                throw new BrokerRegistrationValidationException("username", USERNAME_IN_USE_MSG);
            } else {
                log.debug(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.INCOMING)
                        .description(String.format("Error registering admin with username: %s ",
                                adminRegistration.getUsername()))
                        .build()
                );
                throw new BrokerRegistrationValidationException("username", message);
            }
        }

        String successMessage = "Request accepted successfully";
        if(!successMessage.equalsIgnoreCase(adminRegistrationResponseDto.getMessage())) {
            log.error(String.format("Error while submitting admin registration: Expected '%s, but received '%s",
                    successMessage, adminRegistrationResponseDto.getMessage()));
            throw new BrokerRegistrationException(String.format(
                "Error while submitting admin registration: Expected \"%s\", but received \"%s\"",
                successMessage,
                adminRegistrationResponseDto.getMessage()));
        }
    }


    @Override
    public boolean isUsernameAvailable(String username) {
        UsernameAvailableResponse usernameAvailable = this.helper.isUsernameAvailable(username);
        if (usernameAvailable.isError()) {
            log.error(String.format("UsernameAvailableException: Username: %s not available", username));
            throw new UsernameAvailableException(usernameAvailable.getError());
        }
        log.debug(String.format("Username: %s for brokerUsername is available.", username));
        return usernameAvailable.isAvailable();
    }

    @Override
    public FirmDetailsResponse getFirmDetails(String brand, String fcaNumber) {
        FirmDetailsResponseDto dto = this.helper.getFirmDetails(brand, fcaNumber);

        if (!dto.getIsExist() || !dto.getIsAllowed()) {
            log.error(String.format("BrokerFirmNotValidException: FCA Number '%s' does not exist or is not allowed " +
                    "to do business.", fcaNumber));
            throw new BrokerFirmNotValidException(String.format("FCA Number '%s' does not exist or is not allowed to " +
                    "do business", fcaNumber));
        }
        log.debug("Firm details successfully retrieved.");
        return this.firmDetailsResponseMapper.toFirmDetails(fcaNumber, dto);
    }
}