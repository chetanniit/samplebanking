package com.natwest.pbbdhb.ui.coord.brokerauth.service.registration;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeGenerateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RegistrationService {

  private final BrokerAuthClient brokerAuthClient;

  public RegistrationService(
      BrokerAuthClient brokerAuthClient) {
    this.brokerAuthClient = brokerAuthClient;
  }


  public String createUser(CreateUserRequestModel createUserRequestModel) {
    brokerAuthClient.createUser(createUserRequestModel);
    String activationCode = brokerAuthClient.generateActivationCode(
        createUserRequestModel.getUsername());

    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("User: %s created with activation code: %s", createUserRequestModel.getUsername(),
            activationCode))
        .build());
    return activationCode;
  }

  public void deleteUser(DeleteUserRequestModel deleteUserRequest) {
    brokerAuthClient.deleteUser(deleteUserRequest);

    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("User '%s' deleted ",
                    deleteUserRequest.getUsername()))
            .build());
  }

  public String reactivateUser(String username) {
    String oneTimePasscode = brokerAuthClient.reactivateUser(username);

    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Generated one-time passcode: %s to reactivate user: %s", oneTimePasscode, username))
        .build());

    return oneTimePasscode;
  }

  public String activationCode(ActivationCodeGenerateRequestModel request) {
    String activationCode = brokerAuthClient.generateActivationCode(request.getUsername());

    log.debug(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.INCOMING)
        .description(String.format("Obtained activation code :%s for user :%s", activationCode, request.getUsername()))
        .build());

    return activationCode;
  }
}
