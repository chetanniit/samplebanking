package com.natwest.pbbdhb.ui.coord.brokerauth.service.activation;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.event.BrokerEvent;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ActivationService {

  private final BrokerAuthClient client;
  private final BrokerEvent brokerEventService;

  public ActivationService(
      BrokerAuthClient client, BrokerEvent brokerEventService) {
    this.brokerEventService = brokerEventService;
    this.client = client;
  }

  public void activateUser(ActivateUserRequestModel requestModel) {
    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Activation Request Successful for user: %s",
                    requestModel.getUsername()))
            .build()
    );
    client.activate(requestModel);
    brokerEventService.createBrokerActivationEvent(requestModel.getUsername());
  }

  public void validateActivationCode(ActivationCodeValidateRequestModel requestModel) {
    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "Validate activation code request successful for code: %s, for user: %s", requestModel.getCode(),
                    requestModel.getUsername()))
            .build()
    );
    client.validateActivationCode(requestModel);

  }

}
