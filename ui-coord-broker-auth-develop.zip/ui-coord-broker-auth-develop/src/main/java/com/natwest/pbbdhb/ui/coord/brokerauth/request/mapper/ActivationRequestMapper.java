package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ActivationCodeValidateRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ActivationRequestMapper {

  private ActivationRequestMapper() {
    // Added to resolve sonarlint issue
  }

  public static ActivateUserRequestModel toDomainModel(ActivateUserRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ActivateUserRequest to ActivateUserRequestModel")
            .build()
    );
    return ActivateUserRequestModel.builder()
        .otpCode(request.getOtpCode())
        .username(request.getUsername())
        .password(request.getPassword())
        .securityQuestions(request.getSecurityQuestions())
        .build();
  }

  public static ActivationCodeValidateRequestModel toDomainModel(
      ActivationCodeValidateRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ActivationCodeValidateRequest to ActivationCodeValidateRequestModel")
            .build()
    );
    return ActivationCodeValidateRequestModel.builder()
        .username(request.getUsername())
        .code(request.getCode())
        .build();
  }
}
