package com.natwest.pbbdhb.ui.coord.brokerauth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FirmDetailsResponseDto {
    @JsonProperty("mbs_firmtype")
    private String brokerType;

    @JsonProperty("mbs_oktodobusiness")
    private Boolean isAllowed;

    @JsonProperty("mbs_isfcanumberexist")
    private Boolean isExist;

    @JsonProperty("mbs_paymentpath")
    private List<PaymentPathDto> paymentPaths;

    @JsonProperty("mbs_alternativetradingnames")
    private List<AlternativeTradingNamesDto> tradingNames;

    @JsonProperty("mbs_principalfcafirm")
    private List<PrincipalFcaFirmDto> principalFcaFirms;
}
