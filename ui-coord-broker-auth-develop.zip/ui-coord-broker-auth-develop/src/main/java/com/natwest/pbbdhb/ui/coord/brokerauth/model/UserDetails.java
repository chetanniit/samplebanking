package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.Title;
import com.natwest.pbbdhb.ui.coord.brokerauth.validator.annotation.ValidateAtLeastOneNotNull;
import jakarta.validation.constraints.Email;
import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.Valid;
import java.time.LocalDate;

@Data
@ValidateAtLeastOneNotNull(fields = "mobilePhoneNumber,otherPhoneNumber")
public class UserDetails {
    @NotNull
    private Title title;

    @NotBlank
    private String firstNames;

    @NotBlank
    private String lastName;

    @NotNull
    private LocalDate dateOfBirth;

    @NotBlank
    @Size(max = 250)
    private String nationality;

    @NotNull
    @Valid
    private ResidentialAddress residentialAddress;

    private String mobilePhoneNumber;

    private String otherPhoneNumber;

    @NotBlank
    @Email
    private String emailAddress;
}
