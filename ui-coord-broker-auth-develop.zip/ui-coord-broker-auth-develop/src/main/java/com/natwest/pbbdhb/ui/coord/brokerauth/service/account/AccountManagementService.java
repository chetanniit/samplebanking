package com.natwest.pbbdhb.ui.coord.brokerauth.service.account;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.BrokerAuthClient;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.QuestionsNotRetrievedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
@Slf4j
public class AccountManagementService {

  private final BrokerAuthClient client;

  public AccountManagementService(BrokerAuthClient client) {
    this.client = client;
  }

  public List<String> retrieveSecurityQuestions(String username) {
    try {
      List<String> allSecurityQuestions = client.retrieveSecurityQuestions(username);

      if (allSecurityQuestions == null) {
        log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.INCOMING)
                .description(String.format("No Challenge Questions Retrieved For User: %s", username))
                .build()
        );
        throw new QuestionsNotRetrievedException("No questions retrieved for user: " + username);
      } else if (allSecurityQuestions.size() < 2) {
        log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.INCOMING)
                .description(String.format("Fewer Than Two Challenge Questions Retrieved For User: %s", username))
                .build()
        );
        throw new QuestionsNotRetrievedException(
                "Fewer than two questions retrieved for user: " + username);
      }

      log.debug(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.INCOMING)
              .description(String.format(
                      "Challenge questions retrieved successfully for user: %s", username))
              .build()
      );

      return Lists.newArrayList(
              allSecurityQuestions.remove(getRandomIndex(allSecurityQuestions.size())),
              allSecurityQuestions.remove(getRandomIndex(allSecurityQuestions.size()))
      );
    } catch (RemoteRequestFailedException ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.INCOMING)
              .description(String.format("Error Retrieving Challenge Questions For User: %s", username))
              .build()
      );
      throw new QuestionsNotRetrievedException("Error retrieving questions for user: " + username,
              ex);
    }
  }

  public ValidateSecurityAnswersResponseModel validateSecurityAnswers(
          ValidateSecurityAnswersRequestModel answersModel) {
    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format("Challenge answers for user: %s validated successfully",
                    answersModel.getUsername()))
            .build()
    );
    return client.validateSecurityAnswers(answersModel);
  }

  public void resetPassword(ResetPasswordRequestModel requestModel) {
    client.resetPassword(requestModel);

    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "Password for user: %s reset successfully", requestModel.getUsername()))
            .build()
    );
  }

  public void validateOtp(ValidateOtpRequestModel requestModel) {
    client.validateOtp(requestModel);

    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "OTP for user: %s with OTP code: %s validated successfully", requestModel.getUsername(),
                    requestModel.getOtpCode()))
            .build()
    );
  }

  public BrokerDetailsResponse getBrokerDetails(String username) {
    return client.getBrokerDetails(username);
  }

  public void getUsernameReminder(UsernameReminderRequest usernameReminderRequest) {
    client.getUsernameReminder(usernameReminderRequest);

    log.debug(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description(String.format(
                    "Username reminder Request Successful for %s ", usernameReminderRequest))
            .build()
    );
  }

  private int getRandomIndex(int size) {
    return ThreadLocalRandom.current().nextInt(0, size);
  }


}
