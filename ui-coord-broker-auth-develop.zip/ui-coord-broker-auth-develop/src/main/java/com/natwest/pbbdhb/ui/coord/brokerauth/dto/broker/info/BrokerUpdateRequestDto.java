package com.natwest.pbbdhb.ui.coord.brokerauth.dto.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerUpdateRequestDto {

  @JsonProperty("mbs_requesttype")
  public String requestType;

  @JsonProperty("mbs_status")
  public String status;

}
