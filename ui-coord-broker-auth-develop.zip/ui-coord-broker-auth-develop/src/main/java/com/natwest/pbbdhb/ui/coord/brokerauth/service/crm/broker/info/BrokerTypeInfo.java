package com.natwest.pbbdhb.ui.coord.brokerauth.service.crm.broker.info;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;

import java.util.List;

public interface BrokerTypeInfo {

  BrokerInfoBrokerDomainModel getBrokerInfo(String username);
}
