package com.natwest.pbbdhb.ui.coord.brokerauth.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum UserRegistrationType implements ValuedEnum {
  ADMIN("ADMIN"),
  BROKER("BROKER");

  private final String value;

  @Override
  public String value() {
    return value;
  }

  @JsonCreator
  public static UserRegistrationType fromValue(String value) {
    for (UserRegistrationType result : UserRegistrationType.values()) {
      if (result.name().equals(value)) {
        return result;
      }
    }
    return null;
  }
}
