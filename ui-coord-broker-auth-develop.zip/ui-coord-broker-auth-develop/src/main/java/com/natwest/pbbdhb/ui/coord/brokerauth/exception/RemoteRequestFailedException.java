package com.natwest.pbbdhb.ui.coord.brokerauth.exception;

public class RemoteRequestFailedException extends RuntimeException {

  public RemoteRequestFailedException(String message, Throwable cause) {
    super(message, cause);
  }

  public RemoteRequestFailedException(String message) {
    super(message);
  }
}
