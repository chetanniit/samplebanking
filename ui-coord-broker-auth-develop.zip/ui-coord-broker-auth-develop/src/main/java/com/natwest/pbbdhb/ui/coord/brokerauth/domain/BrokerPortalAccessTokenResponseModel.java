package com.natwest.pbbdhb.ui.coord.brokerauth.domain;


import javax.annotation.CheckForNull;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class BrokerPortalAccessTokenResponseModel {

  @NonNull
  String accessToken;

  @NonNull
  String tokenType;

  @CheckForNull
  Integer expiresIn;


}
