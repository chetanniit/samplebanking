package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Builder
@Value
@Jacksonized
public class ReactivateUserResponse {

  @JsonProperty("code")
  @NonNull
  String otpCode;
}
