package com.natwest.pbbdhb.ui.coord.brokerauth.client.email.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.EmailTemplate;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.email.domain.EmailClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;
@Slf4j
public class EmailClientMapper {

  public static <T extends EmailTemplate> EmailClientRequest toClientModel(T emailRequestModel) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping emailRequestModel to EmailClientRequest")
            .build()
    );
    return EmailClientRequest.builder()
        .templateName(emailRequestModel.getTemplateName())
        .parameters(new ObjectMapper().convertValue(emailRequestModel, Map.class))
        .build();
  }
}
