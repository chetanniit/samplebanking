package com.natwest.pbbdhb.ui.coord.brokerauth.request.mapper;

import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ResetPasswordRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.RetrieveChallengeQuestionsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.SubmitChallengeAnswersRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.domain.ValidateOtpRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class AccountManagementRequestMapper {

  private AccountManagementRequestMapper() {
    // Added to resolve sonarlint issue
  }

  public static RetrieveChallengeQuestionsResponse toResponseModel(List<String> securityQuestions) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping securityQuestions to RetrieveChallengeQuestionsResponse")
            .build()
    );
    return RetrieveChallengeQuestionsResponse.builder().securityQuestions(securityQuestions)
        .build();
  }

  public static ValidateSecurityAnswersRequestModel toDomainModel(SubmitChallengeAnswersRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping SubmitChallengeAnswersRequest to ValidateSecurityAnswersRequestModel")
            .build()
    );
    return ValidateSecurityAnswersRequestModel.builder().username(request.getUsername())
        .securityQuestions(request.getSecurityQuestions()).build();
  }

  public static ResetPasswordRequestModel toDomainModel(ResetPasswordRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ResetPasswordRequest to ResetPasswordRequestModel")
            .build()
    );
    return ResetPasswordRequestModel.builder()
        .username(request.getUsername())
        .otpCode(request.getOtpCode())
        .password(request.getPassword())
        .build();
  }

  public static ValidateOtpRequestModel toDomainModel(ValidateOtpRequest request) {
    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.INCOMING)
            .description("Mapping ValidateOtpRequest to ValidateOtpRequestModel")
            .build()
    );
    return ValidateOtpRequestModel.builder()
        .username(request.getUsername())
        .otpCode(request.getOtpCode())
        .build();
  }

}
