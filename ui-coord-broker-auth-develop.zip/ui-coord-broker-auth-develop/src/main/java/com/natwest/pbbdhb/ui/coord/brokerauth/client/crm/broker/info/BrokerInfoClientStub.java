package com.natwest.pbbdhb.ui.coord.brokerauth.client.crm.broker.info;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.AddressInfoModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerInfoBrokerDomainModel;
import java.util.Collections;
import java.util.List;

import com.natwest.pbbdhb.ui.coord.brokerauth.domain.PaymentPathDetailsModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@ConditionalOnProperty(
    value = "clients.brokerinfo.stub.enabled",
    havingValue = "true")
@Service
@Primary
@Slf4j
public class BrokerInfoClientStub implements BrokerInfo {

  @Override
  public BrokerInfoBrokerDomainModel getBrokerInfo(String username) {
   return BrokerInfoBrokerDomainModel.builder()
       .username(username)
       .brokerId("123456789")
       .title("Mr")
       .brokerFirstName("StubFirstname")
       .brokerLastName("StubLastname")
       .emailAddress("stub@email.com")
       .businessPhone("0791231234")
       .mobileNumber("0791231234")
       .brokerPostcode("NE2 1AA")
       .fcaNumber("875689")
       .principalFcaNumber("789678")
       .firmName("London & Country ")
       .firmAddress(AddressInfoModel.builder()
           .postcode("NE1 2AA")
           .line1("123 Street Road")
           .build())
       .paymentPaths(Collections.singletonList(PaymentPathDetailsModel.builder()
           .paymentPathId("229181986")
           .paymentPathName("A & B Financial Ltd")
           .paymentPathScaleResidential("654567")
           .paymentPathScaleBtl("7867567")
           .build()))
       .build();
  }

  @Override
  public BrokerInfoBrokerDomainModel getAdminInfo(String username) {
    return BrokerInfoBrokerDomainModel.builder()
        .username(username)
        .brokerId("234567890")
        .brokerFirstName("StubAdminFirstName")
        .brokerLastName("StubAdminLastName")
        .emailAddress("adminstub@email.com")
        .businessPhone("0791231234")
        .mobileNumber("0791231234")
        .fcaNumber("875689")
        .principalFcaNumber("789678")
        .firmName("London & Country ")
        .build();
  }
}
