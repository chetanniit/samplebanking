package com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth;

import static java.lang.String.format;

import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivateUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivationCodeClientResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivationCodeGenerateClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ActivationCodeValidateClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.CreateUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.DeleteUserClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.LoginClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ReactivateUserRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ReactivateUserResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ResetPasswordClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.RetrieveSecurityQuestionsRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.RetrieveSecurityQuestionsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ValidateOtpClientRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ValidateSecurityAnswersRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.domain.ValidateSecurityAnswersResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.client.brokerauth.mapper.BrokerAuthClientMapper;
import com.natwest.pbbdhb.ui.coord.brokerauth.config.BrokerAuthRestClientConfig;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ActivationCodeValidateRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.Brand;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.BrokerDetailsResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.LoginRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ResetPasswordRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateOtpRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.domain.ValidateSecurityAnswersResponseModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.AccountLockedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ActivationCodeException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.BrokerDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.InvalidDetailsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.LoginFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.MemorableQuestionAnswersValidationException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.PasswordExpiredException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.QuestionsNotRetrievedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.RemoteRequestFailedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ResetPasswordException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UnauthorisedException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserAlreadyExistsException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.UserNotFoundException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.ValidateOtpException;
import com.natwest.pbbdhb.ui.coord.brokerauth.exception.domain.ErrorCode;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.CreateUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.DeleteUserRequestModel;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderRequest;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.UsernameReminderResponse;
import com.natwest.pbbdhb.ui.coord.brokerauth.model.enums.UserRegistrationType;
import com.natwest.pbbdhb.ui.coord.brokerauth.request.security.UserClaimsProvider;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSubtype;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageSystem;
import com.natwest.pbbdhb.ui.coord.brokerauth.util.LogMessageType;
import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Slf4j
public class BrokerAuthRestClient implements BrokerAuthClient {

  private final BrokerAuthRestClientConfig config;
  private final RestTemplate restTemplate;
  private final UserClaimsProvider userClaimsProvider;

  private static final String LOGIN = "login";
  private static final String USERS = "users";
  private static final String ACTIVATION = "activation";
  private static final String ACTIVATION_CODE = "activation-code";
  private static final String VALIDATE = "validate";
  private static final String REACTIVATE = "reactivate";
  private static final String ACCOUNT_MANAGEMENT = "account-management";
  private static final String CHALLENGE_QUESTIONS = "challenge-questions";
  private static final String CHALLENGE_ANSWERS = "challenge-answers";
  private static final String PASSWORD_RESET = "password-reset";
  private static final String OTP_VALIDATION = "otp-validation";
  private static final String BROKER_DETAILS = "broker-details";
  private static final String USERNAME_REMINDER = "username-reminder";

  @Autowired
  public BrokerAuthRestClient(
      BrokerAuthRestClientConfig config,
      @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
      UserClaimsProvider userClaimsProvider) {
    this.config = config;
    this.restTemplate = restTemplate;
    this.userClaimsProvider = userClaimsProvider;
  }

  @Override
  public UserRegistrationType login(LoginRequestModel attempt) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(format("Calling BrokerAuth service with login request for user: %s", attempt.getUsername()))
        .build()
    );

    try {
      Brand brand = userClaimsProvider.getOperatingBrand();

      HttpEntity<LoginClientRequest> httpRequest = new HttpEntity<>(
          BrokerAuthClientMapper.toClientModel(attempt),
          getHeaders(brand.getValue()));

      ResponseEntity<UserRegistrationType> responseEntity = restTemplate
          .postForEntity(
              createLoginUri(),
              httpRequest,
              UserRegistrationType.class);

      return Optional
          .ofNullable(responseEntity.getBody())
          .orElseThrow(() -> {
            String error =
                "BrokerAuth service returned an empty payload for login request for user: " + attempt.getUsername();
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(error)
                .build());
            return new RemoteRequestFailedException(error);
          });
    } catch (HttpClientErrorException.Unauthorized ex) {
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCode.INVALID_CREDENTIALS.toString())) {
        log.warn(String.format("Login failed due to input of invalid credentials for user: '%s'",
                attempt.getUsername()));
        throw new LoginFailedException(attempt.getUsername());
      }
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCode.ACCOUNT_LOCKED.toString())) {
        log.warn(String.format("Login failed due to account being locked for user: '%s'", attempt.getUsername()));
        throw new AccountLockedException(attempt.getUsername());
      }
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCode.PASSWORD_EXPIRED.toString())) {
        log.warn(String.format("Login failed due to password being expired for user: '%s'", attempt.getUsername()));
        throw new PasswordExpiredException(attempt.getUsername());
      }
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(format(
                      "Login failed due to returning more than 1 resource or error code does not relate to invalid " +
                              "credentials for user: '%s'", attempt.getUsername()))
              .build()
      );
      throw new UnauthorisedException(ErrorCode.UNAUTHORISED, format(
          "Login failed due to returning more than 1 resource or error code does not relate to invalid credentials " +
                  "for user: '%s'",
          attempt.getUsername()));
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(format("Call to BrokerAuth service with login request for user: %s failed with " +
                      "RestClientException: %s", attempt.getUsername(), ex.getMessage()))
          .build()
      );

      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  @Override
  public void activate(ActivateUserRequestModel requestModel) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            format("Calling BrokerAuth service with activation request for user: %s", requestModel.getUsername()))
        .build()
    );

    try {
      Brand brand = userClaimsProvider.getOperatingBrand();

      HttpEntity<ActivateUserClientRequest> httpRequest = new HttpEntity<>(
          BrokerAuthClientMapper.toClientModel(requestModel), getHeaders(brand.getValue()));

      restTemplate
          .postForEntity(
              createActivationUri(),
              httpRequest,
              Void.class);

      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("End of call of BrokerAuth service with activation request for user: %s",
                      requestModel.getUsername()))
              .build()
      );

    } catch (HttpClientErrorException.Unauthorized ex) {
      ErrorCode code = ErrorCode.fromValue(
          JsonPath.parse(ex.getResponseBodyAsString()).read("code"));
      log.error(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(format("Call to BrokerAuth service with activation request for user: %s failed with " +
                      "HttpClientErrorException: %s", requestModel.getUsername(), ex.getMessage()))
              .build()
      );
      throwActivationCodeErrors(Objects.requireNonNull(code), requestModel.getUsername());
    } catch (HttpClientErrorException.BadRequest ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(format("Call to BrokerAuth service with activation request for user: %s failed as password" +
                      " doesn't meet requirements", requestModel.getUsername()))
              .build()
      );
      throw new InvalidDetailsException(
          format("Password for user '%s' doesn't meet requirements",
              requestModel.getUsername()));
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(format("Call to BrokerAuth service with activation request for user: %s failed with " +
                  "RestClientException: %s", requestModel.getUsername(), ex.getMessage()))
          .build()
      );

      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  @Override
  public String generateActivationCode(
      String username) {
    URI url = createActivationCodeGenerationUri();
    ActivationCodeGenerateClientRequest codeGenerateClientRequest = BrokerAuthClientMapper.toActivationCodeGenerationClientModel(
        username);
    HttpEntity<ActivationCodeGenerateClientRequest> requestHttpEntity = new HttpEntity<>(
        codeGenerateClientRequest);

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description("Calling BrokerAuth service to generate activation code for user: " + username)
        .build()
    );

    try {
      ResponseEntity<ActivationCodeClientResponse> response = restTemplate.postForEntity(url,
          requestHttpEntity, ActivationCodeClientResponse.class);

      log.info(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(format("BrokerAuth service returned activation code: %s for user: %s",
                  Objects.requireNonNull(response.getBody()).getCode(), username))
          .build());

      return Optional
          .of(Objects.requireNonNull(response.getBody()).getCode())
          .orElseThrow(() -> {
            String error =
                "BrokerAuth service returned an empty payload for generate activation code request for user: "
                    + username;
            log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(error)
                .build());
            return new RemoteRequestFailedException(error);
          });
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(format("Call to BrokerAuth service to generate activation code for user: %s failed with " +
                  "RestClientException: %s", username, ex.getMessage()))
          .build()
      );

      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  @Override
  public void validateActivationCode(ActivationCodeValidateRequestModel requestModel) {
    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            format("Calling BrokerAuth service to validate activation code request: %s", requestModel))
        .build()
    );

    try {
      Brand brand = userClaimsProvider.getOperatingBrand();

      HttpEntity<ActivationCodeValidateClientRequest> httpRequest = new HttpEntity<>(
          BrokerAuthClientMapper.toClientModel(requestModel), getHeaders(brand.getValue()));

      restTemplate
          .postForEntity(
              createValidateActivationCodeUri(),
              httpRequest,
              Void.class);

      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("End of call to BrokerAuth service to validate activation code request: %s",
                      requestModel))
              .build()
      );

    } catch (HttpClientErrorException.Unauthorized ex) {
      ErrorCode code = ErrorCode.fromValue(
          JsonPath.parse(ex.getResponseBodyAsString()).read("code"));
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(format("Call to BrokerAuth to validate activation code request: %s failed with " +
                      "HttpClientErrorException: %s", requestModel, ex.getMessage()))
              .build()
      );
      throwActivationCodeErrors(Objects.requireNonNull(code), requestModel.getUsername());
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(format(
              "Call to BrokerAuth service to validate activation code request: %s failed with RestClientException: %s",
                  requestModel, ex.getMessage()))
          .build()
      );
      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  @Override
  public void createUser(CreateUserRequestModel createUserRequestModel) {

    URI url = buildCreateUsersUri();
    CreateUserClientRequest createUserClientRequest = BrokerAuthClientMapper.toClientModel(
        createUserRequestModel);
    HttpEntity<CreateUserClientRequest> requestEntity = new HttpEntity<>(createUserClientRequest);

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(format("Calling BrokerAuth service to create user: %s",
            createUserRequestModel))
        .build()
    );

    try {
      restTemplate.postForEntity(url, requestEntity, Void.class);
      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("End of Call to BrokerAuth service to create user: %s", createUserRequestModel))
              .build()
      );
    } catch (HttpClientErrorException.Conflict ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("Calling to BrokerAuth service to Create User request failed due to user '%s' " +
                      "already existing", createUserRequestModel.getUsername()))
              .build()
      );
      throw new UserAlreadyExistsException(createUserRequestModel.getUsername());
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(String.format("Call to BrokerAuth service with Create User request failed with " +
                      "RestClientException: %s", ex.getMessage()))
              .build(),
          ex
      );
      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    }
  }

  @Override
  public void deleteUser(DeleteUserRequestModel deleteUserRequestModel) {

    URI url = buildDeleteUsersUri();
    DeleteUserClientRequest deleteUserClientRequest = BrokerAuthClientMapper.toClientModel(
        deleteUserRequestModel);

    HttpEntity<DeleteUserClientRequest> requestEntity = new HttpEntity<>(deleteUserClientRequest);

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(format("Calling BrokerAuth service to delete user: %s",
            deleteUserRequestModel))
        .build()
    );

    try {
      restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, Void.class);
      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("End of Call BrokerAuth service to delete user: %s", deleteUserRequestModel))
              .build()
      );
    } catch (HttpClientErrorException.BadRequest ex) {
      if (!ex.getResponseBodyAsString().isEmpty()) {
        ErrorCode code = ErrorCode.fromValue(
            JsonPath.parse(ex.getResponseBodyAsString()).read("code"));
        log.error(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .description(format("Call to BrokerAuth service to delete user: %s failed with error code: %s",
                        deleteUserRequestModel.getUsername(), code))
                .build()
        );
        throw getDeleteUserErrors(code, deleteUserClientRequest.getUsername(), ex);
      }
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("Call to BrokerAuth service to delete user: %s failed with " +
                      "RemoteRequestFailedException: %s", deleteUserRequestModel.getUsername(), ex.getMessage()))
              .build()
      );
      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(String.format("Call to BrokerAuth service with Delete User request failed with " +
                      "RestClientException: %s", ex.getMessage()))
              .build(),
          ex
      );
      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    }
  }

  @Override
  public String reactivateUser(String username) {
    URI url = buildReactivateUserUri();
    ReactivateUserRequest reactivateUserRequest = ReactivateUserRequest.builder().username(username)
        .build();

    HttpEntity<ReactivateUserRequest> requestEntity = new HttpEntity<>(reactivateUserRequest);

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(String.format("Calling BrokerAuth service to reactivate user: %s", username))
        .build());

    try {
      ResponseEntity<ReactivateUserResponse> response = restTemplate.postForEntity(url,
          requestEntity, ReactivateUserResponse.class);

      log.info(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(
              String.format("BrokerAuth service returned reactivation one-time passcode: %s for user: %s",
                      Objects.requireNonNull(response.getBody()).getOtpCode(), username))
          .build());

      return Optional
          .of(Objects.requireNonNull(response.getBody()).getOtpCode())
          .orElseThrow(() ->
              new RemoteRequestFailedException(
                  "BrokerAuth service returned an empty payload for reactivate request " +
                          "for user: " + username));
    } catch (HttpClientErrorException.BadRequest ex) {
      if (!ex.getResponseBodyAsString().isEmpty()) {
        ErrorCode code = ErrorCode.fromValue(
            JsonPath.parse(ex.getResponseBodyAsString()).read("code"));
        log.warn(LogMessage.builder()
                .system(LogMessageSystem.NAPOLI)
                .type(LogMessageType.OUTGOING)
                .subtype(LogMessageSubtype.INVALID_RESPONSE)
                .description(String.format("Call to BrokerAuth service to reactivate user: %s failed with " +
                        "Error Code: %s", username, code))
                .build()
        );
        throw getReactivateUserErrors(code, username, ex);
      }
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description(String.format("Call to BrokerAuth service to reactivate user: %s failed with " +
                      "RemoteRequestFailedException: %s", username, ex.getMessage()))
              .build()
      );
      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .subtype(LogMessageSubtype.INVALID_RESPONSE)
          .description(String.format("Call to BrokerAuth service to reactivate user: %s failed with " +
                          "RestClientException: %s", username, ex.getMessage()))
          .build()
      );

      throw new RemoteRequestFailedException(ex.getMessage(), ex);
    }
  }

  @Override
  public List<String> retrieveSecurityQuestions(String username) {

    URI url = buildRetrieveSecurityQuestionsUri();
    RetrieveSecurityQuestionsRequest retrieveSecurityQuestionsRequest = RetrieveSecurityQuestionsRequest.builder()
            .username(username).build();

    HttpEntity<RetrieveSecurityQuestionsRequest> requestEntity = new HttpEntity<>(
            retrieveSecurityQuestionsRequest);

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(String.format("Calling BrokerAuth service to retrieve security questions: %s",
                    retrieveSecurityQuestionsRequest))
            .build());

    try {
      ResponseEntity<RetrieveSecurityQuestionsResponse> response = restTemplate.postForEntity(url,
              requestEntity, RetrieveSecurityQuestionsResponse.class);

      List<String> securityQuestions = Optional
              .of(Objects.requireNonNull(response.getBody()).getSecurityQuestions())
              .orElseThrow(() ->
                      new RemoteRequestFailedException(
                              "BrokerAuth service returned an empty payload for retrieve" +
                                      " security questions request for user: " + username));

      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(
                      String.format("BrokerAuth service returned security questions: %s for user: %s",
                              securityQuestions, username))
              .build());

      return securityQuestions;
    } catch (HttpClientErrorException.BadRequest ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(String.format("Call to BrokerAuth service with retrieve security questions request " +
                              "failed with HttpClientErrorException: '%s'",
                      ex.getMessage()))
              .build()
      );
      throw new QuestionsNotRetrievedException("Failed to retrieve questions for user: " + username,
              ex);
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .subtype(LogMessageSubtype.INVALID_RESPONSE)
                      .description("Call to BrokerAuth service with retrieve security questions request failed")
                      .build(),
              ex
      );

      throw new RemoteRequestFailedException(
              ex.getMessage(),
              ex);
    }
  }


  @Override
  public ValidateSecurityAnswersResponseModel validateSecurityAnswers(
      ValidateSecurityAnswersRequestModel answersModel) {
    URI url = buildValidateSecurityAnswersUri();
    ValidateSecurityAnswersRequest validateSecurityAnswersRequest = BrokerAuthClientMapper.toClientModel(
        answersModel);

    String username = answersModel.getUsername();
    HttpEntity<ValidateSecurityAnswersRequest> requestEntity = new HttpEntity<>(
        validateSecurityAnswersRequest);

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(
            String.format("Calling BrokerAuth service to validate security questions for user: %s",
                    validateSecurityAnswersRequest.getUsername()))
        .build());

    try {
      ResponseEntity<ValidateSecurityAnswersResponse> response = restTemplate.postForEntity(url,
          requestEntity, ValidateSecurityAnswersResponse.class);

      ValidateSecurityAnswersResponseModel validateSecurityAnswersResponse = Optional.of(
              Objects.requireNonNull(
                  BrokerAuthClientMapper.toResponseModel(Objects.requireNonNull(response.getBody()))))
          .orElseThrow(() ->
              new RemoteRequestFailedException(
                  "BrokerAuth service returned an empty payload for validate security " +
                          "answers request for user: " + username));

      log.info(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format("BrokerAuth service returned otpCode: %s and brokerType: %s for user: %s",
                  validateSecurityAnswersResponse.getOtp(), validateSecurityAnswersResponse.getUserType(),
                  username))
          .build());

      return validateSecurityAnswersResponse;
    } catch (HttpClientErrorException.Unauthorized ex) {
      ErrorCode code = ErrorCode.fromValue(
          JsonPath.parse(ex.getResponseBodyAsString()).read("code"));
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .description(String.format("Call to BrokerAuth service with validate security answers request" +
                                      " failed with HttpClientErrorException: '%s'", ex.getMessage()))
                      .build()
      );
      throw getValidateMemorableQuestionAnswersValidationErrors(Objects.requireNonNull(code),
          username,
          ex);
    } catch (RestClientException ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description("Call to BrokerAuth service with validate security answers request failed")
              .build(),
          ex
      );

      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    }
  }

  @Override
  public void resetPassword(ResetPasswordRequestModel resetPasswordRequestModel) {
    final String username = resetPasswordRequestModel.getUsername();
    final String otpCode = resetPasswordRequestModel.getOtpCode();
    URI url = buildResetPasswordUri();
    ResetPasswordClientRequest resetPasswordClientRequest = BrokerAuthClientMapper.toClientModel(resetPasswordRequestModel);

    HttpEntity<ResetPasswordClientRequest> requestEntity = new HttpEntity<>(resetPasswordClientRequest);

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(format("Calling BrokerAuth service to reset password for user: %s",
                    resetPasswordClientRequest.getUsername()))
            .build()
    );

    try {
      restTemplate.exchange(url, HttpMethod.POST, requestEntity, Void.class);
      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(format("End of call to BrokerAuth service to reset password for user: %s",
                      resetPasswordClientRequest.getUsername()))
              .build()
      );
    } catch (HttpClientErrorException.BadRequest ex) {
      final int httpStatusBadRequest = HttpStatus.BAD_REQUEST.value();
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.USER_NOT_FOUND.toString())) {
        log.warn(String.format("Call to BrokerAuth service with Reset Password request failed due to user: '%s' not" +
                " being found", username));
        throw new ResetPasswordException(httpStatusBadRequest, ErrorCode.USER_NOT_FOUND, format("User not found for user: '%s'", username));
      }
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCode.INVALID_DETAILS.toString())) {
        log.warn(String.format("Call to BrokerAuth service with Reset Password request failed due to password not " +
                "being valid. Error Code: '%s'", ErrorCode.INVALID_DETAILS));
        throw new ResetPasswordException(httpStatusBadRequest, ErrorCode.INVALID_DETAILS, "Password not valid");
      }
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .subtype(LogMessageSubtype.INVALID_RESPONSE)
                      .description("Call to BrokerAuth service with Reset Password request failed with unexpected " +
                              "400 BadRequest response")
                      .build(),
              ex
      );
      throw new RemoteRequestFailedException(
              ex.getMessage(),
              ex);
    } catch (HttpClientErrorException.Unauthorized ex) {
      final int httpStatusUnauthorised = HttpStatus.UNAUTHORIZED.value();
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.ACCOUNT_LOCKED.toString())) {
        log.warn(String.format("Account locked for user: '%s'", username));
        throw new ResetPasswordException(httpStatusUnauthorised, ErrorCode.ACCOUNT_LOCKED, format("Account locked for user: '%s'", username));
      } else if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.INVALID_CREDENTIALS.toString())) {
        log.warn(String.format("Invalid OTP code for code '%s' and username '%s'",
                otpCode, username));
        throw new ResetPasswordException(httpStatusUnauthorised, ErrorCode.INVALID_CREDENTIALS, format("Invalid OTP code for code '%s' and username '%s'", otpCode, username));
      } else if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.OTP_EXPIRED.toString())) {
        log.warn(String.format("Expired OTP code for code '%s' and username '%s'",
                otpCode, username));
        throw new ResetPasswordException(httpStatusUnauthorised, ErrorCode.OTP_EXPIRED, format("Expired OTP code for code '%s' and username '%s'", otpCode, username));
      } else if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.OTP_VALIDATION_FAILED.toString())) {
        log.warn(String.format("Generic OTP failure for code '%s' and username '%s'",
                otpCode, username));
        throw new ResetPasswordException(httpStatusUnauthorised, ErrorCode.OTP_VALIDATION_FAILED, format("Generic OTP failure for code '%s' and username '%s'", otpCode, username));
      }
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .subtype(LogMessageSubtype.INVALID_RESPONSE)
                      .description("Call to BrokerAuth service with Reset Password request failed with unexpected " +
                              "400 BadRequest response")
                      .build(),
              ex
      );
      throw new RemoteRequestFailedException(
              ex.getMessage(),
              ex);
    } catch (Exception ex) {
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .subtype(LogMessageSubtype.INVALID_RESPONSE)
                      .description("Call to BrokerAuth service with Reset Password request failed")
                      .build(),
              ex
      );
      throw new RemoteRequestFailedException(
              ex.getMessage(),
              ex);
    }
  }

  @Override
  public void validateOtp(ValidateOtpRequestModel validateOtpRequestModel) {
    final String username = validateOtpRequestModel.getUsername();
    final String otpCode = validateOtpRequestModel.getOtpCode();
    URI url = buildValidateOtpUri();
    ValidateOtpClientRequest validateOtpClientRequest = BrokerAuthClientMapper.toClientModel(validateOtpRequestModel);

    HttpEntity<ValidateOtpClientRequest> requestEntity = new HttpEntity<>(validateOtpClientRequest);

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(format("Calling BrokerAuth service to validate OTP for user: %s",
                    validateOtpClientRequest.getUsername()))
            .build());

    try {
      restTemplate.exchange(url, HttpMethod.POST, requestEntity, Void.class);
    } catch (HttpClientErrorException.Unauthorized ex) {
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.ACCOUNT_LOCKED.toString())) {
        log.warn(String.format("Account locked for user: '%s'", username));
        throw new ValidateOtpException(ErrorCode.ACCOUNT_LOCKED, format("Account locked for user: '%s'", username));
      } else if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.INVALID_CREDENTIALS.toString())) {
        log.warn(String.format("Login failed due to invalid credentials for user: '%s'",
                username));
        throw new ValidateOtpException(ErrorCode.INVALID_CREDENTIALS, format("Login failed due to invalid credentials for user: '%s'", username));
      } else if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.OTP_EXPIRED.toString())) {
        log.warn(String.format("Expired OTP code for code '%s' and username '%s'",
                otpCode, username));
        throw new ValidateOtpException(ErrorCode.OTP_EXPIRED, format("Expired OTP code for code '%s' and username '%s'", otpCode, username));
      } else if (Objects.requireNonNull(ex.getResponseBodyAsString())
              .contains(ErrorCode.OTP_VALIDATION_FAILED.toString())) {
        log.warn(String.format("Generic OTP failure for code '%s' and username '%s'",
                otpCode, username));
        throw new ValidateOtpException(ErrorCode.OTP_VALIDATION_FAILED, format("Generic OTP failure for code '%s' and username '%s'", otpCode, username));
      }
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .subtype(LogMessageSubtype.INVALID_RESPONSE)
                      .description("Call to BrokerAuth service with Validate OTP request failed with unexpected " +
                              "401 Unauthorised response")
                      .build(),
              ex
      );
      throw new RemoteRequestFailedException(
              ex.getMessage(),
              ex);
    } catch (Exception ex) {
      log.warn(LogMessage.builder()
                      .system(LogMessageSystem.NAPOLI)
                      .type(LogMessageType.OUTGOING)
                      .subtype(LogMessageSubtype.INVALID_RESPONSE)
                      .description("Call to BrokerAuth service with Validate OTP request failed")
                      .build(),
              ex
      );
      throw new RemoteRequestFailedException(
              ex.getMessage(),
              ex);
    }
  }

  @Override
  public BrokerDetailsResponse getBrokerDetails(String username) {
    URI url = buildGetBrokerDerailsUri(username);

    HttpEntity requestEntity = HttpEntity.EMPTY;

    log.info(LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.OUTGOING)
        .description(format("Calling BrokerAuth service to get broker details for user: %s", username))
        .build());

    try {
      ResponseEntity<BrokerDetailsResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET,
          requestEntity, BrokerDetailsResponse.class);
      log.info(LogMessage.builder()
          .system(LogMessageSystem.NAPOLI)
          .type(LogMessageType.OUTGOING)
          .description(String.format("BrokerAuth service returned broker details for user: %s", username))
          .build());

      return responseEntity.getBody();
    } catch (HttpClientErrorException.BadRequest ex) {
      if (Objects.requireNonNull(ex.getResponseBodyAsString())
          .contains(ErrorCode.INVALID_REQUEST.toString())) {
        log.warn(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.OUTGOING)
                        .description(String.format("Call to BrokerAuth service with broker details request for user:" +
                                                " %s failed with error code INVALID_REQUEST", username))
                        .build(),
                ex
        );
        throw new BrokerDetailsException(ErrorCode.INVALID_REQUEST,
            format("Invalid request for user: '%s'", username));
      }
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description("Call to BrokerAuth service with broker details request failed with unexpected response")
              .build(),
          ex
      );
      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    } catch (Exception ex) {
      log.warn(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .subtype(LogMessageSubtype.INVALID_RESPONSE)
              .description("Call to BrokerAuth service with broker details request failed")
              .build(),
          ex
      );
      throw new RemoteRequestFailedException(
          ex.getMessage(),
          ex);
    }
  }

  @Override
  public void getUsernameReminder(UsernameReminderRequest usernameReminderRequest) {
    URI url = buildGetUsernameReminderUri();

    HttpEntity<UsernameReminderRequest> requestEntity = new HttpEntity<>(usernameReminderRequest);

    log.info(LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.OUTGOING)
            .description(format("Calling BrokerAuth service to get username reminder for user: %s",
                    usernameReminderRequest))
            .build());

    try {
      ResponseEntity<UsernameReminderResponse> responseEntity = restTemplate.exchange(url, HttpMethod.POST,
              requestEntity, UsernameReminderResponse.class);
      log.info(LogMessage.builder()
              .system(LogMessageSystem.NAPOLI)
              .type(LogMessageType.OUTGOING)
              .description(
                      String.format(
                              "BrokerAuth service returned username reminder response %s for user %s",
                              responseEntity.getBody(), usernameReminderRequest))
              .build());

      } catch (HttpClientErrorException.BadRequest ex) {
        if(Objects.requireNonNull(ex.getResponseBodyAsString().contains(ErrorCode.USER_NOT_FOUND.toString()))) {
          log.info("User not found for details {}", usernameReminderRequest);
        } else {
          if (Objects.requireNonNull(ex.getResponseBodyAsString())
                  .contains(ErrorCode.INVALID_REQUEST.toString())) {
            log.warn(LogMessage.builder()
                            .system(LogMessageSystem.NAPOLI)
                            .type(LogMessageType.OUTGOING)
                            .description(String.format("Call to BrokerAuth service with username reminder request for" +
                                    " user: %s failed with error code INVALID_REQUEST", usernameReminderRequest))
                            .build(),
                    ex
            );
            throw new InvalidDetailsException(format("Invalid request for user: '%s'", usernameReminderRequest), ex);
          }
          log.warn(LogMessage.builder()
                          .system(LogMessageSystem.NAPOLI)
                          .type(LogMessageType.OUTGOING)
                          .subtype(LogMessageSubtype.INVALID_RESPONSE)
                          .description(String.format("Call to BrokerAuth service with username reminder request for " +
                                  "user: %s failed with unexpected response", usernameReminderRequest))
                          .build(),
                  ex
          );
          throw new RemoteRequestFailedException(
                  ex.getMessage(),
                  ex);
        }
      } catch (Exception ex) {
        log.warn(LogMessage.builder()
                        .system(LogMessageSystem.NAPOLI)
                        .type(LogMessageType.OUTGOING)
                        .subtype(LogMessageSubtype.INVALID_RESPONSE)
                        .description(String.format("Call to BrokerAuth service with username reminder request failed" +
                                " for user: %s.", usernameReminderRequest))
                        .build(),
                ex
        );
        throw new RemoteRequestFailedException(
                ex.getMessage(),
                ex);
      }
  }

  private URI buildGetBrokerDerailsUri(String username) {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(ACCOUNT_MANAGEMENT)
        .pathSegment(BROKER_DETAILS, "{username}")
        .build(username);
  }

  private URI createLoginUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(LOGIN)
        .build()
        .toUri();
  }

  private URI createActivationCodeGenerationUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(USERS, ACTIVATION_CODE)
        .build()
        .toUri();
  }

  private URI createActivationUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(ACTIVATION)
        .build()
        .toUri();
  }

  private URI createValidateActivationCodeUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(ACTIVATION, VALIDATE)
        .build()
        .toUri();
  }

  private URI buildCreateUsersUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(USERS)
        .build()
        .toUri();
  }

  private URI buildDeleteUsersUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(USERS)
        .build()
        .toUri();
  }

  private URI buildReactivateUserUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(USERS, REACTIVATE)
        .build()
        .toUri();
  }

  private URI buildRetrieveSecurityQuestionsUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(ACCOUNT_MANAGEMENT, CHALLENGE_QUESTIONS)
        .build()
        .toUri();
  }

  private URI buildValidateSecurityAnswersUri() {
    return UriComponentsBuilder
        .fromHttpUrl(config.getUrl())
        .pathSegment(ACCOUNT_MANAGEMENT, CHALLENGE_ANSWERS)
        .build()
        .toUri();
  }

  private URI buildResetPasswordUri() {
    return UriComponentsBuilder
            .fromHttpUrl(config.getUrl())
            .pathSegment(ACCOUNT_MANAGEMENT, PASSWORD_RESET)
            .build()
            .toUri();
  }

  private URI buildValidateOtpUri() {
    return UriComponentsBuilder
            .fromHttpUrl(config.getUrl())
            .pathSegment(ACCOUNT_MANAGEMENT, OTP_VALIDATION)
            .build()
            .toUri();
  }

  private URI buildGetUsernameReminderUri() {
    return UriComponentsBuilder
            .fromHttpUrl(config.getUrl())
            .pathSegment(ACCOUNT_MANAGEMENT, USERNAME_REMINDER)
            .build()
            .toUri();
  }

  private HttpHeaders getHeaders(String brand) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("brand", brand);

    return headers;
  }

  private void throwActivationCodeErrors(ErrorCode code, String username) {
    switch (code) {
      case INVALID_CREDENTIALS:
        throw new ActivationCodeException(ErrorCode.INVALID_CREDENTIALS,
            "Username or otp code is invalid for user: " + username);
      case OTP_EXPIRED:
        throw new ActivationCodeException(ErrorCode.OTP_EXPIRED,
            "Otp code has expired for user: " + username);
      case ACCOUNT_LOCKED:
        throw new ActivationCodeException(ErrorCode.ACCOUNT_LOCKED,
            "Account is locked for user: " + username);
      default:
        throw new ActivationCodeException(ErrorCode.OTP_VALIDATION_FAILED,
            "Something went wrong whilst validating otp for user: " + username);
    }
  }

  private RuntimeException getDeleteUserErrors(ErrorCode code, String username,
      Throwable cause) {
    if (code != null && code.equals(ErrorCode.USER_NOT_FOUND)) {
      return new UserNotFoundException("Could not find user to delete: " + username, cause);
    }

    return new RemoteRequestFailedException(cause.getMessage(), cause);
  }

  private RuntimeException getReactivateUserErrors(ErrorCode code, String username,
      Throwable cause) {
    if (code != null && code.equals(ErrorCode.USER_NOT_FOUND)) {
      return new UserNotFoundException("Could not find user to reactivate: " + username, cause);
    }

    return new RemoteRequestFailedException(cause.getMessage(), cause);
  }

  private RuntimeException getValidateMemorableQuestionAnswersValidationErrors(ErrorCode code,
      String username, Throwable cause) {
    switch (code) {
      case INCORRECT_MEMORABLE_QUESTION_ANSWERS:
        return new MemorableQuestionAnswersValidationException(
            ErrorCode.INCORRECT_MEMORABLE_QUESTION_ANSWERS,
            "Incorrect answers to memorable questions for user: " + username, cause);
      case MEMORABLE_QUESTIONS_LOCKED:
        return new MemorableQuestionAnswersValidationException(ErrorCode.MEMORABLE_QUESTIONS_LOCKED,
            "Memorable questions locked for user: " + username, cause);
      case ACCOUNT_LOCKED:
        return new MemorableQuestionAnswersValidationException(ErrorCode.ACCOUNT_LOCKED,
            "Memorable questions locked for user: " + username, cause);
      default:
        return new RemoteRequestFailedException(
            cause.getMessage(),
            cause);
    }
  }
}
