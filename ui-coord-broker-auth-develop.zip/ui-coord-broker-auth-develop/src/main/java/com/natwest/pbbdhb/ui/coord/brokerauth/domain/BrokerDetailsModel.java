package com.natwest.pbbdhb.ui.coord.brokerauth.domain;

import lombok.Builder;
import lombok.Value;

import javax.annotation.CheckForNull;

@Builder
@Value
public class BrokerDetailsModel {

    @CheckForNull
    String userName;

    @CheckForNull
    String firstName;

    @CheckForNull
    String middleName;

    @CheckForNull
    String lastName;

    @CheckForNull
    String title;

    @CheckForNull
    String emailAddress;

    @CheckForNull
    String mobilePhone;

    @CheckForNull
    String businessPhone;

    @CheckForNull
    String postcode;

}
