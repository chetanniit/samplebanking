package com.natwest.pbbdhb.ui.coord.brokerauth.request.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
public class ActivationCodeValidateRequest {

  @Schema(
      description = "Username from a user's credentials",
      required = true
  )
  @NotNull
  String username;

  @Schema(
      description = "One time activation code received by the user",
      required = true
  )
  @NotNull
  String code;
}
