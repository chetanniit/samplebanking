package com.natwest.pbbdhb.ui.coord.brokerauth.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Builder
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Validated
public class UsernameReminderRequest {

  @JsonProperty("email")
  @Schema(
      description = "Specifies user's email address",
      required = true
  )
  @NotBlank
  String email;

  @JsonProperty("lastName")
  @Schema(
          description = "Specifies user's last name",
          required = true
  )
  @NotBlank
  String lastName;

  @JsonProperty("dateOfBirth")
  @Schema(
          description = "Specifies user's date of birth",
          required = true,
          format = "yyyy-MM-dd"
  )
  @NotNull
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  LocalDate dateOfBirth;

}
