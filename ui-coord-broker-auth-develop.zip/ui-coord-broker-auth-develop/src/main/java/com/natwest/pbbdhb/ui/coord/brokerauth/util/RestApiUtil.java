package com.natwest.pbbdhb.ui.coord.brokerauth.util;

import org.slf4j.MDC;
import org.springframework.http.RequestEntity;

import java.util.Optional;

import static com.rbs.dws.server.tomcat.valve.RequestCorrelationIdValve.REQUEST_CORRELATION_ID_MDC_KEY;
import static com.rbs.dws.server.tomcat.valve.RequestCorrelationIdValve.REQUEST_INTERNAL_CORRELATION_ID_MDC_KEY;

/**
 * The rest api utility methods.
 */
public final class RestApiUtil {

    /**
     * Sets missing correlation id in http header if value present in {@link MDC}.
     *
     * @param builder The {@link RequestEntity.BodyBuilder} to set the header
     */
    public static void setCorrelationIdIfPresent(RequestEntity.BodyBuilder builder) {
        if (!builder.build().getHeaders().containsKey(REQUEST_INTERNAL_CORRELATION_ID_MDC_KEY)) {
            Optional.ofNullable(MDC.get(REQUEST_CORRELATION_ID_MDC_KEY))
                    .ifPresent(correlationId -> builder.header(REQUEST_INTERNAL_CORRELATION_ID_MDC_KEY, correlationId));
        }
    }

    private RestApiUtil() {
    }
}
