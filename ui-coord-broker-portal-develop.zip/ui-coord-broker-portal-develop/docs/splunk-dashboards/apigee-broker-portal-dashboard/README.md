Make sure you follow the guide on PRN-Splunk Dashboards: https://natwest.atlassian.net/wiki/spaces/PBBDHB/pages/1603765502/PRN+-+Splunk+Dashboards

I've added the code in here to keep track of changes better than in confluence