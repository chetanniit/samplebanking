package com.natwest.pbbdhb.broker.portal.uicoord.fma;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.Error;
import com.natwest.pbbdhb.openapi.fma.ResponseData;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil.getFmaRequestJson;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getFmaValidationResponseFilePath;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource("classpath:application-it-fma-submission.properties")
@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
@Disabled
public class FmaSubmissionIT {
     //IMPORTANT - This test is directly calling the FMA service.
     // While it does not test Napoli Code we may be relying on the expected response

    // If 'singleTestCase' is set, only the test case with that name will be run.
    private static final String singleTestCase = null;
//        private static final String singleTestCase = "scenario-2";


    private static String fmaPath = "/mortgages/v1/msvc-full-mortgage-application";
    private static final String FMA_SERVICE_NAME = "msvc-full-mortgage-application";
    private TestInfo testInfo;
    private String testResult;

    @Value("${full.mortgage.application.endpoint}")
    private String fullMortgageApplicationEndpoint;

    @Value("${client.id}")
    private String clientId;

    @Autowired
    private TokenConfiguration tokenConfig;

    @BeforeEach
    public void setUp(TestInfo testInfo) {
        RestAssured.baseURI = fullMortgageApplicationEndpoint;
        RestAssured.port = 443;

        this.testInfo = testInfo;
    }

    @AfterEach
    public void cleanUp() throws IOException {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.DEFAULT_PORT;
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void submitFma(String testCaseName, String fmaRequestJson) {
        Response response = with()
                .header("client_id", clientId)
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, FMA_SERVICE_NAME))
                .contentType(APPLICATION_JSON_VALUE)
                .body(fmaRequestJson)
                .post(fmaPath);

        log.info(response.body().asPrettyString());

        FullMortgageApplicationExtendedResponse fmaResponse = response
                .then()
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(FullMortgageApplicationExtendedResponse.class);

        int statusCode = response.getStatusCode();

      if (testCaseName.startsWith("400")) {

        if (statusCode != 400){
          reportUnexpectedResponseCode(statusCode, response.body().asPrettyString());
        }
        if (statusCode == 400 && checkExpectedValidationError(testCaseName, fmaResponse)){
            this.testResult = "OK   - expected validation error";
            return;
          }
        reportUnexpectedValidationError(fmaResponse);
      }

        if (statusCode == 201 || statusCode == 202) {
            if (hasReferenceNumber(fmaResponse)) {
                // SUCCESS
                String decision = getDecision(fmaResponse);
                this.testResult = "OK      (" + decision + ")";
            } else {
                // MISSING REFERENCE NUMBER
                reportMissingReferenceNumber();
            }
        } else if (statusCode == 400){
            // VALIDATION ERROR
            reportUnexpectedValidationError(fmaResponse);
        } else {
            // UNEXPECTED RESPONSE CODE
            reportUnexpectedResponseCode(statusCode, response.body().asPrettyString());
        }
    }

    private static Stream<Arguments> testCases() throws IOException {
        if (singleTestCase != null) {
            return Stream.of(testCaseArguments(singleTestCase));
        }
        PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
        Resource[] testCaseResources = resourceResolver.getResources("classpath:fma-test-cases/fma-request/*.json");
        return Arrays.stream(testCaseResources)
                .map(JsonTestCaseUtil::testCaseNameFromResource)
                .map(FmaSubmissionIT::testCaseArguments)
                .filter(args -> args.get()[1] != null);
    }

    private static Arguments testCaseArguments(String testCaseName) {
        return Arguments.of(testCaseName, getFmaRequestJson(testCaseName));
    }

    private boolean hasReferenceNumber(FullMortgageApplicationExtendedResponse fmaResponse) {
        ResponseData data = fmaResponse.getData();
        if (data == null) {
            return false;
        }

        return isNotBlank(data.getMortgageNumber()) || isNotBlank(data.getTempRefNo());
    }

    private String getDecision(FullMortgageApplicationExtendedResponse fmaResponse) {
        String decision = "<empty>";
        if (fmaResponse.getData() != null && fmaResponse.getData().getHardscoreDecision() != null) {
            String hardscoreDecision = fmaResponse.getData().getHardscoreDecision().getDecision();
            if (!StringUtils.isEmpty(hardscoreDecision)) {
                decision = hardscoreDecision;
            }
        }
        return decision;
    }

    private String getSummaryErrorMessage(FullMortgageApplicationExtendedResponse fmaResponse) {
        String errorMessage = null;
        List<Error> errors = fmaResponse.getErrors();
        if (errors != null && errors.size() > 0) {
            String firstErrorMessage = errors.get(0).getMessage();
            if (errors.size() == 1) {
                errorMessage = "FAILURE. " + firstErrorMessage;
            } else {
                errorMessage = "FAILURE. " + errors.size() + " errors. First error: " + firstErrorMessage;
            }
        }
        return errorMessage;
    }

    private void reportUnexpectedValidationError(FullMortgageApplicationExtendedResponse fmaResponse) {
        String failureSummary = "validation error";

        String defaultErrorMessage = "FAILURE. Validation error.";
        String summaryErrorMessage = getSummaryErrorMessage(fmaResponse);

        String errorMessage = summaryErrorMessage != null ? summaryErrorMessage : defaultErrorMessage;

        reportFailure(failureSummary, errorMessage);
    }

  private boolean checkExpectedValidationError(String testCaseName, FullMortgageApplicationExtendedResponse fmaResponse) {
    String expectedMessage;
    try {
      expectedMessage = TestUtil.getResourceText(
          new ClassPathResource(getFmaValidationResponseFilePath(testCaseName)));
    }catch (IOException ex){
      log.warn("Missing test resource ", ex);
      return false;
    }
    return getSummaryErrorMessage(fmaResponse).contains(expectedMessage);
  }


  private void reportMissingReferenceNumber() {
        String failureSummary = "missing reference number";
        String errorMessage = "FAILURE. No mortgage reference number or temporary reference number included in response.";

        reportFailure(failureSummary, errorMessage);
    }

    private void reportUnexpectedResponseCode(int statusCode, String responseBody) {
        String failureSummary = "unexpected response code";
        String errorMessage = "FAILURE. Unexpected response code: " + statusCode;

        // include response body in test results
        errorMessage += "\n" + responseBody + "\n";

        reportFailure(failureSummary, errorMessage);
    }

    private void reportFailure(String failureSummary, String errorMessage) {
        this.testResult = "FAILED  (" + failureSummary + ")";

        this.testResult += "\n";
        this.testResult += errorMessage;
        this.testResult += "\n";

        throw new AssertionFailedError(errorMessage);
    }


}
