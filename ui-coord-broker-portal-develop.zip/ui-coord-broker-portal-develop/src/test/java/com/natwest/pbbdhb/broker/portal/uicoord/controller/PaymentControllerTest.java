package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_PAYMENT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.readObjectFromResource;
import static io.restassured.RestAssured.with;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
public class PaymentControllerTest {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/payment/payment-url-request.json")
    private Resource paymentRequestRequest;

    @Value("classpath:test-files/payment/payment-url-response.json")
    private Resource paymentRequestResponse;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void paymentUrlValidRequest() throws IOException, JSONException {

        PaymentRequest paymentRequest = readObjectFromResource(paymentRequestRequest, PaymentRequest.class);

        String expectedResponseJson = TestUtil.getResourceText(paymentRequestResponse);

        Response paymentResponse = with()
                .contentType(APPLICATION_JSON_VALUE)
                .body(paymentRequest)
                .post(PATH_PAYMENT);

        log.info(paymentResponse.body().asPrettyString());

        JSONCompareResult compareResult = JSONCompare.compareJSON(expectedResponseJson, paymentResponse.body().asPrettyString(), JSONCompareMode.STRICT);
        assertTrue(compareResult.passed(), compareResult.getMessage());
    }
}
