package com.natwest.pbbdhb.broker.portal.uicoord.service;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BUREAU_CALL_INFO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_COMPLETED_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_AFTER_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_GENERATE_CASE_ID_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidCaseApplication;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidDecisionInPrincipleDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidInterestOnly;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_BROKER_CLAIMS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.NEW_CUSTOMER;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.AdditionalAnswers.returnsSecondArg;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseIdGenerationClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallInfoDto;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BasicAddressMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BuyerTypeMappingHelper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.NapoliBrokerMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.CaseApplicationAutoMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.CaseApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.DipResultMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.DirectDebitDetailsMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.EstateAgentMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.HardscoreDecisionMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ProductDetailsMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.SolicitorMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.LoanPurpose;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ErcItem;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.CaseServiceImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.system.Clock;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Fee;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith({MockitoExtension.class, SpringExtension.class})
@ContextConfiguration(classes = {
        CaseApplicationMapper.class,
        CaseApplicationAutoMapperImpl.class,
        EstateAgentMapperImpl.class,
        SolicitorMapperImpl.class,
        BasicAddressMapperImpl.class,
        ProductDetailsMapperImpl.class,
        NapoliBrokerMapperImpl.class,
        DipResultMapperImpl.class,
        HardscoreDecisionMapperImpl.class,
        Clock.class,
        DirectDebitDetailsMapperImpl.class
})
class CaseServiceImplTest {

    @Mock
    private CaseIdGenerationClient mockCaseIdGenerationClient;

    @Mock
    private CaseClientNapoli mockCaseClient;

    @Mock
    private  UserClaimsProvider userClaimsProvider;

    @Mock
    private  AccessPermissionChecker accessPermissionChecker;

    @Autowired
    private CaseApplicationMapper caseApplicationMapper;

    private CaseServiceImpl caseService;

    @BeforeEach
    public void beforeEach() {
        caseService = new CaseServiceImpl(mockCaseIdGenerationClient, mockCaseClient, caseApplicationMapper, userClaimsProvider, accessPermissionChecker);
    }

    @Test
    void generateCaseIdPassesExceptionFromClientToCaller() {
        when(accessPermissionChecker.isBroker()).thenReturn(true);
        String expectedMessage = "expected";
        when(mockCaseIdGenerationClient.generateCaseId(BRAND_DEFAULT)).thenThrow(new RuntimeException(expectedMessage));

        assertThat(catchThrowable(() -> caseService.generateCaseId(BRAND_DEFAULT)))
                .isInstanceOf(RuntimeException.class)
                .hasMessage(expectedMessage);
    }

    @Test
    void saveCaseForUpdateMakesCallToClient() {
        CaseApplication caseApplication = createValidCaseApplication();

        String caseId = caseApplication.getCaseId();

        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class))).then(returnsSecondArg());

        assertEquals(caseApplication, caseService.saveCase(BRAND_DEFAULT, caseId, caseApplication,
                TEST_BROKER_CLAIMS, false, false));
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class));
    }

    @Test
    void saveCaseForUpdatePassesExceptionFromClientToCaller() {
        CaseApplication caseApplication = createValidCaseApplication();
        String caseId = caseApplication.getCaseId();

        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());
        String expectedMessage = "expected";
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class))).thenThrow(new RuntimeException(expectedMessage));

        assertThat(catchThrowable(() -> caseService.saveCase(BRAND_DEFAULT, caseId, caseApplication,
                TEST_BROKER_CLAIMS, false, false)))
                .isInstanceOf(RuntimeException.class)
                .hasMessage(expectedMessage);
    }

    @Test
    void saveCaseForUpdateSetsBuyerTypeToNewCustomerWhenFirstTimeBuyerIsFalse() {
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());
        CaseApplication caseApplication = createValidCaseApplication();

        caseApplication.setFirstTimeBuyer(false);

        caseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication,
                TEST_BROKER_CLAIMS, false, false);

        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        CaseApplicationDto caseApplicationDto = caseApplicationDtoArgumentCaptor.getValue();
        assertEquals(NEW_CUSTOMER.name(), caseApplicationDto.getBuyerType());
    }

    @Test
    void saveCaseForUpdateSetsInterestOnlyToNullWhenMortgageTypeIsRepayment() {
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());
        CaseApplication caseApplication = createValidCaseApplication();

        caseApplication.getMortgage().setMortgageType("REPAYMENT");
        caseApplication.getMortgage().setInterestOnly(createValidInterestOnly());

        // InterestOnly object needs to be set to null for DIP validation rules.

        caseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication, TEST_BROKER_CLAIMS, false, false);

        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        CaseApplicationDto caseApplicationDto = caseApplicationDtoArgumentCaptor.getValue();
        assertNull(caseApplicationDto.getMortgage().getInterestOnly());
    }

    @Test
    void saveCaseForUpdateSetsPortingFieldsToNullWhenLoanPurposeIsRemortgage() {
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());

        CaseApplication caseApplication = createValidCaseApplication();

        caseApplication.setLoanPurpose(LoanPurpose.REMORTGAGE.value());
        caseApplication.getProductDetails().setIsPortingProduct(false);
        caseApplication.getProductDetails().setPortingText("some porting text");

        // isPortingProduct and portingNotes need to be set to null for DIP validation rules.

        caseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication, TEST_BROKER_CLAIMS, false, false);

        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        CaseApplicationDto caseApplicationDto = caseApplicationDtoArgumentCaptor.getValue();
        ProductDetailsDto product = caseApplicationDto.getSalesIllustrations().get(0).getProducts().get(0);
        assertNull(product.getIsPortingProduct());
        assertNull(product.getPortingNotes());
    }

    @Test
    void saveCaseForUpdateSetsPortingProductFieldsWhenLoanPurposeIsPurchase() {
      when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());

      CaseApplication caseApplication = createValidCaseApplication();

      caseApplication.setLoanPurpose(LoanPurpose.HOUSE_PURCHASE.value());
      caseApplication.getProductDetails().setIsPortingProduct(true);
      caseApplication.getProductDetails().setProductTerm("TWO_YEAR");
      caseApplication.getProductDetails().setInitialInterestRate(0.05d);
      caseApplication.getProductDetails().setPortingText("some porting text");
      caseApplication.getProductDetails().setProductCode("product code");

      caseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication, TEST_BROKER_CLAIMS, false, false);

      ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
      verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

      CaseApplicationDto caseApplicationDto = caseApplicationDtoArgumentCaptor.getValue();
      ProductDetailsDto product = caseApplicationDto.getSalesIllustrations().get(0).getProducts().get(0);
      assertEquals(true, product.getIsPortingProduct());
      assertEquals("TWO_YEAR", product.getProductTerm());
      assertEquals(BigDecimal.valueOf(0.05d), product.getInitialInterestRate());
      assertEquals("some porting text", product.getPortingNotes());
      assertEquals("product code", product.getProductCode());
    }

  @Test
  void saveCaseForUpdateSetsNonPortingProductFieldsWhenLoanPurposeIsPurchase() {
    when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());

    CaseApplication caseApplication = createValidCaseApplication();

    caseApplication.setLoanPurpose(LoanPurpose.HOUSE_PURCHASE.value());
    caseApplication.getProductDetails().setIsPortingProduct(false);
    caseApplication.getProductDetails().setProductTerm("TWO_YEAR");
    caseApplication.getProductDetails().setInitialInterestRate(0.05d);
    caseApplication.getProductDetails().setPortingText("some porting text");
    caseApplication.getProductDetails().setProductCode("product code");
    caseApplication.getProductDetails().setProductType("product type");
    caseApplication.getProductDetails().setProductName("product name");
    caseApplication.getProductDetails().setLtv(1L);
    caseApplication.getProductDetails().setProductSelectedDate("2024-05-15");
    caseApplication.getProductDetails().setProductEndDate("2024-12-31");
    caseApplication.getProductDetails().setFees(Collections.singletonList(Fee.builder()
        .feeCode("FEE_CODE")
        .type("FEE_TYPE")
        .feeAmount(BigDecimal.valueOf(100))
        .feeAction("FEE_ACTION")
        .build()));
    caseApplication.getProductDetails().setMortgageType("mortgage type");
    caseApplication.getProductDetails().setSvr(0.5);
    caseApplication.getProductDetails().setBaseRate(100.0);
    caseApplication.getProductDetails().setCashBackValue(BigDecimal.valueOf(0.05));
    caseApplication.getProductDetails().setErcItems(Collections.singletonList(ErcItem.builder()
        .endDate("2024-10-31")
        .percentage(BigDecimal.valueOf(10.0))
        .seqNo(1)
        .build()));

    caseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication, TEST_BROKER_CLAIMS, false, false);

    ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
    verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

    CaseApplicationDto caseApplicationDto = caseApplicationDtoArgumentCaptor.getValue();
    ProductDetailsDto product = caseApplicationDto.getSalesIllustrations().get(0).getProducts().get(0);
    assertEquals(false, product.getIsPortingProduct());
    assertEquals("TWO_YEAR", product.getProductTerm());
    assertEquals(BigDecimal.valueOf(0.05d), product.getInitialInterestRate());
    assertEquals("some porting text", product.getPortingNotes());
    assertEquals("product code", product.getProductCode());
    assertEquals("product type", product.getProductType());
    assertEquals("product name", product.getProductName());
    assertEquals(1L, product.getLtv());
    assertEquals("2024-05-15", product.getProductSelectedDate());
    assertEquals("2024-12-31", product.getProductEndDate());
    assertEquals("FEE_CODE", product.getFees().get(0).getFeeCode());
    assertEquals("FEE_TYPE", product.getFees().get(0).getType());
    assertEquals(BigDecimal.valueOf(100), product.getFees().get(0).getFeeAmount());
    assertEquals("FEE_ACTION", product.getFees().get(0).getFeeAction());
    assertEquals("mortgage type", product.getMortgageType());
    assertEquals(BigDecimal.valueOf(0.5), product.getSvr());
    assertEquals(BigDecimal.valueOf(100.0), product.getBaseRate());
    assertEquals(BigDecimal.valueOf(0.05), product.getCashBackValue());
    assertEquals("2024-10-31", product.getErcItems().get(0).getEndDate());
    assertEquals(BigDecimal.valueOf(10.0), product.getErcItems().get(0).getPercentage());
    assertEquals(1, product.getErcItems().get(0).getSeqNo());
  }

    @Test
    void saveCaseForUpdateSetsNumberOfDependantsToZeroWhenApplicantHasNoDependants() {
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), any(String.class))).thenReturn(new CaseApplicationDto());

        CaseApplication caseApplication = createValidCaseApplication();

        caseApplication.setHasDependants(false);
        caseApplication.setNumberOfDependantsUnder18(null);
        caseApplication.setNumberOfDependantsOver18(null);

        // Number of dependants (in both fields) needs to be set to 0 for DIP validation rules.

        caseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication, TEST_BROKER_CLAIMS, false, false);

        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        CaseApplicationDto caseApplicationDto = caseApplicationDtoArgumentCaptor.getValue();
        assertEquals(0, caseApplicationDto.getNumberOfDependantsUnder18());
        assertEquals(0, caseApplicationDto.getNumberOfDependantsOver18());
    }

    @Test
    void saveCaseForUpdateThrowsUpdateNotPermittedWhenApplicationStatusIsStage20() {
        CaseApplication caseApplication = createValidCaseApplication();
        String caseId = caseApplication.getCaseId();

        // set up a CaseApplicationDto with application status SUBMIT_GMS_STAGE_20 (after FMA submission)
        CaseApplicationDto caseApplicationDtoAfterFmaSubmission = caseApplicationMapper.toCaseApplicationDto(
                caseId, caseApplication, TEST_BROKER_CLAIMS);
        caseApplicationDtoAfterFmaSubmission.setApplicationStatus(ApplicationStatus.SUBMIT_GMS_STAGE_20.name());

        // simulate retrieving the existing case with application status SUBMIT_GMS_STAGE_20 from the case client
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), eq(caseId))).thenReturn(caseApplicationDtoAfterFmaSubmission);

        RuntimeException ex = assertThrows(
                UpdateNotPermittedException.class,
                () -> caseService.saveCase(BRAND_DEFAULT, caseId, caseApplication, TEST_BROKER_CLAIMS, false, false));

        assertEquals(MSG_NO_UPDATE_AFTER_FMA, ex.getMessage());
    }

    @Test
    void saveCaseForUpdateCopiesExistingDipResult() {
        CaseApplication caseApplicationWithoutDipResult = createValidCaseApplication();
        String caseId = caseApplicationWithoutDipResult.getCaseId();

        // set up a CaseApplicationDto with a DIP result
        CaseApplicationDto caseApplicationDtoWithDipResult = caseApplicationMapper.toCaseApplicationDto(
                caseId, caseApplicationWithoutDipResult, TEST_BROKER_CLAIMS);
        DecisionInPrincipleDto dipResult = createValidDecisionInPrincipleDto();
        caseApplicationDtoWithDipResult.setDecisionInPrinciples(Collections.singletonList(dipResult));

        // simulate retrieving the existing case with DIP result from the case client
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), eq(caseId))).thenReturn(caseApplicationDtoWithDipResult);

        // set up echo result when updating the case with the case client
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class))).then(returnsSecondArg());

        // update case using case without dip results
        caseService.saveCase(BRAND_DEFAULT, caseId, caseApplicationWithoutDipResult, TEST_BROKER_CLAIMS, false, false);

        verify(mockCaseClient).getCase(eq(BRAND_DEFAULT), eq(caseId));
        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        // check that the dip result was copied to the case DTO used to update the case
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getDecisionInPrinciples().get(0)).isEqualTo(dipResult);
    }

    @Test
    void saveCaseForUpdateCopiesExistingApplicationStatus() {
        String newApplicationStatus = ApplicationStatus.SUBMIT_GMS_STAGE_20.name();
        CaseApplication caseApplicationWithNewApplicationStatus = createValidCaseApplication();
        caseApplicationWithNewApplicationStatus.setApplicationStatus(newApplicationStatus);

        String caseId = caseApplicationWithNewApplicationStatus.getCaseId();

        // set up a CaseApplicationDto with an old application status
        String oldApplicationStatus = null;
        CaseApplicationDto caseApplicationDtoWithOldApplicationStatus = caseApplicationMapper.toCaseApplicationDto(
                caseId, caseApplicationWithNewApplicationStatus, TEST_BROKER_CLAIMS);
        caseApplicationDtoWithOldApplicationStatus.setApplicationStatus(oldApplicationStatus);

        // simulate retrieving the existing case with old application status from the case client
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), eq(caseId))).thenReturn(caseApplicationDtoWithOldApplicationStatus);

        // set up echo result when updating the case with the case client
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class))).then(returnsSecondArg());

        // update case using case with new application status
        caseService.saveCase(BRAND_DEFAULT, caseId, caseApplicationWithNewApplicationStatus, TEST_BROKER_CLAIMS, false, false);

        verify(mockCaseClient).getCase(eq(BRAND_DEFAULT), eq(caseId));
        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        // check that the old application status was copied to the case DTO used to update the case
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getApplicationStatus()).isEqualTo(oldApplicationStatus);
    }

    @Test
    void saveCaseForUpdateCopiesExistingHasCompletedDip() {
        CaseApplication caseApplicationWithFlag = createValidCaseApplication();
        caseApplicationWithFlag.setHasCompletedDip(true);

        String caseId = caseApplicationWithFlag.getCaseId();

        CaseApplicationDto caseApplicationDtoWithoutFlag = caseApplicationMapper.toCaseApplicationDto(
            caseId, caseApplicationWithFlag, TEST_BROKER_CLAIMS);
        if (caseApplicationDtoWithoutFlag.getJourneyData() == null) {
            caseApplicationDtoWithoutFlag.setJourneyData(new HashMap<>());
        }
        caseApplicationDtoWithoutFlag.getJourneyData().put(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, null);

        // simulate retrieving the existing case from the case client
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), eq(caseId))).thenReturn(caseApplicationDtoWithoutFlag);

        // set up echo result when updating the case with the case client
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class))).then(returnsSecondArg());

        // update case using case with hasCompletedDip flag set
        caseService.saveCase(BRAND_DEFAULT, caseId, caseApplicationWithFlag, TEST_BROKER_CLAIMS, false, false);

        verify(mockCaseClient).getCase(eq(BRAND_DEFAULT), eq(caseId));
        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        // check that the hasCompletedDip flag was not set by the update
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getJourneyData().get(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP)).isEqualTo(null);
    }

    @Test
    void saveCaseForUpdateKeepsReadOnlyDataWhenClearDipResultTrue() {
        CaseApplication caseApplicationWithFlag = createValidCaseApplication();
        caseApplicationWithFlag.setHasCompletedDip(true);

        String caseId = caseApplicationWithFlag.getCaseId();

        CaseApplicationDto caseApplicationDtoWithoutFlag = caseApplicationMapper.toCaseApplicationDto(
            caseId, caseApplicationWithFlag, TEST_BROKER_CLAIMS);
        if (caseApplicationDtoWithoutFlag.getJourneyData() == null) {
            caseApplicationDtoWithoutFlag.setJourneyData(new HashMap<>());
        }
        caseApplicationDtoWithoutFlag.getJourneyData().put(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, true);

        DecisionInPrincipleDto dip = new DecisionInPrincipleDto();
        dip.setDipId("dipId");
        caseApplicationDtoWithoutFlag.setDecisionInPrinciples(Arrays.asList(dip));

        BureauCallAddressDto addressDto = BureauCallAddressDto.builder()
            .houseNumber("houseNumber")
            .houseName("houseName")
            .flatNameOrNumber("flat")
            .street("street")
            .town("town")
            .county("county")
            .postcode("postcode")
            .country("country")
            .build();

        BureauCallInfoDto bureauCallInfo = new BureauCallInfoDto();
        BureauCallApplicantDto bureauApplicant = new BureauCallApplicantDto();
        bureauApplicant.setFirstNames("F");
        bureauApplicant.setLastName("L");
        bureauApplicant.setDateOfBirth("dob");
        bureauApplicant.setAddresses(Collections.singletonList(addressDto));
        bureauCallInfo.setApplicants(Arrays.asList(bureauApplicant));
        caseApplicationDtoWithoutFlag.getJourneyData().put(CASE_JOURNEY_DATA_BUREAU_CALL_INFO, bureauCallInfo);

        String submittedDateTime = "submittedDateTime";
        caseApplicationDtoWithoutFlag.getJourneyData().put(CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME, submittedDateTime);
        String amendedDateTime = "amendedDateTime";
        caseApplicationDtoWithoutFlag.getJourneyData().put(CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME, amendedDateTime);

        // simulate retrieving the existing case from the case client
        when(mockCaseClient.getCase(eq(BRAND_DEFAULT), eq(caseId))).thenReturn(caseApplicationDtoWithoutFlag);

        // set up echo result when updating the case with the case client
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any(CaseApplicationDto.class))).then(returnsSecondArg());

        // update case using case with hasCompletedDip flag set
        caseService.saveCase(BRAND_DEFAULT, caseId, caseApplicationWithFlag, TEST_BROKER_CLAIMS, false, true);

        verify(mockCaseClient).getCase(eq(BRAND_DEFAULT), eq(caseId));
        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(mockCaseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoArgumentCaptor.capture());

        assertThat(caseApplicationDtoArgumentCaptor.getValue().getDecisionInPrinciples()).isEqualTo(Arrays.asList(dip));
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getJourneyData().get(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP)).isEqualTo(true);
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getJourneyData().get(CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME)).isEqualTo(submittedDateTime);
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getJourneyData().get(CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME)).isEqualTo(amendedDateTime);
        assertThat(caseApplicationDtoArgumentCaptor.getValue().getJourneyData().get(CASE_JOURNEY_DATA_BUREAU_CALL_INFO)).isEqualTo(bureauCallInfo);
    }

    @Test
    void generateCaseIdUserNotBrokerPermissionDeniedExceptionException() {
        when(accessPermissionChecker.isBroker()).thenReturn(false);
        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () ->  caseService.generateCaseId(BRAND_DEFAULT));

        assertEquals(MSG_NO_GENERATE_CASE_ID_PERMISSION, ex.getMessage());
    }
}
