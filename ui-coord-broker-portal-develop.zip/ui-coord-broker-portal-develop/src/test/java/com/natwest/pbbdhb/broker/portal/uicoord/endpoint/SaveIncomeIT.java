package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.createBasicBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.saveBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidIncome;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import io.restassured.RestAssured;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class SaveIncomeIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

  @Test
  public void saveBrokerCaseCreatesAndUpdatesIncome() {
    BrokerCase brokerCase = createBasicBrokerCase(tokenConfig);
    String caseId = brokerCase.getCaseApplication().getCaseId();

    List<String> applicantIds = brokerCase.getApplicants().stream()
        .map(Applicant::getApplicantId)
        .collect(Collectors.toList());

    brokerCase.setIncome(createValidIncome(applicantIds));
    // set version to null to trigger creating a new income record
    brokerCase.getIncome().setVersion(null);

    BrokerCase brokerCaseWithIncome = saveBrokerCase(caseId, brokerCase, tokenConfig);
    assertNotNull(brokerCaseWithIncome.getIncome());

    String newEmployerName = "new employer name";

    // change a value in the income
    JobDetails primaryJob = brokerCaseWithIncome.getIncome().getApplicants().get(0).getPrimaryJob();
    // check employer name is not already set to the 'new' employer name
    assertNotEquals(newEmployerName, primaryJob.getEmployerName());
    primaryJob.setEmployerName(newEmployerName);

    BrokerCase brokerCaseAfterIncomeUpdate = saveBrokerCase(caseId, brokerCaseWithIncome, tokenConfig);
    assertEquals(newEmployerName, brokerCaseAfterIncomeUpdate.getIncome().getApplicants().get(0).getPrimaryJob().getEmployerName());

    assertThat(brokerCaseAfterIncomeUpdate)
        .usingRecursiveComparison()
        .ignoringFields("caseApplication.version", "applicants.version", "income.version")
        .isEqualTo(brokerCaseWithIncome);
  }

  @Test
  public void saveBrokerCaseCreatesAndUpdatesIncomeWithPreviousJobs() {
    BrokerCase brokerCase = createBasicBrokerCase(tokenConfig);
    String caseId = brokerCase.getCaseApplication().getCaseId();

    List<String> applicantIds = brokerCase.getApplicants().stream()
        .map(Applicant::getApplicantId)
        .collect(Collectors.toList());

    brokerCase.setIncome(createValidIncome(applicantIds));
    // set version to null to trigger creating a new income record
    brokerCase.getIncome().setVersion(null);

    assertNotNull(brokerCase.getIncome().getApplicants().get(0).getPreviousJobDetails().get(0));

    BrokerCase brokerCaseCreated = saveBrokerCase(caseId, brokerCase, tokenConfig);

    assertNotNull(brokerCaseCreated.getIncome().getApplicants().get(0).getPreviousJobDetails().get(0));
  }
}
