package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.getNewCaseId;
import static com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoServiceIT.EXPECTED_CRM_USER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.readCaseApplicationFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.readBrokerCaseFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class SaveCaseIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/cases/save-case-create-request.json")
    private Resource saveCaseCreateRequest;

    @Value("classpath:test-files/cases/save-case-create-response.json")
    private Resource saveCaseCreateResponse;

    @Value("classpath:test-files/cases/save-case-update-request.json")
    private Resource saveCaseUpdateRequest;

    @Value("classpath:test-files/cases/save-case-update-response.json")
    private Resource saveCaseUpdateResponse;

    @Value("classpath:test-files/cases/save-case-max-term-create-request.json")
    private Resource saveCaseMaxTermCreateRequest;

    @Value("classpath:test-files/cases/save-case-max-term-create-response.json")
    private Resource saveCaseMaxTermCreateResponse;

    @Value("classpath:test-files/cases/save-case-max-term-update-request.json")
    private Resource saveCaseMaxTermUpdateRequest;

    @Value("classpath:test-files/cases/save-case-max-term-update-response.json")
    private Resource saveCaseMaxTermUpdateResponse;

    @Value("classpath:test-files/broker-cases/save-interest-only-broker-case-create-request.json")
    private Resource saveBrokerCaseCreateInterestOnlyMortgageRequest;

    @Value("classpath:test-files/broker-cases/save-interest-only-broker-case-create-response.json")
    private Resource saveBrokerCaseCreateInterestOnlyMortgageResponse;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void saveCaseCreatesAndUpdatesCase() throws IOException {
        String caseId = getNewCaseId(tokenConfig);
        assertThat(caseId).isNotEmpty();

        CaseApplication createRequest = readCaseApplicationFromResource(saveCaseCreateRequest);
        CaseApplication expectedCreateResponse = readCaseApplicationFromResource(saveCaseCreateResponse);
        expectedCreateResponse.setCaseId(caseId);

        Response response = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(createRequest)
                .put(PATH_SAVE_CASE);

        log.info(response.getBody().asPrettyString());

        CaseApplication createResult = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        expectedCreateResponse.getMortgage().getOtherProperties().get(0).setId(createResult.getMortgage().getOtherProperties().get(0).getId());

        assertThat(createResult.getCaseId()).isEqualTo(caseId);
        assertThat(createResult).usingRecursiveComparison().ignoringExpectedNullFields().isEqualTo(expectedCreateResponse);

        CaseApplication updateRequest = readCaseApplicationFromResource(saveCaseUpdateRequest);
        updateRequest.setCaseId(caseId);
        updateRequest.setVersion(createResult.getVersion());
        updateRequest.getMortgage().getOtherProperties().get(0).setId(createResult.getMortgage().getOtherProperties().get(0).getId());

        CaseApplication expectedUpdateResponse = readCaseApplicationFromResource(saveCaseUpdateResponse);
        expectedUpdateResponse.setCaseId(caseId);
        expectedUpdateResponse.getMortgage().getOtherProperties().get(0).setId(createResult.getMortgage().getOtherProperties().get(0).getId());

        Response updateResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(updateRequest)
                .put(PATH_SAVE_CASE);

        log.info(updateResponse.body().asPrettyString());

        CaseApplication updateResult = updateResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        assertThat(updateResult.getCaseId()).isEqualTo(caseId);
        assertThat(updateResult).usingRecursiveComparison().ignoringExpectedNullFields().isEqualTo(expectedUpdateResponse);
    }

    @Test
    public void saveCaseCreatesMaxTermCase() throws IOException {
        String caseId = getNewCaseId(tokenConfig);
        assertThat(caseId).isNotEmpty();

        CaseApplication createRequest = readCaseApplicationFromResource(saveCaseMaxTermCreateRequest);
        CaseApplication expectedCreateResponse = readCaseApplicationFromResource(saveCaseMaxTermCreateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(createRequest)
                .put(PATH_SAVE_CASE);

        log.info(response.body().asPrettyString());

        CaseApplication createResult = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        assertThat(createResult.getCaseId()).isEqualTo(caseId);
        assertThat(createResult).usingRecursiveComparison().ignoringExpectedNullFields().isEqualTo(expectedCreateResponse);
    }

    @Test
    public void saveCaseUpdatesMaxTermCase() throws IOException {
        String caseId = getNewCaseId(tokenConfig);
        assertThat(caseId).isNotEmpty();

        CaseApplication createRequest = readCaseApplicationFromResource(saveCaseCreateRequest);

        Response response = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(createRequest)
                .put(PATH_SAVE_CASE);

        log.info(response.body().asPrettyString());

        CaseApplication createResult = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        CaseApplication updateRequest = readCaseApplicationFromResource(saveCaseMaxTermUpdateRequest);
        updateRequest.setCaseId(caseId);
        CaseApplication expectedUpdateResponse = readCaseApplicationFromResource(saveCaseMaxTermUpdateResponse);

        Response updateResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(updateRequest)
                .put(PATH_SAVE_CASE);

        log.info(updateResponse.body().asPrettyString());

        CaseApplication updateResult = updateResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        assertThat(createResult.getCaseId()).isEqualTo(caseId);
        assertThat(updateResult).usingRecursiveComparison().ignoringExpectedNullFields().isEqualTo(expectedUpdateResponse);
    }

    @Test
    public void saveBrokerCaseCreatesInterestOnlyMortgage() throws IOException {
        String caseId = getNewCaseId(tokenConfig);
        assertThat(caseId).isNotEmpty();

        BrokerCase createRequest = readBrokerCaseFromResource(saveBrokerCaseCreateInterestOnlyMortgageRequest);
        BrokerCase expectedCreateResponse = readBrokerCaseFromResource(saveBrokerCaseCreateInterestOnlyMortgageResponse);
        expectedCreateResponse.getCaseApplication().setCaseId(caseId);

        Response createResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(createRequest)
                .put(PATH_SAVE_BROKER_CASE);

        log.info(createResponse.body().asPrettyString());

        BrokerCase createResult = createResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        expectedCreateResponse.getCaseApplication().getMortgage().getOtherProperties().get(0).setId(createResult.getCaseApplication().getMortgage().getOtherProperties().get(0).getId());

        assertThat(createResult).usingRecursiveComparison().ignoringExpectedNullFields().isEqualTo(expectedCreateResponse);
    }
}
