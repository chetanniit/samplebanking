package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_APPLICANT_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicantDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.constructExpectedHeaders;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApplicantClientNapoliTest {

    private static final String TEST_ENDPOINT_GET = "http://test.endpoint/applicants/case/{caseId}";
    private static final String TEST_ENDPOINT_CREATE = "http://test.endpoint/applicants";
    private static final String TEST_ENDPOINT_UPDATE = "http://test.endpoint/applicants/{applicantId}";

    @Mock
    private RestTemplate mockRestTemplate;

    private ApplicantClientNapoli applicantClient;

    @BeforeEach
    void setUp() {
        this.applicantClient = new ApplicantClientNapoli(TEST_ENDPOINT_GET, TEST_ENDPOINT_CREATE, TEST_ENDPOINT_UPDATE, mockRestTemplate);
    }

    @Test
    void saveApplicantMakesPostCallWhenApplicantIdMissing() {
        ApplicantDto applicantDtoToSave = createValidApplicantDto();
        applicantDtoToSave.setApplicantId(null);

        ApplicantDto expectedApplicantDtoResponse = createValidApplicantDto();
        ResponseEntity<ApplicantDto> expectedResponseEntity = ResponseEntity.ok(expectedApplicantDtoResponse);
        HttpEntity<ApplicantDto> expectedHttpEntity = new HttpEntity<>(applicantDtoToSave, constructExpectedHeaders());
        when(mockRestTemplate.exchange(URI.create(TEST_ENDPOINT_CREATE), HttpMethod.POST, expectedHttpEntity, ApplicantDto.class))
                .thenReturn(expectedResponseEntity);

        ApplicantDto applicantDtoResponse = this.applicantClient.saveApplicant(BRAND_DEFAULT, applicantDtoToSave);

        assertEquals(expectedApplicantDtoResponse, applicantDtoResponse);
    }

    @Test
    void saveApplicantMakesPutCallWhenApplicantIdPresent() {
        ApplicantDto applicantDtoToSave = createValidApplicantDto();

        ApplicantDto expectedApplicantDtoResponse = createValidApplicantDto();
        ResponseEntity<ApplicantDto> expectedResponseEntity = ResponseEntity.ok(expectedApplicantDtoResponse);
        HttpEntity<ApplicantDto> expectedHttpEntity = new HttpEntity<>(applicantDtoToSave, constructExpectedHeaders());
        URI expectedEndpoint = URI.create(TEST_ENDPOINT_UPDATE.replace("{applicantId}", TEST_APPLICANT_ID));
        when(mockRestTemplate.exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, ApplicantDto.class))
                .thenReturn(expectedResponseEntity);

        ApplicantDto applicantDtoResponse = this.applicantClient.saveApplicant(BRAND_DEFAULT, applicantDtoToSave);

        assertEquals(expectedApplicantDtoResponse, applicantDtoResponse);
    }

    @Test
    void saveApplicantBadRequestErrorReceivedFromPostCallIsPassedToTheCaller() {
        ApplicantDto applicantDtoToSave = createValidApplicantDto();
        applicantDtoToSave.setApplicantId(null);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(ApplicantDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> applicantClient.saveApplicant(BRAND_DEFAULT, applicantDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void saveApplicantBadRequestErrorReceivedFromPutCallIsPassedToTheCaller() {
        ApplicantDto applicantDtoToSave = createValidApplicantDto();

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(ApplicantDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> applicantClient.saveApplicant(BRAND_DEFAULT, applicantDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void getApplicantReturnsEmptyListOn404Error() {
        HttpClientErrorException notFoundException = HttpClientErrorException.create(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.getReasonPhrase(), new HttpHeaders(), null, null);
        when(mockRestTemplate.exchange(any(), any(), any(), ArgumentMatchers.<ParameterizedTypeReference<ApplicantDto>>any())).thenThrow(notFoundException);

        List<ApplicantDto> applicants = applicantClient.getApplicants(BRAND_DEFAULT, TEST_CASE_ID);
        assertEquals(0, applicants.size());
    }
}