package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

public class RepaymentDetailValidationTest extends AbstractValidationTest<RepaymentDetail> {
    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid repayment detail", (Consumer<RepaymentDetail>) a -> {/* no-op */}, EMPTY_SET),
                Arguments.of("Valid repayment detail with repayment value 99999999", (Consumer<RepaymentDetail>) a -> a.setRepaymentValue(99_999_999L), EMPTY_SET),
                Arguments.of("Repayment value is above maximum value", (Consumer<RepaymentDetail>) a -> a.setRepaymentValue(100_000_000L), singleton(create("repaymentValue", "must be less than or equal to 99999999"))),
                Arguments.of("Repayment value is below minimum value", (Consumer<RepaymentDetail>) a -> a.setRepaymentValue(-1L), singleton(create("repaymentValue", "must be greater than or equal to 0"))),
                Arguments.of("Repayment strategy type invalid", (Consumer<RepaymentDetail>) a -> a.setRepaymentStrategyType("invalid"), singleton(create("repaymentStrategyType", "must be any of: MAIN_RESIDENCE, NOT_MAIN_RESIDENCE, OTHER_MORTGAGE_PROPERTY, UNENCUMBERED_MAIN_RESIDENCE, UNENCUMBERED_OTHER_TERRACED, SALE_OF_PROPERTY, STOCK_SHARES, UNIT_TRUSTS, OEIC, ICVC, PENSION, SAVING, OTHER_ASSETS, ENDOWMENT"))),
                Arguments.of("Repayment maturity date in past", (Consumer<RepaymentDetail>) a -> a.setRepaymentMaturityDate("2000-01-01"), singleton(create("repaymentMaturityDate", "must be a date in the future in format 'yyyy-MM-dd'"))),
                Arguments.of("Repayment provider too large", (Consumer<RepaymentDetail>) a -> a.setRepaymentProvider(randomAlphabetic(51)), singleton(create("repaymentProvider", "size must be between 0 and 50"))),
                Arguments.of("Repayment monthly payment is above maximum value", (Consumer<RepaymentDetail>) a -> a.setRepaymentMonthlyPayment(100_000_000L), singleton(create("repaymentMonthlyPayment", "must be less than or equal to 99999999"))),
                Arguments.of("Repayment monthly payment is below minimum value", (Consumer<RepaymentDetail>) a -> a.setRepaymentMonthlyPayment(-1L), singleton(create("repaymentMonthlyPayment", "must be greater than or equal to 0"))),
                Arguments.of("Repayment reference too large", (Consumer<RepaymentDetail>) a -> a.setRepaymentReference(randomAlphabetic(41)), singleton(create("repaymentReference", "size must be between 0 and 40"))),
                Arguments.of("Originating currency accepts EUR", (Consumer<RepaymentDetail>) a -> a.setOriginatingCurrency("EUR"), EMPTY_SET),
                Arguments.of("Originating currency is invalid", (Consumer<RepaymentDetail>) a -> a.setOriginatingCurrency("EURO"), singleton(create("originatingCurrency","must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testRepaymentDetailValidations(String testDescription, Consumer<RepaymentDetail> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidRepaymentDetail, mutator, expectedErrorMessages);
    }


}
