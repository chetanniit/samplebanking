package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.security.StubUserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.CaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicant;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidCaseApplication;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {CaseController.class, ControllerAdvice.class, StubUserClaimsProvider.class})
public class CaseControllerValidationTest {

    @MockBean
    private CaseService caseService;

    @MockBean
    private BrokerInfoService brokerInfoService;

    @MockBean
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate iamJwtChainSecureRestTemplate;

    @MockBean
    @Qualifier("sslRestTemplate")
    private RestTemplate sslRestTemplate;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    public void beforeEach() {
        when(brokerInfoService.getBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfo());
    }

    @Test
    public void getCaseIdValidRequestWithProvidedBrand() throws Exception {
        when(caseService.generateCaseId(BRAND_RBS)).thenReturn(TEST_CASE_ID);

        RequestBuilder request = get(PATH_GET_CASE_ID)
                .header(BRAND_HEADER, BRAND_RBS);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MEDIA_TYPE_TEXT_PLAIN_UTF8))
                .andExpect(content().string(TEST_CASE_ID));
    }

    @Test
    public void getCaseIdValidRequestWithDefaultBrand() throws Exception {
        when(caseService.generateCaseId(BRAND_DEFAULT)).thenReturn(TEST_CASE_ID);

        RequestBuilder request = get(PATH_GET_CASE_ID);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MEDIA_TYPE_TEXT_PLAIN_UTF8))
                .andExpect(content().string(TEST_CASE_ID));
    }

    @Test
    public void getCaseIdInvalidRequestWithInvalidBrand() throws Exception {
        RequestBuilder request = get(PATH_GET_CASE_ID)
                .header(BRAND_HEADER, "invalid");

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("getCaseId.brand"))
            .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

        verifyNoInteractions(this.caseService);
    }

    @Test
    public void getCaseIdBadRequestErrorReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        String body = "{\"errorCount\":2,\"errors\":[{\"object\":\"object1\",\"field\":\"field1\",\"message\":\"message1\"},{\"field\":\"field2\",\"message\":\"message2\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(caseService.generateCaseId(anyString())).thenThrow(badRequestException);

        RequestBuilder request = get(PATH_GET_CASE_ID);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("400"))
                .andExpect(jsonPath("$.title").value("Bad Request"))
                .andExpect(jsonPath("$.description").value("The following errors occurred"))
                .andExpect(jsonPath("$.errors[0].title").value("field1"))
                .andExpect(jsonPath("$.errors[0].description").value("message1"))
                .andExpect(jsonPath("$.errors[1].title").value("field2"))
                .andExpect(jsonPath("$.errors[1].description").value("message2"));
    }

    @Test
    public void getCaseIdBadRequestErrorReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(caseService.generateCaseId(anyString())).thenThrow(badRequestException);

        RequestBuilder request = get(PATH_GET_CASE_ID);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("400"))
                .andExpect(jsonPath("$.title").value("Bad Request"))
                .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @Test
    public void saveCaseForCreateValidRequest() throws Exception {
        CaseApplication caseApplicationRequest = createValidCaseApplication();
        caseApplicationRequest.setVersion(null);
        String requestBodyContent = this.objectMapper.writeValueAsString(caseApplicationRequest);
        CaseApplication caseApplicationResponse = createValidCaseApplication();
        String responseBodyContent = this.objectMapper.writeValueAsString(caseApplicationResponse);
        when(caseService.saveCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(caseApplicationRequest),
                any(), eq(true), eq(false))).thenReturn(caseApplicationResponse);

        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }

    @Test
    public void saveCaseMissingCaseIdReturnsNotFoundError() throws Exception {
        RequestBuilder request = put(PATH_SAVE_CASE, (String) null)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(this.objectMapper.writeValueAsString(createValidApplicant()));

        this.mockMvc.perform(request)
                .andExpect(status().isNotFound());
    }

    @Test
    public void saveCaseInvalidContentTypeReturnsUnsupportedMediaTypeError() throws Exception {
        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("text");

        this.mockMvc.perform(request)
                .andExpect(status().isUnsupportedMediaType());
    }


    @Test
    public void saveCaseForUpdateBadRequestErrorReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        CaseApplication caseApplicationRequest = createValidCaseApplication();
        String requestBodyContent = this.objectMapper.writeValueAsString(caseApplicationRequest);

        String body = "{\"errorCount\":2,\"errors\":[{\"object\":\"object1\",\"field\":\"field1\",\"message\":\"message1\"},{\"field\":\"field2\",\"message\":\"message2\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(caseService.saveCase(anyString(), anyString(), any(CaseApplication.class), any(BrokerInfo.class), eq(false), eq(false))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("400"))
                .andExpect(jsonPath("$.title").value("Bad Request"))
                .andExpect(jsonPath("$.description").value("The following errors occurred"))
                .andExpect(jsonPath("$.errors[0].title").value("field1"))
                .andExpect(jsonPath("$.errors[0].description").value("message1"))
                .andExpect(jsonPath("$.errors[1].title").value("field2"))
                .andExpect(jsonPath("$.errors[1].description").value("message2"));
    }

    @Test
    public void saveCaseForCreateBadRequestErrorReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        CaseApplication caseApplicationRequest = createValidCaseApplication();
        caseApplicationRequest.setVersion(null);
        String requestBodyContent = this.objectMapper.writeValueAsString(caseApplicationRequest);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(caseService.saveCase(anyString(), anyString(), any(CaseApplication.class), any(BrokerInfo.class), eq(true), eq(false))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Bad Request"))
            .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @Test
    public void saveCaseForUpdateConflictReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        CaseApplication caseApplicationRequest = createValidCaseApplication();
        String requestBodyContent = this.objectMapper.writeValueAsString(caseApplicationRequest);

        String body = "{\"errorCount\":1,\"errors\":[{\"message\":\"message1\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.CONFLICT, HttpStatus.CONFLICT.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(caseService.saveCase(anyString(), anyString(), any(CaseApplication.class), any(BrokerInfo.class), eq(false), eq(false))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isConflict())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("409"))
            .andExpect(jsonPath("$.title").value("Conflict"))
            .andExpect(jsonPath("$.description").value("The following errors occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("Error"))
            .andExpect(jsonPath("$.errors[0].description").value("message1"));
    }

    @Test
    public void saveCaseForUpdateConflictReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        CaseApplication caseApplicationRequest = createValidCaseApplication();
        String requestBodyContent = this.objectMapper.writeValueAsString(caseApplicationRequest);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.CONFLICT, HttpStatus.CONFLICT.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(caseService.saveCase(anyString(), anyString(), any(CaseApplication.class), any(BrokerInfo.class), eq(false), eq(false))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isConflict())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("409"))
                .andExpect(jsonPath("$.title").value("Conflict"))
                .andExpect(jsonPath("$.description").value( CUSTOM_HTTP_BODY));
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("saveCaseArgs")
    public void saveCaseRequestWithValidationErrorsReturnsBadRequestError(String testDescription, Consumer<CaseApplication> mutator,
                                                                          ErrorResponse expected) throws Exception {
        CaseApplication caseApplicationRequest = createValidCaseApplication();
        mutator.accept(caseApplicationRequest);

        RequestBuilder request = put(PATH_SAVE_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.objectMapper.writeValueAsString(caseApplicationRequest));

        MvcResult mvcResult = this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        ErrorResponse response = this.objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ErrorResponse.class);
        assertThat(response)
                .usingRecursiveComparison()
                .ignoringCollectionOrder()
                .isEqualTo(expected);
    }

    private static Stream<Arguments> saveCaseArgs() {
        return Stream.of(
                Arguments.of("Mortgage advised invalid", (Consumer<CaseApplication>) a -> a.getMortgage().setMortgageAdvised("invalid"),
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("mortgage.mortgageAdvised", "must be any of: ADVICE, REJECTED_ADVICE_EXECUTION_ONLY")))),
                Arguments.of("Mortgage term is above maximum value 40 years and 0 months", (Consumer<CaseApplication>) a -> {
                    a.getMortgage().setMortgageTermYears(40);
                    a.getMortgage().setMortgageTermMonths(1);
                },
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("mortgage", "'mortgageTermMonths' value cannot be greater than 0 when 'mortgageTermYears' equals 40"))))
        );
    }
}
