package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisCaseDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.commondictionaries.enums.cases.MortgageAdvised;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import org.springframework.test.context.ActiveProfiles;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.HELP_TO_BUY_SHARED_EQUITY;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.OTHER;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.RIGHT_TO_BUY;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.SHARED_EQUITY;
import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.FIRST_TIME_BUYER;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class EsisCaseMapperTest {

  @Mock
  EsisProductMapper esisProductMapper;

  @InjectMocks
  EsisCaseMapper esisCaseMapper;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  BrokerInfo broker;
  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  EsisData esisData;
  @Mock(answer = Answers.RETURNS_DEFAULTS)
  PaymentPath paymentPath;
  final String caseId = "caseId";

  @BeforeEach
  void setupPaymentPath() {
    when(esisData.getCaseDetails().getPaymentPathId())
        .thenReturn("1");
    when(broker.getPaymentPaths())
        .thenReturn(singletonList(paymentPath));
    when(paymentPath.getPaymentPathId())
        .thenReturn(1);
    when(paymentPath.getPaymentPathName())
        .thenReturn("paymentPathName");
    when(paymentPath.getPaymentPathScaleResidential())
        .thenReturn("paymentPathScale");
  }

  @BeforeEach
  void setupLoanPurpose() {
    when(esisData.getCaseDetails().getLoanPurpose())
        .thenReturn("PURCHASE");
    when(esisData.getCaseDetails().getApplicationType())
        .thenReturn("RESIDENTIAL");
  }

  @Test
  void toCaseApplicationDto_brokerFirmName_tradingNameAsMainSource() {
    when(broker.getFirmDetails().getTradingName()).thenReturn("tradingName");
    when(broker.getFirmDetails().getFirmName()).thenReturn("firmName");
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBroker().getFirmName())
        .isEqualTo("tradingName");
  }

  @Test
  void toCaseApplicationDto_brokerFirmName_firmNameAsSecondSource() {
    when(broker.getFirmDetails().getTradingName()).thenReturn(null);
    when(broker.getFirmDetails().getFirmName()).thenReturn("firmName");
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBroker().getFirmName())
        .isEqualTo("firmName");
  }

  @Test
  void toCaseApplicationDto_brokerTelephoneNumber_mobilePhoneAsMainSource() {
    when(broker.getBrokerDetails().getMobilePhone()).thenReturn("mobilePhone");
    when(broker.getBrokerDetails().getOtherPhone()).thenReturn("businessPhone");
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBroker().getBrokerTelephoneNumber())
        .isEqualTo("mobilePhone");
  }

  @Test
  void toCaseApplicationDto_brokerTelephoneNumber_businessPhoneAsSecondSource() {
    when(broker.getBrokerDetails().getOtherPhone()).thenReturn("businessPhone");
    when(broker.getBrokerDetails().getMobilePhone()).thenReturn(null);
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBroker().getBrokerTelephoneNumber())
        .isEqualTo("businessPhone");
  }

  @Test
  void toCaseApplicationDto_brokerUsername_isSet() {
    when(broker.getBrokerDetails().getUserName()).thenReturn("brokerUsername");
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBroker().getBrokerUsername())
        .isEqualTo("brokerUsername");
  }

  @Test
  void toCaseApplicationDto_brokerFee_isSet() {
    when(esisData.getCaseDetails().getBrokerFee()).thenReturn(BigDecimal.valueOf(500.00));
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBroker().getDetails().getFee().getAmount())
        .isEqualTo(BigDecimal.valueOf(500.00));
  }

  @Test
  void toCaseApplicationDto_mortgageAdvised() {
    when(esisData.getCaseDetails().getReviewType())
        .thenReturn(EsisCaseDetails.MortgageAdvised.ADVISED.toString());
    assertThat(esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId).getMortgage()
        .getMortgageAdvised())
        .isEqualTo(MortgageAdvised.ADVICE.toString());
    when(esisData.getCaseDetails().getReviewType())
        .thenReturn(EsisCaseDetails.MortgageAdvised.ADVICE_REJECTED.toString());
    assertThat(esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId).getMortgage()
        .getMortgageAdvised())
        .isEqualTo(MortgageAdvised.REJECTED_ADVICE_EXECUTION_ONLY.toString());
    when(esisData.getCaseDetails().getReviewType())
        .thenReturn(EsisCaseDetails.MortgageAdvised.NON_ADVISED.toString());
    assertThat(esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId).getMortgage()
        .getMortgageAdvised())
        .isEqualTo(MortgageAdvised.REJECTED_ADVICE_EXECUTION_ONLY.toString());
    when(esisData.getCaseDetails().getReviewType())
        .thenReturn(EsisCaseDetails.MortgageAdvised.EXECUTION_ONLY.toString());
    assertThat(esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId).getMortgage()
        .getMortgageAdvised())
        .isEqualTo(MortgageAdvised.REJECTED_ADVICE_EXECUTION_ONLY.toString());
  }

  @Test
  void toCaseApplicationDto_scheme_firstTimeBuyer() {
    when(esisData.getMortgageDetails().getFirstTimeBuyer()).thenReturn(true);
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getBuyerType()).isEqualTo(FIRST_TIME_BUYER.name());
  }

  @Test
  void toCaseApplicationDto_scheme_sharedEquity() {
    when(esisData.getMortgageDetails().getSchemeType()).thenReturn(SHARED_EQUITY.value());
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getGovtSharedEquityScheme()).isEqualTo(true);
  }

  @Test
  void toCaseApplicationDto_scheme_helpToBuySharedEquity() {
    when(esisData.getMortgageDetails().getSchemeType())
        .thenReturn(HELP_TO_BUY_SHARED_EQUITY.value());
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getGovtSharedEquityScheme()).isEqualTo(true);
    assertThat(actual.getSchemeType()).isEqualTo("HELP_TO_BUY");
  }

  @Test
  void toCaseApplicationDto_scheme_rightToBuy() {
    when(esisData.getMortgageDetails().getSchemeType()).thenReturn(RIGHT_TO_BUY.value());
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getGovtSharedEquityScheme()).isEqualTo(false);
    assertThat(actual.getSchemeType()).isEqualTo("OTHER");
    assertThat(actual.getSchemeName()).isEqualTo("RIGHT_TO_BUY");
    assertThat(actual.getMortgage().getRightToBuy()).isEqualTo(true);
  }

  @Test
  void toCaseApplicationDto_scheme_other() {
    when(esisData.getMortgageDetails().getSchemeType()).thenReturn(OTHER.value());
    CaseApplicationDto actual = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
    assertThat(actual.getGovtSharedEquityScheme()).isEqualTo(false);
    assertThat(actual.getSchemeType()).isEqualTo("OTHER");
    assertThat(actual.getSchemeName()).isEqualTo("OTHER");
  }
}