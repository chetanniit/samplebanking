package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SUBMIT_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.github.tomakehurst.wiremock.http.HttpHeader;
import com.github.tomakehurst.wiremock.http.HttpHeaders;
import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import com.natwest.pbbdhb.exception.FMAException;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.model.fma.ResponseStatus;
import com.natwest.pbbdhb.openapi.fma.Error;
import com.natwest.pbbdhb.service.IntegrationService;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.io.IOException;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
    "wiremock.reset-mappings-after-each-test=false"})
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
class FmaControllerTest {

  @Value("${server.servlet.context-path}")
  private String contextPath;

  @LocalServerPort
  private int port;

  @Value("classpath:test-files/fma-cases/basic-post-dip-case-response.json")
  private Resource basicPostDipCaseResponseResource;

  @Value("classpath:test-files/fma-cases/basic-post-dip-case-response-with-payment-path.json")
  private Resource basicPostDipWithPaymentPathCaseResponseResource;

  @Value("classpath:test-files/fma-cases/basic-post-dip-case-response-with-estate-agent.json")
  private Resource basicPostDipWithEstateAgentResponseResource;

  @Value("classpath:test-files/fma-cases/basic-income-response.json")
  private Resource basicIncomeResponseResource;

  @Value("classpath:test-files/fma-cases/basic-expenditure-response.json")
  private Resource basicExpenditureResponseResource;

  @Value("classpath:test-files/fma-cases/basic-applicant-response.json")
  private Resource basicApplicantResponseResource;

  @Value("classpath:test-files/fma-cases/400-invalid-payments-path-response.json")
  private Resource invalidPaymentsPathResponse;
  @Value("classpath:test-files/fma-cases/400-invalid-broker-trading-name-response.json")
  private Resource invalidBrokerTradingNameResponse;

  @Value("classpath:test-files/fma-cases/400-invalid-estate-agent-name-response.json")
  private Resource invalidEstateAgentname;
  @Value("classpath:test-files/fma-cases/400-expired-product-response.json")
  private Resource expiredProductResponse;
  @Value("classpath:test-files/fma-cases/400-invalid-foreign-currency-type-response.json")
  private Resource invalidForeignCurrrencyRate;

  @Value("classpath:test-files/fma-cases/500-unhandled-validation-response.json")
  private Resource unhandledValidationResponse;

  @MockBean
  private BrokerInfoClient client;

  @MockBean
  private IntegrationService integrationService;


  @BeforeEach
  public void setUp() {
    RestAssured.baseURI = "http://localhost" + contextPath;
    RestAssured.port = this.port;
  }

  @AfterEach
  public void cleanUp() {
    RestAssured.baseURI = RestAssured.DEFAULT_URI;
    RestAssured.port = RestAssured.UNDEFINED_PORT;
  }

  @Test
  void submitFMAWithCaseThatFailsValidationDueToMissingPaymentPathIdOnCase()
      throws IOException, JSONException {
    String caseId = "test-case-id-x";
    stubCapie(caseId, basicPostDipCaseResponseResource);

    String expectedResponseJson = TestUtil.getResourceText(invalidPaymentsPathResponse);

    Response response = with().pathParam(CASE_ID_PARAM, caseId).header(JWT_HEADER, "someheader")
        .post(PATH_SUBMIT_FMA).then().assertThat().statusCode(HttpStatus.BAD_REQUEST.value())
        .extract()
        .response();

    log.info(response.body().asPrettyString());

    JSONCompareResult compareResult = JSONCompare.compareJSON(expectedResponseJson,
        response.body().asPrettyString(), JSONCompareMode.STRICT);
    assertTrue(compareResult.passed(), compareResult.getMessage());

  }

  @Test
  void submitFMAWithCaseThatFailsValidationDueToNullTradingName()
      throws IOException, JSONException {
    String caseId = "test-case-id-y";
    stubCapie(caseId, basicPostDipWithPaymentPathCaseResponseResource);

    String expectedResponseJson = TestUtil.getResourceText(invalidBrokerTradingNameResponse);

    BrokerInfoResponseDto brokerinfo = BrokerInfoTestUtil.brokerInfoDto();
    brokerinfo.setTradingName(null);

    when(client.readBroker(any()))
        .thenReturn(brokerinfo);

    Response response = with().pathParam(CASE_ID_PARAM, caseId).header(JWT_HEADER, "someheader")
        .post(PATH_SUBMIT_FMA).then().assertThat().statusCode(HttpStatus.BAD_REQUEST.value())
        .extract()
        .response();

    log.info(response.body().asPrettyString());

    JSONCompareResult compareResult = JSONCompare.compareJSON(expectedResponseJson,
        response.body().asPrettyString(), JSONCompareMode.STRICT);
    assertTrue(compareResult.passed(), compareResult.getMessage());

  }

  @Test
  void submitFMAWithCaseThatFailsFmaValidationDueToInvalidProduct()
      throws IOException, JSONException, FMAException {

    String expectedResponseJson = TestUtil.getResourceText(expiredProductResponse);
    submitFmawithValidationError("Product code - NOTREAL is not valid", expectedResponseJson,
        HttpStatus.BAD_REQUEST, basicPostDipWithPaymentPathCaseResponseResource);
  }

  @Test
  void submitFMAWithCaseThatFailsFmaValidationDueToExpiredProduct()
      throws IOException, JSONException, FMAException {

    String expectedResponseJson = TestUtil.getResourceText(expiredProductResponse);
    String productExpiryMessage = "{\\\"productCode\\\":\\\"TO6397\\\",\\\"validProduct\\\":false,\\\"message\\\":\\\"Validation failed, product has been expired\\\"}";
    submitFmawithValidationError(productExpiryMessage, expectedResponseJson, HttpStatus.BAD_REQUEST,
        basicPostDipWithPaymentPathCaseResponseResource);
  }

  @Test
  void submitFMAWithCaseThatFailsFmaValidationDueToUnhandled()
      throws IOException, JSONException, FMAException {

    String expectedResponseJson = TestUtil.getResourceText(unhandledValidationResponse);
    submitFmawithValidationError("unhandled error", expectedResponseJson,
        HttpStatus.INTERNAL_SERVER_ERROR, basicPostDipWithPaymentPathCaseResponseResource);
  }

  @Test
  void submitFMAWithCaseThatFailsFmaValidationDueToInvalidEstateAgentname()
      throws IOException, JSONException, FMAException {

    String expectedResponseJson = TestUtil.getResourceText(invalidEstateAgentname);
    submitFmawithValidationError(
        "Estate agent firm name character limit exceeded, please reduce to a maximum of 45 characters.",
        expectedResponseJson, HttpStatus.BAD_REQUEST, basicPostDipWithEstateAgentResponseResource);
  }

  @Test
  void submitFMAWithCaseThatFailsFmaValidationDueToInvalidCurrencyType()
      throws IOException, JSONException, FMAException {

    String expectedResponseJson = TestUtil.getResourceText(invalidForeignCurrrencyRate);
    submitFmawithValidationError(
        "repayMortgageCurrency is required if application.repayMortgageCurrencyNotSterling = true",
        expectedResponseJson, HttpStatus.BAD_REQUEST, basicPostDipWithPaymentPathCaseResponseResource);
  }


  void submitFmawithValidationError(String message, String expectedResponseJson,
      HttpStatus expectedStatus, Resource resource)
      throws IOException, JSONException, FMAException {
    String caseId = "test-case-id-y";
      stubCapie(caseId, resource);
    FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
    fmaResponse.setResponseStatus(new ResponseStatus("400"));
    fmaResponse.setErrors(Arrays.asList(Error.builder().message(message).build()));
    when(integrationService.getFMA(any())).thenReturn(fmaResponse);

    when(client.readBroker(any()))
        .thenReturn(BrokerInfoTestUtil.brokerInfoDto());

    Response response = with().pathParam(CASE_ID_PARAM, caseId).header(JWT_HEADER, "someheader")
        .post(PATH_SUBMIT_FMA).then().assertThat().statusCode(expectedStatus.value())
        .extract()
        .response();

    log.info(response.body().asPrettyString());

    JSONCompareResult compareResult = JSONCompare.compareJSON(expectedResponseJson,
        response.body().asPrettyString(), JSONCompareMode.STRICT);
    assertTrue(compareResult.passed(), compareResult.getMessage());

  }

  private void stubCapie(String caseId, Resource caseResource) throws IOException {
    String basicResponse = TestUtil.getResourceText(basicExpenditureResponseResource);
    String basicIncomeResponse = TestUtil.getResourceText(basicIncomeResponseResource);
    String basicCaseResponse = TestUtil.getResourceText(caseResource);
    String basicApplicantResponse = TestUtil.getResourceText(basicApplicantResponseResource);

    stub("/v2/applicants/case/" + caseId, basicApplicantResponse);
    stub("/v2/properties/" + caseId, basicResponse);
    stub("/income/" + caseId, basicIncomeResponse);
    stub("/v2/cases/" + caseId, basicCaseResponse);
    stub("/expense/" + caseId, basicResponse);
    stubPut("/v2/cases/" + caseId, basicCaseResponse, HttpStatus.OK);
    stubPut("/v2/cases/" + caseId, basicCaseResponse, HttpStatus.OK);

  }


  private void stub(String pattern, String response) throws IOException {
    stubFor(get(urlPathMatching(pattern)).withHeader(BRAND_HEADER, equalTo(BRAND_DEFAULT))
        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
            .withHeaders(new HttpHeaders(new HttpHeader("Content-Type", "application/json")))
            .withBody(response)));
  }

  private void stubPut(String pattern, String response, HttpStatus status) throws IOException {
    stubFor(put(urlPathMatching(pattern)).withHeader(BRAND_HEADER, equalTo(BRAND_DEFAULT))
        .willReturn(aResponse().withStatus(status.value())
            .withHeaders(new HttpHeaders(new HttpHeader("Content-Type", "application/json")))
            .withBody(response)));
  }


}