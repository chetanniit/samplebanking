package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisBorrowingRequirements;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisCaseDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisRepaymentDetails;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.rbs.pbbdhb.sales.esis.models.Application;
import com.rbs.pbbdhb.sales.esis.models.enums.LevelOfService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.EsisTestUtil.brokerResponseDtoSample;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    EsisMapper.class,
    EsisProductMapper.class
})
class EsisMapperTest {

  @Autowired
  EsisMapper esisMapper;

  EsisData esisData;

  @BeforeEach
  void setupEsisData() {
    EsisData esisData = new EsisData();
    esisData.setBorrowingRequirements(new EsisBorrowingRequirements());
    ProductDto selectedProduct = new ProductDto();
    esisData.setSelectedProduct(selectedProduct);
    selectedProduct.setInitialInterestRate(1.23);
    EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    mortgageDetails.setRepaymentDetails(new EsisRepaymentDetails());
    mortgageDetails.setFirstTimeBuyer(false);
    EsisCaseDetails caseDetails = new EsisCaseDetails();
    esisData.setCaseDetails(caseDetails);
    caseDetails.setPaymentPathId("1");
    caseDetails.setApplicationType("RESIDENTIAL");
    this.esisData = esisData;
  }

  @Test
  void mapToBroker_firmName_usesTradingNameAsSourceOne() {
    BrokerInfo broker = brokerResponseDtoSample();
    broker.getFirmDetails().setTradingName("tradingName");
    broker.getFirmDetails().setFirmName("firmName");
    Application actual = esisMapper.mapToEsisApplication(
        esisData, broker, "caseId", new CaseApplicationDto());
    assertThat(actual.getBroker().getFirmName())
        .isEqualTo("tradingName");
  }

  @Test
  void mapToBroker_firmName_usesFirmNameAsSourceTwo() {
    BrokerInfo broker = brokerResponseDtoSample();
    broker.getFirmDetails().setTradingName(null);
    broker.getFirmDetails().setFirmName("firmName");
    Application actual = esisMapper.mapToEsisApplication(
        esisData, broker, "caseId", new CaseApplicationDto());
    assertThat(actual.getBroker().getFirmName())
        .isEqualTo("firmName");
  }

  @Test
  void mapToBroker_mobilePhoneAsOptionOne() {
    BrokerInfo broker = brokerResponseDtoSample();
    broker.getBrokerDetails().setOtherPhone("businessPhone");
    broker.getBrokerDetails().setMobilePhone("mobilePhone");
    Application actual = esisMapper.mapToEsisApplication(
        esisData, broker, "caseId", new CaseApplicationDto());
    assertThat(actual.getBroker().getBrokerTelephoneNumber())
        .isEqualTo("mobilePhone");
  }

  @Test
  void mapToBroker_businessPhoneAsOptionTwo() {
    BrokerInfo broker = brokerResponseDtoSample();
    broker.getBrokerDetails().setMobilePhone(null);
    broker.getBrokerDetails().setOtherPhone("businessPhone");
    Application actual = esisMapper.mapToEsisApplication(
        esisData, broker, "caseId", new CaseApplicationDto());
    assertThat(actual.getBroker().getBrokerTelephoneNumber())
        .isEqualTo("businessPhone");
  }

  @Test
  void mapToBroker_addressWhenLine2IsPresent() {
    BrokerInfo broker = brokerResponseDtoSample();
    broker.getFirmDetails().getAddress().setLine1("line1");
    broker.getFirmDetails().getAddress().setLine2("line2");
    broker.getFirmDetails().getAddress().setCity("city");
    broker.getFirmDetails().getAddress().setCounty("county");
    broker.getFirmDetails().getAddress().setPostcode("postcode");
    Application actual = esisMapper.mapToEsisApplication(
        esisData, broker, "caseId", new CaseApplicationDto());
    assertThat(actual.getBroker().getFirmAddress1()).isEqualTo("line1");
    assertThat(actual.getBroker().getFirmAddress2()).isEqualTo("line2");
    assertThat(actual.getBroker().getFirmAddress3()).isEqualTo("city");
    assertThat(actual.getBroker().getFirmAddress4()).isEqualTo("county");
    assertThat(actual.getBroker().getFirmPostcode()).isEqualTo("postcode");
  }

  @Test
  void mapToBroker_addressWhenLine2IsNotPresent() {
    BrokerInfo broker = brokerResponseDtoSample();
    broker.getFirmDetails().getAddress().setLine1("line1");
    broker.getFirmDetails().getAddress().setLine2(null);
    broker.getFirmDetails().getAddress().setCity("city");
    broker.getFirmDetails().getAddress().setCounty("county");
    broker.getFirmDetails().getAddress().setPostcode("postcode");
    Application actual = esisMapper.mapToEsisApplication(
        esisData, broker, "caseId", new CaseApplicationDto());
    assertThat(actual.getBroker().getFirmAddress1()).isEqualTo("line1");
    assertThat(actual.getBroker().getFirmAddress2()).isEqualTo("city");
    assertThat(actual.getBroker().getFirmAddress3()).isEqualTo("county");
    assertThat(actual.getBroker().getFirmAddress4()).isEqualTo(null);
    assertThat(actual.getBroker().getFirmPostcode()).isEqualTo("postcode");
  }

  @Test
  void mapToEsisApplication_levelOfService() {
    BrokerInfo broker = brokerResponseDtoSample();
    esisData.getCaseDetails().setReviewType(EsisCaseDetails.MortgageAdvised.ADVISED.toString());
    assertThat(esisMapper.mapToEsisApplication(esisData, broker, "caseId", new CaseApplicationDto())
        .getLevelOfService())
        .isEqualTo(LevelOfService.ADVISED.toString());
    esisData.getCaseDetails()
        .setReviewType(EsisCaseDetails.MortgageAdvised.ADVICE_REJECTED.toString());
    assertThat(esisMapper.mapToEsisApplication(esisData, broker, "caseId", new CaseApplicationDto())
        .getLevelOfService())
        .isEqualTo(LevelOfService.ADVICE_REJECTED.toString());
    esisData.getCaseDetails().setReviewType(EsisCaseDetails.MortgageAdvised.NON_ADVISED.toString());
    assertThat(esisMapper.mapToEsisApplication(esisData, broker, "caseId", new CaseApplicationDto())
        .getLevelOfService())
        .isEqualTo(LevelOfService.NON_ADVISED.toString());
    esisData.getCaseDetails()
        .setReviewType(EsisCaseDetails.MortgageAdvised.EXECUTION_ONLY.toString());
    assertThat(esisMapper.mapToEsisApplication(esisData, broker, "caseId", new CaseApplicationDto())
        .getLevelOfService())
        .isEqualTo(LevelOfService.EXECUTION_ONLY.toString());
  }

  @Test
  void mapToEsisApplication_scheme_firstTimeBuyer() {
    esisData.getMortgageDetails().setFirstTimeBuyer(true);
    Application actual = esisMapper
        .mapToEsisApplication(esisData, brokerResponseDtoSample(), "caseId",
            new CaseApplicationDto());
    assertThat(actual.getBuyerType()).isEqualTo("FIRST_TIME_BUYER");
  }

  @Test
  void mapToEsisApplication_scheme_rightToBuy() {
    esisData.getMortgageDetails()
        .setSchemeType(EsisMortgageDetails.SchemeType.RIGHT_TO_BUY.value());
    Application actual = esisMapper
        .mapToEsisApplication(esisData, brokerResponseDtoSample(), "caseId",
            new CaseApplicationDto());
    assertThat(actual.getMortgage().getSchemeType()).isEqualTo("RIGHT_TO_BUY");
  }

  @Test
  void mapToEsisApplication_scheme_sharedEquity() {
    esisData.getMortgageDetails()
        .setSchemeType(EsisMortgageDetails.SchemeType.SHARED_EQUITY.value());
    Application actual = esisMapper
        .mapToEsisApplication(esisData, brokerResponseDtoSample(), "caseId",
            new CaseApplicationDto());
    assertThat(actual.getMortgage().getSchemeName()).isEqualTo("SHARED_EQUITY");
  }

  @Test
  void mapToEsisApplication_scheme_helpToBuySharedEquity() {
    esisData.getMortgageDetails()
        .setSchemeType(EsisMortgageDetails.SchemeType.HELP_TO_BUY_SHARED_EQUITY.value());
    Application actual = esisMapper
        .mapToEsisApplication(esisData, brokerResponseDtoSample(), "caseId",
            new CaseApplicationDto());
    assertThat(actual.getMortgage().getSchemeType()).isEqualTo("HELP_TO_BUY");
    assertThat(actual.getMortgage().getSchemeName()).isEqualTo("SHARED_EQUITY");
  }

}