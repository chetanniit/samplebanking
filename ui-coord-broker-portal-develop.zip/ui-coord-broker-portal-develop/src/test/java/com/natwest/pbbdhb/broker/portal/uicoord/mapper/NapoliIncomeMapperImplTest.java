package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_APPLICANT_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidIncome;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidIncomeDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidPartnershipIncome;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidSoleTraderIncome;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidatedCaseIncomeDto;
import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStage;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentType;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import java.util.Comparator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    NapoliIncomeMapperImpl.class,
    JobDetailsMapper.class,
    JobDetailsAutoMapperImpl.class,
    OtherIncomeDetailsMapperImpl.class,
    EmployerAddressMapperImpl.class
})
class NapoliIncomeMapperImplTest {

  @Autowired
  private NapoliIncomeMapper mapper;

  @Test
  void testRoundTripMapping() {
    CaseIncome income = createValidIncome(TEST_APPLICANT_ID);
    CaseIncomeDto incomeDto = this.mapper.toIncomeDto(income);
    CaseIncome roundTripResult = this.mapper.toIncome(
        this.mapper.caseIncomeToValidatedCaseIncomeDto(incomeDto));

    assertThat(roundTripResult).usingRecursiveComparison()
        .ignoringFields("applicants.previousJobDetails",
            "applicants.additionalJobDetails")
        .isEqualTo(income);
  }

  @Test
  void testRoundTripMappingForSoleTrader() {
    CaseIncome income = createValidSoleTraderIncome(TEST_APPLICANT_ID);
    CaseIncomeDto incomeDto = this.mapper.toIncomeDto(income);
    CaseIncome roundTripResult = this.mapper.toIncome(
        this.mapper.caseIncomeToValidatedCaseIncomeDto(incomeDto));

    assertThat(roundTripResult).usingRecursiveComparison()
        .ignoringFields("applicants.previousJobDetails",
            "applicants.additionalJobDetails")
        .isEqualTo(income);
  }

  @Test
  void testRoundTripMappingForPartnership() {
    CaseIncome income = createValidPartnershipIncome(TEST_APPLICANT_ID);
    CaseIncomeDto incomeDto = this.mapper.toIncomeDto(income);
    CaseIncome roundTripResult = this.mapper.toIncome(
        this.mapper.caseIncomeToValidatedCaseIncomeDto(incomeDto));

    assertThat(roundTripResult).usingRecursiveComparison()
        .ignoringFields("applicants.previousJobDetails",
            "applicants.additionalJobDetails")
        .isEqualTo(income);
  }

  @Test
  void toIncomeDtoMapsCorrectly() {
    CaseIncome income = createValidIncome(TEST_APPLICANT_ID);
    CaseIncomeDto incomeDto = this.mapper.toIncomeDto(income);

    assertThat(incomeDto.getVersion()).isEqualTo(Integer.valueOf(income.getVersion()));
    assertThat(incomeDto.getStage()).isEqualTo(CaseStage.DIP);
    EmploymentType employmentType = incomeDto.getApplicants().get(0).getPrimaryJob()
        .getEmploymentType();
    assertThat(employmentType).isEqualTo(EmploymentType.PERMANENT);
    assertThat(incomeDto.getApplicants().get(0).getPrimaryJob().getPreferredEmployerTelephone()
        .getNumber()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getEmployerTelephone());
    assertThat(incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0)
        .getPreferredEmployerTelephone().getNumber()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getEmployerTelephone());
    assertThat(incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0)
        .getEmploymentType()).isEqualTo(EmploymentType.PERMANENT);
    assertThat(incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(1)
        .getEmploymentStartDate().toString())
        .isEqualTo(income.getApplicants().get(0).getAdditionalJobDetails().get(1).getEmploymentStartDate());
    assertThat(incomeDto)
        .usingRecursiveComparison()
        .ignoringFields("version", "stage", "applicants.primaryJob.employmentType",
            "applicants.additionalJobDetails.employmentType",
            "applicants.primaryJob.preferredEmployerTelephone",
            "applicants.additionalJobDetails.preferredEmployerTelephone", "mimoPayslipGroups",
            "applicants.sourceOfIncomeVerification", "applicants.cin",
            "applicants.excludedIncomeReason",
            "applicants.sickPayImpactExplanation", "applicants.otherIncomeTotals",
            "applicants.sickPay", "applicants.parentalLeave",
            "applicants.sickPayImpact", "applicants.breakInEmploymentInLastSixMonths",
            "applicants.jobIncomeTotals", "applicants.primaryJob.reducedBasicPayAnnualIncome",
            "applicants.primaryJob.businessName", "applicants.primaryJob.natureOfBusiness",
            "applicants.primaryJob.additionalEmployerTelephones",
            "applicants.primaryJob.profitExpectedToDecreaseFurther",
            "applicants.primaryJob.yearOneTurnover",
            "applicants.primaryJob.employerAddressSameAsHomeAddress",
            "applicants.primaryJob.decreasingProfitReason",
            "applicants.primaryJob.yearTwoTurnover", "applicants.primaryJob.employmentEndDate",
            "applicants.otherIncome.otherIncome1.otherIncomeFrequency",
            "applicants.otherIncome.otherIncome1.sourceOfIncome",
            "applicants.otherIncome.otherIncome1.otherIncomeCurrency",
            "applicants.otherIncome.otherIncome1.otherIncomeNetAmount",
            "applicants.otherIncome.otherIncome1.sourceOfIncomeCountryCode",
            "applicants.primaryJob.additionalIncome.additionalIncome.frequency",
            "applicants.primaryJob.additionalIncome.additionalIncome.type",
            "applicants.primaryJob.additionalIncome.additionalIncome.currency",
            "applicants.primaryJob.employmentStatus", "applicants.primaryJob.occupationType",
            "applicants.primaryJob.payslipFrequency", "applicants.primaryJob.grossYearTwoProfit",
            "applicants.primaryJob.yearTwoDividendsCurrency",
            "applicants.primaryJob.grossYearOneProfit",
            "applicants.primaryJob.yearOneTurnoverCurrency", "applicants.primaryJob.yearTwoProfitCurrency",
            "applicants.primaryJob.yearOneProfitCurrency",
            "applicants.primaryJob.yearOneDividendsCurrency", "applicants.primaryJob.basicPayAnnualIncomeCurrency",
            "applicants.primaryJob.yearTwoDirectorSalaryCurrency", "applicants.primaryJob.netYearOneTurnover",
            "applicants.primaryJob.netYearOneDirectorSalary", "applicants.primaryJob.yearTwoTurnoverCurrency",
            "applicants.primaryJob.yearOneDirectorSalaryCurrency",
            "applicants.primaryJob.reducedBasicPayAnnualIncomeCurrency",
            "applicants.primaryJob.netReducedBasicPayAnnualIncome", "applicants.primaryJob.netYearTwoTurnover",
            "applicants.additionalJobDetails.additionalIncome.additionalIncome.frequency",
            "applicants.additionalJobDetails.additionalIncome.additionalIncome.type",
            "applicants.additionalJobDetails.additionalIncome.additionalIncome.currency",
            "applicants.additionalJobDetails.employmentStatus",
            "applicants.additionalJobDetails.occupationType",
            "applicants.additionalJobDetails.payslipFrequency",
            "applicants.additionalJobDetails.reducedBasicPayAnnualIncome",
            "applicants.additionalJobDetails.businessName",
            "applicants.additionalJobDetails.natureOfBusiness",
            "applicants.additionalJobDetails.additionalEmployerTelephones",
            "applicants.additionalJobDetails.profitExpectedToDecreaseFurther",
            "applicants.additionalJobDetails.yearOneTurnover",
            "applicants.additionalJobDetails.employerAddressSameAsHomeAddress",
            "applicants.additionalJobDetails.decreasingProfitReason",
            "applicants.additionalJobDetails.yearTwoTurnover",
            "applicants.additionalJobDetails.employmentStartDate",
            "applicants.additionalJobDetails.employmentEndDate",
            "applicants.additionalJobDetails.netYearOneProfit",
            "applicants.additionalJobDetails.netYearTwoDirectorSalary",
            "applicants.additionalJobDetails.netYearOneDividends",
            "applicants.additionalJobDetails.yearOneTurnoverCurrency",
            "applicants.additionalJobDetails.yearTwoProfitCurrency",
            "applicants.additionalJobDetails.netYearTwoDividends",
            "applicants.additionalJobDetails.yearOneProfitCurrency",
            "applicants.additionalJobDetails.yearOneDividendsCurrency",
            "applicants.additionalJobDetails.basicPayAnnualIncomeCurrency",
            "applicants.additionalJobDetails.yearTwoDividendsCurrency",
            "applicants.additionalJobDetails.netBasicPayAnnualIncome",
            "applicants.additionalJobDetails.yearTwoDirectorSalaryCurrency",
            "applicants.additionalJobDetails.grossYearOneProfit",
            "applicants.additionalJobDetails.grossYearTwoProfit",
            "applicants.additionalJobDetails.netYearOneTurnover",
            "applicants.additionalJobDetails.netYearOneDirectorSalary",
            "applicants.additionalJobDetails.yearTwoTurnoverCurrency",
            "applicants.additionalJobDetails.yearOneDirectorSalaryCurrency",
            "applicants.additionalJobDetails.reducedBasicPayAnnualIncomeCurrency",
            "applicants.additionalJobDetails.netReducedBasicPayAnnualIncome",
            "applicants.additionalJobDetails.netYearTwoTurnover",
            "applicants.additionalJobDetails.netYearTwoProfit")
        .isEqualTo(income);
    assertThat(incomeDto.getApplicants().get(0).getOtherIncome().get("otherIncome1")
        .getOtherIncomeFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getOtherIncome().get("otherIncome1")
            .getOtherIncomeFrequency());
    assertThat(incomeDto.getApplicants().get(0).getOtherIncome().get("otherIncome1")
        .getOtherIncomeCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getOtherIncome().get("otherIncome1")
            .getOtherIncomeOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getOtherIncome().get("otherIncome1").getSourceOfIncome()
            .name()).isEqualTo(
        income.getApplicants().get(0).getOtherIncome().get("otherIncome1").getSourceOfIncome());
    assertThat(incomeDto.getApplicants().get(0).getPrimaryJob().getAdditionalIncome()
        .get("additionalIncome").getFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getAdditionalIncome().get("additionalIncome")
            .getFrequency());
    assertThat(incomeDto.getApplicants().get(0).getPrimaryJob().getAdditionalIncome()
        .get("additionalIncome").getType().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getAdditionalIncome().get("additionalIncome")
            .getType());
    assertThat(incomeDto.getApplicants().get(0).getPrimaryJob().getAdditionalIncome()
        .get("additionalIncome").getCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getAdditionalIncome().get("additionalIncome")
            .getOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getEmploymentStatus().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getEmploymentStatus());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getOccupationType().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getOccupationType());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getPayslipFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getPayslipFrequency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome()
            .get("additionalIncome").getFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome()
            .get("additionalIncome").getFrequency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome()
            .get("additionalIncome").getType().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome()
            .get("additionalIncome").getType());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getEmploymentStatus()
            .name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getEmploymentStatus());
    assertThat(incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getOccupationType()
        .name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getOccupationType());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getPayslipFrequency()
            .name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getPayslipFrequency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getGrossYearOneProfit()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearOneNetProfitAfterTax());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getGrossYearTwoProfit()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearTwoNetProfitAfterTax());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getYearOneDividendsCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearOneOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getYearTwoDividendsCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearTwoOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getYearOneDirectorSalaryCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearOneOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getYearTwoDirectorSalaryCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearTwoOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getYearOneProfitCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearOneProfitOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getYearTwoProfitCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearTwoProfitOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getBasicPayAnnualIncomeCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getBasicPayAnnualIncomeOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneProfitCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneProfitOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoProfitCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoProfitOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getBasicPayAnnualIncomeCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getAdditionalJobDetails().get(0).getBasicPayAnnualIncomeOriginatingCurrency());
    assertThat(
            incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome().get("additionalIncome").getCurrency().name()).isEqualTo(
            income.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome().get("additionalIncome").getOriginatingCurrency());
    assertThat(
          incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneDividendsCurrency().name()).isEqualTo(
          income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneOriginatingCurrency());
    assertThat(
          incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoDividendsCurrency().name()).isEqualTo(
          income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoOriginatingCurrency());
    assertThat(
          incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneDirectorSalaryCurrency().name()).isEqualTo(
          income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneOriginatingCurrency());
    assertThat(
          incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoDirectorSalaryCurrency().name()).isEqualTo(
          income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoOriginatingCurrency());
  }

  @Test
  void toIncomeMapsCorrectly() {
    CaseIncomeDto incomeDto = createValidIncomeDto(TEST_APPLICANT_ID);
    CaseIncome income = this.mapper.toIncome(
        this.mapper.caseIncomeToValidatedCaseIncomeDto(incomeDto));

    assertThat(income.getVersion()).isEqualTo(incomeDto.getVersion().toString());
    assertThat(incomeDto).usingRecursiveComparison()
        .withComparatorForType(Comparator.comparing(Enum::name), Enum.class)
        .ignoringFields("stage", "version",
            "applicants.previousJobDetails",
            "applicants.additionalJobDetails",
            "applicants.primaryJob.employmentType",
            "applicants.parentalLeave",
            "applicants.primaryJob.preferredEmployerTelephone",
            "mimoPayslipGroups", "applicants.sourceOfIncomeVerification", "applicants.cin",
            "applicants.excludedIncomeReason", "applicants.sickPayImpactExplanation",
            "applicants.otherIncomeTotals", "applicants.otherIncomeCurrency",
            "applicants.otherIncomeNetAmount", "applicants.sourceOfIncomeCountryCode",
            "applicants.sickPay", "applicants.sickPayImpact",
            "applicants.breakInEmploymentInLastSixMonths", "applicants.jobIncomeTotals",
            "applicants.primaryJob.reducedBasicPayAnnualIncome",
            "applicants.primaryJob.businessName",
            "applicants.primaryJob.natureOfBusiness",
            "applicants.primaryJob.additionalEmployerTelephones",
            "applicants.primaryJob.profitExpectedToDecreaseFurther",
            "applicants.primaryJob.yearOneTurnover",
            "applicants.primaryJob.employerAddressSameAsHomeAddress",
            "applicants.primaryJob.decreasingProfitReason",
            "applicants.primaryJob.yearTwoTurnover", "applicants.primaryJob.employmentEndDate",
            "applicants.otherIncome.otherIncome1.otherIncomeFrequency",
            "applicants.otherIncome.otherIncome1.sourceOfIncome",
            "applicants.otherIncome.otherIncome1.sourceOfIncomeCountryCode",
            "applicants.otherIncome.otherIncome1.otherIncomeCurrency",
            "applicants.primaryJob.additionalIncome.additionalIncome.frequency",
            "applicants.primaryJob.additionalIncome.additionalIncome.type",
            "applicants.primaryJob.additionalIncome.additionalIncome.netAmount",
            "applicants.primaryJob.additionalIncome.additionalIncome.currency",
            "applicants.primaryJob.employmentStatus", "applicants.primaryJob.occupationType",
            "applicants.primaryJob.payslipFrequency", "applicants.primaryJob.netYearOneProfit",
            "applicants.primaryJob.yearOneTurnoverCurrency", "applicants.primaryJob.yearTwoProfitCurrency",
            "applicants.primaryJob.netYearTwoDividends", "applicants.primaryJob.yearOneProfitCurrency",
            "applicants.primaryJob.yearOneDividendsCurrency", "applicants.primaryJob.basicPayAnnualIncomeCurrency",
            "applicants.primaryJob.yearTwoDividendsCurrency", "applicants.primaryJob.yearOneDirectorSalaryCurrency",
            "applicants.primaryJob.yearTwoDirectorSalaryCurrency", "applicants.primaryJob.netYearOneTurnover",
            "applicants.primaryJob.yearTwoTurnoverCurrency", "applicants.primaryJob.reducedBasicPayAnnualIncomeCurrency",
            "applicants.primaryJob.netReducedBasicPayAnnualIncome", "applicants.primaryJob.netYearTwoTurnover",
            "applicants.primaryJob.netYearTwoProfit", "applicants.primaryJob.grossYearOneProfit",
            "applicants.primaryJob.grossYearTwoProfit")
        .isEqualTo(income);
    assertThat(incomeDto.getApplicants().get(0).getOtherIncome().get("otherIncome1")
        .getOtherIncomeFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getOtherIncome().get("otherIncome1")
            .getOtherIncomeFrequency());
    assertThat(
        incomeDto.getApplicants().get(0).getOtherIncome().get("otherIncome1").getSourceOfIncome()
            .name()).isEqualTo(
        income.getApplicants().get(0).getOtherIncome().get("otherIncome1").getSourceOfIncome());
    assertThat(incomeDto.getApplicants().get(0).getPrimaryJob().getAdditionalIncome()
        .get("additionalIncome").getFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getAdditionalIncome().get("additionalIncome")
            .getFrequency());
    assertThat(incomeDto.getApplicants().get(0).getPrimaryJob().getAdditionalIncome()
        .get("additionalIncome").getType().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getAdditionalIncome().get("additionalIncome")
            .getType());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getEmploymentStatus().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getEmploymentStatus());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getOccupationType().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getOccupationType());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getPayslipFrequency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getPayslipFrequency());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getGrossYearOneProfit()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearOneNetProfitAfterTax());
    assertThat(
            incomeDto.getApplicants().get(0).getPrimaryJob().getGrossYearTwoProfit()).isEqualTo(
            income.getApplicants().get(0).getPrimaryJob().getYearTwoNetProfitAfterTax());
    assertThat(incomeDto.getApplicants().get(0).getOtherIncome().get("otherIncome1")
        .getOtherIncomeCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getOtherIncome().get("otherIncome1")
            .getOtherIncomeOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getYearOneDividendsCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getYearOneOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getYearTwoDividendsCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getYearTwoOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getYearOneDirectorSalaryCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getYearOneOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getYearTwoDirectorSalaryCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getYearTwoOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getYearOneProfitCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getYearOneProfitOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getYearTwoProfitCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getYearTwoProfitOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getPrimaryJob().getBasicPayAnnualIncomeCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getPrimaryJob().getBasicPayAnnualIncomeOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneProfitCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneProfitOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoProfitCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoProfitOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getBasicPayAnnualIncomeCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getBasicPayAnnualIncomeOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome().get("additionalIncome").getCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getAdditionalIncome().get("additionalIncome").getOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneDividendsCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoDividendsCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneDirectorSalaryCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearOneOriginatingCurrency());
    assertThat(
        incomeDto.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoDirectorSalaryCurrency().name()).isEqualTo(
        income.getApplicants().get(0).getAdditionalJobDetails().get(0).getYearTwoOriginatingCurrency());
  }


  @Test
  void toIncomeMapsCorrectlyAndPreviousJobDetailsProperlyFiltered() {
    ValidatedCaseIncomeDto validatedCaseIncomeDto = createValidatedCaseIncomeDto("123");
    CaseIncome income = this.mapper.toIncome(validatedCaseIncomeDto);

    assertThat(
        validatedCaseIncomeDto.getApplicants().get(0).getAdditionalJobDetails().size()).isEqualTo(
        2);
    assertThat(income.getApplicants().size()).isEqualTo(1);
    assertThat(income.getApplicants().get(0).getAdditionalJobDetails().size()).isEqualTo(1);
    assertThat(income.getApplicants().get(0).getPreviousJobDetails().size()).isEqualTo(1);
    assertThat(income.getApplicants().get(0).getPreviousJobDetails().get(0)
        .getEmploymentEndDate()).isEqualTo("2020-01-01");
  }

  @Test
  void toIncomeDtoMapsCorrectlyAndPreviousJobDetailsAreMergedIntoAdditional() {
    CaseIncome income = createValidIncome(TEST_APPLICANT_ID);
    assertThat(income.getApplicants().get(0).getPreviousJobDetails().size()).isEqualTo(1);
    assertThat(income.getApplicants().get(0).getAdditionalJobDetails().size()).isEqualTo(1);

    CaseIncomeDto incomeDto = this.mapper.toIncomeDto(income);

    assertThat(incomeDto.getApplicants().get(0).getAdditionalJobDetails().size()).isEqualTo(2);
  }
}
