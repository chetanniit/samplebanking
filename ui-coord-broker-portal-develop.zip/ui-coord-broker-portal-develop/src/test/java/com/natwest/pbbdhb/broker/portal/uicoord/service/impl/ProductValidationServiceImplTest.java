package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_READ_CASE_PERMISSION;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.ProductValidationClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ProductValidationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.CaseService;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ProductValidationServiceImplTest {

  @Mock
  UserClaimsProvider userClaimsProvider;
  @Mock
  AccessPermissionChecker accessPermissionChecker;
  @Mock
  CaseService caseService;
  @Mock
  ProductValidationMapper productValidationMapper;
  @Mock
  ProductValidationClient productValidationClient;

  @InjectMocks
  ProductValidationServiceImpl productValidationService;

  CaseApplication caseApplication;
  ProductDetails productDetails;
  ProductValidationMsvcRequest productValidationMsvcRequest;
  ProductValidationMsvcResponse productValidationMsvcResponse;
  ProductValidationResponse productValidationResponse;

  final String caseId = "testCaseId";
  final String productCode = "testProductCode";
  final String brandArg = "brandArg";
  final String caseIdArg = "caseIdArg";
  final LocalDate productSelectionDate = LocalDate.of(2024, 5, 28);

  @BeforeEach
  void setup() {
    when(userClaimsProvider.getBrokerUsername())
        .thenReturn("brokerUsername");
    when(accessPermissionChecker.isCaseOwner(any(), any()))
        .thenReturn(true);

    productDetails = new ProductDetails();
    productDetails.setProductCode(productCode);
    caseApplication = new CaseApplication();
    caseApplication.setCaseId(caseId);
    caseApplication.setProductDetails(productDetails);
    when(caseService.getCase(any(), any()))
        .thenReturn(caseApplication);

    productValidationMsvcRequest = new ProductValidationMsvcRequest();
    productValidationMsvcRequest.setProductCode(productCode);
    when(productValidationMapper.mapToValidationMsvcRequest(any()))
        .thenReturn(productValidationMsvcRequest);

    productValidationMsvcResponse = ProductValidationMsvcResponse.builder()
        .productCode(productCode)
        .validProduct(true)
        .message("testMessage")
        .jurisdiction("UK")
        .build();
    when(productValidationClient.validateProduct(any(), any()))
        .thenReturn(productValidationMsvcResponse);


    productValidationResponse = ProductValidationResponse.builder()
        .validProduct(true)
        .productCode(productCode)
        .productSelectionDate(productSelectionDate)
        .build();
    when(productValidationMapper.mapToProductValidationResponse(any(), any()))
        .thenReturn(productValidationResponse);
  }

  @Test
  void validateProduct_checksCaseOwner() {
    productValidationService.validateProduct(brandArg, caseIdArg);
    verify(accessPermissionChecker).isCaseOwner(brandArg, caseIdArg);
  }

  @Test
  void validateProduct_loadsCaseFromCaseService() {
    productValidationService.validateProduct(brandArg, caseIdArg);
    verify(caseService).getCase(brandArg, caseIdArg);
  }

  @Test
  void validateProduct_callsValidationClientWithMappedArgs() {
    productValidationService.validateProduct(brandArg, caseIdArg);
    verify(productValidationMapper).mapToValidationMsvcRequest(caseApplication);
    verify(productValidationClient).validateProduct(eq(brandArg),
        eq(productValidationMsvcRequest));
  }

  @Test
  void validateProduct_returnsMappedResponse() {
    ProductValidationResponse response = productValidationService
        .validateProduct(brandArg, caseIdArg);
    verify(productValidationClient).validateProduct(eq(brandArg),
        eq(productValidationMsvcRequest));
    verify(productValidationMapper)
        .mapToProductValidationResponse(eq(productValidationMsvcResponse), eq(caseApplication));

    assertThat(response).isEqualTo(productValidationResponse);
  }

  @Test
  void validateProduct_stopsBrokerWithoutAccess() {
    when(accessPermissionChecker.isCaseOwner(any(), any()))
        .thenReturn(false);
    PermissionDeniedException exception = assertThrows(PermissionDeniedException.class,
        () -> productValidationService.validateProduct(brandArg, caseIdArg));
    assertThat(exception.getDescription()).isEqualTo(MSG_NO_READ_CASE_PERMISSION);
  }

  @Test
  void validateProduct_returnsInvalidProductForCasesWithNoProduct() {
    caseApplication = new CaseApplication();
    caseApplication.setCaseId(caseId);
    caseApplication.setProductDetails(null);
    when(caseService.getCase(any(), any()))
        .thenReturn(caseApplication);

    ProductValidationResponse response = productValidationService
        .validateProduct(brandArg, caseIdArg);

    assertThat(response.getValidProduct()).isFalse();
  }

}