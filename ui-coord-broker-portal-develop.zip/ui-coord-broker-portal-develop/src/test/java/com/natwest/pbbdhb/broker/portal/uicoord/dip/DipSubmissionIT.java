package com.natwest.pbbdhb.broker.portal.uicoord.dip;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil.testCaseNameFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@TestPropertySource("classpath:application-it-dip-submission.properties")
@ExtendWith(SpringExtension.class)
@Slf4j
public class DipSubmissionIT {
    private static final String DIP_SERVICE_NAME = "core-decision-in-principle";
    private static String dipPath = "/mortgages/v2/decision-in-principle";
    private TestInfo testInfo;
    private String testResult;

    @Autowired
    private TokenConfiguration tokenConfig;

    @Value("${decision.in.principle.endpoint}")
    private String decisionInPrincipleEndpoint;

    @Value("${client.id}")
    private String clientId;

    @BeforeEach
    public void setUp(TestInfo testInfo) {
        RestAssured.baseURI = decisionInPrincipleEndpoint;
        RestAssured.port = 443;

        this.testInfo = testInfo;
    }

    @AfterEach
    public void cleanUp() throws IOException {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.DEFAULT_PORT;
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void submitDip(String testCaseName, String dipRequestJson) {
        Response response = with()
                .header("client_id", clientId)
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, DIP_SERVICE_NAME))
                .contentType(APPLICATION_JSON_VALUE)
                .body(dipRequestJson)
                .post(dipPath);

        log.info(response.body().asPrettyString());

        DipExtendedResponse dipResponse = response.then().extract().as(DipExtendedResponse.class);
        String decision = dipResponse.getDecision();
        if ("ACCEPT".equals(decision) || "REFER".equals(decision)) {
            this.testResult = "OK      (" + decision + ")";
        } else {
            this.testResult = "FAILED  (" + decision + ")";
            String errorMessage = "Application declined";

            String errorCode = dipResponse.getErrorCode();
            if (errorCode != null) {
                errorMessage = dipResponse.getErrorMessage();
                if (errorMessage == null) {
                    errorMessage = "DIP response error code " + errorCode;
                }

                this.testResult += "\n";
                this.testResult += errorMessage;
            }
            // TODO: emit policy messages?
            this.testResult += "\n";

            throw new AssertionFailedError(errorMessage);
        }
    }

    private static Stream<Arguments> testCases() throws IOException {
        PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
        Resource[] testCaseResources = resourceResolver.getResources("classpath:dip-test-cases/dip-request/*.json");
        return Arrays.stream(testCaseResources).map(r -> {
            try {
                return Arguments.of(testCaseNameFromResource(r), getResourceText(r));
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        });
    }
}
