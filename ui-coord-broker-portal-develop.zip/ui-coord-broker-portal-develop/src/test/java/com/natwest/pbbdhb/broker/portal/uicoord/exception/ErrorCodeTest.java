package com.natwest.pbbdhb.broker.portal.uicoord.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class ErrorCodeTest {


  @Test
  void fromValueThrowsExceptionForUnsupportedInput() {
    assertThrows(IllegalArgumentException.class, () -> ErrorCode.fromValue("text"));
  }

  @Test
  void fromValueReturnsEnum() {
    assertEquals(ErrorCode.INVALID_PAYMENT_PATH, ErrorCode.fromValue("INVALID_PAYMENT_PATH"));
  }

  @Test
  void toStringReturnsName() {
    assertEquals(ErrorCode.INVALID_PAYMENT_PATH.toString(), ErrorCode.INVALID_PAYMENT_PATH.name());
  }

  @Test
  void getExternalMessageReturnsExternalMessage() {
    assertEquals("Payment path invalid. Please reselect the Payment path.",
        ErrorCode.INVALID_PAYMENT_PATH.getExternalMessage());
  }


}