package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.brand.BrandContextHolder;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerCaseTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.groups.FmaValidationGroup;
import jakarta.validation.groups.Default;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class NwiConditionalModelValidationTest extends AbstractValidationTest<BrokerCase> {
    @BeforeEach
    void setNwiBrandInConntext() {
        BrandContextHolder.setCurrentBrand("nwi");
    }

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid Broker case for nwi", (Consumer<BrokerCase>) a -> {
                }, EMPTY_SET, new Class[]{Default.class}),
                Arguments.of("CaseApplication ukAssociationAddress null", (Consumer<BrokerCase>) a -> {
                    a.getApplicants().get(0).getPersonalDetails().setUkAssociationAddress(null);
                }, singleton(create("applicants[0].personalDetails.ukAssociationAddress", "Required when brand is [nwi].")), new Class[]{FmaValidationGroup.class})
        );


    }


    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void testDepositValidations(String testDescription, Consumer<BrokerCase> mutator, Set<TestValidationError> expectedErrorMessages, Class<?>... groups) {
        testValidations(testDescription, BrokerCaseTestUtil::createValidBrokerCase, mutator, expectedErrorMessages, groups);
    }


    @AfterEach
    void clearBranFromContext() {
        BrandContextHolder.clear();
    }

}
