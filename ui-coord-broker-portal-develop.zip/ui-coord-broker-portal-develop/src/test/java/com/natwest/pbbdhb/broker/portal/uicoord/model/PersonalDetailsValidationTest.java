package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;
import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.google.common.collect.Sets.newHashSet;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getConstraintViolations;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.assertj.core.api.Assertions.assertThat;

class PersonalDetailsValidationTest extends AbstractValidationTest<PersonalDetails> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid personal details", (Consumer<PersonalDetails>) a -> {
                }, EMPTY_SET),
                Arguments.of("Title is null", (Consumer<PersonalDetails>) a -> a.setTitle(null), singleton(create("title", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Title is invalid", (Consumer<PersonalDetails>) a -> a.setTitle("invalid"), singleton(create("title", "must be any of: None, Mr, Mrs, Miss, Ms, Dr, Reverend, Professor, Sir, Lord, Lady, Captain, Major, Colonel, Master, Hon, Mx, Sister, Viscount, Countess, Earl, Other"))),
                Arguments.of("First names is null", (Consumer<PersonalDetails>) a -> a.setFirstNames(null), singleton(create("firstNames", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("First names is empty", (Consumer<PersonalDetails>) a -> a.setFirstNames(""), newHashSet(create("firstNames", MUST_NOT_BE_BLANK_ERROR_MESSAGE), create("firstNames", "size must be between 1 and 15"))),
                Arguments.of("First names is blank", (Consumer<PersonalDetails>) a -> a.setFirstNames(" "), singleton(create("firstNames", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("First names is longer than 15 characters", (Consumer<PersonalDetails>) a -> a.setFirstNames(randomAlphabetic(16)), singleton(create("firstNames", "size must be between 1 and 15"))),
                Arguments.of("Valid middle names is null", (Consumer<PersonalDetails>) a -> a.setMiddleNames(null), EMPTY_SET),
                Arguments.of("Middle names is longer than 25 characters", (Consumer<PersonalDetails>) a -> a.setMiddleNames(randomAlphabetic(26)), singleton(create("middleNames", "size must be between 0 and 25"))),
                Arguments.of("Last name is null", (Consumer<PersonalDetails>) a -> a.setLastName(null), singleton(create("lastName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Last name is empty", (Consumer<PersonalDetails>) a -> a.setLastName(""), newHashSet(create("lastName", MUST_NOT_BE_BLANK_ERROR_MESSAGE), create("lastName", "size must be between 2 and 25"))),
                Arguments.of("Last name is blank", (Consumer<PersonalDetails>) a -> a.setLastName("  "), singleton(create("lastName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Last name is 1 character", (Consumer<PersonalDetails>) a -> a.setLastName(randomAlphabetic(1)), singleton(create("lastName", "size must be between 2 and 25"))),
                Arguments.of("Last name is 2 characters", (Consumer<PersonalDetails>) a -> a.setLastName(randomAlphabetic(2)), EMPTY_SET),
                Arguments.of("Last name is longer than 25 characters", (Consumer<PersonalDetails>) a -> a.setLastName(randomAlphabetic(26)), singleton(create("lastName", "size must be between 2 and 25"))),
                Arguments.of("Date of birth is null", (Consumer<PersonalDetails>) a -> a.setDateOfBirth(null), singleton(create("dateOfBirth", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Date of birth is in invalid format", (Consumer<PersonalDetails>) a -> a.setDateOfBirth("13-11-2000"), singleton(create("dateOfBirth", "must be a date in the past in format 'yyyy-MM-dd'"))),
                Arguments.of("Date of birth is today (invalid)", (Consumer<PersonalDetails>) a -> a.setDateOfBirth(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))), singleton(create("dateOfBirth", "must be a date in the past in format 'yyyy-MM-dd'"))),
                Arguments.of("Nationality is null", (Consumer<PersonalDetails>) a -> a.setNationality(null), singleton(create("nationality", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Nationality is longer than 2 characters", (Consumer<PersonalDetails>) a -> a.setNationality(randomAlphabetic(3)), singleton(create("nationality", "size must be between 0 and 2"))),
                Arguments.of("Gender is invalid", (Consumer<PersonalDetails>) a -> a.setGender("invalid gender"), singleton(create("gender", "must be any of: MALE, FEMALE"))),
                Arguments.of("maritalStatus is invalid", (Consumer<PersonalDetails>) a -> a.setMaritalStatus("invalid maritalStatus"), singleton(create("maritalStatus", "must be any of: DIVORCED, MARRIED, SEPARATED, SINGLE, ENGAGED, WIDOWED, LIVING_WITH_PARTNER, CIVIL_PARTNERSHIP, SURVIVING_CIVIL_PARTNER"))),
                Arguments.of("Valid telephone null", (Consumer<PersonalDetails>) a -> a.setTelephone(null), EMPTY_SET),
                Arguments.of("Email longer than 45 characters and badly formed", (Consumer<PersonalDetails>) a -> a.setEmail(randomAlphabetic(46)), newHashSet(create("email", "size must be between 0 and 45"), create("email", "Badly formed email"))),
                Arguments.of("Email badly formed (. before @)", (Consumer<PersonalDetails>) a -> a.setEmail("test.test@example"), singleton(create("email", "Badly formed email"))),
                Arguments.of("Email badly formed no @)", (Consumer<PersonalDetails>) a -> a.setEmail("test.test"), singleton(create("email", "Badly formed email"))),
                Arguments.of("Email badly formed no .)", (Consumer<PersonalDetails>) a -> a.setEmail("test@test"), singleton(create("email", "Badly formed email"))),
                Arguments.of("Valid email", (Consumer<PersonalDetails>) a -> a.setEmail("test@example.com"), EMPTY_SET),
                Arguments.of("Too many additionalNationalities", (Consumer<PersonalDetails>) a -> a.setAdditionalNationalities(new ArrayList<>(List.of("FR", "PT", "IR", "US", "BR", "EC"))), singleton(create("additionalNationalities", "size must be between 0 and 5"))),
                Arguments.of("Two additionalNationalities", (Consumer<PersonalDetails>) a -> a.setAdditionalNationalities(new ArrayList<>(List.of("FR", "PT", "IR", "US", "BR"))), EMPTY_SET),
                Arguments.of("No additionalNationalities", (Consumer<PersonalDetails>) a -> a.setAdditionalNationalities(new ArrayList<>()), EMPTY_SET),
                Arguments.of("Invalid additionalNationality", (Consumer<PersonalDetails>) a -> a.setAdditionalNationalities(new ArrayList<>(List.of("ABC"))), singleton(create("additionalNationalities[0].<list element>", "size must be between 0 and 2"))),
                Arguments.of("Valid Country of Birth", (Consumer<PersonalDetails>) a -> a.setCountryOfBirth("GB"), EMPTY_SET),
                Arguments.of("Invalid Country of Birth", (Consumer<PersonalDetails>) a -> a.setCountryOfBirth("PRT"), singleton(create("countryOfBirth", "size must be between 0 and 2"))),
                Arguments.of("Valid Place of Birth", (Consumer<PersonalDetails>) a -> a.setPlaceOfBirth("London"), EMPTY_SET),
                Arguments.of("Invalid Place of Birth", (Consumer<PersonalDetails>) a -> a.setPlaceOfBirth("A place that has more than twenty eight characters"), singleton(create("placeOfBirth", "size must be between 0 and 28"))),
                Arguments.of("Valid Previous Name", (Consumer<PersonalDetails>) a -> a.setPreviousNames(new ArrayList<>(List.of("Previous Name 1", "Previous Name 2"))), EMPTY_SET),
                Arguments.of("Invalid Previous Name", (Consumer<PersonalDetails>) a -> a.setPreviousNames(new ArrayList<>(List.of("Previous Name That Is Longer Than Fourty Five Characters", "Previous Name 2"))), singleton(create("previousNames[0].<list element>", "size must be between 1 and 45"))),
                Arguments.of("Valid Other Name", (Consumer<PersonalDetails>) a -> a.setOtherNames(new ArrayList<>(List.of("Other Name 1", "Other Name 2"))), EMPTY_SET),
                Arguments.of("Invalid Other Name", (Consumer<PersonalDetails>) a -> a.setOtherNames(new ArrayList<>(List.of("Other Name That Is Longer Than Fourty Five Characters", "Other Name 2"))), singleton(create("otherNames[0].<list element>", "size must be between 0 and 45"))),
                Arguments.of("Valid Tax Numbers", (Consumer<PersonalDetails>) a -> a.setTaxNumbers(new ArrayList<>(List.of("123456789", "987654321"))), EMPTY_SET),
                Arguments.of("Invalid Tax Numbers", (Consumer<PersonalDetails>) a -> a.setTaxNumbers(new ArrayList<>(List.of("1234567890123456789012345678901", "123456789"))), singleton(create("taxNumbers[0].<list element>", "size must be between 0 and 30"))),
                Arguments.of("Valid Tax Residency", (Consumer<PersonalDetails>) a -> a.setTaxResidency(new ArrayList<>(List.of("UK", "PT"))), EMPTY_SET),
                Arguments.of("Invalid Tax Residency", (Consumer<PersonalDetails>) a -> a.setTaxResidency(new ArrayList<>(List.of("PRT", "UK"))), singleton(create("taxResidency[0].<list element>", "size must be between 0 and 2"))),
                Arguments.of("Valid Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, EMPTY_SET),
                Arguments.of("Invalid Flat in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setFlat("12345678910");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.flat", "size must be between 0 and 10"))),
                Arguments.of("Invalid House Number in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setHouseNumber("123456");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.houseNumber", "size must be between 0 and 5"))),
                Arguments.of("Invalid House Name in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setHouseName("This house name is longer than twenty two characters");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.houseName", "size must be between 0 and 22"))),
                Arguments.of("Invalid Street in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setStreet("This street is longer than thirty characters");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.street", "size must be between 0 and 30"))),
                Arguments.of("Invalid District in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setDistrict("This district is longer than thirty characters");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.district", "size must be between 0 and 30"))),
                Arguments.of("Invalid Town in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setTown("This town is longer than twenty eight characters");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.town", "size must be between 0 and 28"))),
                Arguments.of("Invalid County in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setCounty("This county is longer than eighteen characters");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.county", "size must be between 0 and 18"))),
                Arguments.of("Invalid Postcode in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setPostcode("This postcode is longer than twelve characters");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.postcode", "size must be between 0 and 12"))),
                Arguments.of("Invalid Country ISO Code in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    CorrespondenceAddress correspondenceAddress = createValidCorrespondenceAddress();
                    correspondenceAddress.setCountryIsoCode("PRT");
                    a.setCorrespondenceAddress(correspondenceAddress);
                }, singleton(create("correspondenceAddress.countryIsoCode", "size must be between 0 and 2"))),
                Arguments.of("Valid UK Association Address Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, EMPTY_SET),
                Arguments.of("Invalid Flat in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setFlat("12345678910");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.flat", "size must be between 0 and 10"))),
                Arguments.of("Invalid House Number in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setHouseNumber("123456");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.houseNumber", "size must be between 0 and 5"))),
                Arguments.of("Invalid House Name in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setHouseName("This house name is longer than twenty two characters");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.houseName", "size must be between 0 and 22"))),
                Arguments.of("Invalid Street in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setStreet("This street is longer than thirty characters");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.street", "size must be between 0 and 30"))),
                Arguments.of("Invalid District in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setDistrict("This district is longer than thirty characters");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.district", "size must be between 0 and 30"))),
                Arguments.of("Invalid Town in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setTown("This town is longer than twenty eight characters");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.town", "size must be between 0 and 28"))),
                Arguments.of("Invalid County in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setCounty("This county is longer than eighteen characters");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.county", "size must be between 0 and 18"))),
                Arguments.of("Invalid Postcode in Correspondence Address", (Consumer<PersonalDetails>) a -> {
                    UKAssociationAddress ukAssociationAddress = createValidUkAssociationAddress();
                    ukAssociationAddress.setPostcode("This postcode is longer than twelve characters");
                    a.setUkAssociationAddress(ukAssociationAddress);
                }, singleton(create("ukAssociationAddress.postcode", "size must be between 0 and 12"))),
                Arguments.of("@Valid annotation - error when telephone invalid ", (Consumer<PersonalDetails>) a -> {
                    PersonalTelephone phone = createValidPersonalTelephone();
                    phone.setType("invalid");
                    a.setTelephone(phone);
                }, singleton(create("telephone.type", "must be any of: HOME, WORK, MOBILE")))

        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void testPersonalDetailsValidations(String testDescription, Consumer<PersonalDetails> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, ApplicantTestUtil::createValidPersonalDetails, mutator, expectedErrorMessages);
    }

    @Test
    void testAllTitlesInEnumAreValid() {
        PersonalDetails personalDetails = createValidPersonalDetails();
        EnumSet.allOf(Title.class).forEach(title -> {
            personalDetails.setTitle(title.value());
            assertThat(getConstraintViolations(personalDetails)).isEmpty();
        });
    }

}
