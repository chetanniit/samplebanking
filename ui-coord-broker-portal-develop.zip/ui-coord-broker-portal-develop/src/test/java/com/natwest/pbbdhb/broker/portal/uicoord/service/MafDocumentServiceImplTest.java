package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.client.MafDocumentClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.MafDocumentException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.MafDocumentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;

import java.io.IOException;
import java.io.InputStream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_MAF_DOWNLOAD_PERMISSION;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MafDocumentServiceImplTest {

    private static final String DOCUMENT_NAME = "MAF-MED0123123-20032023120057667IFDMOE.pdf";
    private static final String DEFAULT_BRAND = "nwb";

    @Mock
    private MafDocumentClient mockMafDocumentClient;

    @Mock
    private InputStream mockInputStream;

    @Mock
    private  AccessPermissionChecker accessPermissionChecker;

    @Mock
    private  UserClaimsProvider userClaimsProvider;

    private MafDocumentService mafDocumentService;

    @BeforeEach
    public void setUp() {
        mafDocumentService = new MafDocumentServiceImpl(mockMafDocumentClient, accessPermissionChecker, userClaimsProvider);
    }

    @Test
    void testGetMafDocument() throws IOException {
        when(mockMafDocumentClient.getMafDocument(eq(DOCUMENT_NAME))).thenReturn(mockInputStream);

        when(accessPermissionChecker.isCaseOwner(eq(DEFAULT_BRAND),eq("MED0123123"))).thenReturn(true);

        InputStreamResource inputStreamResource = mafDocumentService.getMafDocument(DOCUMENT_NAME,DEFAULT_BRAND);

        assertThat(inputStreamResource.getInputStream()).isEqualTo(mockInputStream);
    }

    @Test
    void testGetMafDocumentErrorPropagates() {
        when(mockMafDocumentClient.getMafDocument(eq(DOCUMENT_NAME))).thenThrow(new MafDocumentException("Something went wrong"));

        when(accessPermissionChecker.isCaseOwner(eq(DEFAULT_BRAND),eq("MED0123123"))).thenReturn(true);

        assertThatThrownBy(() -> mafDocumentService.getMafDocument(DOCUMENT_NAME,DEFAULT_BRAND))
                .isInstanceOf(MafDocumentException.class);
    }

    @Test
    void testGetMafDocumentUserNotOwnerException() {
        when(accessPermissionChecker.isCaseOwner(eq(DEFAULT_BRAND),eq("MED0123123"))).thenReturn(false);

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () ->  mafDocumentService.getMafDocument(DOCUMENT_NAME,DEFAULT_BRAND));

        assertEquals(MSG_NO_MAF_DOWNLOAD_PERMISSION, ex.getMessage());
    }
}
