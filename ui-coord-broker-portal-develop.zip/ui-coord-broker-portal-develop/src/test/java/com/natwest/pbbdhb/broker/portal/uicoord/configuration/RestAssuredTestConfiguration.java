package com.natwest.pbbdhb.broker.portal.uicoord.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.config.ObjectMapperConfig;
import io.restassured.config.RestAssuredConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

@TestConfiguration
public class RestAssuredTestConfiguration {

  @Autowired
  private Jackson2ObjectMapperBuilderCustomizer objectMapperBuilderCustomizer;

  @Bean
  public RestAssuredConfig restAssuredConfig() {
    final Jackson2ObjectMapperBuilder objectMapperBuilder = Jackson2ObjectMapperBuilder.json();
    objectMapperBuilderCustomizer.customize(objectMapperBuilder);
    final ObjectMapper objectMapper = objectMapperBuilder.build();
    RestAssured.config = RestAssuredConfig.config().objectMapperConfig(
        new ObjectMapperConfig().jackson2ObjectMapperFactory((type, s) -> objectMapper));
    return RestAssured.config;
  }

}
