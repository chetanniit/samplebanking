package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ExpenseTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class ExpenseTransactionValidationTest extends AbstractValidationTest<ExpenseTransaction>  {
    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid expense transaction", (Consumer<ExpenseTransaction>) a -> {/* no-op */}, EMPTY_SET),
                Arguments.of("Valid expense transaction with amount 99999999", (Consumer<ExpenseTransaction>) a -> a.setAmount(BigDecimal.valueOf(99999999L)), EMPTY_SET),
                Arguments.of("Amount below minimum", (Consumer<ExpenseTransaction>) a -> a.setAmount(BigDecimal.valueOf(-1L)), singleton(create("amount", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))),
                Arguments.of("Outstanding balance value is below minimum value", (Consumer<ExpenseTransaction>) a -> a.setOutstandingBalance(BigDecimal.valueOf(-1L)), singleton(create("outstandingBalance", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))),
                Arguments.of("Consolidation Amount is below minimum value", (Consumer<ExpenseTransaction>) a -> a.setConsolidationAmount(BigDecimal.valueOf(-1L)), singleton(create("consolidationAmount", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))),
                Arguments.of("CategoryCode is blank", (Consumer<ExpenseTransaction>) a -> a.setCategoryCode(null), singleton(create("categoryCode", "must not be blank"))),
                Arguments.of("CategoryCode strategy type invalid", (Consumer<ExpenseTransaction>) a -> a.setCategoryCode("invalid"), singleton(create("categoryCode", "must be any of: CHILD_CARE, CREDIT_CARD, LOANS_CAR, LOANS_PERSONAL_CONTRACT_PURCHASE, LOANS_SECURED, LOANS_STUDENT, LOANS_UNSECURED, OTHER_COMMITTED_EXPENDITURE_ADDITIONAL_PROPERTY_MORTGAGE, OTHER_COMMITTED_EXPENDITURE_ADDITIONAL_PROPERTY_RUNNING_COST, OTHER_COMMITTED_EXPENDITURE_ADULT_CARE_COST, OTHER_COMMITTED_EXPENDITURE_CAREER_RELATED_SUBSCRIPTIONS_QUALIFICATIONS, OTHER_COMMITTED_EXPENDITURE_CHILD_SUPPORT, OTHER_COMMITTED_EXPENDITURE_GROUND_RENT, OTHER_COMMITTED_EXPENDITURE_HELP_TO_BUY_LOAN, OTHER_COMMITTED_EXPENDITURE_MAINTENANCE_PAYMENTS, OTHER_COMMITTED_EXPENDITURE_OTHER, OTHER_COMMITTED_EXPENDITURE_SCHOOL_EDUCATION_FEES, OTHER_EXPENDITURE_ESTATE_RENT, OTHER_EXPENDITURE_SERVICE_CHARGES_FOR_LEASEHOLD_PROPERTIES, OVERDRAFTS, BUDGET_ACCOUNT, MAIL_ORDER, SHARED_EQUITY"))),
                Arguments.of("Frequency strategy type invalid", (Consumer<ExpenseTransaction>) a -> a.setFrequency("invalid"), singleton(create("frequency", "must be any of: ANNUALLY, BIANNUALLY, QUARTERLY, MONTHLY, FOUR_WEEKLY, FORTNIGHTLY, WEEKLY"))),
                Arguments.of("OriginatingCurrency invalid", (Consumer<ExpenseTransaction>) a -> a.setOriginatingCurrency("invalid"), singleton(create("originatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testExpenseTransactionValidations(String testDescription, Consumer<ExpenseTransaction> mutator, Set<AbstractValidationTest.TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, ExpenseTestUtil::createValidExpenseTransaction, mutator, expectedErrorMessages);
    }
}
