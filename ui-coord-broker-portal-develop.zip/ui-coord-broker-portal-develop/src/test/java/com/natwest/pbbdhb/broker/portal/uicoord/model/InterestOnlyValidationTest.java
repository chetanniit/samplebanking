package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class InterestOnlyValidationTest extends AbstractValidationTest<InterestOnly> {
    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid interest only data", (Consumer<InterestOnly>) a -> { /* no-op */ }, EMPTY_SET),
                Arguments.of("Repayment details is null", (Consumer<InterestOnly>) a -> a.setRepaymentDetails(null), singleton(create("repaymentDetails", "must not be empty"))),
                Arguments.of("Repayment details is empty list", (Consumer<InterestOnly>) a -> a.setRepaymentDetails(new ArrayList<>()), singleton(create("repaymentDetails", "must not be empty"))),
                Arguments.of("@Valid annotation - error when repaymentDetails.repaymentValue invalid", (Consumer<InterestOnly>) a -> a.getRepaymentDetails().get(0).setRepaymentValue(-1L), singleton(create("repaymentDetails[0].repaymentValue", "must be greater than or equal to 0"))),
                Arguments.of("Valid interest only data with minimum interest only term years", (Consumer<InterestOnly>) a -> a.setTermYears(3), EMPTY_SET),
                Arguments.of("Interest only data term years is below minimum value", (Consumer<InterestOnly>) a -> a.setTermYears(2), singleton(create("termYears", "must be greater than or equal to 3"))),
                Arguments.of("Valid interest only data with interest only term years 34", (Consumer<InterestOnly>) a -> a.setTermYears(34), EMPTY_SET),
                Arguments.of("Interest only term years is above maximum value", (Consumer<InterestOnly>) a -> a.setTermYears(36), singleton(create("termYears", "must be less than or equal to 35"))),
                Arguments.of("Valid interest only data with minimum interest only term months", (Consumer<InterestOnly>) a -> a.setTermMonths(0), EMPTY_SET),
                Arguments.of("Interest only term months is below minimum value", (Consumer<InterestOnly>) a -> a.setTermMonths(-1), singleton(create("termMonths", "must be greater than or equal to 0"))),
                Arguments.of("Valid interest only dat with maximum interest only term months", (Consumer<InterestOnly>) a -> a.setTermMonths(11), EMPTY_SET),
                Arguments.of("Interest only term months is above maximum value", (Consumer<InterestOnly>) a -> a.setTermMonths(12), singleton(create("termMonths", "must be less than or equal to 11"))),
                Arguments.of("Valid interest only data with maximum interest only term 35 years and 0 months", (Consumer<InterestOnly>) a -> {
                    a.setTermYears(35);
                    a.setTermMonths(0);
                }, EMPTY_SET),
                Arguments.of("Interest only term is above maximum value 35 years and 0 months", (Consumer<InterestOnly>) a -> {
                    a.setTermYears(35);
                    a.setTermMonths(1);
                }, singleton(create("", "'termMonths' value cannot be greater than 0 when 'termYears' equals 35")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testInterestOnlyRepaymentValidations(String testDescription, Consumer<InterestOnly> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidInterestOnly, mutator, expectedErrorMessages);
    }
}
