package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ValidateAccountRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ValidateAccountService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import jakarta.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ValidateAccountTestUtil.createValidProductSearchRequest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {ValidateAccountController.class, ControllerAdvice.class})
class ValidateAccountControllerValidationTest {

    @MockBean
    private ValidateAccountService validateAccountService;

    @MockBean
    private UserClaimsProvider userClaimsProvider;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void validateAccountValidRequest() throws Exception {
        ValidateAccountRequest validateAccountRequest = createValidProductSearchRequest();
        String requestBodyContent = this.objectMapper.writeValueAsString(validateAccountRequest);

        boolean validateAccountResponse = true;
        String responseBodyContent = this.objectMapper.writeValueAsString(validateAccountResponse);
        when(validateAccountService.validateAccount(BRAND_DEFAULT, validateAccountRequest)).thenReturn(validateAccountResponse);

        RequestBuilder request = post(PATH_VALIDATE_ACCOUNT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(responseBodyContent));
    }

    @Test
    void validateAccountWithInvalidBrandHeader() throws Exception {
        ValidateAccountRequest validateAccountRequest = createValidProductSearchRequest();
        String requestBodyContent = this.objectMapper.writeValueAsString(validateAccountRequest);

        RequestBuilder request = post(PATH_VALIDATE_ACCOUNT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent)
                .header(BRAND_HEADER, "INVALID_BRAND");

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("validateAccount.brand"))
            .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

        verifyNoInteractions(validateAccountService);
    }

    @Test
    public void validateAccountInvalidContentTypeReturnsUnsupportedMediaTypeError() throws Exception {
        RequestBuilder request = post(PATH_VALIDATE_ACCOUNT)
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("text");

        this.mockMvc.perform(request)
                .andExpect(status().isUnsupportedMediaType());
    }

    @Test
    void validateAccountWithNoSortCodeReturnsBadRequest() throws Exception {
        ValidateAccountRequest validateAccountRequest = createValidProductSearchRequest();
        validateAccountRequest.setSortCode("");
        String requestBodyContent = this.objectMapper.writeValueAsString(validateAccountRequest);

        RequestBuilder request = post(PATH_VALIDATE_ACCOUNT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest());
    }

    @Test
    void validateAccountServiceThrowsConstraintViolation() throws Exception {
        ValidateAccountRequest validateAccountRequest = createValidProductSearchRequest();
        validateAccountRequest.setSortCode("4242");
        String requestBodyContent = this.objectMapper.writeValueAsString(validateAccountRequest);

        when(validateAccountService.validateAccount(BRAND_DEFAULT, validateAccountRequest)).thenThrow(new ConstraintViolationException(MUST_BE_5_OR_6_DIGITS, null));

        RequestBuilder request = post(PATH_VALIDATE_ACCOUNT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("sortCode"))
            .andExpect(jsonPath("$.errors[0].description").value(MUST_BE_5_OR_6_DIGITS));
    }


    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("validateAccountValidationCases")
    public void validateAccountWithValidationErrorsReturnsBadRequestError(
            String testDescription, String sortCode, String accountNumber, String rollNumber, ErrorResponse expected
    ) throws Exception {
        ValidateAccountRequest validateAccountRequest = createValidProductSearchRequest();
        validateAccountRequest.setSortCode(sortCode);
        validateAccountRequest.setAccountNumber(accountNumber);
        validateAccountRequest.setRollNumber(rollNumber);
        String requestBodyContent = this.objectMapper.writeValueAsString(validateAccountRequest);

        RequestBuilder request = post(PATH_VALIDATE_ACCOUNT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        MvcResult mvcResult = this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        ErrorResponse response = this.objectMapper.readValue(
                mvcResult.getResponse().getContentAsString(), ErrorResponse.class);

        assertThat(response)
                .usingRecursiveComparison()
                .ignoringCollectionOrder()
                .isEqualTo(expected);
    }

    private static Stream<Arguments> validateAccountValidationCases() {
        return Stream.of(
                Arguments.of("Sort code too short", "9386", "00101242", null,
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("sortCode", "must be 5 or 6 digits")))),
                Arguments.of("Account number too short", "938613", "0010124", null,
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("accountNumber", "must be 8 digits"))))
        );
    }
}
