package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.mapper.MortgageSchemeMappingHelper.CAPIE_HELP_TO_BUY;
import static com.natwest.pbbdhb.broker.portal.uicoord.mapper.MortgageSchemeMappingHelper.CAPIE_OTHER;
import static com.natwest.pbbdhb.broker.portal.uicoord.mapper.MortgageSchemeMappingHelper.CAPIE_OTHER_NAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.LoanPurpose.REMORTGAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.SchemeType.SHARED_EQUITY;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage.MortgageAdvised.ADVICE;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage.MortgageType.REPAYMENT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidBankDetails;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BROKER_FEE_CHARGED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BROKER_JOURNEY_VERSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_CURRENT_ROUTE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_EPC_RATING_A_OR_B_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_FIRST_TIME_BUYER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_COMPLETED_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_DEPENDANTS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_IS_PRODUCT_FEE_PAYMENT_SELECTED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_LEASEHOLD_OWNERSHIP_TERM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_REPAYMENT_STRATEGY_ADDRESSES;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_USING_SPECIALIST_SCHEME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidCaseApplication;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidCaseApplicationDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidInterestOnlyMortgage;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidNorthernIrelandCaseApplication;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidPartAndPartMortgage;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidSolicitor;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_BROKER_CLAIMS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_BROKER_CLAIMS_BUILDER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_BROKER_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_PAYMENT_PATH_NAME;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BankDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty.PropertyUsage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.RepaymentDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.FirmDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.system.Clock;
import com.natwest.pbbdhb.cases.dto.AdditionalBorrowingDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import com.natwest.pbbdhb.cases.dto.OtherPropertyDto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    CaseApplicationMapper.class,
    CaseApplicationAutoMapperImpl.class,
    EstateAgentMapperImpl.class,
    BasicAddressMapperImpl.class,
    SolicitorMapperImpl.class,
    ProductDetailsMapperImpl.class,
    NapoliBrokerMapperImpl.class,
    DipResultMapperImpl.class,
    HardscoreDecisionMapperImpl.class,
    Clock.class,
    DirectDebitDetailsMapperImpl.class
})
class CaseApplicationMapperTest {

  private static final String ADDITIONAL_SERVICES_REQUIRED_DEFAULT_VALUE = "EKYC";
  private static final String BRANCH_DEFAULT_VALUE = "GMOI";
  private static final String DIRECT_APPLICATION_DEFAULT_VALUE = "N";
  public static final String DEFAULT_PROPERTY_NOTES_VALUE = "Property not being sold";

  @Autowired
  private CaseApplicationMapper caseApplicationMapper;

  @Test
  void testCaseApplicationRoundTripMapping() {
    CaseApplication caseApplication = createValidCaseApplication();
    CaseApplicationDto
        caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, caseApplication,
            TEST_BROKER_CLAIMS);
    CaseApplication roundTripCaseApplication = this.caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(roundTripCaseApplication).usingRecursiveComparison().isEqualTo(caseApplication);
  }

  @Test
  void testInterestOnlyCaseApplicationRoundTripMapping() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setMortgage(createValidInterestOnlyMortgage());

    CaseApplicationDto caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID,
            caseApplication, TEST_BROKER_CLAIMS);
    CaseApplication roundTripCaseApplication = this.caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(roundTripCaseApplication).usingRecursiveComparison()
        .ignoringFields("mortgage.buyToLet").isEqualTo(caseApplication);
  }

  @Test
  void testPartAndPartCaseApplicationRoundTripMapping() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setMortgage(createValidPartAndPartMortgage());

    CaseApplicationDto caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID,
            caseApplication, TEST_BROKER_CLAIMS);
    CaseApplication roundTripCaseApplication = this.caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(roundTripCaseApplication).usingRecursiveComparison()
        .ignoringFields("mortgage.buyToLet").isEqualTo(caseApplication);
  }

  @Test
  void testServiceLevelRoundTripMappingWithNullServiceLevel() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.getMortgage().setMortgageAdvised("ADVICE");
    caseApplication.setServiceLevel(null);

    CaseApplicationDto caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID,
            caseApplication, TEST_BROKER_CLAIMS);
    CaseApplication roundTripCaseApplication = this.caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(roundTripCaseApplication.getServiceLevel()).isNull();
  }

  @Test
  void testSchemeTypeMappingThrowsWithInvalidSchemeType() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setSchemeType("<INVALID>");
    assertThat(catchThrowable(() -> this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS)))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage("Unrecognised mortgage scheme type: '<INVALID>'");
  }

  @Test
  void toCaseApplicationMapsCorrectly() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto
        .setMafDocumentUrl("https://foo.bar.baz.rbsgrp.net/FMA/MAF-DOCUMENT-NAME.pdf");

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getHasDependants())
        .isEqualTo(caseApplicationDto.getJourneyData().get(CASE_JOURNEY_DATA_HAS_DEPENDANTS));
    assertThat(result.getCurrentRoute())
        .isEqualTo(caseApplicationDto.getJourneyData().get(CASE_JOURNEY_DATA_CURRENT_ROUTE));

    assertThat(result).usingRecursiveComparison().ignoringFields(
        "currentRoute",
        "firstTimeBuyer",
        "usingSpecialistScheme",
        "schemeType",
        "mortgage.interestOnlyTermYears",
        "mortgage.interestOnlyTermMonths",
        "hasDependants",
        "mortgage.additionalBorrowing",
        "productDetails",
        "repaymentStrategyAddresses",
        "salesIllustrations",
        "broker.paymentPath",
        "broker.fee",
        "broker.brokerFeeCharged",
        "decisionInPrinciple",
        "decisionInPrinciples",
        "mortgage.mortgageAmount",
        "mortgage.propertyValue",
        "mortgage.purchasePrice",
        "mortgage.buyToLet",
        "mafDocumentName",
        "hasCompletedDip",
        "leaseholdOwnershipTerm",
        "isProductSelectedAtDip",
        "epcRatingAOrBDip",
        "brokerJourneyVersion",
        "isProductFeePaymentSelected"
    ).isEqualTo(caseApplicationDto);
    assertThat(result.getMortgage().getMortgageAmount())
        .isEqualTo(caseApplicationDto.getMortgage().getMortgageAmount().intValue());
    assertThat(result.getMortgage().getPropertyValue())
        .isEqualTo(caseApplicationDto.getMortgage().getPropertyValue().intValue());
    assertThat(result.getMortgage().getPurchasePrice())
        .isEqualTo(caseApplicationDto.getMortgage().getPurchasePrice().intValue());
    assertThat(result.getMafDocumentName()).isEqualTo("MAF-DOCUMENT-NAME.pdf");
  }

  @Test
  void toCaseApplicationMapsCorrectlyWhenMortgageNull() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto.setMortgage(null);

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getMortgage()).isNull();
    assertThat(result).usingRecursiveComparison().ignoringFields(
        "currentRoute",
        "firstTimeBuyer",
        "usingSpecialistScheme",
        "schemeType",
        "hasDependants",
        "mortgage.additionalBorrowing",
        "productDetails",
        "salesIllustrations",
        "broker.paymentPath",
        "broker.fee",
        "broker.brokerFeeCharged",
        "repaymentStrategyAddresses",
        "decisionInPrinciple",
        "decisionInPrinciples",
        "mafDocumentName",
        "hasCompletedDip",
        "leaseholdOwnershipTerm",
        "isProductSelectedAtDip",
        "epcRatingAOrBDip",
        "brokerJourneyVersion",
        "isProductFeePaymentSelected"
    ).isEqualTo(caseApplicationDto);
  }

  @Test
  void toCaseApplicationMapsCorrectlyWithRemortgage() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();

    caseApplicationDto.setLoanPurpose(REMORTGAGE.value());
    MortgageDto mortgage = new MortgageDto();
    mortgage.setMortgageTermYears(25);
    mortgage.setMortgageTermMonths(7);
    mortgage.setMortgageType(REPAYMENT.value());
    mortgage.setMortgageAdvised(ADVICE.value());
    mortgage.setPropertyValue(500_000L);
    mortgage.setPurchasePrice(500_000L);
    AdditionalBorrowingDto additionalBorrowingItem = new AdditionalBorrowingDto();
    additionalBorrowingItem.setAmount(60_000L);
    additionalBorrowingItem.setReason("OTHER");
    mortgage.setAdditionalBorrowings(Collections.singletonList(additionalBorrowingItem));
    mortgage.setMortgageAmount(500_000 + 60_000L);
    caseApplicationDto.setMortgage(mortgage);
    caseApplicationDto.getJourneyData().put("additionalBorrowing", true);

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result).usingRecursiveComparison().ignoringFields(
        "currentRoute",
        "firstTimeBuyer",
        "usingSpecialistScheme",
        "schemeType",
        "mortgage.interestOnlyTermYears",
        "mortgage.interestOnlyTermMonths",
        "hasDependants",
        "mortgage.additionalBorrowing",
        "repaymentStrategyAddresses",
        "productDetails",
        "salesIllustrations",
        "broker.paymentPath",
        "broker.fee",
        "broker.brokerFeeCharged",
        "decisionInPrinciple",
        "decisionInPrinciples",
        "mortgage.mortgageAmount",
        "mortgage.propertyValue",
        "mortgage.purchasePrice",
        "mortgage.buyToLet",
        "mafDocumentName",
        "hasCompletedDip",
        "leaseholdOwnershipTerm",
        "isProductSelectedAtDip",
        "epcRatingAOrBDip",
        "brokerJourneyVersion",
        "isProductFeePaymentSelected"
    ).isEqualTo(caseApplicationDto);
    assertThat(result.getMortgage().getAdditionalBorrowing())
        .isEqualTo(caseApplicationDto.getJourneyData().get("additionalBorrowing"));
    assertThat(result.getMortgage().getMortgageAmount())
        .isEqualTo(caseApplicationDto.getMortgage().getMortgageAmount().intValue());
    assertThat(result.getMortgage().getPropertyValue())
        .isEqualTo(caseApplicationDto.getMortgage().getPropertyValue().intValue());
    assertThat(result.getMortgage().getPurchasePrice())
        .isEqualTo(caseApplicationDto.getMortgage().getPurchasePrice().intValue());
  }

  @Test
  void toCaseApplicationReturnsNullWhenCaseApplicationDtoNull() {
    assertThat(this.caseApplicationMapper.toCaseApplication(null)).isNull();
  }

  @Test
  void toCaseApplicationDtoMapsCorrectly() {
    CaseApplication caseApplication = createValidCaseApplication();

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
    checkDefaultValues(result);
    assertThat(result).usingRecursiveComparison().ignoringFields(
        "caseId",
        "buyerType",
        "schemeType",
        "schemeName",
        "govtSharedEquityScheme",
        "mortgage.rightToBuy",
        "journeyData",
        "mortgage.mortgageGuarantee",
        "mortgage.journeyData",
        "estateAgent.telephones",
        "estateAgent.address",
        "solicitor.postcode",
        "solicitor.telephones",
        "productDetails",
        "salesIllustrations",
        "additionalServicesRequired",
        "branch",
        "directApplication",
        "serviceLevel.levelOfService",
        "decisionInPrinciples", "racfId", "mortgageReferenceNumber", "channel",
        "mortgageTempReferenceNumber",
        "salesIllustrationTempReferenceNumber", "applicationStatus", "movingToPropertyAtCompletion",
        "marketingSource", "hardscoreDecision", "secondaryAdvisorRacfId", "contactPermission",
        "marketingSchemeNumber", "directDebit.sortcode", "directDebit.mandate", "mortgageApplSeq",
        "exceptionPolicies", "primaryAdvisorRacfId",
        "broker.details", "broker.brokerEmail", "broker.firmPostcode",
        "broker.brokerTelephoneNumber",
        "broker.brokerSurname", "broker.brokerForename", "broker.brokerPostcode",
        "broker.firmAddressLine1",
        "broker.firmName", "broker.brokerUsername", "broker.firmAddressLine4",
        "broker.firmAddressLine3",
        "broker.paymentPath", "broker.fcaNumber", "broker.firmAddressLine2", "solicitor.branchCode",
        "solicitor.documentExchangeNumber", "solicitor.contactName", "solicitor.associateType",
        "solicitor.branchName", "solicitor.alphaKey", "solicitor.solePractitioner",
        "solicitor.status",
        "mortgage.mortgageAdvisor", "mortgage.deposits.depositDetails", "mortgage.mortgageAmount",
        "mortgage.propertyValue", "mortgage.purchasePrice", "caseNotes", "isEsis", "createdDate",
        "modifiedDate", "mafDocumentUrl", "mortgage.buyToLet.monthlyRentalIncome",
        "mortgage.buyToLet.lettingAgentCost", "mortgage.buyToLet.monthlyNetRentalIncome",
        "broker.firmAddressLine5", "broker.firmAddressCounty", "broker.brokerTitle",
        "broker.firmAddressCountry", "broker.firmAddressCity",
        "mortgage.existingMortgageTransfer", "broker.tppId",
        "isProductSelectedAtDip",
        "brokerJourneyVersion",
        "affordableHousingFlag",
        "mortgage.buyToLet.originatingCurrency",
        "hmrcConsent", "taxStatus",
        "broker.brokerAdminEmail",
        "runningCost"
    ).ignoringFieldsMatchingRegexes(
        "mortgage.otherProperties.*.address",
        "mortgage.otherProperties.*.monthlyRentalIncome",
        "mortgage.otherProperties.*.useLettingAgent",
        "mortgage.otherProperties.*.lastUpdated",
        "mortgage.otherProperties.*.estimatedPropertyValue",
        "mortgage.otherProperties.*.interestOnlyAmount",
        "mortgage.otherProperties.*.monthlyMortgagePayment",
        "mortgage.otherProperties.*.outstandingMortgageBalance",
        "mortgage.otherProperties.*.purchasePrice", "mortgage.otherProperties.*.propertyNotes",
        "mortgage.otherProperties.*.monthlyNetRentalIncome",
        "mortgage.otherProperties.*.runningCost"

    ).isEqualTo(caseApplication);
    assertThat(result.getServiceLevel().getLevelOfService()).isEqualTo("ADVISED");
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
    assertThat(result.getBroker().getDetails().getNetworkId())
        .isEqualTo(caseApplication.getBroker().getPaymentPath());
    assertThat(result.getBroker().getPaymentPath().getName()).isEqualTo(TEST_PAYMENT_PATH_NAME);
    assertThat(result.getMortgage().getMortgageAmount().intValue())
        .isEqualTo(caseApplication.getMortgage().getMortgageAmount());
    assertThat(result.getMortgage().getPropertyValue().intValue())
        .isEqualTo(caseApplication.getMortgage().getPropertyValue());
    assertThat(result.getMortgage().getPurchasePrice().intValue())
        .isEqualTo(caseApplication.getMortgage().getPurchasePrice());
    assertThat(result.getMortgage().getBuyToLet().getMonthlyRentalIncome().longValue())
        .isEqualTo(caseApplication.getMortgage().getBuyToLet().getMonthlyRentalIncome());
    assertThat(result.getMortgage().getBuyToLet().getLettingAgentCost().longValue())
        .isEqualTo(caseApplication.getMortgage().getBuyToLet().getLettingAgentCost());
    assertThat(result.getDirectDebit().getSortcode())
        .isEqualTo(caseApplication.getDirectDebit().getSortCode());
    assertThat(result.getMortgage().getDeposits().get(0).getOriginatingCurrency()).isEqualTo(
        caseApplication.getMortgage().getDeposits().get(0).getOriginatingCurrency());
    assertThat(result.getMortgage().getBuyToLet().getMonthlyNetRentalIncome().longValue()).isEqualTo(
        caseApplication.getMortgage().getBuyToLet().getMonthlyNetRentalIncome());

    OtherProperty otherProperty = caseApplication.getMortgage().getOtherProperties().get(0);
    OtherPropertyDto otherPropertyDto = result.getMortgage().getOtherProperties().get(0);
    assertThat(otherPropertyDto.getEstimatedPropertyValue().intValue())
        .isEqualTo(otherProperty.getEstimatedPropertyValue());
    assertThat(otherPropertyDto.getInterestOnlyAmount().intValue())
        .isEqualTo(otherProperty.getInterestOnlyAmount());
    assertThat(otherPropertyDto.getMonthlyMortgagePayment().intValue())
        .isEqualTo(otherProperty.getMonthlyMortgagePayment());
    assertThat(otherPropertyDto.getOutstandingMortgageBalance().intValue())
        .isEqualTo(otherProperty.getOutstandingMortgageBalance());
    assertThat(otherPropertyDto.getPurchasePrice().intValue())
        .isEqualTo(otherProperty.getPurchasePrice());
    assertThat(otherPropertyDto.getPropertyNotes()).isEqualTo(otherProperty.getPropertyNotes());
    assertThat(otherPropertyDto.getPropertyRedemption())
        .isEqualTo(otherProperty.getPropertyRedemption());
    assertThat(otherPropertyDto.getOriginatingCurrency())
            .isEqualTo(otherProperty.getOriginatingCurrency());

    assertThat(otherPropertyDto.getRunningCost()).isEqualTo(otherProperty.getHasPropertyRunningCosts());
  }

  @Test
  void toOtherPropertyDtoMapsCorrectlyWhenPropertyUsageIsBUY_TO_LET() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.getMortgage().getOtherProperties().get(0).setPropertyUsage(
        PropertyUsage.BUY_TO_LET.value());
    caseApplication.getMortgage().getOtherProperties().get(0).setMonthlyNetRentalIncome(1000);

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
    checkDefaultValues(result);

    OtherProperty otherProperty = caseApplication.getMortgage().getOtherProperties().get(0);
    OtherPropertyDto otherPropertyDto = result.getMortgage().getOtherProperties().get(0);
    assertThat(otherPropertyDto.getMonthlyNetRentalIncome().intValue())
        .isEqualTo(otherProperty.getMonthlyNetRentalIncome());
  }

  @Test
  void toOtherPropertyDtoMapsCorrectlyWhenPropertyUsageIsCONSENT_TO_LET() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.getMortgage().getOtherProperties().get(0).setPropertyUsage(
        PropertyUsage.CONSENT_TO_LET.value());
    caseApplication.getMortgage().getOtherProperties().get(0).setMonthlyNetRentalIncome(1000);

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
    checkDefaultValues(result);

    OtherProperty otherProperty = caseApplication.getMortgage().getOtherProperties().get(0);
    OtherPropertyDto otherPropertyDto = result.getMortgage().getOtherProperties().get(0);
    assertThat(otherPropertyDto.getMonthlyNetRentalIncome().intValue())
        .isEqualTo(otherProperty.getMonthlyNetRentalIncome());
  }

  @Test
  void toOtherPropertyDtoMapsCorrectlyWhenPropertyUsageIsRESIDENTIAL() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.getMortgage().getOtherProperties().get(0).setPropertyUsage(
        PropertyUsage.RESIDENTIAL.value());
    caseApplication.getMortgage().getOtherProperties().get(0).setMonthlyNetRentalIncome(1000);

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
    checkDefaultValues(result);

    OtherProperty otherProperty = caseApplication.getMortgage().getOtherProperties().get(0);
    OtherPropertyDto otherPropertyDto = result.getMortgage().getOtherProperties().get(0);
    assertThat(otherPropertyDto.getMonthlyNetRentalIncome()).isNull();
  }

  @Test
  void toCaseApplicationDtoMapsCorrectlyWhenMortgageNull() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setMortgage(null);

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
    assertThat(result.getMortgage()).isNull();
    checkDefaultValues(result);
    assertThat(result).usingRecursiveComparison().ignoringFields(
        "buyerType",
        "schemeType",
        "schemeName",
        "govtSharedEquityScheme",
        "journeyData",
        "estateAgent.telephones",
        "estateAgent.address",
        "solicitor.postcode",
        "solicitor.telephones",
        "salesIllustrations",
        "additionalServicesRequired",
        "branch",
        "directApplication",
        "broker.details",
        "decisionInPrinciples", "racfId", "mortgageReferenceNumber", "channel",
        "mortgageTempReferenceNumber",
        "salesIllustrationTempReferenceNumber", "applicationStatus", "movingToPropertyAtCompletion",
        "marketingSource", "hardscoreDecision", "secondaryAdvisorRacfId", "contactPermission",
        "marketingSchemeNumber", "serviceLevel", "directDebit.sortcode", "directDebit.mandate",
        "mortgageApplSeq", "exceptionPolicies",
        "primaryAdvisorRacfId", "broker.brokerEmail", "broker.firmPostcode",
        "broker.brokerTelephoneNumber",
        "broker.brokerSurname", "broker.brokerForename", "broker.brokerPostcode",
        "broker.firmAddressLine1",
        "broker.firmName", "broker.brokerUsername", "broker.firmAddressLine4",
        "broker.firmAddressLine3",
        "broker.fcaNumber", "broker.firmAddressLine2", "solicitor.branchCode",
        "solicitor.documentExchangeNumber",
        "solicitor.contactName", "solicitor.associateType", "solicitor.branchName",
        "solicitor.alphaKey",
        "solicitor.solePractitioner", "solicitor.status", "broker.paymentPath",
        "mortgage.mortgageAdvisor",
        "mortgage.deposits.depositDetails", "mortgage.mortgageAmount", "mortgage.propertyValue",
        "mortgage.purchasePrice", "caseNotes", "isEsis", "createdDate", "modifiedDate",
        "mafDocumentUrl",
        "broker.firmAddressLine5", "broker.firmAddressCounty", "broker.brokerTitle",
        "broker.firmAddressCountry", "broker.firmAddressCity", "broker.tppId",
        "isProductSelectedAtDip",
        "brokerJourneyVersion",
        "affordableHousingFlag",
        "mortgage.buyToLet.originatingCurrency",
        "hmrcConsent", "taxStatus",
        "broker.brokerAdminEmail"
    ).isEqualTo(caseApplication);
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
    assertThat(result.getBroker().getDetails().getNetworkId())
        .isEqualTo(caseApplication.getBroker().getPaymentPath());
  }

  @Test
  void toCaseApplicationDtoMapsCorrectlyWhenCaseIdNull() {
    CaseApplication caseApplication = createValidCaseApplication();

    // set null for propertyNotes and false to propertyRedemption to check if default value is set
    caseApplication.getMortgage().getOtherProperties().get(0).setPropertyRedemption(false);
    caseApplication.getMortgage().getOtherProperties().get(0).setPropertyNotes(null);

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(null,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat(result.getCaseId()).isNull();
    checkDefaultValues(result);
    assertThat(result).usingRecursiveComparison().ignoringFields(
        "caseId",
        "buyerType",
        "schemeType",
        "schemeName",
        "govtSharedEquityScheme",
        "mortgage.rightToBuy",
        "journeyData",
        "mortgage.mortgageGuarantee",
        "mortgage.journeyData",
        "estateAgent.telephones",
        "estateAgent.address",
        "solicitor.postcode",
        "solicitor.telephones",
        "salesIllustrations",
        "additionalServicesRequired",
        "branch",
        "directApplication",
        "broker.details",
        "decisionInPrinciples", "racfId", "mortgageReferenceNumber", "channel",
        "mortgageTempReferenceNumber",
        "salesIllustrationTempReferenceNumber", "applicationStatus", "movingToPropertyAtCompletion",
        "marketingSource", "hardscoreDecision", "secondaryAdvisorRacfId", "contactPermission",
        "marketingSchemeNumber", "serviceLevel", "directDebit.sortcode", "directDebit.mandate",
        "mortgageApplSeq", "exceptionPolicies",
        "primaryAdvisorRacfId", "broker.brokerEmail", "broker.firmPostcode",
        "broker.brokerTelephoneNumber",
        "broker.brokerSurname", "broker.brokerForename", "broker.brokerPostcode",
        "broker.firmAddressLine1",
        "broker.firmName", "broker.brokerUsername", "broker.firmAddressLine4",
        "broker.firmAddressLine3",
        "broker.fcaNumber", "broker.firmAddressLine2", "solicitor.branchCode",
        "solicitor.documentExchangeNumber",
        "solicitor.contactName", "solicitor.associateType", "solicitor.branchName",
        "solicitor.alphaKey",
        "solicitor.solePractitioner", "solicitor.status", "broker.paymentPath",
        "mortgage.mortgageAdvisor",
        "mortgage.deposits.depositDetails", "mortgage.mortgageAmount", "mortgage.propertyValue",
        "mortgage.purchasePrice", "caseNotes", "isEsis", "createdDate", "modifiedDate",
        "mafDocumentUrl", "broker.tppId",
        "mortgage.buyToLet.monthlyRentalIncome", "mortgage.buyToLet.lettingAgentCost",
        "mortgage.buyToLet.monthlyNetRentalIncome",
        "broker.firmAddressLine5", "broker.firmAddressCounty", "broker.brokerTitle",
        "broker.firmAddressCountry", "broker.firmAddressCity", "mortgage.existingMortgageTransfer",
        "isProductSelectedAtDip",
        "brokerJourneyVersion",
        "mortgage.buyToLet.originatingCurrency",
        "affordableHousingFlag", "taxStatus",
        "hmrcConsent", "broker.brokerAdminEmail",
        "runningCost"
    ).ignoringFieldsMatchingRegexes(
        "mortgage.otherProperties.*.address",
        "mortgage.otherProperties.*.monthlyRentalIncome",
        "mortgage.otherProperties.*.useLettingAgent",
        "mortgage.otherProperties.*.lastUpdated",
        "mortgage.otherProperties.*.estimatedPropertyValue",
        "mortgage.otherProperties.*.interestOnlyAmount",
        "mortgage.otherProperties.*.monthlyMortgagePayment",
        "mortgage.otherProperties.*.outstandingMortgageBalance",
        "mortgage.otherProperties.*.purchasePrice", "mortgage.otherProperties.*.propertyNotes",
        "mortgage.otherProperties.*.monthlyNetRentalIncome",
        "mortgage.otherProperties.*.runningCost"
    ).isEqualTo(caseApplication);
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
    assertThat(result.getBroker().getDetails().getNetworkId())
        .isEqualTo(caseApplication.getBroker().getPaymentPath());
    assertThat(result.getMortgage().getMortgageAmount().intValue())
        .isEqualTo(caseApplication.getMortgage().getMortgageAmount());
    assertThat(result.getMortgage().getPropertyValue().intValue())
        .isEqualTo(caseApplication.getMortgage().getPropertyValue());
    assertThat(result.getMortgage().getPurchasePrice().intValue())
        .isEqualTo(caseApplication.getMortgage().getPurchasePrice());
    assertThat(result.getMortgage().getBuyToLet().getMonthlyRentalIncome().longValue())
        .isEqualTo(caseApplication.getMortgage().getBuyToLet().getMonthlyRentalIncome());
    assertThat(result.getMortgage().getBuyToLet().getLettingAgentCost().longValue())
        .isEqualTo(caseApplication.getMortgage().getBuyToLet().getLettingAgentCost());
    assertThat(result.getDirectDebit().getSortcode())
        .isEqualTo(caseApplication.getDirectDebit().getSortCode());
    assertThat(result.getMortgage().getDeposits().get(0).getOriginatingCurrency()).isEqualTo(
        caseApplication.getMortgage().getDeposits().get(0).getOriginatingCurrency());

    OtherProperty otherProperty = caseApplication.getMortgage().getOtherProperties().get(0);
    OtherPropertyDto otherPropertyDto = result.getMortgage().getOtherProperties().get(0);
    assertThat(otherPropertyDto.getEstimatedPropertyValue().intValue())
        .isEqualTo(otherProperty.getEstimatedPropertyValue());
    assertThat(otherPropertyDto.getInterestOnlyAmount().intValue())
        .isEqualTo(otherProperty.getInterestOnlyAmount());
    assertThat(otherPropertyDto.getMonthlyMortgagePayment().intValue())
        .isEqualTo(otherProperty.getMonthlyMortgagePayment());
    assertThat(otherPropertyDto.getOutstandingMortgageBalance().intValue())
        .isEqualTo(otherProperty.getOutstandingMortgageBalance());
    assertThat(otherPropertyDto.getPurchasePrice().intValue())
        .isEqualTo(otherProperty.getPurchasePrice());
    assertThat(otherPropertyDto.getPropertyNotes()).isEqualTo(DEFAULT_PROPERTY_NOTES_VALUE);
    assertThat(otherPropertyDto.getPropertyRedemption())
        .isEqualTo(otherProperty.getPropertyRedemption());
    assertThat(otherPropertyDto.getOriginatingCurrency())
            .isEqualTo(otherProperty.getOriginatingCurrency());
  }

  private void checkDefaultValues(CaseApplicationDto result) {
    assertThat(result.getAdditionalServicesRequired())
        .isEqualTo(ADDITIONAL_SERVICES_REQUIRED_DEFAULT_VALUE);
    assertThat(result.getBranch()).isEqualTo(BRANCH_DEFAULT_VALUE);
    assertThat(result.getDirectApplication()).isEqualTo(DIRECT_APPLICATION_DEFAULT_VALUE);
  }

  @Test
  void toCaseApplicationDtoMapsCorrectlyForInterestOnly() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setMortgage(createValidInterestOnlyMortgage());

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    // specific tests for fields related to interest-only mortgages
    assertThat(result.getMortgage().getInterestOnly().getAmount())
        .isEqualTo(BigDecimal.valueOf(caseApplication.getMortgage().getMortgageAmount()));

    checkDefaultValues(result);
    assertThat(result).usingRecursiveComparison().ignoringFields(
        "mortgage.interestOnly.amount",
        "buyerType",
        "schemeType",
        "schemeName",
        "govtSharedEquityScheme",
        "mortgage.rightToBuy",
        "journeyData",
        "mortgage.mortgageGuarantee",
        "mortgage.journeyData",
        "estateAgent.telephones",
        "estateAgent.address",
        "solicitor.postcode",
        "solicitor.telephones",
        "salesIllustrations",
        "repaymentStrategyAddresses",
        "additionalServicesRequired",
        "branch",
        "directApplication",
        "broker.details",
        "decisionInPrinciples", "racfId", "mortgageReferenceNumber", "channel",
        "mortgageTempReferenceNumber",
        "salesIllustrationTempReferenceNumber", "applicationStatus", "movingToPropertyAtCompletion",
        "marketingSource", "hardscoreDecision", "secondaryAdvisorRacfId", "contactPermission",
        "marketingSchemeNumber", "serviceLevel", "directDebit.sortcode", "directDebit.mandate",
        "mortgageApplSeq", "exceptionPolicies",
        "primaryAdvisorRacfId", "broker.brokerEmail", "broker.firmPostcode",
        "broker.brokerTelephoneNumber",
        "broker.brokerSurname", "broker.brokerForename", "broker.brokerPostcode",
        "broker.firmAddressLine1",
        "broker.firmName", "broker.brokerUsername", "broker.firmAddressLine4",
        "broker.firmAddressLine3",
        "broker.fcaNumber", "broker.firmAddressLine2", "solicitor.branchCode",
        "solicitor.documentExchangeNumber",
        "solicitor.contactName", "solicitor.associateType", "solicitor.branchName",
        "solicitor.alphaKey",
        "solicitor.solePractitioner", "solicitor.status", "broker.paymentPath",
        "mortgage.mortgageAdvisor",
        "mortgage.deposits.depositDetails", "mortgage.mortgageAmount", "mortgage.propertyValue",
        "mortgage.purchasePrice",
        "mortgage.interestOnly.repaymentDetails.repaymentVerificationType",
        "mortgage.interestOnly.repaymentDetails.repaymentMortgageAmount",
        "mortgage.interestOnly.repaymentDetails.repaymentSumAssured",
        "mortgage.interestOnly.repaymentDetails.repaymentStartDate",
        "mortgage.interestOnly.repaymentDetails.repaymentStrategyStatus",
        "mortgage.interestOnly.repaymentDetails.repaymentVerificationDate",
        "mortgage.interestOnly.repaymentDetails.repaymentProjectedValuation",
        "mortgage.interestOnly.repaymentDetails.repaymentValueAtMaturity", "caseNotes", "isEsis",
        "createdDate", "modifiedDate", "mafDocumentUrl", "broker.tppId",
        "mortgage.buyToLet.monthlyRentalIncome", "mortgage.buyToLet.lettingAgentCost",
        "mortgage.buyToLet.monthlyNetRentalIncome","mortgage.buyToLet.originatingCurrency",
        "broker.firmAddressLine5", "broker.firmAddressCounty", "broker.brokerTitle",
        "broker.firmAddressCountry", "broker.firmAddressCity", "mortgage.existingMortgageTransfer",
        "isProductSelectedAtDip",
        "brokerJourneyVersion",
        "affordableHousingFlag", "mortgage.buyToLet.originatingCurrency",
        "taxStatus", "hmrcConsent",
        "broker.brokerAdminEmail",
        "runningCost"
    ).ignoringFieldsMatchingRegexes(
        "mortgage.otherProperties.*.address",
        "mortgage.otherProperties.*.monthlyRentalIncome",
        "mortgage.otherProperties.*.useLettingAgent",
        "mortgage.otherProperties.*.lastUpdated",
        "mortgage.otherProperties.*.estimatedPropertyValue",
        "mortgage.otherProperties.*.interestOnlyAmount",
        "mortgage.otherProperties.*.monthlyMortgagePayment",
        "mortgage.otherProperties.*.outstandingMortgageBalance",
        "mortgage.otherProperties.*.purchasePrice", "mortgage.otherProperties.*.propertyNotes",
        "mortgage.otherProperties.*.monthlyNetRentalIncome",
        "mortgage.otherProperties.*.runningCost"
    ).isEqualTo(caseApplication);
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
    assertThat(result.getBroker().getDetails().getNetworkId())
        .isEqualTo(caseApplication.getBroker().getPaymentPath());
    assertThat(result.getMortgage().getMortgageAmount().intValue())
        .isEqualTo(caseApplication.getMortgage().getMortgageAmount());
    assertThat(result.getMortgage().getPropertyValue().intValue())
        .isEqualTo(caseApplication.getMortgage().getPropertyValue());
    assertThat(result.getMortgage().getPurchasePrice().intValue())
        .isEqualTo(caseApplication.getMortgage().getPurchasePrice());
    assertThat(result.getMortgage().getBuyToLet().getMonthlyRentalIncome().longValue())
        .isEqualTo(caseApplication.getMortgage().getBuyToLet().getMonthlyRentalIncome());
    assertThat(result.getMortgage().getBuyToLet().getLettingAgentCost().longValue())
        .isEqualTo(caseApplication.getMortgage().getBuyToLet().getLettingAgentCost());
    assertThat(result.getDirectDebit().getSortcode())
        .isEqualTo(caseApplication.getDirectDebit().getSortCode());
    assertThat(result.getMortgage().getInterestOnly().getRepaymentDetails().get(0).
        getOriginatingCurrency()).isEqualTo(caseApplication.getMortgage().getInterestOnly().
        getRepaymentDetails().get(0).getOriginatingCurrency());
    assertThat(result.getMortgage().getDeposits().get(0).getOriginatingCurrency()).isEqualTo(
        caseApplication.getMortgage().getDeposits().get(0).getOriginatingCurrency());

    OtherProperty otherProperty = caseApplication.getMortgage().getOtherProperties().get(0);
    OtherPropertyDto otherPropertyDto = result.getMortgage().getOtherProperties().get(0);
    assertThat(otherPropertyDto.getEstimatedPropertyValue().intValue())
        .isEqualTo(otherProperty.getEstimatedPropertyValue());
    assertThat(otherPropertyDto.getInterestOnlyAmount().intValue())
        .isEqualTo(otherProperty.getInterestOnlyAmount());
    assertThat(otherPropertyDto.getMonthlyMortgagePayment().intValue())
        .isEqualTo(otherProperty.getMonthlyMortgagePayment());
    assertThat(otherPropertyDto.getOutstandingMortgageBalance().intValue())
        .isEqualTo(otherProperty.getOutstandingMortgageBalance());
    assertThat(otherPropertyDto.getPurchasePrice().intValue())
        .isEqualTo(otherProperty.getPurchasePrice());
    assertThat(otherPropertyDto.getPropertyNotes()).isEqualTo(otherProperty.getPropertyNotes());

    assertThat(otherPropertyDto.getRunningCost()).isEqualTo(otherProperty.getHasPropertyRunningCosts());
  }

  @Test
  void toCaseApplicationDtoMapsCorrectlyForCaseNotes() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setMortgage(createValidInterestOnlyMortgage());

    List<RepaymentDetail> repaymentDetails = caseApplication.getMortgage().getInterestOnly()
        .getRepaymentDetails();
    RepaymentDetail repaymentDetail1 = new RepaymentDetail();
    repaymentDetail1.setRepaymentStrategyType(
        RepaymentDetail.RepaymentStrategyType.OTHER_MORTGAGE_PROPERTY.value());
    repaymentDetail1.setRepaymentValue(1000L);
    repaymentDetails.add(repaymentDetail1);
    RepaymentDetail repaymentDetail2 = new RepaymentDetail();
    repaymentDetail2.setRepaymentStrategyType(
        RepaymentDetail.RepaymentStrategyType.OTHER_MORTGAGE_PROPERTY.value());
    repaymentDetail2.setRepaymentValue(45950L);
    repaymentDetails.add(repaymentDetail2);

    caseApplication.setRepaymentStrategyAddresses(new ArrayList<>(Arrays
        .asList(null, "First address 1\nFirst address 2", "Second address 1\nSecond address 2")));

    CaseApplicationDto result = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, caseApplication,
            TEST_BROKER_CLAIMS);

    assertThat(result.getCaseNotes()).isEqualTo(
        "OTHER_MORTGAGE_PROPERTY 1000\nFirst address 1\nFirst address 2\n\nOTHER_MORTGAGE_PROPERTY 45950\nSecond address 1\nSecond address 2");
  }


  @Test
  void toCaseApplicationDtoMapsCorrectlyForCaseNotesOverMaxlength() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setMortgage(createValidInterestOnlyMortgage());

    List<RepaymentDetail> repaymentDetails = caseApplication.getMortgage().getInterestOnly()
        .getRepaymentDetails();
    RepaymentDetail repaymentDetail1 = new RepaymentDetail();
    repaymentDetail1.setRepaymentStrategyType(
        RepaymentDetail.RepaymentStrategyType.OTHER_MORTGAGE_PROPERTY.value());
    repaymentDetails.add(repaymentDetail1);

    caseApplication.setRepaymentStrategyAddresses(
        new ArrayList<>(Arrays.asList(null, randomAlphabetic(1001))));

    CaseApplicationDto result = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, caseApplication,
            TEST_BROKER_CLAIMS);

    assertThat(result.getCaseNotes().length()).isEqualTo(1000);
  }

  @Test
  void toCaseApplicationMapsCorrectlyForRepaymentStrategyAddresses() {

    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_REPAYMENT_STRATEGY_ADDRESSES,
        new ArrayList<>(Arrays.asList(null, "First address 1\\n\\nFirst address 2",
            "Second address 1\\n\\nSecond address 2")));

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getRepaymentStrategyAddresses()).isEqualTo(new ArrayList<>(Arrays
        .asList(null, "First address 1\\n\\nFirst address 2",
            "Second address 1\\n\\nSecond address 2")));
  }

  @Test
  void toCaseApplicationDtoReturnsNullWhenCaseApplicationNull() {
    assertThat(this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID, null,
        TEST_BROKER_CLAIMS)).isNull();
  }

  @Test
  void toCaseApplicationDtoMapsUsingSpecialistScheme() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setUsingSpecialistScheme(true);

    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    assertThat((Boolean) result.getJourneyData().get(CASE_JOURNEY_DATA_USING_SPECIALIST_SCHEME))
        .isTrue();
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
  }

  @Test
  void toCaseApplicationMapsUsingSpecialistScheme() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    final Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(CASE_JOURNEY_DATA_USING_SPECIALIST_SCHEME, true);
    caseApplicationDto.setJourneyData(journeyData);

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getUsingSpecialistScheme()).isTrue();
  }

  @Test
  void toCaseApplicationDtoMapsFirstTimeBuyer() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setFirstTimeBuyer(true);
    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertThat((Boolean) result.getJourneyData().get(CASE_JOURNEY_DATA_FIRST_TIME_BUYER)).isTrue();
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
  }

  @Test
  void toCaseApplicationDtoMapsIsProductSelectedAtDip() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setIsProductSelectedAtDip(true);
    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertThat((Boolean) result.getJourneyData().get(CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP)).isTrue();
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
  }

  @Test
  void toCaseApplicationDtoMapsBrokerJourneyVersion() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setBrokerJourneyVersion(12);
    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertThat(caseApplication.getBrokerJourneyVersion().equals(result.getJourneyData().get(
        CASE_JOURNEY_DATA_BROKER_JOURNEY_VERSION))).isTrue();
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
  }

  @Test
  void toCaseApplicationDtoSetsSalesIllustrationAccepted() {
    CaseApplication caseApplication = createValidCaseApplication();
    BankDetails bankDetails = createValidBankDetails();
    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertThat(result.getSalesIllustrations().get(0).getIsAccepted()).isTrue();
  }

  @Test
  void toCaseApplicationMapsFirstTimeBuyer() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    final Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(CASE_JOURNEY_DATA_FIRST_TIME_BUYER, true);
    caseApplicationDto.setJourneyData(journeyData);

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getFirstTimeBuyer()).isTrue();
  }

  @Test
  void testCaseApplicationSolicitorRoundTripMapping() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setSolicitor(createValidSolicitor());

    CaseApplicationDto caseApplicationDto = caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);

    CaseApplication roundTripCaseApplication = caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(roundTripCaseApplication).usingRecursiveComparison()
        .ignoringFields("mortgage.buyToLet").isEqualTo(caseApplication);
  }

  @Test
  void testCaseApplicationDipMapsCorrectly() {
    CaseApplication caseApplication = createValidCaseApplication();

    CaseApplicationDto caseApplicationDto = caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    CaseApplication roundTripCaseApplication = caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(roundTripCaseApplication).usingRecursiveComparison()
        .ignoringFields("mortgage.buyToLet").isEqualTo(caseApplication);
  }


  @Test
  void testMortgageSchemeMapper() {
    CaseApplication caseApplication = createValidCaseApplication();

    caseApplication.setSchemeType(CaseApplication.SchemeType.RIGHT_TO_BUY.value());
    CaseApplicationDto result_RIGHT_TO_BUY = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID,
            caseApplication, TEST_BROKER_CLAIMS);
    assertTrue(result_RIGHT_TO_BUY.getMortgage() != null && result_RIGHT_TO_BUY.getMortgage()
        .getRightToBuy());
    assertFalse(result_RIGHT_TO_BUY.getGovtSharedEquityScheme());
    assertThat(result_RIGHT_TO_BUY.getSchemeType()).isNull();
    assertThat(result_RIGHT_TO_BUY.getSchemeName()).isNull();
    CaseApplication backToCaseApplication = this.caseApplicationMapper
        .toCaseApplication(result_RIGHT_TO_BUY);
    assertThat(backToCaseApplication.getSchemeType()).isEqualTo(caseApplication.getSchemeType());

    caseApplication.setSchemeType(CaseApplication.SchemeType.HELP_TO_BUY_SHARED_EQUITY.value());
    CaseApplicationDto result_HELP_TO_BUY_SHARED_EQUITY = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID,
            caseApplication, TEST_BROKER_CLAIMS);
    assertTrue(
        result_HELP_TO_BUY_SHARED_EQUITY.getMortgage() != null && !result_HELP_TO_BUY_SHARED_EQUITY
            .getMortgage().getRightToBuy());
    assertTrue(result_HELP_TO_BUY_SHARED_EQUITY.getGovtSharedEquityScheme());
    assertThat(result_HELP_TO_BUY_SHARED_EQUITY.getSchemeType()).isEqualTo(CAPIE_HELP_TO_BUY);
    assertThat(result_HELP_TO_BUY_SHARED_EQUITY.getSchemeName()).isNull();
    backToCaseApplication = this.caseApplicationMapper
        .toCaseApplication(result_HELP_TO_BUY_SHARED_EQUITY);
    assertThat(backToCaseApplication.getSchemeType()).isEqualTo(caseApplication.getSchemeType());

    caseApplication.setSchemeType(SHARED_EQUITY.value());
    CaseApplicationDto result_SHARED_EQUITY = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID,
            caseApplication, TEST_BROKER_CLAIMS);
    assertTrue(result_SHARED_EQUITY.getMortgage() != null && !result_SHARED_EQUITY.getMortgage()
        .getRightToBuy());
    assertTrue(result_SHARED_EQUITY.getGovtSharedEquityScheme());
    assertThat(result_SHARED_EQUITY.getSchemeType()).isEqualTo(CAPIE_OTHER);
    assertThat(result_SHARED_EQUITY.getSchemeName()).isEqualTo(SHARED_EQUITY.value());
    backToCaseApplication = this.caseApplicationMapper.toCaseApplication(result_SHARED_EQUITY);
    assertThat(backToCaseApplication.getSchemeType()).isEqualTo(caseApplication.getSchemeType());

    caseApplication.setSchemeType(CaseApplication.SchemeType.OTHER.value());
    CaseApplicationDto result_OTHER = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertTrue(result_OTHER.getMortgage() != null && !result_OTHER.getMortgage().getRightToBuy());
    assertFalse(result_OTHER.getGovtSharedEquityScheme());
    assertThat(result_OTHER.getSchemeType()).isEqualTo(CAPIE_OTHER);
    assertThat(result_OTHER.getSchemeName()).isEqualTo(CAPIE_OTHER_NAME);
    backToCaseApplication = this.caseApplicationMapper.toCaseApplication(result_OTHER);
    assertThat(backToCaseApplication.getSchemeType()).isEqualTo(caseApplication.getSchemeType());
  }

  @Test
  void toCaseApplicationMapsHasCompletedDip() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, true);

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getHasCompletedDip()).isTrue();
  }

  @Test
  void toCaseApplicationMapsBrokerFeeCharged() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BROKER_FEE_CHARGED, true);

    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);

    assertThat(result.getBroker().getBrokerFeeCharged()).isTrue();
  }

  @Test
  void testCaseApplicationNorthernIrelandApplication() {
    CaseApplication caseApplication = createValidNorthernIrelandCaseApplication();
    CaseApplicationDto
        caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, caseApplication,
            TEST_BROKER_CLAIMS);
    CaseApplication caseApplicationResult = this.caseApplicationMapper
        .toCaseApplication(caseApplicationDto);

    assertThat(caseApplicationResult).usingRecursiveComparison().isEqualTo(caseApplication);
  }

  @Test
  void testCaseApplication_broker_firmName_userTradingNameAsPrimarySource() {
    CaseApplication caseApplication = createValidCaseApplication();
    BrokerInfo brokerClaims = TEST_BROKER_CLAIMS_BUILDER
        .firmDetails(FirmDetails.builder()
            .firmName("firmName")
            .tradingName("tradingName")
            .build())
        .build();

    CaseApplicationDto
        caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, caseApplication,
            brokerClaims);

    assertThat(caseApplicationDto.getBroker().getFirmName()).isEqualTo("tradingName");
  }

  @ParameterizedTest
  @CsvSource({"true", "false", "null"})
  void toCaseApplicationDto_leaseholdOwnershipTerm(String argumentString) {
    Boolean argument = Boolean.valueOf(argumentString);
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setLeaseholdOwnershipTerm(argument);

    CaseApplicationDto caseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, caseApplication, TEST_BROKER_CLAIMS);

    assertThat(caseApplicationDto.getJourneyData().get(CASE_JOURNEY_DATA_LEASEHOLD_OWNERSHIP_TERM))
        .isEqualTo(argument);
  }

  @ParameterizedTest
  @CsvSource({"true", "false", "null"})
  void leaseholdOwnershipTerm_roundTripMapping(String argumentLeaseholdOwnershipTermString) {
    Boolean argumentLeaseholdOwnershipTerm = Boolean.valueOf(argumentLeaseholdOwnershipTermString);
    CaseApplication argumentCaseApplication = createValidCaseApplication();
    argumentCaseApplication.setLeaseholdOwnershipTerm(argumentLeaseholdOwnershipTerm);

    CaseApplicationDto mappedCaseApplicationDto = this.caseApplicationMapper
        .toCaseApplicationDto(TEST_CASE_ID, argumentCaseApplication, TEST_BROKER_CLAIMS);
    assertThat(mappedCaseApplicationDto.getJourneyData().get(CASE_JOURNEY_DATA_LEASEHOLD_OWNERSHIP_TERM))
        .isEqualTo(argumentLeaseholdOwnershipTerm);

    CaseApplication mappedCaseApplication = this.caseApplicationMapper
        .toCaseApplication(mappedCaseApplicationDto);
    assertThat(mappedCaseApplication.getLeaseholdOwnershipTerm())
        .isEqualTo(argumentLeaseholdOwnershipTerm);
  }

  @Test
  void toCaseApplicationDto_mapsCorrectly_epcRatingAOrBDip() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setEpcRatingAOrBDip(true);
    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertThat((Boolean) result.getJourneyData().get(CASE_JOURNEY_DATA_EPC_RATING_A_OR_B_DIP)).isTrue();
    assertThat(result.getBroker().getDetails().getId()).isEqualTo(TEST_BROKER_ID);
  }

  @Test
  void toCaseApplication_mapsCorrectly_epcRatingAOrB() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_EPC_RATING_A_OR_B_DIP, true);
    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);
    assertThat(result.getEpcRatingAOrBDip()).isTrue();
  }

  @Test
  void toCaseApplicationDto_mapsCorrectly_isProductFeePaymentSelected() {
    CaseApplication caseApplication = createValidCaseApplication();
    caseApplication.setIsProductFeePaymentSelected(true);
    CaseApplicationDto result = this.caseApplicationMapper.toCaseApplicationDto(TEST_CASE_ID,
        caseApplication, TEST_BROKER_CLAIMS);
    assertThat((Boolean) result.getJourneyData().get(CASE_JOURNEY_DATA_IS_PRODUCT_FEE_PAYMENT_SELECTED)).isTrue();
  }

  @Test
  void toCaseApplication_mapsCorrectly_isProductFeePaymentSelected() {
    CaseApplicationDto caseApplicationDto = createValidCaseApplicationDto();
    caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_IS_PRODUCT_FEE_PAYMENT_SELECTED, true);
    CaseApplication result = this.caseApplicationMapper.toCaseApplication(caseApplicationDto);
    assertThat(result.getIsProductFeePaymentSelected()).isTrue();
  }

}
