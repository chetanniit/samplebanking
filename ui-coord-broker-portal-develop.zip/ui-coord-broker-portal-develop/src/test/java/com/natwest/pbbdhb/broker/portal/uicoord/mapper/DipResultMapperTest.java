package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createDipResponse;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.system.Clock;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        DipResultMapperImpl.class,
        Clock.class
})
class DipResultMapperTest {

    @Autowired
    private DipResultMapper mapper;

    @Test
    void toDecisionInPrincipleDtoMapsCorrectlyWithCustomDateTime() {
        DipExtendedResponse input = createDipResponse();

        DecisionInPrincipleDto result = mapper.toDecisionInPrincipleDtoWithCustomDateTime(input, "dateTime");

        assertThat(result).usingRecursiveComparison()
            .ignoringFields("dateTime", "additionalDetails.landlordCode")
            .isEqualTo(input);
        assertThat(result.getDateTime())
            .isEqualTo("dateTime");
    }

    @Test
    void toDecisionInPrincipleDtoMaps2am() {
        DipExtendedResponse input = createDipResponse();

        Clock twoAmClock = mock(Clock.class);
        LocalDateTime twoAm = LocalDateTime.of(1776, 7, 4, 2, 0, 0);
        when(twoAmClock.localNow()).thenReturn(twoAm);

        mapper.setClock(twoAmClock);
        String result = mapper.newDecisionInPrincipleDateTime();

        assertThat(result).isEqualTo("1776-07-04 02:00:00");
    }

    @Test
    void toDecisionInPrincipleDtoMaps2pm() {
        DipExtendedResponse input = createDipResponse();

        Clock twoPmClock = mock(Clock.class);
        LocalDateTime twoPm = LocalDateTime.of(1776, 7, 4, 14, 0, 0);
        when(twoPmClock.localNow()).thenReturn(twoPm);

        mapper.setClock(twoPmClock);
        String result = mapper.newDecisionInPrincipleDateTime();

        assertThat(result).isEqualTo("1776-07-04 14:00:00");
    }
}
