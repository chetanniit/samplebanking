package com.natwest.pbbdhb.broker.portal.uicoord.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.FmaErrorResultMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.exception.FMAException;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.model.fma.ResponseStatus;
import com.natwest.pbbdhb.openapi.fma.Error;
import com.natwest.pbbdhb.service.IntegrationService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FmaClientTest {

  private static final String TEST_CASE_ID = "t302834930248920";

  @Mock
  private IntegrationService integrationService;


  private FmaClient fmaClient;

  @BeforeEach
  void setUp() {
    this.fmaClient = new FmaClient(integrationService, new FmaErrorResultMapper());
  }

    @Test
    void submitFmaSuccessfully() throws FmaIntegrationException, FMAException, IOException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      Map<String, Object> journeyData = new HashMap<>();
      journeyData.put(ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
      caseApplication.setJourneyData(journeyData);
      application.setCaseApplication(caseApplication);
      FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
      fmaResponse.setResponseStatus(new ResponseStatus("200"));
      when(integrationService.getFMA(any())).thenReturn(fmaResponse);
      FullMortgageApplicationExtendedResponse response = fmaClient.submitFma(application);

      assertThat(response.getResponseStatus().getStatus()).isEqualTo("200");
    }

    @Test
    void submitFmaFailedWith400_ThrowsFmaValidationException() throws FMAException, IOException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      Map<String, Object> journeyData = new HashMap<>();
      journeyData.put(ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
      caseApplication.setJourneyData(journeyData);
      application.setCaseApplication(caseApplication);
      FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
      fmaResponse.setResponseStatus(new ResponseStatus("400"));
      when(integrationService.getFMA(any())).thenReturn(fmaResponse);

      FmaValidationException exception = assertThrows(
          FmaValidationException.class,
          () -> fmaClient.submitFma(application)
      );

      assertThat(exception.getMessage()).isEqualTo("FMA Response error status 400");
      assertThat(exception.getCode()).isEqualTo(ErrorCode.UNHANDLED);
    }

    @Test
    void submitFmaFailedWith400AndMissingExistingMortgagesError_ThrowsFmaValidationException() throws FMAException, IOException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      Map<String, Object> journeyData = new HashMap<>();
      journeyData.put(ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
      caseApplication.setJourneyData(journeyData);
      application.setCaseApplication(caseApplication);
      FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
      fmaResponse.setResponseStatus(new ResponseStatus("400"));
      List<Error> errors = new ArrayList<>();
      errors.add(new Error(null, null, "applicants[0] existingMortgages[] must not be empty"));
      errors.add(new Error(null, null, "applicants[1] existingMortgages[] must not be empty"));
      fmaResponse.setErrors(errors);
      when(integrationService.getFMA(any())).thenReturn(fmaResponse);

      FmaValidationException exception = assertThrows(
          FmaValidationException.class,
          () -> fmaClient.submitFma(application)
      );

      assertThat(exception.getMessage()).isEqualTo("2 errors. First error is: applicants[0] existingMortgages[] must not be empty");
      assertThat(exception.getCode()).isEqualTo(ErrorCode.MISSING_EXISTING_MORTGAGES);
    }

  @Test
  void submitFmaFailedWithProductExpiry400_ThrowsFmaValidationException() throws FMAException, IOException {

    String productExpiryMessage = "{\\\"productCode\\\":\\\"TO6397\\\",\\\"validProduct\\\":false,\\\"message\\\":\\\"Validation failed, product has been expired\\\"}";
    Application application = Application.builder().build();
    CaseApplicationDto caseApplication = makeCaseApplicationDto();
    Map<String, Object> journeyData = new HashMap<>();
    journeyData.put(ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
    caseApplication.setJourneyData(journeyData);
    application.setCaseApplication(caseApplication);
    FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
    fmaResponse.setResponseStatus(new ResponseStatus("400"));
    fmaResponse.setErrors(Arrays.asList(Error.builder().message(productExpiryMessage).build()));
    when(integrationService.getFMA(any())).thenReturn(fmaResponse);

    FmaValidationException exception = assertThrows(
        FmaValidationException.class,
        () -> fmaClient.submitFma(application)
    );

    assertThat(exception.getMessage()).isEqualTo(productExpiryMessage);
    assertThat(exception.getCode()).isEqualTo(ErrorCode.VALIDATION_PRODUCT_INVALID);
  }

    @Test
    void submitFmaFailedWith500WhenGetFmaReturnsResponseWithStatus500_ThrowsFmaIntegrationException()
        throws FMAException, IOException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      Map<String, Object> journeyData = new HashMap<>();
      journeyData.put(ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
      caseApplication.setJourneyData(journeyData);
      application.setCaseApplication(caseApplication);
      FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
      fmaResponse.setResponseStatus(new ResponseStatus("500"));
      fmaResponse.setErrors(Arrays.asList(Error.builder().message("error message").code(null).build()));
      when(integrationService.getFMA(any())).thenReturn(fmaResponse);
      FmaIntegrationException exception = assertThrows(
          FmaIntegrationException.class,
          () -> fmaClient.submitFma(application)
      );

      assertThat(exception.getMessage()).isEqualTo("error message");
    }

    @Test
    void submitFmaFailedWith500_ThrowsFmaIntegrationException() throws FMAException, IOException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = CaseApplicationDto.builder()
          .applicationStatus("SUBMIT_GMS_MOPS").caseId(TEST_CASE_ID).build();
      Map<String, Object> journeyData = new HashMap<>();
        journeyData.put(ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
        caseApplication.setJourneyData(journeyData);
        application.setCaseApplication(caseApplication);
        FullMortgageApplicationExtendedResponse fmaResponse = new FullMortgageApplicationExtendedResponse();
        fmaResponse.setResponseStatus(new ResponseStatus("500"));
        when(integrationService.getFMA(any())).thenThrow(new IOException("Some issue"));
        FmaIntegrationException exception = assertThrows(
            FmaIntegrationException.class,
            () -> fmaClient.submitFma(application)
        );

        assertThat(exception.getMessage()).isEqualTo("Some issue");
    }

  private CaseApplicationDto makeCaseApplicationDto() {
    CaseApplicationDto caseApplication = CaseApplicationDto.builder()
        .applicationStatus("SUBMIT_GMS_MOPS").caseId(TEST_CASE_ID).build();
    return caseApplication;
  }

}
