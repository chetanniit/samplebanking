package com.natwest.pbbdhb.broker.portal.uicoord.dip;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicantDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BUREAU_CALL_INFO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BureauCallInfoUtil.createBureauCallInfo;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.DIP_RESULT_DATE_TIME_FORMATTER;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.Collections.singletonMap;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonAddressDto;
import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BureauCallInfoUtil;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;


public class BureauCallManagerTest {

  BureauCallManager bureauCallManager = new BureauCallManager();

  @Test
  void hasMatchingBureauCallReturnsFalseIfNoBureauCallInfo() {
    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    List<ApplicantDto> applicantDtoList = new ArrayList<>();

    assertFalse(bureauCallManager.hasMatchingBureauCall(caseApplicationDto, applicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIf2ndApplicantAdded() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.getPersonalDetails().setFirstNames("Identical Twin");

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIf2ndApplicantRemoved() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.getPersonalDetails().setFirstNames("Identical Twin");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueForIdenticalSingleApplicant() {
    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueForIdenticalJointApplicants() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.getPersonalDetails().setFirstNames("Identical Twin");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseForIdenticalJointApplicantsWhenOrderIsDifferent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.getPersonalDetails().setFirstNames("Identical Twin");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant, firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfOneApplicantIsDifferent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.getPersonalDetails().setFirstNames("Identical Twin");
    ApplicantDto thirdApplicant = createValidApplicantDto();
    thirdApplicant.getPersonalDetails().setFirstNames("Other Sibling");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesAreDifferentInPrevious() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    ApplicantDto thirdApplicant = createValidApplicantDto();
    secondApplicant.getAddresses().get(1).setTown("OTHER");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesAreDifferentInCurrent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    ApplicantDto thirdApplicant = createValidApplicantDto();
    thirdApplicant.getAddresses().get(1).setTown("OTHER");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesOrderIsDifferent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.getAddresses().get(0).setTown("OTHER");
    ApplicantDto thirdApplicant = createValidApplicantDto();
    thirdApplicant.getAddresses().get(1).setTown("OTHER");

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesIsEmptyInPrevious() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    secondApplicant.setAddresses(emptyList());
    ApplicantDto thirdApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesIsEmptyInCurrent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    ApplicantDto thirdApplicant = createValidApplicantDto();
    thirdApplicant.setAddresses(emptyList());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesIsAddedInCurrent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    ApplicantDto thirdApplicant = createValidApplicantDto();
    thirdApplicant.getAddresses().add(PersonAddressDto.builder()
        .countryIsoCode("UK")
        .houseName("houseName")
        .houseNumber("houseNumber")
        .county("county")
        .postcode("postcode")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesIsRemovedInCurrent() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    ApplicantDto thirdApplicant = createValidApplicantDto();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .countryIsoCode("UK")
        .houseName("houseName")
        .houseNumber("houseNumber")
        .county("county")
        .postcode("postcode")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant, secondApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant, thirdApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingPostcode() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .postcode("postcode")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentPostcode() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .postcode("postcode1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .postcode("postcode2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingHouseNumber() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .houseNumber("houseNumber")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentHouseNumber() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .houseNumber("houseNumber1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .houseNumber("houseNumber2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingHouseName() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .houseName("houseName")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentHouseName() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .houseName("houseName1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .houseName("houseName2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingFlat() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .flat("flat")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentFlat() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .flat("flat1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .flat("flat2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingStreet() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .street("street")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentStreet() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .street("street1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .street("street2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingTown() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .town("town")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentTown() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .town("town1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .town("town2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingCounty() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .county("county")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentCounty() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .county("county1")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .county("county2")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsTrueIfAddressesHasMatchingCountry() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    PersonAddressDto address = PersonAddressDto.builder()
        .countryIsoCode("UK")
        .build();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(address);
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(address);

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseIfAddressesHasDifferentCountry() {
    ApplicantDto firstApplicant = createValidApplicantDto();
    ApplicantDto secondApplicant = createValidApplicantDto();
    firstApplicant.getAddresses().clear();
    firstApplicant.getAddresses().add(PersonAddressDto.builder()
        .countryIsoCode("UK")
        .build());
    secondApplicant.getAddresses().clear();
    secondApplicant.getAddresses().add(PersonAddressDto.builder()
        .countryIsoCode("US")
        .build());

    List<ApplicantDto> previousApplicantDtoList = ImmutableList.of(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(secondApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCallReturnsFalseForACaseWithOldModelStored()
      throws JsonProcessingException {
    ApplicantDto firstApplicant = ApplicantDto.builder()
        .personalDetails(PersonDetailsDto.builder()
            .firstNames("First Names")
            .lastName("Last Name")
            .dateOfBirth("dob")
            .build())
        .addresses(singletonList(PersonAddressDto.builder()
            .postcode("postcode")
            .build()))
        .build();

    String oldBureauCallInfo = "{\n"
        + "  \"dipId\": \"TEST_DIP_ID\",\n"
        + "  \"applicants\": [\n"
        + "    {\n"
        + "      \"firstNames\": \"First Names\",\n"
        + "      \"lastName\": \"Last Name\",\n"
        + "      \"dateOfBirth\": \"dob\",\n"
        + "      \"postcode\": \"postcode\" \n"
        + "    }\n"
        + "  ]\n"
        + "}";

    List<ApplicantDto> currentApplicantDtoList = ImmutableList.of(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    TypeReference<HashMap<String, Object>> typeRef = new TypeReference<HashMap<String, Object>>() {
    };
    HashMap<String, Object> journeyDataMap = new ObjectMapper()
        .readValue(oldBureauCallInfo, typeRef);
    caseApplicationDto
        .setJourneyData(singletonMap(CASE_JOURNEY_DATA_BUREAU_CALL_INFO, journeyDataMap));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCall_dipExpiry_longExpiry_ReturnsFalseForExpiredIdenticalSingleApplicant() {
    final LocalDateTime dipDateTime = LocalDateTime.of(2010, 1, 1, 9, 40);

    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    // up until now this would return true
    // but we are not setting an expired date for DIP
    DecisionInPrincipleDto decisionInPrincipleDto = new DecisionInPrincipleDto();
    caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(decisionInPrincipleDto));

    decisionInPrincipleDto.setDateTime(dipDateTime.format(DIP_RESULT_DATE_TIME_FORMATTER));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCall_dipExpiry_shortExpiry_ReturnsFalseForExpiredIdenticalSingleApplicant() {
    final LocalDateTime dipDateTime = LocalDate.now().atTime(9, 45).minusDays(31);

    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    // up until now this would return true
    // but we are not setting an expired date for DIP
    DecisionInPrincipleDto decisionInPrincipleDto = new DecisionInPrincipleDto();
    caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(decisionInPrincipleDto));

    decisionInPrincipleDto.setDateTime(dipDateTime.format(DIP_RESULT_DATE_TIME_FORMATTER));

    assertFalse(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCall_dipExpiry_shortValid_ReturnsFalseForExpiredIdenticalSingleApplicant() {
    final LocalDateTime dipDateTime = LocalDate.now().atTime(9, 45).minusDays(29);

    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    // up until now this would return true
    // but we are not setting an expired date for DIP
    DecisionInPrincipleDto decisionInPrincipleDto = new DecisionInPrincipleDto();
    caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(decisionInPrincipleDto));

    decisionInPrincipleDto.setDateTime(dipDateTime.format(DIP_RESULT_DATE_TIME_FORMATTER));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  @Test
  void hasMatchingBureauCall_dipExpiry_longValid_ReturnsFalseForExpiredIdenticalSingleApplicant() {
    final LocalDateTime dipDateTime = LocalDateTime.now();

    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    // up until now this would return true
    // but we are not setting an expired date for DIP
    DecisionInPrincipleDto decisionInPrincipleDto = new DecisionInPrincipleDto();
    caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(decisionInPrincipleDto));

    decisionInPrincipleDto.setDateTime(dipDateTime.format(DIP_RESULT_DATE_TIME_FORMATTER));

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }

  private static Stream<Arguments> hasMatchingBureauCall_dipExpiry_specificDates_args() {
    return Stream.of(
        Arguments.of("2024-05-08T11:00:00", "2024-06-06T12:00:00" , true),
        Arguments.of("2024-05-08T11:00:00", "2024-06-07T12:00:00" , false),
        Arguments.of("2024-05-09T11:00:00", "2024-06-07T12:00:00" , true),
        Arguments.of("2024-05-09T11:00:00", "2024-06-08T12:00:00" , false),
        Arguments.of("2024-05-10T11:00:00", "2024-06-08T12:00:00" , true),
        Arguments.of("2024-05-10T11:00:00", "2024-06-09T12:00:00" , false),
        // dip valid for 30 days regardless of hour
        Arguments.of("2024-05-01T11:00:00", "2024-05-30T23:59:59" , true),
        Arguments.of("2024-05-01T11:00:00", "2024-05-31T00:00:00" , false)
    );
  }

  @MethodSource("hasMatchingBureauCall_dipExpiry_specificDates_args")
  @ParameterizedTest
  void hasMatchingBureauCall_dipExpiry_specificDates(
      final LocalDateTime dipDateTime,
      final LocalDateTime executionDate,
      final boolean expectedResult
  ) {
    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    // up until now this would return true
    // but we are not setting an expired date for DIP
    DecisionInPrincipleDto decisionInPrincipleDto = new DecisionInPrincipleDto();
    caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(decisionInPrincipleDto));

    decisionInPrincipleDto.setDateTime(dipDateTime.format(DIP_RESULT_DATE_TIME_FORMATTER));

    boolean dipValid = bureauCallManager
        .hasMatchingBureauCallInternal(caseApplicationDto, currentApplicantDtoList, executionDate);
    Assertions.assertThat(dipValid).isEqualTo(expectedResult);
  }

  @Test
  void hasMatchingBureauCall_dipExpiry_scenarioMay2() {
    final LocalDateTime dipDateTime = LocalDateTime.of(2024, 5, 1, 11, 0);
    final LocalDateTime executionDate = LocalDateTime.of(2024, 5, 31, 12, 0);

    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    BureauCallInfoUtil.setBureauCallInfo(
        caseApplicationDto,
        createBureauCallInfo("TEST_DIP_ID", previousApplicantDtoList));

    // up until now this would return true
    // but we are not setting an expired date for DIP
    DecisionInPrincipleDto decisionInPrincipleDto = new DecisionInPrincipleDto();
    caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(decisionInPrincipleDto));

    decisionInPrincipleDto.setDateTime(dipDateTime.format(DIP_RESULT_DATE_TIME_FORMATTER));

    boolean dipValid = bureauCallManager
        .hasMatchingBureauCallInternal(caseApplicationDto, currentApplicantDtoList, executionDate);
    Assertions.assertThat(dipValid).isFalse();
  }

  @Test
  void bureauCallInfoMatchesAfterSetBureauCall() {
    ApplicantDto firstApplicant = createValidApplicantDto();

    List<ApplicantDto> previousApplicantDtoList = singletonList(firstApplicant);
    List<ApplicantDto> currentApplicantDtoList = singletonList(firstApplicant);

    CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
    DipExtendedResponse dipResponse = DipExtendedResponse.builder()
        .dipId("TEST_DIP_ID")
        .build();

    bureauCallManager.setBureauCallInfo(
        caseApplicationDto,
        dipResponse,
        previousApplicantDtoList);

    assertTrue(
        bureauCallManager.hasMatchingBureauCall(caseApplicationDto, currentApplicantDtoList));
  }
}
