package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.HardscoreDecision;
import com.natwest.pbbdhb.cases.dto.HardscoreDecisionDto;
import com.natwest.pbbdhb.model.fma.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        HardscoreDecisionMapperImpl.class
})
public class HardscoreDecisionMapperTest {

    @Autowired
    HardscoreDecisionMapper mapper;

    @Test
    void fmaResponseToHardscoreDecisionDtoMapsCorrectly() {
        FullMortgageApplicationExtendedResponse fmaResponse = createValidFmaResponse();

        HardscoreDecisionDto result = mapper.toHardscoreDecisionDto(fmaResponse);

        assertThat(result).usingRecursiveComparison()
                .ignoringFields("additionalDetails.postRetirement")
                .isEqualTo(fmaResponse.getData().getHardscoreDecision());
    }

    @Test
    void hardscoreDecisionRoundTripMapsCorrectly() {
        HardscoreDecision decision = createValidHardscoreDecision();

        HardscoreDecisionDto decisionDto = mapper.toHardscoreDecisionDto(decision);
        HardscoreDecision roundTrip = mapper.toHardscoreDecision(decisionDto);

        assertThat(roundTrip).isEqualTo(decision);
    }
}
