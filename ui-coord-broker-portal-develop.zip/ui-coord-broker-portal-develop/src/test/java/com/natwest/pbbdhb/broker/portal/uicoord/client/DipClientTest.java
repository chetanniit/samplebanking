package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ApplicationNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.exception.DIPException;
import com.natwest.pbbdhb.exception.MinMaxCalculatorException;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import com.natwest.pbbdhb.service.IntegrationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_HEADER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DipClientTest {

  private static final String TEST_DIP_ID = "t302834930248920";

  private final static String TEST_ENDPOINT_GET_DIP_CERTIFICATE = "http://test.endpoint/mortgages/v2/decision-in-principle/document/{caseId}";
  private final static String TEST_ENDPOINT_GET_DIP_DOCUMENT = "http://test.endpoint/mortgages/v2/decision-in-principle/document/{dipId}";

  private static final String CLIENT_ID_TEST = "CLIENT-ID";
  public static final String CASE_ID = "CASE_ID";
  public static final String DIP_ID = "DIP_ID";

  @Mock
  private RestTemplate restTemplate;

  @Mock
  private IntegrationService integrationService;

  private DipClient dipClient;

  @BeforeEach
  public void setUp() {
    this.dipClient = new DipClient(integrationService, TEST_ENDPOINT_GET_DIP_CERTIFICATE, TEST_ENDPOINT_GET_DIP_DOCUMENT, restTemplate, CLIENT_ID_TEST);
  }

  /*******************************************************************
   ***********************  Submit DIP *********************************
   *******************************************************************/

    @Test
    void submitDipSuccessfully()
        throws IOException, DIPException, MinMaxCalculatorException, DipIntegrationException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      application.setCaseApplication(caseApplication);
      DipExtendedResponse dipResponse = new DipExtendedResponse();
      dipResponse.setDipId(TEST_DIP_ID);
      when(integrationService.getDIP(any(), any())).thenReturn(dipResponse);
      DipExtendedResponse response = dipClient.submitDip(application);
      assertEquals(response.getDipId(), TEST_DIP_ID);
      assertNull(dipResponse.getErrorCode());
    }

    @Test
    void submitDipFailedWith400_ThrowsDipValidationException()
        throws IOException, DIPException, MinMaxCalculatorException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      application.setCaseApplication(caseApplication);
      DipExtendedResponse dipResponse = new DipExtendedResponse();
      dipResponse.setErrorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
      when(integrationService.getDIP(any(), any())).thenReturn(dipResponse);

      DipValidationException exception = assertThrows(
          DipValidationException.class,
          () -> dipClient.submitDip(application)
      );

      assertEquals(exception.getMessage(),"DIP response error code 400");
      assertEquals(exception.getCode(), ErrorCode.UNHANDLED);
    }

    @Test
    void submitDipFailedWith500_ThrowsDipIntegrationException()
       throws IOException, DIPException, MinMaxCalculatorException {
      Application application = Application.builder().build();
      CaseApplicationDto caseApplication = makeCaseApplicationDto();
      application.setCaseApplication(caseApplication);
      DipExtendedResponse dipResponse = new DipExtendedResponse();
      dipResponse.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
      when(integrationService.getDIP(any(), any())).thenReturn(dipResponse);

      DipIntegrationException exception = assertThrows(
          DipIntegrationException.class,
          () -> dipClient.submitDip(application)
      );

      assertEquals(exception.getMessage(),"DIP response error code 500");
    }

    @Test
    void submitDipFailedWithDIPException_ThrowsDipIntegrationException()
       throws IOException, DIPException, MinMaxCalculatorException {
      Application application = Application.builder().build();
      when(integrationService.getDIP(any(), any())).thenThrow(new DIPException(new Exception("DIP exception")));

      DipIntegrationException exception = assertThrows(
          DipIntegrationException.class,
          () -> dipClient.submitDip(application)
      );

      assertEquals(exception.getMessage(),"java.lang.Exception: DIP exception");
    }

    @Test
    void submitDipFailedWithMinMaxCalculatorException_ThrowsDipIntegrationException()
       throws IOException, DIPException, MinMaxCalculatorException {
      Application application = Application.builder().build();
      when(integrationService.getDIP(any(), any())).thenThrow(new MinMaxCalculatorException(new Exception("DIP exception")));

      DipIntegrationException exception = assertThrows(
          DipIntegrationException.class,
          () -> dipClient.submitDip(application)
      );

      assertEquals(exception.getMessage(),"java.lang.Exception: DIP exception");
    }

    @Test
    void submitDipFailedWithIOException_ThrowsDipIntegrationException()
       throws IOException, DIPException, MinMaxCalculatorException {
      Application application = Application.builder().build();
      when(integrationService.getDIP(any(), any())).thenThrow(new IOException(new Exception("DIP exception")));

      DipIntegrationException exception = assertThrows(
          DipIntegrationException.class,
          () -> dipClient.submitDip(application)
      );

      assertEquals(exception.getMessage(),"java.lang.Exception: DIP exception");
    }

    @Test
    void submitDipFailedWithThrowable_ThrowsDipIntegrationException()
        throws IOException, DIPException, MinMaxCalculatorException {
      Application application = Application.builder().build();
      when(integrationService.getDIP(any(), any())).thenThrow(new RuntimeException("Unexpected error"));

      DipIntegrationException exception = assertThrows(
          DipIntegrationException.class,
          () -> dipClient.submitDip(application)
      );

      assertEquals(exception.getMessage(),"Unexpected error");
    }

    /*******************************************************************
    ***********************  Amend DIP *********************************
    *******************************************************************/

  @Test
  void amendDipSuccess()
      throws IOException, DIPException, MinMaxCalculatorException, DipIntegrationException {
    Application application = Application.builder().build();
    CaseApplicationDto caseApplication = makeCaseApplicationDto();
    application.setCaseApplication(caseApplication);
    DipExtendedResponse dipResponse = new DipExtendedResponse();
    dipResponse.setDipId(TEST_DIP_ID);
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenReturn(dipResponse);
    DipExtendedResponse response = dipClient.amendDip(application, TEST_DIP_ID);
    assertEquals(response.getDipId(), TEST_DIP_ID);
    assertNull(dipResponse.getErrorCode());
  }

  @Test
  void amendDipFailedWith400_ThrowsDipValidationException()
      throws IOException, DIPException, MinMaxCalculatorException {
    Application application = Application.builder().build();
    CaseApplicationDto caseApplication = makeCaseApplicationDto();
    application.setCaseApplication(caseApplication);
    DipExtendedResponse dipResponse = new DipExtendedResponse();
    dipResponse.setErrorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenReturn(dipResponse);

    DipValidationException exception = assertThrows(
        DipValidationException.class,
        () -> dipClient.amendDip(application, TEST_DIP_ID)
    );

    assertEquals(exception.getMessage(),"DIP response error code 400");
    assertEquals(exception.getCode(), ErrorCode.UNHANDLED);
  }

  @Test
  void amendDipFailedWith500_ThrowsDipIntegrationException()
      throws IOException, DIPException, MinMaxCalculatorException {
    Application application = Application.builder().build();
    CaseApplicationDto caseApplication = makeCaseApplicationDto();
    application.setCaseApplication(caseApplication);
    DipExtendedResponse dipResponse = new DipExtendedResponse();
    dipResponse.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenReturn(dipResponse);

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.amendDip(application, TEST_DIP_ID)
    );

    assertEquals(exception.getMessage(),"DIP response error code 500");
  }

  @Test
  void amendDipFailedWithDIPException_ThrowsDipIntegrationException()
      throws IOException, DIPException, MinMaxCalculatorException {
    Application application = Application.builder().build();
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenThrow(new DIPException(new Exception("DIP exception")));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.amendDip(application, TEST_DIP_ID)
    );

    assertEquals(exception.getMessage(),"java.lang.Exception: DIP exception");
  }

  @Test
  void amendDipFailedWithMinMaxCalculatorException_ThrowsDipIntegrationException()
      throws IOException, DIPException, MinMaxCalculatorException {
    Application application = Application.builder().build();
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenThrow(new MinMaxCalculatorException(new Exception("DIP exception")));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.amendDip(application, TEST_DIP_ID)
    );

    assertEquals(exception.getMessage(),"java.lang.Exception: DIP exception");
  }

  @Test
  void amendDipFailedWithIOException_ThrowsDipIntegrationException()
      throws IOException, DIPException, MinMaxCalculatorException {
    Application application = Application.builder().build();
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenThrow(new IOException(new Exception("DIP exception")));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.amendDip(application, TEST_DIP_ID)
    );

    assertEquals(exception.getMessage(),"java.lang.Exception: DIP exception");
  }

  @Test
  void amendDipFailedWithThrowable_ThrowsDipIntegrationException()
      throws IOException, DIPException, MinMaxCalculatorException {
    Application application = Application.builder().build();
    when(integrationService.getDIPSubsequent(any(), any(), any())).thenThrow(new RuntimeException("Unexpected error"));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.amendDip(application, TEST_DIP_ID)
    );

    assertEquals(exception.getMessage(),"Unexpected error");
  }


  /*******************************************************************
   *****************  Download DIP Certificate ***********************
   *******************************************************************/

  @Test
  void getDipCertificateSuccessfully() throws DipIntegrationException {

    ResponseEntity<byte[]> expectedResponseEntity = ResponseEntity.ok("test".getBytes());
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_CERTIFICATE, HttpMethod.GET, expectedHttpEntity, byte[].class,
        CASE_ID))
        .thenReturn(expectedResponseEntity);

    InputStream response = this.dipClient.getDipCertificate(BRAND_DEFAULT, CASE_ID);

    assertNotNull(response);
  }

  @Test
  void getDipCertificateFailedWith400_ThrowsDipIntegrationException() {

    ResponseEntity<byte[]> expectedResponseEntity = ResponseEntity.badRequest().body("test".getBytes());
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_CERTIFICATE, HttpMethod.GET, expectedHttpEntity, byte[].class,
        CASE_ID))
        .thenReturn(expectedResponseEntity);

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipCertificate(BRAND_DEFAULT, CASE_ID)
    );
    assertEquals(exception.getMessage(),"Could not load DIP PDF for case ID: CASE_ID");
  }

  @Test
  void getDipCertificateFailedWithNullBody_ThrowsDipIntegrationException() {

    ResponseEntity<byte[]> expectedResponseEntity = ResponseEntity.ok(null);
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_CERTIFICATE, HttpMethod.GET, expectedHttpEntity, byte[].class,
        CASE_ID))
        .thenReturn(expectedResponseEntity);

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipCertificate(BRAND_DEFAULT, CASE_ID)
    );
    assertEquals(exception.getMessage(),"Could not load DIP PDF for case ID: CASE_ID");
  }

  @Test
  void getDipCertificateFailedWithRestClientException_ThrowsDipIntegrationException() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_CERTIFICATE, HttpMethod.GET, expectedHttpEntity, byte[].class,
        CASE_ID))
        .thenThrow(new RestClientException("Rest Client Exception"));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipCertificate(BRAND_DEFAULT, CASE_ID)
    );
    assertEquals(exception.getMessage(),"Rest Client Exception");
  }

  @Test
  void getDipCertificateFailedWithThrowable_ThrowsDipIntegrationException() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_CERTIFICATE, HttpMethod.GET, expectedHttpEntity, byte[].class,
        CASE_ID))
        .thenThrow(new RuntimeException("Runtime Exception"));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipCertificate(BRAND_DEFAULT, CASE_ID)
    );
    assertEquals(exception.getMessage(),"Runtime Exception");
  }



  /*******************************************************************
   *****************  Download DIP Document **************************
   *******************************************************************/

  @Test
  void getDipDocumentSuccessfully() throws DipIntegrationException {

    ResponseEntity<byte[]> expectedResponseEntity = ResponseEntity.ok("test".getBytes());
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_DOCUMENT, HttpMethod.GET, expectedHttpEntity, byte[].class,
        DIP_ID))
        .thenReturn(expectedResponseEntity);

    InputStream response = this.dipClient.getDipDocumentByDipId(BRAND_DEFAULT, DIP_ID);

    assertNotNull(response);
  }

  @Test
  void getDipDocumentFailedWith400_ThrowsDipIntegrationException() {

    ResponseEntity<byte[]> expectedResponseEntity = ResponseEntity.badRequest().body("test".getBytes());
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_DOCUMENT, HttpMethod.GET, expectedHttpEntity, byte[].class,
        DIP_ID))
        .thenReturn(expectedResponseEntity);

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipDocumentByDipId(BRAND_DEFAULT, DIP_ID)
    );
    assertEquals(exception.getMessage(),"Could not load DIP PDF for DIP ID: DIP_ID");
  }

  @Test
  void getDipDocumentFailedWithNullBody_ThrowsDipIntegrationException() {

    ResponseEntity<byte[]> expectedResponseEntity = ResponseEntity.ok(null);
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_DOCUMENT, HttpMethod.GET, expectedHttpEntity, byte[].class,
        DIP_ID))
        .thenReturn(expectedResponseEntity);

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipDocumentByDipId(BRAND_DEFAULT, DIP_ID)
    );
    assertEquals(exception.getMessage(),"Could not load DIP PDF for DIP ID: DIP_ID");
  }

  @Test
  void getDipDocumentFailedWithRestClientException_ThrowsDipIntegrationException() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_DOCUMENT, HttpMethod.GET, expectedHttpEntity, byte[].class,
        DIP_ID))
        .thenThrow(new RestClientException("Rest Client Exception"));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipDocumentByDipId(BRAND_DEFAULT, DIP_ID)
    );
    assertEquals(exception.getMessage(),"Rest Client Exception");
  }

  @Test
  void getDipDocumentFailedWithHttpClientErrorExceptionNotFound_ThrowsApplicationNotFoundException() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_DOCUMENT, HttpMethod.GET, expectedHttpEntity, byte[].class,
        DIP_ID))
        .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

    ApplicationNotFoundException exception = assertThrows(
        ApplicationNotFoundException.class,
        () -> dipClient.getDipDocumentByDipId(BRAND_DEFAULT, DIP_ID)
    );
    assertEquals(exception.getMessage(),"Could not load DIP PDF for DIP ID: DIP_ID");
  }

  @Test
  void getDipDocumentFailedWithThrowable_ThrowsDipIntegrationException() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(BRAND_HEADER, BRAND_DEFAULT);
    headers.add(CLIENT_ID_HEADER, CLIENT_ID_TEST);
    HttpEntity<Void> expectedHttpEntity = new HttpEntity<>(headers);
    when(restTemplate.exchange(TEST_ENDPOINT_GET_DIP_DOCUMENT, HttpMethod.GET, expectedHttpEntity, byte[].class,
        DIP_ID))
        .thenThrow(new RuntimeException("Runtime Exception"));

    DipIntegrationException exception = assertThrows(
        DipIntegrationException.class,
        () -> dipClient.getDipDocumentByDipId(BRAND_DEFAULT, DIP_ID)
    );
    assertEquals(exception.getMessage(),"Runtime Exception");
  }

  private CaseApplicationDto makeCaseApplicationDto() {
    CaseApplicationDto caseApplication = CaseApplicationDto.builder()
        .applicationStatus("SUBMIT_GMS_MOPS").caseId(TEST_DIP_ID).build();
    return caseApplication;
  }
}
