package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicant;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_AFTER_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_CASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SAVE_BROKER_CASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.SIZE_AT_LEAST_ONE_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.BRAND_RBS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.CUSTOM_HTTP_BODY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.createValidBrokerCase;
import static java.util.Collections.emptyList;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.AdditionalBorrowing;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BasicAddress;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.EstateAgent;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Fee;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherIncomeDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerCaseService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.BrokerCaseValidator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

@WebMvcTest
@ContextConfiguration(classes = {BrokerCaseController.class, ControllerAdvice.class, BrokerCaseValidator.class})
public class BrokerCaseControllerValidationTest {

    @MockBean
    private BrokerCaseService brokerCaseService;

    @MockBean
    private UserClaimsProvider userClaimsProvider;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void saveBrokerCaseValidRequest() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
        BrokerCase brokerCaseResponse = createValidBrokerCase();
        String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
        when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
            .thenReturn(brokerCaseResponse);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }

    @Test
    public void saveBrokerCaseValidRequestWithNonUKAddressAndInvalidUKPostcode() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        BasicAddress addr = brokerCaseRequest.getCaseApplication().getEstateAgent().getAddress();
        addr.setCountry("ZZ");
        addr.setPostcode("12345");
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
        BrokerCase brokerCaseResponse = createValidBrokerCase();
        String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
        when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
                .thenReturn(brokerCaseResponse);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }
    @Test
    public void saveBrokerCaseValidRequestWithNonUKAddressAndNullPostcode() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        BasicAddress addr = brokerCaseRequest.getCaseApplication().getEstateAgent().getAddress();
        addr.setCountry("ZZ");
        addr.setPostcode(null);
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
        BrokerCase brokerCaseResponse = createValidBrokerCase();
        String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
        when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
                .thenReturn(brokerCaseResponse);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }
    @Test
    public void saveBrokerCaseValidRequestWithValidAdditionalBorrowingDetails() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        Mortgage mortgage = brokerCaseRequest.getCaseApplication().getMortgage();
        mortgage.setMortgageType("MIXED");
        mortgage.setMortgageAdvised("ADVICE");
        mortgage.setOutstandingMortgage(9L);
        AdditionalBorrowing additionalBorrowingItem = new AdditionalBorrowing();
        additionalBorrowingItem.setAmount(9999L);
        additionalBorrowingItem.setReason("OTHER_DEBT_CONSOLIDATION");
        additionalBorrowingItem.setBorrowingDetails("Valid Reason");
        mortgage.setAdditionalBorrowings(Collections.singletonList(additionalBorrowingItem));
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
        BrokerCase brokerCaseResponse = createValidBrokerCase();
        String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
        when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
            .thenReturn(brokerCaseResponse);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
            .contentType(MediaType.APPLICATION_JSON)
            .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(content().json(responseBodyContent));
    }

    @Test
    public void saveBrokerCaseValidRequestWithInValidMultipleAdditionalBorrowingDetails() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();

        Mortgage mortgage = brokerCaseRequest.getCaseApplication().getMortgage();
        mortgage.setMortgageType("MIXED");
        mortgage.setMortgageAdvised("ADVICE");
        mortgage.setOutstandingMortgage(9L);

        List<AdditionalBorrowing> additionalBorrowingList = new ArrayList<AdditionalBorrowing>();

        AdditionalBorrowing adBo1 = new AdditionalBorrowing();
        adBo1.setAmount(9999L);
        adBo1.setReason("OTHER");
        adBo1.setBorrowingDetails("Valid Other Reasons less than 50");

        AdditionalBorrowing adBo2 = new AdditionalBorrowing();
        adBo2.setAmount(9999L);
        adBo2.setReason("OTHER_DEBT_CONSOLIDATION");
        adBo2.setBorrowingDetails("Other_Debt_Consolidated Reason less than 50");

        AdditionalBorrowing adBo3 = new AdditionalBorrowing();
        adBo3.setAmount(9999L);
        adBo3.setReason("BUY_NEW_CAR");

        additionalBorrowingList.add(adBo1);
        additionalBorrowingList.add(adBo2);
        additionalBorrowingList.add(adBo3);
        mortgage.setAdditionalBorrowings(additionalBorrowingList);

        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
        BrokerCase brokerCaseResponse = createValidBrokerCase();
        String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
        when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
            .thenReturn(brokerCaseResponse);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
            .contentType(MediaType.APPLICATION_JSON)
            .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(content().json(responseBodyContent));
    }

    @Test
    public void saveBrokerCaseWithValidBrandHeader() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
        BrokerCase brokerCaseResponse = createValidBrokerCase();

        when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
            .thenReturn(brokerCaseResponse);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .header(BRAND_HEADER, BRAND_RBS)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request).andExpect(status().isOk());

        verify(brokerCaseService).saveBrokerCase(eq(BRAND_RBS), eq(TEST_CASE_ID), eq(brokerCaseRequest));
    }

    @Test
    public void saveBrokerCaseWithInvalidBrandHeader() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        String invalidBrand = "INVALID_BRAND";

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .header(BRAND_HEADER, invalidBrand)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("400"))
                .andExpect(jsonPath("$.title").value("Validation Failure"))
                .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
                .andExpect(jsonPath("$.errors[0].title").value("saveBrokerCase.brand"))
                .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

        verifyNoInteractions(brokerCaseService);
    }
  @Test
  public void saveBrokerCaseWithOneDecimalCurrencyRate() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    brokerCaseRequest.getCaseApplication().setCurrencyExchangeRate(BigDecimal.valueOf(123.1));
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }
  @Test
  public void saveBrokerCaseReturnsValidationErrorWithBankOpeningDateAsToday() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    brokerCaseRequest.getApplicants().get(0).getMainBankDetails().setDateOpened(LocalDate.now().toString());
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.status").value("400"))
        .andExpect(jsonPath("$.title").value("Validation Failure"))
        .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
        .andExpect(jsonPath("$.errors[0].title").value("applicants[0].mainBankDetails.dateOpened"))
        .andExpect(jsonPath("$.errors[0].description").value("must be a date in the past in format 'yyyy-MM-dd'"));
  }
  @Test
  public void saveBrokerCaseReturnsValidationErrorWithBankOpeningDateAsTomorrow() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    brokerCaseRequest.getApplicants().get(0).getMainBankDetails().setDateOpened(LocalDate.now().plusDays(1).toString());
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.status").value("400"))
        .andExpect(jsonPath("$.title").value("Validation Failure"))
        .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
        .andExpect(jsonPath("$.errors[0].title").value("applicants[0].mainBankDetails.dateOpened"))
        .andExpect(jsonPath("$.errors[0].description").value("must be a date in the past in format 'yyyy-MM-dd'"));
  }
  @Test
  public void saveBrokerCaseReturnsOkWithBankOpeningDateAsYesterday() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    brokerCaseRequest.getApplicants().get(0).getMainBankDetails().setDateOpened(LocalDate.now().minusDays(1).toString());
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }
  @Test
  public void saveBrokerCaseWithTwoDecimalCurrencyRate() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    brokerCaseRequest.getCaseApplication().setCurrencyExchangeRate(BigDecimal.valueOf(123.12));
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }
  @Test
  public void saveBrokerCaseWithThreeDecimalCurrencyRate() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    brokerCaseRequest.getCaseApplication().setCurrencyExchangeRate(BigDecimal.valueOf(123.123));
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.status").value("400"))
        .andExpect(jsonPath("$.title").value("Validation Failure"))
        .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
        .andExpect(jsonPath("$.errors[0].title").value("caseApplication.currencyExchangeRate"))
        .andExpect(jsonPath("$.errors[0].description").value("must be a value between 0.00 and 99999999.99 with up to 2 decimal places"));;
  }
  @Test
  public void saveBrokerCaseWithEmptyBorrowingDetails() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();

    when(brokerCaseService.saveBrokerCase(BRAND_RBS, TEST_CASE_ID, brokerCaseRequest))
        .thenReturn(brokerCaseRequest);

    AdditionalBorrowing additionalBorrowingItem = new AdditionalBorrowing();
    additionalBorrowingItem.setAmount(9_999L);
    additionalBorrowingItem.setReason("HOME_IMPROVEMENT");
    additionalBorrowingItem.setBorrowingDetails("");
    brokerCaseRequest.getCaseApplication().getMortgage().setAdditionalBorrowings(Collections.singletonList(additionalBorrowingItem));

    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .header(BRAND_HEADER, BRAND_RBS)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }
    @Test
    public void saveBrokerCaseMissingCaseIdReturnsNotFoundError() throws Exception {
        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, (String) null)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(this.objectMapper.writeValueAsString(createValidApplicant()));

        this.mockMvc.perform(request)
                .andExpect(status().isNotFound());
    }

    @Test
    public void saveBrokerCaseInvalidContentTypeReturnsUnsupportedMediaTypeError() throws Exception {
        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("text");

        this.mockMvc.perform(request)
                .andExpect(status().isUnsupportedMediaType());
    }

    @Test
    public void saveBrokerCaseBadRequestErrorReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        String body = "{\"errorCount\":2,\"errors\":[{\"object\":\"object1\",\"field\":\"field1\",\"message\":\"message1\"},{\"field\":\"field2\",\"message\":\"message2\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(brokerCaseService.saveBrokerCase(anyString(), anyString(), any(BrokerCase.class))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Bad Request"))
            .andExpect(jsonPath("$.description").value("The following errors occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("field1"))
            .andExpect(jsonPath("$.errors[0].description").value("message1"))
            .andExpect(jsonPath("$.errors[1].title").value("field2"))
            .andExpect(jsonPath("$.errors[1].description").value("message2"));
    }

    @Test
    public void saveBrokerCaseBadRequestErrorReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(brokerCaseService.saveBrokerCase(anyString(), anyString(), any(BrokerCase.class))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Bad Request"))
            .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @Test
    public void saveBrokerCaseInternalServerErrorReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        String body = "{\"errorCount\":2,\"errors\":[{\"object\":\"object1\",\"field\":\"field1\",\"message\":\"message1\"},{\"field\":\"field2\",\"message\":\"message2\"}]}";

        HttpServerErrorException internalServerErrorException = HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(brokerCaseService.saveBrokerCase(anyString(), anyString(), any(BrokerCase.class))).thenThrow(internalServerErrorException);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isInternalServerError())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("500"))
            .andExpect(jsonPath("$.title").value("Internal Server Error"))
            .andExpect(jsonPath("$.description").value("The following errors occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("field1"))
            .andExpect(jsonPath("$.errors[0].description").value("message1"))
            .andExpect(jsonPath("$.errors[1].title").value("field2"))
            .andExpect(jsonPath("$.errors[1].description").value("message2"));
    }

    @Test
    public void saveBrokerCaseInternalServerErrorReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        HttpServerErrorException internalServerErrorException = HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(brokerCaseService.saveBrokerCase(anyString(), anyString(), any(BrokerCase.class))).thenThrow(internalServerErrorException);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isInternalServerError())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("500"))
            .andExpect(jsonPath("$.title").value("Internal Server Error"))
            .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @Test
    public void saveBrokerCaseConflictReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        String body = "{\"errorCount\":1,\"errors\":[{\"message\":\"message1\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.CONFLICT, HttpStatus.CONFLICT.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(brokerCaseService.saveBrokerCase(anyString(), anyString(), any(BrokerCase.class))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isConflict())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("409"))
            .andExpect(jsonPath("$.title").value("Conflict"))
            .andExpect(jsonPath("$.description").value("The following errors occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("Error"))
            .andExpect(jsonPath("$.errors[0].description").value("message1"));
    }

    @Test
    public void saveBrokerCaseConflictReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.CONFLICT, HttpStatus.CONFLICT.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(brokerCaseService.saveBrokerCase(anyString(), anyString(), any(BrokerCase.class))).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isConflict())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("409"))
            .andExpect(jsonPath("$.title").value("Conflict"))
            .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("saveBrokerCaseArgs")
    public void saveBrokerCaseRequestWithValidationErrorsReturnsBadRequestError(String testDescription, Consumer<BrokerCase> mutator,
                                                                                ErrorResponse expected) throws Exception {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        mutator.accept(brokerCaseRequest);

        RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.objectMapper.writeValueAsString(brokerCaseRequest));

        MvcResult mvcResult = this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        ErrorResponse response = this.objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ErrorResponse.class);

        assertThat(response)
                .usingRecursiveComparison()
                .ignoringCollectionOrder()
                .isEqualTo(expected);
    }

    @Test
    public void getBrokerCaseValidRequest() throws Exception {
        BrokerCase brokerCaseResponse = createValidBrokerCase();
        String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);

        when(brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(brokerCaseResponse);

        RequestBuilder request = get(PATH_GET_BROKER_CASE, TEST_CASE_ID);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));

        verify(brokerCaseService).getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID);
    }

    @Test
    public void getBrokerCaseWithValidBrandHeader() throws Exception {
        BrokerCase brokerCaseResponse = createValidBrokerCase();

        when(brokerCaseService.getBrokerCase(BRAND_RBS, TEST_CASE_ID)).thenReturn(brokerCaseResponse);

        RequestBuilder request = get(PATH_GET_BROKER_CASE, TEST_CASE_ID)
                .header(BRAND_HEADER, BRAND_RBS);

        this.mockMvc.perform(request).andExpect(status().isOk());

        verify(brokerCaseService).getBrokerCase(BRAND_RBS, TEST_CASE_ID);
    }

    @Test
    public void getBrokerCaseWithInvalidBrandHeader() throws Exception {
      String invalidBrand = "INVALID_BRAND";

      RequestBuilder request = get(PATH_GET_BROKER_CASE, TEST_CASE_ID)
          .header(BRAND_HEADER, invalidBrand);

      this.mockMvc.perform(request)
          .andExpect(status().isBadRequest())
          .andExpect(content().contentType(MediaType.APPLICATION_JSON))
          .andExpect(jsonPath("$.status").value("400"))
          .andExpect(jsonPath("$.title").value("Validation Failure"))
          .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
          .andExpect(jsonPath("$.errors[0].title").value("getBrokerCase.brand"))
          .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

      verifyNoInteractions(brokerCaseService);
    }

    @Test
    public void shouldReturnForbiddenErrorWhenPermissionDeniedThrown() throws Exception {

        when(brokerCaseService.getBrokerCase(any(), any()))
            .thenThrow(new PermissionDeniedException("Permission Denied"));

        RequestBuilder request = get(PATH_GET_BROKER_CASE, TEST_CASE_ID)
                .header(BRAND_HEADER, BRAND_RBS);

        this.mockMvc.perform(request)
            .andExpect(status().isForbidden())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("403"))
            .andExpect(jsonPath("$.title").value("Forbidden"))
            .andExpect(jsonPath("$.description").value("Permission Denied"));
    }

    @Test
    public void shouldReturnForbiddenErrorWhenUpdateNotPermittedThrown() throws Exception {

        when(brokerCaseService.getBrokerCase(any(), any()))
                .thenThrow(new UpdateNotPermittedException(MSG_NO_UPDATE_AFTER_FMA));

        RequestBuilder request = get(PATH_GET_BROKER_CASE, TEST_CASE_ID)
                .header(BRAND_HEADER, BRAND_RBS);

        this.mockMvc.perform(request)
                .andExpect(status().isForbidden())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("403"))
                .andExpect(jsonPath("$.title").value("Update not permitted"))
                .andExpect(jsonPath("$.description").value(MSG_NO_UPDATE_AFTER_FMA));
    }

    @Test
    public void shouldReturnInternalServerErrorWhenUnexpectedExceptionThrown() throws Exception {

        when(brokerCaseService.getBrokerCase(any(), any()))
            .thenThrow(new RuntimeException("Failed"));

        RequestBuilder request = get(PATH_GET_BROKER_CASE, TEST_CASE_ID)
            .header(BRAND_HEADER, BRAND_RBS);

        this.mockMvc.perform(request)
            .andExpect(status().isInternalServerError())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("500"))
            .andExpect(jsonPath("$.title").value("Internal Server Error"));
    }

    @Test
    public void saveBrokerCaseValidRequestWithValidIsProductSelectedAtDipValue() throws Exception {
      BrokerCase brokerCaseRequest = createValidBrokerCase();
      CaseApplication caseApplication = brokerCaseRequest.getCaseApplication();
      caseApplication.setIsProductSelectedAtDip(true);
      String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
      BrokerCase brokerCaseResponse = createValidBrokerCase();
      String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
      when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
        .thenReturn(brokerCaseResponse);

      RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

      this.mockMvc.perform(request)
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(content().json(responseBodyContent));
  }

  @Test
  public void saveBrokerCaseValidRequestWithValidBrokerJourneyVersionValue() throws Exception {
    BrokerCase brokerCaseRequest = createValidBrokerCase();
    CaseApplication caseApplication = brokerCaseRequest.getCaseApplication();
    caseApplication.setBrokerJourneyVersion(12);
    String requestBodyContent = this.objectMapper.writeValueAsString(brokerCaseRequest);
    BrokerCase brokerCaseResponse = createValidBrokerCase();
    String responseBodyContent = this.objectMapper.writeValueAsString(brokerCaseResponse);
    when(brokerCaseService.saveBrokerCase(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), eq(brokerCaseRequest)))
        .thenReturn(brokerCaseResponse);

    RequestBuilder request = put(PATH_SAVE_BROKER_CASE, TEST_CASE_ID)
        .contentType(MediaType.APPLICATION_JSON)
        .content(requestBodyContent);

    this.mockMvc.perform(request)
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(content().json(responseBodyContent));
  }

    private static Stream<Arguments> saveBrokerCaseArgs() {
        return Stream.of(
                Arguments.of("Applicants list empty", (Consumer<BrokerCase>) a -> a.setApplicants(emptyList()),
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("applicants", SIZE_AT_LEAST_ONE_MSG)))),
                Arguments.of("Case application multiple errors", (Consumer<BrokerCase>) a -> {
                            Mortgage mortgage = a.getCaseApplication().getMortgage();
                            mortgage.setMortgageType("invalid");
                            mortgage.setMortgageAdvised("invalid");
                            mortgage.setOutstandingMortgage(999_999_999L);
                            AdditionalBorrowing additionalBorrowingItem = new AdditionalBorrowing();
                            additionalBorrowingItem.setAmount(1_999_999_999L);
                            additionalBorrowingItem.setReason("invalid");
                            additionalBorrowingItem.setBorrowingDetails("");
                            mortgage.setAdditionalBorrowings(Collections.singletonList(additionalBorrowingItem));
                        },

                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                            new ErrorResponseDetail("caseApplication.mortgage.mortgageType", "must be any of: REPAYMENT, INTEREST_ONLY, MIXED"),
                            new ErrorResponseDetail("caseApplication.mortgage.mortgageAdvised", "must be any of: ADVICE, REJECTED_ADVICE_EXECUTION_ONLY"),
                            new ErrorResponseDetail("caseApplication.mortgage.outstandingMortgage", "must be less than or equal to 99999999"),
                            new ErrorResponseDetail("caseApplication.mortgage.additionalBorrowings[0].reason", "must be any of: HOME_IMPROVEMENT, HOUSE_PURCHASE, HOLIDAY, BUY_NEW_CAR, BUY_USED_CAR, DEBT_CONSOLIDATION, OTHER, OTHER_DEBT_CONSOLIDATION"),
                            new ErrorResponseDetail("caseApplication.mortgage.additionalBorrowings[0].amount", "must be less than or equal to 99999999")
                        ))),
                Arguments.of("Case application other errors", (Consumer<BrokerCase>) a -> {
                            Mortgage mortgage = a.getCaseApplication().getMortgage();
                            AdditionalBorrowing additionalBorrowingItem = new AdditionalBorrowing();
                            additionalBorrowingItem.setAmount(1L);
                            additionalBorrowingItem.setReason("OTHER");
                            mortgage.setAdditionalBorrowings(Collections.singletonList(additionalBorrowingItem));
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                            new ErrorResponseDetail("caseApplication.mortgage.additionalBorrowings[0]", "borrowingDetails is mandatory when reason == OTHER")
                        ))),
                Arguments.of("Case application OTHER_DEBT_CONSOLIDATION errors", (Consumer<BrokerCase>) a -> {
                      Mortgage mortgage = a.getCaseApplication().getMortgage();
                      AdditionalBorrowing additionalBorrowingItem = new AdditionalBorrowing();
                      additionalBorrowingItem.setAmount(1L);
                      additionalBorrowingItem.setReason("OTHER_DEBT_CONSOLIDATION");
                      mortgage.setAdditionalBorrowings(Collections.singletonList(additionalBorrowingItem));
                    },
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("caseApplication.mortgage.additionalBorrowings[0]", "borrowingDetails is mandatory when reason == OTHER_DEBT_CONSOLIDATION")
                    ))),
                Arguments.of("Applicants multiple errors", (Consumer<BrokerCase>) a -> {
                            a.getApplicants().get(0).getPersonalDetails().setTitle(null);
                        },
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                        new ErrorResponseDetail("applicants[0].personalDetails.title", MUST_NOT_BE_NULL_ERROR_MESSAGE)
                    ))),
                Arguments.of("Estate agent multiple errors", (Consumer<BrokerCase>) a -> {
                            EstateAgent estateAgent = a.getCaseApplication().getEstateAgent();
                            estateAgent.setAgencyName("");
                            estateAgent.setTelephoneNumber("007");
                            BasicAddress addr = estateAgent.getAddress();
                            addr.setCountry("ZZZ");
                            addr.setHouseNumber(randomAlphabetic(6));
                            addr.setHouseName(randomAlphabetic(23));
                            addr.setFlatNameOrNumber(randomAlphabetic(11));
                            addr.setStreet(randomAlphabetic(31));
                            addr.setTown(randomAlphabetic(29));
                            addr.setCounty(randomAlphabetic(119));
                            addr.setPostcode("6H6 6BU");
                        },
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                        new ErrorResponseDetail("caseApplication.estateAgent.agencyName", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.estateAgent.telephoneNumber", "Badly formed phone number"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.country", "size must be between 2 and 2"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.houseNumber", "size must be between 0 and 5"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.houseName", "size must be between 0 and 22"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.flatNameOrNumber", "size must be between 0 and 10"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.street", "size must be between 0 and 30"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.town", "size must be between 0 and 28"),
                        new ErrorResponseDetail("caseApplication.estateAgent.address.county", "size must be between 0 and 18")
                        ))),
                Arguments.of("Product Details multiple errors", (Consumer<BrokerCase>) a -> {
                            ProductDetails productDetails = a.getCaseApplication().getProductDetails();
                            productDetails.setProductCode("");
                            productDetails.setProductType("");
                            productDetails.setProductTerm("");
                            productDetails.setMortgageType("");
                            productDetails.setLtv(110L);
                            productDetails.setProductSelectedDate("");
                            Fee fee = new Fee();
                            fee.setFeeCode("");
                            fee.setFeeAction("");
                            productDetails.setFees(Collections.singletonList(fee));
                        },
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                        new ErrorResponseDetail("caseApplication.productDetails.productCode", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.productType", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.productType", "must be any of: FIXED, TRACKER"),
                        new ErrorResponseDetail("caseApplication.productDetails.productTerm", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.productTerm", "must be any of: ONE_YEAR, TWO_YEAR, THREE_YEAR, FOUR_YEAR, FIVE_YEAR, SIX_YEAR, SEVEN_YEAR, EIGHT_YEAR, NINE_YEAR, TEN_YEAR"),
                        new ErrorResponseDetail("caseApplication.productDetails.mortgageType", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.mortgageType", "must be any of: FIRST_TIME_BUYER, PURCHASE, PURCHASE_SHARED_EQUITY, PURCHASE_H2B_SHARED_EQUITY, REMORTGAGE, REMORTGAGE_H2B_SHARED_EQUITY, ADBO"),
                        new ErrorResponseDetail("caseApplication.productDetails.ltv", "must be less than or equal to 100"),
                        new ErrorResponseDetail("caseApplication.productDetails.productSelectedDate", "must be a valid date in format 'yyyy-MM-dd'"),
                        new ErrorResponseDetail("caseApplication.productDetails.productSelectedDate", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.fees[0].feeCode", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.fees[0].feeCode", "must be any of: A01, A03, ADM, AFF, B01, B02, B03, B04, B05, B06, BD1, BTL, COH, CR1, CR2, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11, D12, D13, D15, D16, D17, D18, D19, D20, D21, D22, D23, D24, DEN, DPA, DR1, DR2, DR3, DR4, DR5, DR6, DRA, DRN, DSC, EBH, ER1, ER2, ER3, ER4, ERL, F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16, F17, F18, F19, F20, F21, F22, F23, F24, F25, F26, F27, F28, F29, F32, F33, F34, F35, F36, F37, F38, F39, F40, F41, F42, F43, F44, F45, F46, F47, F48, F49, FAD, FR1, FR2, FTC, FTF, FVA, H01, HLC, KVL, LAF, LCB, LFA, LMS, LPF, M01, M02, M2M, NEG, RIF, RVF, SOL, SSC, SSF, T01, T02, T03, T04, T05, T06, T07, T08, T09, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22, T23, T24, T25, T26, T27, T28, T29, T30, T31, T32, T33, T34, T35, T36, T37, T38, T39, T40, T41, T42, T43, TAF, TMO, TOE, VA1, VAF, VAL, VAR, VR1, W01, WC1, WCF, XPA"),
                        new ErrorResponseDetail("caseApplication.productDetails.fees[0].feeAction", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                        new ErrorResponseDetail("caseApplication.productDetails.fees[0].feeAction", "must be any of: ADD_CAPITALISE_TO_LOAN, DEDUCT_FROM_ADVANCE, NO_ACTION")
                        ))),
                Arguments.of("Other properties multiple errors", (Consumer<BrokerCase>) a -> {
                                OtherProperty otherProperty = a.getCaseApplication().getMortgage().getOtherProperties()
                                    .get(0);
                                otherProperty.setDatePurchased("03-03-2023");
                                otherProperty.setEstimatedPropertyValue(100_000_000);
                                otherProperty.setInterestOnlyAmount(0);
                                otherProperty.setLenderName("");
                                otherProperty.setMonthlyMortgagePayment(200_000_000);
                                otherProperty.setMortgageRepaymentType("Invalid repayment type");
                                otherProperty.setNumberBedrooms(100);
                                otherProperty.setOutstandingMortgageBalance(0);
                                otherProperty.setOwnership("Invalid ownership");
                                otherProperty.setOwnershipType("Invalid ownership type");
                                otherProperty.setPropertyNotes("");
                                otherProperty.setPropertyType("Invalid property type");
                                otherProperty.setPurchasePrice(300_000_000);
                                otherProperty.setPropertyUsage("Invalid property usage");
                                otherProperty.setRemainingMortgageTermMonths(12);
                                otherProperty.setRemainingMortgageTermYears(100);
                                otherProperty.setOriginatingCurrency("Invalid");
                        },
                    new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].datePurchased", "must be a valid date in format 'yyyy-MM-dd'"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].estimatedPropertyValue", "must be less than or equal to 99999999"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].interestOnlyAmount", "must be greater than or equal to 1"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].lenderName", "size must be between 1 and 30"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].monthlyMortgagePayment", "must be less than or equal to 99999999"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].mortgageRepaymentType", "must be any of: REPAYMENT, INTEREST_ONLY, MIXED"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].numberBedrooms", "must be less than or equal to 99"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].outstandingMortgageBalance", "must be greater than or equal to 1"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].ownership", "must be any of: APPLICANT_ONE, APPLICANT_TWO, JOINT"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].ownershipType", "must be any of: HELD_RBSG, HELD_ELSEWHERE, UNENCUMBERED"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].propertyNotes", "size must be between 1 and 50"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].propertyType", "must be any of: BUNGALOW_NEW_BUILD, BUNGALOW_DETACHED, BUNGALOW_SEMI_DETACHED, BUNGALOW_MID_TERRACED, BUNGALOW_END_TERRACED, HOUSE_NEW_BUILD, HOUSE_DETACHED, HOUSE_SEMI_DETACHED, HOUSE_MID_TERRACED, HOUSE_END_TERRACED, HOUSE_NEW_BUY, FLAT_NEW_BUILD, FLAT_PURPOSE_BUILT, FLAT_CONVERTED, FLAT_NEW_BUY"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].purchasePrice", "must be less than or equal to 99999999"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].propertyUsage", "must be any of: RESIDENTIAL, BUY_TO_LET, CONSENT_TO_LET"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].remainingMortgageTermMonths", "must be less than or equal to 11"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].remainingMortgageTermYears", "must be less than or equal to 99"),
                        new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].originatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")
                        ))),
            Arguments.of("Estate agent country error", (Consumer<BrokerCase>) a -> {
                  BasicAddress addr = a.getCaseApplication().getEstateAgent().getAddress();
                  addr.setCountry("GB");
                  addr.setPostcode(null);
                },
                new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                    new ErrorResponseDetail("caseApplication.estateAgent.address.postcode", "postcode must not be blank when country is GB")
                ))),
            Arguments.of("Employment country error", (Consumer<BrokerCase>) a -> {
                  BasicAddress addr = new BasicAddress();
                  addr.setHouseNumber("1");
                  addr.setStreet("Street");
                  addr.setTown("Town");
                  addr.setCountry("GB");
                  addr.setPostcode(null);
                  a.getIncome().getApplicants().get(0).getPrimaryJob().setEmployerAddress(addr);
                },
                new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                    new ErrorResponseDetail("income.applicants[0].primaryJob.employerAddress.postcode", "postcode must not be blank when country is GB")
                ))),
            Arguments.of("Existing mortgage country error", (Consumer<BrokerCase>) a -> {
                  BasicAddress addr = a.getCaseApplication().getMortgage().getOtherProperties().get(0).getAddress();
                  addr.setHouseNumber("1");
                  addr.setStreet("Street");
                  addr.setTown("Town");
                  addr.setCountry("GB");
                  addr.setPostcode(null);
                },
                new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                    new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].address.postcode", "postcode must not be blank when country is GB")
                ))),
                Arguments.of("Estate agent invalid postcode error", (Consumer<BrokerCase>) a -> {
                            BasicAddress addr = a.getCaseApplication().getEstateAgent().getAddress();
                            addr.setCountry("GB");
                            addr.setPostcode("12345");
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                                new ErrorResponseDetail("caseApplication.estateAgent.address.postcode", "Invalid UK postcode")
                        ))),
                Arguments.of("Employment invalid postcode error", (Consumer<BrokerCase>) a -> {
                            BasicAddress addr = new BasicAddress();
                            addr.setHouseNumber("1");
                            addr.setStreet("Street");
                            addr.setTown("Town");
                            addr.setCountry("GB");
                            addr.setPostcode("12345");
                            a.getIncome().getApplicants().get(0).getPrimaryJob().setEmployerAddress(addr);
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                                new ErrorResponseDetail("income.applicants[0].primaryJob.employerAddress.postcode", "Invalid UK postcode")
                        ))),
                Arguments.of("Existing mortgage invalid postcode error", (Consumer<BrokerCase>) a -> {
                            BasicAddress addr = a.getCaseApplication().getMortgage().getOtherProperties().get(0).getAddress();
                            addr.setHouseNumber("1");
                            addr.setStreet("Street");
                            addr.setTown("Town");
                            addr.setCountry("GB");
                            addr.setPostcode("12345");
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                                new ErrorResponseDetail("caseApplication.mortgage.otherProperties[0].address.postcode", "Invalid UK postcode")
                        ))),
                Arguments.of("Other Income  sourceOfIncome HOUSING_ALLOWANCE error", (Consumer<BrokerCase>) a -> {
                            OtherIncomeDetails otherIncome = a.getIncome().getApplicants().get(0).getOtherIncome().get("otherIncome1");
                            otherIncome.setOtherIncomeAmount(null);
                            otherIncome.setOtherIncomeFrequency(null);
                            otherIncome.setSourceOfIncome(OtherIncomeDetails.SourceOfIncome.HOUSING_ALLOWANCE.value());
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                                new ErrorResponseDetail("income.applicants[0].otherIncome[otherIncome1]", "otherIncomeAmount is mandatory when sourceOfIncome == HOUSING_ALLOWANCE"),
                                new ErrorResponseDetail("income.applicants[0].otherIncome[otherIncome1]", "otherIncomeFrequency is mandatory when sourceOfIncome == HOUSING_ALLOWANCE")
                        ))),
                Arguments.of("Other Income originatingCurrency error", (Consumer<BrokerCase>) a -> {
                            OtherIncomeDetails otherIncome = a.getIncome().getApplicants().get(0).getOtherIncome().get("otherIncome1");
                            otherIncome.setOtherIncomeOriginatingCurrency("HOP");
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                            new ErrorResponseDetail("income.applicants[0].otherIncome[otherIncome1].otherIncomeOriginatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")
                        )))
        );
    }
}
