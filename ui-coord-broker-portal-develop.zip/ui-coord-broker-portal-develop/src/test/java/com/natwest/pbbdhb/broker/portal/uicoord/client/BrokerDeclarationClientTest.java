package com.natwest.pbbdhb.broker.portal.uicoord.client;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerDeclarationTestUtil.createValidBrokerDeclarationRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerDeclarationRequestDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class BrokerDeclarationClientTest {

    private static final String TEST_ENDPOINT_POST = "http://test.endpoint/declaration";

    @Mock
    private RestTemplate mockRestTemplate;

    private BrokerDeclarationClient brokerDeclarationClient;

    @BeforeEach
    void setUp() {
        this.brokerDeclarationClient = new BrokerDeclarationClient(TEST_ENDPOINT_POST, mockRestTemplate);
    }

    @Test
    void getBrokerDeclaration() {
        BrokerDeclarationRequestDto brokerDeclarationRequestDto = createValidBrokerDeclarationRequest();
        String expectedResponse = "<html>sample</html>";
        ResponseEntity<String> expectedEntity = ResponseEntity.ok(expectedResponse);
        when(mockRestTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(expectedEntity);
        String declarationResponse = brokerDeclarationClient.getDeclaration(BRAND_DEFAULT, brokerDeclarationRequestDto);
        verify(mockRestTemplate).exchange(any(), any(), any(), eq(String.class));
        assertEquals(expectedResponse, declarationResponse);
    }

    @Test
    void getBrokerDeclarationThrowsExceptionOn404Error() {
        BrokerDeclarationRequestDto brokerDeclarationRequestDto = createValidBrokerDeclarationRequest();
        HttpClientErrorException notFoundException = HttpClientErrorException.create(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.getReasonPhrase(), new HttpHeaders(), null, null);
        when(mockRestTemplate.exchange(any(), any(), any(), eq(String.class))).thenThrow(notFoundException);

        assertThrows(
            HttpClientErrorException.NotFound.class,
            () -> brokerDeclarationClient.getDeclaration(BRAND_DEFAULT, brokerDeclarationRequestDto));
    }
}
