package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ProductSearchTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class ProductSearchRequestValidationTest extends AbstractValidationTest<ProductSearchRequest> {
    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid product search request", (Consumer<ProductSearchRequest>) a -> {/* no-op */}, EMPTY_SET),
                Arguments.of("Valid request with property value 99999999", (Consumer<ProductSearchRequest>) a -> a.setPropertyValue(BigDecimal.valueOf(99_999_999L)), EMPTY_SET),
                Arguments.of("Property value is above maximum value", (Consumer<ProductSearchRequest>) a -> a.setPropertyValue(BigDecimal.valueOf(100_000_000L)), singleton(create("propertyValue", "must be less than or equal to 99999999"))),
                Arguments.of("Property value is below minimum value", (Consumer<ProductSearchRequest>) a -> a.setPropertyValue(BigDecimal.valueOf(-1L)), singleton(create("propertyValue", "must be greater than or equal to 1"))),
                Arguments.of("Mortgage amount value is above maximum value", (Consumer<ProductSearchRequest>) a -> a.setMortgageAmount(BigDecimal.valueOf(100_000_000L)), singleton(create("mortgageAmount", "must be less than or equal to 99999999"))),
                Arguments.of("Mortgage amount is below minimum value", (Consumer<ProductSearchRequest>) a -> a.setMortgageAmount(BigDecimal.valueOf(-1L)), singleton(create("mortgageAmount", "must be greater than or equal to 1"))),
                Arguments.of("repaymentType invalid", (Consumer<ProductSearchRequest>) a -> a.setRepaymentType("invalid"), singleton(create("repaymentType", "must be any of: REPAYMENT, INTEREST_ONLY, MIXED"))),
                Arguments.of("applicationType invalid", (Consumer<ProductSearchRequest>) a -> a.setApplicationType("invalid"), singleton(create("applicationType", "must be any of: RESIDENTIAL, BUY_TO_LET"))),
                Arguments.of("mortgageType invalid", (Consumer<ProductSearchRequest>) a -> a.setMortgageType("invalid"), singleton(create("mortgageType", "must be any of: FIRST_TIME_BUYER, PURCHASE, PURCHASE_SHARED_EQUITY, PURCHASE_H2B_SHARED_EQUITY, REMORTGAGE, REMORTGAGE_H2B_SHARED_EQUITY"))),
                Arguments.of("productSearchDate is invalid", (Consumer<ProductSearchRequest>) a -> a.setProductSearchDate("2020-01-01"), singleton(create("productSearchDate", "must be a valid date in format 'dd-MM-yyyy'"))),
                Arguments.of("ltv above 100", (Consumer<ProductSearchRequest>) a -> a.setLtv(101d), singleton(create("ltv", "must be less than or equal to 100"))),
                Arguments.of("CustomerPreferredTermYears below minimum", (Consumer<ProductSearchRequest>) a -> a.setCustomerPreferredTermYears(2), singleton(create("customerPreferredTermYears", "must be greater than or equal to 3"))),
                Arguments.of("CustomerPreferredTermYears above max", (Consumer<ProductSearchRequest>) a -> a.setCustomerPreferredTermYears(41), singleton(create("customerPreferredTermYears", "must be less than or equal to 40"))),
                Arguments.of("CustomerPreferredTermMonths below minimum", (Consumer<ProductSearchRequest>) a -> a.setCustomerPreferredTermMonths(-1), singleton(create("customerPreferredTermMonths", "must be greater than or equal to 0"))),
                Arguments.of("CustomerPreferredTermMonths above max", (Consumer<ProductSearchRequest>) a -> a.setCustomerPreferredTermMonths(12), singleton(create("customerPreferredTermMonths", "must be less than or equal to 11"))),
                Arguments.of("CustomerPreferredTermMonths above max due to Max year", (Consumer<ProductSearchRequest>) a -> { a.setCustomerPreferredTermYears(40);a.setCustomerPreferredTermMonths(1);}, singleton(create("", "'customerPreferredTermMonths' value cannot be greater than 0 when 'customerPreferredTermYears' equals 40")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testProductSearchRequestValidations(String testDescription, Consumer<ProductSearchRequest> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, ProductSearchTestUtil::createValidProductSearchRequest, mutator, expectedErrorMessages);
    }

}
