package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.groups.DipSubmitValidationGroup;
import jakarta.validation.groups.Default;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class FinancialCommitmentValidationTest extends AbstractValidationTest<FinancialCommitment> {
    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid financial Commitment for nwi", (Consumer<FinancialCommitment>) a -> {
                }, EMPTY_SET, new Class[]{Default.class}),
                Arguments.of("FinancialCommitment originating currency  null", (Consumer<FinancialCommitment>) a -> {
                    a.setOriginatingCurrency(null);
                }, singleton(create("originatingCurrency", "must not be blank")), new Class[]{DipSubmitValidationGroup.class}),
                Arguments.of("FinancialCommitment originating currency  invalid", (Consumer<FinancialCommitment>) a -> {
                    a.setOriginatingCurrency("Invalid");
                }, singleton(create("originatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")), new Class[]{Default.class}),
                Arguments.of("FinancialCommitment payments null", (Consumer<FinancialCommitment>) a -> {
                    a.setPayments(null);
                }, singleton(create("payments", "must not be null")), new Class[]{DipSubmitValidationGroup.class}),
                Arguments.of("FinancialCommitment frequency null", (Consumer<FinancialCommitment>) a -> {
                    a.setFrequency(null);
                }, singleton(create("frequency", "must not be blank")), new Class[]{DipSubmitValidationGroup.class})

        );


    }


    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void testDepositValidations(String testDescription, Consumer<FinancialCommitment> mutator, Set<TestValidationError> expectedErrorMessages, Class<?>... groups) {
        testValidations(testDescription, CaseTestUtil::createValidFinancialCommitment, mutator, expectedErrorMessages, groups);
    }

}
