package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.FIRST_TIME_BUYER;
import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.NEW_CUSTOMER;
import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest.ProductValidationFee;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Fee;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.Test;

class ProductValidationMapperTest {

  private ProductValidationMapper mapper = new ProductValidationMapperImpl();

  @Test
  void mapToValidationMsvcRequest() {
    // test data
    String applicationType = "RESIDENTIAL";
    Integer propertyValue = 123_456;
    Long mortgageAmount = 234_567L;
    String productCode = "FO26357";
    String productSelectedDate = "2024-05-24";
    String mortgageType = "PURCHASE";
    String productType = "FIXED";
    String repaymentType = "REPAYMENT";
    String productTerm = "TWO_YEAR";
    Long ltv = 95L;
    BigDecimal cashBackValue = BigDecimal.TEN;
    Boolean freeLegal = true;
    String jurisdiction = "UK";

    String fee1Code = "DRA";
    String fee1Type = "CHAPS_FEE";
    BigDecimal fee1Amount = new BigDecimal(30);
    String fee2Code = "FVA";
    String fee2Type = "FREE_VALUATION";
    BigDecimal fee2Amount = BigDecimal.ZERO;

    CaseApplication caseApplication = TestUtil
        .createValidBrokerCase().getCaseApplication();
    ProductDetails pDetails = new ProductDetails();
    caseApplication.setProductDetails(pDetails);
    // prepare product data
    pDetails.setProductCode(productCode);
    pDetails.setProductType(productType);
    pDetails.setProductTerm(productTerm);
    pDetails.setMortgageType(mortgageType);
    pDetails.setLtv(ltv);
    pDetails.setCashBackValue(cashBackValue);
    pDetails.setProductSelectedDate(productSelectedDate);
    pDetails.setIsFreeLegal(freeLegal);
    // fees
    pDetails.setFees(List.of(
        Fee.builder()
            .feeCode(fee1Code)
            .type(fee1Type)
            .feeAmount(fee1Amount)
            .build(),
        Fee.builder()
            .feeCode(fee2Code)
            .type(fee2Type)
            .feeAmount(fee2Amount)
            .build()
    ));
    // prepare case data
    caseApplication.setApplicationType(applicationType);
    caseApplication.getMortgage().setPropertyValue(propertyValue);
    caseApplication.getMortgage().setMortgageAmount(mortgageAmount.intValue());
    caseApplication.getMortgage().setMortgageType(repaymentType);

    // execute
    ProductValidationMsvcRequest actual = mapper
        .mapToValidationMsvcRequest(caseApplication);

    // validate
    assertThat(actual.getApplicationType()).isEqualTo(applicationType);
    assertThat(actual.getPropertyValue()).isEqualTo(propertyValue);
    assertThat(actual.getCustomerType()).isEqualTo(NEW_CUSTOMER.name());  // hardcoded in mapper
    assertThat(actual.getMortgageAmount()).isEqualTo(mortgageAmount);
    assertThat(actual.getProductCode()).isEqualTo(productCode);
    assertThat(actual.getProductSearchDate()).isEqualTo("24-05-2024"); // same date, diff format
    assertThat(actual.getMortgageType()).isEqualTo(mortgageType);
    assertThat(actual.getProductType()).isEqualTo(productType);
    assertThat(actual.getRepaymentType()).isEqualTo(repaymentType);
    assertThat(actual.getProductTerm()).isEqualTo(productTerm);
    assertThat(actual.getLtv()).isEqualTo(ltv.intValue()); // ltv int value
    assertThat(actual.getIsCashbackProduct()).isEqualTo(true); // cashback is present
    assertThat(actual.getFreeLegal()).isEqualTo(freeLegal);
    assertThat(actual.getJurisdiction()).isEqualTo(jurisdiction); // hardcoded in mapper
    assertThat(actual.getFees()).isEqualTo(List.of(
        ProductValidationFee.builder()
            .code(fee1Code)
            .type(fee1Type)
            .amount(fee1Amount)
            .build(),
        ProductValidationFee.builder()
            .code(fee2Code)
            .type(fee2Type)
            .amount(fee2Amount)
            .build()
    ));
  }

  @Test
  void mapToValidationMsvcRequest_firstTimeBuyer() {
    // test data
    String applicationType = "RESIDENTIAL";
    Integer propertyValue = 123_456;
    Long mortgageAmount = 234_567L;
    String productCode = "FO26357";
    String productSelectedDate = "2024-05-24";
    String mortgageType = "PURCHASE";
    String productType = "FIXED";
    String repaymentType = "REPAYMENT";
    String productTerm = "TWO_YEAR";
    Long ltv = 95L;
    BigDecimal cashBackValue = BigDecimal.TEN;
    Boolean freeLegal = true;
    String jurisdiction = "UK";

    String fee1Code = "DRA";
    String fee1Type = "CHAPS_FEE";
    BigDecimal fee1Amount = new BigDecimal(30);
    String fee2Code = "FVA";
    String fee2Type = "FREE_VALUATION";
    BigDecimal fee2Amount = BigDecimal.ZERO;

    CaseApplication caseApplication = TestUtil
        .createValidBrokerCase().getCaseApplication();
    ProductDetails pDetails = new ProductDetails();
    caseApplication.setProductDetails(pDetails);
    caseApplication.setFirstTimeBuyer(true);
    // prepare product data
    pDetails.setProductCode(productCode);
    pDetails.setProductType(productType);
    pDetails.setProductTerm(productTerm);
    pDetails.setMortgageType(mortgageType);
    pDetails.setLtv(ltv);
    pDetails.setCashBackValue(cashBackValue);
    pDetails.setProductSelectedDate(productSelectedDate);
    pDetails.setIsFreeLegal(freeLegal);
    // fees
    pDetails.setFees(List.of(
        Fee.builder()
            .feeCode(fee1Code)
            .type(fee1Type)
            .feeAmount(fee1Amount)
            .build(),
        Fee.builder()
            .feeCode(fee2Code)
            .type(fee2Type)
            .feeAmount(fee2Amount)
            .build()
    ));
    // prepare case data
    caseApplication.setApplicationType(applicationType);
    caseApplication.getMortgage().setPropertyValue(propertyValue);
    caseApplication.getMortgage().setMortgageAmount(mortgageAmount.intValue());
    caseApplication.getMortgage().setMortgageType(repaymentType);

    // execute
    ProductValidationMsvcRequest actual = mapper
        .mapToValidationMsvcRequest(caseApplication);

    // validate
    assertThat(actual.getApplicationType()).isEqualTo(applicationType);
    assertThat(actual.getPropertyValue()).isEqualTo(propertyValue);
    assertThat(actual.getCustomerType()).isEqualTo(NEW_CUSTOMER.name());  // hardcoded in mapper
    assertThat(actual.getMortgageAmount()).isEqualTo(mortgageAmount);
    assertThat(actual.getProductCode()).isEqualTo(productCode);
    assertThat(actual.getProductSearchDate()).isEqualTo("24-05-2024"); // same date, diff format
    assertThat(actual.getMortgageType()).isEqualTo(mortgageType);
    assertThat(actual.getProductType()).isEqualTo(productType);
    assertThat(actual.getRepaymentType()).isEqualTo(repaymentType);
    assertThat(actual.getProductTerm()).isEqualTo(productTerm);
    assertThat(actual.getLtv()).isEqualTo(ltv.intValue()); // ltv int value
    assertThat(actual.getIsCashbackProduct()).isEqualTo(true); // cashback is present
    assertThat(actual.getFreeLegal()).isEqualTo(freeLegal);
    assertThat(actual.getJurisdiction()).isEqualTo(jurisdiction); // hardcoded in mapper
    assertThat(actual.getFees()).isEqualTo(List.of(
        ProductValidationFee.builder()
            .code(fee1Code)
            .type(fee1Type)
            .amount(fee1Amount)
            .build(),
        ProductValidationFee.builder()
            .code(fee2Code)
            .type(fee2Type)
            .amount(fee2Amount)
            .build()
    ));
  }

  @Test
  void mapToValidationMsvcRequest_cashBackValue_Zero() {
    // test data
    String productCode = "FO26357";
    BigDecimal cashBackValue = BigDecimal.ZERO;

    CaseApplication caseApplication = TestUtil
        .createValidBrokerCase().getCaseApplication();
    ProductDetails pDetails = new ProductDetails();
    caseApplication.setProductDetails(pDetails);
    // prepare product data
    pDetails.setProductCode(productCode);
    pDetails.setCashBackValue(cashBackValue);

    // execute
    ProductValidationMsvcRequest actual = mapper
        .mapToValidationMsvcRequest(caseApplication);

    // validate
    assertThat(actual.getProductCode()).isEqualTo(productCode);
    assertThat(actual.getIsCashbackProduct()).isEqualTo(false); // cashback is present
  }

  @Test
  void mapToValidationMsvcRequest_cashBackValue_One() {
    // test data
    String productCode = "FO26357";
    BigDecimal cashBackValue = BigDecimal.ONE;

    CaseApplication caseApplication = TestUtil
        .createValidBrokerCase().getCaseApplication();
    ProductDetails pDetails = new ProductDetails();
    caseApplication.setProductDetails(pDetails);
    // prepare product data
    pDetails.setProductCode(productCode);
    pDetails.setCashBackValue(cashBackValue);

    // execute
    ProductValidationMsvcRequest actual = mapper
        .mapToValidationMsvcRequest(caseApplication);

    // validate
    assertThat(actual.getProductCode()).isEqualTo(productCode);
    assertThat(actual.getIsCashbackProduct()).isEqualTo(true); // cashback is present
  }
}