package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.rbs.pbbdhb.sales.esis.models.enums.SchemeName;
import org.junit.jupiter.api.Test;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.SchemeType.*;
import static org.assertj.core.api.Assertions.assertThat;

class MortgageSchemeMappingHelperTest {

    public static final String CAPIE_HELP_TO_BUY = "HELP_TO_BUY";
    public static final String CAPIE_OTHER = "OTHER";

    @Test
    void shouldSetDefaultsForNullSchemeType() {
        CaseApplication caseApplication = new CaseApplication();
        caseApplication.setUsingSpecialistScheme(false);
        caseApplication.setSchemeType(null);

        MortgageSchemeMappingHelper.CapieMortgageScheme capieMortgageScheme = MortgageSchemeMappingHelper.getCapieMortgageScheme(caseApplication);

        assertThat(capieMortgageScheme.getRightToBuy()).isFalse();
        assertThat(capieMortgageScheme.getGovtSharedEquityScheme()).isFalse();
        assertThat(capieMortgageScheme.getSchemeType()).isNull();
        assertThat(capieMortgageScheme.getSchemeName()).isNull();
    }

    @Test
    void shouldSetDefaultsForRightToBuy() {
        CaseApplication caseApplication = new CaseApplication();
        caseApplication.setUsingSpecialistScheme(false);
        caseApplication.setSchemeType(RIGHT_TO_BUY.value());

        MortgageSchemeMappingHelper.CapieMortgageScheme capieMortgageScheme = MortgageSchemeMappingHelper.getCapieMortgageScheme(caseApplication);

        assertThat(capieMortgageScheme.getRightToBuy()).isTrue();
        assertThat(capieMortgageScheme.getGovtSharedEquityScheme()).isFalse();
        assertThat(capieMortgageScheme.getSchemeType()).isNull();
        assertThat(capieMortgageScheme.getSchemeName()).isNull();
    }

    @Test
    void shouldSetDefaultsForHelpToBuySharedEquity() {
        CaseApplication caseApplication = new CaseApplication();
        caseApplication.setUsingSpecialistScheme(false);
        caseApplication.setSchemeType(HELP_TO_BUY_SHARED_EQUITY.value());

        MortgageSchemeMappingHelper.CapieMortgageScheme capieMortgageScheme = MortgageSchemeMappingHelper.getCapieMortgageScheme(caseApplication);

        assertThat(capieMortgageScheme.getRightToBuy()).isFalse();
        assertThat(capieMortgageScheme.getGovtSharedEquityScheme()).isTrue();
        assertThat(capieMortgageScheme.getSchemeType()).isEqualTo(CAPIE_HELP_TO_BUY);
        assertThat(capieMortgageScheme.getSchemeName()).isNull();
    }

    @Test
    void shouldSetDefaultsForSharedEquity() {
        CaseApplication caseApplication = new CaseApplication();
        caseApplication.setUsingSpecialistScheme(false);
        caseApplication.setSchemeType(SHARED_EQUITY.value());

        MortgageSchemeMappingHelper.CapieMortgageScheme capieMortgageScheme = MortgageSchemeMappingHelper.getCapieMortgageScheme(caseApplication);

        assertThat(capieMortgageScheme.getRightToBuy()).isFalse();
        assertThat(capieMortgageScheme.getGovtSharedEquityScheme()).isTrue();
        assertThat(capieMortgageScheme.getSchemeType()).isEqualTo(CaseApplication.SchemeType.OTHER.value());
        assertThat(capieMortgageScheme.getSchemeName()).isEqualTo(SchemeName.SHARED_EQUITY.toString());
    }

    @Test
    void shouldSetDefaultsForOther() {
        CaseApplication caseApplication = new CaseApplication();
        caseApplication.setUsingSpecialistScheme(false);
        caseApplication.setSchemeType(OTHER.value());

        MortgageSchemeMappingHelper.CapieMortgageScheme capieMortgageScheme = MortgageSchemeMappingHelper.getCapieMortgageScheme(caseApplication);

        assertThat(capieMortgageScheme.getRightToBuy()).isFalse();
        assertThat(capieMortgageScheme.getGovtSharedEquityScheme()).isFalse();
        assertThat(capieMortgageScheme.getSchemeType()).isEqualTo(CaseApplication.SchemeType.OTHER.value());
        assertThat(capieMortgageScheme.getSchemeName()).isEqualTo(CAPIE_OTHER);
    }
}