package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ApplicantProfile;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.readApplicantProfileFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_ADD_APPLICANTS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static io.restassured.RestAssured.with;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
public class ApplicantControllerTest {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/applicants/add-applicants-one-create-request.json")
    private Resource addApplicantsOneCreateRequest;

    @Value("classpath:test-files/applicants/add-applicants-one-create-response.json")
    private Resource addApplicantsOneCreateResponse;

    @Value("classpath:test-files/applicants/add-applicants-one-update-request.json")
    private Resource addApplicantsOneUpdateRequest;

    @Value("classpath:test-files/applicants/add-applicants-one-update-response.json")
    private Resource addApplicantsOneUpdateResponse;

    @Value("classpath:test-files/applicants/add-applicants-one-create-one-update-request.json")
    private Resource addApplicantsOneCreateOneUpdateRequest;

    @Value("classpath:test-files/applicants/add-applicants-one-create-one-update-response.json")
    private Resource addApplicantsOneCreateOneUpdateResponse;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void addApplicantsValidRequestSendsPostToCreateApplicant() throws IOException {
        ApplicantProfile request = readApplicantProfileFromResource(addApplicantsOneCreateRequest);
        ApplicantProfile expectedResponse = readApplicantProfileFromResource(addApplicantsOneCreateResponse);

        ApplicantProfile result = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_ADD_APPLICANTS)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(ApplicantProfile.class);

        Assertions.assertThat(result).isEqualTo(expectedResponse);
    }

    @Test
    void addApplicantsValidRequestSendsPutToUpdateApplicant() throws IOException {
        ApplicantProfile request = readApplicantProfileFromResource(addApplicantsOneUpdateRequest);
        ApplicantProfile expectedResponse = readApplicantProfileFromResource(addApplicantsOneUpdateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_ADD_APPLICANTS);

        log.info(response.body().asPrettyString());

        ApplicantProfile result = response.then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(ApplicantProfile.class);

        Assertions.assertThat(result).isEqualTo(expectedResponse);
    }

    @Test
    void addApplicantsValidRequestSendsPostForNewApplicantAndPutToUpdateApplicantInSingleRequest() throws IOException {
        ApplicantProfile request = readApplicantProfileFromResource(addApplicantsOneCreateOneUpdateRequest);
        ApplicantProfile expectedResponse = readApplicantProfileFromResource(addApplicantsOneCreateOneUpdateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_ADD_APPLICANTS);

        log.info(response.body().asPrettyString());

        ApplicantProfile result = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(ApplicantProfile.class);

        Assertions.assertThat(result).isEqualTo(expectedResponse);
    }
}
