package com.natwest.pbbdhb.broker.portal.uicoord.client;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PREFIX_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PREFIX_VALUE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_VALUE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CaseIdGenerationClientTest {

    private static final String TEST_ENDPOINT = "http://test.endpoint";
    private static final String TEST_BRAND = "test";
    private static final String GENERATED_CASE_ID = "THX1138";

    @Mock
    private RestTemplate mockRestTemplate;

    @Captor
    private ArgumentCaptor<URI> urlCaptor;

    @Captor
    private ArgumentCaptor<HttpEntity<Void>> requestEntityCaptor;

    private CaseIdGenerationClient caseIdGenerationClient;

    @BeforeEach
    void setUp() {
        this.caseIdGenerationClient = new CaseIdGenerationClient(TEST_ENDPOINT, mockRestTemplate);
    }

    @Test
    void generateCaseIdUsesConfiguredEndpoint() {
        ResponseEntity<String> successResponse = ResponseEntity.ok(GENERATED_CASE_ID);
        when(mockRestTemplate.exchange(isA(URI.class), eq(HttpMethod.GET), isA(HttpEntity.class), eq(String.class))).thenReturn(successResponse);

        caseIdGenerationClient.generateCaseId(TEST_BRAND);

        verify(mockRestTemplate).exchange(urlCaptor.capture(), eq(HttpMethod.GET), isA(HttpEntity.class), eq(String.class));
        URI requestUrl = urlCaptor.getValue();
        String baseEndpoint = requestUrl.toString().split("\\?")[0];

        assertEquals(TEST_ENDPOINT, baseEndpoint);
    }

    @Test
    void generateCaseIdSetsRequiredQueryParameters() {
        ResponseEntity<String> successResponse = ResponseEntity.ok(GENERATED_CASE_ID);
        when(mockRestTemplate.exchange(isA(URI.class), eq(HttpMethod.GET), isA(HttpEntity.class), eq(String.class))).thenReturn(successResponse);

        caseIdGenerationClient.generateCaseId(TEST_BRAND);

        verify(mockRestTemplate).exchange(urlCaptor.capture(), eq(HttpMethod.GET), isA(HttpEntity.class), eq(String.class));
        URI requestUrl = urlCaptor.getValue();
        String queryString = requestUrl.toString().split("\\?")[1];
        String[] params = queryString.split("&");
        List<String> paramsList = Arrays.asList(params);

        assertTrue(paramsList.contains(CASE_ID_PREFIX_PARAM + "=" + CASE_ID_PREFIX_VALUE));
        assertTrue(paramsList.contains(CLIENT_ID_PARAM + "=" + CLIENT_ID_VALUE));
    }

    @Test
    void createCaseSetsBrandHeader() {
        ResponseEntity<String> successResponse = ResponseEntity.ok(GENERATED_CASE_ID);
        when(mockRestTemplate.exchange(isA(URI.class), eq(HttpMethod.GET), isA(HttpEntity.class), eq(String.class))).thenReturn(successResponse);

        caseIdGenerationClient.generateCaseId(TEST_BRAND);

        verify(mockRestTemplate).exchange(isA(URI.class), eq(HttpMethod.GET), requestEntityCaptor.capture(), eq(String.class));
        HttpEntity<Void> request = requestEntityCaptor.getValue();
        assertEquals(TEST_BRAND, request.getHeaders().getFirst("brand"));
    }

    @Test
    void createCaseSetsContentTypeHeader() {
        ResponseEntity<String> successResponse = ResponseEntity.ok(GENERATED_CASE_ID);
        when(mockRestTemplate.exchange(isA(URI.class), eq(HttpMethod.GET), isA(HttpEntity.class), eq(String.class))).thenReturn(successResponse);

        caseIdGenerationClient.generateCaseId(TEST_BRAND);

        verify(mockRestTemplate).exchange(isA(URI.class), eq(HttpMethod.GET), requestEntityCaptor.capture(), eq(String.class));
        HttpEntity<Void> request = requestEntityCaptor.getValue();
        assertNull(request.getHeaders().getContentType());
    }
}
