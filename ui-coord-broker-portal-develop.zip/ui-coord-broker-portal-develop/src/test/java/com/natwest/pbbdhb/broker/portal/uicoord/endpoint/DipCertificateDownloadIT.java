package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_DIP_WITH_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil.testCaseNameFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@TestPropertySource("classpath:application-it-dip-submission.properties")
@ExtendWith(SpringExtension.class)
@Slf4j
@Disabled //this depends on Galileo mock service being on to get the AIP with APPROVE status, we can only download the document if the AIP is APPROVED
//If the Galileo mock service is off, we get REFER for any AIP submitted
public class DipCertificateDownloadIT {
  private static final String DIP_SERVICE_NAME = "core-decision-in-principle";
  private static String dipPath = "/mortgages/v2/decision-in-principle";
  private TestInfo testInfo;
  private String testResult;

  @Value("${server.servlet.context-path}")
  String contextPath;

  @LocalServerPort
  int port;

  @Autowired
  private TokenConfiguration tokenConfig;

  @Value("${decision.in.principle.endpoint}")
  private String decisionInPrincipleEndpoint;

  @Value("${client.id}")
  private String clientId;

  @BeforeEach
  public void setUp(TestInfo testInfo) {
    RestAssured.baseURI = decisionInPrincipleEndpoint;
    RestAssured.port = 443;

    this.testInfo = testInfo;
  }

  @AfterEach
  public void cleanUp() throws IOException {
    RestAssured.baseURI = RestAssured.DEFAULT_URI;
    RestAssured.port = RestAssured.DEFAULT_PORT;
  }


  @ParameterizedTest(name = "{index} {0}")
  @MethodSource("testCases")
  void getDipCertificateSuccessfully(String testCaseName, String dipRequestJson) throws JSONException {
    Response response = with()
        .header(CLIENT_ID_HEADER, clientId)
        .header(BRAND_HEADER, BRAND_DEFAULT)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, DIP_SERVICE_NAME))
        .contentType(APPLICATION_JSON_VALUE)
        .body(dipRequestJson)
        .post(dipPath);

    log.info(response.body().asPrettyString());

    RestAssured.baseURI = "http://localhost" + contextPath;
    RestAssured.port = port;
    DipExtendedResponse dipResponse = response.then().extract().as(DipExtendedResponse.class);
    String decision = dipResponse.getDecision();
    assertEquals("ACCEPT", decision);

    Response getDipCertificate = with()
        .header(CLIENT_ID_HEADER, clientId)
        .header(BRAND_HEADER, BRAND_DEFAULT)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .get(PATH_GET_DIP_WITH_CASE_ID, dipResponse.getDipId());

    log.info(getDipCertificate.body().asPrettyString());

    getDipCertificate
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_PDF_VALUE);
    assertNotNull(getDipCertificate.body().asInputStream());

  }

  private static Stream<Arguments> testCases() throws IOException {
    PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
    Resource[] testCaseResources = resourceResolver.getResources("classpath:dip-test-cases/dip-get-certificate/*.json");
    return Arrays.stream(testCaseResources).map(r -> {
      try {
        return Arguments.of(testCaseNameFromResource(r), getResourceText(r));
      } catch (IOException e) {
        e.printStackTrace();
        return null;
      }
    });
  }
}