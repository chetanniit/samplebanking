package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.*;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

/**
 * Test behaviour of the BrokerInfo client when handling different responses from CRM.
 * Responses per username are provided by configured Wiremock mappings.
 *
 * Access token responses are provided by Wiremock mappings held in /mappings/token.json
 * Broker responses are provided by Wiremock mappings held in /mappings/broker.json
 */
@SpringBootTest
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
class BrokerInfoClientTest {

    @Autowired
    private BrokerInfoClient client;

    @Test
    void shouldReturnExpectedBrokerWhenValidUserRequested() {

        final BrokerInfoResponseDto broker = client.readBroker("brdemo5");

        // verify token endpoint was called
        WireMock.verify(
            exactly(1),
            WireMock.postRequestedFor(
                WireMock.urlPathEqualTo("/test-tenant-id/oauth2/token")));

        // verify broker-core endpoint was called
        WireMock.verify(
            exactly(1),
            WireMock.getRequestedFor(
                    WireMock.urlPathEqualTo("/mbs_ReadBrokerCore(mbs_userName='brdemo5')")));

        assertThat(broker).isNotNull();
        assertThat(broker).isEqualTo(BrokerInfoTestUtil.brokerInfoDto());
    }

    @Test
    void shouldThrowExceptionWhenClientReceivesBadRequestResponse() {
        assertThat(catchThrowable(() -> client.readBroker("bad-request-user")))
            .isInstanceOf(BrokerNotFoundException.class)
            .hasMessage("Failed to retrieve Broker data from CRM");
    }

    @Test
    void shouldThrowExceptionWhenUserIsNotFound() {
        assertThat(catchThrowable(() -> client.readBroker("user-not-found")))
            .isInstanceOf(BrokerNotFoundException.class)
            .hasMessage("Broker not found in CRM");
    }

    @Test
    void shouldThrowExceptionWhenClientReceivesNullResponse() {
        assertThat(catchThrowable(() -> client.readBroker("null-user")))
            .isInstanceOf(BrokerNotFoundException.class)
            .hasMessage("Empty Broker data returned from CRM");
    }
}


