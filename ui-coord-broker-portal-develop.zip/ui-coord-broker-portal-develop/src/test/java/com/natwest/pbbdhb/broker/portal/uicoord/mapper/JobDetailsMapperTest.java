package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;

import com.natwest.pbbdhb.income.expense.model.enums.EmploymentStatus;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentType;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        JobDetailsMapper.class,
        JobDetailsAutoMapperImpl.class,
        EmployerAddressMapperImpl.class
})
class JobDetailsMapperTest {

    @Autowired
    private JobDetailsMapper mapper;

    @Test
    void returnsCorrectEmploymentStatusWhenEmploymentTypeIsContractor() {
        JobDetails jobDetails = createValidJobDetails();
        jobDetails.setEmploymentStatus(JobDetails.EmploymentStatus.CONTRACTOR.value());
        String employmentStatus = this.mapper.employmentStatusDto(jobDetails);

        assertThat(employmentStatus).isEqualTo(EmploymentStatus.EMPLOYED.name());
    }

    @Test
    void returnsCorrectEmploymentStatusForDtoWhenEmploymentTypeIsContractor() {
        JobDetailsDto jobDetailsDto = createValidJobDetailsDto();
        jobDetailsDto.setEmploymentStatus(EmploymentStatus.EMPLOYED);
        jobDetailsDto.setEmploymentType(EmploymentType.CONTRACT);
        String employmentStatus = this.mapper.employmentStatus(jobDetailsDto);
        assertThat(employmentStatus).isEqualTo(JobDetails.EmploymentStatus.CONTRACTOR.value());
    }
}
