package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.google.common.collect.Sets.newHashSet;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_APPLICANT_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.SIZE_AT_LEAST_ONE_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_VERSION;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.emptyList;
import static java.util.Collections.singleton;

public class ApplicantProfileValidationTest extends AbstractValidationTest<ApplicantProfile> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid applicant profile", (Consumer<ApplicantProfile>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid applicant profile with both applicant.applicantId and applicant.version null", (Consumer<ApplicantProfile>) a -> {
                    a.getApplicants().get(0).setApplicantId(null);
                    a.getApplicants().get(0).setVersion(null);
                }, EMPTY_SET),
                Arguments.of("Applicants list is null", (Consumer<ApplicantProfile>) a -> a.setApplicants(null), singleton(create("applicants", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Applicants list is empty", (Consumer<ApplicantProfile>) a -> a.setApplicants(emptyList()), singleton(create("applicants", SIZE_AT_LEAST_ONE_MSG))),
                Arguments.of("applicant.applicantId provided, applicant.version null", (Consumer<ApplicantProfile>) a -> {
                    a.getApplicants().get(0).setApplicantId(null);
                    a.getApplicants().get(0).setVersion(TEST_VERSION);
                }, singleton(create("applicants[0]", "'version' must be present"))),
                Arguments.of("applicant.applicantId null, applicant.version provided", (Consumer<ApplicantProfile>) a -> {
                    a.getApplicants().get(0).setApplicantId(TEST_APPLICANT_ID);
                    a.getApplicants().get(0).setVersion(null);
                }, singleton(create("applicants[0]", "'version' must be present"))),
                Arguments.of("@Valid annotation - error when applicantDetails.name invalid", (Consumer<ApplicantProfile>) a -> a.getApplicants().get(0).getPersonalDetails().setTitle(null), singleton(create("applicants[0].personalDetails.title", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("@Valid annotation - error when applicantDetails.name invalid for multiple applicants", (Consumer<ApplicantProfile>) a -> {
                    a.getApplicants().get(0).getPersonalDetails().setTitle(null);
                    a.getApplicants().get(1).getPersonalDetails().setTitle(null);
                }, newHashSet(create("applicants[0].personalDetails.title", MUST_NOT_BE_NULL_ERROR_MESSAGE), create("applicants[1].personalDetails.title", MUST_NOT_BE_NULL_ERROR_MESSAGE)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testApplicantProfileValidations(String testDescription, Consumer<ApplicantProfile> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, ApplicantTestUtil::createValidApplicantProfile, mutator, expectedErrorMessages);
    }

}
