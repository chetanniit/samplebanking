package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.PaymentService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ProductSearchService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {PaymentController.class, ControllerAdvice.class, ProductSearchController.class})
public class PaymentControllerValidationTest {

    @MockBean
    private PaymentService paymentService;

    @MockBean
    private UserClaimsProvider userClaimsProvider;

    @MockBean
    private ProductSearchService productSearchService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void paymentValidRequest() throws Exception {
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setMortgageReferenceNumber("123456");
        String requestBodyContent = this.objectMapper.writeValueAsString(paymentRequest);
        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setPaymentUrl("https://test.worldpay.com");
        String responseBodyContent = this.objectMapper.writeValueAsString(paymentResponse);
        when(paymentService.fetchPaymentUrl(BRAND_DEFAULT, paymentRequest)).thenReturn(paymentResponse);

        RequestBuilder request = post(PATH_PAYMENT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }

    @Test
    public void paymentInvalidRequest() throws Exception {
        PaymentRequest paymentRequest = new PaymentRequest();
        String requestBodyContent = this.objectMapper.writeValueAsString(paymentRequest);

        RequestBuilder request = post(PATH_PAYMENT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("mortgageReferenceNumber"))
            .andExpect(jsonPath("$.errors[0].description").value("must not be blank"));
    }

    @Test
    public void paymentWithInvalidBrandHeader() throws Exception {
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setMortgageReferenceNumber("123456");
        String requestBodyContent = this.objectMapper.writeValueAsString(paymentRequest);

        String invalidBrand = "INVALID_BRAND";

        RequestBuilder request = post(PATH_PAYMENT)
                .header(BRAND_HEADER, invalidBrand)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("payment.brand"))
            .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

        verifyNoInteractions(paymentService);
    }
    
    @Test
    public void paymentInvalidContentTypeReturnsUnsupportedMediaTypeError() throws Exception {
        RequestBuilder request = post(PATH_PRODUCT_SEARCH)
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("text");

        this.mockMvc.perform(request)
                .andExpect(status().isUnsupportedMediaType());
    }

}
