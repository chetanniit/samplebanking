package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_DIP_WITH_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.DipService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

@WebMvcTest
@ContextConfiguration(classes = {DipController.class, ControllerAdvice.class})
public class DipControllerValidationTest {

    @MockBean
    private DipService dipService;

    @MockBean
    private UserClaimsProvider userClaimsProvider;

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void getDipCertificateWithCaseIdReturnsDipUnhandledValidationException() throws Exception {
        when(dipService.getDipCertificateWithCaseId(any(), any())).thenThrow(new DipIntegrationException("400 Bad Request: '{'errorCode':'400','errorMessage':'DIP has expired, create a new DIP'}', errors=null)"));

        RequestBuilder request = get(PATH_GET_DIP_WITH_CASE_ID, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON);

        this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType("application/json"))
                .andExpect(content().string("{\"status\":400,\"title\":\"DIP Submit Unhandled Validation Errors\",\"errors\":[{\"status\":400,\"code\":\"VALIDATION_EXPIRED_DIP\",\"message\":\"DIP has expired, create a new DIP\"}]}"));
    }

}
