package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ApplicantProfile;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalAddress;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ApplicantService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.web.client.HttpClientErrorException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.applicantsWorkStatusMap;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicant;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicantProfile;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.*;
import static java.util.Collections.emptyList;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {ApplicantController.class, ControllerAdvice.class})
public class ApplicantControllerValidationTest {

    @MockBean
    private ApplicantService applicantService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void addApplicantsValidRequest() throws Exception {
        ApplicantProfile applicantProfileRequest = createValidApplicantProfile();
        List<Applicant> applicants = applicantProfileRequest.getApplicants();
        Map<String, String> workStatusMap = applicantsWorkStatusMap(applicants, null);

        when(applicantService.saveApplicants(BRAND_DEFAULT, TEST_CASE_ID, applicants, workStatusMap)).thenReturn(applicants);

        String applicantsBodyContent = this.objectMapper.writeValueAsString(applicantProfileRequest);
        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(applicantsBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(applicantsBodyContent));
    }

    @Test
    public void addApplicantsMissingCaseIdReturnsNotFoundError() throws Exception {
        RequestBuilder request = put(PATH_ADD_APPLICANTS, (String) null)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(this.objectMapper.writeValueAsString(createValidApplicant()));

        this.mockMvc.perform(request)
                .andExpect(status().isNotFound());
    }

    @Test
    public void addApplicantsInvalidContentTypeReturnsUnsupportedMediaTypeError() throws Exception {
        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("text");

        this.mockMvc.perform(request)
                .andExpect(status().isUnsupportedMediaType());
    }


    @Test
    public void addApplicantsBadRequestErrorReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        ApplicantProfile applicantProfileRequest = createValidApplicantProfile();
        String requestBodyContent = this.objectMapper.writeValueAsString(applicantProfileRequest);

        String body = "{\"errorCount\":2,\"errors\":[{\"object\":\"object1\",\"field\":\"field1\",\"message\":\"message1\"},{\"field\":\"field2\",\"message\":\"message2\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(applicantService.saveApplicants(anyString(), anyString(), anyList(), anyMap())).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Bad Request"))
            .andExpect(jsonPath("$.description").value("The following errors occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("field1"))
            .andExpect(jsonPath("$.errors[0].description").value("message1"))
            .andExpect(jsonPath("$.errors[1].title").value("field2"))
            .andExpect(jsonPath("$.errors[1].description").value("message2"));
    }

    @Test
    public void addApplicantsBadRequestErrorReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        ApplicantProfile applicantProfileRequest = createValidApplicantProfile();
        String requestBodyContent = this.objectMapper.writeValueAsString(applicantProfileRequest);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(applicantService.saveApplicants(anyString(), anyString(), anyList(), anyMap())).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Bad Request"))
            .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @Test
    public void addApplicantsConflictReturnFromServiceIsPassedToCallerWhenAbleToParseBody() throws Exception {
        ApplicantProfile applicantProfileRequest = createValidApplicantProfile();
        String requestBodyContent = this.objectMapper.writeValueAsString(applicantProfileRequest);

        String body = "{\"errorCount\":1,\"errors\":[{\"message\":\"message1\"}]}";

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.CONFLICT, HttpStatus.CONFLICT.getReasonPhrase(), new HttpHeaders(), body.getBytes(), null);
        when(applicantService.saveApplicants(anyString(), anyString(), anyList(), anyMap())).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isConflict())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("409"))
            .andExpect(jsonPath("$.title").value("Conflict"))
            .andExpect(jsonPath("$.description").value("The following errors occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("Error"))
            .andExpect(jsonPath("$.errors[0].description").value("message1"));
    }

    @Test
    public void addApplicantsConflictReturnFromServiceIsPassedToCallerAsIsWhenNotAbleToParseBody() throws Exception {
        ApplicantProfile applicantProfileRequest = createValidApplicantProfile();
        String requestBodyContent = this.objectMapper.writeValueAsString(applicantProfileRequest);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.CONFLICT, HttpStatus.CONFLICT.getReasonPhrase(), new HttpHeaders(), CUSTOM_HTTP_BODY.getBytes(), null);
        when(applicantService.saveApplicants(anyString(), anyString(), anyList(), anyMap())).thenThrow(badRequestException);

        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isConflict())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("409"))
            .andExpect(jsonPath("$.title").value("Conflict"))
            .andExpect(jsonPath("$.description").value(CUSTOM_HTTP_BODY));
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("addApplicantsArgs")
    public void addApplicantsRequestWithValidationErrorsReturnsBadRequestError(String testDescription, Consumer<ApplicantProfile> mutator,
                                                                               ErrorResponse expected) throws Exception {
        ApplicantProfile applicantProfileRequest = createValidApplicantProfile();
        mutator.accept(applicantProfileRequest);

        RequestBuilder request = put(PATH_ADD_APPLICANTS, TEST_CASE_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.objectMapper.writeValueAsString(applicantProfileRequest));

        MvcResult mvcResult = this.mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        ErrorResponse response = this.objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ErrorResponse.class);
        assertThat(response)
                .usingRecursiveComparison()
                .ignoringCollectionOrder()
                .isEqualTo(expected);
    }

    private static Stream<Arguments> addApplicantsArgs() {
        return Stream.of(
                Arguments.of("Applicants list empty", (Consumer<ApplicantProfile>) a -> a.setApplicants(emptyList()),
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                            new ErrorResponseDetail("applicants", SIZE_AT_LEAST_ONE_MSG)))),
                Arguments.of("PersonalDetails multiple errors for one applicant", (Consumer<ApplicantProfile>) a -> {
                            PersonalDetails personalDetails = a.getApplicants().get(0).getPersonalDetails();
                            personalDetails.setTitle("invalid");
                            personalDetails.setFirstNames(null);
                            personalDetails.setLastName(randomAlphabetic(26));
                            personalDetails.setDateOfBirth("2001-13-32");

                            List<PersonalAddress> addrs = new ArrayList<>();
                            a.getApplicants().get(0).setAddresses(addrs);
                            PersonalAddress addr = new PersonalAddress();
                            addrs.add(addr);
                            addr.setCountry("ZZZ");
                            addr.setHouseNumber(randomAlphabetic(6));
                            addr.setHouseName(randomAlphabetic(23));
                            addr.setFlatNameOrNumber(randomAlphabetic(11));
                            addr.setStreet(randomAlphabetic(31));
                            addr.setTown(randomAlphabetic(29));
                            addr.setCounty(randomAlphabetic(119));
                            addr.setPostcode("6H6 6BU");
                            addr.setStartMonth(13);
                            addr.setStartYear(1899);
                            addr.setOccupyStatus("invalid");
                            addr.setCurrentPropertyValue(999999999);
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                                new ErrorResponseDetail("applicants[0].personalDetails.title", "must be any of: None, Mr, Mrs, Miss, Ms, Dr, Reverend, Professor, Sir, Lord, Lady, Captain, Major, Colonel, Master, Hon, Mx, Sister, Viscount, Countess, Earl, Other"),
                                new ErrorResponseDetail("applicants[0].personalDetails.firstNames", MUST_NOT_BE_BLANK_ERROR_MESSAGE),
                                new ErrorResponseDetail("applicants[0].personalDetails.lastName", "size must be between 2 and 25"),
                                new ErrorResponseDetail("applicants[0].personalDetails.dateOfBirth", "must be a date in the past in format 'yyyy-MM-dd'"),
                                new ErrorResponseDetail("applicants[0].addresses[0].country", "size must be between 2 and 2"),
                                new ErrorResponseDetail("applicants[0].addresses[0].houseNumber", "size must be between 0 and 5"),
                                new ErrorResponseDetail("applicants[0].addresses[0].houseName", "size must be between 0 and 22"),
                                new ErrorResponseDetail("applicants[0].addresses[0].flatNameOrNumber", "size must be between 0 and 10"),
                                new ErrorResponseDetail("applicants[0].addresses[0].street", "size must be between 0 and 30"),
                                new ErrorResponseDetail("applicants[0].addresses[0].town", "size must be between 0 and 28"),
                                new ErrorResponseDetail("applicants[0].addresses[0].county", "size must be between 0 and 18"),
                                new ErrorResponseDetail("applicants[0].addresses[0].startMonth", "must be less than or equal to 12"),
                                new ErrorResponseDetail("applicants[0].addresses[0].startYear", "must be greater than or equal to 1900"),
                                new ErrorResponseDetail("applicants[0].addresses[0].occupyStatus", "must be any of: OWNER_MORTGAGED, OWNER_NO_MORTGAGE, LIVING_WITH_RELATIVES, OTHER, TENANT"),
                                new ErrorResponseDetail("applicants[0].addresses[0].currentPropertyValue", "must be less than or equal to 99999999")
                        ))),
                Arguments.of("PersonalDetails multiple errors for two applicants", (Consumer<ApplicantProfile>) a -> {
                            PersonalDetails firstApplicantDetails = a.getApplicants().get(0).getPersonalDetails();
                            firstApplicantDetails.setTitle(null);
                            firstApplicantDetails.setMiddleNames(randomAlphabetic(26));
                            PersonalAddress personalAddress = a.getApplicants().get(0).getAddresses().get(0);
                            personalAddress.setOccupyStatus("OWNER_MORTGAGED");
                            personalAddress.setCurrentPropertyValue(null);
                            PersonalDetails secondApplicantDetails = a.getApplicants().get(1).getPersonalDetails();
                            secondApplicantDetails.setNationality(randomAlphabetic(3));
                        },
                        new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Arrays.asList(
                                new ErrorResponseDetail("applicants[0].personalDetails.title", MUST_NOT_BE_NULL_ERROR_MESSAGE),
                                new ErrorResponseDetail("applicants[0].personalDetails.middleNames", "size must be between 0 and 25"),
                                new ErrorResponseDetail("applicants[1].personalDetails.nationality", "size must be between 0 and 2")
                        )))
        );
    }
}
