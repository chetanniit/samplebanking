package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import java.math.BigDecimal;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class CaseApplicationValidationTest extends AbstractValidationTest<CaseApplication> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid case application", (Consumer<CaseApplication>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid case application with null case id", (Consumer<CaseApplication>) a -> a.setCaseId(null), EMPTY_SET),
                Arguments.of("Valid case application with null version", (Consumer<CaseApplication>) a -> a.setVersion(null), EMPTY_SET),
                Arguments.of("Valid case application with null mortgage", (Consumer<CaseApplication>) a -> a.setMortgage(null), EMPTY_SET),
                Arguments.of("@Valid annotation - error when mortgage.mortgageAdvised invalid", (Consumer<CaseApplication>) a -> a.getMortgage().setMortgageAdvised("invalid"), singleton(create("mortgage.mortgageAdvised", "must be any of: ADVICE, REJECTED_ADVICE_EXECUTION_ONLY"))),
                Arguments.of("@Valid annotation - error when mortgage term is above maximum value 40 years and 0 months", (Consumer<CaseApplication>) a -> {
                    a.getMortgage().setMortgageTermYears(40);
                    a.getMortgage().setMortgageTermMonths(1);
                }, singleton(create("mortgage", "'mortgageTermMonths' value cannot be greater than 0 when 'mortgageTermYears' equals 40"))),
                Arguments.of("numberOfDependantsUnder18 is less than 0", (Consumer<CaseApplication>) a -> a.setNumberOfDependantsUnder18(-1), singleton(create("numberOfDependantsUnder18", "must be greater than or equal to 0"))),
                Arguments.of("numberOfDependantsUnder18 is more than 99", (Consumer<CaseApplication>) a -> a.setNumberOfDependantsUnder18(100), singleton(create("numberOfDependantsUnder18", "must be less than or equal to 99"))),
                Arguments.of("numberOfDependantsOver18 is less than 0", (Consumer<CaseApplication>) a -> a.setNumberOfDependantsOver18(-1), singleton(create("numberOfDependantsOver18", "must be greater than or equal to 0"))),
                Arguments.of("numberOfDependantsOver18 is more than 99", (Consumer<CaseApplication>) a -> a.setNumberOfDependantsOver18(100), singleton(create("numberOfDependantsOver18", "must be less than or equal to 99"))),
                Arguments.of("repayMortgageCurrency is more than three characters", (Consumer<CaseApplication>) a -> a.setRepayMortgageCurrency("ABCD"), singleton(create("repayMortgageCurrency", "Badly formed currency code"))),
                Arguments.of("repayMortgageCurrency is less than three characters", (Consumer<CaseApplication>) a -> a.setRepayMortgageCurrency("AB"), singleton(create("repayMortgageCurrency", "Badly formed currency code"))),
                Arguments.of("solicitor.companyName is null",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setCompanyName(null),
                        singleton(create("solicitor.companyName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("solicitor.companyName is less than 3 characters",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setCompanyName("12"),
                        singleton(create("solicitor.companyName", "size must be between 3 and 45"))),
                Arguments.of("solicitor.companyName is greater than 45 characters",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setCompanyName("01234567890123456789012345678901234567890123456"),
                        singleton(create("solicitor.companyName", "size must be between 3 and 45"))),
                Arguments.of("solicitor.address is null",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setAddress(null),
                        singleton(create("solicitor.address", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("solicitor.address.addressPC is blank",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().getAddress().setAddressPC(""),
                        singleton(create("solicitor.address.addressPC", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("solicitor.address.addressPC is greater than 8 characters",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().getAddress().setAddressPC("123456789"),
                        singleton(create("solicitor.address.addressPC", "size must be between 0 and 8"))),
                Arguments.of("solicitor.telephoneNumber is 2 characters",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setTelephoneNumber("12"),
                        singleton(create("solicitor.telephoneNumber", "Badly formed phone number"))),
                Arguments.of("solicitor.telephoneNumber is 16 characters",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setTelephoneNumber("1234567890123456"),
                        singleton(create("solicitor.telephoneNumber", "Badly formed phone number"))),
                Arguments.of("solicitor.telephoneNumber contains non-numbers",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setTelephoneNumber("12345678901A"),
                        singleton(create("solicitor.telephoneNumber", "Badly formed phone number"))),
                Arguments.of("solicitor.emailAddress is greater than 72 characters",
                        (Consumer<CaseApplication>) a -> a.getSolicitor().setEmailAddress("1234567890123456789012345678901234567890123456789012345678901234567890123"),
                        singleton(create("solicitor.emailAddress", "size must be between 0 and 72"))),
                Arguments.of("broker.consentToDIP is false",
                        (Consumer<CaseApplication>) a -> a.getBroker().setConsentToDIP(false),
                        singleton(create("broker.consentToDIP", "must be true"))),
                Arguments.of("broker.consentToFMA is false",
                    (Consumer<CaseApplication>) a -> a.getBroker().setConsentToFMA(false),
                    singleton(create("broker.consentToFMA", "must be true"))),
                Arguments.of("broker.fee is less than 0",
                    (Consumer<CaseApplication>) a -> a.getBroker().setFee(BigDecimal.valueOf(-1)),
                    singleton(create("broker.fee", "must be greater than or equal to 0"))),
                Arguments.of("broker.fee is more than 9999",
                    (Consumer<CaseApplication>) a -> a.getBroker().setFee(
                        BigDecimal.valueOf(10_000)),
                    singleton(create("broker.fee", "must be less than or equal to 9999"))),
                Arguments.of("Valid case application with null levelOfService",
                        (Consumer<CaseApplication>) a -> a.getServiceLevel().setLevelOfService(null), EMPTY_SET)
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testCaseApplicationValidations(String testDescription, Consumer<CaseApplication> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidCaseApplication, mutator, expectedErrorMessages);
    }
}
