package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.PropertyDetailsTestUtil.createValidPropertyDetailsDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.constructExpectedHeaders;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PropertyClientNapoliTest {

    private static final String TEST_ENDPOINT_GET = "http://test.endpoint/properties/{caseId}";
    private static final String TEST_ENDPOINT_CREATE = "http://test.endpoint/properties";
    private static final String TEST_ENDPOINT_UPDATE = "http://test.endpoint/properties/{caseId}";

    @Mock
    private RestTemplate mockRestTemplate;

    private PropertyClientNapoli propertyClient;

    @BeforeEach
    void setUp() {
        this.propertyClient = new PropertyClientNapoli(TEST_ENDPOINT_GET, TEST_ENDPOINT_CREATE, TEST_ENDPOINT_UPDATE, mockRestTemplate);
    }

    @Test
    void savePropertyMakesPostCallWhenVersionMissing() {
        PropertyDetailsDto propertyDetailsDtoToSave = createValidPropertyDetailsDto();
        // version=null indicates this is a new property to be created
        propertyDetailsDtoToSave.setVersion(null);

        PropertyDetailsDto expectedPropertyDetailsDtoResponse = createValidPropertyDetailsDto();
        ResponseEntity<PropertyDetailsDto> expectedResponseEntity = ResponseEntity.ok(expectedPropertyDetailsDtoResponse);
        HttpEntity<PropertyDetailsDto> expectedHttpEntity = new HttpEntity<>(propertyDetailsDtoToSave, constructExpectedHeaders());
        when(mockRestTemplate.exchange(URI.create(TEST_ENDPOINT_CREATE), HttpMethod.POST, expectedHttpEntity, PropertyDetailsDto.class))
                .thenReturn(expectedResponseEntity);

        PropertyDetailsDto propertyDetailsDtoResponse = this.propertyClient.saveProperty(BRAND_DEFAULT, propertyDetailsDtoToSave);

        verify(mockRestTemplate).exchange(URI.create(TEST_ENDPOINT_CREATE), HttpMethod.POST, expectedHttpEntity, PropertyDetailsDto.class);
    }

    @Test
    void savePropertyMakesPutCallWhenVersionPresent() {
        PropertyDetailsDto propertyDetailsDtoToSave = createValidPropertyDetailsDto();

        PropertyDetailsDto expectedPropertyDetailsDtoResponse = createValidPropertyDetailsDto();
        ResponseEntity<PropertyDetailsDto> expectedResponseEntity = ResponseEntity.ok(expectedPropertyDetailsDtoResponse);
        HttpEntity<PropertyDetailsDto> expectedHttpEntity = new HttpEntity<>(propertyDetailsDtoToSave, constructExpectedHeaders());
        URI expectedEndpoint = URI.create(TEST_ENDPOINT_UPDATE.replace("{caseId}", TEST_CASE_ID));
        when(mockRestTemplate.exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, PropertyDetailsDto.class))
                .thenReturn(expectedResponseEntity);

        PropertyDetailsDto propertyDetailsDtoResponse = this.propertyClient.saveProperty(BRAND_DEFAULT, propertyDetailsDtoToSave);

        verify(mockRestTemplate).exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, PropertyDetailsDto.class);
    }

    @Test
    void savePropertyBadRequestErrorFromCreateIsPassedToCaller() {
        PropertyDetailsDto propertyDetailsDtoToSave = createValidPropertyDetailsDto();
        // version=null indicates this is a new property to be created
        propertyDetailsDtoToSave.setVersion(null);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(PropertyDetailsDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> propertyClient.saveProperty(BRAND_DEFAULT, propertyDetailsDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void savePropertyBadRequestErrorFromUpdateIsPassedToCaller() {
        PropertyDetailsDto propertyDetailsDtoToSave = createValidPropertyDetailsDto();

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(PropertyDetailsDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> propertyClient.saveProperty(BRAND_DEFAULT, propertyDetailsDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void getPropertyReturnsNullOn404Error() {
        HttpClientErrorException notFoundException = HttpClientErrorException.create(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.getReasonPhrase(), new HttpHeaders(), null, null);
        when(mockRestTemplate.exchange(any(), any(), any(), eq(PropertyDetailsDto.class))).thenThrow(notFoundException);

        PropertyDetailsDto propertyDetailsDto = propertyClient.getProperty(BRAND_DEFAULT, TEST_CASE_ID);
        assertNull(propertyDetailsDto);
    }
}
