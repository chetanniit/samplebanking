package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.rbs.dws.security.UserPrincipal;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

public class MockUserPrincipal implements UserPrincipal {

  public static final String ADDITIONAL_CLAIMS = "additional_claims";

  private final Map<String, Object> claims;

  public MockUserPrincipal(Map<String, Object> claims) {
    this.claims = claims;
  }

  @Override
  public String getUserName() {
    return null;
  }

  @Override
  public String getDomain() {
    return null;
  }

  @Override
  public String getToken() {
    return null;
  }

  @Override
  public X509Certificate getCertificate() {
    return null;
  }

  @Override
  public Date getSessionExpiry() {
    return null;
  }

  @Override
  public String getRemoteAddress() {
    return null;
  }

  @Override
  public Integer getAuthenticationLevel() {
    return null;
  }

  @Override
  public boolean isEmployee() {
    return false;
  }

  @Override
  public boolean isAccessingInternally() {
    return false;
  }

  @Override
  public boolean isImpersonating() {
    return false;
  }

  @Override
  public UserPrincipal getImpersonatorsUserPrincipal() {
    return null;
  }

  @Override
  public Object getProperty(String key) {
    if (claims.containsKey(key)) {
      return claims.get(key);
    }
    final Map<?, ?> additionalClaims = (Map<?, ?>) claims.get(ADDITIONAL_CLAIMS);
    return additionalClaims.get(key);
  }

  @Override
  public Collection<String> getPropertyKeys() {
    return claims.keySet();
  }

  @Override
  public String getName() {
    return null;
  }
}
