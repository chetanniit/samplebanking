package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import org.assertj.core.api.AssertionsForClassTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.nio.charset.StandardCharsets;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidCaseApplicationDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.constructExpectedHeaders;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CaseClientNapoliTest {

    private static final String TEST_ENDPOINT_GET = "http://test.endpoint/cases/{caseId}";
    private static final String TEST_ENDPOINT_CREATE = "http://test.endpoint/cases";
    private static final String TEST_ENDPOINT_UPDATE = "http://test.endpoint/cases/{caseId}";

    @Mock
    private RestTemplate mockRestTemplate;

    private CaseClientNapoli caseClient;

    @BeforeEach
    void setUp() {
        this.caseClient = new CaseClientNapoli(TEST_ENDPOINT_GET, TEST_ENDPOINT_CREATE, TEST_ENDPOINT_UPDATE, mockRestTemplate);
    }

    @Test
    void createCaseMakesPostCall() {
        CaseApplicationDto caseApplicationDtoToSave = createValidCaseApplicationDto();
        caseApplicationDtoToSave.setVersion(null);

        CaseApplicationDto expectedCaseApplicationDtoResponse = createValidCaseApplicationDto();
        ResponseEntity<CaseApplicationDto> expectedResponseEntity = ResponseEntity.ok(expectedCaseApplicationDtoResponse);
        HttpEntity<CaseApplicationDto> expectedHttpEntity = new HttpEntity<>(caseApplicationDtoToSave, constructExpectedHeaders());
        when(mockRestTemplate.exchange(URI.create(TEST_ENDPOINT_CREATE), HttpMethod.POST, expectedHttpEntity, CaseApplicationDto.class))
                .thenReturn(expectedResponseEntity);

        CaseApplicationDto applicantDtoResponse = this.caseClient.createCase(BRAND_DEFAULT, caseApplicationDtoToSave);

        verify(mockRestTemplate).exchange(URI.create(TEST_ENDPOINT_CREATE), HttpMethod.POST, expectedHttpEntity, CaseApplicationDto.class);
        assertEquals(expectedCaseApplicationDtoResponse, applicantDtoResponse);
    }

    @Test
    void updateCaseMakesPutCall() {
        CaseApplicationDto caseApplicationDtoToSave = createValidCaseApplicationDto();

        CaseApplicationDto expectedCaseApplicationDtoResponse = createValidCaseApplicationDto();
        ResponseEntity<CaseApplicationDto> expectedResponseEntity = ResponseEntity.ok(expectedCaseApplicationDtoResponse);
        HttpEntity<CaseApplicationDto> expectedHttpEntity = new HttpEntity<>(caseApplicationDtoToSave, constructExpectedHeaders());
        URI expectedEndpoint = URI.create(TEST_ENDPOINT_UPDATE.replace("{caseId}", TEST_CASE_ID));
        when(mockRestTemplate.exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, CaseApplicationDto.class))
                .thenReturn(expectedResponseEntity);

        CaseApplicationDto applicantDtoResponse = this.caseClient.updateCase(BRAND_DEFAULT, caseApplicationDtoToSave);

        verify(mockRestTemplate).exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, CaseApplicationDto.class);
        assertEquals(expectedCaseApplicationDtoResponse, applicantDtoResponse);
    }

    @Test
    void createCaseBadRequestErrorReceivedIsPassedToTheCaller() {
        CaseApplicationDto applicantDtoToSave = createValidCaseApplicationDto();
        applicantDtoToSave.setVersion(null);

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(CaseApplicationDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> this.caseClient.createCase(BRAND_DEFAULT, applicantDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void updateCaseBadRequestErrorReceivedIsPassedToTheCaller() {
        CaseApplicationDto applicantDtoToSave = createValidCaseApplicationDto();

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(CaseApplicationDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> this.caseClient.updateCase(BRAND_DEFAULT, applicantDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void getCasePropagates404Error() {
        String notFoundBody = "not-found-error-body";
        HttpClientErrorException notFoundException = HttpClientErrorException.create(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.getReasonPhrase(), new HttpHeaders(), notFoundBody.getBytes(StandardCharsets.UTF_8), null);
        when(mockRestTemplate.exchange(any(), any(), any(), eq(CaseApplicationDto.class))).thenThrow(notFoundException);

        assertThat(AssertionsForClassTypes.catchThrowableOfType(() -> caseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID), HttpClientErrorException.class))
                .isInstanceOf(HttpClientErrorException.NotFound.class)
                .matches(notFoundException::equals);
    }
}
