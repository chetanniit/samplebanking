package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
class MafDocumentIT {
    private static final String FMA_SERVICE_NAME = "msvc-full-mortgage-application";

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Value("${full.mortgage.application.endpoint}")
    private String fullMortgageApplicationEndpoint;

    @Value("${client.id}")
    private String clientId;

    @Value("classpath:fma-test-cases/fma-request/scenario-1.json")
    private Resource fmaRequestJson;
    private final String caseId = "WQ1692030237794"; // from the above json

    @MockBean
    private AccessPermissionChecker mockAccessPermissionChecker;

    @LocalServerPort
    private int port;

    @Autowired
    private TokenConfiguration tokenConfig;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void testGetDocumentByNameNotFound() {
        String mafDocumentName = "MAF-foo-bar.pdf";
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        with().log().all()
                .pathParam(MAF_DOC_NAME_PARAM, mafDocumentName)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_MAF_DOC_FROM_NAME)
                .then()
                .statusCode(HttpStatus.NOT_FOUND.value());
    }

    @Test
    void submitAndGetDocument() throws IOException {
        RestAssured.baseURI = fullMortgageApplicationEndpoint;
        RestAssured.port = 443;

        String body = getResourceText(fmaRequestJson);

        // Submit FMA
        Response response = with()
                .header("client_id", clientId)
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, FMA_SERVICE_NAME))
                .contentType(APPLICATION_JSON_VALUE)
                .body(body)
                .post("/");

        log.info(response.body().asPrettyString());

        // reset URL after FMA submission
        setUp();

        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // use case ID to check CAPIE for mafDocumentUrl
        BrokerCase brokerCaseResponse = with()
                .log().all()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_BROKER_CASE)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        assertThat(brokerCaseResponse.getCaseApplication().getMafDocumentName()).isNotNull();

        // download mafDocumentUrl
        byte[] mafDoc = with().log().all()
                .pathParam(MAF_DOC_NAME_PARAM, brokerCaseResponse.getCaseApplication().getMafDocumentName())
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_MAF_DOC_FROM_NAME)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_PDF_VALUE)
                .extract().asByteArray();

        // Uncomment the below code to save the resulting MAF document
//        File target = new File("src/test/resources/maf_doc_full_flow.pdf");
//        FileUtils.writeByteArrayToFile(target, mafDoc);
    }
}
