package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidAdditionalIncome;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidJobDetails;
import static java.util.Collections.*;
import static java.util.Collections.singleton;

public class IncomeApplicantValidationTest extends AbstractValidationTest<IncomeApplicant> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid income applicant", (Consumer<IncomeApplicant>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid income applicant when otherIncome is null", (Consumer<IncomeApplicant>) a -> a.setOtherIncome(null), EMPTY_SET),
                Arguments.of("Valid income applicant when AdditionalJobDetails is null", (Consumer<IncomeApplicant>) a -> a.setAdditionalJobDetails(null), EMPTY_SET),
                Arguments.of("applicantId is null", (Consumer<IncomeApplicant>) a -> a.setApplicantId(null), singleton(create("applicantId", "must not be null"))),
                Arguments.of("OtherIncome map is empty", (Consumer<IncomeApplicant>) a -> a.setOtherIncome(emptyMap()), singleton(create("otherIncome", "size must be between 1 and 25"))),
                Arguments.of("AdditionalJobDetails list is too large", (Consumer<IncomeApplicant>) a -> {
                    List<JobDetails> details = new ArrayList<>();
                    for (int i = 0; i < 11; i++) {
                        details.add(createValidJobDetails());
                    }
                    a.setAdditionalJobDetails(details);
                }, singleton(create("additionalJobDetails", "size must be between 0 and 9"))),
                Arguments.of("@Valid annotation - error when AdditionalJobDetails invalid", (Consumer<IncomeApplicant>) a -> a.getAdditionalJobDetails().get(0).setSelfEmploymentStatus("invalid status"), singleton(create("additionalJobDetails[0].selfEmploymentStatus", "must be any of: SOLE_TRADER, PARTNERSHIP, LIMITED_COMPANY"))),
                Arguments.of("@Valid annotation - error when OtherIncome invalid", (Consumer<IncomeApplicant>) a -> a.getOtherIncome().get("otherIncome1").setSourceOfIncome(null), singleton(create("otherIncome[otherIncome1].sourceOfIncome", "must not be blank")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testIncomeApplicantValidations(String testDescription, Consumer<IncomeApplicant> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, IncomeTestUtil::createValidIncomeApplicant, mutator, expectedErrorMessages);
    }
}
