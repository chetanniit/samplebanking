package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.SolicitorMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.SolicitorMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.SolicitorSearchService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.SolicitorTestUtil;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import jakarta.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.impl.SolicitorSearchServiceImpl.SEARCH_TEXT_TOO_SHORT_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.BRAND_RBS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {SolicitorSearchController.class, ControllerAdvice.class, SolicitorMapperImpl.class})
class SolicitorSearchControllerValidationTest {

    @MockBean
    private SolicitorSearchService solicitorSearchService;

    @MockBean
    private UserClaimsProvider userClaimsProvider;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private SolicitorMapper solicitorMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void solicitorSearchValidRequest() throws Exception {
        String searchFor = "EH6";
        List<Solicitor> solicitorSearchResponse = Lists.list(
                solicitorMapper.toSolicitor(SolicitorTestUtil.createExampleSolicitorSearchResultDto("ABC solicitors", "EH6 5AB")),
                solicitorMapper.toSolicitor(SolicitorTestUtil.createExampleSolicitorSearchResultDto("XYZ solicitors", "EH6 5XY"))
        );
        String responseBodyContent = this.objectMapper.writeValueAsString(solicitorSearchResponse);
        when(solicitorSearchService.solicitorSearch(BRAND_DEFAULT, searchFor)).thenReturn(solicitorSearchResponse);

        RequestBuilder request = get(PATH_SOLICITOR_SEARCH)
                .queryParam(SEARCH_FOR_PARAM, searchFor);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }

    @Test
    void solicitorSearchWithValidBrandHeader() throws Exception {
        String searchFor = "EH6";
        List<Solicitor> solicitorSearchResponse = Lists.list(
                solicitorMapper.toSolicitor(SolicitorTestUtil.createExampleSolicitorSearchResultDto("ABC solicitors", "EH6 5AB")),
                solicitorMapper.toSolicitor(SolicitorTestUtil.createExampleSolicitorSearchResultDto("XYZ solicitors", "EH6 5XY"))
        );
        when(solicitorSearchService.solicitorSearch(BRAND_RBS, searchFor)).thenReturn(solicitorSearchResponse);

        RequestBuilder request = get(PATH_SOLICITOR_SEARCH)
                .queryParam(SEARCH_FOR_PARAM, searchFor)
                .header(BRAND_HEADER, BRAND_RBS);

        this.mockMvc.perform(request).andExpect(status().isOk());

        verify(solicitorSearchService).solicitorSearch(BRAND_RBS, searchFor);
    }

    @Test
    void solicitorSearchWithInvalidBrandHeader() throws Exception {
        String searchFor = "EH6";

        String invalidBrand = "INVALID_BRAND";

        RequestBuilder request = get(PATH_SOLICITOR_SEARCH)
                .queryParam(SEARCH_FOR_PARAM, searchFor)
                .header(BRAND_HEADER, invalidBrand);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("solicitorSearch.brand"))
            .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

        verifyNoInteractions(solicitorSearchService);
    }

    @Test
    void solicitorSearchWithNoSearchTextReturnsBadRequest() throws Exception {
        String searchFor = "EH6";

        RequestBuilder request = get(PATH_SOLICITOR_SEARCH);

        this.mockMvc.perform(request).andExpect(status().isBadRequest());
    }


    @Test
    void solicitorSearchServiceThrowsConstraintViolation() throws Exception {
        String searchFor = " E ";

        when(solicitorSearchService.solicitorSearch(BRAND_DEFAULT, searchFor)).thenThrow(new ConstraintViolationException(SEARCH_TEXT_TOO_SHORT_MESSAGE, null));
        RequestBuilder request = get(PATH_SOLICITOR_SEARCH)
                .queryParam(SEARCH_FOR_PARAM, searchFor);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value(SEARCH_TEXT_TOO_SHORT_MESSAGE));
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("solicitorSearchValidationCases")
    public void solicitorSearchWithValidationErrorsReturnsBadRequestError(
            String testDescription, String searchFor, ErrorResponse expected
    ) throws Exception {
        RequestBuilder request = get(PATH_SOLICITOR_SEARCH)
                .queryParam(SEARCH_FOR_PARAM, searchFor);

        MvcResult mvcResult = this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andReturn();

        ErrorResponse response = this.objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), ErrorResponse.class);

        assertThat(response)
            .usingRecursiveComparison()
            .ignoringCollectionOrder()
            .isEqualTo(expected);
    }

    private static Stream<Arguments> solicitorSearchValidationCases() {
        return Stream.of(
            Arguments.of("Search text too short", "E",
                new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                    new ErrorResponseDetail("solicitorSearch.searchFor", "size must be between 2 and 45")))),
            Arguments.of("Search text too long", "1234567890123456789012345678901234567890123456",
                new ErrorResponse(400, "Validation Failure", "The following validation failures occurred", Collections.singletonList(
                    new ErrorResponseDetail("solicitorSearch.searchFor", "size must be between 2 and 45"))))
        );
    }
}
