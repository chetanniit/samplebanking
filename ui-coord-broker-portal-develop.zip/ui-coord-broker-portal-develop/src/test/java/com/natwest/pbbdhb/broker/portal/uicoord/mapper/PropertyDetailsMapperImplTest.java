package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.PropertyDetails;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PROPERTY_JOURNEY_DATA_HOME_REPORT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PROPERTY_JOURNEY_DATA_NEW_BUILD;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.PropertyDetailsTestUtil.createValidPropertyDetails;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.PropertyDetailsTestUtil.createValidPropertyDetailsDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        PropertyDetailsMapperImpl.class,
        PropertyAddressMapperImpl.class
})
class PropertyDetailsMapperImplTest {

    @Autowired
    private PropertyDetailsMapper mapper;

    @Test
    void testRoundTripMapping() {
        PropertyDetails propertyDetails = createValidPropertyDetails();
        PropertyDetailsDto propertyDetailsDto = this.mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);
        PropertyDetails roundTripResult = this.mapper.toPropertyDetails(propertyDetailsDto);

        assertThat(roundTripResult).usingRecursiveComparison().ignoringFields("valuation").isEqualTo(propertyDetails);
    }

    @Test
    void toPropertyDetailsDtoMapsJourneyData() {
        PropertyDetails propertyDetails = createValidPropertyDetails();
        propertyDetails.setNewBuild(true);
        propertyDetails.setHomeReport(true);

        PropertyDetailsDto result = this.mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);

        assertThat((Boolean) result.getJourneyData().get(PROPERTY_JOURNEY_DATA_NEW_BUILD)).isTrue();
        assertThat((Boolean) result.getJourneyData().get(PROPERTY_JOURNEY_DATA_HOME_REPORT)).isTrue();
    }

    @Test
    void toPropertyDetailsMapsJourneyData() {
        PropertyDetailsDto propertyDetailsDto = createValidPropertyDetailsDto();
        final Map<String, Object> journeyData = new HashMap<>();
        journeyData.put(PROPERTY_JOURNEY_DATA_NEW_BUILD, true);
        journeyData.put(PROPERTY_JOURNEY_DATA_HOME_REPORT, true);
        propertyDetailsDto.setJourneyData(journeyData);

        PropertyDetails result = this.mapper.toPropertyDetails(propertyDetailsDto);

        assertThat(result.getNewBuild()).isTrue();
        assertThat(result.isHomeReport()).isTrue();
    }

    @Test
    void testPropertyDetailsEpcTrueMapping() {
        PropertyDetails propertyDetails = createValidPropertyDetails();
        propertyDetails.setEpcRatingAorB(true);

        PropertyDetailsDto result = mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);
        PropertyDetails roundTrip = mapper.toPropertyDetails(result);

        assertThat(result.getEpcRating()).isEqualTo("A");
        assertThat(roundTrip.isEpcRatingAorB()).isTrue();
    }

    @Test
    void testPropertyDetailsEpcFalseMapping() {
        PropertyDetails propertyDetails = createValidPropertyDetails();
        propertyDetails.setEpcRatingAorB(false);

        PropertyDetailsDto result = mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);
        PropertyDetails roundTrip = mapper.toPropertyDetails(result);

        assertThat(result.getEpcRating()).isEqualTo("NO_VALID_EPC");
        assertThat(roundTrip.isEpcRatingAorB()).isFalse();
    }

    @Test
    void toPropertyDetailsDtoConstantsSet() {
        PropertyDetails propertyDetails = createValidPropertyDetails();

        PropertyDetailsDto result = mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);

        assertThat(result.getWallType()).isEqualTo("BRICKS_AND_MORTAR");
        assertThat(result.getUsage()).isEqualTo("OWNER_OCCUPIED");
        assertThat(result.getPropertyClass()).isEqualTo("RESIDENTIAL");
    }

    @Test
    void toPropertyDetailsDtoConstantsSetWithHomeReport() {
        PropertyDetails propertyDetails = createValidPropertyDetails();
        propertyDetails.setHomeReport(true);

        PropertyDetailsDto result = mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);

        assertThat(result.getWallType()).isEqualTo("BRICKS_AND_MORTAR");
        assertThat(result.getUsage()).isEqualTo("OWNER_OCCUPIED");
        assertThat(result.getPropertyClass()).isEqualTo("RESIDENTIAL");
    }

    @Test
    void toPropertyDetailsDtoConstantsSetScottishValuation() {
        PropertyDetails propertyDetails = createValidPropertyDetails();
        propertyDetails.setHomeReport(false);

        PropertyDetailsDto result = mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, false);

        assertThat(result.getWallType()).isEqualTo("BRICKS_AND_MORTAR");
        assertThat(result.getUsage()).isEqualTo("OWNER_OCCUPIED");
        assertThat(result.getPropertyClass()).isEqualTo("RESIDENTIAL");
    }

    @Test
    void toPropertyDetailsDtoConstantsSetBuyToLet() {
        PropertyDetails propertyDetails = createValidPropertyDetails();

        PropertyDetailsDto result = mapper.toPropertyDetailsDto(TEST_CASE_ID, propertyDetails, true);

        assertThat(result.getUsage()).isEqualTo("FULLY_LET");
        assertThat(result.getPropertyClass()).isEqualTo("RESIDENTIAL");
    }
}
