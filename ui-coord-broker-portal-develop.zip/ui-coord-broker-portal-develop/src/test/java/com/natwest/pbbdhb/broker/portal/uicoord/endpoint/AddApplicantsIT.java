package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ApplicantProfile;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.getNewCaseId;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.readApplicantProfileFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_ADD_APPLICANTS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class AddApplicantsIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/applicants/add-applicants-one-create-request.json")
    private Resource addApplicantsOneCreateRequest;

    @Value("classpath:test-files/applicants/add-applicants-one-create-response.json")
    private Resource addApplicantsOneCreateResponse;

    @Value("classpath:test-files/applicants/add-applicants-one-update-request.json")
    private Resource addApplicantsOneUpdateRequest;

    @Value("classpath:test-files/applicants/add-applicants-one-update-response.json")
    private Resource addApplicantsOneUpdateResponse;

    @Autowired
    private TokenConfiguration tokenConfig;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void addApplicantsCreatesAndUpdatesApplicant() throws IOException {
        String caseId = getNewCaseId(tokenConfig);
        assertThat(caseId).isNotEmpty();

        ApplicantProfile createRequest = readApplicantProfileFromResource(addApplicantsOneCreateRequest);
        ApplicantProfile expectedCreateResponse = readApplicantProfileFromResource(addApplicantsOneCreateResponse);

        Response createResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(createRequest)
                .put(PATH_ADD_APPLICANTS);

        log.info(createResponse.getBody().prettyPrint());

        ApplicantProfile createResult = createResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(ApplicantProfile.class);

        assertThat(createResult.getApplicants().get(0).getApplicantId()).isNotEmpty();
        assertThat(createResult).usingRecursiveComparison().ignoringFields("applicants.applicantId", "applicants.version").isEqualTo(expectedCreateResponse);

        String applicantId = createResult.getApplicants().get(0).getApplicantId();

        ApplicantProfile updateRequest = readApplicantProfileFromResource(addApplicantsOneUpdateRequest);
        updateRequest.getApplicants().get(0).setApplicantId(applicantId);
        ApplicantProfile expectedUpdateResponse = readApplicantProfileFromResource(addApplicantsOneUpdateResponse);
        expectedUpdateResponse.getApplicants().get(0).setApplicantId(applicantId);

        Response updateResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(updateRequest)
                .put(PATH_ADD_APPLICANTS);

        log.info(updateResponse.getBody().prettyPrint());

        ApplicantProfile updateResult = updateResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(ApplicantProfile.class);

        assertThat(createResult.getApplicants().get(0).getApplicantId()).isNotEmpty();
        assertThat(updateResult).usingRecursiveComparison().ignoringExpectedNullFields().isEqualTo(expectedUpdateResponse);
    }
}
