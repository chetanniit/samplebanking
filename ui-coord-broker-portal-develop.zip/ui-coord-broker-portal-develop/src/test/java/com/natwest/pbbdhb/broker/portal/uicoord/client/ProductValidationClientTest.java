package com.natwest.pbbdhb.broker.portal.uicoord.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcResponse;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class ProductValidationClientTest {

  String productValidationEndpoint = "/productValidationEndpoint";
  @Mock
  RestTemplate restTemplate;

  ProductValidationClient productValidationClient;

  ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

  @BeforeEach
  void setup() {
    productValidationClient = new ProductValidationClient(productValidationEndpoint, restTemplate,
        objectMapper);
  }

  @Test
  void validateProduct_ok() {
    ProductValidationMsvcResponse response = ProductValidationMsvcResponse.builder()
        .productCode("productCodeResponse")
        .validProduct(true)
        .jurisdiction("UK")
        .message("message")
        .build();
    ResponseEntity<ProductValidationMsvcResponse> responseEntity = ResponseEntity.ok(response);
    when(restTemplate.exchange(
        anyString(),
        any(HttpMethod.class),
        any(),
        ArgumentMatchers.<Class<ProductValidationMsvcResponse>>any())
    ).thenReturn(responseEntity);

    ProductValidationMsvcRequest request = ProductValidationMsvcRequest.builder()
        .productCode("productCodeRequest")
        .build();
    productValidationClient.validateProduct("nwb", request);

    ArgumentCaptor<HttpEntity> captor = ArgumentCaptor.forClass(HttpEntity.class);
    verify(restTemplate).exchange(
        eq(productValidationEndpoint),
        eq(HttpMethod.POST),
        captor.capture(),
        eq(ProductValidationMsvcResponse.class));
    assertThat(captor.getValue().getBody()).isEqualTo(request);
  }

  /**
   * Emulates error seen in UAT that confirms msvc-product contract is broken:
   * >> "POST /mortgages/v2/msvc-product/validate HTTP/1.1[\r][\n]"
   * >> "Content-Type: application/json[\r][\n]"
   * >> "Accept: application/json, application/*+json[\r][\n]"
   * >> "brand: nwb[\r][\n]"
   * >> "{"applicationType":"BUY_TO_LET","propertyValue":66000,"customerType":"NEW_CUSTOMER","mortgageAmount":32000,"productCode":"FO38669","productSearchDate":"03-06-2024","mortgageType":"REMORTGAGE","productType":"FIXED","repaymentType":"MIXED","productTerm":"THREE_YEAR","ltv":60,"isCashbackProduct":false,"freeLegal":true,"jurisdiction":"UK","fees":[{"code":"F45","type":"995_PRODUCT_FEE","amount":995},{"code":"FVA","type":"FREE_VALUATION","amount":0},{"code":"DRA","type":"CHAPS_FEE","amount":30}]}"
   * << "HTTP/1.1 400 Bad Request[\r][\n]"
   * << "Content-Type: application/json[\r][\n]"
   * << "{"productCode":"FO38669","validProduct":false,"message":"Validation failed, product has been expired"}[\r][\n]"
   */
  @Test
  void validateProduct_BadRequestException() {
    String statusText = "Bad Request";
    Charset charset = StandardCharsets.UTF_8;
    byte[] body = "{\"productCode\":\"FO38669\",\"validProduct\":false,\"message\":\"Validation failed, product has been expired\"}"
        .getBytes(StandardCharsets.UTF_8);
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpClientErrorException exception = HttpClientErrorException
        .create(HttpStatusCode.valueOf(400), statusText, headers, body, charset);
    when(restTemplate.exchange(
        anyString(),
        any(HttpMethod.class),
        any(),
        ArgumentMatchers.<Class<ProductValidationMsvcResponse>>any())
    ).thenThrow(exception);

    ProductValidationMsvcRequest request = ProductValidationMsvcRequest.builder()
        .productCode("productCodeRequest")
        .build();

    ProductValidationMsvcResponse response = productValidationClient
        .validateProduct("nwb", request);
    assertThat(response.getProductCode()).isEqualTo("FO38669");
    assertThat(response.getValidProduct()).isEqualTo(false);
    assertThat(response.getMessage()).isEqualTo("Validation failed, product has been expired");
  }

  @Test
  void validateProduct_restClientException() {
    RestClientResponseException exception = new RestClientResponseException("Something went wrong",
        500, "Internal Server Error", null, null, null);
    when(restTemplate.exchange(
        anyString(),
        any(HttpMethod.class),
        any(),
        ArgumentMatchers.<Class<ProductValidationMsvcResponse>>any())
    ).thenThrow(exception);

    ProductValidationMsvcRequest request = ProductValidationMsvcRequest.builder()
        .productCode("productCodeRequest")
        .build();

    RestClientResponseException capturedException = assertThrows(RestClientResponseException.class,
        () -> productValidationClient.validateProduct("nwb", request));

    assertThat(capturedException.getMessage()).isEqualTo("Something went wrong");
    assertThat(capturedException.getStatusCode().value()).isEqualTo(500);
  }

  @Test
  void validateProduct_runtimeException() {
    when(restTemplate.exchange(
        anyString(),
        any(HttpMethod.class),
        any(),
        ArgumentMatchers.<Class<ProductValidationMsvcResponse>>any())
    ).thenThrow(new RuntimeException("Oops I did it again!"));

    ProductValidationMsvcRequest request = ProductValidationMsvcRequest.builder()
        .productCode("productCodeRequest")
        .build();

    Exception capturedException = assertThrows(RuntimeException.class,
        () -> productValidationClient.validateProduct("nwb", request));

    assertThat(capturedException.getMessage()).isEqualTo("Oops I did it again!");
  }
}