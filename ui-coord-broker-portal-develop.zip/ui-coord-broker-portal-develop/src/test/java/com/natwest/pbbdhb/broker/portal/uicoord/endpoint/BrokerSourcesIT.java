package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerSourcesClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourcesAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourcesRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class BrokerSourcesIT {

    private static final String BROKER_SOURCES_SERVICE_NAME = "msvc-int-gms-product-state";
    @Value("${msvc.broker.sources.url}")
    private String brokerSourcesServiceEndpoint;

    @LocalServerPort
    private int port;

    @Autowired
    private BrokerSourcesClient brokerSourcesClient;

    @Autowired
    private TokenConfiguration tokenConfig;

    // These tests no longer work after recent security updates (RL 22/03/2023)
//    @Test
//    void brokerSourcesClientSingleResult() throws BrokerSourcesException {
//        BrokerSourcesRequestDto brokerDetails = createTestBrokerDetails();
//        BrokerSourceResultDto[] results = brokerSourcesClient.findBrokerSources(BRAND_DEFAULT, brokerDetails);
//
//        assertEquals(1, results.length);
//    }
//
//    @Test
//    void brokerSourcesClientNoResults() {
//        BrokerSourcesRequestDto brokerDetails = createTestBrokerDetailsWithNoMatches();
//
//        assertThrows(
//                BrokerSourcesException.class,
//                () -> brokerSourcesClient.findBrokerSources(BRAND_DEFAULT, brokerDetails),
//                BrokerSourcesClient.NO_MATCHING_BROKER_SOURCES
//        );
//    }
//
//    @Test
//    void brokerSourcesClientMultipleResults() {
//        BrokerSourcesRequestDto brokerDetails = createTestBrokerDetailsWithMultipleMatches();
//
//        assertThrows(
//                BrokerSourcesException.class,
//                () -> brokerSourcesClient.findBrokerSources(BRAND_DEFAULT, brokerDetails),
//                BrokerSourcesClient.MULTIPLE_MATCHING_BROKER_SOURCES
//        );
//    }

    @Test
    void brokerSourcesDirectTest() {
        RestAssured.port = 443;

        BrokerSourcesRequestDto brokerDetails = createTestBrokerDetails();

        Response brokerSourcesResponse = with()
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, BROKER_SOURCES_SERVICE_NAME))
                .contentType(APPLICATION_JSON_VALUE)
                .body(brokerDetails)
                .post(brokerSourcesServiceEndpoint);

        log.info(brokerSourcesResponse.body().asPrettyString());

        brokerSourcesResponse.then().statusCode(200);
    }

    private BrokerSourcesRequestDto createTestBrokerDetails() {
        BrokerSourcesRequestDto brokerDetails = new BrokerSourcesRequestDto();
        brokerDetails.setFirmName("Financial Resolutions Mortgage Brokers Limited");
        BrokerSourcesAddressDto address = new BrokerSourcesAddressDto();
        address.setPostcode("HP3 0HG");
        brokerDetails.setAddress(address);
        brokerDetails.setFcaReference("934986");
        brokerDetails.setNetworkInfo("Premier Mortgage Services");
        return brokerDetails;
    }

    private BrokerSourcesRequestDto createTestBrokerDetailsWithNoMatches() {
        BrokerSourcesRequestDto brokerDetails = new BrokerSourcesRequestDto();
        brokerDetails.setFirmName("no such firm");
        BrokerSourcesAddressDto address = new BrokerSourcesAddressDto();
        address.setPostcode("SS99 9XX");
        brokerDetails.setAddress(address);
        brokerDetails.setFcaReference("000000");
        brokerDetails.setNetworkInfo("no payment path");
        return brokerDetails;
    }

    private BrokerSourcesRequestDto createTestBrokerDetailsWithMultipleMatches() {
        BrokerSourcesRequestDto brokerDetails = new BrokerSourcesRequestDto();
        brokerDetails.setFirmName("Mortgage Matters Direct");
        BrokerSourcesAddressDto address = new BrokerSourcesAddressDto();
        address.setPostcode("ME2 4FX");
        brokerDetails.setAddress(address);
        brokerDetails.setFcaReference("405444");
        brokerDetails.setNetworkInfo("Arun Estates (Connells Group)");
        return brokerDetails;
    }
}
