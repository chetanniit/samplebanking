package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.updateBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_DIP_RESULT_CLEAR;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SUBMIT_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.createBrokerCaseForBuyToLetDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.createBrokerCaseForDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.createBrokerCaseForInterestOnlyDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.createBrokerCaseForPartAndPartDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
class SubmitDipIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void submitDipSucceeds() {
        BrokerCase brokerCaseWithDip = submitDip();
        assertNotNull(brokerCaseWithDip.getCaseApplication().getDecisionInPrinciple());
        assertNotNull(brokerCaseWithDip.getCaseApplication().getDecisionInPrinciple().getDateTime());
        assertEquals("/dip/Submitted", brokerCaseWithDip.getCaseApplication().getCurrentRoute());
    }

    BrokerCase submitDip() {
        BrokerCase brokerCaseForDip = createBrokerCaseForDip(tokenConfig);
        String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

        // Submit DIP
        Response submitDipResponse = with()
            .pathParam(CASE_ID_PARAM, caseId)
            .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
            .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        BrokerCase brokerCaseWithDip = submitDipResponse
            .then()
            .statusCode(200)
            .extract()
            .as(BrokerCase.class);

        return brokerCaseWithDip;
    }

    @Test
    void amendDipSucceeds() {
        String caseId = submitDip().getCaseApplication().getCaseId();

        // clear dip result
        with()
            .pathParam(CASE_ID_PARAM, caseId)
            .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
            .post(PATH_DIP_RESULT_CLEAR)
            .then().statusCode(200);

        // Submit DIP
        Response submitDipResponse = with()
            .pathParam(CASE_ID_PARAM, caseId)
            .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
            .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        BrokerCase brokerCaseWithDip = submitDipResponse
            .then()
            .statusCode(200)
            .extract()
            .as(BrokerCase.class);

        assertNotNull(brokerCaseWithDip.getCaseApplication().getDecisionInPrinciple());
        assertNotNull(brokerCaseWithDip.getCaseApplication().getDecisionInPrinciple().getDateTime());
        assertEquals("/dip/Submitted", brokerCaseWithDip.getCaseApplication().getCurrentRoute());
    }

    @Test
    void submitInterestOnlyDipSucceeds() {
        BrokerCase brokerCaseForDip = createBrokerCaseForInterestOnlyDip(tokenConfig);
        String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

        // Submit DIP
        Response submitDipResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        submitDipResponse.then().statusCode(200);
    }

    @Test
    void submitPartAndPartDipSucceeds() {
        BrokerCase brokerCaseForDip = createBrokerCaseForPartAndPartDip(tokenConfig);
        String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

        // Submit DIP
        Response submitDipResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        submitDipResponse.then().statusCode(200);
    }

    @Test
    void submitBuyToLetDipSucceeds() {
        BrokerCase brokerCaseForDip = createBrokerCaseForBuyToLetDip(tokenConfig);
        String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

        // Submit DIP
        Response submitDipResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        submitDipResponse.then().statusCode(200);
    }

    @Test
    void submitDipGives404ResponseIfCaseDoesNotExist() {
        // Submit DIP
        Response submitDipResponse = with()
                .pathParam(CASE_ID_PARAM, "CASEDOESNOTEXIST")
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        submitDipResponse.then().statusCode(404);
    }

    @Test
    void submitDipGives400Response_whenUnhandledValidationError() {
        BrokerCase brokerCaseForDip = createBrokerCaseForDip(tokenConfig);
        brokerCaseForDip.getCaseApplication().setFirstTimeBuyer(null);

        BrokerCase storedBrokerCase = updateBrokerCase(brokerCaseForDip, tokenConfig);

        String caseId = storedBrokerCase.getCaseApplication().getCaseId();

        // Submit DIP
        Response submitDipResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_DIP);

        log.info(submitDipResponse.body().asPrettyString());

        ValidationResponse validationError = submitDipResponse
                .then()
                .statusCode(400)
                .extract()
                .as(ValidationResponse.class);

        ValidationResponseDetail error = validationError.getError().get(0);
        assertEquals("DIP Submit Unhandled Validation Errors", validationError.getTitle());
        assertEquals(HttpStatus.BAD_REQUEST.value(), validationError.getStatus());
        assertEquals(HttpStatus.BAD_REQUEST.value(), error.getStatus());
        assertEquals("buyerType Buyer type cannot be null or empty", error.getMessage());
        assertEquals(ErrorCode.UNHANDLED.toString(), error.getCode());
    }

}
