package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Product;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ProductSearchTestUtil.createValidProductDto;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        ProductMapperImpl.class,
        ErcItemMapperImpl.class
})
public class ProductMapperTest {
    @Autowired
    private ProductMapper mapper;

    @Test
    void testToDtoMapping() {
        ProductDto productDto = createValidProductDto("Purchase range");
        Product product = this.mapper.toProduct(productDto);

        assertThat(product)
                .usingRecursiveComparison()
                .ignoringFields("greenMortgage", "freeValuation", "sharedEquity", "ercItems")
                .isEqualTo(productDto);

        assertThat(product.getRange()).isEqualTo("Purchase range");
        assertThat(product.getFreeValuation()).isEqualTo(true);
        assertThat(product.getGreenMortgage()).isEqualTo(false);
        assertThat(product.getSharedEquity()).isEqualTo(false);
    }

    @Test
    void testGreenMortgageMapping() {
        assertThat(this.mapper.toProduct(createValidProductDto("a green range"))
                .getGreenMortgage()).isEqualTo(true);
        assertThat(this.mapper.toProduct(createValidProductDto("GREEN"))
                .getGreenMortgage()).isEqualTo(true);
        assertThat(this.mapper.toProduct(createValidProductDto("red"))
                .getGreenMortgage()).isEqualTo(false);
    }

    @Test
    void testFreeValuationMapping() {
        ProductDto productDto = createValidProductDto("Purchase range");

        productDto.setStandardValuationFee(null);
        assertThat(this.mapper.toProduct(productDto)
                .getFreeValuation()).isEqualTo(true);

        productDto.setStandardValuationFee(BigDecimal.valueOf(0));
        assertThat(this.mapper.toProduct(productDto)
                .getFreeValuation()).isEqualTo(true);

        productDto.setStandardValuationFee(BigDecimal.valueOf(0.2));
        assertThat(this.mapper.toProduct(productDto)
                .getFreeValuation()).isEqualTo(false);
    }

    @Test
    void testSharedEquityMapping() {
        assertThat(this.mapper.toProduct(createValidProductDto("2y Shared Equity mortgages"))
                .getSharedEquity()).isEqualTo(true);
        assertThat(this.mapper.toProduct(createValidProductDto("SHARED EQUITY"))
                .getSharedEquity()).isEqualTo(true);
        assertThat(this.mapper.toProduct(createValidProductDto("SHARED"))
                .getSharedEquity()).isEqualTo(false);
    }
}
