package com.natwest.pbbdhb.broker.portal.uicoord.fma;

import com.google.gson.Gson;
import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.insertNewBrokerCaseIntoCapie;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.submitDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SUBMIT_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getFmaValidationCodeFilePath;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class FmaCompleteIT {
    // If 'singleTestCase' is set, only the test case with that name will be run.
    private static String singleTestCase;
//    private static String singleTestCase = "scenario-2";

    private static final Gson gson = new Gson();

    private TestInfo testInfo;
    private boolean passed;
    private boolean hasError;
    private String errorMessage;

    @Autowired
    private TokenConfiguration tokenConfig;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @MockBean
    private BrokerInfoClient brokerInfoClient;

    @BeforeEach
    public void setUp(TestInfo testInfo) {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;

        this.testInfo = testInfo;
        this.passed = false;
        this.hasError = false;
        this.errorMessage = null;

        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() throws IOException {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.DEFAULT_PORT;
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void testFmaSucceeds(String testCaseName, String brokerCaseJson) {
        try {
            BrokerCase brokerCase = gson.fromJson(brokerCaseJson, BrokerCase.class);

            String caseId = insertNewBrokerCaseIntoCapie(brokerCase, tokenConfig);

            submitDip(caseId, tokenConfig);

            // Submit FMA
            Response submitFmaResponse = with()
                    .pathParam(CASE_ID_PARAM, caseId)
                    .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                    .post(PATH_SUBMIT_FMA);

            log.info(submitFmaResponse.body().asPrettyString());

            submitFmaResponse.then().statusCode(anyOf(is(201), is(202)));

            this.passed = true;
        } catch (AssertionError error) {
            this.passed = false;
            this.errorMessage = error.getMessage();
            throw error;
        } catch (Throwable t) {
            this.hasError = true;
            this.errorMessage = t.getMessage();
            throw t;
        }
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("failTestCases")
    void testFmaFails(String testCaseName, String brokerCaseJson) throws IOException {
    try {
      BrokerCase brokerCase = gson.fromJson(brokerCaseJson, BrokerCase.class);

      String caseId = insertNewBrokerCaseIntoCapie(brokerCase, tokenConfig);

      submitDip(caseId, tokenConfig);
      if (testCaseName.startsWith("400") && testCaseName.contains("trading-name")) {
        BrokerInfoResponseDto brokerinfo = BrokerInfoTestUtil.brokerInfoDto();
        brokerinfo.setTradingName(null);

        when(brokerInfoClient.readBroker(any())).thenReturn(brokerinfo);
      }

      // Submit FMA
      Response submitFmaResponse = with()
          .pathParam(CASE_ID_PARAM, caseId)
          .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
          .post(PATH_SUBMIT_FMA);

      log.info(submitFmaResponse.body().asPrettyString());

      if (testCaseName.startsWith("400")){

        String expectedCode = TestUtil.getResourceText(
            new ClassPathResource(getFmaValidationCodeFilePath(testCaseName)));


        submitFmaResponse.then().statusCode(anyOf(is(400)))
            .body("title", equalTo("FMA Submit Validation Errors"))
            .body("errors", hasSize(1))
            .body("errors.code", hasItem(((expectedCode))));
      } else {
        submitFmaResponse.then().statusCode(anyOf(is(500)))
            .body("title", equalTo("FMA Submit Unhandled Validation Errors"));
      }



      this.passed = true;
    } catch (AssertionError error) {
      this.passed = false;
      this.errorMessage = error.getMessage();
      throw error;
    } catch (Throwable t) {
      this.hasError = true;
      this.errorMessage = t.getMessage();
      throw t;
    }
  }


   private static Stream<Arguments> failTestCases() throws IOException {
    if (singleTestCase != null) {
      return Stream.of(testCaseArguments(singleTestCase));
    }
    PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
    Resource[] testCaseResources = resourceResolver.getResources("classpath:fma-test-cases/broker-fail-case/*.json");
    return Arrays.stream(testCaseResources).map(JsonTestCaseUtil::testCaseNameFromResource).map(FmaCompleteIT::testFailCaseArguments);
   }

    private static Stream<Arguments> testCases() throws IOException {
        if (singleTestCase != null) {
            return Stream.of(testCaseArguments(singleTestCase));
        }
        PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
        Resource[] testCaseResources = resourceResolver.getResources("classpath:fma-test-cases/broker-case/*.json");
        return Arrays.stream(testCaseResources).map(JsonTestCaseUtil::testCaseNameFromResource).map(FmaCompleteIT::testCaseArguments);
    }

    private static Arguments testCaseArguments(String testCaseName) {
      String brokerCasePath = "fma-test-cases/broker-case";
        return Arguments.of(testCaseName, getBrokerCaseJson(testCaseName, brokerCasePath));
    }

  private static Arguments testFailCaseArguments(String testCaseName) {
    String brokerCasePath = "fma-test-cases/broker-fail-case";
    return Arguments.of(testCaseName, getBrokerCaseJson(testCaseName, brokerCasePath));
  }

    private static String getBrokerCaseJson(String testCaseName, String brokerCasePath) {
        try {

            Resource brokerCaseResource = new ClassPathResource(brokerCasePath + "/" + testCaseName + ".json");
            return getResourceText(brokerCaseResource);
        } catch (IOException ioex) {
            log.info(ioex.toString());
            return null;
        }
    }

}