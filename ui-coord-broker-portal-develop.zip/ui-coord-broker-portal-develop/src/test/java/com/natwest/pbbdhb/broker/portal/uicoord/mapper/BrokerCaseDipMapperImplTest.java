package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCaseDip;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.IncomeApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import java.util.ArrayList;
import java.util.Collections;
import org.junit.jupiter.api.Test;

class BrokerCaseDipMapperImplTest {

  @Test
  void toBrokerCaseDipClearPreviousJobDetails() {
    BrokerCaseDipMapper mapper = new BrokerCaseDipMapperImpl();

    JobDetails previousJobDetails = new JobDetails();
    previousJobDetails.setJobId("jobId");
    IncomeApplicant incomeApplicant = new IncomeApplicant();
    incomeApplicant.setPreviousJobDetails(new ArrayList<>(Collections.singletonList(previousJobDetails)));
    CaseIncome caseIncome = new CaseIncome();
    caseIncome.setApplicants(Collections.singletonList(incomeApplicant));
    BrokerCase brokerCase = new BrokerCase();
    brokerCase.setIncome(caseIncome);

    BrokerCaseDip brokerCaseDip = mapper.toBrokerCaseDip(brokerCase);

    assertNotNull(brokerCaseDip);
    assertNull(brokerCaseDip.getIncome().getApplicants().get(0).getAdditionalJobDetails());

    BrokerCase result = mapper.toBrokerCase(brokerCaseDip);
    assertNull(result.getIncome().getApplicants().get(0).getPreviousJobDetails());
  }
}