package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Fee;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.cases.dto.FeeDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidProductDetails;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {ProductDetailsMapperImpl.class})
class ProductDetailsMapperTest {

    @Autowired
    private ProductDetailsMapper productDetailsMapper;

    @Test
    void testProductDetailsRoundTripMapping() {
        ProductDetails productDetails = createValidProductDetails();
        ProductDetailsDto productDetailsDto = productDetailsMapper.toProductDetailsDto(productDetails);
        ProductDetails roundTripResult = productDetailsMapper.toProductDetails(productDetailsDto);

        assertThat(roundTripResult).usingRecursiveComparison().isEqualTo(productDetails);
    }

    @Test
    void toProductDetailsDtoMapsCorrectly() {
        ProductDetails productDetails = createValidProductDetails();
        ProductDetailsDto productDetailsDto = productDetailsMapper.toProductDetailsDto(productDetails);

        assertThat(productDetailsDto)
                .usingRecursiveComparison()
                .ignoringFields("productEndDate", "ercItems", "productName", "svr", "baseRate", "initialInterestRate",
                        "cashBackValue", "portingNotes", "fees.isPaymentMade", "fees.paidDate", "fees.feePaymentType", "fees.orderId")
                .isEqualTo(productDetails);
        assertThat(productDetailsDto.getPortingNotes()).isEqualTo(productDetails.getPortingText());
    }

    @Test
    void toProductDetailsDtoMapsFeePaymentTypeCorrectly() {
        ProductDetails productDetails = createValidProductDetails();

        List<Fee> fees = new ArrayList<>();
        Fee noPaymentTypeFee = new Fee();
        noPaymentTypeFee.setFeeCode("F45");
        noPaymentTypeFee.setType("£995_PRODUCT_FEE");
        noPaymentTypeFee.setFeeAmount(BigDecimal.valueOf(995));
        noPaymentTypeFee.setFeeAction("ADD_CAPITALISE_TO_LOAN");
        fees.add(noPaymentTypeFee);

        Fee noActionFee = new Fee();
        noActionFee.setFeeCode("FVA");
        noActionFee.setType("FREE_VALUATION");
        noActionFee.setFeeAmount(BigDecimal.ZERO);
        noActionFee.setFeeAction("NO_ACTION");
        fees.add(noActionFee);

        productDetails.setFees(fees);

        ProductDetailsDto productDetailsDto = productDetailsMapper.toProductDetailsDto(productDetails);

        FeeDto noPaymentTypeFeeDto = productDetailsDto.getFees().get(0);
        assertThat(noPaymentTypeFeeDto.getFeeAction()).isEqualTo("ADD_CAPITALISE_TO_LOAN"); // just checking we have the right fee
        assertThat(noPaymentTypeFeeDto.getFeePaymentType()).isNull();

        FeeDto noActionFeeDto = productDetailsDto.getFees().get(1);
        assertThat(noActionFeeDto.getFeeAction()).isEqualTo("NO_ACTION"); // just checking we have the right fee
        assertThat(noActionFeeDto.getFeePaymentType()).isEqualTo("CARD_PAYMENT");
    }

    @Test
    void toSalesIllustrationsSetsIsAcceptedTrue() {
        ProductDetails productDetails = createValidProductDetails();
        List<SalesIllustrationDto> salesIllustrationDtoList = productDetailsMapper.toSalesIllustrationDtoList(productDetails);

        assertThat(salesIllustrationDtoList.size()).isEqualTo(1);
        assertThat(salesIllustrationDtoList.get(0).getIsAccepted()).isTrue();
    }
}
