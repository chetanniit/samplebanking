package com.natwest.pbbdhb.broker.portal.uicoord.configuration;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.validation.annotation.Validated;

/**
 * Represents the configuration for the token issuing hosts.
 */
@TestConfiguration
@ConditionalOnProperty(prefix = "tokens", name = "enabled", havingValue = "true")
@ConfigurationProperties(prefix = "tokens")
@Data
@Validated
public class TokenConfiguration {

  @NotNull
  private HostConfig jwtIssuer;

  @NotNull
  private HostConfig accessTokenIssuer;

  @Getter
  @Setter
  public static class HostConfig {

    @NotBlank
    private String host;

    @NotNull
    @Min(0)
    private int port;
  }
}
