package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class BuyToLetValidationTest extends AbstractValidationTest<BuyToLet> {

    private static Stream<Arguments> commonBuyToLetTestCases() {
        return Stream.of(
                Arguments.of("Valid BuyToLet", (Consumer<BuyToLet>) a -> {
                }, EMPTY_SET),
                Arguments.of("BuyToLet with monthlyRentalIncome below minimum value", (Consumer<BuyToLet>) a -> a.setMonthlyRentalIncome(0L), singleton(create("monthlyRentalIncome", "must be greater than or equal to 1"))),
                Arguments.of("BuyToLet with monthlyRentalIncome above maximum value", (Consumer<BuyToLet>) a -> a.setMonthlyRentalIncome(100000000L), singleton(create("monthlyRentalIncome", "must be less than or equal to 99999999"))),
                Arguments.of("BuyToLet with icrTaxRate with bad enum value", (Consumer<BuyToLet>) a -> a.setIcrTaxRate("BAD_VALUE"), singleton(create("icrTaxRate", "must be any of: HIGH, LOW"))),
                Arguments.of("BuyToLet with lettingAgentCost below minimum value", (Consumer<BuyToLet>) a -> a.setLettingAgentCost(0L), singleton(create("lettingAgentCost", "must be greater than or equal to 1"))),
                Arguments.of("BuyToLet with lettingAgentCost above maximum value", (Consumer<BuyToLet>) a -> a.setLettingAgentCost(100000000L), singleton(create("lettingAgentCost", "must be less than or equal to 99999999"))),
                Arguments.of("PortfolioLandlord with numberOfYearsAsLandlord below minimum value", (Consumer<BuyToLet>) a -> a.getPortfolioLandlord().setNumberOfYearsAsLandlord(-1), singleton(create("portfolioLandlord.numberOfYearsAsLandlord", "must be greater than or equal to 0"))),
                Arguments.of("PortfolioLandlord with numberOfYearsAsLandlord above maximum value", (Consumer<BuyToLet>) a -> a.getPortfolioLandlord().setNumberOfYearsAsLandlord(100), singleton(create("portfolioLandlord.numberOfYearsAsLandlord", "must be less than or equal to 99"))),
                Arguments.of("PortfolioLandlord with extendNotes is too small", (Consumer<BuyToLet>) a -> a.getPortfolioLandlord().setExtendNotes("Abcd"), singleton(create("portfolioLandlord.extendNotes", "size must be between 5 and 300"))),
                Arguments.of("PortfolioLandlord with extendNotes is too long", (Consumer<BuyToLet>) a -> a.getPortfolioLandlord().setExtendNotes("asdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklalaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjkl"),
                        singleton(create("portfolioLandlord.extendNotes", "size must be between 5 and 300"))),
                Arguments.of("PortfolioLandlord with sellNotes is too small", (Consumer<BuyToLet>) a -> a.getPortfolioLandlord().setSellNotes("Abcd"), singleton(create("portfolioLandlord.sellNotes", "size must be between 5 and 300"))),
                Arguments.of("PortfolioLandlord with sellNotes is too long", (Consumer<BuyToLet>) a -> a.getPortfolioLandlord().setSellNotes("asdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklalaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjklaasdfghjkl"),
                        singleton(create("portfolioLandlord.sellNotes", "size must be between 5 and 300"))),
                Arguments.of("BuyToLet with isRentingToImmediateFamilyMember set to true", (Consumer<BuyToLet>) a -> a.setIsRentingToImmediateFamilyMember(true), singleton(create("isRentingToImmediateFamilyMember", "must be false"))),
                Arguments.of("BuyToLet with isAssuredShortHoldOrShortAssured set to false", (Consumer<BuyToLet>) a -> a.setIsAssuredShortHoldOrShortAssured(false), singleton(create("isAssuredShortHoldOrShortAssured", "must be true"))),
                Arguments.of("BuyToLet with isNotSelectiveLicenceOrHMO set to false", (Consumer<BuyToLet>) a -> a.setIsNotSelectiveLicenceOrHMO(false), singleton(create("isNotSelectiveLicenceOrHMO", "must be true"))),
                Arguments.of("BuyToLet with isForInvestment set to false", (Consumer<BuyToLet>) a -> a.setIsForInvestment(false), singleton(create("isForInvestment", "must be true")))
                 );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("commonBuyToLetTestCases")
    public void testBuyToLetValidations(String testDescription, Consumer<BuyToLet> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidBuyToLet, mutator, expectedErrorMessages);
    }

}
