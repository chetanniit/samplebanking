package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_5_OR_6_DIGITS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_8_DIGITS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class BankDetailsValidationTest extends AbstractValidationTest<BankDetails> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid bank details", (Consumer<BankDetails>) a -> {}, EMPTY_SET),
                Arguments.of("Bank details with null dateOpened", (Consumer<BankDetails>) a -> a.setDateOpened(null), singleton(create("dateOpened", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Bank details with invalid date format for dateOpened", (Consumer<BankDetails>) a -> a.setDateOpened("12-12-2001"), singleton(create("dateOpened", "must be a date in the past in format 'yyyy-MM-dd'"))),
                Arguments.of("Bank details with null bankName", (Consumer<BankDetails>) a -> a.setBankName(null), singleton(create("bankName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Bank details with null accountName", (Consumer<BankDetails>) a -> a.setAccountName(null), singleton(create("accountName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Bank details with null debitCard", (Consumer<BankDetails>) a -> a.setDebitCard(null), singleton(create("debitCard", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Bank details with null sortCode", (Consumer<BankDetails>) a -> a.setSortCode(null), singleton(create("sortCode", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Bank details with sort code too short", (Consumer<BankDetails>) a -> a.setSortCode("1234"), singleton(create("sortCode", MUST_BE_5_OR_6_DIGITS))),
                Arguments.of("Bank details with sort code too long", (Consumer<BankDetails>) a -> a.setSortCode("1234567"), singleton(create("sortCode", MUST_BE_5_OR_6_DIGITS))),
                Arguments.of("Bank details with non-numeric sort code", (Consumer<BankDetails>) a -> a.setSortCode("ABCDEF"), singleton(create("sortCode", MUST_BE_5_OR_6_DIGITS))),
                Arguments.of("Bank details with null accountNumber", (Consumer<BankDetails>) a -> a.setAccountNumber(null), singleton(create("accountNumber", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Bank details with sort code too short", (Consumer<BankDetails>) a -> a.setAccountNumber("1234567"), singleton(create("accountNumber", MUST_BE_8_DIGITS))),
                Arguments.of("Bank details with sort code too long", (Consumer<BankDetails>) a -> a.setAccountNumber("123456789"), singleton(create("accountNumber", MUST_BE_8_DIGITS))),
                Arguments.of("Bank details with non-numeric sort code", (Consumer<BankDetails>) a -> a.setAccountNumber("ABCDEFGH"), singleton(create("accountNumber", MUST_BE_8_DIGITS)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testBankDetailsValidations(String testDescription, Consumer<BankDetails> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, ApplicantTestUtil::createValidBankDetails, mutator, expectedErrorMessages);
    }
}
