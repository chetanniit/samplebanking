package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction;
import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.ExpenseTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.PropertyDetailsTestUtil;
import com.natwest.pbbdhb.cases.dto.BrokerDetailsDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.mapper.fma.FmaAdditionalBorrowingMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaBrokerMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaBuyToLetMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaDepositMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaDirectDebitDetailsMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaFeeMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaInterestOnlyMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaMortgageMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaOtherPropertyMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaProductDetailsMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaPropertyDetailsMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaRepaymentDetailMapperImpl;
import com.natwest.pbbdhb.mapper.fma.FmaServiceLevelMapperImpl;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import javax.enterprise.inject.Stereotype;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    FmaApplicationMapper.class,
    CapieClonerMapperImpl.class,
    CaseExpenseMapperImpl.class,
    ExpenseTransactionMapperImpl.class,
    FmaPropertyDetailsMapperImpl.class,
    FmaDirectDebitDetailsMapperImpl.class,
    FmaMortgageMapperImpl.class,
    FmaDepositMapperImpl.class,
    FmaAdditionalBorrowingMapperImpl.class,
    FmaProductDetailsMapperImpl.class,
    FmaFeeMapperImpl.class,
    FmaInterestOnlyMapperImpl.class,
    FmaRepaymentDetailMapperImpl.class,
    FmaOtherPropertyMapperImpl.class,
    FmaBuyToLetMapperImpl.class,
    FmaBrokerMapperImpl.class,
    FmaServiceLevelMapperImpl.class
})
class FmaApplicationMapperTest {

  private static final String BRAND = "brand";
  private static final String CHANGED = "changed";

  @Autowired
  private CaseExpenseMapperImpl caseExpenseMapper;

  @Autowired
  FmaApplicationMapper fmaApplicationMapper;

  @Test
  void toFmaApplication() {
    String brand = BRAND;
    CaseApplicationDto caseApplicationDto = CaseTestUtil.createValidCaseApplicationDto();
    List<ApplicantDto> applicantDtoList = Arrays.asList(ApplicantTestUtil.createValidApplicantDto());
    PropertyDetailsDto propertyDetailsDto = PropertyDetailsTestUtil.createValidPropertyDetailsDto();
    String applicantId = applicantDtoList.get(0).getApplicantId();
    ValidatedCaseIncomeDto validatedCaseIncomeDto = IncomeTestUtil.createValidatedCaseIncomeDto(applicantId);
    ValidatedCaseExpenseDto validatedCaseExpenseDto = caseExpenseMapper.caseExpenseToValidatedExpenseIncomeDto(
        ExpenseTestUtil.createValidCaseExpenseDto(applicantId)
    );

    caseApplicationDto.getBroker().setDetails(new BrokerDetailsDto());
    caseApplicationDto.getBroker().getDetails().setId(111);
    caseApplicationDto.getBroker().getDetails().setNetworkId(222);

    Application actual = fmaApplicationMapper.toFmaApplication(
        brand,
        caseApplicationDto,
        applicantDtoList,
        propertyDetailsDto,
        validatedCaseIncomeDto,
        validatedCaseExpenseDto);
    // actual values should be a deep copy and not use the same reference to the same objects
    actual.getCaseApplication().setChannel(CHANGED);
    assertThat(actual.getCaseApplication().getChannel()).isEqualTo(CHANGED);
    assertThat(caseApplicationDto.getChannel()).isNotEqualTo(CHANGED);

    actual.getApplicants().get(0).getPersonalDetails().setLastName(CHANGED);
    assertThat(actual.getApplicants().get(0).getPersonalDetails().getLastName()).isEqualTo(CHANGED);
    assertThat(applicantDtoList.get(0).getPersonalDetails().getLastName()).isNotEqualTo(CHANGED);

    actual.getCaseApplication().getBroker().getDetails().setId(666);
    assertThat(actual.getCaseApplication().getBroker().getDetails().getId()).isEqualTo(666);
    assertThat(caseApplicationDto.getBroker().getDetails().getId()).isNotEqualTo(666);

    actual.getCaseApplication().getBroker().getDetails().setNetworkId(666);
    assertThat(actual.getCaseApplication().getBroker().getDetails().getNetworkId()).isEqualTo(666);
    assertThat(caseApplicationDto.getBroker().getDetails().getNetworkId()).isNotEqualTo(666);
  }

  @ParameterizedTest
  @CsvSource({"1.2,1.20", "11.2,11.20", "11,11", "1.20,1.20", "11.20,11.20", "1.23,1.23", "1.234,1.234"})
  void toFmaApplication_fixesDecimalPlace(String input, String expected) {
    CaseApplicationDto caseApplicationDto = CaseTestUtil.createValidCaseApplicationDto();
    caseApplicationDto.setCurrencyExchangeRate(new BigDecimal(input));
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, caseApplicationDto, null, null, null, null);
    assertThat(actual.getCaseApplication().getCurrencyExchangeRate().toString()).isEqualTo(expected);
  }

  @Test
  void fixConsolidationAmountGiven0SetsNull() {
    ValidatedCaseExpenseDto caseExpenseDto = ExpenseTestUtil.createValidatedCaseExpenseDto(new ArrayList<>(List.of("TestApplicant")));
    caseExpenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").setConsolidationAmount(new BigDecimal(0));
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, null, null, null, null, caseExpenseDto);
    assertThat(actual.getExpenditure().getApplicants().get(0).getTransactions().get("loantransaction1").getConsolidationAmount()).isNull();
  }

  @Test
  void fixConsolidationAmountGivenNegativeIntegerValueSetsNull() {
    ValidatedCaseExpenseDto caseExpenseDto = ExpenseTestUtil.createValidatedCaseExpenseDto(new ArrayList<>(List.of("TestApplicant")));
    caseExpenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").setConsolidationAmount(new BigDecimal(-8));
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, null, null, null, null, caseExpenseDto);
    assertThat(actual.getExpenditure().getApplicants().get(0).getTransactions().get("loantransaction1").getConsolidationAmount()).isNull();
  }

  @Test
  void fixConsolidationAmountGivenNegativeDoubleValueSetsNull() {
    ValidatedCaseExpenseDto caseExpenseDto = ExpenseTestUtil.createValidatedCaseExpenseDto(new ArrayList<>(List.of("TestApplicant")));
    caseExpenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").setConsolidationAmount(new BigDecimal(-7.8));
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, null, null, null, null, caseExpenseDto);
    assertThat(actual.getExpenditure().getApplicants().get(0).getTransactions().get("loantransaction1").getConsolidationAmount()).isNull();
  }

  @Test
  void fixConsolidationAmountGivenNullStaysNull() {
    ValidatedCaseExpenseDto caseExpenseDto = ExpenseTestUtil.createValidatedCaseExpenseDto(new ArrayList<>(List.of("TestApplicant")));
    caseExpenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").setConsolidationAmount(null);
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, null, null, null, null, caseExpenseDto);
    assertThat(actual.getExpenditure().getApplicants().get(0).getTransactions().get("loantransaction1").getConsolidationAmount()).isNull();
  }

  @Test
  void fixConsolidationAmountGivenPositiveIntegerValueStaysTheSame() {
    ValidatedCaseExpenseDto caseExpenseDto = ExpenseTestUtil.createValidatedCaseExpenseDto(new ArrayList<>(List.of("TestApplicant")));
    caseExpenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").setConsolidationAmount(new BigDecimal("8"));
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, null, null, null, null, caseExpenseDto);
    assertThat(actual.getExpenditure().getApplicants().get(0).getTransactions().get("loantransaction1").getConsolidationAmount().toString()).isEqualTo("8");
  }

  @Test
  void fixConsolidationAmountGivenPositiveDoubleValueStaysTheSame() {
    ValidatedCaseExpenseDto caseExpenseDto = ExpenseTestUtil.createValidatedCaseExpenseDto(new ArrayList<>(List.of("TestApplicant")));
    caseExpenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").setConsolidationAmount(new BigDecimal("3.9"));
    Application actual = fmaApplicationMapper.toFmaApplication(BRAND, null, null, null, null, caseExpenseDto);
    assertThat(actual.getExpenditure().getApplicants().get(0).getTransactions().get("loantransaction1").getConsolidationAmount().toString()).isEqualTo("3.9");
  }
}