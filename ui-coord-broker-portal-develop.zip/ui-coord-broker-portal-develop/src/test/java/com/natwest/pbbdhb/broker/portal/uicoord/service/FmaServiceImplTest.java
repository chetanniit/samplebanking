package com.natwest.pbbdhb.broker.portal.uicoord.service;

import static com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerSourcesClient.NO_MATCHING_BROKER_SOURCES;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_STEP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_DIP_EXPIRED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_FMA_ALREADY_SUBMITTED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_BROKER_TRADING_NAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_CREDIT_CARD_CONSOLIDATED_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_CREDIT_CARD_OUTSTANDING_BALANCE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_LOAN_CONSOLIDATED_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_LOAN_OUTSTANDING_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_DIP_RESULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DataUtils.toDataObject;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.DIP_RESULT_DATE_TIME_FORMATTER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerSourcesClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerSourcesException;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ExpenseClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.FmaClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.client.IncomeClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.PropertyClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourceResultDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourcesRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.CaseJourneyDataDto;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaUnhandledValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.InvalidCaseStateException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.CaseApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.FmaApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.LoanPurpose;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty.OwnershipType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty.PropertyUsage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.AddressDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.FirmDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.StubUserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.FmaServiceImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.system.Clock;
import com.natwest.pbbdhb.cases.dto.BrokerDetailsDto;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.BuyToLetDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.cases.dto.EstateAgentDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import com.natwest.pbbdhb.cases.dto.OtherPropertyDto;
import com.natwest.pbbdhb.cases.dto.OtherPropertyDto.OtherPropertyDtoBuilder;
import com.natwest.pbbdhb.cases.dto.PortfolioLandlordDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseApplicantDto;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.ResponseData;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpServerErrorException;


@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = {StubUserClaimsProvider.class, FmaServiceImplTest.StoppedClock.class})
@Slf4j
public class FmaServiceImplTest {

  private static final Integer PAYMENT_PATH_ID = 123456789;
  private static final String PAYMENT_PATH_NAME = "PAYMENT PATH NAME";

  private static final Integer NO_MATCH_PAYMENT_PATH_ID = 988289;

  private static final String SOURCE_1_ID = "123";
  private static final String SOURCE_2_ID = "55555";
  private static final Integer DEFAULT_SOURCE_ID = 1234;
  public static final String FIRM_NAME = "Acme Brokers";
  public static final String FCA_NUMBER = "FCA01";
  public static final String TRADING_NAME = "Trading Broker";
  public static final String POSTCODE = "EH6 5BC";


  @Mock
    private UserClaimsProvider mockUserClaimsProvider;

    @Mock
    private BrokerInfoService mockBrokerInfoService;

    @Mock
    private BrokerSourcesClient mockBrokerSourcesClient;

    @Mock
    private AccessPermissionChecker mockAccessPermissionChecker;

    @Mock
    private CaseClientNapoli mockCaseClient;

    @Mock
    private ApplicantClientNapoli mockApplicantClient;

    @Mock
    private PropertyClientNapoli mockPropertyClient;

    @Mock
    private IncomeClient mockIncomeClient;

    @Mock
    private ExpenseClient mockExpenseClient;

    @Mock
    private FmaClient mockFmaClient;

    @Mock
    private FmaApplicationMapper mockFmaApplicationMapper;

    @Mock
    private CaseApplicationMapper mockCaseApplicationMapper;

    @InjectMocks
    private FmaServiceImpl fmaService;

    @Captor
    ArgumentCaptor<BrokerSourcesRequestDto> brokerSourcesRequestDtoArgumentCaptor;


  @Nested
  class UpdateBrokerWithGmsIdsTests{

    @Test
    void findBrokerSourcesNotCalledWhenBrokerIsNull() throws FmaIntegrationException, BrokerSourcesException {
        fmaService.updateBrokerWithGmsIds(null, null, BRAND_DEFAULT);
        verify(mockBrokerSourcesClient, never()).findBrokerSources(eq(BRAND_DEFAULT), any(BrokerSourcesRequestDto.class));
    }

    @Test
    void brokerSourcesClientCalledWhenUpdatingBrokerWithGmsIds() throws BrokerSourcesException {
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerSourceResultDto brokerSourceResult = new BrokerSourceResultDto();
      brokerSourceResult.setSource1(SOURCE_1_ID);
      brokerSourceResult.setSource2(SOURCE_2_ID);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenReturn(
          new BrokerSourceResultDto[]{brokerSourceResult}
      );

      BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);
      fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT);

      verify(mockBrokerSourcesClient).findBrokerSources(eq(BRAND_DEFAULT), any(BrokerSourcesRequestDto.class));
      assertEquals(Integer.valueOf(SOURCE_2_ID), broker.getDetails().getNetworkId());
      assertEquals(Integer.valueOf(SOURCE_1_ID), broker.getDetails().getId());

    }

    @Test
    void callsBrokerSourcesForBrokerNetworkIdMatchingPaymentPathInformation()  throws BrokerSourcesException {

      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerSourceResultDto brokerSourceResult = new BrokerSourceResultDto();
      brokerSourceResult.setSource1(SOURCE_1_ID);
      brokerSourceResult.setSource2(SOURCE_2_ID);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenReturn(
          new BrokerSourceResultDto[]{brokerSourceResult}
      );

      BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);
      fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT);

      verify(mockBrokerSourcesClient).findBrokerSources(eq(BRAND_DEFAULT), brokerSourcesRequestDtoArgumentCaptor.capture());

      BrokerSourcesRequestDto requestDto = brokerSourcesRequestDtoArgumentCaptor.getValue();

      assertEquals(PAYMENT_PATH_NAME, requestDto.getNetworkInfo());
      assertEquals(TRADING_NAME, requestDto.getFirmName());
      assertEquals(FCA_NUMBER, requestDto.getFcaReference());
      assertEquals(POSTCODE, requestDto.getAddress().getPostcode());
    }


    @Test
    void exceptionThrownWhenCallBrokerSourcesAndNoMatchingPaymentPathInformationFound()  {

      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerDto broker =  createBrokerDto(NO_MATCH_PAYMENT_PATH_ID);

      FmaValidationException exception = assertThrows(FmaValidationException.class, () -> fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT));
      assertEquals("Selected Broker Payment Path is invalid.",exception.getMessage());
      assertEquals(ErrorCode.INVALID_PAYMENT_PATH,exception.getCode());

      verifyNoInteractions(mockBrokerSourcesClient);

    }

    @Test
    void exceptionThrownWhenCallBrokerSourcesWithoutPaymentPathId()  throws BrokerSourcesException {

      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      BrokerDto broker = new BrokerDto();

      FmaValidationException exception = assertThrows(FmaValidationException.class, () -> fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT));
      assertEquals("Broker Payment Path is missing.",exception.getMessage());
      assertEquals(ErrorCode.INVALID_PAYMENT_PATH,exception.getCode());

      broker.setDetails(new BrokerDetailsDto());
      exception = assertThrows(FmaValidationException.class, () -> fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT));
      assertEquals("Broker Payment Path is missing.",exception.getMessage());
      assertEquals(ErrorCode.INVALID_PAYMENT_PATH,exception.getCode());

      verifyNoInteractions(mockBrokerInfoService);
      verifyNoInteractions(mockBrokerSourcesClient);

    }

    @Test
    void exceptionThrownWhenCallBrokerSourcesWithoutTradingName()  throws BrokerSourcesException {

      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      brokerPrincipal.getFirmDetails().setTradingName(null);

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      FmaValidationException exception = assertThrows(FmaValidationException.class, () -> fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT));
      assertEquals(MSG_INVALID_BROKER_TRADING_NAME,exception.getMessage());
      assertEquals(ErrorCode.INVALID_BROKER_TRADING_NAME,exception.getCode());

      verifyNoInteractions(mockFmaClient);

    }

    @Test
    void exceptionThrownAndGMSIdsNotUpdatedWhenBrokerSourcesClientThrowsUnhandledException()
        throws BrokerSourcesException {
      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();
      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);
      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

      BrokerDto broker =  createBrokerDto(PAYMENT_PATH_ID);

      assertThrows(HttpServerErrorException.class, () -> fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT));

      assertNull(broker.getDetails().getId());
      assertEquals(PAYMENT_PATH_ID, broker.getDetails().getNetworkId());
    }


    @Test
    void defaultsBrokerIdIfNoMatchingBrokerSourcesFound()
        throws BrokerSourcesException, FmaIntegrationException {
      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);
      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenThrow(
          new BrokerSourcesException(NO_MATCHING_BROKER_SOURCES));

        BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);
        fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT);

      assertEquals(DEFAULT_SOURCE_ID, broker.getDetails().getId());
      assertNull(broker.getDetails().getNetworkId());
    }


    @Test
    void defaultsBrokerIdIfReturnedSourceValueIsNull() throws BrokerSourcesException, FmaIntegrationException {
      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);
      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenReturn(
          new BrokerSourceResultDto[]{new BrokerSourceResultDto()});

      BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);

      fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT);

      assertEquals(DEFAULT_SOURCE_ID, broker.getDetails().getId());
      assertNull(broker.getDetails().getNetworkId());
    }

    @Test
    void defaultIfMultipleMatchingBrokerSourcesFound()
        throws BrokerSourcesException, FmaIntegrationException {
      ReflectionTestUtils.setField(fmaService, "defaultSource1Id", DEFAULT_SOURCE_ID);
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any()))
          .thenReturn(new BrokerSourceResultDto[]{
              new BrokerSourceResultDto(),
              new BrokerSourceResultDto()
          });

      BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);

      fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT);
      assertEquals(DEFAULT_SOURCE_ID, broker.getDetails().getId());
      assertNull(broker.getDetails().getNetworkId());
    }

    @Test
    void brokerSourcesResultUsedForBrokerIdAndNetworkId() throws BrokerSourcesException {
      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().caseId(TEST_CASE_ID).build();

      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerSourceResultDto brokerSourceResult = new BrokerSourceResultDto();
      brokerSourceResult.setSource1(SOURCE_1_ID);
      brokerSourceResult.setSource2(SOURCE_2_ID);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any()))
          .thenReturn(new BrokerSourceResultDto[]{brokerSourceResult});

      BrokerDto broker = createBrokerDto(PAYMENT_PATH_ID);
      fmaService.updateBrokerWithGmsIds(caseApplicationDto, broker, BRAND_DEFAULT);

      assertEquals(Integer.valueOf(SOURCE_1_ID), broker.getDetails().getId());
      assertEquals(Integer.valueOf(SOURCE_2_ID), broker.getDetails().getNetworkId());
    }



  }

  private BrokerDto createBrokerDto(Integer networkId) {
    BrokerDto broker = new BrokerDto();
    broker.setDetails(BrokerDetailsDto.builder().networkId(networkId).build());
    return broker;
  }

  @Nested
  class SubmitFmaTests{


    @Test
    void updateBrokerCaseThrowsPermissionDeniedIfUserIsNotOwner() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(false);

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () -> fmaService.submitFma("brand", "caseId"));

        assertEquals(MSG_NO_UPDATE_CASE_PERMISSION, ex.getMessage());
    }

    // NOTE: It would be good to add a test to check cin and gmsCustomerId are getting updated for each applicant.

    @Test
    void successfulSubmitFmaUsesCloneWithGMSDataInSubmitToFMA() throws FmaIntegrationException, BrokerSourcesException {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      // case validity checks require a CaseApplicationDto with an unexpired DIP result
      CaseApplicationDto originalCaseWithDipResult = getCaseWithDipResult();
      CaseApplicationDto clonedCaseWithDipResult = getCaseWithDipResult();
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(originalCaseWithDipResult);
      ArgumentCaptor<CaseApplicationDto> caseApplicationDtoCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
      when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), caseApplicationDtoCaptor.capture())).thenAnswer(i -> { CaseApplicationDto sentToSave = i.getArgument(1);
      CaseApplicationDto newlySaved = getCaseWithDipResult();
        newlySaved.setJourneyData(new HashMap<>(sentToSave.getJourneyData()));
        newlySaved.setBroker(BrokerDto.builder().details(
            BrokerDetailsDto.builder().networkId(sentToSave.getBroker().getDetails().getNetworkId())
                .id(sentToSave.getBroker().getDetails().getId()).
            build()).build());
        return newlySaved;
      });  //return the same case application

      Application clonedApplication = Application.builder()
          .caseApplication(clonedCaseWithDipResult)
          .applicants(new ArrayList<>())
          .income(new ValidatedCaseIncomeDto())
          .expenditure(new ValidatedCaseExpenseDto())
          .build();
       when(mockFmaApplicationMapper.toFmaApplication(any(), any(), any(), any(), any(), any())).thenReturn(clonedApplication);

      FullMortgageApplicationExtendedResponse fakeFmaResponse = new FullMortgageApplicationExtendedResponse();
      fakeFmaResponse.setData(ResponseData.builder().build());

      ArgumentCaptor<Application> applicationSubmittedToFmaCaptor = ArgumentCaptor.forClass(Application.class);
      when(mockFmaClient.submitFma(applicationSubmittedToFmaCaptor.capture())).thenReturn(fakeFmaResponse);

      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerSourceResultDto brokerSourceResult = new BrokerSourceResultDto();
      brokerSourceResult.setSource1(SOURCE_1_ID);
      brokerSourceResult.setSource2(SOURCE_2_ID);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenReturn(
          new BrokerSourceResultDto[]{brokerSourceResult}
      );

      //Method under Test
      fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID);

      //Verify Capie Calls
      verify(mockCaseClient, times(1)).updateCase(eq(BRAND_DEFAULT), any());

      List<CaseApplicationDto> capturedCapieApplicationUpdates = caseApplicationDtoCaptor.getAllValues();
      assertEquals(1, capturedCapieApplicationUpdates.size());

      //Capie Case update before submit
      assertNotSame(originalCaseWithDipResult, capturedCapieApplicationUpdates.get(0));
      assertSame(clonedCaseWithDipResult,capturedCapieApplicationUpdates.get(0) );
      assertEquals(SOURCE_2_ID, capturedCapieApplicationUpdates.get(0).getBroker().getDetails().getNetworkId().toString());
      assertEquals(SOURCE_1_ID, capturedCapieApplicationUpdates.get(0).getBroker().getDetails().getId().toString());
      CaseJourneyDataDto journeyDataDto = toDataObject(capturedCapieApplicationUpdates.get(0).getJourneyData(), CaseJourneyDataDto.class);
      assertTrue((boolean) capturedCapieApplicationUpdates.get(0).getJourneyData().get(CASE_JOURNEY_DATA_FMA_SUBMITTED));
      assertEquals(JourneyStep.FMA_ON_SUBMIT.toString(), capturedCapieApplicationUpdates.get(0).getJourneyData().get(CASE_JOURNEY_DATA_STEP).toString());
      assertEquals(JourneyStep.FMA_ON_SUBMIT, journeyDataDto.getStep());

      //Verify that the correct application data is being sent to FMA with
      List<Application> applicationsSubmittedToFma = applicationSubmittedToFmaCaptor.getAllValues();
      assertEquals(1, applicationsSubmittedToFma.size());
      BrokerDto broker = applicationsSubmittedToFma.get(0).getCaseApplication().getBroker();
      assertEquals(SOURCE_2_ID, broker.getDetails().getNetworkId().toString());
      assertEquals(SOURCE_1_ID, broker.getDetails().getId().toString());

    }


    @Test
    void knownValidationFailedSubmitFmaReturnsCapieToOriginalStateAndThrowsValidationException() throws FmaIntegrationException, BrokerSourcesException {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      // case validity checks require a CaseApplicationDto with an unexpired DIP result
      CaseApplicationDto originalCaseWithDipResult = getCaseWithDipResult();
      CaseApplicationDto clonedCaseWithDipResult = getCaseWithDipResult();
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(originalCaseWithDipResult);
      ArgumentCaptor<CaseApplicationDto> caseApplicationDtoCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
      when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), caseApplicationDtoCaptor.capture())).thenAnswer(i -> { CaseApplicationDto sentToSave = i.getArgument(1);
        CaseApplicationDto newlySaved = getCaseWithDipResult();
        newlySaved.setJourneyData(new HashMap<>(sentToSave.getJourneyData()));
        newlySaved.setBroker(BrokerDto.builder().details(
            BrokerDetailsDto.builder().networkId(sentToSave.getBroker().getDetails().getNetworkId())
                .id(sentToSave.getBroker().getDetails().getId()).
                build()).build());
        return newlySaved;
      });  //return the same case application


      Application clonedApplication = Application.builder()
          .caseApplication(clonedCaseWithDipResult)
          .applicants(new ArrayList<>())
          .income(new ValidatedCaseIncomeDto())
          .expenditure(new ValidatedCaseExpenseDto())
          .build();
      when(mockFmaApplicationMapper.toFmaApplication(any(), any(), any(), any(), any(), any())).thenReturn(clonedApplication);

      FullMortgageApplicationExtendedResponse fakeFmaResponse = new FullMortgageApplicationExtendedResponse();
      fakeFmaResponse.setData(ResponseData.builder().build());

      ArgumentCaptor<Application> applicationSubmittedToFmaCaptor = ArgumentCaptor.forClass(Application.class);
      when(mockFmaClient.submitFma(applicationSubmittedToFmaCaptor.capture())).thenThrow(new FmaValidationException(ErrorCode.INVALID_PAYMENT_PATH, "KNOWN VALIDATION"));

      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerSourceResultDto brokerSourceResult = new BrokerSourceResultDto();
      brokerSourceResult.setSource1(SOURCE_1_ID);
      brokerSourceResult.setSource2(SOURCE_2_ID);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenReturn(
          new BrokerSourceResultDto[]{brokerSourceResult}
      );

      //Method under Test
      FmaValidationException ex = assertThrows(
          FmaValidationException.class,
          () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));
      assertEquals(ErrorCode.INVALID_PAYMENT_PATH, ex.getCode());

      //Verify Capie Calls
      verify(mockCaseClient, times(2)).updateCase(eq(BRAND_DEFAULT), any());

      List<CaseApplicationDto> capturedCapieApplicationUpdates = caseApplicationDtoCaptor.getAllValues();
      assertEquals(2, capturedCapieApplicationUpdates.size());

      //Capie Case update before submit
      assertNotSame(originalCaseWithDipResult, capturedCapieApplicationUpdates.get(0));
      assertSame(clonedCaseWithDipResult,capturedCapieApplicationUpdates.get(0) );
      assertEquals(SOURCE_2_ID, capturedCapieApplicationUpdates.get(0).getBroker().getDetails().getNetworkId().toString());
      assertEquals(SOURCE_1_ID, capturedCapieApplicationUpdates.get(0).getBroker().getDetails().getId().toString());
      CaseJourneyDataDto journeyDataDto = toDataObject(capturedCapieApplicationUpdates.get(0).getJourneyData(), CaseJourneyDataDto.class);
      assertTrue((boolean) capturedCapieApplicationUpdates.get(0).getJourneyData().get(CASE_JOURNEY_DATA_FMA_SUBMITTED));
      assertEquals(JourneyStep.FMA_ON_SUBMIT.toString(), capturedCapieApplicationUpdates.get(0).getJourneyData().get(CASE_JOURNEY_DATA_STEP).toString());
      assertEquals(JourneyStep.FMA_ON_SUBMIT, journeyDataDto.getStep());

      //Capie Case update after submit is back to original values
      assertSame(originalCaseWithDipResult, capturedCapieApplicationUpdates.get(1));
      assertNotSame(clonedCaseWithDipResult,capturedCapieApplicationUpdates.get(1) );
      assertEquals(PAYMENT_PATH_ID, capturedCapieApplicationUpdates.get(1).getBroker().getDetails().getNetworkId());
      assertNull(capturedCapieApplicationUpdates.get(1).getBroker().getDetails().getId());
      journeyDataDto = toDataObject(capturedCapieApplicationUpdates.get(1).getJourneyData(), CaseJourneyDataDto.class);
      assertFalse(capturedCapieApplicationUpdates.get(1).getJourneyData().containsKey(CASE_JOURNEY_DATA_FMA_SUBMITTED));
      assertEquals(JourneyStep.FMA_POST_SUBMIT_RESET.toString(),capturedCapieApplicationUpdates.get(1).getJourneyData().get(CASE_JOURNEY_DATA_STEP).toString());
      assertEquals(JourneyStep.FMA_POST_SUBMIT_RESET, journeyDataDto.getStep());

      //Verify that the application data sent to FMA contains with GMS Network info
      List<Application> applicationsSubmittedToFma = applicationSubmittedToFmaCaptor.getAllValues();
      assertEquals(1, applicationsSubmittedToFma.size());
      BrokerDto broker = applicationsSubmittedToFma.get(0).getCaseApplication().getBroker();
      assertEquals(SOURCE_2_ID, broker.getDetails().getNetworkId().toString());
      assertEquals(SOURCE_1_ID, broker.getDetails().getId().toString());


    }


    @Test
    void unknownValidationFailedSubmitFmaReturnsCapieToOriginalStateAndThrowsIntegrationException() throws FmaIntegrationException, BrokerSourcesException {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      // case validity checks require a CaseApplicationDto with an unexpired DIP result
      CaseApplicationDto originalCaseWithDipResult = getCaseWithDipResult();
      CaseApplicationDto clonedCaseWithDipResult = getCaseWithDipResult();
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(originalCaseWithDipResult);
      ArgumentCaptor<CaseApplicationDto> caseApplicationDtoCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
      when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), caseApplicationDtoCaptor.capture())).thenAnswer(i -> { CaseApplicationDto sentToSave = i.getArgument(1);
        CaseApplicationDto newlySaved = getCaseWithDipResult();
        newlySaved.setJourneyData(new HashMap<>(sentToSave.getJourneyData()));
        newlySaved.setBroker(BrokerDto.builder().details(
            BrokerDetailsDto.builder().networkId(sentToSave.getBroker().getDetails().getNetworkId())
                .id(sentToSave.getBroker().getDetails().getId()).
                build()).build());
        return newlySaved;
      });  //return the same case application


      Application clonedApplication = Application.builder()
          .caseApplication(clonedCaseWithDipResult)
          .applicants(new ArrayList<>())
          .income(new ValidatedCaseIncomeDto())
          .expenditure(new ValidatedCaseExpenseDto())
          .build();
      when(mockFmaApplicationMapper.toFmaApplication(any(), any(), any(), any(), any(), any())).thenReturn(clonedApplication);

      FullMortgageApplicationExtendedResponse fakeFmaResponse = new FullMortgageApplicationExtendedResponse();
      fakeFmaResponse.setData(ResponseData.builder().build());

      ArgumentCaptor<Application> applicationSubmittedToFmaCaptor = ArgumentCaptor.forClass(Application.class);
      when(mockFmaClient.submitFma(applicationSubmittedToFmaCaptor.capture())).thenThrow(new FmaValidationException(ErrorCode.UNHANDLED, "UNHANDLED VALIDATION"));

      BrokerInfo brokerPrincipal = fakeBrokerPrincipal();
      when(mockBrokerInfoService.getBroker(any())).thenReturn(brokerPrincipal);

      BrokerSourceResultDto brokerSourceResult = new BrokerSourceResultDto();
      brokerSourceResult.setSource1(SOURCE_1_ID);
      brokerSourceResult.setSource2(SOURCE_2_ID);

      when(mockBrokerSourcesClient.findBrokerSources(any(), any())).thenReturn(
          new BrokerSourceResultDto[]{brokerSourceResult}
      );

      //Method under Test
      FmaUnhandledValidationException ex = assertThrows(
          FmaUnhandledValidationException.class,
          () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));
      assertEquals("UNHANDLED VALIDATION", ex.getMessage());

      //Verify Capie Calls
      verify(mockCaseClient, times(2)).updateCase(eq(BRAND_DEFAULT), any());

      List<CaseApplicationDto> capturedCapieApplicationUpdates = caseApplicationDtoCaptor.getAllValues();
      assertEquals(2, capturedCapieApplicationUpdates.size());

      //Capie Case update before submit
      assertNotSame(originalCaseWithDipResult, capturedCapieApplicationUpdates.get(0));
      assertSame(clonedCaseWithDipResult,capturedCapieApplicationUpdates.get(0) );
      assertEquals(SOURCE_2_ID, capturedCapieApplicationUpdates.get(0).getBroker().getDetails().getNetworkId().toString());
      assertEquals(SOURCE_1_ID, capturedCapieApplicationUpdates.get(0).getBroker().getDetails().getId().toString());
      CaseJourneyDataDto journeyDataDto = toDataObject(capturedCapieApplicationUpdates.get(0).getJourneyData(), CaseJourneyDataDto.class);
      assertTrue((boolean) capturedCapieApplicationUpdates.get(0).getJourneyData().get(CASE_JOURNEY_DATA_FMA_SUBMITTED));
      assertEquals(JourneyStep.FMA_ON_SUBMIT.toString(), capturedCapieApplicationUpdates.get(0).getJourneyData().get(CASE_JOURNEY_DATA_STEP).toString());
      assertEquals(JourneyStep.FMA_ON_SUBMIT, journeyDataDto.getStep());

      //Capie Case update after submit is back to original values
      assertSame(originalCaseWithDipResult, capturedCapieApplicationUpdates.get(1));
      assertNotSame(clonedCaseWithDipResult,capturedCapieApplicationUpdates.get(1) );
      assertEquals(PAYMENT_PATH_ID, capturedCapieApplicationUpdates.get(1).getBroker().getDetails().getNetworkId());
      assertNull(capturedCapieApplicationUpdates.get(1).getBroker().getDetails().getId());
      journeyDataDto = toDataObject(capturedCapieApplicationUpdates.get(1).getJourneyData(), CaseJourneyDataDto.class);
      assertFalse(capturedCapieApplicationUpdates.get(1).getJourneyData().containsKey(CASE_JOURNEY_DATA_FMA_SUBMITTED));
      assertEquals(JourneyStep.FMA_POST_SUBMIT_RESET.toString(),capturedCapieApplicationUpdates.get(1).getJourneyData().get(CASE_JOURNEY_DATA_STEP).toString());
      assertEquals(JourneyStep.FMA_POST_SUBMIT_RESET, journeyDataDto.getStep());

      //Verify that the application data sent to FMA contains with GMS Network info
      List<Application> applicationsSubmittedToFma = applicationSubmittedToFmaCaptor.getAllValues();
      assertEquals(1, applicationsSubmittedToFma.size());
      BrokerDto broker = applicationsSubmittedToFma.get(0).getCaseApplication().getBroker();
      assertEquals(SOURCE_2_ID, broker.getDetails().getNetworkId().toString());
      assertEquals(SOURCE_1_ID, broker.getDetails().getId().toString());



    }

    @Test
    void submitFmaThrowsUpdateNotPermittedWhenApplicationStatusIsStage20() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with application status SUBMIT_GMS_STAGE_20 (after FMA submission)
        CaseApplicationDto caseApplicationDtoAfterFmaSubmission = CaseApplicationDto.builder()
                .applicationStatus(ApplicationStatus.SUBMIT_GMS_STAGE_20.name())
                .build();

        // simulate retrieving the existing case with application status SUBMIT_GMS_STAGE_20 from the case client
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoAfterFmaSubmission);

        RuntimeException ex = assertThrows(
                UpdateNotPermittedException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_FMA_ALREADY_SUBMITTED, ex.getMessage());
    }

    @Test
    void submitFmaThrowsInvalidCaseStateWhenDipListIsNull() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with decisionInPrinciples == null
        CaseApplicationDto caseApplicationDtoWithNullDipList = CaseApplicationDto.builder()
                .decisionInPrinciples(null)
                .build();

        // simulate retrieving the existing case with decisionInPrinciples == null from the case client
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithNullDipList);

        RuntimeException ex = assertThrows(
                InvalidCaseStateException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_NO_DIP_RESULT, ex.getMessage());
    }

    @Test
    void submitFmaThrowsInvalidCaseStateWhenDipListIsEmpty() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with decisionInPrinciples == empty list
        CaseApplicationDto caseApplicationDtoWithEmptyDipList = CaseApplicationDto.builder()
                .decisionInPrinciples(new ArrayList<>())
                .build();

        // simulate retrieving the existing case with decisionInPrinciples == empty list from the case client
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithEmptyDipList);

        RuntimeException ex = assertThrows(
                InvalidCaseStateException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_NO_DIP_RESULT, ex.getMessage());
    }

    @Test
    void submitFmaThrowsInvalidCaseStateWhenDipResultIsNull() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with decisionInPrinciples[0] == null
        CaseApplicationDto caseApplicationDtoWithNullDipResult = CaseApplicationDto.builder()
                .decisionInPrinciples(Collections.singletonList(null))
                .build();

        // simulate retrieving the existing case with decisionInPrinciples[0] == null from the case client
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithNullDipResult);

        RuntimeException ex = assertThrows(
                InvalidCaseStateException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_NO_DIP_RESULT, ex.getMessage());
    }

    @Test
    void submitFmaThrowsInvalidCaseStateWhenDipDateTimeIsNull() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with decisionInPrinciples[0].dateTime == null
        CaseApplicationDto caseApplicationDtoWithNullDipDateTime = CaseApplicationDto.builder()
                .decisionInPrinciples(Collections.singletonList(
                        DecisionInPrincipleDto.builder()
                                .dateTime(null)
                                .build()))
                .build();

        // simulate retrieving the existing case with decisionInPrinciples[0].dateTime == null from the case client
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithNullDipDateTime);

        RuntimeException ex = assertThrows(
                InvalidCaseStateException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_DIP_EXPIRED, ex.getMessage());
    }

    @Test
    void submitFmaThrowsInvalidCaseStateWhenDipDateTimeIsBlank() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with decisionInPrinciples[0].dateTime == " "
        CaseApplicationDto caseApplicationDtoWithBlankDipDateTime = CaseApplicationDto.builder()
                .decisionInPrinciples(Collections.singletonList(
                        DecisionInPrincipleDto.builder()
                                .dateTime(" ")
                                .build()))
                .build();

        // simulate retrieving the existing case with decisionInPrinciples[0].dateTime == " " from the case client
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithBlankDipDateTime);

        RuntimeException ex = assertThrows(
                InvalidCaseStateException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_DIP_EXPIRED, ex.getMessage());
    }

    @Test
    void submitFmaThrowsInvalidCaseStateWhenDipDateTimeIs30DaysAgoStartOfDay() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with decisionInPrinciples[0].dateTime == today - 30 days at at 00:00:00
        LocalDateTime twentyNineDaysAgoEndOfDay = StoppedClock.getTheTime().minusDays(30).withHour(0).withMinute(0).withSecond(0);
        CaseApplicationDto caseApplicationDtoWithDipDateTime29DaysAgoEndOfDay = CaseApplicationDto.builder()
                .decisionInPrinciples(Collections.singletonList(
                        DecisionInPrincipleDto.builder()
                                .dateTime(twentyNineDaysAgoEndOfDay.format(DIP_RESULT_DATE_TIME_FORMATTER))
                                .build()))
                .build();

        // simulate retrieving the existing case with decisionInPrinciples[0].dateTime == today - 30 days at at 00:00:00
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithDipDateTime29DaysAgoEndOfDay);

        RuntimeException ex = assertThrows(
                InvalidCaseStateException.class,
                () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_DIP_EXPIRED, ex.getMessage());
    }

    @Test
    void submitFmaThrowsFmaValidationExceptionWhenLandlordHasNotEnoughExperience() {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      OtherPropertyDto otherProperty1Dto = OtherPropertyDto.builder()
          .propertyUsage(PropertyUsage.BUY_TO_LET.value())
          .ownershipType(OwnershipType.HELD_ELSEWHERE.value())
          .propertyRedemption(false)
          .build();

      OtherPropertyDto otherProperty2Dto = OtherPropertyDto.builder()
          .propertyUsage(PropertyUsage.CONSENT_TO_LET.value())
          .ownershipType(OwnershipType.HELD_RBSG.value())
          .propertyRedemption(false)
          .build();

      OtherPropertyDto otherProperty3Dto = OtherPropertyDto.builder()
          .propertyUsage(PropertyUsage.BUY_TO_LET.value())
          .ownershipType(OwnershipType.HELD_RBSG.value())
          .propertyRedemption(false)
          .build();

      CaseApplicationDto caseApplicationDtoWithNotEnoughLandlordExperience = getCaseWithDipResult();

      caseApplicationDtoWithNotEnoughLandlordExperience.setApplicationType(ApplicationType.BUY_TO_LET.value());
      caseApplicationDtoWithNotEnoughLandlordExperience.setLoanPurpose(LoanPurpose.HOUSE_PURCHASE.value());
      caseApplicationDtoWithNotEnoughLandlordExperience.setMortgage(MortgageDto.builder()
          .otherProperties(Arrays.asList(otherProperty1Dto, otherProperty2Dto, otherProperty3Dto))
          .buyToLet(BuyToLetDto.builder()
              .portfolioLandlord(PortfolioLandlordDto.builder()
                  .numberOfYearsAsLandlord(1)
                  .build())
              .build())
          .build());

      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithNotEnoughLandlordExperience);

      RuntimeException ex = assertThrows(
          FmaValidationException.class,
          () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

      assertEquals(ErrorCode.NOT_ENOUGH_LANDLORD_EXPERIENCE.getExternalMessage(), ex.getMessage());
    }

    @Test
    void submitFmaSucceedsWhenDipDateTimeIs28DaysAgoAtStartOfDay() throws FmaIntegrationException, BrokerSourcesException {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(mockCaseClient.updateCase(eq(BRAND_DEFAULT), any())).thenAnswer(i -> i.getArgument(1));

        // set up a CaseApplicationDto with decisionInPrinciples[0].dateTime == today - 28 days at 00:00:00
        LocalDateTime twentyEightDaysAgoStartOfDay = StoppedClock.getTheTime().minusDays(28).withHour(0).withMinute(0).withSecond(0);
        CaseApplicationDto caseApplicationDtoWithDipDateTime28DaysAgoStartOfDay = CaseApplicationDto.builder()
                .decisionInPrinciples(Collections.singletonList(
                        DecisionInPrincipleDto.builder()
                                .dateTime(twentyEightDaysAgoStartOfDay.format(DIP_RESULT_DATE_TIME_FORMATTER))
                                .build()))
                .build();

        // simulate retrieving the existing case with decisionInPrinciples[0].dateTime == today - 28 days at 00:00:00
        when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoWithDipDateTime28DaysAgoStartOfDay);

        // include the test CaseApplicationDto and other fields in the FMA application (to avoid NPEs)
        Application fakeFmaApplication = Application.builder()
                .caseApplication(caseApplicationDtoWithDipDateTime28DaysAgoStartOfDay)
                .applicants(new ArrayList<>())
                .income(new ValidatedCaseIncomeDto())
                .expenditure(new ValidatedCaseExpenseDto())
                .build();
        when(mockFmaApplicationMapper.toFmaApplication(any(), any(), any(), any(), any(), any())).thenReturn(fakeFmaApplication);

        // return non-null response from FmaClient.submitFma() to avoid NPEs
        FullMortgageApplicationExtendedResponse fakeFmaResponse = new FullMortgageApplicationExtendedResponse();
        when(mockFmaClient.submitFma(any())).thenReturn(fakeFmaResponse);

        fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID);
    }

    @Test
    void submitFmaThrowsFmaValidationExceptionWhenLoanOutstandingAmountIsNotInteger() {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      CaseApplicationDto aCase = getCaseWithDipResult();
      aCase.setBroker(BrokerDto.builder().details(BrokerDetailsDto.builder().networkId(PAYMENT_PATH_ID).build()).build());
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(aCase);

      ExpenseTransactionDto transactionDto = ExpenseTransactionDto.builder()
        .categoryCode(ExpenseCategory.LOANS_PERSONAL_CONTRACT_PURCHASE)
        .outstandingBalance(BigDecimal.valueOf(1000.50))
        .build();
      ExpenseApplicantDto applicantDto = ExpenseApplicantDto.builder()
        .transactions(Collections.singletonMap("1", transactionDto))
        .build();
      ValidatedCaseExpenseDto expenseDto = new ValidatedCaseExpenseDto();
      expenseDto.setApplicants(Collections.singletonList(applicantDto));
      when(mockExpenseClient.getExpense(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(expenseDto);

      RuntimeException ex = assertThrows(
        FmaValidationException.class,
        () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

      assertEquals(MSG_INVALID_EXPENSE_LOAN_OUTSTANDING_AMOUNT, ex.getMessage());
    }

    @Test
    void submitFmaThrowsFmaValidationExceptionWhenCreditCardOutstandingBalanceIsNotInteger() {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      CaseApplicationDto aCase = getCaseWithDipResult();
      aCase.setBroker(BrokerDto.builder().details(BrokerDetailsDto.builder().networkId(PAYMENT_PATH_ID).build()).build());
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(aCase);

      ExpenseTransactionDto transactionDto = ExpenseTransactionDto.builder()
        .categoryCode(ExpenseCategory.CREDIT_CARD)
        .outstandingBalance(BigDecimal.valueOf(1000.50))
        .build();
      ExpenseApplicantDto applicantDto = ExpenseApplicantDto.builder()
        .transactions(Collections.singletonMap("1", transactionDto))
        .build();
      ValidatedCaseExpenseDto expenseDto = new ValidatedCaseExpenseDto();
      expenseDto.setApplicants(Collections.singletonList(applicantDto));
      when(mockExpenseClient.getExpense(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(expenseDto);

      RuntimeException ex = assertThrows(
        FmaValidationException.class,
        () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

      assertEquals(MSG_INVALID_EXPENSE_CREDIT_CARD_OUTSTANDING_BALANCE, ex.getMessage());
    }

    @Test
    void submitFmaThrowsFmaValidationExceptionWhenLoanConsolidatedAmountIsNotInteger() {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      CaseApplicationDto aCase = getCaseWithDipResult();
      aCase.setBroker(BrokerDto.builder().details(BrokerDetailsDto.builder().networkId(PAYMENT_PATH_ID).build()).build());
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(aCase);

      ExpenseTransactionDto transactionDto = ExpenseTransactionDto.builder()
          .categoryCode(ExpenseCategory.LOANS_PERSONAL_CONTRACT_PURCHASE)
          .consolidationAmount(BigDecimal.valueOf(1000.50))
          .build();
      ExpenseApplicantDto applicantDto = ExpenseApplicantDto.builder()
          .transactions(Collections.singletonMap("1", transactionDto))
          .build();
      ValidatedCaseExpenseDto expenseDto = new ValidatedCaseExpenseDto();
      expenseDto.setApplicants(Collections.singletonList(applicantDto));
      when(mockExpenseClient.getExpense(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(expenseDto);

      RuntimeException ex = assertThrows(
          FmaValidationException.class,
          () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

      assertEquals(MSG_INVALID_EXPENSE_LOAN_CONSOLIDATED_AMOUNT, ex.getMessage());
    }

    @Test
    void submitFmaThrowsFmaValidationExceptionWhenCreditCardConsolidatedAmountIsNotInteger() {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      CaseApplicationDto aCase = getCaseWithDipResult();
      aCase.setBroker(BrokerDto.builder().details(BrokerDetailsDto.builder().networkId(PAYMENT_PATH_ID).build()).build());
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(aCase);

      ExpenseTransactionDto transactionDto = ExpenseTransactionDto.builder()
          .categoryCode(ExpenseCategory.CREDIT_CARD)
          .consolidationAmount(BigDecimal.valueOf(1000.50))
          .build();
      ExpenseApplicantDto applicantDto = ExpenseApplicantDto.builder()
          .transactions(Collections.singletonMap("1", transactionDto))
          .build();
      ValidatedCaseExpenseDto expenseDto = new ValidatedCaseExpenseDto();
      expenseDto.setApplicants(Collections.singletonList(applicantDto));
      when(mockExpenseClient.getExpense(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(expenseDto);

      RuntimeException ex = assertThrows(
          FmaValidationException.class,
          () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

      assertEquals(MSG_INVALID_EXPENSE_CREDIT_CARD_CONSOLIDATED_AMOUNT, ex.getMessage());
    }
    @Test
    void submitFmaThrowsFmaValidationExceptionWhenEstateAgentNameIsInvalid() {
      when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      CaseApplicationDto aCase = getCaseWithDipResult();
      aCase.setBroker(
          BrokerDto.builder().details(BrokerDetailsDto.builder().networkId(PAYMENT_PATH_ID).build())
              .build());
      String agentNamemax45 ="max45max45max45max45max45max45max45max45max45max45";
      aCase.setEstateAgent(EstateAgentDto.builder().agencyName(agentNamemax45).build());
      when(mockCaseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(aCase);

      FmaValidationException ex = assertThrows(
          FmaValidationException.class,
          () -> fmaService.submitFma(BRAND_DEFAULT, TEST_CASE_ID));

      assertEquals(ErrorCode.ESTATE_AGENT_LENGTH_EXCEEDED,ex.getCode());
    }
  }

  private CaseApplicationDto getCaseWithDipResult() {
    CaseApplicationDto caseWithDipResult = new CaseApplicationDto();
    caseWithDipResult.setBroker(BrokerDto.builder().details(BrokerDetailsDto.builder().networkId(PAYMENT_PATH_ID).build()).build());
    DecisionInPrincipleDto dipResult = new DecisionInPrincipleDto();
    LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
    dipResult.setDateTime(yesterday.format(DIP_RESULT_DATE_TIME_FORMATTER));
    caseWithDipResult.setDecisionInPrinciples(Collections.singletonList(dipResult));
    return caseWithDipResult;
  }


  private BrokerInfo fakeBrokerPrincipal() {
        return BrokerInfo.builder()
                .firmDetails(FirmDetails.builder()
                        .fcaNumber(FCA_NUMBER)
                        .firmName(FIRM_NAME)
                        .tradingName(TRADING_NAME)
                        .address(AddressDetails.builder()
                                .postcode(POSTCODE)
                                .build())

                        .build())
            .paymentPaths(Arrays.asList(new PaymentPath(1234, "DO NOT MATCH", "bit", "res"),
                                        new PaymentPath(PAYMENT_PATH_ID, PAYMENT_PATH_NAME, "bit", "res"),
                                        new PaymentPath(999, "DO NOT MATCH", "bit", "res")))
            .build();
    }

    static class StoppedClock extends Clock {
        @Getter
        @Setter
        private static LocalDateTime theTime = LocalDateTime.now();

        @Override
        public LocalDateTime localNow() {
            return theTime;
        }
    }
}
