package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title.MR;
import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.WORK_STATUS_WORKING;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE2_COUNTRY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE2_NUMBER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE2_POSTCODE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE2_STREET;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE2_TOWN;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE_COUNTRY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE_NUMBER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE_POSTCODE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE_STREET;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.TEST_HOUSE_TOWN;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createMarketingPreferences;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createMarketingPreferencesDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.createValidApplicant;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.MarketingPreferencesDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import java.math.BigDecimal;
import com.natwest.pbbdhb.broker.portal.uicoord.model.MarketingPreferences;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        NapoliApplicantMapperImpl.class,
        PersonalAddressMapperImpl.class,
        NapoliPersonalDetailsMapperImpl.class
})
class NapoliApplicantMapperImplTest {

    @Autowired
    private NapoliApplicantMapper napoliApplicantMapper;

    @Test
    void testApplicantRoundTripMapping() {
        Applicant applicant = createValidApplicant();
        ApplicantDto applicantDto = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);
        Applicant roundTripApplicant = this.napoliApplicantMapper.toApplicant(applicantDto);

        assertThat(roundTripApplicant).usingRecursiveComparison().isEqualTo(applicant);
    }

    @Test
    void toApplicantMapsCorrectlyWhenPersonalDetailsNull() {
        ApplicantDto applicantDto = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, createValidApplicant());
        applicantDto.setPersonalDetails(null);

        Applicant result = this.napoliApplicantMapper.toApplicant(applicantDto);

        assertThat(result.getPersonalDetails()).isNull();

        assertThat(result).usingRecursiveComparison().ignoringFields("bankWithNatWest", "addresses").isEqualTo(applicantDto);
        assertThat(result.getBankWithNatWest()).isEqualTo(applicantDto.getJourneyData().get(APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST));
        assertThat(result.getAddresses()).usingRecursiveComparison().ignoringFields("country", "flatNameOrNumber", "originalPurchasePrice", "currentPropertyValue").isEqualTo(applicantDto.getAddresses());
        for (int i = 0; i < result.getAddresses().size(); i++) {
            assertThat(result.getAddresses().get(i).getCountry()).isEqualTo(applicantDto.getAddresses().get(i).getCountryIsoCode());
            assertThat(result.getAddresses().get(i).getFlatNameOrNumber()).isEqualTo(applicantDto.getAddresses().get(i).getFlat());
            assertThat(result.getAddresses().get(i).getCurrentPropertyValue()).isEqualTo(applicantDto.getAddresses().get(i).getCurrentPropertyValue().intValue());
        }
    }

    @Test
    void toApplicantDtoMapsCorrectlyWhenMarketingPreferencesIsNullAndBankWithNatWestFalse() {
      Applicant applicant = createValidApplicant();
      applicant.setBankWithNatWest(false);

      ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);
      MarketingPreferencesDto marketingPreferences = result.getMarketingPreferences();

      assertTrue(result.getNewToBank());
      assertNull(applicant.getMarketingPreferences());
      assertNotNull(marketingPreferences);
      assertFalse(marketingPreferences.getTelephone());
      assertFalse(marketingPreferences.getPost());
      assertFalse(marketingPreferences.getEmail());

    }

    @Test
    void toApplicantMapsCorrectlyWhenMarketingPreferencesIsNullAndNewToBankTrue() {
      ApplicantDto applicantDto = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, createValidApplicant());
      applicantDto.setNewToBank(true);

      Applicant result = this.napoliApplicantMapper.toApplicant(applicantDto);
      MarketingPreferences marketingPreferences = result.getMarketingPreferences();

      assertFalse(result.getBankWithNatWest());
      assertNull(applicantDto.getMarketingPreferences());
      assertNotNull(marketingPreferences);
      assertFalse(marketingPreferences.getTelephone());
      assertFalse(marketingPreferences.getPost());
      assertFalse(marketingPreferences.getEmail());

    }

    @Test
    void toApplicantDtoMapsCorrectlyWhenMarketingPreferencesIsNullAndBankWithNatWestTrue() {
      Applicant applicant = createValidApplicant();

      ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);

      assertFalse(result.getNewToBank());
      assertNull(applicant.getMarketingPreferences());
      assertNull(result.getMarketingPreferences());

    }

    @Test
    void toApplicantMapsCorrectlyWhenMarketingPreferencesIsNullAndNewToBankFalse() {
      ApplicantDto applicantDto = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, createValidApplicant());

      Applicant result = this.napoliApplicantMapper.toApplicant(applicantDto);

      assertTrue(result.getBankWithNatWest());
      assertNull(applicantDto.getMarketingPreferences());
      assertNull(result.getMarketingPreferences());

    }

    @Test
    void toApplicantDtoMapsCorrectlyWhenMarketingPreferencesIsNotNullAndBankWithNatWestFalse() {
      Applicant applicant = createValidApplicant();
      applicant.setBankWithNatWest(false);
      applicant.setMarketingPreferences(createMarketingPreferences());

      ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);
      MarketingPreferencesDto marketingPreferences = result.getMarketingPreferences();

      assertTrue(result.getNewToBank());
      assertNotNull(marketingPreferences);
      assertFalse(marketingPreferences.getTelephone());
      assertFalse(marketingPreferences.getPost());
      assertTrue(marketingPreferences.getEmail());

    }

    @Test
    void toApplicantMapsCorrectlyWhenMarketingPreferencesIsNotNullAndNewToBankTrue() {
      ApplicantDto applicantDto = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, createValidApplicant());
      applicantDto.setMarketingPreferences(createMarketingPreferencesDto());
      applicantDto.setNewToBank(null);
      applicantDto.getJourneyData().put(APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST, false);

      Applicant result = this.napoliApplicantMapper.toApplicant(applicantDto);
      MarketingPreferences marketingPreferences = result.getMarketingPreferences();

      assertFalse(result.getBankWithNatWest());
      assertNotNull(marketingPreferences);
      assertFalse(marketingPreferences.getTelephone());
      assertFalse(marketingPreferences.getPost());
      assertTrue(marketingPreferences.getEmail());

    }

    @Test
    void toApplicantDtoMapsCorrectlyWhenMarketingPreferencesIsNotNullAndBankWithNatWestTrue() {
      Applicant applicant = createValidApplicant();
      applicant.setMarketingPreferences(createMarketingPreferences());

      ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);

      assertFalse(result.getNewToBank());
      assertNull(result.getMarketingPreferences());

    }

    @Test
    void toApplicantMapsCorrectlyWhenMarketingPreferencesIsNotNullAndNewToBankFalse() {
      ApplicantDto applicantDto = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, createValidApplicant());
      applicantDto.setMarketingPreferences(createMarketingPreferencesDto());

      Applicant result = this.napoliApplicantMapper.toApplicant(applicantDto);

      assertTrue(result.getBankWithNatWest());
      assertNull(result.getMarketingPreferences());

    }

    @Test
    void toApplicantReturnsNullWhenApplicantDtoNull() {
        assertThat(this.napoliApplicantMapper.toApplicant(null)).isNull();
    }

    @Test
    void toApplicantDtoMapsCorrectly() {
        Applicant applicant = createValidApplicant();

        ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);

        assertThat(result).usingRecursiveComparison().ignoringFields("caseId", "workStatus",
            "personalDetails.title", "personalDetails.telephones", "personalDetails.countryOfResidenceIsoCode",
            "journeyData", "addresses", "existingMortgages", "multiCins", "cin", "gmsCustomerId", "kycChannel", "customerType",
            "createdDate", "applicationStatus", "proofOfIds", "giveYourAgreement",
            "modifiedDate", "unstructuredCurrentAddress", "route", "additionalBorrowing",
            "creditHistory.bankruptcyDate", "creditHistory.bankruptDetails", "creditHistory.courtProceedingDetails",
            "personalDetails.mailIndicator", "personalDetails.emailVerified", "newToBank",
            "consentToJointParty", "consentToMiau", "consentToMortagageIllustration", "consentToDebtConsolidationAcceptedAt", "giveYourAgreementAt",
            "consentToJointPartyAcceptedAt", "consentToDebtConsolidation", "consentToYmr",
            "mainBankDetails.consentToDirectDebit", "mainBankDetails.consentToDirectDebitAt",
            "personalDetails.placeOfBirth", "personalDetails.taxNumbers", "personalDetails.ukAssociationAddress",
            "personalDetails.taxResidency", "personalDetails.correspondenceAddress", "personalDetails.countryOfBirth",
            "personalDetails.previousNames", "personalDetails.otherNames").isEqualTo(applicant);
        assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
        assertThat(result.getWorkStatus()).isEqualTo(WORK_STATUS_WORKING);
        assertThat(result.getPersonalDetails().getTitle()).isEqualTo(MR.name());
        assertThat(result.getPersonalDetails().getCountryOfBirth()).isEqualTo(applicant.getPersonalDetails().getCountryOfBirth());
        assertThat(result.getPersonalDetails().getPlaceOfBirth()).isEqualTo(applicant.getPersonalDetails().getPlaceOfBirth());
        assertThat(result.getPersonalDetails().getPreviousNames()).isEqualTo(applicant.getPersonalDetails().getPreviousNames());
        assertThat(result.getPersonalDetails().getOtherNames()).isEqualTo(applicant.getPersonalDetails().getOtherNames());
        assertThat(result.getPersonalDetails().getTaxNumbers()).isEqualTo(applicant.getPersonalDetails().getTaxNumbers());
        assertThat(result.getPersonalDetails().getTaxResidency()).isEqualTo(applicant.getPersonalDetails().getTaxResidency());
        assertThat(result.getPersonalDetails().getCorrespondenceAddress()).usingRecursiveComparison().isEqualTo(applicant.getPersonalDetails().getCorrespondenceAddress());
        assertThat(result.getPersonalDetails().getUkAssociationAddress()).usingRecursiveComparison().isEqualTo(applicant.getPersonalDetails().getUkAssociationAddress());
        assertThat(result.getPersonalDetails().getTelephones().size()).isEqualTo(1);
        assertThat(result.getPersonalDetails().getTelephones().get(0)).usingRecursiveComparison().ignoringFields("preferred", "verified").isEqualTo(applicant.getPersonalDetails().getTelephone());
        assertThat(result.getExistingMortgages().get(0).getOriginatingCurrency()).isEqualTo(applicant.getExistingMortgages().get(0).getOriginatingCurrency());
        assertThat(result.getJourneyData().get(APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST)).isEqualTo(applicant.getBankWithNatWest());
        assertThat(result.getAddresses().get(0).getHouseNumber()).isEqualTo(TEST_HOUSE_NUMBER);
        assertThat(result.getAddresses().get(0).getStreet()).isEqualTo(TEST_HOUSE_STREET);
        assertThat(result.getAddresses().get(0).getTown()).isEqualTo(TEST_HOUSE_TOWN);
        assertThat(result.getAddresses().get(0).getPostcode()).isEqualTo(TEST_HOUSE_POSTCODE);
        assertThat(result.getAddresses().get(0).getCountryIsoCode()).isEqualTo(TEST_HOUSE_COUNTRY);
        assertThat(result.getAddresses().get(0).getStartMonth()).isEqualTo(7);
        assertThat(result.getAddresses().get(0).getStartYear()).isEqualTo(2010);
        assertThat(result.getAddresses().get(0).getOccupyStatus()).isEqualTo("OWNER_MORTGAGED");
        assertThat(result.getAddresses().get(1).getHouseNumber()).isEqualTo(TEST_HOUSE2_NUMBER);
        assertThat(result.getAddresses().get(1).getStreet()).isEqualTo(TEST_HOUSE2_STREET);
        assertThat(result.getAddresses().get(1).getTown()).isEqualTo(TEST_HOUSE2_TOWN);
        assertThat(result.getAddresses().get(1).getPostcode()).isEqualTo(TEST_HOUSE2_POSTCODE);
        assertThat(result.getAddresses().get(1).getCountryIsoCode()).isEqualTo(TEST_HOUSE2_COUNTRY);
        assertThat(result.getAddresses().get(1).getStartMonth()).isEqualTo(7);
        assertThat(result.getAddresses().get(1).getStartYear()).isEqualTo(2005);
        assertThat(result.getAddresses().get(1).getOccupyStatus()).isEqualTo("OWNER_MORTGAGED");

        for (int i = 0; i < result.getAddresses().size(); i++) {
            if (i == 0) {
                assertThat(result.getAddresses().get(0).getIsCurrentAddress()).isEqualTo(true);
                assertThat(result.getAddresses().get(0).getEndMonth()).isNull();
                assertThat(result.getAddresses().get(0).getEndYear()).isNull();
            } else {
                assertThat(result.getAddresses().get(i).getIsCurrentAddress()).isEqualTo(false);
                assertThat(result.getAddresses().get(i).getEndMonth()).isEqualTo(result.getAddresses().get(i-1).getStartMonth());
                assertThat(result.getAddresses().get(i).getEndYear()).isEqualTo(result.getAddresses().get(i-1).getStartYear());
            }
            assertThat(result.getAddresses().get(i).getCountryIsoCode()).isEqualTo(applicant.getAddresses().get(i).getCountry());
            assertThat(result.getAddresses().get(i).getFlat()).isEqualTo(applicant.getAddresses().get(i).getFlatNameOrNumber());
            assertThat(result.getAddresses().get(i).getUkAddress()).isEqualTo("GB".equals(applicant.getAddresses().get(i).getCountry()));
            assertThat(result.getAddresses().get(i).getOriginalPurchasePrice()).isEqualTo(BigDecimal.valueOf(1));
        }
    }

    @Test
    void toApplicantDtoMapsCorrectlyWhenPersonalDetailsNull() {
        Applicant applicant = createValidApplicant();
        applicant.setPersonalDetails(null);

        ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, WORK_STATUS_WORKING, applicant);

        assertThat(result.getPersonalDetails()).isNull();

        assertThat(result).usingRecursiveComparison()
            .ignoringFields("caseId", "workStatus", "journeyData", "addresses", "existingMortgages", "multiCins", "cin",
                "gmsCustomerId", "kycChannel", "customerType", "createdDate", "applicationStatus", "proofOfIds",
                "modifiedDate", "unstructuredCurrentAddress", "route", "additionalBorrowing",
                "giveYourAgreement", "creditHistory.bankruptcyDate", "creditHistory.bankruptDetails", "creditHistory.courtProceedingDetails", "newToBank",
                "consentToJointParty", "consentToMiau", "consentToMortagageIllustration", "consentToDebtConsolidationAcceptedAt", "giveYourAgreementAt",
                "consentToJointPartyAcceptedAt", "consentToDebtConsolidation", "consentToYmr",
                "mainBankDetails.consentToDirectDebit", "mainBankDetails.consentToDirectDebitAt")
                .isEqualTo(applicant);
        assertThat(result.getCaseId()).isEqualTo(TEST_CASE_ID);
        assertThat(result.getWorkStatus()).isEqualTo(WORK_STATUS_WORKING);
        assertThat(result.getJourneyData().get(APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST)).isEqualTo(applicant.getBankWithNatWest());
        assertThat(result.getExistingMortgages().get(0).getOriginatingCurrency()).isEqualTo(applicant.getExistingMortgages().get(0).getOriginatingCurrency());
        assertThat(result.getAddresses().get(0).getHouseNumber()).isEqualTo(TEST_HOUSE_NUMBER);
        assertThat(result.getAddresses().get(0).getStreet()).isEqualTo(TEST_HOUSE_STREET);
        assertThat(result.getAddresses().get(0).getTown()).isEqualTo(TEST_HOUSE_TOWN);
        assertThat(result.getAddresses().get(0).getPostcode()).isEqualTo(TEST_HOUSE_POSTCODE);
        assertThat(result.getAddresses().get(0).getCountryIsoCode()).isEqualTo(TEST_HOUSE_COUNTRY);
        assertThat(result.getAddresses().get(0).getStartMonth()).isEqualTo(7);
        assertThat(result.getAddresses().get(0).getStartYear()).isEqualTo(2010);
        assertThat(result.getAddresses().get(0).getOccupyStatus()).isEqualTo("OWNER_MORTGAGED");
        assertThat(result.getAddresses().get(1).getHouseNumber()).isEqualTo(TEST_HOUSE2_NUMBER);
        assertThat(result.getAddresses().get(1).getStreet()).isEqualTo(TEST_HOUSE2_STREET);
        assertThat(result.getAddresses().get(1).getTown()).isEqualTo(TEST_HOUSE2_TOWN);
        assertThat(result.getAddresses().get(1).getPostcode()).isEqualTo(TEST_HOUSE2_POSTCODE);
        assertThat(result.getAddresses().get(1).getCountryIsoCode()).isEqualTo(TEST_HOUSE2_COUNTRY);
        assertThat(result.getAddresses().get(1).getStartMonth()).isEqualTo(7);
        assertThat(result.getAddresses().get(1).getStartYear()).isEqualTo(2005);
        assertThat(result.getAddresses().get(1).getOccupyStatus()).isEqualTo("OWNER_MORTGAGED");
        for (int i = 0; i < result.getAddresses().size(); i++) {
            if (i == 0) {
                assertThat(result.getAddresses().get(0).getIsCurrentAddress()).isEqualTo(true);
            } else {
                assertThat(result.getAddresses().get(i).getIsCurrentAddress()).isEqualTo(false);
                assertThat(result.getAddresses().get(i).getEndMonth()).isEqualTo(result.getAddresses().get(i-1).getStartMonth());
                assertThat(result.getAddresses().get(i).getEndYear()).isEqualTo(result.getAddresses().get(i-1).getStartYear());
            }
            assertThat(result.getAddresses().get(i).getCountryIsoCode()).isEqualTo(applicant.getAddresses().get(i).getCountry());
            assertThat(result.getAddresses().get(i).getFlat()).isEqualTo(applicant.getAddresses().get(i).getFlatNameOrNumber());
        }
    }

    @Test
    void toApplicantDtoMapsCorrectlyWhenCaseIdNull() {
        Applicant applicant = createValidApplicant();

        ApplicantDto result = this.napoliApplicantMapper.toApplicantDto(null, WORK_STATUS_WORKING, applicant);

        assertThat(result).usingRecursiveComparison()
            .ignoringFields("caseId", "workStatus", "personalDetails.title", "personalDetails.telephones", "personalDetails.countryOfResidenceIsoCode", "journeyData", "addresses", "existingMortgages",
                "countryOfResidenceIsoCode", "multiCins", "cin", "gmsCustomerId", "kycChannel", "customerType", "createdDate", "applicationStatus", "proofOfIds",
                "modifiedDate", "unstructuredCurrentAddress", "route", "additionalBorrowing", "personalDetails.emailVerified",
                "giveYourAgreement", "creditHistory.bankruptcyDate", "creditHistory.bankruptDetails", "creditHistory.courtProceedingDetails", "personalDetails.mailIndicator", "newToBank",
                "consentToJointParty", "consentToMiau", "consentToMortagageIllustration", "consentToDebtConsolidationAcceptedAt", "giveYourAgreementAt",
                "consentToJointPartyAcceptedAt", "consentToDebtConsolidation", "consentToYmr",
                "mainBankDetails.consentToDirectDebit", "mainBankDetails.consentToDirectDebitAt",
                "personalDetails.placeOfBirth", "personalDetails.taxNumbers", "personalDetails.ukAssociationAddress",
                "personalDetails.taxResidency", "personalDetails.correspondenceAddress", "personalDetails.countryOfBirth", "personalDetails.previousNames", "personalDetails.otherNames").isEqualTo(applicant);
        assertThat(result.getCaseId()).isNull();
        assertThat(result.getWorkStatus()).isEqualTo(WORK_STATUS_WORKING);
        assertThat(result.getPersonalDetails().getTitle()).isEqualTo(MR.name());
        assertThat(result.getPersonalDetails().getCountryOfBirth()).isEqualTo(applicant.getPersonalDetails().getCountryOfBirth());
        assertThat(result.getPersonalDetails().getPlaceOfBirth()).isEqualTo(applicant.getPersonalDetails().getPlaceOfBirth());
        assertThat(result.getPersonalDetails().getPreviousNames()).isEqualTo(applicant.getPersonalDetails().getPreviousNames());
        assertThat(result.getPersonalDetails().getOtherNames()).isEqualTo(applicant.getPersonalDetails().getOtherNames());
        assertThat(result.getPersonalDetails().getTaxNumbers()).isEqualTo(applicant.getPersonalDetails().getTaxNumbers());
        assertThat(result.getPersonalDetails().getTaxResidency()).isEqualTo(applicant.getPersonalDetails().getTaxResidency());
        assertThat(result.getPersonalDetails().getCorrespondenceAddress()).usingRecursiveComparison().isEqualTo(applicant.getPersonalDetails().getCorrespondenceAddress());
        assertThat(result.getPersonalDetails().getUkAssociationAddress()).usingRecursiveComparison().isEqualTo(applicant.getPersonalDetails().getUkAssociationAddress());
        assertThat(result.getPersonalDetails().getTelephones().size()).isEqualTo(1);
        assertThat(result.getPersonalDetails().getTelephones().get(0)).usingRecursiveComparison().ignoringFields("preferred", "verified").isEqualTo(applicant.getPersonalDetails().getTelephone());
        assertThat(result.getJourneyData().get(APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST)).isEqualTo(applicant.getBankWithNatWest());
        assertThat(result.getExistingMortgages().get(0).getOriginatingCurrency()).isEqualTo(applicant.getExistingMortgages().get(0).getOriginatingCurrency());
        assertThat(result.getAddresses().get(0).getHouseNumber()).isEqualTo(TEST_HOUSE_NUMBER);
        assertThat(result.getAddresses().get(0).getStreet()).isEqualTo(TEST_HOUSE_STREET);
        assertThat(result.getAddresses().get(0).getTown()).isEqualTo(TEST_HOUSE_TOWN);
        assertThat(result.getAddresses().get(0).getPostcode()).isEqualTo(TEST_HOUSE_POSTCODE);
        assertThat(result.getAddresses().get(0).getCountryIsoCode()).isEqualTo(TEST_HOUSE_COUNTRY);
        assertThat(result.getAddresses().get(0).getStartMonth()).isEqualTo(7);
        assertThat(result.getAddresses().get(0).getStartYear()).isEqualTo(2010);
        assertThat(result.getAddresses().get(0).getOccupyStatus()).isEqualTo("OWNER_MORTGAGED");
        assertThat(result.getAddresses().get(1).getHouseNumber()).isEqualTo(TEST_HOUSE2_NUMBER);
        assertThat(result.getAddresses().get(1).getStreet()).isEqualTo(TEST_HOUSE2_STREET);
        assertThat(result.getAddresses().get(1).getTown()).isEqualTo(TEST_HOUSE2_TOWN);
        assertThat(result.getAddresses().get(1).getPostcode()).isEqualTo(TEST_HOUSE2_POSTCODE);
        assertThat(result.getAddresses().get(1).getCountryIsoCode()).isEqualTo(TEST_HOUSE2_COUNTRY);
        assertThat(result.getAddresses().get(1).getStartMonth()).isEqualTo(7);
        assertThat(result.getAddresses().get(1).getStartYear()).isEqualTo(2005);
        assertThat(result.getAddresses().get(1).getOccupyStatus()).isEqualTo("OWNER_MORTGAGED");
        for (int i = 0; i < result.getAddresses().size(); i++) {
            if (i == 0) {
                assertThat(result.getAddresses().get(0).getIsCurrentAddress()).isEqualTo(true);
            } else {
                assertThat(result.getAddresses().get(i).getIsCurrentAddress()).isEqualTo(false);
                assertThat(result.getAddresses().get(i).getEndMonth()).isEqualTo(result.getAddresses().get(i-1).getStartMonth());
                assertThat(result.getAddresses().get(i).getEndYear()).isEqualTo(result.getAddresses().get(i-1).getStartYear());
            }
            assertThat(result.getAddresses().get(i).getCountryIsoCode()).isEqualTo(applicant.getAddresses().get(i).getCountry());
            assertThat(result.getAddresses().get(i).getFlat()).isEqualTo(applicant.getAddresses().get(i).getFlatNameOrNumber());
        }
    }

    @Test
    void toApplicantReturnsNullWhenAllArgumentsAreNull() {
        assertThat(this.napoliApplicantMapper.toApplicantDto(null, null, null)).isNull();
    }
}
