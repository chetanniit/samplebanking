package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.github.tomakehurst.wiremock.http.HttpHeader;
import com.github.tomakehurst.wiremock.http.HttpHeaders;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PREFIX_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PREFIX_VALUE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_VALUE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SAVE_CASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.readCaseApplicationFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MEDIA_TYPE_TEXT_PLAIN_UTF8;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
public class CaseControllerTest {

    private static final String PATH_MSVC_CASE_MANAGEMENT_GENERATE_CASE_ID = "/mortgages/v1/msvc-case-management/generateCaseId";

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/cases/save-case-create-request.json")
    private Resource saveCaseCreateRequest;

    @Value("classpath:test-files/cases/save-case-create-response.json")
    private Resource saveCaseCreateResponse;

    @Value("classpath:test-files/cases/save-case-update-request.json")
    private Resource saveCaseUpdateRequest;

    @Value("classpath:test-files/cases/save-case-update-response.json")
    private Resource saveCaseUpdateResponse;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void getCaseIdValidRequestReturnsCaseId() {
        stubFor(get(urlPathMatching(PATH_MSVC_CASE_MANAGEMENT_GENERATE_CASE_ID))
                .withHeader(BRAND_HEADER, equalTo(BRAND_DEFAULT))
                .withQueryParam(CASE_ID_PREFIX_PARAM, equalTo(CASE_ID_PREFIX_VALUE))
                .withQueryParam(CLIENT_ID_PARAM, equalTo(CLIENT_ID_VALUE))
                .willReturn(aResponse().withStatus(HttpStatus.OK.value()).withBody(TEST_CASE_ID)));

        with()
                .get(PATH_GET_CASE_ID)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(MEDIA_TYPE_TEXT_PLAIN_UTF8.toString())
                .body(containsString(TEST_CASE_ID));
    }

    @Test
    void getCaseIdValidRequestClientServerUnavailableReturnsInternalServerError() {
        stubFor(get(urlPathMatching(PATH_MSVC_CASE_MANAGEMENT_GENERATE_CASE_ID))
                .withHeader(BRAND_HEADER, equalTo(BRAND_DEFAULT))
                .withQueryParam(CASE_ID_PREFIX_PARAM, equalTo(CASE_ID_PREFIX_VALUE))
                .withQueryParam(CLIENT_ID_PARAM, equalTo(CLIENT_ID_VALUE))
                .willReturn(aResponse().withStatus(HttpStatus.SERVICE_UNAVAILABLE.value()).withBody("expected")));

        with()
                .get(PATH_GET_CASE_ID)
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void saveCaseValidRequestSendsPostToCreateCase() throws IOException {
        CaseApplication request = readCaseApplicationFromResource(saveCaseCreateRequest);
        CaseApplication expectedResponse = readCaseApplicationFromResource(saveCaseCreateResponse);

        CaseApplication result = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_SAVE_CASE)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        assertThat(result).isEqualTo(expectedResponse);
    }

    @Test
    void saveCaseValidRequestSendsPutToUpdateCase() throws IOException {
        // When updating a case, CaseServiceImpl first gets the current case data.
        // Need to stub a non-null response for the GET request to prevent NPE when saving a case.
        String emptyCaseResponseJson = "{\"caseId\": \"any-case-id\"}";
        String getCasePattern = "/v2/cases/" + TEST_CASE_ID;

        stubFor(get(urlPathMatching(getCasePattern))
                .withHeader(BRAND_HEADER, equalTo(BRAND_DEFAULT))
                .willReturn(
                        aResponse()
                                .withStatus(HttpStatus.OK.value())
                                .withHeaders(new HttpHeaders(new HttpHeader("Content-Type", "application/json")))
                                .withBody(emptyCaseResponseJson)));

        CaseApplication request = readCaseApplicationFromResource(saveCaseUpdateRequest);
        CaseApplication expectedResponse = readCaseApplicationFromResource(saveCaseUpdateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_SAVE_CASE);

        log.info(response.body().asPrettyString());

        CaseApplication result = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(CaseApplication.class);

        assertThat(result).isEqualTo(expectedResponse);
    }
}
