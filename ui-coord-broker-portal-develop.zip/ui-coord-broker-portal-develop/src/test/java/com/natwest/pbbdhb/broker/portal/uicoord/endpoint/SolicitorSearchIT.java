package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.SolicitorSearchClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchCriteria;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchResults;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class SolicitorSearchIT {

    private static final String SOLICITOR_SERVICE_NAME = "msvc-solicitor";

    @Value("${msvc.solicitor.search.url}")
    private String solicitorSearchServiceEndpoint;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Autowired
    private SolicitorSearchClient solicitorSearchClient;

    @Autowired
    private TokenConfiguration tokenConfig;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void solicitorPostcodeSearchReturnsSolicitorList() {
        log.info("sending search query");
        Response solicitorSearchResponse = with()
                .queryParam(SEARCH_FOR_PARAM, "EH6")
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_SOLICITOR_SEARCH);

        log.info(solicitorSearchResponse.body().asPrettyString());

        ParameterizedTypeReference<List<Solicitor>> solicitorListTypeRef = new ParameterizedTypeReference<List<Solicitor>>() {};
        List<Solicitor> solicitorList = solicitorSearchResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(solicitorListTypeRef.getType());


        assertThat(solicitorList.size()).isGreaterThan(0);
    }

    @Test
    public void solicitorCompanyNameSearchReturnsSolicitorList() {
        log.info("sending search query");
        Response solicitorSearchResponse = with()
                .queryParam(SEARCH_FOR_PARAM, "water")
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_SOLICITOR_SEARCH);

        log.info(solicitorSearchResponse.body().asPrettyString());

        ParameterizedTypeReference<List<Solicitor>> solicitorListTypeRef = new ParameterizedTypeReference<List<Solicitor>>() {};
        List<Solicitor> solicitorList = solicitorSearchResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(solicitorListTypeRef.getType());


        assertThat(solicitorList.size()).isGreaterThan(0);
    }

    @Test
    public void solicitorServiceDirectTest() {
        RestAssured.port = 443;

        SolicitorSearchCriteria searchCriteria = new SolicitorSearchCriteria();
        searchCriteria.setPostCode("EH6");

        Response solicitorServiceResponse = with()
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, SOLICITOR_SERVICE_NAME))
                .contentType(APPLICATION_JSON_VALUE)
                .body(searchCriteria)
                .post(solicitorSearchServiceEndpoint);

        log.info(solicitorServiceResponse.body().asPrettyString());


        SolicitorSearchResults searchResults = solicitorServiceResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .extract()
                .as(SolicitorSearchResults.class);

        assertThat(searchResults.getSolicitors().size()).isGreaterThan(0);
    }
}
