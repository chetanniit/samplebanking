package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.getNewCaseId;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_PRODUCT_VALIDATION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SAVE_CASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.readCaseApplicationFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.io.IOException;
import java.time.LocalDate;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class ProductValidationIT {

  @Value("classpath:test-files/product-validation/save-case-create-request-for-product-validation.json")
  private Resource saveCaseCreateRequestForProductValidation;

  @Value("${server.servlet.context-path}")
  private String contextPath;

  @Value("${msvc.product.validation.url}")
  private String productValidationEndpoint;

  @LocalServerPort
  private int port;

  @Autowired
  private TokenConfiguration tokenConfig;

  @MockBean
  private BrokerInfoClient brokerInfoClient;

  @BeforeEach
  public void setUp() {
    RestAssured.baseURI = "http://localhost" + contextPath;
    RestAssured.port = this.port;
    when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
  }

  @AfterEach
  public void cleanUp() {
    RestAssured.baseURI = RestAssured.DEFAULT_URI;
    RestAssured.port = RestAssured.UNDEFINED_PORT;
  }

  @Test
  public void validateProduct() throws IOException {

    String caseId = getNewCaseId(tokenConfig);
    assertThat(caseId).isNotEmpty();

    CaseApplication createRequest = readCaseApplicationFromResource(
        saveCaseCreateRequestForProductValidation);
    // needs to match productCode in the json
    String productCode = "FO48758";
    // needs to match productSelectedDate in the json
    LocalDate productSelectionDate = LocalDate.of(2024, 9, 10);
    with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .contentType(APPLICATION_JSON_VALUE)
        .body(createRequest)
        .put(PATH_SAVE_CASE);

    Response productValidationHttpResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_PRODUCT_VALIDATION, caseId);

    ProductValidationResponse productValidationResponse = productValidationHttpResponse
        .then()
        .statusCode(HttpStatus.OK.value())
        .extract()
        .as(ProductValidationResponse.class);

    assertThat(productValidationResponse).isNotNull();
    assertThat(productValidationResponse.getValidProduct()).isTrue();
    assertThat(productValidationResponse.getProductCode()).isEqualTo(productCode);
    assertThat(productValidationResponse.getProductSelectionDate()).isEqualTo(productSelectionDate);
  }

  @Test
  public void validateProduct_firstTimeBuyer() throws IOException {

    String caseId = getNewCaseId(tokenConfig);
    assertThat(caseId).isNotEmpty();

    CaseApplication createRequest = readCaseApplicationFromResource(
        saveCaseCreateRequestForProductValidation);
    createRequest.setFirstTimeBuyer(true);
    // needs to match productCode in the json
    String productCode = "FO48758";
    // needs to match productSelectedDate in the json
    LocalDate productSelectionDate = LocalDate.of(2024, 9, 10);
    with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .contentType(APPLICATION_JSON_VALUE)
        .body(createRequest)
        .put(PATH_SAVE_CASE);

    Response productValidationHttpResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_PRODUCT_VALIDATION, caseId);

    ProductValidationResponse productValidationResponse = productValidationHttpResponse
        .then()
        .statusCode(HttpStatus.OK.value())
        .extract()
        .as(ProductValidationResponse.class);

    assertThat(productValidationResponse).isNotNull();
    assertThat(productValidationResponse.getValidProduct()).isTrue();
    assertThat(productValidationResponse.getProductCode()).isEqualTo(productCode);
    assertThat(productValidationResponse.getProductSelectionDate()).isEqualTo(productSelectionDate);
  }
}
