package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_BROKER_BASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_DECLARATION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.FirmDto;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class GetBrokerDeclarationIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoResponseDto.builder()
                .broker(BrokerDetailsDto.builder()
                    .username("Test0123")
                    .firstName("Test")
                    .lastName("World")
                    .brokerPostcode("SN14 6JL")
                    .emailAddress("snehalata.nayak@natwest.com")
                    .build())
                .firm(FirmDto.builder()
                    .fcaNumber("953055")
                    .build())
            .build());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void getBrokerDeclarationReturnsHtml() throws IOException {
        String brokerDeclarationResponse = with()
            .log().all()
            .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
            .get(PATH_BROKER_BASE + PATH_GET_BROKER_DECLARATION)
            .thenReturn()
            .prettyPrint();

        assertThat(brokerDeclarationResponse).contains("<h2>The Direct Debit Guarantee</h2>");
    }

    @Test
    public void getBrokerDeclarationInvalidJwt401() throws IOException {
        with()
            .log().all()
            .get(PATH_BROKER_BASE + PATH_GET_BROKER_DECLARATION)
            .then()
            .statusCode(401);
    }

}
