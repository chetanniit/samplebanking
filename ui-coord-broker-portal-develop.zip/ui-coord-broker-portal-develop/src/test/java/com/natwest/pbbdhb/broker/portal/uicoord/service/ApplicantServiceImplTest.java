package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.NapoliApplicantMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.NapoliApplicantMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.PersonalAddressMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.NapoliPersonalDetailsMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.ApplicantServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.AdditionalAnswers.returnsSecondArg;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        NapoliApplicantMapperImpl.class,
        NapoliPersonalDetailsMapperImpl.class,
        PersonalAddressMapperImpl.class
})
class ApplicantServiceImplTest {

    @Mock
    private ApplicantClientNapoli mockApplicantClient;

    @Mock
    private UserClaimsProvider userClaimsProvider;

    @Autowired
    private NapoliApplicantMapper napoliApplicantMapper;

    ArgumentCaptor<ApplicantDto> applicantDtoCaptor = ArgumentCaptor.forClass(ApplicantDto.class);

    @Test
    void saveApplicantsSendsSingleApplicantToClient() {
        List<Applicant> applicants = createValidApplicants(1);
        Applicant applicant = applicants.get(0);
        Map<String, String> workStatusMap = WorkStatusHelper.applicantsWorkStatusMap(applicants, null);
        ApplicantDto applicantDto = napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, null, applicant);

        ApplicantService applicantService = new ApplicantServiceImpl(mockApplicantClient,
            napoliApplicantMapper, userClaimsProvider);
        when(mockApplicantClient.saveApplicant(eq(BRAND_DEFAULT), applicantDtoCaptor.capture())).then(returnsSecondArg());

        assertEquals(applicants, applicantService.saveApplicants(BRAND_DEFAULT, TEST_CASE_ID, applicants, workStatusMap));

        verify(mockApplicantClient).saveApplicant(eq(BRAND_DEFAULT), applicantDtoCaptor.capture());
        assertThat(applicantDtoCaptor.getValue()).usingRecursiveComparison().isEqualTo(applicantDto);
    }

    @Test
    void saveApplicantsSendsMultipleApplicantsToClient() {
        List<Applicant> applicants = createValidApplicants(2);
        Applicant firstApplicant = applicants.get(0);
        Applicant secondApplicant = applicants.get(1);
        Map<String, String> workStatusMap = WorkStatusHelper.applicantsWorkStatusMap(applicants, null);
        ApplicantDto firstApplicantDto = napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, null, firstApplicant);
        ApplicantDto secondApplicantDto = napoliApplicantMapper.toApplicantDto(TEST_CASE_ID, null, secondApplicant);

        ApplicantService applicantService = new ApplicantServiceImpl(mockApplicantClient,
            napoliApplicantMapper, userClaimsProvider);

        when(mockApplicantClient.saveApplicant(eq(BRAND_DEFAULT), applicantDtoCaptor.capture())).then(returnsSecondArg());

        assertEquals(applicants, applicantService.saveApplicants(BRAND_DEFAULT, TEST_CASE_ID, applicants, workStatusMap));

        verify(mockApplicantClient, times(2)).saveApplicant(eq(BRAND_DEFAULT), applicantDtoCaptor.capture());

        assertThat(applicantDtoCaptor.getAllValues().get(0)).usingRecursiveComparison().isEqualTo(firstApplicantDto);
        assertThat(applicantDtoCaptor.getAllValues().get(1)).usingRecursiveComparison().isEqualTo(secondApplicantDto);
    }
}
