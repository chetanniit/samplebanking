package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.getNewCaseId;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SAVE_BROKER_CASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.readBrokerCaseFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class SaveBrokerCaseIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/broker-cases/create-broker-case-request.json")
    private Resource createBrokerCaseRequest;

    @Value("classpath:test-files/broker-cases/create-broker-case-request-journey-data-check.json")
    private Resource createBrokerCaseRequestJourneyDataCheck;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void createBrokerCaseSucceeds() throws IOException {
        BrokerCase brokerCase = readBrokerCaseFromResource(createBrokerCaseRequest);
        // Ensure case version is null, as this is how the API decides if it is a new case
        brokerCase.getCaseApplication().setVersion(null);

        String caseId = getNewCaseId(tokenConfig);

        Response httpResponse = sendSaveCaseRequest(brokerCase, caseId);
        BrokerCase brokerCaseResponse = httpResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        assertNotNull(brokerCaseResponse);
    }

    // This test helps ensure that the permission checks applied on updating a case can't be
    // bypassed by submitting updates to an existing case in a request that looks like a new case because
    // it is missing a case version.
    @Test
    void createBrokerCaseTwiceWithSameCaseIdReturns400() throws IOException {
        BrokerCase brokerCase = readBrokerCaseFromResource(createBrokerCaseRequest);
        // Ensure case version is null, as this is how the API decides if it is a new case
        brokerCase.getCaseApplication().setVersion(null);

        String caseId = getNewCaseId(tokenConfig);

        Response httpResponse = sendSaveCaseRequest(brokerCase, caseId);
        httpResponse
                .then()
                .statusCode(HttpStatus.OK.value());

        Response secondHttpResponse = sendSaveCaseRequest(brokerCase, caseId);
        secondHttpResponse
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

  @Test
  void createBrokerCase_isLeasehold_savesOk() throws IOException {
    BrokerCase brokerCase = readBrokerCaseFromResource(createBrokerCaseRequest);
    // Ensure case version is null, as this is how the API decides if it is a new case
    brokerCase.getCaseApplication().setVersion(null);
    brokerCase.getCaseApplication().setLeaseholdOwnershipTerm(true);

    String caseId = getNewCaseId(tokenConfig);

    Response httpResponse = sendSaveCaseRequest(brokerCase, caseId);
    BrokerCase brokerCaseResponse = httpResponse
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(BrokerCase.class);

    assertNotNull(brokerCaseResponse);
    assertNotNull(brokerCaseResponse.getCaseApplication());
    Assertions.assertTrue(brokerCase.getCaseApplication().getLeaseholdOwnershipTerm());
  }

  @Test
  void createBrokerCaseSucceedsForNewFieldsInJourneyData() throws IOException {
    BrokerCase brokerCase = readBrokerCaseFromResource(createBrokerCaseRequestJourneyDataCheck);
    // Ensure case version is null, as this is how the API decides if it is a new case
    brokerCase.getCaseApplication().setVersion(null);

    String caseId = getNewCaseId(tokenConfig);

    Response httpResponse = sendSaveCaseRequest(brokerCase, caseId);
    BrokerCase brokerCaseResponse = httpResponse
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(BrokerCase.class);

    assertNotNull(brokerCaseResponse);
  }

  @Test
  void createBrokerCaseTwiceWithSameCaseIdReturns400ForNewFieldsInJourneyData() throws IOException {
    BrokerCase brokerCase = readBrokerCaseFromResource(createBrokerCaseRequestJourneyDataCheck);
    // Ensure case version is null, as this is how the API decides if it is a new case
    brokerCase.getCaseApplication().setVersion(null);

    String caseId = getNewCaseId(tokenConfig);

    Response httpResponse = sendSaveCaseRequest(brokerCase, caseId);
    httpResponse
        .then()
        .statusCode(HttpStatus.OK.value());

    Response secondHttpResponse = sendSaveCaseRequest(brokerCase, caseId);
    secondHttpResponse
        .then()
        .statusCode(HttpStatus.BAD_REQUEST.value());
  }

  @Test
  void createBrokerCase_isLeasehold_savesOk_ForNewFieldsInJourneyData() throws IOException {
    BrokerCase brokerCase = readBrokerCaseFromResource(createBrokerCaseRequestJourneyDataCheck);
    // Ensure case version is null, as this is how the API decides if it is a new case
    brokerCase.getCaseApplication().setVersion(null);
    brokerCase.getCaseApplication().setLeaseholdOwnershipTerm(true);

    String caseId = getNewCaseId(tokenConfig);

    Response httpResponse = sendSaveCaseRequest(brokerCase, caseId);
    BrokerCase brokerCaseResponse = httpResponse
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(BrokerCase.class);

    assertNotNull(brokerCaseResponse);
    assertNotNull(brokerCaseResponse.getCaseApplication());
    Assertions.assertTrue(brokerCase.getCaseApplication().getLeaseholdOwnershipTerm());
  }

  private Response sendSaveCaseRequest(BrokerCase brokerCase, String caseId) {
    return with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .contentType(APPLICATION_JSON_VALUE)
        .body(brokerCase)
        .put(PATH_SAVE_BROKER_CASE);
  }
}
