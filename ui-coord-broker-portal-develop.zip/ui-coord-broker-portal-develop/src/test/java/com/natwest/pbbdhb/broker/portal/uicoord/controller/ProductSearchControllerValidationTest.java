package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Product;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ProductSearchService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ProductSearchTestUtil.createValidListProducts;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ProductSearchTestUtil.createValidProductSearchRequest;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = {ProductSearchController.class, ControllerAdvice.class})
public class ProductSearchControllerValidationTest {

    @MockBean
    private ProductSearchService productSearchService;

    @MockBean
    private UserClaimsProvider userClaimsProvider;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void searchProductValidRequest() throws Exception {
        ProductSearchRequest productSearchRequest = createValidProductSearchRequest();
        String requestBodyContent = this.objectMapper.writeValueAsString(productSearchRequest);
        List<Product> productsResponse = createValidListProducts();
        String responseBodyContent = this.objectMapper.writeValueAsString(productsResponse);
        when(productSearchService.search(BRAND_DEFAULT, productSearchRequest)).thenReturn(productsResponse);

        RequestBuilder request = post(PATH_PRODUCT_SEARCH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBodyContent));
    }


    @Test
    public void searchProductWithInvalidBrandHeader() throws Exception {
        ProductSearchRequest productSearchRequest = createValidProductSearchRequest();
        String requestBodyContent = this.objectMapper.writeValueAsString(productSearchRequest);

        String invalidBrand = "INVALID_BRAND";

        RequestBuilder request = post(PATH_PRODUCT_SEARCH)
                .header(BRAND_HEADER, invalidBrand)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBodyContent);

        this.mockMvc.perform(request)
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value("400"))
            .andExpect(jsonPath("$.title").value("Validation Failure"))
            .andExpect(jsonPath("$.description").value("The following validation failures occurred"))
            .andExpect(jsonPath("$.errors[0].title").value("productSearch.brand"))
            .andExpect(jsonPath("$.errors[0].description").value("The brand name is invalid"));

        verifyNoInteractions(productSearchService);
    }


    @Test
    public void searchProductInvalidContentTypeReturnsUnsupportedMediaTypeError() throws Exception {
        RequestBuilder request = post(PATH_PRODUCT_SEARCH)
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .content("text");

        this.mockMvc.perform(request)
                .andExpect(status().isUnsupportedMediaType());
    }

}
