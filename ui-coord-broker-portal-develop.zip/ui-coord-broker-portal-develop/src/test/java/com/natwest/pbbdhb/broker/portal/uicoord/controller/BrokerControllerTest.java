package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_BROKER_BASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_DECLARATION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_PAYMENT_PATHS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_PRODUCT_SWITCH;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PAYMENT_PATH_NAME_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.PAYMENT_PATH_NAME_TEST;
import static io.restassured.RestAssured.with;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.JwtGeneratorUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.io.IOException;
import java.util.UUID;

import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.StringUtils;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
@ActiveProfiles(profiles = {"integration", "userclaims"})
@Slf4j
class BrokerControllerTest {

  private static final String CLAIMSETJWT_HEADER = "iam-claimsetjwt";

  private static final String CORRELATION_ID = UUID.randomUUID().toString();
  private static final String INTERNAL_CORRELATION_ID = UUID.randomUUID().toString();

  @Value("${server.servlet.context-path}")
  private String contextPath;

  @LocalServerPort
  private int port;

  @Value("classpath:test-files/broker/payment-paths-response.json")
  private Resource paymentPathsRequestResponse;

  @Value("classpath:test-files/broker/broker-product-switch-details.json")
  private Resource brokerProductSwitchDetails;

  @Value("classpath:test-files/broker/broker-declaration.html")
  private Resource brokerDeclaration;

  @MockBean
  private BrokerInfoService brokerInfoService;

  @BeforeEach
  public void setUp() {
    RestAssured.baseURI = "http://localhost";
    RestAssured.port = this.port;
    when(brokerInfoService.getBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfo());
  }

  @AfterEach
  public void cleanUp() {
    RestAssured.baseURI = RestAssured.DEFAULT_URI;
    RestAssured.port = RestAssured.UNDEFINED_PORT;
  }

  @Test
  void getPaymentPathsRequestReturnsCorrectPaymentPaths() throws IOException, JSONException {

    String expectedResponseJson = TestUtil.getResourceText(paymentPathsRequestResponse);

    Response paymentPathsResponse = with().header(CLAIMSETJWT_HEADER,
            JwtGeneratorUtil.createBrokerJwt())
        .get(contextPath + PATH_BROKER_BASE + PATH_GET_BROKER_PAYMENT_PATHS);

    log.info(paymentPathsResponse.body().asPrettyString());

    JSONCompareResult compareResult = JSONCompare.compareJSON(expectedResponseJson,
        paymentPathsResponse.body().asPrettyString(), JSONCompareMode.STRICT);
    assertTrue(compareResult.passed(), compareResult.getMessage());
  }

  @Test
  void getBrokerProductSwitchDetails() throws IOException, JSONException {
    String expectedResponseJson = TestUtil.getResourceText(brokerProductSwitchDetails);
    Response response = with().header(CLAIMSETJWT_HEADER,
                    JwtGeneratorUtil.createBrokerJwt())
                    .param(PAYMENT_PATH_NAME_PARAM, PAYMENT_PATH_NAME_TEST)
                    .get(contextPath + PATH_BROKER_BASE + PATH_GET_BROKER_PRODUCT_SWITCH);

    log.info(response.body().asPrettyString());

    JSONCompareResult compareResult = JSONCompare.compareJSON(expectedResponseJson,
            response.body().asPrettyString(), JSONCompareMode.STRICT);
    assertTrue(compareResult.passed(), compareResult.getMessage());
  }

  @Test
  void getBrokerDeclaration() throws IOException {
    String expectedResponse = TestUtil.getResourceText(brokerDeclaration);
    Response response = with().header(CLAIMSETJWT_HEADER,
            JwtGeneratorUtil.createBrokerJwt())
        .get(contextPath + PATH_BROKER_BASE + PATH_GET_BROKER_DECLARATION);

    log.info(response.body().asPrettyString());

    assertEquals(200, response.getStatusCode());
    assertEquals(StringUtils.trimAllWhitespace(expectedResponse),
        StringUtils.trimAllWhitespace(response.prettyPrint()));
  }
}
