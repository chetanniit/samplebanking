package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    BrokerInfoMapperImpl.class
})
public class BrokerInfoMapperTest {
  
  @Autowired
  BrokerInfoMapper mapper;

  @Test
  public void toBrokerInfoTest() {

    final BrokerInfoResponseDto brokerInfoResponseDto = BrokerInfoTestUtil.brokerInfoDto();
    final BrokerInfo broker = mapper.toBroker(brokerInfoResponseDto);

    assertThat(broker).isEqualTo(BrokerInfoTestUtil.brokerInfo());
  }

  @Test
  public void toBrokerInfoTestRemovesPhoneNumberSpaces() {

    final BrokerInfoResponseDto brokerInfoResponseDto = BrokerInfoTestUtil.brokerInfoDto();
    brokerInfoResponseDto.getBroker().setMobileNumber("011 22222");
    brokerInfoResponseDto.getBroker().setBusinessPhone(" 022 33333 ");

    final BrokerInfo expectedBrokerInfo = BrokerInfoTestUtil.brokerInfo();
    expectedBrokerInfo.getBrokerDetails().setMobilePhone("01122222");
    expectedBrokerInfo.getBrokerDetails().setOtherPhone("02233333");

    final BrokerInfo broker = mapper.toBroker(brokerInfoResponseDto);

    assertThat(broker).isEqualTo(expectedBrokerInfo);
  }
}
