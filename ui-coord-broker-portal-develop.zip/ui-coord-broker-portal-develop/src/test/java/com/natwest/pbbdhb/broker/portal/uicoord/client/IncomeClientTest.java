package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidIncomeDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidatedCaseIncomeDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.constructExpectedHeaders;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IncomeClientTest {

    private static final String TEST_ENDPOINT_GET = "http://test.endpoint/income/{caseId}";
    private static final String TEST_ENDPOINT_SAVE = "http://test.endpoint/income/{caseId}";

    @Mock
    private RestTemplate mockRestTemplate;

    private IncomeClient incomeClient;

    @BeforeEach
    void setUp() {
        this.incomeClient = new IncomeClient(TEST_ENDPOINT_GET, TEST_ENDPOINT_SAVE, mockRestTemplate);
    }

    @Test
    void saveIncomeMakesPutCallWhenVersionMissing() {
        CaseIncomeDto incomeDtoToSave = createValidIncomeDto();
        incomeDtoToSave.setVersion(null);

        ValidatedCaseIncomeDto expectedIncomeDtoResponse = createValidatedCaseIncomeDto();
        ResponseEntity<ValidatedCaseIncomeDto> expectedResponseEntity = ResponseEntity.ok(expectedIncomeDtoResponse);
        HttpEntity<CaseIncomeDto> expectedHttpEntity = new HttpEntity<>(incomeDtoToSave, constructExpectedHeaders());
        URI expectedEndpoint = URI.create(TEST_ENDPOINT_SAVE.replace("{caseId}", TEST_CASE_ID));
        when(mockRestTemplate.exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, ValidatedCaseIncomeDto.class))
                .thenReturn(expectedResponseEntity);

        ValidatedCaseIncomeDto
                incomeDtoResponse = this.incomeClient.saveIncome(BRAND_DEFAULT, TEST_CASE_ID, incomeDtoToSave);

        verify(mockRestTemplate).exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, ValidatedCaseIncomeDto.class);
    }

    @Test
    void saveIncomeMakesPutCallWhenVersionPresent() {
        CaseIncomeDto incomeDtoToSave = createValidIncomeDto();

        ValidatedCaseIncomeDto expectedIncomeDtoResponse = createValidatedCaseIncomeDto();
        ResponseEntity<ValidatedCaseIncomeDto> expectedResponseEntity = ResponseEntity.ok(expectedIncomeDtoResponse);
        HttpEntity<CaseIncomeDto> expectedHttpEntity = new HttpEntity<>(incomeDtoToSave, constructExpectedHeaders());
        URI expectedEndpoint = URI.create(TEST_ENDPOINT_SAVE.replace("{caseId}", TEST_CASE_ID));
        when(mockRestTemplate.exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, ValidatedCaseIncomeDto.class))
                .thenReturn(expectedResponseEntity);

        ValidatedCaseIncomeDto incomeDtoResponse = this.incomeClient.saveIncome(BRAND_DEFAULT, TEST_CASE_ID, incomeDtoToSave);

        verify(mockRestTemplate).exchange(expectedEndpoint, HttpMethod.PUT, expectedHttpEntity, ValidatedCaseIncomeDto.class);
    }

    @Test
    void saveIncomeBadRequestErrorFromSaveIsPassedToCaller() {
        CaseIncomeDto incomeDtoToSave = createValidIncomeDto();

        HttpClientErrorException badRequestException = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.getReasonPhrase(), new HttpHeaders(), null, null);

        when(mockRestTemplate.exchange(any(URI.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(ValidatedCaseIncomeDto.class)))
                .thenThrow(badRequestException);

        assertThat(catchThrowable(() -> incomeClient.saveIncome(BRAND_DEFAULT, TEST_CASE_ID, incomeDtoToSave)))
                .isInstanceOf(HttpClientErrorException.BadRequest.class)
                .hasMessage("400 Bad Request");
    }

    @Test
    void getIncomeReturnsNullOn404Error() {
        HttpClientErrorException notFoundException = HttpClientErrorException.create(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.getReasonPhrase(), new HttpHeaders(), null, null);
        when(mockRestTemplate.exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class))).thenThrow(notFoundException);

        ValidatedCaseIncomeDto incomeDto = incomeClient.getIncome(BRAND_DEFAULT, TEST_CASE_ID);
        assertNull(incomeDto);
    }
}
