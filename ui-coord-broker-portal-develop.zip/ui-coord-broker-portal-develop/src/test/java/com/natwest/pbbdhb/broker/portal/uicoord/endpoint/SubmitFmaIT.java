package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BasicAddress;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.EstateAgent;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalAddress.OccupyStatusType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.math.BigDecimal;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import java.util.List;
import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.createBasicBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.saveBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.submitDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.updateBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidDeposits;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.createBrokerCaseForDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.modifyBrokerCaseForDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.FmaTestUtil.updateBrokerCaseForFma;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_PAYMENT_PATH_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class SubmitFmaIT {

  private static final String FMA_SERVICE_NAME = "msvc-full-mortgage-application";

  @Value("${server.servlet.context-path}")
  private String contextPath;

  @LocalServerPort
  private int port;

  @Value("${full.mortgage.application.endpoint}")
  private String fmaEndpoint;

  @Value("${client.id}")
  private String clientId;

  @Value("classpath:fma-test-cases/fma-request/repayment.json")
  private Resource repaymentFmaRequestJson;

  @Autowired
  private TokenConfiguration tokenConfig;

  @MockBean
  private BrokerInfoClient brokerInfoClient;


  @BeforeEach
  public void setUp() {
    RestAssured.baseURI = "http://localhost" + contextPath;
    RestAssured.port = this.port;
    when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
  }

  @AfterEach
  public void cleanUp() {
    RestAssured.baseURI = RestAssured.DEFAULT_URI;
    RestAssured.port = RestAssured.UNDEFINED_PORT;
  }

  @Test
  void submitFmaSucceeds() {
    BrokerCase brokerCaseForDip = createBrokerCaseForDip(tokenConfig);
    String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

    submitDip(caseId, tokenConfig);

    BrokerCase brokerCaseForFma = updateBrokerCaseForFma(brokerCaseForDip, tokenConfig);

    // TODO: Submit broker case data as part of triggering FMA submission.
    BrokerCase brokerCaseSavedForFma = saveBrokerCase(caseId, brokerCaseForFma, tokenConfig);

    // Submit FMA
    Response submitFmaResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
// TODO: Submit broker case data as part of triggering FMA submission.
//                .contentType(APPLICATION_JSON_VALUE)
//                .body(brokerCaseForFma)
        .post(PATH_SUBMIT_FMA);

    log.info(submitFmaResponse.body().asPrettyString());

    submitFmaResponse.then().statusCode(202);
  }

  @Test
  void submitFmaMapsConsolidationAmount() {
    BrokerCase brokerCaseForDip = createBasicBrokerCase(tokenConfig);
    modifyBrokerCaseForDip(brokerCaseForDip);

    ExpenseTransaction expenseTransaction = brokerCaseForDip.getExpense().getApplicants().get(0).getTransactions().get("transaction1");
    expenseTransaction.setCategoryCode("LOANS_CAR");
    expenseTransaction.setFrequency("MONTHLY");
    expenseTransaction.setRedeemedOrLessThanSixMonths(true);
    expenseTransaction.setAmount(new BigDecimal(400));
    expenseTransaction.setOutstandingBalance(new BigDecimal(800));
    expenseTransaction.setConsolidationAmount(new BigDecimal(400));

    Mortgage mortgage = brokerCaseForDip
        .getCaseApplication().getMortgage();
    mortgage.setPropertyValue(500_000);
    mortgage.setPurchasePrice(500_000);
    mortgage.setDeposits(createValidDeposits(100_000L));
    mortgage.setMortgageAmount(500_000 - 100_000);

    brokerCaseForDip = updateBrokerCase(brokerCaseForDip, tokenConfig);
    String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

    submitDip(caseId, tokenConfig);

    BrokerCase brokerCaseForFma = updateBrokerCaseForFma(brokerCaseForDip, tokenConfig);

    saveBrokerCase(caseId, brokerCaseForFma, tokenConfig);

    // Submit FMA
    Response submitFmaResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_SUBMIT_FMA);

    log.info(submitFmaResponse.body().asPrettyString());

    submitFmaResponse.then().statusCode(202);
  }

  @Test
  @Disabled
  public void submitFmaDirectTest() throws IOException {
    RestAssured.port = 443;

    String fmaApplication = getResourceText(repaymentFmaRequestJson);

    log.info("calling " + fmaEndpoint + " to submit FMA...");

    Response submitFmaResponse = with()
        .header(BRAND_HEADER, BRAND_DEFAULT)
        .header("client_id", clientId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig, FMA_SERVICE_NAME))
        .contentType(APPLICATION_JSON_VALUE)
        .body(fmaApplication)
        .post(fmaEndpoint);

    log.info(submitFmaResponse.body().asPrettyString());

    int statusCode = submitFmaResponse.getStatusCode();
    assertTrue(statusCode == 201 || statusCode == 202);
  }


  @Test
  void submitFmaGives400ResponseWhenPaymentPathIsInvalid() {
    BrokerCase brokerCaseForDip = createBrokerCaseForDip(tokenConfig);
    String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

    submitDip(caseId, tokenConfig);

    BrokerCase brokerCaseForFma = updateBrokerCaseForFma(brokerCaseForDip, tokenConfig);
    brokerCaseForFma.getCaseApplication().getBroker()
        .setPaymentPath(123456); //Set to invalid payment path

    BrokerCase brokerCaseSavedForFma = saveBrokerCase(caseId, brokerCaseForFma, tokenConfig);

    // Submit FMA
    Response submitFmaResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_SUBMIT_FMA);

    log.info(submitFmaResponse.body().asPrettyString());

    submitFmaResponse.then().statusCode(400);
  }

  @Test
  void submitFmaGives400ResponseWhenExistingMortgageIsMissingAndOccupyStatusIsOwnerMortgaged() {
    BrokerCase brokerCaseForDip = createBrokerCaseForDip(tokenConfig);
    String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

    submitDip(caseId, tokenConfig);

    BrokerCase brokerCaseForFma = updateBrokerCaseForFma(brokerCaseForDip, tokenConfig);
    brokerCaseForFma.getApplicants().get(0).getAddresses().get(0).setOccupyStatus(OccupyStatusType.OWNER_MORTGAGED.value());
    brokerCaseForFma.getApplicants().get(0).setExistingMortgages(null);
    saveBrokerCase(caseId, brokerCaseForFma, tokenConfig);

    // Submit FMA
    Response submitFmaResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_SUBMIT_FMA);

    log.info(submitFmaResponse.body().asPrettyString());

    ValidationResponse response = submitFmaResponse.then()
        .statusCode(400)
        .contentType(ContentType.JSON).extract().as(ValidationResponse.class);
    assertEquals(response.getTitle(), "FMA Submit Validation Errors");

    List<ValidationResponseDetail> errors = response.getError();
    assertFalse(errors.isEmpty());
    ValidationResponseDetail error = errors.get(0);
    assertEquals(error.getMessage(), "Missing Existing Mortgages Validation Exception");
    assertEquals(error.getCode(), "MISSING_EXISTING_MORTGAGES");
    assertEquals(error.getStatus(), 400);

  }

  @Test
  void submitFma400ResponseForValidationErrorCanBeResolvedWithoutPaymentPathIssues() {
    BrokerCase brokerCaseForDip = createBrokerCaseForDip(tokenConfig);
    String caseId = brokerCaseForDip.getCaseApplication().getCaseId();

    submitDip(caseId, tokenConfig);
    BrokerCase brokerCaseForFma = updateBrokerCaseForFma(brokerCaseForDip, tokenConfig);

    //Add an invalid estate agent
    BasicAddress addr = new BasicAddress();
    addr.setHouseNumber("1");
    addr.setStreet("Street");
    addr.setTown("Town");
    addr.setCountry("US");
    addr.setPostcode(null);
    EstateAgent estateAgent = new EstateAgent();
    estateAgent.setAgencyName("any name");
    estateAgent.setAddress(addr);
    estateAgent.setTelephoneNumber("01234567812345");
    brokerCaseForFma.getCaseApplication().setEstateAgent(estateAgent);

    brokerCaseForFma.getCaseApplication().getEstateAgent().getAddress().setCountry("US");

    saveBrokerCase(caseId, brokerCaseForFma, tokenConfig);

    // Submit FMA
    Response submitFmaResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_SUBMIT_FMA);

    log.info(submitFmaResponse.body().asPrettyString());

    submitFmaResponse.then().statusCode(anyOf(is(400), is(500)));

    //GET THE NOW SAVED BROKER
    BrokerCase brokerCaseResponse = with()
        .log().all()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .get(PATH_GET_BROKER_CASE)
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(BrokerCase.class);

    assertEquals(TEST_PAYMENT_PATH_ID,
        brokerCaseResponse.getCaseApplication().getBroker().getPaymentPath());
    assertEquals("US",
        brokerCaseResponse.getCaseApplication().getEstateAgent().getAddress().getCountry());

    //MAKE IT VALID
    brokerCaseResponse.getCaseApplication().getEstateAgent().getAddress().setCountry("GB");
    brokerCaseResponse.getCaseApplication().getEstateAgent().getAddress().setPostcode("LA1 4DQ");
    BrokerCase brokerCaseResaved = saveBrokerCase(caseId, brokerCaseResponse, tokenConfig);

    assertEquals("GB",
        brokerCaseResaved.getCaseApplication().getEstateAgent().getAddress().getCountry());
    assertEquals("LA1 4DQ",
        brokerCaseResaved.getCaseApplication().getEstateAgent().getAddress().getPostcode());

    // ReSubmit FMA
    submitFmaResponse = with()
        .pathParam(CASE_ID_PARAM, caseId)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .post(PATH_SUBMIT_FMA);

    log.info(submitFmaResponse.body().asPrettyString());

    int statusCode = submitFmaResponse.getStatusCode();
    assertTrue(statusCode == 201 || statusCode == 202);


  }


}
