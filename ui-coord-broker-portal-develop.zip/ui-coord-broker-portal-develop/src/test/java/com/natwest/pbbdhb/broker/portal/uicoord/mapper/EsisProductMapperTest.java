package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.enums.RepaymentType.REPAYMENT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.EsisTestUtil.productDtoSample;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.EsisTestUtil.productSample;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.RepaymentType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisBorrowingRequirements;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisRepaymentDetails;
import com.rbs.pbbdhb.sales.esis.models.ErcItem;
import com.rbs.pbbdhb.sales.esis.models.Product;
import com.rbs.pbbdhb.sales.esis.models.enums.ProductType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    EsisProductMapper.class
})
@Slf4j
class EsisProductMapperTest {

  @Autowired
  private EsisProductMapper esisMapper;

  @Test
  void mapToEsisProducts_handlesMortgageType_capitalAndInterest() {
    final EsisData esisData = new EsisData();
    final ProductDto product = productDtoSample();
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(REPAYMENT.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final List<Product> actual = this.esisMapper.mapToEsisProducts(esisData);
    assertThat(actual).isEqualTo(singletonList(Product.builder()
        .feeAddedToLoan(false)
        .loanAmount(BigDecimal.valueOf(200000))
        .calculationType("REPAYMENT")
        .termMonths(0)
        .termYears(25)
        .productSelectionDate(LocalDate.of(2023, 2, 23))
        .initialInterestRate(new BigDecimal("4.98"))
        .svr(new BigDecimal("6.24"))
        .baseRate(new BigDecimal("3.50"))
        .productCode("FO35635")
        .productName("2 year fixed rate")
        .productEndDate(LocalDate.of(2025, 5, 31))
        .productType("FIXED")
        .productTerm("TWO_YEAR")
        .ltv(new BigDecimal("80.00"))
        .productFee(new BigDecimal("995"))
        .valuationFee(new BigDecimal("1234"))
        .chapsFee(new BigDecimal("30"))
        .cashBackValue(new BigDecimal("0"))
        .erc(Arrays.asList(
            ErcItem.builder()
                .seqNo(1)
                .endDate(LocalDate.of(2024, 5, 31))
                .percentage(new BigDecimal("1.500"))
                .build(),
            ErcItem.builder()
                .seqNo(2)
                .endDate(LocalDate.of(2025, 5, 31))
                .percentage(new BigDecimal("0.7500"))
                .build()
        ))
        .freeLegal(false)
        .build()));
  }

  @Test
  void mapToEsisProducts_handlesMortgageType_interestOnly() {
    final EsisData esisData = new EsisData();
    final ProductDto product = productDtoSample();
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(RepaymentType.INTEREST_ONLY.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final List<Product> actual = this.esisMapper.mapToEsisProducts(esisData);
    final Product expected = productSample();
    expected.setCalculationType("INTEREST_ONLY");
    expected.setBaseRate(new BigDecimal("3.50"));
    expected.setFreeLegal(false);
    assertThat(actual).isEqualTo(singletonList(expected));
  }

  @Test
  void mapToEsisProducts_handlesMortgageType_mixed() {
    final EsisData esisData = new EsisData();
    final ProductDto product = productDtoSample();
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(RepaymentType.MIXED.toString());
    repaymentDetails.setAmountCapital(new BigDecimal("110000"));
    repaymentDetails.setTermYears(21);
    repaymentDetails.setTermMonths(1);
    repaymentDetails.setInterestOnlyAmount(new BigDecimal("90000"));
    repaymentDetails.setInterestOnlyTermYears(19);
    repaymentDetails.setInterestOnlyTermMonths(2);

    final List<Product> actual = this.esisMapper.mapToEsisProducts(esisData);

    final Product repaymentProduct = productSample();
    repaymentProduct.setLoanAmount(BigDecimal.valueOf(110000));
    repaymentProduct.setCalculationType("REPAYMENT");
    repaymentProduct.setTermYears(21);
    repaymentProduct.setTermMonths(1);
    repaymentProduct.setBaseRate(new BigDecimal("3.50"));
    repaymentProduct.setFreeLegal(false);

    final Product interestOnlyProduct = productSample();
    interestOnlyProduct.setLoanAmount(BigDecimal.valueOf(90000));
    interestOnlyProduct.setCalculationType("INTEREST_ONLY");
    interestOnlyProduct.setTermYears(19);
    interestOnlyProduct.setTermMonths(2);
    interestOnlyProduct.setProductFee(new BigDecimal("0"));
    interestOnlyProduct.setValuationFee(new BigDecimal("0"));
    interestOnlyProduct.setChapsFee(new BigDecimal("0"));
    interestOnlyProduct.setCashBackValue(null);
    interestOnlyProduct.setBaseRate(new BigDecimal("3.50"));
    interestOnlyProduct.setFreeLegal(false);

    assertThat(actual).isEqualTo(Arrays.asList(repaymentProduct, interestOnlyProduct));
  }

  @Test
  void mapToEsisProducts_handlesMortgageType_mixed_withoutDuplicatingCashback() {

    // a product with cashback of 10
    final ProductDto product = productDtoSample();
    product.setCashBackValue(BigDecimal.TEN);

    final EsisData esisData = new EsisData();
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(RepaymentType.MIXED.toString());
    repaymentDetails.setAmountCapital(new BigDecimal("110000"));
    repaymentDetails.setTermYears(21);
    repaymentDetails.setTermMonths(1);
    repaymentDetails.setInterestOnlyAmount(new BigDecimal("90000"));
    repaymentDetails.setInterestOnlyTermYears(19);
    repaymentDetails.setInterestOnlyTermMonths(2);

    final List<Product> actual = this.esisMapper.mapToEsisProducts(esisData);

    final Product repaymentProduct = productSample();
    repaymentProduct.setLoanAmount(BigDecimal.valueOf(110000));
    repaymentProduct.setCalculationType("REPAYMENT");
    repaymentProduct.setTermYears(21);
    repaymentProduct.setTermMonths(1);
    repaymentProduct.setBaseRate(new BigDecimal("3.50"));
    repaymentProduct.setFreeLegal(false);
    repaymentProduct.setCashBackValue(BigDecimal.TEN);

    final Product interestOnlyProduct = productSample();
    interestOnlyProduct.setLoanAmount(BigDecimal.valueOf(90000));
    interestOnlyProduct.setCalculationType("INTEREST_ONLY");
    interestOnlyProduct.setTermYears(19);
    interestOnlyProduct.setTermMonths(2);
    interestOnlyProduct.setProductFee(new BigDecimal("0"));
    interestOnlyProduct.setValuationFee(new BigDecimal("0"));
    interestOnlyProduct.setChapsFee(new BigDecimal("0"));
    interestOnlyProduct.setCashBackValue(null);
    interestOnlyProduct.setBaseRate(new BigDecimal("3.50"));
    interestOnlyProduct.setFreeLegal(false);

    assertThat(actual).isEqualTo(Arrays.asList(repaymentProduct, interestOnlyProduct));
  }

  @Test
  void mapToEsisProducts_handlesTrackerProduct_trackerMarginPercent() {
    final EsisData esisData = new EsisData();
    ProductDto product = productDtoSample();
    product.setProductType(ProductType.TRACKER.value());
    product.setTrackerMarginPercent(0.0071);
    product.setBaseRate(0.1234d);
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(REPAYMENT.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final List<Product> mappedProducts = this.esisMapper.mapToEsisProducts(esisData);
    final Product result = mappedProducts.get(0);

    assertThat(result.getProductType()).isEqualTo("Tracker");
    assertThat(result.getBaseRate()).isEqualTo(new BigDecimal("12.34"));
    assertThat(result.getInitialInterestRate()).isEqualByComparingTo(BigDecimal.valueOf(0.71));
  }

  @Test
  void mapToEsisProducts_handlesTrackerProduct_trackerInitialInterestRate() {
    final EsisData esisData = new EsisData();
    ProductDto product = productDtoSample();
    product.setProductType(ProductType.TRACKER.value());
    product.setInitialInterestRate(5.39);
    product.setSvr(3.59);
    product.setBaseRate(0.001);
    product.setTrackerMarginPercent(0.0014);
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(REPAYMENT.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final List<Product> mappedProducts = this.esisMapper.mapToEsisProducts(esisData);
    final Product result = mappedProducts.get(0);

    assertThat(result.getProductType()).isEqualTo("Tracker");
    assertThat(result.getBaseRate()).isEqualTo(new BigDecimal("0.10"));
    assertThat(result.getInitialInterestRate())
        .isEqualTo(new BigDecimal("0.14")); // set with tracker margin percent
    assertThat(result.getSvr()).isEqualTo(new BigDecimal("3.59"));
  }

  @ParameterizedTest(name = "{index}:{0} (trackerMarginPercentage:{1},baseRate:{2}) => (trueTmp:{3},trueBr:{4})")
  @MethodSource("mapToEsisProducts_handlesTrackerProduct_arguments")
  void mapToEsisProducts_handlesTrackerProduct(String testName,
      String trackerMarginPercentInput, String baseRateInput,
      String trackerMarginPercentExpected, String baseRateExpected
  ) {
    final EsisData esisData = new EsisData();
    ProductDto product = productDtoSample();
    product.setProductType(ProductType.TRACKER.value());
    product.setBaseRate(Double.valueOf(baseRateInput));
    product.setTrackerMarginPercent(Double.valueOf(trackerMarginPercentInput));
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(REPAYMENT.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final Product result = this.esisMapper.mapToEsisProducts(esisData).get(0);

    assertThat(result.getInitialInterestRate())
        .isEqualTo(new BigDecimal(trackerMarginPercentExpected)); // set with tracker margin percent
    assertThat(result.getBaseRate()).isEqualTo(new BigDecimal(baseRateExpected));
  }

  private static Stream<Arguments> mapToEsisProducts_handlesTrackerProduct_arguments() {
    return Stream.of(
        Arguments.of("Business Test", "0.0014", "0.0525", "0.14", "5.25"),
        Arguments.of("Business Test", "0.0019", "0.0525", "0.19", "5.25"),
        Arguments.of("Business Test", "0.0024", "0.0525", "0.24", "5.25"),
        Arguments.of("Business Test", "0.0029", "0.0525", "0.29", "5.25"),
        Arguments.of("Business Test", "0.0034", "0.0525", "0.34", "5.25"),
        Arguments.of("Business Test", "0.0039", "0.0525", "0.39", "5.25"),
        Arguments.of("Business Test", "0.0044", "0.0525", "0.44", "5.25"),
        Arguments.of("Business Test", "0.0049", "0.0525", "0.49", "5.25"),
        Arguments.of("Business Test", "0.0054", "0.0525", "0.54", "5.25"),
        Arguments.of("Business Test", "0.0059", "0.0525", "0.59", "5.25"),
        Arguments.of("Business Test", "0.0064", "0.0525", "0.64", "5.25"),
        Arguments.of("Business Test", "0.0069", "0.0525", "0.69", "5.25"),
        Arguments.of("Business Test", "0.0074", "0.0525", "0.74", "5.25"),
        Arguments.of("Business Test", "0.0079", "0.0525", "0.79", "5.25"),
        Arguments.of("Business Test", "0.0084", "0.0525", "0.84", "5.25"),
        Arguments.of("Business Test", "0.0089", "0.0525", "0.89", "5.25"),
        Arguments.of("Business Test", "0.0094", "0.0525", "0.94", "5.25"),
        Arguments.of("Business Test", "0.0099", "0.0525", "0.99", "5.25"),
        Arguments.of("Business Test", "0.0098", "0.0525", "0.98", "5.25"),
        Arguments.of("Business Test", "0.0104", "0.0525", "1.04", "5.25"),
        Arguments.of("Business Test", "0.0108", "0.0525", "1.08", "5.25"),
        Arguments.of("Business Test", "0.0093", "0.0525", "0.93", "5.25"),
        Arguments.of("Business Test", "0.0109", "0.0525", "1.09", "5.25"),
        Arguments.of("Business Test", "0.0113", "0.0525", "1.13", "5.25"),
        Arguments.of("Developer Edge Case Test", "0.0111", "0.0111", "1.11", "1.11"),
        Arguments.of("Developer Edge Case Test", "0.0999", "0.0999", "9.99", "9.99"),
        Arguments.of("Developer Edge Case Test", "0.0511", "0.0511", "5.11", "5.11"),
        Arguments.of("Developer Edge Case Test", "0.0544", "0.0544", "5.44", "5.44"),
        Arguments.of("Developer Edge Case Test", "0.0566", "0.0566", "5.66", "5.66"),
        Arguments.of("Developer Edge Case Test", "0.0599", "0.0599", "5.99", "5.99"),
        Arguments.of("Developer Edge Case Test", "0.059", "0.059", "5.90", "5.90"),
        Arguments.of("Product Data Issue Test", "0.05999", "0.05999", "5.999", "5.999"),
        Arguments.of("Product Data Issue Test", "6.6599", "6.6599", "665.99", "665.99")
    );
  }

  /**
   * Covers trackerMarginPercent range between 0.010 - 0.250
   */
  @ParameterizedTest(name = "{0} => {1}")
  @MethodSource("mapToEsisProducts_handlesTrackerMarginPercentage_arguments")
  void mapToEsisProducts_handlesTrackerMarginPercentage(
      String trackerMarginPercentInput,
      String trackerMarginPercentExpected,
      String seed
  ) {
    final EsisData esisData = new EsisData();
    ProductDto product = productDtoSample();
    product.setProductType(ProductType.TRACKER.value());
    product.setTrackerMarginPercent(Double.valueOf(trackerMarginPercentInput));
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(REPAYMENT.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final Product result = this.esisMapper.mapToEsisProducts(esisData).get(0);
    if (!result.getInitialInterestRate().equals(new BigDecimal(trackerMarginPercentExpected))) {
      log.warn("trackerMarginRangeTest:fail {} => {}. Actual: {}", trackerMarginPercentInput, trackerMarginPercentExpected, result.getInitialInterestRate());
    }
    assertThat(result.getInitialInterestRate())
        .isEqualTo(new BigDecimal(trackerMarginPercentExpected)); // set with tracker margin percent
  }

  // 0.0010 => 0.10
  // 0.0100 => 1.00
  // 0.0250 => 2.50
  private static Stream<Arguments> mapToEsisProducts_handlesTrackerMarginPercentage_arguments() {
    List<Arguments> args = new ArrayList<>();
    IntStream.range(10, 100).forEach(i -> {
      args.add(Arguments.of(
          String.format("0.00%s", i),
          String.format("0.%s", i),
          String.valueOf(i))); // 0.0010
    });
    IntStream.range(0, 100).forEach(i -> {
      args.add(Arguments.of(
          String.format("0.01%02d", i),
          String.format("1.%02d", i),
          String.valueOf(100 + i)));
    });
    IntStream.range(0, 51).forEach(i -> {
      args.add(Arguments.of(
          String.format("0.02%02d", i),
          String.format("2.%02d", i),
          String.valueOf(200 + i)));
    });
    return args.stream();
  }

  /**
   * Covers base rate between 0.400 - 0.0700
   */
  @ParameterizedTest(name = "{0} => {1}")
  @MethodSource("mapToEsisProducts_handlesBaseRate_arguments")
  void mapToEsisProducts_handlesBaseRate(
      String baseRateInput,
      String baseRateExpected,
      String seed
  ) {
    final EsisData esisData = new EsisData();
    ProductDto product = productDtoSample();
    product.setProductType(ProductType.TRACKER.value());
    product.setBaseRate(Double.valueOf(baseRateInput));
    esisData.setSelectedProduct(product);
    final EsisMortgageDetails mortgageDetails = new EsisMortgageDetails();
    esisData.setMortgageDetails(mortgageDetails);
    final EsisRepaymentDetails repaymentDetails = new EsisRepaymentDetails();
    mortgageDetails.setRepaymentDetails(repaymentDetails);
    repaymentDetails.setRepaymentType(REPAYMENT.toString());
    final EsisBorrowingRequirements borrowingRequirements = new EsisBorrowingRequirements();
    esisData.setBorrowingRequirements(borrowingRequirements);
    borrowingRequirements.setAddFeeToLoan(false);

    final Product result = this.esisMapper.mapToEsisProducts(esisData).get(0);

    if (!result.getBaseRate().equals(new BigDecimal(baseRateExpected))) {
      log.warn("baseRateRangeTest:fail {} => {}. Actual: {}", baseRateInput, baseRateExpected, result.getBaseRate());
    }

    assertThat(result.getBaseRate())
        .isEqualTo(new BigDecimal(baseRateExpected)); // set with tracker margin percent
  }

  // Covers range 0.0400 - 0.0700
  // 0.0400 => 4.00
  // 0.0401 => 4.01
  // 0.0700 => 7.00
  private static Stream<Arguments> mapToEsisProducts_handlesBaseRate_arguments() {
    List<Arguments> args = new ArrayList<>();
    IntStream.range(4, 8).forEach(i1 -> {
      IntStream.range(0, 100).forEach(i2 -> {
        args.add(Arguments.of(
            String.format("0.0%s%02d", i1, i2),
            String.format("%s.%02d", i1, i2),
            String.format("%s,%s", i1, i2)));
      });
    });
    return args.stream();
  }

}