package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AccessPermissionCheckerTest {

    @Mock
    private UserClaimsProvider mockUserClaimsProvider;

    @Mock
    private CaseClientNapoli mockCaseClient;

    @InjectMocks
    private AccessPermissionChecker accessPermissionChecker;

    @Test
    void isCaseOwnerReturnsTrueWhenUsernamesAndFcaNumbersMatch() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(TEST_BROKER_USERNAME);
        brokerDto.setFcaNumber(TEST_FCA_NUMBER);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCase(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getFcaNumber()).thenReturn(TEST_FCA_NUMBER);
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertTrue(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsTrueWhenUsernamesHaveDifferentCases() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername("TestBroker1");
        brokerDto.setFcaNumber(TEST_FCA_NUMBER);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCase(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getFcaNumber()).thenReturn(TEST_FCA_NUMBER);
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn("testbroker1");
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertTrue(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseWhenUsernamesDiffer() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(TEST_BROKER_USERNAME);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCase(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getFcaNumber()).thenReturn(TEST_FCA_NUMBER);
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_OTHER_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseWhenFcaNumbersDiffer() {
      CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
      BrokerDto brokerDto = new BrokerDto();
      brokerDto.setBrokerUsername(TEST_BROKER_USERNAME);
      caseApplicationDto.setBroker(brokerDto);

      when(mockCaseClient.getCase(any(), any())).thenReturn(caseApplicationDto);

      when(mockUserClaimsProvider.getFcaNumber()).thenReturn(TEST_OTHER_FCA_NUMBER);
      when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
      when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

      boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
      assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfLoggedInUserHasNullUsername() {
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(null);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfLoggedInUserHasNullFcaNumber() {
      when(mockUserClaimsProvider.getFcaNumber()).thenReturn(null);
      when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
      when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

      boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
      assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfCaseHasNoBroker() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        caseApplicationDto.setBroker(null);

        when(mockCaseClient.getCase(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getFcaNumber()).thenReturn(TEST_FCA_NUMBER);
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseIfCaseHasBrokerWithNullUsername() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(null);
        caseApplicationDto.setBroker(brokerDto);

        when(mockCaseClient.getCase(any(), any())).thenReturn(caseApplicationDto);

        when(mockUserClaimsProvider.getFcaNumber()).thenReturn(TEST_FCA_NUMBER);
        when(mockUserClaimsProvider.getBrokerUsername()).thenReturn(TEST_BROKER_USERNAME);
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isCaseOwnerReturnsFalseWhenUserNotBroker() {
        CaseApplicationDto caseApplicationDto = new CaseApplicationDto();
        BrokerDto brokerDto = new BrokerDto();
        brokerDto.setBrokerUsername(TEST_BROKER_USERNAME);
        caseApplicationDto.setBroker(brokerDto);

        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);

        boolean isCaseOwner = accessPermissionChecker.isCaseOwner(BRAND_DEFAULT, TEST_CASE_ID);
        assertFalse(isCaseOwner);
    }

    @Test
    void isBrokerReturnsTrueWhenUserIsBroker() {
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.BROKER);

        boolean isBroker = accessPermissionChecker.isBroker();
        assertTrue(isBroker);
    }

    @Test
    void isBrokerReturnsFalseWhenUserNotBroker() {
        when(mockUserClaimsProvider.getBrokerType()).thenReturn(BrokerType.ADMIN);

        boolean isBroker = accessPermissionChecker.isBroker();
        assertFalse(isBroker);
    }
}
