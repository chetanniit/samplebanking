package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

/**
 * This integration test makes a real request to CRM to retrieve broker info for a given user.
 *
 * This test relies on having a real user in the configured CRM environment.
 * This test could be flaky if test users get cleaned-out from CRM.
 */
@ActiveProfiles(profiles = {"secured-uat"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Slf4j
@Disabled
public class BrokerInfoServiceIT {

  // change as needed to test different usernames
  public final static String EXPECTED_CRM_USER ="brdemo5";
  private final static String UNKNOWN_CRM_USER ="unknown-user";

  @Autowired
  private BrokerInfoService service;

  @Autowired
  private ObjectMapper mapper;

  @Test
  public void shouldFindKnownUser() throws JsonProcessingException {
    final BrokerInfo broker = service.getBroker(EXPECTED_CRM_USER);
    assertThat(broker).isNotNull();
    assertThat(broker.getBrokerDetails().getUserName()).isEqualTo(EXPECTED_CRM_USER);

    // log found user as JSON for readability
    String json = mapper.writeValueAsString(broker);
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    JsonElement je = JsonParser.parseString(json);
    String lineSeparator = System.getProperty("line.separator");
    log.info("Found user:{}{}", lineSeparator, gson.toJson(je));
  }

  @Test
  public void shouldThrowExceptionForUnknownUser() {

    assertThat(catchThrowable(() -> service.getBroker(UNKNOWN_CRM_USER)))
        .isInstanceOf(BrokerNotFoundException.class)
        .hasMessage("Broker not found in CRM");
  }
}
