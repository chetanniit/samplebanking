package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.github.tomakehurst.wiremock.http.HttpHeader;
import com.github.tomakehurst.wiremock.http.HttpHeaders;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.readBrokerCaseFromResource;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
@ActiveProfiles("integration")
@Slf4j
class BrokerCaseControllerTest {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/broker-cases/save-broker-case-create-request.json")
    private Resource saveBrokerCaseCreateRequest;

    @Value("classpath:test-files/broker-cases/save-broker-case-create-request-new-fields.json")
    private Resource saveBrokerCaseCreateRequestNewFields;

    @Value("classpath:test-files/broker-cases/save-broker-case-create-response.json")
    private Resource saveBrokerCaseCreateResponse;

    @Value("classpath:test-files/broker-cases/save-broker-case-create-response-new-fields.json")
    private Resource saveBrokerCaseCreateResponseNewFields;

    @Value("classpath:test-files/broker-cases/save-broker-case-update-request.json")
    private Resource saveBrokerCaseUpdateRequest;

    @Value("classpath:test-files/broker-cases/save-broker-case-update-response.json")
    private Resource saveBrokerCaseUpdateResponse;

    @Value("classpath:test-files/broker-cases/save-interest-only-broker-case-create-request.json")
    private Resource saveInterestOnlyBrokerCaseCreateRequest;

    @Value("classpath:test-files/broker-cases/save-interest-only-broker-case-create-response.json")
    private Resource saveInterestOnlyBrokerCaseCreateResponse;

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    void saveBrokerCaseValidRequestCreatesRecordsInRespectiveCapieMicroservices() throws IOException {
        BrokerCase request = readBrokerCaseFromResource(saveBrokerCaseCreateRequest);
        BrokerCase expectedResponse = readBrokerCaseFromResource(saveBrokerCaseCreateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_SAVE_BROKER_CASE);

        log.info(response.body().asPrettyString());

        BrokerCase result = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        assertThat(result).isEqualTo(expectedResponse);
    }

  @Test
  void saveBrokerCaseValidRequestCreatesRecordsInRespectiveCapieMicroservicesForNewFields() throws IOException {
    BrokerCase request = readBrokerCaseFromResource(saveBrokerCaseCreateRequestNewFields);
    BrokerCase expectedResponse = readBrokerCaseFromResource(saveBrokerCaseCreateResponseNewFields);

    stubFor(post("/v2/cases").willReturn(created()
        .withHeader("Content-Type","application/json")
        .withBody("{\"caseId\":\"test-case-id\",\"version\":\"0\",\"applicationType\":\"RESIDENTIAL\",\"loanPurpose\":\"HOUSE_PURCHASE\",\"buyerType\":\"FIRST_TIME_BUYER\",\"mainResidence\":true,\"repayMortgageCurrencyNotSterling\":true,\"repayMortgageCurrency\":\"CHF\",\"currencyExchangeRate\":500.55,\"scottishApplication\":false,\"northernIrelandApplication\":false,\"transcriptValuer\":\"ALLIED_SURVEYORS_SCOTLAND_PLC\",\"transcriptValuationDate\":\"2022-10-31\",\"estateAgent\":{\"agencyName\":\"Blokes and bricks\",\"address\":{\"houseNumber\":\"42\",\"street\":\"The Street\",\"town\":\"Townsville\",\"postcode\":\"EH6 6BU\",\"countryIsoCode\":\"UK\"},\"telephones\":[{\"type\":\"WORK\",\"number\":\"01315554242\",\"preferred\":true}]},\"serviceLevel\":{\"interview\":\"FACE_TO_FACE\",\"levelOfService\":\"ADVISED\"},\"mortgage\":{\"propertyValue\":500000,\"purchasePrice\":600000,\"deposits\":[{\"depositAmount\":60000,\"depositType\":\"SAVINGS\"}],\"mortgageAmount\":440000,\"mortgageTermYears\":27,\"mortgageTermMonths\":9,\"mortgageType\":\"REPAYMENT\",\"mortgageAdvised\":\"ADVICE\",\"mortgagePrisoner\":false,\"otherProperties\":[{\"id\":\"other-property-id\",\"lastUpdated\":\"2023-03-09 10:26:53\",\"address\":{\"houseNumber\":\"22B\",\"street\":\"The street\",\"town\":\"Townsville\",\"postcode\":\"EH6 6BU\",\"countryIsoCode\":\"GB\"},\"datePurchased\":\"2023-03-02\",\"estimatedPropertyValue\":300000,\"interestOnlyAmount\":200000,\"lenderName\":\"Lender\",\"monthlyMortgagePayment\":1000,\"monthlyRentalIncome\":null,\"mortgageRepaymentType\":\"MIXED\",\"numberBedrooms\":3,\"outstandingMortgageBalance\":150000,\"ownership\":\"APPLICANT_ONE\",\"ownershipType\":\"HELD_ELSEWHERE\",\"propertyRedemption\":false,\"propertyNotes\":\"Redemption notes\",\"propertyType\":\"FLAT_NEW_BUILD\",\"purchasePrice\":240000,\"propertyUsage\":\"RESIDENTIAL\",\"remainingMortgageTermMonths\":3,\"remainingMortgageTermYears\":15,\"useLettingAgent\":null}]},\"directDebit\":{\"accountName\":\"John Doe\",\"sortcode\":\"102030\",\"accountNumber\":\"12345678\",\"paymentDayOfTheMonth\":15,\"attestation\":true,\"mandate\":true},\"broker\":{\"consentToDIP\":true,\"consentToFMA\":true,\"details\":{\"networkId\":334492222,\"fee\":{\"amount\":999}}},\"journeyData\":{\"firstTimeBuyer\":true,\"currentRoute\":\"/dip/ApplicantDetails\",\"isProductSelectedAtDip\":true,\"brokerJourneyVersion\":12}}")));

    Response response = with()
        .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
        .contentType(APPLICATION_JSON_VALUE)
        .body(request)
        .put(PATH_SAVE_BROKER_CASE);

    log.info(response.body().asPrettyString());

    BrokerCase result = response
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(BrokerCase.class);

    verify(postRequestedFor(urlPathMatching("/v2/cases"))
        .withRequestBody(matchingJsonPath("journeyData.brokerJourneyVersion", equalTo("12")))
        .withRequestBody(matchingJsonPath("journeyData.isProductSelectedAtDip", equalTo("true"))));

    assertThat(result).isEqualTo(expectedResponse);
  }

    @Test
    void saveBrokerCaseValidRequestUpdatesRecordsInRespectiveCapieMicroservices() throws IOException {
        // When updating a case, CaseServiceImpl first gets the current case data.
        // Need to stub a non-null response for the GET request to prevent NPE when saving a case.
        // Owner broker has same username as found in StubUserClaimsProvider.
        String emptyCaseResponseJson = "{\"caseId\": \"any-case-id\", \"broker\": {\"brokerUsername\": \"brdemo5\", \"fcaNumber\" : \"405714\"}}";
        String getCasePattern = "/v2/cases/" + TEST_CASE_ID;

        stubFor(get(urlPathMatching(getCasePattern))
                .withHeader(BRAND_HEADER, equalTo(BRAND_DEFAULT))
                .willReturn(
                        aResponse()
                                .withStatus(HttpStatus.OK.value())
                                .withHeaders(new HttpHeaders(new HttpHeader("Content-Type", "application/json")))
                                .withBody(emptyCaseResponseJson)));

        BrokerCase request = readBrokerCaseFromResource(saveBrokerCaseUpdateRequest);
        BrokerCase expectedResponse = readBrokerCaseFromResource(saveBrokerCaseUpdateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_SAVE_BROKER_CASE);

        log.info(response.body().asPrettyString());

        BrokerCase result = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        assertThat(result).isEqualTo(expectedResponse);
    }

    @Test
    void saveInterestOnlyBrokerCaseValidRequestCreatesRecordsInRespectiveCapieMicroservices() throws IOException {
        BrokerCase request = readBrokerCaseFromResource(saveInterestOnlyBrokerCaseCreateRequest);
        BrokerCase expectedResponse = readBrokerCaseFromResource(saveInterestOnlyBrokerCaseCreateResponse);

        Response response = with()
                .pathParam(CASE_ID_PARAM, TEST_CASE_ID)
                .contentType(APPLICATION_JSON_VALUE)
                .body(request)
                .put(PATH_SAVE_BROKER_CASE);

        log.info(response.body().asPrettyString());

        BrokerCase result = response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        assertThat(result).isEqualTo(expectedResponse);
    }
}
