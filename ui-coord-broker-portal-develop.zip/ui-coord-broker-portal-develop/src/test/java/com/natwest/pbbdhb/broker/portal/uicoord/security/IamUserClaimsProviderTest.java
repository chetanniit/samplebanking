package com.natwest.pbbdhb.broker.portal.uicoord.security;

import static com.natwest.pbbdhb.broker.portal.uicoord.security.IamUserClaimsProvider.ADDITIONAL_CLAIMS;
import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import org.junit.jupiter.api.Test;

class IamUserClaimsProviderTest {

  @Test
  void testBrokerUsernameIsRetrieved() {
    final Map<String, Object> brokerData = new HashMap<>();
    brokerData.put("userName", "test-broker-username");
    IamUserClaimsProvider userClaimsProvider = createClaimsProvider(
        (claims) -> claims.put(ADDITIONAL_CLAIMS, brokerData));
    assertThat(userClaimsProvider.getBrokerUsername()).isEqualTo("test-broker-username");
  }

  @Test
  void testBrokerTypeIsRetrieved() {
    final Map<String, Object> brokerData = new HashMap<>();
    brokerData.put("brokerRole", BrokerType.BROKER.toString());
    IamUserClaimsProvider userClaimsProvider = createClaimsProvider(
        (claims) -> claims.put(ADDITIONAL_CLAIMS, brokerData));
    assertThat(userClaimsProvider.getBrokerType()).isEqualTo(BrokerType.BROKER);
  }

  @Test
  void testChannelIsRetrieved() {
    final Map<String, Object> brokerData = new HashMap<>();
    brokerData.put("channel", "test-channel");
    IamUserClaimsProvider userClaimsProvider = createClaimsProvider(
        (claims) -> claims.put(ADDITIONAL_CLAIMS, brokerData));
    assertThat(userClaimsProvider.getChannel()).isEqualTo("test-channel");
  }

  @Test
  void testFcaNumberIsRetrieved() {
    final Map<String, Object> brokerData = new HashMap<>();
    brokerData.put("fcaNumber", TestUtil.TEST_FCA_NUMBER);
    IamUserClaimsProvider userClaimsProvider = createClaimsProvider(
        (claims) -> claims.put(ADDITIONAL_CLAIMS, brokerData));
    assertThat(userClaimsProvider.getFcaNumber()).isEqualTo(TestUtil.TEST_FCA_NUMBER);
  }


  private IamUserClaimsProvider createClaimsProvider(
      Consumer<Map<String, Object>> claimConfiguration) {
    Map<String, Object> claims = new HashMap<>();
    claimConfiguration.accept(claims);

    UserPrincipalProvider userPrincipalProvider = new MockUserPrincipalProvider(
        new MockUserPrincipal(claims));

    return new IamUserClaimsProvider(userPrincipalProvider);
  }
}
