package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import java.security.GeneralSecurityException;

public class MockUserPrincipalProvider implements UserPrincipalProvider {

  private final UserPrincipal userPrincipal;

  public MockUserPrincipalProvider(UserPrincipal userPrincipal) {
    this.userPrincipal = userPrincipal;
  }

  @Override
  public UserPrincipal get() throws GeneralSecurityException {
    return userPrincipal;
  }
}
