package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Deposit.DepositType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.EnumSet;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidDeposit;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getConstraintViolations;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.assertj.core.api.Assertions.assertThat;

class DepositValidationTest extends AbstractValidationTest<Deposit> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid deposit", (Consumer<Deposit>) a -> {
                }, EMPTY_SET),
                Arguments.of("Deposit type is invalid", (Consumer<Deposit>) a -> a.setDepositType(""),
                        singleton(create("depositType",
                                "must be any of: SALE_OF_EXISTING_PROPERTY, SAVINGS, LOANS, OTHER_SAVINGS, PARENTAL_CONTRIBUTION, GIFT, RBS_SAVINGS, NW_SAVINGS, INHERITANCE, INVESTMENTS"
                        ))),
                Arguments.of("Deposit amount is null", (Consumer<Deposit>) a -> a.setDepositAmount(null), singleton(create("depositAmount", "must not be null"))),
                Arguments.of("Originating Currency accepts EUR", (Consumer<Deposit>) a -> a.setOriginatingCurrency("EUR"), EMPTY_SET),
                Arguments.of("Originating Currency is invalid", (Consumer<Deposit>) a -> a.setOriginatingCurrency("EURO"), singleton(create("originatingCurrency","must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")))

        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void testDepositValidations(String testDescription, Consumer<Deposit> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidDeposit, mutator, expectedErrorMessages);
    }

    @Test
    void testAllTitlesInEnumAreValid() {
        Deposit deposit = createValidDeposit();
        EnumSet.allOf(DepositType.class).forEach(depositType -> {
            deposit.setDepositType(depositType.value());
            assertThat(getConstraintViolations(deposit)).isEmpty();
        });
    }

}
