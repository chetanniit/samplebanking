package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Product;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.util.ProductSearchTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_PRODUCT_SEARCH;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class ProductSearchIT {

    @Value("classpath:test-files/product-search/product-search-request.json")
    private Resource productSearchRequestRequest;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Value("${msvc.product.search.url}")
    private String productSearchEndpoint;

    @LocalServerPort
    private int port;

    @Autowired
    private TokenConfiguration tokenConfig;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void submitProductSearchSucceeds() throws IOException {

        ProductSearchRequest productSearchRequest = ProductSearchTestUtil.readProductSearchRequestFromResource(productSearchRequestRequest);

        Response productSearchResponse = with()
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(productSearchRequest)
                .post(PATH_PRODUCT_SEARCH);

        log.info(productSearchResponse.body().asPrettyString());

        Product[] products = productSearchResponse
                .then()
                .statusCode(HttpStatus.OK.value())
                .extract()
                .as(Product[].class);

        assertThat(products.length).isGreaterThan(0);
        productSearchResponse.then().statusCode(200);
    }
}
