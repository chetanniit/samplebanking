package com.natwest.pbbdhb.broker.portal.uicoord.fma;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.http.HttpHeader;
import com.github.tomakehurst.wiremock.http.HttpHeaders;
import com.github.tomakehurst.wiremock.stubbing.ServeEvent;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import com.natwest.pbbdhb.openapi.fma.FullMortgageApplicationRequest;
import com.natwest.pbbdhb.openapi.fma.Valuation;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.skyscreamer.jsonassert.comparator.DefaultComparator;
import org.skyscreamer.jsonassert.comparator.JSONComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.getAllServeEvents;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static com.github.tomakehurst.wiremock.core.Options.DEFAULT_PORT;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.insertNewBrokerCaseIntoCapie;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.submitDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SUBMIT_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil.getFmaRequestFilePath;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil.getFmaRequestJson;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.JsonTestCaseUtil.saveTextToFile;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;


@TestPropertySource("classpath:application-it-fma-outgoing-request.properties")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class FmaOutgoingRequestIT {
    // If 'singleTestCase' is set, only the test case with that name will be run.
    private static final String singleTestCase = null;
//    private static final String singleTestCase = "scenario-2";

    // Set this to 'true' to update 'expected output' file to match actual output INSTEAD OF running the tests
    private static final boolean updateExpectedRequest = false;

    private static final Gson gson = new GsonBuilder().serializeNulls().create();
    private static final String fmaPath = "/mortgages/v1/msvc-full-mortgage-application";
    private static WireMockServer wireMockServer;

    private TestInfo testInfo;
    private JSONCompareResult compareResult;

    @Autowired
    private TokenConfiguration tokenConfig;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @MockBean
    private BrokerInfoClient brokerInfoClient;

    @BeforeAll
    public static void beforeAll() throws IOException {
        wireMockServer = new WireMockServer(options().port(DEFAULT_PORT));
        wireMockServer.start();
        String genericResponseJson = "{}";

        stubFor(post(urlPathMatching(fmaPath))
                .willReturn(
                        aResponse()
                                .withStatus(HttpStatus.OK.value())
                                .withHeaders(new HttpHeaders(new HttpHeader("Content-Type", "application/json")))
                                .withBody(genericResponseJson)));
    }

    @BeforeEach
    public void setUp(TestInfo testInfo) {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;

        // reset the journal (i.e. forget all previous requests)
        wireMockServer.resetRequests();

        this.testInfo = testInfo;
        this.compareResult = null;
        when(brokerInfoClient.readBroker(Mockito.any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() throws IOException {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.DEFAULT_PORT;
    }

    @AfterAll
    public static void tearDown() {
      wireMockServer.stop();
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void inspectFmaRequest(String testCaseName, String brokerCaseJson, String expectedFmaRequestJson) throws JSONException {
        BrokerCase brokerCase = gson.fromJson(brokerCaseJson, BrokerCase.class);

        String caseId = insertNewBrokerCaseIntoCapie(brokerCase, tokenConfig);

        BrokerCase brokerCaseWithDip = submitDip(caseId, tokenConfig);
        String dipId = brokerCaseWithDip.getCaseApplication().getDecisionInPrinciple().getDipId();

        // Submit FMA
        Response submitFmaResponse = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_FMA);

        log.info(submitFmaResponse.body().asPrettyString());

        submitFmaResponse.then().statusCode(anyOf(is(201), is(202)));

        verify(postRequestedFor(urlPathMatching(fmaPath)));

        String actualRequestBody = getOutgoingRequestJson();

        if (updateExpectedRequest) {
            String filePath = "src/test/resources/" + getFmaRequestFilePath(testCaseName);
            saveTextToFile(actualRequestBody, filePath);
        } else {
            FullMortgageApplicationRequest fmaRequest = gson.fromJson(expectedFmaRequestJson, FullMortgageApplicationRequest.class);

            // modify expected request to match current case
            fmaRequest.getApplication().setCaseId(caseId);
            fmaRequest.getApplication().setDipId(dipId);
            Valuation valuation = fmaRequest.getApplication().getProperty().getValuation();
            // expect a valuation date of today if no valuation was supplied
            if (brokerCase.getProperty().getValuation() == null) {
                String todayDateString = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
                valuation.setDate(todayDateString);
            }
            expectedFmaRequestJson = gson.toJson(fmaRequest);

            JSONComparator fmaRequestComparator = getFmaRequestComparator();
            compareResult = JSONCompare.compareJSON(expectedFmaRequestJson, actualRequestBody, fmaRequestComparator);
            assertTrue(compareResult.passed(), compareResult.getMessage());
        }
    }

    private String getOutgoingRequestJson() {
        List<ServeEvent> allServeEvents = getAllServeEvents();
        ServeEvent firstServeEvent = allServeEvents.get(0);
        return firstServeEvent.getRequest().getBodyAsString();
    }

    private static Stream<Arguments> testCases() throws IOException {
        if (singleTestCase != null) {
            return Stream.of(testCaseArguments(singleTestCase));
        }
        PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
        Resource[] testCaseResources = resourceResolver.getResources("classpath:fma-test-cases/broker-case/*.json");
        return Arrays.stream(testCaseResources).map(JsonTestCaseUtil::testCaseNameFromResource).map(FmaOutgoingRequestIT::testCaseArguments).filter(args -> args.get()[2] != null);
    }

    private static Arguments testCaseArguments(String testCaseName) {
        return Arguments.of(testCaseName, getBrokerCaseJson(testCaseName), getFmaRequestJson(testCaseName));
    }

    private static String getBrokerCaseJson(String testCaseName) {
        try {
            String brokerCasePath = "fma-test-cases/broker-case";
            Resource brokerCaseResource = new ClassPathResource(brokerCasePath + "/" + testCaseName + ".json");
            return getResourceText(brokerCaseResource);
        } catch (IOException ioex) {
            log.info(ioex.toString());
            return null;
        }
    }

    private JSONComparator getFmaRequestComparator() {
        // NOTE: Ideally, this would be a comparator that selectively ignores order of arrays where we know they can vary.
        // My first attempt to ignore array order only for 'applicants[].employment.incomes' didn't work as intended.
        // Testing this is awkward because the array order of 'applicants[].employment.incomes' in the FMA request body is non-deterministic.
        // For now - always ignore array order.
        return new DefaultComparator(JSONCompareMode.NON_EXTENSIBLE);
    }
}