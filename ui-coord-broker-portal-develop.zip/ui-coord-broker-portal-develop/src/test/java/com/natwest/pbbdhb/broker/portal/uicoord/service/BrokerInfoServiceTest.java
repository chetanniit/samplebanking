package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInfoMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.BrokerInfoServiceImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith({
    MockitoExtension.class,
    SpringExtension.class
})
@ContextConfiguration(classes = {
    BrokerInfoServiceImpl.class,
    BrokerInfoMapperImpl.class
})
public class BrokerInfoServiceTest {

  @MockBean
  private BrokerInfoClient client;

  @Autowired
  private BrokerInfoService service;

  @BeforeEach
  public void beforeEach() {
    when(client.readBroker(any()))
        .thenReturn(BrokerInfoTestUtil.brokerInfoDto());
  }

  @Test
  public void shouldReturnBrokerInfo() {
    final BrokerInfo broker = service.getBroker("my-username");
    assertThat(broker).isNotNull();
    assertThat(broker).isEqualTo(BrokerInfoTestUtil.brokerInfo());
  }

  @Test
  public void shouldThrowExceptionWhenBrokerNotFound() {
    when(client.readBroker(any()))
        .thenThrow(new BrokerNotFoundException("user not found"));
    assertThat(catchThrowable(() -> service.getBroker("unknown-user")))
        .isInstanceOf(BrokerNotFoundException.class)
        .hasMessage("user not found");
  }
}
