package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.UNHANDLED;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.VALIDATION_PRODUCT_EXPIRY;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.VALIDATION_PRODUCT_INVALID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidFmaResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.Error;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class FmaErrorResultMapperTest {


  private static final String FMA_PRODUCT_EXPIRY_MESSAGE = "Validation failed, product has been expired";
  private static final String CASE_ID = "test-case-id";

  @Test
  void testToErrorCodesWithMatchErrorWithErrorCode() {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();

    List<Error> fmaErrors = Arrays.asList(
        Error.builder().message(FMA_PRODUCT_EXPIRY_MESSAGE).build());
    FullMortgageApplicationExtendedResponse extendedResponse = createValidFmaResponse();
    extendedResponse.setErrors(fmaErrors);

    List<ErrorCode> errorCodes = testee.toErrorCodes(extendedResponse, CASE_ID);
    assertEquals(1, errorCodes.size());
    assertTrue(errorCodes.contains(VALIDATION_PRODUCT_INVALID));

  }

  @Test
  void testToErrorCodesWithNoErrorsReturnsEmptyList() {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();

    FullMortgageApplicationExtendedResponse extendedResponse = createValidFmaResponse();

    List<ErrorCode> errorCodes = testee.toErrorCodes(extendedResponse, CASE_ID);
    assertEquals(0, errorCodes.size());

  }

  @Test
  void testToSingleErrorCodeWithNoErrorsReturnsUNHANDLED() {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();

    FullMortgageApplicationExtendedResponse extendedResponse = createValidFmaResponse();

    ErrorCode errorCode = testee.toSingleErrorCode(extendedResponse, CASE_ID);
    assertEquals(UNHANDLED, errorCode);

  }


  @Test
  void testToErrorCodesWithNoMatchFoundReturnsUnhandled() {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();

    List<Error> fmaErrors = Arrays.asList(
        Error.builder().message("Validation Failed, don't match me").build());
    FullMortgageApplicationExtendedResponse extendedResponse = createValidFmaResponse();
    extendedResponse.setErrors(fmaErrors);

    List<ErrorCode> errorCodes = testee.toErrorCodes(extendedResponse, CASE_ID);
    assertEquals(1, errorCodes.size());
    assertTrue(errorCodes.contains(ErrorCode.UNHANDLED));

  }


  @Test
  void testToErrorCodesWithMultipleErrorsReturnsCorrectMatchesWIthNoDuplicates() {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();

    List<Error> fmaErrors = Arrays.asList(
        Error.builder().message("Validation Failed, don't match me 1").build(),
        Error.builder().message(FMA_PRODUCT_EXPIRY_MESSAGE).build(),
        Error.builder().message("Something extra" + FMA_PRODUCT_EXPIRY_MESSAGE).build(),
        Error.builder().message("Validation Failed, don't match me 2").build());

    FullMortgageApplicationExtendedResponse extendedResponse = createValidFmaResponse();
    extendedResponse.setErrors(fmaErrors);

    List<ErrorCode> errorCodes = testee.toErrorCodes(extendedResponse, CASE_ID);
    assertEquals(2, errorCodes.size());
    assertTrue(errorCodes.contains(ErrorCode.UNHANDLED));
    assertTrue(errorCodes.contains(VALIDATION_PRODUCT_INVALID));

  }

  @Test
  void testToSingleErrorCodePrefersHandledErrors() {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();

    List<Error> fmaErrors = Arrays.asList(
        Error.builder().message("Validation Failed, don't match me 1").build(),
        Error.builder().message(FMA_PRODUCT_EXPIRY_MESSAGE).build(),
        Error.builder().message("also unhandled").build());

    FullMortgageApplicationExtendedResponse extendedResponse = createValidFmaResponse();
    extendedResponse.setErrors(fmaErrors);

    ErrorCode mappedErrorCode = testee.toSingleErrorCode(extendedResponse, CASE_ID);
    assertEquals(VALIDATION_PRODUCT_INVALID, mappedErrorCode);

  }


  @ParameterizedTest(name = "{index} {1}")
  @MethodSource("fmaResponseMatches")
  void testToErrorCodesWithSpecificErrorCodeIsMatched(String fmaMessage, ErrorCode expectedMatch) {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();
    List<ErrorCode> mappedMatches = testee.toErrorCodes(makeResponse(fmaMessage), CASE_ID);
    assertEquals(1, mappedMatches.size());
    assertTrue(mappedMatches.contains(expectedMatch));

  }

  @ParameterizedTest(name = "{index} {1}")
  @MethodSource("fmaResponseMatches")
  void testToSingleErrorCodeWithSpecificErrorCodeIsMatched(String fmaMessage, ErrorCode expectedMatch) {

    FmaErrorResultMapper testee = new FmaErrorResultMapper();
    ErrorCode mappedMatch = testee.toSingleErrorCode(makeResponse(fmaMessage), CASE_ID);
    assertEquals(expectedMatch, mappedMatch);

  }


  private static Stream<Arguments> fmaResponseMatches() {
    return Stream.of(
        Arguments.of(FMA_PRODUCT_EXPIRY_MESSAGE, VALIDATION_PRODUCT_INVALID),
        Arguments.of("No match", ErrorCode.UNHANDLED)
    );

  }

  private static FullMortgageApplicationExtendedResponse makeResponse(String message) {
    Error error = Error.builder().code("some code").message(message).status("400").build();
    FullMortgageApplicationExtendedResponse response = new FullMortgageApplicationExtendedResponse();
    response.addErrorsItem(error);
    return response;
  }

}