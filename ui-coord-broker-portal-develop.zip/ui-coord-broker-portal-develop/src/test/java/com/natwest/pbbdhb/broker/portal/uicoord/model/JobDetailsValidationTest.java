package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil.createValidAdditionalIncome;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class JobDetailsValidationTest extends AbstractValidationTest<JobDetails> {

    private static Stream<Arguments> jobDetailsTestCases() {
        return Stream.of(
                Arguments.of("Valid job details", (Consumer<JobDetails>) a -> { /* no-op */ }, EMPTY_SET),
                Arguments.of("Employment start date is in invalid format", (Consumer<JobDetails>) a -> a.setEmploymentStartDate("13-11-2000"),
                        singleton(create("employmentStartDate", "must be a date in the past in format 'yyyy-MM-dd'"))
                ),
                Arguments.of("Employment start date is today (invalid)", (Consumer<JobDetails>) a -> a.setEmploymentStartDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))),
                        singleton(create("employmentStartDate", "must be a date in the past in format 'yyyy-MM-dd'"))
                ),
                Arguments.of("Business establishment date is in invalid format", (Consumer<JobDetails>) a -> a.setBusinessEstablishmentDate("13-11-2015"),
                        singleton(create("businessEstablishmentDate", "must be a date in the past in format 'yyyy-MM-dd'"))
                ),
                Arguments.of("Business establishment date is today (invalid)", (Consumer<JobDetails>) a -> a.setBusinessEstablishmentDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))),
                        singleton(create("businessEstablishmentDate", "must be a date in the past in format 'yyyy-MM-dd'"))
                ),
                Arguments.of("basicPayAnnualIncome is below 1.00", (Consumer<JobDetails>) a -> a.setBasicPayAnnualIncome(new BigDecimal("0.99")),
                        singleton(create("basicPayAnnualIncome", "must be a value between 1.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("basicPayAnnualIncome is above 99999999.99", (Consumer<JobDetails>) a -> a.setBasicPayAnnualIncome(new BigDecimal("100000000")),
                        singleton(create("basicPayAnnualIncome", "must be a value between 1.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netBasicPayAnnualIncome is above 0", (Consumer<JobDetails>) a -> a.setNetBasicPayAnnualIncome(new BigDecimal("0")),
                        singleton(create("netBasicPayAnnualIncome", "must be a value between 1.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("basicPayAnnualIncomeOriginatingCurrency is not valid ORIGINATING_CURRENCY enum", (Consumer<JobDetails>) a -> a.setBasicPayAnnualIncomeOriginatingCurrency("HOP"),
                    singleton(create("basicPayAnnualIncomeOriginatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR"))
                ),
                Arguments.of("Valid number of additional incomes", (Consumer<JobDetails>) a -> a.getAdditionalIncome().put("1", createValidAdditionalIncome()), EMPTY_SET),
                Arguments.of("Number of additional incomes is too large", (Consumer<JobDetails>) a -> {
                    for (int i = 0; i < 11; i++) {
                        a.getAdditionalIncome().put(String.valueOf(i), createValidAdditionalIncome());
                    }
                }, singleton(create("additionalIncome", "size must be between 1 and 10"))),
                Arguments.of("additionalIncome.type is null", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setType(null);
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].type", "must not be blank"))),
                Arguments.of("additionalIncome.frequency is null", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setFrequency(null);
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].frequency", "must not be blank"))),
                Arguments.of("additionalIncome.originatingCurrency is not valid ORIGINATING_CURRENCY enum", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setOriginatingCurrency("HOP");
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].originatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR"))),
                Arguments.of("additionalIncome.amount is null", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setAmount(null);
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].amount", "must not be null"))),
                Arguments.of("additionalIncome.amount is below 1.00", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setAmount(new BigDecimal("0.99"));
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].amount", "must be a value between 1.00 and 99999999.99 with up to 2 decimal places"))),
                Arguments.of("additionalIncome.amount is above 99999999.99", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setAmount(new BigDecimal("100000000"));
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].amount", "must be a value between 1.00 and 99999999.99 with up to 2 decimal places"))),
                Arguments.of("additionalIncome.netamount is above 99999999.99", (Consumer<JobDetails>) a -> {
                    AdditionalJobIncome additionalJobIncome = createValidAdditionalIncome();
                    additionalJobIncome.setNetAmount(new BigDecimal("100000000"));
                    a.getAdditionalIncome().put("additionalIncome-1", additionalJobIncome);
                }, singleton(create("additionalIncome[additionalIncome-1].netAmount", "must be a value between 1.00 and 99999999.99 with up to 2 decimal places"))),
                Arguments.of("yearOneProfit is below 0.00", (Consumer<JobDetails>) a -> a.setYearOneProfit(new BigDecimal("-0.1")),
                        singleton(create("yearOneProfit", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneProfit is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearOneProfit(new BigDecimal("100000000")),
                        singleton(create("yearOneProfit", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneProfitOriginatingCurrency is not valid ORIGINATING_CURRENCY enum", (Consumer<JobDetails>) a -> a.setYearOneProfitOriginatingCurrency("HOP"),
                        singleton(create("yearOneProfitOriginatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR"))
                ),
                Arguments.of("yearOneNetProfitAfterTax is below 0.00", (Consumer<JobDetails>) a -> a.setYearOneNetProfitAfterTax(new BigDecimal("-0.1")),
                        singleton(create("yearOneNetProfitAfterTax", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneNetProfitAfterTax is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearOneNetProfitAfterTax(new BigDecimal("100000000")),
                        singleton(create("yearOneNetProfitAfterTax", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoProfit is below 0.00", (Consumer<JobDetails>) a -> a.setYearTwoProfit(new BigDecimal("-0.1")),
                        singleton(create("yearTwoProfit", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoProfit is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearTwoProfit(new BigDecimal("100000000")),
                        singleton(create("yearTwoProfit", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoProfitOriginatingCurrency is not valid ORIGINATING_CURRENCY enum", (Consumer<JobDetails>) a -> a.setYearTwoProfitOriginatingCurrency("HOP"),
                        singleton(create("yearTwoProfitOriginatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR"))
                ),
                Arguments.of("yearNetProfitAfterTax is below 0.00", (Consumer<JobDetails>) a -> a.setYearTwoNetProfitAfterTax(new BigDecimal("-0.1")),
                        singleton(create("yearTwoNetProfitAfterTax", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearNetProfitAfterTax is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearTwoNetProfitAfterTax(new BigDecimal("100000000")),
                        singleton(create("yearTwoNetProfitAfterTax", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneDirectorSalary is below 0.00", (Consumer<JobDetails>) a -> a.setYearOneDirectorSalary(new BigDecimal("-0.1")),
                        singleton(create("yearOneDirectorSalary", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneDirectorSalary is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearOneDirectorSalary(new BigDecimal("100000000")),
                        singleton(create("yearOneDirectorSalary", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneOriginatingCurrency is not valid ORIGINATING_CURRENCY enum", (Consumer<JobDetails>) a -> a.setYearOneOriginatingCurrency("HOP"),
                        singleton(create("yearOneOriginatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR"))
                ),
                Arguments.of("netYearOneDirectorSalary is below 0.00", (Consumer<JobDetails>) a -> a.setNetYearOneDirectorSalary(new BigDecimal("-0.1")),
                        singleton(create("netYearOneDirectorSalary", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netYearOneDirectorSalary is above 99999999.99", (Consumer<JobDetails>) a -> a.setNetYearOneDirectorSalary(new BigDecimal("100000000")),
                        singleton(create("netYearOneDirectorSalary", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoDirectorSalary is below 0.00", (Consumer<JobDetails>) a -> a.setYearTwoDirectorSalary(new BigDecimal("-0.1")),
                        singleton(create("yearTwoDirectorSalary", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoDirectorSalary is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearTwoDirectorSalary(new BigDecimal("100000000")),
                        singleton(create("yearTwoDirectorSalary", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoOriginatingCurrency is not valid ORIGINATING_CURRENCY enum", (Consumer<JobDetails>) a -> a.setYearTwoOriginatingCurrency("HOP"),
                        singleton(create("yearTwoOriginatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR"))
                ),
                Arguments.of("netYearTwoDirectorSalary is below 0.00", (Consumer<JobDetails>) a -> a.setNetYearTwoDirectorSalary(new BigDecimal("-0.1")),
                        singleton(create("netYearTwoDirectorSalary", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netYearTwoDirectorSalary is above 99999999.99", (Consumer<JobDetails>) a -> a.setNetYearTwoDirectorSalary(new BigDecimal("100000000")),
                        singleton(create("netYearTwoDirectorSalary", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneDividends is below 0.00", (Consumer<JobDetails>) a -> a.setYearOneDividends(new BigDecimal("-0.1")),
                        singleton(create("yearOneDividends", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearOneDividends is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearOneDividends(new BigDecimal("100000000")),
                        singleton(create("yearOneDividends", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netYearOneDividends is below 0.00", (Consumer<JobDetails>) a -> a.setNetYearOneDividends(new BigDecimal("-0.1")),
                        singleton(create("netYearOneDividends", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netYearOneDividends is above 99999999.99", (Consumer<JobDetails>) a -> a.setNetYearOneDividends(new BigDecimal("100000000")),
                        singleton(create("netYearOneDividends", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoDividends is below 0.00", (Consumer<JobDetails>) a -> a.setYearTwoDividends(new BigDecimal("-0.1")),
                        singleton(create("yearTwoDividends", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("yearTwoDividends is above 99999999.99", (Consumer<JobDetails>) a -> a.setYearTwoDividends(new BigDecimal("100000000")),
                        singleton(create("yearTwoDividends", "must be a value between 0.00 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netYearTwoDividends is below 0.00", (Consumer<JobDetails>) a -> a.setNetYearTwoDividends(new BigDecimal("-0.1")),
                        singleton(create("netYearTwoDividends", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("netYearTwoDividends is above 99999999.99", (Consumer<JobDetails>) a -> a.setNetYearTwoDividends(new BigDecimal("100000000")),
                        singleton(create("netYearTwoDividends", "must be a value between 0 and 99999999.99 with up to 2 decimal places"))
                ),
                Arguments.of("employerTelephone contains non-digit characters", (Consumer<JobDetails>) a -> a.setEmployerTelephone("01234567890A"),
                        singleton(create("employerTelephone", "Badly formed phone number"))
                ),
                Arguments.of("employeeSharePercentage is less than 0", (Consumer<JobDetails>) a -> a.setEmployeeSharePercentage(-1),
                        singleton(create("employeeSharePercentage", "must be greater than or equal to 0"))
                ),
                Arguments.of("employeeSharePercentage is greater than 100", (Consumer<JobDetails>) a -> a.setEmployeeSharePercentage(101),
                        singleton(create("employeeSharePercentage", "must be less than or equal to 100"))
                )

        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("jobDetailsTestCases")
    public void testCommonJobDetailsValidations(String testDescription, Consumer<JobDetails> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, IncomeTestUtil::createValidJobDetails, mutator, expectedErrorMessages);
    }
}
