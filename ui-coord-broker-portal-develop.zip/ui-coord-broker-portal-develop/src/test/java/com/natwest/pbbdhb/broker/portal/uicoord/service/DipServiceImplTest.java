package com.natwest.pbbdhb.broker.portal.uicoord.service;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.WORK_STATUS_NOT_WORKING;
import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.WORK_STATUS_WORKING;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_COMPLETED_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_MISSING_EXISTING_MORTGAGES;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_DIP_AFTER_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_DIP_ID;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.DipClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ExpenseClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.IncomeClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.PropertyClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.dip.BureauCallManager;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.DipApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.DipResultMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalAddress.OccupyStatusType;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.DipServiceImpl;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentStatus;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import com.natwest.pbbdhb.income.expense.model.income.response.IncomeApplicantDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.model.Application;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DipServiceImplTest {

    @Mock
    CaseClientNapoli caseClient;

    @Mock
    UserClaimsProvider userClaimsProvider;

    @Mock
    ApplicantClientNapoli applicantClient;

    @Mock
    PropertyClientNapoli propertyClient;

    @Mock
    IncomeClient incomeClient;

    @Mock
    ExpenseClient expenseClient;

    @Mock
    DipApplicationMapper dipApplicationMapper;

    @Mock
    DipClient dipClient;

    @Mock
    AccessPermissionChecker accessPermissionChecker;

    @Mock
    BureauCallManager bureauCallManager;

    @Mock
    DipResultMapper dipResultMapper;

    @Mock
    BrokerCaseService brokerCaseService;

    @InjectMocks
    DipServiceImpl dipService;

    @Mock
    InputStream inputStream;

    @Test
    void submitDipSucceeds() throws DipIntegrationException {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        ValidatedCaseIncomeDto fakeCaseIncomeDto = new ValidatedCaseIncomeDto();
        fakeCaseIncomeDto.setApplicants(new ArrayList<>());
        when(incomeClient.getIncome(any(), any())).thenReturn(fakeCaseIncomeDto);

        CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
        when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);

        Application dipApplication = new Application();
        dipApplication.setApplicants(new ArrayList<>());
        when(dipApplicationMapper.toDipApplication(any(), any(), any(), any(), any(), any())).thenReturn(dipApplication);

        dipService.submitDip("brand", "caseId");
    }

    @Test
    void submitDipCallsSubmitDipIfNoBureauCallInfo() throws DipIntegrationException {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
        when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);

        when(bureauCallManager.hasMatchingBureauCall(any(), any())).thenReturn(false);
        dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);
        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(caseClient).updateCase(eq(BRAND_DEFAULT), caseApplicationDtoCaptor.capture());

        assertEquals(true, caseApplicationDtoCaptor.getValue().getJourneyData().getOrDefault(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, null));
    }

    @Test
    void submitDipSetsJourneyDataHasCompletedDip() throws DipIntegrationException {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
        when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);
        when(bureauCallManager.hasMatchingBureauCall(any(), any())).thenReturn(false);
        dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);
        verify(dipClient).submitDip(any());
    }

    @Test
    void submitDipSetsJourneyDataForIsProductSelectedAtDipEqualsTrueHasCompletedDip() throws DipIntegrationException {
      when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
      CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
      SalesIllustrationDto fakeSalesIllustrationDto = new SalesIllustrationDto();
      ProductDetailsDto fakeCaseDetailsDto = new ProductDetailsDto();
      fakeCaseDetailsDto.setProductCode("TestCode");
      List<ProductDetailsDto> fakeCaseList = new ArrayList<>();
      List<SalesIllustrationDto> fakeSalesIllustrationsList = new ArrayList<>();
      fakeCaseList.add(fakeCaseDetailsDto);
      fakeSalesIllustrationDto.setProducts(fakeCaseList);
      fakeSalesIllustrationsList.add(fakeSalesIllustrationDto);
      fakeCaseApplicationDto.setSalesIllustrations(fakeSalesIllustrationsList);
      when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);
      when(bureauCallManager.hasMatchingBureauCall(any(), any())).thenReturn(false);
      dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);
      assertEquals(true, fakeCaseApplicationDto.getJourneyData().get(CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP));
      verify(dipClient).submitDip(any());
    }

  @Test
  void submitDipSetsJourneyDataForIsProductSelectedAtDipEqualsFalseHasCompletedDip() throws DipIntegrationException {
    when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
    CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
    when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);
    when(bureauCallManager.hasMatchingBureauCall(any(), any())).thenReturn(false);
    dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);
    assertEquals(false, fakeCaseApplicationDto.getJourneyData().get(CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP));
    verify(dipClient).submitDip(any());
  }

    @Test
    void submitDipCallsAmendDipIfBureauCallInfoIsPresent() throws DipIntegrationException {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        CaseApplicationDto fakeCaseApplicationDto = mock(CaseApplicationDto.class, RETURNS_DEEP_STUBS);
        when(fakeCaseApplicationDto.getDecisionInPrinciples().get(0).getDateTime()).thenReturn("2023-08-01 14:00:00");
        when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);
        when(dipResultMapper.newDecisionInPrincipleDateTime()).thenReturn("2023-08-01 14:00:00");

        when(bureauCallManager.hasMatchingBureauCall(any(), any())).thenReturn(true);
        when(bureauCallManager.getDipId(any())).thenReturn("TEST_DIP_ID");
        dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);
        verify(dipClient).amendDip(any(), eq("TEST_DIP_ID"));

        ArgumentCaptor<CaseApplicationDto> caseApplicationDtoArgumentCaptor = ArgumentCaptor.forClass(CaseApplicationDto.class);
        verify(caseClient).updateCase(eq("nwb"), caseApplicationDtoArgumentCaptor.capture());
        assertEquals("2023-08-01 14:00:00",
            caseApplicationDtoArgumentCaptor.getValue().getDecisionInPrinciples().get(0).getDateTime());
    }

    @Test
    void submitDipSetsNewBureauCallInfoIfNoMatchingPreviousBureauCallInfo() throws DipIntegrationException {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
        when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);

        when(bureauCallManager.hasMatchingBureauCall(any(), any())).thenReturn(false);

        dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);
        verify(bureauCallManager).setBureauCallInfo(any(), any(), any());
    }

    @Test
    void submitDipThrowsValidationExceptionIfExistingMortgagesIsMissingForOwnerMortgagedOccupancy() {
      when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

      CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
      when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);

      List<ApplicantDto> applicants = new ArrayList<>();
      ApplicantDto applicant = new ApplicantDto();
      List<PersonAddressDto> addresses = new ArrayList<>();
      PersonAddressDto address = new PersonAddressDto();
      address.setOccupyStatus(OccupyStatusType.OWNER_MORTGAGED.value());
      address.setIsCurrentAddress(true);
      addresses.add(address);
      applicant.setAddresses(addresses);
      applicant.setExistingMortgages(null);
      applicants.add(applicant);
      when(applicantClient.getApplicants(any(), any())).thenReturn(applicants);

      DipValidationException ex = assertThrows(
          DipValidationException.class,
          () -> dipService.submitDip("brand", "caseId"));

      assertEquals(MSG_MISSING_EXISTING_MORTGAGES + " caseId", ex.getMessage());
    }

    @Test
    void submitDipThrowsPermissionDeniedIfUserIsNotOwner() {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(false);

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () -> dipService.submitDip("brand", "caseId"));

        assertEquals(MSG_NO_UPDATE_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void submitDipThrowsUpdateNotPermittedWhenApplicationStatusIsStage20() {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);

        // set up a CaseApplicationDto with application status SUBMIT_GMS_STAGE_20 (after FMA submission)
        CaseApplicationDto caseApplicationDtoAfterFmaSubmission = CaseApplicationDto.builder()
                .applicationStatus(ApplicationStatus.SUBMIT_GMS_STAGE_20.name())
                .build();

        // simulate retrieving the existing case with application status SUBMIT_GMS_STAGE_20 from the case client
        when(caseClient.getCase(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseApplicationDtoAfterFmaSubmission);

        RuntimeException ex = assertThrows(
                UpdateNotPermittedException.class,
                () -> dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID));

        assertEquals(MSG_NO_DIP_AFTER_FMA, ex.getMessage());
    }

    @Test
    void getDipCertificateWithCaseIdSuccessfully() throws DipIntegrationException {
        when(dipClient.getDipCertificate(any(), any())).thenReturn(inputStream);
        dipService.getDipCertificateWithCaseId(BRAND_DEFAULT, TEST_CASE_ID);
        verify(dipClient).getDipCertificate(BRAND_DEFAULT, TEST_CASE_ID);
    }

    @Test
    void getDipCertificateWithCaseIdThrowsException() throws DipIntegrationException {
        assertThatThrownBy(() -> dipService.getDipCertificateWithCaseId(BRAND_DEFAULT, TEST_CASE_ID))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void getDipDocumentWithCaseIdSuccessfully() throws DipIntegrationException {
        when(dipClient.getDipDocumentByDipId(any(), any())).thenReturn(inputStream);
        dipService.getDipDocumentByDipId(BRAND_DEFAULT, TEST_DIP_ID);
        verify(dipClient).getDipDocumentByDipId(BRAND_DEFAULT, TEST_DIP_ID);
    }

    @Test
    void getDipDocumentWithCaseIdThrowsException() throws DipIntegrationException {
        assertThatThrownBy(() -> dipService.getDipDocumentByDipId(BRAND_DEFAULT, TEST_DIP_ID))
            .isInstanceOf(IllegalArgumentException.class);
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("getWorkStatusCorrectionTestCases")
    public void workStatusCorrectionWhenIncomeIsNull(
            String description,
            List<ApplicantDto> applicantDtoList,
            ValidatedCaseIncomeDto caseIncomeDto,
            List<Pair<String, String>> expectedCorrections
    ) throws DipIntegrationException {
        when(accessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(applicantClient.getApplicants(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(applicantDtoList);
        when(incomeClient.getIncome(BRAND_DEFAULT, TEST_CASE_ID)).thenReturn(caseIncomeDto);
        Application dipApplication = new Application();
        dipApplication.setApplicants(new ArrayList<>());
        when(dipApplicationMapper.toDipApplication(any(), any(), any(), any(), any(), any())).thenReturn(dipApplication);
        CaseApplicationDto fakeCaseApplicationDto = new CaseApplicationDto();
        when(caseClient.getCase(any(), any())).thenReturn(fakeCaseApplicationDto);

        dipService.submitDip(BRAND_DEFAULT, TEST_CASE_ID);

        int expectedTimes = expectedCorrections.size();

        ArgumentCaptor<ApplicantDto> applicantDtoCaptor = ArgumentCaptor.forClass(ApplicantDto.class);
        verify(applicantClient, times(expectedTimes)).saveApplicant(eq(BRAND_DEFAULT), applicantDtoCaptor.capture());

        List<ApplicantDto> correctedApplicantDtoList = applicantDtoCaptor.getAllValues();

        for (int i = 0; i < expectedCorrections.size(); i++) {
            Pair<String, String> expected = expectedCorrections.get(i);
            ApplicantDto correctedApplicantDto = correctedApplicantDtoList.get(i);
            assertEquals(expected.getLeft(), correctedApplicantDto.getApplicantId());
            assertEquals(expected.getRight(), correctedApplicantDto.getWorkStatus());
        }
    }

    private static Stream<Arguments> getWorkStatusCorrectionTestCases() {
        return Stream.of(
                Arguments.of(
                        "workStatus corrections when income is null",
                        // applicants
                        Lists.newArrayList(
                                buildApplicantDto("workstatus=null", null),
                                buildApplicantDto("workstatus=working", WORK_STATUS_WORKING),
                                buildApplicantDto("workstatus=notworking", WORK_STATUS_NOT_WORKING)
                        ),
                        // case income
                        null,
                        // expected corrections
                        Lists.newArrayList(
                                Pair.of("workstatus=working", null),
                                Pair.of("workstatus=notworking", null)
                        )
                ),

                Arguments.of(
                        "workStatus corrections when employment status is EMPLOYED",
                        // applicants
                        Lists.newArrayList(
                                buildApplicantDto("workstatus=null", null),
                                buildApplicantDto("workstatus=working", WORK_STATUS_WORKING),
                                buildApplicantDto("workstatus=notworking", WORK_STATUS_NOT_WORKING)
                        ),
                        buildCaseIncomeWithEmploymentStatus(
                                Lists.newArrayList("workstatus=null", "workstatus=working", "workstatus=notworking"),
                                "EMPLOYED"
                        ),
                        // expected corrections
                        Lists.newArrayList(
                                Pair.of("workstatus=null", WORK_STATUS_WORKING),
                                Pair.of("workstatus=notworking", WORK_STATUS_WORKING)
                        )
                ),

                Arguments.of(
                        "workStatus corrections when employment status is RETIRED",
                        // applicants
                        Lists.newArrayList(
                                buildApplicantDto("workstatus=null", null),
                                buildApplicantDto("workstatus=working", WORK_STATUS_WORKING),
                                buildApplicantDto("workstatus=notworking", WORK_STATUS_NOT_WORKING)
                        ),
                        buildCaseIncomeWithEmploymentStatus(
                                Lists.newArrayList("workstatus=null", "workstatus=working", "workstatus=notworking"),
                                "RETIRED"
                        ),
                        // expected corrections
                        Lists.newArrayList(
                                Pair.of("workstatus=null", WORK_STATUS_NOT_WORKING),
                                Pair.of("workstatus=working", WORK_STATUS_NOT_WORKING)
                        )
                ),

                Arguments.of(
                        "workStatus corrections when applicant has no income applicant entry",
                        // applicants
                        Lists.newArrayList(
                                buildApplicantDto("workstatus=null", null),
                                buildApplicantDto("workstatus=working", WORK_STATUS_WORKING),
                                buildApplicantDto("workstatus=notworking", WORK_STATUS_NOT_WORKING)
                        ),
                        // case income with no income applicants
                        buildCaseIncomeWithEmploymentStatus(
                                Collections.emptyList(),
                                null
                        ),
                        // expected corrections
                        Lists.newArrayList(
                                Pair.of("workstatus=working", null),
                                Pair.of("workstatus=notworking", null)
                        )
                )
        );
    }

    private static ApplicantDto buildApplicantDto(String applicantId, String workStatus) {
        ApplicantDto applicantDto = new ApplicantDto();
        applicantDto.setApplicantId(applicantId);
        applicantDto.setWorkStatus(workStatus);
        return applicantDto;
    }

    private static ValidatedCaseIncomeDto buildCaseIncomeWithEmploymentStatus(List<String> applicantIds, String employmentStatus) {
        ValidatedCaseIncomeDto caseIncomeDto = new ValidatedCaseIncomeDto();
        List<IncomeApplicantDto> incomeApplicantDtoList = new ArrayList<>();
        for (String applicantId : applicantIds) {
            incomeApplicantDtoList.add(buildIncomeApplicantDto(applicantId, employmentStatus));
        }
        caseIncomeDto.setApplicants(incomeApplicantDtoList);
        return caseIncomeDto;
    }

    private static IncomeApplicantDto buildIncomeApplicantDto(String applicantId, String employmentStatus) {
        IncomeApplicantDto incomeApplicantDto = new IncomeApplicantDto();
        incomeApplicantDto.setApplicantId(applicantId);
        JobDetailsDto primaryJobDto = new JobDetailsDto();
        primaryJobDto.setEmploymentStatus(EmploymentStatus.valueOf(employmentStatus));
        incomeApplicantDto.setPrimaryJob(primaryJobDto);
        return incomeApplicantDto;
    }
}
