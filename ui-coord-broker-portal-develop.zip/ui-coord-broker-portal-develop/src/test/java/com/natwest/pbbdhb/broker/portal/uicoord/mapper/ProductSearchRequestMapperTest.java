package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductSearchRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ProductSearchTestUtil.createValidProductSearchRequest;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        ProductSearchRequestMapperImpl.class
})
public class ProductSearchRequestMapperTest {
    @Autowired
    private ProductSearchRequestMapper mapper;

    @Test
    void testToDtoMapping() {
        ProductSearchRequest request = createValidProductSearchRequest();
        ProductSearchRequestDto requestDto = this.mapper.toProductSearchRequestDto(request);

        assertThat(requestDto)
                .usingRecursiveComparison()
                .ignoringFields("customerType", "channel")
                .isEqualTo(request);

        assertThat(requestDto.getChannel()).isEqualTo("INTERMEDIARY");
        assertThat(requestDto.getCustomerType()).isEqualTo("NEW_CUSTOMER");
    }

}
