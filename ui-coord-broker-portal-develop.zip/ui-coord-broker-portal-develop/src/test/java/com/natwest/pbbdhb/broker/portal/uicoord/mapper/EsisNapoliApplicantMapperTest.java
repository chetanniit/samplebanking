package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisApplicant;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.EsisTestUtil.esisApplicantSample;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        EsisApplicantMapper.class
})
class EsisNapoliApplicantMapperTest {

    private static final String CASE_ID = "LS1677086057198";
    private static final String DEFAULT_NATIONALITY = "GB";

    @Autowired
    private EsisApplicantMapper esisMapper;

    @Test
    void testToApplicantDtoMapping() {
        final EsisApplicant esisApplicant = esisApplicantSample();

        final ApplicantDto applicantDto = this.esisMapper.toApplicantDto(esisApplicant, CASE_ID, true);

        assertThat(applicantDto.getCaseId()).isEqualTo(CASE_ID);
        PersonDetailsDto personalDetails = applicantDto.getPersonalDetails();
        assertThat(personalDetails.getTitle()).isEqualTo(esisApplicant.getTitle());
        assertThat(personalDetails.getFirstNames()).isEqualTo(esisApplicant.getFirstNames());
        assertThat(personalDetails.getMiddleNames()).isEqualTo(esisApplicant.getMiddleNames());
        assertThat(personalDetails.getLastName()).isEqualTo(esisApplicant.getLastName());
        assertThat(personalDetails.getDateOfBirth()).isEqualTo(esisApplicant.getDateOfBirth());
        assertThat(personalDetails.getNationality()).isEqualTo(DEFAULT_NATIONALITY);
    }

}