package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.SIZE_AT_LEAST_ONE_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.emptyList;
import static java.util.Collections.singleton;

public class BrokerCaseValidationTest extends AbstractValidationTest<BrokerCase> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid broker case", (Consumer<BrokerCase>) a -> {
                }, EMPTY_SET),
                Arguments.of("@NotNull annotation - error when case application is null", (Consumer<BrokerCase>) a -> a.setCaseApplication(null), singleton(create("caseApplication", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Valid broker case when applicants is null", (Consumer<BrokerCase>) a -> a.setApplicants(null), EMPTY_SET),
                Arguments.of("Applicants list is empty", (Consumer<BrokerCase>) a -> a.setApplicants(emptyList()), singleton(create("applicants", SIZE_AT_LEAST_ONE_MSG))),
                Arguments.of("@Valid annotation - error when case application invalid", (Consumer<BrokerCase>) a -> a.getCaseApplication().getMortgage().setMortgageAdvised("invalid"), singleton(create("caseApplication.mortgage.mortgageAdvised", "must be any of: ADVICE, REJECTED_ADVICE_EXECUTION_ONLY"))),
                Arguments.of("@Valid annotation - error when applicants invalid", (Consumer<BrokerCase>) a -> a.getApplicants().get(0).getPersonalDetails().setFirstNames(null), singleton(create("applicants[0].personalDetails.firstNames", MUST_NOT_BE_BLANK_ERROR_MESSAGE)))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testBrokerCaseValidations(String testDescription, Consumer<BrokerCase> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, TestUtil::createValidBrokerCase, mutator, expectedErrorMessages);
    }
}
