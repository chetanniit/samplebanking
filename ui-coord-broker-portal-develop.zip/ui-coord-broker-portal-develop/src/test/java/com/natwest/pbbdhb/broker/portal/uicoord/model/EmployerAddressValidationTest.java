package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class EmployerAddressValidationTest extends AbstractValidationTest<BasicAddress> {

    private static Stream<Arguments> employerAddressTestCases() {
        return Stream.of(
                Arguments.of("Valid employer address", (Consumer<BasicAddress>) a -> { /* no-op */ }, EMPTY_SET),
                Arguments.of("Postcode is in invalid format", (Consumer<BasicAddress>) a -> a.setPostcode("ERROR"),
                        singleton(create("postcode", "Invalid UK postcode"))
                )
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("employerAddressTestCases")
    public void testCommonEmployerAddressValidations(String testDescription, Consumer<BasicAddress> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, IncomeTestUtil::createValidEmployerAddress, mutator, expectedErrorMessages);
    }
}
