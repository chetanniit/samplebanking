package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.DipService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_DIP_WITH_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_DIP_ID;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest
@ContextConfiguration(classes = {DipController.class, ControllerAdvice.class})
class DipControllerTest {

  @MockBean
  private DipService dipService;

  @MockBean
  private UserClaimsProvider userClaimsProvider;

  @Autowired
  private MockMvc mockMvc;


  @Test
  public void getExpiredDipCertificateShouldThrowDipUnhandledValidationException() throws Exception {

    when(dipService.getDipCertificateWithCaseId(any(), any()))
        .thenThrow(new DipIntegrationException("DIP has expired, create a new DIP"));

    RequestBuilder request = get(PATH_GET_DIP_WITH_CASE_ID, TEST_DIP_ID);

    this.mockMvc.perform(request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.status").value("400"))
        .andExpect(jsonPath("$.title").value("DIP Submit Unhandled Validation Errors"))
        .andExpect(jsonPath("$.errors[0].status").value("400"))
        .andExpect(jsonPath("$.errors[0].code").value("VALIDATION_EXPIRED_DIP"))
        .andExpect(jsonPath("$.errors[0].message").value("DIP has expired, create a new DIP"));
  }

  @Test
  public void getExpiredDipCertificateShouldThrowDipIntegrationException() throws Exception {

    when(dipService.getDipCertificateWithCaseId(any(), any()))
        .thenThrow(new DipIntegrationException("Some test text"));

    RequestBuilder request = get(PATH_GET_DIP_WITH_CASE_ID, TEST_DIP_ID);

    this.mockMvc.perform(request)
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.status").value("500"))
        .andExpect(jsonPath("$.title").value("Internal Server Error"))
        .andExpect(jsonPath("$.description").value("Our backend is non-functional, please try again later."));
  }

  @Test
  public void getExpiredDipCertificateShouldSucceed() throws Exception {

    RequestBuilder request = get(PATH_GET_DIP_WITH_CASE_ID, TEST_DIP_ID);

    this.mockMvc.perform(request)
        .andExpect(status().isOk());
  }

}