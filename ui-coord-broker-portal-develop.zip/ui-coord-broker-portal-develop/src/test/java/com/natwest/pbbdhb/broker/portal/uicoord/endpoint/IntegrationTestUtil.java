package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.*;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipTestUtil.getBasicApplicants;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@Slf4j
public class IntegrationTestUtil {
    private IntegrationTestUtil() {
    }

    public static BrokerCase submitDip(String caseId, TokenConfiguration tokenConfig) {
        Response response = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .post(PATH_SUBMIT_DIP);

        log.info("submitDip response: {}", response.body().asString());

        return response
                .then()
                .extract()
                .as(BrokerCase.class);
    }

    public static BrokerCase updateBrokerCase(BrokerCase brokerCase) {
        return updateBrokerCase(brokerCase, null);
    }

    public static BrokerCase updateBrokerCase(BrokerCase brokerCase, TokenConfiguration tokenConfig) {
        String caseId = brokerCase.getCaseApplication().getCaseId();
        return saveBrokerCase(caseId, brokerCase, tokenConfig);
    }

    public static BrokerCase saveBrokerCase(String caseId, BrokerCase brokerCase) {
        return saveBrokerCase(caseId, brokerCase, null);
    }

    public static BrokerCase saveBrokerCase(String caseId, BrokerCase brokerCase, TokenConfiguration tokenConfig) {
        Response response = with()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .contentType(APPLICATION_JSON_VALUE)
                .body(brokerCase)
                .put(PATH_SAVE_BROKER_CASE);

        log.info("saveBrokerCase response: {}", response.body().asString());

        return response
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);
    }

    public static String getNewCaseId() {
        return getNewCaseId(null);
    }

    public static String getNewCaseId(TokenConfiguration tokenConfig) {
        return with()
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_CASE_ID)
                .then()
                .extract()
                .asString();
    }

    public static BrokerCase createBasicBrokerCase() {
        String caseId = getNewCaseId(null);
        return createBasicBrokerCase(caseId, null);
    }

    public static BrokerCase createBasicBrokerCase(TokenConfiguration tokenConfig) {
        String caseId = getNewCaseId(tokenConfig);
        return createBasicBrokerCase(caseId, tokenConfig);
    }

    public static BrokerCase createBasicBrokerCase(String caseId) {
        return createBasicBrokerCase(caseId, null);
    }

    public static BrokerCase createBasicBrokerCase(String caseId, TokenConfiguration tokenConfig) {
        BrokerCase basicBrokerCase = buildBasicBrokerCase();
        return saveBrokerCase(caseId, basicBrokerCase, tokenConfig);
    }

    public static BrokerCase buildBasicBrokerCase() {
        BrokerCase basicBrokerCase = new BrokerCase();

        CaseApplication basicCaseApplication = new CaseApplication();
        basicCaseApplication.setCurrentRoute("/dip/ApplicantDetails");
        basicBrokerCase.setCaseApplication(basicCaseApplication);

        List<Applicant> applicants = new ArrayList<>();
        applicants.add(buildBasicApplicant());
        basicBrokerCase.setApplicants(applicants);

        return basicBrokerCase;
    }

    public static Applicant buildBasicApplicant() {
        Applicant applicant = new Applicant();
        PersonalDetails personalDetails = createValidPersonalDetails();
        applicant.setPersonalDetails(personalDetails);
        applicant.setAddresses(createValidPersonalAddresses());
        applicant.setConsentToDIP(true);
        applicant.setMainApplicant(true);
        CreditHistory creditHistory = new CreditHistory();
        creditHistory.setBankrupt(false);
        creditHistory.setCourtProceedings(false);
        applicant.setCreditHistory(creditHistory);
        applicant.setExistingMortgages(createExistingMortgages());
        applicant.setMarketingPreferences(createMarketingPreferences());
        return applicant;
    }

    public static String insertNewBrokerCaseIntoCapie(BrokerCase brokerCase, TokenConfiguration tokenConfig) {
        String caseId = getNewCaseId(tokenConfig);

        BrokerCase basicBrokerCase = new BrokerCase();
        CaseApplication basicCaseApplication = new CaseApplication();
        basicCaseApplication.setCaseId(caseId);
        basicCaseApplication.setCurrentRoute("/dip/ApplicationDetails");
        basicBrokerCase.setCaseApplication(basicCaseApplication);
        List<Applicant> basicApplicants = getBasicApplicants(brokerCase.getApplicants());
        basicBrokerCase.setApplicants(basicApplicants);

        BrokerCase newBrokerCase = saveBrokerCase(caseId, basicBrokerCase, tokenConfig);
        List<Applicant> newApplicants = newBrokerCase.getApplicants();

        brokerCase.getCaseApplication().setCaseId(caseId);
        brokerCase.getCaseApplication().setVersion(newBrokerCase.getCaseApplication().getVersion());
        List<Applicant> applicants = brokerCase.getApplicants();
        List<IncomeApplicant> incomeApplicants = brokerCase.getIncome().getApplicants();
        List<ExpenseApplicant> expenseApplicants = brokerCase.getExpense().getApplicants();
        for (int i = 0; i < applicants.size(); i++) {
            Applicant newApplicant = newApplicants.get(i);
            applicants.get(i).setVersion(newApplicant.getVersion());

            String applicantId = newApplicant.getApplicantId();
            applicants.get(i).setApplicantId(applicantId);
            incomeApplicants.get(i).setApplicantId(applicantId);
            expenseApplicants.get(i).setApplicantId(applicantId);
        }

        saveBrokerCase(caseId, brokerCase, tokenConfig);
        return caseId;
    }

}
