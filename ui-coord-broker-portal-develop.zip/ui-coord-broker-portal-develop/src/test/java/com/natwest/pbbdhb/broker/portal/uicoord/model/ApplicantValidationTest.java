package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class ApplicantValidationTest extends AbstractValidationTest<Applicant> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid applicant", (Consumer<Applicant>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid applicant with null applicant id and version", (Consumer<Applicant>) a -> {
                    a.setApplicantId(null);
                    a.setVersion(null);
                }, EMPTY_SET),
                Arguments.of("Valid applicant with null personal details", (Consumer<Applicant>) a -> a.setPersonalDetails(null), EMPTY_SET),
                Arguments.of("Valid applicant with minimum intended retirement age", (Consumer<Applicant>) a -> a.setIntendedRetirementAge(18), EMPTY_SET),
                Arguments.of("Intended retirement age is below minimum value", (Consumer<Applicant>) a -> a.setIntendedRetirementAge(17), singleton(create("intendedRetirementAge", "must be greater than or equal to 18"))),
                Arguments.of("Valid applicant with maximum intended retirement age", (Consumer<Applicant>) a -> a.setIntendedRetirementAge(99), EMPTY_SET),
                Arguments.of("Intended retirement age is above maximum value", (Consumer<Applicant>) a -> a.setIntendedRetirementAge(100), singleton(create("intendedRetirementAge", "must be less than or equal to 99"))),
                Arguments.of("@Valid annotation - error when applicantDetails.name invalid", (Consumer<Applicant>) a -> a.getPersonalDetails().setTitle(null), singleton(create("personalDetails.title", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("mainApplicant - error when null", (Consumer<Applicant>) a -> a.setMainApplicant(null), singleton(create("mainApplicant", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("consentToDIP - error when null", (Consumer<Applicant>) a -> a.setConsentToDIP(null), singleton(create("consentToDIP", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("consentToDIP - error when false", (Consumer<Applicant>) a -> a.setConsentToDIP(false), singleton(create("consentToDIP", "must be true"))),
                Arguments.of("consentToFMA - error when false", (Consumer<Applicant>) a -> a.setConsentToFMA(false), singleton(create("consentToFMA", "must be true"))),
                Arguments.of("creditHistory - error when null", (Consumer<Applicant>) a -> a.setCreditHistory(null), singleton(create("creditHistory", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("@Valid creditHistory - error when bankrupt is null", (Consumer<Applicant>) a -> a.getCreditHistory().setBankrupt(null), singleton(create("creditHistory.bankrupt", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("@Valid creditHistory - error when courtProceedings is null", (Consumer<Applicant>) a -> a.getCreditHistory().setCourtProceedings(null), singleton(create("creditHistory.courtProceedings", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Valid applicant with null main bank details", (Consumer<Applicant>) a -> a.setMainBankDetails(null), EMPTY_SET),
                Arguments.of("Valid applicant with null futureAffordability.commitmentsDueDuringMortgage",
                        (Consumer<Applicant>) a -> a.getFutureAffordability().setCommitmentsDueDuringMortgage(null),
                        singleton(create("futureAffordability.commitmentsDueDuringMortgage", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Valid applicant with null futureAffordability.otherCommitments",
                        (Consumer<Applicant>) a -> a.getFutureAffordability().setOtherCommitments(null),
                        singleton(create("futureAffordability.otherCommitments", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Valid applicant with null futureAffordability.propertyExpensesAffectingMortgagePayment",
                        (Consumer<Applicant>) a -> a.getFutureAffordability().setPropertyExpensesAffectingMortgagePayment(null),
                        singleton(create("futureAffordability.propertyExpensesAffectingMortgagePayment", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Valid applicant with null futureAffordability.personalChangesAmountAffectingTheMortgagePayment",
                        (Consumer<Applicant>) a -> a.getFutureAffordability().setPersonalChangesAmountAffectingTheMortgagePayment(null),
                        singleton(create("futureAffordability.personalChangesAmountAffectingTheMortgagePayment", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Other Title length is below minimum value",
                        (Consumer<Applicant>) a -> a.getPersonalDetails().setOtherTitle(""),
                        singleton(create("personalDetails.otherTitle", "size must be between 1 and 15"))),
                Arguments.of("Other Title length is exactly minimum value",
                        (Consumer<Applicant>) a -> a.getPersonalDetails().setOtherTitle("1"),
                        EMPTY_SET),
                Arguments.of("Other Title length is exactly maximum value",
                        (Consumer<Applicant>) a -> a.getPersonalDetails().setOtherTitle("123456789012345"),
                        EMPTY_SET),
                Arguments.of("Other Title length is above maximum value",
                        (Consumer<Applicant>) a -> a.getPersonalDetails().setOtherTitle("1234567890123456"),
                        singleton(create("personalDetails.otherTitle", "size must be between 1 and 15"))),
                Arguments.of("Lender name is null",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setLenderName(null),
                        singleton(create("existingMortgages[0].lenderName", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Lender name is too long",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setLenderName("1234567891234567891234567891234"),
                        singleton(create("existingMortgages[0].lenderName", "size must be between 0 and 30"))),
                Arguments.of("Monthly repayment amount is null",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setMonthlyRepaymentAmount(null),
                        singleton(create("existingMortgages[0].monthlyRepaymentAmount", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Redeeming mortgage is null",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setRedeemingMortgage(null),
                        singleton(create("existingMortgages[0].redeemingMortgage", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Type is null",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setType(null),
                        singleton(create("existingMortgages[0].type", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Type is blank",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setType(""),
                        singleton(create("existingMortgages[0].type", "must be any of: RESIDENTIAL, BUY_TO_LET"))),
                Arguments.of("Ownership is null",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setOwnership(null),
                        singleton(create("existingMortgages[0].ownership", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Ownership is blank",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setOwnership(""),
                        singleton(create("existingMortgages[0].ownership", "must be any of: JOINT, SINGLE"))),
                Arguments.of("Outstanding amount is null",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setOutstandingAmount(null),
                        singleton(create("existingMortgages[0].outstandingAmount", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Originating Currency is valid",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(1).setOriginatingCurrency("EUR"),
                        EMPTY_SET),
                Arguments.of("Originating Currency is invalid",
                        (Consumer<Applicant>) a -> a.getExistingMortgages().get(0).setOriginatingCurrency("PRTL"),
                        singleton(create("existingMortgages[0].originatingCurrency", "must be any of: GBP, EUR, AUD, BHD, CAD, DKK, HKD, JPY, NZD, NOK, OMR, QAR, SAR, SGD, SEK, CHF, AED, USD, KWD, CNY, BMD, INR")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testApplicantValidations(String testDescription, Consumer<Applicant> mutator, Set<AbstractValidationTest.TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, ApplicantTestUtil::createValidApplicant, mutator, expectedErrorMessages);
    }
}
