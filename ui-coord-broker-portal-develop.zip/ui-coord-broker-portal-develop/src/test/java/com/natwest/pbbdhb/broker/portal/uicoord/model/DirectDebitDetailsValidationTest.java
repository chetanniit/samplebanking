package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicantTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_5_OR_6_DIGITS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_8_DIGITS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_BLANK_ERROR_MESSAGE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.MUST_NOT_BE_NULL_ERROR_MESSAGE;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;

public class DirectDebitDetailsValidationTest extends AbstractValidationTest<DirectDebitDetails> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid direct debit details", (Consumer<DirectDebitDetails>) a -> {}, EMPTY_SET),
                Arguments.of("Direct debit details with null accountName", (Consumer<DirectDebitDetails>) a -> a.setAccountName(null), singleton(create("accountName", MUST_NOT_BE_BLANK_ERROR_MESSAGE))),
                Arguments.of("Direct debit details with null sortCode", (Consumer<DirectDebitDetails>) a -> a.setSortCode(null), singleton(create("sortCode", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Direct debit details with sort code too short", (Consumer<DirectDebitDetails>) a -> a.setSortCode("1234"), singleton(create("sortCode", MUST_BE_5_OR_6_DIGITS))),
                Arguments.of("Direct debit details with sort code too long", (Consumer<DirectDebitDetails>) a -> a.setSortCode("1234567"), singleton(create("sortCode", MUST_BE_5_OR_6_DIGITS))),
                Arguments.of("Direct debit details with non-numeric sort code", (Consumer<DirectDebitDetails>) a -> a.setSortCode("ABCDEF"), singleton(create("sortCode", MUST_BE_5_OR_6_DIGITS))),
                Arguments.of("Direct debit details with null accountNumber", (Consumer<DirectDebitDetails>) a -> a.setAccountNumber(null), singleton(create("accountNumber", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Direct debit details with sort code too short", (Consumer<DirectDebitDetails>) a -> a.setAccountNumber("1234567"), singleton(create("accountNumber", MUST_BE_8_DIGITS))),
                Arguments.of("Direct debit details with sort code too long", (Consumer<DirectDebitDetails>) a -> a.setAccountNumber("123456789"), singleton(create("accountNumber", MUST_BE_8_DIGITS))),
                Arguments.of("Direct debit details with non-numeric sort code", (Consumer<DirectDebitDetails>) a -> a.setAccountNumber("ABCDEFGH"), singleton(create("accountNumber", MUST_BE_8_DIGITS))),
                Arguments.of("Direct debit details with null paymentDayOfTheMonth", (Consumer<DirectDebitDetails>) a -> a.setPaymentDayOfTheMonth(null), singleton(create("paymentDayOfTheMonth", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("Direct debit details with paymentDayOfTheMonth zero", (Consumer<DirectDebitDetails>) a -> a.setPaymentDayOfTheMonth(0), singleton(create("paymentDayOfTheMonth", "must be greater than or equal to 1"))),
                Arguments.of("Direct debit details with paymentDayOfTheMonth 29", (Consumer<DirectDebitDetails>) a -> a.setPaymentDayOfTheMonth(29), singleton(create("paymentDayOfTheMonth", "must be less than or equal to 28")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    public void testDirectDebitDetailsValidations(String testDescription, Consumer<DirectDebitDetails> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidDirectDebitDetails, mutator, expectedErrorMessages);
    }
}
