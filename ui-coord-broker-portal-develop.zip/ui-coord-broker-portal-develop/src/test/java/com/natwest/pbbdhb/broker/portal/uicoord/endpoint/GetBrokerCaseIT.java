package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.IncomeApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.getNewCaseId;
import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.saveBrokerCase;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_CASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.readBrokerCaseFromResource;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class GetBrokerCaseIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Value("classpath:test-files/broker-cases/create-broker-case-request.json")
    private Resource createBrokerCaseRequest;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void getBrokerCaseReturnsSavedBrokerCase() throws IOException {
        String caseId = getNewCaseId(tokenConfig);
        BrokerCase storedBrokerCase = storeTestBrokerCase(caseId);

        BrokerCase brokerCaseResponse = with()
                .log().all()
                .pathParam(CASE_ID_PARAM, caseId)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_BROKER_CASE)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(BrokerCase.class);

        assertThat(brokerCaseResponse).isEqualTo(storedBrokerCase);
    }

    @Test
    void getBrokerCase404ResponseWhenNoMatchingCase() {
        with()
                .log().all()
                .pathParam(CASE_ID_PARAM, "case-does-not-exist")
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_BROKER_CASE)
                .then()
                .statusCode(404);
    }

    private BrokerCase storeTestBrokerCase(String caseId) throws IOException {
        BrokerCase createdBrokerCase = createBrokerCase(caseId);
        return addIncomeToBrokerCase(createdBrokerCase, caseId);
    }

    private BrokerCase createBrokerCase(String caseId) throws IOException {
        BrokerCase requestedBrokerCase = readBrokerCaseFromResource(createBrokerCaseRequest);
        return saveBrokerCase(caseId, requestedBrokerCase, tokenConfig);
    }

    private BrokerCase addIncomeToBrokerCase(BrokerCase brokerCase, String caseId) {
        String applicantId = brokerCase.getApplicants().get(0).getApplicantId();

        // NOTE: Could improve readability by storing CaseIncome as JSON and deserialising here.
        CaseIncome income = new CaseIncome();
        income.setVersion(null);
        List<IncomeApplicant> incomeApplicants = new ArrayList<>();
        IncomeApplicant incomeApplicant = new IncomeApplicant();
        JobDetails primaryJob = new JobDetails();
        primaryJob.setEmploymentStatus("EMPLOYED");
        primaryJob.setOccupationType("ACADEMIC_STAFF");
        primaryJob.setPayslipFrequency("MONTHLY");
        primaryJob.setEmploymentStartDate("2021-12-15");
        primaryJob.setBasicPayAnnualIncome(BigDecimal.valueOf(25_000L));
        incomeApplicant.setPrimaryJob(primaryJob);
        incomeApplicants.add(incomeApplicant);
        income.setApplicants(incomeApplicants);
        brokerCase.setIncome(income);

        brokerCase.getIncome().getApplicants().get(0).setApplicantId(applicantId);

        return saveBrokerCase(caseId, brokerCase, tokenConfig);
    }
}
