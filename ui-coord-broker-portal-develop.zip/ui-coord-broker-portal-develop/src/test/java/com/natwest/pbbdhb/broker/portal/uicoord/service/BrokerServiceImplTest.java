package com.natwest.pbbdhb.broker.portal.uicoord.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInfoMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInfoMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInformationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInformationMapperImpl;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerInformation;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import java.math.BigDecimal;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Base64Utils;

@ExtendWith({
    MockitoExtension.class,
    SpringExtension.class
})
@ContextConfiguration(classes = {
    BrokerInfoMapperImpl.class,
    BrokerInformationMapperImpl.class
})
@Slf4j
class BrokerServiceImplTest {

  @Autowired
  BrokerInfoMapper brokerInfoMapper;

  @Autowired
  BrokerInformationMapper brokerInformationMapper;

  ObjectMapper om = new ObjectMapper();

  @ParameterizedTest
  @MethodSource("getBrokerProductSwitchDetailsTestArguments")
  @SneakyThrows
  void getBrokerProductSwitchDetailsTest(String paymentPathName, String brokerInfoResponseJson, String expectedXml) {
    log.info("brokerInfoResponseJson:\n{}", brokerInfoResponseJson);
    BrokerInfoResponseDto brokerInfoResponseDto = om.readValue(brokerInfoResponseJson, BrokerInfoResponseDto.class);
    log.info("brokerInfoResponseDto:\n{}", brokerInfoResponseDto);
    BrokerInfo brokerInfo = brokerInfoMapper.toBroker(brokerInfoResponseDto);
    log.info("brokerInfo:\n{}", brokerInfo);
    BrokerInformation brokerInforrmation = brokerInformationMapper
        .toBrokerInformation(brokerInfo, paymentPathName, BigDecimal.ONE);
    String encoded = brokerInforrmation.generateEncodedXml();
    byte[] decoded = Base64Utils.decodeFromString(encoded);
    String decodedString = new String(decoded);
    //log.info("decoded:\n{}", decodedString);
    assertThat(decodedString).isEqualTo(expectedXml);
  }

  // paymentPathName, brokerInfoResponseJson, expectedXml
  private static Stream<Arguments> getBrokerProductSwitchDetailsTestArguments() {
    return Stream.of(
        Arguments.of(
            "2 Plan Wealth Management Limited",
            "{\"mbs_message\":\"Broker Data found\",\"mbs_paymentpaths\":[{\"mbs_paymentpathid\":\"429578666\",\"mbs_paymentpathname\":\"2 Plan Wealth Management\",\"mbs_residentialproductscale\":\"3\",\"mbs_btlproductscale\":\"2\"}],\"mbs_broker\":{\"mbs_brokerid\":\"281578168\",\"mbs_username\":\"RCampling\",\"mbs_title\":\"Mr\",\"mbs_firstname\":\"Robert\",\"mbs_lastname\":\"Campling\",\"mbs_emailaddress\":\"rob.campling@2plan.com\",\"mbs_businessphone\":\"0208 318 1848\",\"mbs_mobilenumber\":null,\"mbs_brokerpostcode\":\"LS11 5BZ\"},\"mbs_brokerupdaterequest\":null,\"mbs_firm\":{\"mbs_firmid\":\"13378886\",\"mbs_firmname\":\"Birch Financial Services\",\"mbs_fcanumber\":\"461598\",\"mbs_principlefcanumber\":null,\"mbs_firmaddress_line1\":\"Bridgewater Place\",\"mbs_firmaddress_line2\":\"Water Lane\",\"mbs_firmaddress_line3\":null,\"mbs_firmaddress_postcode\":\"LS11 5BZ\",\"mbs_firmaddress_city\":\"Leeds\",\"mbs_firmaddress_county\":\"West Yorkshire\",\"mbs_firmaddress_country\":null,\"mbs_statusdate\":\"5/27/2022\"},\"mbs_tradingName\":{\"mbs_name\":\"2 Plan Wealth Management Limited\",\"mbs_type\":\"Registered\",\"mbs_effectivedate\":null}}",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><ProductSwitch xmlns=\"http://www.focus-solutions.co.uk/focus360/1.0\"><BrokerName><Title>Mr</Title><Forename>Robert</Forename><Surname>Campling</Surname></BrokerName><FirmName>2 Plan Wealth Management Limited</FirmName><Address><POBoxNumber/><HouseNameNumber>Bridgewater Place</HouseNameNumber><AddressLine1>Water Lane</AddressLine1><AddressLine2/><AddressLine3/><City>Leeds</City><County>West Yorkshire</County><Postcode>LS11 5BZ</Postcode><Country/></Address><EmailAddress>rob.campling@2plan.com</EmailAddress><FCAReference>461598</FCAReference><NetworkInfo>2 Plan Wealth Management Limited</NetworkInfo><BrokerPhoneNumber>02083181848</BrokerPhoneNumber><ProcFee>1</ProcFee></ProductSwitch>"
        ),
        Arguments.of(
            "Paradigm Mortgage Club (DA)",
            "{\"mbs_message\":\"Broker Data found\",\"mbs_paymentpaths\":[{\"mbs_paymentpathid\":\"229181986\",\"mbs_paymentpathname\":\"Paradigm Mortgage Club (DA)\",\"mbs_residentialproductscale\":\"4\",\"mbs_btlproductscale\":\"2\"},{\"mbs_paymentpathid\":\"212929233\",\"mbs_paymentpathname\":\"Premier Mortgage Services\",\"mbs_residentialproductscale\":\"4\",\"mbs_btlproductscale\":\"2\"},{\"mbs_paymentpathid\":\"212929211\",\"mbs_paymentpathname\":\"TMA Club\",\"mbs_residentialproductscale\":\"4\",\"mbs_btlproductscale\":\"2\"}],\"mbs_broker\":{\"mbs_brokerid\":\"700020029\",\"mbs_username\":\"AlexReynolds\",\"mbs_title\":\"Mr\",\"mbs_firstname\":\"Alex\",\"mbs_lastname\":\"Reynolds\",\"mbs_emailaddress\":\"alex.reynolds@advies.co.uk\",\"mbs_businessphone\":null,\"mbs_mobilenumber\":\"07769942828\",\"mbs_brokerpostcode\":\"EC3A 6DQ\"},\"mbs_brokerupdaterequest\":{\"mbs_requesttype\":[\"Address Change\"],\"mbs_status\":\"In Progress\"},\"mbs_firm\":{\"mbs_firmid\":\"800002767\",\"mbs_firmname\":\"Advies Private Clients LLP\",\"mbs_fcanumber\":\"937655\",\"mbs_principlefcanumber\":null,\"mbs_firmaddress_line1\":\"15-16\",\"mbs_firmaddress_line2\":\"St Helen's Place\",\"mbs_firmaddress_line3\":null,\"mbs_firmaddress_postcode\":\"EC3A 6DQ\",\"mbs_firmaddress_city\":\"London\",\"mbs_firmaddress_county\":null,\"mbs_firmaddress_country\":null,\"mbs_statusdate\":\"8/4/2023\"},\"mbs_tradingName\":{\"mbs_name\":\"Advies Private Clients LLP\",\"mbs_type\":\"Registered\",\"mbs_effectivedate\":null}}",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><ProductSwitch xmlns=\"http://www.focus-solutions.co.uk/focus360/1.0\"><BrokerName><Title>Mr</Title><Forename>Alex</Forename><Surname>Reynolds</Surname></BrokerName><FirmName>Advies Private Clients LLP</FirmName><Address><POBoxNumber/><HouseNameNumber>15-16</HouseNameNumber><AddressLine1>St Helen's Place</AddressLine1><AddressLine2/><AddressLine3/><City>London</City><County/><Postcode>EC3A 6DQ</Postcode><Country/></Address><EmailAddress>alex.reynolds@advies.co.uk</EmailAddress><FCAReference>937655</FCAReference><NetworkInfo>Paradigm Mortgage Club (DA)</NetworkInfo><BrokerPhoneNumber>07769942828</BrokerPhoneNumber><ProcFee>1</ProcFee></ProductSwitch>"
        )
    );
  }
}