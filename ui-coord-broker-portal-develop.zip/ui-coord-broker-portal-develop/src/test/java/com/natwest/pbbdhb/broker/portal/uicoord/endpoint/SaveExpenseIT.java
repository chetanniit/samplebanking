package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.portal.uicoord.endpoint.IntegrationTestUtil.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ExpenseTestUtil.createValidCaseExpense;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class SaveExpenseIT {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LocalServerPort
    private int port;

    @Autowired
    private TokenConfiguration tokenConfig;

    @MockBean
    private BrokerInfoClient brokerInfoClient;


    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

    @Test
    public void saveBrokerCaseCreatesAndUpdatesExpense() {
        BrokerCase brokerCase = createBasicBrokerCase(tokenConfig);
        String caseId = brokerCase.getCaseApplication().getCaseId();

        List<String> applicantIds = brokerCase.getApplicants().stream()
                .map(Applicant::getApplicantId)
                .collect(Collectors.toList());

        brokerCase.setExpense(createValidCaseExpense(applicantIds));
        // set version to null to trigger creating a new expense record
        brokerCase.getExpense().setVersion(null);

        BrokerCase brokerCaseWithExpense = saveBrokerCase(caseId, brokerCase, tokenConfig);
        assertNotNull(brokerCaseWithExpense.getExpense());

        BigDecimal newAmount = BigDecimal.valueOf(4321);

        // change a value in the expense
        brokerCaseWithExpense.getExpense().getApplicants().get(0).getTransactions()
                .forEach((key, transaction) -> {
                    // ensure the amount was not already equal to the 'new' amount
                    assertNotEquals(newAmount, transaction.getAmount());
                    transaction.setAmount(newAmount);
                });

        BrokerCase brokerCaseAfterExpenseUpdate = saveBrokerCase(caseId, brokerCaseWithExpense, tokenConfig);
        brokerCaseAfterExpenseUpdate.getExpense().getApplicants().get(0).getTransactions()
                .forEach((key, transaction) -> assertEquals(newAmount, transaction.getAmount()));

        assertThat(brokerCaseAfterExpenseUpdate)
                .usingRecursiveComparison()
                .ignoringFields("caseApplication.version", "applicants.version", "expense.version")
                .isEqualTo(brokerCaseWithExpense);
    }
}
