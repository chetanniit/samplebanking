package com.natwest.pbbdhb.broker.portal.uicoord.endpoint;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_ESIS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_ESIS_DOC_INFO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SAVE_ESIS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_UPDATE_ESIS_DOC_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getResourceText;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil.JWT_HEADER;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisDocumentDescription;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles(profiles = "secured-uat")
@Slf4j
public class EsisIT {

    private final ResourceLoader resourceLoader;
    private final String contextPath;
    private final int port;
    private final TokenConfiguration tokenConfig;
    private final Resource sendEsisDefault;

    @MockBean
    private BrokerInfoClient brokerInfoClient;

    @Autowired
    public EsisIT(ResourceLoader resourceLoader,
                  TokenConfiguration tokenConfig,
                  @Value("${server.servlet.context-path}")
                  String contextPath,
                  @LocalServerPort
                  int port,
                  @Value("classpath:test-files/esis/test-cases/send-esis-default.json")
                  Resource sendEsisDefault) {
        this.resourceLoader = resourceLoader;
        this.contextPath = contextPath;
        this.port = port;
        this.tokenConfig = tokenConfig;
        this.sendEsisDefault = sendEsisDefault;
    }

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost" + contextPath;
        RestAssured.port = this.port;
        when(brokerInfoClient.readBroker(any())).thenReturn(BrokerInfoTestUtil.brokerInfoDto());
    }

    @AfterEach
    public void cleanUp() {
        RestAssured.baseURI = RestAssured.DEFAULT_URI;
        RestAssured.port = RestAssured.UNDEFINED_PORT;
    }

  @ParameterizedTest
  @ValueSource(strings = {
      "classpath:test-files/esis/test-cases/send-esis-default.json"
  })
  public void shouldPostEsisDocumentAndGetPdf(String resourceString) throws IOException {
    Resource resource = resourceLoader.getResource(resourceString);
    Response postEsisDocument = with()
        .header(BRAND_HEADER, BRAND_DEFAULT)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .body(getResourceText(resource))
        .contentType(APPLICATION_JSON_VALUE)
        .post(PATH_SAVE_ESIS);

    EsisResponse getPdfName = postEsisDocument
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_JSON_VALUE)
        .extract()
        .as(EsisResponse.class);

    Response getEsisDocument = with()
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .get(PATH_GET_ESIS, getPdfName.getDocumentName());

    getEsisDocument
        .then()
        .statusCode(HttpStatus.OK.value())
        .contentType(APPLICATION_PDF_VALUE);
  }

  @ParameterizedTest
  @ValueSource(strings = {
      "classpath:test-files/esis/test-cases/send-esis-tracker-broken.json"
  })
  public void shouldPostEsisDocumentAndGet400(String resourceString) throws IOException {
    Resource resource = resourceLoader.getResource(resourceString);
    Response postEsisDocument = with()
        .header(BRAND_HEADER, BRAND_DEFAULT)
        .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
        .body(getResourceText(resource))
        .contentType(APPLICATION_JSON_VALUE)
        .post(PATH_SAVE_ESIS);

    postEsisDocument
        .then()
        .statusCode(HttpStatus.BAD_REQUEST.value())
        .contentType(APPLICATION_JSON_VALUE);
  }

    @ParameterizedTest
    @ValueSource(strings = {
            "classpath:test-files/esis/test-cases/send-esis-mixed-with-cashback.json",
            "classpath:test-files/esis/test-cases/send-esis-2year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-3year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-4year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-5year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-6year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-7year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-10year-product.json",
            "classpath:test-files/esis/test-cases/send-esis-interestonly.json",
            "classpath:test-files/esis/test-cases/send-esis-mixed.json",
            "classpath:test-files/esis/test-cases/send-esis-foreigncurrency.json",
            "classpath:test-files/esis/test-cases/send-esis-remortgage.json",
            "classpath:test-files/esis/test-cases/send-esis-tracker.json",
            "classpath:test-files/esis/test-cases/send-esis-scheme-sharedequity.json",
            "classpath:test-files/esis/test-cases/send-esis-scheme-other.json",
            "classpath:test-files/esis/test-cases/send-esis-scheme-righttobuy.json",
            "classpath:test-files/esis/test-cases/send-esis-scheme-htb-sharedequity.json"
    })
    public void shouldWorkWithAllAlternativeScenarios(String resourceString) throws IOException {
        shouldPostEsisDocumentAndGetPdf(resourceString);
    }

    @Test
    public void shouldUpdateDocumentDescription() throws IOException {
        String description = "This is a document description";

        EsisResponse postEsisDocumentResponse = with()
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .body(getResourceText(sendEsisDefault))
                .contentType(APPLICATION_JSON_VALUE)
                .post(PATH_SAVE_ESIS)
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(EsisResponse.class);

        EsisDocumentDescription documentDescription = new EsisDocumentDescription();
        documentDescription.setDocumentDescription(description);

        with()
                .header(BRAND_HEADER, BRAND_DEFAULT)
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .body(documentDescription)
                .contentType(APPLICATION_JSON_VALUE)
                .post(PATH_UPDATE_ESIS_DOC_DESCRIPTION, postEsisDocumentResponse.getCaseId())
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE);

        EsisResponse getDocumentInfoWithDescriptionResponse = with()
                .header(JWT_HEADER, TokensUtil.createJwt(tokenConfig))
                .get(PATH_GET_ESIS_DOC_INFO, postEsisDocumentResponse.getCaseId())
                .then()
                .statusCode(HttpStatus.OK.value())
                .contentType(APPLICATION_JSON_VALUE)
                .extract()
                .as(EsisResponse.class);

        assertThat(getDocumentInfoWithDescriptionResponse.getDocumentDescription()).isEqualTo(description);
        assertThat(getDocumentInfoWithDescriptionResponse).usingRecursiveComparison().ignoringFields("documentDescription").isEqualTo(postEsisDocumentResponse);
    }
}
