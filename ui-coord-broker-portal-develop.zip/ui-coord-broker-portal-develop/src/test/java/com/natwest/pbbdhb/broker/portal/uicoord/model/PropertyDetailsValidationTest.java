package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.util.PropertyDetailsTestUtil;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.google.common.collect.Sets.newHashSet;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

// TODO - FMA specific validation has been commented out until the `validation-type` header is utilised with CAPIE to distinguish between DIP & FMA validation
public class PropertyDetailsValidationTest extends AbstractValidationTest<PropertyDetails> {

    private static Stream<Arguments> testCases() {
        return Stream.of(
                Arguments.of("Valid property details", (Consumer<PropertyDetails>) p -> {
                }, EMPTY_SET),
//                Arguments.of("propertyDetails.address is null",
//                        (Consumer<PropertyDetails>) p -> p.setAddress(null),
//                        singleton(create("address", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("propertyDetails.address.flatNameOrNumber is greater than 10 characters",
                        (Consumer<PropertyDetails>) p -> p.getAddress().setFlatNameOrNumber(randomAlphabetic(11)),
                        singleton(create("address.flatNameOrNumber", "size must be between 0 and 10"))),
                Arguments.of("propertyDetails.address.houseName is greater than 22 characters",
                        (Consumer<PropertyDetails>) p -> p.getAddress().setHouseName(randomAlphabetic(23)),
                        singleton(create("address.houseName", "size must be between 0 and 22"))),
                Arguments.of("propertyDetails.address.houseNumber is greater than 5 characters",
                        (Consumer<PropertyDetails>) p -> p.getAddress().setHouseNumber(randomAlphabetic(6)),
                        singleton(create("address.houseNumber", "size must be between 0 and 5"))),
                Arguments.of("propertyDetails.address.street is greater than 30 characters",
                        (Consumer<PropertyDetails>) p -> p.getAddress().setStreet(randomAlphabetic(31)),
                        singleton(create("address.street", "size must be between 0 and 30"))),
                Arguments.of("propertyDetails.address.town is greater than 28 characters",
                        (Consumer<PropertyDetails>) p -> p.getAddress().setTown(randomAlphabetic(29)),
                        singleton(create("address.town", "size must be between 0 and 28"))),
                Arguments.of("propertyDetails.address.postcode is greater than 8 characters",
                        (Consumer<PropertyDetails>) p -> p.getAddress().setPostcode(randomAlphabetic(9)),
                        newHashSet(create("address.postcode", "Invalid UK postcode"), create("address.postcode", "size must be between 0 and 8"))),
//                Arguments.of("propertyDetails.numberBedrooms is null",
//                        (Consumer<PropertyDetails>) p -> p.setNumberBedrooms(null),
//                        singleton(create("numberBedrooms", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("propertyDetails.numberBedrooms not a number",
                        (Consumer<PropertyDetails>) p -> p.setNumberBedrooms("a"),
                        singleton(create("numberBedrooms", "Badly formed number of bedrooms"))),
//                Arguments.of("propertyDetails.tenure is null",
//                        (Consumer<PropertyDetails>) p -> p.setPropertyTenure(null),
//                        singleton(create("propertyTenure", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("propertyDetails.remainingLeasehold is not a number",
                        (Consumer<PropertyDetails>) p -> p.setRemainingLeasehold("AAAAA"),
                        singleton(create("remainingLeasehold", "Badly formed remaining leasehold"))),
//                Arguments.of("propertyDetails.whenBuilt is null",
//                        (Consumer<PropertyDetails>) p -> p.setWhenBuilt(null),
//                        singleton(create("whenBuilt", MUST_NOT_BE_NULL_ERROR_MESSAGE))),
                Arguments.of("propertyDetails.whenBuilt is not correct format",
                        (Consumer<PropertyDetails>) p -> p.setWhenBuilt("1/1/2022"),
                        singleton(create("whenBuilt", "must be a valid date in format 'yyyy-MM-dd'"))),
                Arguments.of("propertyDetails.propertyBuilder is greater than 50 characters",
                        (Consumer<PropertyDetails>) p -> p.setPropertyBuilder(randomAlphabetic(51)),
                        singleton(create("propertyBuilder", "size must be between 0 and 50"))),
                Arguments.of("propertyDetails.propertyDevelopment is greater than 50 characters",
                        (Consumer<PropertyDetails>) p -> p.setPropertyDevelopment(randomAlphabetic(51)),
                        singleton(create("propertyDevelopment", "size must be between 0 and 50")))


        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("testCases")
    void testPropertyDetailsValidations(String testDescription, Consumer<PropertyDetails> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, PropertyDetailsTestUtil::createValidPropertyDetails, mutator, expectedErrorMessages);
    }
}
