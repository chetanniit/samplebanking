package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchResultDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import com.natwest.pbbdhb.cases.dto.SolicitorDetailsDto;
import com.natwest.pbbdhb.cases.dto.TelephoneDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.SolicitorTestUtil.createExampleSolicitorSearchResultDto;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        SolicitorMapperImpl.class
})
class SolicitorMapperImplTest {

    @Autowired
    private SolicitorMapper mapper;

    @Test
    void searchResultToSolicitorMappingTest() {
        SolicitorSearchResultDto solicitorResult = createExampleSolicitorSearchResultDto();
        Solicitor result = this.mapper.toSolicitor(solicitorResult);

        assertThat(result).usingRecursiveComparison().isEqualTo(solicitorResult);
    }

    @Test
    void solicitorToSolicitorDetailsDtoTest() {
        Solicitor input = CaseTestUtil.createValidSolicitor();

        SolicitorDetailsDto result = mapper.toSolicitorDetailsDto(input);

        assertThat(result).usingRecursiveComparison()
                .ignoringFields("postcode", "telephones", "branchCode", "documentExchangeNumber", "contactName",
                        "associateType", "branchName", "alphaKey", "solePractitioner", "status")
                .as("Fields mapped exactly")
                .isEqualTo(input);
        assertThat(result.getPostcode()).as("Postcode mapping")
                .isEqualTo(input.getAddress().getAddressPC());
        assertThat(result.getTelephones().get(0)).usingRecursiveComparison()
                .as("Telephone mapping")
                .isEqualTo(getTelephoneDto("01315546321"));

    }

    static TelephoneDto getTelephoneDto(String number) {
        TelephoneDto telephone = new TelephoneDto();
        telephone.setNumber(number);
        telephone.setPreferred(true);
        telephone.setType("WORK");

        return telephone;
    }
}
