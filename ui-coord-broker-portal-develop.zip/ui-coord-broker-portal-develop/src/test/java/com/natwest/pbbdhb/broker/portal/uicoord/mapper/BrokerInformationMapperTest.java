package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerInformation;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.BROKER_EMAIL;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.BROKER_FORE_NAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.BROKER_PHONE_NUMBER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.BROKER_SURNAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.BROKER_TITLE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FCA_NUMBER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_ADDRESS_CITY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_ADDRESS_COUNTY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_ADDRESS_LINE_1;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_ADDRESS_LINE_2;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_ADDRESS_LINE_3;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_NAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_POSTCODE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.FIRM_TRADING_NAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerInfoTestUtil.PAYMENT_PATH_NAME;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        BrokerInformationMapperImpl.class
})
class BrokerInformationMapperTest {

    public static final BigDecimal PROC_FEE_PERCENTAGE = BigDecimal.valueOf(0.45);
    @Autowired
    private BrokerInformationMapper mapper;

    @Test
    void toBrokerInformation() {
        BrokerInformation result = mapper.toBrokerInformation(BrokerInfoTestUtil.brokerInfo(), PAYMENT_PATH_NAME,
                PROC_FEE_PERCENTAGE);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo(BROKER_TITLE);
        assertThat(result.getSurname()).isEqualTo(BROKER_SURNAME);
        assertThat(result.getForename()).isEqualTo(BROKER_FORE_NAME);
        assertThat(result.getFirmName()).isEqualTo(FIRM_TRADING_NAME);
        assertThat(result.getPoBoxNumber()).isNull();
        assertThat(result.getHouseNameNumber()).isEqualTo(FIRM_ADDRESS_LINE_1);
        assertThat(result.getAddressLine1()).isEqualTo(FIRM_ADDRESS_LINE_2);
        assertThat(result.getAddressLine2()).isEqualTo(FIRM_ADDRESS_LINE_3);
        assertThat(result.getAddressLine3()).isNull();
        assertThat(result.getCity()).isEqualTo(FIRM_ADDRESS_CITY);
        assertThat(result.getCounty()).isEqualTo(FIRM_ADDRESS_COUNTY);
        assertThat(result.getPostCode()).isEqualTo(FIRM_POSTCODE);
        assertThat(result.getCountry()).isNull();
        assertThat(result.getEmailAddress()).isEqualTo(BROKER_EMAIL);
        assertThat(result.getFcaReference()).isEqualTo(FCA_NUMBER);
        assertThat(result.getNetworkInfo()).isEqualTo(PAYMENT_PATH_NAME);
        assertThat(result.getBrokerPhoneNumber()).isEqualTo(BROKER_PHONE_NUMBER);
        assertThat(result.getProcurementFee()).isEqualTo(PROC_FEE_PERCENTAGE.toString());
    }

    @Test
    void toBrokerInformation_NoFirmAddressLine2() {
        BrokerInfo brokerInfo = BrokerInfoTestUtil.brokerInfo();
        brokerInfo.getFirmDetails().getAddress().setLine2(null);
        BrokerInformation result = mapper.toBrokerInformation(brokerInfo, PAYMENT_PATH_NAME,
                PROC_FEE_PERCENTAGE);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo(BROKER_TITLE);
        assertThat(result.getSurname()).isEqualTo(BROKER_SURNAME);
        assertThat(result.getForename()).isEqualTo(BROKER_FORE_NAME);
        assertThat(result.getFirmName()).isEqualTo(FIRM_TRADING_NAME);
        assertThat(result.getPoBoxNumber()).isNull();
        assertThat(result.getHouseNameNumber()).isEqualTo(FIRM_ADDRESS_LINE_1);
        assertThat(result.getAddressLine1()).isEqualTo(FIRM_ADDRESS_CITY);
        assertThat(result.getAddressLine2()).isNull();
        assertThat(result.getAddressLine3()).isNull();
        assertThat(result.getCity()).isEqualTo(FIRM_ADDRESS_COUNTY);
        assertThat(result.getCounty()).isNull();
        assertThat(result.getPostCode()).isEqualTo(FIRM_POSTCODE);
        assertThat(result.getCountry()).isNull();
        assertThat(result.getEmailAddress()).isEqualTo(BROKER_EMAIL);
        assertThat(result.getFcaReference()).isEqualTo(FCA_NUMBER);
        assertThat(result.getNetworkInfo()).isEqualTo(PAYMENT_PATH_NAME);
        assertThat(result.getBrokerPhoneNumber()).isEqualTo(BROKER_PHONE_NUMBER);
        assertThat(result.getProcurementFee()).isEqualTo(PROC_FEE_PERCENTAGE.toString());
    }

    @Test
    void toBrokerInformation_BlankFirmAddressLine2() {
        BrokerInfo brokerInfo = BrokerInfoTestUtil.brokerInfo();
        brokerInfo.getFirmDetails().getAddress().setLine2("  ");
        BrokerInformation result = mapper.toBrokerInformation(brokerInfo, PAYMENT_PATH_NAME,
                PROC_FEE_PERCENTAGE);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo(BROKER_TITLE);
        assertThat(result.getSurname()).isEqualTo(BROKER_SURNAME);
        assertThat(result.getForename()).isEqualTo(BROKER_FORE_NAME);
        assertThat(result.getFirmName()).isEqualTo(FIRM_TRADING_NAME);
        assertThat(result.getPoBoxNumber()).isNull();
        assertThat(result.getHouseNameNumber()).isEqualTo(FIRM_ADDRESS_LINE_1);
        assertThat(result.getAddressLine1()).isEqualTo(FIRM_ADDRESS_CITY);
        assertThat(result.getAddressLine2()).isNull();
        assertThat(result.getAddressLine3()).isNull();
        assertThat(result.getCity()).isEqualTo(FIRM_ADDRESS_COUNTY);
        assertThat(result.getCounty()).isNull();
        assertThat(result.getPostCode()).isEqualTo(FIRM_POSTCODE);
        assertThat(result.getCountry()).isNull();
        assertThat(result.getEmailAddress()).isEqualTo(BROKER_EMAIL);
        assertThat(result.getFcaReference()).isEqualTo(FCA_NUMBER);
        assertThat(result.getNetworkInfo()).isEqualTo(PAYMENT_PATH_NAME);
        assertThat(result.getBrokerPhoneNumber()).isEqualTo(BROKER_PHONE_NUMBER);
        assertThat(result.getProcurementFee()).isEqualTo(PROC_FEE_PERCENTAGE.toString());
    }
}
