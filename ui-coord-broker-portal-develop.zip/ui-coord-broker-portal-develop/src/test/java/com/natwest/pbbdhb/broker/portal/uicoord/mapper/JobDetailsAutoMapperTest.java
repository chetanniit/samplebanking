package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.util.IncomeTestUtil;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentStatus;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentType;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(
    classes = {
        JobDetailsAutoMapperImpl.class,
        EmployerAddressMapperImpl.class
    }
)
class JobDetailsAutoMapperTest {
  @Autowired
  JobDetailsAutoMapper jobDetailsAutoMapper;

  @Test
  void toIncomeDto_mapsPreviousJobDetailsWithEndDate() {
    CaseIncome createdIncome = IncomeTestUtil
        .createValidIncome("applicant1");
    JobDetails previousJobDetails = createdIncome.getApplicants().get(0).getPreviousJobDetails().get(0);
    assertThat(previousJobDetails.getEmploymentStartDate()).isNotNull();
    assertThat(previousJobDetails.getEmploymentEndDate()).isNotNull();

    JobDetailsDto jobDetailsDto = jobDetailsAutoMapper
        .toJobDetailsDto(EmploymentType.PERMANENT, EmploymentStatus.EMPLOYED.toString(), previousJobDetails);
    assertThat(jobDetailsDto.getEmploymentStartDate()).isNotNull();
    assertThat(jobDetailsDto.getEmploymentEndDate()).isNotNull();
  }
}