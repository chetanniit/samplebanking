package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseExpense;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategoryType;
import com.natwest.pbbdhb.income.expense.model.enums.YesNo;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction.CategoryCode.BUDGET_ACCOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction.CategoryCode.CREDIT_CARD;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction.CategoryCode.LOANS_CAR;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction.CategoryCode.MAIL_ORDER;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction.CategoryCode.OVERDRAFTS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ExpenseTestUtil.createValidCaseExpense;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ExpenseTestUtil.createValidCaseExpenseDto;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        CaseExpenseMapperImpl.class,
        ExpenseTransactionMapperImpl.class
})
class CaseExpenseMapperTest {

    private static final String APPLICATION_STAGE_DIP = "DIP";

    @Autowired
    private CaseExpenseMapper mapper;

    @Test
    void testRoundTripMapping() {
        ArrayList<String> applicantIds = new ArrayList<>();
        applicantIds.add("applicant1");
        CaseExpense expense = createValidCaseExpense(applicantIds);
        CaseExpenseDto expenseDto = this.mapper.toCaseExpenseDto("DIP", expense);
        CaseExpense roundTripResult = this.mapper.toCaseExpense(mapper.caseExpenseToValidatedExpenseIncomeDto(expenseDto));

        assertThat(roundTripResult).usingRecursiveComparison().isEqualTo(expense);
    }

    @Test
    void toExpenseDtoMapsCorrectly() {
        ArrayList<String> applicantIds = new ArrayList<>();
        applicantIds.add("applicant1");
        CaseExpense expense = createValidCaseExpense(applicantIds);
        CaseExpenseDto expenseDto = this.mapper.toCaseExpenseDto(APPLICATION_STAGE_DIP, expense);

        assertThat(expenseDto.getVersion()).isEqualTo(Integer.valueOf(expense.getVersion()));
        assertThat(expenseDto.getStage().name()).isEqualTo(APPLICATION_STAGE_DIP);
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").getCategoryCode().toString()).isEqualTo(String.valueOf(LOANS_CAR));
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").getRedeemedOrLessThanSixMonths()).isEqualTo(
                YesNo.N);
        assertThat(expenseDto)
                .usingRecursiveComparison()
                .ignoringFields("version", "stage", "applicants.transactions.loantransaction1.redeemedOrLessThanSixMonths",
                        "applicants.dependentCostsExcludeReason", "applicants.sourceOfExpenditureVerification",
                        "applicants.cin", "applicants.excludedTransactionsReason", "applicants.mimoTransactions",
                        "applicants.transactions.loantransaction1.transactionGroup", "applicants.transactions.loantransaction1.description",
                        "applicants.transactions.loantransaction1.remainingYears", "applicants.transactions.loantransaction1.numberOfConsolidation",
                        "applicants.transactions.loantransaction1.remainingMonths", "applicants.transactions.loantransaction1.categoryCode",
                        "applicants.transactions.loantransaction1.frequency", "applicants.transactions.loantransaction1.currency",
                        "applicants.transactions.loantransaction1.amountToBePaidInFuture", "applicants.transactions.loantransaction1.type",
                        "applicants.transactions.loantransaction1.familyLiveInProperty")
                .isEqualTo(expense);
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").getCategoryCode().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("loantransaction1").getCategoryCode());
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").getFrequency().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("loantransaction1").getFrequency());
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1").getCurrency().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("loantransaction1").getOriginatingCurrency());

    }

    @Test
    void toExpenseDtoMapsMAIL_ORDERCorrectly() {
      ArrayList<String> applicantIds = new ArrayList<>();
      applicantIds.add("applicant1");
      CaseExpense expense = createValidCaseExpense(applicantIds);
      expense.getApplicants().get(0).getTransactions().get("loantransaction1").setCategoryCode(
          String.valueOf(MAIL_ORDER));
      CaseExpenseDto expenseDto = this.mapper.toCaseExpenseDto(APPLICATION_STAGE_DIP, expense);

      assertThat(expenseDto.getVersion()).isEqualTo(Integer.valueOf(expense.getVersion()));
      assertThat(expenseDto.getStage().name()).isEqualTo(APPLICATION_STAGE_DIP);
      assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1")
          .getCategoryCode().toString()).isEqualTo(String.valueOf(CREDIT_CARD));
      assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1")
          .getType().toString()).isEqualTo(String.valueOf(MAIL_ORDER));

    }

  @Test
  void toExpenseDtoMapsBUDGET_ACCOUNTCorrectly() {
    ArrayList<String> applicantIds = new ArrayList<>();
    applicantIds.add("applicant1");
    CaseExpense expense = createValidCaseExpense(applicantIds);
    expense.getApplicants().get(0).getTransactions().get("loantransaction1").setCategoryCode(
        String.valueOf(BUDGET_ACCOUNT));
    CaseExpenseDto expenseDto = this.mapper.toCaseExpenseDto(APPLICATION_STAGE_DIP, expense);

    assertThat(expenseDto.getVersion()).isEqualTo(Integer.valueOf(expense.getVersion()));
    assertThat(expenseDto.getStage().name()).isEqualTo(APPLICATION_STAGE_DIP);
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1")
        .getCategoryCode().toString()).isEqualTo(String.valueOf(CREDIT_CARD));
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1")
        .getType().toString()).isEqualTo(String.valueOf(BUDGET_ACCOUNT));

  }

  @Test
  void toExpenseDtoMapsOVERDRAFTSCorrectly() {
    ArrayList<String> applicantIds = new ArrayList<>();
    applicantIds.add("applicant1");
    CaseExpense expense = createValidCaseExpense(applicantIds);
    expense.getApplicants().get(0).getTransactions().get("loantransaction1").setCategoryCode(
        String.valueOf(OVERDRAFTS));
    CaseExpenseDto expenseDto = this.mapper.toCaseExpenseDto(APPLICATION_STAGE_DIP, expense);

    assertThat(expenseDto.getVersion()).isEqualTo(Integer.valueOf(expense.getVersion()));
    assertThat(expenseDto.getStage().name()).isEqualTo(APPLICATION_STAGE_DIP);
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1")
        .getCategoryCode().toString()).isEqualTo(String.valueOf(OVERDRAFTS));
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("loantransaction1")
        .getType()).isNull();
  }

    @Test
    void toCaseExpenseMapsCorrectly() {
        CaseExpenseDto expenseDto = createValidCaseExpenseDto(TEST_CASE_ID);
        CaseExpense expense = this.mapper.toCaseExpense(mapper.caseExpenseToValidatedExpenseIncomeDto(expenseDto));

        assertThat(expense.getVersion()).isEqualTo(expenseDto.getVersion().toString());
        assertThat(expenseDto).usingRecursiveComparison()
                .ignoringFields("applicants.transactions.test1.redeemedOrLessThanSixMonths", "stage", "version",
                        "applicants.dependentCostsExcludeReason", "applicants.sourceOfExpenditureVerification",
                        "applicants.cin", "applicants.excludedTransactionsReason", "applicants.mimoTransactions",
                        "applicants.transactions.test1.transactionGroup", "applicants.transactions.test1.description",
                        "applicants.transactions.test1.remainingYears", "applicants.transactions.test1.numberOfConsolidation",
                        "applicants.transactions.test1.remainingMonths", "applicants.transactions.test1.categoryCode",
                        "applicants.transactions.test1.frequency", "applicants.transactions.test1.currency",
                        "applicants.transactions.test1.amountToBePaidInFuture", "applicants.transactions.test1.type",
                        "applicants.transactions.test1.familyLiveInProperty").isEqualTo(expense);
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("test1").getCategoryCode().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("test1").getCategoryCode());
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("test1").getFrequency().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("test1").getFrequency());
        assertThat(expenseDto.getApplicants().get(0).getTransactions().get("test1").getCurrency().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("test1").getOriginatingCurrency());

    }

  @Test
  void categoryType_BUDGET_ACCOUNT_ToCategoryCodeMapsCorrectly() {
    CaseExpenseDto expenseDto = createValidCaseExpenseDto(TEST_CASE_ID);
    expenseDto.getApplicants().get(0).getTransactions().get("test1").setCategoryCode(ExpenseCategory.CREDIT_CARD);
    expenseDto.getApplicants().get(0).getTransactions().get("test1").setType(ExpenseCategoryType.BUDGET_ACCOUNT);

    CaseExpense expense = this.mapper.toCaseExpense(mapper.caseExpenseToValidatedExpenseIncomeDto(expenseDto));

    assertThat(expense.getVersion()).isEqualTo(expenseDto.getVersion().toString());
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("test1").getType().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("test1").getCategoryCode());
  }

  @Test
  void categoryType_MAIL_ORDER_ToCategoryCodeMapsCorrectly() {
    CaseExpenseDto expenseDto = createValidCaseExpenseDto(TEST_CASE_ID);
    expenseDto.getApplicants().get(0).getTransactions().get("test1").setCategoryCode(ExpenseCategory.CREDIT_CARD);
    expenseDto.getApplicants().get(0).getTransactions().get("test1").setType(ExpenseCategoryType.MAIL_ORDER);

    CaseExpense expense = this.mapper.toCaseExpense(mapper.caseExpenseToValidatedExpenseIncomeDto(expenseDto));

    assertThat(expense.getVersion()).isEqualTo(expenseDto.getVersion().toString());
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("test1").getType().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("test1").getCategoryCode());
  }

  @Test
  void categoryCode_OVERDRAFTS_toCategoryCodeMapsCorrectly() {
    CaseExpenseDto expenseDto = createValidCaseExpenseDto(TEST_CASE_ID);
    expenseDto.getApplicants().get(0).getTransactions().get("test1").setCategoryCode(ExpenseCategory.OVERDRAFTS);

    CaseExpense expense = this.mapper.toCaseExpense(mapper.caseExpenseToValidatedExpenseIncomeDto(expenseDto));

    assertThat(expense.getVersion()).isEqualTo(expenseDto.getVersion().toString());
    assertThat(expenseDto.getApplicants().get(0).getTransactions().get("test1").getCategoryCode().name()).isEqualTo(expense.getApplicants().get(0).getTransactions().get("test1").getCategoryCode());
  }

  @Test
  void nullCategoryCodeInExpenseTransactionsDtoToCategoryCodeMapsCorrectly() {
    CaseExpenseDto expenseDto = createValidCaseExpenseDto(TEST_CASE_ID);
    expenseDto.getApplicants().get(0).getTransactions().get("test1").setCategoryCode(null);

    CaseExpense expense = this.mapper.toCaseExpense(mapper.caseExpenseToValidatedExpenseIncomeDto(expenseDto));

    assertThat(expense.getVersion()).isEqualTo(expenseDto.getVersion().toString());
    assertThat(expense.getApplicants().get(0).getTransactions().get("test1").getCategoryCode()).isNull();
  }

}
