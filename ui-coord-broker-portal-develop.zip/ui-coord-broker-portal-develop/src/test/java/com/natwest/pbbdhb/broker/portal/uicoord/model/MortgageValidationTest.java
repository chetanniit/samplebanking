package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.google.common.collect.Sets;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage.MortgageAdvised;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage.MortgageType;
import com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.AbstractValidationTest.TestValidationError.create;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.*;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.getConstraintViolations;
import static java.util.Collections.EMPTY_SET;
import static java.util.Collections.singleton;
import static org.assertj.core.api.Assertions.assertThat;

public class MortgageValidationTest extends AbstractValidationTest<Mortgage> {

    private static Stream<Arguments> commonMortgageTestCases() {
        return Stream.of(
                Arguments.of("Valid mortgage", (Consumer<Mortgage>) a -> {
                }, EMPTY_SET),
                Arguments.of("Valid mortgage with null mortgage advised", (Consumer<Mortgage>) a -> a.setMortgageAdvised(null), EMPTY_SET),
                Arguments.of("Mortgage type invalid", (Consumer<Mortgage>) a -> a.setMortgageType("invalid"), singleton(create("mortgageType", "must be any of: REPAYMENT, INTEREST_ONLY, MIXED"))),
                Arguments.of("Mortgage advised invalid", (Consumer<Mortgage>) a -> a.setMortgageAdvised("invalid"), singleton(create("mortgageAdvised", "must be any of: ADVICE, REJECTED_ADVICE_EXECUTION_ONLY"))),
                Arguments.of("Valid mortgage with property value 99999999", (Consumer<Mortgage>) a -> {
                    a.setPropertyValue(99_999_999);
                    a.setMortgageAmount(540_000);
                }, EMPTY_SET),
                Arguments.of("Property value is above maximum value", (Consumer<Mortgage>) a -> {
                    a.setPropertyValue(100_000_000);
                    a.setMortgageAmount(540_000);
                }, singleton(create("propertyValue", "must be less than or equal to 99999999"))),
                Arguments.of("Property value is below minimum value", (Consumer<Mortgage>) a -> {
                    a.setPropertyValue(0);
                    a.setDeposits(createValidDeposits(-1L)); // hack to get past mortgage amount check
                    a.setMortgageAmount(1);
                }, Sets.newHashSet(
                        create("propertyValue", "must be greater than or equal to 1")
                )),
                Arguments.of("Valid mortgage with purchase price 99999999", (Consumer<Mortgage>) a -> {
                    a.setPurchasePrice(99_999_999);
                    a.setMortgageAmount(440_000);
                }, EMPTY_SET),
                Arguments.of("Purchase price is above maximum value", (Consumer<Mortgage>) a -> {
                    a.setPurchasePrice(100_000_000);
                    a.setMortgageAmount(440_000);
                }, singleton(create("purchasePrice", "must be less than or equal to 99999999"))),
                Arguments.of("Purchase price is below minimum value", (Consumer<Mortgage>) a -> {
                    a.setPurchasePrice(0);
                    a.setDeposits(createValidDeposits(-1L)); // hack to get past mortgage amount check
                    a.setMortgageAmount(1);
                }, Sets.newHashSet(
                        create("purchasePrice", "must be greater than or equal to 1")
                )),
                Arguments.of("Valid mortgage with deposits is empty", (Consumer<Mortgage>) a -> {
                    a.setDeposits(new ArrayList<>());
                    a.setMortgageAmount(500_000);
                }, EMPTY_SET),
                Arguments.of("Valid mortgage with deposits is null", (Consumer<Mortgage>) a -> {
                    a.setDeposits(null);
                    a.setMortgageAmount(500_000);
                }, EMPTY_SET),
// we can't test this with the current mortgage amount logic and tests
//                Arguments.of("Deposits total is equal to purchase price", (Consumer<Mortgage>) a -> {
//                    a.setPurchasePrice(1000);
//                    a.setDeposits(depositsWithTotal(1000));
//                    a.setMortgageAmount(1);
//                }, singleton(create("", "Total of deposits must be less than both property value and purchase price."))),
                Arguments.of("Mortgage amount is incorrect", (Consumer<Mortgage>) a -> a.setMortgageAmount(666), singleton(create("", "Mortgage amount must be equal to the lesser of property value and purchase price minus the total deposit amount.")))
        );
    }

    private static Stream<Arguments> repaymentMortgageTestCases() {
        return Stream.of(
                Arguments.of("Valid repayment mortgage with minimum mortgage term years", (Consumer<Mortgage>) a -> a.setMortgageTermYears(3), EMPTY_SET),
                Arguments.of("Repayment mortgage with mortgage term years below minimum value", (Consumer<Mortgage>) a -> a.setMortgageTermYears(2), singleton(create("mortgageTermYears", "must be greater than or equal to 3"))),
                Arguments.of("Valid repayment mortgage with mortgage term years 39", (Consumer<Mortgage>) a -> a.setMortgageTermYears(39), EMPTY_SET),
                Arguments.of("Repayment mortgage with mortgage term years above maximum value", (Consumer<Mortgage>) a -> a.setMortgageTermYears(41), singleton(create("mortgageTermYears", "must be less than or equal to 40"))),
                Arguments.of("Valid repayment mortgage with minimum mortgage term months", (Consumer<Mortgage>) a -> a.setMortgageTermMonths(0), EMPTY_SET),
                Arguments.of("Repayment mortgage with mortgage term months below minimum value", (Consumer<Mortgage>) a -> a.setMortgageTermMonths(-1), singleton(create("mortgageTermMonths", "must be greater than or equal to 0"))),
                Arguments.of("Valid repayment mortgage with maximum mortgage term months", (Consumer<Mortgage>) a -> a.setMortgageTermMonths(11), EMPTY_SET),
                Arguments.of("Repayment mortgage with mortgage term months above maximum value", (Consumer<Mortgage>) a -> a.setMortgageTermMonths(12), singleton(create("mortgageTermMonths", "must be less than or equal to 11"))),
                Arguments.of("Valid repayment mortgage with maximum mortgage term 40 years and 0 months", (Consumer<Mortgage>) a -> {
                    a.setMortgageTermYears(40);
                    a.setMortgageTermMonths(0);
                }, EMPTY_SET),
                Arguments.of("Repayment mortgage with term above maximum value 40 years and 0 months", (Consumer<Mortgage>) a -> {
                    a.setMortgageTermYears(40);
                    a.setMortgageTermMonths(1);
                }, singleton(create("", "'mortgageTermMonths' value cannot be greater than 0 when 'mortgageTermYears' equals 40")))
        );
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("commonMortgageTestCases")
    public void testCommonMortgageValidations(String testDescription, Consumer<Mortgage> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidMortgage, mutator, expectedErrorMessages);
    }

    @ParameterizedTest(name = "{index} {0}")
    @MethodSource("repaymentMortgageTestCases")
    public void testRepaymentMortgageValidations(String testDescription, Consumer<Mortgage> mutator, Set<TestValidationError> expectedErrorMessages) {
        testValidations(testDescription, CaseTestUtil::createValidRepaymentMortgage, mutator, expectedErrorMessages);
    }

    @Test
    void testAllMortgageAdvisedEnumValuesAreValid() {
        Mortgage mortgage = createValidMortgage();
        EnumSet.allOf(MortgageAdvised.class).forEach(mortgageAdvised -> {
            mortgage.setMortgageAdvised(mortgageAdvised.value());
            assertThat(getConstraintViolations(mortgage)).isEmpty();
        });
    }

    @Test
    void testAllMortgageTypeEnumValuesAreValid() {
        Mortgage mortgage = createValidMortgage();
        EnumSet.allOf(MortgageType.class).forEach(mortgageType -> {
            mortgage.setMortgageType(mortgageType.value());
            assertThat(getConstraintViolations(mortgage)).isEmpty();
        });
    }
}
