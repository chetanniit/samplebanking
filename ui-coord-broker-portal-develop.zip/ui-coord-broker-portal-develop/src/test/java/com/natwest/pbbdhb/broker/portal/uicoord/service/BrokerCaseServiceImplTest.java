package com.natwest.pbbdhb.broker.portal.uicoord.service;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.applicantsWorkStatusMap;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_CREATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_READ_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseTestUtil.createValidProductDetails;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_BROKER_CLAIMS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.TEST_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil.createValidBrokerCase;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerCaseDipMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BankDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BasicAddress;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Broker;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseExpense;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.DecisionInPrinciple;
import com.natwest.pbbdhb.broker.portal.uicoord.model.EstateAgent;
import com.natwest.pbbdhb.broker.portal.uicoord.model.FutureAffordability;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalTelephone;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PropertyDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ServiceLevel;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.PropertyType;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.impl.BrokerCaseServiceImpl;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import org.assertj.core.api.AssertionsForClassTypes;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

@ExtendWith(MockitoExtension.class)
public class BrokerCaseServiceImplTest {

    @Mock
    private BrokerInfoService brokerInfoService;

    @Mock
    private UserClaimsProvider userClaimsProvider;

    @Mock
    private CaseService mockCaseService;

    @Mock
    private ApplicantService mockApplicantService;

    @Mock
    private PropertyService mockPropertyService;

    @Mock
    private IncomeService mockIncomeService;

    @Mock
    private ExpenseService mockExpenseService;

    @Mock
    private AccessPermissionChecker mockAccessPermissionChecker;

    @Spy
    private BrokerCaseDipMapper brokerCaseDipMapper = Mappers.getMapper(BrokerCaseDipMapper.class);

    @InjectMocks
    private BrokerCaseServiceImpl brokerCaseService;

    @Test
    void saveBrokerCaseForUpdateCallsAllServices() {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        CaseApplication caseApplication = brokerCaseRequest.getCaseApplication();
        List<Applicant> applicants = brokerCaseRequest.getApplicants();
        PropertyDetails property = brokerCaseRequest.getProperty();
        CaseIncome income = brokerCaseRequest.getIncome();
        CaseExpense expense = brokerCaseRequest.getExpense();
        Map<String, String> workStatusMap = applicantsWorkStatusMap(applicants, income);

        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(brokerInfoService.getBroker(any())).thenReturn(TEST_BROKER_CLAIMS);
        when(mockCaseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication,
                TEST_BROKER_CLAIMS, false, false)).thenReturn(caseApplication);
        when(mockApplicantService.saveApplicants(BRAND_DEFAULT, TEST_CASE_ID, applicants, workStatusMap)).thenReturn(applicants);
        when(mockPropertyService.saveProperty(BRAND_DEFAULT, TEST_CASE_ID, property, true, false)).thenReturn(property);
        when(mockIncomeService.saveIncome(BRAND_DEFAULT, TEST_CASE_ID, income)).thenReturn(income);
        when(mockExpenseService.saveExpense(BRAND_DEFAULT, TEST_CASE_ID, expense)).thenReturn(expense);

        assertEquals(brokerCaseRequest, this.brokerCaseService.saveBrokerCase(BRAND_DEFAULT, TEST_CASE_ID,
                brokerCaseRequest));

        InOrder order = inOrder(mockCaseService, mockApplicantService, mockPropertyService, mockIncomeService, mockExpenseService);
        order.verify(mockCaseService).saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication,
                TEST_BROKER_CLAIMS, false, false);
        order.verify(mockApplicantService).saveApplicants(BRAND_DEFAULT, TEST_CASE_ID, applicants, workStatusMap);
        order.verify(mockPropertyService).saveProperty(BRAND_DEFAULT, TEST_CASE_ID, property, true, false);
        order.verify(mockIncomeService).saveIncome(BRAND_DEFAULT, TEST_CASE_ID, income);
        order.verify(mockExpenseService).saveExpense(BRAND_DEFAULT, TEST_CASE_ID, expense);
    }

    @Test
    void saveBrokerCaseForUpdateDoesNotCallPropertyServiceWhenPropertyNotProvided() {
        BrokerCase brokerCaseRequest = createValidBrokerCase();
        CaseApplication caseApplication = brokerCaseRequest.getCaseApplication();
        List<Applicant> applicants = brokerCaseRequest.getApplicants();
        CaseIncome income = brokerCaseRequest.getIncome();
        Map<String, String> workStatusMap = applicantsWorkStatusMap(applicants, income);
        CaseExpense expense = brokerCaseRequest.getExpense();

        brokerCaseRequest.setProperty(null);

        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(brokerInfoService.getBroker(any())).thenReturn(TEST_BROKER_CLAIMS);
        when(mockCaseService.saveCase(BRAND_DEFAULT, TEST_CASE_ID, caseApplication,
                TEST_BROKER_CLAIMS, false, false)).thenReturn(caseApplication);
        when(mockApplicantService.saveApplicants(BRAND_DEFAULT, TEST_CASE_ID, applicants, workStatusMap)).thenReturn(applicants);
        when(mockIncomeService.saveIncome(BRAND_DEFAULT, TEST_CASE_ID, income)).thenReturn(income);
        when(mockExpenseService.saveExpense(BRAND_DEFAULT, TEST_CASE_ID, expense)).thenReturn(expense);

        assertEquals(brokerCaseRequest, this.brokerCaseService.saveBrokerCase(BRAND_DEFAULT, TEST_CASE_ID,
                brokerCaseRequest));

        verifyNoInteractions(mockPropertyService);
    }

    @Test
    void getBrokerCaseWhenAccessPermissionCheckerThrows404Exception() {
        String notFoundBody = "not-found-body";
        HttpClientErrorException notFoundException = HttpClientErrorException.create(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.getReasonPhrase(), new HttpHeaders(), notFoundBody.getBytes(StandardCharsets.UTF_8), null);

        // missing case gives 404 exception
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenThrow(notFoundException);

        assertThat(AssertionsForClassTypes.catchThrowableOfType(() -> brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID), HttpClientErrorException.class))
                .isInstanceOf(HttpClientErrorException.NotFound.class)
                .hasMessage(HttpStatus.NOT_FOUND.value() + " " + HttpStatus.NOT_FOUND.getReasonPhrase())
                .matches(ex -> notFoundBody.equals(ex.getResponseBodyAsString()));
    }

    @Test
    void getBrokerCaseWhenApplicantsServiceReturnsEmptyList() {
        CaseApplication expectedCaseApplication = new CaseApplication();
        PropertyDetails expectedProperty = new PropertyDetails();
        CaseIncome expectedIncome = new CaseIncome();
        CaseExpense expectedExpense = new CaseExpense();

        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(mockCaseService.getCase(any(), any())).thenReturn(expectedCaseApplication);
        when(mockPropertyService.getProperty(any(), any())).thenReturn(expectedProperty);
        when(mockIncomeService.getIncome(any(), any())).thenReturn(expectedIncome);
        when(mockExpenseService.getExpense(any(), any())).thenReturn(expectedExpense);

        // no applicants in capie
        when(mockApplicantService.getApplicants(any(), any())).thenReturn(new ArrayList<>());

        BrokerCase brokerCase = this.brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID);

        // no applicants in broker case
        assertEquals(0, brokerCase.getApplicants().size());

        assertEquals(expectedCaseApplication, brokerCase.getCaseApplication());
        assertEquals(expectedProperty, brokerCase.getProperty());
        assertEquals(expectedIncome, brokerCase.getIncome());
    }

    @Test
    void getBrokerCaseWhenPropertyServiceReturnsNull() {
        CaseApplication expectedCaseApplication = new CaseApplication();
        List<Applicant> expectedApplicants = Collections.singletonList(new Applicant());
        CaseIncome expectedIncome = new CaseIncome();

        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(mockCaseService.getCase(any(), any())).thenReturn(expectedCaseApplication);
        when(mockApplicantService.getApplicants(any(), any())).thenReturn(expectedApplicants);
        when(mockIncomeService.getIncome(any(), any())).thenReturn(expectedIncome);

        // no property in capie
        when(mockPropertyService.getProperty(any(), any())).thenReturn(null);

        BrokerCase brokerCase = this.brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID);

        // no property in broker case
        assertNull(brokerCase.getProperty());

        assertEquals(expectedCaseApplication, brokerCase.getCaseApplication());
        assertEquals(expectedApplicants, brokerCase.getApplicants());
        assertEquals(expectedIncome, brokerCase.getIncome());
    }

    @Test
    void getBrokerCaseWhenIncomeServiceReturnsNull() {
        CaseApplication expectedCaseApplication = new CaseApplication();
        List<Applicant> expectedApplicants = Collections.singletonList(new Applicant());
        PropertyDetails expectedProperty = new PropertyDetails();

        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(mockCaseService.getCase(any(), any())).thenReturn(expectedCaseApplication);
        when(mockApplicantService.getApplicants(any(), any())).thenReturn(expectedApplicants);
        when(mockPropertyService.getProperty(any(), any())).thenReturn(expectedProperty);

        // no income in capie
        when(mockIncomeService.getIncome(any(), any())).thenReturn(null);

        BrokerCase brokerCase = this.brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID);

        // no income in broker case
        assertNull(brokerCase.getIncome());

        assertEquals(expectedCaseApplication, brokerCase.getCaseApplication());
        assertEquals(expectedApplicants, brokerCase.getApplicants());
        assertEquals(expectedProperty, brokerCase.getProperty());
    }

    @Test
    void createBrokerCaseThrowsPermissionDeniedIfUserIsNotBroker() {
        when(mockAccessPermissionChecker.isBroker()).thenReturn(false);

        BrokerCase brokerCase = createValidBrokerCase();
        // clear version to simulate new case
        brokerCase.getCaseApplication().setVersion(null);

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () -> brokerCaseService.createBrokerCase(BRAND_DEFAULT, TEST_CASE_ID, brokerCase));

        assertEquals(MSG_NO_CREATE_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void updateBrokerCaseThrowsPermissionDeniedIfUserIsNotOwner() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(false);

        BrokerCase brokerCase = createValidBrokerCase();

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () -> brokerCaseService.updateBrokerCase(BRAND_DEFAULT, TEST_CASE_ID, brokerCase));

        assertEquals(MSG_NO_UPDATE_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void updateBrokerCaseThrowsPermissionDeniedIfUserIsNotBroker() {

        BrokerCase brokerCase = createValidBrokerCase();

        PermissionDeniedException ex = assertThrows(
            PermissionDeniedException.class,
            () -> brokerCaseService.updateBrokerCase(BRAND_DEFAULT, TEST_CASE_ID, brokerCase));

        assertEquals(MSG_NO_UPDATE_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void getBrokerCaseThrowsPermissionDeniedIfUserIsNotOwner() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(false);

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () -> brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID));


        assertEquals(MSG_NO_READ_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void getBrokerCaseThrowsPermissionDeniedIfUserIsNotBroker() {

        PermissionDeniedException ex = assertThrows(
            PermissionDeniedException.class,
            () -> brokerCaseService.getBrokerCase(BRAND_DEFAULT, TEST_CASE_ID));


        assertEquals(MSG_NO_READ_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void dipResultClearThrowsPermissionDeniedIfUserIsNotOwner() {
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(false);

        PermissionDeniedException ex = assertThrows(
                PermissionDeniedException.class,
                () -> brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID));


        assertEquals(MSG_NO_UPDATE_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void dipResultClearThrowsPermissionDeniedIfUserIsNotBroker() {

        PermissionDeniedException ex = assertThrows(
            PermissionDeniedException.class,
            () -> brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID));


        assertEquals(MSG_NO_UPDATE_CASE_PERMISSION, ex.getMessage());
    }

    @Test
    void dipResultClear_clearsFmaData() {
        // prepare data
        final BrokerCase brokerCase = createValidBrokerCase();
        brokerCase.getCaseApplication().setDecisionInPrinciple(new DecisionInPrinciple());
        brokerCase.getCaseApplication().setRepayMortgageCurrencyNotSterling(false);
        brokerCase.getCaseApplication().setCurrencyExchangeRate(BigDecimal.ONE);
        brokerCase.getCaseApplication().setRepayMortgageCurrency("EUR");
        brokerCase.getCaseApplication().setEstateAgent(new EstateAgent());
        brokerCase.getCaseApplication().setSolicitor(new Solicitor());
        brokerCase.getCaseApplication().setProductDetails(new ProductDetails());
        brokerCase.getCaseApplication().setScottishApplication(false);
        brokerCase.getCaseApplication().setLeaseholdOwnershipTerm(true);
        final Mortgage mortgage = new Mortgage();
        final OtherProperty otherProperty = new OtherProperty();
        otherProperty.setAddress(new BasicAddress());
        otherProperty.setNumberBedrooms(1);
        otherProperty.setPropertyType(PropertyType.FLAT_CONVERTED.value());
        mortgage.setOtherProperties(Collections.singletonList(otherProperty));
        brokerCase.getCaseApplication().setMortgage(mortgage);
        final Broker broker = new Broker();
        broker.setPaymentPath(1);
        broker.setFee(BigDecimal.TEN);
        brokerCase.getCaseApplication().setBroker(broker);
        final ServiceLevel serviceLevel = new ServiceLevel();
        serviceLevel.setInterview("interview");
        brokerCase.getCaseApplication().setServiceLevel(serviceLevel);
        brokerCase.getApplicants().get(0).getPersonalDetails().setGender("MALE");
        brokerCase.getApplicants().get(0).getPersonalDetails().setMaritalStatus("MARRIED");
        brokerCase.getApplicants().get(0).getPersonalDetails().setEmail("email@email.com");
        brokerCase.getApplicants().get(0).getPersonalDetails().setTelephone(new PersonalTelephone());
        brokerCase.getApplicants().get(0).setMainBankDetails(new BankDetails());
        brokerCase.getApplicants().get(0).setFutureAffordability(new FutureAffordability());
        brokerCase.getApplicants().get(0).setMovingToPropertyAtCompletion(true);
        brokerCase.getIncome().getApplicants().get(0).getPrimaryJob().setEmployeeSharePercentage(12);
        // when 'get' then return brokerCase data
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(mockCaseService.getCase(any(), any())).thenReturn(brokerCase.getCaseApplication());
        when(mockApplicantService.getApplicants(any(), any())).thenReturn(brokerCase.getApplicants());
        when(mockPropertyService.getProperty(any(), any())).thenReturn(brokerCase.getProperty());
        when(mockIncomeService.getIncome(any(), any())).thenReturn(brokerCase.getIncome());
        when(mockExpenseService.getExpense(any(), any())).thenReturn(brokerCase.getExpense());
        // when 'save' return argument used to call save
        when(mockCaseService.saveCase(any(), any(), any(), any(), anyBoolean(), eq(true))).thenAnswer(i -> i.getArgument(2, CaseApplication.class));
        when(mockApplicantService.saveApplicants(any(), any(), any(), any())).thenAnswer(i -> i.getArgument(2, List.class));
        when(mockPropertyService.saveProperty(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), any())).thenAnswer(i -> i.getArgument(2, PropertyDetails.class));
        when(mockIncomeService.saveIncome(any(), any(), any())).thenAnswer(i -> i.getArgument(2, CaseIncome.class));
        when(mockExpenseService.saveExpense(any(), any(), any())).thenAnswer(i -> i.getArgument(2, CaseExpense.class));
        // execute call
        BrokerCase actual = brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID);
        // assertions
        assertThat(Stream.of(
                actual.getCaseApplication().getDecisionInPrinciple(),
                actual.getCaseApplication().getRepayMortgageCurrencyNotSterling(),
                actual.getCaseApplication().getRepayMortgageCurrency(),
                actual.getCaseApplication().getCurrencyExchangeRate(),
                actual.getCaseApplication().getEstateAgent(),
                actual.getCaseApplication().getSolicitor(),
                actual.getCaseApplication().getProductDetails(),
                actual.getCaseApplication().getScottishApplication(),
                actual.getCaseApplication().getBroker().getPaymentPath(),
                actual.getCaseApplication().getBroker().getFee(),
                actual.getCaseApplication().getServiceLevel().getInterview(),
                actual.getApplicants().get(0).getPersonalDetails().getGender(),
                actual.getApplicants().get(0).getPersonalDetails().getMaritalStatus(),
                actual.getApplicants().get(0).getPersonalDetails().getEmail(),
                actual.getApplicants().get(0).getPersonalDetails().getTelephone(),
                actual.getApplicants().get(0).getMainBankDetails(),
                actual.getApplicants().get(0).getFutureAffordability(),
                actual.getApplicants().get(0).getMovingToPropertyAtCompletion(),
                actual.getIncome().getApplicants().get(0).getPrimaryJob().getJobTitle(),
                actual.getIncome().getApplicants().get(0).getPrimaryJob().getEmployerName(),
                actual.getIncome().getApplicants().get(0).getPrimaryJob().getEmployerTelephone(),
                actual.getIncome().getApplicants().get(0).getPrimaryJob().getEmployerAddress(),
                actual.getIncome().getApplicants().get(0).getPrimaryJob().getEmployeeSharePercentage(),
                actual.getProperty().getType(),
                actual.getProperty().getAddress(),
                actual.getProperty().getNumberBedrooms(),
                actual.getProperty().getPropertyTenure(),
                actual.getProperty().getWhenBuilt(),
                actual.getCaseApplication().getMortgage().getOtherProperties().get(0).getAddress(),
                actual.getCaseApplication().getMortgage().getOtherProperties().get(0).getNumberBedrooms(),
                actual.getCaseApplication().getMortgage().getOtherProperties().get(0).getPropertyType()
        )).allMatch(Objects::isNull);
        assertEquals(brokerCase.getApplicants().get(0).getMarketingPreferences(), actual.getApplicants().get(0).getMarketingPreferences());
        assertEquals(brokerCase.getApplicants().get(0).getPersonalDetails().getFirstNames(), actual.getApplicants().get(0).getPersonalDetails().getFirstNames());
        assertEquals(brokerCase.getApplicants().get(0).getPersonalDetails().getMiddleNames(), actual.getApplicants().get(0).getPersonalDetails().getMiddleNames());
        assertEquals(brokerCase.getApplicants().get(0).getPersonalDetails().getLastName(), actual.getApplicants().get(0).getPersonalDetails().getLastName());
        assertEquals(brokerCase.getApplicants().get(0).getPersonalDetails().getDateOfBirth(), actual.getApplicants().get(0).getPersonalDetails().getDateOfBirth());
        assertEquals(brokerCase.getApplicants().get(0).getPersonalDetails().getNationality(), actual.getApplicants().get(0).getPersonalDetails().getNationality());
        assertEquals(brokerCase.getApplicants().get(0).getPersonalDetails().getCountryOfResidenceIsoCode(), actual.getApplicants().get(0).getPersonalDetails().getCountryOfResidenceIsoCode());
        assertEquals(brokerCase.getCaseApplication().getBrokerJourneyVersion(), actual.getCaseApplication().getBrokerJourneyVersion());
        assertThat(actual.getProperty().isEpcRatingAorB()).isFalse();
        assertThat(actual.getProperty().isNhbcCertificate()).isFalse();
        assertThat(actual.getProperty().isHomeReport()).isFalse();
        assertThat(actual.getCaseApplication().getLeaseholdOwnershipTerm()).isTrue();
        assertThat(actual.getCaseApplication().getIsProductSelectedAtDip()).isFalse();
    }

  @Test
  void dipResultClear_productData_isDeletedWhenNotBtlCase() {
    // prepare data
    final BrokerCase brokerCase = setupBrokerCase();
    setupMocks(brokerCase);

    // SET PRODUCT DATA
    brokerCase.getCaseApplication().setProductDetails(createValidProductDetails());
    brokerCase.getCaseApplication().setIsProductSelectedAtDip(false);

    // execute call
    BrokerCase actual = brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID);

    // assertions
    assertThat(actual.getCaseApplication().getIsProductSelectedAtDip()).isFalse();
    assertThat(actual.getCaseApplication().getProductDetails()).isNull();
  }

  @Test
  void dipResultClear_productData_isKeptWhenBtlCase() {
    // prepare data
    final BrokerCase brokerCase = setupBrokerCase();
    setupMocks(brokerCase);

    // SET PRODUCT DATA
    brokerCase.getCaseApplication().setProductDetails(createValidProductDetails());
    brokerCase.getCaseApplication().setIsProductSelectedAtDip(true);

    // execute call
    BrokerCase actual = brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID);

    // assertions
    assertThat(actual.getCaseApplication().getIsProductSelectedAtDip()).isTrue();
    assertThat(actual.getCaseApplication().getProductDetails()).isNotNull();
  }

  @Test
  void dipResultClear_epcRatingAOrBDip_isKept() {
    // prepare data
    final BrokerCase brokerCase = setupBrokerCase();
    setupMocks(brokerCase);

    // SET PRODUCT DATA
    brokerCase.getCaseApplication().setEpcRatingAOrBDip(true);

    // execute call
    BrokerCase actual = brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID);

    // assertions
    assertThat(actual.getCaseApplication().getEpcRatingAOrBDip()).isTrue();
  }

  private void setupMocks(BrokerCase brokerCase) {
    // when 'get' then return brokerCase data
    when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
    when(mockCaseService.getCase(any(), any())).thenReturn(brokerCase.getCaseApplication());
    when(mockApplicantService.getApplicants(any(), any())).thenReturn(brokerCase.getApplicants());
    when(mockPropertyService.getProperty(any(), any())).thenReturn(brokerCase.getProperty());
    when(mockIncomeService.getIncome(any(), any())).thenReturn(brokerCase.getIncome());
    when(mockExpenseService.getExpense(any(), any())).thenReturn(brokerCase.getExpense());
    // when 'save' return argument used to call save
    when(mockCaseService.saveCase(any(), any(), any(), any(), anyBoolean(), eq(true))).thenAnswer(i -> i.getArgument(2, CaseApplication.class));
    when(mockApplicantService.saveApplicants(any(), any(), any(), any())).thenAnswer(i -> i.getArgument(2, List.class));
    when(mockPropertyService.saveProperty(eq(BRAND_DEFAULT), eq(TEST_CASE_ID), any())).thenAnswer(i -> i.getArgument(2, PropertyDetails.class));
    when(mockIncomeService.saveIncome(any(), any(), any())).thenAnswer(i -> i.getArgument(2, CaseIncome.class));
    when(mockExpenseService.saveExpense(any(), any(), any())).thenAnswer(i -> i.getArgument(2, CaseExpense.class));
  }

  private BrokerCase setupBrokerCase() {
    final BrokerCase brokerCase = createValidBrokerCase();
    brokerCase.getCaseApplication().setDecisionInPrinciple(new DecisionInPrinciple());
    brokerCase.getCaseApplication().setRepayMortgageCurrencyNotSterling(false);
    brokerCase.getCaseApplication().setCurrencyExchangeRate(BigDecimal.ONE);
    brokerCase.getCaseApplication().setRepayMortgageCurrency("EUR");
    brokerCase.getCaseApplication().setEstateAgent(new EstateAgent());
    brokerCase.getCaseApplication().setSolicitor(new Solicitor());
    brokerCase.getCaseApplication().setProductDetails(new ProductDetails());
    brokerCase.getCaseApplication().setScottishApplication(false);
    brokerCase.getCaseApplication().setLeaseholdOwnershipTerm(true);
    final Mortgage mortgage = new Mortgage();
    final OtherProperty otherProperty = new OtherProperty();
    otherProperty.setAddress(new BasicAddress());
    otherProperty.setNumberBedrooms(1);
    otherProperty.setPropertyType(PropertyType.FLAT_CONVERTED.value());
    mortgage.setOtherProperties(Collections.singletonList(otherProperty));
    brokerCase.getCaseApplication().setMortgage(mortgage);
    final Broker broker = new Broker();
    broker.setPaymentPath(1);
    broker.setFee(BigDecimal.TEN);
    brokerCase.getCaseApplication().setBroker(broker);
    final ServiceLevel serviceLevel = new ServiceLevel();
    serviceLevel.setInterview("interview");
    brokerCase.getCaseApplication().setServiceLevel(serviceLevel);
    brokerCase.getApplicants().get(0).getPersonalDetails().setGender("MALE");
    brokerCase.getApplicants().get(0).getPersonalDetails().setMaritalStatus("MARRIED");
    brokerCase.getApplicants().get(0).getPersonalDetails().setEmail("email@email.com");
    brokerCase.getApplicants().get(0).getPersonalDetails().setTelephone(new PersonalTelephone());
    brokerCase.getApplicants().get(0).setMainBankDetails(new BankDetails());
    brokerCase.getApplicants().get(0).setFutureAffordability(new FutureAffordability());
    brokerCase.getApplicants().get(0).setMovingToPropertyAtCompletion(true);
    brokerCase.getIncome().getApplicants().get(0).getPrimaryJob().setEmployeeSharePercentage(12);
    return brokerCase;
  }

  @Test
    void dipResultClear_resetsCurrentRoute() {
        // prepare data
        final BrokerCase brokerCase = createValidBrokerCase();
        brokerCase.getCaseApplication().setCurrentRoute("someRandomRoute");
        // when 'get' then return brokerCase data
        when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
        when(brokerInfoService.getBroker(any())).thenReturn(TEST_BROKER_CLAIMS);
        when(mockCaseService.getCase(any(), any())).thenReturn(brokerCase.getCaseApplication());
        // when 'save' return argument used to call save
        when(mockCaseService.saveCase(any(), any(), any(), any(), anyBoolean(), eq(true)))
                .thenAnswer(i -> i.getArgument(2, CaseApplication.class));
        // execute call
        BrokerCase actual = brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID);
        // assertions
        assertThat(actual.getCaseApplication().getCurrentRoute()).isEqualTo("/dip/ApplicantDetails");
    }

  @Test
  void dipResultClear_resets_isProductFeePaymentSelected() {
    // prepare data
    final BrokerCase brokerCase = createValidBrokerCase();
    brokerCase.getCaseApplication().setIsProductFeePaymentSelected(true);
    // when 'get' then return brokerCase data
    when(mockAccessPermissionChecker.isCaseOwner(any(), any())).thenReturn(true);
    when(brokerInfoService.getBroker(any())).thenReturn(TEST_BROKER_CLAIMS);
    when(mockCaseService.getCase(any(), any())).thenReturn(brokerCase.getCaseApplication());
    // when 'save' return argument used to call save
    when(mockCaseService.saveCase(any(), any(), any(), any(), anyBoolean(), eq(true)))
        .thenAnswer(i -> i.getArgument(2, CaseApplication.class));
    // execute call
    BrokerCase actual = brokerCaseService.dipResultClear(BRAND_DEFAULT, TEST_CASE_ID);
    // assertions
    assertThat(actual.getCaseApplication().getIsProductFeePaymentSelected()).isNull();
  }

}
