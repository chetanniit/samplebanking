package com.natwest.pbbdhb.broker.portal.uicoord.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.configuration.TokenConfiguration;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProviderIT.HelloController;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TestUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.TokensUtil;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Tests the {@link UserClaimsProvider} that extracts claims from the JWT contained
 * in the HTTP header.
 */
@Slf4j
@ActiveProfiles(profiles = { "secured-uat" })
@EnableAutoConfiguration
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {
        HelloController.class,
        IamUserClaimsProvider.class,
        TokenConfiguration.class
    })
@TestPropertySource(
    properties = {
        "features.user-claims-mode=iam"
    })
@TestInstance(Lifecycle.PER_CLASS)
public class UserClaimsProviderIT {

  private static final String JWT_CLAIMS_HEADER = "iam-claimsetjwt";
  private static final String ADDITIONAL_CLAIMS = "additional_claims";

  // expectations based on contents of test JWT claims JSON file
  private static final String EXPECTED_CHANNEL = "INTERMEDIARY_NAPOLI";
  private static final BrokerType EXPECTED_BROKER_TYPE = BrokerType.BROKER;
  private static final String EXPECTED_BROKER_USERNAME = "acTestUser1";
  private static final BrokerType EXPECTED_ADMIN_TYPE = BrokerType.ADMIN;
  private static final String EXPECTED_ADMIN_USERNAME = "phillipsc";

  // holds the claims captured by the HTTP calls run during these tests.
  // we use statics as the HTTP requests run in different threads.
  // these captured IDs will be cleared at the start of each test and asserted against after each HTTP call.
  private static String CAPTURED_CHANNEL;
  private static BrokerType CAPTURED_USER_TYPE;
  private static String CAPTURED_USER_USERNAME;

  @SpyBean
  private UserClaimsProvider claimsProvider;

  @Autowired
  private TestRestTemplate restTemplate;

  @Autowired
  private ObjectMapper mapper;

  @Autowired
  private TokenConfiguration tokenConfig;

  @Value("classpath:test-files/jwt-claims/broker-jwt-claims.json")
  private Resource brokerJwtClaimsJson;

  @Value("classpath:test-files/jwt-claims/admin-jwt-claims.json")
  private Resource adminJwtClaimsJson;

  @BeforeEach
  public void before() {
    CAPTURED_CHANNEL = null;
    CAPTURED_USER_TYPE = null;
    CAPTURED_USER_USERNAME = null;
  }

  @Test
  public void shouldCaptureBrokerClaims() throws IOException {

    // read JSON JWT claims into additional claims map
    String jwtClaims = TestUtil.getResourceText(brokerJwtClaimsJson);
    Map<String,Object> claimsMap = mapper.readValue(jwtClaims, HashMap.class);

    // make the HTTP request
    HttpHeaders headers = new HttpHeaders();
    headers.add(
        JWT_CLAIMS_HEADER,
        TokensUtil.createJwt(tokenConfig, claimsMap));

    restTemplate.exchange(
        "/hello",
        HttpMethod.GET,
        new HttpEntity<String>(headers),
        String.class);

    verify(claimsProvider, times(1))
        .getChannel();
    assertThat(CAPTURED_CHANNEL)
        .isEqualTo(EXPECTED_CHANNEL);

    verify(claimsProvider, times(1))
        .getBrokerType();
    assertThat(CAPTURED_USER_TYPE)
        .isEqualTo(EXPECTED_BROKER_TYPE);

    verify(claimsProvider, times(1))
        .getBrokerUsername();
    assertThat(CAPTURED_USER_USERNAME)
        .isEqualTo(EXPECTED_BROKER_USERNAME);
  }

  @Test
  public void shouldCaptureAdminClaims() throws IOException {

    // read JSON JWT claims into additional claims map
    String jwtClaims = TestUtil.getResourceText(adminJwtClaimsJson);
    Map<String,Object> claimsMap = mapper.readValue(jwtClaims, HashMap.class);

    // make the HTTP request
    HttpHeaders headers = new HttpHeaders();
    headers.add(
        JWT_CLAIMS_HEADER,
        TokensUtil.createJwt(tokenConfig, claimsMap));

    restTemplate.exchange(
        "/hello",
        HttpMethod.GET,
        new HttpEntity<String>(headers),
        String.class);

    verify(claimsProvider, times(1))
        .getChannel();
    assertThat(CAPTURED_CHANNEL)
        .isEqualTo(EXPECTED_CHANNEL);

    verify(claimsProvider, times(1))
        .getBrokerType();
    assertThat(CAPTURED_USER_TYPE)
        .isEqualTo(EXPECTED_ADMIN_TYPE);

    verify(claimsProvider, times(1))
        .getBrokerUsername();
    assertThat(CAPTURED_USER_USERNAME)
        .isEqualTo(EXPECTED_ADMIN_USERNAME);
  }

  /**
   * Provides a test REST controller that we can call as part of these tests.
   * <p>
   * The controller captures the JWT claims it receives.
   */
  @RestController
  @Slf4j
  public static class HelloController {

    @Autowired
    UserClaimsProvider claimsProvider;

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public void helloClaims() {
      // capture the received JWT claims
      CAPTURED_CHANNEL = claimsProvider.getChannel();
      CAPTURED_USER_TYPE = claimsProvider.getBrokerType();
      CAPTURED_USER_USERNAME = claimsProvider.getBrokerUsername();

      log.info("Extracted Channel: {}", CAPTURED_CHANNEL);
      log.info("Extracted Broker Type: {}", CAPTURED_USER_TYPE);
      log.info("Extracted Broker Username: {}", CAPTURED_USER_USERNAME);
    }
  }
}
