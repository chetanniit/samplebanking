const { defineConfig } = require('cypress');
const webpackPreprocessor = require('@cypress/webpack-preprocessor');
const cucumber = require('@badeball/cypress-cucumber-preprocessor');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:8080',
    caseManagementUrl: 'https://v1-msvc-case-management-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net',
    caseUrl: 'https://v2-msvc-case-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net',
    video: false,
    specPattern: ['**/*.feature'],
    tags: true,
    supportFile: false,
    defaultCommandTimeout: 45000,
    uiBaseUrl: 'http://localhost:3052',
    homePage: '/',
    startAdminPage: '/admin/ConfirmPrivacyPolicy',
    async setupNodeEvents(on, config) {
      await cucumber.addCucumberPreprocessorPlugin(on, config);
      on(
          'file:preprocessor',
          webpackPreprocessor({
            webpackOptions: {
              resolve: {
                extensions: ['.js']
              },
              module: {
                rules: [
                  {
                    test: /\.js$/,
                    exclude: [/node_modules/],
                    use: [
                      {
                        loader: 'babel-loader',
                        options: {
                          presets: ['@babel/preset-env']
                        }
                      }
                    ]
                  },
                  {
                    test: /\.feature$/,
                    use: [
                      {
                        loader: '@badeball/cypress-cucumber-preprocessor/webpack',
                        options: config
                      }
                    ]
                  }
                ]
              }
            }
          })
      );
      return config;
    }
  }
});