package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import lombok.Data;

@Data
public class BrokerSourcesAddressDto {

    String poBoxNumber;

    String houseNameNumber;

    String addressLine1;

    String addressLine2;

    String addressLine3;

    String city;

    String county;

    String postcode;

    String country;
}
