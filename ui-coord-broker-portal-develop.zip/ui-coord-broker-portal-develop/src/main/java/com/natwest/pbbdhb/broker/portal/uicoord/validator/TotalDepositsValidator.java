package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.TotalDeposits;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.broker.portal.uicoord.validator.MortgageCalculations.getEffectivePropertyValue;
import static com.natwest.pbbdhb.broker.portal.uicoord.validator.MortgageCalculations.getTotalDeposit;

public class TotalDepositsValidator implements ConstraintValidator<TotalDeposits, Object> {
    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        if (!(objectToValidate instanceof Mortgage)) {
            return true;
        }

        Mortgage mortgage = (Mortgage) objectToValidate;

        Integer effectivePropertyValue = getEffectivePropertyValue(mortgage);
        if (effectivePropertyValue == null) {
            return true;
        }

        long totalDeposit = getTotalDeposit(mortgage);

        return totalDeposit < effectivePropertyValue;
    }
}
