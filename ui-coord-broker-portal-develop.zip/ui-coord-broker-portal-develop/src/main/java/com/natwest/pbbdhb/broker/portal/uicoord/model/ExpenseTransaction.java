package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;

@Data
public class ExpenseTransaction {
    @NotBlank
    @ValidateEnum(enumClass = ExpenseTransaction.CategoryCode.class)
    private String categoryCode;

    private String merchantName;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal amount;

    @ValidateEnum(enumClass = ExpenseTransaction.Frequency.class)
    private String frequency;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal outstandingBalance;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal consolidationAmount;

    private Boolean redeemedOrLessThanSixMonths;

    private String otherCommittedExpenditureFreeFormText;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String originatingCurrency;

    public enum CategoryCode implements ValuedEnum {
        CHILD_CARE,
        CREDIT_CARD,
        LOANS_CAR,
        LOANS_PERSONAL_CONTRACT_PURCHASE,
        LOANS_SECURED,
        LOANS_STUDENT,
        LOANS_UNSECURED,
        OTHER_COMMITTED_EXPENDITURE_ADDITIONAL_PROPERTY_MORTGAGE,
        OTHER_COMMITTED_EXPENDITURE_ADDITIONAL_PROPERTY_RUNNING_COST,
        OTHER_COMMITTED_EXPENDITURE_ADULT_CARE_COST,
        OTHER_COMMITTED_EXPENDITURE_CAREER_RELATED_SUBSCRIPTIONS_QUALIFICATIONS,
        OTHER_COMMITTED_EXPENDITURE_CHILD_SUPPORT,
        OTHER_COMMITTED_EXPENDITURE_GROUND_RENT,
        OTHER_COMMITTED_EXPENDITURE_HELP_TO_BUY_LOAN,
        OTHER_COMMITTED_EXPENDITURE_MAINTENANCE_PAYMENTS,
        OTHER_COMMITTED_EXPENDITURE_OTHER,
        OTHER_COMMITTED_EXPENDITURE_SCHOOL_EDUCATION_FEES,
        OTHER_EXPENDITURE_ESTATE_RENT,
        OTHER_EXPENDITURE_SERVICE_CHARGES_FOR_LEASEHOLD_PROPERTIES,
        OVERDRAFTS,
        BUDGET_ACCOUNT,
        MAIL_ORDER,
        SHARED_EQUITY;

        @Override
        public String value() {
            return name();
        }
    }

    public enum Frequency implements ValuedEnum {
        ANNUALLY,
        BIANNUALLY,
        QUARTERLY,
        MONTHLY,
        FOUR_WEEKLY,
        FORTNIGHTLY,
        WEEKLY;

        @Override
        public String value() {
            return name();
        }
    }

}
