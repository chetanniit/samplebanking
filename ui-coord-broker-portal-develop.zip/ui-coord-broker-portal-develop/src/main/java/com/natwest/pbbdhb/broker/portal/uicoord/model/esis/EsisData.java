package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisFirstTimeBuyer;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
@ValidEsisFirstTimeBuyer
public class EsisData {

    @NotNull
    @Valid
    private EsisCaseDetails caseDetails;

    @NotNull
    @Valid
    private List<EsisApplicant> applicants;

    @NotNull
    @Valid
    private EsisMortgageDetails mortgageDetails;

    @NotNull
    @Valid
    private EsisBorrowingRequirements borrowingRequirements;

    @NotNull
    private ProductDto selectedProduct;

}
