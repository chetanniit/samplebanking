package com.natwest.pbbdhb.broker.portal.uicoord.service.helper;

import com.google.common.collect.Lists;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentStatus;
import com.natwest.pbbdhb.income.expense.model.income.response.IncomeApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.IncomeApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class WorkStatusHelper {
    public static final String WORK_STATUS_WORKING = "WORKING";
    public static final String WORK_STATUS_NOT_WORKING = "NOT_WORKING";

    private static final List<String> workingEmploymentStatuses = Lists.newArrayList(
            JobDetails.EmploymentStatus.EMPLOYED.value(),
            JobDetails.EmploymentStatus.SELF_EMPLOYED.value(),
            JobDetails.EmploymentStatus.CONTRACTOR.value()
    );

    private static final List<String> notWorkingEmploymentStatuses = Lists.newArrayList(
            JobDetails.EmploymentStatus.HOME_MAKER.value(),
            JobDetails.EmploymentStatus.RETIRED.value(),
            JobDetails.EmploymentStatus.STUDENT.value(),
            JobDetails.EmploymentStatus.NOT_EMPLOYED.value()
    );

    private WorkStatusHelper() {
    }

    public static Map<String, String> applicantsWorkStatusMap(List<Applicant> applicants, CaseIncome income) {
        Map<String, String> workStatusMap = new HashMap<>();

        for (Applicant applicant : applicants) {
            String applicantId = applicant.getApplicantId();

            if (applicantId == null) {
                // new applicant with no associated income (could be more than one)
                workStatusMap.put(null, null);
            } else if (income == null) {
                // updating applicant without specifying employment; set workStatus = null (fix it when submitting DIP if this is wrong)
                workStatusMap.put(applicant.getApplicantId(), null);
            } else {
                List<IncomeApplicant> incomeApplicants = income.getApplicants();
                // updating applicant and including employment information
                // find matching income applicant
                Optional<IncomeApplicant> matchingIncomeApplicant = incomeApplicants.stream().filter(a -> a.getApplicantId().equals(applicantId)).findFirst();
                if (!matchingIncomeApplicant.isPresent()) {
                    // No income for this applicant
                    workStatusMap.put(applicantId, null);
                } else {
                    IncomeApplicant incomeApplicant = matchingIncomeApplicant.get();
                    workStatusMap.put(applicantId, computeWorkStatus(incomeApplicant));
                }
            }
        }

        return workStatusMap;
    }

    public static Map<String, String> applicantsWorkStatusMap(List<ApplicantDto> applicants, ValidatedCaseIncomeDto income) {
        Map<String, String> workStatusMap = new HashMap<>();

        for (ApplicantDto applicant : applicants) {
            String applicantId = applicant.getApplicantId();

            if (applicantId == null) {
                // new applicant with no associated income (could be more than one)
                workStatusMap.put(null, null);
            } else if (income == null) {
                // updating applicant without specifying employment; set workStatus = null
                workStatusMap.put(applicant.getApplicantId(), null);
            } else {
                List<IncomeApplicantDto> incomeApplicants = income.getApplicants();
                // updating applicant and including employment information
                // find matching income applicant
                Optional<IncomeApplicantDto> matchingIncomeApplicant = incomeApplicants.stream().filter(a -> a.getApplicantId().equals(applicantId)).findFirst();
                if (!matchingIncomeApplicant.isPresent()) {
                    // No income for this applicant
                    workStatusMap.put(applicantId, null);
                } else {
                    IncomeApplicantDto incomeApplicant = matchingIncomeApplicant.get();
                    workStatusMap.put(applicantId, computeWorkStatus(incomeApplicant));
                }
            }
        }

        return workStatusMap;
    }

    private static String computeWorkStatus(IncomeApplicant incomeApplicant) {
        String workStatus;
        if (incomeApplicant.getPrimaryJob() == null || incomeApplicant.getPrimaryJob().getEmploymentStatus() == null) {
            // no employment for this applicant
            workStatus = null;
        } else {
            String employmentStatus = incomeApplicant.getPrimaryJob().getEmploymentStatus();

            if (workingEmploymentStatuses.contains(employmentStatus)) {
                workStatus = WORK_STATUS_WORKING;
            } else if (notWorkingEmploymentStatuses.contains(employmentStatus)) {
                workStatus = WORK_STATUS_NOT_WORKING;
            } else {
                // QUESTION: Is there a better exception type to use here?
                throw new IllegalArgumentException("Unrecognised employment status: '" + employmentStatus + '"');
            }
        }
        return workStatus;
    }

    private static String computeWorkStatus(IncomeApplicantDto incomeApplicant) {
        String workStatus;
        if (incomeApplicant.getPrimaryJob() == null || incomeApplicant.getPrimaryJob().getEmploymentStatus() == null) {
            // no employment for this applicant
            workStatus = null;
        } else {
            EmploymentStatus employmentStatus = incomeApplicant.getPrimaryJob().getEmploymentStatus();

            if (workingEmploymentStatuses.contains(employmentStatus.name())) {
                workStatus = WORK_STATUS_WORKING;
            } else if (notWorkingEmploymentStatuses.contains(employmentStatus.name())) {
                workStatus = WORK_STATUS_NOT_WORKING;
            } else {
                // QUESTION: Is there a better exception type to use here?
                throw new IllegalArgumentException("Unrecognised employment status: '" + employmentStatus + '"');
            }
        }
        return workStatus;
    }
}
