package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "Payment", description = "Payment API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "payment",
            summary = "Get the payment url to pay fees",
            tags = "Payment"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful", content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(value = PATH_PAYMENT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PaymentResponse> payment(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                             @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                             @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                   @RequestBody @Valid final PaymentRequest paymentRequest) {
        String mortgageReferenceNumber = paymentRequest.getMortgageReferenceNumber();
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to get payment URL for mortgageReferenceNumber {} and brokerUsername {}", mortgageReferenceNumber, brokerUsername);
        PaymentResponse paymentResponse = this.paymentService.fetchPaymentUrl(brand, paymentRequest);
        log.info("Payment URL for mortgageReferenceNumber {} and brokerUsername {} successfully retrieved", mortgageReferenceNumber, brokerUsername);
        return ResponseEntity.ok(paymentResponse);
    }
}
