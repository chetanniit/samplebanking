package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.IcrTaxRate;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertFalse;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Data
public class BuyToLet {

    @Min(1)
    @Max(99999999)
    private Long monthlyRentalIncome;

    @Min(1)
    @Max(99_999_999)
    private Long monthlyNetRentalIncome;

    @ValidateEnum(enumClass = IcrTaxRate.class)
    private String icrTaxRate;

    private Boolean useLettingAgent;

    @Min(1)
    @Max(99999999)
    private Long lettingAgentCost;

    @AssertFalse
    private Boolean isRentingToImmediateFamilyMember;

    @AssertTrue
    private Boolean isAssuredShortHoldOrShortAssured;

    @AssertTrue
    private Boolean isNotSelectiveLicenceOrHMO;

    @AssertTrue
    private Boolean isForInvestment;

    private Boolean movingToPropertyAtCompletion;

    @Valid
    private PortfolioLandlord portfolioLandlord;


}
