package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.FmaService;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import jakarta.validation.constraints.Pattern;
import java.nio.charset.StandardCharsets;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;


@RestController
@Tag(name = "FMA", description = "Full Mortgage Application API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class FmaController {

    private final FmaService fmaService;
    private final UserClaimsProvider userClaimsProvider;


    @Operation(
            operationId = "submitFma",
            summary = "Submit a Full Mortgage Application",
            tags = "FMA"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "202", description = "Successful submission of FMA", content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Bad request: handled validation exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ValidationResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error: unexpected exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PostMapping(value = PATH_SUBMIT_FMA, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FullMortgageApplicationExtendedResponse> submitFma(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                                     @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                                     @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                                     @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                                     @PathVariable final String caseId) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to submit FMA for caseId {} and brokerUsername {}", caseId, brokerUsername);
        try {
            FullMortgageApplicationExtendedResponse fmaResponse = fmaService.submitFma(brand, caseId);
            log.debug("FMA for caseId {} and brokerUsername {} successfully submitted", caseId, brokerUsername);
            return ResponseEntity.accepted().body(fmaResponse);
        } catch (FmaIntegrationException ex) {
            log.error("Error submitting FMA for caseId {} and brokerUsername {}: {}", caseId, brokerUsername, ex.getMessage());
            throw HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), new HttpHeaders(), ex.getMessage().getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        }
    }
}
