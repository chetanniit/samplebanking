package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class CaseClientNapoli {

    private final String getCaseEndpoint;
    private final String createCaseEndpoint;
    private final String updateCaseEndpoint;
    private final RestTemplate restTemplate;

    public CaseClientNapoli(
            @Value("${msvc.case.get.url}") String getCaseEndpoint,
            @Value("${msvc.case.create.url}") String createCaseEndpoint,
            @Value("${msvc.case.update.url}") String updateCaseEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.getCaseEndpoint = getCaseEndpoint;
        this.createCaseEndpoint = createCaseEndpoint;
        this.updateCaseEndpoint = updateCaseEndpoint;
        this.restTemplate = restTemplate;
    }

    public CaseApplicationDto createCase(String brand, CaseApplicationDto caseApplication) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(createCaseEndpoint);
        URI url = builder.build().toUri();
        String caseId = caseApplication.getCaseId();
        String version = caseApplication.getVersion();
        log.info("Calling {} to create case with version {} and caseId {}", url, version, caseId);

        try {
                CaseApplicationDto caseApplicationDto = restTemplate.exchange(
                  url,
                  HttpMethod.POST,
                  new HttpEntity<>(caseApplication, constructHeadersForJsonRequest(brand)),
                  CaseApplicationDto.class).getBody();

                if(caseApplicationDto == null) {
                  log.warn("Null response body received from {} while creating case with version {} and caseId {}", url, version, caseId);
                } else {
                  log.debug("Case with version {} and caseId {} successfully created",
                      caseApplicationDto.getVersion(), caseId);
                }
                return caseApplicationDto;

        } catch (RestClientException ex) {
                log.warn("A rest client exception occurred while calling {} to create case with version {} and caseId {}: {}",
                    url, version, caseId, ex.getMessage());
                throw ex;
        } catch (Throwable t) {
                log.warn("An unexpected exception occurred while calling {} to create case with version {} and caseId {}: {}",
                    url, version, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
                throw t;
        }
    }

    public CaseApplicationDto updateCase(String brand, CaseApplicationDto caseApplication) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(updateCaseEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        String caseId = caseApplication.getCaseId();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);
        String version = caseApplication.getVersion();
        URI url = builder.build().toUri();
        log.info("Calling {} to update case with version {} and caseId {}", url, version, caseId);

        try {
              CaseApplicationDto caseApplicationDto = restTemplate.exchange(
                  url,
                  HttpMethod.PUT,
                  new HttpEntity<>(caseApplication, constructHeadersForJsonRequest(brand)),
                  CaseApplicationDto.class).getBody();

              if(caseApplicationDto == null) {
                log.warn("Null response body received from {} while updating case with version {} and caseId {}", url, version, caseId);
              } else {
                log.debug("Case with version {} and caseId {} successfully updated",
                    caseApplicationDto.getVersion(), caseId);
              }
              return caseApplicationDto;

        } catch (RestClientException ex) {
              log.warn("A rest client exception occurred while calling {} to update case with version {} and caseId {}: {}",
                  url, version, caseId, ex.getMessage());
              throw ex;
        } catch (Throwable t) {
              log.warn("An unexpected exception occurred while calling {} to update case with version {} and caseId {}: {}",
                  url, version, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
              throw t;
        }
    }

    public CaseApplicationDto getCase(String brand, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(getCaseEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);

        URI url = builder.build().toUri();
        log.info("Calling {} to get case with caseId {}", url, caseId);

        try {
              CaseApplicationDto caseApplicationDto = restTemplate.exchange(
                  url,
                  HttpMethod.GET,
                  new HttpEntity<>(constructHeadersForJsonRequest(brand)),
                  CaseApplicationDto.class).getBody();

              log.debug("Case with caseId {} successfully retrieved", caseId);
              return caseApplicationDto;

        } catch (RestClientException ex) {
              log.warn("A rest client exception occurred while calling {} to get case with caseId {}: {}",
                  url, caseId, ex.getMessage());
              throw ex;
        } catch (Throwable t) {
              log.warn("An unexpected exception occurred while calling {} to get case with caseId {}: {}",
                  url, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
              throw t;
        }
    }
}
