package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class InvalidCaseStateException extends RuntimeException {

    public InvalidCaseStateException(String message) {
        super(message);
    }

    public InvalidCaseStateException(String message, Throwable cause) {
        super(message, cause);
    }
}
