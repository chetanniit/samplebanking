package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;

@Data
public class PaymentRequest {

    @NotBlank
    private String mortgageReferenceNumber;
}
