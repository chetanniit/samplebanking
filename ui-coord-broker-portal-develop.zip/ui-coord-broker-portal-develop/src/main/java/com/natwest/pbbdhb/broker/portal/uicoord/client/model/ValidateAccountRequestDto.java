package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidateAccountRequestDto {
    private String sortCode;

    private String accountNumber;

    private String rollNumber;
}
