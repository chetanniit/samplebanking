package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
public class PersonalDetailsDip {

    @NotNull
    @ValidateEnum(enumClass = Title.class)
    private String title;

    // field is required if title == OTHER
    @Size(min = 1, max = 15)
    private String otherTitle;

    @NotBlank
    @Size(min = 1, max = 15)
    private String firstNames;

    @Size(max = 25)
    private String middleNames;

    @NotBlank
    @Size(min = 1, max = 30)
    private String lastName;

    @NotNull
    @DateFormat(pattern = "yyyy-MM-dd", constraint = DateFormat.DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String dateOfBirth;

    @NotNull
    @Size(max = 2)
    private String nationality;

    @Size(max = 2)
    private String countryOfResidenceIsoCode;

    private Boolean rightToReside;

}
