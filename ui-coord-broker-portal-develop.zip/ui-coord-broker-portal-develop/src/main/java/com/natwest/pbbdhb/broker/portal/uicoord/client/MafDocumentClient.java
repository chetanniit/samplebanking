package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.MafDocumentException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

@Component
@Slf4j
public class MafDocumentClient {
    private static final String EXCEPTION_MESSAGE_TEMPLATE = "Could not load MAF PDF with document name: %s";
    private final String getMafDocumentEndpoint;
    private final RestTemplate restTemplate;

    public MafDocumentClient(
            @Value("${msvc.maf.get.url}") String getMafDocumentEndpoint,
            @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate) {
        this.getMafDocumentEndpoint = getMafDocumentEndpoint;
        this.restTemplate = restTemplate;
    }

    public InputStream getMafDocument(String documentName) {
        log.info("Calling {} to get MAF document with documentName {}", getMafDocumentEndpoint, documentName);

        try {
            ResponseEntity<byte[]> responseEntity = restTemplate.getForEntity(getMafDocumentEndpoint,
                byte[].class, documentName);

            HttpStatusCode statusCode = responseEntity.getStatusCode();
            if (statusCode == HttpStatus.OK && responseEntity.getBody() != null) {
                log.debug("MAF document with documentName {} successfully retrieved", documentName);
                return new ByteArrayInputStream(responseEntity.getBody());
            }

            log.error("Error response received from {} while getting MAF with documentName {}: statusCode {} - throwing MafDocumentException",
              getMafDocumentEndpoint, documentName, statusCode.value());
            throw new MafDocumentException(String.format(EXCEPTION_MESSAGE_TEMPLATE, documentName));

        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to get MAF document with documentName {}: {}",
                getMafDocumentEndpoint, documentName, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to get MAF document with documentName {}: {}",
                getMafDocumentEndpoint, documentName, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
