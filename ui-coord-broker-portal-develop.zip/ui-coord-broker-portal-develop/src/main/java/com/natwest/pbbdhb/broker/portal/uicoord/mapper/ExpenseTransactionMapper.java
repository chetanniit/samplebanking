package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseTransaction.CategoryCode;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategoryType;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

@Mapper
public abstract class ExpenseTransactionMapper {
    @Mapping(target = "redeemedOrLessThanSixMonths", source = "expenseTransactionDto.redeemedOrLessThanSixMonths", qualifiedByName = "mapYNToBool")
    @Mapping(target = "categoryCode", ignore = true)
    @Mapping(target = "originatingCurrency", source = "expenseTransactionDto.currency")
    abstract ExpenseTransaction toExpenseTransaction(ExpenseTransactionDto expenseTransactionDto);

    @Mapping(target = "redeemedOrLessThanSixMonths", source = "expenseTransaction.redeemedOrLessThanSixMonths", qualifiedByName = "mapBoolToYN")
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "numberOfConsolidation", ignore = true)
    @Mapping(target = "remainingMonths", ignore = true)
    @Mapping(target = "remainingYears", ignore = true)
    @Mapping(target = "transactionGroup", ignore = true)
    @Mapping(target = "type", source= "expenseTransaction.categoryCode", qualifiedByName = "mapCategoryCodeToType")
    @Mapping(target = "categoryCode",source= "expenseTransaction.categoryCode", qualifiedByName = "mapCategoryCodeExpenseTransactionToCategoryCodeExpenseTransactionDto")
    @Mapping(target = "currency", source = "expenseTransaction.originatingCurrency")
    @Mapping(target = "amountToBePaidInFuture", ignore = true)
    @Mapping(target = "familyLiveInProperty", ignore = true)
    abstract ExpenseTransactionDto toExpenseTransactionDto(ExpenseTransaction expenseTransaction);

    @Named("mapYNToBool")
    Boolean mapYNToBool(String value) {
        if (value == null) {
            return null;//NOSONAR
        }

        switch (value) {
            case "Y":
                return true;
            case "N":
                return false;
            default :
                return null;//NOSONAR
        }
    }

    @Named("mapBoolToYN")
    String mapBoolToYN(Boolean value) {

        if (value == null) {
            return null;
        }

        if (value) {
            return "Y";
        }
        return "N";
    }
    @Named("mapCategoryCodeToType")
    protected ExpenseCategoryType mapCategoryCodeToType(CategoryCode value) {
      if (value == null) {
        return null;
      }
      switch (value) {
        case BUDGET_ACCOUNT:
          return ExpenseCategoryType.BUDGET_ACCOUNT;
        case MAIL_ORDER :
          return ExpenseCategoryType.MAIL_ORDER;
        default :
          return null;
      }
    }

    @Named("mapCategoryCodeExpenseTransactionToCategoryCodeExpenseTransactionDto")
    protected ExpenseCategory mapCategoryCodeExpenseTransactionToCategoryCodeExpenseTransactionDto(CategoryCode value) {
      if (value == null) {
        return null;
      }
      if (value == CategoryCode.BUDGET_ACCOUNT) {
        return ExpenseCategory.CREDIT_CARD;
      } else if (value == CategoryCode.MAIL_ORDER) {
        return ExpenseCategory.CREDIT_CARD;
      } else {
        return ExpenseCategory.valueOf(value.toString());
      }
    }

    @AfterMapping
    void mapCategoryCodeExpenseTransactionDtoToCategoryCodeExpenseTransaction(ExpenseTransactionDto
        expenseTransactionDto, @MappingTarget ExpenseTransaction expenseTransaction) {
      ExpenseCategoryType type = expenseTransactionDto.getType();
      ExpenseCategory code = expenseTransactionDto.getCategoryCode();
      if (code == null) {
        expenseTransaction.setCategoryCode(null);
      } else if (type == ExpenseCategoryType.BUDGET_ACCOUNT) {
        expenseTransaction.setCategoryCode(CategoryCode.BUDGET_ACCOUNT.toString());
      } else if (type == ExpenseCategoryType.MAIL_ORDER) {
        expenseTransaction.setCategoryCode(CategoryCode.MAIL_ORDER.toString());
      } else {
        expenseTransaction.setCategoryCode(code.toString());
      }
    }

}
