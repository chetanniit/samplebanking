package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_READ_CASE_PERMISSION;

import com.natwest.pbbdhb.broker.portal.uicoord.client.ProductValidationClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ProductValidationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.CaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ProductValidationService;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductValidationServiceImpl implements ProductValidationService {

  private final UserClaimsProvider userClaimsProvider;
  private final AccessPermissionChecker accessPermissionChecker;
  private final CaseService caseService;
  private final ProductValidationClient productValidationClient;
  private final ProductValidationMapper productValidationMapper;

  @Override
  public ProductValidationResponse validateProduct(String brand, String caseId) {

    // check permissions
    final String brokerUsername = userClaimsProvider.getBrokerUsername();
    if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
      log.info("Error executing validateProduct: broker {} does not have permissions to access case {}; Throwing PermissionDeniedException",
          brokerUsername, caseId);
      throw new PermissionDeniedException(MSG_NO_READ_CASE_PERMISSION);
    }

    // load case data
    CaseApplication caseData = caseService
        .getCase(brand, caseId);
    String productCode = Optional.ofNullable(caseData.getProductDetails())
        .map(ProductDetails::getProductCode)
        .orElse(null);

    // check product data
    if (productCode == null) {
      log.warn("Warning executing validateProduct: broker {} is validating case {} with no product associated; returning invalid product response",
          brokerUsername, caseId);
      return ProductValidationResponse.builder()
          .validProduct(false)
          .build();
    }

    // map to msvc-product model
    ProductValidationMsvcRequest validationRequest = productValidationMapper.mapToValidationMsvcRequest(caseData);

    // execute call
    log.debug("Executing validateProduct; broker:{}, caseId: {}, productCode: {}",
        brokerUsername, caseId, productCode);
    ProductValidationMsvcResponse validationResponse = productValidationClient
        .validateProduct(brand, validationRequest);

    // map back to napoli model
    ProductValidationResponse response = productValidationMapper
        .mapToProductValidationResponse(validationResponse, caseData);

    Boolean validProduct = Optional.ofNullable(response)
        .map(ProductValidationResponse::getValidProduct)
        .orElse(null);
    log.debug("Executed validateProduct; broker:{}, caseId: {}, productCode: {},  validProduct: {}",
        brokerUsername, caseId, productCode, validProduct);
    return response;
  }

}
