package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.AssertTrue;

@Data
public class BrokerDip {

  @AssertTrue
  private Boolean consentToDIP;

}
