package com.natwest.pbbdhb.broker.portal.uicoord.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PostcodeUtil {
    //  Postcode pattern accepting full postcodes with or with a space from natwest
    public final static String POSTCODE_REGEX = "^[A-Z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}$";
    // Postcode pattern accepting full postcodes with or without a space or partial postcodes containing the first part ("outward code") only
    private final String POSTCODE_AND_PARTIAL_POSTCODE_REGEX = "[A-Z]{1,2}[0-9R][0-9A-Z]?( ?[0-9][ABD-HJLNP-UW-Z]{2})?$";
    private final Pattern postcodePattern = Pattern.compile(POSTCODE_AND_PARTIAL_POSTCODE_REGEX);


    public boolean isValidPostcodeFormat(String input) {
        Matcher matcher = postcodePattern.matcher(input);
        return matcher.matches();
    }
}
