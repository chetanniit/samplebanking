package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.SolicitorSearchClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchResultDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.SolicitorMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.service.SolicitorSearchService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.PostcodeUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import jakarta.validation.ConstraintViolationException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SolicitorSearchServiceImpl implements SolicitorSearchService {
    public static final String SEARCH_TEXT_TOO_SHORT_MESSAGE = "search text must be at least 2 characters";

    private final PostcodeUtil postcodeChecker = new PostcodeUtil();
    private final SolicitorSearchClient solicitorSearchClient;
    private final SolicitorMapper solicitorMapper;

    @Override
    public List<Solicitor> solicitorSearch(String brand, String searchFor) {

        log.debug("Searching for solicitor with text {}", searchFor);
        String normalised = searchFor.trim().toUpperCase(Locale.ROOT);
        if (normalised.length() < 2) {
            log.error("Error searching for solicitor with text {}: {}", searchFor, SEARCH_TEXT_TOO_SHORT_MESSAGE);
            throw new ConstraintViolationException(SEARCH_TEXT_TOO_SHORT_MESSAGE, null);
        }

        List<SolicitorSearchResultDto> postcodeResults;
        Boolean isValidPostcode = postcodeChecker.isValidPostcodeFormat(normalised);
        if(isValidPostcode) {
          log.debug("Search text is a valid postcode. Calling solicitorSearchClient to search for solicitor with postcode {}", normalised);
          postcodeResults = solicitorSearchClient.solicitorSearch(brand, null, normalised);
          log.debug("solicitorSearchClient successfully called to search for solicitor with postcode {}", normalised);
        } else {
          log.debug("Search text is not a valid postcode. Returning an empty list");
          postcodeResults = new ArrayList<>();
        }

        log.debug("Calling solicitorSearchClient to search for solicitor with company name {}", normalised);
        List<SolicitorSearchResultDto> companyNameResults = solicitorSearchClient.solicitorSearch(brand, normalised, null);
        log.debug("solicitorSearchClient successfully called to search for solicitor with company name {}", normalised);

        Set<SolicitorSearchResultDto> resultSet = new HashSet<>();
        resultSet.addAll(postcodeResults);
        resultSet.addAll(companyNameResults);

        // Sort by company name
        Comparator<Solicitor> solicitorComparator
                = Comparator.nullsLast(
                        Comparator
                                .comparing(this::getUpperCaseCompanyName)
                                .thenComparing(Solicitor::getAssociateSequenceNumber)
                                .thenComparing(Solicitor::getCompanyCode));
        return resultSet
                .stream()
                .map(s -> solicitorMapper.toSolicitor(s))
                .sorted(solicitorComparator)
                .collect(Collectors.toList());
    }

    private String getUpperCaseCompanyName(Solicitor s) {
        return s.getCompanyName().toUpperCase(Locale.ROOT);
    }
}
