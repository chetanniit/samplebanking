package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.openapi.product.SuitableProduct.ProductTermEnum.FIVE_YEAR;
import static com.natwest.pbbdhb.openapi.product.SuitableProduct.ProductTermEnum.TWO_YEAR;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.Optional.ofNullable;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.EarlyRepaymentChargeDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.RepaymentType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisBorrowingRequirements;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisRepaymentDetails;
import com.natwest.pbbdhb.cases.dto.ErcItemDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.commondictionaries.enums.cases.ProductMortgageType;
import com.rbs.pbbdhb.sales.esis.models.ErcItem;
import com.rbs.pbbdhb.sales.esis.models.Product;
import com.rbs.pbbdhb.sales.esis.models.enums.MortgageType;
import com.rbs.pbbdhb.sales.esis.models.enums.ProductType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EsisProductMapper {

    private static final BigDecimal ONE_HUNDRED = BigDecimal.valueOf(100);
    private static final DateTimeFormatter PRODUCT_API_DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-uuuu");
    private static final DateTimeFormatter CASE_API_DATE_FORMATTER = DateTimeFormatter.ofPattern("uuuu-MM-dd");

    /**
     * WHEN REPAYMENT || INTEREST_ONLY return:
     * { ...map selected product with ERC items }
     * ELSE WHEN MIXED repayment return:
     * { ...repayment product first, with product fees }
     * { ...interest only product, without product fees }
     */
    public List<Product> mapToEsisProducts(EsisData esisData) {
        final EsisRepaymentDetails repaymentDetails = esisData.getMortgageDetails().getRepaymentDetails();
        final boolean isMixedRepayment = RepaymentType.MIXED.toString()
                .equals(repaymentDetails.getRepaymentType());

        // IF when REPAYMENT || INTEREST_ONLY (using negative condition to avoid spaghetti code)
        if (!isMixedRepayment) {
            return singletonList(esisProduct(esisData.getSelectedProduct(), esisData));
        }

        // ELSE when MIXED repayment return:
        // { ...repayment product first, with product fees }
        // { ...interest only product, without product fees }

        // repaymentProduct with correct loan amount and term
        final Product repaymentProduct = esisProduct(esisData.getSelectedProduct(), esisData);
        repaymentProduct.setCalculationType(MortgageType.REPAYMENT.toString());
        repaymentProduct.setLoanAmount(repaymentDetails.getAmountCapital());
        repaymentProduct.setTermYears(repaymentDetails.getTermYears());
        repaymentProduct.setTermMonths(repaymentDetails.getTermMonths());

        // interestOnlyProduct with correct loan amount and term WITHOUT FEES
        final Product interestOnlyProduct = esisProduct(esisData.getSelectedProduct(), esisData);
        interestOnlyProduct.setCalculationType(MortgageType.INTEREST_ONLY.toString());
        interestOnlyProduct.setLoanAmount(repaymentDetails.getInterestOnlyAmount());
        interestOnlyProduct.setTermYears(repaymentDetails.getInterestOnlyTermYears());
        interestOnlyProduct.setTermMonths(repaymentDetails.getInterestOnlyTermMonths());
        interestOnlyProduct.setProductFee(BigDecimal.ZERO);
        interestOnlyProduct.setChapsFee(BigDecimal.ZERO);
        interestOnlyProduct.setValuationFee(BigDecimal.ZERO);

        // BUGFIX: mixed products PDF was showing a cashback value with double the amount we were expecting
        // cause: we were sending cashback on both products
        interestOnlyProduct.setCashBackValue(null);

        return Arrays.asList(repaymentProduct, interestOnlyProduct);
    }

    /**
     * Maps Product API Product into Case API Product Details Dto
     */
    public ProductDetailsDto mapToProductDetailsDto(ProductDto product, EsisData esisData) {
        boolean firstTimeBuyer = ofNullable(esisData.getMortgageDetails()).
                map(EsisMortgageDetails::getFirstTimeBuyer)
                .orElse(false);
        ProductMortgageType mortgageType = firstTimeBuyer
                ? ProductMortgageType.FIRST_TIME_BUYER
                : ProductMortgageType.PURCHASE;
        return ProductDetailsDto.builder()
                .productCode(product.getProductCode())
                .productType(product.getProductType())
                .productTerm(product.getProductTerm())
                .productName(product.getProductName())
                .ltv(product.getLtv().longValue())
                .productSelectedDate(optionalProductDate(product.getProductSearchDate()).map(d -> d.format(CASE_API_DATE_FORMATTER)).orElse(null))
                .productEndDate(optionalProductDate(product.getProductEndDate()).map(d -> d.format(CASE_API_DATE_FORMATTER)).orElse(null))
                .mortgageType(mortgageType.toString())
                .initialInterestRate(StringUtils.equalsIgnoreCase(ProductType.TRACKER.value(), product.getProductType())
                        ? ofNullable(product.getTrackerMarginPercent()).map(EsisProductMapper::shiftedBigDecimal).orElse(null) // times 100 before scaling to 2 decimals
                        : EsisProductMapper.nullableScaledBigDecimal(product.getInitialInterestRate()))
                .svr(BigDecimal.valueOf(product.getSvr()))
                .baseRate(ofNullable(product.getBaseRate())
                        .map(EsisProductMapper::shiftedBigDecimal) // times 100 before scaling to 2 decimals
                        .orElse(null))
                .cashBackValue(product.getCashBackValue())
                .ercItems(ofNullable(product.getEarlyRepaymentCharges()).orElse(emptyList())
                        .stream()
                        .map(ercItem -> esisErcItemDto(ercItem, product))
                        .collect(Collectors.toList()))
                .isFreeLegal(product.getFreeLegal())
                .build();
    }

    private String mapMortgageType(String repaymentTypeValue) {
        MortgageType mortgageType = EnumUtils.getEnumIgnoreCase(MortgageType.class, repaymentTypeValue, null);
        return ofNullable(mortgageType).map(Objects::toString).orElse(null);
    }

    /**
     * Maps Product API Product into Esis API Product
     * Notes:
     * - Product fees are not part of the ESIS model which is strange
     */
    private Product esisProduct(ProductDto p, EsisData esisData) {
        final EsisBorrowingRequirements borrowingRequirements = esisData.getBorrowingRequirements();
        final EsisMortgageDetails mortgageDetails = esisData.getMortgageDetails();

        return Product.builder()
                //.fees() product fees are not part of the ESIS model which is strange
                .erc(ofNullable(p.getEarlyRepaymentCharges()).orElse(emptyList())
                        .stream()
                        .map(ercItem -> toEsisErcItem(ercItem, p))
                        .collect(Collectors.toList()))
                .loanAmount(p.getMortgageAmount())
                .calculationType(mapMortgageType(mortgageDetails.getRepaymentDetails().getRepaymentType()))
                .termMonths(p.getMortgageTermMonths())
                .termYears(p.getMortgageTermYears())
                .productSelectionDate(nullableProductDate(p.getProductSearchDate()))
                .initialInterestRate(StringUtils.equalsIgnoreCase(ProductType.TRACKER.value(), p.getProductType())
                        ? ofNullable(p.getTrackerMarginPercent()).map(EsisProductMapper::shiftedBigDecimal).orElse(null) // times 100 before scaling to 2 decimals
                        : EsisProductMapper.nullableScaledBigDecimal(p.getInitialInterestRate()))
                .svr(nullableScaledBigDecimal(p.getSvr()))
                .baseRate(ofNullable(p.getBaseRate())
                        .map(EsisProductMapper::shiftedBigDecimal) // times 100 before scaling to 2 decimals
                        .orElse(null))
                .productCode(p.getProductCode())
                .productName(p.getProductName())
                .productEndDate(nullableProductDate(p.getProductEndDate()))
                .productType(p.getProductType())
                .productTerm(p.getProductTerm())
                .ltv(nullableScaledBigDecimal(p.getLtv()))
                .productFee(p.getProductFee())
                .feeAddedToLoan(borrowingRequirements.getAddFeeToLoan())
                .valuationFee(p.getStandardValuationFee())
                .chapsFee(p.getChapsFee())
                .cashBackValue(p.getCashBackValue())
                .freeLegal(p.getFreeLegal())
                .build();
    }

    public static ErcItem toEsisErcItem(EarlyRepaymentChargeDto earlyRepaymentChargeDto, ProductDto productApiDto) {
        final String productTermText = productApiDto.getProductTerm();
        final int productTermInYears;
        if (TWO_YEAR.toString().equalsIgnoreCase(productTermText)) {
            productTermInYears = 2;
        } else if (FIVE_YEAR.toString().equalsIgnoreCase(productTermText)) {
            productTermInYears = 5;
        } else {
            // defensive programming, should not happen: Product ESIS only supports 2 and 5
            productTermInYears = 0;
        }
        final Optional<LocalDate> productEndDate = optionalProductDate(productApiDto.getProductEndDate());
        final Optional<LocalDate> productStartDate = productEndDate
                .map(v -> v.minusYears(productTermInYears));
        // ercEndDate:
        // copied logic from XO, there was a good point in not using search date because it might be in mid of month
        // ercEndDate = product.endDate - product.term + erc.year
        final Optional<LocalDate> ercEndDate = productStartDate
                .map(v -> v.plusYears(earlyRepaymentChargeDto.getYear()));
        return ErcItem.builder()
                .seqNo(earlyRepaymentChargeDto.getYear())
                .percentage(ofNullable(earlyRepaymentChargeDto.getCharge())
                        .map(BigDecimal::valueOf).orElse(BigDecimal.ZERO)
                        .multiply(ONE_HUNDRED)) // product api returns 0.1234 to represent pct
                .endDate(ercEndDate.orElse(null))
                .build();
    }

    private ErcItemDto esisErcItemDto(EarlyRepaymentChargeDto earlyRepaymentChargeDto, ProductDto productApiDto) {
        final String productTermText = productApiDto.getProductTerm();
        final int productTermInYears;
        if (TWO_YEAR.toString().equalsIgnoreCase(productTermText)) {
            productTermInYears = 2;
        } else if (FIVE_YEAR.toString().equalsIgnoreCase(productTermText)) {
            productTermInYears = 5;
        } else {
            productTermInYears = 0;
        }
        final Optional<LocalDate> productEndDate = optionalProductDate(productApiDto.getProductEndDate());
        final Optional<LocalDate> productStartDate = productEndDate
                .map(v -> v.minusYears(productTermInYears));
        final Optional<LocalDate> ercEndDate = productStartDate
                .map(v -> v.plusYears(earlyRepaymentChargeDto.getYear()));
        return ErcItemDto.builder()
                .seqNo(earlyRepaymentChargeDto.getYear())
                .percentage(ofNullable(earlyRepaymentChargeDto.getCharge())
                        .map(BigDecimal::valueOf).orElse(BigDecimal.ZERO)
                        .multiply(ONE_HUNDRED)) // product api returns 0.1234 to represent pct
                .endDate(ercEndDate.map(date -> date.format(CASE_API_DATE_FORMATTER)).orElse(null))
                .build();
    }

    private static BigDecimal nullableScaledBigDecimal(Double value) {
        return ofNullable(value)
                .map(EsisProductMapper::scaledBigDecimal)
                .orElse(null);
    }

    private static BigDecimal newBigDecimal(Double v) {
      return BigDecimal.valueOf(v);
    }

    private static BigDecimal scaledBigDecimal(Double v) {
      return minScale(newBigDecimal(v));
    }

    public static BigDecimal shiftedBigDecimal(Double v) {
      return minScale(newBigDecimal(v).movePointRight(2));
    }

    private static BigDecimal minScale(BigDecimal bd) {
      return bd.setScale(Math.max(2, bd.scale()));
    }

    private LocalDate nullableProductDate(String value) {
        return optionalProductDate(value)
                .orElse(null);
    }

    private static Optional<LocalDate> optionalProductDate(String value) {
        return ofNullable(value)
                .map(v -> LocalDate.parse(v, PRODUCT_API_DATE_FORMATTER));
    }

}
