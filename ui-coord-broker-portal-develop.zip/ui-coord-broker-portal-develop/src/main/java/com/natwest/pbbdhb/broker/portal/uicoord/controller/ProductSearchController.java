package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Product;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ProductSearchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "ProductSearch", description = "Product search API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class ProductSearchController {

    private final ProductSearchService productSearchService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "productSearch",
            summary = "Search for products for an application",
            tags = "ProductSearch"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful product search", content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(value = PATH_PRODUCT_SEARCH, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Product>> productSearch(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                        @RequestBody @Valid final ProductSearchRequest productSearchRequest) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to search for products for brokerUsername {}", brokerUsername);
        List<Product> products = this.productSearchService.search(brand, productSearchRequest);
        log.info("Products for brokerUsername {} successfully retrieved", brokerUsername);
        return ResponseEntity.ok(products);
    }
}
