package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseJourneyDataDto {
  private Boolean firstTimeBuyer;
  private Boolean usingSpecialistScheme;
  private Boolean hasDependants;
  private Boolean additionalBorrowing;
  private String solicitorAddress1;
  private String solicitorAddress2;
  private String solicitorAddress3;
  private Boolean isPortingProduct;
  private String portingText;
  private Boolean hasAdditionalBorrowing;
  private String currentRoute;
  private Boolean isAssuredShortHoldOrShortAssured;
  private Boolean isForInvestment;
  private Boolean isNotSelectiveLicenceOrHMO;
  private Boolean isRentingToImmediateFamilyMember;
  private Boolean movingToPropertyAtCompletion;
  private List<String> repaymentStrategyAddresses;
  private BureauCallInfoDto bureauCallInfo;
  private Boolean hasCompletedDip; // used to lock 'about the case' fields section
  private Boolean brokerFeeCharged;
  private JourneyStep step;
  private Boolean leaseholdOwnershipTerm; // boolean required to handle ground rent/service charge checks
  private Boolean isProductSelectedAtDip;
  private Integer brokerJourneyVersion;
  private Boolean epcRatingAOrBDip; // boolean required to store if it's green mortgage on btl dip
  // isProductFeePaymentSelected is required to know if the customer selected fee payment option...
  // in FMA or if it was defaulted at DIP for BTL case
  private Boolean isProductFeePaymentSelected;
}
