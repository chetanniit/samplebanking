package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_5_OR_6_DIGITS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_8_DIGITS;

@Data
public class DirectDebitDetails {
    @Size(max = 18)
    @NotBlank
    private String accountName;

    @NotNull
    @Pattern(regexp = "^[0-9]{8}$", message = MUST_BE_8_DIGITS)
    private String accountNumber;

    @NotNull
    @Pattern(regexp = "^[0-9]{5,6}$", message = MUST_BE_5_OR_6_DIGITS)
    private String sortCode;

    @NotNull
    @Min(value = 1)
    @Max(value = 28)
    private Integer paymentDayOfTheMonth;

    private Boolean attestation;
}
