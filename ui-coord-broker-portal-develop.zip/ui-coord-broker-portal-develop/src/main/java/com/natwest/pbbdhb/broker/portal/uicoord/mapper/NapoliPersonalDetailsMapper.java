package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.applicant.dto.PersonTelephoneDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalTelephone;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.mapper.TitleMap.tokenize;
import static com.natwest.pbbdhb.broker.portal.uicoord.mapper.TitleMap.translate;

@Mapper(builder = @Builder(disableBuilder = true))
public interface NapoliPersonalDetailsMapper {

    @Mapping(target = "telephone", source = "telephones", qualifiedByName = "phonesDtoToPhone")
    PersonalDetails toPersonalDetails(PersonDetailsDto personalDetailsDto);

    @Mapping(target = "telephones", source = "telephone", qualifiedByName = "phoneToPhonesDto")
    @Mapping(target = "mailIndicator", ignore = true)
    @Mapping(target = "emailVerified", ignore = true)
    PersonDetailsDto toPersonalDetailsDto(PersonalDetails personalDetails);

    PersonalTelephone toPersonalTelephone(PersonTelephoneDto dto);

    @Mapping(target = "preferred", constant = "true")
    @Mapping(target = "verified", ignore = true)
    PersonTelephoneDto toPersonalTelephoneDto(PersonalTelephone phone);

    @Named("phonesDtoToPhone")
    default PersonalTelephone phonesDtoToPhone(List<PersonTelephoneDto> phones) {
        if (phones == null || phones.isEmpty()) {
            return null;
        }

        return toPersonalTelephone(phones.get(0));
    }

    @Named("phoneToPhonesDto")
    default List<PersonTelephoneDto> phoneToPhonesDto(PersonalTelephone phone) {
        if (phone == null) {
            return null;
        }
        List<PersonTelephoneDto> phoneDtos = new ArrayList<>();
        phoneDtos.add(toPersonalTelephoneDto(phone));
        return phoneDtos;
    }

    @AfterMapping
    default void useTitleEnum(@MappingTarget PersonDetailsDto personalDetailsDto) {
        String translatedTitle = personalDetailsDto.getTitle();
        if (translatedTitle == null) {
            return;
        }

        personalDetailsDto.setTitle(tokenize(translatedTitle));
    }

    @AfterMapping
    default void translateTitle(@MappingTarget PersonalDetails personalDetails) {
        String tokenizedTitle = personalDetails.getTitle();
        if (tokenizedTitle == null) {
            return;
        }

        personalDetails.setTitle(translate(tokenizedTitle));
    }
}
