package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_INVALID_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_VALID_REGEX;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_BROKER_BASE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_DECLARATION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_PAYMENT_PATHS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_BROKER_PRODUCT_SWITCH;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PAYMENT_PATH_NAME_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PAYMENT_PATH_NAME_PARAM;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerProductSwitchDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Tag(name = "Broker", description = "Broker API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
@RequestMapping(PATH_BROKER_BASE)
public class BrokerController {

  private final BrokerService brokerService;
  private final UserClaimsProvider userClaimsProvider;
  private final BrokerInfoService brokerInfoService;

  @Operation(operationId = "getBrokerPaymentPaths", summary = "Gets a broker's payment paths", tags = "Broker")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successful retrieval of broker's payment paths", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = PaymentPath.class)))),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")})
  @GetMapping(value = PATH_GET_BROKER_PAYMENT_PATHS, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<PaymentPath>> getBrokerPaymentPaths() {
    String username = userClaimsProvider.getBrokerUsername();
    BrokerInfo broker = brokerInfoService.getBroker(username);

    log.info("Request to get broker payment paths for brokerUsername {}", username);
    List<PaymentPath> paymentPaths = brokerService.getBrokerPaymentPaths(broker);
    log.info("Broker payment paths for brokerUsername {} successfully retrieved", username);
    return ResponseEntity.ok(paymentPaths);
  }

  @Operation(operationId = "getBrokerProductSwitchDetails", summary = "Gets a broker's product switch details",
          tags = "Broker")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Successful retrieval of broker's product switch details",
                  content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(
                          implementation = BrokerProductSwitchDetails.class)))),
          @ApiResponse(responseCode = "400", description = "Bad request"),
          @ApiResponse(responseCode = "500", description = "Internal Server Error")})
  @GetMapping(value = PATH_GET_BROKER_PRODUCT_SWITCH, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<BrokerProductSwitchDetails> getBrokerProductSwitchDetails(
          @Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
          @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
          @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
          @Parameter(name = PAYMENT_PATH_NAME_PARAM, description = PAYMENT_PATH_NAME_DESCRIPTION)
          @RequestParam(name = PAYMENT_PATH_NAME_PARAM)
          final String paymentPathName) {
    String username = userClaimsProvider.getBrokerUsername();
    BrokerInfo broker = brokerInfoService.getBroker(username);
    log.info("Request to get broker product switch details for brokerUsername {}", username);
    BrokerProductSwitchDetails brokerProductSwitchDetails = brokerService.getBrokerProductSwitchDetails(brand, paymentPathName, broker);
    log.info("Broker product switch details for brokerUsername {} successfully retrieved", username);
    return ResponseEntity.ok(brokerProductSwitchDetails);
  }

  @Operation(operationId = "getBrokerDeclaration", summary = "Gets a broker's declaration", tags = "Broker")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successful retrieval of broker's declaration", content = @Content(mediaType = "text/html")),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")})
  @GetMapping(value = PATH_GET_BROKER_DECLARATION, produces = MediaType.TEXT_HTML_VALUE)
  public ResponseEntity<String> getBrokerDeclaration(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
  @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
  @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand) {
    String username = userClaimsProvider.getBrokerUsername();
    BrokerInfo broker = brokerInfoService.getBroker(username);

    log.info("Request to get broker declaration for brokerUsername {}", username);
    String brokerDeclaration = brokerService.getBrokerDeclaration(brand, broker);
    log.info("Broker declaration for brokerUsername {} successfully retrieved", username);
    return ResponseEntity
        .status(HttpStatus.OK)
        .contentType(MediaType.TEXT_HTML)
        .body(brokerDeclaration);
  }
}
