package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MandatoryBasedOnEnumValue;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Data
@MandatoryBasedOnEnumValue(MandatoryField = "borrowingDetails", EnumField = "reason", EnumValue = "OTHER")
@MandatoryBasedOnEnumValue(MandatoryField = "borrowingDetails", EnumField = "reason", EnumValue = "OTHER_DEBT_CONSOLIDATION")
public class AdditionalBorrowing {
    @NotNull
    @Min(1)
    @Max(99_999_999)
    private Long amount;

    public enum AdditionalBorrowingReason implements ValuedEnum {
        HOME_IMPROVEMENT,
        HOUSE_PURCHASE,
        HOLIDAY,
        BUY_NEW_CAR,
        BUY_USED_CAR,
        DEBT_CONSOLIDATION,
        OTHER,
        OTHER_DEBT_CONSOLIDATION;

        @Override
        public String value() {
            return name();
        }
    }

    @NotNull
    @ValidateEnum(enumClass = AdditionalBorrowingReason.class)
    private String reason;

    private String borrowingDetails;

    // Required only if mortgage.mortgageType is MIXED
    @ValidateEnum(enumClass = CalculationMortgageType.class)
    private String calculationType;

    public enum CalculationMortgageType implements ValuedEnum {
        REPAYMENT,
        INTEREST_ONLY;

        @Override
        public String value() {
            return name();
        }
    }
}
