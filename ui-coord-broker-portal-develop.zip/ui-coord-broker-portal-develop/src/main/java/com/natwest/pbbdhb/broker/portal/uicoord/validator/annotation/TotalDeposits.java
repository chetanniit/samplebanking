package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.TotalDepositsValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = TotalDepositsValidator.class)
public @interface TotalDeposits {

    String message() default "Total of deposits must be less than both property value and purchase price.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
