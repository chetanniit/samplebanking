package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerInformation;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerProductSwitchDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Value;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import static java.util.Objects.nonNull;

@Mapper
public abstract class BrokerSwitchMapper {
    @Value("${broker.switch.url}")
    String brokerSwitchUrl;

    @Mapping(target = "encodedData", source = "brokerInformation", qualifiedByName = "toEncodedData")
    @Mapping(target = "brokerSwitchUrl", expression = "java(brokerSwitchUrl)")
    public abstract BrokerProductSwitchDetails toBrokerProductSwitchDetails(BrokerInformation brokerInformation);

    @Named("toEncodedData")
    String toEncodedData(BrokerInformation brokerInformation)
        throws ParserConfigurationException, TransformerException, SAXException {
        if (nonNull(brokerInformation)) {
            return brokerInformation.generateEncodedXml();
        }
        return null;
    }
}
