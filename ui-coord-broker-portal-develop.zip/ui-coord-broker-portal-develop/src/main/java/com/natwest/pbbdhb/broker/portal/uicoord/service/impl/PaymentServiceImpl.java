package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.PaymentUrlClient;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.PaymentMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentUrlClient paymentUrlClient;
    private final PaymentMapper paymentMapper;

    @Override
    public PaymentResponse fetchPaymentUrl(String brand, PaymentRequest paymentRequest) {
        String mortgageReferenceNumber = paymentRequest.getMortgageReferenceNumber();
        log.debug("Calling paymentUrlClient to generate payment URL for mortgage reference number {}", mortgageReferenceNumber);
        PaymentResponse paymentResponse = paymentMapper.toPaymentUrlResponse(
                paymentUrlClient.generatePaymentUrl(brand, paymentMapper.toPaymentUrlRequestDto(paymentRequest))
        );
        log.debug("paymentUrlClient successfully called to generate payment URL for mortgage reference number {}", mortgageReferenceNumber);
        return paymentResponse;
    }
}
