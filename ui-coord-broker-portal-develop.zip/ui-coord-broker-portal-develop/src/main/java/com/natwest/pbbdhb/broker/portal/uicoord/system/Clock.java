package com.natwest.pbbdhb.broker.portal.uicoord.system;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class Clock {
    public LocalDateTime localNow() {
        return LocalDateTime.now();
    }
}
