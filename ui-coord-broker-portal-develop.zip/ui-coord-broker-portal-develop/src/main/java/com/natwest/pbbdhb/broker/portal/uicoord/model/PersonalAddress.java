package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateAtLeastOneNotNull;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@ValidateAtLeastOneNotNull(fields = "houseNumber,houseName,flatNameOrNumber")
public class PersonalAddress {

    @Size(max = 5)
    private String houseNumber;

    @Size(max = 22)
    private String houseName;

    @Size(max = 10)
    private String flatNameOrNumber;

    @NotBlank
    @Size(max = 30)
    private String street;

    @NotBlank
    @Size(max = 28)
    private String town;

    @Size(max = 18)
    private String county;

    @Size(max = 12)
    private String postcode;

    @NotBlank
    @Size(min = 2, max = 2)
    private String country;

    @ValidateEnum(enumClass = OccupyStatusType.class)
    private String occupyStatus;

    @NotNull
    @Min(value = 1)
    @Max(value = 12)
    private Integer startMonth;

    @NotNull
    @Min(value = 1900)
    @Max(value = 2100)
    private Integer startYear;

    @Min(value = 1)
    @Max(value = 99999999)
    private Integer currentPropertyValue;

    public enum OccupyStatusType implements ValuedEnum {
        OWNER_MORTGAGED,
        OWNER_NO_MORTGAGE,
        LIVING_WITH_RELATIVES,
        OTHER,
        TENANT;

        @Override
        public String value() {
            return name();
        }
    }

}
