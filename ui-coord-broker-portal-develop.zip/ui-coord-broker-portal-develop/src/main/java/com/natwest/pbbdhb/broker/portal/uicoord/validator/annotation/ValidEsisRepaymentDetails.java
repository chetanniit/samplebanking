package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.esis.EsisRepaymentDetailsValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EsisRepaymentDetailsValidator.class)
public @interface ValidEsisRepaymentDetails {

    String message() default "amountCapital, interestOnlyAmount, interestOnlyTermYears and interestOnlyTermMonths cannot be empty when repaymentType is MIXED";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
