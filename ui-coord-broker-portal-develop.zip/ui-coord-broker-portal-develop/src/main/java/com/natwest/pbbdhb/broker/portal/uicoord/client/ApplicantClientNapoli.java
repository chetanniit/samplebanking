package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class ApplicantClientNapoli {

    private final String getApplicantsEndpoint;
    private final String createApplicantEndpoint;
    private final String updateApplicantEndpoint;
    private final RestTemplate restTemplate;

    public ApplicantClientNapoli(
            @Value("${msvc.applicant.get.url}") String getApplicantsEndpoint,
            @Value("${msvc.applicant.create.url}") String createApplicantEndpoint,
            @Value("${msvc.applicant.update.url}") String updateApplicantEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.getApplicantsEndpoint = getApplicantsEndpoint;
        this.createApplicantEndpoint = createApplicantEndpoint;
        this.updateApplicantEndpoint = updateApplicantEndpoint;
        this.restTemplate = restTemplate;
    }

    public ApplicantDto saveApplicant(String brand, ApplicantDto applicant) {
        return StringUtils.hasText(applicant.getApplicantId()) ? updateApplicant(brand, applicant) : createApplicant(brand, applicant);
    }

    private ApplicantDto createApplicant(String brand, ApplicantDto applicant) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(createApplicantEndpoint);
        URI url = builder.build().toUri();
        String version = applicant.getVersion();
        String caseId = applicant.getCaseId();
        String applicantId = applicant.getApplicantId();
        log.info("Calling {} to create applicant with version {}, caseId {}, and applicantId {}", url, version, caseId, applicantId);

        try {
        ApplicantDto applicantDto = restTemplate.exchange(
                url,
                HttpMethod.POST,
                new HttpEntity<>(applicant, constructHeadersForJsonRequest(brand)),
                ApplicantDto.class).getBody();

        if(applicantDto == null) {
          log.warn("Null response body received from {} while creating applicant with version {}, caseId {}, and applicantId {}", url, version, caseId, applicantId);
        } else {
            log.debug("Applicant with version {}, caseId {}, and applicantId {} successfully created",
              applicantDto.getVersion(), caseId, applicantId);
        }

        return applicantDto;

        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to create applicant with version {}, caseId {}, and applicantId {}: {}",
                url, version, caseId, applicantId, ex.getMessage());
            throw  ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to create applicant with version {}, caseId {}, and applicantId {}: {}",
                url, version, caseId, applicantId, t.getMessage());
            throw  t;
        }
    }

    private ApplicantDto updateApplicant(String brand, ApplicantDto applicant) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(updateApplicantEndpoint);
        String applicantId = applicant.getApplicantId();
        String caseId = applicant.getCaseId();
        String version = applicant.getVersion();
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("applicantId", applicantId);
        builder.uriVariables(urlParams);
        URI url = builder.build().toUri();

        log.info("Calling {} to update applicant with version {}, caseId {}, and applicantId {}", url, version, caseId, applicantId);

        // Here is an example of creating headers that will apply stronger validation rules
        // HttpHeaders requestHeaders = constructHeadersForJsonRequest(brand);
        // requestHeaders.add("validation-type", "dip");  // "fma" is also an option

        try {
            ApplicantDto applicantDto = restTemplate.exchange(
                url,
                HttpMethod.PUT,
                new HttpEntity<>(applicant, constructHeadersForJsonRequest(brand)),
                ApplicantDto.class).getBody();

            if(applicantDto == null) {
              log.warn("Null response body received from {} while updating applicant with version {}, caseId {}, and applicantId {}", url, version, caseId, applicantId);
          } else {
              log.debug(
                  "Applicant with version {}, caseId {}, and applicantId {} successfully updated",
                  version, caseId, applicantId);
          }
          return applicantDto;

        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to update applicant with version {}, caseId {}, and applicantId {}: {}", url,
                version, caseId, applicantId, ex.getMessage());
            throw  ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to update applicant with version {}, caseId {} and applicantId {}: {}", url,
                version, caseId, applicantId, t.getMessage());
            throw  t;
        }
    }

    public List<ApplicantDto> getApplicants(String brand, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(getApplicantsEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);

        URI url = builder.build().toUri();
        log.info("Calling {} to get applicants", url);

        List<ApplicantDto> applicantDtoList;
        try {
            // TODO: Ensure return value is never null.

             applicantDtoList = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    new HttpEntity<>(constructHeadersForJsonRequest(brand)),
                    new ParameterizedTypeReference<List<ApplicantDto>>() {
                    }).getBody();

             if(applicantDtoList != null) {
               List<String> applicantIds = applicantDtoList.stream()
                   .map(applicant -> applicant.getApplicantId()).collect(
                       Collectors.toList());
               log.debug("Applicants with caseId {} and applicantIds {} successfully retrieved",
                   caseId, applicantIds);
             } else {
               throw new HttpClientErrorException(HttpStatus.NOT_FOUND,
                   String.format("Null response body returned from %s to get applicants for caseId %s", url, caseId));
             }

        } catch (HttpClientErrorException.NotFound ex) {
            log.warn("Applicants for caseId {} not found: returning an empty list - {}", caseId, ex.getMessage());
            applicantDtoList = new ArrayList<>();
        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to get applicants with caseId {}: {}", url, caseId, ex.getMessage());
            throw  ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to get applicants with caseId {}: {}", url, caseId, t.getMessage());
            throw  t;
        }
        return applicantDtoList;
    }
}
