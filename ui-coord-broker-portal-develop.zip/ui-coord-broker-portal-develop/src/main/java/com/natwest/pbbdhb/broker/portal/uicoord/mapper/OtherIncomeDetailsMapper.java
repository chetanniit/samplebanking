package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherIncomeDetails;
import com.natwest.pbbdhb.income.expense.model.income.dto.OtherIncomeDetailsDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface OtherIncomeDetailsMapper {

  @Mapping(target = "otherIncomeOriginatingCurrency", source = "otherIncomeCurrency")
    OtherIncomeDetails toOtherIncomeDetails(OtherIncomeDetailsDto otherIncomeDetailsDto);

    @Mapping(target = "sourceOfIncomeCountryCode", ignore = true)
    @Mapping(target = "otherIncomeCurrency", source = "otherIncomeOriginatingCurrency")
    OtherIncomeDetailsDto toOtherIncomeDetailsDto(OtherIncomeDetails otherIncomeDetails);
}
