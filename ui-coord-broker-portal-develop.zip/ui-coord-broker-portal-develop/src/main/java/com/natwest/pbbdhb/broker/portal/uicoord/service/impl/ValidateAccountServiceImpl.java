package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.ValidateAccountClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ValidateAccountResult;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ValidateAccountRequestMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ValidateAccountRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ValidateAccountService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ValidateAccountServiceImpl implements ValidateAccountService {
    private final ValidateAccountClient validateAccountClient;
    private final ValidateAccountRequestMapper validateAccountRequestMapper;

    @Override
    public boolean validateAccount(String brand, ValidateAccountRequest validateAccountRequest) {

        log.debug("Calling validateAccountClient to validate account");
        ValidateAccountResult result = validateAccountClient.validateAccount(brand, validateAccountRequestMapper.toValidateAccountRequestDto(validateAccountRequest));
        log.debug("validateAccountClient successfully called to validate account");
        return result.isValid();
    }
}
