package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;

import java.util.List;

public interface SolicitorSearchService {

    List<Solicitor> solicitorSearch(String brand, String searchFor);
}
