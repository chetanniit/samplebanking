package com.natwest.pbbdhb.broker.portal.uicoord.model.errors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
@JsonInclude(Include.NON_NULL)
@AllArgsConstructor
public class ValidationResponse {

  @JsonProperty("status")
  @Schema(
      description = "Overall HTTP status code of error",
      example = "400"
  )
  int status;

  @JsonProperty("title")
  @Schema(
      description = "Title of error",
      example = "FMA Validation Response"
  )
  String title;

  @JsonProperty("errors")
  @Schema(
      description = "List of errors encountered as part of request, typically supported validation failures"
  )
  List<ValidationResponseDetail> error;

}
