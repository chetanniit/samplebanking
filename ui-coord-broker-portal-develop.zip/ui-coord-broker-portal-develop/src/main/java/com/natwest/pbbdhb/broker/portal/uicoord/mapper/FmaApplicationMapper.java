package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseApplicantDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class FmaApplicationMapper {

  private static final Pattern DECIMAL_PATTERN = Pattern.compile("\\d*\\.\\d");
  @Value("${client.id}")
  private String clientId;
  @Autowired
  private CapieClonerMapper capieClonerMapper;

  public Application toFmaApplication(
      String brand,
      CaseApplicationDto caseApplicationDto,
      List<ApplicantDto> applicantDtoList,
      PropertyDetailsDto propertyDetailsDto,
      ValidatedCaseIncomeDto validatedCaseIncomeDto,
      ValidatedCaseExpenseDto validatedCaseExpenseDto
  ) {
    Application application = Application.builder()
        .clientId(clientId)
        .brand(brand)
        .caseApplication(capieClonerMapper.clone(caseApplicationDto))
        .applicants(capieClonerMapper.clone(applicantDtoList))
        .propertyDetails(capieClonerMapper.clone(propertyDetailsDto))
        .income(capieClonerMapper.clone(validatedCaseIncomeDto))
        .expenditure(capieClonerMapper.clone(validatedCaseExpenseDto))
        .build();
    return afterMappingToFmaApplication(application);
  }

  public Application afterMappingToFmaApplication(Application application) {
    fixDecimalPointOnCurrencyExchangeRate(application);
    fixConsolidationAmount(application);
    return application;
  }

  private void fixDecimalPointOnCurrencyExchangeRate(Application application) {
    // pre conditions:
    // currency exchange rate is set
    // value matches '.1'
    if (application == null || application.getCaseApplication() == null
        || application.getCaseApplication().getCurrencyExchangeRate() == null
        || !DECIMAL_PATTERN.matcher(application.getCaseApplication().getCurrencyExchangeRate().toString()).matches()) {
      return;
    }
    String s = application.getCaseApplication().getCurrencyExchangeRate().toString();
    BigDecimal fixed = new BigDecimal(s.concat("0"));
    application.getCaseApplication().setCurrencyExchangeRate(fixed);
  }

  private void fixConsolidationAmount(Application application) {
    if (application == null || application.getExpenditure() == null
        || application.getExpenditure().getApplicants() == null) {
      return;
    }
    application.getExpenditure().getApplicants().stream()
        .filter(a -> !(null == a.getTransactions() || a.getTransactions().isEmpty()))
        .map(ExpenseApplicantDto::getTransactions).forEach(t -> t.forEach((key, value) -> {
          if (value.getConsolidationAmount() == null
              || value.getConsolidationAmount().doubleValue() <= 0d) {
            value.setConsolidationAmount(null);
          }
        }));
  }
}
