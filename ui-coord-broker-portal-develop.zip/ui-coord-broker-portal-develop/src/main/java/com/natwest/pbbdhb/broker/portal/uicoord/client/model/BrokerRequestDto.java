package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerRequestDto {

    @NotNull
    private String fcaNumber;

    @NotNull
    private String brokerSurname;

    @NotNull
    private String brokerUsername;

    private String brokerForeName;

    private String brokerPostcode;

    @NotNull
    private String brokerEmail;

}
