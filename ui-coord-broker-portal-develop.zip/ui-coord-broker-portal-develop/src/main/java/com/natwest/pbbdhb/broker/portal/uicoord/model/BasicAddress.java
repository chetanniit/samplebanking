package com.natwest.pbbdhb.broker.portal.uicoord.model;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.PostcodeUtil.POSTCODE_REGEX;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ConditionalMandatoryAttribute;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ConditionalRegexValidation;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateAtLeastOneNotNull;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@ValidateAtLeastOneNotNull(fields = "houseNumber,houseName,flatNameOrNumber")
@ConditionalMandatoryAttribute(conditionalMandatoryField = "postcode", conditionField = "country", conditionValue = "GB", message = "postcode must not be blank when country is GB")
@ConditionalRegexValidation(conditionalValidatedField = "postcode", conditionField = "country", conditionValue = "GB", regexp = POSTCODE_REGEX, caseInsensitive = true, message = "Invalid UK postcode")
public class BasicAddress {

    @Size(max = 5)
    private String houseNumber;

    @Size(max = 22)
    private String houseName;

    @Size(max = 10)
    private String flatNameOrNumber;

    @NotBlank
    @Size(max = 30)
    private String street;

    @NotBlank
    @Size(max = 28)
    private String town;

    @Size(max = 18)
    private String county;

    @Size(max = 8)
    private String postcode;

    @NotBlank
    @Size(min = 2, max = 2)
    private String country;
}
