package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerCaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.BrokerCaseValidator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "BrokerCases", description = "Broker cases API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class BrokerCaseController {

    private final BrokerCaseService brokerCaseService;
    private final UserClaimsProvider userClaimsProvider;
    private final BrokerCaseValidator brokerCaseValidator;

    @Operation(
            operationId = "getBrokerCase",
            summary = "Gets a broker's case",
            tags = "BrokerCases"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful retrieval of broker's case", content = @Content(mediaType = "application/json", schema = @Schema(implementation = BrokerCase.class))),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(value = PATH_GET_BROKER_CASE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BrokerCase> getBrokerCase(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                    @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                    @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                    @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                    @PathVariable final String caseId) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to get broker case with caseId {} and brokerUsername {}", caseId,
          brokerUsername);
        BrokerCase brokerCase = this.brokerCaseService.getBrokerCase(brand, caseId);
        log.info("Broker case with caseId {} and brokerUsername {} successfully retrieved", caseId,
            brokerUsername);
        return ResponseEntity.ok(brokerCase);
    }


    @Operation(
            operationId = "saveBrokerCase",
            summary = "Saves a broker's case",
            tags = "BrokerCases"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful save of broker's case", content = @Content(mediaType = "application/json", schema = @Schema(implementation = BrokerCase.class))),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(value = PATH_SAVE_BROKER_CASE, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BrokerCase> saveBrokerCase(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                     @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                     @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                     @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                     @PathVariable final String caseId, @RequestBody  final BrokerCase brokerCase) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to save broker case with caseId {} and brokerUsername {}", caseId,
          brokerUsername);
        brokerCaseValidator.validateBrokerCase(brokerCase);
        BrokerCase brokerCaseResponse = this.brokerCaseService.saveBrokerCase(brand, caseId, brokerCase);
        log.info("Broker case with caseId {} and brokerUsername {} successfully saved", caseId,
            brokerUsername);
        return ResponseEntity.ok(brokerCaseResponse);
    }

    @Operation(
            operationId = "dipResultClear",
            summary = "Clear DIP result for an application",
            tags = "BrokerCases"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful DIP result clear", content = @Content(mediaType = "application/json", schema = @Schema(implementation = BrokerCase.class))),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(value = PATH_DIP_RESULT_CLEAR, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BrokerCase> dipResultClear(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                    @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                    @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                     @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                     @PathVariable final String caseId) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to get Clear DIP result with caseId {} and brokerUsername {}", caseId,
          brokerUsername);
        BrokerCase brokerCase = this.brokerCaseService.dipResultClear(brand, caseId);
        log.info("DIP result with caseId {} and brokerUsername {} successfully cleared", caseId,
          brokerUsername);
        return ResponseEntity.ok(brokerCase);
    }
}
