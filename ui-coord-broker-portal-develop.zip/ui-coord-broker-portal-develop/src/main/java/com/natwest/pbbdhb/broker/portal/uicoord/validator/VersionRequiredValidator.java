package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Versionable;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.VersionRequired;
import org.apache.commons.lang3.ObjectUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class VersionRequiredValidator implements ConstraintValidator<VersionRequired, Versionable> {

    @Override
    public boolean isValid(Versionable value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        return ObjectUtils.allNull(value.getId(), value.getVersion())
                || ObjectUtils.allNotNull(value.getId(), value.getVersion());
    }
}
