package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class EsisCaseDetails {

    @NotNull
    @ValidateEnum(enumClass = ApplicationType.class)
    private String applicationType;

    @NotNull
    @ValidateEnum(enumClass = LoanPurpose.class)
    private String loanPurpose;

    @NotNull
    @ValidateEnum(enumClass = MortgageAdvised.class)
    private String reviewType;

    @NotNull
    private String paymentPathId;

    private BigDecimal brokerFee;

    public enum ApplicationType implements ValuedEnum {
        RESIDENTIAL,
        BUY_TO_LET;

        @Override
        public String value() {
            return name();
        }
    }

    public enum LoanPurpose implements ValuedEnum {
        PURCHASE,
        REMORTGAGE;

        @Override
        public String value() {
            return name();
        }
    }

    // matches ESIS enum: com.rbs.pbbdhb.sales.esis.models.enums.LevelOfService
    // requires mapping to Case API enum: com.natwest.pbbdhb.commondictionaries.enums.cases.MortgageAdvised
    public enum MortgageAdvised implements ValuedEnum {
        ADVISED,
        ADVICE_REJECTED,
        NON_ADVISED,
        EXECUTION_ONLY;

        @Override
        public String value() {
            return name();
        }
    }
}
