package com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentPathDto {

  @JsonProperty("mbs_paymentpathid")
  public Integer paymentPathId;

  @JsonProperty("mbs_paymentpathname")
  public String paymentPathname;

  @JsonProperty("mbs_residentialproductscale")
  public String residentialProductScale;

  @JsonProperty("mbs_btlproductscale")
  public String btlProductScale;
}
