package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductSearchRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductSearchResults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class ProductSearchClient {
    private final String PRODUCT_SEARCH_ERROR = "Product search error";
    private final String productSearchEndpoint;
    private final RestTemplate restTemplate;

    public ProductSearchClient(
            @Value("${msvc.product.search.url}") String productSearchEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.productSearchEndpoint = productSearchEndpoint;
        this.restTemplate = restTemplate;
    }

    public List<ProductDto> search(String brand, ProductSearchRequestDto productSearchRequest) {

        log.info("Calling {} to search for products", productSearchEndpoint);

        try {
            ProductSearchResults results = restTemplate.exchange(
                productSearchEndpoint,
                HttpMethod.POST,
                new HttpEntity<>(productSearchRequest, constructHeadersForJsonRequest(brand)),
                ProductSearchResults.class
            ).getBody();

            if (results == null) {
                  log.warn("Null response body received from {} while searching for products - throwing InternalServerError Exception",
                      productSearchEndpoint);
                  throw HttpServerErrorException.create(
                      HttpStatus.INTERNAL_SERVER_ERROR,
                      HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                      new HttpHeaders(),
                      (PRODUCT_SEARCH_ERROR + ": missing response body")
                          .getBytes(StandardCharsets.UTF_8),
                      StandardCharsets.UTF_8);
            }

            List<String> errors = results.getErrors();
            if (errors != null && errors.size() > 0) {
                  log.warn("Error response received from {} while searching for products: {} - throwing InternalServerError Exception",
                      productSearchEndpoint, errors);
                  throw HttpServerErrorException.create(
                      HttpStatus.INTERNAL_SERVER_ERROR,
                      HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                      new HttpHeaders(),
                      (PRODUCT_SEARCH_ERROR + ": " + String.join("; ", errors))
                          .getBytes(StandardCharsets.UTF_8),
                      StandardCharsets.UTF_8);
            }

            if (results.getProduct() == null) {
              log.warn("No product found: returning an empty list");
              return new ArrayList<>();
            }

            log.debug("Products successfully retrieved");
            return results.getProduct();

        } catch (RestClientException ex) {
            log.warn(
                "A rest client exception occurred while calling {} to search for products: {}",
                productSearchEndpoint, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn(
                "An unexpected exception occurred while calling {} to search for products: {}",
                productSearchEndpoint, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
