package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import static org.apache.tomcat.util.IntrospectionUtils.getProperty;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ConditionalMandatoryAttribute;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

public class ConditionalMandatoryAttributeValidator implements
    ConstraintValidator<ConditionalMandatoryAttribute, Object> {

    private String conditionalMandatoryField;
    private String conditionField;
    private String conditionValue;
    private String defaultErrorMessage;

    @Override
    public void initialize(ConditionalMandatoryAttribute annotation) {
        this.conditionalMandatoryField = annotation.conditionalMandatoryField();
        this.conditionField = annotation.conditionField();
        this.conditionValue = annotation.conditionValue();// "postcode must not be blank when country is GB"
        this.defaultErrorMessage = String.format(ConditionalMandatoryAttribute.DEFAULT_ERROR_MESSAGE_TEMPLATE,
            conditionalMandatoryField, conditionField, conditionValue);
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        context.unwrap(HibernateConstraintValidatorContext.class).addExpressionVariable(ConditionalMandatoryAttribute.DEFAULT_ERROR_MESSAGE_KEY, defaultErrorMessage);
        boolean isValid = objectToValidate == null // ok if obj is null
            || isConditionMet(objectToValidate) // ok if condition doesn't match
            || getProperty(objectToValidate, conditionalMandatoryField) != null; // ok if conditionalMandatory field is not null

        //needed to add the field name to the validation context - ConstraintViolation.class, getPropertyPath()
        if(!isValid) {
            context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate())
                    .addPropertyNode(conditionalMandatoryField)
                    .addConstraintViolation()
                    .disableDefaultConstraintViolation();
        }

        return isValid;
    }

    private boolean isConditionMet(Object objectToValidate) {
      Object property = getProperty(objectToValidate, conditionField);
      return property != null ? !conditionValue.equals(property.toString()) : true;
    }

}
