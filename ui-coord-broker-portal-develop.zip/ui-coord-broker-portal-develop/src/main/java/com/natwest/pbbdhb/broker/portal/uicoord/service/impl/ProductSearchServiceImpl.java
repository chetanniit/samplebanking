package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.ProductSearchClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ProductMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ProductSearchRequestMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Product;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ProductSearchService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductSearchServiceImpl implements ProductSearchService {

    private final ProductSearchClient productSearchClient;
    private final ProductMapper productMapper;
    private final ProductSearchRequestMapper productSearchRequestMapper;

    @Value("${fma.constant-product-search-date}")
    String constantProductSearchDate;

    @Override
    public List<Product> search(String brand, ProductSearchRequest productSearchRequest) {

        // look at property to override productSearchDate which alters productSelectionDate in submitted FMA
        if (StringUtils.hasText(constantProductSearchDate) && !constantProductSearchDate.equals("${fma.constant-product-search-date}")) {
            productSearchRequest.setProductSearchDate(constantProductSearchDate);
        }

        log.debug("Calling productSearchClient to search for product");
        List<ProductDto> results = productSearchClient.search(brand, productSearchRequestMapper.toProductSearchRequestDto(productSearchRequest));
        log.debug("productSearchClient successfully called to search for product");
        return results.stream().map(productMapper::toProduct).collect(Collectors.toList());
    }

}
