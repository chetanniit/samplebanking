package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductValidationMsvcResponse {

  private String productCode;
  private Boolean validProduct;
  private String jurisdiction;
  private String message;

}
