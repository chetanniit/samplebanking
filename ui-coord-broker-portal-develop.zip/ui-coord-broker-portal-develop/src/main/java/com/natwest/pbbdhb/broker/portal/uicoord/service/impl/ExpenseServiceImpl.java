package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.ExpenseClient;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.CaseExpenseMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseExpense;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ExpenseService;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExpenseServiceImpl implements ExpenseService {

    private static final String DIP = "DIP";
    private final ExpenseClient expenseClient;
    private final CaseExpenseMapper expenseMapper;

    @Override
    public CaseExpense saveExpense(String brand, String caseId, CaseExpense expense) {
        // TODO: select stage based on field in BrokerCase (or use a separate endpoint)
        String stage = DIP;
        CaseExpenseDto expenseDtoToSend = this.expenseMapper.toCaseExpenseDto(stage, expense);
        String version = expense.getVersion();
        log.debug("Calling expenseClient to save expense with version {} and caseId {}", version, caseId);
        ValidatedCaseExpenseDto expenseDtoResponse = this.expenseClient.saveExpense(brand, caseId, expenseDtoToSend);
        log.debug("expenseClient successfully called to save expense with version {} and caseId {}", version, caseId);
        return this.expenseMapper.toCaseExpense(expenseDtoResponse);
    }

    @Override
    public CaseExpense getExpense(String brand, String caseId) {
        ValidatedCaseExpenseDto expenseDtoResponse = this.expenseClient.getExpense(brand, caseId);
        return this.expenseMapper.toCaseExpense(expenseDtoResponse);
    }
}
