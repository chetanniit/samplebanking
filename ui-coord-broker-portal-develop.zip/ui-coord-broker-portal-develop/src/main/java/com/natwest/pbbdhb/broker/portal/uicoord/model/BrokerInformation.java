package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;
import org.springframework.util.Base64Utils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;

import static java.util.Objects.nonNull;

@Data
public class BrokerInformation {
    private String title;
    private String forename;
    private String surname;
    private String firmName;
    private String poBoxNumber;
    private String houseNameNumber;
    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private String city;
    private String county;
    private String postCode;
    private String country;
    private String emailAddress;
    private String fcaReference;
    private String networkInfo;
    private String brokerPhoneNumber;
    private String procurementFee;

    private Document createDocument() throws ParserConfigurationException, SAXException {
        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        Schema schema = schemaFactory.newSchema();

        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        builderFactory.setSchema(schema);
        DocumentBuilder documentBuilder = builderFactory.newDocumentBuilder();
        return documentBuilder.newDocument();
    }

    private Element getRootElement(Document document) {
        Element element = document.createElement("ProductSwitch");
        element.setAttribute("xmlns", "http://www.focus-solutions.co.uk/focus360/1.0");
        return element;
    }

    private ByteArrayOutputStream transformIntoXml(Document document) throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
        transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

        DOMSource domSource = new DOMSource(document);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        StreamResult streamResult = new StreamResult(outputStream);
        transformerFactory.newTransformer().transform(domSource, streamResult);
        return outputStream;
    }

    public String generateEncodedXml()
        throws TransformerException, ParserConfigurationException, SAXException {
        Document document = createDocument();
        Element rootElement = getRootElement(document);
        document.appendChild(rootElement);

        Element nameRootElement = document.createElement("BrokerName");
        rootElement.appendChild(nameRootElement);

        createXmlElement(document, nameRootElement, "Title", title);
        createXmlElement(document, nameRootElement, "Forename", forename);
        createXmlElement(document, nameRootElement, "Surname", surname);


        createXmlElement(document, rootElement, "FirmName", firmName);

        Element addressElement = document.createElement("Address");
        rootElement.appendChild(addressElement);

        createXmlElement(document, addressElement, "POBoxNumber", poBoxNumber);
        createXmlElement(document, addressElement, "HouseNameNumber", houseNameNumber);
        createXmlElement(document, addressElement, "AddressLine1", addressLine1);
        createXmlElement(document, addressElement, "AddressLine2", addressLine2);
        createXmlElement(document, addressElement, "AddressLine3", addressLine3);
        createXmlElement(document, addressElement, "City", city);
        createXmlElement(document, addressElement, "County", county);
        createXmlElement(document, addressElement, "Postcode", postCode);
        createXmlElement(document, addressElement, "Country", country);

        createXmlElement(document, rootElement, "EmailAddress", emailAddress);
        createXmlElement(document, rootElement, "FCAReference", fcaReference);
        createXmlElement(document, rootElement, "NetworkInfo", networkInfo);
        createXmlElement(document, rootElement, "BrokerPhoneNumber", brokerPhoneNumber);
        createXmlElement(document, rootElement, "ProcFee", procurementFee);

        ByteArrayOutputStream outputStream = transformIntoXml(document);
        return Base64Utils.encodeToString(outputStream.toByteArray());
    }

    private void createXmlElement(Document document, Element addressElement, String xmlTag, String xmlValue) {
        Element documentElement = document.createElement(xmlTag);
        if (nonNull(xmlValue)) {
            documentElement.appendChild(document.createTextNode(xmlValue));
        }
        addressElement.appendChild(documentElement);
    }
}