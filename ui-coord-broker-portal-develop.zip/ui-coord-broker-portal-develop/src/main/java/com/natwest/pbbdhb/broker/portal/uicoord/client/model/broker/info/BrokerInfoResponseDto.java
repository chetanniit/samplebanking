package com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrokerInfoResponseDto {

    @JsonProperty("mbs_message")
    public String message;

    @JsonProperty("mbs_paymentPaths")
    public List<PaymentPathDto> paymentPaths;

    @JsonProperty("mbs_broker")
    public BrokerDetailsDto broker;

    @JsonProperty("mbs_brokerUpdateRequest")
    public BrokerUpdateRequestDto brokerUpdateRequest;

    @JsonProperty("mbs_firm")
    public FirmDto firm;

    @JsonProperty("mbs_tradingName")
    public TradingNameDto tradingName;
}
