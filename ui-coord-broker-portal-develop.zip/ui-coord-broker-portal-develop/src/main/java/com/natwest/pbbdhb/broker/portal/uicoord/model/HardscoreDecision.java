package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import java.util.List;

@Data
public class HardscoreDecision {

    private String decisionUniqueId;

    private String decision;

    private String podDecision;

    private List<Policy> policyMessages;

    private AdditionalDetails additionalDetails;
}
