package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDetails {
    @NotBlank
    private String productCode;

    @ValidateEnum(enumClass = ProductType.class)
    @NotBlank
    private String productType;

    @ValidateEnum(enumClass = ProductTerm.class)
    @NotBlank
    private String productTerm;

    private BigDecimal cashBackValue;

    private Boolean isPortingProduct;

    private Boolean isFreeLegal;

    private String portingText;

    // TODO: Move this to CaseApplication
    private Boolean hasAdditionalBorrowing;

    private Double initialInterestRate;

    @Min(value = 0)
    @Max(value = 100)
    @NotNull
    private Long ltv;

    @ValidateEnum(enumClass = MortgageType.class)
    @NotBlank
    private String mortgageType;

    @DateFormat(pattern = "yyyy-MM-dd")
    @NotBlank
    private String productSelectedDate;

    private Double svr;

    private Double baseRate;

    private String productEndDate;

    @Valid
    private List<Fee> fees;

    @Valid
    private List<ErcItem> ercItems;

    private String productName;

    public enum ProductType implements ValuedEnum {
        FIXED,
        TRACKER;

        @Override
        public String value() {
            return name();
        }
    }

    public enum ProductTerm implements ValuedEnum {
        ONE_YEAR,
        TWO_YEAR,
        THREE_YEAR,
        FOUR_YEAR,
        FIVE_YEAR,
        SIX_YEAR,
        SEVEN_YEAR,
        EIGHT_YEAR,
        NINE_YEAR,
        TEN_YEAR;

      @Override
        public String value() {
            return name();
        }
    }

    public enum MortgageType implements ValuedEnum {
        FIRST_TIME_BUYER,
        PURCHASE,
        PURCHASE_SHARED_EQUITY,
        PURCHASE_H2B_SHARED_EQUITY,
        REMORTGAGE,
        REMORTGAGE_H2B_SHARED_EQUITY,
        ADBO;

        @Override
        public String value() {
            return name();
        }
    }
}
