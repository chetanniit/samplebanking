package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Data
public class EstateAgent {


    @NotBlank
    private String agencyName;

    @Valid
    @NotNull
    private BasicAddress address;

    @NotBlank
    @Pattern(regexp = "^0\\d{10,14}$", flags=Pattern.Flag.CASE_INSENSITIVE, message = "Badly formed phone number")
    private String telephoneNumber;
}
