package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class CaseApplicationDip {

    private String caseId;

    private String version;

    @NotNull
    private String currentRoute;

    @ValidateEnum(enumClass = ApplicationType.class)
    private String applicationType;

    @ValidateEnum(enumClass = CaseApplication.LoanPurpose.class)
    private String loanPurpose;

    private Boolean firstTimeBuyer;

    private Boolean usingSpecialistScheme;

    @ValidateEnum(enumClass = CaseApplication.SchemeType.class)
    private String schemeType;

    private Boolean mainResidence;

    @Valid
    private MortgageDip mortgage;

    private Boolean hasDependants;

    @Min(value = 0)
    @Max(value = 99)
    private Integer numberOfDependantsOver18;

    @Min(value = 0)
    @Max(value = 99)
    private Integer numberOfDependantsUnder18;

    @ValidateEnum(enumClass = CaseApplication.TranscriptValuer.class)
    private String transcriptValuer;

    private String transcriptValuationDate;

    @Valid
    private ServiceLevelDip serviceLevel;

    @Valid
    private BrokerDip broker;

    private String mortgageReferenceNumber;

    private String mortgageTempReferenceNumber;

    private String mortgageApplSeq;

    private List<String> repaymentStrategyAddresses;

    // When true, locks 'About the Case' fields section
    // Stored in journey data because we clear DIP values in 'Return to AIP' feature
    private Boolean hasCompletedDip;

    // boolean required to handle ground rent/service charge checks
    private Boolean leaseholdOwnershipTerm;

    private Boolean isProductSelectedAtDip;

    // holds dip epc rating so the ui makes the correct product search call for green products
    private Boolean epcRatingAOrBDip;

    private Integer brokerJourneyVersion;

    // will contain product details at DIP if it's a BTL case
    // in that case, isProductSelectedAtDip will be true
    // productDetails is manually deleted on other cases
    private ProductDetails productDetails;
}
