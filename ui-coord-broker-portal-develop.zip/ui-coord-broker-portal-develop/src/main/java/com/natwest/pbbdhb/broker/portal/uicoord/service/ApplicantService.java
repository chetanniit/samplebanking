package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;

import java.util.List;
import java.util.Map;

public interface ApplicantService {

    List<Applicant> saveApplicants(String brand, String caseId, List<Applicant> applicants, Map<String, String> workStatusMap);

    List<Applicant> getApplicants(String brand, String caseId);
}
