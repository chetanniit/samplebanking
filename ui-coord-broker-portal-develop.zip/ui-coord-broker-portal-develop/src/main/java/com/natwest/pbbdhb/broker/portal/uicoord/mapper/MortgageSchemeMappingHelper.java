package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.SchemeType.OTHER;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.SchemeType.SHARED_EQUITY;

@Slf4j
public final class MortgageSchemeMappingHelper {
    public static final String CAPIE_HELP_TO_BUY = "HELP_TO_BUY";
    public static final String CAPIE_OTHER = "OTHER";
    public static final String CAPIE_OTHER_NAME = "OTHER";

    private MortgageSchemeMappingHelper() {}


    public static String getSchemeType(CaseApplicationDto caseApplicationDto) {
        if (caseApplicationDto == null) {
            return null;
        }

        boolean rightToBuy = caseApplicationDto.getMortgage() != null && caseApplicationDto.getMortgage().getRightToBuy() != null && caseApplicationDto.getMortgage().getRightToBuy();
        boolean govtSharedEquityScheme = caseApplicationDto.getGovtSharedEquityScheme() != null && caseApplicationDto.getGovtSharedEquityScheme();
        String schemeType = caseApplicationDto.getSchemeType();
        String schemeName = caseApplicationDto.getSchemeName();

        if (!rightToBuy && !govtSharedEquityScheme && schemeType == null && schemeName == null) {
            return null;
        } else if (rightToBuy && !govtSharedEquityScheme && schemeType == null && schemeName == null) {
            return CaseApplication.SchemeType.RIGHT_TO_BUY.value();
        } else if (!rightToBuy && govtSharedEquityScheme && CAPIE_HELP_TO_BUY.equals(schemeType) && schemeName == null) {
            return CaseApplication.SchemeType.HELP_TO_BUY_SHARED_EQUITY.value();
        } else if (!rightToBuy && govtSharedEquityScheme && CAPIE_OTHER.equals(schemeType) && SHARED_EQUITY.value().equals(schemeName)) {
            return SHARED_EQUITY.value();
        } else if (!rightToBuy && !govtSharedEquityScheme && CAPIE_OTHER.equals(schemeType) && CAPIE_OTHER_NAME.equals(schemeName)) {
            return CaseApplication.SchemeType.OTHER.value();
        } else {
            log.warn("Unexpected mortgage scheme data: rightToBuy = " + rightToBuy +
                    "; govtSharedEquityScheme = " + govtSharedEquityScheme +
                    "; schemeType = " + schemeType +
                    "; schemeName = " + schemeName +
                    ". Ignoring CAPIE mortgage scheme data");

            return null;
        }
    }

    public static CapieMortgageScheme getCapieMortgageScheme(CaseApplication caseApplication) {
        if (caseApplication == null) {
            return null;
        }

        if (caseApplication.getUsingSpecialistScheme() == null) {
            return null;
        }

        String schemeType = caseApplication.getSchemeType();
        if (schemeType == null) {
            return CapieMortgageScheme.builder()
                    .rightToBuy(false)
                    .govtSharedEquityScheme(false)
                    .schemeType(null)
                    .schemeName(null)
                    .build();
        }

        if (CaseApplication.SchemeType.RIGHT_TO_BUY.value().equals(schemeType)) {
            return CapieMortgageScheme.builder()
                    .rightToBuy(true)
                    .govtSharedEquityScheme(false)
                    .schemeType(null)
                    .schemeName(null)
                    .build();
        } else if (CaseApplication.SchemeType.HELP_TO_BUY_SHARED_EQUITY.value().equals(schemeType)) {
            return CapieMortgageScheme.builder()
                    .rightToBuy(false)
                    .govtSharedEquityScheme(true)
                    .schemeType(CAPIE_HELP_TO_BUY)
                    .schemeName(null)
                    .build();
        } else if (SHARED_EQUITY.value().equals(schemeType)) {
            return CapieMortgageScheme.builder()
                    .rightToBuy(false)
                    .govtSharedEquityScheme(true)
                    .schemeType(OTHER.value())
                    .schemeName(SHARED_EQUITY.name())
                    .build();
        } else if (CaseApplication.SchemeType.OTHER.value().equals(schemeType)) {
            return CapieMortgageScheme.builder()
                    .rightToBuy(false)
                    .govtSharedEquityScheme(false)
                    .schemeType(CAPIE_OTHER)
                    .schemeName(CAPIE_OTHER_NAME)
                    .build();
        } else {
            throw new IllegalArgumentException("Unrecognised mortgage scheme type: '" + schemeType + "'");
        }
    }

    @Data
    @Builder
    public static class CapieMortgageScheme {
        private Boolean rightToBuy;
        private Boolean govtSharedEquityScheme;
        private String schemeType;
        private String schemeName;
    }
}
