package com.natwest.pbbdhb.broker.portal.uicoord.model.errors;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

@Validated
@Value
@Builder
@AllArgsConstructor
public class ValidationResponseDetail {

  @JsonProperty("status")
  @Schema(
      description = "HTTP status code of individual error where applicable",
      example = "400"
  )
  int status;

  @JsonProperty("code")
  @Schema(
      description = "Code representing the error",
      required = true,
      example = "INVALID_PAYMENT_PATH"
  )
  String code;

  @JsonProperty("message")
  @Schema(
      description = "message",
      example = "message valid for external display"
  )
  String message;

}

