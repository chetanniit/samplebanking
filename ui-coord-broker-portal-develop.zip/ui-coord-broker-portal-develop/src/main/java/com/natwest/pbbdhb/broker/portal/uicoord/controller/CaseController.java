package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.CaseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "Cases")
@Validated
@Slf4j
@RequiredArgsConstructor
public class CaseController {

    private final CaseService caseService;
    private final UserClaimsProvider userClaimsProvider;
    private final BrokerInfoService brokerInfoService;

    @Operation(
            operationId = "getCaseId",
            summary = "Return unique case ID",
            tags = "Cases"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful return of a case ID"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(value = PATH_GET_CASE_ID, produces = MediaType.TEXT_PLAIN_VALUE)
    public String getCaseId(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                            @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                            @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand) {
        log.info("Request to return unique case ID");

        return this.caseService.generateCaseId(brand);
    }
    /**
     * @deprecated (DEPRECATED: Only used for some legacy tests)
     */
    @Deprecated
    @Operation(
            operationId = "saveCase",
            summary = "Saves a case",
            tags = "Cases"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful save of case application", content = @Content(mediaType = "application/json", schema = @Schema(implementation = CaseApplication.class))),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(value = PATH_SAVE_CASE, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CaseApplication> saveCase(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                    @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                    @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                    @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                    @PathVariable final String caseId, @RequestBody @Valid final CaseApplication caseApplication) {
        String username = userClaimsProvider.getBrokerUsername();
        BrokerInfo broker = brokerInfoService.getBroker(username);
        log.info("Request to save case with caseId={}, broker={}", caseId, broker);

        boolean isNewCase = StringUtils.isBlank(caseApplication.getVersion());
        return ResponseEntity.ok(this.caseService.saveCase(brand, caseId, caseApplication, broker, isNewCase, false));
    }
}
