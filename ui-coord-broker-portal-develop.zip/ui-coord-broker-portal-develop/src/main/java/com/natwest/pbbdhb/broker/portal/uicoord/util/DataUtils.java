package com.natwest.pbbdhb.broker.portal.uicoord.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.util.Objects.isNull;

public interface DataUtils {
    Logger log = LoggerFactory.getLogger(DataUtils.class);

    static <T> T toDataObject(Map<String, Object> source, Class<T> type) {
        if(isNull(source) || source.isEmpty()) {
            return null;
        }

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.convertValue(source, type);
        } catch (Exception ex) {
            log.warn("Unable to parse object!");
            return null;
        }
    }
}
