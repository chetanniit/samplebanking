package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import org.mapstruct.Mapper;

@Mapper
public abstract class ErcItemMapper {
    public abstract com.natwest.pbbdhb.broker.portal.uicoord.model.ErcItem toErcItem(com.rbs.pbbdhb.sales.esis.models.ErcItem ercItem);
}