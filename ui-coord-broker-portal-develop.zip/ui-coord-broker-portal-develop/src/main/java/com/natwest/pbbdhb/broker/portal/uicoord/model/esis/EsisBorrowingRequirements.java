package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class EsisBorrowingRequirements {

    private BigDecimal purchasePrice;

    private BigDecimal propertyValue;

    @NotNull
    private BigDecimal mortgageAmount;

    private BigDecimal deposit;

    @Min(0)
    @Max(100)
    private BigDecimal ltv;

    private Boolean addFeeToLoan;

}
