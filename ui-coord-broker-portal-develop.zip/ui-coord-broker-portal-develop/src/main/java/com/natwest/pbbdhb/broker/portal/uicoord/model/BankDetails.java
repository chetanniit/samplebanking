package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat.DateConstraint;
import lombok.Data;

import jakarta.validation.constraints.*;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_5_OR_6_DIGITS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MUST_BE_8_DIGITS;

@Data
public class BankDetails {

    @NotNull
    @DateFormat(pattern = "yyyy-MM-dd" , constraint = DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String dateOpened;

    @NotBlank
    private String bankName;

    @NotBlank
    private String accountName;

    @NotNull
    private Boolean debitCard;

    @NotNull
    @Pattern(regexp = "^[0-9]{5,6}$", message = MUST_BE_5_OR_6_DIGITS)
    private String sortCode;

    @NotNull
    @Pattern(regexp = "^[0-9]{8}$", message = MUST_BE_8_DIGITS)
    private String accountNumber;

}
