package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.CurrencyRateDecimalValidator;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Target({FIELD,METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CurrencyRateDecimalValidator.class)
public @interface ValidDecimal {

  String message() default "must be a value between 0.00 and 99999999.99 with up to 2 decimal places";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
