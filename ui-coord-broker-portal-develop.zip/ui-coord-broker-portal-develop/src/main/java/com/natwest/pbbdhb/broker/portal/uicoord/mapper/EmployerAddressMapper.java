package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BasicAddress;
import com.natwest.pbbdhb.income.expense.model.income.dto.AddressDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface EmployerAddressMapper {

    @Mapping(target = "flatNameOrNumber", source = "flat")
    @Mapping(target = "country", source = "countryIsoCode")
    BasicAddress toBasicAddress(AddressDto basicAddressDto);

    @Mapping(target = "flat", source = "flatNameOrNumber")
    @Mapping(target = "countryIsoCode", source = "country")
    @Mapping(target = "district", ignore = true)    // not used in the front-end for now
    AddressDto toBasicAddressDto(BasicAddress basicAddress);
}
