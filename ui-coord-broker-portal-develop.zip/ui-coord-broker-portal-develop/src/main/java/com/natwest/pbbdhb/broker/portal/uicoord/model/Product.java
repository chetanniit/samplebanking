package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class Product {

    private String productClass;

    private String productCode;

    private String range;

    private String productSearchDate;

    private String productType;

    private String productTerm;

    private BigDecimal mortgageAmount;

    private Double initialInterestRate;

    private Double ltv;

    private Boolean erc;

    private BigDecimal productFee;

    private BigDecimal chapsFee;

    private BigDecimal cashBackValue;

    private BigDecimal initialMonthlyPayment;

    private BigDecimal productTermCost;

    private BigDecimal mortgageTermCost;

    private String mortgageTerm;

    private String mortgageType;

    private BigDecimal feeWrappedInitialMonthlyPayment;

    private BigDecimal feeWrappedProductTermCost;

    private BigDecimal feeWrappedMortgageTermCost;

    private BigDecimal standardValuationFee;

    private String valuationFeeMessage;

    private Double svr;

    private Double baseRate;

    private Integer sequence;

    private String productStartDate;

    private String productEndDate;

    private String productExpiryDate;

    private List<ProductFee> fees;

    private String waysToApply;

    private Boolean freeLegal;

    private String productName;

    private String overPayment;

    private List<String> eligibility;

    private Double trackerMarginPercent;

    private Boolean switchToFixed;

    private String switchToFixedText;

    // full detail from product service
    private List<EarlyRepaymentCharge> earlyRepaymentCharges;

    // derived version for use with CAPIE and FMA
    private List<ErcItem> ercItems;

    private Integer mortgageTermYears;

    private Integer mortgageTermMonths;

    private Boolean freeValuation;

    private Boolean sharedEquity;

    private Boolean greenMortgage;
}
