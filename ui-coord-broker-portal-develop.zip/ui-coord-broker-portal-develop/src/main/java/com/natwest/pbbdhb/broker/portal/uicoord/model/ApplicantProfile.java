package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.SIZE_AT_LEAST_ONE_MSG;

/**
 * Deprecated: only used in deprecated ApplicantController class.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Deprecated
public class ApplicantProfile {

    @NotNull
    @Size(min = 1, message = SIZE_AT_LEAST_ONE_MSG)
    private List<@Valid Applicant> applicants;
}
