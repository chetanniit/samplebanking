package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.PropertyType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


@Data
public class PropertyDetails {

    private String version;

    private Boolean newBuild;

    @ValidateEnum(enumClass = PropertyType.class)
    private String type;

    // TODO: comments about enforcing validation at FMA stage
    @Valid
    private BasicAddress address;

    // TODO: comments about enforcing validation at FMA stage
    @Pattern(regexp = "^[0-9]{1,2}$", message = "Badly formed number of bedrooms")
    private String numberBedrooms;

    // TODO: comments about enforcing validation at FMA stage
    @ValidateEnum(enumClass = Tenure.class)
    private String propertyTenure;

    @Pattern(regexp = "^[0-9]{1,4}$", message = "Badly formed remaining leasehold")
    private String remainingLeasehold;

    // An A or B rating is needed to qualify for 'Green Mortgage' Products
    // True maps to 'A', which is just used for the above, false maps to 'NO_VALID_EPC'
    // The actual value is set by underwriters later
    private boolean epcRatingAorB;

    // TODO: comments about enforcing validation at FMA stage
    @DateFormat(pattern = "yyyy-MM-dd")
    private String whenBuilt;

    private String refurbishedDate;

    private boolean nhbcCertificate;

    private Integer builderIncentive;

    @Size(max = 50)
    private String propertyBuilder;

    @Size(max = 50)
    private String propertyDevelopment;

    private boolean homeReport;

    private Valuation valuation;

    public enum Tenure implements ValuedEnum {
        FREEHOLD,
        LEASEHOLD,
        FEUHOLD;

        @Override
        public String value() {
            return name();
        }
    }
}
