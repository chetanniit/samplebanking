package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.MarketingPreferencesDto;
import com.natwest.pbbdhb.applicant.dto.MortgageCreditHistoryDto;
import com.natwest.pbbdhb.applicant.dto.PersonAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ApplicantJourneyDataDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import java.util.Collections;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CreditHistory;
import com.natwest.pbbdhb.broker.portal.uicoord.model.MarketingPreferences;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DataUtils.toDataObject;
import static java.util.Objects.isNull;

@Mapper(uses = {NapoliPersonalDetailsMapper.class, PersonalAddressMapper.class}, builder = @Builder(disableBuilder = true))
public interface NapoliApplicantMapper {

    @Mapping(target = "bankWithNatWest", ignore = true)
    Applicant toApplicant(ApplicantDto applicantDto);

    @Mapping(target = "journeyData", source = "applicant", qualifiedByName = "toJourneyDataMap")
    @Mapping(target = "workStatus", source = "workStatus")
    @Mapping(target = "createdDate", ignore = true)
    @Mapping(target = "cin", ignore = true)
    @Mapping(target = "multiCins", ignore = true)
    @Mapping(target = "gmsCustomerId", ignore = true)
    @Mapping(target = "applicationStatus", ignore = true)
    @Mapping(target = "kycChannel", constant = "TPI")
    @Mapping(target = "customerType", ignore = true)
    @Mapping(target = "proofOfIds", ignore = true)
    @Mapping(target = "marketingPreferences", ignore = true)
    @Mapping(target = "giveYourAgreement", ignore = true)
    @Mapping(target = "newToBank", ignore = true)
    @Mapping(target = "modifiedDate", ignore = true)
    @Mapping(target = "unstructuredCurrentAddress", ignore = true)
    @Mapping(target = "route", ignore = true)
    @Mapping(target = "additionalBorrowing", ignore = true)
    @Mapping(target = "consentToMiau", ignore = true)
    @Mapping(target = "consentToDebtConsolidation", ignore = true)
    @Mapping(target = "consentToDebtConsolidationAcceptedAt", ignore = true)
    @Mapping(target = "consentToJointPartyAcceptedAt", ignore = true)
    @Mapping(target = "giveYourAgreementAt", ignore = true)
    @Mapping(target = "consentToMortagageIllustration", ignore = true)
    @Mapping(target = "consentToYmr", ignore = true)
    @Mapping(target = "consentToJointParty", ignore = true)
    @Mapping(target = "mainBankDetails.consentToDirectDebit", ignore = true)
    @Mapping(target = "mainBankDetails.consentToDirectDebitAt", ignore = true)
    ApplicantDto toApplicantDto(String caseId, String workStatus, Applicant applicant);

    @Mapping(target = "bankruptDetails", ignore = true)
    @Mapping(target = "courtProceedingDetails", ignore = true)
    @Mapping(target = "bankruptcyDate", ignore = true)
    MortgageCreditHistoryDto toMortgageCreditHistoryDtoDto(CreditHistory creditHistory);

    @Named("toJourneyDataMap")
    default Map<String, Object> toJourneyDataMap(Applicant applicant) {
        if (isNull(applicant)) {
            return Collections.emptyMap();
        }
        Map<String, Object> journeyData = new HashMap<>();
        journeyData.put(APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST, applicant.getBankWithNatWest());

        return journeyData;
    }

  default void toMarketingPreferences(Applicant applicant, ApplicantDto applicantDto) {
    MarketingPreferencesDto marketingPreferencesDto = new MarketingPreferencesDto();
    MarketingPreferences marketingPreferences = applicant.getMarketingPreferences();
    marketingPreferencesDto.setEmail(marketingPreferences != null && marketingPreferences.getEmail() != null && marketingPreferences.getEmail());
    marketingPreferencesDto.setPost(marketingPreferences != null && marketingPreferences.getPost() != null && marketingPreferences.getPost());
    marketingPreferencesDto.setTelephone(marketingPreferences != null && marketingPreferences.getTelephone() != null && marketingPreferences.getTelephone());
    applicantDto.setMarketingPreferences(marketingPreferencesDto);
  }

    @AfterMapping
    default void afterMappingToApplicantDto(Applicant applicant, @MappingTarget ApplicantDto applicantDto) {
        if (applicantDto.getPersonalDetails() != null) {
            applicantDto.getPersonalDetails().setMailIndicator(false);
        }

        // Fill in extra address fields
        List<PersonAddressDto> addresses = applicantDto.getAddresses();

        if (addresses == null) {
            return;
        }

        // first entry is the current address
        if (!addresses.isEmpty()) {
            addresses.get(0).setIsCurrentAddress(true);
        }

        // go through the addresses and make the end dates the same as the previous entry's start date
        for (int i = addresses.size() - 1; i >= 1; i--) {
            addresses.get(i).setEndMonth(addresses.get(i-1).getStartMonth());
            addresses.get(i).setEndYear(addresses.get(i-1).getStartYear());
            addresses.get(i).setIsCurrentAddress(false);
        }

        Boolean bankWithNatWest = applicant.getBankWithNatWest();
        applicantDto.setNewToBank(bankWithNatWest == null || !bankWithNatWest);
        if(applicantDto.getNewToBank()) {
          toMarketingPreferences(applicant, applicantDto);
        } else {
          applicantDto.setMarketingPreferences(null);
        }
    }

    @AfterMapping
    default void afterMappingToApplicant(ApplicantDto applicantDto, @MappingTarget Applicant applicant) {
        ApplicantJourneyDataDto applicantJourneyDataDto = toDataObject(applicantDto.getJourneyData(), ApplicantJourneyDataDto.class);

        //If newToBank is null (for old applications, before we mapped newToBank = !bankWithNatWest)
        //we use applicantJourneyDataDto to set the value of bankWithNatWest, otherwise we use !newToBank
        applicant.setBankWithNatWest(
            Optional.ofNullable(applicantDto.getNewToBank())
              .map(v -> !v)
              .orElse(
                  Optional.ofNullable(applicantJourneyDataDto)
                  .map(ApplicantJourneyDataDto::getBankWithNatWest)
                      .orElse(false))
        );

        if(applicant.getBankWithNatWest()) {
          applicant.setMarketingPreferences(null);
        } else {
          if(applicantDto.getMarketingPreferences() == null) {
            MarketingPreferences marketingPreferences = new MarketingPreferences();
            marketingPreferences.setTelephone(false);
            marketingPreferences.setEmail(false);
            marketingPreferences.setPost(false);
            applicant.setMarketingPreferences(marketingPreferences);
          }
        }
    }
}
