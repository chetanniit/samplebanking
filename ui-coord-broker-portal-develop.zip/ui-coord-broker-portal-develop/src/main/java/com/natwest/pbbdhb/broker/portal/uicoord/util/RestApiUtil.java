package com.natwest.pbbdhb.broker.portal.uicoord.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_HEADER;

public class RestApiUtil {

    private static final ObjectMapper mapper = new ObjectMapper();

    public static HttpHeaders constructHeaders(final String brand) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add(BRAND_HEADER, brand);
        return headers;
    }

    public static HttpHeaders constructHeadersWithClientId(final String brand, final String clientId) {
        final HttpHeaders headers = constructHeaders(brand);
        headers.add(CLIENT_ID_HEADER, clientId);
        return headers;
    }

    public static HttpHeaders constructHeadersForJsonRequest(final String brand) {
        final HttpHeaders headers = constructHeaders(brand);
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

    public static HttpHeaders constructHeadersForApplicationFormUrlEncodedRequest() {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return headers;
    }

    /**
     * Emit a json representation of an object for logging.
     * Returns an error message (without throwing an exception) if the conversion to JSON fails.
     *
     * @param object The object to convert to JSON
     * @return as string containing the object data in JSON format
     */
    public static String diagnosticJson(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (JsonProcessingException ex) {
            return "WRITE AS JSON FAILED (" + ex.getMessage() + ")";
        }
    }

    private RestApiUtil() {
    }
}
