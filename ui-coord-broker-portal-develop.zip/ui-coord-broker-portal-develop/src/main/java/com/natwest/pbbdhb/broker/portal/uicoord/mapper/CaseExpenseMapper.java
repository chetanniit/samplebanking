package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseExpense;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ExpenseApplicant;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseApplicantDto;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(uses = {ExpenseTransactionMapper.class})
public interface CaseExpenseMapper {
    CaseExpense toCaseExpense(ValidatedCaseExpenseDto incomeDto);

    CaseExpenseDto toCaseExpenseDto(String stage, CaseExpense expense);

    @Mapping(target = "cin", ignore = true)
    @Mapping(target = "dependentCostsExcludeReason", ignore = true)
    @Mapping(target = "excludedTransactionsReason", ignore = true)
    @Mapping(target = "sourceOfExpenditureVerification", ignore = true)
    @Mapping(target = "mimoTransactions", ignore = true)
    ExpenseApplicantDto toCaseExpenseApplicantDto(ExpenseApplicant applicant);

    @Mapping(target = "stage", source = "stage")
    @Mapping(target = "updatedDatetime", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "validationErrors", ignore = true)
    @Mapping(target = "exceptionReferences", ignore = true)
    ValidatedCaseExpenseDto caseExpenseToValidatedExpenseIncomeDto(CaseExpenseDto caseExpenseDto);
}
