package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.FmaErrorResultMapper;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.Error;
import com.natwest.pbbdhb.service.IntegrationService;
import java.util.List;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class FmaClient {

  private final IntegrationService integrationService;
  private final FmaErrorResultMapper errorMapper;

  public FmaClient(IntegrationService integrationService, FmaErrorResultMapper errorMapper) {
    this.integrationService = integrationService;
    this.errorMapper = errorMapper;
  }

  public FullMortgageApplicationExtendedResponse submitFma(Application application)
      throws FmaIntegrationException {
    String caseId = application.getCaseApplication().getCaseId();
    try {

      log.info("Calling integrationService to submit FMA for caseId {}", caseId);

      FullMortgageApplicationExtendedResponse fmaResponse = integrationService.getFMA(application);
      log.info("integrationService successfully called to submit FMA for caseId {}. Processing the result", caseId);
      String status = fmaResponse.getResponseStatus() == null ? null
          : fmaResponse.getResponseStatus().getStatus();

      if ("200".equals(status) || "201".equals(status) || "202".equals(status)) {
        log.info("FMA successfully submitted for caseId {}: response status {}", caseId, status);
        return fmaResponse;
      }

      ErrorDto processedError = processErrors(fmaResponse, status, caseId);

      if (status != null && status.startsWith("4")) {
        log.warn(
            "Error response with status {} returned from integrationService while submitting FMA for caseId {} - throwing FmaValidationException with errorCode {}",
            status, caseId, processedError.errorCode);
        throw new FmaValidationException(processedError.errorCode, processedError.originalErrorMessage);
      }

      log.error(
          "Error response with status {} returned from integrationService while submitting FMA for caseId {} - throwing FmaIntegrationException with errorMessage: {}",
          status, caseId, processedError.originalErrorMessage);
      throw new FmaIntegrationException(processedError.originalErrorMessage);


    } catch (FmaIntegrationException ex) {
      log.trace("Throwing on FMAIntegrationException for caseId {}: {}", caseId, ex.getMessage());
      throw ex;
    } catch (FmaValidationException ex) {
      log.trace("Throwing on FMAValidationException for caseId {}: {}", caseId, ex.getMessage());
      throw ex;
    } catch (Throwable t) {
      String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
      log.error(
          "An unexpected exception occurred while calling integrationService submit FMA for caseID {}: {} - throwing FmaIntegrationException",
          caseId, message);
      throw new FmaIntegrationException(message, t);
    }
  }

  private ErrorDto processErrors(FullMortgageApplicationExtendedResponse fmaResponse, String status,
      String caseId) {

    List<Error> fmaErrors = fmaResponse.getErrors();
    log.warn("CaseId={}, errors returned from FMA - {}  ",
        caseId,
        fmaErrors == null ? "" : fmaErrors.toString().replace(System.lineSeparator(), ", "));

    //TODO - Picking a single error code here - amend to support > 1 code at once when we support > 1 handled errors
    ErrorCode mappedErrorCode = errorMapper.toSingleErrorCode(fmaResponse, caseId);
    //TODO - Keeping original error message in case we have alerting based on it. Review and change along with alerts
    String originalErrorMessage = getOriginalErrorMessage(fmaErrors, status);

    log.info("CaseId={}, Status={} - returning errorCode {}", caseId, status, mappedErrorCode);

    return ErrorDto.builder().errorCode(mappedErrorCode).originalErrorMessage(originalErrorMessage)
        .build();
  }

  private String getOriginalErrorMessage(List<Error> fmaErrors, String status) {

    String errorMessage = "";

    int errorCount = getErrorCount(fmaErrors);

    if (errorCount == 1) {
      errorMessage = getFirstErrorMessage(fmaErrors);
    } else if (errorCount > 1) {
      errorMessage = errorCount + " errors. First error is: " + getFirstErrorMessage(fmaErrors);
    }
    if (errorMessage == null || errorMessage.trim().isEmpty()) {
      errorMessage = "FMA Response error status " + status;
    }
    return errorMessage;
  }

  private int getErrorCount(List<Error> fmaResponseErrors) {
    return fmaResponseErrors == null ? 0 : fmaResponseErrors.size();
  }

  private String getFirstErrorMessage(List<Error> fmaErrors) {
    return fmaErrors != null ? fmaErrors.get(0).getMessage() : "";
  }


  @Builder
  private static class ErrorDto {

    String originalErrorMessage;
    ErrorCode errorCode;
  }


}
