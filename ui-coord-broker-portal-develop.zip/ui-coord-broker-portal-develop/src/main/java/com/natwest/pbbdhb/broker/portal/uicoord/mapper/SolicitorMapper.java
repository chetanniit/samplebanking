package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchResultDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.model.SolicitorAddress;
import com.natwest.pbbdhb.cases.dto.SolicitorDetailsDto;
import com.natwest.pbbdhb.cases.dto.TelephoneDto;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.Objects.isNull;

@Mapper(builder = @Builder(disableBuilder = true))
public interface SolicitorMapper {
    Solicitor toSolicitor(SolicitorSearchResultDto solicitorSearchResultDto);

    @Mapping(target = "telephoneNumber", ignore = true)
    @Mapping(target = "address", ignore = true)
    Solicitor toSolicitor(SolicitorDetailsDto solicitorDetailsDto);

    @Mapping(target = "postcode", expression = "java(solicitor.getAddress().getAddressPC())")
    @Mapping(target = "alphaKey", ignore = true)
    @Mapping(target = "associateType", ignore = true)
    @Mapping(target = "contactName", ignore = true)
    @Mapping(target = "branchCode", ignore = true)
    @Mapping(target = "branchName", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "solePractitioner", ignore = true)
    @Mapping(target = "documentExchangeNumber", ignore = true)
    @Mapping(target = "telephones", ignore = true)
    SolicitorDetailsDto toSolicitorDetailsDto(Solicitor solicitor);

    @AfterMapping
    default void afterMappingToSolicitorDetailsDto(Solicitor solicitor, @MappingTarget SolicitorDetailsDto solicitorDetailsDto) {
        List<TelephoneDto> telephones = Collections.singletonList(new TelephoneDto());
        solicitorDetailsDto.setTelephones(telephones);
        TelephoneDto telephone = telephones.get(0);

        telephone.setNumber(solicitor.getTelephoneNumber());
        telephone.setType("WORK");
        telephone.setPreferred(true);
    }

    @AfterMapping
    default void afterMappingToSolicitor(SolicitorDetailsDto solicitorDetailsDto, @MappingTarget Solicitor solicitor) {
        if (isNull(solicitorDetailsDto)) {
            return;
        }
        SolicitorAddress address = new SolicitorAddress();
        address.setAddressPC(solicitorDetailsDto.getPostcode());

        solicitor.setAddress(address);
        solicitor.setTelephoneNumber(Optional.ofNullable(solicitorDetailsDto.getTelephones()).map(List::stream)
                .flatMap(Stream::findFirst).map(TelephoneDto::getNumber).orElse(null));
    }
}
