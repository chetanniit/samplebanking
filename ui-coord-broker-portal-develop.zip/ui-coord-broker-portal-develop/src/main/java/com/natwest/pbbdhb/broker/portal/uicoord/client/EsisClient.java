package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.EsisException;
import com.rbs.pbbdhb.sales.esis.models.Application;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Collections;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;
import static java.lang.String.format;

/** Client component for msvc-sales-esis API */
@Component
@Slf4j
public class EsisClient {
    private static final String EXCEPTION_MESSAGE_TEMPLATE = "Could not load ESIS PDF with document name: %s";
    private final String createEsisEndpoint;
    private final String getEsisEndpoint;
    private final RestTemplate restTemplate;

    public EsisClient(
            @Value("${msvc.esis.create.url}") String createEsisEndpoint,
            @Value("${msvc.esis.get.url}") String getEsisEndpoint,
            @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate) {
        this.createEsisEndpoint = createEsisEndpoint;
        this.getEsisEndpoint = getEsisEndpoint;
        this.restTemplate = restTemplate;
    }

    /** Create ESIS */
    public void createEsis(String brand, Application application) {
        HttpHeaders headers = constructHeadersForJsonRequest(brand);
        headers.setAccept(Collections.singletonList(MediaType.ALL));

        String caseId = application.getCaseId();
        log.info("Calling {} to create ESIS with caseId {}", createEsisEndpoint, caseId);

        try {
          restTemplate.exchange(
              createEsisEndpoint,
              HttpMethod.POST,
              new HttpEntity<>(application, headers),
              Void.class);
          log.debug("ESIS with caseId {} successfully created", caseId);

        } catch (RestClientException ex) {
          log.warn("A rest client exception occurred while calling {} to create ESIS with caseId {}: {}",
              createEsisEndpoint, caseId, ex.getMessage());
          throw ex;
        } catch (Throwable t) {
          log.warn("An unexpected exception occurred while calling {} to create ESIS with caseId {}: {}",
              createEsisEndpoint, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
          throw t;
        }
    }

    /** Loads ESIS url as a resource and returns the stream */
    public InputStream getEsis(String documentName) {
        log.info("Calling {} to get ESIS with documentName {}", getEsisEndpoint, documentName);

        try {
          ResponseEntity<byte[]> responseEntity = restTemplate.getForEntity(getEsisEndpoint,
              byte[].class, documentName);

          HttpStatusCode statusCode = responseEntity.getStatusCode();
          byte[] responseBody = responseEntity.getBody();
          if (statusCode == HttpStatus.OK && responseBody != null) {
            log.debug("ESIS with documentName {} successfully retrieved", documentName);
            return new ByteArrayInputStream(responseBody);
          }

          log.error("Error response received from {} while getting ESIS with documentName {}: statusCode {} - throwing EsisException",
              getEsisEndpoint, documentName, statusCode.value());
          throw new EsisException(format(EXCEPTION_MESSAGE_TEMPLATE, documentName));

      } catch (RestClientException ex) {
        log.warn("A rest client exception occurred while calling {} to get ESIS with documentName {}: {}",
            createEsisEndpoint, documentName, ex.getMessage());
        throw ex;
      } catch (Throwable t) {
        log.warn("An unexpected exception occurred while calling {} to create ESIS with documentName {}: {}",
            createEsisEndpoint, documentName, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
        throw t;
    }
    }

}
