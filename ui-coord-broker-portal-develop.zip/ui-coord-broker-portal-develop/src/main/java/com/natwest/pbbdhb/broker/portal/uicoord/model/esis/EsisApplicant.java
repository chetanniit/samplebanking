package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisApplicantOtherTitle;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Builder;
import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
@Builder
@ValidEsisApplicantOtherTitle
public class EsisApplicant {

    @NotNull
    @ValidateEnum(enumClass = Title.class)
    private String title;

    private String otherTitle;

    @NotBlank
    @Size(min = 1, max = 15)
    private String firstNames;

    @Size(max = 25)
    private String middleNames;

    @NotBlank
    @Size(min = 1, max = 30)
    private String lastName;

    @NotNull
    @DateFormat(pattern = "yyyy-MM-dd")
    private String dateOfBirth;

}
