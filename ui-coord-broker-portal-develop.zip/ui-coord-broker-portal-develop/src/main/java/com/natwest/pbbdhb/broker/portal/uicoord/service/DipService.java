package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import org.springframework.core.io.InputStreamResource;


public interface DipService {
    BrokerCase submitDip(String brand, String caseId) throws DipIntegrationException;

    InputStreamResource getDipCertificateWithCaseId(String brand, String caseId) throws DipIntegrationException;

    InputStreamResource getDipDocumentByDipId(String brand, String dipId) throws DipIntegrationException;
}
