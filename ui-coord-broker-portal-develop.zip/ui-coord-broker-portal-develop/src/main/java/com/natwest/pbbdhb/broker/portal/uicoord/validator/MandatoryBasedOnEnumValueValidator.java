package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MandatoryBasedOnEnumValue;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static org.apache.tomcat.util.IntrospectionUtils.getProperty;

public class MandatoryBasedOnEnumValueValidator implements ConstraintValidator<MandatoryBasedOnEnumValue, Object> {

    String mandatoryField;
    String enumField;
    String enumValue;

    @Override
    public void initialize(MandatoryBasedOnEnumValue annotation) {
        this.mandatoryField = annotation.MandatoryField();
        this.enumField = annotation.EnumField();
        this.enumValue = annotation.EnumValue();
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        if (objectToValidate == null || null == getProperty(objectToValidate, enumField)) {
            return true;
        }

        if (!getProperty(objectToValidate, enumField).equals(enumValue) ) {
            return true;
        }

        if (getProperty(objectToValidate, mandatoryField) != null && getProperty(objectToValidate, enumField).equals(enumValue)) {
            return true;
        }

        context.unwrap(HibernateConstraintValidatorContext.class).addExpressionVariable("errorMessage", mandatoryField+" is mandatory when "+enumField+" == "+enumValue);
        return false;
    }
}
