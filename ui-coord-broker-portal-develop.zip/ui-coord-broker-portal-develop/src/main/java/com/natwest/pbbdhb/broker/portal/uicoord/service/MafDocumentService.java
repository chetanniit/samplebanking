package com.natwest.pbbdhb.broker.portal.uicoord.service;

import org.springframework.core.io.InputStreamResource;

public interface MafDocumentService {

    InputStreamResource getMafDocument(String documentName, String brand);
}
