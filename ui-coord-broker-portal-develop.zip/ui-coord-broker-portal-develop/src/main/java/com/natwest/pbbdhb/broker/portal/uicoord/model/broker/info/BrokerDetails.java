package com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerDetails {
    private String userName;
    private String firstName;
    private String lastName;
    private String title;
    private String emailAddress;
    private String mobilePhone;
    private String otherPhone;
    private String postcode;
}