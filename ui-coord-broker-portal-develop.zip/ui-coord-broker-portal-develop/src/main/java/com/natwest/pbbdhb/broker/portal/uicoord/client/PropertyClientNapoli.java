package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class PropertyClientNapoli {

    private final String getPropertyEndpoint;
    private final String createPropertyEndpoint;
    private final String updatePropertyEndpoint;
    private final RestTemplate restTemplate;

    public PropertyClientNapoli(
            @Value("${msvc.property.get.url}") String getPropertyEndpoint,
            @Value("${msvc.property.create.url}") String createPropertyEndpoint,
            @Value("${msvc.property.update.url}") String updatePropertyEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ){
        this.getPropertyEndpoint = getPropertyEndpoint;
        this.createPropertyEndpoint = createPropertyEndpoint;
        this.updatePropertyEndpoint = updatePropertyEndpoint;
        this.restTemplate = restTemplate;
    }

    public PropertyDetailsDto saveProperty(String brand, PropertyDetailsDto property) {
        return StringUtils.hasText(property.getVersion()) ? updateProperty(brand, property) : createProperty(brand, property);
    }

    private PropertyDetailsDto createProperty(String brand, PropertyDetailsDto property) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(createPropertyEndpoint);
        URI url = builder.build().toUri();
        String caseId = property.getCaseId();
        String version = property.getVersion();
        log.info("Calling {} to create property with version {} and caseId {}", url, version, caseId);

        try {
            PropertyDetailsDto propertyDetailsDto = restTemplate.exchange(
                url,
                HttpMethod.POST,
                new HttpEntity<>(property, constructHeadersForJsonRequest(brand)),
                PropertyDetailsDto.class).getBody();
            if(propertyDetailsDto == null) {
                log.warn("Null response body received from {} while creating property with version {} and caseId {}", url, version, caseId);
            } else {
              log.debug("Property with version {} successfully created for caseId {}",
                  propertyDetailsDto.getVersion(), caseId);
            }
            return propertyDetailsDto;

        } catch (RestClientException ex) {
          log.warn(
              "A rest client exception occurred while calling {} to create property with version {} and caseId {}: {}",
              url, version, caseId, ex.getMessage());
          throw ex;
        } catch (Throwable t) {
          log.warn(
              "An unexpected exception occurred while calling {} to create property with version {} and caseId {}: {}",
              url, version, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
          throw t;
        }
    }

    private PropertyDetailsDto updateProperty(String brand, PropertyDetailsDto property) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(updatePropertyEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        String caseId = property.getCaseId();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);
        String version = property.getVersion();
        URI url = builder.build().toUri();
        log.info("Calling {} to update property with version {} and caseId {}", url, version, caseId);

        try {
            PropertyDetailsDto propertyDetailsDto = restTemplate.exchange(
                    url,
                    HttpMethod.PUT,
                    new HttpEntity<>(property, constructHeadersForJsonRequest(brand)),
                    PropertyDetailsDto.class).getBody();
            if(propertyDetailsDto == null) {
              log.warn("Null response body received from {} while creating property with version {} and caseId {}", url, version, caseId);
            } else {
              log.debug("Property successfully updated with version {} and caseId {}", propertyDetailsDto.getVersion(), caseId);
            }
            return propertyDetailsDto;

        } catch (RestClientException ex) {
            log.warn(
                "A rest client exception occurred while calling {} to update property with version {} and caseId {}: {}",
                url, version, caseId, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn(
                "An unexpected exception occurred while calling {} to update property with version {} and caseId {}: {}",
                url, version, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }

    }

    public PropertyDetailsDto getProperty(String brand, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(getPropertyEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);

        URI url = builder.build().toUri();
        log.info("Calling {} to get property for caseId {}", url, caseId);

        try {
            PropertyDetailsDto propertyDetailsDto =  restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    new HttpEntity<>(constructHeadersForJsonRequest(brand)),
                    PropertyDetailsDto.class).getBody();
            log.debug("Property successfully retrieved for caseId {}", caseId);
            return propertyDetailsDto;

        } catch (HttpClientErrorException.NotFound ex) {
            log.warn("Property not found for caseId {}: returning null - {}", caseId, ex.getMessage());
            return null;
        } catch (RestClientException ex) {
            log.warn(
                "A rest client exception occurred while calling {} to get property for caseId {}: {}",
                url, caseId, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn(
                "An unexpected exception occurred while calling {} to get property for caseId {}: {}",
                url, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
