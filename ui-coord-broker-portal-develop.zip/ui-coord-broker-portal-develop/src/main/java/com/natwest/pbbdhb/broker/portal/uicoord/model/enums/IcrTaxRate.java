package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum IcrTaxRate implements ValuedEnum{
    HIGH,
    LOW;

    @Override
    public String value() {
        return name();
    }
}