package com.natwest.pbbdhb.broker.portal.uicoord.model;

import java.math.BigDecimal;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class Broker {

  Integer paymentPath;

  @Min(0)
  @Max(9999)
  BigDecimal fee;

  private Boolean brokerFeeCharged;

  @AssertTrue
  private Boolean consentToDIP;

  @AssertTrue
  private Boolean consentToFMA;

  private String brokerEmail;
}
