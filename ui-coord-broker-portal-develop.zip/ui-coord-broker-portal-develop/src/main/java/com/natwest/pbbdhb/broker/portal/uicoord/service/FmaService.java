package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaIntegrationException;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;


public interface FmaService {
    FullMortgageApplicationExtendedResponse submitFma(String brand, String caseId) throws FmaIntegrationException;
}
