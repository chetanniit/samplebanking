package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_UNKNOWN_ERR;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_VALIDATION_FAILURE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_VALIDATION_FAILURE_DESC;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.RequestValidationDto;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ApplicationNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipUnhandledValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaUnhandledValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.InvalidCaseStateException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponseDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.EventLogger;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.LogMessageSubtype;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.LogMessageType;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Exception handler for REST controllers
 */
@RestControllerAdvice
@RequiredArgsConstructor
@Slf4j
public class ControllerAdvice extends ResponseEntityExceptionHandler {

    private final ObjectMapper objectMapper;

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleConstraintViolation(
            ConstraintViolationException ex, WebRequest request) {

        Set<ConstraintViolation<?>> constraintViolations = ex.getConstraintViolations();
        if (constraintViolations == null || constraintViolations.isEmpty()) {
            ErrorResponse error = ErrorResponse.builder()
                .status(HttpStatus.BAD_REQUEST.value())
                .title(MSG_VALIDATION_FAILURE)
                .description(ex.getMessage() != null ? ex.getMessage() : MSG_UNKNOWN_ERR)
                .build();
            logError(ex, error);
            return error;
        }

        List<ErrorResponseDetail> details = constraintViolations.stream()
            .map(error -> ErrorResponseDetail
                .builder()
                .title(error.getPropertyPath().toString())
                .description(error.getMessage())
                .build())
            .sorted(Comparator.comparing(ErrorResponseDetail::getTitle)
                .thenComparing(ErrorResponseDetail::getDescription))
            .collect(Collectors.toList());

        ErrorResponse error = ErrorResponse.builder()
            .status(HttpStatus.BAD_REQUEST.value())
            .title(MSG_VALIDATION_FAILURE)
            .description(MSG_VALIDATION_FAILURE_DESC)
            .errors(details)
            .build();
        logError(ex, error);
        return error;
    }

    @ExceptionHandler(PermissionDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handlePermissionDenied(PermissionDeniedException ex) {
        ErrorResponse error = ErrorResponse.builder()
            .status(HttpStatus.FORBIDDEN.value())
            .title("Forbidden")
            .description(ex.getDescription())
            .build();
        logError(ex, error);
        return error;
    }

    @ExceptionHandler(UpdateNotPermittedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleUpdateNotPermitted(UpdateNotPermittedException ex) {
        ErrorResponse error = ErrorResponse.builder()
                .status(HttpStatus.FORBIDDEN.value())
                .title("Update not permitted")
                .description(ex.getDescription())
                .build();
        logError(ex, error);
        return error;
    }


    @ExceptionHandler(InvalidCaseStateException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ErrorResponse handleUpdateNotPermitted(InvalidCaseStateException ex) {
        ErrorResponse error = ErrorResponse.builder()
                .status(HttpStatus.CONFLICT.value())
                .title("Case not valid for action")
                .description(ex.getMessage())
                .build();
        logError(ex, error);
        return error;
    }

    @ExceptionHandler(FmaValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ValidationResponse handleFmaValidationException(FmaValidationException ex) {

      ValidationResponseDetail error = ValidationResponseDetail.builder().code(ex.getCode().toString())
                                        .message(ex.getCode().getExternalMessage())
                                        .status(HttpStatus.BAD_REQUEST.value()).build();

      ValidationResponse validationResponse = ValidationResponse.builder()
                                          .status(HttpStatus.BAD_REQUEST.value())
                                          .title("FMA Submit Validation Errors")
                                          .error(Collections.singletonList(error))
                                          .build();

      logValidationResponse(ex, validationResponse, LogMessageType.FMA, LogMessageSubtype.FMA_SUBMIT);

      return validationResponse;

    }

    @ExceptionHandler(DipValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ValidationResponse handleDipValidationException(DipValidationException ex) {

      ValidationResponseDetail error = ValidationResponseDetail.builder().code(ex.getCode().toString())
          .message(ex.getCode().getExternalMessage())
          .status(HttpStatus.BAD_REQUEST.value()).build();

      ValidationResponse validationResponse = ValidationResponse.builder()
          .status(HttpStatus.BAD_REQUEST.value())
          .title("DIP Submit Validation Errors")
          .error(Collections.singletonList(error))
          .build();

      logValidationResponse(ex, validationResponse, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT);

      return validationResponse;

    }

    @ExceptionHandler(FmaUnhandledValidationException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ValidationResponse handleFmaUnhandledValidationException(FmaUnhandledValidationException ex) {

      ValidationResponseDetail error = ValidationResponseDetail.builder().code(ex.getCode().toString())
          .message(ex.getMessage())
          .status(HttpStatus.BAD_REQUEST.value()).build();

      ValidationResponse errorResponse = ValidationResponse.builder()
          .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
          .title("FMA Submit Unhandled Validation Errors")
          .error(Collections.singletonList(error))
          .build();

      logUnhandledValidationError(ex, errorResponse, LogMessageType.FMA, LogMessageSubtype.FMA_SUBMIT);

      return errorResponse;

    }

    @ExceptionHandler(DipUnhandledValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ValidationResponse handleDipUnhandledValidationException(DipUnhandledValidationException ex) {

      ValidationResponseDetail error = ValidationResponseDetail.builder().code(ex.getCode().toString())
          .message(ex.getMessage())
          .status(HttpStatus.BAD_REQUEST.value()).build();

      ValidationResponse errorResponse = ValidationResponse.builder()
          .status(HttpStatus.BAD_REQUEST.value())
          .title("DIP Submit Unhandled Validation Errors")
          .error(Collections.singletonList(error))
          .build();

      String logMessageSubtype;
      if (ErrorCode.VALIDATION_EXPIRED_DIP == ex.getCode()) {
        logMessageSubtype = LogMessageSubtype.DIP_CERTIFICATE;
      } else {
        logMessageSubtype = LogMessageSubtype.DIP_SUBMIT;
      }

      logUnhandledValidationError(ex, errorResponse, LogMessageType.DIP, logMessageSubtype);

      return errorResponse;
    }

    @ExceptionHandler(HttpClientErrorException.BadRequest.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleBadRequest(HttpStatusCodeException ex) {
        return buildHttpClientExceptionResponse(ex);
    }


    @ExceptionHandler(ApplicationNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleBadRequest(ApplicationNotFoundException ex) {
      ErrorResponse errorResponse = ErrorResponse.builder()
          .status(HttpStatus.NOT_FOUND.value())
          .title(HttpStatus.NOT_FOUND.getReasonPhrase())
          .description(ex.getMessage())
          .build();
      logError(ex, errorResponse);
      return errorResponse;
    }

    @ExceptionHandler(HttpClientErrorException.Unauthorized.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleUnauthorized(HttpStatusCodeException ex) {
        return buildHttpClientExceptionResponse(ex);
    }

    @ExceptionHandler(HttpClientErrorException.Forbidden.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleForbidden(HttpStatusCodeException ex) {
        return buildHttpClientExceptionResponse(ex);
    }

    @ExceptionHandler(HttpClientErrorException.Conflict.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ErrorResponse handleConflict(HttpStatusCodeException ex) {
        return buildHttpClientExceptionResponse(ex);
    }

    @ExceptionHandler({HttpClientErrorException.NotFound.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleNotFound(HttpStatusCodeException ex) {
        return buildHttpClientExceptionResponse(ex);
    }

    @ExceptionHandler(HttpServerErrorException.InternalServerError.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleInternalServerError(HttpStatusCodeException ex) {
        return buildHttpClientExceptionResponse(ex);
    }

    // falls back to generic handler if not handled above
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleGenericException(Exception ex) {
        log.warn("Handling unexpected error", ex);
        ErrorResponse error = ErrorResponse.builder()
            .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .title("Internal Server Error")
            .description("Our backend is non-functional, please try again later.")
            .build();
        logError(ex, error);
        return error;
    }

    // to handle MethodArgumentNotValidException, we must override Spring's built-in handler
    @Override
    @NonNull
    protected ResponseEntity<Object> handleMethodArgumentNotValid(@NonNull MethodArgumentNotValidException ex,
                                                                  @NonNull HttpHeaders headers,
                                                                  @NonNull HttpStatusCode status,
                                                                  @NonNull WebRequest request) {

        List<ErrorResponseDetail> details = ex.getFieldErrors().stream()
            .map(error -> ErrorResponseDetail
                .builder()
                .title(error.getField())
                .description(error.getDefaultMessage())
                .build())
            .sorted(Comparator.comparing(ErrorResponseDetail::getTitle)
                .thenComparing(ErrorResponseDetail::getDescription))
            .collect(Collectors.toList());

        ErrorResponse error = ErrorResponse.builder()
            .status(status.value())
            .title(MSG_VALIDATION_FAILURE)
            .description(MSG_VALIDATION_FAILURE_DESC)
            .errors(details)
            .build();
        logError(ex, error);

        return new ResponseEntity<>(
            error,
            headers,
            status);
    }

    private ErrorResponse buildHttpClientExceptionResponse(HttpStatusCodeException exception) {
        try {

            RequestValidationDto requestValidationDto = this.objectMapper.readValue(exception.getResponseBodyAsString(), RequestValidationDto.class);
            if (requestValidationDto != null && requestValidationDto.getErrors() != null) {
                List<ErrorResponseDetail> details = requestValidationDto.getErrors().stream()
                    .map(error -> ErrorResponseDetail
                        .builder()
                        .title(error.getField() != null ? error.getField() : "Error")
                        .description(error.getMessage() != null ? error.getMessage() : MSG_UNKNOWN_ERR)
                        .build())
                    .sorted(Comparator.comparing(ErrorResponseDetail::getTitle)
                        .thenComparing(ErrorResponseDetail::getDescription))
                    .collect(Collectors.toList());

                ErrorResponse error = ErrorResponse.builder()
                    .status(exception.getStatusCode().value())
                    .title(exception.getStatusText())
                    .description("The following errors occurred")
                    .errors(details)
                    .build();
                logError(exception, error);
                return error;
            }
        } catch (JsonProcessingException jpex) {
            log.error("Unable to parse HttpStatusCodeException body. Returning original error in message.");
        }

        ErrorResponse error = ErrorResponse.builder()
            .status(exception.getStatusCode().value())
            .title(exception.getStatusText())
            .description(exception.getResponseBodyAsString() != null ? exception.getResponseBodyAsString() : MSG_UNKNOWN_ERR)
            .build();
        logError(exception, error);
        return error;
    }

    // logs errors in a consistent format for application error monitoring tools
    private void logError(Throwable ex, ErrorResponse error) {
        // log errors using our common reporting format
        log.error(EventLogger.logException(ex, error));
    }

    // logs errors in a consistent format for application error monitoring tools
    private void logUnhandledValidationError(Throwable ex, ValidationResponse error, String type, String subtype) {
        // log errors using our common reporting format
        log.warn(EventLogger.logUnhandledValidationErrorResponse(ex, error, type, subtype));
    }

   private void logValidationResponse(Throwable ex, ValidationResponse error, String type, String subtype) {
      // log errors using our common reporting format
      log.warn(EventLogger.logValidationResponse(ex, error, type, subtype));
  }
}
