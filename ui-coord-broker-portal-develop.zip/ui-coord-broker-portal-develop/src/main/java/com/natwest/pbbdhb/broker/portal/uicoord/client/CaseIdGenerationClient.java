package com.natwest.pbbdhb.broker.portal.uicoord.client;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PREFIX_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PREFIX_VALUE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_VALUE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeaders;

@Component
@Slf4j
public class CaseIdGenerationClient {
    private final String caseIdServiceEndpoint;
    private final RestTemplate restTemplate;

    public CaseIdGenerationClient(
            @Value("${msvc.caseId.generation.url}") String caseIdServiceEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.caseIdServiceEndpoint = caseIdServiceEndpoint;
        this.restTemplate = restTemplate;
    }

    // copied from ui-coord-execution-only-sales:com.natwest.pbbdhb.ui.application.xo.service.CaseService
    public String generateCaseId(String brand) {
        // These params are required for the call but have no bearing on the response
        // Hard coding these params in line with advice team
        Map<String, String> params = new HashMap<>();
        params.put(CASE_ID_PREFIX_PARAM, CASE_ID_PREFIX_VALUE);
        params.put(CLIENT_ID_PARAM, CLIENT_ID_VALUE);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(caseIdServiceEndpoint);
        for (Map.Entry<String, String> entry : params.entrySet()) {
            builder.queryParam(entry.getKey(), entry.getValue());
        }

        URI url = builder.build().toUri();
        log.info("Calling {} to generate case id", url);

        try {
              String caseId = restTemplate.exchange(
                  url,
                  HttpMethod.GET,
                  new HttpEntity<>(null, constructHeaders(brand)),
                  String.class).getBody();
              log.debug("Case with caseId {} successfully updated", caseId);
              return caseId;

        } catch (RestClientException ex) {
              log.warn("A rest client exception occurred while calling {} to generate caseId: {}",
                  url, ex.getMessage());
              throw ex;
        } catch (Throwable t) {
              log.warn("An unexpected exception occurred while calling {} to generate caseId: {}",
                  url, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
              throw t;
        }
    }
}
