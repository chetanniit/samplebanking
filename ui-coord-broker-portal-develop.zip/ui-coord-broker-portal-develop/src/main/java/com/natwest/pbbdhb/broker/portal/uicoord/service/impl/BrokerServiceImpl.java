package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerDeclarationClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ProcFeeClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerDeclarationRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerDeclarationRequestDto.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerDeclarationRequestDto.DocumentKey;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PercentageFeeDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInformationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerSwitchMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.PaymentPathMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.ProcFeeMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerProductSwitchDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.FirmDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BrokerServiceImpl implements BrokerService {
    private final ProcFeeClient procFeeClient;
    private final BrokerDeclarationClient brokerDeclarationClient;
    private final PaymentPathMapper paymentPathMapper;
    private final ProcFeeMapper procFeeMapper;
    private final BrokerInformationMapper brokerInformationMapper;
    private final BrokerSwitchMapper brokerSwitchMapper;

    @Override
    public List<PaymentPath> getBrokerPaymentPaths(BrokerInfo broker) {
        String username = broker.getBrokerDetails() == null ? null : broker.getBrokerDetails().getUserName();
        log.debug("Retrieving payment paths for brokerUsername {}", username);
        return Optional.ofNullable(broker.getPaymentPaths()).map(List::stream)
                .map(paymentPathStream -> paymentPathStream.filter(Objects::nonNull)
                        .map(paymentPathMapper::toPaymentPath)
                        .collect(Collectors.toList()))
                .orElse(Collections.emptyList());
    }

    @Override
    public BrokerProductSwitchDetails getBrokerProductSwitchDetails(String brand, String paymentPathName, BrokerInfo broker) {
        String userName = broker.getBrokerDetails() == null ? null : broker.getBrokerDetails().getUserName();
        log.debug("Retrieving broker product switch details for paymentPathName {}, brokerUsername {}, and brand {}", paymentPathName, userName, brand);
        try {
            // NOTE: some logic here might be usefully extracted to BrokerClaimsUtil
            log.debug("Searching payment path for paymentPathName {}, brokerUsername {}, and brand {}", paymentPathName, userName, brand);
            String paymentPathScale = Optional.ofNullable(broker.getPaymentPaths()).map(List::stream).flatMap(
                    paymentPathStream -> paymentPathStream
                            .filter(paymentPath -> paymentPathName.equalsIgnoreCase(paymentPath.getPaymentPathName()))
                            .findFirst())
                    .map(com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath::getPaymentPathScaleResidential)
                    .orElseThrow(() -> {
                      log.error("Payment path name not found for paymentPathName {}, brokerUsername {}, and brand {}", paymentPathName, userName, brand);
                      return new IllegalArgumentException(
                          "Payment path name not found : '" + paymentPathName + "'");
                    });
            log.debug("Payment path successfully found for paymentPathName {}, brokerUsername {}, and brand {}", paymentPathName, userName, brand);
            log.debug("Calling procFeeClient to get percentage fee for payment path {}, brokerUsername {}, and brand {}", paymentPathScale, userName, brand);
            PercentageFeeDto percentageFeeDto =
                    procFeeClient.getPercentageFee(brand, procFeeMapper.toPercentageFeeRequestDto(paymentPathScale));
            log.debug("procFeeClient successfully called to get percentage fee for payment path {}, brokerUsername {}, and brand {}", paymentPathScale, userName, brand);

            BrokerProductSwitchDetails brokerProductSwitchDetails = brokerSwitchMapper.toBrokerProductSwitchDetails(brokerInformationMapper.toBrokerInformation(
                    broker, paymentPathName, percentageFeeDto.getProcFeePercentage()));
            log.debug("Broker product switch details successfully retrieved for paymentPathName {}, brokerUsername {}, and brand {}", paymentPathName, userName, brand);
            return brokerProductSwitchDetails;
        } catch (Exception ex) {
          log.error("An unexpected exception occurred while getting product switch details for brand {}, paymentPathName {}, brokerUsername {}: {} - throwing HttpServerErrorException",
                    brand, paymentPathName, userName, ex.getMessage());
            throw HttpServerErrorException
                    .create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                            new HttpHeaders(), ex.getMessage().getBytes(
                                    StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        }
    }

    @Override
    public String getBrokerDeclaration(String brand, BrokerInfo broker) {
      String userName = broker.getBrokerDetails().getUserName();
      log.debug("Calling brokerDeclarationClient to get broker declaration for brokerUsername {} and brand {}", userName, brand);
      BrokerDeclarationRequestDto brokerDeclarationRequestDto = BrokerDeclarationRequestDto.builder()
          .broker(BrokerRequestDto.builder()
              .fcaNumber(Optional.ofNullable(broker.getFirmDetails())
                  .map(FirmDetails::getFcaNumber)
                  .orElse(null))
              .brokerSurname(broker.getBrokerDetails().getLastName())
              .brokerUsername(userName)
              .brokerForeName(broker.getBrokerDetails().getFirstName())
              .brokerPostcode(broker.getBrokerDetails().getPostcode())
              .brokerEmail(broker.getBrokerDetails().getEmailAddress())
              .build())
          .applicationType(ApplicationType.FMA)
          .documentKey(DocumentKey.DIRECT_DEBT_GUARANTEE)
          .build();
      String brokerDeclaration = brokerDeclarationClient.getDeclaration(brand, brokerDeclarationRequestDto);
      log.debug("brokerDeclarationClient successfully to get broker declaration for brokerUsername {} and brand {}", userName, brand);
      return brokerDeclaration;
    }
}
