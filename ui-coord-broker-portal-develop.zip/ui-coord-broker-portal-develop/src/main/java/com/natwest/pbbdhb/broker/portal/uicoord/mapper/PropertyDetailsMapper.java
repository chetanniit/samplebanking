package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PROPERTY_JOURNEY_DATA_HOME_REPORT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PROPERTY_JOURNEY_DATA_NEW_BUILD;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PROPERTY_JOURNEY_DATA_STANDARD_MORTGAGE_VALUATION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DataUtils.toDataObject;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PropertyJourneyDataDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PropertyDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Valuation;
import com.natwest.pbbdhb.commondictionaries.enums.property.PropertyClass;
import com.natwest.pbbdhb.commondictionaries.enums.property.Usage;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.property.dto.ValuationDto;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(uses = {PropertyAddressMapper.class}, builder = @Builder(disableBuilder = true))
public interface PropertyDetailsMapper {

    @Mapping(target = "newBuild", ignore = true)
    @Mapping(target = "homeReport", ignore = true)
    @Mapping(target = "epcRatingAorB", ignore = true)
    PropertyDetails toPropertyDetails(PropertyDetailsDto propertyDetailsDto);

    @Mapping(target = "journeyData", ignore = true)
    @Mapping(target = "epcRating", expression = "java(propertyDetails.isEpcRatingAorB() ? \"A\" : \"NO_VALID_EPC\")")
    @Mapping(target = "wallType", constant = "BRICKS_AND_MORTAR")
    @Mapping(target = "usage", ignore = true)
    @Mapping(target = "propertyClass", ignore = true)
    @Mapping(target = "floor", ignore = true)
    @Mapping(target = "numberOfFlats", ignore = true)
    @Mapping(target = "localAuthority", ignore = true)
    @Mapping(target = "declarationKnowYourProperty", ignore = true)
    @Mapping(target = "consentToShareDetailsWithSurveyProvider", ignore = true)
    @Mapping(target = "termRemaining", ignore = true)
    @Mapping(target = "applicationStatus", ignore = true)
    @Mapping(target = "storeys", ignore = true)
    @Mapping(target = "warrantyType", ignore = true)
    @Mapping(target = "holdingDeeds", ignore = true)
    @Mapping(target = "roofType", ignore = true)
    @Mapping(target = "equityProvider", ignore = true)
    @Mapping(target = "arrangementName", ignore = true)
    @Mapping(target = "arrangementContactNum", ignore = true)
    @Mapping(target = "createdDate", ignore = true)
    @Mapping(target = "modifiedDate", ignore = true)
    @Mapping(target = "openMarketFlag", ignore = true)
    PropertyDetailsDto toPropertyDetailsDto(String caseId, PropertyDetails propertyDetails, boolean isBuyToLet);

    @Mapping(target = "firmName", ignore = true)
    @Mapping(target = "received", ignore = true)
    @Mapping(target = "amount", ignore = true)
    @Mapping(target = "id", ignore = true)
    ValuationDto toValuationDto(Valuation valuation);

    @AfterMapping
    default void afterToPropertyDetails(PropertyDetailsDto propertyDetailsDto, @MappingTarget PropertyDetails propertyDetails) {
        String epcRating = propertyDetailsDto.getEpcRating();
        if (nonNull(epcRating)) {
            propertyDetails.setEpcRatingAorB("A".equals(epcRating));
        }
        PropertyJourneyDataDto journeyDataDto = toDataObject(propertyDetailsDto.getJourneyData(), PropertyJourneyDataDto.class);
        if (isNull(journeyDataDto)) {
            return;
        }
        propertyDetails.setNewBuild(journeyDataDto.getNewBuild());
        propertyDetails.setHomeReport(journeyDataDto.getHomeReport());
    }

    @AfterMapping
    default void afterToPropertyDetailsDto(PropertyDetails propertyDetails, @MappingTarget PropertyDetailsDto propertyDetailsDto, boolean isBuyToLet) {
        if (isNull(propertyDetailsDto.getJourneyData())) {
            propertyDetailsDto.setJourneyData(new HashMap<>());
        }
        
        propertyDetailsDto.setPropertyClass(PropertyClass.RESIDENTIAL.toString());

        String usageType = isBuyToLet ? Usage.FULLY_LET.toString() : Usage.OWNER_OCCUPIED.toString();
        propertyDetailsDto.setUsage(usageType);

        propertyDetailsDto.getJourneyData().put(PROPERTY_JOURNEY_DATA_NEW_BUILD, propertyDetails.getNewBuild());
        propertyDetailsDto.getJourneyData().put(PROPERTY_JOURNEY_DATA_HOME_REPORT, propertyDetails.isHomeReport());

        if (isNull(propertyDetailsDto.getValuation())) {
            propertyDetailsDto.setValuation(new ValuationDto());
        }
        ValuationDto valuationDto = propertyDetailsDto.getValuation();
        valuationDto.setType(PROPERTY_JOURNEY_DATA_STANDARD_MORTGAGE_VALUATION);
        if (isNull(valuationDto.getDate())) {
            valuationDto.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }
    }
}
