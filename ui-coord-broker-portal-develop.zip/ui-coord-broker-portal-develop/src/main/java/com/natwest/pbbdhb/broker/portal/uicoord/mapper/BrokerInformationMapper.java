package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerInformation;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.AddressDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Mapper
public interface BrokerInformationMapper {
    @Mapping(target = "title", source = "broker.brokerDetails.title")
    @Mapping(target = "forename", source = "broker.brokerDetails.firstName")
    @Mapping(target = "surname", source = "broker.brokerDetails.lastName")
    @Mapping(target = "firmName", source = "broker.firmDetails.tradingName")
    @Mapping(target = "poBoxNumber", ignore = true)
    @Mapping(target = "houseNameNumber", source = "broker.firmDetails.address.line1")
    @Mapping(target = "addressLine1", source = "broker.firmDetails.address", qualifiedByName = "getFirmAddressLine1")
    @Mapping(target = "addressLine2", source = "broker.firmDetails.address", qualifiedByName = "getFirmAddressLine2")
    @Mapping(target = "addressLine3", ignore = true)
    @Mapping(target = "city", source = "broker.firmDetails.address", qualifiedByName = "getFirmAddressCity")
    @Mapping(target = "county", source = "broker.firmDetails.address", qualifiedByName = "getFirmAddressCounty")
    @Mapping(target = "country", ignore = true)
    @Mapping(target = "postCode", source = "broker.firmDetails.address.postcode")
    @Mapping(target = "emailAddress", source = "broker.brokerDetails.emailAddress")
    @Mapping(target = "fcaReference", source = "broker.firmDetails.fcaNumber")
    @Mapping(target = "networkInfo", source = "paymentPathName")
    @Mapping(target = "brokerPhoneNumber", source = "broker.brokerDetails.otherPhone",
            defaultExpression = "java(broker.getBrokerDetails() == null ? null : broker.getBrokerDetails().getMobilePhone())")
    @Mapping(target = "procurementFee", source = "procFeePercentage")
    BrokerInformation toBrokerInformation(BrokerInfo broker, String paymentPathName,
                                          BigDecimal procFeePercentage);

    @Named("getFirmAddressLine1")
    default String getFirmAddressLine1(AddressDetails addressDetails) {
        if (isNull(addressDetails)) {
            return null;
        }
        // If line 2 is available then use line 2, otherwise use city for setting address line 1
        return isNotBlank(addressDetails.getLine2()) ? addressDetails.getLine2() : addressDetails.getCity();
    }

    @Named("getFirmAddressLine2")
    default String getFirmAddressLine2(AddressDetails addressDetails) {
        if (isNull(addressDetails)) {
            return null;
        }
        // If line 2 and line 3 are available then use line 3, otherwise use null for setting address line 2
        return isNotBlank(addressDetails.getLine2()) && isNotBlank(addressDetails.getLine3())
                ? addressDetails.getLine3() : null;
    }

    @Named("getFirmAddressCity")
    default String getFirmAddressCity(AddressDetails addressDetails) {
        if (isNull(addressDetails)) {
            return null;
        }
        // If line 2 is available then city will be mapped to city, otherwise county is mapped
        return isNotBlank(addressDetails.getLine2()) ? addressDetails.getCity() : addressDetails.getCounty();
    }

    @Named("getFirmAddressCounty")
    default String getFirmAddressCounty(AddressDetails addressDetails) {
        if (isNull(addressDetails)) {
            return null;
        }
        // If line 2 is available then county will be mapped to county, otherwise null is mapped
        return isNotBlank(addressDetails.getLine2()) ? addressDetails.getCounty() : null;
    }
}
