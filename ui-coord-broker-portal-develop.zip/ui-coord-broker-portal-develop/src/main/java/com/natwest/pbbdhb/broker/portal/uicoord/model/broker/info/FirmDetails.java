package com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.AddressDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FirmDetails {
    private String firmId;
    private String firmName;
    private String fcaNumber;
    private String principalFCANumber;
    private String tradingName;
    private AddressDetails address;
}