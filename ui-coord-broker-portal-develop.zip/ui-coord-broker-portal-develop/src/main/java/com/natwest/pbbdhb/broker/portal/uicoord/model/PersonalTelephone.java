package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Data
public class PersonalTelephone {

    @NotNull
    @ValidateEnum(enumClass = Type.class)
    private String type;

    @NotBlank
    @Pattern(regexp = "^0\\d{10,14}$", flags=Pattern.Flag.CASE_INSENSITIVE ,message = "Badly formed phone number")
    private String number;

    public enum Type implements ValuedEnum {
        HOME,
        WORK,
        MOBILE;

        @Override
        public String value() {
            return name();
        }
    }
}
