package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.HardscoreDecision;
import com.natwest.pbbdhb.cases.dto.HardscoreDecisionDto;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface HardscoreDecisionMapper {

    @Mapping(target = ".", source = "data.hardscoreDecision")
    @Mapping(target = "additionalDetails.postRetirement", ignore = true)
    @Mapping(target = "kycMessages", ignore = true)
    @Mapping(target = "packaging", ignore = true)
    HardscoreDecisionDto toHardscoreDecisionDto(FullMortgageApplicationExtendedResponse fmaResponse);

    @Mapping(target = "additionalDetails.postRetirement", ignore = true)
    @Mapping(target = "additionalDetails.landlordCode", ignore = true)
    @Mapping(target = "kycMessages", ignore = true)
    @Mapping(target = "packaging", ignore = true)
    HardscoreDecisionDto toHardscoreDecisionDto(HardscoreDecision hardscoreDecision);

    HardscoreDecision toHardscoreDecision(HardscoreDecisionDto hardscoreDecisionDto);
}
