package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ValidateAccountRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ValidateAccountRequest;
import org.mapstruct.Mapper;

@Mapper
public abstract class ValidateAccountRequestMapper {
    public abstract ValidateAccountRequestDto toValidateAccountRequestDto(ValidateAccountRequest validateAccountRequest);
}