package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PaymentUrlRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PaymentUrlResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class PaymentUrlClient {

    private final String paymentUrlEndpoint;
    private final RestTemplate restTemplate;

    public PaymentUrlClient(
            @Value("${msvc.worldpay.generate.url}") String paymentUrlEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.paymentUrlEndpoint = paymentUrlEndpoint;
        this.restTemplate = restTemplate;
    }

    public PaymentUrlResponseDto generatePaymentUrl(String brand, PaymentUrlRequestDto paymentUrlRequest) {

        String mortgageReferenceNumber = paymentUrlRequest.getMortgageReferenceNumber();
        log.info("Calling {} to generate payment page URL for mortgageReferenceNumber {}",
              paymentUrlEndpoint, mortgageReferenceNumber);

        try {
            PaymentUrlResponseDto paymentUrlResponseDto = restTemplate.exchange(
                    paymentUrlEndpoint,
                    HttpMethod.POST,
                    new HttpEntity<>(paymentUrlRequest, constructHeadersForJsonRequest(brand)),
                    PaymentUrlResponseDto.class
            ).getBody();
            log.debug("Payment page URL successfully generated for mortgageReferenceNumber {}",
                mortgageReferenceNumber);
            return paymentUrlResponseDto;

        } catch (RestClientException ex) {
              log.warn("A rest client exception occurred while calling {} to generate payment page URL for mortgageReferenceNumber {}: {}",
                  paymentUrlEndpoint, mortgageReferenceNumber, ex.getMessage());
              throw ex;
        } catch (Throwable t) {
              log.warn("An unexpected exception occurred while calling {} to generate payment page URL for mortgageReferenceNumber {}: {}",
                  paymentUrlEndpoint, mortgageReferenceNumber, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
              throw t;
        }

    }
}
