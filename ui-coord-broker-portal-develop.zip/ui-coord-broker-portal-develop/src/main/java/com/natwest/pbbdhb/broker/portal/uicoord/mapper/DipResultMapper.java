package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.AdditionalDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.DecisionInPrinciple;
import com.natwest.pbbdhb.broker.portal.uicoord.system.Clock;
import com.natwest.pbbdhb.cases.dto.AdditionalDetailsDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import lombok.Setter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.DIP_RESULT_DATE_TIME_FORMATTER;

@Mapper()
public abstract class DipResultMapper {

    DateTimeFormatter formatter = DIP_RESULT_DATE_TIME_FORMATTER;

    @Autowired
    @Setter
    protected Clock clock;

    public String newDecisionInPrincipleDateTime() {
        return clock.localNow().format(formatter);
    }

    @Mapping(target = "dateTime", source = "dateTime")
    public abstract DecisionInPrincipleDto toDecisionInPrincipleDtoWithCustomDateTime(DipExtendedResponse dipResponse, String dateTime);

    @Mapping(target = "excessIncome", ignore = true)
    @Mapping(target = "indicativeCost", ignore = true)
    @Mapping(target = "maxLendFigure", ignore = true)
    @Mapping(target = "minRepayment", ignore = true)
    @Mapping(target = "maxRepayment", ignore = true)
    @Mapping(target = "podDecision", ignore = true)
    public abstract DecisionInPrincipleDto toDecisionInPrincipleDto(DecisionInPrinciple dip);

    @Mapping(target = "postRetirement", ignore = true)
    @Mapping(target = "landlordCode", ignore = true)
    public abstract AdditionalDetailsDto toAdditionalDetailsDto(AdditionalDetails additionalDetails);

    @Mapping(target = "landlordCode", ignore = true)
    public abstract AdditionalDetailsDto toAdditionalDetailsDto(com.natwest.pbbdhb.openapi.dip.AdditionalDetails additionalDetails);

    public abstract DecisionInPrinciple toDecisionInPrinciple(DecisionInPrincipleDto dipDto);

    public DecisionInPrinciple toDecisionInPrinciple(List<DecisionInPrincipleDto> decisionInPrinciples) {
        return decisionInPrinciples != null && !decisionInPrinciples.isEmpty() ? toDecisionInPrinciple(decisionInPrinciples.get(0)) : null;
    }

    public List<DecisionInPrincipleDto> toDecisionInPrinciples(DecisionInPrinciple decisionInPrinciple) {
        return decisionInPrinciple == null ? null : Collections.singletonList(toDecisionInPrincipleDto(decisionInPrinciple));
    }
}
