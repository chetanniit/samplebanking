package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisApplicant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EsisApplicantMapper {

    private static final String DEFAULT_NATIONALITY = "GB";

    public ApplicantDto toApplicantDto(EsisApplicant esisApplicant, String caseId, boolean mainApplicant) {
        final PersonDetailsDto personDetailsDto = PersonDetailsDto.builder()
                .title(esisApplicant.getTitle().toUpperCase())
                .otherTitle(esisApplicant.getOtherTitle())
                .firstNames(esisApplicant.getFirstNames())
                .middleNames(esisApplicant.getMiddleNames())
                .lastName(esisApplicant.getLastName())
                .dateOfBirth(esisApplicant.getDateOfBirth())
                .nationality(DEFAULT_NATIONALITY)
                .build();
        return ApplicantDto.builder()
                .caseId(caseId)
                .mainApplicant(mainApplicant)
                .consentToDIP(false)
                .consentToFMA(false)
                .personalDetails(personDetailsDto)
                .build();
    }

}
