package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PercentageFeeRequestDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface ProcFeeMapper {

  @Mapping(target="paymentPathScale", source="paymentPathScale")
  PercentageFeeRequestDto toPercentageFeeRequestDto(String paymentPathScale);
}
