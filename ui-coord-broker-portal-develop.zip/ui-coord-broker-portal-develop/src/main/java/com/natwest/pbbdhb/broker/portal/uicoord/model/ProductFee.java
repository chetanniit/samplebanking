package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

@Data
public class ProductFee {

    private String code;

    private String type;

    private Double amount;
}
