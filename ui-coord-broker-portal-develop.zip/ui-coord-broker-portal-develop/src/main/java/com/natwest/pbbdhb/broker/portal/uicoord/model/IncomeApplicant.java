package com.natwest.pbbdhb.broker.portal.uicoord.model;

import java.util.List;
import java.util.Map;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class IncomeApplicant {

  @NotNull
  private String applicantId;

  @Valid
  private JobDetails primaryJob;

  @Size(max = 9)
  private List<@Valid JobDetails> additionalJobDetails;

  @Size(max = 9)
  private List<@Valid JobDetails> previousJobDetails;

  @Size(max = 25, min = 1)
  private Map<String, @Valid OtherIncomeDetails> otherIncome;
}
