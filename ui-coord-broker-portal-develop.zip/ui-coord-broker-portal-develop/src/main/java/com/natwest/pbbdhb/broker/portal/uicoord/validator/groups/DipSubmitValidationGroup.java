package com.natwest.pbbdhb.broker.portal.uicoord.validator.groups;

import jakarta.validation.groups.Default;

public interface DipSubmitValidationGroup extends Default {
}
