package com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FirmDto {

  @JsonProperty("mbs_firmid")
  public String firmId;

  @JsonProperty("mbs_firmname")
  public String firmName;

  @JsonProperty("mbs_fcanumber")
  public String fcaNumber;

  @JsonProperty("mbs_principlefcanumber")
  public String principleFcaNumber;

  @JsonProperty("mbs_firmaddress_line1")
  public String firmAddressLine1;

  @JsonProperty("mbs_firmaddress_line2")
  public String firmAddressLine2;

  @JsonProperty("mbs_firmaddress_line3")
  public String firmAddressLine3;

  @JsonProperty("mbs_firmaddress_postcode")
  public String firmAddressPostcode;

  @JsonProperty("mbs_firmaddress_city")
  public String firmAddressCity;

  @JsonProperty("mbs_firmaddress_county")
  public String firmAddressCounty;

  @JsonProperty("mbs_firmaddress_country")
  public String firmAddressCountry;

  @JsonProperty("mbs_statusdate")
  public String statusDate;
}
