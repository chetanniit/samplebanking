package com.natwest.pbbdhb.broker.portal.uicoord.client;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcResponse;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class ProductValidationClient {

  private final String productValidationEndpoint;
  private final RestTemplate restTemplate;
  private final ObjectMapper objectMapper;

  public ProductValidationClient(
      @Value("${msvc.product.validation.url}") String productValidationEndpoint,
      @Qualifier("restTemplateForApiCall") RestTemplate restTemplate,
      @Autowired ObjectMapper objectMapper) {
    this.productValidationEndpoint = productValidationEndpoint;
    this.restTemplate = restTemplate;
    this.objectMapper = objectMapper;
  }

  public ProductValidationMsvcResponse validateProduct(String brand,
      ProductValidationMsvcRequest productValidationMsvcRequest) {
    final String productCode = productValidationMsvcRequest.getProductCode();
    log.info("Execute {}; With productCode: {};", productValidationEndpoint, productCode);

    try {
      return restTemplate.exchange(
          productValidationEndpoint,
          HttpMethod.POST,
          new HttpEntity<>(productValidationMsvcRequest, constructHeadersForJsonRequest(brand)),
          ProductValidationMsvcResponse.class
      ).getBody();
    } catch (HttpClientErrorException.BadRequest ex) {
      // product api returns 400 response for invalid products :(
      // so we need to catch 400 responses and pretend it's 200
      // sample response
      // HTTP/1.1 400 Bad Request
      // {"productCode":"FO38669","validProduct":false,"message":"Validation failed, product has been expired"}
      String responseString = Optional.of(ex.getResponseBodyAsString()).orElse("");
      if (responseString.contains("\"validProduct\"")) {
        try {
          return objectMapper.readValue(ex.getResponseBodyAsString(), ProductValidationMsvcResponse.class);
        } catch (JsonProcessingException e) {
          // ignore and do the // ELSE block below
        }
      }
      // ELSE
      log.warn(
          "HttpClientErrorException.BadRequest caught executing url: {} with product code: {} with error: {}",
          productValidationEndpoint,
          productCode,
          ex.getMessage());
      throw ex;
    } catch (RestClientException ex) {
      log.warn(
          "RestClientException caught executing url: {} with product code: {} with error: {}",
          productValidationEndpoint,
          productCode,
          ex.getMessage());
      throw ex;
    } catch (Throwable t) {
      log.warn(
          "RestClientException caught executing url: {} with product code: {} with error: {}",
          productValidationEndpoint,
          productCode,
          t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
      throw t;
    }
  }
}
