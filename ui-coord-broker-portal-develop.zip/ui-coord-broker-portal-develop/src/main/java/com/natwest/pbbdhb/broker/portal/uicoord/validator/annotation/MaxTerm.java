package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.MaxTermValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Repeatable(MaxTerms.class)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {MaxTermValidator.class})
public @interface MaxTerm {

    String message() default "'{monthField}' value cannot be greater than {monthMaxValue} when '{yearField}' equals {yearValue}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String yearField();
    int yearValue();
    String monthField();
    int monthMaxValue();
}
