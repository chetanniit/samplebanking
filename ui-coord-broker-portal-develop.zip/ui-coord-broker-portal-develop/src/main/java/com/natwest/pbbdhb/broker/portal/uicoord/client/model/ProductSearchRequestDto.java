package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductSearchRequestDto {

    private BigDecimal mortgageAmount;

    private BigDecimal propertyValue;

    private String productSearchDate;

    // NOTE: I don't see 'channel' in the swagger docs (2023-02-23)
    private final String channel = "INTERMEDIARY";

    private String repaymentType;

    private BigDecimal capitalAndInterestAmount;

    private BigDecimal interestOnlyAmount;

    private String applicationType;

    private final String customerType = "NEW_CUSTOMER";

    private String mortgageType;

    private Double ltv;

    private Integer customerPreferredTermYears;

    private Integer customerPreferredTermMonths;

    private boolean greenMortgage;
}
