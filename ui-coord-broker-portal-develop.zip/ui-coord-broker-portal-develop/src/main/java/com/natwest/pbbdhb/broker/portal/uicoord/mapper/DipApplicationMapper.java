package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.applicant.dto.PersonTelephoneDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

import static java.util.Objects.isNull;

@Component
public class DipApplicationMapper {
    @Value("${client.id}")
    private String clientId;

    @Value("${use.galileo.stub}")
    private Boolean useGalileoStub;

    public Application toDipApplication(String brand, CaseApplicationDto caseApplicationDto, List<ApplicantDto> applicantDtoList, PropertyDetailsDto propertyDetailsDto, ValidatedCaseIncomeDto validatedCaseIncomeDto, ValidatedCaseExpenseDto validatedCaseExpenseDto) {

        if (caseApplicationDto != null && applicantDtoList.size() > 0) {
            ApplicantDto applicant0Dto = applicantDtoList.get(0);

            if (applicant0Dto != null && applicant0Dto.getPersonalDetails() != null) {
                PersonDetailsDto personDetailsDto = applicant0Dto.getPersonalDetails();

                //TEMP: To support testing, as telephone number is not captured at DIP level and galileo stubbing uses
                // this number to return a stubbed response
                if (Boolean.TRUE.equals(useGalileoStub) && isNull(personDetailsDto.getTelephones())) {
                    personDetailsDto.setTelephones(Collections.singletonList(PersonTelephoneDto.builder()
                            .type("WORK")
                            .number("08455240822")
                            .preferred(true)
                            .build()));
                }
            }
        }

        return Application.builder()
                .clientId(clientId)
                .brand(brand)
                .caseApplication(caseApplicationDto)
                .applicants(applicantDtoList)
                .propertyDetails(propertyDetailsDto)
                .income(validatedCaseIncomeDto)
                .expenditure(validatedCaseExpenseDto)
                .build();
    }
}
