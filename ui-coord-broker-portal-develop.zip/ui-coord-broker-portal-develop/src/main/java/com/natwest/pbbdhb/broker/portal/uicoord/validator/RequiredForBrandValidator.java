package com.natwest.pbbdhb.broker.portal.uicoord.validator;


import com.natwest.pbbdhb.broker.portal.uicoord.brand.BrandContextHolder;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

import java.util.Arrays;
import java.util.Objects;

public class RequiredForBrandValidator implements ConstraintValidator<RequiredForBrand, Object> {
    private String message;
    private String[] brands;

    @Override
    public void initialize(RequiredForBrand annotation) {
        message = annotation.message();
        brands = annotation.value();

    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (!Arrays.stream(brands).toList().contains(BrandContextHolder.getCurrentBrand())) {
            return true;
        }
        if (Objects.nonNull(value)) {
            if (value instanceof String && StringUtils.isBlank((String) value)) {
                updateContext(context);
                return false;
            } else {
                return true;
            }
        } else {
            updateContext(context);
            return false;
        }

    }

    protected void updateContext(ConstraintValidatorContext context) {
        HibernateConstraintValidatorContext hibernateContext = context.unwrap(HibernateConstraintValidatorContext.class);
        hibernateContext.addExpressionVariable("brandNames", String.join(", ", brands)).buildConstraintViolationWithTemplate(message).enableExpressionLanguage().addConstraintViolation();
    }
}
