package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
public class BureauCallApplicantDto {

    private String firstNames;

    private String lastName;

    private String dateOfBirth;

    private List<BureauCallAddressDto> addresses;

    public BureauCallApplicantDto(ApplicantDto applicantDto) {
        this.firstNames = applicantDto.getPersonalDetails().getFirstNames();
        this.lastName = applicantDto.getPersonalDetails().getLastName();
        this.dateOfBirth = applicantDto.getPersonalDetails().getDateOfBirth();
        this.addresses = applicantDto.getAddresses().stream()
            .map(BureauCallAddressDto::new)
            .collect(Collectors.toList());
    }

}
