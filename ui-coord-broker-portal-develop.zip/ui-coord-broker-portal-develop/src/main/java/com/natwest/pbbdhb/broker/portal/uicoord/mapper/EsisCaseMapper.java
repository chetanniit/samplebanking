package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.FirmDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisBorrowingRequirements;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisCaseDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails;
import com.natwest.pbbdhb.cases.dto.*;
import com.natwest.pbbdhb.commondictionaries.enums.cases.MortgageAdvised;
import com.rbs.pbbdhb.sales.esis.models.enums.Channel;
import com.rbs.pbbdhb.sales.esis.models.enums.MortgageType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Objects;

import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.HELP_TO_BUY_SHARED_EQUITY;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.OTHER;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.RIGHT_TO_BUY;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails.SchemeType.SHARED_EQUITY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerClaimsUtil.getPaymentPathById;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerClaimsUtil.getPaymentPathScale;
import static com.natwest.pbbdhb.commondictionaries.enums.cases.BuyerType.NEW_CUSTOMER;
import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.FIRST_TIME_BUYER;
import static java.util.Collections.singletonList;
import static java.util.Optional.ofNullable;

@Slf4j
@Component
public class EsisCaseMapper {

  private static final String SCHEME_TYPE_OTHER = "OTHER";
  private static final String SCHEME_NAME_OTHER = "OTHER";
  private static final String SCHEME_TYPE_HELP_TO_BUY = "HELP_TO_BUY";
  private static final String SCHEME_NAME_RIGHT_TO_BUY = "RIGHT_TO_BUY";

  private final EsisProductMapper esisProductMapper;

  @Autowired
  public EsisCaseMapper(EsisProductMapper esisProductMapper) {
    this.esisProductMapper = esisProductMapper;
  }

  public CaseApplicationDto toCaseApplicationDto(EsisData esisData, BrokerInfo broker,
      String caseId) {
    final EsisBorrowingRequirements borrowingRequirements = esisData.getBorrowingRequirements();
    final EsisCaseDetails caseDetails = esisData.getCaseDetails();
    final EsisMortgageDetails mortgageDetails = esisData.getMortgageDetails();
    final String paymentPathId = esisData.getCaseDetails().getPaymentPathId();
    final PaymentPath selectedPaymentPath = getPaymentPathById(broker, paymentPathId);
    if (selectedPaymentPath == null) {
      throw new IllegalStateException(
          "No payment path with id " + paymentPathId + " in broker data!");
    }

    final MortgageDto mortgageDto = MortgageDto.builder()
        .propertyValue(borrowingRequirements.getPropertyValue().longValue())
        .purchasePrice(ofNullable(borrowingRequirements.getPurchasePrice())
            .map(BigDecimal::longValue)
            .orElse(null))
        .mortgageAmount(borrowingRequirements.getMortgageAmount().longValue())
        .mortgageTermYears(mortgageDetails.getRepaymentDetails().getTermYears())
        .mortgageTermMonths(mortgageDetails.getRepaymentDetails().getTermMonths())
        .mortgageType(mapMortgageType(mortgageDetails.getRepaymentDetails().getRepaymentType()))
        .mortgageAdvised(mortgageAdvised(caseDetails.getReviewType()))
        .rightToBuy(RIGHT_TO_BUY.value().equals(esisData.getMortgageDetails().getSchemeType())
            ? true
            : null)
        .build();
    final SalesIllustrationDto salesIllustrationDto = SalesIllustrationDto.builder()
        .products(singletonList(
            esisProductMapper.mapToProductDetailsDto(esisData.getSelectedProduct(), esisData)))
        .build();
    // firmName should use tradingName but, I've spotted 52 brokers without trading name set using prod this week
    // so we will fallback to firmName when tradingName is null
    final String firmName = ofNullable(broker.getFirmDetails())
        .map(FirmDetails::getTradingName)
        .orElse(ofNullable(broker.getFirmDetails())
            .map(FirmDetails::getFirmName)
            .orElse(null));
    return CaseApplicationDto.builder()
        .caseId(caseId)
        .applicationType(caseDetails.getApplicationType())
        .isEsis(true)
        .loanPurpose(toCapieLoanPurpose(caseDetails.getLoanPurpose()))
        .channel(Channel.INTERMEDIARY_NAPOLI.name())
        .buyerType(esisData.getCaseDetails().getLoanPurpose()
            .equals(EsisCaseDetails.LoanPurpose.PURCHASE.value()) && mortgageDetails
            .getFirstTimeBuyer()
            ? FIRST_TIME_BUYER.name()
            : NEW_CUSTOMER.name())
        .govtSharedEquityScheme(govtSharedEquityScheme(esisData.getMortgageDetails()
            .getSchemeType()))  // shared equity not supported, only help to buy is
        .mainResidence(true)
        .mortgage(mortgageDto)
        .salesIllustrations(singletonList(salesIllustrationDto))
        .broker(BrokerDto.builder()
            .brokerUsername(broker.getBrokerDetails().getUserName())
            .firmName(firmName)
            .firmAddressLine1(broker.getFirmDetails().getAddress().getLine1())
            .firmAddressLine2(broker.getFirmDetails().getAddress().getLine2())
            .firmAddressLine3(broker.getFirmDetails().getAddress().getLine3())
            .firmPostcode(broker.getFirmDetails().getAddress().getPostcode())
            .brokerTelephoneNumber(ofNullable(
                broker.getBrokerDetails().getMobilePhone()) // mobilePhone then businessPhone
                .orElse(broker.getBrokerDetails().getOtherPhone()))
            .details(BrokerDetailsDto.builder()
                .fee(BrokerFeeDto.builder()
                    .amount(caseDetails.getBrokerFee())
                    .build())
                .build()
            )
            .paymentPath(PaymentPathDto.builder()
                .name(selectedPaymentPath.getPaymentPathName())
                .scale(getPaymentPathScale(selectedPaymentPath,
                    esisData.getCaseDetails().getApplicationType()))
                .build())
            .build())
        .schemeType(schemeType(esisData.getMortgageDetails().getSchemeType()))
        .schemeName(schemeName(esisData.getMortgageDetails().getSchemeType()))
        .build();
  }

  private Boolean govtSharedEquityScheme(String schemeType) {
    return SHARED_EQUITY.value().equals(schemeType)
        || HELP_TO_BUY_SHARED_EQUITY.value().equals(schemeType);
  }

  private String schemeType(String schemeType) {
    if (HELP_TO_BUY_SHARED_EQUITY.value().equals(schemeType)) {
      return SCHEME_TYPE_HELP_TO_BUY;
    }
    if (OTHER.value().equals(schemeType)
        || RIGHT_TO_BUY.value().equals(schemeType)) {
      return SCHEME_TYPE_OTHER;
    }
    return null;
  }

  private String schemeName(String schemeType) {
    if (OTHER.value().equals(schemeType)) {
      return SCHEME_NAME_OTHER;
    }
    if (RIGHT_TO_BUY.value().equals(schemeType)) {
      return SCHEME_NAME_RIGHT_TO_BUY;
    }
    return null;
  }

  private String mortgageAdvised(String reviewType) {
    final EsisCaseDetails.MortgageAdvised mortgageAdvised = EnumUtils.getEnum(
        EsisCaseDetails.MortgageAdvised.class,
        reviewType,
        null);
    if (mortgageAdvised == null) {
      return null;
    }
    if (mortgageAdvised == EsisCaseDetails.MortgageAdvised.ADVISED) {
      return MortgageAdvised.ADVICE.toString();
    }
    return MortgageAdvised.REJECTED_ADVICE_EXECUTION_ONLY.toString();
  }

  private String toCapieLoanPurpose(String loanPurpose) {
    EsisCaseDetails.LoanPurpose esisLoanPurpose = EnumUtils
        .getEnum(EsisCaseDetails.LoanPurpose.class, loanPurpose, null);
    if (esisLoanPurpose == null) {
      return null;
    }
    switch (esisLoanPurpose) {
      case PURCHASE:
        return CaseApplication.LoanPurpose.HOUSE_PURCHASE.value();
      case REMORTGAGE:
        return CaseApplication.LoanPurpose.REMORTGAGE.value();
      default:
        return null;
    }
  }

  private String mapMortgageType(String repaymentTypeValue) {
    MortgageType mortgageType = EnumUtils
        .getEnumIgnoreCase(MortgageType.class, repaymentTypeValue, null);
    return ofNullable(mortgageType)
        .map(Objects::toString)
        .orElse(null);
  }
}
