package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisDocumentDescription;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.EsisService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_INVALID_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_VALID_REGEX;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_ESIS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_ESIS_DOC_INFO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_GET_ESIS_WITH_CASE_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_SAVE_ESIS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_UPDATE_ESIS_DOC_DESCRIPTION;

@RestController
@Tag(name = "ESIS", description = "Esis API for generation of ESIS documents")
@Validated
@Slf4j
@RequiredArgsConstructor
public class EsisController {

    private static final String DOCUMENT_NAME = "documentName";

    private final EsisService esisService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "getEsisDocument",
            summary = "Load previously generated ESIS document",
            tags = "ESIS")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful retrieval of ESIS document", content = @Content(mediaType = MediaType.APPLICATION_PDF_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(
            value = PATH_GET_ESIS,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<InputStreamResource> getEsisDocument(@Parameter(name = DOCUMENT_NAME, description = DOCUMENT_NAME, required = true)
                                                               @PathVariable final String documentName) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to get ESIS document with document name {} and brokerUsername {}", documentName,
          brokerUsername);
        InputStreamResource esisDocumentResource = esisService.getEsisDocument(documentName);
        log.info("ESIS document with name {} and brokerUsername {} successfully retrieved", documentName,
            brokerUsername);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(esisDocumentResource);
    }

    @Operation(
            operationId = "getEsisDocumentWithCaseId",
            summary = "Load previously generated ESIS document using a case id",
            tags = "ESIS")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful retrieval of ESIS document", content = @Content(mediaType = MediaType.APPLICATION_PDF_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(
            value = PATH_GET_ESIS_WITH_CASE_ID,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<InputStreamResource> getEsisDocumentWithCaseId(
            @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION, required = true)
            @PathVariable final String caseId,
            @Parameter(name = BRAND_HEADER, description = BRAND_HEADER, required = true)
            @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to get ESIS document with caseId {} and brokerUsername {}", caseId,
            brokerUsername);
        InputStreamResource esisDocumentResource = esisService.getEsisDocumentWithCaseId(brand, caseId);
        log.info("ESIS document with caseId {} and brokerUsername {} successfully retrieved", caseId,
            brokerUsername);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(esisDocumentResource);
    }

    @Operation(
            operationId = "getEsisDocumentInfo",
            summary = "Load ESIS document info using a case id",
            tags = "ESIS")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful retrieval of ESIS document information", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(
            value = PATH_GET_ESIS_DOC_INFO,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<EsisResponse> getEsisDocumentInfoWithCaseId(
            @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION, required = true)
            @PathVariable final String caseId,
            @Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
            @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
            @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand) {
        log.info("Request to get ESIS document info with case id {}, brand {}, and brokerUsername {}", caseId, brand, userClaimsProvider.getBrokerUsername());
        EsisResponse esisResponse = esisService.getEsisDocumentInfoWithCaseId(brand, caseId);
        log.info("ESIS document info for caseId {} and brokerUsername {} successfully retrieved", caseId, userClaimsProvider.getBrokerUsername());
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(esisResponse);
    }

    @Operation(
            operationId = "createEsisDocument",
            summary = "Generate new ESIS document",
            tags = "ESIS")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful creation of ESIS document", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping(
            value = PATH_SAVE_ESIS,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<EsisResponse> createEsisDocument(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                           @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                           @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                           @RequestBody @Valid final EsisData esisData) {
        final String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to generate ESIS with brokerUsername {}", brokerUsername);
        final EsisResponse esisResponse = esisService.createEsisDocument(esisData, brokerUsername, brand);
        log.info("ESIS document with name {}, caseId {}, and brokerUsername {} successfully created",
            esisResponse.getDocumentName(), esisResponse.getCaseId(), brokerUsername);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(esisResponse);
    }

    @Operation(
            operationId = "submitDocumentDescription",
            summary = "Submit ESIS document description for a given case",
            tags = "ESIS")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful sumbission of ESIS document description", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping(
            value = PATH_UPDATE_ESIS_DOC_DESCRIPTION,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<EsisResponse> submitDocumentDescription(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                                             @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                                             @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                                             @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION, required = true)
                                                                             @PathVariable final String caseId,
                                                                             @RequestBody @Valid final EsisDocumentDescription esisDocumentDescription) {
        log.info("Request to submit document description for case id {}", caseId);
        EsisResponse response = esisService.updateDocumentDescription(esisDocumentDescription.getDocumentDescription(), brand, caseId);
        log.info("Successfully updated document description for case id {}", caseId);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(response);
    }
}
