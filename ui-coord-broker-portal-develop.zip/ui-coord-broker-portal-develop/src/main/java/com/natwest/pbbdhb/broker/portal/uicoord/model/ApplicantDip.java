package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.VersionRequired;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
@VersionRequired
// TODO: add validation - if hasDependants == false, numberOfDependantsOver18 and numberOfDependantsUnder18 must both be 0 or null.
// TODO: add validation - if hasDependants == true, numberOfDependantsOver18 > 0 or numberOfDependantsUnder18 > 0, and neither is null.
public class ApplicantDip implements Versionable {

    private String applicantId;

    private String version;

    @NotNull
    private Boolean mainApplicant;

    @NotNull
    @AssertTrue
    private Boolean consentToDIP;

    @AssertTrue
    private Boolean consentToFMA;

    @Min(value = 18)
    @Max(value = 99)
    private Integer intendedRetirementAge;

    @NotNull
    @Valid
    private CreditHistoryDip creditHistory;
    
    @Valid
    private PersonalDetailsDip personalDetails;

    private List<@Valid PersonalAddressDip> addresses;

    private Boolean bankWithNatWest;

    private MarketingPreferences marketingPreferences;

    private List<@Valid ExistingMortgageDip> existingMortgages;

    @Override
    @JsonIgnore
    public String getId() {
        return this.applicantId;
    }
}
