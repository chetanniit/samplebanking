package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;

public interface BrokerCaseService {

    /**
     * Save the provided broker case. [Deprecated: use createBrokerCase or updateBrokerCase instead]
     * @param brand         which business division is being used - allows for multi-tenant system
     * @param caseId        the ID of the case
     * @param brokerCase    the {@link BrokerCase} to save
     * @return the {@link BrokerCase} with saved details
     */
    BrokerCase saveBrokerCase(String brand, String caseId, BrokerCase brokerCase);

    /**
     * Create a new broker case with the provided data.
     * @param brand         which business division is being used - allows for multi-tenant system
     * @param caseId        the ID of the case
     * @param brokerCase    the {@link BrokerCase} to save
     * @return the {@link BrokerCase} with saved details
     */
    BrokerCase createBrokerCase(String brand, String caseId, BrokerCase brokerCase);

    /**
     * Update the stored broker case with the provided data.
     * @param brand         which business division is being used - allows for multi-tenant system
     * @param caseId        the ID of the case
     * @param brokerCase    the {@link BrokerCase} to save
     * @return the {@link BrokerCase} with saved details
     */
    BrokerCase updateBrokerCase(String brand, String caseId, BrokerCase brokerCase);

    /**
     * Retrieve the stored broker case
     * @param brand         which business division is being used - allows for multi-tenant system
     * @param caseId        the ID of the case
     * @return the current {@link BrokerCase} details
     */
    BrokerCase getBrokerCase(String brand, String caseId);

    /**
     * Retrieve the stored broker case, without applying access permission checks
     * @param brand         which business division is being used - allows for multi-tenant system
     * @param caseId        the ID of the case
     * @return the current {@link BrokerCase} details
     */
    BrokerCase getBrokerCaseInternal(String brand, String caseId);

    BrokerCase dipResultClear(String brand, String caseId);
}
