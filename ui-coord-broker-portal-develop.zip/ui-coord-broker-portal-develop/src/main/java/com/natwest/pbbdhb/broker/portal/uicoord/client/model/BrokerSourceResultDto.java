package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import lombok.Data;

@Data
public class BrokerSourceResultDto {

    private String source1;

    private String source2;
}
