package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Data
public class SolicitorAddress {

    private String address1;

    private String address2;

    private String address3;

    @NotBlank
    @Size(max = 8)
    private String addressPC;
}
