package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisResponse;
import org.springframework.core.io.InputStreamResource;

public interface EsisService {

    InputStreamResource getEsisDocument(String documentName);

    InputStreamResource getEsisDocumentWithCaseId(String brand, String caseId);

    EsisResponse createEsisDocument(EsisData esisData, String username, String brand);

    EsisResponse getEsisDocumentInfoWithCaseId(String brand, String caseId);

    EsisResponse updateDocumentDescription(String documentDescription, String brand, String caseId);
}
