package com.natwest.pbbdhb.broker.portal.uicoord.util;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import lombok.NonNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class DipResultUtil {

    public static final DateTimeFormatter DIP_RESULT_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // prevent instantiation
    private DipResultUtil() {
    }

    public static boolean hasDipResult(@NonNull CaseApplicationDto caseApplicationDto) {
        return getDipResult(caseApplicationDto) != null;
    }

    public static boolean hasUnexpiredDip(@NonNull CaseApplicationDto caseApplicationDto) {
        return hasUnexpiredDip(caseApplicationDto, LocalDate.now());
    }

    public static boolean hasUnexpiredDip(@NonNull CaseApplicationDto caseApplicationDto,LocalDateTime dateTime) {
        return hasUnexpiredDip(caseApplicationDto, dateTime.toLocalDate());
    }

    protected static boolean hasUnexpiredDip(@NonNull CaseApplicationDto caseApplicationDto, LocalDate today) {
        DecisionInPrincipleDto dipResult = getDipResult(caseApplicationDto);

        if (dipResult == null) {
            return false;
        }

        return isDipUnexpired(dipResult, today);
    }

    private static DecisionInPrincipleDto getDipResult(@NonNull CaseApplicationDto caseApplicationDto) {
        List<DecisionInPrincipleDto> dipResults = caseApplicationDto.getDecisionInPrinciples();
        if (dipResults == null || dipResults.isEmpty()) {
            return null;
        }

        return dipResults.get(0);
    }

    private static boolean isDipUnexpired(DecisionInPrincipleDto dipResult, LocalDate today) {
        String dipDateTimeString = dipResult.getDateTime();

        // treat missing date-time as expired
        if (dipDateTimeString == null || dipDateTimeString.trim().isEmpty()) {
            return false;
        }

        LocalDateTime dipDateTime = LocalDateTime.parse(dipDateTimeString.trim(), DIP_RESULT_DATE_TIME_FORMATTER);

        // DIP submitted on 01/05, valid until 30/05, invalid from 31/05
        LocalDate expiryDate = dipDateTime.toLocalDate().plusDays(29); // removes time part


        return (today.isEqual(expiryDate) || today.isBefore(expiryDate));
    }
}
