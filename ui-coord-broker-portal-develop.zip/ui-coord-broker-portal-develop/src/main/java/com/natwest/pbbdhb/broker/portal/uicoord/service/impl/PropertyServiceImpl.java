package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.PropertyClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.PropertyDetailsMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PropertyDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.service.PropertyService;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PropertyServiceImpl implements PropertyService {

    private final PropertyClientNapoli propertyClient;
    private final PropertyDetailsMapper propertyDetailsMapper;

    @Override
    public PropertyDetails saveProperty(String brand, String caseId, PropertyDetails property) {

        PropertyDetailsDto propertyDetailsDtoToSend = this.propertyDetailsMapper.toPropertyDetailsDto(caseId, property, false);

        String version = property.getVersion();
        log.debug("Calling propertyClient to save property with version {} for caseId {}", version, caseId);
        PropertyDetailsDto propertyDetailsDtoResponse = this.propertyClient.saveProperty(brand, propertyDetailsDtoToSend);
        log.debug("propertyClient successfully called to save property with version {} for caseId {}", version, caseId);
        return this.propertyDetailsMapper.toPropertyDetails(propertyDetailsDtoResponse);
    }

    @Override
    public PropertyDetails saveProperty(String brand, String caseId, PropertyDetails property, boolean isScottishApplication, boolean isBuyToLet) {

        PropertyDetailsDto propertyDetailsDtoToSend = this.propertyDetailsMapper.toPropertyDetailsDto(caseId, property, isBuyToLet);
        String version = property.getVersion();

        if (property.getNewBuild() != null && property.getNewBuild()) {
            log.debug("Property for caseId {} is a new build", caseId);
            propertyDetailsDtoToSend.setWhenBuilt(LocalDate.now().getYear() + "-01-01");
            propertyDetailsDtoToSend.setRefurbishedDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }

        log.debug("Calling propertyClient to save property with version {} for caseId {}", version, caseId);
        PropertyDetailsDto propertyDetailsDtoResponse = this.propertyClient.saveProperty(brand, propertyDetailsDtoToSend);
        log.debug("propertyClient successfully called to save property with version {} for caseId {}", version, caseId);
        return this.propertyDetailsMapper.toPropertyDetails(propertyDetailsDtoResponse);
    }

    @Override
    public PropertyDetails getProperty(String brand, String caseId) {
        log.debug("Calling propertyClient to get property for caseId {}", caseId);
        PropertyDetailsDto propertyDetailsDto = this.propertyClient.getProperty(brand, caseId);
        log.debug("propertyClient successfully called to get property for caseId {}", caseId);
        return this.propertyDetailsMapper.toPropertyDetails(propertyDetailsDto);
    }
}
