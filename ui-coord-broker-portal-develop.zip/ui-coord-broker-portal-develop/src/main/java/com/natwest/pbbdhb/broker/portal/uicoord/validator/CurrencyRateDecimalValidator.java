package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidDecimal;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

public class CurrencyRateDecimalValidator implements ConstraintValidator<ValidDecimal, BigDecimal> {

  public static final String PATTERN = "\\d+(\\.\\d{1,2})?";
  @Override
  public void initialize(ValidDecimal validDecimal) {
    //Do nothing comment to pass Sonar
  }

  @Override
  public boolean isValid(BigDecimal bigDecimal,
      ConstraintValidatorContext context) {
    if(bigDecimal == null){
        return true;
    }
    String valueStr = bigDecimal.toString();

    return valueStr.matches(PATTERN);
  }
}

