package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipUnhandledValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.DipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpServerErrorException;

import jakarta.validation.constraints.Pattern;

import java.nio.charset.StandardCharsets;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;


@RestController
@Tag(name = "DIP", description = "Decision in Principle API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class DipController {

    private final DipService dipService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "submitDip",
            summary = "Submit a Decision in Principle application",
            tags = "DIP"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful submission of DIP application", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request: handled validation exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ValidationResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error: unexpected exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PostMapping(value = PATH_SUBMIT_DIP, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BrokerCase> submitDip(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                     @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                     @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                     @PathVariable final String caseId) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to submit DIP with caseId {} and brokerUsername {}", caseId,
            brokerUsername);
        try {
            BrokerCase brokerCase = dipService.submitDip(brand, caseId);
            log.info("DIP for caseId {} and brokerUsername {} successfully submitted", caseId,
                brokerUsername);
            return ResponseEntity.ok(brokerCase);
        } catch (DipIntegrationException ex) {
            log.error("Error submitting DIP for caseId {} and brokerUsername {}: {}", caseId, brokerUsername, ex.getMessage());
            throw HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), new HttpHeaders(), ex.getMessage().getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        }
    }

    @Operation(
            operationId = "getDipCertificateWithCaseId",
            summary = "Get the Decision in Principle certificate for the given case ID",
            tags = "DIP"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "DIP certificate successfully downloaded", content = @Content(mediaType = MediaType.APPLICATION_PDF_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request: handled validation exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ValidationResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error: unexpected exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
     })
    @GetMapping(value = PATH_GET_DIP_WITH_CASE_ID, produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> getDipCertificateWithCaseId(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                                           @Parameter(name = DIP_ID_PARAM, description = DIP_ID_DESCRIPTION)
                                                @PathVariable final String dipId)
        throws DipIntegrationException {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to get DIP certificate with dipId {} and brokerUsername {}", dipId,
          brokerUsername);
        try {
            InputStreamResource dipDocumentResource = dipService.getDipCertificateWithCaseId(brand, dipId);
            log.info("DIP certificate with dipId {} and brokerUsername {} successfully retrieved", dipId,
                brokerUsername);
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(dipDocumentResource);
        } catch (DipIntegrationException ex) {
            String message = ex.getMessage();
            if (message.contains("DIP has expired, create a new DIP")) {
                log.info("Unable to retrieve DIP certificate for dipId {} and brokerUsername {}, due "
                    + "to DIP being expired, please redo DIP: {}", dipId, brokerUsername, message);
                throw new DipUnhandledValidationException(ErrorCode.VALIDATION_EXPIRED_DIP, ErrorCode.VALIDATION_EXPIRED_DIP.getExternalMessage());
            }
            log.error("Unable to retrieve DIP certificate for dipId {} and brokerUsername {}, due "
                + "to internal Server error: {}", dipId, brokerUsername, message);
            throw ex;
        }
    }

    @Operation(
        operationId = "getDipCertificateByDipId",
        summary = "Get the Decision in Principle certificate for the given case ID",
        tags = "DIP"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "DIP certificate successfully downloaded", content = @Content(mediaType = MediaType.APPLICATION_PDF_VALUE)),
        @ApiResponse(responseCode = "400", description = "Bad request: handled validation exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ValidationResponse.class))),
        @ApiResponse(responseCode = "404", description = "Not found: DIP document not found exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal Server Error: unexpected exception", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
    })
    @GetMapping(value = PATH_GET_DIP_DOCUMENT_BY_CASE_ID, produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> getDipDocumentByDipId(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                                        @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                                        @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                                        @Parameter(name = DIP_ID_PARAM, description = DIP_ID_DESCRIPTION)
                                                                        @PathVariable final String dipId) {
      String brokerUsername = userClaimsProvider.getBrokerUsername();
      log.info("Request to get DIP document with dipId {} and brokerUsername {}", dipId,
           brokerUsername);
      try {
        InputStreamResource dipDocumentResource = dipService.getDipDocumentByDipId(brand, dipId);
        log.info("DIP document with dipId {} and brokerUsername {} successfully retrieved", dipId,
            brokerUsername);
        return ResponseEntity.ok()
            .contentType(MediaType.APPLICATION_PDF)
            .body(dipDocumentResource);
      } catch (DipIntegrationException ex) {
          log.error("Error retrieving DIP document for dipId {} and brokerUsername {}: {}", dipId, brokerUsername, ex.getMessage());
          throw HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), new HttpHeaders(), ex.getMessage().getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
      }
    }
}