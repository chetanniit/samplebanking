package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductValidationMsvcRequest {
  private String applicationType;
  private Integer propertyValue;
  private String customerType;
  private Long mortgageAmount;
  private String productCode;
  private String productSearchDate;
  private String mortgageType;
  private String productType;
  private String repaymentType;
  private String productTerm;
  private Integer ltv;
  private Boolean isCashbackProduct;
  private Boolean freeLegal;
  private String jurisdiction;
  private List<ProductValidationFee> fees;

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ProductValidationFee {
    private String code;
    private String type;
    private BigDecimal amount;
  }
}
