package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.VALIDATION_PRODUCT_EXPIRY;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.VALIDATION_PRODUCT_INVALID;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.openapi.fma.Error;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class FmaErrorResultMapper {


  private static Map<String, ErrorCode> mapKeyedOnDownstreamMessage = ErrorCode.getMapKeyedOnDownstreamString();


  public ErrorCode toSingleErrorCode(
      FullMortgageApplicationExtendedResponse fmaResponse,
      String caseId
  ) {

    List<ErrorCode> errorCodes = toErrorCodes(fmaResponse, caseId);

    if (errorCodes.size() == 0) {
      log.warn("No error found in FullMortgageApplicationExtendedResponse to map");
      return ErrorCode.UNHANDLED;
    }

    log.debug("CaseId={}, ErrorCodes mapped={}" , caseId, errorCodes);

    if (errorCodes.size() == 1) {
      return errorCodes.get(0);
    }

    return selectAnyHandledError(errorCodes);

  }

  public List<ErrorCode> toErrorCodes(
      FullMortgageApplicationExtendedResponse fmaResponse, String caseId
  ) {

    if (fmaResponse.getErrors() == null || fmaResponse.getErrors().isEmpty()){
      return Collections.emptyList();
    }

    return fmaResponse.getErrors().stream().map(e -> getErrorCode(e, caseId)).distinct().
        collect(Collectors.toList());
  }

  private ErrorCode getErrorCode(Error fmaError, String caseId) {

    if (fmaError == null) {
      return ErrorCode.UNHANDLED;
    }

    //Check if we have a matching code
    //TODO Match on matching code - needs FMA response to start including some not null;

    //Check if we have a matching string
    Optional<String> foundKey = mapKeyedOnDownstreamMessage.keySet().stream()
        .filter(s -> fmaError.getMessage().contains(s)).findAny();

    if (!foundKey.isPresent()) {
      log.debug("caseID={}, Unhandled fma Validation error. Fma Response Error:  message={}, code={}, status={}",
          caseId, fmaError.getMessage(), fmaError.getCode() == null ? ErrorCode.UNHANDLED : fmaError.getCode(), fmaError.getStatus());
      return ErrorCode.UNHANDLED;
    }

    ErrorCode errorCode = mapKeyedOnDownstreamMessage.get(foundKey.get());

    //Temp fix - UI needs to be updated to handle both - or we need to find a way to match multiple in on error code
    if (VALIDATION_PRODUCT_EXPIRY.equals(errorCode)){
      errorCode = VALIDATION_PRODUCT_INVALID;
    }

    return errorCode;

  }

  private ErrorCode selectAnyHandledError(List<ErrorCode> mappedErrors){
    List<ErrorCode> handledErrors = mappedErrors.stream().filter(c -> !c.equals(ErrorCode.UNHANDLED))
        .collect(
            Collectors.toList());

    return handledErrors.get(0);

  }


}
