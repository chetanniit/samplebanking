package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidDecimal;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import java.math.BigDecimal;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_NWI;

@Data
// TODO: Add validation - if usingSpecialistScheme == false, schemeType must be null
// TODO: Add validation - if usingSpecialistScheme == true, schemeType must NOT be null
public class CaseApplication {

    private String caseId;

    private String version;

    @NotNull
    private String currentRoute;

    @ValidateEnum(enumClass = ApplicationStatus.class)
    private String applicationStatus;

    @ValidateEnum(enumClass = ApplicationType.class)
    private String applicationType;

    @ValidateEnum(enumClass = LoanPurpose.class)
    private String loanPurpose;

    private Boolean firstTimeBuyer;

    private Boolean usingSpecialistScheme;

    @ValidateEnum(enumClass = SchemeType.class)
    private String schemeType;

    private Boolean mainResidence;

    @Valid
    private Mortgage mortgage;

    private Boolean hasDependants;

    @Min(value = 0)
    @Max(value = 99)
    private Integer numberOfDependantsOver18;

    @Min(value = 0)
    @Max(value = 99)
    private Integer numberOfDependantsUnder18;

    private String bpid;

    private Boolean repayMortgageCurrencyNotSterling;

    @Pattern(regexp = "^[A-Z]{3}$", message = "Badly formed currency code")
    private String repayMortgageCurrency;

    @ValidDecimal
    private BigDecimal currencyExchangeRate;

    private Boolean scottishApplication;

    private Boolean northernIrelandApplication;

    @ValidateEnum(enumClass = TranscriptValuer.class)
    private String transcriptValuer;

    private String transcriptValuationDate;

    @Valid
    private EstateAgent estateAgent;

    @Valid
    private ServiceLevel serviceLevel;

    @Valid
    private Solicitor solicitor;

    @Valid
    private Broker broker;

    @Valid
    private ProductDetails productDetails;

    private DecisionInPrinciple decisionInPrinciple;

    private HardscoreDecision hardscoreDecision;

    private String mortgageReferenceNumber;

    private String mortgageTempReferenceNumber;

    private String mortgageApplSeq;

    private List<String> repaymentStrategyAddresses;

    private String mafDocumentName;

    // When true, locks 'About the Case' fields section
    // Stored in journey data because we clear DIP values in 'Return to AIP' feature
    private Boolean hasCompletedDip;

    // boolean required to handle ground rent/service charge checks
    private Boolean leaseholdOwnershipTerm;

    @Valid
    private DirectDebitDetails directDebit;

    private Boolean isProductSelectedAtDip;

    private Integer brokerJourneyVersion;

  private Boolean epcRatingAOrBDip; // boolean required to store if it's green mortgage on btl dip

  // isProductFeePaymentSelected is required to know if the customer selected fee payment option...
  // in FMA or if it was defaulted at DIP for BTL case
  private Boolean isProductFeePaymentSelected;
    private List<@Valid FinancialCommitment> financialCommitments;

    public enum ApplicationStatus implements ValuedEnum {
        FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS,
        SUBMIT_FMA_IN_PROGRESS,
        SUBMIT_GMS_MOPS,
        SUBMIT_GMS_STAGE_20;

        @Override
        public String value() { return name(); }
    }

    public enum LoanPurpose implements ValuedEnum {
        HOUSE_PURCHASE,
        REMORTGAGE;

        @Override
        public String value() {
            return name();
        }
    }

    public enum SchemeType implements ValuedEnum {
        // NOTE: The list of values is different between CAPIE and the field mapping from PRN-70
        // CAPIE only supports "HELP_TO_BUY" and "OTHER"
        SHARED_EQUITY,  // <-- not supported in CAPIE
        HELP_TO_BUY_SHARED_EQUITY, // <- Napoli version
        // HELP_TO_BUY, // <- CAPIE version
        RIGHT_TO_BUY,  // <-- not supported in CAPIE
        OTHER;

        @Override
        public String value() {
            return name();
        }
    }

    public enum TranscriptValuer implements ValuedEnum {
        ALLIED_SURVEYORS_SCOTLAND_PLC,
        CONNELLS,
        DAVID_ADAMSON_AND_PARTNERS_LTD,
        DIXON_HEANEY_KEAN_KENNEDY,
        D_M_HALL,
        GRAHAM_AND_SIBBALD,
        HARVEY_DONALDSON_AND_GIBSON,
        J_AND_E_SHEPHERD,
        STEPHEN_J_OMAND,
        TORRANCE_PARTNERSHIP,
        VALUNATION,
        WALKER_FRASER_AND_STEELE,
        WHYTE_AND_BARRIE,
        NONE_STANDARD_VALUATION;

        @Override
        public String value() {
            return name();
        }
    }
}
