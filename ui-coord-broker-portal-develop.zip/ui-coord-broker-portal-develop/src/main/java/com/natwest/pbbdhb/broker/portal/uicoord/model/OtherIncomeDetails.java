package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MandatoryBasedOnEnumValue;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_NWI;

@Data
@MandatoryBasedOnEnumValue(MandatoryField = "otherIncomeAmount", EnumField = "sourceOfIncome", EnumValue = "HOUSING_ALLOWANCE")
@MandatoryBasedOnEnumValue(MandatoryField = "otherIncomeFrequency", EnumField = "sourceOfIncome", EnumValue = "HOUSING_ALLOWANCE")
public class OtherIncomeDetails {
    @NotBlank
    @ValidateEnum(enumClass = OtherIncomeDetails.SourceOfIncome.class)
    private String sourceOfIncome;

    private String otherSourceOfIncomeFreeText;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal otherIncomeAmount;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @RequiredForBrand(value = {BRAND_NWI})
    private BigDecimal otherIncomeNetAmount;


    @ValidateEnum(enumClass = OtherIncomeDetails.Frequency.class)
    private String otherIncomeFrequency;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    @RequiredForBrand(value = {BRAND_NWI})
    private String otherIncomeOriginatingCurrency;

    public enum SourceOfIncome implements ValuedEnum {
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_WORKING_FAMILIES_TAX_CREDIT,
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_CHILD_TAX_CREDIT,
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_CHILD_BENEFIT,
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_UNIVERSAL_CREDIT,
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_CARERS_ALLOWANCE,
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_DISABLEMENT_LIVING_ALLOWANCE,
        ACCEPTABLE_INCOME_BANKSTATEMENT_BENEFIT_INCOME_PERSONAL_INDEPENDENT_INCOME,
        ACCEPTABLE_INCOME_BANKSTATEMENT_CHILD_MAINTENANCE,
        ACCEPTABLE_INCOME_BANKSTATEMENT_PRIVATE_PENSION,
        ACCEPTABLE_INCOME_BANKSTATEMENT_STATE_PENSION,
        ACCEPTABLE_INCOME_BANKSTATEMENT_RENTAL_INCOME,
        ACCEPTABLE_INCOME_OTHER_INCOME_OTHER,
        ACCEPTABLE_INCOME_BANKSTATEMENT_DIVIDEND,
        ACCEPTABLE_INCOME_BANKSTATEMENT_INVESTMENT_INCOME,
        ACCEPTABLE_INCOME_BANKSTATEMENT_OTHER_TAXABLE,
        ACCEPTABLE_INCOME_BANKSTATEMENT_OTHER_NON_TAXABLE,
        ACCEPTABLE_INCOME_BANKSTATEMENT_TRUST,
        HOUSING_ALLOWANCE;

        @Override
        public String value() {
            return name();
        }
    }

    public enum Frequency implements ValuedEnum {
        ANNUALLY,
        BIANNUALLY,
        QUARTERLY,
        MONTHLY,
        FOUR_WEEKLY,
        FORTNIGHTLY,
        WEEKLY;

        @Override
        public String value() {
            return name();
        }
    }
}
