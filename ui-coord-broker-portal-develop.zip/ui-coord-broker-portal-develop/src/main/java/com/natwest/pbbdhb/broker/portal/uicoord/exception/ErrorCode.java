package com.natwest.pbbdhb.broker.portal.uicoord.exception;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.NonNull;

public enum ErrorCode {


  VALIDATION_PRODUCT_EXPIRY("VALIDATION_PRODUCT_EXPIRY",
                    "Product range has now updated - please remove and reselect valid product.", "product has been expired"),
  VALIDATION_PRODUCT_INVALID("VALIDATION_PRODUCT_INVALID",
      "Product range has now updated - please remove and reselect valid product.", "Product code"),
  VALIDATION_EXPIRED_DIP("VALIDATION_EXPIRED_DIP",
      "DIP has expired, create a new DIP"),
  INVALID_PAYMENT_PATH("INVALID_PAYMENT_PATH",
      "Payment path invalid. Please reselect the Payment path." ),
  INVALID_LOAN_OUTSTANDING_AMOUNT("INVALID_LOAN_OUTSTANDING_AMOUNT",
      "Loan outstanding amount must be in whole pounds."),
  INVALID_LOAN_CONSOLIDATED_AMOUNT("INVALID_LOAN_CONSOLIDATED_AMOUNT",
      "Loan consolidated amount must be in whole pounds."),
  INVALID_CREDIT_CARD_OUTSTANDING_BALANCE("INVALID_CREDIT_CARD_OUTSTANDING_BALANCE",
      "Credit Card outstanding balance must be in whole pounds."),
  INVALID_CREDIT_CARD_CONSOLIDATED_AMOUNT("INVALID_CREDIT_CARD_CONSOLIDATED_AMOUNT",
      "Credit Card consolidated amount must be in whole pounds."),
  ESTATE_AGENT_LENGTH_EXCEEDED("ESTATE_AGENT_LENGTH_EXCEEDED",
      "Estate agent firm name character limit exceeded, please reduce to a maximum of 45 characters." ),
  INCORRECT_REPAY_MORTGAGE_CURRENCY("INCORRECT_REPAY_MORTGAGE_CURRENCY",
      "Please re-select foreign currency income type",
      "repayMortgageCurrency is required if application.repayMortgageCurrencyNotSterling = true"),
  INVALID_BROKER_TRADING_NAME("INVALID_BROKER_TRADING_NAME",
      "Invalid Trading/Firm Name - Please update your trading name/firm name via the maintain personal details page"),
  NOT_ENOUGH_LANDLORD_EXPERIENCE("NOT_ENOUGH_LANDLORD_EXPERIENCE", "Unfortunately we are unable to proceed with your application - At least one applicant must have at least two years Landlord experience"),
  UNHANDLED("UNHANDLED", "Unhandled Validation Exception"),
  MISSING_EXISTING_MORTGAGES("MISSING_EXISTING_MORTGAGES", "Missing Existing Mortgages Validation Exception", "existingMortgages[] must not be empty");

  private final String value;
  private final String externalMessage;
  private final String downstreamString;

  ErrorCode(@NonNull String value, @NonNull String externalMessage) {
    this.value = value;
    this.externalMessage = externalMessage;
    this.downstreamString = "";
  }

  ErrorCode(@NonNull String value, @NonNull String externalMessage, String downstreamString) {
    this.value = value;
    this.externalMessage = externalMessage;
    this.downstreamString = downstreamString;
  }

  @JsonCreator
  public static ErrorCode fromValue(String text) {
    for (ErrorCode code : ErrorCode.values()) {
      if (code.value.equals(text)) {
        return code;
      }
    }
    throw new IllegalArgumentException("Unsupported error code: " + text);
  }

  @Override
  @JsonValue
  public String toString() {
    return value;
  }

  public String getExternalMessage() {
    return externalMessage;
  }

  String getDownstreamString() {
    return downstreamString;
  }

  public static Map<String , ErrorCode> getMapKeyedOnDownstreamString(){
    return Arrays.stream(ErrorCode.values()).filter(v -> !v.getDownstreamString().isEmpty()).collect(Collectors.toMap(v -> v.downstreamString, v -> v));
  }


}