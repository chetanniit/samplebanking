package com.natwest.pbbdhb.broker.portal.uicoord.service.helper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.CrmTokenResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.config.CrmTokenAuthConfig;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.AccessTokenNotRefreshedException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.security.CertificateModel;
import com.natwest.pbbdhb.broker.portal.uicoord.model.security.JsonWebTokenModel;
import com.natwest.pbbdhb.broker.portal.uicoord.util.JwtSigningUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForApplicationFormUrlEncodedRequest;

@Slf4j
@Component
public class SecurityTokenHelper {

  private static final String GRANT_TYPE = "client_credentials";
  private static final String CLIENT_ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";

  private final RestTemplate restTemplate;
  private final CrmTokenAuthConfig tokenConfig;
  private final CertificateModel certificate;
  private String accessToken;
  private LocalDateTime accessTokenExpires;

  @Autowired
  public SecurityTokenHelper(
      @Qualifier("sslRestTemplate") RestTemplate restTemplate,
      CrmTokenAuthConfig tokenConfig,
      CertificateModel certificate) {
    this.restTemplate = restTemplate;
    this.tokenConfig = tokenConfig;
    this.certificate = certificate;
  }

  public String getAccessToken() {
    if (shouldRefreshAccessToken()) {
      refreshAccessToken();
    }
    return accessToken;
  }

  private void refreshAccessToken() {
    try {
      // create signed JWT
      JsonWebTokenModel jwtModel = JsonWebTokenModel
          .builder()
          .header(JsonWebTokenModel.HeaderModel.builder()
              .algorithm(tokenConfig.getAlgorithm())
              .kid(certificate.getCertificateThumbPrint())
              .x5t(tokenConfig.getX5t())
              .build())
          .payload(JsonWebTokenModel.PayloadModel.builder()
              .issuer(tokenConfig.getClientId())
              .audience(tokenConfig.getAudience())
              .subject(tokenConfig.getClientId())
              .build())
          .build();
      String jwt = JwtSigningUtil.createJwt(jwtModel, certificate.getPrivateKey());

      // create access token request
      final MultiValueMap<String, String> tokenRequest = new LinkedMultiValueMap<>();
      tokenRequest.add("grant_type", GRANT_TYPE);
      tokenRequest.add("client_id", tokenConfig.getClientId());
      tokenRequest.add("tenant", tokenConfig.getTenantId());
      tokenRequest.add("resource", tokenConfig.getResource());
      tokenRequest.add("client_assertion_type", CLIENT_ASSERTION_TYPE);
      tokenRequest.add("client_assertion", jwt);

      // request access token
      ResponseEntity<CrmTokenResponseDto> tokenResponse = restTemplate.postForEntity(
          tokenConfig.getUrl(),
          new HttpEntity<>(tokenRequest, constructHeadersForApplicationFormUrlEncodedRequest()),
          CrmTokenResponseDto.class
      );

      final CrmTokenResponseDto token = Optional
          .ofNullable(tokenResponse.getBody())
          .orElseThrow(() -> {
            log.error(String.format(
                "Retrieving Access Token for request : %s returned an empty payload : %s",
                tokenRequest,
                tokenResponse.getStatusCode()));
            return new AccessTokenNotRefreshedException("Empty access token returned");
          });
      accessToken = token.getAccessToken();
      accessTokenExpires = LocalDateTime.ofEpochSecond(
          Long.parseUnsignedLong(token.getExpiresOn()),
          0,
          ZoneOffset.UTC);
    } catch (RestClientException e) {
      throw new AccessTokenNotRefreshedException(
          "Problem retrieving access token: " + e.getMessage());
    }
  }

  private boolean shouldRefreshAccessToken() {
    return null == accessTokenExpires || null == accessToken || accessTokenExpires.isBefore(LocalDateTime.now(ZoneOffset.UTC).plusMinutes(1));
  }
}
