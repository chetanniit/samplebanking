package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.PersonAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalAddress;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;

@Mapper
public interface PersonalAddressMapper {

    @Mapping(target = "flatNameOrNumber", source = "flat")
    @Mapping(target = "country", source = "countryIsoCode")
    PersonalAddress toPersonalAddress(PersonAddressDto personalAddressDto);

    @Mapping(target = "flat", source = "flatNameOrNumber")
    @Mapping(target = "countryIsoCode", source = "country")
    @Mapping(target = "isCurrentAddress", ignore = true)
    @Mapping(target = "endMonth", ignore = true)
    @Mapping(target = "endYear", ignore = true)
    @Mapping(target = "district", ignore = true)
    @Mapping(target = "ukAddress", expression = "java(personalAddress.getCountry() == null ? null : \"GB\".equals(personalAddress.getCountry()))")
    @Mapping(target = "originalPurchasePrice", source = "occupyStatus", qualifiedByName = "mapOriginalPurchasePrice")
    PersonAddressDto toPersonalAddressDto(PersonalAddress personalAddress);

    @Named("mapOriginalPurchasePrice")
    default BigDecimal mapOriginalPurchasePrice(String occupyStatus) {
        if (PersonalAddress.OccupyStatusType.OWNER_MORTGAGED.value().equals(occupyStatus) || PersonalAddress.OccupyStatusType.OWNER_NO_MORTGAGE.value().equals(occupyStatus)) {
            return BigDecimal.valueOf(1);
        }

        return null;
    }
}
