package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BankDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;


public interface CaseService {

    /**
     * Returns generated unique ID for new case.
     *
     * @param brand which business division is being used - allows for multi-tenant system
     * @return the unique ID for new case
     */
    String generateCaseId(String brand);

    /**
     * Saves case with provided details.
     *
     * @param brand           which business division is being used - allows for multi-tenant system
     * @param caseId          the ID of the case
     * @param caseApplication the {@link CaseApplication} to save
     * @param broker          the broker details
     * @param isNewCase       flag to indicate whether a new case should be created
     * @param clearDipResult  flag to indicate whether this update is clearing DIP results
     * @return the {@link CaseApplication} with saved details
     */
    CaseApplication saveCase(String brand, String caseId, CaseApplication caseApplication, BrokerInfo broker, boolean isNewCase, boolean clearDipResult);

    CaseApplication getCase(String brand, String caseId);
}
