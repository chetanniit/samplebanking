package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class AdditionalJobIncome {
    @NotBlank
    @ValidateEnum(enumClass = AdditionalIncomeType.class)
    private String type;

    @NotBlank
    @ValidateEnum(enumClass = AdditionalIncomeFrequency.class)
    private String frequency;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String originatingCurrency;

    @NotNull
    @DecimalMin(value = "1.00", message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal amount;

    @DecimalMin(value = "1.00", message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal netAmount;


    public enum AdditionalIncomeType implements ValuedEnum {
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_SHIFT_PAY_REGULAR,
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_CAR_ALLOWANCE,
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_OVERTIME_REGULAR,
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_OVERTIME_GUARANTEED,
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_COMMISSION_REGULAR,
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_BONUS_DISCRETIONARY,
        ACCEPTABLE_INCOME_PAYSLIP_PAYMENTS_BONUS_GUARANTEED;

        @Override
        public String value() {
            return name();
        }
    }

    public enum AdditionalIncomeFrequency implements ValuedEnum {
        ANNUALLY,
        BIANNUALLY,
        FORTNIGHTLY,
        FOUR_WEEKLY,
        MONTHLY,
        QUARTERLY,
        WEEKLY;

        @Override
        public String value() {
            return name();
        }
    }
}
