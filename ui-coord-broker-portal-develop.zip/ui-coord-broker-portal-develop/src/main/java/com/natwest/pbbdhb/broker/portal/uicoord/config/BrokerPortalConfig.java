package com.natwest.pbbdhb.broker.portal.uicoord.config;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;
import javax.net.ssl.SSLContext;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ProxyConfigurationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.auth.AuthScope;
import org.apache.hc.client5.http.auth.UsernamePasswordCredentials;
import org.apache.hc.client5.http.impl.auth.BasicCredentialsProvider;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.TrustAllStrategy;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

@Configuration
@Slf4j
public class BrokerPortalConfig {

  private static final String PROXY_SCHEME = "http";

  @Bean(value = "sslRestTemplate")
  public RestTemplate createProxyRestTemplate(
      @Qualifier("sslRequestFactory") ClientHttpRequestFactory factory,
      RestTemplateBuilder restTemplateBuilder) {

    return restTemplateBuilder
        .requestFactory(() -> factory)
        .build();
  }

  // standard proxy-aware request factory
  // This factory is expected to be used when deployed to a real PCF environment
  @Bean
  @Qualifier("sslRequestFactory")
  public ClientHttpRequestFactory defaultRequestFactory(
      @Value("${proxy.host}") String proxyHost,
      @Value("${proxy.port:#{0}}") int proxyPort,
      @Value("${proxy.enabled:#{false}}") boolean proxyEnabled) {

    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
    if (proxyEnabled) {
      log.info("Using proxy configuration = (host: {}, port: {})", proxyHost, proxyPort);
      Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
      requestFactory.setProxy(proxy);
    }
    return requestFactory;
  }

  // request factory to be used for local environments/testing.
  // This factory uses a "trust all" strategy that allows requests locally.
  // This factory is NOT expected to be used when deployed to a real PCF environment
  // we use "authentication-required" to determine if we are running locally.
  @Bean
  @Qualifier("sslRequestFactory")
  @ConditionalOnProperty(
      value="proxy.authentication.required",
      havingValue = "true")
  @Primary
  public ClientHttpRequestFactory trustAllRequestFactory(
      @Value("${proxy.host}") String proxyHost,
      @Value("${proxy.port:#{0}}") int proxyPort,
      @Value("${proxy.username:#{null}}") String username,
      @Value("${proxy.password:#{null}}") String password,
      @Value("${proxy.enabled:#{false}}") boolean proxyEnabled,
      @Value("${proxy.authentication.required:#{false}}") boolean proxyAuthRequired) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

    log.warn("Using trust-all request factory - not intended for use in PCF environments");

    HttpClientBuilder clientBuilder = HttpClientBuilder.create();
    SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(new TrustAllStrategy()).build();
    HttpClientConnectionManager connectionManager = PoolingHttpClientConnectionManagerBuilder.create()
        .setSSLSocketFactory(new SSLConnectionSocketFactory(sslContext))
        .build();
    clientBuilder.setConnectionManager(connectionManager);

    if (proxyEnabled) {
      log.info("Using proxy configuration = (host: {}, port: {})", proxyHost, proxyPort);
      clientBuilder
          .setProxy(new HttpHost(PROXY_SCHEME, proxyHost, proxyPort));

      if (proxyAuthRequired) {
        if (Objects.isNull(username) || Objects.isNull(password)) {
          throw new ProxyConfigurationException(
              "Username and password have to be provided when authentication is required");
        }
        BasicCredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(
            new AuthScope(proxyHost, proxyPort),
            new UsernamePasswordCredentials(username, password.toCharArray())
        );
        clientBuilder
            .setDefaultCredentialsProvider(credentialsProvider);
      }
    }

    return new HttpComponentsClientHttpRequestFactory(clientBuilder.build());
  }

  @Bean
  @Qualifier("restTemplateForApiCall")
  @Scope("prototype")
  public RestTemplate restTemplateForApiCall(@Qualifier("iamJwtChainSecureRestTemplate")
                                                       RestTemplate iamJwtChainSecureRestTemplate,
                                             ObjectMapper objectMapper) {
    List<HttpMessageConverter<?>> messageConverters =
            iamJwtChainSecureRestTemplate.getMessageConverters();
    for (HttpMessageConverter<?> messageConverter : messageConverters) {
      if (messageConverter instanceof MappingJackson2HttpMessageConverter) {
        ((MappingJackson2HttpMessageConverter) messageConverter)
                .setObjectMapper(objectMapper);
      }
    }
    return iamJwtChainSecureRestTemplate;
  }
}
