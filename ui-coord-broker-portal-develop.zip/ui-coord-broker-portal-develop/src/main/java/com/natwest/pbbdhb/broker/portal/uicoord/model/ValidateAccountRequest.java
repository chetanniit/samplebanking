package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@Data
public class ValidateAccountRequest {

    @Pattern(regexp = "^[0-9]{5,6}$", message = MUST_BE_5_OR_6_DIGITS)
    @NotNull
    private String sortCode;

    @Pattern(regexp = "^[0-9]{8}$", message = MUST_BE_8_DIGITS)
    @NotNull
    private String accountNumber;

    @Pattern(regexp = "^[A-Za-z0-9][A-Za-z0-9,\\/.\\s-]*[A-Za-z0-9]+$", message = MUST_BE_CORRECT_FORMAT)
    private String rollNumber;
}
