package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCaseDip;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.IncomeApplicant;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import jakarta.validation.Valid;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

/** Mapper for the 'return to AIP' feature */
@Mapper(
        builder = @Builder(disableBuilder = true),
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface BrokerCaseDipMapper {
    BrokerCaseDip toBrokerCaseDip(BrokerCase brokerCase);
    BrokerCase toBrokerCase(BrokerCaseDip brokerCaseDip);

  @AfterMapping
  default void afterMappingToBrokerCaseDip(
  BrokerCase brokerCase, @MappingTarget BrokerCaseDip brokerCaseDip) {
    List<@Valid IncomeApplicant> incomeApplicants = Optional.ofNullable(brokerCase.getIncome())
        .map(CaseIncome::getApplicants).orElse(Collections.emptyList());
    incomeApplicants.stream()
        .map(IncomeApplicant::getPreviousJobDetails).filter(Objects::nonNull)
        .forEach(List::clear);
  }
}
