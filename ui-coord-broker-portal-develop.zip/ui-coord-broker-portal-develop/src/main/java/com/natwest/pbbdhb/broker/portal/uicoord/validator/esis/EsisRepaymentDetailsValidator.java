package com.natwest.pbbdhb.broker.portal.uicoord.validator.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.RepaymentType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisRepaymentDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisRepaymentDetails;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

public class EsisRepaymentDetailsValidator implements ConstraintValidator<ValidEsisRepaymentDetails, Object> {

    @Override
    public boolean isValid(Object target, ConstraintValidatorContext context) {
        EsisRepaymentDetails esisRepaymentDetails = (EsisRepaymentDetails) target;
        if (esisRepaymentDetails.getRepaymentType().equals(RepaymentType.MIXED.value())) {
            return !(esisRepaymentDetails.getAmountCapital() == null
                    || esisRepaymentDetails.getAmountCapital().equals(BigDecimal.ZERO))
                    && !(esisRepaymentDetails.getInterestOnlyAmount() == null
                    || esisRepaymentDetails.getInterestOnlyAmount().equals(BigDecimal.ZERO))
                    && esisRepaymentDetails.getInterestOnlyTermYears() != null
                    && esisRepaymentDetails.getInterestOnlyTermMonths() != null;
        }
        return true;
    }
}
