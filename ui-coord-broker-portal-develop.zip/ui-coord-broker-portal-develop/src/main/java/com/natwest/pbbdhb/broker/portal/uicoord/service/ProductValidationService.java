package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductValidationResponse;

public interface ProductValidationService {

  ProductValidationResponse validateProduct(String brand, String caseId);
}
