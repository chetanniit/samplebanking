package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import static com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerSourcesClient.MULTIPLE_MATCHING_BROKER_SOURCES;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.INVALID_CREDIT_CARD_CONSOLIDATED_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.INVALID_CREDIT_CARD_OUTSTANDING_BALANCE;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.INVALID_LOAN_CONSOLIDATED_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode.INVALID_LOAN_OUTSTANDING_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep.FMA_ON_SUBMIT;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep.FMA_POST_SUBMIT_IN_ERROR;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep.FMA_POST_SUBMIT_RESET;
import static com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep.FMA_PRE_SUBMIT;
import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.applicantsWorkStatusMap;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_STEP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MARKETING_SOURCE_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_DIP_EXPIRED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_ESTATE_AGENT_LENGTH_EXCEEDED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_FMA_ALREADY_SUBMITTED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_BROKER_TRADING_NAME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_CREDIT_CARD_CONSOLIDATED_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_CREDIT_CARD_OUTSTANDING_BALANCE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_LOAN_CONSOLIDATED_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_EXPENSE_LOAN_OUTSTANDING_AMOUNT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_INVALID_PAYMENT_PATH_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_MISSING_PAYMENT_PATH_ID;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_DIP_RESULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseStatusUtil.fmaHasBeenSubmitted;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.hasDipResult;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.hasUnexpiredDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.logging.EventLogger.formatJourneyLog;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerSourcesClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerSourcesException;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ExpenseClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.FmaClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.client.IncomeClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.PropertyClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourceResultDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourcesAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerSourcesRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaUnhandledValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.FmaValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.InvalidCaseStateException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.CaseApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.FmaApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication.LoanPurpose;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty.OwnershipType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty.PropertyUsage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.FmaService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerClaimsUtil;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.EventLogger;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.LogMessageSubtype;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.LogMessageType;
import com.natwest.pbbdhb.cases.dto.BrokerDetailsDto;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.BuyToLetDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import com.natwest.pbbdhb.cases.dto.PortfolioLandlordDto;
import com.natwest.pbbdhb.commondictionaries.enums.Channel;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStage;
import com.natwest.pbbdhb.income.expense.model.enums.ExpenseCategory;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class FmaServiceImpl implements FmaService {

    private static final String LOG_VALIDATION_FAILURE = "Validation errors returned from FMA";
    private static final String LOG_UNHANDLED_VALIDATION_FAILURE = "Unhandled validation errors returned from FMA";
    private static final String LOANS = "LOANS";
    private final CaseClientNapoli caseClient;
    private final ApplicantClientNapoli applicantClient;
    private final PropertyClientNapoli propertyClient;
    private final IncomeClient incomeClient;
    private final ExpenseClient expenseClient;
    private final FmaApplicationMapper fmaApplicationMapper;
    private final FmaClient fmaClient;
    private final BrokerSourcesClient brokerSourcesClient;
    private final BrokerInfoService brokerInfoService;

    private final UserClaimsProvider userClaimsProvider;
    private final AccessPermissionChecker accessPermissionChecker;

    private final Integer defaultSource1Id;

    public FmaServiceImpl(CaseClientNapoli caseClient, ApplicantClientNapoli applicantClient,
        PropertyClientNapoli propertyClient, IncomeClient incomeClient, ExpenseClient expenseClient,
        FmaApplicationMapper fmaApplicationMapper, FmaClient fmaClient,
        BrokerSourcesClient brokerSourcesClient, CaseApplicationMapper caseApplicationMapper,
        BrokerInfoService brokerInfoService, UserClaimsProvider userClaimsProvider,
        AccessPermissionChecker accessPermissionChecker,
        @Value("${gms.default-source1-id}") Integer defaultSource1Id) {
        this.caseClient = caseClient;
        this.applicantClient = applicantClient;
        this.propertyClient = propertyClient;
        this.incomeClient = incomeClient;
        this.expenseClient = expenseClient;
        this.fmaApplicationMapper = fmaApplicationMapper;
        this.fmaClient = fmaClient;
        this.brokerSourcesClient = brokerSourcesClient;
        this.brokerInfoService = brokerInfoService;
        this.userClaimsProvider = userClaimsProvider;
        this.accessPermissionChecker = accessPermissionChecker;
        this.defaultSource1Id = defaultSource1Id;
    }

    @Override
    public FullMortgageApplicationExtendedResponse submitFma(String brand, String caseId) throws FmaIntegrationException, FmaUnhandledValidationException {
      String username = userClaimsProvider.getBrokerUsername();

      validateUserPermission(brand, caseId, username);

      // Fetch and Validate CAPIE Case data
      CaseApplicationDto capieCaseApplication = caseClient.getCase(brand, caseId);
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"Starting submitFma"));

      validateCAPIECaseData(brand, capieCaseApplication);

      // Fetch Remaining CAPIE data
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username, "Calling applicantClient to get applicants"));
      List<ApplicantDto> capieApplicantDtoList = applicantClient.getApplicants(brand, caseId);
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"applicantClient successfully called to get applicants"));
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"Calling propertyClient to get property"));
      PropertyDetailsDto capiePropertyDetailsDto = propertyClient.getProperty(brand, caseId);
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"propertyClient successfully called to get property"));
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"Calling incomeClient to get income"));
      ValidatedCaseIncomeDto capieCaseIncomeDto = incomeClient.getIncome(brand, caseId);
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"incomeClient successfully called to get income"));
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"Calling expenseClient to get expense"));
      ValidatedCaseExpenseDto capieCaseExpenseDto = expenseClient.getExpense(brand, caseId);
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"expenseClient successfully called to get expense"));

      // Update Capie data ahead of cloning.
      //Warning - Anything updated here will be saved to CAPIE before the result of the call to FMA Submit is known, and not reverted if submit fails.
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,"Updating DTOs ahead of application clone"));
      updateAndSaveApplicantAheadOfApplicationCloning(brand, caseId, capieApplicantDtoList, capieCaseIncomeDto);
      capieCaseApplication =  updateCaseAheadOfApplicantCloning(brand, capieCaseApplication);
      // TODO: Check any other 'cross-service' fields that could get out of sync when broker case updates are not atomic.
      log.debug(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication, username, "Completed updating DTOs ahead of application clone"));


      // Create an FMA Application With DTOs cloned from those CAPIE loaded from CAPIE apis
      Application applicationForFmaSubmission = makeApplicationForFmaSubmission(brand,
                                                                                capieCaseApplication,
                                                                                capieApplicantDtoList,
                                                                                capiePropertyDetailsDto,
                                                                                capieCaseIncomeDto,
                                                                                capieCaseExpenseDto);

      CaseApplicationDto clonedCaseApplication = applicationForFmaSubmission.getCaseApplication();

      //Update the cloned CaseApplication and Save to CAPIE
      log.debug(formatJourneyLog(brand, FMA_ON_SUBMIT, applicationForFmaSubmission.getCaseApplication(), username, "Switched to application clone"));
      clonedCaseApplication = saveClonedCaseWithFlagToPreventDuplicateSubmission(brand, clonedCaseApplication);
      applicationForFmaSubmission.setCaseApplication(clonedCaseApplication);
      log.debug(formatJourneyLog(brand, FMA_ON_SUBMIT, clonedCaseApplication, username, "Cloned Application Saved To CAPIE - Case"));

      //Submit to FMA
      final String previousApplicationStatus = applicationForFmaSubmission.getCaseApplication().getApplicationStatus();

      FullMortgageApplicationExtendedResponse fmaResponse = null;
      try {
        log.debug("Calling fmaClient to submit FMA for caseId {} and brokerUsername {}", caseId, username);
        fmaResponse = fmaClient.submitFma(applicationForFmaSubmission);
      }
      catch (FmaValidationException ex) {
        capieCaseApplication.setApplicationStatus(previousApplicationStatus);
        capieCaseApplication.setVersion(clonedCaseApplication.getVersion());
        if (!ErrorCode.UNHANDLED.equals(ex.getCode())){
          log.warn(formatJourneyLog(brand, FMA_POST_SUBMIT_RESET, clonedCaseApplication, username,
              (new StringBuilder()).append(LOG_VALIDATION_FAILURE).append(" - ")
                  .append(ex.getCode()).append(" - ").append(ex.getMessage()).toString()));
          saveCase(brand, FMA_POST_SUBMIT_RESET, capieCaseApplication);
        } else {
          log.warn(formatJourneyLog(brand, FMA_POST_SUBMIT_RESET, clonedCaseApplication, username,
              (new StringBuilder()).append(LOG_UNHANDLED_VALIDATION_FAILURE).append(" - ")
                  .append(ex.getCode()).append(" - ").append(ex.getMessage()).toString()));
          saveCase(brand, FMA_POST_SUBMIT_RESET, capieCaseApplication);
          throw new FmaUnhandledValidationException(ex.getCode(), ex.getMessage());
        }
        throw ex;
      }
      catch (FmaIntegrationException ex) {
        // IMPORTANT: DO NOT UPDATE CAPIE IN HERE.
        log.error(formatJourneyLog(brand,  FMA_POST_SUBMIT_IN_ERROR, clonedCaseApplication,
            username, String.format("Error calling fma %s", ex.getMessage())));
        throw ex;
      }

      // IMPORTANT: NO MORE UPDATES TO CAPIE HERE
      log.info(EventLogger.logFmaResult(brand, username, clonedCaseApplication, fmaResponse));
      return fmaResponse;
    }

    private void validateCAPIECaseData(String brand, CaseApplicationDto capieCaseApplication) {
      String username = userClaimsProvider.getBrokerUsername();
      if (fmaHasBeenSubmitted(capieCaseApplication)) {
        log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication, username, "throwing UpdateNotPermittedException - FMA already submitted"));
        throw new UpdateNotPermittedException(MSG_FMA_ALREADY_SUBMITTED);
      }

      if (!hasDipResult(capieCaseApplication)) {
        log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication, username, "throwing InvalidCaseStateException - FMA has no valid DIP"));
        throw new InvalidCaseStateException(MSG_NO_DIP_RESULT);
      }

      if (!hasUnexpiredDip(capieCaseApplication)) {
        log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication, username,  "throwing InvalidCaseStateException - FMA has expired DIP"));
        throw new InvalidCaseStateException(MSG_DIP_EXPIRED);
      }
      if (!isEstateAgentNameValidForFma(capieCaseApplication)) {
        log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication, username,"Estate agent firm name character limit exceeded, please reduce to a maximum of 45 characters"));
        throw new FmaValidationException(ErrorCode.ESTATE_AGENT_LENGTH_EXCEEDED,
            MSG_ESTATE_AGENT_LENGTH_EXCEEDED);
      }
      if (hasNotEnoughLandlordExperience(capieCaseApplication)){
        log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication, username,"Not enough experience as a landlord"));
        throw new FmaValidationException(ErrorCode.NOT_ENOUGH_LANDLORD_EXPERIENCE, ErrorCode.NOT_ENOUGH_LANDLORD_EXPERIENCE.getExternalMessage());
      }
    }

  private void validateUserPermission(String brand, String caseId, String username) {
        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
          log.error(formatJourneyLog(brand, LogMessageType.FMA,
              LogMessageSubtype.FMA_SUBMIT, caseId, username,
              (new StringBuilder()).append("Permission error - ")
              .append(MSG_NO_UPDATE_CASE_PERMISSION).toString()));
          throw new PermissionDeniedException(MSG_NO_UPDATE_CASE_PERMISSION);
        }
    }


  private CaseApplicationDto saveClonedCaseWithFlagToPreventDuplicateSubmission(String brand, CaseApplicationDto caseApplication) {
      Map<String, Object> journeyData = getJourneyData(caseApplication);
      journeyData.put(CASE_JOURNEY_DATA_FMA_SUBMITTED, true);
      return saveCase(brand, FMA_ON_SUBMIT, caseApplication);
  }

  private CaseApplicationDto updateCaseAheadOfApplicantCloning(String brand, CaseApplicationDto caseApplication) {
    caseApplication.setChannel(Channel.INTERMEDIARY_NAPOLI.toString());
    // NOTE: Not using marketing for brokers. Use a default value just to satisfy FMA validation.
    caseApplication.setMarketingSource(MARKETING_SOURCE_DEFAULT);
    //todo - should we save here  -> return  saveCase(brand, FMA_PRE_SUBMIT, caseApplication);
    return caseApplication;
  }

  private void updateAndSaveApplicantAheadOfApplicationCloning(String brand, String caseId, List<ApplicantDto> applicantDtoList, ValidatedCaseIncomeDto caseIncomeDto) {

    // Check applicant.workStatus is set correctly. If not, update applicant(s) before calling submitDip.
    // This is needed because applicant.workStatus needs to reflect the data stored in income.applicant.primaryJob.employmentStatus.
    // Thus data needs to be synchronised across the applicant and income services, but there is no way to update them both in an atomic operation (no transaction support).
    // This code attempts to fix any inconsistency that might be present due to earlier update failures.

    String username = userClaimsProvider.getBrokerUsername();
    if (applicantDtoList != null) {
      Map<String, String> workStatusMap = applicantsWorkStatusMap(applicantDtoList, caseIncomeDto);
      for (ApplicantDto applicantDto : applicantDtoList) {
        String currentWorkStatus = applicantDto.getWorkStatus();
        String expectedWorkStatus = workStatusMap.get(applicantDto.getApplicantId());
        if (expectedWorkStatus == null) {
          if (currentWorkStatus != null) {
            applicantDto.setWorkStatus(null);
            log.debug("Calling applicantClient to save applicant with null workStatus, caseId {}, and brokerUsername {}", caseId, username);
            applicantClient.saveApplicant(brand, applicantDto);
            log.debug("applicantClient successfully called to save applicant with null workStatus, caseId {}, and brokerUsername {}", caseId, username);
          }
        } else if (!expectedWorkStatus.equals(currentWorkStatus)) {
          applicantDto.setWorkStatus(expectedWorkStatus);
          log.debug("Calling applicantClient to save applicant with workStatus matching currentWorkStatus, caseId {}, and brokerUsername {}", caseId, username);
          applicantClient.saveApplicant(brand, applicantDto);
          log.debug("applicantClient successfully called to save applicant with workStatus matching currentWorkStatus, caseId {}, and brokerUsername {}", caseId, username);
        }
      }
    }

    //TODO: Return updated applicant list?

  }


  private Application makeApplicationForFmaSubmission(String brand,
                                                      CaseApplicationDto capieCaseApplication,
                                                      List<ApplicantDto> capieApplicantDtoList,
                                                      PropertyDetailsDto capiePropertyDetailsDto,
                                                      ValidatedCaseIncomeDto capieCaseIncomeDto,
                                                      ValidatedCaseExpenseDto capieCaseExpenseDto) {
    //Check expense for decimal points
    checkDecimalPoints(brand, capieCaseApplication, capieCaseExpenseDto);

    //Make Cloned application
    Application applicationForFmaSubmission = fmaApplicationMapper.toFmaApplication(brand,
                                                                                   capieCaseApplication,
                                                                                   capieApplicantDtoList,
                                                                                   capiePropertyDetailsDto,
                                                                                   capieCaseIncomeDto,
                                                                                   capieCaseExpenseDto);


    updateFmaApplicationPreSubmit(brand, applicationForFmaSubmission);
    return applicationForFmaSubmission;
  }

  private void checkDecimalPoints(String brand, CaseApplicationDto capieCaseApplication, ValidatedCaseExpenseDto capieCaseExpenseDto) {
    String username = userClaimsProvider.getBrokerUsername();
    if (capieCaseExpenseDto != null && capieCaseExpenseDto.getApplicants() != null) {
      capieCaseExpenseDto.getApplicants().stream().forEach(expenseApplicantDto ->
        expenseApplicantDto.getTransactions().values().stream().forEach(expenseTransactionDto ->
        {
          ExpenseCategory categoryCode = expenseTransactionDto.getCategoryCode();
          if (expenseTransactionDto.getOutstandingBalance() != null && expenseTransactionDto.getOutstandingBalance().scale() > 0) {
            if (categoryCode == ExpenseCategory.CREDIT_CARD) {
              log.warn(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
                  "Invalid credit card outstanding balance"));
              throw new FmaValidationException(INVALID_CREDIT_CARD_OUTSTANDING_BALANCE, MSG_INVALID_EXPENSE_CREDIT_CARD_OUTSTANDING_BALANCE);
            }
            if (categoryCode.toString().startsWith(LOANS)) {
              log.warn(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
                  "Invalid loan outstanding amount"));
              throw new FmaValidationException(INVALID_LOAN_OUTSTANDING_AMOUNT, MSG_INVALID_EXPENSE_LOAN_OUTSTANDING_AMOUNT);
            }
          }
          if (expenseTransactionDto.getConsolidationAmount() != null && expenseTransactionDto.getConsolidationAmount().scale() > 0) {
            if (categoryCode == ExpenseCategory.CREDIT_CARD) {
              log.warn(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
                  "Invalid credit card consolidated amount"));
              throw new FmaValidationException(INVALID_CREDIT_CARD_CONSOLIDATED_AMOUNT, MSG_INVALID_EXPENSE_CREDIT_CARD_CONSOLIDATED_AMOUNT);
            }
            if (categoryCode.toString().startsWith(LOANS)) {
              log.warn(
                  formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
                      "Invalid loan outstanding consolidated amount"));
              throw new FmaValidationException(INVALID_LOAN_CONSOLIDATED_AMOUNT, MSG_INVALID_EXPENSE_LOAN_CONSOLIDATED_AMOUNT);
            }
          }
        }));
    }
  }

  private void updateFmaApplicationPreSubmit(String brand, Application applicationForFmaSubmission) {

    updateApplicationWithJourneyConstantsForFmaSubmit(applicationForFmaSubmission);
    updateBrokerWithGmsIds(applicationForFmaSubmission.getCaseApplication(), applicationForFmaSubmission.getCaseApplication().getBroker(), brand);

    for (ApplicantDto applicant : applicationForFmaSubmission.getApplicants()) {
      // TODO: Remove this if last name is limited to 25 characters in CAPIE.
      applicant.getPersonalDetails()
          .setLastName(StringUtils.truncate(applicant.getPersonalDetails().getLastName(), 25));
    }

  }

  private void updateApplicationWithJourneyConstantsForFmaSubmit(Application application) {
    application.getIncome().setStage(CaseStage.FMA);
    application.getExpenditure().setStage(CaseStage.FMA);
  }

  public void updateBrokerWithGmsIds(CaseApplicationDto capieCaseApplication, BrokerDto broker, String brand) {
    String caseId = capieCaseApplication == null ? null : capieCaseApplication.getCaseId();
    String username = userClaimsProvider.getBrokerUsername();
    if (broker == null) {
      log.warn(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
          "BrokerDto is null - returning null"));
      return;
    }
    BrokerSourcesRequestDto brokerSourcesRequest = createBrokerSourcesRequest(brand, broker, capieCaseApplication);
    String brokerUsername = userClaimsProvider.getBrokerUsername();
    try {
      log.debug("Calling brokerSourcesClient to find broker sources for caseId {} and brokerUsername {}",
          caseId, brokerUsername);
      BrokerSourceResultDto[] brokerSourceResults = brokerSourcesClient.findBrokerSources(brand,
          brokerSourcesRequest);
      if (brokerSourceResults.length > 1) {
        log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
            "Multiple broker source found"));
        throw new BrokerSourcesException(MULTIPLE_MATCHING_BROKER_SOURCES);
      }
      copyGmsIdsToBrokerDetails(caseId, broker, brokerSourceResults[0]);
    } catch (BrokerSourcesException e) {
      log.trace("Caught BrokerSourcesException for caseId {} and brokerUsername {}: {}", caseId,
          brokerUsername, e.getMessage());
      copyGmsIdsToBrokerDetails(caseId, broker, null);
    } catch (Exception e) {
      log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
          (new StringBuilder()).append("Unexpected error calling broker sources - ")
              .append(e.getMessage()).toString()));
      throw e;
    }
  }

  private BrokerSourcesRequestDto createBrokerSourcesRequest(String brand, BrokerDto broker, CaseApplicationDto capieCaseApplication) {
    String caseId = capieCaseApplication == null ? null : capieCaseApplication.getCaseId();
    String username = userClaimsProvider.getBrokerUsername();

    if ((broker.getDetails() == null || broker.getDetails().getNetworkId() == null)) {
      log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
          "No broker details networkId is available for this broker. Cannot match to paymentPaths"));
      throw new FmaValidationException(ErrorCode.INVALID_PAYMENT_PATH,
          MSG_MISSING_PAYMENT_PATH_ID);
    }
    Integer paymentPathId = broker.getDetails().getNetworkId();

    BrokerSourcesRequestDto brokerSourcesRequest = new BrokerSourcesRequestDto();

    log.debug("Calling brokerInfoService to get broker with brokerUsername {} and caseId {}", username, caseId);
    BrokerInfo brokerInfo = brokerInfoService.getBroker(username);
    log.debug("brokerInfoService successfully called to get broker with brokerUsername {} and caseId {}", username, caseId);

    if (brokerInfo.getFirmDetails().getTradingName() == null) {
      log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
          "No broker trading name is available for this broker"));
      throw new FmaValidationException(ErrorCode.INVALID_BROKER_TRADING_NAME,
          MSG_INVALID_BROKER_TRADING_NAME);
    }
    // NOTE: The broker source request can contain other fields, but this set seems to work in testing.
    // The address fields in CAPIE do not map neatly to the broker source request address fields, so not sure how they could be used.
    // It looks like a planned update to the broker data model in the Case service will make this easier.
    brokerSourcesRequest.setFcaReference(brokerInfo.getFirmDetails().getFcaNumber());
    brokerSourcesRequest.setFirmName(brokerInfo.getFirmDetails().getTradingName());

    PaymentPath selectedPaymentPath = BrokerClaimsUtil.getPaymentPathById(brokerInfo,
        paymentPathId);
    if (selectedPaymentPath == null) {
      log.error(formatJourneyLog(brand, FMA_PRE_SUBMIT, capieCaseApplication,  username,
          (new StringBuilder()).append("No matching paymentPath found for paymentPathId")
              .append(paymentPathId).append(", call to broker sources would fail").toString()));
      throw new FmaValidationException(ErrorCode.INVALID_PAYMENT_PATH,
          MSG_INVALID_PAYMENT_PATH_ID);
    }
    brokerSourcesRequest.setNetworkInfo(selectedPaymentPath.getPaymentPathName());

    BrokerSourcesAddressDto brokerSourcesAddress = new BrokerSourcesAddressDto();
    brokerSourcesAddress.setPostcode(brokerInfo.getFirmDetails().getAddress().getPostcode());

    brokerSourcesRequest.setAddress(brokerSourcesAddress);
    return brokerSourcesRequest;
  }

  private void copyGmsIdsToBrokerDetails(String caseId, BrokerDto broker,
      BrokerSourceResultDto brokerSourceResult) {
    Integer gmsId =
        brokerSourceResult == null || brokerSourceResult.getSource1() == null
            ? getDefaultSource1Id(caseId, broker.getBrokerUsername())
            : Integer.parseInt(brokerSourceResult.getSource1());
    Integer gmsNetworkId =
        brokerSourceResult == null || brokerSourceResult.getSource2() == null ? null
            : Integer.parseInt(brokerSourceResult.getSource2());

    BrokerDetailsDto brokerDetails = broker.getDetails();
    if (brokerDetails == null) {
      brokerDetails = new BrokerDetailsDto();
      broker.setDetails(brokerDetails);
    }
    brokerDetails.setId(gmsId);
    brokerDetails.setNetworkId(gmsNetworkId);
    log.debug("GMS ids copied to broker details for FMA Submission for caseId {} and brokerUsername {}",
        caseId, broker.getBrokerUsername());
  }

  private Integer getDefaultSource1Id(String caseId, String brokerUsername) {
    log.debug("setting gmsId to default Source Id for FMA Submission for caseId {} and brokerUsername {}",
        caseId, brokerUsername);
    return defaultSource1Id;
  }

  private CaseApplicationDto saveCase(String brand, JourneyStep step, CaseApplicationDto caseApplication){
    log.debug(formatJourneyLog(brand, step, caseApplication, userClaimsProvider.getBrokerUsername(), "saving case to Capie"));
    Map<String, Object> journeyData = getJourneyData(caseApplication);
    journeyData.put(CASE_JOURNEY_DATA_STEP, step);
    return caseClient.updateCase(brand, caseApplication);
  }

  private Map<String, Object> getJourneyData(CaseApplicationDto caseApplication) {
    Map<String, Object> journeyData = Optional.ofNullable(caseApplication.getJourneyData())
        .orElseGet(() -> {
          caseApplication.setJourneyData(new HashMap<>());
          return caseApplication.getJourneyData();}
        );
    return journeyData;
  }
  private boolean isEstateAgentNameValidForFma(CaseApplicationDto caseApplication){
    String pattern = "^[^\\s](?:.{0,43}[^\\s])?$";
    if (caseApplication.getEstateAgent() == null) {
      return true;
    }
    return Pattern.matches(pattern,caseApplication.getEstateAgent().getAgencyName());
  }

  private boolean hasNotEnoughLandlordExperience(CaseApplicationDto caseApplication) {
    return ApplicationType.BUY_TO_LET.value().equals(caseApplication.getApplicationType())
        && (LoanPurpose.REMORTGAGE.value().equals(caseApplication.getLoanPurpose()) || LoanPurpose.HOUSE_PURCHASE.value().equals(caseApplication.getLoanPurpose()))
        && Optional.ofNullable(caseApplication.getMortgage())
          .map(MortgageDto::getOtherProperties)
          .orElse(Collections.emptyList())
          .stream()
          .filter(otherProperty -> Arrays.asList(PropertyUsage.BUY_TO_LET.value(), PropertyUsage.CONSENT_TO_LET.value()).contains(otherProperty.getPropertyUsage()))
          .filter(otherProperty -> Arrays.asList(OwnershipType.HELD_RBSG.value(), OwnershipType.HELD_ELSEWHERE.value()).contains(otherProperty.getOwnershipType()))
          .filter(otherProperty -> !otherProperty.getPropertyRedemption())
          .count() >= 3
        && Optional.of(caseApplication.getMortgage())
          .map(MortgageDto::getBuyToLet)
          .map(BuyToLetDto::getPortfolioLandlord)
          .map(PortfolioLandlordDto::getNumberOfYearsAsLandlord).orElse(0) < 2;
  }


}
