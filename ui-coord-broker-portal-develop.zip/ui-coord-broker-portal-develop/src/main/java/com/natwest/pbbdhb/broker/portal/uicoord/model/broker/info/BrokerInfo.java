package com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerInfo {
    private Integer brokerId;
    private BrokerDetails brokerDetails;
    private FirmDetails firmDetails;
    private List<PaymentPath> paymentPaths;
}