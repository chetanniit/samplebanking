package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.esis.EsisSpecialistSchemeValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EsisSpecialistSchemeValidator.class)
public @interface ValidEsisSpecialistScheme {

    String message() default "schemeType cannot be empty when using specialistScheme";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
