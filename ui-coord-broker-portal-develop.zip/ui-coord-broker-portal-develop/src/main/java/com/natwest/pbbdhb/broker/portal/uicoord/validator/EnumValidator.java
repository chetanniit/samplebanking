package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EnumValidator implements ConstraintValidator<ValidateEnum, CharSequence> {
    private List<String> acceptedValues;

    @Override
    public void initialize(ValidateEnum annotation) {
        acceptedValues = Stream.of(annotation.enumClass()
                .getEnumConstants())
                .map(ValuedEnum::value)
                .collect(Collectors.toList());
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        context.unwrap(HibernateConstraintValidatorContext.class).addExpressionVariable("enumValues", String.join(", ", this.acceptedValues));
        if (value == null) {
            return true;
        }
        return acceptedValues.contains(value.toString());
    }
}