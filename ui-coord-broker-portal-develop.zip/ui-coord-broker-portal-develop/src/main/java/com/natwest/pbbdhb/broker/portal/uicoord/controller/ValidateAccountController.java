package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ValidateAccountRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ValidateAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "ValidateAccount", description = "Validate bank account API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class ValidateAccountController {

    private final ValidateAccountService validateAccountService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "validateAccount",
            summary = "Check bank account details",
            tags = "ValidateAccount"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Search was executed successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Boolean.class))),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PostMapping(path = PATH_VALIDATE_ACCOUNT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Boolean> validateAccount(
            @Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
            @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
            @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG)
            final String brand,
            @RequestBody @Valid final ValidateAccountRequest validateAccountRequest
    ) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to validate account {} for brokerUsername {}", validateAccountRequest, brokerUsername);
        Boolean isValid = this.validateAccountService.validateAccount(brand, validateAccountRequest);
        log.info("Account {} for brokerUsername {} successfully validated with result: isValid {}", validateAccountRequest, brokerUsername, isValid);
        return ResponseEntity.ok(isValid);
    }
}
