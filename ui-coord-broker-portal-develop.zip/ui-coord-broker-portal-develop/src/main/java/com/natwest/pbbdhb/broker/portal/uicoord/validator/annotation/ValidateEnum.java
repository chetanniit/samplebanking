package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.EnumValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({FIELD})
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = EnumValidator.class)
public @interface ValidateEnum {
    Class<? extends ValuedEnum> enumClass();

    String message() default "must be any of: ${enumValues}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
