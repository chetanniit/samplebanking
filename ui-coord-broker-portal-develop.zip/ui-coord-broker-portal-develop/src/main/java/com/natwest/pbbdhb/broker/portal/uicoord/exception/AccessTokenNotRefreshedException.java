package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class AccessTokenNotRefreshedException extends RuntimeException {

  public AccessTokenNotRefreshedException(String message) {
    super(message);
  }
}
