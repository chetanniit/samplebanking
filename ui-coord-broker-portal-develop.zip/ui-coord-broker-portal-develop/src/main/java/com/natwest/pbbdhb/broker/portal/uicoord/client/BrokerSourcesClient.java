package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.*;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerSourcesException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.*;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class BrokerSourcesClient {

    public static final String NO_MATCHING_BROKER_SOURCES = "Broker source IDs for GMS not found.";
    public static final String MULTIPLE_MATCHING_BROKER_SOURCES = "Multiple matching broker source IDs for GMS found.";

    private final String brokerSourcesServiceEndpoint;
    private final RestTemplate restTemplate;

    public BrokerSourcesClient(
            @Value("${msvc.broker.sources.url}") String brokerSourcesServiceEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.brokerSourcesServiceEndpoint = brokerSourcesServiceEndpoint;
        this.restTemplate = restTemplate;
    }

    public BrokerSourceResultDto[] findBrokerSources(String brand, BrokerSourcesRequestDto brokerDetails) throws BrokerSourcesException {
        log.info("Calling {} to find broker sources for broker with FCA number {}, firm name {}, and network info {}",
            brokerSourcesServiceEndpoint, brokerDetails.getFcaReference(), brokerDetails.getFirmName(), brokerDetails.getNetworkInfo());

        // Using lower-level execute() function so that we can have a custom ResponseExtractor,
        try {
            ResponseEntity<BrokerSourceResultDto[]> response = restTemplate.execute(
                brokerSourcesServiceEndpoint,
                HttpMethod.POST,
                restTemplate.httpEntityCallback(
                    new HttpEntity<>(brokerDetails, constructHeadersForJsonRequest(brand)),
                    BrokerSourceResultDto[].class
                ),
                new CustomResponseExtractor(
                    restTemplate.responseEntityExtractor(BrokerSourceResultDto[].class), brokerDetails),
                (Object) null
            );

            BrokerSourceResultDto[] results = response == null ? null : response.getBody();

            if (response == null || results == null || results.length == 0) {
              log.error(
                  "Broker sources not found for broker with FCA number {}, firm name {}, and network info {} - Throwing BrokerSourcesException",
                  brokerDetails.getFcaReference(), brokerDetails.getFirmName(), brokerDetails.getNetworkInfo());
              throw new BrokerSourcesException(NO_MATCHING_BROKER_SOURCES);
            }

            log.debug("Broker sources successfully retrieved for broker with FCA number {}, firm name {}, and network info {}",
                brokerDetails.getFcaReference(), brokerDetails.getFirmName(), brokerDetails.getNetworkInfo());

            return results;

        } catch (RestClientException ex) {
          log.warn("A rest client exception occurred while retrieving broker sources from {} for broker with FCA number {}, firm name {}, and network info {}: {}",
              brokerSourcesServiceEndpoint, brokerDetails.getFcaReference(), brokerDetails.getFirmName(), brokerDetails.getNetworkInfo(), ex.getMessage());
          throw ex;
        } catch (Throwable t) {
          log.warn("An unexpected exception occurred while calling {} to get broker info for broker with FCA number {}, firm name {}, and network info {}: {}",
              brokerSourcesServiceEndpoint, brokerDetails.getFcaReference(), brokerDetails.getFirmName(), brokerDetails.getNetworkInfo(), t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
          throw t;
        }

    }

    // A custom response extractor is needed to detect errors due to multiple matching broker sources.
    // When there are multiple matches the service sends a 207 response, which is interpreted as success,
    // but the response body cannot be deserialised normally.
    private static class CustomResponseExtractor implements ResponseExtractor<ResponseEntity<BrokerSourceResultDto[]>> {
        private final ResponseExtractor<ResponseEntity<BrokerSourceResultDto[]>> defaultExtractor;
        private final BrokerSourcesRequestDto brokerDetails;

        public CustomResponseExtractor(ResponseExtractor<ResponseEntity<BrokerSourceResultDto[]>> defaultExtractor, BrokerSourcesRequestDto brokerDetails) {
            this.defaultExtractor = defaultExtractor;
            this.brokerDetails = brokerDetails;
        }

        @SneakyThrows
        @Override
        public ResponseEntity<BrokerSourceResultDto[]> extractData(ClientHttpResponse response) throws IOException {
            if (response.getStatusCode().value() == 207) {
                // NOTE: 207 is not an appropriate response code, but it is what this service does
                log.error(
                  "Found multiple broker source IDs for broker with FCA number {}, firm name {}, and network info {} - Throwing BrokerSourcesException",
                  brokerDetails.getFcaReference(), brokerDetails.getFirmName(), brokerDetails.getNetworkInfo());
                throw new BrokerSourcesException(MULTIPLE_MATCHING_BROKER_SOURCES);
            }

            return defaultExtractor.extractData(response);
        }
    }
}
