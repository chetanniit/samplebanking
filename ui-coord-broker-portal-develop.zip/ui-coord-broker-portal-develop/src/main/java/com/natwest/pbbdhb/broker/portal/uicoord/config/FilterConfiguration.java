package com.natwest.pbbdhb.broker.portal.uicoord.config;

import com.natwest.pbbdhb.broker.portal.uicoord.brand.BrandHeaderFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({"dev", "local"})
public class FilterConfiguration {

    @Bean("brandHeaderFilter")
    public FilterRegistrationBean<BrandHeaderFilter> brandHeaderFilter() {
        FilterRegistrationBean<BrandHeaderFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new BrandHeaderFilter());
        registrationBean.setOrder(Integer.MIN_VALUE);
        registrationBean.addUrlPatterns("/*");
        registrationBean.setName("brandHeaderFilter");
        return registrationBean;
    }

}
