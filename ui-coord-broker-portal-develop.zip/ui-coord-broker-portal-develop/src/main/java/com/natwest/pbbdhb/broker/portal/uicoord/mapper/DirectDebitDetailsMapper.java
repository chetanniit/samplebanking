package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.DirectDebitDetails;
import com.natwest.pbbdhb.cases.dto.DirectDebitDetailsDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DirectDebitDetailsMapper {

    @Mapping(target = "sortCode", source = "sortcode")
    DirectDebitDetails toDirectDebitDetails(DirectDebitDetailsDto directDebitDetailsDto);

    @Mapping(target = "sortcode", source = "sortCode")
    @Mapping(target = "mandate", source = "attestation")
    DirectDebitDetailsDto toDirectDebitDetailsDto(DirectDebitDetails directDebitDetails);
}
