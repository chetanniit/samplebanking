package com.natwest.pbbdhb.broker.portal.uicoord.util.logging;

public class LogMessageSubtype {

  public static String ERROR_RESPONSE = "ErrorResponse";
  public static String DIP_SUBMIT = "DIPSubmit";
  public static String DIP_CERTIFICATE = "DIPCertificate";
  public static String FMA_SUBMIT = "FMASubmit";
}
