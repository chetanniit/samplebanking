package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Ownership;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExistingMortgage {
    @NotNull
    private Long monthlyRepaymentAmount;
    @NotNull
    private Boolean redeemingMortgage;
    @NotNull
    @ValidateEnum(enumClass = ApplicationType.class)
    private String type;
    @NotNull
    @ValidateEnum(enumClass = Ownership.class)
    private String ownership;
    @NotNull
    private Long outstandingAmount;
    @NotNull
    @Size(max = 30)
    private String lenderName;
    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String originatingCurrency;
}