package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrokerDeclarationRequestDto {

    @NotNull
    private BrokerRequestDto broker;

    @NotNull
    private ApplicationType applicationType;

    @NotNull
    private DocumentKey documentKey;

    public enum ApplicationType {
        DIP, FMA
    }

    public enum DocumentKey {
        CUSTOMER_DECLARATION, INTERMEDIARY_DECLARATION, KNOW_YOUR_PROPERTY_DECLARATION, FMA_SUBMISSION_DECLARATION, DIRECT_DEBT_GUARANTEE
    }

}
