package com.natwest.pbbdhb.broker.portal.uicoord.util;

import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;

import java.util.ArrayList;
import java.util.Optional;

public final class BrokerClaimsUtil {
    // prevent instantiation
    private BrokerClaimsUtil() {
    }

    public static PaymentPath getPaymentPathById(BrokerInfo brokerInfo, String paymentPathId) {
        Integer paymentPathIdAsInteger = Integer.parseInt(paymentPathId);
        return getPaymentPathById(brokerInfo, paymentPathIdAsInteger);
    }

    public static PaymentPath getPaymentPathById(BrokerInfo brokerInfo, Integer paymentPathId) {
        return Optional.ofNullable(brokerInfo)
                .map(BrokerInfo::getPaymentPaths)
                .orElse(new ArrayList<>())
                .stream()
                .filter(paymentPath -> paymentPath.getPaymentPathId().equals(paymentPathId))
                .findFirst()
                .orElse(null);
    }

    public static String getPaymentPathScale(PaymentPath paymentPath, String applicationType) {
        switch (ApplicationType.valueOf(applicationType)) {
            case RESIDENTIAL:
                return Optional.ofNullable(paymentPath)
                        .map(PaymentPath::getPaymentPathScaleResidential)
                        .orElseThrow(() -> new IllegalStateException("No payment scale present in payment path!"));
            case BUY_TO_LET:
                return Optional.ofNullable(paymentPath)
                        .map(PaymentPath::getPaymentPathScaleBtl)
                        .orElseThrow(() -> new IllegalStateException("No payment scale present in payment path!"));
            default:
                throw new IllegalStateException("Incorrect application type!");
        }
    }
}
