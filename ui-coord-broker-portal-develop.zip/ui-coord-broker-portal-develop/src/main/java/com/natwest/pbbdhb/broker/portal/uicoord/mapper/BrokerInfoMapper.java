package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerDetailsDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.PaymentPathDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public interface BrokerInfoMapper {
    @Mapping(target = "brokerId", source = "broker.brokerId")
    @Mapping(target = "brokerDetails.userName", source = "broker.username")
    @Mapping(target = "brokerDetails.firstName", source = "broker.firstName")
    @Mapping(target = "brokerDetails.lastName", source = "broker.lastName")
    @Mapping(target = "brokerDetails.title", source = "broker.title")
    @Mapping(target = "brokerDetails.emailAddress", source = "broker.emailAddress")
    @Mapping(target = "brokerDetails.mobilePhone", ignore = true)
    @Mapping(target = "brokerDetails.otherPhone", ignore = true)
    @Mapping(target = "brokerDetails.postcode", source = "broker.brokerPostcode")
    @Mapping(target = "firmDetails.firmId", source = "firm.firmId")
    @Mapping(target = "firmDetails.firmName", source = "firm.firmName")
    @Mapping(target = "firmDetails.fcaNumber", source = "firm.fcaNumber")
    @Mapping(target = "firmDetails.principalFCANumber", source = "firm.principleFcaNumber")
    @Mapping(target = "firmDetails.tradingName", source = "tradingName.name")
    @Mapping(target = "firmDetails.address.line1", source = "firm.firmAddressLine1")
    @Mapping(target = "firmDetails.address.line2", source = "firm.firmAddressLine2")
    @Mapping(target = "firmDetails.address.line3", source = "firm.firmAddressLine3")
    @Mapping(target = "firmDetails.address.city", source = "firm.firmAddressCity")
    @Mapping(target = "firmDetails.address.county", source = "firm.firmAddressCounty")
    @Mapping(target = "firmDetails.address.postcode", source = "firm.firmAddressPostcode")
    @Mapping(target = "firmDetails.address.country", source = "firm.firmAddressCountry")
    @Mapping(target = "paymentPaths", source = "paymentPaths", qualifiedByName = "paymentPathsMapper")
    BrokerInfo toBroker(BrokerInfoResponseDto brokerDto);

    @AfterMapping
    default void afterMappingToBroker(BrokerInfoResponseDto brokerInfoDto, @MappingTarget BrokerInfo brokerInfo) {
        BrokerDetailsDto brokerDetailsDto = brokerInfoDto.getBroker();
        BrokerDetails brokerDetails = brokerInfo.getBrokerDetails();
        if (brokerDetailsDto == null || brokerDetails == null) {
            return;
        }

        if (brokerDetailsDto.getMobileNumber() != null) {
            brokerDetails.setMobilePhone(brokerDetailsDto.getMobileNumber().replace(" ", ""));
        }

        if (brokerDetailsDto.getBusinessPhone() != null) {
            brokerDetails.setOtherPhone(brokerDetailsDto.getBusinessPhone().replace(" ", ""));
        }
    }

    @Named("paymentPathsMapper")
    static PaymentPath paymentPathsMapper(PaymentPathDto paymentPathDto) {
        return PaymentPath.builder()
            .paymentPathId(paymentPathDto.getPaymentPathId())
            .paymentPathName(paymentPathDto.getPaymentPathname())
            .paymentPathScaleBtl(paymentPathDto.getBtlProductScale())
            .paymentPathScaleResidential(paymentPathDto.getResidentialProductScale())
            .build();
    }
}
