package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.ConditionalRegexValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>ConditionalRegexValidation enables testing for non-null attributes that need to be validated against a regex
 * when a specified String attribute matches a specified Sting value.</p>
 * <p>Example:</p>
 * <code>conditionalValidatedField=postcode,
 * <br>conditionField=country,
 * <br>conditionValue=GB,
 * <br>regexp="^[A-Z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}$",
 * <br>caseInsensitive=true</code>
 * <p>will flag as invalid postcode values that don't match the given case insensitive regex when the country attribute
 * value is GB, with defaultErrorMessage:</p>
 * <code>'postcode' must match '^[A-Z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}$' when 'country' is 'GB'</code>.
 */
@Target({TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = ConditionalRegexValidator.class)
public @interface ConditionalRegexValidation {

    public static final String DEFAULT_ERROR_MESSAGE_KEY = "defaultErrorMessage";
    public static final String DEFAULT_ERROR_MESSAGE_TEMPLATE = "'%s' must match '%s' when '%s' is '%s'";

    String message() default "${"+DEFAULT_ERROR_MESSAGE_KEY+"}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String conditionalValidatedField();
    String conditionField();
    String conditionValue();
    String regexp();
    boolean caseInsensitive() default false;
}
