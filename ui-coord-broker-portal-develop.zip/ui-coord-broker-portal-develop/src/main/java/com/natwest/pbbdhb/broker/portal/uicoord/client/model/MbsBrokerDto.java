package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MbsBrokerDto {

  private String mbs_message;

  private List<MbsPaymentPathDto> mbs_paymentPaths;
}
