package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

@Data
public class PortfolioLandlord {

    @Min(0)
    @Max(99)
    private Integer numberOfYearsAsLandlord;

    private Boolean planToExtendIn5Years;

    @Size(min = 5, max = 300)
    private String extendNotes;

    private Boolean planToSellIn5Years;

    @Size(min = 5, max = 300)
    private String sellNotes;
}
