package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BROKER_JOURNEY_VERSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BROKER_FEE_CHARGED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BTL_FAMILY;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BTL_FOR_INVESTMENT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BTL_MOVING_AT_COMPLETION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BTL_NOT_HMO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BTL_SHORT_ASSURED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_CURRENT_ROUTE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_EPC_RATING_A_OR_B_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_FIRST_TIME_BUYER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_ADDITIONAL_BORROWING;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_DEPENDANTS;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_IS_PRODUCT_FEE_PAYMENT_SELECTED;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_LEASEHOLD_OWNERSHIP_TERM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_REPAYMENT_STRATEGY_ADDRESSES;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_1;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_2;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_3;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_USING_SPECIALIST_SCHEME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DataUtils.toDataObject;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.CaseJourneyDataDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.MortgageSchemeMappingHelper.CapieMortgageScheme;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Broker;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BuyToLet;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Deposit;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty;
import com.natwest.pbbdhb.broker.portal.uicoord.model.OtherProperty.PropertyUsage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.RepaymentDetail;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.model.SolicitorAddress;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DepositDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import com.natwest.pbbdhb.cases.dto.OtherPropertyDto;
import com.natwest.pbbdhb.cases.dto.RepaymentDetailDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import com.natwest.pbbdhb.commondictionaries.enums.cases.LevelOfService;
import com.natwest.pbbdhb.commondictionaries.enums.cases.MortgageAdvised;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.BeanMapping;
import org.mapstruct.Builder;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

@Slf4j
@Mapper(uses = {EstateAgentMapper.class, SolicitorMapper.class, ProductDetailsMapper.class, NapoliBrokerMapper.class, DipResultMapper.class, HardscoreDecisionMapper.class, BasicAddressMapper.class, DirectDebitDetailsMapper.class}, builder = @Builder(disableBuilder = true))
public abstract class CaseApplicationAutoMapper {

  @Mapping(target = "schemeType", source = "schemeType")
  @Mapping(target = "firstTimeBuyer", ignore = true)
  @Mapping(target = "usingSpecialistScheme", ignore = true)
  @Mapping(target = "hasDependants", ignore = true)
  @Mapping(target = "currentRoute", ignore = true)
  @Mapping(target = "repaymentStrategyAddresses", ignore = true)
  @Mapping(target = "productDetails", source = "caseApplicationDto.salesIllustrations")
  @Mapping(target = "decisionInPrinciple", source = "caseApplicationDto.decisionInPrinciples")
  @Mapping(target = "mafDocumentName", source = "caseApplicationDto.mafDocumentUrl", qualifiedByName = "getMafDocumentName")
  @Mapping(target = "hasCompletedDip", ignore = true)
  @Mapping(target = "leaseholdOwnershipTerm", ignore = true)
  @Mapping(target = "isProductSelectedAtDip", ignore = true)
  @Mapping(target = "brokerJourneyVersion", ignore = true)
  @Mapping(target = "epcRatingAOrBDip", ignore = true)
  @Mapping(target = "isProductFeePaymentSelected", ignore = true)
  abstract CaseApplication toCaseApplication(String schemeType, CaseApplicationDto caseApplicationDto);

    @Mapping(target = "additionalBorrowing", ignore = true)
    @Mapping(target = "buyToLet.isRentingToImmediateFamilyMember", ignore = true)
    @Mapping(target = "buyToLet.isAssuredShortHoldOrShortAssured", ignore = true)
    @Mapping(target = "buyToLet.isNotSelectiveLicenceOrHMO", ignore = true)
    @Mapping(target = "buyToLet.isForInvestment", ignore = true)
    @Mapping(target = "buyToLet.movingToPropertyAtCompletion", ignore = true)
    abstract Mortgage toMortgage(MortgageDto mortgageDto);

    @Mapping(target = "caseId", source = "caseId")
    @Mapping(target = "schemeType", source = "capieMortgageScheme.schemeType")
    @Mapping(target = "journeyData", ignore = true)
    @Mapping(target = "mortgage.rightToBuy", ignore = true) // special handling for rightToBuy in CaseApplicationMapper
    @Mapping(target = "salesIllustrations", source = "caseApplication.productDetails")
    @Mapping(target = "decisionInPrinciples", ignore = true) // special handling in CaseServiceImpl
    @Mapping(target = "additionalServicesRequired", constant = "EKYC")
    @Mapping(target = "branch", constant = "GMOI")
    @Mapping(target = "directApplication", constant = "N")
    @Mapping(target = "mortgage.mortgageGuarantee", constant = "false")
    @Mapping(target = "mortgageReferenceNumber", ignore = true)
    @Mapping(target = "mortgageTempReferenceNumber", ignore = true)
    @Mapping(target = "racfId", ignore = true)
    @Mapping(target = "contactPermission", ignore = true)
    @Mapping(target = "primaryAdvisorRacfId", ignore = true)
    @Mapping(target = "secondaryAdvisorRacfId", ignore = true)
    @Mapping(target = "channel", ignore = true)
    @Mapping(target = "marketingSchemeNumber", ignore = true)
    @Mapping(target = "marketingSource", ignore = true)
    @Mapping(target = "movingToPropertyAtCompletion", ignore = true)
    @Mapping(target = "applicationStatus", ignore = true)
    @Mapping(target = "hardscoreDecision", ignore = true)
    @Mapping(target = "mortgageApplSeq", ignore = true)
    @Mapping(target = "salesIllustrationTempReferenceNumber", ignore = true)
    @Mapping(target = "exceptionPolicies", ignore = true)
    @Mapping(target = "mortgage.mortgageAdvisor", ignore = true)
    @Mapping(target = "caseNotes", ignore = true) // special handling to generate from repayment strategy addresses
    @Mapping(target = "createdDate", ignore = true)
    @Mapping(target = "modifiedDate", ignore = true)
    @Mapping(target = "isEsis", ignore = true)
    @Mapping(target = "taxStatus", ignore = true)
    @Mapping(target = "hmrcConsent", ignore = true)
    @Mapping(target = "mafDocumentUrl", ignore = true) // Case should be locked by the time this is populated, so doesn't need special handling
    @Mapping(target = "mortgage.existingMortgageTransfer", ignore = true)
    @Mapping(target = "mortgage.buyToLet.originatingCurrency", ignore = true)
    @Mapping(target = "affordableHousingFlag", constant = "false", ignore = true)//TODO this need to be removed once we know what to do about this field
    abstract CaseApplicationDto toCaseApplicationDto(String caseId, String buyerType, CapieMortgageScheme capieMortgageScheme, CaseApplication caseApplication,
                                                     @Context BrokerInfo broker);

    @Mapping(target = "lastUpdated", ignore = true)
    @Mapping(target = "monthlyNetRentalIncome", ignore = true)
    @Mapping(target = "propertyRedemption", source = "propertyRedemption")
    @Mapping(target = "runningCost", source = "hasPropertyRunningCosts")
    abstract OtherPropertyDto toOtherPropertyDto(OtherProperty otherProperty);

    @Mapping(target = "hasPropertyRunningCosts", source = "runningCost")
    abstract OtherProperty toOtherProperty(OtherPropertyDto otherPropertyDto);

    @Mapping(target = "repaymentStartDate", ignore = true)
    @Mapping(target = "repaymentSumAssured", ignore = true)
    @Mapping(target = "repaymentValueAtMaturity", ignore = true)
    @Mapping(target = "repaymentMortgageAmount", ignore = true)
    @Mapping(target = "repaymentVerificationType", ignore = true)
    @Mapping(target = "repaymentStrategyStatus", ignore = true)
    @Mapping(target = "repaymentVerificationDate", ignore = true)
    @Mapping(target = "repaymentProjectedValuation", ignore = true)
    abstract RepaymentDetailDto toRepaymentDetailDto(RepaymentDetail repaymentDetail);

    abstract DepositDto toDepositDto(Deposit deposit);

    @AfterMapping
    void afterMappingToCaseApplicationDto(@MappingTarget CaseApplicationDto caseApplicationDto) {
        if (caseApplicationDto != null && nonNull(caseApplicationDto.getMortgage()) && nonNull(caseApplicationDto.getServiceLevel()) && nonNull(caseApplicationDto.getServiceLevel().getLevelOfService())) {
            String advised = caseApplicationDto.getServiceLevel().getLevelOfService().equals(LevelOfService.ADVISED.toString())
                    ? MortgageAdvised.ADVICE.toString()
                    : MortgageAdvised.REJECTED_ADVICE_EXECUTION_ONLY.toString();
            caseApplicationDto.getMortgage().setMortgageAdvised(advised);
        }
    }

    @AfterMapping
    void afterMappingToCaseApplication(CaseApplicationDto caseApplicationDto, @MappingTarget CaseApplication caseApplication) {
        CaseJourneyDataDto journeyDataDto = toDataObject(caseApplicationDto.getJourneyData(), CaseJourneyDataDto.class);

        if (journeyDataDto == null) {
            return;
        }

        caseApplication.setCurrentRoute(journeyDataDto.getCurrentRoute());
        caseApplication.setFirstTimeBuyer(journeyDataDto.getFirstTimeBuyer());
        caseApplication.setUsingSpecialistScheme(journeyDataDto.getUsingSpecialistScheme());
        caseApplication.setHasDependants(journeyDataDto.getHasDependants());
        caseApplication.setRepaymentStrategyAddresses(journeyDataDto.getRepaymentStrategyAddresses());
        caseApplication.setHasCompletedDip(journeyDataDto.getHasCompletedDip());
        caseApplication.setLeaseholdOwnershipTerm(journeyDataDto.getLeaseholdOwnershipTerm());
        caseApplication.setIsProductSelectedAtDip(journeyDataDto.getIsProductSelectedAtDip());
        caseApplication.setBrokerJourneyVersion(journeyDataDto.getBrokerJourneyVersion());
        caseApplication.setEpcRatingAOrBDip(journeyDataDto.getEpcRatingAOrBDip());
        caseApplication.setIsProductFeePaymentSelected(journeyDataDto.getIsProductFeePaymentSelected());
        Solicitor solicitor = caseApplication.getSolicitor();

        if (solicitor != null && solicitor.getAddress() != null) {
            SolicitorAddress address = solicitor.getAddress();
            address.setAddress1(journeyDataDto.getSolicitorAddress1());
            address.setAddress2(journeyDataDto.getSolicitorAddress2());
            address.setAddress3(journeyDataDto.getSolicitorAddress3());
        }

        Broker broker = caseApplication.getBroker();

        if (broker != null) {
            broker.setBrokerFeeCharged(journeyDataDto.getBrokerFeeCharged());
        }


        ProductDetails productDetails = caseApplication.getProductDetails();

        if (productDetails != null) {
            productDetails.setHasAdditionalBorrowing(journeyDataDto.getHasAdditionalBorrowing());
        }

        if (journeyDataDto.getIsAssuredShortHoldOrShortAssured() != null
                || journeyDataDto.getIsForInvestment() != null
                || journeyDataDto.getIsNotSelectiveLicenceOrHMO() != null
                || journeyDataDto.getIsRentingToImmediateFamilyMember() != null
                || journeyDataDto.getMovingToPropertyAtCompletion() != null) {
            Mortgage mortgage = caseApplication.getMortgage();
            if (mortgage == null) {
                mortgage = new Mortgage();
                caseApplication.setMortgage(mortgage);
            }
            BuyToLet btl = caseApplication.getMortgage().getBuyToLet();
            if (btl == null) {
                btl = new BuyToLet();
                mortgage.setBuyToLet(btl);
            }
            btl.setIsRentingToImmediateFamilyMember(journeyDataDto.getIsRentingToImmediateFamilyMember());
            btl.setIsAssuredShortHoldOrShortAssured(journeyDataDto.getIsAssuredShortHoldOrShortAssured());
            btl.setIsForInvestment(journeyDataDto.getIsForInvestment());
            btl.setIsNotSelectiveLicenceOrHMO(journeyDataDto.getIsNotSelectiveLicenceOrHMO());
            btl.setMovingToPropertyAtCompletion(journeyDataDto.getMovingToPropertyAtCompletion());
        }
    }

    @AfterMapping
    void afterMappingToCaseApplicationDto(CaseApplication caseApplication, @MappingTarget CaseApplicationDto caseApplicationDto) {
        ProductDetails productDetails = caseApplication.getProductDetails();

        if (isNull(caseApplicationDto.getJourneyData())) {
            caseApplicationDto.setJourneyData(new HashMap<>());
        }

        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_CURRENT_ROUTE, caseApplication.getCurrentRoute());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_FIRST_TIME_BUYER, caseApplication.getFirstTimeBuyer());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_USING_SPECIALIST_SCHEME, caseApplication.getUsingSpecialistScheme());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_HAS_DEPENDANTS, caseApplication.getHasDependants());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_REPAYMENT_STRATEGY_ADDRESSES, caseApplication.getRepaymentStrategyAddresses());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BROKER_FEE_CHARGED, caseApplication.getBroker().getBrokerFeeCharged());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_LEASEHOLD_OWNERSHIP_TERM, caseApplication.getLeaseholdOwnershipTerm());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP, caseApplication.getIsProductSelectedAtDip());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BROKER_JOURNEY_VERSION, caseApplication.getBrokerJourneyVersion());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_EPC_RATING_A_OR_B_DIP, caseApplication.getEpcRatingAOrBDip());
        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_IS_PRODUCT_FEE_PAYMENT_SELECTED, caseApplication.getIsProductFeePaymentSelected());

        if (nonNull(caseApplication.getSolicitor()) && nonNull(caseApplication.getSolicitor().getAddress())) {
            SolicitorAddress solicitorAddress = caseApplication.getSolicitor().getAddress();
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_1, solicitorAddress.getAddress1());
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_2, solicitorAddress.getAddress2());
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_3, solicitorAddress.getAddress3());
        }

        if (nonNull(caseApplication.getMortgage()) && nonNull(caseApplication.getMortgage().getBuyToLet())) {
            BuyToLet btl = caseApplication.getMortgage().getBuyToLet();
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BTL_SHORT_ASSURED, btl.getIsAssuredShortHoldOrShortAssured());
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BTL_FOR_INVESTMENT, btl.getIsForInvestment());
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BTL_NOT_HMO, btl.getIsNotSelectiveLicenceOrHMO());
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BTL_FAMILY, btl.getIsRentingToImmediateFamilyMember());
            caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_BTL_MOVING_AT_COMPLETION, btl.getMovingToPropertyAtCompletion());

            // The below fields are mandatory, but not present the first time BTL information is captured
            // As the above is in journey data, BTL is essentially empty, and needs nulled out to properly save in CAPIE
            if (isNull(btl.getMonthlyRentalIncome()) && isNull(btl.getIcrTaxRate()) && isNull(btl.getUseLettingAgent())) {
                caseApplicationDto.getMortgage().setBuyToLet(null);
            }
        }

        // Build case notes of repayment strategy property addresses
        if (checkApplicationHasRepaymentFields(caseApplication)) {

            List<@Valid RepaymentDetail> repaymentDetails = caseApplication.getMortgage().getInterestOnly().getRepaymentDetails();

          addCaseNotesForRepaymentAddress(caseApplication, caseApplicationDto, repaymentDetails);
        }

        if (productDetails == null || productDetails.getProductCode() == null) {
            return;
        }

        caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_HAS_ADDITIONAL_BORROWING, productDetails.getHasAdditionalBorrowing());
    }

    private void addCaseNotesForRepaymentAddress(CaseApplication caseApplication, CaseApplicationDto caseApplicationDto,
        List<@Valid RepaymentDetail> repaymentDetails) {
        if (repaymentDetails.size() == caseApplication.getRepaymentStrategyAddresses().size()) {
            StringBuilder builder = new StringBuilder();
            updateRepaymentStrategyAddress(caseApplication, repaymentDetails, builder);
            if (builder.length() >= 5) {
                  if (builder.length() > 1000) {
                      log.warn("Trimming repayment strategy addresses to fit in case notes. Original length={}", builder.length());
                      builder.setLength(1000);
                  }
                  // size must be 5 to 1000
                  caseApplicationDto.setCaseNotes(builder.toString());
              }
        } else {
            log.warn("Repayment strategy address size {} does not match repayment details size {}",
                    caseApplication.getRepaymentStrategyAddresses(), repaymentDetails.size());
        }
    }

    private void updateRepaymentStrategyAddress(CaseApplication caseApplication,
        List<@Valid RepaymentDetail> repaymentDetails, StringBuilder builder) {
        for (int index = 0; index < repaymentDetails.size(); index++) {
            String address = caseApplication.getRepaymentStrategyAddresses().get(index);
            if (nonNull(address)) {
                if (builder.length() > 0) {
                    builder.append("\n\n");
                }
                RepaymentDetail repaymentDetail = repaymentDetails.get(index);
                builder.append(repaymentDetail.getRepaymentStrategyType())
                        .append(" ").append(repaymentDetail.getRepaymentValue())
                        .append("\n").append(address);
            }
        }
    }

    private boolean checkApplicationHasRepaymentFields(CaseApplication caseApplication) {
            return nonNull(caseApplication.getRepaymentStrategyAddresses()) &&
                   nonNull(caseApplication.getMortgage()) &&
                   nonNull(caseApplication.getMortgage().getInterestOnly()) &&
                   nonNull(caseApplication.getMortgage().getInterestOnly().getRepaymentDetails());
        }

  // Explicitly ignore unmapped fields to avoid having to have an annotation for every field not mentioned below
    @BeanMapping(unmappedTargetPolicy = ReportingPolicy.IGNORE)
    @Mapping(target = "hardscoreDecision", source = "fmaResponse.data.hardscoreDecision")
    @Mapping(target = "mortgageReferenceNumber", source = "fmaResponse.data.mortgageNumber")
    @Mapping(target = "mortgageTempReferenceNumber", source = "fmaResponse.data.tempRefNo")
    @Mapping(target = "mortgageApplSeq", source = "fmaResponse.data.applSeq")
    abstract CaseApplicationDto updateCaseApplicationDtoFromFmaResponse(@MappingTarget CaseApplicationDto caseApplicationDto, FullMortgageApplicationExtendedResponse fmaResponse);

    @AfterMapping
    void afterMappingToCaseApplicationDto(@MappingTarget CaseApplicationDto caseApplicationDto, FullMortgageApplicationExtendedResponse fmaResponse) {
        String status = (isNull(fmaResponse) || isNull(fmaResponse.getResponseStatus())) ? null : fmaResponse.getResponseStatus().getStatus();
        if ("201".equals(status)) {
            caseApplicationDto.setApplicationStatus(ApplicationStatus.SUBMIT_GMS_STAGE_20.toString());
        } else if ("202".equals(status)) {
            caseApplicationDto.setApplicationStatus(ApplicationStatus.SUBMIT_FMA_IN_PROGRESS.toString());
        }
    }

  @AfterMapping
  void afterMappingToOtherPropertyDto(@MappingTarget OtherPropertyDto otherPropertyDto, OtherProperty otherProperty) {
    final String propertyNotes = otherProperty.getPropertyNotes();
    final Boolean propertyRedemption = otherProperty.getPropertyRedemption();
    final String propertyUsage = otherProperty.getPropertyUsage();

    if (propertyRedemption != null && propertyRedemption.equals(Boolean.FALSE)
        && propertyNotes == null) {
      otherPropertyDto.setPropertyNotes("Property not being sold");
    } else {
      otherPropertyDto.setPropertyNotes(otherProperty.getPropertyNotes());
    }

    if (PropertyUsage.RESIDENTIAL.toString().equals(propertyUsage)) {
      otherPropertyDto.setMonthlyNetRentalIncome(null);
    } else {
      BigDecimal monthlyNetRentalIncomeBigDecimal = Optional.ofNullable(otherProperty.getMonthlyNetRentalIncome())
          .map(BigDecimal::valueOf)
          .orElse(null);
      otherPropertyDto.setMonthlyNetRentalIncome(monthlyNetRentalIncomeBigDecimal);
    }
  }

    // Full URL should not be exposed to frontend
    @Named("getMafDocumentName")
    public String getMafDocumentName(String mafDocumentUrl) {
        return Optional.ofNullable(mafDocumentUrl)
                .map(s -> StringUtils.substringAfterLast(s, "/"))
                .orElse(null);
    }
}
