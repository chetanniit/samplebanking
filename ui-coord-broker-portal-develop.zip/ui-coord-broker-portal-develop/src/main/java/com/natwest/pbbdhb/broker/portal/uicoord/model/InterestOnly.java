package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MaxTerm;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@Data
@MaxTerm(yearField = "termYears", yearValue = 35, monthField = "termMonths", monthMaxValue = 0)
public class InterestOnly {
    @NotNull
    private BigDecimal amount;

    @NotNull
    @Min(3)
    @Max(35)
    private Integer termYears;

    @NotNull
    @Min(0)
    @Max(11)
    private Integer termMonths;

    @NotEmpty
    private List<@Valid RepaymentDetail> repaymentDetails;
}
