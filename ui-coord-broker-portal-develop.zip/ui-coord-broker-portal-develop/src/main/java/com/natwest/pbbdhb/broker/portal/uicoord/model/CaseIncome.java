package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import java.util.List;

@Data
public class CaseIncome {
    private String version;
    private List<@Valid IncomeApplicant> applicants;
}
