package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseIdGenerationClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.EsisClient;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.EsisApplicantMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.EsisCaseMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.EsisMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.EsisService;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import com.rbs.pbbdhb.sales.esis.models.Application;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.Optional.ofNullable;

@Service
@RequiredArgsConstructor
@Slf4j
public class EsisServiceImpl implements EsisService {

    private static final String URL_PATH_SEPARATOR = "/";
    private static final String DOCUMENT_DESCRIPTION_FIELD_NAME = "esisDocumentDescription";
    private final ApplicantClientNapoli applicantClient;
    private final CaseClientNapoli caseClient;
    private final CaseIdGenerationClient caseIdGenerationClient;
    private final EsisClient esisClient;
    private final EsisMapper esisMapper;
    private final EsisApplicantMapper esisApplicantMapper;
    private final EsisCaseMapper esisCaseMapper;
    private final UserClaimsProvider userClaimsProvider;
    private final BrokerInfoService brokerInfoService;

    @Override
    public InputStreamResource getEsisDocument(String documentName) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.debug("Calling esisClient to get ESIS document with name {} and brokerUsername {}", documentName, brokerUsername);
        InputStream esisPdfStream = esisClient.getEsis(documentName);
        log.debug("esisClient successfully called to get ESIS document with name {} and brokerUsername {}", documentName, brokerUsername);
        return new InputStreamResource(esisPdfStream);
    }

    @Override
    public InputStreamResource getEsisDocumentWithCaseId(String brand, String caseId) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.debug("Getting ESIS document name for caseId {} and brokerUsername {}", caseId, brokerUsername);
        final String documentName = getDocumentNameFromCase(brand, caseId);
        return getEsisDocument(documentName);
    }

    @Override
    public EsisResponse createEsisDocument(EsisData esisData, String username, String brand) {
        log.debug("Calling brokerInfoService to get broker with brokerUsername {}", username);
        BrokerInfo broker = brokerInfoService.getBroker(username);
        log.debug("brokerInfoService successfully called to get broker with brokerUsername {}: {}", username, broker);

        log.debug("Calling caseIdGenerationClient to generate case ID for brokerUsername {} and brand {}", username, brand);
        final String caseId = caseIdGenerationClient.generateCaseId(brand);
        log.debug("caseIdGenerationClient successfully called to generate case ID for brokerUsername {} and brand {}: caseId {}", username, brand, caseId);

        final CaseApplicationDto caseApplicationDto = esisCaseMapper.toCaseApplicationDto(esisData, broker, caseId);
        log.debug("Calling caseClient to create case with caseId {} and brokerUsername {}", caseId, username);
        final CaseApplicationDto capieCase = caseClient.createCase(brand, caseApplicationDto);
        log.debug("caseClient successfully called to create case with caseId {} and brokerUsername {}", caseId, username);

        final List<EsisApplicant> applicants = esisData.getApplicants();
        for (int i = 0; i < applicants.size(); i++) {
            final EsisApplicant esisApplicant = applicants.get(i);
            final boolean mainApplicant = i == 0;
            final ApplicantDto capieApplicantDto = esisApplicantMapper.toApplicantDto(esisApplicant, caseId, mainApplicant);
            log.debug("Calling applicantClient to save applicant with caseId {} and brokerUsername {}", caseId, username);
            final ApplicantDto capieApplicantRecord = applicantClient.saveApplicant(brand, capieApplicantDto);
            log.debug("applicantClient successfully called to save applicant with caseId {}, applicantId {}, and brokerUsername {}",
                caseId, capieApplicantRecord.getApplicantId(), username);
        }

        final Application esisRequest = esisMapper.mapToEsisApplication(esisData, broker, caseId, capieCase);
        log.debug("Calling esisClient to create ESIS with caseId {} and brokerUsername {}", caseId, username);
        esisClient.createEsis(brand, esisRequest);
        log.debug("esisClient successfully called to create ESIS with caseId {} and brokerUsername {}", caseId, username);

        final String documentName = getDocumentNameFromCase(brand, caseId);
        log.info("ESIS document and CAPIE records successfully created with caseId {}, brokerUsername {}, and documentName: {}",
            caseId, username, documentName);
        return EsisResponse.builder()
                .documentName(documentName)
                .caseId(caseId)
                .build();
    }

    @Override
    public EsisResponse getEsisDocumentInfoWithCaseId(String brand, String caseId) {
        String username = userClaimsProvider.getBrokerUsername();
        log.debug("Calling caseClient to get case with caseId {} and brokerUsername {}", caseId, username);
        final CaseApplicationDto existingCase = caseClient.getCase(brand, caseId);
        log.debug("caseClient successfully called to get case with caseId {} and brokerUsername {}", caseId, username);
        final String documentDescription = (String) ofNullable(existingCase.getJourneyData()).orElse(Collections.emptyMap())
                .getOrDefault(DOCUMENT_DESCRIPTION_FIELD_NAME, (String) null);
        return EsisResponse.builder()
                .caseId(caseId)
                .documentName(getDocumentNameFromCase(brand, caseId))
                .documentDescription(documentDescription)
                .build();
    }

    @Override
    public EsisResponse updateDocumentDescription(String documentDescription, String brand, String caseId) {
        String username = userClaimsProvider.getBrokerUsername();
        log.debug("Calling caseClient to get case with {} and brokerUsername {}", caseId, username);
        final CaseApplicationDto existingCase = caseClient.getCase(brand, caseId);
        log.debug("caseClient successfully called to get case with {} and brokerUsername {}", caseId, username);
        final Map<String, Object> journeyData = ofNullable(existingCase.getJourneyData())
                .orElse(new HashMap<>());
        journeyData.put(DOCUMENT_DESCRIPTION_FIELD_NAME, documentDescription);
        existingCase.setJourneyData(journeyData);

        log.debug("Calling caseClient to update case with {} and brokerUsername {}", caseId, username);
        caseClient.updateCase(brand, existingCase);
        log.debug("caseClient successfully called to update case with {} and brokerUsername {}", caseId, username);
        return EsisResponse.builder()
                .caseId(caseId)
                .documentName(getDocumentNameFromCase(brand, caseId))
                .documentDescription(documentDescription)
                .build();
    }

    private String getDocumentNameFromCase(String brand, String caseId) {
        final CaseApplicationDto capieCasePostEsis = caseClient.getCase(brand, caseId);
        return Optional.of(capieCasePostEsis)
                .map(CaseApplicationDto::getSalesIllustrations).orElse(Collections.emptyList()).stream().findFirst()
                .map(SalesIllustrationDto::getDocumentUrls).orElse(Collections.emptyList()).stream().findFirst()
                .map(s -> StringUtils.substringAfterLast(s, URL_PATH_SEPARATOR))
                .orElse(null);
    }

}
