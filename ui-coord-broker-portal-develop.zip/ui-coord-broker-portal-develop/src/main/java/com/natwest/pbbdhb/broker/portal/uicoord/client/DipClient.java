package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.ApplicationNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.exception.DIPException;
import com.natwest.pbbdhb.exception.MinMaxCalculatorException;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.openapi.product.MinMaxCalculatorRequest.ChannelEnum;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import com.natwest.pbbdhb.service.IntegrationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersWithClientId;
import static java.lang.String.format;


@Component
@Slf4j
public class DipClient {

    private static final String EXCEPTION_MESSAGE_TEMPLATE = "Could not load DIP PDF for %s ID: %s";
    private static final String CASE_FIELD = "case";
    private static final String DIP_FIELD = "DIP";

    private final IntegrationService integrationService;
    private final String getDipCertificateEndpoint;
    private final String getDipDocumentEndpoint;
    private final RestTemplate restTemplate;
    private final String clientId;

    public DipClient(IntegrationService integrationService,
                     @Value("${msvc.dip.certificate.get.url}") String getDipCertificateEndpoint,
                     @Value("${msvc.dip.document.get.url}") String getDipDocumentEndpoint,
                     @Qualifier("iamJwtChainSecureRestTemplate") RestTemplate restTemplate,
                     @Value("${client.id}") String clientId) {
        this.integrationService = integrationService;
        this.getDipCertificateEndpoint = getDipCertificateEndpoint;
        this.getDipDocumentEndpoint = getDipDocumentEndpoint;
        this.restTemplate = restTemplate;
        this.clientId = clientId;
    }

    public DipExtendedResponse submitDip(Application application) throws DipIntegrationException {

        CaseApplicationDto caseApplicationDto = application.getCaseApplication();
        String caseId = caseApplicationDto == null ? null : caseApplicationDto.getCaseId();

        log.info("Calling integrationService to submit DIP with caseId {}", caseId);
        try {
            DipExtendedResponse dipResponse = integrationService.getDIP(application, ChannelEnum.INTERMEDIARY);
            log.info("integrationService successfully called to submit DIP for caseId {}. Processing the result", caseId);
            String errorCode = dipResponse.getErrorCode();
            if (errorCode != null) {
                String errorMessage = dipResponse.getErrorMessage();
                if (errorMessage == null) {
                    errorMessage = "DIP response error code " + errorCode;
                }
                if (errorCode.equals(String.valueOf(HttpStatus.BAD_REQUEST.value()))) {
                    log.warn(
                        "Error response with status {} returned from integrationService while submitting DIP for caseId {}: {} - throwing DipValidationException",
                        errorCode, caseId, errorMessage);
                    throw new DipValidationException(ErrorCode.UNHANDLED, errorMessage);
                }
                log.warn("Error response received from integrationService while submitting DIP for caseId {}: error code {}, error message {} - throwing DipIntegrationException",
                    caseId, errorCode, errorMessage);
                throw new DipIntegrationException(errorMessage);
            }

            log.debug("DIP successfully submitted for caseId {}", caseId);
            return dipResponse;

        } catch (DipValidationException ex) {
            log.trace("Throwing on DipValidationException for caseId {}: {}", caseId, ex.getMessage());
            throw ex;
        } catch (DipIntegrationException ex) {
            log.trace("Throwing on DipIntegrationException for caseId {}: {}", caseId, ex.getMessage());
            throw ex;
        } catch (DIPException | MinMaxCalculatorException | IOException ex) {
            log.warn("Caught {} thrown by integrationService while submitting DIP for caseId {}: {} - throwing DipIntegrationException",
                ex.getClass().getSimpleName(), caseId, ex.getMessage());
            throw new DipIntegrationException(ex.getMessage(), ex);
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            log.warn(
                "An unexpected exception occurred while calling integrationService to submit DIP for caseID {}: {}",
                caseId, message);
            throw new DipIntegrationException(message, t);
        }
    }

    public DipExtendedResponse amendDip(Application application, String dipId) throws DipIntegrationException {

        CaseApplicationDto caseApplicationDto = application.getCaseApplication();
        String caseId = caseApplicationDto == null ? null : caseApplicationDto.getCaseId();

        log.info("Calling integrationService to amend DIP with caseId {} and dipId {}", caseId, dipId);
        try {
            DipExtendedResponse dipResponse = integrationService.getDIPSubsequent(application, dipId, ChannelEnum.INTERMEDIARY);
            log.info("integrationService successfully called to amend DIP for caseId {} and dipId {}. Processing the result", caseId, dipId);
            String errorCode = dipResponse.getErrorCode();
            if (errorCode != null) {
                String errorMessage = dipResponse.getErrorMessage();
                if (errorMessage == null) {
                    errorMessage = "DIP response error code " + errorCode;
                }

                if (errorCode.equals(String.valueOf(HttpStatus.BAD_REQUEST.value()))) {
                    log.warn(
                      "Error response with status {} returned from integrationService while amending DIP for caseId {} and dipId {}: {} - throwing DipValidationException",
                      errorCode, caseId, dipId, errorMessage);
                    throw new DipValidationException(ErrorCode.UNHANDLED, errorMessage);
                }
                log.warn("Error response received from integrationService while amending DIP for caseId {} and dipId {}: error code {}, error message {} - throwing DipIntegrationException",
                  caseId, dipId, errorCode, errorMessage);
                throw new DipIntegrationException(errorMessage);
            }
            log.debug("DIP successfully submitted for caseId {} and dipId {}", caseId, dipId);
            return dipResponse;

        } catch (DipValidationException ex) {
            log.trace("Throwing on DipValidationException for caseId {}: {}", caseId, ex.getMessage());
            throw ex;
        } catch (DipIntegrationException ex) {
            log.trace("Throwing on DipIntegrationException for caseId {}: {}", caseId, ex.getMessage());
            throw ex;
        } catch (DIPException | MinMaxCalculatorException | IOException ex) {
            log.warn("Caught {} thrown by integrationService while submitting DIP for caseId {} and dipId {}: {} - throwing DipIntegrationException",
                ex.getClass().getSimpleName(), caseId, dipId, ex.getMessage());
            throw new DipIntegrationException(ex.getMessage(), ex);
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            log.warn(
                "An unexpected exception occurred while calling integrationService to amend DIP for caseID {} and dipId {}: {}",
                caseId, dipId, message);
            throw new DipIntegrationException(message, t);
        }
    }

    public InputStream getDipCertificate(String brand, String caseId) throws DipIntegrationException {

        log.info("Calling {} to get DIP certificate with caseId {}", getDipCertificateEndpoint, caseId);

        HttpHeaders headers = constructHeadersWithClientId(brand, clientId);
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<byte[]> responseEntity = restTemplate.exchange(
                    getDipCertificateEndpoint, HttpMethod.GET, requestEntity, byte[].class, caseId);

            HttpStatusCode statusCode = responseEntity.getStatusCode();
            if (statusCode == HttpStatus.OK && responseEntity.getBody() != null) {
                  log.debug("DIP certificate for caseId {} successfully retrieved", caseId);
                  return new ByteArrayInputStream(responseEntity.getBody());
            }
            log.error("Error response received from {} while getting DIP certificate for caseId {}: statusCode {} - throwing DipIntegrationException",
                getDipCertificateEndpoint, caseId, statusCode.value());
            throw new DipIntegrationException(format(EXCEPTION_MESSAGE_TEMPLATE, CASE_FIELD, caseId));

        } catch (DipIntegrationException ex) {
            log.trace("Throwing on DipIntegrationException for caseId {}: {}", caseId, ex.getMessage());
            throw ex;
        } catch (RestClientException ex) {
            log.warn(
                "A rest client exception occurred while calling {} to get DIP certificate with caseId {}: {}",
                getDipCertificateEndpoint, caseId, ex.getMessage());
            throw new DipIntegrationException(ex.getMessage(), ex);
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            log.warn(
                "An unexpected exception occurred while calling {} to get DIP certificate with caseId {}: {}",
                getDipCertificateEndpoint, caseId, message);
            throw new DipIntegrationException(message, t);
        }
    }

    public InputStream getDipDocumentByDipId(String brand, String dipId) throws DipIntegrationException {

        log.info("Calling {} to get DIP document with caseId {}", getDipDocumentEndpoint, dipId);

        HttpHeaders headers = constructHeadersWithClientId(brand, clientId);
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<byte[]> responseEntity = restTemplate.exchange(
                getDipDocumentEndpoint, HttpMethod.GET, requestEntity, byte[].class, dipId);

            HttpStatusCode statusCode = responseEntity.getStatusCode();
            if (statusCode == HttpStatus.OK && responseEntity.getBody() != null) {
              log.debug("DIP document for caseId {} successfully retrieved", dipId);
              return new ByteArrayInputStream(responseEntity.getBody());
            }
            log.error("Error response received from {} while getting DIP document for dipId {}: statusCode {} - throwing DipIntegrationException",
                getDipDocumentEndpoint, dipId, statusCode.value());
            throw new DipIntegrationException(format(EXCEPTION_MESSAGE_TEMPLATE, DIP_FIELD, dipId));
        } catch (DipIntegrationException ex) {
            log.trace("Throwing on DipIntegrationException for dipId {}: {}", dipId, ex.getMessage(), ex);
            throw ex;
        } catch (RestClientException ex) {
            if(ex instanceof HttpClientErrorException && ((HttpClientErrorException) ex).getStatusCode().value() == HttpStatus.NOT_FOUND.value()) {
              log.error("Error response received from {} while getting DIP document for dipId {}: NOT_FOUND - throwing ApplicationNotFoundException",
                  getDipDocumentEndpoint, dipId, ex);
              throw new ApplicationNotFoundException(format(EXCEPTION_MESSAGE_TEMPLATE, DIP_FIELD, dipId));
            }
            log.error("Error response received from {} while getting DIP document for dipId {}: {} - throwing DipIntegrationException",
                getDipDocumentEndpoint, dipId, ex.getMessage(), ex);
              throw new DipIntegrationException(ex.getMessage(), ex);
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            log.warn(
                "An unexpected exception occurred while calling {} to get DIP document with dipId {}: {}",
                getDipDocumentEndpoint, dipId, message, t);
            throw new DipIntegrationException(message, t);
        }
    }
}
