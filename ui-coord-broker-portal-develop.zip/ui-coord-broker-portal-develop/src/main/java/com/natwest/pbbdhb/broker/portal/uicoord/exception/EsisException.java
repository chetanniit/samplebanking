package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class EsisException extends RuntimeException {

    public EsisException(String message) {
        super(message);
    }

    public EsisException(String message, Throwable cause) {
        super(message, cause);
    }
}
