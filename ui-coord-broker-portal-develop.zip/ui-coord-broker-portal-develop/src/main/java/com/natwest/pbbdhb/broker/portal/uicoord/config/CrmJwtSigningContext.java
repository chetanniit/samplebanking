package com.natwest.pbbdhb.broker.portal.uicoord.config;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.KeystoreException;
import com.natwest.pbbdhb.broker.portal.uicoord.model.security.CertificateModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.bind.DatatypeConverter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.util.Collections;
import java.util.List;

@Configuration
@Slf4j
public class CrmJwtSigningContext {

  @Bean
  @Qualifier("crmJwtSigningCertificate")
  public CertificateModel signingCertificate(@Autowired CrmJwtSigningConfig config) {

    final KeyStore keyStore = createKeyStore(config);
    final String alias = getAlias(keyStore);
    final String password = config.getPassword();

    return CertificateModel.builder()
        .publicKey(getPublicKey(keyStore, alias))
        .privateKey(getPrivateKey(keyStore, password, alias))
        .certificateThumbPrint(getCertificateThumbPrint(keyStore, alias))
        .build();
  }

  private KeyStore createKeyStore(CrmJwtSigningConfig config) {
    try {
      final char[] password = config.getPassword().toCharArray();
      final byte[] certBytes = DatatypeConverter.parseBase64Binary(config.getCertificate());
      final KeyStore keyStore = KeyStore.getInstance(config.getType());
      keyStore.load(
          new ByteArrayInputStream(certBytes),
          password);
      keyStore.store(
          new ByteArrayOutputStream(),
          password);
      return keyStore;
    } catch (CertificateException | IOException | NoSuchAlgorithmException | KeyStoreException e) {
      throw new KeystoreException("Unable to create keystore", e);
    }
  }

  private String getAlias(KeyStore keyStore)  {
    try {
      List<String> aliases = Collections.list(keyStore.aliases());
      if (aliases.size() == 1) {
        return aliases.get(0);
      }
      throw new KeystoreException(
          String.format(
              "Expected 1 alias in keystore. Found %d.",
              aliases.size()));
    } catch (KeyStoreException e) {
      throw new KeystoreException("Unable to extract aliases from keystore", e);
    }
  }

  private PrivateKey getPrivateKey (
      KeyStore keyStore,
      String password,
      String alias) {
    try {
      final Key key = keyStore.getKey(
          alias,
          password.toCharArray());

      if (!(key instanceof PrivateKey)) {
        throw new KeystoreException("Key is not an instance of a PrivateKey");
      }

      return (PrivateKey) key;
    } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
      throw new KeystoreException("Unable to extract private key from keystore", e);
    }
  }

  private PublicKey getPublicKey (
      KeyStore keyStore,
      String alias) {
    try {
      return keyStore
          .getCertificate(alias)
          .getPublicKey();

    } catch (KeyStoreException e) {
      throw new KeystoreException("Unable to extract public key from keystore", e);
    }
  }

  private String getCertificateThumbPrint (
      KeyStore keyStore,
      String alias) {
    try {
      final Certificate certificate = keyStore
          .getCertificate(alias);
      return DatatypeConverter.printHexBinary(
          MessageDigest
              .getInstance("SHA-1")
              .digest(certificate.getEncoded()))
          .toUpperCase();

    } catch (KeyStoreException | CertificateEncodingException | NoSuchAlgorithmException e) {
      throw new KeystoreException("Unable to compute thumb-print from keystore certificate", e);
    }
  }
}