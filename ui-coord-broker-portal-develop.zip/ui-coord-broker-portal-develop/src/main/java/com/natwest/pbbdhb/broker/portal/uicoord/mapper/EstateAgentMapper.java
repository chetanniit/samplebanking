package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.EstateAgent;

import com.natwest.pbbdhb.cases.dto.EstateAgentDto;
import com.natwest.pbbdhb.cases.dto.TelephoneDto;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.Objects.isNull;

@Mapper(uses = {BasicAddressMapper.class}, builder = @Builder(disableBuilder = true))
public interface EstateAgentMapper {
    @Mapping(target = "telephoneNumber", ignore = true)
    EstateAgent toEstateAgent(EstateAgentDto estateAgentDto);

    @Mapping(target = "telephones", ignore = true)
    EstateAgentDto toEstateAgentDto(EstateAgent estateAgent);

    @AfterMapping
    default void afterMappingToEstateAgent(EstateAgentDto estateAgentDto, @MappingTarget EstateAgent estateAgent) {
        if (isNull(estateAgentDto)) {
            return;
        }

        estateAgent.setTelephoneNumber(Optional.ofNullable(estateAgentDto.getTelephones()).map(List::stream)
                .flatMap(Stream::findFirst).map(TelephoneDto::getNumber).orElse(null));
    }

    @AfterMapping
    default void afterMappingToEstateAgentDto(EstateAgent estateAgent, @MappingTarget EstateAgentDto estateAgentDto) {
        List<TelephoneDto> telephones = Collections.singletonList(new TelephoneDto());
        estateAgentDto.setTelephones(telephones);
        TelephoneDto telephone = telephones.get(0);

        telephone.setNumber(estateAgent.getTelephoneNumber());
        telephone.setType("WORK");
        telephone.setPreferred(true);
    }
}
