package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;
import com.natwest.pbbdhb.broker.portal.uicoord.toggles.ConditionalOnUserClaimsStubMode;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Mock of user claims provider that returns hardcoded values that would be retrieved from the JWT
 * in production.
 */
@Service
@Slf4j
@ConditionalOnUserClaimsStubMode
public class StubUserClaimsProvider implements UserClaimsProvider {

  private static final String CHANNEL = "INTERMEDIARY_NAPOLI";
  private static final String STUD_USER_NAME  = "brdemo5";
  private static final String FCA_NUMBER = "405714";

  @Override
  public String getBrokerUsername() {
    log.info("Returning hardcoded username user claim: {}", STUD_USER_NAME );
    return STUD_USER_NAME ;
  }

  @Override
  public BrokerType getBrokerType() {
    return BrokerType.BROKER;
  }

  @Override
  public String getChannel() {
    return CHANNEL;
  }

  @Override
  public String getFcaNumber() {
    return FCA_NUMBER;
  }
}
