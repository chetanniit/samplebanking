package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

@Data
public class ServiceLevelDip {

    @ValidateEnum(enumClass = ServiceLevel.LevelOfService.class)
    private String levelOfService;

}
