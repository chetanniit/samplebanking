package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;

import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.FIRST_TIME_BUYER;
import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.NEW_CUSTOMER;

public final class BuyerTypeMappingHelper {

    private BuyerTypeMappingHelper() {}

    public static String getBuyerType(CaseApplication caseApplication) {
        if (caseApplication ==  null) {
            return null;
        }

        Boolean firstTimeBuyer = caseApplication.getFirstTimeBuyer();
        if (firstTimeBuyer == null) {
            return null;
        }

        return firstTimeBuyer ? FIRST_TIME_BUYER.name() : NEW_CUSTOMER.name();
    }
}
