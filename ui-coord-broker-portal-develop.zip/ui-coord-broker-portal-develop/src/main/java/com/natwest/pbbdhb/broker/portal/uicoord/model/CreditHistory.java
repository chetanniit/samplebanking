package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.NotNull;

@Data
public class CreditHistory {

    @NotNull
    private Boolean bankrupt;

    @NotNull
    private Boolean courtProceedings;
}
