package com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentPath {
  private Integer paymentPathId;
  private String paymentPathName;
  private String paymentPathScaleBtl;
  private String paymentPathScaleResidential;
}
