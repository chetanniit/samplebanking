package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails.EmploymentStatus;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentType;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JobDetailsMapper {

    @Autowired
    private JobDetailsAutoMapper autoMapper;

    public JobDetails toJobDetails(JobDetailsDto jobDetailsDto) {
        return autoMapper.toJobDetails(employmentStatus(jobDetailsDto), jobDetailsDto);
    }

    public JobDetailsDto toJobDetailsDto(JobDetails jobDetails) {
        if (jobDetails == null) {
            return null;
        }

        return autoMapper.toJobDetailsDto(employmentType(jobDetails), employmentStatusDto(jobDetails), jobDetails);
    }

    private EmploymentType employmentType(JobDetails jobDetails) {
        String employmentStatus = jobDetails.getEmploymentStatus();
        if (employmentStatus == null) {
            return null;
        }

        if (EmploymentStatus.EMPLOYED.value().equals(employmentStatus) || EmploymentStatus.SELF_EMPLOYED.value().equals(employmentStatus)) {
            return EmploymentType.PERMANENT;
        } else if (EmploymentStatus.CONTRACTOR.value().equals(employmentStatus)) {
            return EmploymentType.CONTRACT;
        } else {
            return EmploymentType.OTHER;
        }
    }

    public String employmentStatus(JobDetailsDto jobDetailsDto) {
        if (EmploymentType.CONTRACT.equals(jobDetailsDto.getEmploymentType())) {
            return EmploymentStatus.CONTRACTOR.value();
        }
        return jobDetailsDto.getEmploymentStatus().name();
    }

    public String employmentStatusDto(JobDetails jobDetails) {
        if (EmploymentStatus.CONTRACTOR.value().equals(jobDetails.getEmploymentStatus())) {
            return EmploymentStatus.EMPLOYED.value();
        }
        return jobDetails.getEmploymentStatus();
    }
}
