package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Fee {
    @ValidateEnum(enumClass = FeeCodeType.class)
    @NotBlank
    private String feeCode;

    @ValidateEnum(enumClass = FeeActionType.class)
    @NotBlank
    private String feeAction;

    private BigDecimal feeAmount;

    private String type;

    public enum FeeCodeType implements ValuedEnum {
        A01, A03, ADM, AFF, B01, B02, B03, B04, B05, B06, BD1, BTL, COH, CR1, CR2, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11, D12, D13, D15, D16, D17, D18, D19, D20, D21, D22, D23, D24, DEN, DPA, DR1, DR2, DR3, DR4, DR5, DR6, DRA, DRN, DSC, EBH, ER1, ER2, ER3, ER4, ERL, F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16, F17, F18, F19, F20, F21, F22, F23, F24, F25, F26, F27, F28, F29, F32, F33, F34, F35, F36, F37, F38, F39, F40, F41, F42, F43, F44, F45, F46, F47, F48, F49, FAD, FR1, FR2, FTC, FTF, FVA, H01, HLC, KVL, LAF, LCB, LFA, LMS, LPF, M01, M02, M2M, NEG, RIF, RVF, SOL, SSC, SSF, T01, T02, T03, T04, T05, T06, T07, T08, T09, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22, T23, T24, T25, T26, T27, T28, T29, T30, T31, T32, T33, T34, T35, T36, T37, T38, T39, T40, T41, T42, T43, TAF, TMO, TOE, VA1, VAF, VAL, VAR, VR1, W01, WC1, WCF, XPA;

        @Override
        public String value() {
            return name();
        }
    }

    public enum FeeActionType implements ValuedEnum {
        ADD_CAPITALISE_TO_LOAN,
        DEDUCT_FROM_ADVANCE,
        NO_ACTION;

        @Override
        public String value() {
            return name();
        }
    }
}
