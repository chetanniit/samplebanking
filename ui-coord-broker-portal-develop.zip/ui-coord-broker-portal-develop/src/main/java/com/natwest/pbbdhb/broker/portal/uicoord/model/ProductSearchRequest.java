package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.RepaymentType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MaxTerm;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@MaxTerm(yearField = "customerPreferredTermYears", yearValue = 40, monthField = "customerPreferredTermMonths", monthMaxValue = 0)
public class ProductSearchRequest {

    @NotNull
    @ValidateEnum(enumClass = ApplicationType.class)
    private String applicationType;

    @NotNull
    @ValidateEnum(enumClass = MortgageType.class)
    private String mortgageType;

    @NotNull
    @Min(1)
    @Max(99_999_999)
    private BigDecimal mortgageAmount;

    @NotNull
    @Min(1)
    @Max(99_999_999)
    private BigDecimal propertyValue;

    @NotNull
    @DateFormat(pattern = "dd-MM-yyyy")
    private String productSearchDate;

    @NotNull
    @ValidateEnum(enumClass = RepaymentType.class)
    private String repaymentType;

    private BigDecimal capitalAndInterestAmount;

    private BigDecimal interestOnlyAmount;

    @Min(0)
    @Max(100)
    @NotNull
    private Double ltv;

    @Min(3)
    @Max(40)
    private Integer customerPreferredTermYears;

    @Min(0)
    @Max(11)
    private Integer customerPreferredTermMonths;

    private boolean greenMortgage;

    public enum ApplicationType implements ValuedEnum {
        RESIDENTIAL,
        BUY_TO_LET;

        @Override
        public String value() {
            return name();
        }
    }


    public enum MortgageType implements ValuedEnum {
        FIRST_TIME_BUYER,
        PURCHASE,
        PURCHASE_SHARED_EQUITY,
        PURCHASE_H2B_SHARED_EQUITY,
        REMORTGAGE,
        REMORTGAGE_H2B_SHARED_EQUITY;

        @Override
        public String value() {
            return name();
        }
    }
}
