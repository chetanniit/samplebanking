package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.MortgageAmountValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = MortgageAmountValidator.class)
public @interface MortgageAmount {

    String message() default "Mortgage amount must be equal to the lesser of property value and purchase price minus the total deposit amount.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
