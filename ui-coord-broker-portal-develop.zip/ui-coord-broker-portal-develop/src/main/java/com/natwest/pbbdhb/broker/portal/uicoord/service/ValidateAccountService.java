package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ValidateAccountRequest;

public interface ValidateAccountService {

    boolean validateAccount(String brand, ValidateAccountRequest validateAccountRequest);
}
