package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum PropertyType implements ValuedEnum {
  BUNGALOW_NEW_BUILD,
  BUNGALOW_DETACHED,
  BUNGALOW_SEMI_DETACHED,
  BUNGALOW_MID_TERRACED,
  BUNGALOW_END_TERRACED,
  HOUSE_NEW_BUILD,
  HOUSE_DETACHED,
  HOUSE_SEMI_DETACHED,
  HOUSE_MID_TERRACED,
  HOUSE_END_TERRACED,
  HOUSE_NEW_BUY,
  FLAT_NEW_BUILD,
  FLAT_PURPOSE_BUILT,
  FLAT_CONVERTED,
  FLAT_NEW_BUY;

  @Override
  public String value() {
    return name();
  }
}
