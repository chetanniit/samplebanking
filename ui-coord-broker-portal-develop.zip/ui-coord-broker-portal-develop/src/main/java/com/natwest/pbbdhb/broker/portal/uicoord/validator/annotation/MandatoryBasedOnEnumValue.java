package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.MandatoryBasedOnEnumValueValidator;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Target({TYPE})
@Repeatable(MandatoryBasedOnEnumValues.class)
@Retention(RUNTIME)
@Constraint(validatedBy = MandatoryBasedOnEnumValueValidator.class)
public @interface MandatoryBasedOnEnumValue {

    String message() default "${errorMessage}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String MandatoryField();
    String EnumField();
    String EnumValue();
}
