package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.groups.FmaValidationGroup;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_NWI;

@Data
public class PersonalDetails {

    @NotNull
    @ValidateEnum(enumClass = Title.class)
    private String title;

    // field is required if title == OTHER
    @Size(min = 1, max = 15)
    private String otherTitle;

    @NotBlank
    @Size(min = 1, max = 15)
    private String firstNames;

    @Size(max = 25)
    private String middleNames;

    @NotBlank
    @Size(min = 2, max = 25)
    private String lastName;

    @NotNull
    @DateFormat(pattern = "yyyy-MM-dd", constraint = DateFormat.DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String dateOfBirth;

    @NotNull
    @Size(max = 2)
    private String nationality;

    @Size(max = 5)
    private List<@Size(max = 2) String> additionalNationalities;

    @Size(max = 2)
    private String countryOfResidenceIsoCode;

    @Size(max = 2)
    private String countryOfBirth;

    @Size(max = 28)
    private String placeOfBirth;

    private Boolean rightToReside;

    @ValidateEnum(enumClass = Gender.class)
    private String gender;

    @ValidateEnum(enumClass = MaritalStatus.class)
    private String maritalStatus;

    // must contain @ and .
    // . must be after @
    @Size(max = 45)
    @Pattern(regexp = "^.*@.*\\..*$", flags=Pattern.Flag.CASE_INSENSITIVE ,message = "Badly formed email")
    private String email;

    @Valid
    private PersonalTelephone telephone;

    private List<@Size(min = 1, max = 45) String> previousNames;

    private List<@Size(max = 45) String> otherNames;

    private List<@Size(max = 30)String> taxNumbers;

    private List<@Size(min = 0, max = 2)String> taxResidency;

    @Valid
    private CorrespondenceAddress correspondenceAddress;

    @Valid
    @RequiredForBrand(value = {BRAND_NWI}, groups = FmaValidationGroup.class)
    private UKAssociationAddress ukAssociationAddress;

    public enum Gender implements ValuedEnum {
        MALE,
        FEMALE;

        @Override
        public String value() {
            return name();
        }
    }

    public enum MaritalStatus implements ValuedEnum {
        DIVORCED,
        MARRIED,
        SEPARATED,
        SINGLE,
        ENGAGED,
        WIDOWED,
        LIVING_WITH_PARTNER,
        CIVIL_PARTNERSHIP,
        SURVIVING_CIVIL_PARTNER;

        @Override
        public String value() {
            return name();
        }
    }
}
