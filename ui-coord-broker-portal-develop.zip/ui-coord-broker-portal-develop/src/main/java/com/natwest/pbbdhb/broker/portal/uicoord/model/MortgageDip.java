package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MaxTerm;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MortgageAmount;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.TotalDeposits;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
@TotalDeposits
@MortgageAmount
@MaxTerm(yearField = "mortgageTermYears", yearValue = 40, monthField = "mortgageTermMonths", monthMaxValue = 0)
// TODO: Add validation to check interestOnly is not null if mortgageType = "INTEREST_ONLY" or "MIXED", and is null otherwise.
public class MortgageDip {

    @Min(1)
    @Max(99_999_999)
    private Integer propertyValue;

    @Min(1)
    @Max(99_999_999)
    private Integer purchasePrice;

    private List<@Valid @NotNull Deposit> deposits;

    // TODO: we still need to validate that it was calculated correctly, and we will need to do this at the case level to check for remortgage status etc.
    // TODO: we need to check that this is not null before we submit to the dip service or we switch on the validation on CAPIE, possibly we add a validation step at review stage?
    @Min(1)
    @Max(99_999_999)
    private Integer mortgageAmount;

    // TODO: add Mandatory field validation at the case level for remortgage
    @Min(0)
    @Max(99_999_999)
    private Long outstandingMortgage;

    @Min(3)
    @Max(40)
    private Integer mortgageTermYears;

    @Min(0)
    @Max(11)
    private Integer mortgageTermMonths;

    @ValidateEnum(enumClass = Mortgage.MortgageType.class)
    private String mortgageType;

    @ValidateEnum(enumClass = Mortgage.MortgageAdvised.class)
    private String mortgageAdvised;

    @Valid
    private InterestOnly interestOnly;

    private Boolean mortgagePrisoner;

    private Boolean additionalBorrowing;

    private List<@Valid @NotNull AdditionalBorrowing> additionalBorrowings;

    @Valid
    private BuyToLet buyToLet;

    private List<@Valid OtherPropertyDip> otherProperties;
}
