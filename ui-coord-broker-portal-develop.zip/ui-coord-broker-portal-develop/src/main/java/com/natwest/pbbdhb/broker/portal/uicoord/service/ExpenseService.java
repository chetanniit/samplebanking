package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseExpense;

public interface ExpenseService {
    CaseExpense saveExpense(String brand, String caseId, CaseExpense expense);

    CaseExpense getExpense(String brand, String caseId);
}
