package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.AdditionalJobIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.income.expense.model.enums.EmploymentType;
import com.natwest.pbbdhb.income.expense.model.enums.OccupationType;
import com.natwest.pbbdhb.income.expense.model.enums.TelephoneType;
import com.natwest.pbbdhb.income.expense.model.income.dto.AdditionalJobIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.ContactTelephoneDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import org.mapstruct.AfterMapping;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.ValueMapping;

@Mapper(uses = {EmployerAddressMapper.class}, builder = @Builder(disableBuilder = true))
public interface JobDetailsAutoMapper {
    @Mapping(target="employmentStatus", source="employmentStatus")
    @Mapping(target="employerTelephone", source="jobDetailsDto.preferredEmployerTelephone.number")
    @Mapping(target="basicPayAnnualIncomeOriginatingCurrency", source="jobDetailsDto.basicPayAnnualIncomeCurrency")
    @Mapping(target="occupationType", source="jobDetailsDto.occupationType", qualifiedByName = "toJobDetailsOccupationType")
    @Mapping(target="yearOneNetProfitAfterTax", source="jobDetailsDto.grossYearOneProfit")
    @Mapping(target="yearTwoNetProfitAfterTax", source="jobDetailsDto.grossYearTwoProfit")
    @Mapping(target="yearOneProfitOriginatingCurrency", source="jobDetailsDto.yearOneProfitCurrency")
    @Mapping(target="yearTwoProfitOriginatingCurrency", source="jobDetailsDto.yearTwoProfitCurrency")
    @Mapping(target = "yearOneOriginatingCurrency", ignore = true)
    @Mapping(target = "yearTwoOriginatingCurrency", ignore = true)
    JobDetails toJobDetails(String employmentStatus, JobDetailsDto jobDetailsDto);

    @ValueMapping(source = "UNEMPLOYED", target = "NOT_EMPLOYED")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
    @Named("toJobDetailsOccupationType")
    JobDetails.OccupationType toJobDetailsOccupationType(OccupationType occupationType);

    @Mapping(target="employmentStatus", source="employmentStatus")
    @Mapping(target="employmentType", source="employmentType")
    @Mapping(target="occupationType", source="jobDetails", qualifiedByName = "toJobDetailsDtoOccupationType")
    @Mapping(target = "preferredEmployerTelephone", ignore = true)
    @Mapping(target = "additionalEmployerTelephones", ignore = true)
    @Mapping(target = "reducedBasicPayAnnualIncome", ignore = true)
    @Mapping(target = "businessName", ignore = true)
    @Mapping(target = "natureOfBusiness", ignore = true)
    @Mapping(target = "employerAddressSameAsHomeAddress", ignore = true)
    @Mapping(target = "yearOneTurnover", ignore = true)
    @Mapping(target = "yearTwoTurnover", ignore = true)
    @Mapping(target = "profitExpectedToDecreaseFurther", ignore = true)
    @Mapping(target = "decreasingProfitReason", ignore = true)
    @Mapping(target = "basicPayAnnualIncomeCurrency", source="jobDetails.basicPayAnnualIncomeOriginatingCurrency")
    @Mapping(target = "reducedBasicPayAnnualIncomeCurrency", ignore = true)
    @Mapping(target = "netReducedBasicPayAnnualIncome", ignore = true)
    @Mapping(target = "yearOneProfitCurrency", source = "jobDetails.yearOneProfitOriginatingCurrency")
    @Mapping(target = "grossYearOneProfit", source = "jobDetails.yearOneNetProfitAfterTax")
    @Mapping(target = "yearTwoProfitCurrency", source = "jobDetails.yearTwoProfitOriginatingCurrency")
    @Mapping(target = "grossYearTwoProfit", source = "jobDetails.yearTwoNetProfitAfterTax")
    @Mapping(target = "yearOneTurnoverCurrency", ignore = true)
    @Mapping(target = "netYearOneTurnover", ignore = true)
    @Mapping(target = "yearTwoTurnoverCurrency", ignore = true)
    @Mapping(target = "netYearTwoTurnover", ignore = true)
    @Mapping(target = "yearOneDirectorSalaryCurrency", source = "jobDetails.yearOneOriginatingCurrency")
    @Mapping(target = "yearTwoDirectorSalaryCurrency", source = "jobDetails.yearTwoOriginatingCurrency")
    @Mapping(target = "yearOneDividendsCurrency", source = "jobDetails.yearOneOriginatingCurrency")
    @Mapping(target = "yearTwoDividendsCurrency", source = "jobDetails.yearTwoOriginatingCurrency")
    JobDetailsDto toJobDetailsDto(EmploymentType employmentType, String employmentStatus, JobDetails jobDetails);

    @Mapping(target = "currency", source = "originatingCurrency")
    AdditionalJobIncomeDto toAdditionalJobIncomeDto(AdditionalJobIncome additionalJobIncome);

    @Mapping(target = "originatingCurrency", source = "currency")
    AdditionalJobIncome toAdditionalJobIncome(AdditionalJobIncomeDto additionalJobIncomeDto);

    @Named("toJobDetailsDtoOccupationType")
    default OccupationType toJobDetailsDtoOccupationType(JobDetails jobDetails) {
        if (jobDetails.getOccupationType() != null) {
            return mapToJobDetailsDtoOccupationType(jobDetails.getOccupationType());
        }
        return toOccupationTypeFromEmploymentStatus(JobDetails.EmploymentStatus.valueOf(jobDetails.getEmploymentStatus()));
    }

    @ValueMapping(source = "NOT_EMPLOYED", target = "UNEMPLOYED")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
    OccupationType mapToJobDetailsDtoOccupationType(String occupationType);

    @ValueMapping(source = "HOME_MAKER", target = "HOME_FAMILY_RESPONSIBILITIES")
    @ValueMapping(source = "NOT_EMPLOYED", target = "UNEMPLOYED")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
    OccupationType toOccupationTypeFromEmploymentStatus(JobDetails.EmploymentStatus employmentStatus);

    @AfterMapping
    default void afterMappingToJobDetailsDto(JobDetails jobDetails, @MappingTarget JobDetailsDto jobDetailsDto) {
        if (jobDetails.getEmployerTelephone() != null) {
            ContactTelephoneDto telephone = new ContactTelephoneDto();
            telephone.setNumber(jobDetails.getEmployerTelephone());
            telephone.setType(TelephoneType.WORK);
            jobDetailsDto.setPreferredEmployerTelephone(telephone);
        }
    }

    @AfterMapping
    default void afterMappingToJobDetails(JobDetailsDto jobDetailsDto, @MappingTarget JobDetails jobDetails) {
      if (jobDetailsDto.getYearOneDirectorSalaryCurrency() != null) {
        jobDetails.setYearOneOriginatingCurrency(
            String.valueOf(jobDetailsDto.getYearOneDirectorSalaryCurrency()));
      } else if (jobDetailsDto.getYearOneDividendsCurrency() != null) {
        jobDetails.setYearOneOriginatingCurrency(
            String.valueOf(jobDetailsDto.getYearOneDividendsCurrency()));
      } else {
        jobDetails.setYearOneOriginatingCurrency(null);
      }

      if (jobDetailsDto.getYearTwoDirectorSalaryCurrency() != null) {
        jobDetails.setYearTwoOriginatingCurrency(
            String.valueOf(jobDetailsDto.getYearTwoDirectorSalaryCurrency()));
      } else if (jobDetailsDto.getYearTwoDividendsCurrency() != null) {
        jobDetails.setYearTwoOriginatingCurrency(
            String.valueOf(jobDetailsDto.getYearTwoDividendsCurrency()));
      } else {
        jobDetails.setYearTwoOriginatingCurrency(null);
      }
    }
}
