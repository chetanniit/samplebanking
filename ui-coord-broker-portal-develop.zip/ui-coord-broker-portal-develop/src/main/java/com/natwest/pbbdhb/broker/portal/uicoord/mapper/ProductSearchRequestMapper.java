package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductSearchRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;
import org.mapstruct.Mapper;

@Mapper
public abstract class ProductSearchRequestMapper {
    public abstract ProductSearchRequestDto toProductSearchRequestDto(ProductSearchRequest productSearchRequest);
}