package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class MafDocumentException extends RuntimeException {

    public MafDocumentException(String message) {
        super(message);
    }

    public MafDocumentException(String message, Throwable cause) {
        super(message, cause);
    }
}
