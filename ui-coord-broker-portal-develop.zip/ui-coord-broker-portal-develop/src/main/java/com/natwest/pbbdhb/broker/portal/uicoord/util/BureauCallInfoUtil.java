package com.natwest.pbbdhb.broker.portal.uicoord.util;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallInfoDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.CaseJourneyDataDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import lombok.NonNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BUREAU_CALL_INFO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DataUtils.toDataObject;

public final class BureauCallInfoUtil {
    // prevent instantiation
    private BureauCallInfoUtil() {
    }

    public static BureauCallInfoDto getBureauCallInfo(CaseApplicationDto caseApplicationDto) {
        CaseJourneyDataDto journeyDataDto = toDataObject(caseApplicationDto.getJourneyData(), CaseJourneyDataDto.class);
        if (journeyDataDto == null) {
            return null;
        }

        return journeyDataDto.getBureauCallInfo();
    }

    public static BureauCallInfoDto createBureauCallInfo(String dipId, @NonNull List<ApplicantDto> applicantDtoList) throws IllegalArgumentException {
        if (applicantDtoList.isEmpty()) {
            throw new IllegalArgumentException("empty applicant list");
        }

        BureauCallInfoDto bureauCallInfo = new BureauCallInfoDto();
        bureauCallInfo.setDipId(dipId);
        bureauCallInfo.setApplicants(
                applicantDtoList
                        .stream()
                        .map(BureauCallInfoUtil::createBureauCallApplicantDto)
                        .collect(Collectors.toList()));
        return bureauCallInfo;
    }

    private static BureauCallApplicantDto createBureauCallApplicantDto(@NonNull ApplicantDto applicantDto) throws IllegalArgumentException {
        if (applicantDto.getPersonalDetails() == null) {
            throw new IllegalArgumentException("missing person details");
        }
        if (applicantDto.getAddresses() == null) {
           throw new IllegalArgumentException("missing addresses");
        }
        return new BureauCallApplicantDto(applicantDto);
    }

    public static void setBureauCallInfo(CaseApplicationDto caseApplicationDto, BureauCallInfoDto bureauCallInfoDto) {
        Map<String, Object> journeyData = caseApplicationDto.getJourneyData();
        if (journeyData == null) {
            journeyData = new HashMap<>();
            caseApplicationDto.setJourneyData(journeyData);
        }

        journeyData.put(CASE_JOURNEY_DATA_BUREAU_CALL_INFO, bureauCallInfoDto);
    }

}
