package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.groups.DipSubmitValidationGroup;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.groups.FmaValidationGroup;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validator;
import jakarta.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Set;

@Component
@AllArgsConstructor
@Slf4j
public class BrokerCaseValidator {
    private final Validator validator;

    public void validateBrokerCase(BrokerCase brokerCase) {
        if (null != brokerCase) {
            Class<?> group = getGroups(brokerCase);
            Set<ConstraintViolation<BrokerCase>> violations = validator.validate(brokerCase, group);
            log.info("violations from validator {}", violations);
            if (!CollectionUtils.isEmpty(violations)) {
                throw new ConstraintViolationException(violations);
            }
        }
    }

    public Class<?> getGroups(BrokerCase brokerCase) {
        if (null != brokerCase.getCaseApplication() && StringUtils.hasLength(brokerCase.getCaseApplication().getCurrentRoute())) {
            if (brokerCase.getCaseApplication().getCurrentRoute().contains("/fma")) {
                return FmaValidationGroup.class;
            } else if (brokerCase.getCaseApplication().getCurrentRoute().contains("/dip/ReviewAndSubmit")) {
                return DipSubmitValidationGroup.class;
            }
        }
        return Default.class;
    }
}
