package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_BUREAU_CALL_INFO;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_COMPLETED_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_AFTER_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_GENERATE_CASE_ID_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseStatusUtil.fmaHasBeenSubmitted;

import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseIdGenerationClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallInfoDto;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.CaseApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.CaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BureauCallInfoUtil;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import java.util.HashMap;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@Slf4j
@RequiredArgsConstructor
public class CaseServiceImpl implements CaseService {

    private final CaseIdGenerationClient caseIdGenerationClient;
    private final CaseClientNapoli caseClient;
    private final CaseApplicationMapper caseApplicationMapper;
    private final UserClaimsProvider userClaimsProvider;
    private final AccessPermissionChecker accessPermissionChecker;

    @Override
    public String generateCaseId(String brand) {
        log.debug("Calling caseIdGenerationClient to generate caseId");
        if (!accessPermissionChecker.isBroker()) {
            log.error("Error in generateCaseId for user type {} and brokerUsername {}: {}",
                    userClaimsProvider.getBrokerType(), userClaimsProvider.getBrokerUsername(), MSG_NO_GENERATE_CASE_ID_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_GENERATE_CASE_ID_PERMISSION);
        }
        String caseId = this.caseIdGenerationClient.generateCaseId(brand);
        log.debug("caseIdGenerationClient successfully called to generate caseId: {}", caseId);
        return caseId;
    }

    @Override
    public CaseApplication getCase(String brand, String caseId) {
        log.debug("Calling caseClient to get case with caseId {}", caseId);
        CaseApplicationDto caseApplicationDto = this.caseClient.getCase(brand, caseId);
        log.debug("caseClient successfully called to get case with caseId {}", caseId);
        return this.caseApplicationMapper.toCaseApplication(caseApplicationDto);
    }

    @Override
    public CaseApplication saveCase(
            String brand,
            String caseId,
            @NonNull CaseApplication caseApplication,
            BrokerInfo broker,
            boolean isNewCase,
            boolean clearDipResult) {
        normaliseCase(caseApplication);

        String version = caseApplication.getVersion();
        String username = broker == null ? null : (broker.getBrokerDetails() == null ? null : broker.getBrokerDetails().getUserName());

        log.debug("Saving case with version {}, caseId {}, brokerUsername {}, isNewCase {}, and clearDipResult {}",
            version, caseId, username, isNewCase, clearDipResult);
        CaseApplicationDto caseApplicationRequestDto = this.caseApplicationMapper.toCaseApplicationDto(caseId, caseApplication, broker);

        if (!isNewCase) {
            // Read current case data from CAPIE
            log.debug("Calling caseClient to get existing case with version {}, caseId {}, brokerUsername {}, and clearDipResult {}",
                version, caseId, username, clearDipResult);
            CaseApplicationDto currentCaseDto = caseClient.getCase(brand, caseId);
            log.debug("caseClient successfully called to get existing case with version {}, caseId {}, brokerUsername {}, and clearDipResult {}",
                version, caseId, username, clearDipResult);

            // Reject update if FMA has already been submitted
            if (fmaHasBeenSubmitted(currentCaseDto)) {
                log.error("Case with version {}, caseId {}, and brokerUsername {} cannot be saved: FMA has already been submitted - throwing UpdateNotPermittedException",
                    version, caseId, username);
                throw new UpdateNotPermittedException(MSG_NO_UPDATE_AFTER_FMA);
            }

            if (!clearDipResult) {
                // Set data on the request that should not be changed by client unless DIP is cleared, making it effectively read-only.
                caseApplicationRequestDto.setApplicationStatus(currentCaseDto.getApplicationStatus());
            }

            // Set data on the request that should not be changed by client, making it effectively read-only.
            preserveReadOnlyData(caseApplicationRequestDto, currentCaseDto);

            if (caseApplication.getCurrentRoute().contains("/fma")) {
                caseApplicationRequestDto.setApplicationStatus(ApplicationStatus.FMA_IN_PROGRESS_NOT_SUBMITTED_TO_GMS.toString());
            } else {
                caseApplicationRequestDto.setApplicationStatus(null);
            }

        }
        CaseApplicationDto caseApplicationResponseDto;
        if (isNewCase) {
          log.debug("Calling caseClient to save case with version {}, caseId {}, and brokerUsername {}", version, caseId, username);
          caseApplicationResponseDto = this.caseClient.createCase(brand, caseApplicationRequestDto);
          log.debug("caseClient successfully called to save case with version {}, caseId {}, and brokerUsername {}", version, caseId, username);
        } else {
          log.debug("Calling caseClient to update case with version {}, caseId {}, and brokerUsername {}", version, caseId, username);
          caseApplicationResponseDto = this.caseClient.updateCase(brand, caseApplicationRequestDto);
          log.debug("caseClient successfully called to update case with version {}, caseId {}, and brokerUsername {}", version, caseId, username);
        }
        return this.caseApplicationMapper.toCaseApplication(caseApplicationResponseDto);
    }

    /**
     * Some data should never be deleted:
     * CASE_JOURNEY_DATA_HAS_COMPLETED_DIP: affects submitDip
     * CASE_JOURNEY_DATA_BUREAU_CALL_INFO: affects submitDip
     * CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME: for debugging/future purposes
     * CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME: for debugging/future purposes
     * @param caseApplicationRequestDto
     * @param currentCaseDto
     */
    private void preserveReadOnlyData(CaseApplicationDto caseApplicationRequestDto, CaseApplicationDto currentCaseDto) {

        String caseId = caseApplicationRequestDto.getCaseId();
        log.debug("Preserving read-only data for caseId {}", caseId);
        caseApplicationRequestDto.setDecisionInPrinciples(currentCaseDto.getDecisionInPrinciples());

        if (caseApplicationRequestDto.getJourneyData() == null) {
            caseApplicationRequestDto.setJourneyData(new HashMap<>());
        }

        if (currentCaseDto.getJourneyData() == null) {
            Boolean hasCompletedDip = null;
            // preserving old logic, unsure if we have other code expecting this key
            caseApplicationRequestDto.getJourneyData().put(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, hasCompletedDip);
            return;
        }

        Boolean hasCompletedDip = (Boolean) currentCaseDto.getJourneyData().get(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP);
        caseApplicationRequestDto.getJourneyData().put(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, hasCompletedDip);

        BureauCallInfoDto bureauCallInfo = BureauCallInfoUtil
            .getBureauCallInfo(currentCaseDto);
        caseApplicationRequestDto.getJourneyData().put(CASE_JOURNEY_DATA_BUREAU_CALL_INFO, bureauCallInfo);

        String dipSubmittedDateTime = (String) currentCaseDto.getJourneyData()
            .getOrDefault(CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME, null);
        caseApplicationRequestDto.getJourneyData().put(CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME, dipSubmittedDateTime);

        String dipAmendedDateTime = (String) currentCaseDto.getJourneyData()
            .getOrDefault(CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME, null);
        caseApplicationRequestDto.getJourneyData().put(CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME, dipAmendedDateTime);

        log.debug("read-only data for caseId {} successfully preserved", caseId);
    }

    private void normaliseCase(CaseApplication caseApplication) {
        String caseId = caseApplication.getCaseId();
        log.debug("Normalising case with caseId {}", caseId);
        if (caseApplication.getMortgage() != null) {
          Mortgage mortgage = caseApplication.getMortgage();
          if (!hasInterestOnlyPart(mortgage)) {
            log.debug("Setting null interestOnly for caseId {}", caseId);
            mortgage.setInterestOnly(null);
          }
        }

        if (caseApplication.getProductDetails() != null && caseApplication.getLoanPurpose() != null && !isHousePurchase(caseApplication)) {
            ProductDetails productDetails = caseApplication.getProductDetails();
            log.debug("Setting null isPortingProduct and null portingText for caseId {}", caseId);
            productDetails.setIsPortingProduct(null);
            productDetails.setPortingText(null);
        }

        if (caseApplication.getHasDependants() != null && !caseApplication.getHasDependants()) {
            log.debug("Setting 0 numberOfDependantsOver18 and 0 numberOfDependantsUnder18 for caseId {}", caseId);
            caseApplication.setNumberOfDependantsOver18(0);
            caseApplication.setNumberOfDependantsUnder18(0);
        }
        log.debug("Case with caseId {} successfully normalised", caseId);
    }

    private boolean hasInterestOnlyPart(Mortgage mortgage) {
        String mortgageType = mortgage.getMortgageType();
        return Mortgage.MortgageType.INTEREST_ONLY.value().equals(mortgageType) || Mortgage.MortgageType.MIXED.value().equals(mortgageType);
    }

    private boolean isHousePurchase(CaseApplication caseApplication) {
        return CaseApplication.LoanPurpose.HOUSE_PURCHASE.value().equals(caseApplication.getLoanPurpose());
    }
}
