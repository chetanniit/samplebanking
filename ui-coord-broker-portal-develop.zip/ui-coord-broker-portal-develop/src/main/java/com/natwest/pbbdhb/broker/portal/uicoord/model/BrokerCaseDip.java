package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.SIZE_AT_LEAST_ONE_MSG;

/**
 * Data class created to reset values back to DIP state (from FMA).
 * This will be used with a Mapstruct mapper, mapping BrokerCase to BrokerCaseDip and back.
 * This was created from a copy paste off BrokerCase, feel free to edit as required,
 * we may have missed some bits here and there and the solution should be editing this class and its children.
 */
@Data
public class BrokerCaseDip {

    @Valid
    private CaseApplicationDip caseApplication;

    @Size(min = 1, message = SIZE_AT_LEAST_ONE_MSG)
    private List<@Valid ApplicantDip> applicants;

    @Valid
    private PropertyDetailsDip property;

    @Valid
    private CaseIncomeDip income;

    @Valid
    private CaseExpense expense;
}
