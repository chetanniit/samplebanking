package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Title implements ValuedEnum {
    NONE("None"),
    MR("Mr"),
    MRS("Mrs"),
    MISS("Miss"),
    MS("Ms"),
    DR("Dr"),
    REVEREND("Reverend"),
    PROFESSOR("Professor"),
    SIR("Sir"),
    LORD("Lord"),
    LADY("Lady"),
    CAPTAIN("Captain"),
    MAJOR("Major"),
    COLONEL("Colonel"),
    MASTER("Master"),
    HON("Hon"),
    MX("Mx"),
    SISTER("Sister"),
    VISCOUNT("Viscount"),
    COUNTESS("Countess"),
    EARL("Earl"),
    OTHER("Other");

    private final String value;

    @Override
    public String value() {
        return this.value;
    }
}
