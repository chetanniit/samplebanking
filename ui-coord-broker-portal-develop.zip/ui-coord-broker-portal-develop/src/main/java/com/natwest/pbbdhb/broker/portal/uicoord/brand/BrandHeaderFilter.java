package com.natwest.pbbdhb.broker.portal.uicoord.brand;

import com.natwest.pbbdhb.broker.portal.uicoord.brand.request.BrandHttpRequestWrapper;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;

import java.io.IOException;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;

@Slf4j
public class BrandHeaderFilter implements Filter {
    public static final String USE_NWI = "X-Use-nwi";

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        if (isOptionsRequest((HttpServletRequest) req) || isExcludedUrlPattern((HttpServletRequest) req)) {
            chain.doFilter(req, res);
            return;
        }

        String headerValueAsString = ((HttpServletRequest) req).getHeader(BRAND_HEADER);
        String useNWI = ((HttpServletRequest) req).getHeader(USE_NWI);
        try {


            //This is only required untill nwi apigee is not in place
            if (null != useNWI && Boolean.valueOf(useNWI)) {
                BrandContextHolder.setCurrentBrand("nwi");
                BrandHttpRequestWrapper brandHttpRequestWrapper = new BrandHttpRequestWrapper((HttpServletRequest) req);
                chain.doFilter(brandHttpRequestWrapper, res);
            } else {
                BrandContextHolder.setCurrentBrand(headerValueAsString);
                chain.doFilter(req, res);

            }
        } catch (Exception e) {
            //This log is just for visibility purpose
            log.error("exception in the brand filter", e);
        } finally {
            BrandContextHolder.clear();
        }

    }

    private boolean isOptionsRequest(HttpServletRequest req) {
        return HttpMethod.OPTIONS.toString().equals(req.getMethod());
    }

    private boolean isExcludedUrlPattern(HttpServletRequest req) {
        return req
                .getRequestURI()
                .matches("(\\S*(actuator|swagger|api-docs|cloudfoundryapplication)\\S*)+");
    }


}