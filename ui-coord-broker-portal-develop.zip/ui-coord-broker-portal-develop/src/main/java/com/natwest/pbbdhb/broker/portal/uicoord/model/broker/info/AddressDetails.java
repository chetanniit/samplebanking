package com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressDetails {
    private String line1;
    private String line2;
    private String line3;
    private String city;
    private String county;
    private String postcode;
    private String country;
}