package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Product;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductSearchRequest;

import java.util.List;

public interface ProductSearchService {
    List<Product> search(String brand, ProductSearchRequest productSearchRequest);
}
