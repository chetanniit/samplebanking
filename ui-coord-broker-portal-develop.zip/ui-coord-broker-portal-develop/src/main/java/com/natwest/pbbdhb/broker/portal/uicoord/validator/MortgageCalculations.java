package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Deposit;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.RepaymentDetail;

public class MortgageCalculations {

    private MortgageCalculations() {}

    public static Integer getEffectivePropertyValue(Mortgage mortgage) {
        if (mortgage == null) {
            return null;
        }

        Integer propertyValue = mortgage.getPropertyValue();
        Integer purchasePrice = mortgage.getPurchasePrice();

        if (propertyValue == null) {
            return purchasePrice;
        }

        if (purchasePrice == null) {
            return propertyValue;
        }

        return Math.min(propertyValue, purchasePrice);
    }

    public static int getTotalDeposit(Mortgage mortgage) {
        int totalDeposit = 0;
        if (mortgage.getDeposits() != null) {
            for (Deposit deposit : mortgage.getDeposits()) {
                if (deposit != null && deposit.getDepositAmount() != null) {
                    totalDeposit += deposit.getDepositAmount();
                }
            }
        }

        return totalDeposit;
    }

    public static Integer getMortgageAmount(Mortgage mortgage) {
        Integer effectivePropertyValue = getEffectivePropertyValue(mortgage);
        if (effectivePropertyValue == null) {
            return null;
        }

        int totalDeposit = getTotalDeposit(mortgage);

        return effectivePropertyValue - totalDeposit;
    }

    public static Integer getTotalInterestOnlyRepayment(Mortgage mortgage) {
        if (mortgage.getInterestOnly() == null || mortgage.getInterestOnly().getRepaymentDetails() == null) {
            return null;
        }

        int totalRepayments = 0;
        for (RepaymentDetail repaymentDetail : mortgage.getInterestOnly().getRepaymentDetails()) {
            if (repaymentDetail != null && repaymentDetail.getRepaymentValue() != null) {
                totalRepayments += repaymentDetail.getRepaymentValue().intValue();
            }
        }

        return totalRepayments;
    }
}
