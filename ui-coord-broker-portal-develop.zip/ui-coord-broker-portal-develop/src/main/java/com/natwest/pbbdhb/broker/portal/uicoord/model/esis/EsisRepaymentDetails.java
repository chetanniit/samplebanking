package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.RepaymentType;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisRepaymentDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@ValidEsisRepaymentDetails
public class EsisRepaymentDetails {

    @NotNull
    @ValidateEnum(enumClass = RepaymentType.class)
    private String repaymentType;

    @NotNull
    @Min(3)
    @Max(40)
    private Integer termYears;

    @NotNull
    @Min(0)
    @Max(11)
    private Integer termMonths;

    private BigDecimal interestOnlyAmount;

    private BigDecimal amountCapital;

    @Min(3)
    @Max(40)
    private Integer interestOnlyTermYears;

    @Min(0)
    @Max(11)
    private Integer interestOnlyTermMonths;

}
