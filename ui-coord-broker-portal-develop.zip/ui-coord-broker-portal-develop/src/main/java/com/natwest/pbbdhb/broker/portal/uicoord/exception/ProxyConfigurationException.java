package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class ProxyConfigurationException extends RuntimeException {

  public ProxyConfigurationException(String message) {
    super(message);
  }
}
