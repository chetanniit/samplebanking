package com.natwest.pbbdhb.broker.portal.uicoord.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;

@Configuration
@ConfigurationProperties(prefix = "crm.token")
@Data
@Validated
public class CrmTokenAuthConfig {

  @NotBlank
  private String algorithm;

  @NotBlank
  private String x5t;

  @NotBlank
  private String audience;

  @NotBlank
  private String tenantId;

  @NotBlank
  private String clientId;

  @NotBlank
  private String url;

  @NotBlank
  private String resource;
}
