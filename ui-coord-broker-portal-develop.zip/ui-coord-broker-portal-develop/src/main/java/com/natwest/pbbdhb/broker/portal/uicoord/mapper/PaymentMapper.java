package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PaymentUrlRequestDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PaymentUrlResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentResponse;
import org.mapstruct.Mapper;

@Mapper
public interface PaymentMapper {

    PaymentUrlRequestDto toPaymentUrlRequestDto(PaymentRequest paymentRequest);

    PaymentResponse toPaymentUrlResponse(PaymentUrlResponseDto paymentUrlResponseDto);
}
