package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.esis.EsisFirstTimeBuyerValidator;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.esis.EsisSpecialistSchemeValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EsisFirstTimeBuyerValidator.class)
public @interface ValidEsisFirstTimeBuyer {

    String message() default "firstTimeBuyer cannot be empty when loan purpose is Home Purchase";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
