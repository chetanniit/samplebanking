package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.PropertyDetails;

public interface PropertyService {

    PropertyDetails saveProperty(String brand, String caseId, PropertyDetails property);

    PropertyDetails saveProperty(String brand, String caseId, PropertyDetails property, boolean isScottishApplication, boolean isBuyToLet);

    PropertyDetails getProperty(String brand, String caseId);
}
