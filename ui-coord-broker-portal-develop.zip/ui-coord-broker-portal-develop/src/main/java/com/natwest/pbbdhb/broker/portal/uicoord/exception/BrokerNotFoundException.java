package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class BrokerNotFoundException extends RuntimeException {

    public BrokerNotFoundException(String message) {
        super(message);
    }

    public BrokerNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
