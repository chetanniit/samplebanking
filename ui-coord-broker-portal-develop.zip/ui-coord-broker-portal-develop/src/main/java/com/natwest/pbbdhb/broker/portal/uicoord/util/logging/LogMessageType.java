package com.natwest.pbbdhb.broker.portal.uicoord.util.logging;

public class LogMessageType {

  public static String EXCEPTION = "Exception";
  public static String DIP = "DIP";
  public static String FMA = "FMA";

}

