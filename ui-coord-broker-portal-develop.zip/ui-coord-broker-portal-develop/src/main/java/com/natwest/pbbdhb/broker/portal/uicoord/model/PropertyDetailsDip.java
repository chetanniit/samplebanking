package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;


@Data
public class PropertyDetailsDip {

    private String version;

    private Boolean newBuild;

    private Integer builderIncentive;

}
