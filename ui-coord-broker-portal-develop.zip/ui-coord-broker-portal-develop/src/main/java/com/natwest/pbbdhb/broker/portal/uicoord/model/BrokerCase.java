package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.SIZE_AT_LEAST_ONE_MSG;

@Data
public class BrokerCase {

    @NotNull
    @Valid
    private CaseApplication caseApplication;

    @Size(min = 1, message = SIZE_AT_LEAST_ONE_MSG)
    private List<@Valid Applicant> applicants;

    @Valid
    private PropertyDetails property;

    @Valid
    private CaseIncome income;

    @Valid
    private CaseExpense expense;
}
