package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import lombok.NonNull;

public interface BrokerInfoService {

  BrokerInfo getBroker(@NonNull String username);
}
