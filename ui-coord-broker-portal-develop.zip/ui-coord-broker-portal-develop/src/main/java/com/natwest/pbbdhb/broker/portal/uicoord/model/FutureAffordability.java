package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.constraints.NotNull;

@Data
public class FutureAffordability {
    @NotNull
    private Boolean commitmentsDueDuringMortgage;

    @NotNull
    private Boolean otherCommitments;

    @NotNull
    private Boolean propertyExpensesAffectingMortgagePayment;

    @NotNull
    private Boolean personalChangesAmountAffectingTheMortgagePayment;
}
