package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

@Data
public class Policy {

    private String message;

    private String code;
}
