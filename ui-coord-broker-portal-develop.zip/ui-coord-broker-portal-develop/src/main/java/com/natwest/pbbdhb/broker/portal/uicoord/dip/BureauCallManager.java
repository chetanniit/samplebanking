package com.natwest.pbbdhb.broker.portal.uicoord.dip;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.BureauCallInfoUtil.createBureauCallInfo;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BureauCallInfoUtil.getBureauCallInfo;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.hasUnexpiredDip;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.hasDipResult;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BureauCallInfoDto;
import com.natwest.pbbdhb.broker.portal.uicoord.util.BureauCallInfoUtil;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import lombok.NonNull;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class BureauCallManager {

  public boolean hasMatchingBureauCall(@NonNull CaseApplicationDto caseApplicationDto,
      @NonNull List<ApplicantDto> applicantDtoList) {
    return hasMatchingBureauCallInternal(caseApplicationDto, applicantDtoList, LocalDateTime.now());
  }

  /**
   * Internal method created to help testing dip expiry logic using a date parameter
   * @param caseApplicationDto
   * @param applicantDtoList
   * @param today
   * @return
   */
  protected boolean hasMatchingBureauCallInternal(@NonNull CaseApplicationDto caseApplicationDto,
      @NonNull List<ApplicantDto> applicantDtoList, LocalDateTime today) {

    BureauCallInfoDto bureauCallInfo = getBureauCallInfo(caseApplicationDto);
    if (bureauCallInfo == null) {
      return false;
    }

    if (hasDipResult(caseApplicationDto) // has previous dip
            && StringUtils.isNotBlank(caseApplicationDto.getDecisionInPrinciples().get(0).getDateTime()) && !hasUnexpiredDip(caseApplicationDto, today)) { // is expired
      // if we have a previous DIP but it's expired then we should do a completely new dip
      return false; // needs a new dip
    }


    List<BureauCallApplicantDto> bureauCallApplicants = bureauCallInfo.getApplicants();
    if (bureauCallApplicants.size() != applicantDtoList.size()) {
      return false;
    }

    List<BureauCallApplicantDto> applicants = applicantDtoList.stream()
        .map(BureauCallApplicantDto::new)
        .collect(Collectors.toList());

    return bureauCallApplicants.equals(applicants);
  }

  public String getDipId(CaseApplicationDto caseApplicationDto) {
    BureauCallInfoDto bureauCallInfo = getBureauCallInfo(caseApplicationDto);
    if (bureauCallInfo == null) {
      return null;
    }

    return bureauCallInfo.getDipId();
  }

  public void setBureauCallInfo(@NonNull CaseApplicationDto caseApplicationDto,
      DipExtendedResponse dipResponse, List<ApplicantDto> applicantDtoList) {
    BureauCallInfoDto bureauCallInfo = createBureauCallInfo(dipResponse.getDipId(),
        applicantDtoList);
    BureauCallInfoUtil.setBureauCallInfo(caseApplicationDto, bureauCallInfo);
  }
}
