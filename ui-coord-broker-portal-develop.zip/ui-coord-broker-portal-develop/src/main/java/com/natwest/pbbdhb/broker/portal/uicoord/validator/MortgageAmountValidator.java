package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MortgageAmount;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.broker.portal.uicoord.validator.MortgageCalculations.getMortgageAmount;

public class MortgageAmountValidator implements ConstraintValidator<MortgageAmount, Object> {
    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        if (!(objectToValidate instanceof Mortgage)) {
            return true;
        }

        Mortgage mortgage = (Mortgage) objectToValidate;
        Integer mortgageAmount = mortgage.getMortgageAmount();
        if (mortgageAmount == null) {
            return true;
        }

        // TEMP: skip mortgage amount validation for remortgages for now
        if (mortgage.getOutstandingMortgage() != null && mortgage.getOutstandingMortgage() >= 0) {
            return true;
        }

        return mortgageAmount.equals(getMortgageAmount(mortgage));
    }
}
