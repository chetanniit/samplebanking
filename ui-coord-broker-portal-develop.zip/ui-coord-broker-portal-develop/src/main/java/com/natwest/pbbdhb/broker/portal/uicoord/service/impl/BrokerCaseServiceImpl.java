package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.applicantsWorkStatusMap;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_CREATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_READ_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_CASE_PERMISSION;
import static java.util.Optional.ofNullable;

import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerCaseDipMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCaseDip;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplicationDip;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseExpense;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.IncomeApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PropertyDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ApplicationType;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ApplicantService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerCaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.CaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ExpenseService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.IncomeService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.PropertyService;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BrokerCaseServiceImpl implements BrokerCaseService {

    private static final String RETURN_TO_AIP_PATH = "/dip/ApplicantDetails";
    private static final String PRIMARY_JOB_ID = "job-1";

    private final CaseService caseService;

    private final ApplicantService applicantService;

    private final PropertyService propertyService;

    private final IncomeService incomeService;

    private final ExpenseService expenseService;

    private final BrokerCaseDipMapper brokerCaseDipMapper;

    private final AccessPermissionChecker accessPermissionChecker;

    private final UserClaimsProvider userClaimsProvider;

    private final BrokerInfoService brokerInfoService;


    @Override
    public BrokerCase saveBrokerCase(String brand, String caseId, BrokerCase brokerCase) {
        boolean isNewCase = StringUtils.isBlank(brokerCase.getCaseApplication().getVersion());
        return isNewCase
                ? createBrokerCase(brand, caseId, brokerCase)
                : updateBrokerCase(brand, caseId, brokerCase);
    }

    @Override
    public BrokerCase createBrokerCase(String brand, String caseId, BrokerCase brokerCase) {
        if (!accessPermissionChecker.isBroker()) {
            log.error("Error creating broker case with caseId {} and brokerUsername {}: {}",
                caseId, userClaimsProvider.getBrokerUsername(), MSG_NO_CREATE_CASE_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_CREATE_CASE_PERMISSION);
        }

        return saveBrokerCaseInternal(brand, caseId, brokerCase, true);
    }

    @Override
    public BrokerCase updateBrokerCase(String brand, String caseId, BrokerCase brokerCase) {
        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
            log.error("Error updating broker case with caseId {} and brokerUsername {}: {}",
                caseId, userClaimsProvider.getBrokerUsername(), MSG_NO_UPDATE_CASE_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_UPDATE_CASE_PERMISSION);
        }

        return saveBrokerCaseInternal(brand, caseId, brokerCase, false);
    }

    private BrokerCase saveBrokerCaseInternal(String brand, String caseId, BrokerCase brokerCase, boolean isNewCase) {
        return saveBrokerCaseInternal(brand, caseId, brokerCase, isNewCase, false);
    }

    private BrokerCase saveBrokerCaseInternal(String brand, String caseId, BrokerCase brokerCase, boolean isNewCase, boolean clearDipResult) {
        String username = userClaimsProvider.getBrokerUsername();
        log.debug("Saving broker case with brokerUsername {}, caseId {}, isNewCase {}, and clearDipResult {}", username, caseId, isNewCase, clearDipResult);
        BrokerInfo broker = getBroker();
        BrokerCase brokerCaseResponse = new BrokerCase();

        List<Applicant> applicants = brokerCase.getApplicants();
        CaseIncome income = brokerCase.getIncome();

        if (applicants == null && income != null) {
            log.debug("Calling applicantService to get applicants for caseId {} and brokerUsername {}", caseId, username);
            // Get applicants from CAPIE. Update applicants whose workStatus has changed.
            applicants = applicantService.getApplicants(brand, caseId);
            log.debug("applicantService successfully called to get applicants for caseId {} and brokerUsername {}", caseId, username);
        } else if (applicants != null && income == null) {
            log.debug("Calling incomeService to get income for caseId {} and brokerUsername {}", caseId, username);
            // Get income from CAPIE. Use income to set workStatus on applicants.
            income = incomeService.getIncome(brand, caseId);
            log.debug("incomeService successfully called to get income for caseId {} and brokerUsername {}", caseId, username);
        }

        CaseApplication caseApplication = brokerCase.getCaseApplication();

        String caseVersion = caseApplication.getVersion();
        // NOTE: CaseServiceImpl.saveCase() prevents updates after FMA submission.
        // It is important that this is the first call to save data, otherwise CAPIE data for the case can change when it shouldn't.
        log.debug("Calling caseService to save case with version {}, caseId {}, and brokerUsername {}", caseVersion, caseId, username);
        brokerCaseResponse.setCaseApplication(this.caseService.saveCase(brand, caseId, caseApplication, broker, isNewCase, clearDipResult));
        log.debug("caseService successfully called to save case with version {}, caseId {}, and brokerUsername {}", caseVersion, caseId, username);

        if (applicants != null) {
            Map<String, String> workStatusMap = applicantsWorkStatusMap(applicants, income);
            log.debug("Calling applicantService to save applicants with caseId {} and brokerUsername {}", caseId, username);
            brokerCaseResponse.setApplicants(this.applicantService.saveApplicants(brand, caseId, applicants, workStatusMap));
            log.debug("applicantService successfully called to save applicants with caseId {} and brokerUsername {}", caseId, username);
        }

        setPropertyForBrokerCase(brand, caseId, brokerCase, brokerCaseResponse);

        setIncomeForBrokerCase(brand, caseId, brokerCaseResponse, income);

        CaseExpense expense = brokerCase.getExpense();
        if (expense != null) {
            brokerCaseResponse.setExpense(this.expenseService.saveExpense(brand, caseId, expense));
        }

        return brokerCaseResponse;
    }

  private void setIncomeForBrokerCase(String brand, String caseId, BrokerCase brokerCaseResponse,CaseIncome income) {
        String username = userClaimsProvider.getBrokerUsername();
        if (income == null) {
            log.debug("Income for caseId {} and brokerUsername {} is null - returning", caseId, username);
            return;
        }
        // Fix up the jobId if it is missing. (At time of writing it's always missing.)
        List<IncomeApplicant> incomeApplicants = income.getApplicants();
        if (incomeApplicants != null) {
            for (IncomeApplicant incomeApplicant : incomeApplicants) {
                JobDetails primaryJob = incomeApplicant.getPrimaryJob();
                if (primaryJob != null && primaryJob.getJobId() == null) {
                    log.debug("Setting default job id for primaryJob for caseId {} and brokerUsername {}", caseId, username);
                    primaryJob.setJobId(PRIMARY_JOB_ID);
                }
            }
        }
        String incomeVersion = income.getVersion();
        log.debug("Calling incomeService to save income with version {}, caseId {}, and brokerUsername {}", incomeVersion, caseId, username);
        brokerCaseResponse.setIncome(this.incomeService.saveIncome(brand, caseId, income));
        log.debug("incomeService successfully called to save income with version {}, caseId {}, and brokerUsername {}", incomeVersion, caseId, username);
    }

    private void setPropertyForBrokerCase(String brand, String caseId, BrokerCase brokerCase, BrokerCase brokerCaseResponse) {
        PropertyDetails property = brokerCase.getProperty();
        String username = userClaimsProvider.getBrokerUsername();
        if (property == null) {
            log.debug("Property for caseId {} and brokerUsername {} is null - returning", caseId, username);
            return;
        }
        String propertyVersion = property.getVersion();

        if (brokerCase.getCaseApplication() == null || brokerCase.getCaseApplication().getScottishApplication() == null) {
            log.debug("Calling propertyService to save property with null scottishApplication, version {}, caseId {}, and brokerUsername {}",
              propertyVersion, caseId, username);
            brokerCaseResponse.setProperty(this.propertyService.saveProperty(brand, caseId, property));
            log.debug("propertyService successfully called to save property with null scottishApplication, version {}, caseId {} and brokerUsername {}",
              propertyVersion, caseId, username);
        } else {
            log.debug("Calling propertyService to save property with version {}, caseId {}, and brokerUsername {}", propertyVersion, caseId, username);
            brokerCaseResponse.setProperty(
                this.propertyService.saveProperty(
                    brand,
                    caseId,
                    property,
                    brokerCase.getCaseApplication().getScottishApplication(),
                    ApplicationType.BUY_TO_LET.value().equals(brokerCase.getCaseApplication().getApplicationType())));
            log.debug("propertyService successfully called to save property with version {}, caseId {} and brokerUsername {}",
                propertyVersion, caseId, username);
        }
    }

    @Override
    public BrokerCase getBrokerCase(String brand, String caseId) {

        String username = userClaimsProvider.getBrokerUsername();
        log.debug("Getting broker case with caseId {} and brokerUsername {}", caseId, username);

        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
            log.error("Error getting broker case with caseId {} and brokerUsername {}: {}",
                caseId, username, MSG_NO_READ_CASE_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_READ_CASE_PERMISSION);
        }

        return getBrokerCaseInternal(brand, caseId);
    }

    public BrokerCase getBrokerCaseInternal(String brand, String caseId) {

        BrokerCase brokerCase = new BrokerCase();
        String username = userClaimsProvider.getBrokerUsername();

        log.debug("Calling caseService to get case with caseId {} and brokerUsername {}", caseId, username);
        CaseApplication caseApplication = this.caseService.getCase(brand, caseId);
        log.debug("caseService successfully called to get case with caseId {} and brokerUsername {}", caseId, username);
        brokerCase.setCaseApplication(caseApplication);

        log.debug("Calling applicantService to get applicant with caseId {} and brokerUsername {}", caseId, username);
        List<Applicant> applicants = this.applicantService.getApplicants(brand, caseId);
        log.debug("applicantService successfully called to get applicant with caseId {} and brokerUsername {}", caseId, username);
        brokerCase.setApplicants(applicants);

        log.debug("Calling propertyService to get property with caseId {} and brokerUsername {}", caseId, username);
        PropertyDetails propertyDetails = this.propertyService.getProperty(brand, caseId);
        log.debug("propertyService successfully called to get property with caseId {} and brokerUsername {}", caseId, username);
        brokerCase.setProperty(propertyDetails);

        log.debug("Calling incomeService to get income with caseId {} and brokerUsername {}", caseId, username);
        CaseIncome income = this.incomeService.getIncome(brand, caseId);
        log.debug("incomeService successfully called to get income with caseId {} and brokerUsername {}", caseId, username);
        brokerCase.setIncome(income);

        log.debug("Calling expenseService to get expense with caseId {} and brokerUsername {}", caseId, username);
        CaseExpense expenditure = this.expenseService.getExpense(brand, caseId);
        log.debug("expenseService successfully called to get expense with caseId {} and brokerUsername {}", caseId, username);
        brokerCase.setExpense(expenditure);

        log.debug("Broker case with caseId {} and brokerUsername {} successfully retrieved", caseId, username);
        return brokerCase;
    }

    @Override
    public BrokerCase dipResultClear(String brand, String caseId) {
        String username = userClaimsProvider.getBrokerUsername();
        log.debug("Clearing DIP result for caseId {} and brokerUsername {}", caseId, username);

        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
            log.error("Error updating case with caseId {} and brokerUsername {}: {}",
                caseId, username, MSG_NO_UPDATE_CASE_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_UPDATE_CASE_PERMISSION);
        }

        log.debug("Retrieving case with caseId {} and brokerUsername {}", caseId, username);
        BrokerCase brokerCaseResponse = getBrokerCaseInternal(brand, caseId);

        // pre-condition
        if (brokerCaseResponse.getCaseApplication() == null) {
            log.warn("Got null caseApplication for caseId {} and brokerUsername {}. Returning null", caseId, username);
            return null;
        }
        log.debug("Broker case with caseId {} and brokerUsername {} successfully retrieved", caseId, username);

        // drop all FMA data, keeping only DIP attributes
        BrokerCaseDip brokerCaseDip = brokerCaseDipMapper.toBrokerCaseDip(brokerCaseResponse);

        // if BTL case and product is selected we keep the product data, otherwise we delete it
        CaseApplicationDip caseApplicationDip = ofNullable(brokerCaseDip.getCaseApplication())
            .orElse(new CaseApplicationDip()); // I'm being safe but shouldn't be required
        if (BooleanUtils.isNotTrue(caseApplicationDip.getIsProductSelectedAtDip())) {
          // product has not been selected at dip, so we can delete any product details
          caseApplicationDip.setProductDetails(null);
        }

        // parse it back to the full broker data type (extending types would require coding getters for FMA attributes)
        BrokerCase brokerCaseClean = brokerCaseDipMapper.toBrokerCase(brokerCaseDip);
        // apply Return to AIP required changes: { ...currentRoute: "/dip/ApplicantDetails" }
        brokerCaseClean.getCaseApplication().setCurrentRoute(RETURN_TO_AIP_PATH);
        // save brokerCase with null FMA data
        boolean clearDipResult = true;
        return saveBrokerCaseInternal(brand, caseId, brokerCaseClean, false, clearDipResult);
    }

    private BrokerInfo getBroker() {
        String username = userClaimsProvider.getBrokerUsername();
        log.debug("Calling brokerInfoService to get broker with brokerUsername {}", username);
        BrokerInfo brokerInfo = brokerInfoService.getBroker(username);
        log.debug("brokerInfoService successfully called to get broker with brokerUsername {}", username);
        return brokerInfo;
    }
}
