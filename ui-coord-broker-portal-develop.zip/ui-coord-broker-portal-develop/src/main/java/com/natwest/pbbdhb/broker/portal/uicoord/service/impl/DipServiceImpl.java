package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.applicantsWorkStatusMap;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_CURRENT_ROUTE;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_HAS_COMPLETED_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_DIP_AFTER_FMA;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_UPDATE_CASE_PERMISSION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.CaseStatusUtil.fmaHasBeenSubmitted;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.DipResultUtil.DIP_RESULT_DATE_TIME_FORMATTER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.logging.EventLogger.formatJourneyLog;
import static java.util.Objects.isNull;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonAddressDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.client.DipClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ExpenseClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.IncomeClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.PropertyClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.dip.BureauCallManager;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ApplicationNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipIntegrationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipUnhandledValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.DipValidationException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.ErrorCode;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.UpdateNotPermittedException;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.DipApplicationMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.DipResultMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerCase;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalAddress.OccupyStatusType;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerCaseService;
import com.natwest.pbbdhb.broker.portal.uicoord.service.DipService;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.EventLogger;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.LogMessageSubtype;
import com.natwest.pbbdhb.broker.portal.uicoord.util.logging.LogMessageType;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.model.Application;
import com.natwest.pbbdhb.model.dip.response.DipExtendedResponse;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;

@Service
@RequiredArgsConstructor
@Slf4j
public class DipServiceImpl implements DipService {

    private final CaseClientNapoli caseClient;
    private final ApplicantClientNapoli applicantClient;
    private final PropertyClientNapoli propertyClient;
    private final IncomeClient incomeClient;
    private final ExpenseClient expenseClient;
    private final DipApplicationMapper dipApplicationMapper;
    private final DipClient dipClient;
    private final DipResultMapper dipResultMapper;
    private final AccessPermissionChecker accessPermissionChecker;
    private final BureauCallManager bureauCallManager;
    private final BrokerCaseService brokerCaseService;
    private final UserClaimsProvider userClaimsProvider;

    @Override
    public BrokerCase submitDip(String brand, String caseId) throws DipIntegrationException {
        String username = userClaimsProvider.getBrokerUsername();

        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
            log.error(
                formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                (new StringBuilder()).append("Permission error for case - ").append(MSG_NO_UPDATE_CASE_PERMISSION).toString()));
            throw new PermissionDeniedException(MSG_NO_UPDATE_CASE_PERMISSION);
        }

        // Fetch CAPIE data
        log.debug("Calling caseClient to get case with caseId {}", caseId);
        CaseApplicationDto caseApplicationDto = caseClient.getCase(brand, caseId);
        if (caseApplicationDto == null) {
            log.error(
                formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                "caseClient returned null response body while getting case - throwing DipIntegrationException"));
            throw new DipIntegrationException("Case data is missing");
        }

        if (fmaHasBeenSubmitted(caseApplicationDto)) {
            log.error(
                formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                "DIP cannot be submitted: FMA has already been submitted - throwing UpdateNotPermittedException"));
            throw new UpdateNotPermittedException(MSG_NO_DIP_AFTER_FMA);
        }

        log.debug("Calling applicantClient to get applicants for caseId {}", caseId);
        List<ApplicantDto> applicantDtoList = applicantClient.getApplicants(brand, caseId);
        if (applicantDtoList == null) {
            log.error(
                formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                "applicantClient returned null response body while getting applicants - throwing DipIntegrationException"));
            throw new DipIntegrationException("Applicant data is missing");
        }
        log.debug("applicantClient successfully called to get applicants for caseId {}", caseId);

        log.debug("Checking existing mortgages for applicants for caseId {}", caseId);
        applicantDtoList.forEach(a-> {
          List<PersonAddressDto> addresses = a.getAddresses();
          if(addresses != null && !addresses.isEmpty()) {
            PersonAddressDto personAddressDto = addresses.stream()
                .filter(ad -> ad.getIsCurrentAddress() != null && ad.getIsCurrentAddress() == true)
                .findFirst().orElse(null);
            if (personAddressDto != null &&
                OccupyStatusType.OWNER_MORTGAGED.value().equalsIgnoreCase(personAddressDto.getOccupyStatus()) &&
                (a.getExistingMortgages() == null || a.getExistingMortgages().isEmpty())) {
              log.error(
                  formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                  "Missing existing mortgages"));
              throw new DipValidationException(ErrorCode.MISSING_EXISTING_MORTGAGES,
                  String.format("Missing existing mortgages for caseId %s", caseId));
            }
          }
        });
        log.debug("Existing mortgages is present or is not required for caseId {}", caseId);

        log.debug("Calling propertyClient to get property for caseId {}", caseId);
        PropertyDetailsDto propertyDetailsDto = propertyClient.getProperty(brand, caseId);
        log.debug("propertyClient successfully called to get property for caseId {}", caseId);
        log.debug("Calling incomeClient to get income for caseId {}", caseId);
        ValidatedCaseIncomeDto validatedCaseIncomeDto = incomeClient.getIncome(brand, caseId);
        log.debug("incomeClient successfully called to get income for caseId {}", caseId);
        log.debug("Calling expenseClient to get expense for caseId {}", caseId);
        ValidatedCaseExpenseDto validatedCaseExpenseDto = expenseClient.getExpense(brand, caseId);
        log.debug("expenseClient successfully called to get expense for caseId {}", caseId);

        // Check applicant.workStatus is set correctly. If not, update applicant(s) before calling submitDip.
        // This is needed because applicant.workStatus needs to reflect the data stored in income.applicant.primaryJob.employmentStatus.
        // Thus data needs to be synchronised across the applicant and income services, but there is no way to update them both in an atomic operation (no transaction support).
        // This code attempts to fix any inconsistency that might be present due to earlier update failures.
        Map<String, String> workStatusMap = applicantsWorkStatusMap(applicantDtoList, validatedCaseIncomeDto);
        for (ApplicantDto applicantDto : applicantDtoList) {
            String version = applicantDto.getVersion();
            String applicantId = applicantDto.getApplicantId();
            String currentWorkStatus = applicantDto.getWorkStatus();
            String expectedWorkStatus = workStatusMap.get(applicantDto.getApplicantId());
            if (expectedWorkStatus == null) {
                if (currentWorkStatus != null) {
                    applicantDto.setWorkStatus(null);
                    log.debug("Calling applicantClient to save applicant with workStatus null, version {}, caseId {}, and applicantId {}",
                        version, caseId, applicantId);
                    applicantClient.saveApplicant(brand, applicantDto);
                    log.debug("applicantClient successfully called to save applicant with workStatus null, version {}, caseId {}, and applicantId {}", version, caseId, applicantId);
                }
            } else if (!expectedWorkStatus.equals(currentWorkStatus)) {
                applicantDto.setWorkStatus(expectedWorkStatus);
                log.debug("Calling applicantClient to save applicant with workStatus matching expectedWorkStatus, version {}, caseId {}, and applicantId {}",
                    version, caseId, applicantId);
                applicantClient.saveApplicant(brand, applicantDto);
                log.debug("applicantClient successfully called to save applicant with workStatus matching expectedWorkStatus, version {}, caseId {}, and applicantId {}",
                    version, caseId, applicantId);
            }

        }
        // TODO: Check any other 'cross-service' fields that could get out of sync when broker case updates are not atomic.

        try {
          // Populate application
          Application application = dipApplicationMapper.toDipApplication(brand, caseApplicationDto,
              applicantDtoList, propertyDetailsDto, validatedCaseIncomeDto,
              validatedCaseExpenseDto);

          DipExtendedResponse dipResponse;
          // dipSubmissionDateTime logic:
          // -when submitting new DIP: set new date time, to reset expiry date
          // -when amending existing DIP: use previous DIP date time, to keep expiry date period
          // change context:
          // dipResultMapper was always setting a new dateTime but we wanted to keep the existing DIP date time when amending a DIP
          // so I removed the automatic dateTime set and added a dateTime argument in the mapper, which we always control
          String dipSubmissionDateTime;
          final Optional<String> dipAmendDateTime;
          if (bureauCallManager.hasMatchingBureauCall(caseApplicationDto, applicantDtoList)) {
            String dipId = bureauCallManager.getDipId(caseApplicationDto);
            log.debug("Calling dipClient to amend DIP with caseId {} and dipId {}", caseId, dipId);
            dipResponse = dipClient.amendDip(application, dipId);
            log.debug("dipClient successfully called to amend DIP with caseId {} and dipId {}",
                caseId, dipId);
            dipSubmissionDateTime = caseApplicationDto.getDecisionInPrinciples().get(0)
                .getDateTime();
            dipAmendDateTime = Optional.of(dipResultMapper.newDecisionInPrincipleDateTime());
            // update: logic below is useless after dip expiry logic update
            // reset submission date when it's expired (over 30 days)
            dipSubmissionDateTime = resetSubmissionDate(brand, dipSubmissionDateTime, dipId, caseId, username);
          } else {
            log.debug("Calling dipClient to submit DIP for caseId {}", caseId);
            dipResponse = dipClient.submitDip(application);
            log.debug("dipClient successfully called to submit DIP with caseId {}", caseId);
            bureauCallManager.setBureauCallInfo(caseApplicationDto, dipResponse, applicantDtoList);
            dipSubmissionDateTime = dipResultMapper.newDecisionInPrincipleDateTime();
            dipAmendDateTime = Optional.empty();
          }

          // Save DIP result in CAPIE
          DecisionInPrincipleDto dipDto = dipResultMapper.toDecisionInPrincipleDtoWithCustomDateTime(
              dipResponse, dipSubmissionDateTime);
          caseApplicationDto.setDecisionInPrinciples(Collections.singletonList(
              dipDto)); // currently, we only keep the latest DIP, and are not appending new ones
          if (isNull(caseApplicationDto.getJourneyData())) {
            caseApplicationDto.setJourneyData(new HashMap<>());
          }
          // sets dip completed to true, this will not be deleted if 'return to aip' is used and will successfully lock 'about the case' fields section
          caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_HAS_COMPLETED_DIP, true);
          // update current navigation route
          caseApplicationDto.getJourneyData()
              .put(CASE_JOURNEY_DATA_CURRENT_ROUTE, "/dip/Submitted");

          // we are not using these today but I've added them in, but if we need in the future then we will have values in existing cases
          caseApplicationDto.getJourneyData()
              .put(CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME, dipSubmissionDateTime);
          dipAmendDateTime.ifPresent(dipAmendDateTimeString ->
              caseApplicationDto.getJourneyData()
                  .put(CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME, dipAmendDateTimeString));

          //setting the value for Journey data for isProductSelectedAtDip
          SalesIllustrationDto salesIllustrationDto = Optional.ofNullable(caseApplicationDto.getSalesIllustrations())
              .orElse(Collections.emptyList()).stream().findFirst().orElse(new SalesIllustrationDto());
          ProductDetailsDto productDetailsDto = Optional.ofNullable(salesIllustrationDto.getProducts())
              .orElse(Collections.emptyList()).stream().findFirst().orElse(new ProductDetailsDto());
          boolean productExistsAtDip = productDetailsDto.getProductCode() != null;
          log.debug("Updating Case Journey Data value of isProductSelectedAtDip.");
          caseApplicationDto.getJourneyData().put(CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP, productExistsAtDip);

          log.debug("Calling caseClient to update case with caseId {}", caseId);
          caseClient.updateCase(brand, caseApplicationDto);
          log.info(EventLogger.logDipResult(username, brand, caseApplicationDto));

          // return the entire updated broker case
          return brokerCaseService.getBrokerCaseInternal(brand, caseId);

        } catch (DipValidationException ex) {
          if (ErrorCode.UNHANDLED.equals(ex.getCode())){
            log.warn(formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                (new StringBuilder()).append("Caught unhandled validation exception while submitting DIP - throwing DipUnhandledValidationException: ")
                    .append(ex.getMessage()).toString()));
            throw new DipUnhandledValidationException(ex.getCode(), ex.getMessage());
          }
          log.warn(formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
              (new StringBuilder()).append("Caught validation exception while submitting DIP - throwing DipValidationException: ")
                  .append(ex.getMessage()).toString()));
          throw ex;
        } catch (HttpStatusCodeException | DipIntegrationException ex) {
            log.warn(formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                (new StringBuilder()).append("Caught ").append(ex.getClass().getSimpleName())
                    .append(" while submitting DIP - rethrowing: ").append(ex.getMessage()).toString()));
            throw ex;
        } catch (Throwable t) {
            String message = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            log.warn(formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
                (new StringBuilder()).append("An unexpected exception occurred while submitting DIP: ")
                    .append(message).toString()));
            throw new DipIntegrationException(message, t);
        }
    }

    @Override
    public InputStreamResource getDipCertificateWithCaseId(String brand, String caseId) throws DipIntegrationException {
        log.debug("Calling dipClient to get DIP certificate with caseId {}", caseId);
        InputStream dipPdfStream = dipClient.getDipCertificate(brand, caseId);
        log.debug("dipClient successfully called to get DIP certificate with caseId {}", caseId);
        return new InputStreamResource(dipPdfStream);
    }

    @Override
    public InputStreamResource getDipDocumentByDipId(String brand, String dipId) throws ApplicationNotFoundException, DipIntegrationException {
        log.debug("Calling dipClient to get DIP document with dipId {}", dipId);
        InputStream dipPdfStream = dipClient.getDipDocumentByDipId(brand, dipId);
        log.debug("dipClient successfully called to get DIP document with dipId {}", dipId);
        return new InputStreamResource(dipPdfStream);
    }

    private String resetSubmissionDate(String brand, String dipSubmissionDateTime, String dipId, String caseId, String username) {
        try {
            if (LocalDateTime.parse(dipSubmissionDateTime, DIP_RESULT_DATE_TIME_FORMATTER)
                .isBefore(LocalDateTime.now().minusDays(30))) {
                dipSubmissionDateTime = dipResultMapper.newDecisionInPrincipleDateTime();
            }
        } catch (DateTimeParseException ex) {
          log.error(formatJourneyLog(brand, LogMessageType.DIP, LogMessageSubtype.DIP_SUBMIT, caseId,  username,
              (new StringBuilder()).append("Cannot parse dipSubmissionDateTime for DIP with dipId ")
                  .append(dipId).append(": ")
                  .append(ex.getMessage()).toString()));
          throw ex;
        }
        return dipSubmissionDateTime;
    }

}
