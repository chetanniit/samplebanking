package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.MafDocumentClient;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.PermissionDeniedException;
import com.natwest.pbbdhb.broker.portal.uicoord.security.AccessPermissionChecker;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.MafDocumentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.MSG_NO_MAF_DOWNLOAD_PERMISSION;

@Service
@RequiredArgsConstructor
@Slf4j
public class MafDocumentServiceImpl implements MafDocumentService {

    private final MafDocumentClient mafDocumentClient;
    private final AccessPermissionChecker accessPermissionChecker;
    private final UserClaimsProvider userClaimsProvider;

    @Override
    public InputStreamResource getMafDocument(String documentName, String brand) {
        log.debug("Calling mafDocumentClient to get MAF document with name {}", documentName);
        String caseId   = getCaseIdFromDocumentName(documentName);
        log.debug("caseId obtained from document name {}", caseId);
        if (!accessPermissionChecker.isCaseOwner(brand, caseId)) {
            log.error("Error downloading maf document with caseId {} and brokerUsername {} and documentName {} : {}",
                    caseId, userClaimsProvider.getBrokerUsername(),documentName, MSG_NO_MAF_DOWNLOAD_PERMISSION);
            throw new PermissionDeniedException(MSG_NO_MAF_DOWNLOAD_PERMISSION);
        }
        InputStream mafPdfStream = mafDocumentClient.getMafDocument(documentName);
        log.debug("mafDocumentClient successfully called to get MAF document with name {}", documentName);
        return new InputStreamResource(mafPdfStream);
    }

    private String getCaseIdFromDocumentName(String documentName) {
        String[] docAttributes = documentName.split("-");
        return docAttributes[1];
    }
}
