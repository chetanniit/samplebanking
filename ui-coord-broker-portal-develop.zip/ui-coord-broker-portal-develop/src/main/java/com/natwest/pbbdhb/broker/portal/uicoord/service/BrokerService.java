package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BrokerProductSwitchDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;

import java.util.List;

public interface BrokerService {

  List<PaymentPath> getBrokerPaymentPaths(BrokerInfo broker);

  BrokerProductSwitchDetails getBrokerProductSwitchDetails(String brand, String paymentPathName, BrokerInfo broker);

  String getBrokerDeclaration(String brand, BrokerInfo broker);
}
