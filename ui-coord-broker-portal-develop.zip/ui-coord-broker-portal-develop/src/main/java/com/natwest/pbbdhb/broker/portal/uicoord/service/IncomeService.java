package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;

public interface IncomeService {
    CaseIncome saveIncome(String brand, String caseId, CaseIncome income);

    CaseIncome getIncome(String brand, String caseId);
}
