package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ConditionalRegexValidation;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

import java.util.regex.Pattern;

import static org.apache.tomcat.util.IntrospectionUtils.getProperty;

public class ConditionalRegexValidator implements
    ConstraintValidator<ConditionalRegexValidation, Object> {

    private String conditionalValidatedField;
    private String conditionField;
    private String conditionValue;
    private String defaultErrorMessage;
    private String regexp;
    private boolean caseInsensitive;

    @Override
    public void initialize(ConditionalRegexValidation annotation) {
        this.conditionalValidatedField = annotation.conditionalValidatedField();
        this.conditionField = annotation.conditionField();
        this.conditionValue = annotation.conditionValue();
        this.regexp = annotation.regexp();
        this.caseInsensitive = annotation.caseInsensitive();
        this.defaultErrorMessage = String.format(ConditionalRegexValidation.DEFAULT_ERROR_MESSAGE_TEMPLATE,
                conditionalValidatedField, regexp, conditionField, conditionValue); // "postcode must match  when country is GB"
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        context.unwrap(HibernateConstraintValidatorContext.class).addExpressionVariable(ConditionalRegexValidation.DEFAULT_ERROR_MESSAGE_KEY, defaultErrorMessage);
        String conditionalValidatedFieldValue = (String) getProperty(objectToValidate, conditionalValidatedField);
        boolean isValid = objectToValidate == null // ok if obj is null
            || conditionalValidatedFieldValue == null // ok if the field to be validated is null
            || !conditionValue.equals(getProperty(objectToValidate, conditionField)) // ok if condition doesn't match
            || isValid(conditionalValidatedFieldValue); // ok if conditionalMandatory field is not null

        //needed to add the field name to the validation context - ConstraintViolation.class, getPropertyPath()
        if(!isValid) {
            context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate())
                    .addPropertyNode(conditionalValidatedField)
                    .addConstraintViolation()
                    .disableDefaultConstraintViolation();
        }

        return isValid;
    }

    private boolean isValid(String input) {
        Pattern pattern = caseInsensitive ? Pattern.compile(regexp, Pattern.CASE_INSENSITIVE) : Pattern.compile(regexp);
        return pattern.matcher(input).matches();
    }
}
