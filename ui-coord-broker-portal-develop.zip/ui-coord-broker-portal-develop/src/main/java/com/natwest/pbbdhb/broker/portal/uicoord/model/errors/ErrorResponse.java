package com.natwest.pbbdhb.broker.portal.uicoord.model.errors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
@Value
@Builder
@JsonInclude(Include.NON_NULL)
@AllArgsConstructor
public class ErrorResponse {

  @JsonProperty("status")
  @Schema(
      description = "HTTP status code of error",
      example = "500"
  )
  int status;

  @JsonProperty("title")
  @Schema(
      description = "Title of error",
      example = "Internal Server Error"
  )
  String title;

  @JsonProperty("description")
  @Schema(
      description = "Description of error",
      example = "Sorry, something went wrong."
  )
  String description;

  @JsonProperty("errors")
  @Schema(
      description = "List of errors encountered as part of request, typically validation failure errors"
  )
  List<ErrorResponseDetail> errors;
}
