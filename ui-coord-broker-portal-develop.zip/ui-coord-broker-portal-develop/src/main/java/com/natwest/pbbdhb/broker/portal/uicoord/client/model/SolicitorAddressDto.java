package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * Solicitor address details returned from the Solicitor service
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SolicitorAddressDto {

    private String address1;

    private String address2;

    private String address3;

    private String addressPC;
}
