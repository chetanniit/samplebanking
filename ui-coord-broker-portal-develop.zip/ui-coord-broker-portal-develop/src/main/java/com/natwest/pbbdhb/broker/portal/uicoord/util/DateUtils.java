package com.natwest.pbbdhb.broker.portal.uicoord.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateUtils {

  public static final DateTimeFormatter PRODUCT_VALIDATION_DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");

  public static String isoDateToProductValidationDateString(String dateString) {
    return LocalDate.parse(dateString, DateTimeFormatter.ISO_DATE)
        .format(PRODUCT_VALIDATION_DATE_FORMATTER);
  }

}
