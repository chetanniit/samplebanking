package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
public class OtherPropertyDip {

  private String id;

  @NotNull
  @DateFormat(pattern = "yyyy-MM-dd")
  private String datePurchased;

  @NotNull
  @Min(1)
  @Max(99_999_999)
  private Integer estimatedPropertyValue;

  @Min(1)
  @Max(99_999_999)
  private Integer interestOnlyAmount;

  @Size(min = 1, max = 30)
  private String lenderName;

  @Min(1)
  @Max(99_999_999)
  private Integer monthlyRentalIncome;

  @Min(1)
  @Max(99_999_999)
  private Integer monthlyMortgagePayment;

  @ValidateEnum(enumClass = OtherProperty.RepaymentType.class)
  private String mortgageRepaymentType;

  @Min(1)
  @Max(99_999_999)
  private Integer outstandingMortgageBalance;

  @NotNull
  @ValidateEnum(enumClass = OtherProperty.Ownership.class)
  private String ownership;

  @NotNull
  @ValidateEnum(enumClass = OtherProperty.OwnershipType.class)
  private String ownershipType;

  private Boolean propertyRedemption;

  @Size(min = 1, max = 50)
  private String propertyNotes;

  @NotNull
  @Min(1)
  @Max(99_999_999)
  private Integer purchasePrice;

  @NotNull
  @ValidateEnum(enumClass = OtherProperty.PropertyUsage.class)
  private String propertyUsage;

  @Min(0)
  @Max(11)
  private Integer remainingMortgageTermMonths;

  @Min(0)
  @Max(99)
  private Integer remainingMortgageTermYears;

  private Boolean familyLiveInProperty;

  private Boolean hasPropertyRunningCosts;

}
