package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.AddressDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.FirmDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisBorrowingRequirements;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import com.rbs.pbbdhb.sales.esis.models.Applicants;
import com.rbs.pbbdhb.sales.esis.models.Application;
import com.rbs.pbbdhb.sales.esis.models.Broker;
import com.rbs.pbbdhb.sales.esis.models.Mortgage;
import com.rbs.pbbdhb.sales.esis.models.PersonalDetails;
import com.rbs.pbbdhb.sales.esis.models.enums.LevelOfService;
import com.rbs.pbbdhb.sales.esis.models.enums.MortgageType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerClaimsUtil.getPaymentPathById;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerClaimsUtil.getPaymentPathScale;
import static com.natwest.pbbdhb.openapi.dip.Application.BuyerTypeEnum.FIRST_TIME_BUYER;
import static com.natwest.pbbdhb.openapi.fma.Application.BuyerTypeEnum.NEW_CUSTOMER;
import static java.util.Collections.emptyList;
import static java.util.Optional.ofNullable;

@Slf4j
@Component
public class EsisMapper {

  private static final String SCHEME_TYPE_HELP_TO_BUY = "HELP_TO_BUY";
  private static final String SCHEME_TYPE_RIGHT_TO_BUY = "RIGHT_TO_BUY";
  private static final String SCHEME_NAME_SHARED_EQUITY = "SHARED_EQUITY";

  private final EsisProductMapper esisProductMapper;

  @Autowired
  public EsisMapper(EsisProductMapper esisProductMapper) {
    this.esisProductMapper = esisProductMapper;
  }

  public Application mapToEsisApplication(final EsisData esisData,
      final BrokerInfo brokerData,
      final String caseId,
      final CaseApplicationDto capieCase) {
    final EsisMortgageDetails mortgageDetails = esisData.getMortgageDetails();
    final EsisBorrowingRequirements borrowingRequirements = esisData.getBorrowingRequirements();
    final Broker broker = mapToBroker(brokerData, esisData);
    broker.setBrokerFee(esisData.getCaseDetails().getBrokerFee());
    return Application.builder()
        .caseId(caseId)
        .broker(broker)
        .applicants(Applicants.builder()
            .personalDetails(
                ofNullable(esisData.getApplicants()).orElse(emptyList()).stream()
                    .map(this::mapToPersonalDetails)
                    .collect(Collectors.toList()))
            .build())
        .caseSalesIllustrationId(ofNullable(capieCase.getSalesIllustrations()).orElse(emptyList())
            .stream().findFirst()
            .map(SalesIllustrationDto::getId)
            .orElse(null))
        .levelOfService(levelOfService(esisData))
        .applicationType(esisData.getCaseDetails().getApplicationType())
        .loanPurpose(capieCase.getLoanPurpose()) // previously mapped from napoliEsis -> capieCase
        .channel(capieCase.getChannel())
        .buyerType(
            mortgageDetails.getFirstTimeBuyer() != null && mortgageDetails.getFirstTimeBuyer()
                ? FIRST_TIME_BUYER.name()
                : NEW_CUSTOMER.name())
        .mortgage(Mortgage.builder()
            .products(esisProductMapper.mapToEsisProducts(esisData))
            .propertyValue(borrowingRequirements.getPropertyValue())
            .purchasePrice(borrowingRequirements.getPurchasePrice())
            .mortgageAmount(borrowingRequirements.getMortgageAmount())
            .mortgageTermYears(mortgageDetails.getRepaymentDetails().getTermYears())
            .mortgageTermMonths(mortgageDetails.getRepaymentDetails().getTermMonths())
            .mortgageType(mapMortgageType(mortgageDetails.getRepaymentDetails().getRepaymentType()))
            .foreignCurrencyName(mortgageDetails.getCurrency())
            .foreignCurrencyExchangeRate(mortgageDetails.getCurrencyExchangeRate())
            .schemeType(schemeType(mortgageDetails.getSchemeType()))
            .schemeName(schemeName(mortgageDetails.getSchemeType()))
            .build())
        .build();
  }

  private String schemeName(String schemeType) {
    if (EsisMortgageDetails.SchemeType.SHARED_EQUITY.value().equals(schemeType)
        || EsisMortgageDetails.SchemeType.HELP_TO_BUY_SHARED_EQUITY.value().equals(schemeType)) {
      return SCHEME_NAME_SHARED_EQUITY;
    }
    return null;
  }

  private String schemeType(String schemeType) {
    if (EsisMortgageDetails.SchemeType.RIGHT_TO_BUY.value().equals(schemeType)) {
      return SCHEME_TYPE_RIGHT_TO_BUY;
    }
    if (EsisMortgageDetails.SchemeType.HELP_TO_BUY_SHARED_EQUITY.value().equals(schemeType)) {
      return SCHEME_TYPE_HELP_TO_BUY;
    }
    return null;
  }

  private String levelOfService(EsisData esisData) {
    // EsisCaseDetails.MortgageAdvised maps 1-to-1 to LevelOfService
    final LevelOfService levelOfService = EnumUtils.getEnum(
        LevelOfService.class,
        esisData.getCaseDetails().getReviewType(),
        null);
    return ofNullable(levelOfService)
        .map(LevelOfService::toString)
        .orElse(null);
  }

  private PersonalDetails mapToPersonalDetails(EsisApplicant esisApplicant) {
    return PersonalDetails.builder()
        .title(esisApplicant.getTitle().equals(Title.OTHER.value()) ? esisApplicant.getOtherTitle()
            : esisApplicant.getTitle())
        .firstNames(esisApplicant.getFirstNames())
        .middleNames(esisApplicant.getMiddleNames())
        .lastName(esisApplicant.getLastName())
        .dob(nullableCapieDate(esisApplicant.getDateOfBirth()))
        .build();
  }

  private Broker mapToBroker(BrokerInfo brokerData, EsisData esisData) {
    log.trace("mapToBroker(); brokerData: {}", brokerData);
    final String paymentPathId = esisData.getCaseDetails().getPaymentPathId();
    final PaymentPath selectedPaymentPath = getPaymentPathById(brokerData, paymentPathId);
    log.trace("mapToBroker(); selectedPaymentPath: {}", selectedPaymentPath);
    final Optional<BrokerDetails> brokerDetails = ofNullable(brokerData.getBrokerDetails());
    final Optional<AddressDetails> firmAddress = ofNullable(brokerData.getFirmDetails())
        .map(FirmDetails::getAddress);
    // firmName should use tradingName but, I've spotted 52 brokers without trading name set using prod this week
    // so we will fallback to firmName when tradingName is null
    final String firmName = ofNullable(brokerData.getFirmDetails())
        .map(FirmDetails::getTradingName)
        .orElse(ofNullable(brokerData.getFirmDetails())
            .map(FirmDetails::getFirmName)
            .orElse(null));
    return Broker.builder()
        .firmName(firmName)
        .brokerTelephoneNumber(brokerDetails.map(BrokerDetails::getMobilePhone)
            .orElse(brokerDetails.map(BrokerDetails::getOtherPhone)
                .orElse(null)))
        .firmAddress1(firmAddress
            .map(AddressDetails::getLine1)
            .orElse(null))
        .firmAddress2(firmAddress.map(AddressDetails::getLine2)
            // if line 2 is blank we bump city up
            .orElse(firmAddress.map(AddressDetails::getCity).orElse(null)))
        .firmAddress3(firmAddress.map(AddressDetails::getLine2).isPresent()
            // if line 2 is blank we bump county up
            ? firmAddress.map(AddressDetails::getCity).orElse(null)
            : firmAddress.map(AddressDetails::getCounty).orElse(null))
        .firmAddress4(firmAddress.map(AddressDetails::getLine2).isPresent()
            // if county was bumped to linie 3 then we should leave this blank
            ? firmAddress.map(AddressDetails::getCounty).orElse(null)
            : null)
        .firmPostcode(firmAddress
            .map(AddressDetails::getPostcode)
            .orElse(null))
        .paymentPathName(ofNullable(selectedPaymentPath)
            .map(PaymentPath::getPaymentPathName)
            .orElse(null))
        .paymentPathScale(getPaymentPathScale(selectedPaymentPath,
            esisData.getCaseDetails().getApplicationType()))
        .build();
  }

  private String mapMortgageType(String repaymentTypeValue) {
    MortgageType mortgageType = EnumUtils
        .getEnumIgnoreCase(MortgageType.class, repaymentTypeValue, null);
    return ofNullable(mortgageType).map(Objects::toString).orElse(null);
  }

  private LocalDate nullableCapieDate(String value) {
    return ofNullable(value)
        .map(LocalDate::parse)
        .orElse(null);
  }

}
