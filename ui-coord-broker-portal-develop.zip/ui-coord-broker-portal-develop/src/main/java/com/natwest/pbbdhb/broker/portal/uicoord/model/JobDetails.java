package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat.DateConstraint;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_NWI;

@Data
public class JobDetails {
    private String jobId;

    @ValidateEnum(enumClass = EmploymentStatus.class)
    private String employmentStatus;

    @ValidateEnum(enumClass = OccupationType.class)
    private String occupationType;

    @ValidateEnum(enumClass = IndustryType.class)
    private String industryType;

    @ValidateEnum(enumClass = PayslipFrequency.class)
    private String payslipFrequency;

    @DateFormat(pattern = "yyyy-MM-dd" , constraint = DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String employmentStartDate;

    @DateFormat(pattern = "yyyy-MM-dd")
    private String employmentEndDate;

    @DateFormat(pattern = "yyyy-MM-dd")
    private String contractEndDate;

    @DecimalMin(value = "1.00", message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    BigDecimal basicPayAnnualIncome;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String basicPayAnnualIncomeOriginatingCurrency;

    @DecimalMin(value = "1.00", message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal netBasicPayAnnualIncome;

    @Size(max = 10, min = 1)
    @Valid
    private Map<String, AdditionalJobIncome> additionalIncome;

    @ValidateEnum(enumClass = SelfEmploymentStatus.class)
    private String selfEmploymentStatus;

    @DateFormat(pattern = "yyyy-MM-dd", constraint = DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String businessEstablishmentDate;

    private Integer yearOneTradingYear;

    private Integer yearTwoTradingYear;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneProfit;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String yearOneProfitOriginatingCurrency;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneNetProfitAfterTax;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoProfit;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String yearTwoProfitOriginatingCurrency;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoNetProfitAfterTax;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneDirectorSalary;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String yearOneOriginatingCurrency;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    private BigDecimal netYearOneDirectorSalary;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneDividends;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    private BigDecimal netYearOneDividends;


    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoDirectorSalary;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String yearTwoOriginatingCurrency;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    private BigDecimal netYearTwoDirectorSalary;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoDividends;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2,
            message = "must be a value between 0 and 99999999.99 with up to 2 decimal places")
    private BigDecimal netYearTwoDividends;


    @Size(max = 30)
    private String employerName;

    @Size(max = 15)
    @Pattern(regexp = "^[0-9]*$", flags=Pattern.Flag.CASE_INSENSITIVE, message = "Badly formed phone number")
    private String employerTelephone;

    @Size(max = 50)
    private String jobTitle;

    @Min(value = 0)
    @Max(value = 100)
    private Integer employeeSharePercentage;

    @Valid
    private BasicAddress employerAddress;

    public enum EmploymentStatus implements ValuedEnum {
        EMPLOYED,
        SELF_EMPLOYED,
        CONTRACTOR,
        HOME_MAKER,
        RETIRED,
        STUDENT,
        NOT_EMPLOYED;

        @Override
        public String value() {
            return name();
        }
    }

    public enum OccupationType implements ValuedEnum {
        ACADEMIC_STAFF,
        AGRICULTURAL_WORKERS_GENERAL,
        FARM_MANAGEMENT_GENERAL,
        HM_FORCES_OFFICERS,
        HM_FORCES_OTHER_RANKS,
        HOME_FAMILY_RESPONSIBILITIES,
        JUNIOR_MANAGEMENT,
        MANUAL,
        NOT_EMPLOYED,
        OFFICE_AND_CLERICAL,
        PROFESSIONALS,
        RETIRED,
        SALES,
        SELF_EMPLOYED,
        SEMI_PROFESSIONALS,
        SEMI_SKILLED,
        SENIOR_MANAGEMENT,
        SERVICE_JOBS,
        SKILLED_MANUAL,
        STUDENT,
        SUPERVISORY_FOREMAN,
        TEACHERS,
        TECHNICIANS;

        @Override
        public String value() {
            return name();
        }
    }

    public enum IndustryType implements ValuedEnum {
        AGRICULTURE_HUNTING_FORESTRY,
        FISHING,
        MINING_AND_QUARRYING,
        MANUFACTURING,
        ELECTRICITY_GAS_WATER_SUPPLY,
        CONSTRUCTION,
        WHOLESALE_RETAIL_AND_REPAIR,
        HOTELS_AND_RESTAURANTS,
        TRANSPORT_STORAGE_COMM,
        FINANCIAL_INTERMEDIATION,
        PROPERTY_AND_BUSINESS,
        PUBLIC_ADMIN_AND_DEFENCE,
        EDUCATION,
        HEALTH_AND_SOCIAL_WORK,
        OFFICE_WORK_AND_ADMINISTRATION,
        OTHER;

        @Override
        public String value() {
            return name();
        }
    }

    public enum PayslipFrequency implements ValuedEnum {
        ANNUALLY,
        BIANNUALLY,
        QUARTERLY,
        MONTHLY,
        FOUR_WEEKLY,
        FORTNIGHTLY,
        WEEKLY;

        @Override
        public String value() {
            return name();
        }
    }

    public enum SelfEmploymentStatus implements ValuedEnum {
        SOLE_TRADER,
        PARTNERSHIP,
        LIMITED_COMPANY;

        @Override
        public String value() {
            return name();
        }
    }
}
