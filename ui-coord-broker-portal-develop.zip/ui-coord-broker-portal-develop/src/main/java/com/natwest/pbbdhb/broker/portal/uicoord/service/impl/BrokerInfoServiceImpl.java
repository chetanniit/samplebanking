package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.BrokerInfoClient;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.BrokerInfoMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.service.BrokerInfoService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BrokerInfoServiceImpl implements BrokerInfoService {

  private final BrokerInfoClient brokerInfoClient;
  private final BrokerInfoMapper brokerInfoMapper;

  @Override
  public BrokerInfo getBroker(@NonNull String username) {
    log.debug("Calling brokerInfoClient to get broker with brokerUsername {}", username);
    final BrokerInfoResponseDto brokerDto = brokerInfoClient.readBroker(username);
    log.debug("brokerInfoClient successfully called to get broker with brokerUsername {}", username);
    return brokerInfoMapper.toBroker(brokerDto);
  }
}
