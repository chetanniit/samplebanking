package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchResultDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchCriteria;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.SolicitorSearchResults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class SolicitorSearchClient {
    private final String NO_MATCHING_RECORDS_MESSAGE = "No matching records found";
    private final String SOLICITOR_SEARCH_ERROR = "solicitor search error";

    private final String solicitorSearchServiceEndpoint;
    private final RestTemplate restTemplate;

    public SolicitorSearchClient(
            @Value("${msvc.solicitor.search.url}") String solicitorSearchServiceEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.solicitorSearchServiceEndpoint = solicitorSearchServiceEndpoint;
        this.restTemplate = restTemplate;
    }

    public List<SolicitorSearchResultDto> solicitorSearch(String brand, String companyName, String postcode) {
        SolicitorSearchCriteria searchCriteria = new SolicitorSearchCriteria();
        searchCriteria.setAssociateName(companyName);
        searchCriteria.setPostCode(postcode);

        log.info("Calling {} to search for solicitor with companyName {} and postcode {}",
            solicitorSearchServiceEndpoint, companyName, postcode);

        try {
            SolicitorSearchResults results = restTemplate.exchange(
                solicitorSearchServiceEndpoint,
                HttpMethod.POST,
                new HttpEntity<>(searchCriteria, constructHeadersForJsonRequest(brand)),
                SolicitorSearchResults.class
            ).getBody();

            if (results == null) {
                log.warn("Null response body received from {} while searching for solicitor with companyName {} and postcode {} - throwing InternalServerError Exception",
                    solicitorSearchServiceEndpoint, companyName, postcode);
                throw HttpServerErrorException.create(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    new HttpHeaders(),
                    (SOLICITOR_SEARCH_ERROR + ": missing response body")
                        .getBytes(StandardCharsets.UTF_8),
                    StandardCharsets.UTF_8);
            }

            List<String> errors = results.getErrors();
            if (errors != null) {
                errors.remove(NO_MATCHING_RECORDS_MESSAGE);

                if (errors.size() > 0) {
                    log.warn("Error response received from {} while searching for solicitor with companyName {} and postcode {}: {} - throwing InternalServerError Exception",
                        solicitorSearchServiceEndpoint, companyName, postcode, errors);
                    throw HttpServerErrorException.create(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                        new HttpHeaders(),
                        (SOLICITOR_SEARCH_ERROR + ": " + String.join("; ", errors))
                            .getBytes(StandardCharsets.UTF_8),
                        StandardCharsets.UTF_8);
                }
            }

            if (results.getSolicitors() == null) {
                log.warn("No solicitor found with companyName {} and postcode {}: returning an empty list", companyName, postcode);
                return new ArrayList<>();
            }

            log.debug("Solicitor successfully retrieved for companyName {} and postcode {}", companyName, postcode);
            return results.getSolicitors();

        } catch (RestClientException ex) {
            log.warn(
                "A rest client exception occurred while calling {} to search for solicitor with companyName {} and postcode {}: {}",
                solicitorSearchServiceEndpoint, companyName, postcode, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn(
                "An unexpected exception occurred while calling {} to search for solicitor with companyName {} and postcode {}: {}",
                solicitorSearchServiceEndpoint, companyName, postcode, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
