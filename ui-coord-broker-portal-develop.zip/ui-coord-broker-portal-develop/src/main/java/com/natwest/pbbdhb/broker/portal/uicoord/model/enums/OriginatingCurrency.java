package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum OriginatingCurrency implements ValuedEnum {

  GBP,
  EUR,
  AUD,
  BHD,
  CAD,
  DKK,
  HKD,
  JPY,
  NZD,
  NOK,
  OMR,
  QAR,
  SAR,
  SGD,
  SEK,
  CHF,
  AED,
  USD,
  KWD,
  CNY,
  BMD,
  INR
  ;
  @Override
  public String value() {
    return name();
  }
}
