package com.natwest.pbbdhb.broker.portal.uicoord.util;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_JOURNEY_DATA_FMA_SUBMITTED;

import com.google.common.collect.ImmutableList;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.commondictionaries.enums.ApplicationStatus;
import java.util.List;
import java.util.Optional;
import lombok.NonNull;

public final class CaseStatusUtil {

    private static final List<String> fmaSubmittedStatuses = ImmutableList.of(
            ApplicationStatus.SUBMIT_FMA_IN_PROGRESS.name(),
            ApplicationStatus.SUBMIT_GMS_MOPS.name(),
            ApplicationStatus.SUBMIT_GMS_STAGE_20.name());

    // prevent instantiation
    private CaseStatusUtil() {
    }

    public static boolean fmaHasBeenSubmitted(@NonNull CaseApplicationDto caseApplicationDto) {
        Boolean fmaSubmitted = (Boolean) Optional.ofNullable(
            caseApplicationDto.getJourneyData()).map(dto -> dto.get(CASE_JOURNEY_DATA_FMA_SUBMITTED)).orElse(false);
        return fmaSubmittedStatuses.contains(caseApplicationDto.getApplicationStatus()) || fmaSubmitted;
    }
}
