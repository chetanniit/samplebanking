package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import lombok.Data;

@Data
public class BrokerSourcesRequestDto {

    private String firmName;

    private BrokerSourcesAddressDto address;

    private String fcaReference;

    private String networkInfo;
}
