package com.natwest.pbbdhb.broker.portal.uicoord.util.logging;

public class LogMessageSystem {

  public static String NAPOLI = "Napoli";
}

