package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Solicitor;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.SolicitorSearchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "SolicitorSearch", description = "Solicitor search API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class SolicitorSearchController {

    private final SolicitorSearchService solicitorSearchService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "solicitorSearch",
            summary = "Find solicitors matching a query string",
            tags = "SolicitorSearch"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Search was executed successfully", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Solicitor.class)))),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)))
    })
    @GetMapping(path = PATH_SOLICITOR_SEARCH, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Solicitor>> solicitorSearch(
            @Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
            @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
            @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG)
            final String brand,
            @Parameter(name = SEARCH_FOR_PARAM, description = SEARCH_FOR_DESCRIPTION)
            @RequestParam
            @Size(min = 2, max = 45)
            final String searchFor) {
        String brokerUsername = userClaimsProvider.getBrokerUsername();
        log.info("Request to find solicitors matching {} for brokerUsername {}", searchFor, brokerUsername);
        List<Solicitor> solicitors = this.solicitorSearchService.solicitorSearch(brand, searchFor);
        log.info("Solicitors matching {} for brokerUsername {} successfully retrieved", searchFor, brokerUsername);
        return ResponseEntity.ok(solicitors);
    }
}
