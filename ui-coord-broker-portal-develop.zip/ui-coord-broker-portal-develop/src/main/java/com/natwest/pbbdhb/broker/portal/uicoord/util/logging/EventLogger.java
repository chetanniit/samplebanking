package com.natwest.pbbdhb.broker.portal.uicoord.util.logging;

import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ErrorResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.errors.ValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.JourneyStep;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.DecisionInPrincipleDto;
import com.natwest.pbbdhb.commondictionaries.enums.cases.ApplicationType;
import com.natwest.pbbdhb.commondictionaries.enums.cases.BuyerType;
import com.natwest.pbbdhb.commondictionaries.enums.cases.LoanPurpose;
import com.natwest.pbbdhb.model.fma.FullMortgageApplicationExtendedResponse;
import com.natwest.pbbdhb.msvcutils.logging.LogMessage;
import lombok.experimental.UtilityClass;

import java.util.Comparator;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@UtilityClass
public class EventLogger {

  private static final String CASE_TYPE_FIRST_TIME_BUYER = "first_time_buyer";
  private static final String CASE_TYPE_HOME_MOVER = "home_mover";
  private static final String CASE_TYPE_REMORTGAGE = "remortgage";
  private static final String APPLICATION_TYPE_RESIDENTIAL = "residential";
  private static final String APPLICATION_TYPE_BUY_TO_LET = "buy_to_let";

  public static String logException(Throwable ex, ErrorResponse error) {
        return LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.EXCEPTION)
            .subtype(LogMessageSubtype.ERROR_RESPONSE)
            .description(String.format(
                "exception=%s message=%s error=%s",
                ex != null ? ex.getClass().getSimpleName(): "",
                error != null ? removeSpaces(String.format("%d-%s", error.getStatus(), error.getTitle())) : "",
                error))
            .build();
  }

  public static String logValidationResponse(Throwable ex, ValidationResponse response, String type, String subtype) {
        return LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(type)
            .subtype(subtype)
            .description(String.format(
                "exception=%s message=%s error=%s",
                ex != null ? ex.getClass().getSimpleName(): "",
                response != null ? removeSpaces(String.format("%d-%s", response.getStatus(), response.getTitle())) : "",
                response))
            .build();
  }

  public static String logUnhandledValidationErrorResponse(Throwable ex, ValidationResponse response, String type, String subtype) {
        return LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(type)
            .subtype(subtype)
            .description(String.format(
                "exception=%s message=%s error=%s",
                ex != null ? ex.getClass().getSimpleName(): "",
                response != null ? removeSpaces(String.format("%d-%s", response.getStatus(), response.getTitle())) : "",
                response))
            .build();
  }

  public static String logDipResult(String brokerUsername, String brand, CaseApplicationDto caseApplication) {
        return LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.DIP)
            .subtype(LogMessageSubtype.DIP_SUBMIT)
            .description(String.format(
                "brokerUsername=%s brand=%s caseId=%s caseType=%s applicationType=%s dipId=%s mortgageAmount=%s decision=%s",
                brokerUsername,
                brand,
                getCaseId(caseApplication),
                getCaseType(caseApplication),
                getApplicationType(caseApplication),
                getDipId(caseApplication),
                getMortgageAmount(caseApplication),
                getGalileoDecision(caseApplication)))
            .build();
  }

  public static String logFmaResult(String brand, String brokerUsername, CaseApplicationDto caseApplication, FullMortgageApplicationExtendedResponse fmaResponse) {
    return LogMessage.builder()
            .system(LogMessageSystem.NAPOLI)
            .type(LogMessageType.FMA)
            .subtype(LogMessageSubtype.FMA_SUBMIT)
            .description(String.format(
                "brand=%s brokerUsername=%s caseId=%s caseType=%s applicationType=%s mortgageAmount=%s fmaResponseCode=%s mortgageReferenceNumber=%s temporaryReferenceNumber=%s hardScoreDecision=%s",
                brand,
                brokerUsername,
                getCaseId(caseApplication),
                getCaseType(caseApplication),
                getApplicationType(caseApplication),
                getMortgageAmount(caseApplication),
                getFmaStatus(fmaResponse),
                getMortgageReferenceNumber(fmaResponse),
                getTemporaryReferenceNumber(fmaResponse),
                getHardScoreDecision(fmaResponse)))
            .build();
  }

  public static String formatJourneyLog(String brand, JourneyStep journeyStep,
      CaseApplicationDto caseApplication, String brokerUsername, String message) {
    return LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(LogMessageType.FMA)
        .subtype(LogMessageSubtype.FMA_SUBMIT)
        .description(String.format(
            "journeyStep=%s brand=%s caseId=%s caseVersion=%s caseType=%s brokerUsername=%s message=%s",
            journeyStep,
            brand,
            getCaseId(caseApplication),
            getCaseVersion(caseApplication),
            getCaseType(caseApplication),
            brokerUsername,
            message))
        .build();
  }

  public static String formatJourneyLog(String brand,
      String logMessageType, String logMessageSubtype,
      String caseId, String brokerUsername, String message) {
    return LogMessage.builder()
        .system(LogMessageSystem.NAPOLI)
        .type(logMessageType)
        .subtype(logMessageSubtype)
        .description(String.format(
            "brand=%s caseId=%s brokerUsername=%s message=%s",
            brand,
            caseId,
            brokerUsername,
            message))
        .build();
  }


  // application logs are space-delimited key-value pairs
  // we will need to remove additional spaces
  private static String removeSpaces(String text) {
    if (text == null) {
      return "";
    }
    return text.replaceAll("\\s+","-");
  }

  private static String getCaseId(CaseApplicationDto caseApplication) {
    if (caseApplication == null || caseApplication.getCaseId() == null) {
      return "";
    }
    return caseApplication.getCaseId();
  }

  private static String getCaseVersion(CaseApplicationDto caseApplication) {
    if (caseApplication == null || caseApplication.getCaseId() == null) {
      return "";
    }
    return caseApplication.getVersion();
  }

  private static String getApplicationType(CaseApplicationDto caseApplication) {
    if (caseApplication != null && caseApplication.getApplicationType() != null) {
      if (caseApplication.getApplicationType()
          .equalsIgnoreCase(ApplicationType.RESIDENTIAL.name())) {
        return APPLICATION_TYPE_RESIDENTIAL;
      }
      if (caseApplication.getApplicationType()
          .equalsIgnoreCase(ApplicationType.BUY_TO_LET.name())) {
        return APPLICATION_TYPE_BUY_TO_LET;
      }
    }
    return "";
  }

  private static String getCaseType(CaseApplicationDto caseApplication) {
    if (caseApplication != null) {
      if (isNotBlank(caseApplication.getBuyerType()) && caseApplication.getBuyerType()
          .equalsIgnoreCase(BuyerType.FIRST_TIME_BUYER.name())) {
        return CASE_TYPE_FIRST_TIME_BUYER;
      }
      if (caseApplication.getLoanPurpose() == null) {
        return "";
      } else {
        return caseApplication.getLoanPurpose().equalsIgnoreCase(LoanPurpose.HOUSE_PURCHASE.name()) ? CASE_TYPE_HOME_MOVER
            : CASE_TYPE_REMORTGAGE;
      }
    }
    return "";
  }

  private static DecisionInPrincipleDto getLatestDip(CaseApplicationDto caseApplication) {
    if (caseApplication == null) {
      return null;
    }
    if (caseApplication.getDecisionInPrinciples() != null) {
      if (caseApplication.getDecisionInPrinciples().size() == 1) {
        return caseApplication.getDecisionInPrinciples().get(0);
      } else {
        caseApplication.getDecisionInPrinciples().sort(Comparator.comparing(DecisionInPrincipleDto::getDateTime));
        return caseApplication.getDecisionInPrinciples().get(caseApplication.getDecisionInPrinciples().size() - 1);
      }
    }
    return null;
  }

  private static String getDipId(CaseApplicationDto caseApplication) {
    DecisionInPrincipleDto dip =  getLatestDip(caseApplication);
    if (dip == null) {
      return "";
    } else {
      return dip.getDipId();
    }
  }

  private static String getGalileoDecision(CaseApplicationDto caseApplication) {
    DecisionInPrincipleDto dip =  getLatestDip(caseApplication);
    if (dip != null && dip.getDecision() != null) {
      return dip.getDecision();
    }
    return "";
  }

  private static String getFmaStatus(FullMortgageApplicationExtendedResponse fmaResponse) {
    if (fmaResponse == null || fmaResponse.getResponseStatus() == null
        || fmaResponse.getResponseStatus().getStatus() == null) {
      return "";
    }
    return fmaResponse.getResponseStatus().getStatus();
  }

  private static String getMortgageReferenceNumber(FullMortgageApplicationExtendedResponse fmaResponse) {
    if (fmaResponse == null || fmaResponse.getData() == null
        || fmaResponse.getData().getMortgageNumber() == null)
      return "";
    return fmaResponse.getData().getMortgageNumber();
  }

  private static String getTemporaryReferenceNumber(FullMortgageApplicationExtendedResponse fmaResponse) {
    if (fmaResponse == null || fmaResponse.getData() == null
        || fmaResponse.getData().getTempRefNo() == null) {
      return "";
    }
    return fmaResponse.getData().getTempRefNo();
  }

  private static String getHardScoreDecision(FullMortgageApplicationExtendedResponse fmaResponse) {
    if (fmaResponse == null || fmaResponse.getData() == null
        || fmaResponse.getData().getHardscoreDecision() == null
        || fmaResponse.getData().getHardscoreDecision().getDecision() == null) {
      return "";
    }
    return fmaResponse.getData().getHardscoreDecision().getDecision();
  }

  private static String getMortgageAmount(CaseApplicationDto caseApplication) {
    if (caseApplication == null
        || caseApplication.getMortgage() == null
        || caseApplication.getMortgage().getMortgageAmount() == null) {
      return "";
    }
    return Long.toString(caseApplication.getMortgage().getMortgageAmount());
  }
}
