package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

@Data
public class Valuation {

    @ValidateEnum(enumClass = Type.class)
    private String type;

    private String date;

    public enum Type implements ValuedEnum {
        RE_INSPECTION,
        DRIVE_BY_VALUATION,
        STANDARD_MORTGAGE_VALUATION,
        BUILDING_SURVEY,
        NO_VALUATION_REQUIRED,
        SUMMIT_EXISTING_VALUATION,
        KERBSIDE_VALUATION,
        FULL_VALUATION,
        REVALUATION,
        AUTOMATED_VALUATION,
        AUTOMATED_RE_VALUATION,
        DESKTOP_VALUATION,
        NEW_BUILD_RE_VALUATION;

        @Override
        public String value() {
            return name();
        }
    }
}
