package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.groups.DipSubmitValidationGroup;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class FinancialCommitment {
    @NotBlank(groups = DipSubmitValidationGroup.class)
    @ValidateEnum(enumClass = FinancialCommitment.FinancialCommitmentType.class)
    private String type;

    @DecimalMin(value = "0", message = "must be a value between 0 and 99999999")
    @Digits(integer = 8, fraction = 0, message = "must be a value between 0 and 99999999")
    @NotNull(groups = DipSubmitValidationGroup.class)
    private BigDecimal payments;

    @NotBlank(groups = DipSubmitValidationGroup.class)
    @ValidateEnum(enumClass = FinancialCommitment.Frequency.class)
    private String frequency;

    @NotBlank(groups = DipSubmitValidationGroup.class)
    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String originatingCurrency;


    public enum Frequency implements ValuedEnum {
        MONTHLY, YEARLY, WEEKLY, QUARTERLY, FORTNIGHTLY;

        @Override
        public String value() {
            return name();
        }
    }

    public enum FinancialCommitmentType implements ValuedEnum {
        COST_OF_LIVING,
        QUALITY_OF_LIVING;

        @Override
        public String value() {
            return name();
        }
    }
}
