package com.natwest.pbbdhb.broker.portal.uicoord.util;

public final class ApplicationConstants {

  public static final String PATH_BROKER_BASE = "/broker";
  public static final String PATH_GET_BROKER_PAYMENT_PATHS = "/paymentPaths";
  public static final String PATH_GET_BROKER_PRODUCT_SWITCH = "/productSwitch";

  public static final String PATH_GET_BROKER_CASE = "/brokerCases/{caseId}";
  public static final String PATH_SAVE_BROKER_CASE = "/brokerCases/{caseId}";
  public static final String PATH_DIP_RESULT_CLEAR = "/brokerCases/dipResultClear/{caseId}";
  public static final String PATH_GET_BROKER_DECLARATION = "/declaration";

  public static final String PATH_GET_CASE_ID = "/caseId";
  public static final String PATH_SAVE_CASE = "/cases/{caseId}";

  public static final String PATH_GET_ESIS = "/esis/{documentName}";
  public static final String PATH_GET_ESIS_WITH_CASE_ID = "/esis/case/{caseId}";
  public static final String PATH_SAVE_ESIS = "/esis";
  public static final String PATH_GET_ESIS_DOC_INFO = "/esis/{caseId}/info";
  public static final String PATH_UPDATE_ESIS_DOC_DESCRIPTION = "/esis/{caseId}/description";

  public static final String PATH_ADD_APPLICANTS = "/cases/{caseId}/applicants";

  public static final String PATH_GET_DIP_WITH_CASE_ID = "/dip/certificate/{dipId}";
  public static final String PATH_GET_DIP_DOCUMENT_BY_CASE_ID = "/dip/document/{dipId}";
  public static final String PATH_SUBMIT_DIP = "/dip/submit/{caseId}";

  public static final String PATH_SUBMIT_FMA = "/fma/submit/{caseId}";

  public static final String PATH_GET_MAF_DOC_FROM_CASE_ID = "/maf/caseId/{caseId}";
  public static final String PATH_GET_MAF_DOC_FROM_NAME = "/maf/{documentName}";

  public static final String PATH_SOLICITOR_SEARCH = "/solicitors";

  public static final String PATH_PRODUCT_SEARCH = "/products";
  public static final String PATH_PRODUCT_VALIDATION = "/product-validation/{caseId}";

  public static final String PATH_PAYMENT = "/payment";

  public static final String PATH_VALIDATE_ACCOUNT = "/validateAccount";

  public static final String BRAND_HEADER = "brand";
  public static final String BRAND_INVALID_MSG = "The brand name is invalid";
  public static final String BRAND_VALID_REGEX = "(rbs|nwb|nwi)";
  public static final String BRAND_DEFAULT = "nwb";
  public static final String BRAND_DESCRIPTION = "The brand name";


  public static final String CASE_ID_PARAM = "caseId";
  public static final String CASE_ID_DESCRIPTION = "The ID of a case";

  public static final String DIP_ID_PARAM = "dipId";
  public static final String DIP_ID_DESCRIPTION = "The ID of a DIP";

  public static final String MAF_DOC_NAME_PARAM = "documentName";
  public static final String MAF_DOC_NAME_DESCRIPTION = "The name of a MAF Document";

  public static final String PAYMENT_PATH_NAME_PARAM = "paymentPathName";
  public static final String PAYMENT_PATH_NAME_DESCRIPTION = "Payment path name";

  public static final String SEARCH_FOR_PARAM = "searchFor";
  public static final String SEARCH_FOR_DESCRIPTION = "character string to search for";

  public static final String CASE_ID_PREFIX_PARAM = "caseIdPrefix";
  public static final String CASE_ID_PREFIX_VALUE = "CP";
  public static final String CLIENT_ID_PARAM = "clientId";
  public static final String CLIENT_ID_VALUE = "323212";
  public static final String CLIENT_ID_HEADER = "client_id";

  public static final String MARKETING_SOURCE_DEFAULT = "AA";

  public static final String SIZE_AT_LEAST_ONE_MSG = "size must be at least 1";
  public static final String MUST_BE_5_OR_6_DIGITS = "must be 5 or 6 digits";
  public static final String MUST_BE_8_DIGITS = "must be 8 digits";
  public static final String MUST_BE_CORRECT_FORMAT = "must be correct format";

  public static final String MSG_NO_CREATE_CASE_PERMISSION = "User does not have permission to create cases.";
  public static final String MSG_NO_GENERATE_CASE_ID_PERMISSION = "User does not have permission to generate case id.";
  public static final String MSG_NO_MAF_DOWNLOAD_PERMISSION = "User does not have permission to download maf document.";
  public static final String MSG_NO_UPDATE_CASE_PERMISSION = "User does not have permission to update case.";
  public static final String MSG_MISSING_EXISTING_MORTGAGES = "Missing existing mortgages for caseId";
  public static final String MSG_NO_READ_CASE_PERMISSION = "User does not have permission to read case.";
  public static final String MSG_NO_UPDATE_AFTER_FMA = "Update not permitted after FMA submission.";
  public static final String MSG_NO_DIP_AFTER_FMA = "DIP submission not permitted after FMA submission.";
  public static final String MSG_FMA_ALREADY_SUBMITTED = "FMA already submitted.";
  public static final String MSG_NO_DIP_RESULT = "No DIP result";
  public static final String MSG_DIP_EXPIRED = "DIP has expired.";
  public static final String MSG_INVALID_EXPENSE_LOAN_CONSOLIDATED_AMOUNT = "Loan consolidated amount must be in whole pounds.";
  public static final String MSG_INVALID_EXPENSE_CREDIT_CARD_CONSOLIDATED_AMOUNT = "Credit Card consolidated amount must be in whole pounds.";
  public static final String MSG_INVALID_EXPENSE_LOAN_OUTSTANDING_AMOUNT = "Loan outstanding amount must be in whole pounds.";
  public static final String MSG_INVALID_EXPENSE_CREDIT_CARD_OUTSTANDING_BALANCE = "Credit Card outstanding balance must be in whole pounds.";

  public static final String MSG_INVALID_PAYMENT_PATH_ID = "Selected Broker Payment Path is invalid.";
  public static final String MSG_MISSING_PAYMENT_PATH_ID = "Broker Payment Path is missing.";
  public static final String MSG_INVALID_BROKER_TRADING_NAME = "Invalid Trading/Firm Name - Please update your trading name/firm name via the maintain personal details page";
  public static final String MSG_VALIDATION_FAILURE = "Validation Failure";
  public static final String MSG_UNKNOWN_ERR = "An unknown error occurred";
  public static final String MSG_VALIDATION_FAILURE_DESC = "The following validation failures occurred";
  public static final String MSG_ESTATE_AGENT_LENGTH_EXCEEDED = "Estate agent firm name character limit exceeded, please reduce to a maximum of 45 characters.";
  public static final String APPLICANT_JOURNEY_DATA_BANK_WITH_NATWEST = "bankWithNatWest";
  public static final String CASE_JOURNEY_DATA_CURRENT_ROUTE = "currentRoute";
  public static final String CASE_JOURNEY_DATA_FIRST_TIME_BUYER = "firstTimeBuyer";
  public static final String CASE_JOURNEY_DATA_USING_SPECIALIST_SCHEME = "usingSpecialistScheme";
  public static final String CASE_JOURNEY_DATA_HAS_DEPENDANTS = "hasDependants";
  public static final String CASE_JOURNEY_DATA_REPAYMENT_STRATEGY_ADDRESSES = "repaymentStrategyAddresses";
  public static final String CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_1 = "solicitorAddress1";
  public static final String CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_2 = "solicitorAddress2";
  public static final String CASE_JOURNEY_DATA_SOLICITOR_ADDRESS_3 = "solicitorAddress3";
  public static final String CASE_JOURNEY_DATA_HAS_ADDITIONAL_BORROWING = "hasAdditionalBorrowing";
  public static final String CASE_JOURNEY_DATA_BTL_SHORT_ASSURED = "isAssuredShortHoldOrShortAssured";
  public static final String CASE_JOURNEY_DATA_BTL_FOR_INVESTMENT = "isForInvestment";
  public static final String CASE_JOURNEY_DATA_BTL_NOT_HMO = "isNotSelectiveLicenceOrHMO";
  public static final String CASE_JOURNEY_DATA_BTL_FAMILY = "isRentingToImmediateFamilyMember";
  public static final String CASE_JOURNEY_DATA_BTL_MOVING_AT_COMPLETION = "movingToPropertyAtCompletion";
  public static final String CASE_JOURNEY_DATA_BUREAU_CALL_INFO = "bureauCallInfo";
  public static final String CASE_JOURNEY_DATA_HAS_COMPLETED_DIP = "hasCompletedDip";
  public static final String CASE_JOURNEY_DATA_BROKER_FEE_CHARGED = "brokerFeeCharged";
  public static final String CASE_JOURNEY_DATA_DIP_SUBMITTED_DATE_TIME = "dipSubmittedDateTime";
  public static final String CASE_JOURNEY_DATA_DIP_AMENDED_DATE_TIME = "dipAmendedDateTime";
  public static final String CASE_JOURNEY_DATA_FMA_SUBMITTED = "fmaSubmitted";
  public static final String CASE_JOURNEY_DATA_STEP = "step";
  public static final String CASE_JOURNEY_DATA_LEASEHOLD_OWNERSHIP_TERM = "leaseholdOwnershipTerm";
  public static final String CASE_JOURNEY_DATA_IS_PRODUCT_SELECTED_AT_DIP = "isProductSelectedAtDip";
  public static final String CASE_JOURNEY_DATA_BROKER_JOURNEY_VERSION = "brokerJourneyVersion";
  public static final String CASE_JOURNEY_DATA_EPC_RATING_A_OR_B_DIP = "epcRatingAOrBDip";
  public static final String CASE_JOURNEY_DATA_IS_PRODUCT_FEE_PAYMENT_SELECTED = "isProductFeePaymentSelected";
  public static final String PROPERTY_JOURNEY_DATA_NEW_BUILD = "newBuild";
  public static final String PROPERTY_JOURNEY_DATA_HOME_REPORT = "homeReport";
  public static final String PROPERTY_JOURNEY_DATA_STANDARD_MORTGAGE_VALUATION = "STANDARD_MORTGAGE_VALUATION";
  public static final String BRAND_NWI = "nwi";

  private ApplicationConstants() {
  }
}
