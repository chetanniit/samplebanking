package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class AdditionalDetails {
    private Integer shortestTerminMonths;

    private Integer maximumAllowableLoan;

    private BigDecimal loanToValue;

    private Integer excessIncome;

    private String podScoreBand;
}
