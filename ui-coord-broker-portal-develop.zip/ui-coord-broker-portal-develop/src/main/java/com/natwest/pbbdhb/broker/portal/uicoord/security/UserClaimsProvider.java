package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;

/**
 * Provides user claims contained in the request's user principal.
 */

public interface UserClaimsProvider {
  String getBrokerUsername();

  BrokerType getBrokerType();

  String getChannel();

  String getFcaNumber();
}
