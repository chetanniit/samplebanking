package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.AtLeastOneNotNullValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = AtLeastOneNotNullValidator.class)
public @interface ValidateAtLeastOneNotNull {

    String message() default "at least one of '${errorMessageFields}' must have a value";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String fields();
}
