package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.NotNull;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_NWI;

@Data
public class Deposit {
    @NotNull
    private Long depositAmount;

    public enum DepositType implements ValuedEnum {
        SALE_OF_EXISTING_PROPERTY,
        SAVINGS,
        LOANS,
        OTHER_SAVINGS,
        PARENTAL_CONTRIBUTION,
        GIFT,
        RBS_SAVINGS,
        NW_SAVINGS,
        INHERITANCE,
        INVESTMENTS;

        @Override
        public String value() {
            return name();
        }
    }

    @NotNull
    @ValidateEnum(enumClass = DepositType.class)
    private String depositType;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    @RequiredForBrand(value = {BRAND_NWI})
    private String originatingCurrency;

    private String depositDetails;
}
