package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.BasicAddress;
import com.natwest.pbbdhb.cases.dto.BasicAddressDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface BasicAddressMapper {

    @Mapping(target = "flatNameOrNumber", source = "flat")
    @Mapping(target = "country", source = "countryIsoCode")
    BasicAddress toBasicAddress(BasicAddressDto basicAddressDto);

    @Mapping(target = "flat", source = "flatNameOrNumber")
    @Mapping(target = "countryIsoCode", source = "country")
    @Mapping(target = "district", ignore = true)    // not used in the front-end for now
    BasicAddressDto toBasicAddressDto(BasicAddress basicAddress);
}
