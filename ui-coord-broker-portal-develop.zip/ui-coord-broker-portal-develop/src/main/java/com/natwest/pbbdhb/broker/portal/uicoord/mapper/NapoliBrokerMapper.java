package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Broker;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.PaymentPathDto;
import org.mapstruct.*;

import java.math.BigDecimal;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.BrokerClaimsUtil.getPaymentPathById;


@Mapper(builder = @Builder(disableBuilder = true))
public interface NapoliBrokerMapper {

  @Mapping(target = "paymentPath", source = "details.networkId")
  @Mapping(target = "fee", source = "details.fee.amount")
  @Mapping(target = "brokerFeeCharged", ignore = true)
  Broker toBroker(BrokerDto brokerDto);

  @Mapping(target = "details", ignore = true)
  @Mapping(target = "details.networkId", source = "paymentPath")
  @Mapping(target = "details.fee.amount", source = "fee")
  @Mapping(target = "details.fee.payableAt", source = "fee", qualifiedByName = "getFeePayableAt")
  @Mapping(target = "paymentPath", source = "paymentPath", qualifiedByName = "getSelectedPaymentPath")
  @Mapping(target = "fcaNumber", ignore = true)
  @Mapping(target = "firmName", ignore = true)
  @Mapping(target = "firmPostcode", ignore = true)
  @Mapping(target = "firmAddressLine1", ignore = true)
  @Mapping(target = "firmAddressLine2", ignore = true)
  @Mapping(target = "firmAddressLine3", ignore = true)
  @Mapping(target = "firmAddressLine4", ignore = true)
  @Mapping(target = "firmAddressLine5", ignore = true)
  @Mapping(target = "firmAddressCity", ignore = true)
  @Mapping(target = "firmAddressCounty", ignore = true)
  @Mapping(target = "firmAddressCountry", ignore = true)
  @Mapping(target = "brokerTitle", ignore = true)
  @Mapping(target = "brokerUsername", ignore = true)
  @Mapping(target = "brokerSurname", ignore = true)
  @Mapping(target = "brokerForename", ignore = true)
  @Mapping(target = "brokerPostcode", ignore = true)
  @Mapping(target = "brokerEmail", ignore = true)
  @Mapping(target = "brokerTelephoneNumber", ignore = true)
  @Mapping(target = "tppId", ignore = true)
  @Mapping(target = "brokerAdminEmail", ignore = true)
  BrokerDto toBrokerDto(Broker source, @Context BrokerInfo broker);

  @Named("getSelectedPaymentPath")
  default PaymentPathDto getSelectedPaymentPath(Integer paymentPathId, @Context BrokerInfo broker) {
    if (paymentPathId == null || broker == null) {
      return null;
    }

    PaymentPath selectedPaymentPath = getPaymentPathById(broker, paymentPathId);
    if (selectedPaymentPath == null) {
      return null;
    }

    return PaymentPathDto.builder()
            .name(selectedPaymentPath.getPaymentPathName())
            // NOTE: We might want to store payment path scale as well (needed for ESIS and Product Switch but not for FMA)
            .build();
  }

  @Named("getFeePayableAt")
  default String getFeePayableAt(BigDecimal fee) {
    if (fee == null) {
      return null;
    }

    return fee.compareTo(BigDecimal.ZERO) > 0 ? "COMPLETION" : null;
  }

  @Mapping(target = "details", ignore = true)
  @Mapping(target = "details.id", source = "broker.brokerId")
  @Mapping(target = "details.networkId", ignore = true)
  @Mapping(target = "details.fee.amount", ignore = true)
  @Mapping(target = "paymentPath", ignore = true)
  @Mapping(target = "fcaNumber", source = "broker.firmDetails.fcaNumber")
  @Mapping(target = "firmName", source = "broker.firmDetails.tradingName")
  @Mapping(target = "firmPostcode", source = "broker.firmDetails.address.postcode")
  @Mapping(target = "firmAddressLine1", source = "broker.firmDetails.address.line1")
  @Mapping(target = "firmAddressLine2", source = "broker.firmDetails.address.line2")
  @Mapping(target = "firmAddressLine3", source = "broker.firmDetails.address.line3")
  @Mapping(target = "firmAddressLine4", ignore = true)
  @Mapping(target = "firmAddressLine5", ignore = true)
  @Mapping(target = "firmAddressCity", source = "broker.firmDetails.address.city")
  @Mapping(target = "firmAddressCounty", source = "broker.firmDetails.address.county")
  @Mapping(target = "firmAddressCountry", source = "broker.firmDetails.address.country")
  @Mapping(target = "brokerTitle", source = "broker.brokerDetails.title")
  @Mapping(target = "brokerUsername", source = "broker.brokerDetails.userName")
  @Mapping(target = "brokerSurname", source = "broker.brokerDetails.lastName")
  @Mapping(target = "brokerForename", source = "broker.brokerDetails.firstName")
  @Mapping(target = "brokerPostcode", source = "broker.brokerDetails.postcode")
  @Mapping(target = "brokerEmail", source = "broker.brokerDetails.emailAddress")
  @Mapping(target = "brokerTelephoneNumber", source = "broker.brokerDetails.otherPhone",
          defaultExpression = "java(broker.getBrokerDetails() == null ? null : broker.getBrokerDetails().getMobilePhone())")
  @Mapping(target = "consentToDIP", ignore = true)
  @Mapping(target = "consentToFMA", ignore = true)
  @Mapping(target = "tppId", ignore = true)
  @Mapping(target = "brokerAdminEmail", ignore = true)
  BrokerDto updateBrokerDto(@MappingTarget BrokerDto target, BrokerInfo broker);

  @AfterMapping
  default void afterMappingToBrokerDto(@MappingTarget BrokerDto target,
                                       @Context BrokerInfo broker) {
    if (target == null) {
      return;
    }

    updateBrokerDto(target, broker);
  }
}
