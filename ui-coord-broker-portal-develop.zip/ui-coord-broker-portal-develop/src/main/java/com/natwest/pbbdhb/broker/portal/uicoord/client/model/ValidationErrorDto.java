package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidationErrorDto {

    private String object;
    private String field;
    private String message;

    public ValidationErrorDto(String message) {
        this(null, null, message);
    }
}
