package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class DipUnhandledValidationException extends RuntimeException {

  private final ErrorCode code;

  public DipUnhandledValidationException(ErrorCode code, String message) {
    super(message);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }
}


