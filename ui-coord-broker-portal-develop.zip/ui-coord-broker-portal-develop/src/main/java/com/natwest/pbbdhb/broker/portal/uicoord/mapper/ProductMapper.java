package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductDto;
import com.natwest.pbbdhb.broker.portal.uicoord.model.*;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.Optional.ofNullable;

import static com.natwest.pbbdhb.broker.portal.uicoord.mapper.EsisProductMapper.toEsisErcItem;

@Mapper
@Slf4j
public abstract class ProductMapper {

    @Autowired
    ErcItemMapper ercItemMapper;

    @Mapping(target = "greenMortgage", source = "range", qualifiedByName = "rangeToGreenMortgage")
    @Mapping(target = "sharedEquity", source = "range", qualifiedByName = "rangeToSharedEquity")
    @Mapping(target = "freeValuation", source = "standardValuationFee", qualifiedByName = "toFreeValuation")
    @Mapping(target = "ercItems", ignore = true)    // handled in the afterMapper
    public abstract Product toProduct(ProductDto productDto);

    @AfterMapping
    void afterMappingToProduct(ProductDto productDto, @MappingTarget Product product ) {
        if (product != null && productDto != null) {
            product.setErcItems(ofNullable(productDto.getEarlyRepaymentCharges()).orElse(emptyList())
                    .stream()
                    .map(ercItem -> ercItemMapper.toErcItem(toEsisErcItem(ercItem, productDto)))
                    .collect(Collectors.toList()));
        }
    }

    @Named("rangeToGreenMortgage")
    Boolean rangeToGreenMortgage(String value) {
        return value != null && value.toLowerCase().contains("green");
    }

    @Named("rangeToSharedEquity")
    Boolean rangeToSharedEquity(String value) {
        return value != null && value.toLowerCase().contains("shared equity");
    }

    @Named("toFreeValuation")
    Boolean freeValuation(BigDecimal value) {
        return value == null || BigDecimal.ZERO.equals(value);
    }
}
