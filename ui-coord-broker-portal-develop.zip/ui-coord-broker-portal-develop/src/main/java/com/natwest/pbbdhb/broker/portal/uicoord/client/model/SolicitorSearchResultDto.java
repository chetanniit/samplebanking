package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * Solicitor details returned from the Solicitor service
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SolicitorSearchResultDto {

    private Integer associateSequenceNumber;

    private String companyCode;

    private String companyName;

    private SolicitorAddressDto address;

    private String telephoneNumber;

    private String emailAddress;
}
