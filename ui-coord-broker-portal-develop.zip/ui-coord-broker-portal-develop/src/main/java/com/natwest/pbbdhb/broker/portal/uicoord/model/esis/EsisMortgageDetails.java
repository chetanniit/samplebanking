package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisCurrencyNotSterling;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisSpecialistScheme;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import java.math.BigDecimal;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@ValidEsisSpecialistScheme
@ValidEsisCurrencyNotSterling
public class EsisMortgageDetails {

    private Boolean firstTimeBuyer;

    @NotNull
    private Boolean specialistScheme;

    @ValidateEnum(enumClass = SchemeType.class)
    private String schemeType;

    @NotNull
    private Boolean currencyNotSterling;

    private String currency;

    private BigDecimal currencyExchangeRate;

    @NotNull
    @Valid
    private EsisRepaymentDetails repaymentDetails;

    public enum SchemeType implements ValuedEnum {
        SHARED_EQUITY, // PURCHASE only
        RIGHT_TO_BUY, // PURCHASE and REMORTGAGE
        HELP_TO_BUY_SHARED_EQUITY, // REMORTGAGE only
        OTHER; // PURCHASE and REMORTGAGE

        @Override
        public String value() {
            return name();
        }
    }

}
