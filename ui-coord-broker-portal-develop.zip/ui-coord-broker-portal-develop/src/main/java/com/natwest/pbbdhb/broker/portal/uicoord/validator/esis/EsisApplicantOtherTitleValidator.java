package com.natwest.pbbdhb.broker.portal.uicoord.validator.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisApplicantOtherTitle;
import org.apache.commons.lang3.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EsisApplicantOtherTitleValidator implements ConstraintValidator<ValidEsisApplicantOtherTitle, Object> {
    @Override
    public boolean isValid(Object target, ConstraintValidatorContext context) {
        EsisApplicant esisApplicant = (EsisApplicant) target;
        return !esisApplicant.getTitle().equals(Title.OTHER.value())
                || !StringUtils.isEmpty(esisApplicant.getOtherTitle());
    }
}
