package com.natwest.pbbdhb.broker.portal.uicoord.brand.request;

import com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;


public class BrandHttpRequestWrapper extends HttpServletRequestWrapper {
    public static final String USE_NWI = "X-Use-nwi";
    public BrandHttpRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    @Override
    public String getHeader(String name) {
        String header = super.getHeader(name);
        if (name.equalsIgnoreCase(ApplicationConstants.BRAND_HEADER) && null != super.getHeader(USE_NWI) && Boolean.valueOf(super.getHeader(USE_NWI))) {
            return "nwi";
        }
        return header;
    }

    @Override
    public Enumeration<String> getHeaders(String name) {
        if (name.equalsIgnoreCase(ApplicationConstants.BRAND_HEADER) && null != super.getHeader(USE_NWI) && Boolean.valueOf(super.getHeader(USE_NWI))) {
            Set<String> nwiBrand = new HashSet<String>();
            nwiBrand.add("nwi");
            return Collections.enumeration(nwiBrand);
        }
        return super.getHeaders(name);
    }

}
