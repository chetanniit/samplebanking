package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.NotNull;

@Data
public class ServiceLevel {

    @ValidateEnum(enumClass = Interview.class)
    private String interview;

    @ValidateEnum(enumClass = LevelOfService.class)
    private String levelOfService;

    public enum Interview implements ValuedEnum {
        FACE_TO_FACE,
        NONE;

        @Override
        public String value() { return name(); }
    }

    public enum LevelOfService implements ValuedEnum {
        ADVISED,
        ADVICE_REJECTED,
        NON_ADVISED,
        EXECUTION_ONLY;

        @Override
        public String value() { return name(); }
    }
}
