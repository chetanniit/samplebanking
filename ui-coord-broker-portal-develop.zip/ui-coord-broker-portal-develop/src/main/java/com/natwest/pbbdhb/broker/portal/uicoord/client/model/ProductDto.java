package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * Mortgage product details returned from the Product service
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDto {

    @JsonProperty("class")
    private String productClass;

    private String productCode;

    private String range;

    private String productSearchDate;

    private String productType;

    private String productTerm;

    private BigDecimal mortgageAmount;

    private Double initialInterestRate;

    private Double ltv;

    private Boolean erc;

    private BigDecimal productFee;

    private BigDecimal chapsFee;

    private BigDecimal cashBackValue;

    private BigDecimal initialMonthlyPayment;

    private BigDecimal productTermCost;

    private BigDecimal mortgageTermCost;

    private String mortgageTerm;

    private String mortgageType;

    private BigDecimal feeWrappedInitialMonthlyPayment;

    private BigDecimal feeWrappedProductTermCost;

    private BigDecimal feeWrappedMortgageTermCost;

    private BigDecimal standardValuationFee;

    private String valuationFeeMessage;

    private Double svr;

    private Double baseRate;

    private Integer sequence;

    private String productStartDate;

    private String productEndDate;

    private String productExpiryDate;

    private List<ProductFeeDto> fees;

    private String waysToApply;

    private Boolean freeLegal;

    private String productName;

    private String overPayment;

    private List<String> eligibility;

    private Double trackerMarginPercent;

    private Boolean switchToFixed;

    private String switchToFixedText;

    private List<EarlyRepaymentChargeDto> earlyRepaymentCharges;

    private Integer mortgageTermYears;

    private Integer mortgageTermMonths;

}
