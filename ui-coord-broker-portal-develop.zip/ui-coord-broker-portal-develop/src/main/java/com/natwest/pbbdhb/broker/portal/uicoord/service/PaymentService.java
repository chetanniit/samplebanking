package com.natwest.pbbdhb.broker.portal.uicoord.service;

import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentResponse;

public interface PaymentService {

    PaymentResponse fetchPaymentUrl(String brand, PaymentRequest paymentRequest);
}
