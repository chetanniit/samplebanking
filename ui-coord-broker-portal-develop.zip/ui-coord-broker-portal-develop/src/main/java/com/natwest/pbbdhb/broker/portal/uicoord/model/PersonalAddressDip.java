package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateAtLeastOneNotNull;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
@ValidateAtLeastOneNotNull(fields = "houseNumber,houseName,flatNameOrNumber")
public class PersonalAddressDip {

    @Size(max = 5)
    private String houseNumber;

    @Size(max = 22)
    private String houseName;

    @Size(max = 10)
    private String flatNameOrNumber;

    @NotBlank
    @Size(max = 30)
    private String street;

    @NotBlank
    @Size(max = 28)
    private String town;

    @Size(max = 18)
    private String county;

    @NotBlank
    @Size(max = 12)
    private String postcode;

    @NotBlank
    @Size(min = 2, max = 2)
    private String country;

    @ValidateEnum(enumClass = PersonalAddress.OccupyStatusType.class)
    private String occupyStatus;

    @NotNull
    @Min(value = 1)
    @Max(value = 12)
    private Integer startMonth;

    @NotNull
    @Min(value = 1900)
    @Max(value = 2100)
    private Integer startYear;

}
