package com.natwest.pbbdhb.broker.portal.uicoord.validator;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.MaxTerm;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import static org.apache.tomcat.util.IntrospectionUtils.getProperty;

public class MaxTermValidator implements ConstraintValidator<MaxTerm, Object> {

    private String yearField;
    private int yearValue;
    private String monthField;
    private int monthMaxValue;

    @Override
    public void initialize(MaxTerm maxTerm) {
        yearField = maxTerm.yearField();
        yearValue = maxTerm.yearValue();
        monthField = maxTerm.monthField();
        monthMaxValue = maxTerm.monthMaxValue();
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        if (objectToValidate == null) {
            return true;
        }
        Object actualYearValue = getProperty(objectToValidate, yearField);
        Object actualMonthValue = getProperty(objectToValidate, monthField);
        if (!(actualYearValue instanceof Integer && actualMonthValue instanceof Integer)) {
            return true;
        }

        return yearValue != (Integer) actualYearValue || monthMaxValue >= (Integer) actualMonthValue;
    }
}
