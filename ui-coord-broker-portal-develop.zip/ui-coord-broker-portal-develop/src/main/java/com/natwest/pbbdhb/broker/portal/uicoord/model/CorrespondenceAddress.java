package com.natwest.pbbdhb.broker.portal.uicoord.model;

import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CorrespondenceAddress {

  @Size(max = 10)
  private  String flat;

  @Size(max = 22)
  private  String houseName;

  @Size(max = 5)
  private  String houseNumber;

  @Size(max = 30)
  private String street;

  @Size(max = 30)
  private String district;

  @Size(max = 28)
  private String town;

  @Size(max = 18)
  private String county;

  @Size(max = 12)
  private String postcode;

  @Size(max = 2)
  private String countryIsoCode;

}
