package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import lombok.Builder;
import lombok.Data;

import jakarta.validation.constraints.NotNull;

@Data
@Builder
public class EsisResponse {

    @NotNull
    private String caseId;

    private String documentName;

    private String documentDescription;

}
