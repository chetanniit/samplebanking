package com.natwest.pbbdhb.broker.portal.uicoord.validator.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisCaseDetails.LoanPurpose;
import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisData;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisFirstTimeBuyer;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EsisFirstTimeBuyerValidator implements ConstraintValidator<ValidEsisFirstTimeBuyer, Object> {
    @Override
    public boolean isValid(Object target, ConstraintValidatorContext context) {
        EsisData esisData = (EsisData) target;
        return !esisData.getCaseDetails().getLoanPurpose().equals(LoanPurpose.PURCHASE.value())
                || esisData.getMortgageDetails().getFirstTimeBuyer() != null;
    }
}
