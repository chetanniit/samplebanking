package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
public class RepaymentDetail {

    @ValidateEnum(enumClass = RepaymentStrategyType.class)
    private String repaymentStrategyType;

    @ValidateEnum(enumClass = OriginatingCurrency.class)
    private String originatingCurrency;

    @NotNull
    @Min(value = 0)
    @Max(value = 99_999_999)
    private Long repaymentValue;

    // TODO @NotNull for FMA
    @DateFormat(pattern = "yyyy-MM-dd", constraint = DateFormat.DateConstraint.FUTURE, message = "must be a date in the future in format 'yyyy-MM-dd'")
    private String repaymentMaturityDate;

    // TODO @NotNull for FMA
    @Size(max = 50)
    private String repaymentProvider;

    // TODO @NotNull for FMA
    @Size(max = 40)
    private String repaymentReference;

    @Min(value = 0)
    @Max(value = 99_999_999)
    private Long repaymentMonthlyPayment;

    public enum RepaymentStrategyType implements ValuedEnum {
        MAIN_RESIDENCE,
        NOT_MAIN_RESIDENCE,
        OTHER_MORTGAGE_PROPERTY,
        UNENCUMBERED_MAIN_RESIDENCE,
        UNENCUMBERED_OTHER_TERRACED,
        SALE_OF_PROPERTY,
        STOCK_SHARES,
        UNIT_TRUSTS,
        OEIC,
        ICVC,
        PENSION,
        SAVING,
        OTHER_ASSETS,
        ENDOWMENT;

        @Override
        public String value() {
            return name();
        }
    }
}
