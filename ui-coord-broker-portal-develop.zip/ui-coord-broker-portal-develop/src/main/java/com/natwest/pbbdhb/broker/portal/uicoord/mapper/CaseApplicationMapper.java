package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.CaseJourneyDataDto;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.MortgageSchemeMappingHelper.CapieMortgageScheme;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Broker;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Mortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.BrokerInfo;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.DataUtils.toDataObject;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

@Component
public class CaseApplicationMapper {

    @Autowired
    private CaseApplicationAutoMapper autoMapper;

    public CaseApplication toCaseApplication(CaseApplicationDto caseApplicationDto) {
        if (isNull(caseApplicationDto)) {
            return null;
        }

        String mortgageSchemeType = MortgageSchemeMappingHelper.getSchemeType(caseApplicationDto);
        CaseApplication caseApplication = autoMapper.toCaseApplication(mortgageSchemeType, caseApplicationDto);

        if (nonNull(caseApplication)) {
            Mortgage mortgage = caseApplication.getMortgage();
            CaseJourneyDataDto journeyDataDto = toDataObject(caseApplicationDto.getJourneyData(), CaseJourneyDataDto.class);
            if (nonNull(mortgage) && nonNull(journeyDataDto)) {
                mortgage.setAdditionalBorrowing(journeyDataDto.getAdditionalBorrowing());
            }
        }

        return caseApplication;
    }

    public CaseApplicationDto toCaseApplicationDto(String caseId, CaseApplication caseApplication, BrokerInfo broker) {
        if (isNull(caseApplication)) {
            return null;
        }

        if (caseApplication.getBroker() == null) {
            caseApplication.setBroker(new Broker());
        }

        String buyerType = BuyerTypeMappingHelper.getBuyerType(caseApplication);
        CapieMortgageScheme capieMortgageScheme = MortgageSchemeMappingHelper.getCapieMortgageScheme(caseApplication);
        CaseApplicationDto caseApplicationDto = autoMapper.toCaseApplicationDto(caseId, buyerType, capieMortgageScheme, caseApplication, broker);
        if (isNull(caseApplicationDto)) {
            return null;
        }
        MortgageDto mortgageDto = caseApplicationDto.getMortgage();

        if (nonNull(capieMortgageScheme)) {
            Boolean rightToBuy = capieMortgageScheme.getRightToBuy();
            if (nonNull(mortgageDto)) {
                mortgageDto.setRightToBuy(rightToBuy);
            } else if (nonNull(rightToBuy) && rightToBuy) {
                mortgageDto = new MortgageDto();
                caseApplicationDto.setMortgage(mortgageDto);
                mortgageDto.setRightToBuy(true);
            }
        }

        Mortgage mortgage = caseApplication.getMortgage();

        if (nonNull(mortgage)) {
            if (isNull(caseApplicationDto.getJourneyData())) {
                Map<String, Object>  journeyData = new HashMap<>();
                caseApplicationDto.setJourneyData(journeyData);
            }
            caseApplicationDto.getJourneyData().put("additionalBorrowing", mortgage.getAdditionalBorrowing());
        }

        return caseApplicationDto;
    }

}
