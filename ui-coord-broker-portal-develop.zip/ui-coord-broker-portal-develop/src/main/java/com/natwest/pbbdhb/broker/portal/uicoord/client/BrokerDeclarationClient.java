package com.natwest.pbbdhb.broker.portal.uicoord.client;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;
import static java.util.Optional.ofNullable;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.BrokerDeclarationRequestDto;
import java.net.URI;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Slf4j
public class BrokerDeclarationClient {

    public static final String GET_DECLARATION = "get-declaration";
    private final String brokerDeclarationEndpoint;
    private final RestTemplate restTemplate;

    public BrokerDeclarationClient(
            @Value("${broker.declaration.url}") String brokerDeclarationEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate) {
        this.brokerDeclarationEndpoint = brokerDeclarationEndpoint;
        this.restTemplate = restTemplate;
    }

    public String getDeclaration(String brand, BrokerDeclarationRequestDto brokerDeclarationRequestDto) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(brokerDeclarationEndpoint);
        builder.pathSegment(GET_DECLARATION);
        URI uri = builder.build().toUri();
        log.info("Calling {} to get broker declaration for broker with brokerUsername {} and FCA number {}",
            uri, brokerDeclarationRequestDto.getBroker().getBrokerUsername(), brokerDeclarationRequestDto.getBroker().getFcaNumber());
        HttpEntity<BrokerDeclarationRequestDto> entity = new HttpEntity<>(brokerDeclarationRequestDto, constructHeadersForJsonRequest(brand));

        try {
          ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST, entity,
              String.class);

          log.debug(
              "Declaration for broker with brokerUsername {} and FCA number {} successfully retrieved",
              brokerDeclarationRequestDto.getBroker().getBrokerUsername(),
              brokerDeclarationRequestDto.getBroker().getFcaNumber()
          );
          return ofNullable(response).map(HttpEntity::getBody).orElse(null);
        } catch (RestClientException ex) {
          log.warn("A rest client exception occurred while calling {} to get broker declaration for broker with brokerUsername {} and FCA number {}: {}",
              uri, brokerDeclarationRequestDto.getBroker().getBrokerUsername(), brokerDeclarationRequestDto.getBroker().getFcaNumber(), ex.getMessage());
              throw ex;
        } catch (Throwable t) {
          log.warn("An unexpected exception occurred while calling {} to get broker declaration for broker with brokerUsername {} and FCA number {}: {}",
              uri, brokerDeclarationRequestDto.getBroker().getBrokerUsername(), brokerDeclarationRequestDto.getBroker().getFcaNumber(), t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
              throw t;
        }
    }
}
