package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
public class Solicitor {

    private Integer associateSequenceNumber;

    private String companyCode;

    @NotBlank
    @Size(min = 3, max = 45)
    private String companyName;

    @NotNull
    @Valid
    private SolicitorAddress address;

    @NotBlank
    @Pattern(regexp = "^[0-9]{3,15}$", flags=Pattern.Flag.CASE_INSENSITIVE, message = "Badly formed phone number")
    private String telephoneNumber;

    @Size(max = 72)
    private String emailAddress;
}