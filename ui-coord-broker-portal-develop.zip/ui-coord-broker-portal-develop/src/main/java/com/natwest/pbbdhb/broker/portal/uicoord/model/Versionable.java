package com.natwest.pbbdhb.broker.portal.uicoord.model;

public interface Versionable {

    String getId();

    String getVersion();
}
