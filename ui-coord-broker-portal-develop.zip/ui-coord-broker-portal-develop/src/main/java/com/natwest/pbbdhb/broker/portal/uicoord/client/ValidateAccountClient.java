package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CLIENT_ID_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class ValidateAccountClient {
    private final String VALIDATE_ACCOUNT_ERROR = "validate account error";

    private final String directDebitValidateServiceEndpoint;
    private final RestTemplate restTemplate;

    @Value("${client.id}")
    private String clientId;

    public ValidateAccountClient(
            @Value("${msvc.direct.debit.validate.url}") String directDebitValidateServiceEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.directDebitValidateServiceEndpoint = directDebitValidateServiceEndpoint;
        this.restTemplate = restTemplate;
    }

    public ValidateAccountResult validateAccount(String brand, ValidateAccountRequestDto bankDetails) {
        log.info("Calling {} to check bank details", directDebitValidateServiceEndpoint);

        HttpHeaders headers = constructHeadersForJsonRequest(brand);
        headers.add(CLIENT_ID_HEADER, clientId);

        try {
            ValidateAccountResult results = restTemplate.exchange(
                directDebitValidateServiceEndpoint,
                HttpMethod.POST,
                new HttpEntity<>(bankDetails, headers),
                ValidateAccountResult.class
            ).getBody();

            if (results == null) {
              log.warn("Null response body received from {} while checking bank details - throwing InternalServerError Exception",
                  directDebitValidateServiceEndpoint);
              throw HttpServerErrorException.create(
                  HttpStatus.INTERNAL_SERVER_ERROR,
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                  new HttpHeaders(),
                  (VALIDATE_ACCOUNT_ERROR + ": missing response body")
                      .getBytes(StandardCharsets.UTF_8),
                  StandardCharsets.UTF_8);
            }

            List<String> errors = results.getErrors();
            if (errors != null && errors.size() > 0) {
                log.warn("Error response received from {} while checking bank details: {} - throwing InternalServerError Exception",
                    directDebitValidateServiceEndpoint, errors);
                throw HttpServerErrorException.create(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    new HttpHeaders(),
                    (VALIDATE_ACCOUNT_ERROR + ": " + String.join("; ", errors))
                        .getBytes(StandardCharsets.UTF_8),
                    StandardCharsets.UTF_8);
            }

            log.debug("Bank details successfully checked: isValid={}", results.isValid());
            return results;

        } catch (RestClientException ex) {
            log.warn(
                "A rest client exception occurred while calling {} to check bank details: {}",
                directDebitValidateServiceEndpoint, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn(
                "An unexpected exception occurred while calling {} to check bank details: {}",
                directDebitValidateServiceEndpoint, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
