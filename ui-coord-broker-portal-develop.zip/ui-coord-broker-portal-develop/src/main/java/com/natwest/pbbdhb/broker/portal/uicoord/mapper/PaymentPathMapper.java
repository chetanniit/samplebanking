package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.PaymentPath;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface PaymentPathMapper {

  @Mapping(target="paymentPathId", source="paymentPathId")
  @Mapping(target="paymentPathName", source="paymentPathName")
  PaymentPath toPaymentPath(com.natwest.pbbdhb.broker.portal.uicoord.model.broker.info.PaymentPath paymentPath);
}
