package com.natwest.pbbdhb.broker.portal.uicoord.model.security;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

import java.security.PrivateKey;
import java.security.PublicKey;

@Builder
@Value
public class CertificateModel {

  @NonNull
  PublicKey publicKey;

  @NonNull
  PrivateKey privateKey;

  @NonNull
  String certificateThumbPrint;

}
