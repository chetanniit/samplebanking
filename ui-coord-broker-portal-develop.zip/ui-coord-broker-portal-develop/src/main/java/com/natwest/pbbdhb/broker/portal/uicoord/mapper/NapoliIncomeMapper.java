package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import static java.util.Optional.ofNullable;

import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.model.IncomeApplicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.JobDetails;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.request.IncomeApplicantRequestDto;
import com.natwest.pbbdhb.income.expense.model.income.request.IncomeApplicantRequestDto.IncomeApplicantRequestDtoBuilder;
import com.natwest.pbbdhb.income.expense.model.income.response.IncomeApplicantDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

@Mapper(uses = {JobDetailsMapper.class,
    OtherIncomeDetailsMapper.class}, unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface NapoliIncomeMapper {

  CaseIncome toIncome(ValidatedCaseIncomeDto incomeDto);

  @Mapping(target = "stage", constant = "DIP")
  @Mapping(target = "mimoPayslipGroups", ignore = true)
  CaseIncomeDto toIncomeDto(CaseIncome income);

  @BeforeMapping
  default void mergePreviousJobDetails(IncomeApplicant source,
      @MappingTarget IncomeApplicantRequestDtoBuilder target) {
    if (source.getPreviousJobDetails() != null && !source.getPreviousJobDetails().isEmpty()) {
      List<JobDetails> additionalJobDetails = source.getAdditionalJobDetails();
      additionalJobDetails.addAll(source.getPreviousJobDetails());
      source.setAdditionalJobDetails(additionalJobDetails);
      source.setPreviousJobDetails(Collections.emptyList());
    }
  }

  @Mapping(target = "cin", ignore = true)
  @Mapping(target = "excludedIncomeReason", ignore = true)
  @Mapping(target = "sourceOfIncomeVerification", ignore = true)
  @Mapping(target = "breakInEmploymentInLastSixMonths", ignore = true)
  @Mapping(target = "sickPay", ignore = true)
  @Mapping(target = "sickPayImpact", ignore = true)
  @Mapping(target = "sickPayImpactExplanation", ignore = true)
  @Mapping(target = "jobIncomeTotals", ignore = true)
  @Mapping(target = "otherIncomeTotals", ignore = true)
  @Mapping(target = "parentalLeave", ignore = true)
  IncomeApplicantRequestDto toIncomeApplicantDto(IncomeApplicant applicant);

  @Mapping(target = "updatedDatetime", ignore = true)
  @Mapping(target = "status", ignore = true)
  @Mapping(target = "validationErrors", ignore = true)
  @Mapping(target = "exceptionReferences", ignore = true)
  @Mapping(target = "mimoPayslipGroups", ignore = true)
  ValidatedCaseIncomeDto caseIncomeToValidatedCaseIncomeDto(CaseIncomeDto caseIncomeDto);

  @Mapping(target = "jobIncomeTotals", ignore = true)
  @Mapping(target = "otherIncomeTotals", ignore = true)
  IncomeApplicantDto toIncomeApplicantDto(IncomeApplicantRequestDto incomeApplicantRequestDto);


  IncomeApplicant incomeApplicantDtoToIncomeApplicant(IncomeApplicantDto incomeApplicantDto);

  @AfterMapping
  default void filterPreviousJobDetails(IncomeApplicantDto source,
      @MappingTarget IncomeApplicant target) {
    List<JobDetails> previousJobDetails = ofNullable(target.getAdditionalJobDetails())
        .orElse(Collections.emptyList())
        .stream()
        .filter(Objects::nonNull)
        .filter(jobDetails -> StringUtils.isNotBlank(jobDetails.getEmploymentEndDate())).collect(
            Collectors.toList());
    if (!previousJobDetails.isEmpty()) {
      List<JobDetails> additionalJobDetails = target.getAdditionalJobDetails();
      additionalJobDetails.removeAll(previousJobDetails);
      target.setAdditionalJobDetails(additionalJobDetails);
      target.setPreviousJobDetails(previousJobDetails);
    }
  }
}
