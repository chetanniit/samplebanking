package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class ExpenseClient {

    private final String getExpenseEndpoint;
    private final String saveExpenseEndpoint;
    private final RestTemplate restTemplate;

    public ExpenseClient(
            @Value("${msvc.expense.get.url}") String getExpenseEndpoint,
            @Value("${msvc.expense.save.url}") String saveExpenseEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.getExpenseEndpoint = getExpenseEndpoint;
        this.saveExpenseEndpoint = saveExpenseEndpoint;
        this.restTemplate = restTemplate;
    }

    public ValidatedCaseExpenseDto saveExpense(String brand, String caseId, CaseExpenseDto expense) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(saveExpenseEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);
        Integer version = expense.getVersion();
        URI url = builder.build().toUri();
        log.info("Calling {} to save expense with version {} and caseId {}", url, version, caseId);

        try {
              ValidatedCaseExpenseDto validatedCaseExpenseDto = restTemplate.exchange(
                      url,
                      HttpMethod.PUT,
                      new HttpEntity<>(expense, constructHeadersForJsonRequest(brand)),
                      ValidatedCaseExpenseDto.class).getBody();
              if(validatedCaseExpenseDto == null){
                log.warn("Null response body received from {} while saving expense with version {} and caseId {}", url, version, caseId);
              } else {
                log.debug("Expense with version {} and caseId {} successfully saved",
                    validatedCaseExpenseDto.getVersion(), caseId);
              }
              return validatedCaseExpenseDto;

        } catch (RestClientException ex) {
              log.warn("A rest client exception occurred while calling {} to save expense for caseId {}: {}",
                  url, caseId, ex.getMessage());
              throw ex;
        } catch (Throwable t) {
              log.warn("An unexpected exception occurred while calling {} to save expense for caseId {}: {}",
                  url, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
              throw t;
        }
    }

    public ValidatedCaseExpenseDto getExpense(String brand, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(getExpenseEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);

        URI url = builder.build().toUri();
        log.info("Calling {} to get expense for caseId {}", url, caseId);

        try {
            ValidatedCaseExpenseDto validatedCaseExpenseDto = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    new HttpEntity<>(constructHeadersForJsonRequest(brand)),
                    ValidatedCaseExpenseDto.class).getBody();
            log.debug("Expense for caseId {} successfully retrieved", caseId);
            return validatedCaseExpenseDto;

        } catch (HttpClientErrorException.NotFound ex) {
            log.warn("Expense not found for caseId {}: returning null - {}", caseId, ex.getMessage());
            return null;
        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to get expense for caseId {}: {}",
                url, caseId, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to get expense for caseId {}: {}",
                url, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
