package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.OriginatingCurrency;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.PropertyType;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.ValuedEnum;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.RequiredForBrand;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_NWI;

@Data
public class OtherProperty {

  private String id;

  @Valid
  private BasicAddress address;

  @NotNull
  @DateFormat(pattern = "yyyy-MM-dd")
  private String datePurchased;

  @NotNull
  @Min(1)
  @Max(99_999_999)
  private Integer estimatedPropertyValue;

  @Min(1)
  @Max(99_999_999)
  private Integer interestOnlyAmount;

  @Size(min = 1, max = 30)
  private String lenderName;

  @Min(1)
  @Max(99_999_999)
  private Integer monthlyRentalIncome;

  @Min(1)
  @Max(99_999_999)
  private Integer monthlyNetRentalIncome;

  @Min(1)
  @Max(99_999_999)
  private Integer monthlyMortgagePayment;

  @ValidateEnum(enumClass = RepaymentType.class)
  private String mortgageRepaymentType;

  @Min(1)
  @Max(99)
  private Integer numberBedrooms;

  @Min(1)
  @Max(99_999_999)
  private Integer outstandingMortgageBalance;

  @NotNull
  @ValidateEnum(enumClass = Ownership.class)
  private String ownership;

  @NotNull
  @ValidateEnum(enumClass = OwnershipType.class)
  private String ownershipType;

  private Boolean propertyRedemption;

  @Size(min = 1, max = 50)
  private String propertyNotes;

  @ValidateEnum(enumClass = PropertyType.class)
  private String propertyType;

  @NotNull
  @Min(1)
  @Max(99_999_999)
  private Integer purchasePrice;

  @NotNull
  @ValidateEnum(enumClass = PropertyUsage.class)
  private String propertyUsage;

  @Min(0)
  @Max(11)
  private Integer remainingMortgageTermMonths;

  @Min(0)
  @Max(99)
  private Integer remainingMortgageTermYears;

  private Boolean useLettingAgent;

  private Boolean familyLiveInProperty;

  private Boolean hasPropertyRunningCosts;

  @ValidateEnum(enumClass = OriginatingCurrency.class)
  @RequiredForBrand(value = {BRAND_NWI})
  private String originatingCurrency;

  public enum RepaymentType implements ValuedEnum {
    REPAYMENT,
    INTEREST_ONLY,
    MIXED;

    @Override
    public String value() {
      return name();
    }
  }

  public enum Ownership implements ValuedEnum {
    APPLICANT_ONE,
    APPLICANT_TWO,
    JOINT;

    @Override
    public String value() {
      return name();
    }
  }

  public enum OwnershipType implements ValuedEnum {
    HELD_RBSG,
    HELD_ELSEWHERE,
    UNENCUMBERED;

    @Override
    public String value() {
      return name();
    }
  }

  public enum PropertyUsage implements ValuedEnum {
    RESIDENTIAL,
    BUY_TO_LET,
    CONSENT_TO_LET;

    @Override
    public String value() {
      return name();
    }
  }
}
