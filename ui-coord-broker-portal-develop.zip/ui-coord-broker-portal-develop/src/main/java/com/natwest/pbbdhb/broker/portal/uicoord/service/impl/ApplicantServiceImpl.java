package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.ApplicantClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.NapoliApplicantMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ExistingMortgage;
import com.natwest.pbbdhb.broker.portal.uicoord.model.PersonalAddress;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ApplicantService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicantServiceImpl implements ApplicantService {

    private final ApplicantClientNapoli applicantClient;
    private final NapoliApplicantMapper napoliApplicantMapper;
    private final UserClaimsProvider userClaimsProvider;

    @Override
    public List<Applicant> getApplicants(String brand, String caseId) {
        log.debug("Calling applicantClient to get applicants for caseId {}", caseId);
        List<ApplicantDto> applicantDtoList = this.applicantClient.getApplicants(brand, caseId);
        List<Applicant> applicantList = applicantDtoList
                .stream()
                .map(this.napoliApplicantMapper::toApplicant)
                .collect(Collectors.toList());
        log.debug("applicantClient successfully called to get applicants for caseId {}", caseId);
        logExistingMortgages("getApplicants", caseId, applicantList);
        return applicantList;
    }

    @Override
    public List<Applicant> saveApplicants(final String brand, final String caseId, final List<Applicant> applicants, final Map<String, String> workStatusMap) {
        log.debug("Calling applicantClient to save applicants for caseId {}", caseId);

      logExistingMortgages("saveApplicants", caseId, applicants);

      List<Applicant> applicantList = applicants.stream()
              .map(applicant -> this.napoliApplicantMapper
                      .toApplicant(this.applicantClient
                              .saveApplicant(brand, this.napoliApplicantMapper
                                      .toApplicantDto(caseId, workStatusMap.get(applicant.getApplicantId()), applicant))))
              .collect(Collectors.toList());

        log.debug("applicantClient successfully called to save applicants for caseId {}", caseId);
        logExistingMortgages("savedApplicants", caseId, applicantList);
        return applicantList;
        // TODO: ?? Delete applicants that have been removed from the list.
    }

    private void logExistingMortgages(String phase, String caseId, List<Applicant> applicants) {
      applicants.forEach(applicant -> {
            Optional<List<ExistingMortgage>> existingMortgages = Optional.ofNullable(
                applicant.getExistingMortgages());
            List<PersonalAddress> addresses = Optional.ofNullable(applicant.getAddresses()).orElse(
                Collections.emptyList());
            log.info(
                "{} - existingMortgages for caseId {}, brokerUsername {}, applicantId {}, and occupyStatus {}: is present {} and has size {}",
                phase, caseId, userClaimsProvider.getBrokerUsername(), applicant.getApplicantId(),
                addresses.isEmpty() || addresses.get(0) == null ? null
                    : addresses.get(0).getOccupyStatus(),
                existingMortgages.isPresent(),
                existingMortgages.orElse(Collections.emptyList()).size());
      });
  }
}
