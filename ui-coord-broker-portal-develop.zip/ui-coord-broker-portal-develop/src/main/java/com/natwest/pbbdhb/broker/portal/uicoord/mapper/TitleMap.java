package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.Title;

import java.util.HashMap;
import java.util.Map;

public final class TitleMap {
    private TitleMap() {
    }

    private static Map<String, String> translations = buildTranslationMap();
    private static Map<String, String> tokens = buildTokenMap();

    private static Map<String, String> buildTranslationMap() {
        Map<String, String> translationMap = new HashMap<>();
        for (Title title : Title.class.getEnumConstants()) {
            translationMap.put(title.name(), title.value());
        }
        return translationMap;
    }

    private static Map<String, String> buildTokenMap() {
        Map<String, String> translationMap = new HashMap<>();
        for (Title title : Title.class.getEnumConstants()) {
            translationMap.put(title.value(), title.name());
        }
        return translationMap;
    }

    public static String translate(String token) {
        return translations.get(token);
    }

    public static String tokenize(String translation) {
        return tokens.get(translation);
    }
}
