package com.natwest.pbbdhb.broker.portal.uicoord.model.esis;

import lombok.Data;

import jakarta.validation.constraints.NotNull;

@Data
public class EsisDocumentDescription {

    @NotNull
    private String documentDescription;

}
