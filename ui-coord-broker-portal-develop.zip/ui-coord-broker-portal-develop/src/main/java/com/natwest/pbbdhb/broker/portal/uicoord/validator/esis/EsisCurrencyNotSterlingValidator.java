package com.natwest.pbbdhb.broker.portal.uicoord.validator.esis;

import com.natwest.pbbdhb.broker.portal.uicoord.model.esis.EsisMortgageDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidEsisCurrencyNotSterling;
import org.apache.commons.lang3.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

public class EsisCurrencyNotSterlingValidator implements ConstraintValidator<ValidEsisCurrencyNotSterling, Object> {
    @Override
    public boolean isValid(Object target, ConstraintValidatorContext context) {
        EsisMortgageDetails esisMortgageDetails = (EsisMortgageDetails) target;
        return !esisMortgageDetails.getCurrencyNotSterling()
                || (!StringUtils.isEmpty(esisMortgageDetails.getCurrency())
                && !(esisMortgageDetails.getCurrencyExchangeRate()==null || esisMortgageDetails.getCurrencyExchangeRate().equals(BigDecimal.ZERO)));
    }
}
