package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class DipIntegrationException extends Exception {
    public DipIntegrationException(String message) {
        super(message);
    }

    public DipIntegrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
