package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum Ownership implements ValuedEnum{
    JOINT,
    SINGLE;

    @Override
    public String value() {
        return name();
    }
}