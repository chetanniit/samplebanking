package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.Map;

@Data
public class IncomeApplicantDip {

    @NotNull
    private String applicantId;

    @Valid
    private JobDetailsDip primaryJob;

    @Size(max = 9)
    private List<@Valid JobDetailsDip> additionalJobDetails;

    @Size(max = 25, min = 1)
    private Map<String, @Valid OtherIncomeDetails> otherIncome;
}
