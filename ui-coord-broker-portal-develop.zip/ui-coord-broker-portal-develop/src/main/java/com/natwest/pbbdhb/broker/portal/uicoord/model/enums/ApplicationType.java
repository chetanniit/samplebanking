package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum ApplicationType implements ValuedEnum{

    RESIDENTIAL,
    BUY_TO_LET;

    @Override
    public String value() {
        return name();
    }
}
