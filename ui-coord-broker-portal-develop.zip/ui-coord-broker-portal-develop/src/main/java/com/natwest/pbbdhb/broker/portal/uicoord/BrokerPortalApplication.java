package com.natwest.pbbdhb.broker.portal.uicoord;

import com.natwest.pbbdhb.DIPAndFMAIntegrationLibrary;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

/**
 * The main Spring Boot class for this application
 */
@SpringBootApplication
@Import(DIPAndFMAIntegrationLibrary.class)
@ComponentScan(basePackages = "com.natwest.pbbdhb.broker.portal")
@OpenAPIDefinition(
        info = @Info(
                title = "UI Coord Broker Portal Service",
                version = "v1",
                description = "UI Coord Broker Portal API"
        )
)
public class BrokerPortalApplication {

    public static void main(String[] args) {
      SpringApplication.run(BrokerPortalApplication.class, args);
    }
}
