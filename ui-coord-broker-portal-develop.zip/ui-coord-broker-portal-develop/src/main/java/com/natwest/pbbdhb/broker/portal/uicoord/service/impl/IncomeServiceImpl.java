package com.natwest.pbbdhb.broker.portal.uicoord.service.impl;

import com.natwest.pbbdhb.broker.portal.uicoord.client.IncomeClient;
import com.natwest.pbbdhb.broker.portal.uicoord.mapper.NapoliIncomeMapper;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseIncome;
import com.natwest.pbbdhb.broker.portal.uicoord.service.IncomeService;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class IncomeServiceImpl implements IncomeService {

    private final IncomeClient incomeClient;
    private final NapoliIncomeMapper napoliIncomeMapper;

    @Override
    public CaseIncome saveIncome(String brand, String caseId, CaseIncome income) {
        CaseIncomeDto incomeDtoToSend = this.napoliIncomeMapper.toIncomeDto(income);
        String version = income.getVersion();
        log.debug("Calling incomeClient to save income with version {} for caseId {}", version, caseId);
        ValidatedCaseIncomeDto incomeDtoResponse = this.incomeClient.saveIncome(brand, caseId, incomeDtoToSend);
        log.debug("incomeClient successfully called to save income with version {} for caseId {}", version, caseId);
        return this.napoliIncomeMapper.toIncome(incomeDtoResponse);
    }

    @Override
    public CaseIncome getIncome(String brand, String caseId) {
        log.debug("Calling incomeClient to get income for caseId {}", caseId);
        ValidatedCaseIncomeDto incomeDto = this.incomeClient.getIncome(brand, caseId);
        log.debug("incomeClient successfully called to get income for caseId {}", caseId);
        return this.napoliIncomeMapper.toIncome(incomeDto);
    }
}
