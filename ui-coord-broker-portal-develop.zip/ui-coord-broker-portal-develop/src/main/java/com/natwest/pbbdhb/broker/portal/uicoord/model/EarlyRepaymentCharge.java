package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

@Data
public class EarlyRepaymentCharge {
    private String term;
    private Integer year;
    private Double charge;
}
