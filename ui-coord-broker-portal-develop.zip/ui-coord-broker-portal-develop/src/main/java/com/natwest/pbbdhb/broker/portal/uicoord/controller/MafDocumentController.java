package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.MafDocumentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.constraints.Pattern;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.*;

@RestController
@Tag(name = "MAF", description = "Maf API for retrieval of MAF documents")
@Validated
@Slf4j
@RequiredArgsConstructor
public class MafDocumentController {

    private final MafDocumentService mafDocumentService;
    private final UserClaimsProvider userClaimsProvider;

    @Operation(
            operationId = "getMafDocumentWithDocName",
            summary = "Get MAF document for a given PDF name",
            tags = "MAF")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful retrieval of MAF Document", content = @Content(mediaType = MediaType.APPLICATION_PDF_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "404", description = "Document not found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(
            value = PATH_GET_MAF_DOC_FROM_NAME,
            produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> getMafDocument(
            @Parameter(name = MAF_DOC_NAME_PARAM, description = MAF_DOC_NAME_DESCRIPTION, required = true)
            @PathVariable final String documentName,
            @Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
            @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
            @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand) {

        String username = userClaimsProvider.getBrokerUsername();
        log.info("Request to get MAF document with mafDocumentName {} and brokerUsername {}", documentName, username);
        InputStreamResource mafDocument = mafDocumentService.getMafDocument(documentName, brand);
        log.info("MAF document with mafDocumentName {} and brokerUsername {} successfully retrieved", documentName, username);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(mafDocument);
    }
}
