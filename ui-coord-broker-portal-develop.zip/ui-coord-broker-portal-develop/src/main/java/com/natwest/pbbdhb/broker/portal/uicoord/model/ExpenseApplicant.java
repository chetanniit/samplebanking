package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.Map;

@Data
public class ExpenseApplicant {

    @NotNull
    private String applicantId;

    private Map<String, @Valid ExpenseTransaction> transactions;
}
