package com.natwest.pbbdhb.broker.portal.uicoord.exception;

import lombok.Getter;

@Getter
public class UpdateNotPermittedException extends RuntimeException {
  private static final String DEFAULT_DESCRIPTION = "Update not permitted";
  final String description;

  public UpdateNotPermittedException() {
    this(DEFAULT_DESCRIPTION);
  }

  public UpdateNotPermittedException(String description) {
    super(description);
    this.description = description;
  }

  public UpdateNotPermittedException(Throwable cause) {
    this(DEFAULT_DESCRIPTION, cause);
  }

  public UpdateNotPermittedException(String description, Throwable cause) {
    super(description, cause);
    this.description = description;
  }
}
