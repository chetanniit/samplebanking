package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.applicant.dto.PersonAddressDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BureauCallAddressDto {

    private String houseNumber;

    private String houseName;

    private String flatNameOrNumber;

    private String street;

    private String town;

    private String county;

    private String postcode;

    private String country;

    public BureauCallAddressDto(PersonAddressDto personAddressDto) {
      this.houseNumber = personAddressDto.getHouseNumber();
      this.houseName = personAddressDto.getHouseName();
      this.flatNameOrNumber = personAddressDto.getFlat();
      this.street = personAddressDto.getStreet();
      this.town = personAddressDto.getTown();
      this.county = personAddressDto.getCounty();
      this.postcode = personAddressDto.getPostcode();
      this.country = personAddressDto.getCountryIsoCode();
    }

}
