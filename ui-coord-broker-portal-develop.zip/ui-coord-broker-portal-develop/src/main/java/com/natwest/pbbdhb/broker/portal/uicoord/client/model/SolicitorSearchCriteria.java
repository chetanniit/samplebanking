package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SolicitorSearchCriteria {

    private String associateName;

    private String postCode;

    private final Boolean isOnPanel = true;

    private final Boolean isActive = true;
}
