package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PercentageFeeDto;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.PercentageFeeRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class ProcFeeClient {
    private final String procFeePercentageEndpoint;
    private final RestTemplate restTemplate;

    public ProcFeeClient(
            @Value("${msvc.proc.fee.percentage.url}") String procFeePercentageEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.procFeePercentageEndpoint = procFeePercentageEndpoint;
        this.restTemplate = restTemplate;
    }

    public PercentageFeeDto getPercentageFee(String brand, PercentageFeeRequestDto percentageFeeRequestDto) {
        String paymentPathScale = percentageFeeRequestDto.getPaymentPathScale();
        log.info("Calling {} to get percentage fee for paymentPathScale {}", procFeePercentageEndpoint,
            paymentPathScale);

        try {
              PercentageFeeDto percentageFeeDto = restTemplate.exchange(
                    procFeePercentageEndpoint,
                    HttpMethod.POST,
                    new HttpEntity<>(percentageFeeRequestDto, constructHeadersForJsonRequest(brand)),
                    PercentageFeeDto.class).getBody();
              log.debug("Percentage fee successfully retrieved for paymentPathScale {}", paymentPathScale);
              return percentageFeeDto;

        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to get percentage fee for paymentPathScale {}: {}",
                procFeePercentageEndpoint, paymentPathScale, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to get percentage fee for paymentPathScale {}: {}",
                procFeePercentageEndpoint, paymentPathScale, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }
}
