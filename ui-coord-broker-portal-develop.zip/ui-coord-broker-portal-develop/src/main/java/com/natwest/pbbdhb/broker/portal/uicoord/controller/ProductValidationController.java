package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_INVALID_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_VALID_REGEX;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_PRODUCT_VALIDATION;

import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.security.UserClaimsProvider;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ProductValidationService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Tag(name = "ProductValidation", //
    description = "Product validation API for Broker Portal UI coordinator")
@Validated
@Slf4j
@RequiredArgsConstructor
public class ProductValidationController {

  private final UserClaimsProvider userClaimsProvider;
  private final ProductValidationService productValidationService;

  @PostMapping(value = PATH_PRODUCT_VALIDATION, //
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ProductValidationResponse> productValidation(
      @Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
      @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
      @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) //
      final String brand,
      @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
      @PathVariable //
      final String caseId) {
    final String brokerUsername = userClaimsProvider.getBrokerUsername();
    log.info("Request received: productValidation; case id: {}; brokerUsername: {};",
        caseId, brokerUsername);
    final ProductValidationResponse productValidationResponse = productValidationService
        .validateProduct(brand, caseId);
    log.info("Request complete: productValidation; case id: {}; brokerUsername: {}; response: {}",
        caseId, brokerUsername, productValidationResponse);
    return ResponseEntity.ok(productValidationResponse);
  }

}
