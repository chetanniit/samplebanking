package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.control.DeepClone;

@Mapper(mappingControl = DeepClone.class)
public interface CapieClonerMapper {

  CaseApplicationDto clone(CaseApplicationDto caseApplicationDto);
  List<ApplicantDto> clone(List<ApplicantDto> applicantDtoList);
  ApplicantDto clone(ApplicantDto applicantDto);
  PropertyDetailsDto clone(PropertyDetailsDto propertyDetailsDto);
  ValidatedCaseIncomeDto clone(ValidatedCaseIncomeDto validatedCaseIncomeDto);
  ValidatedCaseExpenseDto clone(ValidatedCaseExpenseDto validatedCaseExpenseDto);

}
