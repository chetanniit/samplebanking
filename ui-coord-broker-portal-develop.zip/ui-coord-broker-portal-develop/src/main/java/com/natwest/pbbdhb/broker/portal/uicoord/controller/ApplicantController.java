package com.natwest.pbbdhb.broker.portal.uicoord.controller;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Applicant;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ApplicantProfile;
import com.natwest.pbbdhb.broker.portal.uicoord.service.ApplicantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import java.util.List;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.service.helper.WorkStatusHelper.applicantsWorkStatusMap;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DEFAULT;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_HEADER;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_INVALID_MSG;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.BRAND_VALID_REGEX;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_DESCRIPTION;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.PATH_ADD_APPLICANTS;

/**
 * @deprecated (DEPRECATED: Only used for some legacy tests)
 */
@RestController
@Tag(name = "Applicants")
@Validated
@Slf4j
@RequiredArgsConstructor
@Deprecated
public class ApplicantController {

    private final ApplicantService applicantService;

    @Operation(
            operationId = "addApplicants",
            summary = "Adds applicants for a case",
            tags = "Applicants"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful addition of applicants for a case", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApplicantProfile.class))),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(value = PATH_ADD_APPLICANTS, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApplicantProfile> saveApplicants(@Parameter(name = BRAND_HEADER, description = BRAND_DESCRIPTION)
                                                          @RequestHeader(value = BRAND_HEADER, required = false, defaultValue = BRAND_DEFAULT)
                                                          @Pattern(regexp = BRAND_VALID_REGEX, message = BRAND_INVALID_MSG) final String brand,
                                                          @Parameter(name = CASE_ID_PARAM, description = CASE_ID_DESCRIPTION)
                                                          @PathVariable final String caseId, @RequestBody @Valid final ApplicantProfile applicantProfile) {
        log.info("Request to add applicants for caseId={}", caseId);

        List<Applicant> applicants = applicantProfile.getApplicants();
        Map<String, String> workStatusMap = applicantsWorkStatusMap(applicants, null);
        return ResponseEntity.ok(new ApplicantProfile(this.applicantService.saveApplicants(brand, caseId, applicants, workStatusMap)));
    }
}
