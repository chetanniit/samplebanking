package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum RepaymentType implements ValuedEnum {
    REPAYMENT,
    INTEREST_ONLY,
    MIXED;

    @Override
    public String value() {
        return name();
    }
}