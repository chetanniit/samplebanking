package com.natwest.pbbdhb.broker.portal.uicoord.model;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductValidationResponse {

  private Boolean validProduct;
  private String productCode;
  private LocalDate productSelectionDate;

}
