package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;
import com.natwest.pbbdhb.broker.portal.uicoord.toggles.ConditionalOnUserClaimsIamMode;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalProvider;
import java.security.GeneralSecurityException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Responsible for retrieving user principal claims contained in a request.
 * <p>
 * Each request will hold claims within a UserPrincipal. This class will retrieve the current
 * request's UserPrincipal and will then extract the specific claims required.
 */
@Service
@Slf4j
@ConditionalOnUserClaimsIamMode
public class IamUserClaimsProvider implements UserClaimsProvider {
  public static final String ADDITIONAL_CLAIMS = "additional_claims";
  private static final String BROKER_ROLE = "brokerRole";
  private static final String USER_NAME = "userName";
  private static final String CHANNEL = "channel";
  private static final String FCA_NUMBER = "fcaNumber";

  private final UserPrincipalProvider userPrincipalProvider;

  public IamUserClaimsProvider(
      @Qualifier("simpleUserPrincipalProvider") UserPrincipalProvider userPrincipalProvider) {
    this.userPrincipalProvider = userPrincipalProvider;
  }

  @Override
  public String getBrokerUsername() {
    return getStringClaim(USER_NAME);
  }

  @Override
  public BrokerType getBrokerType() {
    return BrokerType.valueOf(getStringClaim(BROKER_ROLE));
  }

  @Override
  public String getChannel() {
    return getStringClaim(CHANNEL);
  }

  @Override
  public String getFcaNumber() {
    return getStringClaim(FCA_NUMBER);
  }

  private Object getClaim(String claimName) {
    return getUserPrincipal().getProperty(claimName);
  }

  private String getStringClaim(
      final String claimName) {
    final String claimValue = (String) getClaim(claimName);

    if (StringUtils.isNotBlank(claimValue)) {
      return claimValue;
    }
    log.error("Could not retrieve claim: {}", claimName);
    throw new IllegalStateException("Could not retrieve claim: " + claimName);
  }

  private UserPrincipal getUserPrincipal() {
    try {
      return Optional.ofNullable(userPrincipalProvider.get())
          .orElseThrow(() -> new IllegalStateException("UserPrincipal cannot be null"));
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException("Unable to retrieve UserPrincipal", e);
    }
  }
}
