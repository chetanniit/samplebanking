package com.natwest.pbbdhb.broker.portal.uicoord.model;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.DateFormat.DateConstraint;
import com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation.ValidateEnum;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Map;

@Data
public class JobDetailsDip {
    private String jobId;

    @ValidateEnum(enumClass = JobDetails.EmploymentStatus.class)
    private String employmentStatus;

    @ValidateEnum(enumClass = JobDetails.OccupationType.class)
    private String occupationType;

    @ValidateEnum(enumClass = JobDetails.IndustryType.class)
    private String industryType;

    @ValidateEnum(enumClass = JobDetails.PayslipFrequency.class)
    private String payslipFrequency;

    @DateFormat(pattern = "yyyy-MM-dd" , constraint = DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String employmentStartDate;

    @DateFormat(pattern = "yyyy-MM-dd")
    private String employmentEndDate;

    @DateFormat(pattern = "yyyy-MM-dd")
    private String contractEndDate;

    @DecimalMin(value = "1.00", message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 1.00 and 99999999.99 with up to 2 decimal places")
    BigDecimal basicPayAnnualIncome;

    @Size(max = 10, min = 1)
    @Valid
    private Map<String, AdditionalJobIncome> additionalIncome;

    @ValidateEnum(enumClass = JobDetails.SelfEmploymentStatus.class)
    private String selfEmploymentStatus;

    @DateFormat(pattern = "yyyy-MM-dd", constraint = DateConstraint.PAST, message = "must be a date in the past in format 'yyyy-MM-dd'")
    private String businessEstablishmentDate;

    private Integer yearOneTradingYear;

    private Integer yearTwoTradingYear;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneProfit;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoProfit;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneDirectorSalary;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearOneDividends;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoDirectorSalary;

    @DecimalMin(value = "0.00", message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    @Digits(integer = 8, fraction = 2, message = "must be a value between 0.00 and 99999999.99 with up to 2 decimal places")
    private BigDecimal yearTwoDividends;

}
