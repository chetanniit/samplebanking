package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.model.Fee;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.cases.dto.FeeDto;
import com.natwest.pbbdhb.cases.dto.ProductDetailsDto;
import com.natwest.pbbdhb.cases.dto.SalesIllustrationDto;
import org.mapstruct.*;

import java.util.Collections;
import java.util.List;


@Mapper
public interface ProductDetailsMapper {
    @Mapping(target = "portingText", source = "portingNotes")
    @Mapping(target = "hasAdditionalBorrowing", ignore = true)
    ProductDetails toProductDetails(ProductDetailsDto productDetailsDto);

    default ProductDetails toProductDetails(List<SalesIllustrationDto> salesIllustrations) {
        if (salesIllustrations == null || salesIllustrations.isEmpty() || salesIllustrations.get(0) == null
                || salesIllustrations.get(0).getProducts() == null || salesIllustrations.get(0).getProducts().isEmpty()) {
            return null;
        }

        return toProductDetails(salesIllustrations.get(0).getProducts().get(0));
    }

    @Mapping(target = "portingNotes", source = "portingText")
    ProductDetailsDto toProductDetailsDto(ProductDetails productDetails);

    @Mapping(target = "feePaymentType", source = "feeAction", qualifiedByName = "feeActionToFeePaymentType")
    @Mapping(target = "isPaymentMade", ignore = true)
    @Mapping(target = "orderId", ignore = true)
    @Mapping(target = "paidDate", ignore = true)
    FeeDto toFeeDto(Fee fee);

    @Named("feeActionToFeePaymentType")
    default String feeActionToFeePaymentType(String feeAction) {
        if ("NO_ACTION".equals(feeAction)) {
            return "CARD_PAYMENT";
        }

        return null;
    }

    default List<ProductDetailsDto> toProductDetailsDtoList(ProductDetails singleProductDetails) {
        if (singleProductDetails == null) {
            return null;
        }

        return Collections.singletonList(toProductDetailsDto(singleProductDetails));
    }

    default List<SalesIllustrationDto> toSalesIllustrationDtoList(ProductDetails singleProductDetails) {
        if (singleProductDetails == null) {
            return null;
        }

        List<SalesIllustrationDto> salesIllustrationDtoList = Collections.singletonList(new SalesIllustrationDto());
        List<ProductDetailsDto> productDetailsDtoList = Collections.singletonList(toProductDetailsDto(singleProductDetails));
        salesIllustrationDtoList.get(0).setProducts(productDetailsDtoList);
        salesIllustrationDtoList.get(0).setIsAccepted(true);
        return salesIllustrationDtoList;
    }
}
