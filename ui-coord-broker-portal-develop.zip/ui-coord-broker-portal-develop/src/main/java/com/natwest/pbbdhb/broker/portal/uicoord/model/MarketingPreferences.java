package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;
import jakarta.validation.constraints.NotNull;

@Data
public class MarketingPreferences {

  @NotNull
  private Boolean email;

  @NotNull
  private Boolean telephone;

  @NotNull
  private Boolean post;

}
