package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.ConditionalMandatoryAttributeValidator;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

/**
 * ConditionalMandatoryAttribute enables testing for required attributes when a
 * specified String attribute matches a specified Sting value.
 * Example, conditionalMandatoryField=postcode, conditionField=country, conditionValue=GB would flag
 * null postcode values when GB equals country attribute value, with defaultErrorMessage
 * postcode must not be null when country is GB.
 * This can be extended to non-string conditionField by parsing it into string value but it was not
 * required for our initial use case.
 */
@Target({TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = ConditionalMandatoryAttributeValidator.class)
public @interface ConditionalMandatoryAttribute {

    public static final String DEFAULT_ERROR_MESSAGE_KEY = "defaultErrorMessage";
    public static final String DEFAULT_ERROR_MESSAGE_TEMPLATE = "'%s' must not be null when '%s' is '%s'";

    String message() default "${"+DEFAULT_ERROR_MESSAGE_KEY+"}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String conditionalMandatoryField();
    String conditionField();
    String conditionValue();
}
