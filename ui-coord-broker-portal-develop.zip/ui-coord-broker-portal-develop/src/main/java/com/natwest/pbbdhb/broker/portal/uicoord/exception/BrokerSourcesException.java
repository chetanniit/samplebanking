package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class BrokerSourcesException extends Exception {
    public BrokerSourcesException(String message) {
        super(message);
    }

    public BrokerSourcesException(String message, Throwable cause) {
        super(message, cause);
    }
}
