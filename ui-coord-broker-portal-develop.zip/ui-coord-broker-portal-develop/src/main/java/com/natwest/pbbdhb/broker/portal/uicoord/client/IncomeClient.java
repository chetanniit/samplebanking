package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.broker.portal.uicoord.util.ApplicationConstants.CASE_ID_PARAM;
import static com.natwest.pbbdhb.broker.portal.uicoord.util.RestApiUtil.constructHeadersForJsonRequest;

@Component
@Slf4j
public class IncomeClient {

    private final String getIncomeEndpoint;
    private final String saveIncomeEndpoint;
    private final RestTemplate restTemplate;

    public IncomeClient(
            @Value("${msvc.income.get.url}") String getIncomeEndpoint,
            @Value("${msvc.income.save.url}") String saveIncomeEndpoint,
            @Qualifier("restTemplateForApiCall") RestTemplate restTemplate
    ) {
        this.getIncomeEndpoint = getIncomeEndpoint;
        this.saveIncomeEndpoint = saveIncomeEndpoint;
        this.restTemplate = restTemplate;
    }

    public ValidatedCaseIncomeDto saveIncome(String brand, String caseId, CaseIncomeDto income) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(saveIncomeEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);
        Integer version = income.getVersion();
        URI url = builder.build().toUri();
        log.info("Calling {} to save income with version {} and caseId {}", url, version, caseId);

        try {
            ValidatedCaseIncomeDto validatedCaseIncomeDto = restTemplate.exchange(
                    url,
                    HttpMethod.PUT,
                    new HttpEntity<>(income, constructHeadersForJsonRequest(brand)),
                    ValidatedCaseIncomeDto.class).getBody();
            if(validatedCaseIncomeDto == null) {
              log.warn("Null response body received from {} while saving income with version {} and caseId {}", url, version, caseId);
            } else {
              log.debug("Income successfully saved with version {} and caseId {}", validatedCaseIncomeDto.getVersion(), caseId);
            }
            return validatedCaseIncomeDto;

        } catch (RestClientException ex) {
            log.warn("A rest client exception occurred while calling {} to save income with version {} and caseId {}: {}",
                url, version, caseId, ex.getMessage());
            throw ex;
        } catch (Throwable t) {
            log.warn("An unexpected exception occurred while calling {} to save income with version {} and caseId {}: {}",
                url, version, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            throw t;
        }
    }

    public ValidatedCaseIncomeDto getIncome(String brand, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(getIncomeEndpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID_PARAM, caseId);
        builder.uriVariables(urlParams);

        URI url = builder.build().toUri();
        log.info("Calling {} to get income for caseId {}", url, caseId);

        try {
            ValidatedCaseIncomeDto validatedCaseIncomeDto =  restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    new HttpEntity<>(constructHeadersForJsonRequest(brand)),
                    ValidatedCaseIncomeDto.class).getBody();
            log.debug("Income successfully retrieved for caseId {}", caseId);
            return validatedCaseIncomeDto;

        } catch (HttpClientErrorException.NotFound ex) {
            log.warn("Income not found for caseId {}: returning null - {}", caseId, ex.getMessage());
            return null;
        } catch (RestClientException ex) {
          log.warn("A rest client exception occurred while calling {} to save income for caseId {}: {}",
              url, caseId, ex.getMessage());
          throw ex;
        } catch (Throwable t) {
          log.warn("An unexpected exception occurred while calling {} to save income for caseId {}: {}",
              url, caseId, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
          throw t;
        }
    }
}
