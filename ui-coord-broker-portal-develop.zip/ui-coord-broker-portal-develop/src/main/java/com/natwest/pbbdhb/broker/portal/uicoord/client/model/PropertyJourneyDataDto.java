package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PropertyJourneyDataDto {

    private Boolean newBuild;

    private Boolean homeReport;
}
