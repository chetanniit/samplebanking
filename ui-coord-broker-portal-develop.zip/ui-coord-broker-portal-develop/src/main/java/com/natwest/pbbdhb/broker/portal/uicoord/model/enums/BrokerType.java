package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

public enum BrokerType {
  ADMIN,
  BROKER
}
