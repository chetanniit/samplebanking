package com.natwest.pbbdhb.broker.portal.uicoord.model;

import lombok.Data;

@Data
public class BrokerProductSwitchDetails {

    private String encodedData;

    private String brokerSwitchUrl;
}
