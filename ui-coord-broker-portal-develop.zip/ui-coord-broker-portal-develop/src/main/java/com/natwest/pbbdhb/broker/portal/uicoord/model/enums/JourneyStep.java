package com.natwest.pbbdhb.broker.portal.uicoord.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum JourneyStep {

  FMA_PRE_SUBMIT,
  FMA_ON_SUBMIT,
  FMA_POST_SUBMIT_RESET,
  FMA_POST_SUBMIT_IN_ERROR,
  FMA_POST_SUBMIT_COMPLETE;

  @Override
  @JsonValue
  public String toString() {
    return super.toString();
  }

  @JsonCreator
  public static JourneyStep fromValue(String text) {
    for (JourneyStep step : JourneyStep.values()) {
      if (step.toString().equals(text)) {
        return step;
      }
    }
    return null;
  }


}