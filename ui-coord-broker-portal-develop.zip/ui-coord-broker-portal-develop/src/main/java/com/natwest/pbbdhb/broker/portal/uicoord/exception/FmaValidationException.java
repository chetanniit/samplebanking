package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class FmaValidationException extends RuntimeException {

  //todo: Handle more than one validation error code

  private final ErrorCode code;

  public FmaValidationException(ErrorCode code, String message) {
    super(message);
    this.code = code;
  }

  public ErrorCode getCode() {
    return code;
  }

}


