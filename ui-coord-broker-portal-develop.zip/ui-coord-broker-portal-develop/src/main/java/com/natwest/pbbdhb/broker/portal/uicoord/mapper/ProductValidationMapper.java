package com.natwest.pbbdhb.broker.portal.uicoord.mapper;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcRequest.ProductValidationFee;
import com.natwest.pbbdhb.broker.portal.uicoord.client.model.ProductValidationMsvcResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.model.CaseApplication;
import com.natwest.pbbdhb.broker.portal.uicoord.model.Fee;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductDetails;
import com.natwest.pbbdhb.broker.portal.uicoord.model.ProductValidationResponse;
import com.natwest.pbbdhb.broker.portal.uicoord.util.DateUtils;
import java.math.BigDecimal;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import static com.natwest.pbbdhb.openapi.esis.Application.BuyerTypeEnum.NEW_CUSTOMER;

@Mapper(componentModel = "spring", builder = @Builder(disableBuilder = true))
public abstract class ProductValidationMapper {

  @Mapping(target = "productCode", source = "productDetails.productCode")
  @Mapping(target = "applicationType", source = "applicationType")
  @Mapping(target = "propertyValue", source = "mortgage.propertyValue")
  @Mapping(target = "customerType", source = ".", qualifiedByName = "toCustomerType")
  @Mapping(target = "mortgageAmount", source = "mortgage.mortgageAmount")
  @Mapping(target = "productSearchDate", source = ".", qualifiedByName = "toProductSearchDateFormat")
  @Mapping(target = "mortgageType", source = "productDetails.mortgageType")
  @Mapping(target = "productType", source = "productDetails.productType")
  @Mapping(target = "repaymentType", source = "mortgage.mortgageType")
  @Mapping(target = "productTerm", source = "productDetails.productTerm")
  @Mapping(target = "ltv", source = "productDetails.ltv")
  @Mapping(target = "isCashbackProduct", source = "productDetails", qualifiedByName = "toIsCashbackProduct")
  @Mapping(target = "freeLegal", source = "productDetails.isFreeLegal")
  @Mapping(target = "jurisdiction", expression = "java(\"UK\")")
  @Mapping(target = "fees", source = "productDetails.fees")
  public abstract ProductValidationMsvcRequest mapToValidationMsvcRequest(CaseApplication caseData);

  @Mapping(target = "code", source = "feeCode")
  @Mapping(target = "amount", source = "feeAmount")
  public abstract ProductValidationFee mapToProductValidationFee(Fee fee);

  @Named("toCustomerType")
  public String toCustomerType(CaseApplication caseApplication) {
    return NEW_CUSTOMER.name();
  }

  @Named("toIsCashbackProduct")
  public Boolean toIsCashbackProduct(ProductDetails productDetails) {
    return productDetails.getCashBackValue() != null &&
        productDetails.getCashBackValue().compareTo(BigDecimal.ZERO) > 0;
  }

  @Named("toProductSearchDateFormat")
  public String toProductSearchDateFormat(CaseApplication caseApplication) {
    ProductDetails productDetails = caseApplication.getProductDetails();
    if (productDetails == null || productDetails.getProductSelectedDate() == null) {
      return null;
    }
    return DateUtils.isoDateToProductValidationDateString(productDetails.getProductSelectedDate());
  }

  @Mapping(target = "validProduct", source = "validationResponse.validProduct")
  @Mapping(target = "productCode", source = "validationResponse.productCode")
  @Mapping(target = "productSelectionDate", source = "caseData.productDetails.productSelectedDate")
  public abstract ProductValidationResponse mapToProductValidationResponse(
      ProductValidationMsvcResponse validationResponse, CaseApplication caseData);
}
