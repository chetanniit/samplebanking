package com.natwest.pbbdhb.broker.portal.uicoord.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.natwest.pbbdhb.commondictionaries.enums.Channel;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PercentageFeeRequestDto {

    private final String channel = Channel.INTERMEDIARY_NAPOLI.toString();

    private String paymentPathScale;
}
