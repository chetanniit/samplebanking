package com.natwest.pbbdhb.broker.portal.uicoord.security;

import com.natwest.pbbdhb.broker.portal.uicoord.client.CaseClientNapoli;
import com.natwest.pbbdhb.broker.portal.uicoord.model.enums.BrokerType;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class AccessPermissionChecker {

    private final CaseClientNapoli caseClient;

    private final UserClaimsProvider userClaimsProvider;

    public boolean isBroker() {
        BrokerType brokerType = userClaimsProvider.getBrokerType();
        log.debug("Broker type for broker with brokerUsername {} is {}", userClaimsProvider.getBrokerUsername(), brokerType.name());
        return BrokerType.BROKER.equals(brokerType);
    }

    public boolean isCaseOwner(String brand, String caseId) {
        if (!isBroker()) {
          log.debug("Broker with brokerUsername {} and case id {} is not broker", userClaimsProvider.getBrokerUsername(), caseId);
          return false;
        }

        String loggedInUser = getLoggedInUser();
        if (loggedInUser == null) {
            log.debug("Broker with brokerUsername {} and case id {} is not logged in", userClaimsProvider.getBrokerUsername(), caseId);
            return false;
        }

        String loggedInUserFcaNumber = getLoggedInUserFcaNumber();
        if (loggedInUserFcaNumber == null) {
          log.debug("Broker with brokerUsername {} and case id {} is has null Fca number", userClaimsProvider.getBrokerUsername(), caseId);
          return false;
        }

      CaseApplicationDto caseApplicationDto = caseClient.getCase(brand, caseId);
      String caseOwner = getCaseOwner(caseApplicationDto);
      String caseOwnerFcaNumber = getCaseOwnerFcaNumber(caseApplicationDto);
      return loggedInUser.equalsIgnoreCase(caseOwner) && loggedInUserFcaNumber.equalsIgnoreCase(caseOwnerFcaNumber);
    }

    private String getLoggedInUser() {
        return userClaimsProvider.getBrokerUsername();
    }

    private String getLoggedInUserFcaNumber() {
      return userClaimsProvider.getFcaNumber();
    }

    private String getCaseOwner(CaseApplicationDto caseApplicationDto) {
        BrokerDto brokerDto = caseApplicationDto.getBroker();
        if (brokerDto == null) {
            log.debug("Broker details for broker with brokerUsername {} and case id {} are null",
                userClaimsProvider.getBrokerUsername(), caseApplicationDto.getCaseId());
            return null;
        }

        return brokerDto.getBrokerUsername();
    }

  private String getCaseOwnerFcaNumber(CaseApplicationDto caseApplicationDto) {
    BrokerDto brokerDto = caseApplicationDto.getBroker();
    if (brokerDto == null) {
      log.debug("Broker details for broker with brokerUsername {} and case id {} are null",
          userClaimsProvider.getBrokerUsername(), caseApplicationDto.getCaseId());
      return null;
    }

    return brokerDto.getFcaNumber();
  }
}
