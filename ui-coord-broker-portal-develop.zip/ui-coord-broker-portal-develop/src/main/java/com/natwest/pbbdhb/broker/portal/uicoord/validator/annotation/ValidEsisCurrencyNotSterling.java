package com.natwest.pbbdhb.broker.portal.uicoord.validator.annotation;

import com.natwest.pbbdhb.broker.portal.uicoord.validator.esis.EsisCurrencyNotSterlingValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EsisCurrencyNotSterlingValidator.class)
public @interface ValidEsisCurrencyNotSterling {

    String message() default "currency and currencyExchangeRate cannot empty when currency is not Pound Sterling";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
