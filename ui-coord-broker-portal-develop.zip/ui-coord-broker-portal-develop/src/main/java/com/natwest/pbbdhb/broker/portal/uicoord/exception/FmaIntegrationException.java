package com.natwest.pbbdhb.broker.portal.uicoord.exception;

public class FmaIntegrationException extends Exception {

    public FmaIntegrationException(String message) {
        super(message);
    }

    public FmaIntegrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
