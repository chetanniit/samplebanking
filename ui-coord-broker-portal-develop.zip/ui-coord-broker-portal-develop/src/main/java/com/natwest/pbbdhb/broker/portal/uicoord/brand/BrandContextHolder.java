package com.natwest.pbbdhb.broker.portal.uicoord.brand;


public class BrandContextHolder {

    private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();

    public BrandContextHolder() {
    }

    public static void setCurrentBrand(String brand) {
        contextHolder.set(brand);
    }

    public static String getCurrentBrand() {
        return contextHolder.get();
    }

    public static boolean isBrand(String brand) {
        return getCurrentBrand().equalsIgnoreCase(brand);
    }

    public static void clear() {
        contextHolder.remove();
    }


}
