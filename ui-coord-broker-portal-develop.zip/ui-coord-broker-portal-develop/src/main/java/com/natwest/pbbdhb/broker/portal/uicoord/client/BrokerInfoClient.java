package com.natwest.pbbdhb.broker.portal.uicoord.client;

import com.natwest.pbbdhb.broker.portal.uicoord.client.model.broker.info.BrokerInfoResponseDto;
import com.natwest.pbbdhb.broker.portal.uicoord.exception.BrokerNotFoundException;
import com.natwest.pbbdhb.broker.portal.uicoord.service.helper.SecurityTokenHelper;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;

@Slf4j
@Component
public class BrokerInfoClient {

  private static final String EXPECTED_BROKER_FOUND_MESSAGE = "Broker Data found";

  private final String brokerReadEndpoint;
  private final RestTemplate restTemplate;
  private final SecurityTokenHelper securityTokenHelper;

  @Autowired
  public BrokerInfoClient(
      @Value("${crm.brokerCore.read.url}") String brokerReadEndpoint,
      @Qualifier("sslRestTemplate") RestTemplate restTemplate,
      SecurityTokenHelper securityTokenHelper) {

    this.restTemplate = restTemplate;
    this.securityTokenHelper = securityTokenHelper;
    this.brokerReadEndpoint = brokerReadEndpoint;
  }

  public BrokerInfoResponseDto readBroker(@NonNull String username) {
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(HttpHeaders.AUTHORIZATION, String.format("Bearer %s", securityTokenHelper.getAccessToken()));
    URI uri = UriComponentsBuilder.fromHttpUrl(brokerReadEndpoint).buildAndExpand(username).toUri();

    log.info("Calling {} to get broker info for broker with brokerUsername {}", uri, username);
    try {
      ResponseEntity<BrokerInfoResponseDto> brokerResponse = restTemplate.exchange(
          uri,
          HttpMethod.GET,
          new HttpEntity<>(httpHeaders),
          BrokerInfoResponseDto.class
      );

      final BrokerInfoResponseDto brokerInfo = Optional
          .ofNullable(brokerResponse.getBody())
          .orElseThrow(() -> {
            log.error("Empty Broker data returned from CRM when calling {} for broker with brokerUsername {}", uri, username);
            return new BrokerNotFoundException("Empty Broker data returned from CRM");
          });

      if (!EXPECTED_BROKER_FOUND_MESSAGE.equals(brokerInfo.getMessage())) {
        log.error(String.format("Broker data not found for broker with brokerUsername %s. Response: %s", username, brokerInfo.getMessage()));
        throw new BrokerNotFoundException("Broker not found in CRM");
      }

      log.debug("Broker info successfully retrieved: {}", brokerInfo);
      return brokerInfo;

    } catch (RestClientException ex) {
      log.warn("A rest client exception occurred while retrieving broker info from {} for broker with brokerUsername {}: {}",
          uri, username, ex.getMessage());
      throw new BrokerNotFoundException("Failed to retrieve Broker data from CRM", ex);
    } catch (Throwable t) {
      log.warn("An unexpected exception occurred while calling {} to get broker info for broker with brokerUsername {}: {}",
          uri, username, t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
      throw t;
    }
  }
}
