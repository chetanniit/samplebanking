# Spring Boot MicroService - ui-coord-broker-portal

## Brief Overview :

This is UI coord microservice for broker portal

## Proxy

Making calls outside the bank (e.g. calling to CRM) requires a proxy, see [here ("Run the service")](https://natwest.atlassian.net/wiki/spaces/PRN/pages/106823858/Local+development) for instructions on how to set up your credentials.

## Build the application

```shell script
mvn clean install
```

## Running unit tests

```shell script
mvn clean test
```

## Running all tests

```shell script
mvn clean verify -DskipITs=false
```

## Running only the DIP request tests

```shell script
mvn clean verify -P dip-request-test
```
-or-
```shell script
$ ./dip-request-tests.sh
```



## Running the application with the "local" spring profile

```shell script
mvn spring-boot:run
```

## Swagger endpoint (api documentation):

See above for the endpoint URLs for the different environments.

* `.../ui-coord-broker-portal/swagger-ui/index.html`

e.g. `http://localhost:8080/mortgages/v1/ui-coord-broker-portal/swagger-ui/index.html`

## Changing logging level:

As a default, logging level is set to INFO. This setting can be changed in application-XXX.yml files, where XXX stands for an environment (prd, uat, nft, dev).
Each package can have its own logging level setting.

I.e. to change logging level for connectors for production environment, set this line in file `application-prd.yml`:

```yaml
logging:
  level:
    com:
      natwest:
        pbbdhb: INFO
        pbbdhb.broker.portal.uicoord.client: DEBUG
```

This configuration is setting:
* `DEBUG` level for logs for package `com.natwest.pbbdhb.broker.portal.uiccord.client`
* `INFO` level for any other logs for package `com.natwest.pbbdhb`

## PCF configuration and deployment

For working with PCF, you need to open your terminal inside the `pcf-config` directory.

Once inside there, you can call either of the following commands, which should explain how they
work.

```bash
# To see PCF commands
./scripts/pcf.sh --help
```

### Deploying a snapshot build

```bash
./scripts/deploy.sh {ENV} - pcf_url={SNAPSHOT_URL}
```

Example: `./scripts/deploy.sh dev - pcf_url=https://artifactory.server.rbsgrp.net/artifactory/pbbdhb-libs-snapshots-local/com/natwest/pbbdhb/ui-coord-consent/0.1.0-SNAPSHOT/ui-coord-consent-0.1.0-20211006.112502-1-dist.jar`

### Deploying a release build

```bash
./scripts/deploy.sh {ENV} {VERSION}
```

Example: `./scripts/deploy.sh dev 0.1.0`

### Deploying latest release build

```bash
./scripts/deploy.sh {ENV} LATEST
```

Example: `./scripts/deploy.sh dev LATEST`