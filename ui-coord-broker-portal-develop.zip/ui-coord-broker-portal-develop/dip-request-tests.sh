#! /bin/bash

mvn verify -P dip-request-test -DskipTests

echo
echo
echo 'RESULTS'
echo '-------'
cat dip-request-test-results.txt