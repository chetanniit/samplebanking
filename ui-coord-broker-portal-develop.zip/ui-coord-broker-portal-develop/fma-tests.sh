#! /bin/bash

echo $1

mvn verify -P fma-complete-test -DskipTests

echo
echo
echo 'RESULTS'
echo '-------'
cat fma-complete-test-results.txt