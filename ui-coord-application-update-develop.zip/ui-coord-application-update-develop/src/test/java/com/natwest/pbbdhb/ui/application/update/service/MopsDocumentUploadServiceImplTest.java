package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.DocumentUploadServiceImpl;
import com.natwest.pbbdhb.ui.application.update.service.impl.MopsDocumentUploadServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createDocumentUploadRequest;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createDocumentUploadResponseDtoWithOnlySuccesses;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createUserInformationResponse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class MopsDocumentUploadServiceImplTest {

    public static final String BASE_URL = "https://v1-msvc-docin-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net";
    public static final String UPLOAD_ENDPOINT = "/upload";
    public static final String PRECLASSIFIED_UPLOAD_ENDPOINT = "/upload/preclassified";

    private MopsDocumentUploadServiceImpl service;

    @Mock
    private AuthorizationService authorizationService;
    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    public void setUp() {
        this.service = new MopsDocumentUploadServiceImpl(restTemplate, BASE_URL, UPLOAD_ENDPOINT, PRECLASSIFIED_UPLOAD_ENDPOINT, false,Arrays.asList("2"),Arrays.asList("3", "7", "8", "9"));
    }

    @Test
    void testRBSDocumentUploadSuccess() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadSingleDocument(documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));

    }

    @Test
    void testNWBDocumentUploadSuccess1() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/32345678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadSingleDocument(documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testNWBDocumentUploadSuccess2() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/72345678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadSingleDocument(documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testNWBDocumentUploadSuccess3() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/82345678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);
        File jpgFile = new ClassPathResource("testfiles/82345678natwest_logo.jpg").getFile();
        String jpgString = new String(Files.readAllBytes(jpgFile.toPath()));
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadSingleDocument(documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testNWBDocumentUploadSuccess4() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/92345678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);

        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadSingleDocument(documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testNWBDocumentUploadFail() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);

        PreConditionFailedException exception = assertThrows(PreConditionFailedException.class,
                () -> service.uploadSingleDocument(documentRequest));
        verifyNoInteractions(restTemplate);
    }

    @Test
    void testNWBDocumentUploadFail1() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/823a45678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);

        PreConditionFailedException exception = assertThrows(PreConditionFailedException.class,
                () -> service.uploadSingleDocument(documentRequest));
        verifyNoInteractions(restTemplate);
    }

    @Test
    void testDocumentUploadPreConditionFail() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/12345678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);

        PreConditionFailedException exception = assertThrows(PreConditionFailedException.class,
                () -> service.uploadSingleDocument(documentRequest));
        verifyNoInteractions(restTemplate);
    }

    @Test
    void testDocumentUploadPreConditionFail2() throws IOException {
        DocumentUploadRequest documentRequest = createDocumentUploadRequest();
        Resource fileResource = new ClassPathResource(
                "testfiles/img.png");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        documentRequest.setFile(file);

        PreConditionFailedException exception = assertThrows(PreConditionFailedException.class,
                () -> service.uploadSingleDocument(documentRequest));
        verifyNoInteractions(restTemplate);
    }

}
