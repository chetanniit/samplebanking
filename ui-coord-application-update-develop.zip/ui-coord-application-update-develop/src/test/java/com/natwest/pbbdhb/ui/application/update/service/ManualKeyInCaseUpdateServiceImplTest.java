package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.commondictionaries.enums.cases.LoanPurpose;
import com.natwest.pbbdhb.ui.application.update.mapper.GmsAPIStateMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.GmsAPIStateMapperImpl;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ManualKeyInCaseUpdateException;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.ManualKeyInCaseUpdateServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NWB_BRAND;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ManualKeyInCaseUpdateServiceImplTest {

    @InjectMocks
    private ManualKeyInCaseUpdateServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AuthorizationService authorizationService;

    @Spy
    private GmsAPIStateMapper gmsAPIStateMapper = new GmsAPIStateMapperImpl();
    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "msvcHboGmsApiStateParentEndpoint", "https://v1-msvc-hbo-gms-api-state-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net");
        ReflectionTestUtils.setField(service, "manualKeyInCaseUpdateEndpoint", "/mortgages/v1/msvc-hbo-gms-api-state/applications/{caseId}/{dipId}");
        ReflectionTestUtils.setField(service, "successMessage", "Record has been successfully updated.");
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCases() {
        when(authorizationService.getUserData()).thenReturn(UserInformationResponse.builder().racfID("abc").username("James").build());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("Application updated successfully.", HttpStatus.OK));
        ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest = ManualKeyInCaseUpdateRequest.builder().loanPurpose(LoanPurpose.HOUSE_PURCHASE.name()).build();
        SuccessResponse successResponse = service.updateApplicationDataForManualKeyInCases(NWB_BRAND, "CBRKMCCONGAR1662898898686",
                "CB1662898888776", manualKeyInCaseUpdateRequest);
        assertEquals("Record has been successfully updated.", successResponse.getSuccessMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCases404Exception() {
        String responseText = "Path not found";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        when(authorizationService.getUserData()).thenReturn(UserInformationResponse.builder().racfID("abc").username("James").build());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.NOT_FOUND, "not found", mock(HttpHeaders.class),
                        responseBytes, charset));
        ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest = ManualKeyInCaseUpdateRequest.builder().build();
        assertThrows(ManualKeyInCaseUpdateException.class, () -> service.updateApplicationDataForManualKeyInCases(NWB_BRAND,
                "CBRKMCCONGAR1662898898686", "CB1662898888776", manualKeyInCaseUpdateRequest));
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCases400Exception() {
        String responseText = "Invalid applicants";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        when(authorizationService.getUserData()).thenReturn(UserInformationResponse.builder().racfID("abc").username("James").build());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "Bad Request", mock(HttpHeaders.class),
                        responseBytes, charset));
        ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest = ManualKeyInCaseUpdateRequest.builder().build();
        assertThrows(ManualKeyInCaseUpdateException.class, () -> service.updateApplicationDataForManualKeyInCases(NWB_BRAND,
                "CBRKMCCONGAR1662898898686", "CB1662898888776", manualKeyInCaseUpdateRequest));
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testUpdateApplicationDataForManualKeyInADBOCases() {
        when(authorizationService.getUserData()).thenReturn(UserInformationResponse.builder().racfID("abc").username("James").build());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("Application updated successfully.", HttpStatus.OK));
        ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest = ManualKeyInCaseUpdateRequest.builder().loanPurpose(LoanPurpose.ADDITIONAL_BORROWING.name()).build();
        SuccessResponse successResponse = service.updateApplicationDataForManualKeyInCases(NWB_BRAND, "CBRKMCCONGAR1662898898686",
                "CB1662898888776", manualKeyInCaseUpdateRequest);
        assertEquals("Record has been successfully updated.", successResponse.getSuccessMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }
}