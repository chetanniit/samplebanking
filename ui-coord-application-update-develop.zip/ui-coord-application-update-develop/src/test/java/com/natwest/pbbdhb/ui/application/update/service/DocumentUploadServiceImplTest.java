package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocUploadChannelEnum;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.DocumentUploadServiceImpl;
import com.natwest.pbbdhb.ui.application.update.util.TestConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class DocumentUploadServiceImplTest {


    public static final String BASE_URL = "https://v1-msvc-docin-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net";
    public static final String UPLOAD_ENDPOINT = "/upload";
    public static final String UPLOAD_PRECLASSIFIED_ENDPOINT = "/upload/preclassified";

    private DocumentUploadServiceImpl service;

    @Mock
    private AuthorizationService authorizationService;

    @Mock
    private RestTemplate restTemplate;


    @BeforeEach
    public void setUp() {
        this.service = new DocumentUploadServiceImpl(restTemplate, BASE_URL, UPLOAD_ENDPOINT, UPLOAD_PRECLASSIFIED_ENDPOINT,false);
    }


    @Test
    void testDocumentUploadWithReferenceNumber() throws IOException {
        DocumentRequest documentRequest = createDocumentRequest();
        File jpgFile = new ClassPathResource(TestConstants.TEST_IMAGE).getFile();
        String jpgString = new String(Files.readAllBytes(jpgFile.toPath()));
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity<>(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadDocument("NWB", null, "88920823", documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testDocumentUploadWithReferenceNumberBrokerFocus() throws IOException {
        ReflectionTestUtils.setField(service, "prefixValue", false);
        DocumentRequest documentRequest = createDocumentRequest();
        documentRequest.setChannel(DocUploadChannelEnum.INTERNET);
        File jpgFile = new ClassPathResource(TestConstants.TEST_IMAGE).getFile();
        String jpgString = new String(Files.readAllBytes(jpgFile.toPath()));
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity<>(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadDocument("NWB", null, "88920823", documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testDocumentUploadWithCaseId() throws IOException {
        DocumentRequest documentRequest = createDocumentRequest();
        File jpgFile = new ClassPathResource(TestConstants.TEST_IMAGE).getFile();
        String jpgString = new String(Files.readAllBytes(jpgFile.toPath()));
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity<>(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadDocument("NWB", "88920823", null, documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testDocumentUploadBadRequest() throws IOException {
        DocumentRequest documentRequest = createDocumentRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
        service.uploadDocument("NWB", null, null, documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }


    @Test
    void testPreClassifiedDocUploadWithCaseId() throws IOException {
        DocumentRequest documentRequest = createPreClassifiedDocumentRequest();
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity<>(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadDocument("NWB", "88920823", null, documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testPreClassifiedDocUploadWithReferenceNumber() throws IOException {
        DocumentRequest documentRequest = createPreClassifiedDocumentRequest();
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        ResponseEntity<DocumentUploadResponseDto> response = new ResponseEntity<>(uploadResponseDto, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(DocumentUploadResponseDto.class))).thenReturn(response);
        service.uploadDocument("NWB", null, "88920823", documentRequest);
        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(), eq(DocumentUploadResponseDto.class));
    }

    @Test
    void testPreClassifiedDocUploadPreConditionFailed() throws IOException {
        DocumentRequest documentRequest = createPreClassifiedDocRequestWithMultipleFiles();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        assertThrows(PreConditionFailedException.class, () -> service.uploadDocument("NWB", null, "88920823", documentRequest));
    }


}
