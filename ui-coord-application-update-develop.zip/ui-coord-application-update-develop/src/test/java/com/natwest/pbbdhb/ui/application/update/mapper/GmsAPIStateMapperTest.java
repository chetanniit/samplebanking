package com.natwest.pbbdhb.ui.application.update.mapper;

import com.natwest.pbbdhb.ui.application.update.model.dto.capie.GmsAPIStateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInApplicantDetail;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
public class GmsAPIStateMapperTest {

    @InjectMocks
    private GmsAPIStateMapperImpl mapper;


    @Test
    void testToGmsAPIStateRequest() {
        GmsAPIStateRequest gmsAPIStateRequest = mapper.toGmsAPIStateRequest(ManualKeyInCaseUpdateRequest.builder()
                .mortgageRefNo("12345678")
                .applSeq("01")
                .loanPurpose("HOUSE_PURCHASE")
                .applicants(Collections.singletonList(ManualKeyInApplicantDetail.builder().cin("123")
                        .clientId(12344)
                        .dateOfBirth("2022-09-09")
                        .firstNames("James")
                        .lastName("Smith")
                        .middleNames("ad").build()))
                .build());
        assertNotNull(gmsAPIStateRequest);
        assertEquals("FMA", gmsAPIStateRequest.getApplicationType());
    }

    @Test
    void testToGmsAPIStateRequestForADBOCase() {
        GmsAPIStateRequest gmsAPIStateRequest = mapper.toGmsAPIStateRequest(ManualKeyInCaseUpdateRequest.builder()
                .mortgageRefNo("12345678")
                .applSeq("01")
                .loanPurpose("ADDITIONAL_BORROWING")
                .applicants(Collections.singletonList(ManualKeyInApplicantDetail.builder().cin("123")
                        .clientId(12344)
                        .dateOfBirth("2022-09-09")
                        .firstNames("James")
                        .lastName("Smith")
                        .middleNames("ad").build()))
                .build());
        assertNotNull(gmsAPIStateRequest);
        assertEquals("ADDITIONAL_BORROWING", gmsAPIStateRequest.getApplicationType());
    }

    @Test
    void testToGmsAPIStateRequest1() {
        GmsAPIStateRequest gmsAPIStateRequest = mapper.toGmsAPIStateRequest(ManualKeyInCaseUpdateRequest.builder()
                .mortgageRefNo("12345678")
                .applSeq("01")
                .applicants(Collections.singletonList(ManualKeyInApplicantDetail.builder().cin("123")
                        .clientId(12344)
                        .dateOfBirth("2022-09-09")
                        .firstNames("James")
                        .lastName("Smith")
                        .middleNames("ad").build()))
                .build());
        assertNotNull(gmsAPIStateRequest);
        assertEquals("FMA", gmsAPIStateRequest.getApplicationType());
    }

    @Test
    void testToGmsAPIStateRequestForNull() {
        GmsAPIStateRequest gmsAPIStateRequest = mapper.toGmsAPIStateRequest(null);
        assertNull(gmsAPIStateRequest);
    }
}
