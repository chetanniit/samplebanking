package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.TestEnvironment;
import com.natwest.pbbdhb.ui.application.update.cucumber.token.AccessTokenGenerator;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;

//import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.POST_CASE_ID_NOTIFICATION_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.POST_CASE_ID_NOTIFICATION_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PostNotificationCaseIdStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(POST_CASE_ID_NOTIFICATION_JSON);
    }

    @Given("Send Reminder case id endpoint exists")
    public void sendReminderEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User push request for Send Reminder case id using input {string} and verify response code")
    public void userPushRequestForSendReminderUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }
    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGES).asText().contains(error_message_Array.asText()));
    }


    @Then("Verify case id response code while providing valid input in the request parameter of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeWhileProvidingValidInputInTheRequestParameterOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) {
        Assertions.assertEquals(202, response.getStatusCode());
        Assertions.assertTrue(response.asString().contains("Reminder has been sent successfully"));
    }

    @Then("Verify case id response code and error message while providing invalid brand name of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidBrandNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(400, response.getStatusCode());
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid Case Id of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidCaseIdOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid  chasedByFullName of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByFullNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid  chasedByRACFID of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByRACFIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid  requestID of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidRequestIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while some of the requestID has status as Received of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileSomeOfTheRequestIDHasStatusAsReceivedOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) {
        Assertions.assertEquals(206, response.getStatusCode());
        Assertions.assertEquals("Reminder has been send successfully for RequestID 62da44ed2dd8153a7c2a3376 and unsuccessful for RequestID 62da44ed2dd8153a7c2a3374", response.prettyPrint());
    }

    @Then("Verify case id response code and error message while all the requestID provided in request have status as Received along with notificationRequired is false in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileAllTheRequestIDProvidedInRequestHaveStatusAsReceivedAlongWithNotificationRequiredIsFalseInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(404, response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGES).asText().contains(error_message_Array.asText()));
    }

    @Then("Verify case id response code while providing valid input in the request parameter of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeWhileProvidingValidInputInTheRequestParameterOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) {
        Assertions.assertEquals(202, response.getStatusCode());
        Assertions.assertTrue(response.prettyPrint().contains("Reminder has been sent successfully"));
    }

    @Then("Verify case id response code and error message while providing invalid brand name of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidBrandNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(400, response.getStatusCode());
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid Case Id of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidCaseIdOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid  chasedByFullName of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByFullNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid  chasedByRACFID of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByRACFIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while providing invalid  requestID of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidRequestIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify case id response code and error message while some of the requestID has status as Received of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileSomeOfTheRequestIDHasStatusAsReceivedOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) {
        Assertions.assertEquals(206, response.getStatusCode());
        Assertions.assertEquals("Reminder has been send successfully for RequestID 62da44ed2dd8153a7c2a3376 and unsuccessful for RequestID 628381d9780bd56f426271fa", response.prettyPrint());
    }

    @Then("Verify case id response code and error message while all the requestID provided in request have status as Received along with notificationRequired is false in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileAllTheRequestIDProvidedInRequestHaveStatusAsReceivedAlongWithNotificationRequiredIsFalseInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(404, response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGES).asText().contains(error_message_Array.asText()));
    }


    @Then("Validate the case id error message for forbidden user for send reminder {string}")
    public void validateTheErrorMessageForForbiddenUserForSendReminder(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify case id response code while providing valid rbs input in the request parameter of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeWhileProvidingValidRbsInputInTheRequestParameterOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String arg0) {
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertEquals("Reminder has been send successfully for RequestID 628381e701e8915849b7b968", response.prettyPrint());
    }

    @Then("Verify in ui coord application update caseid success response code for the input {string}")
    public void verifyInUiCoordApplicationUpdateCaseidSuccessResponseCodeForTheInput(String arg0) {
        Assertions.assertEquals(202, response.getStatusCode());
    }

    @Then("Verify in ui coord application update caseid error response code when precondition failed if any of the requestId is review or closed for the input {string}")
    public void verifyInUiCoordApplicationUpdateCaseidErrorResponseCodeWhenPreconditionFailedIfAnyOfTheRequestIdIsReviewOrClosedForTheInput(String arg0) {
        Assertions.assertEquals(412, response.getStatusCode());
    }

    @Then("Verify in ui coord application update caseid error response code when caseId or reference number are not present in document collection in for the input {string}")
    public void verifyInUiCoordApplicationUpdateCaseidErrorResponseCodeWhenCaseIdOrReferenceNumberAreNotPresentInDocumentCollectionInForTheInput(String arg0) {
        Assertions.assertEquals(404, response.getStatusCode());
    }


    @Then("Verify in ui coord application update caseid error response code when requestId are not present in document collection for the input {string}")
    public void verifyInUiCoordApplicationUpdateCaseidErrorResponseCodeWhenRequestIdAreNotPresentInDocumentCollectionForTheInput(String arg0) {
        Assertions.assertEquals(412, response.getStatusCode());
    }

    @Then("Verify in ui coord application update caseid error response code when there is any validation error for the input {string}")
    public void verifyInUiCoordApplicationUpdateCaseidErrorResponseCodeWhenThereIsAnyValidationErrorForTheInput(String arg0) {
        Assertions.assertEquals(400, response.getStatusCode());
    }
}
