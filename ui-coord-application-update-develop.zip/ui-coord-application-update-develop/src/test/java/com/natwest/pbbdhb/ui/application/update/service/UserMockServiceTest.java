package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.MockUsersRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.UserMockService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.asJsonString;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.getMockUsersRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = {UserMockService.class}, properties = {"spring.profiles.active=test"})
@DisplayName("UserMockService - MVC Test")
class UserMockServiceTest {

    @MockBean
    private UserMockService userMockService;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        userMockService = new UserMockService();
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.invokeMethod(userMockService, "setup");
    }

    @Test
    void testUserGroup() {
        UserInformationResponse mockUser = userMockService.getMockUser();
        Assertions.assertTrue(mockUser.isUWUser());
        Assertions.assertFalse(mockUser.isMCCUser());
        Assertions.assertFalse(mockUser.isMopsUser());
        Assertions.assertFalse(mockUser.isUWLead());
        Assertions.assertFalse(mockUser.isDocViewer());
        Assertions.assertFalse(mockUser.isMopsDataEntry());
    }

    @Test
    void testSetMultiGroupMockUser(){
        MockUsersRequest mockUsersRequest = getMockUsersRequest();

        userMockService.setMultiGroupMockUser(mockUsersRequest);
        UserInformationResponse mockUser = userMockService.getMockUser();
        Assertions.assertTrue(mockUser.isUWUser());
        Assertions.assertTrue(mockUser.isMCCUser());
        Assertions.assertTrue(mockUser.isMopsUser());
        Assertions.assertTrue(mockUser.isUWLead());
        Assertions.assertTrue(mockUser.isDocViewer());
        Assertions.assertTrue(mockUser.isMopsDataEntry());
        Assertions.assertEquals("test user", mockUser.getUsername());
        Assertions.assertEquals("test", mockUser.getRacfID());
    }

    @Test
    void testSetMultiGroupMockUser2(){
        MockUsersRequest mockUsersRequest = getMockUsersRequest();
        mockUsersRequest.setIsUWUser(false);
        mockUsersRequest.setIsUWLead(false);
        mockUsersRequest.setUsername(null);
        mockUsersRequest.setRacfID(null);

        userMockService.setMultiGroupMockUser(mockUsersRequest);
        UserInformationResponse mockUser = userMockService.getMockUser();
        Assertions.assertFalse(mockUser.isUWUser());
        Assertions.assertTrue(mockUser.isMCCUser());
        Assertions.assertTrue(mockUser.isMopsUser());
        Assertions.assertFalse(mockUser.isUWLead());
        Assertions.assertTrue(mockUser.isDocViewer());
        Assertions.assertTrue(mockUser.isMopsDataEntry());
        Assertions.assertNull(mockUser.getUsername());
        Assertions.assertNull(mockUser.getRacfID());
    }

    @Test
    void testSetMultiGroupMockUser400() throws Exception {
        MockUsersRequest mockUsersRequest = getMockUsersRequest();
        mockUsersRequest.setIsUWUser(null);
        mockUsersRequest.setIsMopsUser(null);
        mockUsersRequest.setIsMCCUser(null);
        mockUsersRequest.setIsUWLead(null);

        MvcResult result = mockMvc.perform(post("/enableMockUsers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(mockUsersRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
    }
}
