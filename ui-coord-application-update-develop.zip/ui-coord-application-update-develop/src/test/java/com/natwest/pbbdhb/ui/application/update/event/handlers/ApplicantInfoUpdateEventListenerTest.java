package com.natwest.pbbdhb.ui.application.update.event.handlers;


import com.natwest.pbbdhb.ui.application.update.events.ApplicantInfoUpdateEvent;
import com.natwest.pbbdhb.ui.application.update.events.handlers.ApplicantInfoUpdateEventListener;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createApplicationInformationUpdateResponse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class ApplicantInfoUpdateEventListenerTest {

    @InjectMocks
    private ApplicantInfoUpdateEventListener applicantInfoUpdateEventListener;

    @Mock
    private ApplicationUpdateService applicationUpdateService;

    @Test
    void onApplicantInfoUpdateEventTest() {
        ApplicantInfoUpdateEvent request = ApplicantInfoUpdateEvent.builder()
                .caseId("caseId")
                .mobileNumber("01234567891")
                .brand("NWB")
                .emailAddress("abc@mail.com")
                .build();


        applicantInfoUpdateEventListener.onApplicantInfoUpdateEvent(request);
        verify(applicationUpdateService).updateApplicationInformation(any(),any(),any(),any());
    }
}
