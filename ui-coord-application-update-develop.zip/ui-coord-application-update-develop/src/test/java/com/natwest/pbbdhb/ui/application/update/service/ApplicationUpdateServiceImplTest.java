package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStatus;
import com.natwest.pbbdhb.income.expense.model.enums.ValidateCaseStatus;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.impl.ApplicationUpdateServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.json.JsonPatch;
import java.io.IOException;
import java.text.ParseException;
import java.util.Objects;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.FI_STATUS_UPDATE_RESPONSE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.REQUEST_REMINDER_RESPONSE;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ApplicationUpdateServiceImplTest {

    private static String REFERENCE_NUMBER = "84153756";
    private static String REQUEST_ID = "12341234";

    @InjectMocks
    private ApplicationUpdateServiceImpl service;

    @Mock
    private TaskService taskService;

    @Mock
    private NoteService noteService;

    @Mock
    private FIService fiService;

    @Mock
    private DocumentReminderService reminderService;

    @Mock
    private ApplicationService applicationService;

    @Mock
    private DocumentUploadService documentUploadService;

    @Mock
    private DocumentNotesService documentNotesService;


    @Mock
    private PropertyService propertyService;

    @Mock
    private ApplicantService applicantService;

    @Mock
    private CaseService caseService;

    @Mock
    private IncomeExpenseService incomeExpenseService;

    @Mock
    private  ApplicationEventPublisher eventPublisher;

    @Mock
    private  MopsDocumentUploadService mopsDocumentUploadService;

    @Mock
    private ManualKeyInCaseUpdateService manualKeyInCaseUpdateService;

    @Mock
    private TeleMessageRequestService teleMessageRequestService;

    @Mock
    private BasicPackagingService basicPackagingService;

    @Mock
    private StpOutcomeService stpOutcomeService;

    @Test
    void testAddTasks() throws ParseException {
        TaskRequest Taskrequest = createTaskRequest();
        when(taskService.addTask(NWB_BRAND,Taskrequest)).thenReturn(ADD_TASK_RESPONSE);
        String response = service.addTask(NWB_BRAND,Taskrequest);
        assertTrue(StringUtils.contains(response, ADD_TASK_RESPONSE));
    }

    @Test
    void testCloseTask() throws ParseException {
        CloseTaskRequest taskRequest = createCloseTaskRequest();
        when(taskService.closeTask(NWB_BRAND,taskRequest)).thenReturn(CLOSE_TASK_RESPONSE);
        String response = service.closeTask(NWB_BRAND,taskRequest);
        assertEquals(CLOSE_TASK_RESPONSE,response);
    }

    @Test
    void testAddNote() throws ParseException {
        NoteRequest noteRequest = getNoteRequest();
        when(noteService.addNote(NWB_BRAND,noteRequest)).thenReturn(ADD_NOTE_RESPONSE);
        String response = service.addNote(NWB_BRAND,noteRequest);
        assertTrue(StringUtils.contains(response, ADD_NOTE_RESPONSE));
    }

    @Test
    void testAddFI() {
        FIRequest fiRequest = createFIRequest();
        when(fiService.addFI(anyString(),anyString(),any(),any())).thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().message(ADD_FI_RESPONSE).build(), OK));
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND,"84153756",null,fiRequest);
        assertTrue(StringUtils.contains(Objects.requireNonNull(response.getBody()).getMessage(), ADD_FI_RESPONSE));
    }

    @Test
    void testSendReminder() {
        DocumentReminder reminder = createDocumentReminder();
        when(reminderService.sendReminder(NWB_BRAND, reminder, REFERENCE_NUMBER, null))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), OK));
        ResponseEntity<SuccessResponse> response = service.sendReminder(NWB_BRAND, reminder, REFERENCE_NUMBER, null);
        assertTrue(Objects.nonNull(response.getBody()) && StringUtils.contains(response.getBody().getSuccessMessage(), REQUEST_REMINDER_RESPONSE));
    }

    @Test
    void testUpdateFIStatus() {
        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        when(fiService.updateFIState(anyString(),any(),anyString(),any(),anyString(), anyString())).thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));
        ResponseEntity<SuccessResponse> response = service.updateFIState(NWB_BRAND,fiStatusRequest,"84153756", null,"TEST123456789", "REVIEWED");
        assertTrue(Objects.nonNull(response.getBody()) && StringUtils.contains(response.getBody().getSuccessMessage(), FI_STATUS_UPDATE_RESPONSE));
    }

    @Test
    void testUpdateApplicationInformation() {
        ApplicationInformationUpdateRequest request = createApplicationInformationUpdateRequest();
        when(applicationService.updateApplicationInformation(anyString(), any(),anyString(), any()))
                .thenReturn(new ResponseEntity<>(createApplicationInformationUpdateResponse(), OK));
        service.updateApplicationInformation(NWB_BRAND, request, "80132415",null);
        verify(applicationService).updateApplicationInformation(anyString(), any(),anyString(),any());
    }

    @Test
    void testUploadDocument() throws IOException {
        DocumentRequest documentRequest = createDocumentRequest();
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(documentUploadService.uploadDocument(anyString(), any(),anyString(), any()))
                .thenReturn(uploadResponseDto);
        service.uploadDocument(NWB_BRAND, null,"80132415", documentRequest);
        verify(documentUploadService).uploadDocument(anyString(), any(),anyString(),any());
    }

    @Test
    void testAddDocumentRequestNotes() {
        DocumentNotesRequest request = createDocumentNotesRequest();
        when(documentNotesService.addDocumentRequestNotes(anyString(), any(),any(), any()))
                .thenReturn(new ResponseEntity<>(SuccessResponse.builder().build(), OK));
        service.addDocumentRequestNotes(NWB_BRAND, "80132415",null, request);
        verify(documentNotesService).addDocumentRequestNotes(anyString(), any(),any(),any());
    }


    @Test
    void testUpdatePropertyDetails() {
        PropertyDetailsDto request = PropertyDetailsDto.builder().build();
        when(propertyService.updatePropertyInformation(anyString(), anyString(), any()))
                .thenReturn(Mockito.mock(PropertyDetailsDto.class));
        service.updatePropertyInformation(NWB_BRAND, "CASE220222105061932438", request);
        verify(propertyService).updatePropertyInformation(anyString(), anyString(), any());
    }


    @Test
    void testUpdateApplicants(){
        ApplicantDto applicantDto = ApplicantDto.builder().build();
        applicantDto.setMainApplicant(true);
        applicantDto.setPersonalDetails(getPersonDetailsDto());
        applicantDto.setCaseId(CASE_ID);
        ApplicationInformationUpdateRequest updateRequest = ApplicationInformationUpdateRequest.builder().build();

        when(applicantService.updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto)).thenReturn(new
                ResponseEntity<>(applicantDto, OK));


        service.updateApplicants(NWB_BRAND, APPLICANT_ID, CASE_ID, applicantDto);
        verify(applicantService).updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void testUpdateApplicants2(){
        ApplicantDto applicantDto = ApplicantDto.builder().build();
        applicantDto.setMainApplicant(true);
        applicantDto.setPersonalDetails(PersonDetailsDto.builder().build());
        applicantDto.setCaseId(CASE_ID);
        ApplicationInformationUpdateRequest updateRequest = ApplicationInformationUpdateRequest.builder().build();

        when(applicantService.updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto)).thenReturn(new
                ResponseEntity<>(applicantDto, OK));

        service.updateApplicants(NWB_BRAND, APPLICANT_ID, CASE_ID, applicantDto);
        verify(applicantService).updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void testUpdateApplicantsSuccess(){
        ApplicantDto applicantDto = ApplicantDto.builder().build();
        applicantDto.setMainApplicant(true);
        applicantDto.setPersonalDetails(getPersonDetailsDto());
        applicantDto.setCaseId(CASE_ID);
        ApplicationInformationUpdateRequest updateRequest = ApplicationInformationUpdateRequest.builder().build();

        when(applicantService.updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto)).thenReturn(new
                ResponseEntity<>(applicantDto, OK));

        ResponseEntity<ApplicantDto> responseEntity = service.updateApplicants(NWB_BRAND, APPLICANT_ID, CASE_ID, applicantDto);

        assertEquals(OK.value(), responseEntity.getStatusCodeValue());
        verify(applicantService).updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void testUpdateApplicantsException2(){
        ApplicantDto applicantDto = ApplicantDto.builder().build();

        PreConditionFailedException exception = assertThrows(PreConditionFailedException.class,
                            () -> service.updateApplicants(NWB_BRAND, APPLICANT_ID, CASE_ID, applicantDto));

        assertEquals("CaseId should be same", getErrorMap().get(exception.getMessage()));
        verifyNoMoreInteractions(applicantService);
        verifyNoMoreInteractions(applicationService);
    }

    @Test
    void testUpdateCase() {
        when(caseService.updateCaseInformation(any(), any(), any())).thenReturn(CaseApplicationDto.builder().build());
        service.updateCaseInformation(NWB_BRAND, CASE_ID, Mockito.mock(JsonPatch.class));
        verify(caseService).updateCaseInformation(any(), any(), any());
    }

    @Test
    void testPatchUpdatePropertyInformation() {
        when(propertyService.patchUpdatePropertyInformation(any(), any(), any())).thenReturn(PropertyDetailsDto.builder().build());
        service.patchUpdatePropertyInformation(NWB_BRAND, CASE_ID, Mockito.mock(JsonPatch.class));
        verify(propertyService).patchUpdatePropertyInformation(any(), any(), any());
    }


    @Test
    void testPatchApplicantUpdate() {
        when(applicantService.patchApplicantUpdate(any(), any(),any(), any())).thenReturn(ApplicantDto.builder().build());
        service.patchApplicantUpdate(NWB_BRAND,CASE_ID,APPLICANT_ID, Mockito.mock(JsonPatch.class));
        verify(applicantService).patchApplicantUpdate(any(), any(),any(), any());
        verifyNoInteractions(eventPublisher);
    }

    @Test
    void testSaveAndValidateIncomeData() {
        when(incomeExpenseService.saveAndValidateIncomeData(any(), any(),any())).thenReturn(ValidatedCaseIncomeDto.builder().build());
        service.saveAndValidateIncomeData(any(), any(),any());
        verify(incomeExpenseService).saveAndValidateIncomeData(any(), any(),any());
    }

    @Test
    void testSaveAndValidateExpenseData() {
        when(incomeExpenseService.saveAndValidateExpenseData(any(), any(),any())).thenReturn(ValidatedCaseExpenseDto.builder().build());
        service.saveAndValidateExpenseData(any(), any(),any());
        verify(incomeExpenseService).saveAndValidateExpenseData(any(), any(),any());
    }

    @Test
    void testUploadSingleDocument() throws IOException {
        DocumentUploadRequest documentUploadRequest = createDocumentUploadRequest();
        DocumentUploadResponseDto uploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        when(mopsDocumentUploadService.uploadSingleDocument(documentUploadRequest))
                .thenReturn(uploadResponseDto);
        service.uploadSingleDocument(documentUploadRequest);
        verify(mopsDocumentUploadService).uploadSingleDocument(any());
    }

    @Test
    void testMarkExpenseValidated()  {
        CaseStatusDto request = CaseStatusDto.builder().status(ValidateCaseStatus.VALIDATED).build();
        ValidatedCaseExpenseDto response = ValidatedCaseExpenseDto.builder().status(CaseStatus.VALIDATED).build();
        when(incomeExpenseService.markExpenseValidated(NWB_BRAND,"caseId",request))
                .thenReturn(response);
        service.markExpenseValidated(NWB_BRAND,"caseId",request);
        verify(incomeExpenseService).markExpenseValidated(any(),any(),any());
    }

    @Test
    void testMarkIncomeValidated()  {
        CaseStatusDto request = CaseStatusDto.builder().status(ValidateCaseStatus.VALIDATED).build();
        ValidatedCaseIncomeDto response = ValidatedCaseIncomeDto.builder().status(CaseStatus.VALIDATED).build();
        when(incomeExpenseService.markIncomeValidated(NWB_BRAND,"caseId",request))
                .thenReturn(response);
        service.markIncomeValidated(NWB_BRAND,"caseId",request);
        verify(incomeExpenseService).markIncomeValidated(any(),any(),any());
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCases() {
        ManualKeyInCaseUpdateRequest request = ManualKeyInCaseUpdateRequest.builder().build();
        when(manualKeyInCaseUpdateService.updateApplicationDataForManualKeyInCases(NWB_BRAND, "CBRKMCCONGAR1662898898686",
                "CB1662898888776", request)).thenReturn(SuccessResponse.builder().build());
        service.updateApplicationDataForManualKeyInCases(NWB_BRAND, "CBRKMCCONGAR1662898898686", "CB1662898888776", request);
        verify(manualKeyInCaseUpdateService).updateApplicationDataForManualKeyInCases(anyString(), anyString(), anyString(), any());
    }

    @Test
    void testAddTeleMessageRequest() {
        AddTeleMessageRequest request = AddTeleMessageRequest.builder().build();
        when(teleMessageRequestService.addTeleMessageRequest(NWB_BRAND, "CBRKMCCONGAR1662898898686", request))
                .thenReturn(SuccessResponse.builder().build());
        service.addTeleMessageRequest(NWB_BRAND, "CBRKMCCONGAR1662898898686", request);
        verify(teleMessageRequestService).addTeleMessageRequest(anyString(), anyString(), any());
    }

    @Test
    void testAddBasicPackagingRequests() {
        when(basicPackagingService.addBasicPackagingRequests(NWB_BRAND, "CBRKMCCONGAR1662898898686"))
                .thenReturn(new ResponseEntity<>(BasicPackagingDocumentResponse.builder().build(), CREATED));
        service.addBasicPackagingRequests(NWB_BRAND, "CBRKMCCONGAR1662898898686");
        verify(basicPackagingService).addBasicPackagingRequests(anyString(), anyString());
    }

    @Test
    void testTransferCase() {
        when(stpOutcomeService.transferCase(NWB_BRAND, CaseTransferRequest.builder().build(), "Case12345678"))
                .thenReturn(SuccessResponse.builder().build());
        service.transferCase(NWB_BRAND, CaseTransferRequest.builder().build(), "Case12345678");
        verify(stpOutcomeService).transferCase(NWB_BRAND, CaseTransferRequest.builder().build(), "Case12345678");
    }

}