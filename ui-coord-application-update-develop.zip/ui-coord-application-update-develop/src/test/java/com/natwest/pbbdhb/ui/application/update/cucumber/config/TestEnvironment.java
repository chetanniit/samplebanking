package com.natwest.pbbdhb.ui.application.update.cucumber.config;

import lombok.Getter;

@Getter
public enum TestEnvironment {
    DEV(false, "https://ui-spa-post-submission-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-sit.web.rbsgrp.mde/as/token.oauth2",
            "https://iaglz08s01d.api.banksvcs.net/hbo-v1-ui-application-update-dev/mortgages/v1/ui-application-update/"),
    SIT(true,
            "https://ui-spa-post-submission-sit-static.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-sit.web.rbsgrp.mde/as/authorization.oauth2",
            "https://iaglz08s01d.api.banksvcs.net/hbo-v1-ui-application-update-sit/mortgages/v1/ui-application-update/"),
    UAT(true, "https://ui-spa-post-submission-uat-static.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-sit.web.rbsgrp.mde/as/authorization.oauth2",
            "https://iaglz08s01s.api.banksvcs.net/hboapiplatform-v1-ui-application-update-uat/mortgages/v1/ui-application-update/"),
    NFT(true, "https://ui-spa-post-submission-nft-static.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-nft.web.rbsgrp.mde/as/authorization.oauth2",
            "https://iaglz08s01s.api.banksvcs.net/hboapiplatform-v1-ui-application-update-nft/mortgages/v1/ui-application-update/"),
    ATDEV(false, "https://ui-spa-post-submission-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-sit.web.rbsgrp.mde/as/token.oauth2",
            "https://iaglz08s01d.api.banksvcs.net/hbo-v1-ui-application-tracking-dev/mortgages/v1/ui-application-tracking/"),
    ATSIT(true,  "https://ui-spa-post-submission-sit-static.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-sit.web.rbsgrp.mde/as/authorization.oauth2",
            "https://iaglz08s01d.api.banksvcs.net/hbo-v1-ui-application-tracking-sit/mortgages/v1/ui-application-tracking/"),
    ATUAT(true, "https://ui-spa-post-submission-uat-static.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-sit.web.rbsgrp.mde/as/authorization.oauth2",
            "https://iaglz08s01s.api.banksvcs.net/hboapiplatform-v1-ui-application-tracking-uat/mortgages/v1/ui-application-tracking/"),
    ATNFT(true, "https://ui-spa-post-submission-nft-static.edi01-apps.dev-pcf.lb4.rbsgrp.net/",
            "https://pfz7-staffiam-backchannel-nft.web.rbsgrp.mde/as/authorization.oauth2",
            "https://iaglz08s01s.api.banksvcs.net/hbo-v1-ui-application-tracking-nft/mortgages/v1/ui-application-tracking/");


    private Boolean isAuthEnabled;
    private String redirectUri;
    private String iamUrl;
    private String tykUrl;

    TestEnvironment(Boolean isAuthEnabled, String redirectUri, String iamUrl, String tykUrl) {
        this.isAuthEnabled = isAuthEnabled;
        this.redirectUri = redirectUri;
        this.iamUrl = iamUrl;
        this.tykUrl = tykUrl;
    }
}
