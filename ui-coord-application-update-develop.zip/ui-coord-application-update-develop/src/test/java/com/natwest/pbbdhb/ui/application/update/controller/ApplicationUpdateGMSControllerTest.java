package com.natwest.pbbdhb.ui.application.update.controller;

import com.natwest.pbbdhb.ui.application.update.model.dto.enums.ApplicationIdType;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.APPLICATION_ID_TYPE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.CHANNEL_ID;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = ApplicationUpdateGMSController.class, properties = {"spring.profiles.active=test"})
@DisplayName("ApplicationUpdateGMSController - MVC Test")
class ApplicationUpdateGMSControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockBean
    private ApplicationUpdateService applicationUpdateService;

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Mockito.doReturn(true).when(authorizationServiceImpl).isUWUser();
    }

    @Test
    void testAddTask() throws Exception {

        TaskRequest Taskrequest = createTaskRequest();
        when(applicationUpdateService.addTask(NWB_BRAND,Taskrequest)).thenReturn(ADD_TASK_RESPONSE);

        MvcResult result = mockMvc.perform(post("/addTask")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(Taskrequest)))
                .andExpect(status().isCreated())
                .andReturn();
        assertEquals(201, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddTaskInvalidBrand() throws Exception {

        TaskRequest request = createTaskRequest();

        MvcResult result = mockMvc.perform(post("/addTask")
                .header(BRAND, INVALID_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddTaskInvalidTaskRequest() throws Exception {

        TaskRequest request = createInvalidTaskRequest();

        MvcResult result = mockMvc.perform(post("/addTask")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddTaskInvalidTaskNoteRequest() throws Exception {

        TaskRequest request = createInvalidTaskNoteRequest();

        MvcResult result = mockMvc.perform(post("/addTask")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testCloseTask() throws Exception {

        CloseTaskRequest taskRequest = createCloseTaskRequest();
        when(applicationUpdateService.closeTask(NWB_BRAND,taskRequest)).thenReturn(CLOSE_TASK_RESPONSE);

        MvcResult result = mockMvc.perform(put("/closeTask")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(taskRequest)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testCloseTaskBadRequest() throws Exception {

        CloseTaskRequest taskRequest = createCloseTaskInvalidRequest();

        MvcResult result = mockMvc.perform(put("/closeTask")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(taskRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testCloseTaskInvalidBrand() throws Exception {

        CloseTaskRequest taskRequest = createCloseTaskRequest();

        MvcResult result = mockMvc.perform(put("/closeTask")
                .header(BRAND, INVALID_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(taskRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testCloseTaskListMissingHeader() throws Exception {

        CloseTaskRequest taskRequest = createCloseTaskRequest();
        when(applicationUpdateService.closeTask(NWB_BRAND,taskRequest)).thenReturn(CLOSE_TASK_RESPONSE);

        MvcResult result = mockMvc.perform(put("/closeTask")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(taskRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(400, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddTaskNote() throws Exception {

        TaskRequest Taskrequest = createTaskNoteRequest();
        when(applicationUpdateService.addTask(NWB_BRAND,Taskrequest)).thenReturn(ADD_TASK_RESPONSE);

        MvcResult result = mockMvc.perform(post("/addTask")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(Taskrequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(201, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUploadDocumentsWithCaseId() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
        map.add("applicationId", "89394151");
        map.add(CHANNEL_ID, "BROKER");
        map.add(APPLICATION_ID_TYPE, ApplicationIdType.CASE_ID.name());
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        MockMvc mockMvc = MockMvcBuilders.
                webAppContextSetup(webApplicationContext).build();
        MvcResult mockResult = mockMvc.perform(MockMvcRequestBuilders
                .multipart("/uploadDocument/caseId/89394151")
                .file(file)
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .queryParams(map))
                .andReturn();
        assertNotNull(mockResult.getResponse());

    }

}