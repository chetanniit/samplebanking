package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.exception.TokenExpiredException;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalContext;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class AuthorizationServiceImplTest {

    private static final String SEPARATOR = "_";
    protected static final String MEMBEROF_CLAIM = "clientstaff_wiam02_atm_memberof";
    protected static final String USER_FIRST_NAME = "clientstaff_wiam02_atm_firstname";
    protected static final String USER_LAST_NAME = "clientstaff_wiam02_atm_lastname";

    @InjectMocks
    private AuthorizationServiceImpl service;

    @Mock
    private UserPrincipal principal;

    @BeforeEach
    public void setup(){
        Mockito.doReturn("username").when(principal).getUserName();
        Mockito.doReturn("remoteAddress").when(principal).getRemoteAddress();
        Mockito.doReturn("domain").when(principal).getDomain();
        Mockito.doReturn("name").when(principal).getName();
        Mockito.doReturn(1).when(principal).getAuthenticationLevel();
        Mockito.doReturn(new Date()).when(principal).getSessionExpiry();
        Mockito.doReturn("token").when(principal).getToken();
    }

    @Test
    void testUserTokenExpired() {
        ReflectionTestUtils.setField(service, "jwtTokenUtilCN", "test");
        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            Assertions.assertThrows(TokenExpiredException.class, () -> service.getUserData());
        }
    }

    @Test
    void testUserValid() {
        ReflectionTestUtils.setField(service, "jwtTokenUtilCN", "rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility");
        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            LocalDate date = LocalDate.now().minusDays(-1);
            Mockito.doReturn(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())).when(principal).getSessionExpiry();
            UserInformationResponse userData = service.getUserData();
            Assertions.assertNotNull(userData.getRacfID());
        }
    }

    @Test
    void testUserPrincipalNotFound() {
        ReflectionTestUtils.setField(service, "userCheck", true);

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(null);
            Assertions.assertThrows(UsernameNotFoundException.class, () -> service.getUserData());
        }
    }

    @Test
    void testNoUserCheck() {
        ReflectionTestUtils.setField(service, "userCheck", false);

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            boolean isValid = service.isUWUser();
            assertTrue(isValid);
        }
    }


    @Test
    void testIsMopsUser() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "mopsUserGroup", "HBOPostSub-MOPSTeam");

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn("HBOPostSub-MOPSTeam");
            boolean isValid = service.isMopsUser();
            assertTrue(isValid);
        }
    }

    @Test
    void testIsUWUser() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "uwUserGroup", "HBOPostSub-UWTeam");

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn("HBOPostSub-UWTeam");
            boolean isValid = service.isUWUser();
            assertTrue(isValid);
        }
    }

    @Test
    void testIsUWUserHasNoMemberOfClaim() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "uwUserGroup", "HBOPostSub-UWTeam");

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn(null);
            boolean isValid = service.isUWUser();
            assertFalse(isValid);
        }
    }

    @Test
    void testIsUWUserHasNoUserGroup() {
        ReflectionTestUtils.setField(service, "userCheck", true);

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn("HBOPostSub-UWTeam");
            boolean isValid = service.isUWUser();
            assertFalse(isValid);
        }
    }

    @Test
    void testIsUWUserHasNoUserGroupAndClaim() {
        ReflectionTestUtils.setField(service, "userCheck", true);

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn(null);
            boolean isValid = service.isUWUser();
            assertFalse(isValid);
        }
    }


    @Test
    void testIsMCCUser() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "mccUserGroup", "HBOPostSub-MCCTeam");

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn("HBOPostSub-MCCTeam");
            boolean isValid = service.isMCCUser();
            assertTrue(isValid);
        }
    }

    @Test
    void testNonUWUser() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "uwUserGroup", "HBOPostSub-MCCTeam");

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn("HBOPostSub-UWTeam");
            boolean isValid = service.isUWUser();
            assertFalse(isValid);
        }
    }

    @Test
    void testGetUserName() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "uwUserGroup", "HBOPostSub-MCCTeam");

        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(USER_FIRST_NAME)).thenReturn("Walter");
            when(principal.getProperty(USER_LAST_NAME)).thenReturn("Tester");

            String username = service.getUsername();
            assertEquals("Walter Tester", username);
        }
    }

    @Test
    void testIsDevTestUser() {
        // when API call from non prod and using util token
        ReflectionTestUtils.setField(service, "currentProfile", "uat");
        ReflectionTestUtils.setField(service, "jwtTokenUtilCN", "rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility");
        Mockito.doReturn("rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility").when(principal).getUserName();
        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            LocalDate date = LocalDate.now().minusDays(-1);
            Mockito.doReturn(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())).when(principal).getSessionExpiry();
            Assertions.assertTrue(service.isDevTestUser());
        }
    }

    @Test
    void testIsDevTestUserForPRD() {
        // when API call from prod and using util token
        ReflectionTestUtils.setField(service, "currentProfile", "prd");
        ReflectionTestUtils.setField(service, "jwtTokenUtilCN", "rbsg.hboapiplatform.prd.msvc-ms2ms-jwt-chain-utility");
        Mockito.doReturn("rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility").when(principal).getUserName();
        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            LocalDate date = LocalDate.now().minusDays(-1);
            Mockito.doReturn(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())).when(principal).getSessionExpiry();
            Assertions.assertFalse(service.isDevTestUser());
        }
    }

    @Test
    void testIsDevTestUserNegativeCase() {
        // when API call from non prod and not using util token
        ReflectionTestUtils.setField(service, "currentProfile", "uat");
        validateTestUser();
    }

    @Test
    void testIsDevTestUserNegativeCase1() {
        // when API call from prod and not using util token
        ReflectionTestUtils.setField(service, "currentProfile", "prd");
        validateTestUser();
    }

    @Test
    void testUserDataForUtilToken() {
        ReflectionTestUtils.setField(service, "currentProfile", "uat");
        ReflectionTestUtils.setField(service, "jwtTokenUtilCN", "rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility");
        Mockito.doReturn("rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility").when(principal).getUserName();
        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            LocalDate date = LocalDate.now().minusDays(-1);
            Mockito.doReturn(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())).when(principal).getSessionExpiry();
            UserInformationResponse userData = service.getUserData();
            Assertions.assertNotNull(userData.getRacfID());
        }
    }

    private void validateTestUser() {
        ReflectionTestUtils.setField(service, "jwtTokenUtilCN", "rbsg.hboapiplatform.uat.msvc-ms2ms-jwt-chain-utility");
        Mockito.doReturn("dummy").when(principal).getUserName();
        try (MockedStatic<UserPrincipalContext> context = Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            LocalDate date = LocalDate.now().minusDays(-1);
            Mockito.doReturn(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())).when(principal).getSessionExpiry();
            Assertions.assertFalse(service.isDevTestUser());
        }
    }

    @Test
    void testIsUWLead() {
        ReflectionTestUtils.setField(service, "userCheck", true);
        ReflectionTestUtils.setField(service, "uwLeadGroup", "HBOPostSub-UWLeads");

        try (MockedStatic<UserPrincipalContext> context =
                     Mockito.mockStatic(UserPrincipalContext.class)) {
            context.when(UserPrincipalContext::get).thenReturn(principal);
            when(principal.getProperty(MEMBEROF_CLAIM)).thenReturn("HBOPostSub-UWLeads");
            boolean isValid = service.isUWLead();
            assertTrue(isValid);
            isValid = service.isUWUser();
            assertTrue(isValid);
        }
    }
}