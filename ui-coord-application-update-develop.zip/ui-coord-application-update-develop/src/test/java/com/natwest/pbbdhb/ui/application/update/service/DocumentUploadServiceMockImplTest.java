package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.service.impl.DocumentUploadServiceMockImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createDocumentRequest;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class DocumentUploadServiceMockImplTest {

    @InjectMocks
    DocumentUploadServiceMockImpl service;

    @Test
    void testDocumentUploadWithReferenceNumber() throws IOException {
        service.uploadDocument("NWB", null, "88920823", createDocumentRequest());
        assertTrue(true);
    }

    @Test
    void testDocumentUploadWithCaseId() throws IOException {
        service.uploadDocument("NWB", "88920823", null, createDocumentRequest());
        assertTrue(true);
    }
}
