package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.service.impl.MopsDocumentUploadServiceMockImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createDocumentUploadRequest;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class MopsDocumentUploadServiceMockImplTest {

    @InjectMocks
    MopsDocumentUploadServiceMockImpl service;

    @Test
    void testDocumentUpload() throws IOException {
        service.uploadSingleDocument(createDocumentUploadRequest());
        assertTrue(true);
    }
}
