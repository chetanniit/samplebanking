package com.natwest.pbbdhb.ui.application.update.mapper;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class PropertyDetailsDtoMapperTest {

    @InjectMocks
    private PropertyDetailsDtoMapperImpl mapper;

    @Test
    void TestToPropertyDetailsDto(){
        PropertyDetailsDto propertyDetailsDto = PropertyDetailsDto.builder()
                .whenBuilt("2022")
                .build();
        PropertyDetailsDto output = mapper.toPropertyDetailsDto(propertyDetailsDto);

        assertNotNull(output);
        assertEquals("2022-01-01",output.getWhenBuilt());
    }
}
