package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.POST_TELE_MESSAGE_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PostTeleMessageReferenceNumberStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(POST_TELE_MESSAGE_JSON);
    }

    @Given("telemessage referencenumber endpoint exists")
    public void telemessageReferencenumberEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request to telemessage referencenumber using input {string} and verify response code")
    public void userSendsRequestToTelemessageReferencenumberUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Verify error message if user not send documentIdentifier {string}")
    public void verifyErrorMessageIfUserNotSendDocumentIdentifier(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify error message if user not send category {string}")
    public void verifyErrorMessageIfUserNotSendCategory(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify error message if user send more than hundred chars for callerInfo {string}")
    public void verifyErrorMessageIfUserSendMoreThanHundredCharsForCallerInfo(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify error message if user send more than three thousand five hundred chars for callReason {string}")
    public void verifyErrorMessageIfUserSendMoreThanThreeThousandFiveHundredCharsForCallReason(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify error message if user not send date {string}")
    public void verifyErrorMessageIfUserNotSendDate(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
}
