package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberConfigReader;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.stream.StreamSupport;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.UPLOAD_DOC_INPUT_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static io.restassured.RestAssured.given;
import static org.apache.http.params.CoreConnectionPNames.CONNECTION_TIMEOUT;
import static org.apache.http.params.CoreConnectionPNames.SO_TIMEOUT;

@Slf4j
public class PostUploadDocReferenceNumberStepDefs
{
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;
    private static FileBasedConfiguration prop = CucumberConfigReader.readProperties();

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(UPLOAD_DOC_INPUT_JSON);
    }

    @Given("Upload Doc endpoint exists")
    public void uploadDocEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request to upload doc using input {string} and verify response code")
    public void userSendsRequestToUploadDocUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        int CONNECTION_TIMEOUT_MS = 600000;

        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header(MULTIPART_CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .basePath(inputsAsJsonNode.get(PATH).asText());
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        setInputFiles(request, testInput.get(FORM_DATA).get(FILES));
        long start = System.currentTimeMillis();
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        long end1 = System.currentTimeMillis();
        response = response.then().extract().response();
        long end2 = System.currentTimeMillis();
        System.out.println("First request ctin:"+(end1-start));
        System.out.println("Second request ctin:"+(end2-end1));
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    private void setInputFiles(RequestSpecification request,JsonNode files) {
        StreamSupport.stream(files.spliterator(), false).forEach(file -> {
            Assertions.assertNotNull(file,"filename is missing");
            Assertions.assertFalse(StringUtils.isEmpty(file.asText()),"filename is missing");
            String fileType = getFileType(file.asText());
            request.multiPart("files", new File(MEDIA_FILES + file.asText()),fileType);
        });
    }

    private String getFileType(String file) {

        if(file.toUpperCase().endsWith("PNG")){
            return APPLICATION_PNG;
        }
        else if(file.toUpperCase().endsWith("DOC"))
        {
            return APPLICATION_WORD_DOC;
        }
        else if(file.toUpperCase().endsWith("JPEG"))
        {
            return APPLICATION_JPEG;
        }
        else if(file.toUpperCase().endsWith("JPG"))
        {
            return APPLICATION_JPEG;
        }
        else if(file.toUpperCase().endsWith("PPT"))
        {
            return APPLICATION_PPT;
        }
        else if(file.toUpperCase().endsWith("ZIP"))
        {
            return APPLICATION_ZIP;
        }
        else if(file.toUpperCase().endsWith("XLSX"))
        {
            return APPLICATION_XLS;
        }
        return APPLICATION_PDF;
    }

    @Then("Verify the document id in response using input {string}")
    public void verifyTheDocumentIdInResponseUsingInput(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode responseFiles =responseJsonNode.get("successfulUploads");
        JsonNode files = inputs.get(FORM_DATA).get(FILES);
        StreamSupport.stream(responseFiles.spliterator(), false).forEach(responseFile -> {
            long fileCount = StreamSupport.stream(files.spliterator(), false).filter(file -> file.asText()
                    .equals(responseFile.get(ORIGINAL_FILE_NAME).asText())).count();
            Assert.assertEquals(1,fileCount);
            Assert.assertNotNull(responseFile.get(DOCUMENT_ID));
        });
    }

    @Then("Verify partial uploads succeeded for the input {string}")
    public void verifyPartialUploadsSucceededForTheInput(String inputName) {
        Assert.assertTrue(responseJsonNode.has("unsuccessfulUploads"));
        Assert.assertTrue(responseJsonNode.has("successfulUploads"));
    }

    @Then("Verify the unsupported media type")
    public void verifyTheUnsupportedMediaType() {
        Assert.assertEquals("HTTP/1.1 415 Unsupported Media Type",response.getStatusLine().trim());
    }

    @Then("Verify the bad request error message using input {string}")
    public void verifyTheBadRequestErrorMessageUsingInput(String inputName) {
        validateBadRequest(responseJsonNode,inputName);
    }
    private void validateBadRequest(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] inputErrorMessages = inputs.get(ERROR_MESSAGES).asText().split(",");
        String responseErrorMessages = responseJsonNode.get(ERROR_MESSAGES).toString();
        for (String inputErrorMessage : inputErrorMessages){
            Assert.assertTrue(responseErrorMessages.contains(inputErrorMessage));
        }
    }

    @Then("Verify response code when the request payload is too large")
    public void verifyResponseCodeWhenTheRequestPayloadIsTooLarge() {
    }

    public static long getFileSize(String fileName) {
        File baseFile = new File(MEDIA_FILES + "downloaded//"+fileName);
        return baseFile.length();
    }

    public static void deleteFile(String fileName) {
        File myObj = new File(MEDIA_FILES + "downloaded//"+fileName);
        if (myObj.delete()) {
            log.info("Deleted the file: " + myObj.getName());
        } else {
            log.info("Failed to delete the file.");
        }
    }

    @When("E2E User sends request to get FI for {string} status {string} having state {string} and verify response code for upload doc after {int} seconds")
    public void getFIList(String inputName, String status, String state, int timeOut) throws JsonProcessingException, InterruptedException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode testInput = ((ObjectNode) requestInput);
        testInput.put(RESPONSE_CODE, "200");
        testInput.put(BRAND, inputs.get(BRAND));
        testInput.put(REFERENCE_NUMBER, inputs.get(REFERENCE_NUMBER));
        testInput.put(REQUEST_ID, inputs.get(FORM_DATA).get(REQUEST_ID));
        testInput.put(STATUS,status);
        String GET_PATH = "/application/{referenceNumber}/filist";
        RequestSpecification request = RestAssured.given().when()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput,"AT"))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_PATH);
        for(int iteration=0; iteration <= timeOut; iteration += 5 ) {
            response = request.get(GET_PATH);
            JsonNode responseJsonNode1 = new ObjectMapper().readTree(response.asString());
            Thread.sleep(5000);
            if(responseJsonNode1.get(DOCUMENTS).size() == 0) {
                continue;
            } else {
                if (responseJsonNode1.get(DOCUMENTS).get(0).get(STATUS).asText().equals(status)) {
                    log.info("State reported in about: " + iteration + " seconds");
                    break;
                }
            }
        }
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @Then("E2E Validate that the document for input {string} having state {string} with status {string} for uploaded doc")
    public void verifyDocumentStatusAndState(String inputName, String state, String status) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(inputs.get(REFERENCE_NUMBER).asText(),responseJsonNode.get(REFERENCE_NUMBER).asText());
        Assert.assertEquals(status,responseJsonNode.get(DOCUMENTS).get(0).get(STATUS).asText());
        Assert.assertEquals(state,responseJsonNode.get(DOCUMENTS).get(0).get(STATE).asText());
    }

    @When("E2E Verify the document download is the same like the the uploaded one {string} with timeout of {int} seconds")
    public void test(String inputName, int timeout) throws JsonProcessingException, InterruptedException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        int lastdocumentPosition = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).size() -1;
        String documentId = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(lastdocumentPosition).get(DOCUMENT_ID).asText();
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        String GET_DOCUMENT_PATH = "/application/"+testInput.get(REFERENCE_NUMBER).asText()+"/document/"+documentId;
        String fileName = testInput.get("fileName").asText();
        deleteFile(fileName);

        RequestSpecification request = RestAssured.given().when()
                .headers(CucumberTestProperties.getHeaders(testInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .header(BRAND, testInput.get(BRAND).asText());
        byte[] dowloadedFile = null;
        for(int iteration = 0; iteration <= timeout ; iteration += 5) {
            dowloadedFile = request.get(CucumberTestProperties.getApplicationTrackingURI() + GET_DOCUMENT_PATH)
                    .then().extract().asByteArray();
            if (dowloadedFile.length < 1000) {
                Thread.sleep(5000);
            } else {
                log.info("Downloaded file obtained after: "+iteration+" seconds");
                break;
            }
        }
        try {
            FileOutputStream os = new FileOutputStream(new File(MEDIA_FILES + "downloaded//"+fileName));
            os.write(dowloadedFile);
            os.close();
            File downloadedFile1 = new File(MEDIA_FILES + "downloaded//"+fileName);
            File actualFile = new File(MEDIA_FILES + fileName);
            Assert.assertEquals(getFileSize(fileName), downloadedFile1.length());
            Assert.assertEquals(actualFile.getName(), downloadedFile1.getName());
            log.info("Actual File Size : "+getFileSize(fileName));
            log.info("Download File Size : "+downloadedFile1.length());
            log.info("Actual File Name : "+actualFile.getName());
            log.info("Downloaded File Name : "+downloadedFile1.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @When("E2E Verify the document status in document info object for the input {string} with timeout of {int} seconds")
    public void eEVerifyTheDocumentStatusInDocumentInfoObjectForTheInputWithTimeoutOfSeconds(String inputName, int timeout) throws JsonProcessingException, InterruptedException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        int lastdocumentPosition = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).size() -1;
        String documentId = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(lastdocumentPosition).get(DOCUMENT_ID).asText();
        Assert.assertEquals("AV_SCAN_SUCCESS",responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(lastdocumentPosition).get("documentStatus").asText());
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        String GET_DOCUMENT_PATH = "/application/"+testInput.get(REFERENCE_NUMBER).asText()+"/document/"+documentId;
        String fileName = testInput.get("fileName").asText();
        deleteFile(fileName);

        RequestSpecification request = RestAssured.given().when()
                .headers(CucumberTestProperties.getHeaders(testInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .header(BRAND, testInput.get(BRAND).asText());
        byte[] dowloadedFile = null;
        for(int iteration = 0; iteration <= timeout ; iteration += 5) {
            dowloadedFile = request.get(CucumberTestProperties.getApplicationTrackingURI() + GET_DOCUMENT_PATH)
                    .then().extract().asByteArray();
            if (dowloadedFile.length < 1000) {
                Thread.sleep(5000);
            } else {
                log.info("Downloaded file obtained after: "+iteration+" seconds");
                break;
            }
        }
        try {
            FileOutputStream os = new FileOutputStream(new File(MEDIA_FILES + "downloaded//"+fileName));
            os.write(dowloadedFile);
            os.close();
            File downloadedFile1 = new File(MEDIA_FILES + "downloaded//"+fileName);
            File actualFile = new File(MEDIA_FILES + fileName);
            Assert.assertEquals(getFileSize(fileName), downloadedFile1.length());
            Assert.assertEquals(actualFile.getName(), downloadedFile1.getName());
            log.info("Actual File Size : "+getFileSize(fileName));
            log.info("Download File Size : "+downloadedFile1.length());
            log.info("Actual File Name : "+actualFile.getName());
            log.info("Downloaded File Name : "+downloadedFile1.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

