package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStatus;
import com.natwest.pbbdhb.income.expense.model.enums.ValidateCaseStatus;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInApplicantDetail;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.UnsuccessfulUpload;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseUpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocUploadChannelEnum;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import java.util.Arrays;
import java.util.Collections;

import static com.natwest.pbbdhb.ui.application.update.converter.JsonPatchHttpMessageConverter.JSON_PATCH;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.ADD_NOTE_CREATION_MESSAGE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.CSP_VALUE;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.INVALID_BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NO_CACHE;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = {ApplicationUpdateCaseController.class, CapieUpdateController.class}, properties = {"spring.profiles.active=test"})
@DisplayName("ApplicationUpdateCaseController - MVC Test")
class ApplicationUpdateCaseControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockBean
    private ApplicationUpdateService applicationUpdateService;

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Mockito.doReturn(true).when(authorizationServiceImpl).isUWUser();
    }


    @Test
    void testAddFISuccess() throws Exception {

        FIRequest fiRequest = createFIRequest();

        when(applicationUpdateService.addFI(NWB_BRAND, null, "77665511xo01", fiRequest))
                .thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().build(), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isCreated())
                .andReturn();
        assertEquals(201, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddFIInvalidBrand() throws Exception {

        FIRequest fiRequest = createFIRequest();

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/firequest")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddFIInvalidCaseId() throws Exception {

        FIRequest fiRequest = createFIRequest();

        MvcResult result = mockMvc.perform(post("/application/case/77665511x^o01/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testUploadDocumentBadRequest() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("77665511xo01")
                .files(Arrays.asList(file))
                .build();

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/case/77665511xo01")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(400, mockResult.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);

    }

    @Test
    void testUploadDocument() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("77665511xo01")
                .channel(DocUploadChannelEnum.INTERNET)
                .classificationCode("AIFLIL")
                .files(Collections.singletonList(file))
                .documentType("OTHER")
                .build();

        DocumentUploadResponseDto documentUploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();

        when(applicationUpdateService.uploadDocument(anyString(),anyString(),any(),any())).thenReturn(documentUploadResponseDto);

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/case/77665511xo01")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isOk())
                .andReturn();

        assertNotNull(mockResult.getResponse());
        assertEquals(200, mockResult.getResponse().getStatus());
        DocumentUploadResponseDto response = objectMapper.readValue(mockResult.getResponse().getContentAsByteArray(),
                DocumentUploadResponseDto.class);

        assertEquals("49bffb0f-0353-45ab-b1c3-6e3de471e0a7", response.getSuccessfulUploads().get(0).getDocumentId());
        assertEquals("natwest_logo.jpg", response.getSuccessfulUploads().get(0).getOriginalFileName());

    }

    @Test
    void testSendReminderSuccess() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        when(applicationUpdateService.sendReminder("NWB", reminder, null, "77665511xo01"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), HttpStatus.ACCEPTED));


        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().is(202))
                .andReturn();
        assertEquals(202, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testSendReminderInvalidBrand() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/notification")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testSendReminderForPSTUser() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isMCCUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();

        when(applicationUpdateService.sendReminder("NWB", reminder, null, "77665511xo01"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), HttpStatus.ACCEPTED));


        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().is(202))
                .andReturn();
        assertEquals(202, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testSendReminderForbiddenForNonPSTUser() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isMCCUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();

        when(applicationUpdateService.sendReminder("NWB", reminder, null, "77665511xo01"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), HttpStatus.ACCEPTED));


        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateFIStatusSuccess() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();


        when(applicationUpdateService.updateFIState("NWB",fiStatusRequest,null,"77665511xo01","624aaa874899e7674d47c8d0", "REVIEWED"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/application/case/77665511xo01/firequest/624aaa874899e7674d47c8d0/fistate/Review")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fiStatusRequest)))
                .andExpect(status().is(200))
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testAddNoteInvalidBrand() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/note")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
    }


    @Test
    void testAddNoteWithNullNote() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        documentNotesRequest.setNote(null);

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddNoteWithNullRequestId() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", null, "77665511xo01", documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void testAddNoteInvalidcaseId() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        MvcResult result = mockMvc.perform(post("/application/case/77665511&xo01/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testAddNoteSuccess() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", null, "77665511xo01", documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicationInformation() throws Exception {

        ApplicationInformationUpdateRequest request = ApplicationInformationUpdateRequest.builder().build();
        MvcResult result = mockMvc.perform(patch("/application/case/77665511xo01")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }


    @Test
    void testUpdatePropertyDetails() throws Exception {

        PropertyDetailsDto request = PropertyDetailsDto.builder().build();
        MvcResult result = mockMvc.perform(put("/capie/case/CASE220222105061932438/property")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }


    @Test
    void testUpdateApplicantsSuccess() throws Exception {
        ApplicantDto applicantDtoRequest = ApplicantDto.builder().build();

        when(applicationUpdateService.updateApplicants("NWB", "ABC123", "77665511xo01", applicantDtoRequest))
                .thenReturn(new ResponseEntity<>(applicantDtoRequest, HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/capie/case/77665511xo01/applicants/ABC123")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(applicantDtoRequest)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }


    @Test
    void testUpdatePropertyDetailsInvalidCaseId() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        MvcResult result = mockMvc.perform(put("/capie/case/77665511&xo01/property")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    void testUpdatePropertyDetailsInvalidBrand() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        MvcResult result = mockMvc.perform(put("/capie/77665511&xo01/property")
                        .header(BRAND, "NWB1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicantsFailure() throws Exception {
        ApplicantDto applicantDtoRequest = ApplicantDto.builder().build();

        when(applicationUpdateService.updateApplicants("NWB", "ABC123", "77665511xo01", applicantDtoRequest))
                .thenReturn(new ResponseEntity<>(applicantDtoRequest, HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/capie/case/77665511xo01/applicants/ABC123")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(applicantDtoRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testUpdateCaseFailure() throws Exception {
        CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().build();

        when(applicationUpdateService.updateApplicationInformation("NWB",caseApplicationDto, "77665511xo01"))
                .thenReturn(new ResponseEntity<>(caseApplicationDto, HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/capie/case/77665511xo01")
                .header(BRAND, INVALID_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(caseApplicationDto)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testUpdateCasesSuccess() throws Exception {
        CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().build();

        when(applicationUpdateService.updateApplicationInformation("NWB",caseApplicationDto, "77665511xo01"))
                .thenReturn(new ResponseEntity<>(caseApplicationDto, HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/capie/case/77665511xo01")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(caseApplicationDto)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }


    @Test
    void testUpdateCaseSuccess() throws Exception {
        String body = "[{\"op\": \"replace\", \"path\": \"/applicationStatus\", \"value\": \"SUBMIT_GMS_MOPS\" }]";
        CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().build();
        when(applicationUpdateService.updateCaseInformation(any(), any(), any()))
                .thenReturn(caseApplicationDto);
        MvcResult result = mockMvc.perform(patch("/capie/case/ID11123456")
                        .header(BRAND, NWB_BRAND)
                        .contentType(JSON_PATCH)
                        .content(body))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testUpdateCaseSuccessJsonException() throws Exception {
        String body = "[{\"op\": \"replace\", \"path\": \"applicationStatus\", \"value\": \"SUBMIT_GMS_MOPS\" }]";
        CaseApplicationDto caseApplicationDto = CaseApplicationDto.builder().build();
        when(applicationUpdateService.updateCaseInformation(any(), any(), any()))
                .thenReturn(caseApplicationDto);
        MvcResult result = mockMvc.perform(patch("/capie/case/ID11123456")
                        .header(BRAND, NWB_BRAND)
                        .contentType(JSON_PATCH)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testPatchUpdatePropertyInformationSuccess() throws Exception {
        String body = "[{\"op\": \"replace\", \"path\": \"/applicationStatus\", \"value\": \"SUBMIT_GMS_MOPS\" }]";
        PropertyDetailsDto propertyDetailsDto = PropertyDetailsDto.builder().build();

        when(applicationUpdateService.patchUpdatePropertyInformation(any(), any(), any())).thenReturn(propertyDetailsDto);

        MvcResult result = mockMvc.perform(patch("/capie/case/ID11123456/property")
                        .header(BRAND, NWB_BRAND)
                        .contentType(JSON_PATCH)
                        .content(body))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testPatchUpdatePropertyInformationJsonException() throws Exception {
        String body = "[{\"op\": \"replace\", \"path\": \"applicationStatus\", \"value\": \"SUBMIT_GMS_MOPS\" }]";
        PropertyDetailsDto propertyDetailsDto = PropertyDetailsDto.builder().build();

        when(applicationUpdateService.patchUpdatePropertyInformation(any(), any(), any())).thenReturn(propertyDetailsDto);

        MvcResult result = mockMvc.perform(patch("/capie/case/ID11123456/property")
                        .header(BRAND, NWB_BRAND)
                        .contentType(JSON_PATCH)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicantByApplicantIdSuccess() throws Exception {
        String body = "[{\"op\": \"replace\", \"path\": \"/kycChannel\", \"value\": \"WEB\" }]";
        ApplicantDto applicantDto = ApplicantDto.builder().build();
        when(applicationUpdateService.patchApplicantUpdate(any(), any(), any(), any()))
                .thenReturn(applicantDto);
        MvcResult result = mockMvc.perform(patch("/capie/case/ID20220221100176521101/applicants/6304e3d3c16157390433c5f0")
                        .header(BRAND, NWB_BRAND)
                        .contentType(JSON_PATCH)
                        .content(body))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicantByApplicantIdException() throws Exception {
        String body = "[{\"op\": \"replace\", \"path\": \"kycChannel\", \"value\": \"WEB\" }]";
        ApplicantDto applicantDto = ApplicantDto.builder().build();
        when(applicationUpdateService.patchApplicantUpdate(any(), any(), any(), any()))
                .thenReturn(applicantDto);
        MvcResult result = mockMvc.perform(patch("/capie/case/ID20220221100176521101/applicants/6304e3d3c16157390433c5f0")
                        .header(BRAND, NWB_BRAND)
                        .contentType(JSON_PATCH)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testSaveAndValidateIncomeDataSuccess() throws Exception {
        CaseIncomeDto caseIncomeDto = getCaseIncomeDto();
        ValidatedCaseIncomeDto validatedCaseIncomeDto = ValidatedCaseIncomeDto.builder().build();

        when(applicationUpdateService.saveAndValidateIncomeData(any(), any(), any())).thenReturn(validatedCaseIncomeDto);
        MvcResult result = mockMvc.perform(put("/capie/case/A202303091006/income")
                        .header(BRAND, NWB_BRAND)
                        .contentType(APPLICATION_JSON)
                        .content(asJsonString(caseIncomeDto)))
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testSaveAndValidateIncomeDataException() throws Exception {
        MvcResult result = mockMvc.perform(put("/capie/case/ID202202211001765211&&/income")
                        .header(BRAND, NWB_BRAND)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testSaveAndValidateIncomeDataInvalidBrand() throws Exception {
        MvcResult result = mockMvc.perform(put("/capie/case/ID202202211001765211/income")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testSaveAndValidateExpenseDataSuccess() throws Exception {
        CaseExpenseDto caseExpenseDto = getCaseExpenseDto();
        ValidatedCaseExpenseDto validatedCaseExpenseDto = ValidatedCaseExpenseDto.builder().build();

        when(applicationUpdateService.saveAndValidateExpenseData(any(), any(), any())).thenReturn(validatedCaseExpenseDto);
        MvcResult result = mockMvc.perform(put("/capie/case/ID20220221100176521101/expense")
                        .header(BRAND, NWB_BRAND)
                        .contentType(APPLICATION_JSON)
                        .content(asJsonString(caseExpenseDto)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testSaveAndValidateExpenseDataException() throws Exception {
        MvcResult result = mockMvc.perform(put("/capie/case/ID202202211001765211&&/expense")
                        .header(BRAND, NWB_BRAND)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testSaveAndValidateExpenseDataInvalidBrand() throws Exception {
        MvcResult result = mockMvc.perform(put("/capie/case/ID202202211001765211/expense")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testUploadDocumentForMultiStatus() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("77665511xo01")
                .channel(DocUploadChannelEnum.INTERNET)
                .files(Arrays.asList(file))
                .documentType("OTHER")
                .build();

        DocumentUploadResponseDto documentUploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        UnsuccessfulUpload unsuccessfulUpload = UnsuccessfulUpload.builder()
                .originalFileName("natwest_logo1.jpg")
                .build();
        documentUploadResponseDto.getUnsuccessfulUploads().add(unsuccessfulUpload);

        when(applicationUpdateService.uploadDocument(anyString(),anyString(),any(),any())).thenReturn(documentUploadResponseDto);

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/case/77665511xo01")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isMultiStatus())
                .andReturn();

        assertNotNull(mockResult.getResponse());
        assertEquals(207, mockResult.getResponse().getStatus());
        DocumentUploadResponseDto response = objectMapper.readValue(mockResult.getResponse().getContentAsByteArray(),
                DocumentUploadResponseDto.class);

        assertEquals("49bffb0f-0353-45ab-b1c3-6e3de471e0a7", response.getSuccessfulUploads().get(0).getDocumentId());
        assertEquals("natwest_logo.jpg", response.getSuccessfulUploads().get(0).getOriginalFileName());

    }

    @Test
    void testExpenseValidationStatusUpdateSuccess() throws Exception {
        CaseStatusDto caseStatusDto = CaseStatusDto.builder()
                .status(ValidateCaseStatus.VALIDATED)
                .build();
        ValidatedCaseExpenseDto validatedCaseExpenseDto = ValidatedCaseExpenseDto.builder()
                .status(CaseStatus.VALIDATED)
                .build();

        when(applicationUpdateService.markExpenseValidated(any(), any(), any())).thenReturn(validatedCaseExpenseDto);
        MvcResult result = mockMvc.perform(patch("/capie/case/ID20220221100176521101/expense")
                        .header(BRAND, NWB_BRAND)
                        .contentType(APPLICATION_JSON)
                        .content(asJsonString(caseStatusDto)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testIncomeValidationStatusUpdateSuccess() throws Exception {
        CaseStatusDto caseStatusDto = CaseStatusDto.builder()
                .status(ValidateCaseStatus.VALIDATED)
                .build();
        ValidatedCaseIncomeDto validatedCaseIncomeDto = ValidatedCaseIncomeDto.builder()
                .status(CaseStatus.VALIDATED)
                .build();

        when(applicationUpdateService.markIncomeValidated(any(), any(), any())).thenReturn(validatedCaseIncomeDto);
        MvcResult result = mockMvc.perform(patch("/capie/case/ID20220221100176521101/income")
                        .header(BRAND, NWB_BRAND)
                        .contentType(APPLICATION_JSON)
                        .content(asJsonString(caseStatusDto)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testUploadDocumentInvalidClassificationCode() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("77665511xo01")
                .channel(DocUploadChannelEnum.INTERNET)
                .classificationCode("AIFLIL!")
                .files(Arrays.asList(file))
                .build();

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/case/77665511xo01")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertNotNull(mockResult.getResponse());
        assertEquals(400, mockResult.getResponse().getStatus());
    }

    @Test
    void testUnauthorisedRoleAccessUpdateApplicationCaseOwner() throws Exception {
        doReturn(false).when(authorizationServiceImpl).isUWLead();
        MvcResult result = mockMvc.perform(patch("/application/case/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(getCaseApplicationCaseOwnerUpdateRequest("case84145778","abc"))))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithInvalidBrand() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();
        MvcResult result = mockMvc.perform(patch("/application/case/caseOwner")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(getCaseApplicationCaseOwnerUpdateRequest("case84145778","abc"))))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithInvalidCaseOwner() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();

        String caseOwner = null;
        CaseUpdateCaseOwnerRequest request = getCaseApplicationCaseOwnerUpdateRequest("case84145778", caseOwner);
        MvcResult result = mockMvc.perform(patch("/application/case/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithInvalidReferenceNumber() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();

        String caseId = null;
        CaseUpdateCaseOwnerRequest request = getCaseApplicationCaseOwnerUpdateRequest(caseId, "abc");
        MvcResult result = mockMvc.perform(patch("/application/case/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithSuccessResponse() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();

        CaseUpdateCaseOwnerRequest request = getCaseApplicationCaseOwnerUpdateRequest("case84145778", "abc");
        MvcResult result = mockMvc.perform(patch("/application/case/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCase() throws Exception {
        Mockito.doReturn(true).when(authorizationServiceImpl).isMopsDataEntry();
        ManualKeyInCaseUpdateRequest request = ManualKeyInCaseUpdateRequest.builder()
                .mortgageRefNo("1233444")
                .applSeq("01")
                .applicants(Collections.singletonList(ManualKeyInApplicantDetail.builder().cin("123")
                        .clientId(12344)
                        .dateOfBirth("2022-09-09")
                        .firstNames("James")
                        .lastName("Smith")
                        .middleNames("ad").build()))
                .build();
        MvcResult result = mockMvc.perform(patch("/capie/case/CBRKMCCONGAR1662898898686/dataentry/CB1662898888776")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCaseBadRequest() throws Exception {
        Mockito.doReturn(true).when(authorizationServiceImpl).isMopsDataEntry();
        ManualKeyInCaseUpdateRequest request = ManualKeyInCaseUpdateRequest.builder()
                .mortgageRefNo("1233444")
                .applSeq("013").build();
        MvcResult result = mockMvc.perform(patch("/capie/case/CBRKMCCONGAR1662898898686/dataentry/CB1662898888776")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicationDataForManualKeyInCaseForbidden() throws Exception {
        ManualKeyInCaseUpdateRequest request = ManualKeyInCaseUpdateRequest.builder()
                .mortgageRefNo("1233444")
                .applSeq("01")
                .applicants(Collections.singletonList(ManualKeyInApplicantDetail.builder().cin("123")
                        .clientId(12344)
                        .dateOfBirth("2022-09-09")
                        .firstNames("James")
                        .lastName("Smith")
                        .middleNames("ad").build()))
                .build();
        MvcResult result = mockMvc.perform(patch("/capie/case/CBRKMCCONGAR1662898898686/dataentry/CB1662898888776")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(403, result.getResponse().getStatus());
    }

    @Test
    void testAddBasicPackaging() throws Exception {
        when(applicationUpdateService.addBasicPackagingRequests(NWB_BRAND, "Case1234567"))
                .thenReturn(new ResponseEntity<>(BasicPackagingDocumentResponse.builder().build(), HttpStatus.CREATED));
        Mockito.doReturn(true).when(authorizationServiceImpl).isMopsDataEntry();
        MvcResult result = mockMvc.perform(post("/application/case/Case1234567/packaging")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void testAddBasicPackagingForbidden() throws Exception {
        Mockito.doReturn(false).when(authorizationServiceImpl).isMopsDataEntry();
        MvcResult result = mockMvc.perform(post("/application/case/Case1234567/packaging")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(403, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
    }


    @Test
    void testDisassociateDocumentForbidden() throws Exception {
        Mockito.doReturn(false).when(authorizationServiceImpl).isDisassociateDocument();
        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();

        MvcResult result = mockMvc.perform(patch("/application/case/122455/documentRequest/adfsdafasdf/document/123213123/disassociate")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(403, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
    }

    @Test
    void testDisassociateDocumentSuccess() throws Exception {
        when(applicationUpdateService.disassociateDocument(any(), any(), any(), any())).thenReturn(SuccessResponse
                .builder()
                .successMessage("Success")
                .build());


        Mockito.doReturn(false).when(authorizationServiceImpl).isDisassociateDocument();
        Mockito.doReturn(true).when(authorizationServiceImpl).isUWUser();

        MvcResult result = mockMvc.perform(patch("/application/case/122455/documentRequest/adfsdafasdf/document/123213123/disassociate")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());

        Mockito.doReturn(true).when(authorizationServiceImpl).isDisassociateDocument();
        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();

        result = mockMvc.perform(patch("/application/case/122455/documentRequest/adfsdafasdf/document/123213123/disassociate")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());

    }

    @Test
    void testNonPSTUserChangeStateForbidden() throws Exception {
        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();
        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        MvcResult result = mockMvc.perform(put("/application/case/77665511xo01/firequest/624aaa874899e7674d47c8d0/fistate/Review")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(403, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
    }

    @Test
    void testPSTUserChangeStateAllowed() throws Exception {
        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();
        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        MvcResult result = mockMvc.perform(put("/application/case/77665511xo01/firequest/624aaa874899e7674d47c8d0/fistate/Review")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().isOk())
                .andReturn();

    }


    @Test
    void testUpdateFIStatusPST_ReviewSuccess() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();


        when(applicationUpdateService.updateFIState("NWB",fiStatusRequest,null,"77665511xo01","624aaa874899e7674d47c8d0", "REVIEWED"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/application/case/77665511xo01/firequest/624aaa874899e7674d47c8d0/fistate/PST_Review")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().is(200))
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testUpdateFIStatusPST_Review_CompleteSuccess() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();


        when(applicationUpdateService.updateFIState("NWB",fiStatusRequest,null,"77665511xo01","624aaa874899e7674d47c8d0", "REVIEWED"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/application/case/77665511xo01/firequest/624aaa874899e7674d47c8d0/fistate/PST_Review_Complete")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().is(200))
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testRequestFurtherInformationPSTSuccess() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();

        FIRequest fiRequest = createFIRequest();

        when(applicationUpdateService.addFI(NWB_BRAND, null, "77665511xo01", fiRequest))
                .thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().build(), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isCreated())
                .andReturn();
        assertEquals(201, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testRequestFurtherInformationPSTFailure() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();

        FIRequest fiRequest = createFIRequest();

        when(applicationUpdateService.addFI(NWB_BRAND, null, "77665511xo01", fiRequest))
                .thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().build(), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddNoteFailureByNonPST() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", null, "77665511xo01", documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));

    }


    @Test
    void testAddNoteSuccessByPST() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", null, "77665511xo01", documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/case/77665511xo01/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }

}