package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.UnsuccessfulUpload;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.Channel;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;


import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createDocumentUploadResponseDtoWithOnlySuccesses;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = MopsDocumentUploadController.class, properties = {"spring.profiles.active=test"})
@DisplayName("MopsDocumentUploadControllerTest - MVC Test")
public class MopsDocumentUploadControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ApplicationUpdateService applicationUpdateService;

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @Autowired
    private ObjectMapper objectMapper;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        doReturn(true).when(authorizationServiceImpl).isMopsUser();
    }

    @Test
    void testUploadDocumentSuccess() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);


        DocumentUploadRequest documentUploadRequest = DocumentUploadRequest
                .builder()
                .file(file)
                .Channel(Channel.FOCUS)
                .documentType("OTHER")
                .build();

        DocumentUploadResponseDto documentUploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();

        when(applicationUpdateService.uploadSingleDocument(documentUploadRequest)).thenReturn(documentUploadResponseDto);

        MvcResult mockResult = mockMvc.perform(post("/upload")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentUploadRequest", documentUploadRequest))
                .andExpect(status().isOk())
                .andReturn();


        assertNotNull(mockResult.getResponse());
        assertEquals(200, mockResult.getResponse().getStatus());
        DocumentUploadResponseDto response = objectMapper.readValue(mockResult.getResponse().getContentAsByteArray(),
                DocumentUploadResponseDto.class);

        assertEquals("49bffb0f-0353-45ab-b1c3-6e3de471e0a7", response.getSuccessfulUploads().get(0).getDocumentId());
        assertEquals("natwest_logo.jpg", response.getSuccessfulUploads().get(0).getOriginalFileName());
    }


    @Test
    void testUploadDocumentBadRequest() throws Exception {

        DocumentUploadRequest documentUploadRequest = DocumentUploadRequest
                .builder()
                .build();

        MvcResult mockResult = mockMvc.perform(post("/upload")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentUploadRequest", documentUploadRequest))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(400, mockResult.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
    }

    @Test
    void testUploadDocumentForMultiStatus() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);


        DocumentUploadRequest documentUploadRequest = DocumentUploadRequest
                .builder()
                .file(file)
                .Channel(Channel.FOCUS)
                .documentType("OTHER")
                .build();

        DocumentUploadResponseDto documentUploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        UnsuccessfulUpload unsuccessfulUpload = UnsuccessfulUpload.builder()
                .originalFileName("natwest_logo1.jpg")
                .build();
        documentUploadResponseDto.getUnsuccessfulUploads().add(unsuccessfulUpload);
        when(applicationUpdateService.uploadSingleDocument(documentUploadRequest)).thenReturn(documentUploadResponseDto);

        MvcResult mockResult = mockMvc.perform(post("/upload")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentUploadRequest", documentUploadRequest))
                .andExpect(status().isMultiStatus())
                .andReturn();


        assertNotNull(mockResult.getResponse());
        assertEquals(207, mockResult.getResponse().getStatus());
        DocumentUploadResponseDto response = objectMapper.readValue(mockResult.getResponse().getContentAsByteArray(),
                DocumentUploadResponseDto.class);

        assertEquals("49bffb0f-0353-45ab-b1c3-6e3de471e0a7", response.getSuccessfulUploads().get(0).getDocumentId());
        assertEquals("natwest_logo.jpg", response.getSuccessfulUploads().get(0).getOriginalFileName());
    }
}
