package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class UpdateApplicationInformationReferenceNumberStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PATCH_UPDATE_APPLICATION_DATA_JSON);
    }

    @Given("UpdateApplicationInformation Service endpoint exists")
    public void updateFIStatusServiceEndpointExists() {
        String test123 = "main";
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    public boolean validateNumberSize(JsonNode number, int size) {
        long test = number.asLong();
        return test >= 0 && test < Math.pow(10, size);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        Assertions.assertTrue(predefined.contains(itemSearched.asText()));
    }

    private void validatePredefinedContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, PREDEFINED);
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateAlphabetAndHyphen(JsonNode field, int size){
        String p = "^[a-zA-Z-]{1,"+size+"}$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    private void validateAlphabetSpaceAndHyphen(JsonNode field, int size){
        String p = "^[a-zA-Z\\s-]{1,"+size+"}$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    private void validateAlphabetAndNumbers(JsonNode field, int size){
        String p = "^[a-zA-Z0-9]{1,"+size+"}$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    private void validateAlphabet(JsonNode field, int size){
        String p = "^[a-zA-Z]{1,"+size+"}$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    private void validateNumbersAndHyphen(JsonNode field, int size){
        String p = "^[0-9-]{1,"+size+"}$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    private void validateNumbers(JsonNode field, int size){
        String p = "^[0-9]{1,"+size+"}$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    private void validateEmail(JsonNode field){
        String p = "^(.+)@(\\S+)$";
        Assertions.assertTrue(field.asText().matches(p));
    }

    public boolean validateDateFormat(String date) {
        return date.matches("^(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])T\\d\\d:\\d\\d+\\d\\d:\\d\\d$");
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGES));
    }

    private void validatePreconditionFailed(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(PRECONDITION_FAILED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String error = inputs.get(ERROR_MESSAGES).asText();
        Assertions.assertEquals(responseJsonNode.get(ERROR_MESSAGES).get(0).asText(),error);
    }

    @When("UpdateApplicationInformation - User sends request to add application information using input {string} and verify response code")
    public void userSendsRequestToAddNotesUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .patch(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service successful response applicant1")
    public void verifySuccessfulResponseApplicant1() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(responseJsonNode.get(APPLICANTS).get(0).get(STATUS).asText(),SUCCESS);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service successful response applicant2")
    public void verifySuccessfulResponseApplicant2() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(responseJsonNode.get(APPLICANTS).get(1).get(STATUS).asText(),SUCCESS);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service successful response broker")
    public void verifySuccessfulResponseBroker() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(responseJsonNode.get(BROKER_INFO).get(STATUS).asText(),SUCCESS);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping brand predefined value {string}")
    public void validateTheResponseCodeBrand(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(BRAND));
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping referenceNumber value in bigdecimal up to 10 chars {string}")
    public void validateTheResponseCodeReferenceNumber(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(REFERENCE_NUMBER).size() < 11 );
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping caseId value  up to 50 chars - only in a-zA-Z0-9 range {string}")
    public void validateTheResponseCodeCaseId(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateAlphabetAndNumbers(inputs.get(REQUEST_BODY).get(CASE_ID),50);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping applicant{int} mainApplicant value as true or false {string}")
    public void validateTheResponseCodeMainApplicant(int ApplicantNr, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(APPLICANTS).get(ApplicantNr-1).get(MAIN_APPLICANT).isBoolean());
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping applicant{int} emailAddress value contains @ {string}")
    public void validateTheResponseCodeApplicantEmailAddress(int ApplicantNr, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateEmail(inputs.get(REQUEST_BODY).get(APPLICANTS).get(ApplicantNr-1).get(EMAIL_ADDRESS));
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping applicant{int} mobileNumber value up to 15 chars - only in 0-9 range and hyphen {string}")
    public void validateTheResponseCodeApplicantNumber(int ApplicantNr, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateNumbersAndHyphen(inputs.get(REQUEST_BODY).get(APPLICANTS).get(ApplicantNr-1).get(MOBILE_NUMBER),15);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping applicant{int} notificationRequired value as true or false {string}")
    public void validateTheResponseCodeNotificationRequired(int ApplicantNr, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(APPLICANTS).get(ApplicantNr-1).get(NOTIFICATION_REQUIRED).isBoolean());
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping broker emailAddress value contains @ {string}")
    public void validateTheResponseCodeBrokerEmail(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateEmail(inputs.get(REQUEST_BODY).get(BROKER_INFO).get(EMAIL_ADDRESS));
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping broker mobileNumber value up to 15 chars - only in 0-9 range and hyphen {string}")
    public void validateTheResponseCodeBrokerMobileNumber(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateNumbersAndHyphen(inputs.get(REQUEST_BODY).get(BROKER_INFO).get(MOBILE_NUMBER),15);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping broker notificationRequired value as true or false {string}")
    public void validateTheResponseCode(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(BROKER_INFO).get(NOTIFICATION_REQUIRED).isBoolean());
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping just applicant1 {string}")
    public void validateTheResponseCodeJustApplicant1(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(APPLICANTS).get(0).get(MAIN_APPLICANT).isBoolean());
        Assertions.assertEquals(inputs.get(REQUEST_BODY).get(APPLICANTS).size(),1);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping just applicant2 {string}")
    public void validateTheResponseCodeJustApplicant2(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(APPLICANTS).get(0).get(MAIN_APPLICANT).isBoolean());
        Assertions.assertEquals(inputs.get(REQUEST_BODY).get(APPLICANTS).size(),1);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping just broker {string}")
    public void validateTheResponseCodeJustBroker(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertFalse(inputs.get(REQUEST_BODY).asText().contains(APPLICANTS));
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping with no applicants and broker {string}")
    public void validateTheResponseCodeNoApplicantsNoBroker(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertFalse(inputs.get(REQUEST_BODY).asText().contains(BROKER_INFO));
        Assertions.assertFalse(inputs.get(REQUEST_BODY).asText().contains(APPLICANTS));
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping applicant2 for application that have just applicant1 {string}")
    public void validateTheResponseCodeForApplicant2UpdateNotAvailableInApplication(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertFalse(inputs.get(REQUEST_BODY).get(APPLICANTS).asText().contains("mainApplicant: false"));
        Assertions.assertEquals(responseJsonNode.get(APPLICANTS).get(1).get(STATUS).asText(),FAIL);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping broker for application that have channel advice, no brokerInfo {string}")
    public void validateTheResponseCodeForBrokerUpdateNotAvailableInApplication(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertFalse(inputs.get(REQUEST_BODY).get(BROKER_INFO).asText().contains(BROKER_INFO));
        Assertions.assertEquals(responseJsonNode.get(BROKER_INFO).get(STATUS).asText(),FAIL);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for brand {string}")
    public void verifyResponseForTheInvalidValueForBrand(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for referenceNumber {string}")
    public void verifyResponseForTheInvalidValueForReferenceNumber(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for caseId {string}")
    public void verifyResponseForTheInvalidValueForCaseId(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant1 emailAddress {string}")
    public void verifyResponseForTheInvalidValueForApplicant1EmailAddress(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant1 mobileNumber {string}")
    public void verifyResponseForTheInvalidValueForApplicant1MobileNumber(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant1 notificationRequired {string}")
    public void verifyResponseForTheInvalidValueForApplicant1NotificationRequired(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant1 mainApplicant {string}")
    public void verifyResponseForTheInvalidValueForApplicant1MainApplicant(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant2 emailAddress {string}")
    public void verifyResponseForTheInvalidValueForApplicant2EmailAddress(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant2 mobileNumber {string}")
    public void verifyResponseForTheInvalidValueForApplicant2MobileNumber(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant2 notificationRequired {string}")
    public void verifyResponseForTheInvalidValueForApplicant2NotificationRequired(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for applicant2 mainApplicant {string}")
    public void verifyResponseForTheInvalidValueForApplicant2MainApplicant(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for broker emailAddress {string}")
    public void verifyResponseForTheInvalidValueForBrokerEmailAddress(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response keeping invalid value for broker notificationRequired {string}")
    public void verifyResponseForTheInvalidValueForBrokerNotificationRequired(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response with referenceNumber and caseId not available in DB {string}")
    public void verifyResponseForPayloadWithRefNoAndCaseIdNotInDB(String inputName) throws JsonProcessingException {
        validatePreconditionFailed(responseJsonNode,inputName);
    }

    @Then("UpdateApplicationInformation - Validate the UI Coord Application Update service response with caseId and referenceNumber null in the payload {string}")
         public void validateNotFoundInURL(String inputName) throws JsonProcessingException {
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            Assertions.assertEquals(inputs.get(ERROR).asText(), responseJsonNode.get(ERROR).asText());
    }

    @Then("Validate the error message for forbidden user for update application {string}")
    public void validateTheErrorMessageForForbiddenUserForUpdateApplication(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("UpdateApplicationInformation - Validate sourceInfo update in UI Coord Application Update service by reference number")
    public void updateapplicationinformationValidateSourceInfoUpdateInUICoordApplicationUpdateServiceByReferenceNumber() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(SUCCESS, responseJsonNode.get(SOURCE_INFO).get(STATUS).asText());
    }
}
