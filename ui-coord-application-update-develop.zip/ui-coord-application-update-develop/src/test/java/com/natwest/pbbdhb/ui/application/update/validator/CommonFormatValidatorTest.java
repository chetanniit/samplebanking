/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.ui.application.update.validator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintValidatorContext;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class CommonFormatValidatorTest {

    @InjectMocks
    private CommonFormatValidator commonFormatValidator;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(commonFormatValidator, "isRequired", true);
    }

    @Test
    void testGetTasks() {
        boolean isValid = commonFormatValidator.isValid("", mock(ConstraintValidatorContext.class));
        assertFalse(isValid);
    }
}
