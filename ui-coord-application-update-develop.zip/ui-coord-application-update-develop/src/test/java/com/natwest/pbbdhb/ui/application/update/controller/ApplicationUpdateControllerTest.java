package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.UnsuccessfulUpload;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.ApplicationIdType;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocUploadChannelEnum;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import java.util.Arrays;
import java.util.Collections;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.ADD_NOTE_CREATION_MESSAGE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.CSP_VALUE;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.INVALID_BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NO_CACHE;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = ApplicationUpdateController.class, properties = {"spring.profiles.active=test"})
@DisplayName("ApplicationUpdateController - MVC Test")
class ApplicationUpdateControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockBean
    private ApplicationUpdateService applicationUpdateService;

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        doReturn(true).when(authorizationServiceImpl).isUWUser();
    }


    @Test
    void testAddFISuccess() throws Exception {

        FIRequest fiRequest = createFIRequest();

        when(applicationUpdateService.addFI(NWB_BRAND, "84153756", null, fiRequest))
                .thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().build(), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/84153756/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isCreated())
                .andReturn();
        assertEquals(201, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddFIInvalidBrand() throws Exception {

        FIRequest fiRequest = createFIRequest();

        MvcResult result = mockMvc.perform(post("/application/84153756/firequest")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddFIInvalidReference() throws Exception {

        FIRequest fiRequest = createFIRequest();

        MvcResult result = mockMvc.perform(post("/application/84153756A11/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testUploadDocuments() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);
        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("89394151")
                .channel(DocUploadChannelEnum.INTERNET)
                .classificationCode("AIFLIL")
                .files(Arrays.asList(file))
                .documentType("OTHER")
                .build();

        DocumentUploadResponseDto documentUploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();

        when(applicationUpdateService.uploadDocument(anyString(),any(),anyString(),any())).thenReturn(documentUploadResponseDto);

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/89394151")
                        .headers(headers)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .flashAttr("documentRequest", documentRequest))
                        .andExpect(status().isOk())
                        .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(200, mockResult.getResponse().getStatus());
        DocumentUploadResponseDto response = objectMapper.readValue(mockResult.getResponse().getContentAsByteArray(),
                DocumentUploadResponseDto.class);

        assertEquals("49bffb0f-0353-45ab-b1c3-6e3de471e0a7", response.getSuccessfulUploads().get(0).getDocumentId());
        assertEquals("natwest_logo.jpg", response.getSuccessfulUploads().get(0).getOriginalFileName());

    }

    @Test
    void testUploadDocumentWithoutChannel() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("89394151")
                .files(Arrays.asList(file))
                .build();
        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/89394151")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(400, mockResult.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);

    }

    @Test
    void testSendReminderSuccess() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        when(applicationUpdateService.sendReminder("NWB", reminder, "84153756", null))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), HttpStatus.ACCEPTED));

        MvcResult result = mockMvc.perform(post("/application/84153756/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().is(202))
                .andReturn();
        assertEquals(202, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testSendReminderForPSTUser() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isMCCUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();

        when(applicationUpdateService.sendReminder("NWB", reminder, "84153756", null))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), HttpStatus.ACCEPTED));

        MvcResult result = mockMvc.perform(post("/application/84153756/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().is(202))
                .andReturn();
        assertEquals(202, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testSendReminderForbiddenForNonPSTUser() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isMCCUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();

        when(applicationUpdateService.sendReminder("NWB", reminder, "84153756", null))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(REQUEST_REMINDER_RESPONSE), HttpStatus.ACCEPTED));

        MvcResult result = mockMvc.perform(post("/application/84153756/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testSendReminderInvalidBrand() throws Exception {

        DocumentReminder reminder = createDocumentReminder();
        reminder.setFiRequestIds(Collections.singletonList("624aaa874899e7674d47c8d0"));

        MvcResult result = mockMvc.perform(post("/application/84153756/notification")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateFIStatusSuccess() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();


        when(applicationUpdateService.updateFIState("NWB",fiStatusRequest,"84145778",null,"624aaa874899e7674d47c8d0","REVIEWED"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/application/84145778/firequest/624aaa874899e7674d47c8d0/fistate/Review")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fiStatusRequest)))
                .andExpect(status().is(200))
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testAddNoteInvalidBrand() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
    }


    @Test
    void testAddNoteWithNullNote() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        documentNotesRequest.setNote(null);

        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddNoteWithNullRequestId() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", "84145778", null, documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        documentNotesRequest.setRequestId(null);
        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }


    @Test
    void testAddNoteWithInvalidRequestId() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", "84145778", null, documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        documentNotesRequest.setRequestId("624aaa874899e7674d47c8d0624aaa874899e7674d47c8d0624aaa874899e7674d47c8d0");
        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(400, result.getResponse().getStatus());
        JsonNode response = new ObjectMapper().readTree(result.getResponse().getContentAsString());
        assertEquals("Please enter a valid request Id", response.get("errorMessages").get(0).asText());
    }

    @Test
    void testAddNoteInvalidReferenceNumber() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        MvcResult result = mockMvc.perform(post("/application/8414577811A/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testAddNoteSuccess() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();

        when(applicationUpdateService.addDocumentRequestNotes("NWB", "84145778", null, documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicationInformation() throws Exception {

        ApplicationInformationUpdateRequest request = ApplicationInformationUpdateRequest.builder().build();
        MvcResult result = mockMvc.perform(patch("/application/84145778")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void testAddFICaseKeywordExclude() throws Exception {

        FIRequest fiRequest = createFIRequest();

        MvcResult result = mockMvc.perform(post("/application/case/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testAddFICaseKeywordExcludeCase1() throws Exception {

        FIRequest fiRequest = createFIRequest();

        MvcResult result = mockMvc.perform(post("/application/Case/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testSendReminderCaseKeywordExclude() throws Exception {

        DocumentReminder reminder = createDocumentReminder();

        MvcResult result = mockMvc.perform(post("/application/case/firequest/624aaa874899e7674d47c8d0/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testSendReminderCaseKeywordExcludeCase1() throws Exception {

        DocumentReminder reminder = createDocumentReminder();

        MvcResult result = mockMvc.perform(post("/application/CASE/firequest/624aaa874899e7674d47c8d0/notification")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reminder)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testAddNoteExcludeCaseKeyword() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        documentNotesRequest.setNote(null);

        MvcResult result = mockMvc.perform(post("/application/case/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testAddNoteExcludeCaseKeywordCase1() throws Exception {

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        documentNotesRequest.setNote(null);

        MvcResult result = mockMvc.perform(post("/application/CASE/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testUpdateExcludeCaseKeyword() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        MvcResult result = mockMvc.perform(put("/application/case/firequest/624aaa874899e7674d47c8d0/fistatus")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testUpdateExcludeCaseKeywordCase1() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        MvcResult result = mockMvc.perform(put("/application/case/firequest/624aaa874899e7674d47c8d0/fistatus")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().isNotFound())
                .andReturn();
        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testUploadDocumentsExcludeCaseKeyword() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
        map.add("applicationId", "89394151");
        map.add(CHANNEL_ID, "INTERNET");
        map.add(APPLICATION_ID_TYPE, ApplicationIdType.MORTGAGE_REFERENCE_NUMBER.name());
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);

        MockMvc mockMvc = MockMvcBuilders.
                webAppContextSetup(webApplicationContext).build();
        MvcResult mockResult = mockMvc.perform(MockMvcRequestBuilders
                        .multipart("/uploadDocument/case")
                        .file(file)
                        .headers(headers)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .queryParams(map))
                .andReturn();

        assertEquals(404, mockResult.getResponse().getStatus());

    }


    @Test
    void testUpdateApplicationInformationExcludeCaseKeyword() throws Exception {

        ApplicationInformationUpdateRequest request = ApplicationInformationUpdateRequest.builder().build();
        MvcResult result = mockMvc.perform(patch("/application/case")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isNotFound())
                .andReturn();

        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testUpdateApplicationInformationExcludeCaseKeywordCase1() throws Exception {

        ApplicationInformationUpdateRequest request = ApplicationInformationUpdateRequest.builder().build();
        MvcResult result = mockMvc.perform(patch("/application/CASE")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isNotFound())
                .andReturn();

        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testSaveIncomeDataExcludeCaseKeyword() throws Exception {

        MvcResult result = mockMvc.perform(put("/income/case")
                        .header(BRAND, NWB_BRAND))
                .andExpect(status().isNotFound())
                .andReturn();

        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testSaveIncomeDataExcludeCaseKeywordCase1() throws Exception {

        MvcResult result = mockMvc.perform(put("/income/CASE")
                        .header(BRAND, NWB_BRAND))
                .andExpect(status().isNotFound())
                .andReturn();

        assertEquals(404, result.getResponse().getStatus());
    }

    @Test
    void testUploadDocumentsForMultiStatus() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);
        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("89394151")
                .channel(DocUploadChannelEnum.INTERNET)
                .files(Arrays.asList(file))
                .documentType("OTHER")
                .build();

        DocumentUploadResponseDto documentUploadResponseDto = createDocumentUploadResponseDtoWithOnlySuccesses();
        UnsuccessfulUpload unsuccessfulUpload = UnsuccessfulUpload.builder()
                .originalFileName("natwest_logo1.jpg")
                .build();
        documentUploadResponseDto.getUnsuccessfulUploads().add(unsuccessfulUpload);

        when(applicationUpdateService.uploadDocument(anyString(),any(),anyString(),any())).thenReturn(documentUploadResponseDto);

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/89394151")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isMultiStatus())
                .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(207, mockResult.getResponse().getStatus());
        DocumentUploadResponseDto response = objectMapper.readValue(mockResult.getResponse().getContentAsByteArray(),
                DocumentUploadResponseDto.class);

        assertEquals("49bffb0f-0353-45ab-b1c3-6e3de471e0a7", response.getSuccessfulUploads().get(0).getDocumentId());
        assertEquals("natwest_logo.jpg", response.getSuccessfulUploads().get(0).getOriginalFileName());

    }

    @Test
    void testUploadDocumentInvalidClassificationCode() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);
        DocumentRequest documentRequest = DocumentRequest.builder()
                .applicantId("89394151")
                .channel(DocUploadChannelEnum.INTERNET)
                .classificationCode("AIFLIL!")
                .files(Arrays.asList(file))
                .build();

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/89394151")
                .headers(headers)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(400, mockResult.getResponse().getStatus());
    }

    @Test
    void testUnauthorisedRoleAccessUpdateApplicationCaseOwner() throws Exception {
        doReturn(false).when(authorizationServiceImpl).isUWLead();
        MvcResult result = mockMvc.perform(patch("/application/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(getApplicationCaseOwnerUpdateRequest("84145778","abc"))))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithInvalidBrand() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();
        MvcResult result = mockMvc.perform(patch("/application/caseOwner")
                        .header(BRAND, INVALID_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(getApplicationCaseOwnerUpdateRequest("84145778","abc"))))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithInvalidCaseOwner() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();

        String caseOwner = null;
        UpdateCaseOwnerRequest request = getApplicationCaseOwnerUpdateRequest("84145778", caseOwner);
        MvcResult result = mockMvc.perform(patch("/application/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithInvalidReferenceNumber() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();

        String referenceNumber = null;
        UpdateCaseOwnerRequest request = getApplicationCaseOwnerUpdateRequest(referenceNumber, "abc");
        MvcResult result = mockMvc.perform(patch("/application/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUpdateApplicatonCaseOwnerWithSuccessResponse() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWLead();

        UpdateCaseOwnerRequest request = getApplicationCaseOwnerUpdateRequest("84145778", "abc");
        MvcResult result = mockMvc.perform(patch("/application/caseOwner")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUploadDocumentInvalidDocumentType() throws Exception {

        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", "NWB");
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        assertNotNull(fileResource);

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        assertNotNull(file);
        DocumentRequest documentRequest = DocumentRequest.builder()
                .channel(DocUploadChannelEnum.INTERNET)
                .files(Arrays.asList(file))
                .documentType("Dummy")
                .build();

        MvcResult mockResult = mockMvc.perform(post("/uploadDocument/89394151")
                        .headers(headers)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .flashAttr("documentRequest", documentRequest))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertNotNull(mockResult.getResponse());
        assertEquals(400, mockResult.getResponse().getStatus());
    }

    @Test
    void testAddTeleMessageRequest() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isMCCUser();
        AddTeleMessageRequest addTeleMessageRequest = createAddTeleMessageRequest();

        when(applicationUpdateService.addTeleMessageRequest(NWB_BRAND, "84153756", addTeleMessageRequest))
                .thenReturn(SuccessResponse.builder().build());
        MvcResult result = mockMvc.perform(post("/application/84153756/telemessage")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(addTeleMessageRequest)))
                .andExpect(status().isCreated())
                .andReturn();
        assertEquals(201, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddTeleMessageRequestForbidden() throws Exception {
        doReturn(false).when(authorizationServiceImpl).isMCCUser();
        AddTeleMessageRequest addTeleMessageRequest = createAddTeleMessageRequest();
        when(applicationUpdateService.addTeleMessageRequest(NWB_BRAND, "84153756", addTeleMessageRequest))
                .thenReturn(SuccessResponse.builder().build());

        MvcResult result = mockMvc.perform(post("/application/84153756/telemessage")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(addTeleMessageRequest)))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testNonPSTUserChangeStateForbidden() throws Exception {
        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();
        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        MvcResult result = mockMvc.perform(put("/application/84145778/firequest/624aaa874899e7674d47c8d0/fistate/Review")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(403, result.getResponse().getStatus());
        verifyNoInteractions(applicationUpdateService);
    }

    @Test
    void testPSTUserChangeStateAllowed() throws Exception {
        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();
        FIStatusRequest fiStatusRequest = createFIStatusRequest();

        MvcResult result = mockMvc.perform(put("/application/84145778/firequest/624aaa874899e7674d47c8d0/fistate/Review")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().isOk())
                .andReturn();

    }

    @Test
    void testUpdateFIStatusPST_ReviewSuccess() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();


        when(applicationUpdateService.updateFIState("NWB",fiStatusRequest,"84145778",null,"624aaa874899e7674d47c8d0","REVIEWED"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/application/84145778/firequest/624aaa874899e7674d47c8d0/fistate/PST_Review")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().is(200))
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testUpdateFIStatusPST_Review_CompleteSuccess() throws Exception {

        FIStatusRequest fiStatusRequest = createFIStatusRequest();


        when(applicationUpdateService.updateFIState("NWB",fiStatusRequest,"84145778",null,"624aaa874899e7674d47c8d0","REVIEWED"))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(FI_STATUS_UPDATE_RESPONSE), HttpStatus.OK));

        MvcResult result = mockMvc.perform(put("/application/84145778/firequest/624aaa874899e7674d47c8d0/fistate/PST_Review_Complete")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiStatusRequest)))
                .andExpect(status().is(200))
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testRequestFurtherInformationPSTSuccess() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();

        FIRequest fiRequest = createFIRequest();

        when(applicationUpdateService.addFI(NWB_BRAND, null, "77665511xo01", fiRequest))
                .thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().build(), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/7766551/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isOk())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testRequestFurtherInformationPSTFailure() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();

        FIRequest fiRequest = createFIRequest();

        when(applicationUpdateService.addFI(NWB_BRAND, null, "77665511xo01", fiRequest))
                .thenReturn(new ResponseEntity<>(AddDocumentResponse.builder().build(), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/7766551/firequest")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fiRequest)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testAddNoteFailureByNonPST() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(false).when(authorizationServiceImpl).isPSTUser();

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", "84145778", null, documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isForbidden())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));

    }


    @Test
    void testAddNoteSuccessByPST() throws Exception {

        Mockito.doReturn(false).when(authorizationServiceImpl).isUWUser();
        Mockito.doReturn(true).when(authorizationServiceImpl).isPSTUser();

        DocumentNotesRequest documentNotesRequest = createDocumentNotesRequest();
        when(applicationUpdateService.addDocumentRequestNotes("NWB", "84145778", null, documentNotesRequest))
                .thenReturn(new ResponseEntity<>(new SuccessResponse(ADD_NOTE_CREATION_MESSAGE), HttpStatus.CREATED));

        MvcResult result = mockMvc.perform(post("/application/84145778/note")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(documentNotesRequest)))
                .andExpect(status().isCreated())
                .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(201, result.getResponse().getStatus());
    }

}