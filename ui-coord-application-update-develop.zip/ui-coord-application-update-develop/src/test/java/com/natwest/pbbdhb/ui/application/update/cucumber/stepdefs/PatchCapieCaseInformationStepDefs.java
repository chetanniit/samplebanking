package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.PATCH_CAPIE_CASE_INFORMATION_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PatchCapieCaseInformationStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PATCH_CAPIE_CASE_INFORMATION_JSON);
    }

    @Given("PatchCapieCaseInformation Service case id endpoint exists")
    public void patchcapiecaseinformationServiceCaseIdEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("PatchCapieCaseInformation - User sends case id request to patch case information using input {string} and verify response code")
    public void patchcapiecaseinformationUserSendsCaseIdRequestToPatchCaseInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, "application/json-patch+json")
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).patch(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
    }

    @Then("Verify case information in patch Cases case ID response output for the input {string}")
    public void verifyCaseInformationInPatchCasesCaseIDResponseOutputForTheInput(String inputName) {
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assert.assertEquals("laksht", responseJsonNode.get("racfId").asText());
        Assert.assertEquals("laksht", responseJsonNode.get("primaryAdvisorRacfId").asText());
        Assert.assertEquals("BUY_TO_LET", responseJsonNode.get("applicationType").asText());
        Assert.assertEquals("Thenmalar", responseJsonNode.get("mortgage").get("mortgageAdvisor").get("advisor").asText());
        Assert.assertEquals("Thenmalar", responseJsonNode.get("mortgage").get("mortgageAdvisor").get("leadAdvisor").asText());
    }

    @Then("Verify error {int} returned as the caseId doesn't exists {string}")
    public void verifyErrorReturnedAsTheCaseIdDoesnTExists(int errorCode, String inputName) {
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(errorCode, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        Assertions.assertTrue(error_message_Array.asText().contains(input.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error {int} returned due to invalid json patch input {string}")
    public void verifyErrorReturnedDueToInvalidJsonPatchInput(int errorCode, String inputName) {
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(errorCode, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        Assertions.assertTrue(error_message_Array.asText().contains(input.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error {int} returned due to invalid field given to replace {string}")
    public void verifyErrorReturnedDueToInvalidFieldGivenToReplace(int errorCode, String inputName) {
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(errorCode, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        System.out.println("constantin "+error_message_Array );
        System.out.println("constantin input "+input.get(ERROR_MESSAGES).asText() );
        Assertions.assertTrue(error_message_Array.asText().contains(input.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error {int} returned due to invalid brand {string}")
    public void verifyErrorReturnedDueToInvalidBrand(int errorCode, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        String errorMessages = responseJsonNode.get("errorMessages").get(0).asText();
        Assertions.assertTrue(errorMessages.contains(input.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error {int} returned due to invalid caseId {string}")
    public void verifyErrorReturnedDueToInvalidCaseId(int arg0, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        String errorMessages = responseJsonNode.get("errorMessages").get(0).asText();
        Assertions.assertTrue(errorMessages.contains(input.get(ERROR_MESSAGES).asText()));
    }
}