package com.natwest.pbbdhb.ui.application.update.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;

class ApplicationUtilTest {

    @ParameterizedTest
    @CsvSource({"  ,true", "2025-11-25T18:30+00:00,true"})
    void testDateTimeValidity(String value, String expectation) {
        boolean expect = Boolean.parseBoolean(expectation);
        assertEquals(expect, isValidDateTime(value));
    }

    @Test
    void testDateTimeValidityForNull() {
        assertTrue(isValidDateTime(null));
    }


    @ParameterizedTest
    @CsvSource({"  ,true","2024-11-25,true", "2024-11-25,true"})
    void testIsValidDateFormat(String value, String expectation) {
        boolean expect = Boolean.parseBoolean(expectation);
        assertEquals(expect, isValidDate(value));
    }

    @Test
    void testIsValidDateFormatForNull() {
        assertTrue(isValidDate(null));
    }

    @Test
    void testDateValidityForNull() {
        assertTrue(isValidDate(null));
    }

    @Test
    void testParseDate() throws ParseException {
        String dateStr = "2022-11-25";
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        dateFormat.setTimeZone(TimeZone.getTimeZone(UK_TIME_ZONE));
        Date date = dateFormat.parse(dateStr);
        assertEquals(date, parseDate(dateStr));
    }

    @Test
    void testParseNullDate() throws ParseException {
        assertNull(parseDate(null));
    }

    @Test
    void testParseDateTime() throws ParseException {
        String dateStr = "2022-11-26T14:07+00:00";
        DateFormat dateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone(UK_TIME_ZONE));
        Date date = dateFormat.parse(dateStr);
        assertEquals(date, parseDateTime(dateStr));
    }

    @Test
    void testParseNullDateTime() throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone(UK_TIME_ZONE));
        Date date = dateFormat.parse(dateFormat.format(new Date()));
        assertEquals(date, parseDateTime(null));
    }

    @Test
    void testValidateTaskNoteRequest(){
        assertTrue(validateTaskNoteRequest(createTaskRequest()));
        assertTrue(validateTaskNoteRequest(createTaskNoteRequest()));
        assertFalse(validateTaskNoteRequest(createInvalidTaskNoteRequest()));
    }

    @ParameterizedTest
    @CsvSource({"  ,true", "2025-11-25,true", "11-12-2021,false", "2021-11-11,false"})
    void testDateValidityInFuture(String value, String expectation) {
        boolean expect = Boolean.parseBoolean(expectation);
        assertEquals(expect, isValidDateInFuture(value));
    }

    @Test
    void testDateValidityInFutureForNull() {
        assertTrue(isValidDateInFuture(null));
    }

    @Test
    void testIsValidEmailForNull(){
        assertTrue(isValidEmail(null));
    }

    @Test
    void testIsValidEmail(){
        assertTrue(isValidEmail("l.copeland-carr@hedleyssolicitors.com"));
    }

    @Test
    void testIsValidEmailInvalid(){
        assertFalse(isValidEmail("l.copeland-carr@hedleyssolicitors"));
    }

    @ParameterizedTest
    @CsvSource({"2022-07-05T11:48:00.000,true"})
    void testISODateTime(String value, String expectation) {
        boolean expect = Boolean.parseBoolean(expectation);
        assertEquals(expect, isValidISODateTime(value));
    }

    @Test
    void testISODateTimeError() {
        assertFalse(isValidISODateTime("2022-07-05T11:4"));
    }

    @Test
    void testISODateTimeNull() {
        assertTrue(isValidISODateTime(null));
    }
}
