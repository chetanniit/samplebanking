package com.natwest.pbbdhb.ui.application.update.cucumber.config;

import static com.mongodb.client.model.Filters.eq;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.conversions.Bson;

public class MongoActions {

    private static String BRAND = CucumberTestProperties.getBrand().toLowerCase();
//    private static String CONNECTION_STRING =
//            "mongodb://flm_"
//                    + BRAND
//                    + "_user:Password1@devecpvm019598.server.banksvcs.net:27017/?authSource=admin&readPreference=primary&appname=MongoDB+Compass&directConnection=true&ssl=false";
//

private static String CONNECTION_STRING = "mongodb://hbotestuser"+":Password1@devecpvm019600.server.banksvcs.net:27017/flm_"+BRAND+"?authSource=admin&replicaSet=HBO&readPreference=primary&ssl=false";
    private static String NFT_NWB_CONNECTION_STRING = "mongodb://Service-Flmmnftnwbrw%40EUROPA.RBSGRP.NET:g9%40l4CHa@devecpvm020932.server.banksvcs.net:27017/flm_"+BRAND+"_db?authMechanism=PLAIN&readPreference=primary&authSource=%24external&ssl=false&authSource=%24external";
    private static String NFT_RBS_CONNECTION_STRING = "mongodb://Service-Flmmnftrbsrw%40EUROPA.RBSGRP.NET:XnVlO3Y%7B@devecpvm020932.server.banksvcs.net:27017/flm_"+BRAND+"_db?authMechanism=PLAIN&readPreference=primary&authSource=$external";

    private static String DB_NAME = "flm_" + BRAND + "_db";
    private static ArrayList<String> result;

    private static JsonNode getInputFile(String inputFileName) throws IOException {
        String testInputPath = CucumberTestProperties.getTestInputPath();
        String inputFilePath = testInputPath.concat(inputFileName);
        JsonNode inputsAsJsonNode = new ObjectMapper().readTree(new File(inputFilePath));
        return inputsAsJsonNode;
    }

    public static ArrayList<String> connectToCollection(
            String CONNECTION_STRING,
            String DB_NAME,
            String collectionName,
            String queryFieldName,
            String queryFieldValue) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        MongoCollection<Document> collection = database.getCollection(collectionName);
        Bson filter = eq(queryFieldName, queryFieldValue);
        result = collection.find(filter).map(Document::toJson).into(new ArrayList<>());
        System.out.print("connect to mong db :" + result);
        return result;
    }

    public static void deleteSingleRecord(
            String collectionName, String queryFieldName, String queryFieldValue) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        Bson deleteValue = eq(queryFieldName, queryFieldValue);
        DeleteResult collection = database.getCollection(collectionName).deleteOne(deleteValue);
        mongoClient.close();
    }

    public static void deleteManyRecords(
            String collectionName, String queryFieldName, String queryFieldValue) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        Bson deleteValue = eq(queryFieldName, queryFieldValue);
        DeleteResult collection = database.getCollection(collectionName).deleteMany(deleteValue);
        mongoClient.close();
    }

    public static void NFTNWBdeleteSingleRecord(
            String collectionName, String queryFieldName, String queryFieldValue) {
        MongoClient mongoClient = MongoClients.create(NFT_NWB_CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        Bson deleteValue = eq(queryFieldName, queryFieldValue);
        DeleteResult collection = database.getCollection(collectionName).deleteOne(deleteValue);
        mongoClient.close();
    }

    public static void NFTRBSdeleteSingleRecord(
            String collectionName, String queryFieldName, String queryFieldValue) {
        MongoClient mongoClient = MongoClients.create(NFT_RBS_CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        Bson deleteValue = eq(queryFieldName, queryFieldValue);
        DeleteResult collection = database.getCollection(collectionName).deleteOne(deleteValue);
        mongoClient.close();
    }

    public static void removeOtherDocumentFromApplicationRecord(
            String queryFieldName, String queryFieldValue) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        Bson query = eq(queryFieldName, queryFieldValue);
        String ODItem = "{ $pull: { \"documentRequests\": { documentIdentifier: \"OD\" }}}";
        Document ODItemDoc = Document.parse(ODItem);
        UpdateResult collection = database.getCollection("documents").updateOne(query,ODItemDoc);
        mongoClient.close();
    }

    public static ArrayList<String> queryMongo(String collectionName, String queryFieldName, String queryFieldValue) {
        return connectToCollection(CONNECTION_STRING, DB_NAME, collectionName, queryFieldName, queryFieldValue);
    }

    public Long testDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }
}
