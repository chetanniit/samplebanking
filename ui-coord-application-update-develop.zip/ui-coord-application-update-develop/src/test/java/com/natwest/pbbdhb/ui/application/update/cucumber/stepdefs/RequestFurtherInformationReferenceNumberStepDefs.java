package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.StreamSupport;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.REQUEST_FURTHER_INFORMATION;

@Slf4j
public class RequestFurtherInformationReferenceNumberStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;
    public JsonNode getDocumentsResponse;
    private String closeNote;
    private String additionalInfo;
    public static String additionalInfoText;


    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(REQUEST_FURTHER_INFORMATION);

    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());
    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) throws JsonProcessingException{
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());
        // Assertions.assertEquals(inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());

    }
    private void validateBadRequestForMissingInput(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());
    }


    @Given("All raise Request Further Information Service endpoint exists")
    public void allRaiseRequestFurtherInformationServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    public Long newTestDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }
    @When("User sends request to raise Request Further Information using input {string} and verify response code")
    public void userSendsRequestToRaiseRequestFurtherInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(inputs.get(REQUEST_BODY).get("documentRequests").spliterator(), false).forEach(documentRequest -> {
            JsonNode requiredForArray = documentRequest.get("requiredFor");
            StreamSupport.stream(requiredForArray.spliterator(), false).forEach(requiredFor -> {
                ((ObjectNode) requiredFor).put("applicantId", RandomStringUtils.randomAlphabetic(1, 30) + newTestDateFormat());
            });
        });
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(inputs, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(inputs, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(inputs)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Verify further information reference number as a request input parameter which accepts Ten digit numeric number only for the end point input {string}")
    public void verifyFurtherInformationReferenceNumberAsARequestInputParameterWhichAcceptsTenDigitNumericNumberOnlyForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));

    }

    @Then("Verify response for channel having Intermediary Case for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingIntermediaryCaseForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for channel having Direct Advised Case for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingDirectAdvisedCaseForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for channel having Digital Non-Advised Case for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingDigitalNonAdvisedCaseForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for channel having Advisor for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingAdvisorForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for single applicant for Intermediary Case response of request further information as the endpoint input {string}")
    public void verifyResponseForSingleApplicantForIntermediaryCaseResponseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for joint applicant for Intermediary Case of request further information as the endpoint input {string}")
    public void verifyResponseForJointApplicantForIntermediaryCaseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for single applicant for Digital Advised Case response of request further information as the endpoint input {string}")
    public void verifyResponseForSingleApplicantForDigitalAdvisedCaseResponseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for joint applicant for Digital Advised Case of request further information as the endpoint input {string}")
    public void verifyResponseForJointApplicantForDigitalAdvisedCaseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for single applicant for Digital Non-Advised Case response of request further information as the endpoint input {string}")
    public void verifyResponseForSingleApplicantForDigitalNonAdvisedCaseResponseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for joint applicant for Digital Non-Advised Case of request further information as the endpoint input {string}")
    public void verifyResponseForJointApplicantForDigitalNonAdvisedCaseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for single applicant for Advisor response of request further information as the endpoint input {string}")
    public void verifyResponseForSingleApplicantForAdvisorResponseOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for joint applicant for Advisor of request further information as the endpoint input {string}")
    public void verifyResponseForJointApplicantForAdvisorOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify response for single and joint applicant for Advisor of request further information as the endpoint input {string}")
    public void verifyResponseForSingleAndJointApplicantForAdvisorOfRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to single applicant of Intermediary Case {string}")
    public void verifyForEmailNotificationIsSentToSingleApplicantOfIntermediaryCase(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to both applicants of Intermediary Case {string}")
    public void verifyForEmailNotificationIsSentToBothApplicantsOfIntermediaryCase(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to single applicant of Direct Advised Case {string}")
    public void verifyForEmailNotificationIsSentToSingleApplicantOfDirectAdvisedCase(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to both applicants of Direct Advised Case {string}")
    public void verifyForEmailNotificationIsSentToBothApplicantsOfDirectAdvisedCase(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to single applicant of Digital Non-Advised Case {string}")
    public void verifyForEmailNotificationIsSentToSingleApplicantOfDigitalNonAdvisedCase(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to both applicants of Digital Non-Advised Case {string}")
    public void verifyForEmailNotificationIsSentToBothApplicantsOfDigitalNonAdvisedCase(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to single applicant of Advisor {string}")
    public void verifyForEmailNotificationIsSentToSingleApplicantOfAdvisor(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to both applicants of Advisor {string}")
    public void verifyForEmailNotificationIsSentToBothApplicantsOfAdvisor(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification send to single applicant for Direct Advised Case and broker {string}")
    public void verifyForEmailNotificationSendToSingleApplicantForDirectAdvisedCaseAndBroker(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is sent to both applicants for Direct Advised Case and notification is sent to broker {string}")
    public void verifyForEmailNotificationIsSentToBothApplicantsForDirectAdvisedCaseAndNotificationIsSentToBroker(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification send send to {int}st applicant, not send to {int}nd applicant of Direct Advised Case and broker {string}")
    public void verifyForEmailNotificationSendSendToStApplicantNotSendToNdApplicantOfDirectAdvisedCaseAndBroker(int arg0, int arg1, String arg2) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for email notification is not send to {int}st applicant but send to {int}nd applicant of Direct Advised Case and notification is sent to broker {string}")
    public void verifyForEmailNotificationIsNotSendToStApplicantButSendToNdApplicantOfDirectAdvisedCaseAndNotificationIsSentToBroker(int arg0, int arg1, String arg2) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for NO email notification to both {int}st applicant and {int}nd applicant of  Digital Non-Advised Case but notification is sent to broker {string}")
    public void verifyForNOEmailNotificationToBothStApplicantAndNdApplicantOfDigitalNonAdvisedCaseButNotificationIsSentToBroker(int arg0, int arg1, String arg2) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify for NO email notification send to any joint applicants of Advisor and also no email notification to broker {string}")
    public void verifyForNOEmailNotificationSendToAnyJointApplicantsOfAdvisorAndAlsoNoEmailNotificationToBroker(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information requestorFullName as a request input parameter which accepts alphabet and space max {int} char only for the end point input {string}")
    public void verifyFurtherInformationRequestorFullNameAsARequestInputParameterWhichAcceptsAlphabetAndSpaceMaxCharOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information requestorRACFID as a request input parameter which alphabet {int} char only for the end point input {string}")
    public void verifyFurtherInformationRequestorRACFIDAsARequestInputParameterWhichAlphabetCharOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information source as a request input parameter which accepts alphabet and space max {int} char only for the end point input {string}")
    public void verifyFurtherInformationSourceAsARequestInputParameterWhichAcceptsAlphabetAndSpaceMaxCharOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information caseId as a request input parameter which alphabet and space max {int} char only for the end point input {string}")
    public void verifyFurtherInformationCaseIdAsARequestInputParameterWhichAlphabetAndSpaceMaxCharOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information channel as a request input parameter which accepts alphabet and space max {int} char only for the end point input {string}")
    public void verifyFurtherInformationChannelAsARequestInputParameterWhichAcceptsAlphabetAndSpaceMaxCharOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information applicantId as a request input parameter which allow only numbers max {int} for the end point input {string}")
    public void verifyFurtherInformationApplicantIdAsARequestInputParameterWhichAllowOnlyNumbersMaxForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information documentType as a request input parameter which accepts alphanumeric with special char and space max length {int} for the end point input {string}")
    public void verifyFurtherInformationDocumentTypeAsARequestInputParameterWhichAcceptsAlphanumericWithSpecialCharAndSpaceMaxLengthForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information documentName as a request input parameter which accepts alphanumeric with special char and space max length {int}  for the end point input {string}")
    public void verifyFurtherInformationDocumentNameAsARequestInputParameterWhichAcceptsAlphanumericWithSpecialCharAndSpaceMaxLengthForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information fromDate as a request input parameter which accepts yyyy-mm-dd Date only for the end point input {string}")
    public void verifyFurtherInformationFromDateAsARequestInputParameterWhichAcceptsYyyyMmDdDateOnlyForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }
    @Then("Verify further information toDate as a request input parameter which accepts yyyy-mm-dd Date only for the end point input {string}")
    public void verifyFurtherInformationToDateAsARequestInputParameterWhichAcceptsYyyyMmDdDateOnlyForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information dueDate as a request input parameter which accepts yyyy-mm-dd Date only for the end point input {string}")
    public void verifyFurtherInformationDueDateAsARequestInputParameterWhichAcceptsYyyyMmDdDateOnlyForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information timePeriod as a request input parameter which accepts alphanumeric with special char and space max length {int} only for the end point input {string}")
    public void verifyFurtherInformationTimePeriodAsARequestInputParameterWhichAcceptsAlphanumericWithSpecialCharAndSpaceMaxLengthOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information requestReason as a request input parameter for the end point input {string}")
    public void verifyFurtherInformationRequestReasonAsARequestInputParameterForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information taskCode as a request input parameter which accepts alphanumeric and space max length {int} only for the end point input {string}")
    public void verifyFurtherInformationTaskCodeAsARequestInputParameterWhichAcceptsAlphanumericAndSpaceMaxLengthOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information otherInfo as a request input parameter for the end point input {string}")
    public void verifyFurtherInformationOtherInfoAsARequestInputParameterForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information applicantId as a request input parameter which accepts only numbers max {int} for the end point input {string}")
    public void verifyFurtherInformationApplicantIdAsARequestInputParameterWhichAcceptsOnlyNumbersMaxForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information title as a request input parameter which accepts Min {int},Max {int} -Alphabets for the end point input {string}")
    public void verifyFurtherInformationTitleAsARequestInputParameterWhichAcceptsMinMaxAlphabetsForTheEndPointInput(int arg0, int arg1, String arg2) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information firstName as a request input parameter which accepts alphabet and space max {int} char for the end point input {string}")
    public void verifyFurtherInformationFirstNameAsARequestInputParameterWhichAcceptsAlphabetAndSpaceMaxCharForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information lastName as a request input parameter which accepts alphabet and space max {int} char for the end point input {string}")
    public void verifyFurtherInformationLastNameAsARequestInputParameterWhichAcceptsAlphabetAndSpaceMaxCharForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information emailAddress as a request input parameter which accepts email validation for the end point input {string}")
    public void verifyFurtherInformationEmailAddressAsARequestInputParameterWhichAcceptsEmailValidationForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information mobileNumber as a request input parameter which accepts number max {int} digits with space and plus special char for the end point input {string}")
    public void verifyFurtherInformationMobileNumberAsARequestInputParameterWhichAcceptsNumberMaxDigitsWithSpaceAndPlusSpecialCharForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information isNotificationRequired as a request input parameter which accepts true or false boolean for the end point input {string}")
    public void verifyFurtherInformationIsNotificationRequiredAsARequestInputParameterWhichAcceptsTrueOrFalseBooleanForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information fullname as a request input parameter which accepts alphabet and space max {int} char for the end point input {string}")
    public void verifyFurtherInformationFullnameAsARequestInputParameterWhichAcceptsAlphabetAndSpaceMaxCharForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information firmName as a request input parameter which acceptsAlphabets, Numbers, special characters \\(allowed list only), Min {int}, Max {int} for the end point input {string}")
    public void verifyFurtherInformationFirmNameAsARequestInputParameterWhichAcceptsAlphabetsNumbersSpecialCharactersAllowedListOnlyMinMaxForTheEndPointInput(int arg0, int arg1, String arg2) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the error response for invalid value for reference number for the end point input {string}")
    public void verifyTheErrorResponseForInvalidValueForReferenceNumberForTheEndPointInput(String inputName) throws JsonProcessingException{
        validateBadRequest(responseJsonNode, inputName);

       /* responseJsonNode = new ObjectMapper().readTree(response.asString());
         Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());*/

    }

    @Then("Verify the error response for reference number not found for the end point input {string}")
    public void verifyTheErrorResponseForReferenceNumberNotFoundForTheEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the display of invalid value for requestorFullName for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueForRequestorFullNameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of error message for missing brand for the end point input {string}")
    public void verifyTheDisplayOfErrorMessageForMissingBrandForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequestForMissingInput(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid requestorRACFID error for the input {string}")
    public void verifyTheDisplayOfInvalidRequestorRACFIDErrorForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of source for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfSourceForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of caseId for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfCaseIdForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of channel for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfChannelForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of applicantId for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfApplicantIdForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of documentType the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfDocumentTypeTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of documentName for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfDocumentNameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of fromDate for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfFromDateForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of toDate for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfToDateForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of dueDate for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfDueDateForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of timePeriod for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfTimePeriodForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of taskCode for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfTaskCodeForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of title for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfTitleForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of firstName for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfFirstNameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of lastName for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfLastNameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of emailAddress for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfEmailAddressForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of mobileNumber for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfMobileNumberForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of isNotificationRequired for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfIsNotificationRequiredForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of fullname for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfFullnameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of error message for blank firm name for the end point input {string}")
    public void verifyTheDisplayOfErrorMessageForBlankFirmNameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of firmName for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfFirmNameForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify further information applicantId as a request input parameter which allow Alphabets and Numbers max {int} for the end point input {string}")
    public void verifyFurtherInformationApplicantIdAsARequestInputParameterWhichAllowAlphabetsAndNumbersMaxForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information documentType as a request input parameter for the end point input {string}")
    public void verifyFurtherInformationDocumentTypeAsARequestInputParameterForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information reRequestReason as a request input parameter for the end point input {string}")
    public void verifyFurtherInformationReRequestReasonAsARequestInputParameterForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information timePeriod as a request input parameter max length {int} only for the end point input {string}")
    public void verifyFurtherInformationTimePeriodAsARequestInputParameterMaxLengthOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information purpose as a request input parameter for the end point input {string}")
    public void verifyFurtherInformationPurposeAsARequestInputParameterForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information title as a request input parameter which accepts {int} alphabets only for the end point input {string}")
    public void verifyFurtherInformationTitleAsARequestInputParameterWhichAcceptsAlphabetsOnlyForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify further information emailAddress as a request input parameter which accepts max length {int} char for the end point input {string}")
    public void verifyFurtherInformationEmailAddressAsARequestInputParameterWhichAcceptsMaxLengthCharForTheEndPointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the display of invalid value of reRequestReason the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfReRequestReasonTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of invalid value of documentType for the end point input {string}")
    public void verifyTheDisplayOfInvalidValueOfDocumentTypeForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify the display of error message for all mandatory fields left blank for the end point input  {string}")
    public void verifyTheDisplayOfErrorMessageForAllMandatoryFieldsLeftBlankForTheEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessages = inputs.get(ERROR_MESSAGES).asText().split(",");
        String responseError = "";
        for(int i=0;i<responseJsonNode.get(ERROR_MESSAGES).size();i++){
            responseError +=responseJsonNode.get(ERROR_MESSAGES).get(i);
        }
        for(String error:errorMessages){
            Assertions.assertTrue(responseError.contains(error));
        }
        Assertions.assertEquals(5, responseJsonNode.get(ERROR_MESSAGES).size());
    }

    @Then("Verify the display of source for the end point input {string}")
    public void verifyTheDisplayOfSourceForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the display of reRequestReason the end point input {string}")
    public void verifyTheDisplayOfReRequestReasonTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the display of timePeriod for the end point input {string}")
    public void verifyTheDisplayOfTimePeriodForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the display of taskCode for the end point input {string}")
    public void verifyTheDisplayOfTaskCodeForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Validate the error message for forbidden user for request FI {string}")
    public void validateTheErrorMessageForForbiddenUserForRequestFI(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify error message for duplicate FI check reference number for the input {string}")
    public void verifyErrorMessageForDuplicateFICheckReferenceNumberForTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals("409",responseJsonNode.get(RESPONSE_CODE).asText());
        Assert.assertEquals(inputs.get(MESSAGE).asText(), responseJsonNode.get("message").asText());

    }



    public Long testDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    @When("User sends request to duplicate FI raise Request Further Information using input {string} and verify response code")
    public void userSendsRequestToDuplicateFIRaiseRequestFurtherInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(inputs);
        DocumentContext doc = JsonPath.parse(json);
        String randomizedString = RandomStringUtils.randomAlphabetic(1, 30);
        //inputs.get(REQUEST_BODY).get("documentRequests").get(0).get("requiredFor").get(0).get("applicantId").asText() +
        String applicantId = randomizedString;
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantId);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(inputs, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(inputs)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Verify error message for partial duplicate FI check reference number for the input {string}")
    public void verifyErrorMessageForPartialDuplicateFICheckReferenceNumberForTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals("206",responseJsonNode.get(RESPONSE_CODE).asText());
        Assert.assertEquals(inputs.get(MESSAGE).asText(), responseJsonNode.get("message").asText());

    }

    @When("User sends request to raise Request Further Information using input {string} and verify response codes")
    public void userSendsRequestToRaiseRequestFurtherInformationUsingInputAndVerifyResponseCodes(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to raise Request Further Information using input {string} and verify error code")
    public void userSendsRequestToRaiseRequestFurtherInformationUsingInputAndVerifyErrorCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(inputs);
        DocumentContext doc = JsonPath.parse(json);
        String randomizedString = RandomStringUtils.randomAlphabetic(1, 50);
        String applicantId = inputs.get(REQUEST_BODY).get("documentRequests").get(0).get("requiredFor").get(0).get("applicantId").asText() + randomizedString;
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantId);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(inputs, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(inputs, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(inputs)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to raise Request Further Information for documentIdentifier {string} using input {string} and verify response code")
    public void userSendsRequestToRaiseRequestFurtherInformationForDocumentIdentifierUsingInputAndVerifyResponseCodes(String documentIdentifier, String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.documentRequests.[0].documentIdentifier", documentIdentifier);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }


    @When("Custom FI User sends request to raise Request Further Information using input {string} and verify response code")
    public void customFIUserSendsRequestToRaiseRequestFurtherInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        additionalInfoText = testInput.get(REQUEST_BODY).get("documentRequests").get(0).get("additionalInfo").asText() +" "+ testDateFormat();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.documentRequests[0].additionalInfo", additionalInfoText);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to raise custom SI for documentIdentifier {string} additionalInfo {string} using input {string} and verify response code")
    public void userSendsRequestToRaiseCustomSIForDocumentIdentifierUsingInputAndVerifyResponseCodes(String documentIdentifier, String additionalInfo1, String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        additionalInfo = additionalInfo1 + ExternalServicesStepDefs.testDateFormatFull();
        doc.set("requestBody.documentRequests.[0].documentIdentifier", documentIdentifier);
        doc.set("requestBody.documentRequests.[0].additionalInfo", additionalInfo);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view document list for input {string}")
    public void userSendsRequestToGetDocumentListUsingRefNoAndVerifyResponseCode(
            String inputName) throws JsonProcessingException, InterruptedException {
        Thread.sleep(20000);
        String GET_APPLICATION_TRACKING_FILIST_PATH = "/application/{referenceNumber}/filist";
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(ApiTestConstants.Params.BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, inputsAsJsonNode.get(inputName).get(REFERENCE_NUMBER).asText());
        ApiTestUtil.createRequestForInputParams(
                addedNode, request, GET_APPLICATION_TRACKING_FILIST_PATH);
        Response response =
                request.headers(CucumberTestProperties.getHeaders(inputsAsJsonNode.get(inputName)))
                        .get(GET_APPLICATION_TRACKING_FILIST_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        getDocumentsResponse = new ObjectMapper().readTree(response.asString());
    }

    @Then("Verify that created document have identifier {string} type {string} category {string} purpose {string}")
    public void verifyDocumentFields(String identifier, String type, String category, String purpose) throws JsonProcessingException, InterruptedException {
        JsonNode firstDocument = getDocumentsResponse.get(DOCUMENTS).get(0);
        String responseIdentifier = firstDocument.get(DOCUMENT_IDENTIFIER).asText();
        String responseDocumentType = firstDocument.get(FI_TYPE).asText();
        String responseCategory = firstDocument.get(CATEGORY).asText();
        String responsePurpose = firstDocument.get("purpose").get(0).asText();
        Assertions.assertEquals(identifier, responseIdentifier, "documentIdentifier not match");
        Assertions.assertEquals(type, responseDocumentType, "documentType not match");
        Assertions.assertEquals(category, responseCategory, "category not match");
        Assertions.assertEquals(purpose, responsePurpose, "purpose not match");
    }

    @Then("Verify that created document have configured additionalInfo")
    public void verifyDocumentFields() {
        JsonNode firstDocument = getDocumentsResponse.get(DOCUMENTS).get(0);
        String responseAdditionalInfo = firstDocument.get("additionalInfo").asText();
        Assertions.assertEquals(additionalInfo, responseAdditionalInfo, "additionalInfo not match");
    }

    @When("User sends request to upload doc using input {string} on last added FI and verify response code")
    public void userSendsRequestToUploadDocUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        String path = "/uploadDocument/{referenceNumber}";
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        String firstDocumentRequestId = getDocumentsResponse.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("formData.requestId", firstDocumentRequestId);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(MULTIPART_CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .basePath(path);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @When("Move FI with uploaded document to Upload state")
    public void switchToUploadStateLastOpenFI() throws JsonProcessingException, JSONException, InterruptedException {
        String brand = CucumberTestProperties.getBrand();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String firstDocumentRequestId = getDocumentsResponse.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String referenceNumber = getDocumentsResponse.get(REFERENCE_NUMBER).asText();
        String state = "Upload";
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("referenceNumber", referenceNumber);
        doc.put("firequestId", firstDocumentRequestId);
        doc.put("state", state);
        doc.put("loginUserName", "HBOPostSub8");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @When("Move FI with uploaded document to Close state")
    public void closeLastOpenFI() throws JsonProcessingException, JSONException, InterruptedException {
        String brand = CucumberTestProperties.getBrand();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String firstDocumentRequestId = getDocumentsResponse.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String firstDocumentState = getDocumentsResponse.get(DOCUMENTS).get(0).get(STATE).asText();
        String referenceNumber = getDocumentsResponse.get(REFERENCE_NUMBER).asText();
        String state = "Closed";
        closeNote = "FI closed at "+ExternalServicesStepDefs.testDateFormatFull();
        if(!firstDocumentState.equals(state)) {
            JSONObject doc = new JSONObject();
            doc.put("brand", brand);
            doc.put("referenceNumber", referenceNumber);
            doc.put("firequestId", firstDocumentRequestId);
            doc.put("state", state);
            doc.put("note", closeNote);
            doc.put("loginUserName", "HBOPostSub8");
            JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
            response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
        }
    }

    @When("User sends request to get notes information for input {string} and verify response code")
    public void userSendsRequestToGetNotesInformationForReferenceNumberAndVerifyResponseCode(
            String inputName) throws IOException, JSONException {
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        JSONObject doc = new JSONObject();
        String brand = CucumberTestProperties.getBrand();
        doc.put("brand", brand);
        doc.put("referenceNumber", testInput.get(REFERENCE_NUMBER).asText());
        doc.put("loginUserName", "HBOPostSub8");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, "/notesInformation/{referenceNumber}");
        Response response =
                request.headers(CucumberTestProperties.getHeaders(updatedInput))
                        .get("/notesInformation/{referenceNumber}");
        log.info("response : {}", response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @Then("Verify notes contains close note text")
    public void verifyNotesContainsCloseNote() {
        String notesResponse = responseJsonNode.toPrettyString();
        Assertions.assertTrue(notesResponse.contains(closeNote), "close note:"+closeNote+" not available");
    }

    @Then("Verify FST raised notes contains additionalInfo text")
    public void verifyNotesContainsAdditionalInfo() {
        String notesResponse = responseJsonNode.toPrettyString();
        JsonNode firstDocument = getDocumentsResponse.get(DOCUMENTS).get(0);
        String updatedByRACFID = firstDocument.get("userRACFId").asText();
        String openNote = "FI raised by "+updatedByRACFID+" - Query - Other requested - "+additionalInfo;
        log.info("Verify existence of FST raise note for custom SI: "+ openNote);
        Assertions.assertTrue(notesResponse.contains(openNote), "openNote: "+openNote+" not available");
    }

    @Then("Verify review FST notes contains additionalInfo text")
    public void verifyReviewNotesContainsAdditionalInfo() {
        String notesResponse = responseJsonNode.toPrettyString();
        JsonNode firstDocument = getDocumentsResponse.get(DOCUMENTS).get(0);
        String updatedByRACFID = firstDocument.get("userRACFId").asText();
        String reviewNote = "Reviewed by "+updatedByRACFID+" - Query - Other requested - "+additionalInfo;
        log.info("Verify existence of FST review note for custom SI: "+ reviewNote);
        Assertions.assertTrue(notesResponse.contains(reviewNote), "reviewNote: "+reviewNote+" not available");
    }

    @Then("Verify received FST notes contains additionalInfo text")
    public void verifyReceivedNotesContainsAdditionalInfo() {
        String notesResponse = responseJsonNode.toPrettyString();
        String receivedNote = "Received  - Query - Other requested - "+additionalInfo;
        log.info("Verify existence of FST received note for custom SI: "+ receivedNote);
        Assertions.assertTrue(notesResponse.contains(receivedNote), "receivedNote: "+receivedNote+" not available");
    }

    @Then("Verify T23 notes contains additionalInfo text")
    public void verifyT23NotesContainsAdditionalInfo() {
        String notesResponse = responseJsonNode.toPrettyString();
        JsonNode firstDocument = getDocumentsResponse.get(DOCUMENTS).get(0);
        String requestId = firstDocument.get(REQUEST_ID).asText();
        String t23Note = requestId+" - Received  - Query - Other requested - "+additionalInfo;
        log.info("Verify existence of FST T23 note for custom SI: "+ t23Note);
        Assertions.assertTrue(notesResponse.contains(t23Note), "t23Note: "+t23Note+" not available");
    }

    @When("Update customer response field for input {string}")
    public void updateCustomerResponseApplication(String inputName) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        String referenceNumber = testInput.get(REFERENCE_NUMBER).asText();
        String fiRequestId = getDocumentsResponse.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String fiType = "Text";
        String state = "Open";
        JSONObject doc = new JSONObject();
        JSONObject requestBody = new JSONObject();
        doc.put("brand", brand);
        doc.put("referenceNumber", referenceNumber);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);
        doc.put("loginUserName", "HBOPostSub8");
        requestBody.put("note","text note for "+fiRequestId);
        String customerResponseValue = "customer response "+ExternalServicesStepDefs.testDateFormatFull();
        requestBody.put("customerResponse", customerResponseValue);
        doc.put("requestBody", requestBody);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @Then("Verify invalid additionalInfo maxLegth error message")
    public void verifyInvalidMaxLengthErrorMesage() throws JsonProcessingException {
        JsonNode responseErrorMessage = responseJsonNode = new ObjectMapper().readTree(responseString);
        String responseStatus = responseErrorMessage.get(RESPONSE_STATUS).asText();
        String errorMessage = responseErrorMessage.get(ERROR_MESSAGES).get(0).asText();
        Assertions.assertEquals(BAD_REQUEST, responseStatus, "responseStatus not match");
        Assertions.assertEquals("Please enter a valid additionalInfo", errorMessage, "errorMessage not match");
    }

    @When("Wait for {int} seconds")
    public void waitForSeconds(int delayTimeout) throws InterruptedException {
        log.info("Delay execution with "+delayTimeout+" seconds");
        Thread.sleep(delayTimeout*1000);
    }

    private void setInputFiles(RequestSpecification request,JsonNode files) {
        StreamSupport.stream(files.spliterator(), false).forEach(file -> {
            Assertions.assertNotNull(file,"filename is missing");
            Assertions.assertFalse(StringUtils.isEmpty(file.asText()),"filename is missing");
            String fileType = getFileType(file.asText());
            request.multiPart("files", new File(MEDIA_FILES + file.asText()),fileType);
        });
    }

    private String getFileType(String file) {

        if (file.toUpperCase().endsWith("PNG")) {
            return APPLICATION_PNG;
        } else if (file.toUpperCase().endsWith("DOC")) {
            return APPLICATION_WORD_DOC;
        } else if (file.toUpperCase().endsWith("JPEG")) {
            return APPLICATION_JPEG;
        } else if (file.toUpperCase().endsWith("JPG")) {
            return APPLICATION_JPEG;
        } else if (file.toUpperCase().endsWith("PPT")) {
            return APPLICATION_PPT;
        } else if (file.toUpperCase().endsWith("ZIP")) {
            return APPLICATION_ZIP;
        }
        return APPLICATION_PDF;
    }
}