package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.service.impl.CaseServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.json.Json;
import javax.json.JsonPatch;
import javax.json.JsonReader;
import java.io.StringReader;
import java.util.Collections;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.CASE_ID;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NWB_BRAND;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class CaseServiceImplTest {

    @InjectMocks
    private CaseServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ApplicationEventPublisher eventPublisher;

    public static final String BASE_URL = "https://v1-msvc-case-dev.edi02-apps.dev-pcf.lb4.rbsgrp.net";
    public static final String ENDPOINT = "/v1/cases/1234567";

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "msvcCaseParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "msvcCaseCasesEndpoint", ENDPOINT);
        ReflectionTestUtils.setField(service, "caseInfoUpdateAllowedFields",
                Collections.singletonList("/racfId"));
    }

    @Test
    void testUpdateCaseInformation() {
        String body = "[{\"op\": \"replace\", \"path\": \"/racfI\", \"value\": \"WEB\" }]";

        JsonReader jsonReader = Json.createReader(new StringReader(body));
        JsonPatch jsonPatch = Json.createPatch(jsonReader.readArray());
        when(restTemplate.exchange(any(), any(), any(), eq(CaseApplicationDto.class)))
                .thenReturn(new ResponseEntity<>(CaseApplicationDto.builder().build(), HttpStatus.OK));
        service.updateCaseInformation(NWB_BRAND, CASE_ID, jsonPatch);
        verify(restTemplate).exchange(any(), any(), any(), eq(CaseApplicationDto.class));
        verifyNoInteractions(eventPublisher);
    }

    @Test
    void testUpdateCasesInformation() {
        CaseApplicationDto request = CaseApplicationDto.builder().caseId(CASE_ID).build();
        when(restTemplate.exchange(any(), any(), any(), eq(CaseApplicationDto.class)))
                .thenReturn(new ResponseEntity<>(CaseApplicationDto.builder().build(), HttpStatus.OK));

        ResponseEntity<CaseApplicationDto> response = service.updateCase(NWB_BRAND, request,CASE_ID);

        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(CaseApplicationDto.class));
        verify(eventPublisher).publishEvent(any());
    }


    @Test
    void testUpdateCaseInformationException() {
        CaseApplicationDto request = CaseApplicationDto.builder().caseId(CASE_ID).build();
        when(restTemplate.exchange(any(), any(), any(), eq(CaseApplicationDto.class)))
                .thenThrow(HttpClientErrorException.class);
        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class,
                () -> service.updateCase(NWB_BRAND, request,CASE_ID));
        verify(restTemplate).exchange(any(), any(), any(), eq(CaseApplicationDto.class));
        verifyNoInteractions(eventPublisher);
    }

    @Test
    void testUpdateCaseInformationPreConditionFailedException() {
        CaseApplicationDto request = CaseApplicationDto.builder().build();
        assertThrows(PreConditionFailedException.class,
                () -> service.updateCase(NWB_BRAND, request,CASE_ID));
        verifyNoInteractions(restTemplate);
        verifyNoInteractions(eventPublisher);
    }
}