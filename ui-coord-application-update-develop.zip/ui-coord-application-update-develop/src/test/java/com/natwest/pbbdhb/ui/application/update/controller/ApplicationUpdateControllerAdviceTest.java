package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.cases.validation.RequestValidationDto;
import com.natwest.pbbdhb.cases.validation.ValidationErrorDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.GlobalErrorResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.*;
import com.natwest.pbbdhb.ui.application.update.util.ErrorMessageConfigReader;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.apache.tomcat.util.http.fileupload.impl.SizeLimitExceededException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.request.WebRequest;

import javax.json.JsonException;
import javax.validation.ConstraintViolationException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.getErrorMap;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ApplicationUpdateControllerAdviceTest {

    @InjectMocks
    private ApplicationUpdateControllerAdvice applicationUpdateControllerAdvice;

    @Mock
    private ErrorMessageConfigReader errorMessageConfigReader;

    @Mock
    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHandleResourceNotFoundException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleResourceNotFoundException(mock(ResourceNotFoundException.class), mock(WebRequest.class));

        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleClosedTaskException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleClosedTaskException(mock(ClosedTaskException.class), mock(WebRequest.class));

        assertEquals(412, response.getStatusCodeValue());
    }

    @Test
    void testHandleUserNotValidException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleUserNotValidException(mock(UserNotValidException.class), mock(WebRequest.class));

        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleUserNotAuthorizedException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleUserNotAuthorizedException(mock(UserNotAuthorizedException.class), mock(WebRequest.class));

        assertEquals(403, response.getStatusCodeValue());
    }

    @Test
    void testHandleAccessDeniedException() {

        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleAccessDeniedException(mock(AccessDeniedException.class), mock(WebRequest.class));

        assertEquals(403, response.getStatusCodeValue());
    }



    @Test
    void testHandleUnprocessableEntityException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleUnProcessableEntityException(mock(UnProcessableEntityException.class));

        assertEquals(422, response.getStatusCodeValue());
    }

   /* @Test
    void TestHandleMethodArgumentNotValidException() throws Exception {

        MethodArgumentNotValidException methodArgumentNotValidException = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        DefaultMessageSourceResolvable defaultMessageSourceResolvable = mock(DefaultMessageSourceResolvable.class);
        when(bindingResult.getFieldErrors()).thenReturn(Arrays.asList(new FieldError("applicationDetailsRequest", "emailId", "please enter valid email id")));
        when(methodArgumentNotValidException.getBindingResult()).thenReturn(bindingResult);
        when(defaultMessageSourceResolvable.getDefaultMessage()).thenReturn("applicationDetailsRequest");
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleMethodArgumentNotValid(methodArgumentNotValidException, mock(HttpHeaders.class), HttpStatus.BAD_REQUEST, mock(WebRequest.class));

        assertEquals(400, response.getStatusCodeValue());
    }*/

    @Test
    void testHandleMissingRequestHeaderException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleMissingRequestHeaderException(mock(MissingRequestHeaderException.class), mock(WebRequest.class));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        HttpClientErrorException mockException = mock(HttpClientErrorException.class);
        when(mockException.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(mockException);

        assertEquals(500, response.getStatusCodeValue());
    }

    @Test
    void testHandleSizeLimitExceededException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleFileSizeLimitExceededException(mock(FileSizeLimitExceededException.class));
        assertEquals(413, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpServerErrorException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleHttpServerErrorException(mock(HttpServerErrorException.class));
        assertEquals(500, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorRouteNotFoundException() {
        String responseText ="404 Not Found: Requested route ('v1-msvc-application-flow-manager-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net') does not exist.";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);

        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.NOT_FOUND, "not found", null, responseBytes, charset));

        assertEquals(500, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorNotFoundException() {
        String responseText ="Record Not Found";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);

        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.NOT_FOUND, "not found", null, responseBytes, charset));

        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorConflictException() throws JsonProcessingException {
        String responseText = "{\"applicants\": [{\"mainApplicant\": false,\"status\": \"Failure\"}],\"brokerInfo\": null}";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.CONFLICT, "conflict", null, responseBytes, charset));
        assertEquals(409, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorUnsupportedMediaTypeException() throws JsonProcessingException {
        String responseText = "{unsuccessfulUploads}";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "UNSUPPORTED_MEDIA_TYPE", null, responseBytes, charset));
        assertEquals(415, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorPreconditionFailedException() throws JsonProcessingException {

        String responseText = "{unsuccessfulUploads}";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.PRECONDITION_FAILED, "Precondition Failed", null, responseBytes, charset));
        assertEquals(412, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorBadRequestException() throws JsonProcessingException {

        String responseText = "{BadRequest}";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "Bad Request", null, responseBytes, charset));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpServerErrorServiceUnavailableException() {
        String responseText ="Service unavailable";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);

        ResponseEntity<Object > response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.SERVICE_UNAVAILABLE, "Service unavailable", null, responseBytes, charset));

        assertEquals(500, response.getStatusCodeValue());
    }


    @Test
    void testHandleHttpClientErrorConflictException1() {
        String responseText = "Lock version has not been updated for this record.";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.CONFLICT, "conflict", null, responseBytes, charset));
        assertEquals(409, response.getStatusCodeValue());
    }

    @Test
    void testHandlePreConditionFailedException() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handlePreConditionFailedException(mock(PreConditionFailedException.class), mock(WebRequest.class));

        assertEquals(412, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpClientErrorPropertyValuationBadRequestException() throws JsonProcessingException {
        List<ValidationErrorDto> dtoList = new ArrayList<>();
        dtoList.add(ValidationErrorDto.builder().field("valuation.type").build());
        dtoList.add(ValidationErrorDto.builder().field("valuation.date").build());
        dtoList.add(ValidationErrorDto.builder().field("valuation.amount").build());
        RequestValidationDto validationDto = RequestValidationDto.builder().errorCount(3).errors(dtoList).build();
        String responseText = "{\"errorCount\":3,\"errors\":[{\"object\":\"PropertyDetails\",\"field\":\"valuation.type\",\"message\":\"Your value 'ABC123' is wrong. It must be one of the valid 'ValuationType' enum values: [RE_INSPECTION, DRIVE_BY_VALUATION, STANDARD_MORTGAGE_VALUATION, BUILDING_SURVEY, NO_VALUATION_REQUIRED, SUMMIT_EXISTING_VALUATION, HOME_BUYERS_REPORT, KERBSIDE_VALUATION, FULL_VALUATION, REVALUATION, AUTOMATED_VALUATION, AUTOMATED_RE_VALUATION, DESTOP_VALUATION, NEW_BUILD_RE_VALUATION].\"},{\"object\":\"PropertyDetails\",\"field\":\"valuation.amount\",\"message\":\"Please enter a valid amount\"},{\"object\":\"PropertyDetails\",\"field\":\"valuation.date\",\"message\":\"Invalid date value: date must be in format 'yyyy-MM-dd'\"}]}";
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        String errorMsg = "Bad Request: [{\"errorCount\":3,\"errors\":[{\"object\":\"PropertyDetails\",\"field\":\"valuation.amount\",\"message\":\"Please enter a valid amount\"},{\"object\":\"PropertyDetails\",\"field\":\"valuation.type\",\"message\":\"Your value 'ABC123' is wrong.\"},{\"object\":\"PropertyDetails\",\"field\":\"valuation.date\",\"message\":\"Invalid date value: date must be in format 'yyyy-MM-dd'\"}]";

        when(objectMapper.readValue(responseText, RequestValidationDto.class)).thenReturn(validationDto);
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpClientErrorException(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, errorMsg, null, responseBytes, charset));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleHttpMessageNotReadable() {
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<Object> response = applicationUpdateControllerAdvice.handleHttpMessageNotReadable(new HttpMessageNotReadableException("Failed", mock(HttpInputMessage.class)),mock(HttpHeaders.class),mock(HttpStatus.class), mock(WebRequest.class));

        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleJsonException(){
        when(errorMessageConfigReader.getMessage()).thenReturn(getErrorMap());
        ResponseEntity<RequestValidationDto> response = applicationUpdateControllerAdvice.handleJsonException(new JsonException("Error during patching document. Unrecognized property: 'dummy'"));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleSizeLimitExceededException1(){
        ResponseEntity<GlobalErrorResponseDto> response =  applicationUpdateControllerAdvice.handleSizeLimitExceededException(mock(SizeLimitExceededException.class));
        assertEquals(413, response.getStatusCodeValue());
    }

    @Test
    void testHandleTokenNotFoundException(){
        ResponseEntity<ErrorResponse> response =  applicationUpdateControllerAdvice.handleTokenNotFoundException(mock(AuthenticationException.class),mock(WebRequest.class));
        assertEquals(403, response.getStatusCodeValue());
    }

    @Test
    void testHandleTokenExpiredException(){
        ResponseEntity<ErrorResponse> response =  applicationUpdateControllerAdvice.handleTokenExpiredException(mock(TokenExpiredException.class),mock(WebRequest.class));
        assertEquals(403, response.getStatusCodeValue());
    }

    @Test
    void testHandleUnsupportedMediaTypeException(){
        ResponseEntity<Object> response =  applicationUpdateControllerAdvice.handleUnsupportedMediaTypeException((HttpClientErrorException.UnsupportedMediaType) HttpClientErrorException.UnsupportedMediaType.create(HttpStatus.UNSUPPORTED_MEDIA_TYPE,"UNSUPPORTED_MEDIA_TYPE",mock(HttpHeaders.class),"".getBytes(), StandardCharsets.UTF_8));
        assertEquals(415, response.getStatusCodeValue());
    }

    @Test
    void testHandleMethodArgumentNotValid(){

        ResponseEntity<Object> response =  applicationUpdateControllerAdvice.handleMethodArgumentNotValid(new MethodArgumentNotValidException(mock(MethodParameter.class),mock(BindingResult.class)),mock(HttpHeaders.class),mock(HttpStatus.class),mock(WebRequest.class));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleConstraintViolationException(){
        ResponseEntity<ErrorResponse> response =  applicationUpdateControllerAdvice.handleConstraintViolationException(mock(ConstraintViolationException.class),mock(WebRequest.class));
        assertEquals(400, response.getStatusCodeValue());
    }

    @Test
    void testHandleManualKeyInCaseUpdateExceptionServerError() {
        ResponseEntity<ErrorResponse> response = applicationUpdateControllerAdvice.handleManualKeyInCaseUpdateException
                (mock(ManualKeyInCaseUpdateException.class));
        assertEquals(500, response.getStatusCodeValue());
    }
}