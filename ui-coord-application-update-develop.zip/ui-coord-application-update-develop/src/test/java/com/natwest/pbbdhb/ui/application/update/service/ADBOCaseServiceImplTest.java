package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.adbo.dto.CaseDetailsDto;
import com.natwest.pbbdhb.ui.application.update.service.impl.ADBOCaseServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import javax.json.Json;
import javax.json.JsonPatch;
import javax.json.JsonReader;
import java.io.StringReader;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ADBOCaseServiceImplTest {
    public static final String CASE_ID = "CPKX1645787036574";
    private static final String NWB_BRAND = "NWB";
    public static final String BASE_URL =
            "https://msvc-case-adbo-v1-hboapiplatform.${hbo.env}.internal-paas-ms.api.banksvcs.net/";
    public static final String ADBO_CASE_ENDPOINT = "v1/case-adbo/{caseId}";

    @InjectMocks
    private ADBOCaseServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "msvcADBOCaseParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "msvcPatchADBOCaseEndpoint", ADBO_CASE_ENDPOINT);
    }

    @Test
    void testUpdateAdboCaseInformation() {
        String body = "[{\"op\": \"replace\", \"path\": \"/loanPurpose\", \"value\": \"ADDITIONAL_BORROWING\" }]";

        JsonReader jsonReader = Json.createReader(new StringReader(body));
        JsonPatch jsonPatch = Json.createPatch(jsonReader.readArray());
        when(restTemplate.exchange(any(), any(), any(), eq(CaseDetailsDto.class)))
                .thenReturn(new ResponseEntity<>(CaseDetailsDto.builder().build(), HttpStatus.OK));
        service.updateADBOCaseInformation(NWB_BRAND, CASE_ID, jsonPatch);
        verify(restTemplate).exchange(any(), any(), any(), eq(CaseDetailsDto.class));
    }

}
