package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.TestEnvironment;
import com.natwest.pbbdhb.ui.application.update.cucumber.token.AccessTokenGenerator;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.ADD_APPLICATION_NOTE_CASE_ID_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class AddApplicationNoteCaseIdStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(ADD_APPLICATION_NOTE_CASE_ID_JSON);
    }

    @Given("ApplicationNote Service case id endpoint exists")
    public void updateFIStatusServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    public boolean validateNumberSize(JsonNode number, int size) {
        long test = number.asLong();
        return test >= 0 && test < Math.pow(10, size);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        Assertions.assertTrue(predefined.contains(itemSearched.asText()));
    }

    private void validatePredefinedContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, PREDEFINED);
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGE));
    }


    private void validateNotFound(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(responseJsonNode.get(ERROR_MESSAGES).get(0).asText(),inputs.get(ERROR_MESSAGE).asText());
    }

    @When("User sends request to add application notes case id using input {string} and verify response code")
    public void userSendsRequestToAddNotesUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }



    @Then("AddApplicationNote - Validate the Coord Application Update case id service successful response {string}")
    public void verifySuccessfulResponse(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName).get(REQUEST_BODY);
        Assertions.assertTrue(responseString.contains(SUCCESSFUL_ADD_APPLICATION_MESSAGE));
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping brand predefined value {string}")
    public void validateTheResponseCodeBrand(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(BRAND));
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping case id value in bigdecimal up to 50 alphanumeric {string}")
    public void validateTheResponseCodeReferenceNumber(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(CASE_ID).size() < 51 );
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping addedByFullName value up to 50 chars - only in a-zA-Z range and space {string}")
    public void validateTheResponseCodeAddedByFullName(String inputName)  {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(ADDED_BY_FULL_NAME).asText().matches("^[a-zA-Z\\s]{1,50}$"));
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping addedByRACFID value up to 10 chars - only in a-zA-Z range {string}")
    public void validateTheResponseCodeAddedByRACFID(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(ADDED_BY_RACFID).asText().matches("^[a-zA-Z]{1,10}$"));
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping note value up to 4000 chars {string}")
    public void validateTheResponseCodeNote(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(NOTE).size() < 4001 );
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping invalid value for brand {string}")
    public void verifyResponseForTheInvalidValueForBrand(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping invalid value for case id {string}")
    public void verifyResponseForTheInvalidValueForReferenceNumber(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }


    @Then("AddApplicationNote - Validate the Coord Application Update case id service response keeping invalid value for note {string}")
    public void verifyResponseForTheInvalidValueForNote(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response  value that doesn't exists {string}")
    public void verifyResponseForReferenceNumberNotFound(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }


    @When("Enabling the under writer rights for case id user")
    public void enablingTheUnderWriterRightsForCaseIdUser() throws JsonProcessingException {
        AccessTokenGenerator.accessToken=null;
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equals("DEV")){
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            response = request.get("enableUwMockUser");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }


    @When("Enabling the other user rights for case id user")
    public void enablingTheOtherUserRightsForCaseIdUser() throws JsonProcessingException {
        AccessTokenGenerator.accessToken=null;
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equals("DEV")){
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            response = request.get("enableOtherMockUser");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }

   /* @Then("AddApplicationNote - Validate the error message for forbidden user {string}")
    public void addapplicationnoteValidateTheErrorMessageForForbiddenUser(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }*/

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response value that doesn't exists {string}")
    public void addapplicationnoteValidateTheCoordApplicationUpdateCaseIdServiceResponseValueThatDoesnTExists(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }

    @Then("AddApplicationNote - Validate the Coord Application Update case id service response for addedByFullName value that doesn't exists {string}")
    public void addapplicationnoteValidateTheCoordApplicationUpdateCaseIdServiceResponseForAddedByFullNameValueThatDoesnTExists(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }

}
