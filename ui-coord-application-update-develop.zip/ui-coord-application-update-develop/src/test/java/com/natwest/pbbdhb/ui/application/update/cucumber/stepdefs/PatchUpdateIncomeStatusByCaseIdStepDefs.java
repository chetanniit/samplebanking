package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.PATCH_UPDATE_INCOME_CASE_ID_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PatchUpdateIncomeStatusByCaseIdStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;
    private String incomeDataVersion;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PATCH_UPDATE_INCOME_CASE_ID_JSON);
    }

    @Given("PatchUpdateIncomeData Income Service case id endpoint exists")
    public void updateIncomeStatusInformationServiceCaseIdEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    private void validateBadRequest(String inputName) throws JsonProcessingException {
        JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
        if(responseJsonNode.get(RESPONSE_STATUS) == null){
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
            Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGE).asText()));
        }else{
            Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGE));
        }

    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGE).asText()));
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        Assertions.assertTrue(predefined.contains(itemSearched.asText()));
    }

    @When("PatchUpdateIncomeData - User sends case id request to get Income information using input {string} and verify response code")
    public void getIncomeInformationByCaseId(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).get(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        incomeDataVersion = responseJsonNode.get("validatedCaseIncomeDto").get(VERSION).asText();
    }

    @When("PatchUpdateIncomeData - User sends case id request to patch update Income information using input {string} and verify response code")
    public void updateIncomeInformationByCaseId(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        if(incomeDataVersion == null){
            incomeDataVersion = testInput.get(REQUEST_BODY).get(VERSION).asText();
        }
        doc.set("requestBody.version", incomeDataVersion);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).patch(inputsAsJsonNode.get(PATH).asText());
        log.info("response123:{} " ,response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Verify Income information in Patch Income case id response output for the input {string}")
    public void verifyIncomeSuccessfulResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());
        Assert.assertTrue(responseJsonNode.get("version").asInt()>=1);
        Assert.assertEquals("VALIDATED", responseJsonNode.get("status").asText());
    }

    @Then("Verify error code 404 Not Found for the UI Coord Application patch Income service response for the input {string}")
    public void verifyPatchIncomeByCaseIdNotFoundResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(404, response.getStatusCode());
    }


    @Then("Verify error code 409 Conflict for the Patch Update Income Status service response for the input {string}")
    public void verifyIncomeConflictResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(409, response.getStatusCode());
    }

    @Then("Verify error code 400 bad request for invalid brand for the Update Income Status service response for the input {string}")
    public void verifyPropertyBadRequestResponse(String inputName) throws JsonProcessingException {
        validateBadRequest(inputName);
    }
}
