package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerAddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.TeleMessageRequestServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createUserInformationResponse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class TeleMessageRequestServiceImplTest {

    @InjectMocks
    TeleMessageRequestServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AuthorizationService authorizationService;

    @Mock
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Mock
    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(service, "flowManagerParentEndpoint", "https://v1-msvc-application-flow-manager-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net/mortgages/v1/flow-manager");
        ReflectionTestUtils.setField(service, "addTelemessageRequestEndpoint", "/application/{referenceNumber}/telemessage");
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @Test
    void testAddTeleMessageRequest() throws JsonProcessingException {
        AddTeleMessageRequest request = AddTeleMessageRequest.builder().build();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerAddTeleMessageRequest(any()))
                .thenReturn(FlowManagerAddTeleMessageRequest.builder().build());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("Success", HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(NOTES_ADDED_SUCCESSFULLY));
        service.addTeleMessageRequest(NWB_BRAND, REFERENCE_NUMBER, request);
        verify(authorizationService).getUserData();
        verify(flowManagerRequestMapper).toFlowManagerAddTeleMessageRequest(any());
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testAddTeleMessageRequestJsonParsingError() throws JsonProcessingException {
        AddTeleMessageRequest request = AddTeleMessageRequest.builder().build();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerAddTeleMessageRequest(any()))
                .thenReturn(FlowManagerAddTeleMessageRequest.builder().build());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("Success", HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenThrow(JsonProcessingException.class);
        service.addTeleMessageRequest(NWB_BRAND, REFERENCE_NUMBER, request);
        verify(authorizationService).getUserData();
        verify(flowManagerRequestMapper).toFlowManagerAddTeleMessageRequest(any());
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

}
