package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.POST_NOTIFICATION_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PostNotificationReferenceNumberStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(POST_NOTIFICATION_JSON);
    }

    @Given("Send Reminder endpoint exists")
    public void sendReminderEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User push request for Send Reminder using input {string} and verify response code")
    public void userPushRequestForSendReminderUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
       ApiTestUtil.createRequestForInputParams(testInput, request, path);
       response = request.post(inputsAsJsonNode.get(PATH).asText());
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }
    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGES).asText().contains(error_message_Array.asText()));
    }


    @Then("Verify response code while providing valid input in the request parameter of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeWhileProvidingValidInputInTheRequestParameterOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) {
        Assertions.assertEquals(202, response.getStatusCode());
        Assertions.assertTrue(response.asPrettyString().contains("Reminder has been sent successfully"));
    }

    @Then("Verify response code and error message while providing invalid brand name of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidBrandNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(400, response.getStatusCode());
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  Reference Number of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidReferenceNumberOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  Sequence Number of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidSequenceNumberOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  chasedByFullName of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByFullNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  chasedByRACFID of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByRACFIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  requestID of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidRequestIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while some of the requestID has status as Received of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileSomeOfTheRequestIDHasStatusAsReceivedOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String inputName) {
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertTrue(response.asPrettyString().contains("Document request not found for requestId: 62e8224151e1a210934c3a27 referenceNumber 84154339 and caseId ID2022022110019992"));
    }

    @Then("Verify response code and error message while all the requestID provided in request have status as Received along with notificationRequired is false in ui coord application update for the input {string}")
    public void verifyResponseCodeAndErrorMessageWhileAllTheRequestIDProvidedInRequestHaveStatusAsReceivedAlongWithNotificationRequiredIsFalseInUiCoordApplicationUpdateForTheInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertTrue(response.asPrettyString().contains("Document request not found for requestId: 628244e21b712d64171bd211 referenceNumber 84154339 and caseId ID2022022110019992"));
    }

    @Then("Verify response code while providing valid input in the request parameter of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeWhileProvidingValidInputInTheRequestParameterOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) {
        Assertions.assertEquals(202, response.getStatusCode());
        Assertions.assertTrue(response.prettyPrint().contains("Reminder has been sent successfully"));
    }

    @Then("Verify response code and error message while providing invalid brand name of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidBrandNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(400, response.getStatusCode());
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  Reference Number of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidReferenceNumberOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  Sequence Number of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidSequenceNumberOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  chasedByFullName of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByFullNameOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  chasedByRACFID of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidChasedByRACFIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while providing invalid  requestID of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileProvidingInvalidRequestIDOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify response code and error message while some of the requestID has status as Received of Send Reminder endpoint in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileSomeOfTheRequestIDHasStatusAsReceivedOfSendReminderEndpointInUiCoordApplicationUpdateForTheRbsInput(String inputName) {
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertTrue(response.prettyPrint().contains("Document request not found for requestId: 62a782eab0920561bbf5d2hh referenceNumber 28089581 and caseId Test28089581"));
    }

    @Then("Verify response code and error message while all the requestID provided in request have status as Received along with notificationRequired is false in ui coord application update for the rbs input {string}")
    public void verifyResponseCodeAndErrorMessageWhileAllTheRequestIDProvidedInRequestHaveStatusAsReceivedAlongWithNotificationRequiredIsFalseInUiCoordApplicationUpdateForTheRbsInput(String inputName) throws JsonProcessingException {
        Assertions.assertEquals(404, response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertTrue(inputs.get(ERROR_MESSAGES).asText().contains(error_message_Array.asText()));
    }


    @Then("Validate the error message for forbidden user for send reminder {string}")
    public void validateTheErrorMessageForForbiddenUserForSendReminder(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify response code while providing valid rbs input in the request parameter of Send Reminder endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeWhileProvidingValidRbsInputInTheRequestParameterOfSendReminderEndpointInUiCoordApplicationUpdateForTheInput(String arg0) {
        Assertions.assertEquals(202, response.getStatusCode());
        Assertions.assertTrue(response.prettyPrint().contains("Reminder has been sent successfully"));
    }

    @Then("Verify in ui coord application update ref success response code for the input {string}")
    public void verifyInUiCoordApplicationUpdateRefSuccessResponseCodeForTheInput(String arg0) {
        Assertions.assertEquals(202, response.getStatusCode());
    }

    @Then("Verify in ui coord application update ref error response code when precondition failed if any of the requestId is review or closed for the input {string}")
    public void verifyInUiCoordApplicationUpdateRefErrorResponseCodeWhenPreconditionFailedIfAnyOfTheRequestIdIsReviewOrClosedForTheInput(String arg0) {
        Assertions.assertEquals(412, response.getStatusCode());
    }

    @Then("Verify in ui coord application update ref error response code when caseId or reference number are not present in document collection in for the input {string}")
    public void verifyInUiCoordApplicationUpdateRefErrorResponseCodeWhenCaseIdOrReferenceNumberAreNotPresentInDocumentCollectionInForTheInput(String arg0) {
        Assertions.assertEquals(404, response.getStatusCode());
    }

    @Then("Verify in ui coord application update ref error response code when requestId are not present in document collection for the input {string}")
    public void verifyInUiCoordApplicationUpdateRefErrorResponseCodeWhenRequestIdAreNotPresentInDocumentCollectionForTheInput(String arg0) {
        Assertions.assertEquals(412, response.getStatusCode());
    }

    @Then("Verify in ui coord application update ref error response code when there is any validation error for the input {string}")
    public void verifyInUiCoordApplicationUpdateRefErrorResponseCodeWhenThereIsAnyValidationErrorForTheInput(String arg0) {
        Assertions.assertEquals(400, response.getStatusCode());
    }
}
