package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.FlowManagerAddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentInfo;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.FIServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Objects;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class FIServiceImplTest {

    @InjectMocks
    private FIServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AuthorizationService authorizationService;

    @Mock
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Mock
    private ObjectMapper objectMapper;

    public static final String BASE_URL = "http://11.15.0.124:8082/mortgages/v1/flow-manager/";
    public static final String ENDPOINT = "addDocuments";

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(service, "flowManagerParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "flowManagerApplicantEndpoint", ENDPOINT);
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @Test
    void testAddFI() {
        FIRequest fiRequest = createFIRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(flowManagerRequestMapper.toAddDocumentResponse(any())).thenReturn(AddDocumentResponse.builder().message(ADD_FI_RESPONSE).build());
        when(restTemplate.exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class)))
                .thenReturn(new ResponseEntity<>(FlowManagerAddDocumentResponse.builder().message(ADD_FI_RESPONSE).build(), HttpStatus.CREATED));
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND, "84153756", null, fiRequest);
        assertEquals(ADD_FI_RESPONSE, Objects.requireNonNull(response.getBody()).getMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testAddFIConflict() {
        String responseText = FlowManagerAddDocumentResponse.builder().build().toString();
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        HttpClientErrorException httpClientErrorException = HttpClientErrorException.create(HttpStatus.CONFLICT, responseText, null, responseBytes, charset);
        FIRequest fiRequest = createFIRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(flowManagerRequestMapper.toAddDocumentResponse(any())).thenReturn(AddDocumentResponse.builder().message(ADD_FI_RESPONSE).build());
        when(restTemplate.exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class))).thenThrow(httpClientErrorException);
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND, "84153756", null, fiRequest);
        assertEquals(ADD_FI_RESPONSE, Objects.requireNonNull(response.getBody()).getMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testAddFIJsonProcessingException() throws JsonProcessingException {
        String responseText = FlowManagerAddDocumentResponse.builder().build().toString();
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        HttpClientErrorException httpClientErrorException = HttpClientErrorException.create(HttpStatus.CONFLICT, responseText, null, responseBytes, charset);
        FIRequest fiRequest = createFIRequest();
        when(objectMapper.readValue(anyString(), eq(FlowManagerAddDocumentResponse.class))).thenThrow(JsonProcessingException.class);
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(flowManagerRequestMapper.toAddDocumentResponse(any())).thenReturn(AddDocumentResponse.builder().message(ADD_FI_RESPONSE).build());
        when(restTemplate.exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class))).thenThrow(httpClientErrorException);
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND, "84153756", null, fiRequest);
        assertEquals(ADD_FI_RESPONSE, Objects.requireNonNull(response.getBody()).getMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testAddFIJsonMappingException() throws JsonProcessingException {
        String responseText = FlowManagerAddDocumentResponse.builder().build().toString();
        Charset charset = StandardCharsets.UTF_8;
        byte[] responseBytes = responseText.getBytes(charset);
        HttpClientErrorException httpClientErrorException = HttpClientErrorException.create(HttpStatus.CONFLICT, responseText, null, responseBytes, charset);
        FIRequest fiRequest = createFIRequest();
        when(objectMapper.readValue(anyString(), eq(FlowManagerAddDocumentResponse.class))).thenThrow(JsonMappingException.class);
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(flowManagerRequestMapper.toAddDocumentResponse(any())).thenReturn(AddDocumentResponse.builder().message(ADD_FI_RESPONSE).build());
        when(restTemplate.exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class))).thenThrow(httpClientErrorException);
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND, "84153756", null, fiRequest);
        assertEquals(ADD_FI_RESPONSE, Objects.requireNonNull(response.getBody()).getMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testAddFIException() {
        FIRequest fiRequest = createFIRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(restTemplate.exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class)))
                .thenThrow(HttpClientErrorException.class);
        assertThrows(HttpClientErrorException.class, () -> service.addFI(NWB_BRAND, "84153756", null, fiRequest));
        verify(restTemplate).exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testUpdateFIStatus() {
        FIStatusRequest fiStatusRequest = createFIStatusRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIStatusRequest(any())).thenReturn(createFlowManagerFIStatusRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        when(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        ResponseEntity<SuccessResponse> response = service.updateFIState(NWB_BRAND,fiStatusRequest,"84153756",null,"TEST123456789", "REVIEWED");
        assertEquals( HttpStatus.OK, response.getStatusCode());

        verify(restTemplate, Mockito.times(1)).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testUpdateFIStatusWithNote() {
        FIStatusRequest fiStatusRequest = createFIStatusWithNoteRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIStatusRequest(any())).thenReturn(createFlowManagerFIStatusWithNoteRequest());
        when(flowManagerRequestMapper.toFlowManagerAddNoteRequest(any())).thenReturn(createFlowManagerAddNoteRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        ResponseEntity<SuccessResponse> response = service.updateFIState(NWB_BRAND,fiStatusRequest,"84153756", null,"TEST123456789", "REVIEWED");
        assertEquals(HttpStatus.OK, response.getStatusCode());

        verify(restTemplate, Mockito.times(2)).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testAddFICaseId() {
        FIRequest fiRequest = createFIRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(flowManagerRequestMapper.toAddDocumentResponse(any())).thenReturn(AddDocumentResponse.builder().message(ADD_FI_RESPONSE).build());
        when(restTemplate.exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class)))
                .thenReturn(new ResponseEntity<>(FlowManagerAddDocumentResponse.builder().message(ADD_FI_RESPONSE).build(), HttpStatus.OK));
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND, null, CASE_ID, fiRequest);
        assertEquals(ADD_FI_RESPONSE, Objects.requireNonNull(response.getBody()).getMessage());
        verify(restTemplate).exchange(any(), any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testUpdateFIStatusWithNoteCaseId() {
        FIStatusRequest fiStatusRequest = createFIStatusWithNoteRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIStatusRequest(any())).thenReturn(createFlowManagerFIStatusWithNoteRequest());
        when(flowManagerRequestMapper.toFlowManagerAddNoteRequest(any())).thenReturn(createFlowManagerAddNoteRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        ResponseEntity<SuccessResponse> response = service.updateFIState(NWB_BRAND,fiStatusRequest,null, CASE_ID,"TEST123456789","REVIEWED");
        assertEquals(HttpStatus.OK, response.getStatusCode());

        verify(restTemplate, Mockito.times(2)).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testUpdateFIStatusCaseId() {
        FIStatusRequest fiStatusRequest = createFIStatusRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIStatusRequest(any())).thenReturn(createFlowManagerFIStatusRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        when(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        ResponseEntity<SuccessResponse> response = service.updateFIState(NWB_BRAND,fiStatusRequest,null,CASE_ID,"TEST123456789","REVIEWED");
        assertEquals( HttpStatus.OK, response.getStatusCode());

        verify(restTemplate, Mockito.times(1)).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testJsonProcessingException() throws JsonProcessingException {
        FIRequest fiRequest = createFIRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIRequest(any())).thenReturn(createFlowManagerFIRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(FlowManagerAddDocumentResponse.class)))
                .thenReturn(new ResponseEntity<>(FlowManagerAddDocumentResponse.builder().message("SUCCESS").build(), HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(FlowManagerAddDocumentResponse.class))).thenThrow(JsonProcessingException.class);
        ResponseEntity<AddDocumentResponse> response = service.addFI(NWB_BRAND, null, CASE_ID, fiRequest);

        assertNull(response.getBody());
        verify(restTemplate).exchange(any(),any(), any(), eq(FlowManagerAddDocumentResponse.class));
    }

    @Test
    void testUpdateStatusJsonProcessingException() throws JsonProcessingException {
        FIStatusRequest fiStatusRequest = createFIStatusRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerFIStatusRequest(any())).thenReturn(createFlowManagerFIStatusRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ABC", HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenThrow(JsonProcessingException.class);
        ResponseEntity<SuccessResponse> response = service.updateFIState(NWB_BRAND,fiStatusRequest,null,CASE_ID,"TEST123456789","REVIEWED");


        assertNull(response.getBody());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testUpdateStatusCloseState412Exception() {
        FIStatusRequest fiStatusRequest = createFIStatusRequest();
        fiStatusRequest.setCustomerResponse("customer response");
        fiStatusRequest.setDocumentInfo(Collections.singletonList(DocumentInfo.builder().originalFileName("testFile.pdf").build()));

        PreConditionFailedException exception = assertThrows(PreConditionFailedException.class,
                () -> service.updateFIState(NWB_BRAND,fiStatusRequest,null,CASE_ID,"TEST123456789","CLOSED"));

        verifyNoInteractions(restTemplate);
        verifyNoInteractions(authorizationService);
    }


    @Test
    void tesDissociateDocumentErrors() {


        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "Document not found"));
        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class, () -> service.disassociateDocument(NWB_BRAND, CASE_ID, "TEST123456789", "123456"));
        verify(restTemplate, Mockito.times(1)).exchange(any(),any(), any(), eq(String.class));


    }

}
